
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/cilium/bpf_lxc.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <__check_cluster_id_bits>:
       0:      	adrp	x8, 0x0 <__check_cluster_id_bits>
       4:      	ldr	x8, [x8]
       8:      	ldr	wzr, [x8]
       c:      	ret

0000000000000010 <__check_device_mtu>:
      10:      	adrp	x8, 0x0 <__check_cluster_id_bits>
      14:      	ldr	x8, [x8]
      18:      	ldrh	wzr, [x8]
      1c:      	ret

Disassembly of section tc/tail:

0000000000000000 <tail_drop_notify>:
       0:      	sub	sp, sp, #0xa0
       4:      	str	x29, [sp, #0x50]
       8:      	stp	x30, x25, [sp, #0x60]
       c:      	stp	x24, x23, [sp, #0x70]
      10:      	stp	x22, x21, [sp, #0x80]
      14:      	stp	x20, x19, [sp, #0x90]
      18:      	adrp	x8, 0x0 <tail_drop_notify>
      1c:      	ldr	w23, [x0, #0x38]
      20:      	mov	x19, x0
      24:      	ldr	x8, [x8]
      28:      	ldrb	w8, [x8]
      2c:      	cbz	w8, 0x54 <tail_drop_notify+0x54>
      30:      	str	wzr, [sp, #0x10]
      34:      	mov	w8, #0x1                // =1
      38:      	adrp	x0, 0x0 <tail_drop_notify>
      3c:      	add	x1, sp, #0x10
      40:      	ldr	x0, [x0]
      44:      	blr	x8
      48:      	cbz	x0, 0x58 <tail_drop_notify+0x58>
      4c:      	ldr	x0, [x0]
      50:      	b	0x58 <tail_drop_notify+0x58>
      54:      	mov	x0, xzr
      58:      	mov	w20, #0x2               // =2
      5c:      	adrp	x9, 0x0 <tail_drop_notify>
      60:      	ldr	w25, [x19, #0x70]
      64:      	ldr	w22, [x19, #0x40]
      68:      	mov	w8, w25
      6c:      	str	x20, [sp, #0x40]
      70:      	ldr	x9, [x9]
      74:      	ldr	w10, [x9]
      78:      	cbz	w10, 0x1a4 <tail_drop_notify+0x1a4>
      7c:      	str	x0, [sp, #0x8]
      80:      	adrp	x8, 0x0 <tail_drop_notify>
      84:      	ldr	x8, [x8]
      88:      	ldr	w29, [x8]
      8c:      	ldr	w24, [x9]
      90:      	mov	w8, #0x5                // =5
      94:      	blr	x8
      98:      	str	w20, [sp, #0x5c]
      9c:      	mov	x21, x0
      a0:      	mov	w8, #0x1                // =1
      a4:      	adrp	x0, 0x0 <tail_drop_notify>
      a8:      	add	x1, sp, #0x5c
      ac:      	ldr	x0, [x0]
      b0:      	blr	x8
      b4:      	mov	x20, x0
      b8:      	cbnz	x0, 0xe4 <tail_drop_notify+0xe4>
      bc:      	str	xzr, [sp, #0x48]
      c0:      	mov	w8, #0x2                // =2
      c4:      	adrp	x0, 0x0 <tail_drop_notify>
      c8:      	add	x1, sp, #0x5c
      cc:      	add	x2, sp, #0x48
      d0:      	mov	w3, wzr
      d4:      	add	x20, sp, #0x48
      d8:      	ldr	x0, [x0]
      dc:      	blr	x8
      e0:      	tbnz	w0, #0x1f, 0x264 <tail_drop_notify+0x264>
      e4:      	mov	w8, #0x1                // =1
      e8:      	adrp	x0, 0x0 <tail_drop_notify>
      ec:      	add	x1, sp, #0x40
      f0:      	ldr	x0, [x0]
      f4:      	blr	x8
      f8:      	cbz	x0, 0x160 <tail_drop_notify+0x160>
      fc:      	ldr	x8, [x0]
     100:      	mov	w9, #0xca00             // =51712
     104:      	movk	w9, #0x3b9a, lsl #16
     108:      	sub	x10, x21, x8
     10c:      	cmp	x10, x9
     110:      	b.ls	0x18c <tail_drop_notify+0x18c>
     114:      	mov	x11, #0x5a53            // =23123
     118:      	lsr	x8, x10, #9
     11c:      	neg	x10, x10
     120:      	movk	x11, #0xa09b, lsl #16
     124:      	movk	x11, #0xb82f, lsl #32
     128:      	movk	x11, #0x44, lsl #48
     12c:      	umulh	x8, x8, x11
     130:      	lsr	x11, x8, #11
     134:      	ldr	x8, [x0, #0x8]
     138:      	madd	x9, x11, x9, x10
     13c:      	madd	x8, x11, x24, x8
     140:      	add	x9, x21, x9
     144:      	cmp	x8, x29
     148:      	stp	x9, x8, [x0]
     14c:      	b.ls	0x158 <tail_drop_notify+0x158>
     150:      	mov	x8, x29
     154:      	str	x29, [x0, #0x8]
     158:      	cbnz	x8, 0x194 <tail_drop_notify+0x194>
     15c:      	b	0x284 <tail_drop_notify+0x284>
     160:      	sub	x8, x24, #0x1
     164:      	adrp	x0, 0x0 <tail_drop_notify>
     168:      	add	x1, sp, #0x40
     16c:      	stp	x21, x8, [sp, #0x10]
     170:      	mov	w8, #0x2                // =2
     174:      	add	x2, sp, #0x10
     178:      	mov	w3, wzr
     17c:      	ldr	x0, [x0]
     180:      	blr	x8
     184:      	tbz	w0, #0x1f, 0x19c <tail_drop_notify+0x19c>
     188:      	b	0x284 <tail_drop_notify+0x284>
     18c:      	ldr	x8, [x0, #0x8]
     190:      	cbz	x8, 0x284 <tail_drop_notify+0x284>
     194:      	sub	x8, x8, #0x1
     198:      	str	x8, [x0, #0x8]
     19c:      	ldr	w8, [x19, #0x70]
     1a0:      	ldr	x0, [sp, #0x8]
     1a4:      	adrp	x10, 0x0 <tail_drop_notify>
     1a8:      	mov	w11, #0xdd86            // =56710
     1ac:      	ldr	x10, [x10]
     1b0:      	ldrh	w9, [x19, #0xb4]
     1b4:      	ldr	w10, [x10]
     1b8:      	cmp	w9, w11
     1bc:      	cset	w9, eq
     1c0:      	cmp	w8, w10
     1c4:      	csel	w8, w8, w10, lo
     1c8:      	adrp	x10, 0x0 <tail_drop_notify>
     1cc:      	ldr	x10, [x10]
     1d0:      	ldrh	w14, [x10]
     1d4:      	ldr	w15, [x19, #0x98]
     1d8:      	ldp	w10, w11, [x19, #0x30]
     1dc:      	ldr	w12, [x19, #0x3c]
     1e0:      	ldr	x13, [x19, #0x10]
     1e4:      	cbz	x13, 0x1ec <tail_drop_notify+0x1ec>
     1e8:      	ldr	w13, [x13, #0xe0]
     1ec:      	mov	w16, #0x1               // =1
     1f0:      	lsr	w17, w22, #8
     1f4:      	strh	w14, [sp, #0x12]
     1f8:      	stp	w15, w25, [sp, #0x14]
     1fc:      	lsr	w14, w22, #16
     200:      	mov	w15, #0x3               // =3
     204:      	strb	w16, [sp, #0x10]
     208:      	lsr	w16, w23, #8
     20c:      	strb	w23, [sp, #0x11]
     210:      	adrp	x1, 0x0 <tail_drop_notify>
     214:      	add	x3, sp, #0x10
     218:      	mov	w4, #0x30               // =48
     21c:      	strh	w8, [sp, #0x1c]
     220:      	strh	w15, [sp, #0x1e]
     224:      	stp	w10, w11, [sp, #0x20]
     228:      	mov	w10, #-0x1              // =-1
     22c:      	orr	x2, x10, x8, lsl #32
     230:      	str	w12, [sp, #0x28]
     234:      	strh	w14, [sp, #0x2c]
     238:      	strb	w17, [sp, #0x2e]
     23c:      	strb	w16, [sp, #0x2f]
     240:      	str	w13, [sp, #0x30]
     244:      	strb	w9, [sp, #0x34]
     248:      	mov	w9, #0x19               // =25
     24c:      	sturh	wzr, [sp, #0x35]
     250:      	strb	wzr, [sp, #0x37]
     254:      	str	x0, [sp, #0x38]
     258:      	ldr	x1, [x1]
     25c:      	mov	x0, x19
     260:      	blr	x9
     264:      	and	w0, w22, #0xff
     268:      	ldp	x20, x19, [sp, #0x90]
     26c:      	ldr	x29, [sp, #0x50]
     270:      	ldp	x22, x21, [sp, #0x80]
     274:      	ldp	x24, x23, [sp, #0x70]
     278:      	ldp	x30, x25, [sp, #0x60]
     27c:      	add	sp, sp, #0xa0
     280:      	ret
     284:      	ldr	x8, [x20]
     288:      	add	x8, x8, #0x1
     28c:      	str	x8, [x20]
     290:      	b	0x264 <tail_drop_notify+0x264>
     294:      	nop
     298:      	nop
     29c:      	nop

00000000000002a0 <tail_icmp6_send_time_exceeded>:
     2a0:      	sub	sp, sp, #0x100
     2a4:      	str	x30, [sp, #0xc0]
     2a8:      	stp	x24, x23, [sp, #0xd0]
     2ac:      	stp	x22, x21, [sp, #0xe0]
     2b0:      	stp	x20, x19, [sp, #0xf0]
     2b4:      	mov	w8, #0x3a               // =58
     2b8:      	ldp	w20, w22, [x0, #0x30]
     2bc:      	str	wzr, [x0, #0x30]
     2c0:      	adrp	x23, 0x0 <tail_drop_notify>
     2c4:      	adrp	x1, 0x0 <tail_drop_notify>
     2c8:      	add	x3, sp, #0xa8
     2cc:      	mov	w2, #-0x1               // =-1
     2d0:      	stp	xzr, xzr, [sp, #0x60]
     2d4:      	mov	w4, #0x14               // =20
     2d8:      	mov	x19, x0
     2dc:      	stp	xzr, xzr, [sp, #0x50]
     2e0:      	add	x21, sp, #0x20
     2e4:      	str	xzr, [sp, #0x28]
     2e8:      	strh	wzr, [sp, #0x1c]
     2ec:      	strb	w8, [sp, #0x18]
     2f0:      	adrp	x8, 0x0 <tail_drop_notify>
     2f4:      	stp	xzr, xzr, [sp, #0x40]
     2f8:      	stp	xzr, xzr, [sp, #0x30]
     2fc:      	ldr	x8, [x8]
     300:      	ldr	x9, [x8]
     304:      	str	x9, [sp, #0x10]
     308:      	ldr	x8, [x8, #0x8]
     30c:      	str	x8, [sp, #0x8]
     310:      	mov	w8, #0x3                // =3
     314:      	str	x8, [sp, #0x20]
     318:      	mov	w8, #0xe02              // =3586
     31c:      	strh	w8, [sp, #0xa8]
     320:      	ldr	x23, [x23]
     324:      	ldrh	w8, [x23]
     328:      	str	xzr, [sp, #0xb0]
     32c:      	str	wzr, [sp, #0xb8]
     330:      	strh	w8, [sp, #0xaa]
     334:      	ldr	w8, [x0, #0x98]
     338:      	str	w8, [sp, #0xac]
     33c:      	mov	w8, #0x19               // =25
     340:      	ldr	x1, [x1]
     344:      	blr	x8
     348:      	mov	w8, #0x1a               // =26
     34c:      	add	x2, x21, #0x8
     350:      	mov	x0, x19
     354:      	mov	w1, w20
     358:      	mov	w3, #0x28               // =40
     35c:      	blr	x8
     360:      	tbnz	w0, #0x1f, 0x7ec <tail_icmp6_send_time_exceeded+0x54c>
     364:      	mov	w8, #0x9                // =9
     368:      	add	w1, w20, #0x6
     36c:      	add	x2, sp, #0x18
     370:      	mov	x0, x19
     374:      	mov	w3, #0x1                // =1
     378:      	mov	w4, wzr
     37c:      	blr	x8
     380:      	tbnz	w0, #0x1f, 0x7f4 <tail_icmp6_send_time_exceeded+0x554>
     384:      	ldrb	w8, [sp, #0x2e]
     388:      	cmp	w8, #0x6
     38c:      	b.eq	0x4b8 <tail_icmp6_send_time_exceeded+0x218>
     390:      	cmp	w8, #0x3a
     394:      	b.eq	0x3a0 <tail_icmp6_send_time_exceeded+0x100>
     398:      	cmp	w8, #0x11
     39c:      	b.ne	0x7fc <tail_icmp6_send_time_exceeded+0x55c>
     3a0:      	mov	w8, #0x1a               // =26
     3a4:      	add	w1, w20, #0x28
     3a8:      	add	x2, x21, #0x30
     3ac:      	mov	x0, x19
     3b0:      	mov	w3, #0x8                // =8
     3b4:      	blr	x8
     3b8:      	tbnz	w0, #0x1f, 0x7ec <tail_icmp6_send_time_exceeded+0x54c>
     3bc:      	mov	w8, #0x1c               // =28
     3c0:      	add	x2, sp, #0x20
     3c4:      	mov	x0, xzr
     3c8:      	mov	w1, wzr
     3cc:      	mov	w3, #0x38               // =56
     3d0:      	mov	w4, wzr
     3d4:      	mov	w21, #0x1c              // =28
     3d8:      	add	x24, sp, #0x20
     3dc:      	blr	x8
     3e0:      	mov	w8, #0x38000000         // =939524096
     3e4:      	mov	w4, w0
     3e8:      	add	x2, x24, #0x10
     3ec:      	str	w8, [sp, #0xa8]
     3f0:      	mov	w8, #0x3a000000         // =973078528
     3f4:      	mov	x0, xzr
     3f8:      	mov	w1, wzr
     3fc:      	str	w8, [sp, #0x98]
     400:      	mov	w8, #0x1c               // =28
     404:      	mov	w3, #0x10               // =16
     408:      	blr	x8
     40c:      	mov	w8, #0x1c               // =28
     410:      	mov	w4, w0
     414:      	add	x2, x24, #0x20
     418:      	mov	x0, xzr
     41c:      	mov	w1, wzr
     420:      	mov	w3, #0x10               // =16
     424:      	blr	x8
     428:      	mov	w8, #0x1c               // =28
     42c:      	mov	w4, w0
     430:      	add	x2, sp, #0xa8
     434:      	mov	x0, xzr
     438:      	mov	w1, wzr
     43c:      	mov	w3, #0x4                // =4
     440:      	blr	x8
     444:      	mov	w4, w0
     448:      	add	x2, sp, #0x98
     44c:      	mov	x0, xzr
     450:      	mov	w1, wzr
     454:      	mov	w3, #0x4                // =4
     458:      	blr	x21
     45c:      	mov	w8, #0x3800             // =14336
     460:      	mov	w9, #0x26               // =38
     464:      	mov	w21, w0
     468:      	strh	w8, [sp, #0x1c]
     46c:      	ldrh	w8, [sp, #0x2c]
     470:      	mov	x0, x19
     474:      	mov	w2, wzr
     478:      	ldr	w10, [x19, #0x70]
     47c:      	rev	w8, w8
     480:      	sub	w8, w10, w8, lsr #16
     484:      	add	w1, w8, #0x38
     488:      	blr	x9
     48c:      	tbnz	w0, #0x1f, 0x7f4 <tail_icmp6_send_time_exceeded+0x554>
     490:      	mov	w8, #0x9                // =9
     494:      	add	w1, w20, #0x28
     498:      	add	x2, sp, #0x20
     49c:      	mov	x0, x19
     4a0:      	mov	w3, #0x38               // =56
     4a4:      	mov	w4, wzr
     4a8:      	blr	x8
     4ac:      	tbnz	w0, #0x1f, 0x7f4 <tail_icmp6_send_time_exceeded+0x554>
     4b0:      	mov	w8, #0x9                // =9
     4b4:      	b	0x5cc <tail_icmp6_send_time_exceeded+0x32c>
     4b8:      	mov	w8, #0x1a               // =26
     4bc:      	add	w1, w20, #0x28
     4c0:      	add	x2, x21, #0x30
     4c4:      	mov	x0, x19
     4c8:      	mov	w3, #0x14               // =20
     4cc:      	blr	x8
     4d0:      	tbnz	w0, #0x1f, 0x7ec <tail_icmp6_send_time_exceeded+0x54c>
     4d4:      	mov	w8, #0x1c               // =28
     4d8:      	add	x2, sp, #0x20
     4dc:      	mov	x0, xzr
     4e0:      	mov	w1, wzr
     4e4:      	mov	w3, #0x44               // =68
     4e8:      	mov	w4, wzr
     4ec:      	mov	w21, #0x1c              // =28
     4f0:      	add	x24, sp, #0x20
     4f4:      	blr	x8
     4f8:      	mov	w8, #0x44000000         // =1140850688
     4fc:      	mov	w4, w0
     500:      	add	x2, x24, #0x10
     504:      	str	w8, [sp, #0xa8]
     508:      	mov	w8, #0x3a000000         // =973078528
     50c:      	mov	x0, xzr
     510:      	mov	w1, wzr
     514:      	str	w8, [sp, #0x98]
     518:      	mov	w8, #0x1c               // =28
     51c:      	mov	w3, #0x10               // =16
     520:      	blr	x8
     524:      	mov	w8, #0x1c               // =28
     528:      	mov	w4, w0
     52c:      	add	x2, x24, #0x20
     530:      	mov	x0, xzr
     534:      	mov	w1, wzr
     538:      	mov	w3, #0x10               // =16
     53c:      	blr	x8
     540:      	mov	w8, #0x1c               // =28
     544:      	mov	w4, w0
     548:      	add	x2, sp, #0xa8
     54c:      	mov	x0, xzr
     550:      	mov	w1, wzr
     554:      	mov	w3, #0x4                // =4
     558:      	blr	x8
     55c:      	mov	w4, w0
     560:      	add	x2, sp, #0x98
     564:      	mov	x0, xzr
     568:      	mov	w1, wzr
     56c:      	mov	w3, #0x4                // =4
     570:      	blr	x21
     574:      	mov	w8, #0x4400             // =17408
     578:      	mov	w9, #0x26               // =38
     57c:      	mov	w21, w0
     580:      	strh	w8, [sp, #0x1c]
     584:      	ldrh	w8, [sp, #0x2c]
     588:      	mov	x0, x19
     58c:      	mov	w2, wzr
     590:      	ldr	w10, [x19, #0x70]
     594:      	rev	w8, w8
     598:      	sub	w8, w10, w8, lsr #16
     59c:      	add	w1, w8, #0x44
     5a0:      	blr	x9
     5a4:      	tbnz	w0, #0x1f, 0x7f4 <tail_icmp6_send_time_exceeded+0x554>
     5a8:      	mov	w8, #0x9                // =9
     5ac:      	add	w1, w20, #0x28
     5b0:      	add	x2, sp, #0x20
     5b4:      	mov	x0, x19
     5b8:      	mov	w3, #0x44               // =68
     5bc:      	mov	w4, wzr
     5c0:      	blr	x8
     5c4:      	tbnz	w0, #0x1f, 0x7f4 <tail_icmp6_send_time_exceeded+0x554>
     5c8:      	mov	w8, #0x9                // =9
     5cc:      	add	w1, w20, #0x4
     5d0:      	add	x2, sp, #0x1c
     5d4:      	mov	x0, x19
     5d8:      	mov	w3, #0x2                // =2
     5dc:      	mov	w4, wzr
     5e0:      	blr	x8
     5e4:      	tbnz	w0, #0x1f, 0x7f4 <tail_icmp6_send_time_exceeded+0x554>
     5e8:      	mov	w8, #0xb                // =11
     5ec:      	add	w1, w20, #0x2a
     5f0:      	mov	x0, x19
     5f4:      	mov	w2, wzr
     5f8:      	mov	w3, w21
     5fc:      	mov	w4, #0x10               // =16
     600:      	blr	x8
     604:      	tbnz	w0, #0x1f, 0x8c0 <tail_icmp6_send_time_exceeded+0x620>
     608:      	ldp	x9, x8, [sp, #0x8]
     60c:      	add	w1, w20, #0x8
     610:      	add	x2, sp, #0x80
     614:      	mov	x0, x19
     618:      	mov	w3, #0x10               // =16
     61c:      	stp	x8, x9, [sp, #0x98]
     620:      	adrp	x8, 0x0 <tail_drop_notify>
     624:      	ldr	x8, [x8]
     628:      	ldr	x8, [x8]
     62c:      	str	x8, [sp, #0x90]
     630:      	mov	w8, #0x1a               // =26
     634:      	blr	x8
     638:      	tbnz	w0, #0x1f, 0x7ec <tail_icmp6_send_time_exceeded+0x54c>
     63c:      	mov	w8, #0x1a               // =26
     640:      	add	w1, w20, #0x18
     644:      	add	x2, sp, #0x70
     648:      	mov	x0, x19
     64c:      	mov	w3, #0x10               // =16
     650:      	blr	x8
     654:      	tbnz	w0, #0x1f, 0x7ec <tail_icmp6_send_time_exceeded+0x54c>
     658:      	mov	w8, #0x9                // =9
     65c:      	add	w1, w20, #0x8
     660:      	add	x2, sp, #0x98
     664:      	mov	x0, x19
     668:      	mov	w3, #0x10               // =16
     66c:      	mov	w4, wzr
     670:      	blr	x8
     674:      	tbnz	w0, #0x1f, 0x7f4 <tail_icmp6_send_time_exceeded+0x554>
     678:      	mov	w8, #0x9                // =9
     67c:      	add	w1, w20, #0x18
     680:      	add	x2, sp, #0x80
     684:      	mov	x0, x19
     688:      	mov	w3, #0x10               // =16
     68c:      	mov	w4, wzr
     690:      	blr	x8
     694:      	tbnz	w0, #0x1f, 0x7f4 <tail_icmp6_send_time_exceeded+0x554>
     698:      	mov	w8, #0x1c               // =28
     69c:      	add	x0, sp, #0x80
     6a0:      	add	x2, sp, #0x98
     6a4:      	mov	w1, #0x10               // =16
     6a8:      	mov	w3, #0x10               // =16
     6ac:      	mov	w4, wzr
     6b0:      	blr	x8
     6b4:      	mov	w3, w0
     6b8:      	mov	w8, #0xb                // =11
     6bc:      	add	w1, w20, #0x2a
     6c0:      	mov	x0, x19
     6c4:      	mov	w2, wzr
     6c8:      	mov	w4, #0x10               // =16
     6cc:      	blr	x8
     6d0:      	tbnz	w0, #0x1f, 0x8c0 <tail_icmp6_send_time_exceeded+0x620>
     6d4:      	mov	w8, #0x1c               // =28
     6d8:      	add	x0, sp, #0x70
     6dc:      	add	x2, sp, #0x80
     6e0:      	mov	w1, #0x10               // =16
     6e4:      	mov	w3, #0x10               // =16
     6e8:      	mov	w4, wzr
     6ec:      	blr	x8
     6f0:      	mov	w3, w0
     6f4:      	mov	w8, #0xb                // =11
     6f8:      	add	w1, w20, #0x2a
     6fc:      	mov	x0, x19
     700:      	mov	w2, wzr
     704:      	mov	w4, #0x10               // =16
     708:      	blr	x8
     70c:      	tbnz	w0, #0x1f, 0x8c0 <tail_icmp6_send_time_exceeded+0x620>
     710:      	mov	w8, #0x1a               // =26
     714:      	add	x2, sp, #0xc8
     718:      	mov	x0, x19
     71c:      	mov	w1, #0x6                // =6
     720:      	mov	w3, #0x6                // =6
     724:      	blr	x8
     728:      	tbnz	w0, #0x1f, 0x7ec <tail_icmp6_send_time_exceeded+0x54c>
     72c:      	mov	w8, #0x9                // =9
     730:      	add	x2, sp, #0xc8
     734:      	mov	x0, x19
     738:      	mov	w1, wzr
     73c:      	mov	w3, #0x6                // =6
     740:      	mov	w4, wzr
     744:      	blr	x8
     748:      	tbnz	w0, #0x1f, 0x7f4 <tail_icmp6_send_time_exceeded+0x554>
     74c:      	mov	w8, #0x9                // =9
     750:      	add	x2, sp, #0x90
     754:      	mov	x0, x19
     758:      	mov	w1, #0x6                // =6
     75c:      	mov	w3, #0x6                // =6
     760:      	mov	w4, wzr
     764:      	blr	x8
     768:      	tbnz	w0, #0x1f, 0x7f4 <tail_icmp6_send_time_exceeded+0x554>
     76c:      	ldr	x8, [x19, #0x10]
     770:      	cbz	x8, 0x778 <tail_icmp6_send_time_exceeded+0x4d8>
     774:      	ldr	w8, [x8, #0xe0]
     778:      	adrp	x10, 0x0 <tail_drop_notify>
     77c:      	ldr	w9, [x19, #0x70]
     780:      	mov	w11, #0x403             // =1027
     784:      	adrp	x1, 0x0 <tail_drop_notify>
     788:      	ldr	x10, [x10]
     78c:      	add	x3, sp, #0xa8
     790:      	mov	x0, x19
     794:      	mov	w4, #0x18               // =24
     798:      	ldr	w10, [x10]
     79c:      	strh	w11, [sp, #0xa8]
     7a0:      	ldrh	w11, [x23]
     7a4:      	stp	w8, wzr, [sp, #0xb8]
     7a8:      	mov	w8, #0x19               // =25
     7ac:      	cmp	w9, w10
     7b0:      	strh	w11, [sp, #0xaa]
     7b4:      	ldr	w11, [x19, #0x98]
     7b8:      	csel	w10, w9, w10, lo
     7bc:      	strh	w10, [sp, #0xb4]
     7c0:      	stp	w11, w9, [sp, #0xac]
     7c4:      	mov	w9, #0x1                // =1
     7c8:      	strh	w9, [sp, #0xb6]
     7cc:      	mov	w9, #-0x1               // =-1
     7d0:      	orr	x2, x9, x10, lsl #32
     7d4:      	ldr	x1, [x1]
     7d8:      	blr	x8
     7dc:      	ldr	x8, [x19, #0x10]
     7e0:      	cbz	x8, 0x8c8 <tail_icmp6_send_time_exceeded+0x628>
     7e4:      	ldr	w0, [x8, #0xe0]
     7e8:      	b	0x8cc <tail_icmp6_send_time_exceeded+0x62c>
     7ec:      	mov	w0, #-0x86              // =-134
     7f0:      	b	0x800 <tail_icmp6_send_time_exceeded+0x560>
     7f4:      	mov	w0, #-0x8d              // =-141
     7f8:      	b	0x800 <tail_icmp6_send_time_exceeded+0x560>
     7fc:      	mov	w0, #-0x8e              // =-142
     800:      	cmp	w0, #0x0
     804:      	str	xzr, [x19, #0x30]
     808:      	ldr	w20, [x19, #0x70]
     80c:      	add	x1, sp, #0xa8
     810:      	cneg	w8, w0, mi
     814:      	adrp	x0, 0x0 <tail_drop_notify>
     818:      	and	w9, w8, #0xff
     81c:      	str	w9, [x19, #0x38]
     820:      	mov	x9, #0x670200000000     // =113258287595520
     824:      	movk	x9, #0x142, lsl #48
     828:      	stur	x9, [x19, #0x3c]
     82c:      	mov	x9, #0x1420000          // =21102592
     830:      	movk	x9, #0x67, lsl #32
     834:      	str	x9, [sp, #0xa8]
     838:      	strb	w8, [sp, #0xa8]
     83c:      	and	w8, w22, #0x3
     840:      	strb	w8, [sp, #0xa9]
     844:      	mov	w8, #0x1                // =1
     848:      	ldr	x0, [x0]
     84c:      	blr	x8
     850:      	cbz	x0, 0x868 <tail_icmp6_send_time_exceeded+0x5c8>
     854:      	ldp	x8, x9, [x0]
     858:      	add	x8, x8, #0x1
     85c:      	add	x9, x9, x20
     860:      	stp	x8, x9, [x0]
     864:      	b	0x88c <tail_icmp6_send_time_exceeded+0x5ec>
     868:      	mov	w8, #0x1                // =1
     86c:      	adrp	x0, 0x0 <tail_drop_notify>
     870:      	add	x1, sp, #0xa8
     874:      	stp	x8, x20, [sp, #0x20]
     878:      	mov	w8, #0x2                // =2
     87c:      	add	x2, sp, #0x20
     880:      	mov	w3, wzr
     884:      	ldr	x0, [x0]
     888:      	blr	x8
     88c:      	mov	w8, #0xc                // =12
     890:      	adrp	x1, 0x0 <tail_drop_notify>
     894:      	mov	x0, x19
     898:      	ldr	x1, [x1]
     89c:      	mov	w2, #0x1                // =1
     8a0:      	blr	x8
     8a4:      	mov	w0, #0x2                // =2
     8a8:      	ldp	x20, x19, [sp, #0xf0]
     8ac:      	ldr	x30, [sp, #0xc0]
     8b0:      	ldp	x22, x21, [sp, #0xe0]
     8b4:      	ldp	x24, x23, [sp, #0xd0]
     8b8:      	add	sp, sp, #0x100
     8bc:      	ret
     8c0:      	mov	w0, #-0x9a              // =-154
     8c4:      	b	0x800 <tail_icmp6_send_time_exceeded+0x560>
     8c8:      	mov	w0, wzr
     8cc:      	mov	w8, #0x17               // =23
     8d0:      	mov	w1, wzr
     8d4:      	blr	x8
     8d8:      	tbnz	w0, #0x1f, 0x800 <tail_icmp6_send_time_exceeded+0x560>
     8dc:      	cmp	w0, #0x2
     8e0:      	b.ne	0x8a8 <tail_icmp6_send_time_exceeded+0x608>
     8e4:      	b	0x800 <tail_icmp6_send_time_exceeded+0x560>
     8e8:      	nop
     8ec:      	nop

00000000000008f0 <tail_icmp6_handle_ns>:
     8f0:      	sub	sp, sp, #0x120
     8f4:      	stp	x29, x30, [sp, #0xe0]
     8f8:      	stp	x24, x23, [sp, #0xf0]
     8fc:      	stp	x22, x21, [sp, #0x100]
     900:      	stp	x20, x19, [sp, #0x110]
     904:      	ldp	w23, w21, [x0, #0x30]
     908:      	str	wzr, [x0, #0x30]
     90c:      	adrp	x8, 0x0 <tail_drop_notify>
     910:      	adrp	x24, 0x0 <tail_drop_notify>
     914:      	add	x2, sp, #0x48
     918:      	mov	w3, #0x10               // =16
     91c:      	ldr	x8, [x8]
     920:      	mov	x19, x0
     924:      	add	w1, w23, #0x30
     928:      	ldr	x9, [x8]
     92c:      	str	x9, [sp, #0x40]
     930:      	ldr	x8, [x8, #0x8]
     934:      	str	x8, [sp, #0x38]
     938:      	ldr	x24, [x24]
     93c:      	ldrb	w8, [x24]
     940:      	strb	w8, [sp, #0x30]
     944:      	ldrb	w8, [x24, #0x1]
     948:      	strb	w8, [sp, #0x2c]
     94c:      	ldrb	w8, [x24, #0x2]
     950:      	strb	w8, [sp, #0x28]
     954:      	ldrb	w8, [x24, #0x3]
     958:      	strb	w8, [sp, #0x24]
     95c:      	ldrb	w8, [x24, #0x4]
     960:      	strb	w8, [sp, #0x20]
     964:      	ldrb	w8, [x24, #0x5]
     968:      	strb	w8, [sp, #0x1c]
     96c:      	ldrh	w8, [x24, #0x6]
     970:      	strh	w8, [sp, #0x1a]
     974:      	mov	w8, #0x1a               // =26
     978:      	blr	x8
     97c:      	tbnz	w0, #0x1f, 0xd1c <tail_icmp6_handle_ns+0x42c>
     980:      	mov	w10, #0xd02             // =3330
     984:      	adrp	x22, 0x0 <tail_drop_notify>
     988:      	ldp	w8, w9, [sp, #0x50]
     98c:      	adrp	x1, 0x0 <tail_drop_notify>
     990:      	strh	w10, [sp, #0xc8]
     994:      	add	x3, sp, #0xc8
     998:      	mov	x0, x19
     99c:      	mov	w2, #-0x1               // =-1
     9a0:      	ldr	x22, [x22]
     9a4:      	mov	w4, #0x14               // =20
     9a8:      	ldrh	w10, [x22]
     9ac:      	stp	w9, wzr, [sp, #0xd4]
     9b0:      	strh	w10, [sp, #0xca]
     9b4:      	ldr	w10, [x19, #0x98]
     9b8:      	stp	w10, w8, [sp, #0xcc]
     9bc:      	mov	w8, #0x19               // =25
     9c0:      	ldr	x1, [x1]
     9c4:      	blr	x8
     9c8:      	ldp	x10, x9, [sp, #0x40]
     9cc:      	cmp	x9, x10
     9d0:      	ldr	x8, [sp, #0x50]
     9d4:      	b.ne	0xd88 <tail_icmp6_handle_ns+0x498>
     9d8:      	ldr	x10, [sp, #0x38]
     9dc:      	cmp	x8, x10
     9e0:      	b.ne	0xd88 <tail_icmp6_handle_ns+0x498>
     9e4:      	mov	x8, #0x88               // =136
     9e8:      	add	w1, w23, #0x40
     9ec:      	add	x2, sp, #0x68
     9f0:      	mov	x0, x19
     9f4:      	mov	w3, #0x8                // =8
     9f8:      	movk	x8, #0xc0, lsl #32
     9fc:      	str	x8, [sp, #0x80]
     a00:      	mov	w8, #0x1a               // =26
     a04:      	blr	x8
     a08:      	tbnz	w0, #0x1f, 0x14b0 <tail_icmp6_handle_ns+0xbc0>
     a0c:      	mov	w20, wzr
     a10:      	mov	w8, #0x1a               // =26
     a14:      	add	w1, w23, #0x28
     a18:      	add	x2, sp, #0x78
     a1c:      	mov	x0, x19
     a20:      	mov	w3, #0x8                // =8
     a24:      	blr	x8
     a28:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
     a2c:      	ldrh	w8, [sp, #0x7a]
     a30:      	add	w1, w23, #0x30
     a34:      	add	x2, sp, #0x58
     a38:      	mov	x0, x19
     a3c:      	strh	w8, [sp, #0x82]
     a40:      	mov	w8, #0x1a               // =26
     a44:      	mov	w3, #0x10               // =16
     a48:      	blr	x8
     a4c:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
     a50:      	mov	w8, #0x9                // =9
     a54:      	add	w1, w23, #0x28
     a58:      	add	x2, sp, #0x80
     a5c:      	mov	x0, x19
     a60:      	mov	w3, #0x8                // =8
     a64:      	mov	w4, wzr
     a68:      	blr	x8
     a6c:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
     a70:      	mov	w8, #0x1c               // =28
     a74:      	add	x0, sp, #0x78
     a78:      	add	x2, sp, #0x80
     a7c:      	mov	w1, #0x8                // =8
     a80:      	mov	w3, #0x8                // =8
     a84:      	mov	w4, w20
     a88:      	blr	x8
     a8c:      	mov	w8, #0x1a               // =26
     a90:      	mov	w20, w0
     a94:      	add	w1, w23, #0x40
     a98:      	add	x2, sp, #0x68
     a9c:      	mov	x0, x19
     aa0:      	mov	w3, #0x8                // =8
     aa4:      	blr	x8
     aa8:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
     aac:      	mov	w8, #0x102              // =258
     ab0:      	add	w1, w23, #0x40
     ab4:      	add	x2, sp, #0x70
     ab8:      	strh	w8, [sp, #0x70]
     abc:      	ldrb	w8, [sp, #0x30]
     ac0:      	mov	x0, x19
     ac4:      	mov	w3, #0x8                // =8
     ac8:      	mov	w4, wzr
     acc:      	strb	w8, [sp, #0x72]
     ad0:      	ldrb	w8, [sp, #0x2c]
     ad4:      	strb	w8, [sp, #0x73]
     ad8:      	ldrb	w8, [sp, #0x28]
     adc:      	strb	w8, [sp, #0x74]
     ae0:      	ldrb	w8, [sp, #0x24]
     ae4:      	strb	w8, [sp, #0x75]
     ae8:      	ldrb	w8, [sp, #0x20]
     aec:      	strb	w8, [sp, #0x76]
     af0:      	ldrb	w8, [sp, #0x1c]
     af4:      	strb	w8, [sp, #0x77]
     af8:      	mov	w8, #0x9                // =9
     afc:      	blr	x8
     b00:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
     b04:      	mov	w8, #0x1c               // =28
     b08:      	add	x0, sp, #0x68
     b0c:      	add	x2, sp, #0x70
     b10:      	mov	w1, #0x8                // =8
     b14:      	mov	w3, #0x8                // =8
     b18:      	mov	w4, w20
     b1c:      	blr	x8
     b20:      	mov	w3, w0
     b24:      	mov	w8, #0xb                // =11
     b28:      	add	w1, w23, #0x2a
     b2c:      	mov	x0, x19
     b30:      	mov	w2, wzr
     b34:      	mov	w4, #0x10               // =16
     b38:      	blr	x8
     b3c:      	tbnz	w0, #0x1f, 0x1608 <tail_icmp6_handle_ns+0xd18>
     b40:      	ldp	x8, x9, [sp, #0x58]
     b44:      	add	w1, w23, #0x8
     b48:      	add	x2, sp, #0x98
     b4c:      	mov	x0, x19
     b50:      	mov	w3, #0x10               // =16
     b54:      	stp	x8, x9, [sp, #0xb8]
     b58:      	ldr	x8, [x24]
     b5c:      	str	x8, [sp, #0xa8]
     b60:      	mov	w8, #0x1a               // =26
     b64:      	blr	x8
     b68:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
     b6c:      	mov	w8, #0x1a               // =26
     b70:      	add	w1, w23, #0x18
     b74:      	add	x2, sp, #0x88
     b78:      	mov	x0, x19
     b7c:      	mov	w3, #0x10               // =16
     b80:      	blr	x8
     b84:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
     b88:      	mov	w8, #0x9                // =9
     b8c:      	add	w1, w23, #0x8
     b90:      	add	x2, sp, #0xb8
     b94:      	mov	x0, x19
     b98:      	mov	w3, #0x10               // =16
     b9c:      	mov	w4, wzr
     ba0:      	blr	x8
     ba4:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
     ba8:      	mov	w8, #0x9                // =9
     bac:      	add	w1, w23, #0x18
     bb0:      	add	x2, sp, #0x98
     bb4:      	mov	x0, x19
     bb8:      	mov	w3, #0x10               // =16
     bbc:      	mov	w4, wzr
     bc0:      	blr	x8
     bc4:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
     bc8:      	mov	w8, #0x1c               // =28
     bcc:      	add	x0, sp, #0x98
     bd0:      	add	x2, sp, #0xb8
     bd4:      	mov	w1, #0x10               // =16
     bd8:      	mov	w3, #0x10               // =16
     bdc:      	mov	w4, wzr
     be0:      	blr	x8
     be4:      	mov	w3, w0
     be8:      	mov	w8, #0xb                // =11
     bec:      	add	w1, w23, #0x2a
     bf0:      	mov	x0, x19
     bf4:      	mov	w2, wzr
     bf8:      	mov	w4, #0x10               // =16
     bfc:      	blr	x8
     c00:      	tbnz	w0, #0x1f, 0x1608 <tail_icmp6_handle_ns+0xd18>
     c04:      	mov	w8, #0x1c               // =28
     c08:      	add	x0, sp, #0x88
     c0c:      	add	x2, sp, #0x98
     c10:      	mov	w1, #0x10               // =16
     c14:      	mov	w3, #0x10               // =16
     c18:      	mov	w4, wzr
     c1c:      	blr	x8
     c20:      	mov	w3, w0
     c24:      	mov	w8, #0xb                // =11
     c28:      	add	w1, w23, #0x2a
     c2c:      	mov	x0, x19
     c30:      	mov	w2, wzr
     c34:      	mov	w4, #0x10               // =16
     c38:      	blr	x8
     c3c:      	tbnz	w0, #0x1f, 0x1608 <tail_icmp6_handle_ns+0xd18>
     c40:      	mov	w8, #0x1a               // =26
     c44:      	add	x2, sp, #0xb0
     c48:      	mov	x0, x19
     c4c:      	mov	w1, #0x6                // =6
     c50:      	mov	w3, #0x6                // =6
     c54:      	blr	x8
     c58:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
     c5c:      	mov	w8, #0x9                // =9
     c60:      	add	x2, sp, #0xb0
     c64:      	mov	x0, x19
     c68:      	mov	w1, wzr
     c6c:      	mov	w3, #0x6                // =6
     c70:      	mov	w4, wzr
     c74:      	blr	x8
     c78:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
     c7c:      	mov	w8, #0x9                // =9
     c80:      	add	x2, sp, #0xa8
     c84:      	mov	x0, x19
     c88:      	mov	w1, #0x6                // =6
     c8c:      	mov	w3, #0x6                // =6
     c90:      	mov	w4, wzr
     c94:      	blr	x8
     c98:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
     c9c:      	ldr	x8, [x19, #0x10]
     ca0:      	cbz	x8, 0xca8 <tail_icmp6_handle_ns+0x3b8>
     ca4:      	ldr	w8, [x8, #0xe0]
     ca8:      	adrp	x10, 0x0 <tail_drop_notify>
     cac:      	ldr	w9, [x19, #0x70]
     cb0:      	mov	w11, #0x403             // =1027
     cb4:      	adrp	x1, 0x0 <tail_drop_notify>
     cb8:      	ldr	x10, [x10]
     cbc:      	add	x3, sp, #0xc8
     cc0:      	mov	x0, x19
     cc4:      	mov	w4, #0x18               // =24
     cc8:      	ldr	w10, [x10]
     ccc:      	strh	w11, [sp, #0xc8]
     cd0:      	ldrh	w11, [x22]
     cd4:      	stp	w8, wzr, [sp, #0xd8]
     cd8:      	mov	w8, #0x19               // =25
     cdc:      	cmp	w9, w10
     ce0:      	strh	w11, [sp, #0xca]
     ce4:      	ldr	w11, [x19, #0x98]
     ce8:      	csel	w10, w9, w10, lo
     cec:      	strh	w10, [sp, #0xd4]
     cf0:      	stp	w11, w9, [sp, #0xcc]
     cf4:      	mov	w9, #0x1                // =1
     cf8:      	strh	w9, [sp, #0xd6]
     cfc:      	mov	w9, #-0x1               // =-1
     d00:      	orr	x2, x9, x10, lsl #32
     d04:      	ldr	x1, [x1]
     d08:      	blr	x8
     d0c:      	ldr	x8, [x19, #0x10]
     d10:      	cbz	x8, 0x161c <tail_icmp6_handle_ns+0xd2c>
     d14:      	ldr	w0, [x8, #0xe0]
     d18:      	b	0x1620 <tail_icmp6_handle_ns+0xd30>
     d1c:      	mov	w0, #-0x86              // =-134
     d20:      	cmp	w0, #0x0
     d24:      	str	xzr, [x19, #0x30]
     d28:      	ldr	w20, [x19, #0x70]
     d2c:      	add	x1, sp, #0xb8
     d30:      	cneg	w8, w0, mi
     d34:      	adrp	x0, 0x0 <tail_drop_notify>
     d38:      	and	w9, w8, #0xff
     d3c:      	str	w9, [x19, #0x38]
     d40:      	mov	x9, #0x670200000000     // =113258287595520
     d44:      	movk	x9, #0x196, lsl #48
     d48:      	stur	x9, [x19, #0x3c]
     d4c:      	mov	x9, #0x1960000          // =26607616
     d50:      	movk	x9, #0x67, lsl #32
     d54:      	str	x9, [sp, #0xb8]
     d58:      	strb	w8, [sp, #0xb8]
     d5c:      	and	w8, w21, #0x3
     d60:      	strb	w8, [sp, #0xb9]
     d64:      	mov	w8, #0x1                // =1
     d68:      	ldr	x0, [x0]
     d6c:      	blr	x8
     d70:      	cbz	x0, 0x1458 <tail_icmp6_handle_ns+0xb68>
     d74:      	ldp	x8, x9, [x0]
     d78:      	add	x8, x8, #0x1
     d7c:      	add	x9, x9, x20
     d80:      	stp	x8, x9, [x0]
     d84:      	b	0x147c <tail_icmp6_handle_ns+0xb8c>
     d88:      	adrp	x10, 0x0 <tail_drop_notify>
     d8c:      	ldr	x10, [x10]
     d90:      	ldr	x11, [x10]
     d94:      	str	x11, [sp, #0x10]
     d98:      	cmp	x9, x11
     d9c:      	ldr	x10, [x10, #0x8]
     da0:      	str	x10, [sp, #0x8]
     da4:      	b.ne	0x10e4 <tail_icmp6_handle_ns+0x7f4>
     da8:      	cmp	x8, x10
     dac:      	b.ne	0x10e4 <tail_icmp6_handle_ns+0x7f4>
     db0:      	mov	w8, #0x1a               // =26
     db4:      	mov	x2, sp
     db8:      	mov	x0, x19
     dbc:      	mov	w1, #0x6                // =6
     dc0:      	mov	w3, #0x6                // =6
     dc4:      	blr	x8
     dc8:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
     dcc:      	mov	x8, #0x88               // =136
     dd0:      	add	w1, w23, #0x40
     dd4:      	add	x2, sp, #0x68
     dd8:      	mov	x0, x19
     ddc:      	mov	w3, #0x8                // =8
     de0:      	movk	x8, #0x60, lsl #32
     de4:      	str	x8, [sp, #0x80]
     de8:      	mov	w8, #0x1a               // =26
     dec:      	blr	x8
     df0:      	tbnz	w0, #0x1f, 0x1524 <tail_icmp6_handle_ns+0xc34>
     df4:      	mov	w20, wzr
     df8:      	mov	w8, #0x1a               // =26
     dfc:      	add	w1, w23, #0x28
     e00:      	add	x2, sp, #0x78
     e04:      	mov	x0, x19
     e08:      	mov	w3, #0x8                // =8
     e0c:      	blr	x8
     e10:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
     e14:      	ldrh	w8, [sp, #0x7a]
     e18:      	add	w1, w23, #0x30
     e1c:      	add	x2, sp, #0x58
     e20:      	mov	x0, x19
     e24:      	strh	w8, [sp, #0x82]
     e28:      	mov	w8, #0x1a               // =26
     e2c:      	mov	w3, #0x10               // =16
     e30:      	blr	x8
     e34:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
     e38:      	mov	w8, #0x9                // =9
     e3c:      	add	w1, w23, #0x28
     e40:      	add	x2, sp, #0x80
     e44:      	mov	x0, x19
     e48:      	mov	w3, #0x8                // =8
     e4c:      	mov	w4, wzr
     e50:      	blr	x8
     e54:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
     e58:      	mov	w8, #0x1c               // =28
     e5c:      	add	x0, sp, #0x78
     e60:      	add	x2, sp, #0x80
     e64:      	mov	w1, #0x8                // =8
     e68:      	mov	w3, #0x8                // =8
     e6c:      	mov	w4, w20
     e70:      	blr	x8
     e74:      	mov	w8, #0x1a               // =26
     e78:      	mov	w20, w0
     e7c:      	add	w1, w23, #0x40
     e80:      	add	x2, sp, #0x68
     e84:      	mov	x0, x19
     e88:      	mov	w3, #0x8                // =8
     e8c:      	blr	x8
     e90:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
     e94:      	mov	w8, #0x102              // =258
     e98:      	add	w1, w23, #0x40
     e9c:      	add	x2, sp, #0x70
     ea0:      	strh	w8, [sp, #0x70]
     ea4:      	ldrh	w8, [sp]
     ea8:      	mov	x0, x19
     eac:      	mov	w3, #0x8                // =8
     eb0:      	mov	w4, wzr
     eb4:      	strh	w8, [sp, #0x72]
     eb8:      	ldur	w8, [sp, #0x2]
     ebc:      	str	w8, [sp, #0x74]
     ec0:      	mov	w8, #0x9                // =9
     ec4:      	blr	x8
     ec8:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
     ecc:      	mov	w8, #0x1c               // =28
     ed0:      	add	x0, sp, #0x68
     ed4:      	add	x2, sp, #0x70
     ed8:      	mov	w1, #0x8                // =8
     edc:      	mov	w3, #0x8                // =8
     ee0:      	mov	w4, w20
     ee4:      	blr	x8
     ee8:      	mov	w3, w0
     eec:      	mov	w8, #0xb                // =11
     ef0:      	add	w1, w23, #0x2a
     ef4:      	mov	x0, x19
     ef8:      	mov	w2, wzr
     efc:      	mov	w4, #0x10               // =16
     f00:      	blr	x8
     f04:      	tbnz	w0, #0x1f, 0x1608 <tail_icmp6_handle_ns+0xd18>
     f08:      	ldp	x8, x9, [sp, #0x58]
     f0c:      	add	w1, w23, #0x8
     f10:      	add	x2, sp, #0x98
     f14:      	mov	x0, x19
     f18:      	mov	w3, #0x10               // =16
     f1c:      	stp	x8, x9, [sp, #0xb8]
     f20:      	ldr	x8, [x24]
     f24:      	str	x8, [sp, #0xa8]
     f28:      	mov	w8, #0x1a               // =26
     f2c:      	blr	x8
     f30:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
     f34:      	mov	w8, #0x1a               // =26
     f38:      	add	w1, w23, #0x18
     f3c:      	add	x2, sp, #0x88
     f40:      	mov	x0, x19
     f44:      	mov	w3, #0x10               // =16
     f48:      	blr	x8
     f4c:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
     f50:      	mov	w8, #0x9                // =9
     f54:      	add	w1, w23, #0x8
     f58:      	add	x2, sp, #0xb8
     f5c:      	mov	x0, x19
     f60:      	mov	w3, #0x10               // =16
     f64:      	mov	w4, wzr
     f68:      	blr	x8
     f6c:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
     f70:      	mov	w8, #0x9                // =9
     f74:      	add	w1, w23, #0x18
     f78:      	add	x2, sp, #0x98
     f7c:      	mov	x0, x19
     f80:      	mov	w3, #0x10               // =16
     f84:      	mov	w4, wzr
     f88:      	blr	x8
     f8c:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
     f90:      	mov	w8, #0x1c               // =28
     f94:      	add	x0, sp, #0x98
     f98:      	add	x2, sp, #0xb8
     f9c:      	mov	w1, #0x10               // =16
     fa0:      	mov	w3, #0x10               // =16
     fa4:      	mov	w4, wzr
     fa8:      	blr	x8
     fac:      	mov	w3, w0
     fb0:      	mov	w8, #0xb                // =11
     fb4:      	add	w1, w23, #0x2a
     fb8:      	mov	x0, x19
     fbc:      	mov	w2, wzr
     fc0:      	mov	w4, #0x10               // =16
     fc4:      	blr	x8
     fc8:      	tbnz	w0, #0x1f, 0x1608 <tail_icmp6_handle_ns+0xd18>
     fcc:      	mov	w8, #0x1c               // =28
     fd0:      	add	x0, sp, #0x88
     fd4:      	add	x2, sp, #0x98
     fd8:      	mov	w1, #0x10               // =16
     fdc:      	mov	w3, #0x10               // =16
     fe0:      	mov	w4, wzr
     fe4:      	blr	x8
     fe8:      	mov	w3, w0
     fec:      	mov	w8, #0xb                // =11
     ff0:      	add	w1, w23, #0x2a
     ff4:      	mov	x0, x19
     ff8:      	mov	w2, wzr
     ffc:      	mov	w4, #0x10               // =16
    1000:      	blr	x8
    1004:      	tbnz	w0, #0x1f, 0x1608 <tail_icmp6_handle_ns+0xd18>
    1008:      	mov	w8, #0x1a               // =26
    100c:      	add	x2, sp, #0xb0
    1010:      	mov	x0, x19
    1014:      	mov	w1, #0x6                // =6
    1018:      	mov	w3, #0x6                // =6
    101c:      	blr	x8
    1020:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
    1024:      	mov	w8, #0x9                // =9
    1028:      	add	x2, sp, #0xb0
    102c:      	mov	x0, x19
    1030:      	mov	w1, wzr
    1034:      	mov	w3, #0x6                // =6
    1038:      	mov	w4, wzr
    103c:      	blr	x8
    1040:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
    1044:      	mov	w8, #0x9                // =9
    1048:      	add	x2, sp, #0xa8
    104c:      	mov	x0, x19
    1050:      	mov	w1, #0x6                // =6
    1054:      	mov	w3, #0x6                // =6
    1058:      	mov	w4, wzr
    105c:      	blr	x8
    1060:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
    1064:      	ldr	x8, [x19, #0x10]
    1068:      	cbz	x8, 0x1070 <tail_icmp6_handle_ns+0x780>
    106c:      	ldr	w8, [x8, #0xe0]
    1070:      	adrp	x10, 0x1000 <tail_icmp6_handle_ns+0x710>
    1074:      	ldr	w9, [x19, #0x70]
    1078:      	mov	w11, #0x403             // =1027
    107c:      	adrp	x1, 0x1000 <tail_icmp6_handle_ns+0x710>
    1080:      	ldr	x10, [x10]
    1084:      	add	x3, sp, #0xc8
    1088:      	mov	x0, x19
    108c:      	mov	w4, #0x18               // =24
    1090:      	ldr	w10, [x10]
    1094:      	strh	w11, [sp, #0xc8]
    1098:      	ldrh	w11, [x22]
    109c:      	stp	w8, wzr, [sp, #0xd8]
    10a0:      	mov	w8, #0x19               // =25
    10a4:      	cmp	w9, w10
    10a8:      	strh	w11, [sp, #0xca]
    10ac:      	ldr	w11, [x19, #0x98]
    10b0:      	csel	w10, w9, w10, lo
    10b4:      	strh	w10, [sp, #0xd4]
    10b8:      	stp	w11, w9, [sp, #0xcc]
    10bc:      	mov	w9, #0x1                // =1
    10c0:      	strh	w9, [sp, #0xd6]
    10c4:      	mov	w9, #-0x1               // =-1
    10c8:      	orr	x2, x9, x10, lsl #32
    10cc:      	ldr	x1, [x1]
    10d0:      	blr	x8
    10d4:      	ldr	x8, [x19, #0x10]
    10d8:      	cbz	x8, 0x1628 <tail_icmp6_handle_ns+0xd38>
    10dc:      	ldr	w0, [x8, #0xe0]
    10e0:      	b	0x162c <tail_icmp6_handle_ns+0xd3c>
    10e4:      	ldp	x8, x9, [sp, #0x48]
    10e8:      	adrp	x0, 0x1000 <tail_icmp6_handle_ns+0x710>
    10ec:      	add	x1, sp, #0xc8
    10f0:      	str	wzr, [sp, #0xd8]
    10f4:      	stp	x8, x9, [sp, #0xc8]
    10f8:      	mov	w8, #0x2                // =2
    10fc:      	strb	w8, [sp, #0xd8]
    1100:      	mov	w8, #0x1                // =1
    1104:      	ldr	x0, [x0]
    1108:      	blr	x8
    110c:      	cbz	x0, 0x1514 <tail_icmp6_handle_ns+0xc24>
    1110:      	ldrb	w8, [x0, #0x8]
    1114:      	tbnz	w8, #0x0, 0x151c <tail_icmp6_handle_ns+0xc2c>
    1118:      	mov	x8, #0x88               // =136
    111c:      	add	w1, w23, #0x40
    1120:      	add	x2, sp, #0x68
    1124:      	mov	x0, x19
    1128:      	mov	w3, #0x8                // =8
    112c:      	movk	x8, #0x60, lsl #32
    1130:      	str	x8, [sp, #0x80]
    1134:      	mov	w8, #0x1a               // =26
    1138:      	blr	x8
    113c:      	tbnz	w0, #0x1f, 0x1588 <tail_icmp6_handle_ns+0xc98>
    1140:      	mov	w20, wzr
    1144:      	mov	w8, #0x1a               // =26
    1148:      	add	w1, w23, #0x28
    114c:      	add	x2, sp, #0x78
    1150:      	mov	x0, x19
    1154:      	mov	w3, #0x8                // =8
    1158:      	blr	x8
    115c:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
    1160:      	ldrh	w8, [sp, #0x7a]
    1164:      	add	w1, w23, #0x30
    1168:      	add	x2, sp, #0x58
    116c:      	mov	x0, x19
    1170:      	strh	w8, [sp, #0x82]
    1174:      	mov	w8, #0x1a               // =26
    1178:      	mov	w3, #0x10               // =16
    117c:      	blr	x8
    1180:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
    1184:      	mov	w8, #0x9                // =9
    1188:      	add	w1, w23, #0x28
    118c:      	add	x2, sp, #0x80
    1190:      	mov	x0, x19
    1194:      	mov	w3, #0x8                // =8
    1198:      	mov	w4, wzr
    119c:      	blr	x8
    11a0:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
    11a4:      	mov	w8, #0x1c               // =28
    11a8:      	add	x0, sp, #0x78
    11ac:      	add	x2, sp, #0x80
    11b0:      	mov	w1, #0x8                // =8
    11b4:      	mov	w3, #0x8                // =8
    11b8:      	mov	w4, w20
    11bc:      	blr	x8
    11c0:      	mov	w8, #0x1a               // =26
    11c4:      	mov	w20, w0
    11c8:      	add	w1, w23, #0x40
    11cc:      	add	x2, sp, #0x68
    11d0:      	mov	x0, x19
    11d4:      	mov	w3, #0x8                // =8
    11d8:      	blr	x8
    11dc:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
    11e0:      	mov	w8, #0x102              // =258
    11e4:      	add	w1, w23, #0x40
    11e8:      	add	x2, sp, #0x70
    11ec:      	strh	w8, [sp, #0x70]
    11f0:      	ldrb	w8, [sp, #0x30]
    11f4:      	mov	x0, x19
    11f8:      	mov	w3, #0x8                // =8
    11fc:      	mov	w4, wzr
    1200:      	strb	w8, [sp, #0x72]
    1204:      	ldrb	w8, [sp, #0x2c]
    1208:      	strb	w8, [sp, #0x73]
    120c:      	ldrb	w8, [sp, #0x28]
    1210:      	strb	w8, [sp, #0x74]
    1214:      	ldrb	w8, [sp, #0x24]
    1218:      	strb	w8, [sp, #0x75]
    121c:      	ldrb	w8, [sp, #0x20]
    1220:      	strb	w8, [sp, #0x76]
    1224:      	ldrb	w8, [sp, #0x1c]
    1228:      	strb	w8, [sp, #0x77]
    122c:      	mov	w8, #0x9                // =9
    1230:      	blr	x8
    1234:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
    1238:      	mov	w8, #0x1c               // =28
    123c:      	add	x0, sp, #0x68
    1240:      	add	x2, sp, #0x70
    1244:      	mov	w1, #0x8                // =8
    1248:      	mov	w3, #0x8                // =8
    124c:      	mov	w4, w20
    1250:      	blr	x8
    1254:      	mov	w3, w0
    1258:      	mov	w8, #0xb                // =11
    125c:      	add	w1, w23, #0x2a
    1260:      	mov	x0, x19
    1264:      	mov	w2, wzr
    1268:      	mov	w4, #0x10               // =16
    126c:      	blr	x8
    1270:      	tbnz	w0, #0x1f, 0x1608 <tail_icmp6_handle_ns+0xd18>
    1274:      	ldp	x8, x9, [sp, #0x58]
    1278:      	add	w1, w23, #0x8
    127c:      	add	x2, sp, #0x98
    1280:      	mov	x0, x19
    1284:      	mov	w3, #0x10               // =16
    1288:      	stp	x8, x9, [sp, #0xb8]
    128c:      	ldr	x8, [x24]
    1290:      	str	x8, [sp, #0xa8]
    1294:      	mov	w8, #0x1a               // =26
    1298:      	blr	x8
    129c:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
    12a0:      	mov	w8, #0x1a               // =26
    12a4:      	add	w1, w23, #0x18
    12a8:      	add	x2, sp, #0x88
    12ac:      	mov	x0, x19
    12b0:      	mov	w3, #0x10               // =16
    12b4:      	blr	x8
    12b8:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
    12bc:      	mov	w8, #0x9                // =9
    12c0:      	add	w1, w23, #0x8
    12c4:      	add	x2, sp, #0xb8
    12c8:      	mov	x0, x19
    12cc:      	mov	w3, #0x10               // =16
    12d0:      	mov	w4, wzr
    12d4:      	blr	x8
    12d8:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
    12dc:      	mov	w8, #0x9                // =9
    12e0:      	add	w1, w23, #0x18
    12e4:      	add	x2, sp, #0x98
    12e8:      	mov	x0, x19
    12ec:      	mov	w3, #0x10               // =16
    12f0:      	mov	w4, wzr
    12f4:      	blr	x8
    12f8:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
    12fc:      	mov	w8, #0x1c               // =28
    1300:      	add	x0, sp, #0x98
    1304:      	add	x2, sp, #0xb8
    1308:      	mov	w1, #0x10               // =16
    130c:      	mov	w3, #0x10               // =16
    1310:      	mov	w4, wzr
    1314:      	blr	x8
    1318:      	mov	w3, w0
    131c:      	mov	w8, #0xb                // =11
    1320:      	add	w1, w23, #0x2a
    1324:      	mov	x0, x19
    1328:      	mov	w2, wzr
    132c:      	mov	w4, #0x10               // =16
    1330:      	blr	x8
    1334:      	tbnz	w0, #0x1f, 0x1608 <tail_icmp6_handle_ns+0xd18>
    1338:      	mov	w8, #0x1c               // =28
    133c:      	add	x0, sp, #0x88
    1340:      	add	x2, sp, #0x98
    1344:      	mov	w1, #0x10               // =16
    1348:      	mov	w3, #0x10               // =16
    134c:      	mov	w4, wzr
    1350:      	blr	x8
    1354:      	mov	w3, w0
    1358:      	mov	w8, #0xb                // =11
    135c:      	add	w1, w23, #0x2a
    1360:      	mov	x0, x19
    1364:      	mov	w2, wzr
    1368:      	mov	w4, #0x10               // =16
    136c:      	blr	x8
    1370:      	tbnz	w0, #0x1f, 0x1608 <tail_icmp6_handle_ns+0xd18>
    1374:      	mov	w8, #0x1a               // =26
    1378:      	add	x2, sp, #0xb0
    137c:      	mov	x0, x19
    1380:      	mov	w1, #0x6                // =6
    1384:      	mov	w3, #0x6                // =6
    1388:      	blr	x8
    138c:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
    1390:      	mov	w8, #0x9                // =9
    1394:      	add	x2, sp, #0xb0
    1398:      	mov	x0, x19
    139c:      	mov	w1, wzr
    13a0:      	mov	w3, #0x6                // =6
    13a4:      	mov	w4, wzr
    13a8:      	blr	x8
    13ac:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
    13b0:      	mov	w8, #0x9                // =9
    13b4:      	add	x2, sp, #0xa8
    13b8:      	mov	x0, x19
    13bc:      	mov	w1, #0x6                // =6
    13c0:      	mov	w3, #0x6                // =6
    13c4:      	mov	w4, wzr
    13c8:      	blr	x8
    13cc:      	tbnz	w0, #0x1f, 0x1450 <tail_icmp6_handle_ns+0xb60>
    13d0:      	ldr	x8, [x19, #0x10]
    13d4:      	cbz	x8, 0x13dc <tail_icmp6_handle_ns+0xaec>
    13d8:      	ldr	w8, [x8, #0xe0]
    13dc:      	adrp	x10, 0x1000 <tail_icmp6_handle_ns+0x710>
    13e0:      	ldr	w9, [x19, #0x70]
    13e4:      	mov	w11, #0x403             // =1027
    13e8:      	adrp	x1, 0x1000 <tail_icmp6_handle_ns+0x710>
    13ec:      	ldr	x10, [x10]
    13f0:      	add	x3, sp, #0xc8
    13f4:      	mov	x0, x19
    13f8:      	mov	w4, #0x18               // =24
    13fc:      	ldr	w10, [x10]
    1400:      	strh	w11, [sp, #0xc8]
    1404:      	ldrh	w11, [x22]
    1408:      	stp	w8, wzr, [sp, #0xd8]
    140c:      	mov	w8, #0x19               // =25
    1410:      	cmp	w9, w10
    1414:      	strh	w11, [sp, #0xca]
    1418:      	ldr	w11, [x19, #0x98]
    141c:      	csel	w10, w9, w10, lo
    1420:      	strh	w10, [sp, #0xd4]
    1424:      	stp	w11, w9, [sp, #0xcc]
    1428:      	mov	w9, #0x1                // =1
    142c:      	strh	w9, [sp, #0xd6]
    1430:      	mov	w9, #-0x1               // =-1
    1434:      	orr	x2, x9, x10, lsl #32
    1438:      	ldr	x1, [x1]
    143c:      	blr	x8
    1440:      	ldr	x8, [x19, #0x10]
    1444:      	cbz	x8, 0x1634 <tail_icmp6_handle_ns+0xd44>
    1448:      	ldr	w0, [x8, #0xe0]
    144c:      	b	0x1638 <tail_icmp6_handle_ns+0xd48>
    1450:      	mov	w0, #-0x8d              // =-141
    1454:      	b	0x15e4 <tail_icmp6_handle_ns+0xcf4>
    1458:      	mov	w8, #0x1                // =1
    145c:      	adrp	x0, 0x1000 <tail_icmp6_handle_ns+0x710>
    1460:      	add	x1, sp, #0xb8
    1464:      	stp	x8, x20, [sp, #0xc8]
    1468:      	mov	w8, #0x2                // =2
    146c:      	add	x2, sp, #0xc8
    1470:      	mov	w3, wzr
    1474:      	ldr	x0, [x0]
    1478:      	blr	x8
    147c:      	mov	w8, #0xc                // =12
    1480:      	adrp	x1, 0x1000 <tail_icmp6_handle_ns+0x710>
    1484:      	mov	x0, x19
    1488:      	ldr	x1, [x1]
    148c:      	mov	w2, #0x1                // =1
    1490:      	blr	x8
    1494:      	mov	w0, #0x2                // =2
    1498:      	ldp	x20, x19, [sp, #0x110]
    149c:      	ldp	x22, x21, [sp, #0x100]
    14a0:      	ldp	x24, x23, [sp, #0xf0]
    14a4:      	ldp	x29, x30, [sp, #0xe0]
    14a8:      	add	sp, sp, #0x120
    14ac:      	ret
    14b0:      	mov	w8, #0x26               // =38
    14b4:      	mov	x0, x19
    14b8:      	mov	w2, wzr
    14bc:      	ldr	w9, [x19, #0x70]
    14c0:      	add	w1, w9, #0x8
    14c4:      	blr	x8
    14c8:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
    14cc:      	ldr	x8, [x19, #0xd0]
    14d0:      	ldr	x9, [x19, #0x50]
    14d4:      	add	x10, x8, #0x36
    14d8:      	cmp	x10, x9
    14dc:      	b.hi	0x15e0 <tail_icmp6_handle_ns+0xcf0>
    14e0:      	ldrh	w10, [x8, #0x12]
    14e4:      	rev	w10, w10
    14e8:      	lsr	w10, w10, #16
    14ec:      	add	w10, w10, #0x8
    14f0:      	rev	w10, w10
    14f4:      	lsr	w10, w10, #16
    14f8:      	strh	w10, [x8, #0x12]
    14fc:      	add	x10, x8, #0x56
    1500:      	cmp	x10, x9
    1504:      	b.hi	0x15e0 <tail_icmp6_handle_ns+0xcf0>
    1508:      	mov	w20, #0x8000000         // =134217728
    150c:      	stur	xzr, [x8, #0x4e]
    1510:      	b	0xa10 <tail_icmp6_handle_ns+0x120>
    1514:      	mov	w0, #-0x96              // =-150
    1518:      	b	0x15e4 <tail_icmp6_handle_ns+0xcf4>
    151c:      	mov	w0, wzr
    1520:      	b	0x15e4 <tail_icmp6_handle_ns+0xcf4>
    1524:      	mov	w8, #0x26               // =38
    1528:      	mov	x0, x19
    152c:      	mov	w2, wzr
    1530:      	ldr	w9, [x19, #0x70]
    1534:      	add	w1, w9, #0x8
    1538:      	blr	x8
    153c:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
    1540:      	ldr	x8, [x19, #0xd0]
    1544:      	ldr	x9, [x19, #0x50]
    1548:      	add	x10, x8, #0x36
    154c:      	cmp	x10, x9
    1550:      	b.hi	0x15e0 <tail_icmp6_handle_ns+0xcf0>
    1554:      	ldrh	w10, [x8, #0x12]
    1558:      	rev	w10, w10
    155c:      	lsr	w10, w10, #16
    1560:      	add	w10, w10, #0x8
    1564:      	rev	w10, w10
    1568:      	lsr	w10, w10, #16
    156c:      	strh	w10, [x8, #0x12]
    1570:      	add	x10, x8, #0x56
    1574:      	cmp	x10, x9
    1578:      	b.hi	0x15e0 <tail_icmp6_handle_ns+0xcf0>
    157c:      	mov	w20, #0x8000000         // =134217728
    1580:      	stur	xzr, [x8, #0x4e]
    1584:      	b	0xdf8 <tail_icmp6_handle_ns+0x508>
    1588:      	mov	w8, #0x26               // =38
    158c:      	mov	x0, x19
    1590:      	mov	w2, wzr
    1594:      	ldr	w9, [x19, #0x70]
    1598:      	add	w1, w9, #0x8
    159c:      	blr	x8
    15a0:      	tbnz	w0, #0x1f, 0x15e0 <tail_icmp6_handle_ns+0xcf0>
    15a4:      	ldr	x8, [x19, #0xd0]
    15a8:      	ldr	x9, [x19, #0x50]
    15ac:      	add	x10, x8, #0x36
    15b0:      	cmp	x10, x9
    15b4:      	b.hi	0x15e0 <tail_icmp6_handle_ns+0xcf0>
    15b8:      	ldrh	w10, [x8, #0x12]
    15bc:      	rev	w10, w10
    15c0:      	lsr	w10, w10, #16
    15c4:      	add	w10, w10, #0x8
    15c8:      	rev	w10, w10
    15cc:      	lsr	w10, w10, #16
    15d0:      	strh	w10, [x8, #0x12]
    15d4:      	add	x10, x8, #0x56
    15d8:      	cmp	x10, x9
    15dc:      	b.ls	0x1610 <tail_icmp6_handle_ns+0xd20>
    15e0:      	mov	w0, #-0x86              // =-134
    15e4:      	tbnz	w0, #0x1f, 0xd20 <tail_icmp6_handle_ns+0x430>
    15e8:      	cmp	w0, #0x2
    15ec:      	b.eq	0xd20 <tail_icmp6_handle_ns+0x430>
    15f0:      	ldp	x20, x19, [sp, #0x110]
    15f4:      	ldp	x22, x21, [sp, #0x100]
    15f8:      	ldp	x24, x23, [sp, #0xf0]
    15fc:      	ldp	x29, x30, [sp, #0xe0]
    1600:      	add	sp, sp, #0x120
    1604:      	ret
    1608:      	mov	w0, #-0x9a              // =-154
    160c:      	b	0x15e4 <tail_icmp6_handle_ns+0xcf4>
    1610:      	mov	w20, #0x8000000         // =134217728
    1614:      	stur	xzr, [x8, #0x4e]
    1618:      	b	0x1144 <tail_icmp6_handle_ns+0x854>
    161c:      	mov	w0, wzr
    1620:      	mov	w8, #0x17               // =23
    1624:      	b	0x163c <tail_icmp6_handle_ns+0xd4c>
    1628:      	mov	w0, wzr
    162c:      	mov	w8, #0x17               // =23
    1630:      	b	0x163c <tail_icmp6_handle_ns+0xd4c>
    1634:      	mov	w0, wzr
    1638:      	mov	w8, #0x17               // =23
    163c:      	mov	w1, wzr
    1640:      	blr	x8
    1644:      	b	0x15e4 <tail_icmp6_handle_ns+0xcf4>

Disassembly of section tc/entry:

0000000000000000 <cil_from_container>:
       0:      	sub	sp, sp, #0x60
       4:      	stp	x30, x25, [sp, #0x20]
       8:      	stp	x24, x23, [sp, #0x30]
       c:      	stp	x22, x21, [sp, #0x40]
      10:      	stp	x20, x19, [sp, #0x50]
      14:      	adrp	x8, 0x0 <cil_from_container>
      18:      	mov	x19, x0
      1c:      	mov	w21, #0xa6              // =166
      20:      	ldr	x8, [x8]
      24:      	ldr	w22, [x8]
      28:      	ldr	x8, [x0, #0xd0]
      2c:      	ldr	x9, [x0, #0x50]
      30:      	add	x10, x8, #0xe
      34:      	cmp	x10, x9
      38:      	b.hi	0x4c <cil_from_container+0x4c>
      3c:      	ldrh	w8, [x8, #0xc]
      40:      	cmp	w8, #0x5
      44:      	mov	w8, #0x8b               // =139
      48:      	csel	w21, w8, w21, hi
      4c:      	str	wzr, [x19, #0x30]
      50:      	adrp	x23, 0x0 <cil_from_container>
      54:      	str	wzr, [x19, #0x34]
      58:      	str	wzr, [x19, #0x38]
      5c:      	str	wzr, [x19, #0x3c]
      60:      	str	wzr, [x19, #0x40]
      64:      	ldr	x23, [x23]
      68:      	ldrb	w8, [x23]
      6c:      	cbz	w8, 0xa8 <cil_from_container+0xa8>
      70:      	ldrb	w24, [x23]
      74:      	ldr	x9, [x19, #0xd0]
      78:      	add	x8, x9, #0xe
      7c:      	ldr	x10, [x19, #0x50]
      80:      	cmp	x8, x10
      84:      	b.ls	0x194 <cil_from_container+0x194>
      88:      	str	wzr, [sp, #0x8]
      8c:      	mov	w8, #0x1                // =1
      90:      	adrp	x0, 0x0 <cil_from_container>
      94:      	add	x1, sp, #0x8
      98:      	ldr	x0, [x0]
      9c:      	blr	x8
      a0:      	cbz	x0, 0xa8 <cil_from_container+0xa8>
      a4:      	str	xzr, [x0]
      a8:      	strh	wzr, [x19, #0x7c]
      ac:      	adrp	x8, 0x0 <cil_from_container>
      b0:      	ldr	x8, [x8]
      b4:      	ldrh	wzr, [x8]
      b8:      	adrp	x8, 0x0 <cil_from_container>
      bc:      	ldr	x8, [x8]
      c0:      	ldr	wzr, [x8]
      c4:      	ldrb	w8, [x23]
      c8:      	cbz	w8, 0xe4 <cil_from_container+0xe4>
      cc:      	str	wzr, [sp, #0x8]
      d0:      	mov	w8, #0x1                // =1
      d4:      	adrp	x0, 0x0 <cil_from_container>
      d8:      	add	x1, sp, #0x8
      dc:      	ldr	x0, [x0]
      e0:      	blr	x8
      e4:      	mov	x8, #0x20200000000      // =2207613190144
      e8:      	stp	w22, wzr, [x19, #0x30]
      ec:      	str	w21, [x19, #0x38]
      f0:      	ldr	w20, [x19, #0x70]
      f4:      	adrp	x0, 0x0 <cil_from_container>
      f8:      	mov	x1, sp
      fc:      	movk	x8, #0x73c, lsl #48
     100:      	stur	x8, [x19, #0x3c]
     104:      	mov	x8, #0x200              // =512
     108:      	movk	x8, #0x73c, lsl #16
     10c:      	movk	x8, #0x2, lsl #32
     110:      	str	x8, [sp]
     114:      	strb	w21, [sp]
     118:      	mov	w8, #0x1                // =1
     11c:      	ldr	x0, [x0]
     120:      	blr	x8
     124:      	cbz	x0, 0x13c <cil_from_container+0x13c>
     128:      	ldp	x8, x9, [x0]
     12c:      	add	x8, x8, #0x1
     130:      	add	x9, x9, x20
     134:      	stp	x8, x9, [x0]
     138:      	b	0x160 <cil_from_container+0x160>
     13c:      	mov	w8, #0x1                // =1
     140:      	adrp	x0, 0x0 <cil_from_container>
     144:      	mov	x1, sp
     148:      	stp	x8, x20, [sp, #0x8]
     14c:      	mov	w8, #0x2                // =2
     150:      	add	x2, sp, #0x8
     154:      	mov	w3, wzr
     158:      	ldr	x0, [x0]
     15c:      	blr	x8
     160:      	mov	w8, #0xc                // =12
     164:      	adrp	x1, 0x0 <cil_from_container>
     168:      	mov	x0, x19
     16c:      	ldr	x1, [x1]
     170:      	mov	w2, #0x1                // =1
     174:      	blr	x8
     178:      	ldp	x20, x19, [sp, #0x50]
     17c:      	mov	w0, #0x2                // =2
     180:      	ldp	x22, x21, [sp, #0x40]
     184:      	ldp	x24, x23, [sp, #0x30]
     188:      	ldp	x30, x25, [sp, #0x20]
     18c:      	add	sp, sp, #0x60
     190:      	ret
     194:      	add	x11, x9, #0x22
     198:      	cmp	x11, x10
     19c:      	b.hi	0x88 <cil_from_container+0x88>
     1a0:      	ldrh	w9, [x9, #0xc]
     1a4:      	cmp	w9, #0x8
     1a8:      	b.ne	0x88 <cil_from_container+0x88>
     1ac:      	ldrb	w8, [x8]
     1b0:      	and	w25, w8, #0xf
     1b4:      	cmp	w25, #0x6
     1b8:      	b.hs	0x1e4 <cil_from_container+0x1e4>
     1bc:      	mov	x20, xzr
     1c0:      	str	wzr, [sp, #0x8]
     1c4:      	mov	w8, #0x1                // =1
     1c8:      	adrp	x0, 0x0 <cil_from_container>
     1cc:      	add	x1, sp, #0x8
     1d0:      	ldr	x0, [x0]
     1d4:      	blr	x8
     1d8:      	cbz	x0, 0xa8 <cil_from_container+0xa8>
     1dc:      	str	x20, [x0]
     1e0:      	b	0xa8 <cil_from_container+0xa8>
     1e4:      	mov	w8, #0x1a               // =26
     1e8:      	mov	x2, sp
     1ec:      	mov	x0, x19
     1f0:      	mov	w1, #0x22               // =34
     1f4:      	mov	w3, #0x1                // =1
     1f8:      	blr	x8
     1fc:      	tbnz	w0, #0x1f, 0x88 <cil_from_container+0x88>
     200:      	ldrb	w8, [sp]
     204:      	cbz	w8, 0x1bc <cil_from_container+0x1bc>
     208:      	cmp	w8, #0x1
     20c:      	b.ne	0x218 <cil_from_container+0x218>
     210:      	mov	w20, #0x23              // =35
     214:      	b	0x290 <cil_from_container+0x290>
     218:      	mov	w8, #0x1a               // =26
     21c:      	add	x2, sp, #0x1c
     220:      	mov	x0, x19
     224:      	mov	w1, #0x23               // =35
     228:      	mov	w3, #0x1                // =1
     22c:      	blr	x8
     230:      	tbnz	w0, #0x1f, 0x88 <cil_from_container+0x88>
     234:      	ldrb	w8, [sp]
     238:      	cmp	w8, w24
     23c:      	b.ne	0x288 <cil_from_container+0x288>
     240:      	mov	w20, #0x22              // =34
     244:      	ldrb	w8, [sp, #0x1c]
     248:      	cmp	w8, #0xa
     24c:      	b.eq	0x384 <cil_from_container+0x384>
     250:      	cmp	w8, #0x6
     254:      	b.eq	0x358 <cil_from_container+0x358>
     258:      	cmp	w8, #0x4
     25c:      	b.ne	0x88 <cil_from_container+0x88>
     260:      	mov	w8, #0x1a               // =26
     264:      	add	w1, w20, #0x2
     268:      	add	x2, sp, #0x8
     26c:      	mov	x0, x19
     270:      	mov	w3, #0x2                // =2
     274:      	blr	x8
     278:      	ldrh	w8, [sp, #0x8]
     27c:      	rev	w8, w8
     280:      	lsr	w8, w8, #16
     284:      	b	0x3a4 <cil_from_container+0x3a4>
     288:      	ldrb	w8, [sp, #0x1c]
     28c:      	add	w20, w8, #0x22
     290:      	lsl	w8, w25, #2
     294:      	add	w25, w8, #0x22
     298:      	cmp	w20, w25
     29c:      	b.hs	0x1bc <cil_from_container+0x1bc>
     2a0:      	mov	w8, #0x1a               // =26
     2a4:      	mov	x2, sp
     2a8:      	mov	x0, x19
     2ac:      	mov	w1, w20
     2b0:      	mov	w3, #0x1                // =1
     2b4:      	blr	x8
     2b8:      	tbnz	w0, #0x1f, 0x88 <cil_from_container+0x88>
     2bc:      	ldrb	w8, [sp]
     2c0:      	cbz	w8, 0x1bc <cil_from_container+0x1bc>
     2c4:      	cmp	w8, #0x1
     2c8:      	b.eq	0x2f8 <cil_from_container+0x2f8>
     2cc:      	mov	w8, #0x1a               // =26
     2d0:      	add	w1, w20, #0x1
     2d4:      	add	x2, sp, #0x1c
     2d8:      	mov	x0, x19
     2dc:      	mov	w3, #0x1                // =1
     2e0:      	blr	x8
     2e4:      	tbnz	w0, #0x1f, 0x88 <cil_from_container+0x88>
     2e8:      	ldrb	w8, [sp]
     2ec:      	cmp	w8, w24
     2f0:      	b.eq	0x244 <cil_from_container+0x244>
     2f4:      	ldrb	w8, [sp, #0x1c]
     2f8:      	add	w20, w20, w8
     2fc:      	cmp	w20, w25
     300:      	b.hs	0x1bc <cil_from_container+0x1bc>
     304:      	mov	w8, #0x1a               // =26
     308:      	mov	x2, sp
     30c:      	mov	x0, x19
     310:      	mov	w1, w20
     314:      	mov	w3, #0x1                // =1
     318:      	blr	x8
     31c:      	tbnz	w0, #0x1f, 0x88 <cil_from_container+0x88>
     320:      	ldrb	w8, [sp]
     324:      	cmp	w8, #0x2
     328:      	b.lo	0x1bc <cil_from_container+0x1bc>
     32c:      	mov	w8, #0x1a               // =26
     330:      	add	w1, w20, #0x1
     334:      	add	x2, sp, #0x1c
     338:      	mov	x0, x19
     33c:      	mov	w3, #0x1                // =1
     340:      	blr	x8
     344:      	tbnz	w0, #0x1f, 0x88 <cil_from_container+0x88>
     348:      	ldrb	w8, [sp]
     34c:      	cmp	w8, w24
     350:      	b.ne	0x1bc <cil_from_container+0x1bc>
     354:      	b	0x244 <cil_from_container+0x244>
     358:      	mov	w8, #0x1a               // =26
     35c:      	add	w1, w20, #0x2
     360:      	add	x2, sp, #0x8
     364:      	mov	x0, x19
     368:      	mov	w3, #0x4                // =4
     36c:      	blr	x8
     370:      	ldr	w8, [sp, #0x8]
     374:      	cmp	w0, #0x0
     378:      	rev	w8, w8
     37c:      	csel	w20, wzr, w8, lt
     380:      	b	0x3ac <cil_from_container+0x3ac>
     384:      	mov	w8, #0x1a               // =26
     388:      	add	w1, w20, #0x2
     38c:      	add	x2, sp, #0x8
     390:      	mov	x0, x19
     394:      	mov	w3, #0x8                // =8
     398:      	blr	x8
     39c:      	ldr	x8, [sp, #0x8]
     3a0:      	rev	x8, x8
     3a4:      	cmp	w0, #0x0
     3a8:      	csel	x20, xzr, x8, lt
     3ac:      	tbz	w0, #0x1f, 0x1c0 <cil_from_container+0x1c0>
     3b0:      	b	0x88 <cil_from_container+0x88>
     3b4:      	nop
     3b8:      	nop
     3bc:      	nop

00000000000003c0 <cil_lxc_policy>:
     3c0:      	sub	sp, sp, #0x30
     3c4:      	str	x30, [sp, #0x10]
     3c8:      	stp	x20, x19, [sp, #0x20]
     3cc:      	adrp	x8, 0x0 <cil_from_container>
     3d0:      	mov	x19, x0
     3d4:      	ldr	x8, [x8]
     3d8:      	ldr	w9, [x8]
     3dc:      	ldr	x10, [x0, #0xd0]
     3e0:      	ldr	x11, [x0, #0x50]
     3e4:      	mov	w8, #0xa6               // =166
     3e8:      	add	x12, x10, #0xe
     3ec:      	cmp	x12, x11
     3f0:      	b.hi	0x404 <cil_lxc_policy+0x44>
     3f4:      	ldrh	w10, [x10, #0xc]
     3f8:      	cmp	w10, #0x5
     3fc:      	mov	w10, #0x8b              // =139
     400:      	csel	w8, w10, w8, hi
     404:      	adrp	x10, 0x0 <cil_from_container>
     408:      	adrp	x0, 0x0 <cil_from_container>
     40c:      	add	x1, sp, #0x18
     410:      	ldr	x10, [x10]
     414:      	ldrh	w10, [x10]
     418:      	stp	w9, w8, [x19, #0x34]
     41c:      	mov	w9, #0x202              // =514
     420:      	ldr	w20, [x19, #0x70]
     424:      	movk	w9, #0x9e8, lsl #16
     428:      	stp	w10, w9, [x19, #0x3c]
     42c:      	mov	x9, #0x100              // =256
     430:      	movk	x9, #0x9e8, lsl #16
     434:      	movk	x9, #0x2, lsl #32
     438:      	str	x9, [sp, #0x18]
     43c:      	strb	w8, [sp, #0x18]
     440:      	mov	w8, #0x1                // =1
     444:      	ldr	x0, [x0]
     448:      	blr	x8
     44c:      	cbz	x0, 0x464 <cil_lxc_policy+0xa4>
     450:      	ldp	x8, x9, [x0]
     454:      	add	x8, x8, #0x1
     458:      	add	x9, x9, x20
     45c:      	stp	x8, x9, [x0]
     460:      	b	0x488 <cil_lxc_policy+0xc8>
     464:      	mov	w8, #0x1                // =1
     468:      	adrp	x0, 0x0 <cil_from_container>
     46c:      	add	x1, sp, #0x18
     470:      	stp	x8, x20, [sp]
     474:      	mov	w8, #0x2                // =2
     478:      	mov	x2, sp
     47c:      	mov	w3, wzr
     480:      	ldr	x0, [x0]
     484:      	blr	x8
     488:      	mov	w8, #0xc                // =12
     48c:      	adrp	x1, 0x0 <cil_from_container>
     490:      	mov	x0, x19
     494:      	ldr	x1, [x1]
     498:      	mov	w2, #0x1                // =1
     49c:      	blr	x8
     4a0:      	ldp	x20, x19, [sp, #0x20]
     4a4:      	mov	w0, #0x2                // =2
     4a8:      	ldr	x30, [sp, #0x10]
     4ac:      	add	sp, sp, #0x30
     4b0:      	ret
     4b4:      	nop
     4b8:      	nop
     4bc:      	nop

00000000000004c0 <cil_lxc_policy_egress>:
     4c0:      	mov	w0, wzr
     4c4:      	ret
     4c8:      	nop
     4cc:      	nop

00000000000004d0 <cil_to_container>:
     4d0:      	sub	sp, sp, #0x60
     4d4:      	stp	x30, x25, [sp, #0x20]
     4d8:      	stp	x24, x23, [sp, #0x30]
     4dc:      	stp	x22, x21, [sp, #0x40]
     4e0:      	stp	x20, x19, [sp, #0x50]
     4e4:      	adrp	x8, 0x0 <cil_from_container>
     4e8:      	adrp	x22, 0x0 <cil_from_container>
     4ec:      	mov	x19, x0
     4f0:      	ldr	x8, [x8]
     4f4:      	ldr	w21, [x8]
     4f8:      	ldr	x8, [x0, #0xd0]
     4fc:      	ldr	x9, [x0, #0x50]
     500:      	ldr	x22, [x22]
     504:      	add	x10, x8, #0xe
     508:      	cmp	x10, x9
     50c:      	b.hi	0x614 <cil_to_container+0x144>
     510:      	ldrh	w8, [x8, #0xc]
     514:      	cmp	w8, #0x6
     518:      	b.lo	0x614 <cil_to_container+0x144>
     51c:      	str	wzr, [x19, #0x30]
     520:      	adrp	x23, 0x0 <cil_from_container>
     524:      	str	wzr, [x19, #0x34]
     528:      	str	wzr, [x19, #0x38]
     52c:      	str	wzr, [x19, #0x3c]
     530:      	str	wzr, [x19, #0x40]
     534:      	ldr	x23, [x23]
     538:      	ldrb	w8, [x23]
     53c:      	cbz	w8, 0x578 <cil_to_container+0xa8>
     540:      	ldrb	w24, [x23]
     544:      	ldr	x9, [x19, #0xd0]
     548:      	add	x8, x9, #0xe
     54c:      	ldr	x10, [x19, #0x50]
     550:      	cmp	x8, x10
     554:      	b.ls	0x69c <cil_to_container+0x1cc>
     558:      	str	wzr, [sp]
     55c:      	mov	w8, #0x1                // =1
     560:      	adrp	x0, 0x0 <cil_from_container>
     564:      	mov	x1, sp
     568:      	ldr	x0, [x0]
     56c:      	blr	x8
     570:      	cbz	x0, 0x578 <cil_to_container+0xa8>
     574:      	str	xzr, [x0]
     578:      	ldr	w20, [x19, #0xa8]
     57c:      	and	w8, w20, #0xf00
     580:      	sub	w8, w8, #0xa00
     584:      	lsr	w8, w8, #8
     588:      	cmp	w8, #0x1
     58c:      	b.gt	0x620 <cil_to_container+0x150>
     590:      	cbz	w8, 0x6f4 <cil_to_container+0x224>
     594:      	cmp	w8, #0x1
     598:      	b.ne	0x6ec <cil_to_container+0x21c>
     59c:      	adrp	x9, 0x0 <cil_from_container>
     5a0:      	mov	w11, #-0x1              // =-1
     5a4:      	mov	w12, #0x7fffff00        // =2147483392
     5a8:      	ldr	x9, [x9]
     5ac:      	mov	w14, #0x18              // =24
     5b0:      	and	w8, w20, #0xff
     5b4:      	ldr	w10, [x9]
     5b8:      	lsl	w10, w11, w10
     5bc:      	bic	w10, w12, w10
     5c0:      	ldr	w12, [x9]
     5c4:      	neg	w12, w12
     5c8:      	lsl	w10, w10, w12
     5cc:      	ldr	w12, [x9]
     5d0:      	ldr	w13, [x9]
     5d4:      	ldr	w9, [x9]
     5d8:      	and	w10, w10, w20
     5dc:      	neg	w12, w12
     5e0:      	sub	w13, w14, w13
     5e4:      	sub	w9, w14, w9
     5e8:      	lsr	w10, w10, w12
     5ec:      	lsr	w12, w20, #16
     5f0:      	lsl	w11, w11, w13
     5f4:      	orr	w8, w10, w8
     5f8:      	bic	w11, w12, w11
     5fc:      	lsl	w8, w8, w9
     600:      	orr	w24, w8, w11
     604:      	ldrh	w8, [x19, #0x86]
     608:      	orr	w8, w8, #0x2
     60c:      	strh	w8, [x19, #0x86]
     610:      	b	0x770 <cil_to_container+0x2a0>
     614:      	mov	w24, wzr
     618:      	mov	w8, #0xa6               // =166
     61c:      	b	0x854 <cil_to_container+0x384>
     620:      	cmp	w8, #0x2
     624:      	b.eq	0x76c <cil_to_container+0x29c>
     628:      	cmp	w8, #0x5
     62c:      	b.ne	0x6ec <cil_to_container+0x21c>
     630:      	adrp	x8, 0x0 <cil_from_container>
     634:      	mov	w11, #-0x1              // =-1
     638:      	mov	w12, #0x7fffff00        // =2147483392
     63c:      	ldr	x8, [x8]
     640:      	mov	w14, #0x18              // =24
     644:      	and	w9, w20, #0xff
     648:      	ldr	w10, [x8]
     64c:      	lsl	w10, w11, w10
     650:      	bic	w10, w12, w10
     654:      	ldr	w12, [x8]
     658:      	neg	w12, w12
     65c:      	lsl	w10, w10, w12
     660:      	ldr	w12, [x8]
     664:      	ldr	w13, [x8]
     668:      	ldr	w8, [x8]
     66c:      	and	w10, w10, w20
     670:      	neg	w12, w12
     674:      	sub	w13, w14, w13
     678:      	sub	w8, w14, w8
     67c:      	lsr	w10, w10, w12
     680:      	lsr	w12, w20, #16
     684:      	lsl	w11, w11, w13
     688:      	orr	w9, w10, w9
     68c:      	bic	w11, w12, w11
     690:      	lsl	w8, w9, w8
     694:      	orr	w24, w8, w11
     698:      	b	0x770 <cil_to_container+0x2a0>
     69c:      	add	x11, x9, #0x22
     6a0:      	cmp	x11, x10
     6a4:      	b.hi	0x558 <cil_to_container+0x88>
     6a8:      	ldrh	w9, [x9, #0xc]
     6ac:      	cmp	w9, #0x8
     6b0:      	b.ne	0x558 <cil_to_container+0x88>
     6b4:      	ldrb	w8, [x8]
     6b8:      	and	w25, w8, #0xf
     6bc:      	cmp	w25, #0x6
     6c0:      	b.hs	0x908 <cil_to_container+0x438>
     6c4:      	mov	x20, xzr
     6c8:      	str	wzr, [sp]
     6cc:      	mov	w8, #0x1                // =1
     6d0:      	adrp	x0, 0x0 <cil_from_container>
     6d4:      	mov	x1, sp
     6d8:      	ldr	x0, [x0]
     6dc:      	blr	x8
     6e0:      	cbz	x0, 0x578 <cil_to_container+0xa8>
     6e4:      	str	x20, [x0]
     6e8:      	b	0x578 <cil_to_container+0xa8>
     6ec:      	mov	w24, #0x2               // =2
     6f0:      	b	0x770 <cil_to_container+0x2a0>
     6f4:      	adrp	x9, 0x0 <cil_from_container>
     6f8:      	mov	w11, #-0x1              // =-1
     6fc:      	mov	w12, #0x7fffff00        // =2147483392
     700:      	ldr	x9, [x9]
     704:      	mov	w14, #0x18              // =24
     708:      	and	w8, w20, #0xff
     70c:      	ldr	w10, [x9]
     710:      	lsl	w10, w11, w10
     714:      	bic	w10, w12, w10
     718:      	ldr	w12, [x9]
     71c:      	neg	w12, w12
     720:      	lsl	w10, w10, w12
     724:      	ldr	w12, [x9]
     728:      	ldr	w13, [x9]
     72c:      	ldr	w9, [x9]
     730:      	and	w10, w10, w20
     734:      	neg	w12, w12
     738:      	sub	w13, w14, w13
     73c:      	sub	w9, w14, w9
     740:      	lsr	w10, w10, w12
     744:      	lsr	w12, w20, #16
     748:      	lsl	w11, w11, w13
     74c:      	orr	w8, w10, w8
     750:      	bic	w11, w12, w11
     754:      	lsl	w8, w8, w9
     758:      	orr	w24, w8, w11
     75c:      	ldrh	w8, [x19, #0x86]
     760:      	orr	w8, w8, #0x1
     764:      	strh	w8, [x19, #0x86]
     768:      	b	0x770 <cil_to_container+0x2a0>
     76c:      	mov	w24, #0x1               // =1
     770:      	mov	w8, #0x3d02             // =15618
     774:      	str	wzr, [x19, #0xa8]
     778:      	adrp	x1, 0x0 <cil_from_container>
     77c:      	mov	x3, sp
     780:      	strh	w8, [sp]
     784:      	mov	x0, x19
     788:      	mov	w2, #-0x1               // =-1
     78c:      	mov	w4, #0x14               // =20
     790:      	ldrh	w8, [x22]
     794:      	stur	xzr, [sp, #0xc]
     798:      	strh	w8, [sp, #0x2]
     79c:      	ldr	w8, [x19, #0x98]
     7a0:      	stp	w8, w24, [sp, #0x4]
     7a4:      	mov	w8, #0x19               // =25
     7a8:      	ldr	x1, [x1]
     7ac:      	blr	x8
     7b0:      	adrp	x8, 0x0 <cil_from_container>
     7b4:      	ldrh	wzr, [x22]
     7b8:      	and	w20, w20, #0xe00
     7bc:      	ldr	x8, [x8]
     7c0:      	ldr	wzr, [x8]
     7c4:      	ldrb	w8, [x23]
     7c8:      	cbz	w8, 0x7e4 <cil_to_container+0x314>
     7cc:      	str	wzr, [sp]
     7d0:      	mov	w8, #0x1                // =1
     7d4:      	adrp	x0, 0x0 <cil_from_container>
     7d8:      	mov	x1, sp
     7dc:      	ldr	x0, [x0]
     7e0:      	blr	x8
     7e4:      	cmp	w20, #0xa00
     7e8:      	b.eq	0x850 <cil_to_container+0x380>
     7ec:      	mov	x8, #0x103              // =259
     7f0:      	ldr	w20, [x19, #0x70]
     7f4:      	adrp	x0, 0x0 <cil_from_container>
     7f8:      	add	x1, sp, #0x18
     7fc:      	movk	x8, #0xa51, lsl #16
     800:      	movk	x8, #0x2, lsl #32
     804:      	str	x8, [sp, #0x18]
     808:      	mov	w8, #0x1                // =1
     80c:      	ldr	x0, [x0]
     810:      	blr	x8
     814:      	cbz	x0, 0x82c <cil_to_container+0x35c>
     818:      	ldp	x8, x9, [x0]
     81c:      	add	x8, x8, #0x1
     820:      	add	x9, x9, x20
     824:      	stp	x8, x9, [x0]
     828:      	b	0x850 <cil_to_container+0x380>
     82c:      	mov	w8, #0x1                // =1
     830:      	adrp	x0, 0x0 <cil_from_container>
     834:      	add	x1, sp, #0x18
     838:      	stp	x8, x20, [sp]
     83c:      	mov	w8, #0x2                // =2
     840:      	mov	x2, sp
     844:      	mov	w3, wzr
     848:      	ldr	x0, [x0]
     84c:      	blr	x8
     850:      	mov	w8, #0x8b               // =139
     854:      	ldrh	w9, [x22]
     858:      	stp	w24, w21, [x19, #0x30]
     85c:      	adrp	x0, 0x0 <cil_from_container>
     860:      	add	x1, sp, #0x18
     864:      	ldr	w20, [x19, #0x70]
     868:      	stp	w8, w9, [x19, #0x38]
     86c:      	mov	w9, #0x202              // =514
     870:      	movk	w9, #0xa85, lsl #16
     874:      	str	w9, [x19, #0x40]
     878:      	mov	x9, #0x100              // =256
     87c:      	movk	x9, #0xa85, lsl #16
     880:      	movk	x9, #0x2, lsl #32
     884:      	str	x9, [sp, #0x18]
     888:      	strb	w8, [sp, #0x18]
     88c:      	mov	w8, #0x1                // =1
     890:      	ldr	x0, [x0]
     894:      	blr	x8
     898:      	cbz	x0, 0x8b0 <cil_to_container+0x3e0>
     89c:      	ldp	x8, x9, [x0]
     8a0:      	add	x8, x8, #0x1
     8a4:      	add	x9, x9, x20
     8a8:      	stp	x8, x9, [x0]
     8ac:      	b	0x8d4 <cil_to_container+0x404>
     8b0:      	mov	w8, #0x1                // =1
     8b4:      	adrp	x0, 0x0 <cil_from_container>
     8b8:      	add	x1, sp, #0x18
     8bc:      	stp	x8, x20, [sp]
     8c0:      	mov	w8, #0x2                // =2
     8c4:      	mov	x2, sp
     8c8:      	mov	w3, wzr
     8cc:      	ldr	x0, [x0]
     8d0:      	blr	x8
     8d4:      	mov	w8, #0xc                // =12
     8d8:      	adrp	x1, 0x0 <cil_from_container>
     8dc:      	mov	x0, x19
     8e0:      	ldr	x1, [x1]
     8e4:      	mov	w2, #0x1                // =1
     8e8:      	blr	x8
     8ec:      	ldp	x20, x19, [sp, #0x50]
     8f0:      	mov	w0, #0x2                // =2
     8f4:      	ldp	x22, x21, [sp, #0x40]
     8f8:      	ldp	x24, x23, [sp, #0x30]
     8fc:      	ldp	x30, x25, [sp, #0x20]
     900:      	add	sp, sp, #0x60
     904:      	ret
     908:      	mov	w8, #0x1a               // =26
     90c:      	add	x2, sp, #0x18
     910:      	mov	x0, x19
     914:      	mov	w1, #0x22               // =34
     918:      	mov	w3, #0x1                // =1
     91c:      	blr	x8
     920:      	tbnz	w0, #0x1f, 0x558 <cil_to_container+0x88>
     924:      	ldrb	w8, [sp, #0x18]
     928:      	cbz	w8, 0x6c4 <cil_to_container+0x1f4>
     92c:      	cmp	w8, #0x1
     930:      	b.ne	0x93c <cil_to_container+0x46c>
     934:      	mov	w20, #0x23              // =35
     938:      	b	0x9b4 <cil_to_container+0x4e4>
     93c:      	mov	w8, #0x1a               // =26
     940:      	add	x2, sp, #0x14
     944:      	mov	x0, x19
     948:      	mov	w1, #0x23               // =35
     94c:      	mov	w3, #0x1                // =1
     950:      	blr	x8
     954:      	tbnz	w0, #0x1f, 0x558 <cil_to_container+0x88>
     958:      	ldrb	w8, [sp, #0x18]
     95c:      	cmp	w8, w24
     960:      	b.ne	0x9ac <cil_to_container+0x4dc>
     964:      	mov	w20, #0x22              // =34
     968:      	ldrb	w8, [sp, #0x14]
     96c:      	cmp	w8, #0xa
     970:      	b.eq	0xaa8 <cil_to_container+0x5d8>
     974:      	cmp	w8, #0x6
     978:      	b.eq	0xa7c <cil_to_container+0x5ac>
     97c:      	cmp	w8, #0x4
     980:      	b.ne	0x558 <cil_to_container+0x88>
     984:      	mov	w8, #0x1a               // =26
     988:      	add	w1, w20, #0x2
     98c:      	mov	x2, sp
     990:      	mov	x0, x19
     994:      	mov	w3, #0x2                // =2
     998:      	blr	x8
     99c:      	ldrh	w8, [sp]
     9a0:      	rev	w8, w8
     9a4:      	lsr	w8, w8, #16
     9a8:      	b	0xac8 <cil_to_container+0x5f8>
     9ac:      	ldrb	w8, [sp, #0x14]
     9b0:      	add	w20, w8, #0x22
     9b4:      	lsl	w8, w25, #2
     9b8:      	add	w25, w8, #0x22
     9bc:      	cmp	w20, w25
     9c0:      	b.hs	0x6c4 <cil_to_container+0x1f4>
     9c4:      	mov	w8, #0x1a               // =26
     9c8:      	add	x2, sp, #0x18
     9cc:      	mov	x0, x19
     9d0:      	mov	w1, w20
     9d4:      	mov	w3, #0x1                // =1
     9d8:      	blr	x8
     9dc:      	tbnz	w0, #0x1f, 0x558 <cil_to_container+0x88>
     9e0:      	ldrb	w8, [sp, #0x18]
     9e4:      	cbz	w8, 0x6c4 <cil_to_container+0x1f4>
     9e8:      	cmp	w8, #0x1
     9ec:      	b.eq	0xa1c <cil_to_container+0x54c>
     9f0:      	mov	w8, #0x1a               // =26
     9f4:      	add	w1, w20, #0x1
     9f8:      	add	x2, sp, #0x14
     9fc:      	mov	x0, x19
     a00:      	mov	w3, #0x1                // =1
     a04:      	blr	x8
     a08:      	tbnz	w0, #0x1f, 0x558 <cil_to_container+0x88>
     a0c:      	ldrb	w8, [sp, #0x18]
     a10:      	cmp	w8, w24
     a14:      	b.eq	0x968 <cil_to_container+0x498>
     a18:      	ldrb	w8, [sp, #0x14]
     a1c:      	add	w20, w20, w8
     a20:      	cmp	w20, w25
     a24:      	b.hs	0x6c4 <cil_to_container+0x1f4>
     a28:      	mov	w8, #0x1a               // =26
     a2c:      	add	x2, sp, #0x18
     a30:      	mov	x0, x19
     a34:      	mov	w1, w20
     a38:      	mov	w3, #0x1                // =1
     a3c:      	blr	x8
     a40:      	tbnz	w0, #0x1f, 0x558 <cil_to_container+0x88>
     a44:      	ldrb	w8, [sp, #0x18]
     a48:      	cmp	w8, #0x2
     a4c:      	b.lo	0x6c4 <cil_to_container+0x1f4>
     a50:      	mov	w8, #0x1a               // =26
     a54:      	add	w1, w20, #0x1
     a58:      	add	x2, sp, #0x14
     a5c:      	mov	x0, x19
     a60:      	mov	w3, #0x1                // =1
     a64:      	blr	x8
     a68:      	tbnz	w0, #0x1f, 0x558 <cil_to_container+0x88>
     a6c:      	ldrb	w8, [sp, #0x18]
     a70:      	cmp	w8, w24
     a74:      	b.ne	0x6c4 <cil_to_container+0x1f4>
     a78:      	b	0x968 <cil_to_container+0x498>
     a7c:      	mov	w8, #0x1a               // =26
     a80:      	add	w1, w20, #0x2
     a84:      	mov	x2, sp
     a88:      	mov	x0, x19
     a8c:      	mov	w3, #0x4                // =4
     a90:      	blr	x8
     a94:      	ldr	w8, [sp]
     a98:      	cmp	w0, #0x0
     a9c:      	rev	w8, w8
     aa0:      	csel	w20, wzr, w8, lt
     aa4:      	b	0xad0 <cil_to_container+0x600>
     aa8:      	mov	w8, #0x1a               // =26
     aac:      	add	w1, w20, #0x2
     ab0:      	mov	x2, sp
     ab4:      	mov	x0, x19
     ab8:      	mov	w3, #0x8                // =8
     abc:      	blr	x8
     ac0:      	ldr	x8, [sp]
     ac4:      	rev	x8, x8
     ac8:      	cmp	w0, #0x0
     acc:      	csel	x20, xzr, x8, lt
     ad0:      	tbz	w0, #0x1f, 0x6c8 <cil_to_container+0x1f8>
     ad4:      	b	0x558 <cil_to_container+0x88>
