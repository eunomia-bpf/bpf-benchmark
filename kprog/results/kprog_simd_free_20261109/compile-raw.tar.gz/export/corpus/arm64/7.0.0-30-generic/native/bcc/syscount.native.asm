
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/bcc/syscount.native.o:	file format elf64-littleaarch64

Disassembly of section tracepoint/raw_syscalls/sys_enter:

0000000000000000 <sys_enter>:
       0:      	sub	sp, sp, #0x20
       4:      	stp	x30, x19, [sp, #0x10]
       8:      	bl	0x8 <sys_enter+0x8>
       c:      	mov	x19, x0
      10:      	adrp	x8, 0x0 <sys_enter>
      14:      	str	w19, [sp, #0xc]
      18:      	ldr	x8, [x8]
      1c:      	ldrb	w8, [x8]
      20:      	cbz	w8, 0x38 <sys_enter+0x38>
      24:      	adrp	x0, 0x0 <sys_enter>
      28:      	mov	w1, wzr
      2c:      	ldr	x0, [x0]
      30:      	bl	0x30 <sys_enter+0x30>
      34:      	cbz	x0, 0x78 <sys_enter+0x78>
      38:      	adrp	x8, 0x0 <sys_enter>
      3c:      	ldr	x8, [x8]
      40:      	ldr	w9, [x8]
      44:      	cbz	w9, 0x58 <sys_enter+0x58>
      48:      	ldr	w8, [x8]
      4c:      	lsr	x9, x19, #32
      50:      	cmp	w8, w9
      54:      	b.ne	0x78 <sys_enter+0x78>
      58:      	bl	0x58 <sys_enter+0x58>
      5c:      	str	x0, [sp]
      60:      	adrp	x0, 0x0 <sys_enter>
      64:      	add	x1, sp, #0xc
      68:      	mov	x2, sp
      6c:      	ldr	x0, [x0]
      70:      	mov	x3, xzr
      74:      	bl	0x74 <sys_enter+0x74>
      78:      	ldp	x30, x19, [sp, #0x10]
      7c:      	mov	w0, wzr
      80:      	add	sp, sp, #0x20
      84:      	ret

Disassembly of section tracepoint/raw_syscalls/sys_exit:

0000000000000000 <sys_exit>:
       0:      	sub	sp, sp, #0x40
       4:      	str	x30, [sp, #0x10]
       8:      	stp	x22, x21, [sp, #0x20]
       c:      	stp	x20, x19, [sp, #0x30]
      10:      	adrp	x8, 0x0 <sys_exit>
      14:      	mov	x19, x0
      18:      	ldr	x8, [x8]
      1c:      	ldrb	w8, [x8]
      20:      	cbz	w8, 0x38 <sys_exit+0x38>
      24:      	adrp	x0, 0x0 <sys_exit>
      28:      	mov	w1, wzr
      2c:      	ldr	x0, [x0]
      30:      	bl	0x30 <sys_exit+0x30>
      34:      	cbz	x0, 0x1f4 <sys_exit+0x1f4>
      38:      	bl	0x38 <sys_exit+0x38>
      3c:      	ldr	x8, [x19, #0x8]
      40:      	str	w0, [sp, #0xc]
      44:      	cmn	x8, #0x1
      48:      	b.eq	0x1f4 <sys_exit+0x1f4>
      4c:      	adrp	x8, 0x0 <sys_exit>
      50:      	ldr	x8, [x8]
      54:      	ldr	w9, [x8]
      58:      	cbz	w9, 0x6c <sys_exit+0x6c>
      5c:      	ldr	w8, [x8]
      60:      	lsr	x9, x0, #32
      64:      	cmp	w8, w9
      68:      	b.ne	0x1f4 <sys_exit+0x1f4>
      6c:      	adrp	x8, 0x0 <sys_exit>
      70:      	ldr	x8, [x8]
      74:      	ldrb	w8, [x8]
      78:      	cbz	w8, 0x84 <sys_exit+0x84>
      7c:      	ldr	x8, [x19, #0x10]
      80:      	tbz	x8, #0x3f, 0x1f4 <sys_exit+0x1f4>
      84:      	adrp	x8, 0x0 <sys_exit>
      88:      	ldr	x8, [x8]
      8c:      	ldr	w9, [x8]
      90:      	cbz	w9, 0xa4 <sys_exit+0xa4>
      94:      	ldr	x9, [x19, #0x10]
      98:      	ldrsw	x8, [x8]
      9c:      	cmn	x9, x8
      a0:      	b.ne	0x1f4 <sys_exit+0x1f4>
      a4:      	adrp	x21, 0x0 <sys_exit>
      a8:      	ldr	x21, [x21]
      ac:      	ldrb	w8, [x21]
      b0:      	cbz	w8, 0x100 <sys_exit+0x100>
      b4:      	adrp	x8, 0x0 <sys_exit>
      b8:      	add	x1, sp, #0xc
      bc:      	mov	x22, x0
      c0:      	ldr	x8, [x8]
      c4:      	mov	x0, x8
      c8:      	bl	0xc8 <sys_exit+0xc8>
      cc:      	cbz	x0, 0x1f4 <sys_exit+0x1f4>
      d0:      	mov	x20, x0
      d4:      	bl	0xd4 <sys_exit+0xd4>
      d8:      	ldr	x9, [x20]
      dc:      	mov	x8, x0
      e0:      	mov	x0, x22
      e4:      	sub	x20, x8, x9
      e8:      	adrp	x22, 0x0 <sys_exit>
      ec:      	ldr	x22, [x22]
      f0:      	ldrb	w8, [x22]
      f4:      	cbz	w8, 0x114 <sys_exit+0x114>
      f8:      	asr	x8, x0, #32
      fc:      	b	0x118 <sys_exit+0x118>
     100:      	mov	x20, xzr
     104:      	adrp	x22, 0x0 <sys_exit>
     108:      	ldr	x22, [x22]
     10c:      	ldrb	w8, [x22]
     110:      	cbnz	w8, 0xf8 <sys_exit+0xf8>
     114:      	ldr	x8, [x19, #0x8]
     118:      	str	w8, [sp, #0x8]
     11c:      	adrp	x0, 0x0 <sys_exit>
     120:      	add	x1, sp, #0x8
     124:      	ldr	x0, [x0]
     128:      	bl	0x128 <sys_exit+0x128>
     12c:      	mov	x19, x0
     130:      	cbz	x0, 0x1b4 <sys_exit+0x1b4>
     134:      	nop
     138:      	nop
     13c:      	nop
     140:      	ldaxr	x8, [x19]
     144:      	add	x8, x8, #0x1
     148:      	stlxr	w9, x8, [x19]
     14c:      	cbnz	w9, 0x140 <sys_exit+0x140>
     150:      	ldrb	w8, [x22]
     154:      	cbz	w8, 0x184 <sys_exit+0x184>
     158:      	bl	0x158 <sys_exit+0x158>
     15c:      	mov	x8, x0
     160:      	add	x0, sp, #0x18
     164:      	mov	w1, #0x8                // =8
     168:      	add	x2, x8, #0x910
     16c:      	bl	0x16c <sys_exit+0x16c>
     170:      	ldr	x8, [sp, #0x18]
     174:      	add	x0, x19, #0x10
     178:      	mov	w1, #0x10               // =16
     17c:      	add	x2, x8, #0xaf0
     180:      	bl	0x180 <sys_exit+0x180>
     184:      	ldrb	w8, [x21]
     188:      	cbz	w8, 0x1f4 <sys_exit+0x1f4>
     18c:      	add	x8, x19, #0x8
     190:      	nop
     194:      	nop
     198:      	nop
     19c:      	nop
     1a0:      	ldaxr	x9, [x8]
     1a4:      	add	x9, x9, x20
     1a8:      	stlxr	w10, x9, [x8]
     1ac:      	cbnz	w10, 0x1a0 <sys_exit+0x1a0>
     1b0:      	b	0x1f4 <sys_exit+0x1f4>
     1b4:      	adrp	x0, 0x0 <sys_exit>
     1b8:      	adrp	x2, 0x0 <sys_exit>
     1bc:      	add	x2, x2, #0x0
     1c0:      	ldr	x0, [x0]
     1c4:      	add	x1, sp, #0x8
     1c8:      	mov	w3, #0x1                // =1
     1cc:      	bl	0x1cc <sys_exit+0x1cc>
     1d0:      	cbz	x0, 0x1dc <sys_exit+0x1dc>
     1d4:      	cmn	x0, #0x11
     1d8:      	b.ne	0x1f4 <sys_exit+0x1f4>
     1dc:      	adrp	x0, 0x0 <sys_exit>
     1e0:      	add	x1, sp, #0x8
     1e4:      	ldr	x0, [x0]
     1e8:      	bl	0x1e8 <sys_exit+0x1e8>
     1ec:      	mov	x19, x0
     1f0:      	cbnz	x0, 0x140 <sys_exit+0x140>
     1f4:      	ldp	x20, x19, [sp, #0x30]
     1f8:      	mov	w0, wzr
     1fc:      	ldr	x30, [sp, #0x10]
     200:      	ldp	x22, x21, [sp, #0x20]
     204:      	add	sp, sp, #0x40
     208:      	ret
