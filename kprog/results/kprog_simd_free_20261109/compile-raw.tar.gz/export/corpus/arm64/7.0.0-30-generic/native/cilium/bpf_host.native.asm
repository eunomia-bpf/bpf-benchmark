
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/cilium/bpf_host.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <__check_cluster_id_bits>:
       0:      	adrp	x8, 0x0 <__check_cluster_id_bits>
       4:      	ldr	x8, [x8]
       8:      	ldr	wzr, [x8]
       c:      	ret

0000000000000010 <__check_eth_header_length>:
      10:      	adrp	x8, 0x0 <__check_cluster_id_bits>
      14:      	ldr	x8, [x8]
      18:      	ldrb	wzr, [x8]
      1c:      	ret

0000000000000020 <__check_device_mtu>:
      20:      	adrp	x8, 0x0 <__check_cluster_id_bits>
      24:      	ldr	x8, [x8]
      28:      	ldrh	wzr, [x8]
      2c:      	ret

Disassembly of section tc/tail:

0000000000000000 <tail_drop_notify>:
       0:      	sub	sp, sp, #0xa0
       4:      	str	x29, [sp, #0x50]
       8:      	stp	x30, x25, [sp, #0x60]
       c:      	stp	x24, x23, [sp, #0x70]
      10:      	stp	x22, x21, [sp, #0x80]
      14:      	stp	x20, x19, [sp, #0x90]
      18:      	adrp	x8, 0x0 <tail_drop_notify>
      1c:      	ldr	w23, [x0, #0x38]
      20:      	mov	x19, x0
      24:      	ldr	x8, [x8]
      28:      	ldrb	w8, [x8]
      2c:      	cbz	w8, 0x54 <tail_drop_notify+0x54>
      30:      	str	wzr, [sp, #0x10]
      34:      	mov	w8, #0x1                // =1
      38:      	adrp	x0, 0x0 <tail_drop_notify>
      3c:      	add	x1, sp, #0x10
      40:      	ldr	x0, [x0]
      44:      	blr	x8
      48:      	cbz	x0, 0x58 <tail_drop_notify+0x58>
      4c:      	ldr	x0, [x0]
      50:      	b	0x58 <tail_drop_notify+0x58>
      54:      	mov	x0, xzr
      58:      	mov	w20, #0x2               // =2
      5c:      	adrp	x9, 0x0 <tail_drop_notify>
      60:      	ldr	w25, [x19, #0x70]
      64:      	ldr	w22, [x19, #0x40]
      68:      	mov	w8, w25
      6c:      	str	x20, [sp, #0x40]
      70:      	ldr	x9, [x9]
      74:      	ldr	w10, [x9]
      78:      	cbz	w10, 0x1a4 <tail_drop_notify+0x1a4>
      7c:      	str	x0, [sp, #0x8]
      80:      	adrp	x8, 0x0 <tail_drop_notify>
      84:      	ldr	x8, [x8]
      88:      	ldr	w29, [x8]
      8c:      	ldr	w24, [x9]
      90:      	mov	w8, #0x5                // =5
      94:      	blr	x8
      98:      	str	w20, [sp, #0x5c]
      9c:      	mov	x21, x0
      a0:      	mov	w8, #0x1                // =1
      a4:      	adrp	x0, 0x0 <tail_drop_notify>
      a8:      	add	x1, sp, #0x5c
      ac:      	ldr	x0, [x0]
      b0:      	blr	x8
      b4:      	mov	x20, x0
      b8:      	cbnz	x0, 0xe4 <tail_drop_notify+0xe4>
      bc:      	str	xzr, [sp, #0x48]
      c0:      	mov	w8, #0x2                // =2
      c4:      	adrp	x0, 0x0 <tail_drop_notify>
      c8:      	add	x1, sp, #0x5c
      cc:      	add	x2, sp, #0x48
      d0:      	mov	w3, wzr
      d4:      	add	x20, sp, #0x48
      d8:      	ldr	x0, [x0]
      dc:      	blr	x8
      e0:      	tbnz	w0, #0x1f, 0x27c <tail_drop_notify+0x27c>
      e4:      	mov	w8, #0x1                // =1
      e8:      	adrp	x0, 0x0 <tail_drop_notify>
      ec:      	add	x1, sp, #0x40
      f0:      	ldr	x0, [x0]
      f4:      	blr	x8
      f8:      	cbz	x0, 0x160 <tail_drop_notify+0x160>
      fc:      	ldr	x8, [x0]
     100:      	mov	w9, #0xca00             // =51712
     104:      	movk	w9, #0x3b9a, lsl #16
     108:      	sub	x10, x21, x8
     10c:      	cmp	x10, x9
     110:      	b.ls	0x18c <tail_drop_notify+0x18c>
     114:      	mov	x11, #0x5a53            // =23123
     118:      	lsr	x8, x10, #9
     11c:      	neg	x10, x10
     120:      	movk	x11, #0xa09b, lsl #16
     124:      	movk	x11, #0xb82f, lsl #32
     128:      	movk	x11, #0x44, lsl #48
     12c:      	umulh	x8, x8, x11
     130:      	lsr	x11, x8, #11
     134:      	ldr	x8, [x0, #0x8]
     138:      	madd	x9, x11, x9, x10
     13c:      	madd	x8, x11, x24, x8
     140:      	add	x9, x21, x9
     144:      	cmp	x8, x29
     148:      	stp	x9, x8, [x0]
     14c:      	b.ls	0x158 <tail_drop_notify+0x158>
     150:      	mov	x8, x29
     154:      	str	x29, [x0, #0x8]
     158:      	cbnz	x8, 0x194 <tail_drop_notify+0x194>
     15c:      	b	0x29c <tail_drop_notify+0x29c>
     160:      	sub	x8, x24, #0x1
     164:      	adrp	x0, 0x0 <tail_drop_notify>
     168:      	add	x1, sp, #0x40
     16c:      	stp	x21, x8, [sp, #0x10]
     170:      	mov	w8, #0x2                // =2
     174:      	add	x2, sp, #0x10
     178:      	mov	w3, wzr
     17c:      	ldr	x0, [x0]
     180:      	blr	x8
     184:      	tbz	w0, #0x1f, 0x19c <tail_drop_notify+0x19c>
     188:      	b	0x29c <tail_drop_notify+0x29c>
     18c:      	ldr	x8, [x0, #0x8]
     190:      	cbz	x8, 0x29c <tail_drop_notify+0x29c>
     194:      	sub	x8, x8, #0x1
     198:      	str	x8, [x0, #0x8]
     19c:      	ldr	w8, [x19, #0x70]
     1a0:      	ldr	x0, [sp, #0x8]
     1a4:      	adrp	x9, 0x0 <tail_drop_notify>
     1a8:      	adrp	x10, 0x0 <tail_drop_notify>
     1ac:      	mov	w12, #0xdd86            // =56710
     1b0:      	ldr	x9, [x9]
     1b4:      	ldr	x10, [x10]
     1b8:      	ldrh	w11, [x19, #0xb4]
     1bc:      	ldrb	w9, [x9]
     1c0:      	ldr	w10, [x10]
     1c4:      	cmp	w9, #0x0
     1c8:      	cset	w9, eq
     1cc:      	cmp	w11, w12
     1d0:      	cset	w11, eq
     1d4:      	cmp	w10, w8
     1d8:      	csel	w8, w10, w8, lo
     1dc:      	adrp	x10, 0x0 <tail_drop_notify>
     1e0:      	orr	w9, w11, w9, lsl #1
     1e4:      	ldr	x10, [x10]
     1e8:      	ldrh	w14, [x10]
     1ec:      	ldr	w15, [x19, #0x98]
     1f0:      	ldp	w10, w11, [x19, #0x30]
     1f4:      	ldr	w12, [x19, #0x3c]
     1f8:      	ldr	x13, [x19, #0x10]
     1fc:      	cbz	x13, 0x204 <tail_drop_notify+0x204>
     200:      	ldr	w13, [x13, #0xe0]
     204:      	mov	w16, #0x1               // =1
     208:      	lsr	w17, w22, #8
     20c:      	strh	w14, [sp, #0x12]
     210:      	stp	w15, w25, [sp, #0x14]
     214:      	lsr	w14, w22, #16
     218:      	mov	w15, #0x3               // =3
     21c:      	strb	w16, [sp, #0x10]
     220:      	lsr	w16, w23, #8
     224:      	strb	w23, [sp, #0x11]
     228:      	adrp	x1, 0x0 <tail_drop_notify>
     22c:      	add	x3, sp, #0x10
     230:      	mov	w4, #0x30               // =48
     234:      	strh	w8, [sp, #0x1c]
     238:      	strh	w15, [sp, #0x1e]
     23c:      	stp	w10, w11, [sp, #0x20]
     240:      	mov	w10, #-0x1              // =-1
     244:      	orr	x2, x10, x8, lsl #32
     248:      	str	w12, [sp, #0x28]
     24c:      	strh	w14, [sp, #0x2c]
     250:      	strb	w17, [sp, #0x2e]
     254:      	strb	w16, [sp, #0x2f]
     258:      	str	w13, [sp, #0x30]
     25c:      	strb	w9, [sp, #0x34]
     260:      	mov	w9, #0x19               // =25
     264:      	sturh	wzr, [sp, #0x35]
     268:      	strb	wzr, [sp, #0x37]
     26c:      	str	x0, [sp, #0x38]
     270:      	ldr	x1, [x1]
     274:      	mov	x0, x19
     278:      	blr	x9
     27c:      	and	w0, w22, #0xff
     280:      	ldp	x20, x19, [sp, #0x90]
     284:      	ldr	x29, [sp, #0x50]
     288:      	ldp	x22, x21, [sp, #0x80]
     28c:      	ldp	x24, x23, [sp, #0x70]
     290:      	ldp	x30, x25, [sp, #0x60]
     294:      	add	sp, sp, #0xa0
     298:      	ret
     29c:      	ldr	x8, [x20]
     2a0:      	add	x8, x8, #0x1
     2a4:      	str	x8, [x20]
     2a8:      	b	0x27c <tail_drop_notify+0x27c>
     2ac:      	nop

00000000000002b0 <tail_icmp6_send_time_exceeded>:
     2b0:      	sub	sp, sp, #0x100
     2b4:      	str	x30, [sp, #0xc0]
     2b8:      	stp	x24, x23, [sp, #0xd0]
     2bc:      	stp	x22, x21, [sp, #0xe0]
     2c0:      	stp	x20, x19, [sp, #0xf0]
     2c4:      	mov	w8, #0x3a               // =58
     2c8:      	ldp	w20, w22, [x0, #0x30]
     2cc:      	str	wzr, [x0, #0x30]
     2d0:      	adrp	x23, 0x0 <tail_drop_notify>
     2d4:      	adrp	x1, 0x0 <tail_drop_notify>
     2d8:      	add	x3, sp, #0xa8
     2dc:      	mov	w2, #-0x1               // =-1
     2e0:      	stp	xzr, xzr, [sp, #0x60]
     2e4:      	mov	w4, #0x14               // =20
     2e8:      	mov	x19, x0
     2ec:      	stp	xzr, xzr, [sp, #0x50]
     2f0:      	add	x21, sp, #0x20
     2f4:      	str	xzr, [sp, #0x28]
     2f8:      	strh	wzr, [sp, #0x1c]
     2fc:      	strb	w8, [sp, #0x18]
     300:      	adrp	x8, 0x0 <tail_drop_notify>
     304:      	stp	xzr, xzr, [sp, #0x40]
     308:      	stp	xzr, xzr, [sp, #0x30]
     30c:      	ldr	x8, [x8]
     310:      	ldr	x9, [x8]
     314:      	str	x9, [sp, #0x10]
     318:      	ldr	x8, [x8, #0x8]
     31c:      	str	x8, [sp, #0x8]
     320:      	mov	w8, #0x3                // =3
     324:      	str	x8, [sp, #0x20]
     328:      	mov	w8, #0xe02              // =3586
     32c:      	strh	w8, [sp, #0xa8]
     330:      	ldr	x23, [x23]
     334:      	ldrh	w8, [x23]
     338:      	str	xzr, [sp, #0xb0]
     33c:      	str	wzr, [sp, #0xb8]
     340:      	strh	w8, [sp, #0xaa]
     344:      	ldr	w8, [x0, #0x98]
     348:      	str	w8, [sp, #0xac]
     34c:      	mov	w8, #0x19               // =25
     350:      	ldr	x1, [x1]
     354:      	blr	x8
     358:      	mov	w8, #0x1a               // =26
     35c:      	add	x2, x21, #0x8
     360:      	mov	x0, x19
     364:      	mov	w1, w20
     368:      	mov	w3, #0x28               // =40
     36c:      	blr	x8
     370:      	tbnz	w0, #0x1f, 0x7fc <tail_icmp6_send_time_exceeded+0x54c>
     374:      	mov	w8, #0x9                // =9
     378:      	add	w1, w20, #0x6
     37c:      	add	x2, sp, #0x18
     380:      	mov	x0, x19
     384:      	mov	w3, #0x1                // =1
     388:      	mov	w4, wzr
     38c:      	blr	x8
     390:      	tbnz	w0, #0x1f, 0x804 <tail_icmp6_send_time_exceeded+0x554>
     394:      	ldrb	w8, [sp, #0x2e]
     398:      	cmp	w8, #0x6
     39c:      	b.eq	0x4c8 <tail_icmp6_send_time_exceeded+0x218>
     3a0:      	cmp	w8, #0x3a
     3a4:      	b.eq	0x3b0 <tail_icmp6_send_time_exceeded+0x100>
     3a8:      	cmp	w8, #0x11
     3ac:      	b.ne	0x80c <tail_icmp6_send_time_exceeded+0x55c>
     3b0:      	mov	w8, #0x1a               // =26
     3b4:      	add	w1, w20, #0x28
     3b8:      	add	x2, x21, #0x30
     3bc:      	mov	x0, x19
     3c0:      	mov	w3, #0x8                // =8
     3c4:      	blr	x8
     3c8:      	tbnz	w0, #0x1f, 0x7fc <tail_icmp6_send_time_exceeded+0x54c>
     3cc:      	mov	w8, #0x1c               // =28
     3d0:      	add	x2, sp, #0x20
     3d4:      	mov	x0, xzr
     3d8:      	mov	w1, wzr
     3dc:      	mov	w3, #0x38               // =56
     3e0:      	mov	w4, wzr
     3e4:      	mov	w21, #0x1c              // =28
     3e8:      	add	x24, sp, #0x20
     3ec:      	blr	x8
     3f0:      	mov	w8, #0x38000000         // =939524096
     3f4:      	mov	w4, w0
     3f8:      	add	x2, x24, #0x10
     3fc:      	str	w8, [sp, #0xa8]
     400:      	mov	w8, #0x3a000000         // =973078528
     404:      	mov	x0, xzr
     408:      	mov	w1, wzr
     40c:      	str	w8, [sp, #0x98]
     410:      	mov	w8, #0x1c               // =28
     414:      	mov	w3, #0x10               // =16
     418:      	blr	x8
     41c:      	mov	w8, #0x1c               // =28
     420:      	mov	w4, w0
     424:      	add	x2, x24, #0x20
     428:      	mov	x0, xzr
     42c:      	mov	w1, wzr
     430:      	mov	w3, #0x10               // =16
     434:      	blr	x8
     438:      	mov	w8, #0x1c               // =28
     43c:      	mov	w4, w0
     440:      	add	x2, sp, #0xa8
     444:      	mov	x0, xzr
     448:      	mov	w1, wzr
     44c:      	mov	w3, #0x4                // =4
     450:      	blr	x8
     454:      	mov	w4, w0
     458:      	add	x2, sp, #0x98
     45c:      	mov	x0, xzr
     460:      	mov	w1, wzr
     464:      	mov	w3, #0x4                // =4
     468:      	blr	x21
     46c:      	mov	w8, #0x3800             // =14336
     470:      	mov	w9, #0x26               // =38
     474:      	mov	w21, w0
     478:      	strh	w8, [sp, #0x1c]
     47c:      	ldrh	w8, [sp, #0x2c]
     480:      	mov	x0, x19
     484:      	mov	w2, wzr
     488:      	ldr	w10, [x19, #0x70]
     48c:      	rev	w8, w8
     490:      	sub	w8, w10, w8, lsr #16
     494:      	add	w1, w8, #0x38
     498:      	blr	x9
     49c:      	tbnz	w0, #0x1f, 0x804 <tail_icmp6_send_time_exceeded+0x554>
     4a0:      	mov	w8, #0x9                // =9
     4a4:      	add	w1, w20, #0x28
     4a8:      	add	x2, sp, #0x20
     4ac:      	mov	x0, x19
     4b0:      	mov	w3, #0x38               // =56
     4b4:      	mov	w4, wzr
     4b8:      	blr	x8
     4bc:      	tbnz	w0, #0x1f, 0x804 <tail_icmp6_send_time_exceeded+0x554>
     4c0:      	mov	w8, #0x9                // =9
     4c4:      	b	0x5dc <tail_icmp6_send_time_exceeded+0x32c>
     4c8:      	mov	w8, #0x1a               // =26
     4cc:      	add	w1, w20, #0x28
     4d0:      	add	x2, x21, #0x30
     4d4:      	mov	x0, x19
     4d8:      	mov	w3, #0x14               // =20
     4dc:      	blr	x8
     4e0:      	tbnz	w0, #0x1f, 0x7fc <tail_icmp6_send_time_exceeded+0x54c>
     4e4:      	mov	w8, #0x1c               // =28
     4e8:      	add	x2, sp, #0x20
     4ec:      	mov	x0, xzr
     4f0:      	mov	w1, wzr
     4f4:      	mov	w3, #0x44               // =68
     4f8:      	mov	w4, wzr
     4fc:      	mov	w21, #0x1c              // =28
     500:      	add	x24, sp, #0x20
     504:      	blr	x8
     508:      	mov	w8, #0x44000000         // =1140850688
     50c:      	mov	w4, w0
     510:      	add	x2, x24, #0x10
     514:      	str	w8, [sp, #0xa8]
     518:      	mov	w8, #0x3a000000         // =973078528
     51c:      	mov	x0, xzr
     520:      	mov	w1, wzr
     524:      	str	w8, [sp, #0x98]
     528:      	mov	w8, #0x1c               // =28
     52c:      	mov	w3, #0x10               // =16
     530:      	blr	x8
     534:      	mov	w8, #0x1c               // =28
     538:      	mov	w4, w0
     53c:      	add	x2, x24, #0x20
     540:      	mov	x0, xzr
     544:      	mov	w1, wzr
     548:      	mov	w3, #0x10               // =16
     54c:      	blr	x8
     550:      	mov	w8, #0x1c               // =28
     554:      	mov	w4, w0
     558:      	add	x2, sp, #0xa8
     55c:      	mov	x0, xzr
     560:      	mov	w1, wzr
     564:      	mov	w3, #0x4                // =4
     568:      	blr	x8
     56c:      	mov	w4, w0
     570:      	add	x2, sp, #0x98
     574:      	mov	x0, xzr
     578:      	mov	w1, wzr
     57c:      	mov	w3, #0x4                // =4
     580:      	blr	x21
     584:      	mov	w8, #0x4400             // =17408
     588:      	mov	w9, #0x26               // =38
     58c:      	mov	w21, w0
     590:      	strh	w8, [sp, #0x1c]
     594:      	ldrh	w8, [sp, #0x2c]
     598:      	mov	x0, x19
     59c:      	mov	w2, wzr
     5a0:      	ldr	w10, [x19, #0x70]
     5a4:      	rev	w8, w8
     5a8:      	sub	w8, w10, w8, lsr #16
     5ac:      	add	w1, w8, #0x44
     5b0:      	blr	x9
     5b4:      	tbnz	w0, #0x1f, 0x804 <tail_icmp6_send_time_exceeded+0x554>
     5b8:      	mov	w8, #0x9                // =9
     5bc:      	add	w1, w20, #0x28
     5c0:      	add	x2, sp, #0x20
     5c4:      	mov	x0, x19
     5c8:      	mov	w3, #0x44               // =68
     5cc:      	mov	w4, wzr
     5d0:      	blr	x8
     5d4:      	tbnz	w0, #0x1f, 0x804 <tail_icmp6_send_time_exceeded+0x554>
     5d8:      	mov	w8, #0x9                // =9
     5dc:      	add	w1, w20, #0x4
     5e0:      	add	x2, sp, #0x1c
     5e4:      	mov	x0, x19
     5e8:      	mov	w3, #0x2                // =2
     5ec:      	mov	w4, wzr
     5f0:      	blr	x8
     5f4:      	tbnz	w0, #0x1f, 0x804 <tail_icmp6_send_time_exceeded+0x554>
     5f8:      	mov	w8, #0xb                // =11
     5fc:      	add	w1, w20, #0x2a
     600:      	mov	x0, x19
     604:      	mov	w2, wzr
     608:      	mov	w3, w21
     60c:      	mov	w4, #0x10               // =16
     610:      	blr	x8
     614:      	tbnz	w0, #0x1f, 0x8d0 <tail_icmp6_send_time_exceeded+0x620>
     618:      	ldp	x9, x8, [sp, #0x8]
     61c:      	add	w1, w20, #0x8
     620:      	add	x2, sp, #0x80
     624:      	mov	x0, x19
     628:      	mov	w3, #0x10               // =16
     62c:      	stp	x8, x9, [sp, #0x98]
     630:      	adrp	x8, 0x0 <tail_drop_notify>
     634:      	ldr	x8, [x8]
     638:      	ldr	x8, [x8]
     63c:      	str	x8, [sp, #0x90]
     640:      	mov	w8, #0x1a               // =26
     644:      	blr	x8
     648:      	tbnz	w0, #0x1f, 0x7fc <tail_icmp6_send_time_exceeded+0x54c>
     64c:      	mov	w8, #0x1a               // =26
     650:      	add	w1, w20, #0x18
     654:      	add	x2, sp, #0x70
     658:      	mov	x0, x19
     65c:      	mov	w3, #0x10               // =16
     660:      	blr	x8
     664:      	tbnz	w0, #0x1f, 0x7fc <tail_icmp6_send_time_exceeded+0x54c>
     668:      	mov	w8, #0x9                // =9
     66c:      	add	w1, w20, #0x8
     670:      	add	x2, sp, #0x98
     674:      	mov	x0, x19
     678:      	mov	w3, #0x10               // =16
     67c:      	mov	w4, wzr
     680:      	blr	x8
     684:      	tbnz	w0, #0x1f, 0x804 <tail_icmp6_send_time_exceeded+0x554>
     688:      	mov	w8, #0x9                // =9
     68c:      	add	w1, w20, #0x18
     690:      	add	x2, sp, #0x80
     694:      	mov	x0, x19
     698:      	mov	w3, #0x10               // =16
     69c:      	mov	w4, wzr
     6a0:      	blr	x8
     6a4:      	tbnz	w0, #0x1f, 0x804 <tail_icmp6_send_time_exceeded+0x554>
     6a8:      	mov	w8, #0x1c               // =28
     6ac:      	add	x0, sp, #0x80
     6b0:      	add	x2, sp, #0x98
     6b4:      	mov	w1, #0x10               // =16
     6b8:      	mov	w3, #0x10               // =16
     6bc:      	mov	w4, wzr
     6c0:      	blr	x8
     6c4:      	mov	w3, w0
     6c8:      	mov	w8, #0xb                // =11
     6cc:      	add	w1, w20, #0x2a
     6d0:      	mov	x0, x19
     6d4:      	mov	w2, wzr
     6d8:      	mov	w4, #0x10               // =16
     6dc:      	blr	x8
     6e0:      	tbnz	w0, #0x1f, 0x8d0 <tail_icmp6_send_time_exceeded+0x620>
     6e4:      	mov	w8, #0x1c               // =28
     6e8:      	add	x0, sp, #0x70
     6ec:      	add	x2, sp, #0x80
     6f0:      	mov	w1, #0x10               // =16
     6f4:      	mov	w3, #0x10               // =16
     6f8:      	mov	w4, wzr
     6fc:      	blr	x8
     700:      	mov	w3, w0
     704:      	mov	w8, #0xb                // =11
     708:      	add	w1, w20, #0x2a
     70c:      	mov	x0, x19
     710:      	mov	w2, wzr
     714:      	mov	w4, #0x10               // =16
     718:      	blr	x8
     71c:      	tbnz	w0, #0x1f, 0x8d0 <tail_icmp6_send_time_exceeded+0x620>
     720:      	mov	w8, #0x1a               // =26
     724:      	add	x2, sp, #0xc8
     728:      	mov	x0, x19
     72c:      	mov	w1, #0x6                // =6
     730:      	mov	w3, #0x6                // =6
     734:      	blr	x8
     738:      	tbnz	w0, #0x1f, 0x7fc <tail_icmp6_send_time_exceeded+0x54c>
     73c:      	mov	w8, #0x9                // =9
     740:      	add	x2, sp, #0xc8
     744:      	mov	x0, x19
     748:      	mov	w1, wzr
     74c:      	mov	w3, #0x6                // =6
     750:      	mov	w4, wzr
     754:      	blr	x8
     758:      	tbnz	w0, #0x1f, 0x804 <tail_icmp6_send_time_exceeded+0x554>
     75c:      	mov	w8, #0x9                // =9
     760:      	add	x2, sp, #0x90
     764:      	mov	x0, x19
     768:      	mov	w1, #0x6                // =6
     76c:      	mov	w3, #0x6                // =6
     770:      	mov	w4, wzr
     774:      	blr	x8
     778:      	tbnz	w0, #0x1f, 0x804 <tail_icmp6_send_time_exceeded+0x554>
     77c:      	ldr	x8, [x19, #0x10]
     780:      	cbz	x8, 0x788 <tail_icmp6_send_time_exceeded+0x4d8>
     784:      	ldr	w8, [x8, #0xe0]
     788:      	adrp	x10, 0x0 <tail_drop_notify>
     78c:      	ldr	w9, [x19, #0x70]
     790:      	mov	w11, #0x403             // =1027
     794:      	adrp	x1, 0x0 <tail_drop_notify>
     798:      	ldr	x10, [x10]
     79c:      	add	x3, sp, #0xa8
     7a0:      	mov	x0, x19
     7a4:      	mov	w4, #0x18               // =24
     7a8:      	ldr	w10, [x10]
     7ac:      	strh	w11, [sp, #0xa8]
     7b0:      	ldrh	w11, [x23]
     7b4:      	stp	w8, wzr, [sp, #0xb8]
     7b8:      	mov	w8, #0x19               // =25
     7bc:      	cmp	w9, w10
     7c0:      	strh	w11, [sp, #0xaa]
     7c4:      	ldr	w11, [x19, #0x98]
     7c8:      	csel	w10, w9, w10, lo
     7cc:      	strh	w10, [sp, #0xb4]
     7d0:      	stp	w11, w9, [sp, #0xac]
     7d4:      	mov	w9, #0x1                // =1
     7d8:      	strh	w9, [sp, #0xb6]
     7dc:      	mov	w9, #-0x1               // =-1
     7e0:      	orr	x2, x9, x10, lsl #32
     7e4:      	ldr	x1, [x1]
     7e8:      	blr	x8
     7ec:      	ldr	x8, [x19, #0x10]
     7f0:      	cbz	x8, 0x8d8 <tail_icmp6_send_time_exceeded+0x628>
     7f4:      	ldr	w0, [x8, #0xe0]
     7f8:      	b	0x8dc <tail_icmp6_send_time_exceeded+0x62c>
     7fc:      	mov	w0, #-0x86              // =-134
     800:      	b	0x810 <tail_icmp6_send_time_exceeded+0x560>
     804:      	mov	w0, #-0x8d              // =-141
     808:      	b	0x810 <tail_icmp6_send_time_exceeded+0x560>
     80c:      	mov	w0, #-0x8e              // =-142
     810:      	cmp	w0, #0x0
     814:      	str	xzr, [x19, #0x30]
     818:      	ldr	w20, [x19, #0x70]
     81c:      	add	x1, sp, #0xa8
     820:      	cneg	w8, w0, mi
     824:      	adrp	x0, 0x0 <tail_drop_notify>
     828:      	and	w9, w8, #0xff
     82c:      	str	w9, [x19, #0x38]
     830:      	mov	x9, #0x670200000000     // =113258287595520
     834:      	movk	x9, #0x142, lsl #48
     838:      	stur	x9, [x19, #0x3c]
     83c:      	mov	x9, #0x1420000          // =21102592
     840:      	movk	x9, #0x67, lsl #32
     844:      	str	x9, [sp, #0xa8]
     848:      	strb	w8, [sp, #0xa8]
     84c:      	and	w8, w22, #0x3
     850:      	strb	w8, [sp, #0xa9]
     854:      	mov	w8, #0x1                // =1
     858:      	ldr	x0, [x0]
     85c:      	blr	x8
     860:      	cbz	x0, 0x878 <tail_icmp6_send_time_exceeded+0x5c8>
     864:      	ldp	x8, x9, [x0]
     868:      	add	x8, x8, #0x1
     86c:      	add	x9, x9, x20
     870:      	stp	x8, x9, [x0]
     874:      	b	0x89c <tail_icmp6_send_time_exceeded+0x5ec>
     878:      	mov	w8, #0x1                // =1
     87c:      	adrp	x0, 0x0 <tail_drop_notify>
     880:      	add	x1, sp, #0xa8
     884:      	stp	x8, x20, [sp, #0x20]
     888:      	mov	w8, #0x2                // =2
     88c:      	add	x2, sp, #0x20
     890:      	mov	w3, wzr
     894:      	ldr	x0, [x0]
     898:      	blr	x8
     89c:      	mov	w8, #0xc                // =12
     8a0:      	adrp	x1, 0x0 <tail_drop_notify>
     8a4:      	mov	x0, x19
     8a8:      	ldr	x1, [x1]
     8ac:      	mov	w2, #0x1                // =1
     8b0:      	blr	x8
     8b4:      	mov	w0, #0x2                // =2
     8b8:      	ldp	x20, x19, [sp, #0xf0]
     8bc:      	ldr	x30, [sp, #0xc0]
     8c0:      	ldp	x22, x21, [sp, #0xe0]
     8c4:      	ldp	x24, x23, [sp, #0xd0]
     8c8:      	add	sp, sp, #0x100
     8cc:      	ret
     8d0:      	mov	w0, #-0x9a              // =-154
     8d4:      	b	0x810 <tail_icmp6_send_time_exceeded+0x560>
     8d8:      	mov	w0, wzr
     8dc:      	mov	w8, #0x17               // =23
     8e0:      	mov	w1, wzr
     8e4:      	blr	x8
     8e8:      	tbnz	w0, #0x1f, 0x810 <tail_icmp6_send_time_exceeded+0x560>
     8ec:      	cmp	w0, #0x2
     8f0:      	b.ne	0x8b8 <tail_icmp6_send_time_exceeded+0x608>
     8f4:      	b	0x810 <tail_icmp6_send_time_exceeded+0x560>
     8f8:      	nop
     8fc:      	nop

0000000000000900 <tail_icmp6_handle_ns>:
     900:      	sub	sp, sp, #0x120
     904:      	str	x29, [sp, #0xd0]
     908:      	stp	x30, x25, [sp, #0xe0]
     90c:      	stp	x24, x23, [sp, #0xf0]
     910:      	stp	x22, x21, [sp, #0x100]
     914:      	stp	x20, x19, [sp, #0x110]
     918:      	ldp	w24, w22, [x0, #0x30]
     91c:      	str	wzr, [x0, #0x30]
     920:      	adrp	x8, 0x0 <tail_drop_notify>
     924:      	adrp	x25, 0x0 <tail_drop_notify>
     928:      	add	x2, sp, #0x38
     92c:      	mov	w3, #0x10               // =16
     930:      	ldr	x8, [x8]
     934:      	mov	x19, x0
     938:      	add	x21, sp, #0x98
     93c:      	ldr	x9, [x8]
     940:      	add	w1, w24, #0x30
     944:      	str	x9, [sp, #0x30]
     948:      	ldr	x8, [x8, #0x8]
     94c:      	str	x8, [sp, #0x28]
     950:      	ldr	x25, [x25]
     954:      	ldrb	w8, [x25]
     958:      	strb	w8, [sp, #0x20]
     95c:      	ldrb	w8, [x25, #0x1]
     960:      	strb	w8, [sp, #0x1c]
     964:      	ldrb	w8, [x25, #0x2]
     968:      	strb	w8, [sp, #0x18]
     96c:      	ldrb	w8, [x25, #0x3]
     970:      	strb	w8, [sp, #0x14]
     974:      	ldrb	w8, [x25, #0x4]
     978:      	strb	w8, [sp, #0x10]
     97c:      	ldrb	w8, [x25, #0x5]
     980:      	strb	w8, [sp, #0xc]
     984:      	ldrh	w8, [x25, #0x6]
     988:      	strh	w8, [sp, #0xa]
     98c:      	mov	w8, #0x1a               // =26
     990:      	blr	x8
     994:      	tbnz	w0, #0x1f, 0x10a0 <tail_icmp6_handle_ns+0x7a0>
     998:      	mov	w10, #0xd02             // =3330
     99c:      	adrp	x23, 0x0 <tail_drop_notify>
     9a0:      	ldp	w8, w9, [sp, #0x40]
     9a4:      	adrp	x1, 0x0 <tail_drop_notify>
     9a8:      	strh	w10, [sp, #0xb8]
     9ac:      	add	x3, sp, #0xb8
     9b0:      	mov	x0, x19
     9b4:      	mov	w2, #-0x1               // =-1
     9b8:      	ldr	x23, [x23]
     9bc:      	mov	w4, #0x14               // =20
     9c0:      	ldrh	w10, [x23]
     9c4:      	stp	w9, wzr, [x21, #0x2c]
     9c8:      	strh	w10, [sp, #0xba]
     9cc:      	ldr	w10, [x19, #0x98]
     9d0:      	stp	w10, w8, [x21, #0x24]
     9d4:      	mov	w8, #0x19               // =25
     9d8:      	ldr	x1, [x1]
     9dc:      	blr	x8
     9e0:      	ldp	x9, x8, [sp, #0x30]
     9e4:      	cmp	x8, x9
     9e8:      	b.ne	0xd34 <tail_icmp6_handle_ns+0x434>
     9ec:      	ldr	x8, [sp, #0x40]
     9f0:      	ldr	x9, [sp, #0x28]
     9f4:      	cmp	x8, x9
     9f8:      	b.ne	0xd34 <tail_icmp6_handle_ns+0x434>
     9fc:      	mov	x8, #0x88               // =136
     a00:      	add	w1, w24, #0x40
     a04:      	add	x2, sp, #0x58
     a08:      	mov	x0, x19
     a0c:      	mov	w3, #0x8                // =8
     a10:      	movk	x8, #0xc0, lsl #32
     a14:      	str	x8, [sp, #0x70]
     a18:      	mov	w8, #0x1a               // =26
     a1c:      	blr	x8
     a20:      	tbnz	w0, #0x1f, 0x1160 <tail_icmp6_handle_ns+0x860>
     a24:      	mov	w20, wzr
     a28:      	mov	w8, #0x1a               // =26
     a2c:      	add	w1, w24, #0x28
     a30:      	add	x2, sp, #0x68
     a34:      	mov	x0, x19
     a38:      	mov	w3, #0x8                // =8
     a3c:      	blr	x8
     a40:      	tbnz	w0, #0x1f, 0x123c <tail_icmp6_handle_ns+0x93c>
     a44:      	ldrh	w8, [sp, #0x6a]
     a48:      	add	w1, w24, #0x30
     a4c:      	add	x2, sp, #0x48
     a50:      	mov	x0, x19
     a54:      	strh	w8, [sp, #0x72]
     a58:      	mov	w8, #0x1a               // =26
     a5c:      	mov	w3, #0x10               // =16
     a60:      	blr	x8
     a64:      	tbnz	w0, #0x1f, 0x1158 <tail_icmp6_handle_ns+0x858>
     a68:      	mov	w8, #0x9                // =9
     a6c:      	add	w1, w24, #0x28
     a70:      	add	x2, sp, #0x70
     a74:      	mov	x0, x19
     a78:      	mov	w3, #0x8                // =8
     a7c:      	mov	w4, wzr
     a80:      	blr	x8
     a84:      	tbnz	w0, #0x1f, 0x1158 <tail_icmp6_handle_ns+0x858>
     a88:      	mov	w8, #0x1c               // =28
     a8c:      	add	x0, sp, #0x68
     a90:      	add	x2, sp, #0x70
     a94:      	mov	w1, #0x8                // =8
     a98:      	mov	w3, #0x8                // =8
     a9c:      	mov	w4, w20
     aa0:      	blr	x8
     aa4:      	mov	w8, #0x1a               // =26
     aa8:      	mov	w20, w0
     aac:      	add	w1, w24, #0x40
     ab0:      	add	x2, sp, #0x58
     ab4:      	mov	x0, x19
     ab8:      	mov	w3, #0x8                // =8
     abc:      	blr	x8
     ac0:      	tbnz	w0, #0x1f, 0x123c <tail_icmp6_handle_ns+0x93c>
     ac4:      	mov	w8, #0x102              // =258
     ac8:      	add	w1, w24, #0x40
     acc:      	add	x2, sp, #0x60
     ad0:      	strh	w8, [sp, #0x60]
     ad4:      	ldrb	w8, [sp, #0x20]
     ad8:      	mov	x0, x19
     adc:      	mov	w3, #0x8                // =8
     ae0:      	mov	w4, wzr
     ae4:      	strb	w8, [sp, #0x62]
     ae8:      	ldrb	w8, [sp, #0x1c]
     aec:      	strb	w8, [sp, #0x63]
     af0:      	ldrb	w8, [sp, #0x18]
     af4:      	strb	w8, [sp, #0x64]
     af8:      	ldrb	w8, [sp, #0x14]
     afc:      	strb	w8, [sp, #0x65]
     b00:      	ldrb	w8, [sp, #0x10]
     b04:      	strb	w8, [sp, #0x66]
     b08:      	ldrb	w8, [sp, #0xc]
     b0c:      	strb	w8, [sp, #0x67]
     b10:      	mov	w8, #0x9                // =9
     b14:      	blr	x8
     b18:      	tbnz	w0, #0x1f, 0x1158 <tail_icmp6_handle_ns+0x858>
     b1c:      	mov	w8, #0x1c               // =28
     b20:      	add	x0, sp, #0x58
     b24:      	add	x2, sp, #0x60
     b28:      	mov	w1, #0x8                // =8
     b2c:      	mov	w3, #0x8                // =8
     b30:      	mov	w4, w20
     b34:      	blr	x8
     b38:      	mov	w3, w0
     b3c:      	mov	w8, #0xb                // =11
     b40:      	add	w1, w24, #0x2a
     b44:      	mov	x0, x19
     b48:      	mov	w2, wzr
     b4c:      	mov	w4, #0x10               // =16
     b50:      	blr	x8
     b54:      	tbnz	w0, #0x1f, 0x1274 <tail_icmp6_handle_ns+0x974>
     b58:      	ldp	x8, x9, [sp, #0x48]
     b5c:      	add	w1, w24, #0x8
     b60:      	add	x2, sp, #0x88
     b64:      	mov	x0, x19
     b68:      	mov	w3, #0x10               // =16
     b6c:      	stp	x8, x9, [x21, #0x10]
     b70:      	ldr	x8, [x25]
     b74:      	str	x8, [x21]
     b78:      	mov	w8, #0x1a               // =26
     b7c:      	blr	x8
     b80:      	tbnz	w0, #0x1f, 0x123c <tail_icmp6_handle_ns+0x93c>
     b84:      	mov	w8, #0x1a               // =26
     b88:      	add	w1, w24, #0x18
     b8c:      	add	x2, sp, #0x78
     b90:      	mov	x0, x19
     b94:      	mov	w3, #0x10               // =16
     b98:      	blr	x8
     b9c:      	tbnz	w0, #0x1f, 0x123c <tail_icmp6_handle_ns+0x93c>
     ba0:      	mov	w8, #0x9                // =9
     ba4:      	add	w1, w24, #0x8
     ba8:      	add	x2, sp, #0xa8
     bac:      	mov	x0, x19
     bb0:      	mov	w3, #0x10               // =16
     bb4:      	mov	w4, wzr
     bb8:      	blr	x8
     bbc:      	tbnz	w0, #0x1f, 0x1158 <tail_icmp6_handle_ns+0x858>
     bc0:      	mov	w8, #0x9                // =9
     bc4:      	add	w1, w24, #0x18
     bc8:      	add	x2, sp, #0x88
     bcc:      	mov	x0, x19
     bd0:      	mov	w3, #0x10               // =16
     bd4:      	mov	w4, wzr
     bd8:      	blr	x8
     bdc:      	tbnz	w0, #0x1f, 0x1158 <tail_icmp6_handle_ns+0x858>
     be0:      	mov	w8, #0x1c               // =28
     be4:      	add	x0, sp, #0x88
     be8:      	add	x2, sp, #0xa8
     bec:      	mov	w1, #0x10               // =16
     bf0:      	mov	w3, #0x10               // =16
     bf4:      	mov	w4, wzr
     bf8:      	blr	x8
     bfc:      	mov	w3, w0
     c00:      	mov	w8, #0xb                // =11
     c04:      	add	w1, w24, #0x2a
     c08:      	mov	x0, x19
     c0c:      	mov	w2, wzr
     c10:      	mov	w4, #0x10               // =16
     c14:      	blr	x8
     c18:      	tbnz	w0, #0x1f, 0x1274 <tail_icmp6_handle_ns+0x974>
     c1c:      	mov	w8, #0x1c               // =28
     c20:      	add	x0, sp, #0x78
     c24:      	add	x2, sp, #0x88
     c28:      	mov	w1, #0x10               // =16
     c2c:      	mov	w3, #0x10               // =16
     c30:      	mov	w4, wzr
     c34:      	blr	x8
     c38:      	mov	w3, w0
     c3c:      	mov	w8, #0xb                // =11
     c40:      	add	w1, w24, #0x2a
     c44:      	mov	x0, x19
     c48:      	mov	w2, wzr
     c4c:      	mov	w4, #0x10               // =16
     c50:      	blr	x8
     c54:      	tbnz	w0, #0x1f, 0x1274 <tail_icmp6_handle_ns+0x974>
     c58:      	mov	w8, #0x1a               // =26
     c5c:      	add	x2, sp, #0xa0
     c60:      	mov	x0, x19
     c64:      	mov	w1, #0x6                // =6
     c68:      	mov	w3, #0x6                // =6
     c6c:      	blr	x8
     c70:      	tbnz	w0, #0x1f, 0x123c <tail_icmp6_handle_ns+0x93c>
     c74:      	mov	w8, #0x9                // =9
     c78:      	add	x2, sp, #0xa0
     c7c:      	mov	x0, x19
     c80:      	mov	w1, wzr
     c84:      	mov	w3, #0x6                // =6
     c88:      	mov	w4, wzr
     c8c:      	blr	x8
     c90:      	tbnz	w0, #0x1f, 0x1158 <tail_icmp6_handle_ns+0x858>
     c94:      	mov	w8, #0x9                // =9
     c98:      	add	x2, sp, #0x98
     c9c:      	mov	x0, x19
     ca0:      	mov	w1, #0x6                // =6
     ca4:      	mov	w3, #0x6                // =6
     ca8:      	mov	w4, wzr
     cac:      	blr	x8
     cb0:      	tbnz	w0, #0x1f, 0x1158 <tail_icmp6_handle_ns+0x858>
     cb4:      	ldr	x8, [x19, #0x10]
     cb8:      	cbz	x8, 0xcc0 <tail_icmp6_handle_ns+0x3c0>
     cbc:      	ldr	w8, [x8, #0xe0]
     cc0:      	adrp	x10, 0x0 <tail_drop_notify>
     cc4:      	ldr	w9, [x19, #0x70]
     cc8:      	mov	w11, #0x403             // =1027
     ccc:      	adrp	x1, 0x0 <tail_drop_notify>
     cd0:      	ldr	x10, [x10]
     cd4:      	add	x3, sp, #0xb8
     cd8:      	mov	x0, x19
     cdc:      	mov	w4, #0x18               // =24
     ce0:      	ldr	w10, [x10]
     ce4:      	strh	w11, [sp, #0xb8]
     ce8:      	ldrh	w11, [x23]
     cec:      	stp	w8, wzr, [x21, #0x30]
     cf0:      	mov	w8, #0x19               // =25
     cf4:      	cmp	w9, w10
     cf8:      	strh	w11, [sp, #0xba]
     cfc:      	ldr	w11, [x19, #0x98]
     d00:      	csel	w10, w9, w10, lo
     d04:      	strh	w10, [sp, #0xc4]
     d08:      	stp	w11, w9, [x21, #0x24]
     d0c:      	mov	w9, #0x1                // =1
     d10:      	strh	w9, [sp, #0xc6]
     d14:      	mov	w9, #-0x1               // =-1
     d18:      	orr	x2, x9, x10, lsl #32
     d1c:      	ldr	x1, [x1]
     d20:      	blr	x8
     d24:      	ldr	x8, [x19, #0x10]
     d28:      	cbz	x8, 0x127c <tail_icmp6_handle_ns+0x97c>
     d2c:      	ldr	w0, [x8, #0xe0]
     d30:      	b	0x1280 <tail_icmp6_handle_ns+0x980>
     d34:      	ldp	x8, x9, [sp, #0x38]
     d38:      	adrp	x0, 0x0 <tail_drop_notify>
     d3c:      	add	x1, sp, #0xb8
     d40:      	str	wzr, [x21, #0x30]
     d44:      	stp	x8, x9, [x21, #0x20]
     d48:      	mov	w8, #0x2                // =2
     d4c:      	strb	w8, [sp, #0xc8]
     d50:      	mov	w8, #0x1                // =1
     d54:      	ldr	x0, [x0]
     d58:      	blr	x8
     d5c:      	cbz	x0, 0x1240 <tail_icmp6_handle_ns+0x940>
     d60:      	ldrb	w8, [x0, #0x8]
     d64:      	tbnz	w8, #0x0, 0x110c <tail_icmp6_handle_ns+0x80c>
     d68:      	mov	x8, #0x88               // =136
     d6c:      	add	w1, w24, #0x40
     d70:      	add	x2, sp, #0x58
     d74:      	mov	x0, x19
     d78:      	mov	w3, #0x8                // =8
     d7c:      	movk	x8, #0x60, lsl #32
     d80:      	str	x8, [sp, #0x70]
     d84:      	mov	w8, #0x1a               // =26
     d88:      	blr	x8
     d8c:      	tbnz	w0, #0x1f, 0x11d4 <tail_icmp6_handle_ns+0x8d4>
     d90:      	mov	w20, wzr
     d94:      	mov	w8, #0x1a               // =26
     d98:      	add	w1, w24, #0x28
     d9c:      	add	x2, sp, #0x68
     da0:      	mov	x0, x19
     da4:      	mov	w3, #0x8                // =8
     da8:      	blr	x8
     dac:      	tbnz	w0, #0x1f, 0x123c <tail_icmp6_handle_ns+0x93c>
     db0:      	ldrh	w8, [sp, #0x6a]
     db4:      	add	w1, w24, #0x30
     db8:      	add	x2, sp, #0x48
     dbc:      	mov	x0, x19
     dc0:      	strh	w8, [sp, #0x72]
     dc4:      	mov	w8, #0x1a               // =26
     dc8:      	mov	w3, #0x10               // =16
     dcc:      	blr	x8
     dd0:      	tbnz	w0, #0x1f, 0x1158 <tail_icmp6_handle_ns+0x858>
     dd4:      	mov	w8, #0x9                // =9
     dd8:      	add	w1, w24, #0x28
     ddc:      	add	x2, sp, #0x70
     de0:      	mov	x0, x19
     de4:      	mov	w3, #0x8                // =8
     de8:      	mov	w4, wzr
     dec:      	blr	x8
     df0:      	tbnz	w0, #0x1f, 0x1158 <tail_icmp6_handle_ns+0x858>
     df4:      	mov	w8, #0x1c               // =28
     df8:      	add	x0, sp, #0x68
     dfc:      	add	x2, sp, #0x70
     e00:      	mov	w1, #0x8                // =8
     e04:      	mov	w3, #0x8                // =8
     e08:      	mov	w4, w20
     e0c:      	blr	x8
     e10:      	mov	w8, #0x1a               // =26
     e14:      	mov	w20, w0
     e18:      	add	w1, w24, #0x40
     e1c:      	add	x2, sp, #0x58
     e20:      	mov	x0, x19
     e24:      	mov	w3, #0x8                // =8
     e28:      	blr	x8
     e2c:      	tbnz	w0, #0x1f, 0x123c <tail_icmp6_handle_ns+0x93c>
     e30:      	mov	w8, #0x102              // =258
     e34:      	add	w1, w24, #0x40
     e38:      	add	x2, sp, #0x60
     e3c:      	strh	w8, [sp, #0x60]
     e40:      	ldrb	w8, [sp, #0x20]
     e44:      	mov	x0, x19
     e48:      	mov	w3, #0x8                // =8
     e4c:      	mov	w4, wzr
     e50:      	strb	w8, [sp, #0x62]
     e54:      	ldrb	w8, [sp, #0x1c]
     e58:      	strb	w8, [sp, #0x63]
     e5c:      	ldrb	w8, [sp, #0x18]
     e60:      	strb	w8, [sp, #0x64]
     e64:      	ldrb	w8, [sp, #0x14]
     e68:      	strb	w8, [sp, #0x65]
     e6c:      	ldrb	w8, [sp, #0x10]
     e70:      	strb	w8, [sp, #0x66]
     e74:      	ldrb	w8, [sp, #0xc]
     e78:      	strb	w8, [sp, #0x67]
     e7c:      	mov	w8, #0x9                // =9
     e80:      	blr	x8
     e84:      	tbnz	w0, #0x1f, 0x1158 <tail_icmp6_handle_ns+0x858>
     e88:      	mov	w8, #0x1c               // =28
     e8c:      	add	x0, sp, #0x58
     e90:      	add	x2, sp, #0x60
     e94:      	mov	w1, #0x8                // =8
     e98:      	mov	w3, #0x8                // =8
     e9c:      	mov	w4, w20
     ea0:      	blr	x8
     ea4:      	mov	w3, w0
     ea8:      	mov	w8, #0xb                // =11
     eac:      	add	w1, w24, #0x2a
     eb0:      	mov	x0, x19
     eb4:      	mov	w2, wzr
     eb8:      	mov	w4, #0x10               // =16
     ebc:      	blr	x8
     ec0:      	tbnz	w0, #0x1f, 0x1274 <tail_icmp6_handle_ns+0x974>
     ec4:      	ldp	x8, x9, [sp, #0x48]
     ec8:      	add	w1, w24, #0x8
     ecc:      	add	x2, sp, #0x88
     ed0:      	mov	x0, x19
     ed4:      	mov	w3, #0x10               // =16
     ed8:      	stp	x8, x9, [x21, #0x10]
     edc:      	ldr	x8, [x25]
     ee0:      	str	x8, [x21]
     ee4:      	mov	w8, #0x1a               // =26
     ee8:      	blr	x8
     eec:      	tbnz	w0, #0x1f, 0x123c <tail_icmp6_handle_ns+0x93c>
     ef0:      	mov	w8, #0x1a               // =26
     ef4:      	add	w1, w24, #0x18
     ef8:      	add	x2, sp, #0x78
     efc:      	mov	x0, x19
     f00:      	mov	w3, #0x10               // =16
     f04:      	blr	x8
     f08:      	tbnz	w0, #0x1f, 0x123c <tail_icmp6_handle_ns+0x93c>
     f0c:      	mov	w8, #0x9                // =9
     f10:      	add	w1, w24, #0x8
     f14:      	add	x2, sp, #0xa8
     f18:      	mov	x0, x19
     f1c:      	mov	w3, #0x10               // =16
     f20:      	mov	w4, wzr
     f24:      	blr	x8
     f28:      	tbnz	w0, #0x1f, 0x1158 <tail_icmp6_handle_ns+0x858>
     f2c:      	mov	w8, #0x9                // =9
     f30:      	add	w1, w24, #0x18
     f34:      	add	x2, sp, #0x88
     f38:      	mov	x0, x19
     f3c:      	mov	w3, #0x10               // =16
     f40:      	mov	w4, wzr
     f44:      	blr	x8
     f48:      	tbnz	w0, #0x1f, 0x1158 <tail_icmp6_handle_ns+0x858>
     f4c:      	mov	w8, #0x1c               // =28
     f50:      	add	x0, sp, #0x88
     f54:      	add	x2, sp, #0xa8
     f58:      	mov	w1, #0x10               // =16
     f5c:      	mov	w3, #0x10               // =16
     f60:      	mov	w4, wzr
     f64:      	blr	x8
     f68:      	mov	w3, w0
     f6c:      	mov	w8, #0xb                // =11
     f70:      	add	w1, w24, #0x2a
     f74:      	mov	x0, x19
     f78:      	mov	w2, wzr
     f7c:      	mov	w4, #0x10               // =16
     f80:      	blr	x8
     f84:      	tbnz	w0, #0x1f, 0x1274 <tail_icmp6_handle_ns+0x974>
     f88:      	mov	w8, #0x1c               // =28
     f8c:      	add	x0, sp, #0x78
     f90:      	add	x2, sp, #0x88
     f94:      	mov	w1, #0x10               // =16
     f98:      	mov	w3, #0x10               // =16
     f9c:      	mov	w4, wzr
     fa0:      	blr	x8
     fa4:      	mov	w3, w0
     fa8:      	mov	w8, #0xb                // =11
     fac:      	add	w1, w24, #0x2a
     fb0:      	mov	x0, x19
     fb4:      	mov	w2, wzr
     fb8:      	mov	w4, #0x10               // =16
     fbc:      	blr	x8
     fc0:      	tbnz	w0, #0x1f, 0x1274 <tail_icmp6_handle_ns+0x974>
     fc4:      	mov	w8, #0x1a               // =26
     fc8:      	add	x2, sp, #0xa0
     fcc:      	mov	x0, x19
     fd0:      	mov	w1, #0x6                // =6
     fd4:      	mov	w3, #0x6                // =6
     fd8:      	blr	x8
     fdc:      	tbnz	w0, #0x1f, 0x123c <tail_icmp6_handle_ns+0x93c>
     fe0:      	mov	w8, #0x9                // =9
     fe4:      	add	x2, sp, #0xa0
     fe8:      	mov	x0, x19
     fec:      	mov	w1, wzr
     ff0:      	mov	w3, #0x6                // =6
     ff4:      	mov	w4, wzr
     ff8:      	blr	x8
     ffc:      	tbnz	w0, #0x1f, 0x1158 <tail_icmp6_handle_ns+0x858>
    1000:      	mov	w8, #0x9                // =9
    1004:      	add	x2, sp, #0x98
    1008:      	mov	x0, x19
    100c:      	mov	w1, #0x6                // =6
    1010:      	mov	w3, #0x6                // =6
    1014:      	mov	w4, wzr
    1018:      	blr	x8
    101c:      	tbnz	w0, #0x1f, 0x1158 <tail_icmp6_handle_ns+0x858>
    1020:      	ldr	x8, [x19, #0x10]
    1024:      	cbz	x8, 0x102c <tail_icmp6_handle_ns+0x72c>
    1028:      	ldr	w8, [x8, #0xe0]
    102c:      	adrp	x10, 0x1000 <tail_icmp6_handle_ns+0x700>
    1030:      	ldr	w9, [x19, #0x70]
    1034:      	mov	w11, #0x403             // =1027
    1038:      	adrp	x1, 0x1000 <tail_icmp6_handle_ns+0x700>
    103c:      	ldr	x10, [x10]
    1040:      	add	x3, sp, #0xb8
    1044:      	mov	x0, x19
    1048:      	mov	w4, #0x18               // =24
    104c:      	ldr	w10, [x10]
    1050:      	strh	w11, [sp, #0xb8]
    1054:      	ldrh	w11, [x23]
    1058:      	stp	w8, wzr, [x21, #0x30]
    105c:      	mov	w8, #0x19               // =25
    1060:      	cmp	w9, w10
    1064:      	strh	w11, [sp, #0xba]
    1068:      	ldr	w11, [x19, #0x98]
    106c:      	csel	w10, w9, w10, lo
    1070:      	strh	w10, [sp, #0xc4]
    1074:      	stp	w11, w9, [x21, #0x24]
    1078:      	mov	w9, #0x1                // =1
    107c:      	strh	w9, [sp, #0xc6]
    1080:      	mov	w9, #-0x1               // =-1
    1084:      	orr	x2, x9, x10, lsl #32
    1088:      	ldr	x1, [x1]
    108c:      	blr	x8
    1090:      	ldr	x8, [x19, #0x10]
    1094:      	cbz	x8, 0x1288 <tail_icmp6_handle_ns+0x988>
    1098:      	ldr	w0, [x8, #0xe0]
    109c:      	b	0x128c <tail_icmp6_handle_ns+0x98c>
    10a0:      	mov	w0, #-0x86              // =-134
    10a4:      	cmp	w0, #0x0
    10a8:      	str	xzr, [x19, #0x30]
    10ac:      	ldr	w20, [x19, #0x70]
    10b0:      	add	x1, sp, #0xa8
    10b4:      	cneg	w8, w0, mi
    10b8:      	adrp	x0, 0x1000 <tail_icmp6_handle_ns+0x700>
    10bc:      	and	w9, w8, #0xff
    10c0:      	str	w9, [x19, #0x38]
    10c4:      	mov	x9, #0x670200000000     // =113258287595520
    10c8:      	movk	x9, #0x196, lsl #48
    10cc:      	stur	x9, [x19, #0x3c]
    10d0:      	mov	x9, #0x1960000          // =26607616
    10d4:      	movk	x9, #0x67, lsl #32
    10d8:      	str	x9, [x21, #0x10]
    10dc:      	strb	w8, [sp, #0xa8]
    10e0:      	and	w8, w22, #0x3
    10e4:      	strb	w8, [sp, #0xa9]
    10e8:      	mov	w8, #0x1                // =1
    10ec:      	ldr	x0, [x0]
    10f0:      	blr	x8
    10f4:      	cbz	x0, 0x1114 <tail_icmp6_handle_ns+0x814>
    10f8:      	ldp	x8, x9, [x0]
    10fc:      	add	x8, x8, #0x1
    1100:      	add	x9, x9, x20
    1104:      	stp	x8, x9, [x0]
    1108:      	b	0x1138 <tail_icmp6_handle_ns+0x838>
    110c:      	mov	w0, wzr
    1110:      	b	0x1240 <tail_icmp6_handle_ns+0x940>
    1114:      	mov	w8, #0x1                // =1
    1118:      	adrp	x0, 0x1000 <tail_icmp6_handle_ns+0x700>
    111c:      	add	x1, sp, #0xa8
    1120:      	stp	x8, x20, [x21, #0x20]
    1124:      	mov	w8, #0x2                // =2
    1128:      	add	x2, sp, #0xb8
    112c:      	mov	w3, wzr
    1130:      	ldr	x0, [x0]
    1134:      	blr	x8
    1138:      	mov	w8, #0xc                // =12
    113c:      	adrp	x1, 0x1000 <tail_icmp6_handle_ns+0x700>
    1140:      	mov	x0, x19
    1144:      	ldr	x1, [x1]
    1148:      	mov	w2, #0x1                // =1
    114c:      	blr	x8
    1150:      	mov	w0, #0x2                // =2
    1154:      	b	0x124c <tail_icmp6_handle_ns+0x94c>
    1158:      	mov	w0, #-0x8d              // =-141
    115c:      	b	0x1240 <tail_icmp6_handle_ns+0x940>
    1160:      	mov	w8, #0x26               // =38
    1164:      	mov	x0, x19
    1168:      	mov	w2, wzr
    116c:      	ldr	w9, [x19, #0x70]
    1170:      	add	w1, w9, #0x8
    1174:      	blr	x8
    1178:      	tbnz	w0, #0x1f, 0x123c <tail_icmp6_handle_ns+0x93c>
    117c:      	adrp	x8, 0x1000 <tail_icmp6_handle_ns+0x700>
    1180:      	ldr	x8, [x8]
    1184:      	ldrb	w8, [x8]
    1188:      	ldr	x10, [x19, #0xd0]
    118c:      	ldr	x9, [x19, #0x50]
    1190:      	add	x8, x10, x8
    1194:      	add	x10, x8, #0x28
    1198:      	cmp	x10, x9
    119c:      	b.hi	0x123c <tail_icmp6_handle_ns+0x93c>
    11a0:      	ldrh	w10, [x8, #0x4]
    11a4:      	rev	w10, w10
    11a8:      	lsr	w10, w10, #16
    11ac:      	add	w10, w10, #0x8
    11b0:      	rev	w10, w10
    11b4:      	lsr	w10, w10, #16
    11b8:      	strh	w10, [x8, #0x4]
    11bc:      	add	x10, x8, #0x48
    11c0:      	cmp	x10, x9
    11c4:      	b.hi	0x123c <tail_icmp6_handle_ns+0x93c>
    11c8:      	mov	w20, #0x8000000         // =134217728
    11cc:      	str	xzr, [x8, #0x40]
    11d0:      	b	0xa28 <tail_icmp6_handle_ns+0x128>
    11d4:      	mov	w8, #0x26               // =38
    11d8:      	mov	x0, x19
    11dc:      	mov	w2, wzr
    11e0:      	ldr	w9, [x19, #0x70]
    11e4:      	add	w1, w9, #0x8
    11e8:      	blr	x8
    11ec:      	tbnz	w0, #0x1f, 0x123c <tail_icmp6_handle_ns+0x93c>
    11f0:      	adrp	x8, 0x1000 <tail_icmp6_handle_ns+0x700>
    11f4:      	ldr	x8, [x8]
    11f8:      	ldrb	w8, [x8]
    11fc:      	ldr	x10, [x19, #0xd0]
    1200:      	ldr	x9, [x19, #0x50]
    1204:      	add	x8, x10, x8
    1208:      	add	x10, x8, #0x28
    120c:      	cmp	x10, x9
    1210:      	b.hi	0x123c <tail_icmp6_handle_ns+0x93c>
    1214:      	ldrh	w10, [x8, #0x4]
    1218:      	rev	w10, w10
    121c:      	lsr	w10, w10, #16
    1220:      	add	w10, w10, #0x8
    1224:      	rev	w10, w10
    1228:      	lsr	w10, w10, #16
    122c:      	strh	w10, [x8, #0x4]
    1230:      	add	x10, x8, #0x48
    1234:      	cmp	x10, x9
    1238:      	b.ls	0x1268 <tail_icmp6_handle_ns+0x968>
    123c:      	mov	w0, #-0x86              // =-134
    1240:      	tbnz	w0, #0x1f, 0x10a4 <tail_icmp6_handle_ns+0x7a4>
    1244:      	cmp	w0, #0x2
    1248:      	b.eq	0x10a4 <tail_icmp6_handle_ns+0x7a4>
    124c:      	ldp	x20, x19, [sp, #0x110]
    1250:      	ldr	x29, [sp, #0xd0]
    1254:      	ldp	x22, x21, [sp, #0x100]
    1258:      	ldp	x24, x23, [sp, #0xf0]
    125c:      	ldp	x30, x25, [sp, #0xe0]
    1260:      	add	sp, sp, #0x120
    1264:      	ret
    1268:      	mov	w20, #0x8000000         // =134217728
    126c:      	str	xzr, [x8, #0x40]
    1270:      	b	0xd94 <tail_icmp6_handle_ns+0x494>
    1274:      	mov	w0, #-0x9a              // =-154
    1278:      	b	0x1240 <tail_icmp6_handle_ns+0x940>
    127c:      	mov	w0, wzr
    1280:      	mov	w8, #0x17               // =23
    1284:      	b	0x1290 <tail_icmp6_handle_ns+0x990>
    1288:      	mov	w0, wzr
    128c:      	mov	w8, #0x17               // =23
    1290:      	mov	w1, wzr
    1294:      	blr	x8
    1298:      	b	0x1240 <tail_icmp6_handle_ns+0x940>

Disassembly of section tc/entry:

0000000000000000 <cil_from_netdev>:
       0:      	sub	sp, sp, #0x60
       4:      	stp	x30, x25, [sp, #0x20]
       8:      	stp	x24, x23, [sp, #0x30]
       c:      	stp	x22, x21, [sp, #0x40]
      10:      	stp	x20, x19, [sp, #0x50]
      14:      	str	wzr, [x0, #0x30]
      18:      	adrp	x22, 0x0 <cil_from_netdev>
      1c:      	adrp	x23, 0x0 <cil_from_netdev>
      20:      	mov	x19, x0
      24:      	str	wzr, [x0, #0x34]
      28:      	str	wzr, [x0, #0x38]
      2c:      	str	wzr, [x0, #0x3c]
      30:      	str	wzr, [x0, #0x40]
      34:      	ldr	x22, [x22]
      38:      	ldrb	w8, [x22]
      3c:      	ldr	x23, [x23]
      40:      	cbz	w8, 0xc0 <cil_from_netdev+0xc0>
      44:      	ldrb	w24, [x22]
      48:      	ldr	x8, [x19, #0x50]
      4c:      	ldrb	w10, [x23]
      50:      	ldr	x9, [x19, #0xd0]
      54:      	ldrb	w11, [x23]
      58:      	cbz	w11, 0x80 <cil_from_netdev+0x80>
      5c:      	add	x10, x9, x10
      60:      	cmp	x10, x8
      64:      	b.hi	0xa0 <cil_from_netdev+0xa0>
      68:      	ldrh	w10, [x9, #0xc]
      6c:      	cmp	w10, #0x6
      70:      	b.lo	0xa0 <cil_from_netdev+0xa0>
      74:      	cmp	w10, #0x8
      78:      	b.eq	0x8c <cil_from_netdev+0x8c>
      7c:      	b	0xa0 <cil_from_netdev+0xa0>
      80:      	ldrh	w10, [x19, #0xb4]
      84:      	cmp	w10, #0x8
      88:      	b.ne	0xa0 <cil_from_netdev+0xa0>
      8c:      	ldrb	w10, [x23]
      90:      	add	x9, x9, x10
      94:      	add	x10, x9, #0x14
      98:      	cmp	x10, x8
      9c:      	b.ls	0x244 <cil_from_netdev+0x244>
      a0:      	str	wzr, [sp, #0x10]
      a4:      	mov	w8, #0x1                // =1
      a8:      	adrp	x0, 0x0 <cil_from_netdev>
      ac:      	add	x1, sp, #0x10
      b0:      	ldr	x0, [x0]
      b4:      	blr	x8
      b8:      	cbz	x0, 0xc0 <cil_from_netdev+0xc0>
      bc:      	str	xzr, [x0]
      c0:      	ldr	w8, [x19, #0x9c]
      c4:      	cbz	w8, 0x100 <cil_from_netdev+0x100>
      c8:      	tst	w8, #0xfff0000
      cc:      	b.eq	0x100 <cil_from_netdev+0x100>
      d0:      	ldr	x9, [x19, #0x10]
      d4:      	cbz	x9, 0x2a8 <cil_from_netdev+0x2a8>
      d8:      	ldr	w9, [x9, #0xe0]
      dc:      	cmp	w9, #0x75
      e0:      	b.eq	0x298 <cil_from_netdev+0x298>
      e4:      	cmp	w9, #0x74
      e8:      	b.ne	0x2a8 <cil_from_netdev+0x2a8>
      ec:      	and	w8, w8, #0xffe0000
      f0:      	mov	w9, #0xfa00000          // =262144000
      f4:      	cmp	w8, w9
      f8:      	b.ne	0x2a8 <cil_from_netdev+0x2a8>
      fc:      	b	0x228 <cil_from_netdev+0x228>
     100:      	ldr	x9, [x19, #0x50]
     104:      	ldrb	w10, [x23]
     108:      	ldr	x8, [x19, #0xd0]
     10c:      	ldrb	w11, [x23]
     110:      	cbz	w11, 0x12c <cil_from_netdev+0x12c>
     114:      	add	x10, x8, x10
     118:      	cmp	x10, x9
     11c:      	b.hi	0x1a4 <cil_from_netdev+0x1a4>
     120:      	ldrh	w8, [x8, #0xc]
     124:      	cmp	w8, #0x5
     128:      	b.ls	0x1a4 <cil_from_netdev+0x1a4>
     12c:      	adrp	x8, 0x0 <cil_from_netdev>
     130:      	ldr	x8, [x8]
     134:      	ldr	wzr, [x8]
     138:      	ldrb	w8, [x22]
     13c:      	cbz	w8, 0x158 <cil_from_netdev+0x158>
     140:      	str	wzr, [sp, #0x10]
     144:      	mov	w8, #0x1                // =1
     148:      	adrp	x0, 0x0 <cil_from_netdev>
     14c:      	add	x1, sp, #0x10
     150:      	ldr	x0, [x0]
     154:      	blr	x8
     158:      	mov	x8, #0x103              // =259
     15c:      	ldr	w19, [x19, #0x70]
     160:      	adrp	x0, 0x0 <cil_from_netdev>
     164:      	add	x1, sp, #0x8
     168:      	movk	x8, #0x47e, lsl #16
     16c:      	movk	x8, #0x1, lsl #32
     170:      	str	x8, [sp, #0x8]
     174:      	mov	w8, #0x1                // =1
     178:      	ldr	x0, [x0]
     17c:      	blr	x8
     180:      	cbnz	x0, 0x1f0 <cil_from_netdev+0x1f0>
     184:      	mov	w8, #0x1                // =1
     188:      	adrp	x0, 0x0 <cil_from_netdev>
     18c:      	add	x1, sp, #0x8
     190:      	stp	x8, x19, [sp, #0x10]
     194:      	mov	w8, #0x2                // =2
     198:      	add	x2, sp, #0x10
     19c:      	mov	w3, wzr
     1a0:      	b	0x220 <cil_from_netdev+0x220>
     1a4:      	ldrb	w8, [x22]
     1a8:      	cbz	w8, 0x1c4 <cil_from_netdev+0x1c4>
     1ac:      	str	wzr, [sp, #0x10]
     1b0:      	mov	w8, #0x1                // =1
     1b4:      	adrp	x0, 0x0 <cil_from_netdev>
     1b8:      	add	x1, sp, #0x10
     1bc:      	ldr	x0, [x0]
     1c0:      	blr	x8
     1c4:      	mov	x8, #0x200              // =512
     1c8:      	ldr	w19, [x19, #0x70]
     1cc:      	adrp	x0, 0x0 <cil_from_netdev>
     1d0:      	add	x1, sp, #0x8
     1d4:      	movk	x8, #0x4c5, lsl #16
     1d8:      	movk	x8, #0x1, lsl #32
     1dc:      	str	x8, [sp, #0x8]
     1e0:      	mov	w8, #0x1                // =1
     1e4:      	ldr	x0, [x0]
     1e8:      	blr	x8
     1ec:      	cbz	x0, 0x204 <cil_from_netdev+0x204>
     1f0:      	ldp	x8, x9, [x0]
     1f4:      	add	x8, x8, #0x1
     1f8:      	add	x9, x9, x19
     1fc:      	stp	x8, x9, [x0]
     200:      	b	0x228 <cil_from_netdev+0x228>
     204:      	mov	w8, #0x1                // =1
     208:      	adrp	x0, 0x0 <cil_from_netdev>
     20c:      	add	x1, sp, #0x8
     210:      	stp	x8, x19, [sp, #0x10]
     214:      	mov	w8, #0x2                // =2
     218:      	add	x2, sp, #0x10
     21c:      	mov	w3, wzr
     220:      	ldr	x0, [x0]
     224:      	blr	x8
     228:      	mov	w0, wzr
     22c:      	ldp	x20, x19, [sp, #0x50]
     230:      	ldp	x22, x21, [sp, #0x40]
     234:      	ldp	x24, x23, [sp, #0x30]
     238:      	ldp	x30, x25, [sp, #0x20]
     23c:      	add	sp, sp, #0x60
     240:      	ret
     244:      	ldrb	w8, [x9]
     248:      	and	w9, w8, #0xe
     24c:      	cmp	w9, #0x6
     250:      	b.lo	0x4ec <cil_from_netdev+0x4ec>
     254:      	ldrb	w21, [x23]
     258:      	ubfiz	w25, w8, #2, #4
     25c:      	cbz	w25, 0x4ec <cil_from_netdev+0x4ec>
     260:      	mov	w8, #0x1a               // =26
     264:      	add	w20, w21, #0x14
     268:      	add	x2, sp, #0x8
     26c:      	mov	x0, x19
     270:      	mov	w3, #0x1                // =1
     274:      	mov	w1, w20
     278:      	blr	x8
     27c:      	tbnz	w0, #0x1f, 0xa0 <cil_from_netdev+0xa0>
     280:      	ldrb	w8, [sp, #0x8]
     284:      	cbz	w8, 0x4ec <cil_from_netdev+0x4ec>
     288:      	cmp	w8, #0x1
     28c:      	b.ne	0x354 <cil_from_netdev+0x354>
     290:      	add	w21, w21, #0x15
     294:      	b	0x3c8 <cil_from_netdev+0x3c8>
     298:      	ubfx	w8, w8, #16, #12
     29c:      	sub	w8, w8, #0xfa3
     2a0:      	cmp	w8, #0x3
     2a4:      	b.lo	0x228 <cil_from_netdev+0x228>
     2a8:      	mov	w8, #0xb6               // =182
     2ac:      	ldr	w20, [x19, #0x70]
     2b0:      	adrp	x0, 0x0 <cil_from_netdev>
     2b4:      	add	x1, sp, #0x8
     2b8:      	stp	xzr, x8, [x19, #0x30]
     2bc:      	mov	w8, #0x102              // =258
     2c0:      	movk	w8, #0x4e0, lsl #16
     2c4:      	str	w8, [x19, #0x40]
     2c8:      	mov	x8, #0x1b6              // =438
     2cc:      	movk	x8, #0x4e0, lsl #16
     2d0:      	movk	x8, #0x1, lsl #32
     2d4:      	str	x8, [sp, #0x8]
     2d8:      	mov	w8, #0x1                // =1
     2dc:      	ldr	x0, [x0]
     2e0:      	blr	x8
     2e4:      	cbz	x0, 0x2fc <cil_from_netdev+0x2fc>
     2e8:      	ldp	x8, x9, [x0]
     2ec:      	add	x8, x8, #0x1
     2f0:      	add	x9, x9, x20
     2f4:      	stp	x8, x9, [x0]
     2f8:      	b	0x320 <cil_from_netdev+0x320>
     2fc:      	mov	w8, #0x1                // =1
     300:      	adrp	x0, 0x0 <cil_from_netdev>
     304:      	add	x1, sp, #0x8
     308:      	stp	x8, x20, [sp, #0x10]
     30c:      	mov	w8, #0x2                // =2
     310:      	add	x2, sp, #0x10
     314:      	mov	w3, wzr
     318:      	ldr	x0, [x0]
     31c:      	blr	x8
     320:      	mov	w8, #0xc                // =12
     324:      	adrp	x1, 0x0 <cil_from_netdev>
     328:      	mov	x0, x19
     32c:      	ldr	x1, [x1]
     330:      	mov	w2, #0x1                // =1
     334:      	blr	x8
     338:      	mov	w0, #0x2                // =2
     33c:      	ldp	x20, x19, [sp, #0x50]
     340:      	ldp	x22, x21, [sp, #0x40]
     344:      	ldp	x24, x23, [sp, #0x30]
     348:      	ldp	x30, x25, [sp, #0x20]
     34c:      	add	sp, sp, #0x60
     350:      	ret
     354:      	mov	w8, #0x1a               // =26
     358:      	add	w1, w21, #0x15
     35c:      	add	x2, sp, #0x4
     360:      	mov	x0, x19
     364:      	mov	w3, #0x1                // =1
     368:      	blr	x8
     36c:      	tbnz	w0, #0x1f, 0xa0 <cil_from_netdev+0xa0>
     370:      	ldrb	w8, [sp, #0x8]
     374:      	cmp	w8, w24
     378:      	b.ne	0x3c0 <cil_from_netdev+0x3c0>
     37c:      	ldrb	w8, [sp, #0x4]
     380:      	cmp	w8, #0xa
     384:      	b.eq	0x45c <cil_from_netdev+0x45c>
     388:      	cmp	w8, #0x6
     38c:      	b.eq	0x430 <cil_from_netdev+0x430>
     390:      	cmp	w8, #0x4
     394:      	b.ne	0xa0 <cil_from_netdev+0xa0>
     398:      	mov	w8, #0x1a               // =26
     39c:      	add	w1, w20, #0x2
     3a0:      	add	x2, sp, #0x10
     3a4:      	mov	x0, x19
     3a8:      	mov	w3, #0x2                // =2
     3ac:      	blr	x8
     3b0:      	ldrh	w8, [sp, #0x10]
     3b4:      	rev	w8, w8
     3b8:      	lsr	w8, w8, #16
     3bc:      	b	0x47c <cil_from_netdev+0x47c>
     3c0:      	ldrb	w8, [sp, #0x4]
     3c4:      	add	w21, w20, w8
     3c8:      	add	w25, w20, w25
     3cc:      	cmp	w21, w25
     3d0:      	b.hs	0x4ec <cil_from_netdev+0x4ec>
     3d4:      	mov	w8, #0x1a               // =26
     3d8:      	add	x2, sp, #0x8
     3dc:      	mov	x0, x19
     3e0:      	mov	w1, w21
     3e4:      	mov	w3, #0x1                // =1
     3e8:      	blr	x8
     3ec:      	tbnz	w0, #0x1f, 0xa0 <cil_from_netdev+0xa0>
     3f0:      	ldrb	w8, [sp, #0x8]
     3f4:      	cbz	w8, 0x4ec <cil_from_netdev+0x4ec>
     3f8:      	cmp	w8, #0x1
     3fc:      	b.eq	0x490 <cil_from_netdev+0x490>
     400:      	mov	w8, #0x1a               // =26
     404:      	add	w1, w21, #0x1
     408:      	add	x2, sp, #0x4
     40c:      	mov	x0, x19
     410:      	mov	w3, #0x1                // =1
     414:      	blr	x8
     418:      	tbnz	w0, #0x1f, 0xa0 <cil_from_netdev+0xa0>
     41c:      	ldrb	w8, [sp, #0x8]
     420:      	cmp	w8, w24
     424:      	b.ne	0x48c <cil_from_netdev+0x48c>
     428:      	mov	w20, w21
     42c:      	b	0x37c <cil_from_netdev+0x37c>
     430:      	mov	w8, #0x1a               // =26
     434:      	add	w1, w20, #0x2
     438:      	add	x2, sp, #0x10
     43c:      	mov	x0, x19
     440:      	mov	w3, #0x4                // =4
     444:      	blr	x8
     448:      	ldr	w8, [sp, #0x10]
     44c:      	cmp	w0, #0x0
     450:      	rev	w8, w8
     454:      	csel	w20, wzr, w8, lt
     458:      	b	0x484 <cil_from_netdev+0x484>
     45c:      	mov	w8, #0x1a               // =26
     460:      	add	w1, w20, #0x2
     464:      	add	x2, sp, #0x10
     468:      	mov	x0, x19
     46c:      	mov	w3, #0x8                // =8
     470:      	blr	x8
     474:      	ldr	x8, [sp, #0x10]
     478:      	rev	x8, x8
     47c:      	cmp	w0, #0x0
     480:      	csel	x20, xzr, x8, lt
     484:      	tbz	w0, #0x1f, 0x4f0 <cil_from_netdev+0x4f0>
     488:      	b	0xa0 <cil_from_netdev+0xa0>
     48c:      	ldrb	w8, [sp, #0x4]
     490:      	add	w20, w21, w8
     494:      	cmp	w20, w25
     498:      	b.hs	0x4ec <cil_from_netdev+0x4ec>
     49c:      	mov	w8, #0x1a               // =26
     4a0:      	add	x2, sp, #0x8
     4a4:      	mov	x0, x19
     4a8:      	mov	w1, w20
     4ac:      	mov	w3, #0x1                // =1
     4b0:      	blr	x8
     4b4:      	tbnz	w0, #0x1f, 0xa0 <cil_from_netdev+0xa0>
     4b8:      	ldrb	w8, [sp, #0x8]
     4bc:      	cmp	w8, #0x2
     4c0:      	b.lo	0x4ec <cil_from_netdev+0x4ec>
     4c4:      	mov	w8, #0x1a               // =26
     4c8:      	add	w1, w20, #0x1
     4cc:      	add	x2, sp, #0x4
     4d0:      	mov	x0, x19
     4d4:      	mov	w3, #0x1                // =1
     4d8:      	blr	x8
     4dc:      	tbnz	w0, #0x1f, 0xa0 <cil_from_netdev+0xa0>
     4e0:      	ldrb	w8, [sp, #0x8]
     4e4:      	cmp	w8, w24
     4e8:      	b.eq	0x37c <cil_from_netdev+0x37c>
     4ec:      	mov	x20, xzr
     4f0:      	str	wzr, [sp, #0x10]
     4f4:      	mov	w8, #0x1                // =1
     4f8:      	adrp	x0, 0x0 <cil_from_netdev>
     4fc:      	add	x1, sp, #0x10
     500:      	ldr	x0, [x0]
     504:      	blr	x8
     508:      	cbz	x0, 0xc0 <cil_from_netdev+0xc0>
     50c:      	str	x20, [x0]
     510:      	b	0xc0 <cil_from_netdev+0xc0>
     514:      	nop
     518:      	nop
     51c:      	nop

0000000000000520 <cil_from_host>:
     520:      	sub	sp, sp, #0x60
     524:      	stp	x30, x25, [sp, #0x20]
     528:      	stp	x24, x23, [sp, #0x30]
     52c:      	stp	x22, x21, [sp, #0x40]
     530:      	stp	x20, x19, [sp, #0x50]
     534:      	str	wzr, [x0, #0x30]
     538:      	adrp	x22, 0x0 <cil_from_netdev>
     53c:      	adrp	x23, 0x0 <cil_from_netdev>
     540:      	mov	x19, x0
     544:      	str	wzr, [x0, #0x34]
     548:      	str	wzr, [x0, #0x38]
     54c:      	str	wzr, [x0, #0x3c]
     550:      	str	wzr, [x0, #0x40]
     554:      	ldr	x22, [x22]
     558:      	ldrb	w8, [x22]
     55c:      	ldr	x23, [x23]
     560:      	cbz	w8, 0x5e0 <cil_from_host+0xc0>
     564:      	ldrb	w24, [x22]
     568:      	ldr	x8, [x19, #0x50]
     56c:      	ldrb	w10, [x23]
     570:      	ldr	x9, [x19, #0xd0]
     574:      	ldrb	w11, [x23]
     578:      	cbz	w11, 0x5a0 <cil_from_host+0x80>
     57c:      	add	x10, x9, x10
     580:      	cmp	x10, x8
     584:      	b.hi	0x5c0 <cil_from_host+0xa0>
     588:      	ldrh	w10, [x9, #0xc]
     58c:      	cmp	w10, #0x6
     590:      	b.lo	0x5c0 <cil_from_host+0xa0>
     594:      	cmp	w10, #0x8
     598:      	b.eq	0x5ac <cil_from_host+0x8c>
     59c:      	b	0x5c0 <cil_from_host+0xa0>
     5a0:      	ldrh	w10, [x19, #0xb4]
     5a4:      	cmp	w10, #0x8
     5a8:      	b.ne	0x5c0 <cil_from_host+0xa0>
     5ac:      	ldrb	w10, [x23]
     5b0:      	add	x9, x9, x10
     5b4:      	add	x10, x9, #0x14
     5b8:      	cmp	x10, x8
     5bc:      	b.ls	0x904 <cil_from_host+0x3e4>
     5c0:      	str	wzr, [sp]
     5c4:      	mov	w8, #0x1                // =1
     5c8:      	adrp	x0, 0x0 <cil_from_netdev>
     5cc:      	mov	x1, sp
     5d0:      	ldr	x0, [x0]
     5d4:      	blr	x8
     5d8:      	cbz	x0, 0x5e0 <cil_from_host+0xc0>
     5dc:      	str	xzr, [x0]
     5e0:      	ldr	x9, [x19, #0x50]
     5e4:      	ldrb	w10, [x23]
     5e8:      	ldr	x8, [x19, #0xd0]
     5ec:      	ldrb	w11, [x23]
     5f0:      	cbz	w11, 0x60c <cil_from_host+0xec>
     5f4:      	add	x10, x8, x10
     5f8:      	cmp	x10, x9
     5fc:      	b.hi	0x6a8 <cil_from_host+0x188>
     600:      	ldrh	w8, [x8, #0xc]
     604:      	cmp	w8, #0x5
     608:      	b.ls	0x6a8 <cil_from_host+0x188>
     60c:      	ldr	w20, [x19, #0xa8]
     610:      	and	w8, w20, #0xf00
     614:      	sub	w8, w8, #0xa00
     618:      	lsr	w8, w8, #8
     61c:      	cmp	w8, #0x1
     620:      	b.gt	0x704 <cil_from_host+0x1e4>
     624:      	cbz	w8, 0x788 <cil_from_host+0x268>
     628:      	cmp	w8, #0x1
     62c:      	b.ne	0x780 <cil_from_host+0x260>
     630:      	adrp	x9, 0x0 <cil_from_netdev>
     634:      	mov	w11, #-0x1              // =-1
     638:      	mov	w12, #0x7fffff00        // =2147483392
     63c:      	ldr	x9, [x9]
     640:      	and	w8, w20, #0xff
     644:      	mov	w14, #0x18              // =24
     648:      	ldr	w10, [x9]
     64c:      	lsl	w10, w11, w10
     650:      	bic	w10, w12, w10
     654:      	ldr	w12, [x9]
     658:      	neg	w12, w12
     65c:      	lsl	w10, w10, w12
     660:      	ldr	w12, [x9]
     664:      	ldr	w13, [x9]
     668:      	ldr	w9, [x9]
     66c:      	and	w10, w10, w20
     670:      	neg	w12, w12
     674:      	sub	w9, w14, w9
     678:      	sub	w13, w14, w13
     67c:      	lsr	w10, w10, w12
     680:      	lsr	w12, w20, #16
     684:      	lsl	w11, w11, w13
     688:      	orr	w8, w10, w8
     68c:      	bic	w11, w12, w11
     690:      	lsl	w8, w8, w9
     694:      	ldrh	w9, [x19, #0x86]
     698:      	orr	w8, w8, w11
     69c:      	orr	w9, w9, #0x2
     6a0:      	strh	w9, [x19, #0x86]
     6a4:      	b	0x804 <cil_from_host+0x2e4>
     6a8:      	ldrb	w8, [x22]
     6ac:      	cbz	w8, 0x6c8 <cil_from_host+0x1a8>
     6b0:      	str	wzr, [sp]
     6b4:      	mov	w8, #0x1                // =1
     6b8:      	adrp	x0, 0x0 <cil_from_netdev>
     6bc:      	mov	x1, sp
     6c0:      	ldr	x0, [x0]
     6c4:      	blr	x8
     6c8:      	mov	x8, #0x200              // =512
     6cc:      	ldr	w19, [x19, #0x70]
     6d0:      	adrp	x0, 0x0 <cil_from_netdev>
     6d4:      	add	x1, sp, #0x18
     6d8:      	movk	x8, #0x503, lsl #16
     6dc:      	movk	x8, #0x1, lsl #32
     6e0:      	str	x8, [sp, #0x18]
     6e4:      	mov	w8, #0x1                // =1
     6e8:      	ldr	x0, [x0]
     6ec:      	blr	x8
     6f0:      	cbnz	x0, 0x8b0 <cil_from_host+0x390>
     6f4:      	mov	w8, #0x1                // =1
     6f8:      	stp	x8, x19, [sp]
     6fc:      	mov	w8, #0x2                // =2
     700:      	b	0x8d0 <cil_from_host+0x3b0>
     704:      	cmp	w8, #0x2
     708:      	b.eq	0x800 <cil_from_host+0x2e0>
     70c:      	cmp	w8, #0x5
     710:      	b.ne	0x780 <cil_from_host+0x260>
     714:      	adrp	x8, 0x0 <cil_from_netdev>
     718:      	mov	w11, #-0x1              // =-1
     71c:      	mov	w12, #0x7fffff00        // =2147483392
     720:      	ldr	x8, [x8]
     724:      	mov	w14, #0x18              // =24
     728:      	and	w9, w20, #0xff
     72c:      	ldr	w10, [x8]
     730:      	lsl	w10, w11, w10
     734:      	bic	w10, w12, w10
     738:      	ldr	w12, [x8]
     73c:      	neg	w12, w12
     740:      	lsl	w10, w10, w12
     744:      	ldr	w12, [x8]
     748:      	ldr	w13, [x8]
     74c:      	ldr	w8, [x8]
     750:      	and	w10, w10, w20
     754:      	neg	w12, w12
     758:      	sub	w13, w14, w13
     75c:      	sub	w8, w14, w8
     760:      	lsr	w10, w10, w12
     764:      	lsr	w12, w20, #16
     768:      	lsl	w11, w11, w13
     76c:      	orr	w9, w10, w9
     770:      	bic	w11, w12, w11
     774:      	lsl	w8, w9, w8
     778:      	orr	w8, w8, w11
     77c:      	b	0x804 <cil_from_host+0x2e4>
     780:      	mov	w8, #0x2                // =2
     784:      	b	0x804 <cil_from_host+0x2e4>
     788:      	adrp	x9, 0x0 <cil_from_netdev>
     78c:      	mov	w11, #-0x1              // =-1
     790:      	mov	w12, #0x7fffff00        // =2147483392
     794:      	ldr	x9, [x9]
     798:      	and	w8, w20, #0xff
     79c:      	mov	w14, #0x18              // =24
     7a0:      	ldr	w10, [x9]
     7a4:      	lsl	w10, w11, w10
     7a8:      	bic	w10, w12, w10
     7ac:      	ldr	w12, [x9]
     7b0:      	neg	w12, w12
     7b4:      	lsl	w10, w10, w12
     7b8:      	ldr	w12, [x9]
     7bc:      	ldr	w13, [x9]
     7c0:      	ldr	w9, [x9]
     7c4:      	and	w10, w10, w20
     7c8:      	neg	w12, w12
     7cc:      	sub	w9, w14, w9
     7d0:      	sub	w13, w14, w13
     7d4:      	lsr	w10, w10, w12
     7d8:      	lsr	w12, w20, #16
     7dc:      	lsl	w11, w11, w13
     7e0:      	orr	w8, w10, w8
     7e4:      	bic	w11, w12, w11
     7e8:      	lsl	w8, w8, w9
     7ec:      	ldrh	w9, [x19, #0x86]
     7f0:      	orr	w8, w8, w11
     7f4:      	orr	w9, w9, #0x1
     7f8:      	strh	w9, [x19, #0x86]
     7fc:      	b	0x804 <cil_from_host+0x2e4>
     800:      	mov	w8, #0x1                // =1
     804:      	mov	w9, #0x3d02             // =15618
     808:      	str	wzr, [x19, #0xa8]
     80c:      	adrp	x1, 0x0 <cil_from_netdev>
     810:      	mov	x3, sp
     814:      	strh	w9, [sp]
     818:      	adrp	x9, 0x0 <cil_from_netdev>
     81c:      	mov	x0, x19
     820:      	mov	w2, #-0x1               // =-1
     824:      	ldr	x9, [x9]
     828:      	mov	w4, #0x14               // =20
     82c:      	ldrh	w9, [x9]
     830:      	stur	xzr, [sp, #0xc]
     834:      	strh	w9, [sp, #0x2]
     838:      	ldr	w9, [x19, #0x98]
     83c:      	stp	w9, w8, [sp, #0x4]
     840:      	mov	w8, #0x19               // =25
     844:      	ldr	x1, [x1]
     848:      	blr	x8
     84c:      	adrp	x8, 0x0 <cil_from_netdev>
     850:      	and	w20, w20, #0xe00
     854:      	ldr	x8, [x8]
     858:      	ldr	wzr, [x8]
     85c:      	ldrb	w8, [x22]
     860:      	cbz	w8, 0x87c <cil_from_host+0x35c>
     864:      	str	wzr, [sp]
     868:      	mov	w8, #0x1                // =1
     86c:      	adrp	x0, 0x0 <cil_from_netdev>
     870:      	mov	x1, sp
     874:      	ldr	x0, [x0]
     878:      	blr	x8
     87c:      	cmp	w20, #0xa00
     880:      	b.eq	0x8e8 <cil_from_host+0x3c8>
     884:      	mov	x8, #0x103              // =259
     888:      	ldr	w19, [x19, #0x70]
     88c:      	adrp	x0, 0x0 <cil_from_netdev>
     890:      	add	x1, sp, #0x18
     894:      	movk	x8, #0x47e, lsl #16
     898:      	movk	x8, #0x1, lsl #32
     89c:      	str	x8, [sp, #0x18]
     8a0:      	mov	w8, #0x1                // =1
     8a4:      	ldr	x0, [x0]
     8a8:      	blr	x8
     8ac:      	cbz	x0, 0x8c4 <cil_from_host+0x3a4>
     8b0:      	ldp	x8, x9, [x0]
     8b4:      	add	x8, x8, #0x1
     8b8:      	add	x9, x9, x19
     8bc:      	stp	x8, x9, [x0]
     8c0:      	b	0x8e8 <cil_from_host+0x3c8>
     8c4:      	mov	w8, #0x1                // =1
     8c8:      	stp	x8, x19, [sp]
     8cc:      	mov	w8, #0x2                // =2
     8d0:      	adrp	x0, 0x0 <cil_from_netdev>
     8d4:      	add	x1, sp, #0x18
     8d8:      	mov	x2, sp
     8dc:      	ldr	x0, [x0]
     8e0:      	mov	w3, wzr
     8e4:      	blr	x8
     8e8:      	ldp	x20, x19, [sp, #0x50]
     8ec:      	mov	w0, wzr
     8f0:      	ldp	x22, x21, [sp, #0x40]
     8f4:      	ldp	x24, x23, [sp, #0x30]
     8f8:      	ldp	x30, x25, [sp, #0x20]
     8fc:      	add	sp, sp, #0x60
     900:      	ret
     904:      	ldrb	w8, [x9]
     908:      	and	w9, w8, #0xe
     90c:      	cmp	w9, #0x6
     910:      	b.lo	0xaf0 <cil_from_host+0x5d0>
     914:      	ldrb	w21, [x23]
     918:      	ubfiz	w25, w8, #2, #4
     91c:      	cbz	w25, 0xaf0 <cil_from_host+0x5d0>
     920:      	mov	w8, #0x1a               // =26
     924:      	add	w20, w21, #0x14
     928:      	add	x2, sp, #0x18
     92c:      	mov	x0, x19
     930:      	mov	w3, #0x1                // =1
     934:      	mov	w1, w20
     938:      	blr	x8
     93c:      	tbnz	w0, #0x1f, 0x5c0 <cil_from_host+0xa0>
     940:      	ldrb	w8, [sp, #0x18]
     944:      	cbz	w8, 0xaf0 <cil_from_host+0x5d0>
     948:      	cmp	w8, #0x1
     94c:      	b.ne	0x958 <cil_from_host+0x438>
     950:      	add	w21, w21, #0x15
     954:      	b	0x9cc <cil_from_host+0x4ac>
     958:      	mov	w8, #0x1a               // =26
     95c:      	add	w1, w21, #0x15
     960:      	add	x2, sp, #0x14
     964:      	mov	x0, x19
     968:      	mov	w3, #0x1                // =1
     96c:      	blr	x8
     970:      	tbnz	w0, #0x1f, 0x5c0 <cil_from_host+0xa0>
     974:      	ldrb	w8, [sp, #0x18]
     978:      	cmp	w8, w24
     97c:      	b.ne	0x9c4 <cil_from_host+0x4a4>
     980:      	ldrb	w8, [sp, #0x14]
     984:      	cmp	w8, #0xa
     988:      	b.eq	0xa60 <cil_from_host+0x540>
     98c:      	cmp	w8, #0x6
     990:      	b.eq	0xa34 <cil_from_host+0x514>
     994:      	cmp	w8, #0x4
     998:      	b.ne	0x5c0 <cil_from_host+0xa0>
     99c:      	mov	w8, #0x1a               // =26
     9a0:      	add	w1, w20, #0x2
     9a4:      	mov	x2, sp
     9a8:      	mov	x0, x19
     9ac:      	mov	w3, #0x2                // =2
     9b0:      	blr	x8
     9b4:      	ldrh	w8, [sp]
     9b8:      	rev	w8, w8
     9bc:      	lsr	w8, w8, #16
     9c0:      	b	0xa80 <cil_from_host+0x560>
     9c4:      	ldrb	w8, [sp, #0x14]
     9c8:      	add	w21, w20, w8
     9cc:      	add	w25, w20, w25
     9d0:      	cmp	w21, w25
     9d4:      	b.hs	0xaf0 <cil_from_host+0x5d0>
     9d8:      	mov	w8, #0x1a               // =26
     9dc:      	add	x2, sp, #0x18
     9e0:      	mov	x0, x19
     9e4:      	mov	w1, w21
     9e8:      	mov	w3, #0x1                // =1
     9ec:      	blr	x8
     9f0:      	tbnz	w0, #0x1f, 0x5c0 <cil_from_host+0xa0>
     9f4:      	ldrb	w8, [sp, #0x18]
     9f8:      	cbz	w8, 0xaf0 <cil_from_host+0x5d0>
     9fc:      	cmp	w8, #0x1
     a00:      	b.eq	0xa94 <cil_from_host+0x574>
     a04:      	mov	w8, #0x1a               // =26
     a08:      	add	w1, w21, #0x1
     a0c:      	add	x2, sp, #0x14
     a10:      	mov	x0, x19
     a14:      	mov	w3, #0x1                // =1
     a18:      	blr	x8
     a1c:      	tbnz	w0, #0x1f, 0x5c0 <cil_from_host+0xa0>
     a20:      	ldrb	w8, [sp, #0x18]
     a24:      	cmp	w8, w24
     a28:      	b.ne	0xa90 <cil_from_host+0x570>
     a2c:      	mov	w20, w21
     a30:      	b	0x980 <cil_from_host+0x460>
     a34:      	mov	w8, #0x1a               // =26
     a38:      	add	w1, w20, #0x2
     a3c:      	mov	x2, sp
     a40:      	mov	x0, x19
     a44:      	mov	w3, #0x4                // =4
     a48:      	blr	x8
     a4c:      	ldr	w8, [sp]
     a50:      	cmp	w0, #0x0
     a54:      	rev	w8, w8
     a58:      	csel	w20, wzr, w8, lt
     a5c:      	b	0xa88 <cil_from_host+0x568>
     a60:      	mov	w8, #0x1a               // =26
     a64:      	add	w1, w20, #0x2
     a68:      	mov	x2, sp
     a6c:      	mov	x0, x19
     a70:      	mov	w3, #0x8                // =8
     a74:      	blr	x8
     a78:      	ldr	x8, [sp]
     a7c:      	rev	x8, x8
     a80:      	cmp	w0, #0x0
     a84:      	csel	x20, xzr, x8, lt
     a88:      	tbz	w0, #0x1f, 0xaf4 <cil_from_host+0x5d4>
     a8c:      	b	0x5c0 <cil_from_host+0xa0>
     a90:      	ldrb	w8, [sp, #0x14]
     a94:      	add	w20, w21, w8
     a98:      	cmp	w20, w25
     a9c:      	b.hs	0xaf0 <cil_from_host+0x5d0>
     aa0:      	mov	w8, #0x1a               // =26
     aa4:      	add	x2, sp, #0x18
     aa8:      	mov	x0, x19
     aac:      	mov	w1, w20
     ab0:      	mov	w3, #0x1                // =1
     ab4:      	blr	x8
     ab8:      	tbnz	w0, #0x1f, 0x5c0 <cil_from_host+0xa0>
     abc:      	ldrb	w8, [sp, #0x18]
     ac0:      	cmp	w8, #0x2
     ac4:      	b.lo	0xaf0 <cil_from_host+0x5d0>
     ac8:      	mov	w8, #0x1a               // =26
     acc:      	add	w1, w20, #0x1
     ad0:      	add	x2, sp, #0x14
     ad4:      	mov	x0, x19
     ad8:      	mov	w3, #0x1                // =1
     adc:      	blr	x8
     ae0:      	tbnz	w0, #0x1f, 0x5c0 <cil_from_host+0xa0>
     ae4:      	ldrb	w8, [sp, #0x18]
     ae8:      	cmp	w8, w24
     aec:      	b.eq	0x980 <cil_from_host+0x460>
     af0:      	mov	x20, xzr
     af4:      	str	wzr, [sp]
     af8:      	mov	w8, #0x1                // =1
     afc:      	adrp	x0, 0x0 <cil_from_netdev>
     b00:      	mov	x1, sp
     b04:      	ldr	x0, [x0]
     b08:      	blr	x8
     b0c:      	cbz	x0, 0x5e0 <cil_from_host+0xc0>
     b10:      	str	x20, [x0]
     b14:      	b	0x5e0 <cil_from_host+0xc0>
     b18:      	nop
     b1c:      	nop

0000000000000b20 <cil_to_netdev>:
     b20:      	sub	sp, sp, #0x60
     b24:      	stp	x30, x25, [sp, #0x20]
     b28:      	stp	x24, x23, [sp, #0x30]
     b2c:      	stp	x22, x21, [sp, #0x40]
     b30:      	stp	x20, x19, [sp, #0x50]
     b34:      	adrp	x8, 0x0 <cil_from_netdev>
     b38:      	ldr	w23, [x0, #0xa8]
     b3c:      	adrp	x22, 0x0 <cil_from_netdev>
     b40:      	mov	x19, x0
     b44:      	ldr	x8, [x8]
     b48:      	ldrb	wzr, [x8]
     b4c:      	ldrb	wzr, [x8]
     b50:      	str	wzr, [x0, #0x30]
     b54:      	str	wzr, [x0, #0x34]
     b58:      	str	wzr, [x0, #0x38]
     b5c:      	str	wzr, [x0, #0x3c]
     b60:      	str	wzr, [x0, #0x40]
     b64:      	ldr	x22, [x22]
     b68:      	ldrb	w9, [x22]
     b6c:      	cbz	w9, 0xbec <cil_to_netdev+0xcc>
     b70:      	ldrb	w24, [x22]
     b74:      	ldr	x9, [x19, #0x50]
     b78:      	ldrb	w11, [x8]
     b7c:      	ldr	x10, [x19, #0xd0]
     b80:      	ldrb	w12, [x8]
     b84:      	cbz	w12, 0xbac <cil_to_netdev+0x8c>
     b88:      	add	x11, x10, x11
     b8c:      	cmp	x11, x9
     b90:      	b.hi	0xbcc <cil_to_netdev+0xac>
     b94:      	ldrh	w11, [x10, #0xc]
     b98:      	cmp	w11, #0x6
     b9c:      	b.lo	0xbcc <cil_to_netdev+0xac>
     ba0:      	cmp	w11, #0x8
     ba4:      	b.eq	0xbb8 <cil_to_netdev+0x98>
     ba8:      	b	0xbcc <cil_to_netdev+0xac>
     bac:      	ldrh	w11, [x19, #0xb4]
     bb0:      	cmp	w11, #0x8
     bb4:      	b.ne	0xbcc <cil_to_netdev+0xac>
     bb8:      	ldrb	w11, [x8]
     bbc:      	add	x10, x10, x11
     bc0:      	add	x11, x10, #0x14
     bc4:      	cmp	x11, x9
     bc8:      	b.ls	0xd84 <cil_to_netdev+0x264>
     bcc:      	str	wzr, [sp, #0x10]
     bd0:      	mov	w8, #0x1                // =1
     bd4:      	adrp	x0, 0x0 <cil_from_netdev>
     bd8:      	add	x1, sp, #0x10
     bdc:      	ldr	x0, [x0]
     be0:      	blr	x8
     be4:      	cbz	x0, 0xbec <cil_to_netdev+0xcc>
     be8:      	str	xzr, [x0]
     bec:      	and	w9, w23, #0x700
     bf0:      	mov	w8, #0x1                // =1
     bf4:      	cmp	w9, #0x400
     bf8:      	b.eq	0xc98 <cil_to_netdev+0x178>
     bfc:      	and	w9, w23, #0xf00
     c00:      	cmp	w9, #0xe00
     c04:      	b.eq	0xc98 <cil_to_netdev+0x178>
     c08:      	cmp	w9, #0xb00
     c0c:      	b.eq	0xc2c <cil_to_netdev+0x10c>
     c10:      	adrp	x10, 0x0 <cil_from_netdev>
     c14:      	mov	w8, wzr
     c18:      	ldr	x10, [x10]
     c1c:      	ldrb	w10, [x10]
     c20:      	cbz	w10, 0xc98 <cil_to_netdev+0x178>
     c24:      	cmp	w9, #0xf00
     c28:      	b.ne	0xc98 <cil_to_netdev+0x178>
     c2c:      	adrp	x9, 0x0 <cil_from_netdev>
     c30:      	ldr	w8, [x19, #0xa8]
     c34:      	mov	w12, #-0x1              // =-1
     c38:      	mov	w13, #0x7fffff00        // =2147483392
     c3c:      	ldr	x9, [x9]
     c40:      	mov	w14, #0x18              // =24
     c44:      	and	w10, w8, #0xff
     c48:      	ldr	w11, [x9]
     c4c:      	lsl	w11, w12, w11
     c50:      	bic	w11, w13, w11
     c54:      	ldr	w13, [x9]
     c58:      	neg	w13, w13
     c5c:      	lsl	w11, w11, w13
     c60:      	ldr	w13, [x9]
     c64:      	and	w11, w11, w8
     c68:      	lsr	w8, w8, #16
     c6c:      	neg	w13, w13
     c70:      	lsr	w11, w11, w13
     c74:      	ldr	w13, [x9]
     c78:      	ldr	w9, [x9]
     c7c:      	orr	w10, w11, w10
     c80:      	sub	w13, w14, w13
     c84:      	sub	w9, w14, w9
     c88:      	lsl	w12, w12, w13
     c8c:      	lsl	w9, w10, w9
     c90:      	bic	w8, w8, w12
     c94:      	orr	w8, w9, w8
     c98:      	ldr	w9, [x19, #0x9c]
     c9c:      	cbz	w9, 0xcd8 <cil_to_netdev+0x1b8>
     ca0:      	tst	w9, #0xfff0000
     ca4:      	b.eq	0xcd8 <cil_to_netdev+0x1b8>
     ca8:      	ldr	x10, [x19, #0x10]
     cac:      	cbz	x10, 0xde8 <cil_to_netdev+0x2c8>
     cb0:      	ldr	w10, [x10, #0xe0]
     cb4:      	cmp	w10, #0x75
     cb8:      	b.eq	0xdd8 <cil_to_netdev+0x2b8>
     cbc:      	cmp	w10, #0x74
     cc0:      	b.ne	0xde8 <cil_to_netdev+0x2c8>
     cc4:      	and	w9, w9, #0xffe0000
     cc8:      	mov	w10, #0xfa00000         // =262144000
     ccc:      	cmp	w9, w10
     cd0:      	b.ne	0xde8 <cil_to_netdev+0x2c8>
     cd4:      	b	0xd68 <cil_to_netdev+0x248>
     cd8:      	adrp	x8, 0x0 <cil_from_netdev>
     cdc:      	ldr	x8, [x8]
     ce0:      	ldr	wzr, [x8]
     ce4:      	ldrb	w8, [x22]
     ce8:      	cbz	w8, 0xd04 <cil_to_netdev+0x1e4>
     cec:      	str	wzr, [sp, #0x10]
     cf0:      	mov	w8, #0x1                // =1
     cf4:      	adrp	x0, 0x0 <cil_from_netdev>
     cf8:      	add	x1, sp, #0x10
     cfc:      	ldr	x0, [x0]
     d00:      	blr	x8
     d04:      	mov	x8, #0x200              // =512
     d08:      	ldr	w19, [x19, #0x70]
     d0c:      	adrp	x0, 0x0 <cil_from_netdev>
     d10:      	add	x1, sp, #0x8
     d14:      	movk	x8, #0x5f3, lsl #16
     d18:      	movk	x8, #0x1, lsl #32
     d1c:      	str	x8, [sp, #0x8]
     d20:      	mov	w8, #0x1                // =1
     d24:      	ldr	x0, [x0]
     d28:      	blr	x8
     d2c:      	cbz	x0, 0xd44 <cil_to_netdev+0x224>
     d30:      	ldp	x8, x9, [x0]
     d34:      	add	x8, x8, #0x1
     d38:      	add	x9, x9, x19
     d3c:      	stp	x8, x9, [x0]
     d40:      	b	0xd68 <cil_to_netdev+0x248>
     d44:      	mov	w8, #0x1                // =1
     d48:      	adrp	x0, 0x0 <cil_from_netdev>
     d4c:      	add	x1, sp, #0x8
     d50:      	stp	x8, x19, [sp, #0x10]
     d54:      	mov	w8, #0x2                // =2
     d58:      	add	x2, sp, #0x10
     d5c:      	mov	w3, wzr
     d60:      	ldr	x0, [x0]
     d64:      	blr	x8
     d68:      	mov	w0, wzr
     d6c:      	ldp	x20, x19, [sp, #0x50]
     d70:      	ldp	x22, x21, [sp, #0x40]
     d74:      	ldp	x24, x23, [sp, #0x30]
     d78:      	ldp	x30, x25, [sp, #0x20]
     d7c:      	add	sp, sp, #0x60
     d80:      	ret
     d84:      	ldrb	w9, [x10]
     d88:      	and	w10, w9, #0xe
     d8c:      	cmp	w10, #0x6
     d90:      	b.lo	0x1030 <cil_to_netdev+0x510>
     d94:      	ldrb	w21, [x8]
     d98:      	ubfiz	w25, w9, #2, #4
     d9c:      	cbz	w25, 0x1030 <cil_to_netdev+0x510>
     da0:      	mov	w8, #0x1a               // =26
     da4:      	add	w20, w21, #0x14
     da8:      	add	x2, sp, #0x8
     dac:      	mov	x0, x19
     db0:      	mov	w3, #0x1                // =1
     db4:      	mov	w1, w20
     db8:      	blr	x8
     dbc:      	tbnz	w0, #0x1f, 0xbcc <cil_to_netdev+0xac>
     dc0:      	ldrb	w8, [sp, #0x8]
     dc4:      	cbz	w8, 0x1030 <cil_to_netdev+0x510>
     dc8:      	cmp	w8, #0x1
     dcc:      	b.ne	0xe98 <cil_to_netdev+0x378>
     dd0:      	add	w21, w21, #0x15
     dd4:      	b	0xf0c <cil_to_netdev+0x3ec>
     dd8:      	ubfx	w9, w9, #16, #12
     ddc:      	sub	w9, w9, #0xfa3
     de0:      	cmp	w9, #0x3
     de4:      	b.lo	0xd68 <cil_to_netdev+0x248>
     de8:      	str	w8, [x19, #0x30]
     dec:      	mov	x8, #0xb600000000       // =781684047872
     df0:      	ldr	w20, [x19, #0x70]
     df4:      	adrp	x0, 0x0 <cil_from_netdev>
     df8:      	add	x1, sp, #0x8
     dfc:      	stur	x8, [x19, #0x34]
     e00:      	mov	x8, #0x10200000000      // =1108101562368
     e04:      	movk	x8, #0x5f9, lsl #48
     e08:      	stur	x8, [x19, #0x3c]
     e0c:      	mov	x8, #0x2b6              // =694
     e10:      	movk	x8, #0x5f9, lsl #16
     e14:      	movk	x8, #0x1, lsl #32
     e18:      	str	x8, [sp, #0x8]
     e1c:      	mov	w8, #0x1                // =1
     e20:      	ldr	x0, [x0]
     e24:      	blr	x8
     e28:      	cbz	x0, 0xe40 <cil_to_netdev+0x320>
     e2c:      	ldp	x8, x9, [x0]
     e30:      	add	x8, x8, #0x1
     e34:      	add	x9, x9, x20
     e38:      	stp	x8, x9, [x0]
     e3c:      	b	0xe64 <cil_to_netdev+0x344>
     e40:      	mov	w8, #0x1                // =1
     e44:      	adrp	x0, 0x0 <cil_from_netdev>
     e48:      	add	x1, sp, #0x8
     e4c:      	stp	x8, x20, [sp, #0x10]
     e50:      	mov	w8, #0x2                // =2
     e54:      	add	x2, sp, #0x10
     e58:      	mov	w3, wzr
     e5c:      	ldr	x0, [x0]
     e60:      	blr	x8
     e64:      	mov	w8, #0xc                // =12
     e68:      	adrp	x1, 0x0 <cil_from_netdev>
     e6c:      	mov	x0, x19
     e70:      	ldr	x1, [x1]
     e74:      	mov	w2, #0x1                // =1
     e78:      	blr	x8
     e7c:      	mov	w0, #0x2                // =2
     e80:      	ldp	x20, x19, [sp, #0x50]
     e84:      	ldp	x22, x21, [sp, #0x40]
     e88:      	ldp	x24, x23, [sp, #0x30]
     e8c:      	ldp	x30, x25, [sp, #0x20]
     e90:      	add	sp, sp, #0x60
     e94:      	ret
     e98:      	mov	w8, #0x1a               // =26
     e9c:      	add	w1, w21, #0x15
     ea0:      	add	x2, sp, #0x4
     ea4:      	mov	x0, x19
     ea8:      	mov	w3, #0x1                // =1
     eac:      	blr	x8
     eb0:      	tbnz	w0, #0x1f, 0xbcc <cil_to_netdev+0xac>
     eb4:      	ldrb	w8, [sp, #0x8]
     eb8:      	cmp	w8, w24
     ebc:      	b.ne	0xf04 <cil_to_netdev+0x3e4>
     ec0:      	ldrb	w8, [sp, #0x4]
     ec4:      	cmp	w8, #0xa
     ec8:      	b.eq	0xfa0 <cil_to_netdev+0x480>
     ecc:      	cmp	w8, #0x6
     ed0:      	b.eq	0xf74 <cil_to_netdev+0x454>
     ed4:      	cmp	w8, #0x4
     ed8:      	b.ne	0xbcc <cil_to_netdev+0xac>
     edc:      	mov	w8, #0x1a               // =26
     ee0:      	add	w1, w20, #0x2
     ee4:      	add	x2, sp, #0x10
     ee8:      	mov	x0, x19
     eec:      	mov	w3, #0x2                // =2
     ef0:      	blr	x8
     ef4:      	ldrh	w8, [sp, #0x10]
     ef8:      	rev	w8, w8
     efc:      	lsr	w8, w8, #16
     f00:      	b	0xfc0 <cil_to_netdev+0x4a0>
     f04:      	ldrb	w8, [sp, #0x4]
     f08:      	add	w21, w20, w8
     f0c:      	add	w25, w20, w25
     f10:      	cmp	w21, w25
     f14:      	b.hs	0x1030 <cil_to_netdev+0x510>
     f18:      	mov	w8, #0x1a               // =26
     f1c:      	add	x2, sp, #0x8
     f20:      	mov	x0, x19
     f24:      	mov	w1, w21
     f28:      	mov	w3, #0x1                // =1
     f2c:      	blr	x8
     f30:      	tbnz	w0, #0x1f, 0xbcc <cil_to_netdev+0xac>
     f34:      	ldrb	w8, [sp, #0x8]
     f38:      	cbz	w8, 0x1030 <cil_to_netdev+0x510>
     f3c:      	cmp	w8, #0x1
     f40:      	b.eq	0xfd4 <cil_to_netdev+0x4b4>
     f44:      	mov	w8, #0x1a               // =26
     f48:      	add	w1, w21, #0x1
     f4c:      	add	x2, sp, #0x4
     f50:      	mov	x0, x19
     f54:      	mov	w3, #0x1                // =1
     f58:      	blr	x8
     f5c:      	tbnz	w0, #0x1f, 0xbcc <cil_to_netdev+0xac>
     f60:      	ldrb	w8, [sp, #0x8]
     f64:      	cmp	w8, w24
     f68:      	b.ne	0xfd0 <cil_to_netdev+0x4b0>
     f6c:      	mov	w20, w21
     f70:      	b	0xec0 <cil_to_netdev+0x3a0>
     f74:      	mov	w8, #0x1a               // =26
     f78:      	add	w1, w20, #0x2
     f7c:      	add	x2, sp, #0x10
     f80:      	mov	x0, x19
     f84:      	mov	w3, #0x4                // =4
     f88:      	blr	x8
     f8c:      	ldr	w8, [sp, #0x10]
     f90:      	cmp	w0, #0x0
     f94:      	rev	w8, w8
     f98:      	csel	w20, wzr, w8, lt
     f9c:      	b	0xfc8 <cil_to_netdev+0x4a8>
     fa0:      	mov	w8, #0x1a               // =26
     fa4:      	add	w1, w20, #0x2
     fa8:      	add	x2, sp, #0x10
     fac:      	mov	x0, x19
     fb0:      	mov	w3, #0x8                // =8
     fb4:      	blr	x8
     fb8:      	ldr	x8, [sp, #0x10]
     fbc:      	rev	x8, x8
     fc0:      	cmp	w0, #0x0
     fc4:      	csel	x20, xzr, x8, lt
     fc8:      	tbz	w0, #0x1f, 0x1034 <cil_to_netdev+0x514>
     fcc:      	b	0xbcc <cil_to_netdev+0xac>
     fd0:      	ldrb	w8, [sp, #0x4]
     fd4:      	add	w20, w21, w8
     fd8:      	cmp	w20, w25
     fdc:      	b.hs	0x1030 <cil_to_netdev+0x510>
     fe0:      	mov	w8, #0x1a               // =26
     fe4:      	add	x2, sp, #0x8
     fe8:      	mov	x0, x19
     fec:      	mov	w1, w20
     ff0:      	mov	w3, #0x1                // =1
     ff4:      	blr	x8
     ff8:      	tbnz	w0, #0x1f, 0xbcc <cil_to_netdev+0xac>
     ffc:      	ldrb	w8, [sp, #0x8]
    1000:      	cmp	w8, #0x2
    1004:      	b.lo	0x1030 <cil_to_netdev+0x510>
    1008:      	mov	w8, #0x1a               // =26
    100c:      	add	w1, w20, #0x1
    1010:      	add	x2, sp, #0x4
    1014:      	mov	x0, x19
    1018:      	mov	w3, #0x1                // =1
    101c:      	blr	x8
    1020:      	tbnz	w0, #0x1f, 0xbcc <cil_to_netdev+0xac>
    1024:      	ldrb	w8, [sp, #0x8]
    1028:      	cmp	w8, w24
    102c:      	b.eq	0xec0 <cil_to_netdev+0x3a0>
    1030:      	mov	x20, xzr
    1034:      	str	wzr, [sp, #0x10]
    1038:      	mov	w8, #0x1                // =1
    103c:      	adrp	x0, 0x1000 <cil_to_netdev+0x4e0>
    1040:      	add	x1, sp, #0x10
    1044:      	ldr	x0, [x0]
    1048:      	blr	x8
    104c:      	cbz	x0, 0xbec <cil_to_netdev+0xcc>
    1050:      	str	x20, [x0]
    1054:      	b	0xbec <cil_to_netdev+0xcc>
    1058:      	nop
    105c:      	nop

0000000000001060 <cil_to_host>:
    1060:      	sub	sp, sp, #0x70
    1064:      	stp	x30, x25, [sp, #0x30]
    1068:      	stp	x24, x23, [sp, #0x40]
    106c:      	stp	x22, x21, [sp, #0x50]
    1070:      	stp	x20, x19, [sp, #0x60]
    1074:      	adrp	x23, 0x1000 <cil_to_netdev+0x4e0>
    1078:      	ldr	w22, [x0, #0x30]
    107c:      	mov	x19, x0
    1080:      	ldr	x23, [x23]
    1084:      	ldrb	w8, [x23]
    1088:      	cbz	w8, 0x1110 <cil_to_host+0xb0>
    108c:      	adrp	x8, 0x1000 <cil_to_netdev+0x4e0>
    1090:      	ldrb	w24, [x23]
    1094:      	ldr	x9, [x19, #0x50]
    1098:      	ldr	x8, [x8]
    109c:      	ldrb	w11, [x8]
    10a0:      	ldr	x10, [x19, #0xd0]
    10a4:      	ldrb	w12, [x8]
    10a8:      	cbz	w12, 0x10d0 <cil_to_host+0x70>
    10ac:      	add	x11, x10, x11
    10b0:      	cmp	x11, x9
    10b4:      	b.hi	0x10f0 <cil_to_host+0x90>
    10b8:      	ldrh	w11, [x10, #0xc]
    10bc:      	cmp	w11, #0x6
    10c0:      	b.lo	0x10f0 <cil_to_host+0x90>
    10c4:      	cmp	w11, #0x8
    10c8:      	b.eq	0x10dc <cil_to_host+0x7c>
    10cc:      	b	0x10f0 <cil_to_host+0x90>
    10d0:      	ldrh	w11, [x19, #0xb4]
    10d4:      	cmp	w11, #0x8
    10d8:      	b.ne	0x10f0 <cil_to_host+0x90>
    10dc:      	ldrb	w11, [x8]
    10e0:      	add	x10, x10, x11
    10e4:      	add	x11, x10, #0x14
    10e8:      	cmp	x11, x9
    10ec:      	b.ls	0x13fc <cil_to_host+0x39c>
    10f0:      	str	wzr, [sp, #0x8]
    10f4:      	mov	w8, #0x1                // =1
    10f8:      	adrp	x0, 0x1000 <cil_to_netdev+0x4e0>
    10fc:      	add	x1, sp, #0x8
    1100:      	ldr	x0, [x0]
    1104:      	blr	x8
    1108:      	cbz	x0, 0x1110 <cil_to_host+0xb0>
    110c:      	str	xzr, [x0]
    1110:      	adrp	x8, 0x1000 <cil_to_netdev+0x4e0>
    1114:      	ldr	x8, [x8]
    1118:      	ldrb	w8, [x8]
    111c:      	ldr	w9, [x19, #0xa8]
    1120:      	and	w10, w9, #0xf00
    1124:      	cbz	w8, 0x1210 <cil_to_host+0x1b0>
    1128:      	cmp	w10, #0xf00
    112c:      	b.ne	0x1210 <cil_to_host+0x1b0>
    1130:      	adrp	x8, 0x1000 <cil_to_netdev+0x4e0>
    1134:      	mov	w12, #-0x1              // =-1
    1138:      	mov	w13, #0x7fffff00        // =2147483392
    113c:      	ldr	x8, [x8]
    1140:      	mov	w14, #0x18              // =24
    1144:      	and	w10, w9, #0xff
    1148:      	ldr	w11, [x8]
    114c:      	lsl	w11, w12, w11
    1150:      	bic	w11, w13, w11
    1154:      	ldr	w13, [x8]
    1158:      	neg	w13, w13
    115c:      	lsl	w11, w11, w13
    1160:      	ldr	w13, [x8]
    1164:      	and	w11, w11, w9
    1168:      	lsr	w9, w9, #16
    116c:      	neg	w13, w13
    1170:      	lsr	w11, w11, w13
    1174:      	ldr	w13, [x8]
    1178:      	ldr	w8, [x8]
    117c:      	orr	w10, w11, w10
    1180:      	sub	w13, w14, w13
    1184:      	sub	w8, w14, w8
    1188:      	lsl	w12, w12, w13
    118c:      	lsl	w8, w10, w8
    1190:      	bic	w9, w9, w12
    1194:      	orr	w8, w8, w9
    1198:      	and	w9, w22, #0xffff
    119c:      	cmp	w9, #0x200
    11a0:      	b.eq	0x1228 <cil_to_host+0x1c8>
    11a4:      	adrp	x8, 0x1000 <cil_to_netdev+0x4e0>
    11a8:      	ldr	x8, [x8]
    11ac:      	ldr	wzr, [x8]
    11b0:      	ldrb	w8, [x23]
    11b4:      	cbz	w8, 0x11d0 <cil_to_host+0x170>
    11b8:      	str	wzr, [sp, #0x8]
    11bc:      	mov	w8, #0x1                // =1
    11c0:      	adrp	x0, 0x1000 <cil_to_netdev+0x4e0>
    11c4:      	add	x1, sp, #0x8
    11c8:      	ldr	x0, [x0]
    11cc:      	blr	x8
    11d0:      	mov	x8, #0x200              // =512
    11d4:      	ldr	w19, [x19, #0x70]
    11d8:      	adrp	x0, 0x1000 <cil_to_netdev+0x4e0>
    11dc:      	add	x1, sp, #0x28
    11e0:      	movk	x8, #0x6f6, lsl #16
    11e4:      	movk	x8, #0x1, lsl #32
    11e8:      	str	x8, [sp, #0x28]
    11ec:      	mov	w8, #0x1                // =1
    11f0:      	ldr	x0, [x0]
    11f4:      	blr	x8
    11f8:      	cbz	x0, 0x1308 <cil_to_host+0x2a8>
    11fc:      	ldp	x8, x9, [x0]
    1200:      	add	x8, x8, #0x1
    1204:      	add	x9, x9, x19
    1208:      	stp	x8, x9, [x0]
    120c:      	b	0x132c <cil_to_host+0x2cc>
    1210:      	cmp	w10, #0x200
    1214:      	mov	w8, wzr
    1218:      	csel	w22, w9, w22, eq
    121c:      	and	w9, w22, #0xffff
    1220:      	cmp	w9, #0x200
    1224:      	b.ne	0x11a4 <cil_to_host+0x144>
    1228:      	str	wzr, [x19, #0x30]
    122c:      	adrp	x9, 0x1000 <cil_to_netdev+0x4e0>
    1230:      	cmp	w22, #0x10, lsl #12     // =0x10000
    1234:      	ldr	x9, [x9]
    1238:      	ldrb	w9, [x9]
    123c:      	b.lo	0x1280 <cil_to_host+0x220>
    1240:      	cbz	w9, 0x1280 <cil_to_host+0x220>
    1244:      	adrp	x12, 0x1000 <cil_to_netdev+0x4e0>
    1248:      	ldr	x10, [x19, #0x50]
    124c:      	ldr	x12, [x12]
    1250:      	ldrb	w11, [x12]
    1254:      	ldr	x9, [x19, #0xd0]
    1258:      	ldrb	w12, [x12]
    125c:      	cbz	w12, 0x1278 <cil_to_host+0x218>
    1260:      	add	x11, x9, x11
    1264:      	cmp	x11, x10
    1268:      	b.hi	0x1348 <cil_to_host+0x2e8>
    126c:      	ldrh	w9, [x9, #0xc]
    1270:      	cmp	w9, #0x6
    1274:      	b.lo	0x1348 <cil_to_host+0x2e8>
    1278:      	mov	w9, #0x8b               // =139
    127c:      	b	0x134c <cil_to_host+0x2ec>
    1280:      	adrp	x10, 0x1000 <cil_to_netdev+0x4e0>
    1284:      	ldr	w9, [x19, #0x70]
    1288:      	mov	w11, #0x903             // =2307
    128c:      	lsr	w8, w22, #16
    1290:      	ldr	x10, [x10]
    1294:      	adrp	x1, 0x1000 <cil_to_netdev+0x4e0>
    1298:      	add	x3, sp, #0x8
    129c:      	mov	x0, x19
    12a0:      	ldr	w10, [x10]
    12a4:      	strh	w11, [sp, #0x8]
    12a8:      	adrp	x11, 0x1000 <cil_to_netdev+0x4e0>
    12ac:      	mov	w4, #0x18               // =24
    12b0:      	ldr	x11, [x11]
    12b4:      	cmp	w9, w10
    12b8:      	ldrh	w11, [x11]
    12bc:      	csel	w10, w9, w10, lo
    12c0:      	stp	w8, wzr, [sp, #0x18]
    12c4:      	mov	w8, #0x19               // =25
    12c8:      	strh	w10, [sp, #0x14]
    12cc:      	strh	w11, [sp, #0xa]
    12d0:      	ldr	w11, [x19, #0x98]
    12d4:      	stp	w11, w9, [sp, #0xc]
    12d8:      	mov	w9, #0x1                // =1
    12dc:      	strh	w9, [sp, #0x16]
    12e0:      	mov	w9, #-0x1               // =-1
    12e4:      	orr	x2, x9, x10, lsl #32
    12e8:      	ldr	x1, [x1]
    12ec:      	blr	x8
    12f0:      	str	w22, [x19, #0xa8]
    12f4:      	mov	w8, #0x20               // =32
    12f8:      	mov	x0, x19
    12fc:      	mov	w1, wzr
    1300:      	blr	x8
    1304:      	b	0x132c <cil_to_host+0x2cc>
    1308:      	mov	w8, #0x1                // =1
    130c:      	adrp	x0, 0x1000 <cil_to_netdev+0x4e0>
    1310:      	add	x1, sp, #0x28
    1314:      	stp	x8, x19, [sp, #0x8]
    1318:      	mov	w8, #0x2                // =2
    131c:      	add	x2, sp, #0x8
    1320:      	mov	w3, wzr
    1324:      	ldr	x0, [x0]
    1328:      	blr	x8
    132c:      	mov	w0, wzr
    1330:      	ldp	x20, x19, [sp, #0x60]
    1334:      	ldp	x22, x21, [sp, #0x50]
    1338:      	ldp	x24, x23, [sp, #0x40]
    133c:      	ldp	x30, x25, [sp, #0x30]
    1340:      	add	sp, sp, #0x70
    1344:      	ret
    1348:      	mov	w9, #0xa6               // =166
    134c:      	stp	w8, wzr, [x19, #0x30]
    1350:      	mov	x8, #0x10200000000      // =1108101562368
    1354:      	str	w9, [x19, #0x38]
    1358:      	ldr	w20, [x19, #0x70]
    135c:      	adrp	x0, 0x1000 <cil_to_netdev+0x4e0>
    1360:      	add	x1, sp, #0x28
    1364:      	movk	x8, #0x6f1, lsl #48
    1368:      	stur	x8, [x19, #0x3c]
    136c:      	mov	x8, #0x100              // =256
    1370:      	movk	x8, #0x6f1, lsl #16
    1374:      	movk	x8, #0x1, lsl #32
    1378:      	str	x8, [sp, #0x28]
    137c:      	strb	w9, [sp, #0x28]
    1380:      	mov	w8, #0x1                // =1
    1384:      	ldr	x0, [x0]
    1388:      	blr	x8
    138c:      	cbz	x0, 0x13a4 <cil_to_host+0x344>
    1390:      	ldp	x8, x9, [x0]
    1394:      	add	x8, x8, #0x1
    1398:      	add	x9, x9, x20
    139c:      	stp	x8, x9, [x0]
    13a0:      	b	0x13c8 <cil_to_host+0x368>
    13a4:      	mov	w8, #0x1                // =1
    13a8:      	adrp	x0, 0x1000 <cil_to_netdev+0x4e0>
    13ac:      	add	x1, sp, #0x28
    13b0:      	stp	x8, x20, [sp, #0x8]
    13b4:      	mov	w8, #0x2                // =2
    13b8:      	add	x2, sp, #0x8
    13bc:      	mov	w3, wzr
    13c0:      	ldr	x0, [x0]
    13c4:      	blr	x8
    13c8:      	mov	w8, #0xc                // =12
    13cc:      	adrp	x1, 0x1000 <cil_to_netdev+0x4e0>
    13d0:      	mov	x0, x19
    13d4:      	ldr	x1, [x1]
    13d8:      	mov	w2, #0x1                // =1
    13dc:      	blr	x8
    13e0:      	mov	w0, #0x2                // =2
    13e4:      	ldp	x20, x19, [sp, #0x60]
    13e8:      	ldp	x22, x21, [sp, #0x50]
    13ec:      	ldp	x24, x23, [sp, #0x40]
    13f0:      	ldp	x30, x25, [sp, #0x30]
    13f4:      	add	sp, sp, #0x70
    13f8:      	ret
    13fc:      	ldrb	w9, [x10]
    1400:      	and	w10, w9, #0xe
    1404:      	cmp	w10, #0x6
    1408:      	b.lo	0x15e8 <cil_to_host+0x588>
    140c:      	ldrb	w21, [x8]
    1410:      	ubfiz	w25, w9, #2, #4
    1414:      	cbz	w25, 0x15e8 <cil_to_host+0x588>
    1418:      	mov	w8, #0x1a               // =26
    141c:      	add	w20, w21, #0x14
    1420:      	add	x2, sp, #0x28
    1424:      	mov	x0, x19
    1428:      	mov	w3, #0x1                // =1
    142c:      	mov	w1, w20
    1430:      	blr	x8
    1434:      	tbnz	w0, #0x1f, 0x10f0 <cil_to_host+0x90>
    1438:      	ldrb	w8, [sp, #0x28]
    143c:      	cbz	w8, 0x15e8 <cil_to_host+0x588>
    1440:      	cmp	w8, #0x1
    1444:      	b.ne	0x1450 <cil_to_host+0x3f0>
    1448:      	add	w21, w21, #0x15
    144c:      	b	0x14c4 <cil_to_host+0x464>
    1450:      	mov	w8, #0x1a               // =26
    1454:      	add	w1, w21, #0x15
    1458:      	add	x2, sp, #0x24
    145c:      	mov	x0, x19
    1460:      	mov	w3, #0x1                // =1
    1464:      	blr	x8
    1468:      	tbnz	w0, #0x1f, 0x10f0 <cil_to_host+0x90>
    146c:      	ldrb	w8, [sp, #0x28]
    1470:      	cmp	w8, w24
    1474:      	b.ne	0x14bc <cil_to_host+0x45c>
    1478:      	ldrb	w8, [sp, #0x24]
    147c:      	cmp	w8, #0xa
    1480:      	b.eq	0x1558 <cil_to_host+0x4f8>
    1484:      	cmp	w8, #0x6
    1488:      	b.eq	0x152c <cil_to_host+0x4cc>
    148c:      	cmp	w8, #0x4
    1490:      	b.ne	0x10f0 <cil_to_host+0x90>
    1494:      	mov	w8, #0x1a               // =26
    1498:      	add	w1, w20, #0x2
    149c:      	add	x2, sp, #0x8
    14a0:      	mov	x0, x19
    14a4:      	mov	w3, #0x2                // =2
    14a8:      	blr	x8
    14ac:      	ldrh	w8, [sp, #0x8]
    14b0:      	rev	w8, w8
    14b4:      	lsr	w8, w8, #16
    14b8:      	b	0x1578 <cil_to_host+0x518>
    14bc:      	ldrb	w8, [sp, #0x24]
    14c0:      	add	w21, w20, w8
    14c4:      	add	w25, w20, w25
    14c8:      	cmp	w21, w25
    14cc:      	b.hs	0x15e8 <cil_to_host+0x588>
    14d0:      	mov	w8, #0x1a               // =26
    14d4:      	add	x2, sp, #0x28
    14d8:      	mov	x0, x19
    14dc:      	mov	w1, w21
    14e0:      	mov	w3, #0x1                // =1
    14e4:      	blr	x8
    14e8:      	tbnz	w0, #0x1f, 0x10f0 <cil_to_host+0x90>
    14ec:      	ldrb	w8, [sp, #0x28]
    14f0:      	cbz	w8, 0x15e8 <cil_to_host+0x588>
    14f4:      	cmp	w8, #0x1
    14f8:      	b.eq	0x158c <cil_to_host+0x52c>
    14fc:      	mov	w8, #0x1a               // =26
    1500:      	add	w1, w21, #0x1
    1504:      	add	x2, sp, #0x24
    1508:      	mov	x0, x19
    150c:      	mov	w3, #0x1                // =1
    1510:      	blr	x8
    1514:      	tbnz	w0, #0x1f, 0x10f0 <cil_to_host+0x90>
    1518:      	ldrb	w8, [sp, #0x28]
    151c:      	cmp	w8, w24
    1520:      	b.ne	0x1588 <cil_to_host+0x528>
    1524:      	mov	w20, w21
    1528:      	b	0x1478 <cil_to_host+0x418>
    152c:      	mov	w8, #0x1a               // =26
    1530:      	add	w1, w20, #0x2
    1534:      	add	x2, sp, #0x8
    1538:      	mov	x0, x19
    153c:      	mov	w3, #0x4                // =4
    1540:      	blr	x8
    1544:      	ldr	w8, [sp, #0x8]
    1548:      	cmp	w0, #0x0
    154c:      	rev	w8, w8
    1550:      	csel	w20, wzr, w8, lt
    1554:      	b	0x1580 <cil_to_host+0x520>
    1558:      	mov	w8, #0x1a               // =26
    155c:      	add	w1, w20, #0x2
    1560:      	add	x2, sp, #0x8
    1564:      	mov	x0, x19
    1568:      	mov	w3, #0x8                // =8
    156c:      	blr	x8
    1570:      	ldr	x8, [sp, #0x8]
    1574:      	rev	x8, x8
    1578:      	cmp	w0, #0x0
    157c:      	csel	x20, xzr, x8, lt
    1580:      	tbz	w0, #0x1f, 0x15ec <cil_to_host+0x58c>
    1584:      	b	0x10f0 <cil_to_host+0x90>
    1588:      	ldrb	w8, [sp, #0x24]
    158c:      	add	w20, w21, w8
    1590:      	cmp	w20, w25
    1594:      	b.hs	0x15e8 <cil_to_host+0x588>
    1598:      	mov	w8, #0x1a               // =26
    159c:      	add	x2, sp, #0x28
    15a0:      	mov	x0, x19
    15a4:      	mov	w1, w20
    15a8:      	mov	w3, #0x1                // =1
    15ac:      	blr	x8
    15b0:      	tbnz	w0, #0x1f, 0x10f0 <cil_to_host+0x90>
    15b4:      	ldrb	w8, [sp, #0x28]
    15b8:      	cmp	w8, #0x2
    15bc:      	b.lo	0x15e8 <cil_to_host+0x588>
    15c0:      	mov	w8, #0x1a               // =26
    15c4:      	add	w1, w20, #0x1
    15c8:      	add	x2, sp, #0x24
    15cc:      	mov	x0, x19
    15d0:      	mov	w3, #0x1                // =1
    15d4:      	blr	x8
    15d8:      	tbnz	w0, #0x1f, 0x10f0 <cil_to_host+0x90>
    15dc:      	ldrb	w8, [sp, #0x28]
    15e0:      	cmp	w8, w24
    15e4:      	b.eq	0x1478 <cil_to_host+0x418>
    15e8:      	mov	x20, xzr
    15ec:      	str	wzr, [sp, #0x8]
    15f0:      	mov	w8, #0x1                // =1
    15f4:      	adrp	x0, 0x1000 <cil_to_netdev+0x4e0>
    15f8:      	add	x1, sp, #0x8
    15fc:      	ldr	x0, [x0]
    1600:      	blr	x8
    1604:      	cbz	x0, 0x1110 <cil_to_host+0xb0>
    1608:      	str	x20, [x0]
    160c:      	b	0x1110 <cil_to_host+0xb0>

0000000000001610 <cil_host_policy>:
    1610:      	mov	w0, wzr
    1614:      	ret
