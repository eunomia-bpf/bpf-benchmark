
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_tracepoint_v511.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	cbz	x2, 0x8c <native_bpf_strncasestr+0x8c>
       4:      	mov	x8, x0
       8:      	mov	x0, xzr
       c:      	mov	x9, x2
      10:      	b	0x34 <native_bpf_strncasestr+0x34>
      14:      	nop
      18:      	nop
      1c:      	nop
      20:      	add	x0, x0, #0x1
      24:      	sub	x9, x9, #0x1
      28:      	add	x8, x8, #0x1
      2c:      	cmp	x0, x2
      30:      	b.eq	0x8c <native_bpf_strncasestr+0x8c>
      34:      	mov	x10, xzr
      38:      	nop
      3c:      	nop
      40:      	cmp	x9, x10
      44:      	b.eq	0x20 <native_bpf_strncasestr+0x20>
      48:      	ldrb	w11, [x1, x10]
      4c:      	cbz	w11, 0x90 <native_bpf_strncasestr+0x90>
      50:      	ldrb	w12, [x8, x10]
      54:      	sub	w13, w12, #0x41
      58:      	orr	w14, w12, #0x20
      5c:      	cmp	w13, #0x1a
      60:      	sub	w13, w11, #0x41
      64:      	csel	w12, w14, w12, lo
      68:      	orr	w14, w11, #0x20
      6c:      	cmp	w13, #0x1a
      70:      	csel	w11, w14, w11, lo
      74:      	cmp	w12, w11
      78:      	b.ne	0x20 <native_bpf_strncasestr+0x20>
      7c:      	cmp	x10, #0x63
      80:      	add	x10, x10, #0x1
      84:      	b.lo	0x40 <native_bpf_strncasestr+0x40>
      88:      	b	0x20 <native_bpf_strncasestr+0x20>
      8c:      	mov	w0, #-0x1               // =-1
      90:      	ret

Disassembly of section tracepoint:

0000000000000000 <generic_tracepoint_process_event>:
       0:      	sub	sp, sp, #0x150
       4:      	str	x29, [sp, #0x100]
       8:      	stp	x30, x25, [sp, #0x110]
       c:      	stp	x24, x23, [sp, #0x120]
      10:      	stp	x22, x21, [sp, #0x130]
      14:      	stp	x20, x19, [sp, #0x140]
      18:      	str	wzr, [sp, #0x4c]
      1c:      	adrp	x21, 0x0 <generic_tracepoint_process_event>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x4c
      28:      	ldr	x21, [x21]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x4c
      34:      	mov	x0, x21
      38:      	blr	x8
      3c:      	cbz	x0, 0x974 <generic_tracepoint_process_event+0x974>
      40:      	ldr	w23, [x0, #0x4]
      44:      	mov	w25, #0x5efc            // =24316
      48:      	mov	x20, x0
      4c:      	ldr	w29, [x0, x25]
      50:      	lsr	w8, w23, #3
      54:      	cmp	w8, #0x464
      58:      	b.hi	0x8d8 <generic_tracepoint_process_event+0x8d8>
      5c:      	str	wzr, [sp, #0x58]
      60:      	mov	w8, #0x1                // =1
      64:      	add	x9, sp, #0x58
      68:      	add	x1, sp, #0x58
      6c:      	mov	x0, x21
      70:      	blr	x8
      74:      	cbz	x0, 0x8d8 <generic_tracepoint_process_event+0x8d8>
      78:      	mov	w8, #0x5ef8             // =24312
      7c:      	mov	x22, x0
      80:      	add	x1, x0, x8
      84:      	adrp	x0, 0x0 <generic_tracepoint_process_event>
      88:      	mov	w8, #0x1                // =1
      8c:      	ldr	x0, [x0]
      90:      	blr	x8
      94:      	cmp	w29, #0x4
      98:      	ccmp	x0, #0x0, #0x4, le
      9c:      	b.eq	0x8d8 <generic_tracepoint_process_event+0x8d8>
      a0:      	and	x24, x29, #0x7
      a4:      	str	x23, [sp, #0x108]
      a8:      	add	x8, x0, x24, lsl #2
      ac:      	add	x10, x22, x24, lsl #2
      b0:      	ldr	w23, [x8, #0x4]
      b4:      	ldrsw	x9, [x8, #0x18]
      b8:      	mov	w8, #0x5ea0             // =24224
      bc:      	str	wzr, [x10, x8]
      c0:      	add	x8, x22, x24, lsl #3
      c4:      	ldr	x8, [x8, #0x5e50]
      c8:      	str	x9, [sp, #0x38]
      cc:      	str	x8, [sp, #0x50]
      d0:      	tbnz	w9, #0x8, 0x3bc <generic_tracepoint_process_event+0x3bc>
      d4:      	cmp	w24, #0x4
      d8:      	b.hi	0x3c0 <generic_tracepoint_process_event+0x3c0>
      dc:      	mov	w9, #0x50               // =80
      e0:      	umaddl	x22, w24, w9, x0
      e4:      	ldrh	w9, [x22, #0x76]
      e8:      	cbz	w9, 0x3c0 <generic_tracepoint_process_event+0x3c0>
      ec:      	str	x10, [sp, #0x40]
      f0:      	adrp	x9, 0x0 <generic_tracepoint_process_event>
      f4:      	ldr	x9, [x9]
      f8:      	ldrb	w10, [x9]
      fc:      	ldur	w9, [x22, #0x70]
     100:      	add	x8, x8, x9
     104:      	str	x8, [sp, #0x50]
     108:      	ldurh	w9, [x22, #0x74]
     10c:      	cbz	w10, 0x500 <generic_tracepoint_process_event+0x500>
     110:      	cbz	w9, 0x134 <generic_tracepoint_process_event+0x134>
     114:      	mov	w9, #0x8                // =8
     118:      	mov	w10, #0x4               // =4
     11c:      	add	x11, sp, #0x50
     120:      	ldr	x2, [sp, #0x50]
     124:      	add	x0, sp, #0x50
     128:      	mov	w1, #0x8                // =8
     12c:      	blr	x10
     130:      	tbnz	w0, #0x1f, 0x824 <generic_tracepoint_process_event+0x824>
     134:      	ldurh	w8, [x22, #0x7e]
     138:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     13c:      	ldr	x8, [sp, #0x50]
     140:      	ldur	w9, [x22, #0x78]
     144:      	add	x8, x8, x9
     148:      	str	x8, [sp, #0x50]
     14c:      	ldurh	w9, [x22, #0x7c]
     150:      	cbz	w9, 0x17c <generic_tracepoint_process_event+0x17c>
     154:      	mov	w9, #0x8                // =8
     158:      	mov	w10, #0x4               // =4
     15c:      	add	x11, sp, #0x50
     160:      	ldr	x2, [sp, #0x50]
     164:      	add	x0, sp, #0x50
     168:      	mov	w1, #0x8                // =8
     16c:      	blr	x10
     170:      	ldr	x8, [sp, #0x40]
     174:      	mov	w9, #0x5ea0             // =24224
     178:      	tbnz	w0, #0x1f, 0x112c <generic_tracepoint_process_event+0x112c>
     17c:      	ldurh	w8, [x22, #0x86]
     180:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     184:      	ldr	x8, [sp, #0x50]
     188:      	ldur	w9, [x22, #0x80]
     18c:      	add	x8, x8, x9
     190:      	str	x8, [sp, #0x50]
     194:      	ldurh	w9, [x22, #0x84]
     198:      	cbz	w9, 0x1c4 <generic_tracepoint_process_event+0x1c4>
     19c:      	mov	w9, #0x8                // =8
     1a0:      	mov	w10, #0x4               // =4
     1a4:      	add	x11, sp, #0x50
     1a8:      	ldr	x2, [sp, #0x50]
     1ac:      	add	x0, sp, #0x50
     1b0:      	mov	w1, #0x8                // =8
     1b4:      	blr	x10
     1b8:      	ldr	x8, [sp, #0x40]
     1bc:      	mov	w9, #0x5ea0             // =24224
     1c0:      	tbnz	w0, #0x1f, 0x11a8 <generic_tracepoint_process_event+0x11a8>
     1c4:      	ldurh	w8, [x22, #0x8e]
     1c8:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     1cc:      	ldr	x8, [sp, #0x50]
     1d0:      	ldur	w9, [x22, #0x88]
     1d4:      	add	x8, x8, x9
     1d8:      	str	x29, [sp, #0x30]
     1dc:      	str	x8, [sp, #0x50]
     1e0:      	ldurh	w9, [x22, #0x8c]
     1e4:      	cbz	w9, 0x214 <generic_tracepoint_process_event+0x214>
     1e8:      	mov	w9, #0x8                // =8
     1ec:      	add	x10, sp, #0x50
     1f0:      	mov	w11, #0x4               // =4
     1f4:      	ldr	x2, [sp, #0x50]
     1f8:      	add	x0, sp, #0x50
     1fc:      	mov	w1, #0x8                // =8
     200:      	mov	w29, #0x4               // =4
     204:      	blr	x11
     208:      	ldr	x8, [sp, #0x40]
     20c:      	mov	w9, #0x5ea0             // =24224
     210:      	tbnz	w0, #0x1f, 0x11b0 <generic_tracepoint_process_event+0x11b0>
     214:      	ldurh	w8, [x22, #0x96]
     218:      	ldr	x29, [sp, #0x30]
     21c:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     220:      	ldr	x8, [sp, #0x50]
     224:      	ldur	w9, [x22, #0x90]
     228:      	add	x8, x8, x9
     22c:      	str	x8, [sp, #0x50]
     230:      	ldurh	w9, [x22, #0x94]
     234:      	cbz	w9, 0x260 <generic_tracepoint_process_event+0x260>
     238:      	mov	w9, #0x8                // =8
     23c:      	mov	w10, #0x4               // =4
     240:      	add	x11, sp, #0x50
     244:      	ldr	x2, [sp, #0x50]
     248:      	add	x0, sp, #0x50
     24c:      	mov	w1, #0x8                // =8
     250:      	blr	x10
     254:      	ldr	x8, [sp, #0x40]
     258:      	mov	w9, #0x5ea0             // =24224
     25c:      	tbnz	w0, #0x1f, 0x155c <generic_tracepoint_process_event+0x155c>
     260:      	ldurh	w8, [x22, #0x9e]
     264:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     268:      	ldr	x8, [sp, #0x50]
     26c:      	ldur	w9, [x22, #0x98]
     270:      	add	x8, x8, x9
     274:      	str	x8, [sp, #0x50]
     278:      	ldurh	w9, [x22, #0x9c]
     27c:      	cbz	w9, 0x2a0 <generic_tracepoint_process_event+0x2a0>
     280:      	mov	w9, #0x8                // =8
     284:      	mov	w10, #0x4               // =4
     288:      	add	x11, sp, #0x50
     28c:      	ldr	x2, [sp, #0x50]
     290:      	add	x0, sp, #0x50
     294:      	mov	w1, #0x8                // =8
     298:      	blr	x10
     29c:      	tbnz	w0, #0x1f, 0x1bcc <generic_tracepoint_process_event+0x1bcc>
     2a0:      	ldurh	w8, [x22, #0xa6]
     2a4:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     2a8:      	ldr	x8, [sp, #0x50]
     2ac:      	ldur	w9, [x22, #0xa0]
     2b0:      	add	x8, x8, x9
     2b4:      	str	x8, [sp, #0x50]
     2b8:      	ldurh	w9, [x22, #0xa4]
     2bc:      	cbz	w9, 0x2e0 <generic_tracepoint_process_event+0x2e0>
     2c0:      	mov	w9, #0x8                // =8
     2c4:      	mov	w10, #0x4               // =4
     2c8:      	add	x11, sp, #0x50
     2cc:      	ldr	x2, [sp, #0x50]
     2d0:      	add	x0, sp, #0x50
     2d4:      	mov	w1, #0x8                // =8
     2d8:      	blr	x10
     2dc:      	tbnz	w0, #0x1f, 0x2048 <generic_tracepoint_process_event+0x2048>
     2e0:      	adrp	x21, 0x0 <generic_tracepoint_process_event>
     2e4:      	ldurh	w8, [x22, #0xae]
     2e8:      	ldr	x29, [sp, #0x30]
     2ec:      	mov	w25, #0x5efc            // =24316
     2f0:      	ldr	x21, [x21]
     2f4:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     2f8:      	ldr	x8, [sp, #0x50]
     2fc:      	ldur	w9, [x22, #0xa8]
     300:      	add	x8, x8, x9
     304:      	str	x8, [sp, #0x50]
     308:      	ldurh	w9, [x22, #0xac]
     30c:      	cbz	w9, 0x338 <generic_tracepoint_process_event+0x338>
     310:      	mov	w29, #0x8               // =8
     314:      	mov	w9, #0x4                // =4
     318:      	add	x10, sp, #0x50
     31c:      	ldr	x2, [sp, #0x50]
     320:      	add	x0, sp, #0x50
     324:      	mov	w1, #0x8                // =8
     328:      	blr	x9
     32c:      	ldr	x8, [sp, #0x40]
     330:      	mov	w9, #0x5ea0             // =24224
     334:      	tbnz	w0, #0x1f, 0x11b0 <generic_tracepoint_process_event+0x11b0>
     338:      	ldurh	w8, [x22, #0xb6]
     33c:      	ldr	x29, [sp, #0x30]
     340:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     344:      	ldr	x8, [sp, #0x50]
     348:      	ldur	w9, [x22, #0xb0]
     34c:      	add	x8, x8, x9
     350:      	str	x8, [sp, #0x50]
     354:      	ldurh	w9, [x22, #0xb4]
     358:      	cbz	w9, 0x37c <generic_tracepoint_process_event+0x37c>
     35c:      	mov	w9, #0x8                // =8
     360:      	mov	w10, #0x4               // =4
     364:      	add	x11, sp, #0x50
     368:      	ldr	x2, [sp, #0x50]
     36c:      	add	x0, sp, #0x50
     370:      	mov	w1, #0x8                // =8
     374:      	blr	x10
     378:      	tbnz	w0, #0x1f, 0x2564 <generic_tracepoint_process_event+0x2564>
     37c:      	adrp	x21, 0x0 <generic_tracepoint_process_event>
     380:      	ldurh	w8, [x22, #0xbe]
     384:      	ldr	x29, [sp, #0x30]
     388:      	mov	w25, #0x5efc            // =24316
     38c:      	ldr	x21, [x21]
     390:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     394:      	ldr	x8, [sp, #0x50]
     398:      	ldur	w9, [x22, #0xb8]
     39c:      	add	x8, x8, x9
     3a0:      	str	x8, [sp, #0x50]
     3a4:      	ldurh	w9, [x22, #0xbc]
     3a8:      	cbz	w9, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     3ac:      	mov	w9, #0x8                // =8
     3b0:      	mov	w10, #0x4               // =4
     3b4:      	add	x11, sp, #0x50
     3b8:      	b	0x7ac <generic_tracepoint_process_event+0x7ac>
     3bc:      	str	xzr, [sp, #0x50]
     3c0:      	ldr	x9, [sp, #0x50]
     3c4:      	mov	w22, #0x1000            // =4096
     3c8:      	cmp	w23, #0x15
     3cc:      	b.gt	0x400 <generic_tracepoint_process_event+0x400>
     3d0:      	cmp	w23, #0xb
     3d4:      	b.gt	0x430 <generic_tracepoint_process_event+0x430>
     3d8:      	cmp	w23, #0x5
     3dc:      	b.gt	0x4a0 <generic_tracepoint_process_event+0x4a0>
     3e0:      	cmp	w23, #0x3
     3e4:      	b.gt	0x804 <generic_tracepoint_process_event+0x804>
     3e8:      	sub	w8, w23, #0x2
     3ec:      	cmp	w8, #0x2
     3f0:      	b.lo	0x4f0 <generic_tracepoint_process_event+0x4f0>
     3f4:      	cmp	w23, #0x1
     3f8:      	b.eq	0x4f0 <generic_tracepoint_process_event+0x4f0>
     3fc:      	b	0x850 <generic_tracepoint_process_event+0x850>
     400:      	cmp	w23, #0x20
     404:      	b.le	0x454 <generic_tracepoint_process_event+0x454>
     408:      	cmp	w23, #0x27
     40c:      	b.gt	0x478 <generic_tracepoint_process_event+0x478>
     410:      	sub	w8, w23, #0x21
     414:      	cmp	w8, #0x4
     418:      	b.lo	0x81c <generic_tracepoint_process_event+0x81c>
     41c:      	cmp	w23, #0x25
     420:      	b.eq	0x854 <generic_tracepoint_process_event+0x854>
     424:      	cmp	w23, #0x27
     428:      	b.eq	0x4f8 <generic_tracepoint_process_event+0x4f8>
     42c:      	b	0x850 <generic_tracepoint_process_event+0x850>
     430:      	cmp	w23, #0x11
     434:      	b.gt	0x4c4 <generic_tracepoint_process_event+0x4c4>
     438:      	sub	w8, w23, #0xf
     43c:      	cmp	w8, #0x3
     440:      	b.lo	0x854 <generic_tracepoint_process_event+0x854>
     444:      	sub	w8, w23, #0xc
     448:      	cmp	w8, #0x2
     44c:      	b.lo	0x4f0 <generic_tracepoint_process_event+0x4f0>
     450:      	b	0x850 <generic_tracepoint_process_event+0x850>
     454:      	cmp	w23, #0x1a
     458:      	b.gt	0x4e4 <generic_tracepoint_process_event+0x4e4>
     45c:      	cmp	w23, #0x16
     460:      	b.eq	0x4f8 <generic_tracepoint_process_event+0x4f8>
     464:      	cmp	w23, #0x17
     468:      	b.eq	0x81c <generic_tracepoint_process_event+0x81c>
     46c:      	cmp	w23, #0x1a
     470:      	b.eq	0x848 <generic_tracepoint_process_event+0x848>
     474:      	b	0x850 <generic_tracepoint_process_event+0x850>
     478:      	cmp	w23, #0x29
     47c:      	b.le	0x7e8 <generic_tracepoint_process_event+0x7e8>
     480:      	cmp	w23, #0x2a
     484:      	b.eq	0x854 <generic_tracepoint_process_event+0x854>
     488:      	cmp	w23, #0x2b
     48c:      	b.eq	0x7fc <generic_tracepoint_process_event+0x7fc>
     490:      	cmp	w23, #0x2c
     494:      	b.ne	0x850 <generic_tracepoint_process_event+0x850>
     498:      	mov	w22, #0x70              // =112
     49c:      	b	0x854 <generic_tracepoint_process_event+0x854>
     4a0:      	cmp	w23, #0x9
     4a4:      	b.gt	0x81c <generic_tracepoint_process_event+0x81c>
     4a8:      	cmp	w23, #0x6
     4ac:      	b.eq	0x854 <generic_tracepoint_process_event+0x854>
     4b0:      	cmp	w23, #0x7
     4b4:      	b.eq	0x814 <generic_tracepoint_process_event+0x814>
     4b8:      	cmp	w23, #0x8
     4bc:      	b.eq	0x848 <generic_tracepoint_process_event+0x848>
     4c0:      	b	0x850 <generic_tracepoint_process_event+0x850>
     4c4:      	cmp	w23, #0x13
     4c8:      	b.gt	0x7d0 <generic_tracepoint_process_event+0x7d0>
     4cc:      	ldr	x22, [sp, #0x38]
     4d0:      	cmp	w23, #0x12
     4d4:      	b.eq	0x854 <generic_tracepoint_process_event+0x854>
     4d8:      	cmp	w23, #0x13
     4dc:      	b.eq	0x7fc <generic_tracepoint_process_event+0x7fc>
     4e0:      	b	0x850 <generic_tracepoint_process_event+0x850>
     4e4:      	sub	w8, w23, #0x1d
     4e8:      	cmp	w8, #0x4
     4ec:      	b.hs	0x840 <generic_tracepoint_process_event+0x840>
     4f0:      	mov	w22, #0x4               // =4
     4f4:      	b	0x854 <generic_tracepoint_process_event+0x854>
     4f8:      	mov	w22, #0x10              // =16
     4fc:      	b	0x854 <generic_tracepoint_process_event+0x854>
     500:      	cbz	w9, 0x524 <generic_tracepoint_process_event+0x524>
     504:      	mov	w9, #0x8                // =8
     508:      	mov	w10, #0x4               // =4
     50c:      	add	x11, sp, #0x50
     510:      	ldr	x2, [sp, #0x50]
     514:      	add	x0, sp, #0x50
     518:      	mov	w1, #0x8                // =8
     51c:      	blr	x10
     520:      	tbnz	w0, #0x1f, 0x824 <generic_tracepoint_process_event+0x824>
     524:      	ldurh	w8, [x22, #0x7e]
     528:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     52c:      	ldr	x8, [sp, #0x50]
     530:      	ldur	w9, [x22, #0x78]
     534:      	add	x8, x8, x9
     538:      	str	x8, [sp, #0x50]
     53c:      	ldurh	w9, [x22, #0x7c]
     540:      	cbz	w9, 0x56c <generic_tracepoint_process_event+0x56c>
     544:      	mov	w9, #0x8                // =8
     548:      	mov	w10, #0x4               // =4
     54c:      	add	x11, sp, #0x50
     550:      	ldr	x2, [sp, #0x50]
     554:      	add	x0, sp, #0x50
     558:      	mov	w1, #0x8                // =8
     55c:      	blr	x10
     560:      	ldr	x8, [sp, #0x40]
     564:      	mov	w9, #0x5ea0             // =24224
     568:      	tbnz	w0, #0x1f, 0x112c <generic_tracepoint_process_event+0x112c>
     56c:      	ldurh	w8, [x22, #0x86]
     570:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     574:      	ldr	x8, [sp, #0x50]
     578:      	ldur	w9, [x22, #0x80]
     57c:      	add	x8, x8, x9
     580:      	str	x8, [sp, #0x50]
     584:      	ldurh	w9, [x22, #0x84]
     588:      	cbz	w9, 0x5b4 <generic_tracepoint_process_event+0x5b4>
     58c:      	mov	w9, #0x8                // =8
     590:      	mov	w10, #0x4               // =4
     594:      	add	x11, sp, #0x50
     598:      	ldr	x2, [sp, #0x50]
     59c:      	add	x0, sp, #0x50
     5a0:      	mov	w1, #0x8                // =8
     5a4:      	blr	x10
     5a8:      	ldr	x8, [sp, #0x40]
     5ac:      	mov	w9, #0x5ea0             // =24224
     5b0:      	tbnz	w0, #0x1f, 0x11a8 <generic_tracepoint_process_event+0x11a8>
     5b4:      	ldurh	w8, [x22, #0x8e]
     5b8:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     5bc:      	ldr	x8, [sp, #0x50]
     5c0:      	ldur	w9, [x22, #0x88]
     5c4:      	add	x8, x8, x9
     5c8:      	str	x29, [sp, #0x30]
     5cc:      	str	x8, [sp, #0x50]
     5d0:      	ldurh	w9, [x22, #0x8c]
     5d4:      	cbz	w9, 0x604 <generic_tracepoint_process_event+0x604>
     5d8:      	mov	w9, #0x8                // =8
     5dc:      	add	x10, sp, #0x50
     5e0:      	mov	w11, #0x4               // =4
     5e4:      	ldr	x2, [sp, #0x50]
     5e8:      	add	x0, sp, #0x50
     5ec:      	mov	w1, #0x8                // =8
     5f0:      	mov	w29, #0x4               // =4
     5f4:      	blr	x11
     5f8:      	ldr	x8, [sp, #0x40]
     5fc:      	mov	w9, #0x5ea0             // =24224
     600:      	tbnz	w0, #0x1f, 0x11b0 <generic_tracepoint_process_event+0x11b0>
     604:      	ldurh	w8, [x22, #0x96]
     608:      	ldr	x29, [sp, #0x30]
     60c:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     610:      	ldr	x8, [sp, #0x50]
     614:      	ldur	w9, [x22, #0x90]
     618:      	add	x8, x8, x9
     61c:      	str	x8, [sp, #0x50]
     620:      	ldurh	w9, [x22, #0x94]
     624:      	cbz	w9, 0x650 <generic_tracepoint_process_event+0x650>
     628:      	mov	w9, #0x8                // =8
     62c:      	mov	w10, #0x4               // =4
     630:      	add	x11, sp, #0x50
     634:      	ldr	x2, [sp, #0x50]
     638:      	add	x0, sp, #0x50
     63c:      	mov	w1, #0x8                // =8
     640:      	blr	x10
     644:      	ldr	x8, [sp, #0x40]
     648:      	mov	w9, #0x5ea0             // =24224
     64c:      	tbnz	w0, #0x1f, 0x155c <generic_tracepoint_process_event+0x155c>
     650:      	ldurh	w8, [x22, #0x9e]
     654:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     658:      	ldr	x8, [sp, #0x50]
     65c:      	ldur	w9, [x22, #0x98]
     660:      	add	x8, x8, x9
     664:      	str	x8, [sp, #0x50]
     668:      	ldurh	w9, [x22, #0x9c]
     66c:      	cbz	w9, 0x690 <generic_tracepoint_process_event+0x690>
     670:      	mov	w9, #0x8                // =8
     674:      	mov	w10, #0x4               // =4
     678:      	add	x11, sp, #0x50
     67c:      	ldr	x2, [sp, #0x50]
     680:      	add	x0, sp, #0x50
     684:      	mov	w1, #0x8                // =8
     688:      	blr	x10
     68c:      	tbnz	w0, #0x1f, 0x1bcc <generic_tracepoint_process_event+0x1bcc>
     690:      	ldurh	w8, [x22, #0xa6]
     694:      	ldr	x29, [sp, #0x30]
     698:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     69c:      	ldr	x8, [sp, #0x50]
     6a0:      	ldur	w9, [x22, #0xa0]
     6a4:      	add	x8, x8, x9
     6a8:      	str	x8, [sp, #0x50]
     6ac:      	ldurh	w9, [x22, #0xa4]
     6b0:      	cbz	w9, 0x6d4 <generic_tracepoint_process_event+0x6d4>
     6b4:      	mov	w9, #0x8                // =8
     6b8:      	mov	w10, #0x4               // =4
     6bc:      	add	x11, sp, #0x50
     6c0:      	ldr	x2, [sp, #0x50]
     6c4:      	add	x0, sp, #0x50
     6c8:      	mov	w1, #0x8                // =8
     6cc:      	blr	x10
     6d0:      	tbnz	w0, #0x1f, 0x2048 <generic_tracepoint_process_event+0x2048>
     6d4:      	adrp	x21, 0x0 <generic_tracepoint_process_event>
     6d8:      	ldurh	w8, [x22, #0xae]
     6dc:      	ldr	x29, [sp, #0x30]
     6e0:      	mov	w25, #0x5efc            // =24316
     6e4:      	ldr	x21, [x21]
     6e8:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     6ec:      	ldr	x8, [sp, #0x50]
     6f0:      	ldur	w9, [x22, #0xa8]
     6f4:      	add	x8, x8, x9
     6f8:      	str	x8, [sp, #0x50]
     6fc:      	ldurh	w9, [x22, #0xac]
     700:      	cbz	w9, 0x72c <generic_tracepoint_process_event+0x72c>
     704:      	mov	w29, #0x8               // =8
     708:      	mov	w9, #0x4                // =4
     70c:      	add	x10, sp, #0x50
     710:      	ldr	x2, [sp, #0x50]
     714:      	add	x0, sp, #0x50
     718:      	mov	w1, #0x8                // =8
     71c:      	blr	x9
     720:      	ldr	x8, [sp, #0x40]
     724:      	mov	w9, #0x5ea0             // =24224
     728:      	tbnz	w0, #0x1f, 0x11b0 <generic_tracepoint_process_event+0x11b0>
     72c:      	ldurh	w8, [x22, #0xb6]
     730:      	ldr	x29, [sp, #0x30]
     734:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     738:      	ldr	x8, [sp, #0x50]
     73c:      	ldur	w9, [x22, #0xb0]
     740:      	add	x8, x8, x9
     744:      	str	x8, [sp, #0x50]
     748:      	ldurh	w9, [x22, #0xb4]
     74c:      	cbz	w9, 0x770 <generic_tracepoint_process_event+0x770>
     750:      	mov	w9, #0x8                // =8
     754:      	mov	w10, #0x4               // =4
     758:      	add	x11, sp, #0x50
     75c:      	ldr	x2, [sp, #0x50]
     760:      	add	x0, sp, #0x50
     764:      	mov	w1, #0x8                // =8
     768:      	blr	x10
     76c:      	tbnz	w0, #0x1f, 0x2564 <generic_tracepoint_process_event+0x2564>
     770:      	adrp	x21, 0x0 <generic_tracepoint_process_event>
     774:      	ldurh	w8, [x22, #0xbe]
     778:      	ldr	x29, [sp, #0x30]
     77c:      	mov	w25, #0x5efc            // =24316
     780:      	ldr	x21, [x21]
     784:      	cbz	w8, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     788:      	ldr	x8, [sp, #0x50]
     78c:      	ldur	w9, [x22, #0xb8]
     790:      	add	x8, x8, x9
     794:      	str	x8, [sp, #0x50]
     798:      	ldurh	w9, [x22, #0xbc]
     79c:      	cbz	w9, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     7a0:      	mov	w9, #0x8                // =8
     7a4:      	mov	w10, #0x4               // =4
     7a8:      	add	x11, sp, #0x50
     7ac:      	ldr	x2, [sp, #0x50]
     7b0:      	add	x0, sp, #0x50
     7b4:      	mov	w1, #0x8                // =8
     7b8:      	blr	x10
     7bc:      	ldr	x8, [sp, #0x40]
     7c0:      	mov	w9, #0x5ea0             // =24224
     7c4:      	tbz	w0, #0x1f, 0x3c0 <generic_tracepoint_process_event+0x3c0>
     7c8:      	mov	w29, #0xa               // =10
     7cc:      	b	0x11b0 <generic_tracepoint_process_event+0x11b0>
     7d0:      	cmp	w23, #0x14
     7d4:      	b.eq	0x838 <generic_tracepoint_process_event+0x838>
     7d8:      	cmp	w23, #0x15
     7dc:      	b.ne	0x850 <generic_tracepoint_process_event+0x850>
     7e0:      	mov	w22, #0x20              // =32
     7e4:      	b	0x854 <generic_tracepoint_process_event+0x854>
     7e8:      	cmp	w23, #0x28
     7ec:      	b.eq	0x7fc <generic_tracepoint_process_event+0x7fc>
     7f0:      	cmp	w23, #0x29
     7f4:      	b.eq	0x814 <generic_tracepoint_process_event+0x814>
     7f8:      	b	0x850 <generic_tracepoint_process_event+0x850>
     7fc:      	mov	w22, #0x18              // =24
     800:      	b	0x854 <generic_tracepoint_process_event+0x854>
     804:      	cmp	w23, #0x4
     808:      	b.eq	0x81c <generic_tracepoint_process_event+0x81c>
     80c:      	cmp	w23, #0x5
     810:      	b.ne	0x850 <generic_tracepoint_process_event+0x850>
     814:      	mov	w22, #0x40              // =64
     818:      	b	0x854 <generic_tracepoint_process_event+0x854>
     81c:      	mov	w22, #0x8               // =8
     820:      	b	0x854 <generic_tracepoint_process_event+0x854>
     824:      	str	x29, [sp, #0x30]
     828:      	mov	w29, #0x1               // =1
     82c:      	ldr	x8, [sp, #0x40]
     830:      	mov	w9, #0x5ea0             // =24224
     834:      	b	0x11b0 <generic_tracepoint_process_event+0x11b0>
     838:      	mov	w22, #0x98              // =152
     83c:      	b	0x854 <generic_tracepoint_process_event+0x854>
     840:      	cmp	w23, #0x1b
     844:      	b.ne	0x850 <generic_tracepoint_process_event+0x850>
     848:      	mov	w22, #0x50              // =80
     84c:      	b	0x854 <generic_tracepoint_process_event+0x854>
     850:      	mov	x22, xzr
     854:      	str	x9, [sp, #0x40]
     858:      	str	wzr, [sp, #0x5c]
     85c:      	mov	w8, #0x1                // =1
     860:      	add	x9, sp, #0x5c
     864:      	add	x1, sp, #0x5c
     868:      	mov	x0, x21
     86c:      	blr	x8
     870:      	cbz	x0, 0x8d4 <generic_tracepoint_process_event+0x8d4>
     874:      	ldr	x9, [sp, #0x108]
     878:      	mov	w8, #0x3ffb             // =16379
     87c:      	sub	x8, x8, x22
     880:      	cmp	x8, x9
     884:      	b.ls	0x8d4 <generic_tracepoint_process_event+0x8d4>
     888:      	add	x10, x0, x24, lsl #2
     88c:      	mov	w8, #0x5ea0             // =24224
     890:      	ldr	x9, [sp, #0x108]
     894:      	add	x11, x0, #0x90
     898:      	ldr	w8, [x10, x8]
     89c:      	add	x22, x9, #0x4
     8a0:      	str	w8, [x11, x9]
     8a4:      	add	x9, x0, x24, lsl #3
     8a8:      	str	x22, [x9, #0x5e78]
     8ac:      	cbz	w8, 0x994 <generic_tracepoint_process_event+0x994>
     8b0:      	ldr	x23, [sp, #0x108]
     8b4:      	mov	w8, #0x4                // =4
     8b8:      	add	w23, w8, w23
     8bc:      	str	w23, [x20, #0x4]
     8c0:      	adrp	x22, 0x0 <generic_tracepoint_process_event>
     8c4:      	cmp	w29, #0x3
     8c8:      	ldr	x22, [x22]
     8cc:      	b.le	0x8ec <generic_tracepoint_process_event+0x8ec>
     8d0:      	b	0x958 <generic_tracepoint_process_event+0x958>
     8d4:      	ldr	x23, [sp, #0x108]
     8d8:      	str	w23, [x20, #0x4]
     8dc:      	adrp	x22, 0x0 <generic_tracepoint_process_event>
     8e0:      	cmp	w29, #0x3
     8e4:      	ldr	x22, [x22]
     8e8:      	b.gt	0x958 <generic_tracepoint_process_event+0x958>
     8ec:      	str	wzr, [sp, #0x88]
     8f0:      	mov	w8, #0x1                // =1
     8f4:      	add	x9, sp, #0x88
     8f8:      	add	x1, sp, #0x88
     8fc:      	mov	x0, x21
     900:      	blr	x8
     904:      	cbz	x0, 0x958 <generic_tracepoint_process_event+0x958>
     908:      	mov	w8, #0x5ef8             // =24312
     90c:      	add	x1, x0, x8
     910:      	adrp	x0, 0x0 <generic_tracepoint_process_event>
     914:      	mov	w8, #0x1                // =1
     918:      	ldr	x0, [x0]
     91c:      	blr	x8
     920:      	cbz	x0, 0x958 <generic_tracepoint_process_event+0x958>
     924:      	add	w8, w29, #0x1
     928:      	and	w9, w8, #0x7
     92c:      	add	x9, x0, w9, uxtw #2
     930:      	ldr	w9, [x9, #0x40]
     934:      	cmn	w9, #0x1
     938:      	b.eq	0x958 <generic_tracepoint_process_event+0x958>
     93c:      	str	w8, [x20, x25]
     940:      	mov	w8, #0x1                // =1
     944:      	mov	w9, #0xc                // =12
     948:      	mov	x0, x19
     94c:      	mov	x1, x22
     950:      	mov	w2, #0x1                // =1
     954:      	blr	x9
     958:      	str	wzr, [x20, x25]
     95c:      	mov	w8, #0x3                // =3
     960:      	mov	w9, #0xc                // =12
     964:      	mov	x0, x19
     968:      	mov	x1, x22
     96c:      	mov	w2, #0x3                // =3
     970:      	blr	x9
     974:      	ldp	x20, x19, [sp, #0x140]
     978:      	mov	w0, wzr
     97c:      	ldr	x29, [sp, #0x100]
     980:      	ldp	x22, x21, [sp, #0x130]
     984:      	ldp	x24, x23, [sp, #0x120]
     988:      	ldp	x30, x25, [sp, #0x110]
     98c:      	add	sp, sp, #0x150
     990:      	ret
     994:      	ldr	x12, [sp, #0x40]
     998:      	add	x9, sp, #0xd0
     99c:      	add	x8, x11, x22
     9a0:      	add	x24, sp, #0xd0
     9a4:      	str	x11, [sp, #0x20]
     9a8:      	str	xzr, [x9, #0x10]
     9ac:      	cmp	w23, #0x17
     9b0:      	stp	x8, x10, [sp, #0x10]
     9b4:      	str	x12, [sp, #0x88]
     9b8:      	b.le	0x9e4 <generic_tracepoint_process_event+0x9e4>
     9bc:      	cmp	w23, #0x18
     9c0:      	b.eq	0xa04 <generic_tracepoint_process_event+0xa04>
     9c4:      	cmp	w23, #0x25
     9c8:      	b.eq	0xa60 <generic_tracepoint_process_event+0xa60>
     9cc:      	cmp	w23, #0x2a
     9d0:      	b.ne	0x108c <generic_tracepoint_process_event+0x108c>
     9d4:      	add	x8, sp, #0x60
     9d8:      	stp	xzr, x12, [sp, #0x60]
     9dc:      	str	x8, [sp, #0x28]
     9e0:      	b	0xac0 <generic_tracepoint_process_event+0xac0>
     9e4:      	cmp	w23, #0xf
     9e8:      	b.eq	0xa94 <generic_tracepoint_process_event+0xa94>
     9ec:      	cmp	w23, #0x10
     9f0:      	b.ne	0x108c <generic_tracepoint_process_event+0x108c>
     9f4:      	mov	x23, x21
     9f8:      	add	x22, sp, #0xf0
     9fc:      	add	x21, sp, #0xd0
     a00:      	b	0xa30 <generic_tracepoint_process_event+0xa30>
     a04:      	add	x22, sp, #0xf0
     a08:      	mov	w8, #0x8                // =8
     a0c:      	mov	w9, #0x4                // =4
     a10:      	ldr	x2, [sp, #0x88]
     a14:      	add	x0, sp, #0xf0
     a18:      	mov	w1, #0x8                // =8
     a1c:      	mov	x23, x21
     a20:      	blr	x9
     a24:      	add	x21, sp, #0xd0
     a28:      	ldr	x8, [x21, #0x20]
     a2c:      	str	x8, [sp, #0x88]
     a30:      	mov	w8, #0x8                // =8
     a34:      	mov	w9, #0x4                // =4
     a38:      	add	x10, sp, #0x88
     a3c:      	add	x0, sp, #0xf0
     a40:      	add	x2, sp, #0x88
     a44:      	mov	w1, #0x8                // =8
     a48:      	blr	x9
     a4c:      	ldr	x8, [x21, #0x20]
     a50:      	mov	x21, x23
     a54:      	add	x8, x8, #0x40
     a58:      	str	x8, [sp, #0x28]
     a5c:      	b	0xac0 <generic_tracepoint_process_event+0xac0>
     a60:      	add	x8, x12, #0x40
     a64:      	mov	w9, #0x8                // =8
     a68:      	mov	w10, #0x4               // =4
     a6c:      	str	x8, [sp, #0x88]
     a70:      	add	x11, sp, #0xf0
     a74:      	add	x0, sp, #0xf0
     a78:      	mov	w1, #0x8                // =8
     a7c:      	ldr	x2, [sp, #0x88]
     a80:      	blr	x10
     a84:      	ldr	x8, [x24, #0x20]
     a88:      	add	x8, x8, #0x40
     a8c:      	str	x8, [sp, #0x28]
     a90:      	b	0xac0 <generic_tracepoint_process_event+0xac0>
     a94:      	mov	w8, #0x8                // =8
     a98:      	mov	w9, #0x4                // =4
     a9c:      	add	x10, sp, #0xe0
     aa0:      	add	x11, sp, #0x88
     aa4:      	add	x0, sp, #0xe0
     aa8:      	add	x2, sp, #0x88
     aac:      	mov	w1, #0x8                // =8
     ab0:      	blr	x9
     ab4:      	ldr	x8, [x24, #0x10]
     ab8:      	str	x8, [sp, #0x28]
     abc:      	cbz	x8, 0x1138 <generic_tracepoint_process_event+0x1138>
     ac0:      	str	wzr, [sp, #0x74]
     ac4:      	adrp	x0, 0x0 <generic_tracepoint_process_event>
     ac8:      	mov	w8, #0x1                // =1
     acc:      	add	x9, sp, #0x74
     ad0:      	ldr	x0, [x0]
     ad4:      	add	x1, sp, #0x74
     ad8:      	blr	x8
     adc:      	mov	x24, x0
     ae0:      	cbz	x0, 0x1124 <generic_tracepoint_process_event+0x1124>
     ae4:      	add	x8, x24, #0x1, lsl #12  // =0x1000
     ae8:      	stp	x29, x8, [sp, #0x30]
     aec:      	mov	w8, #0x23               // =35
     af0:      	blr	x8
     af4:      	add	x2, x0, #0xb30
     af8:      	mov	w25, #0x8               // =8
     afc:      	add	x8, sp, #0x78
     b00:      	mov	w9, #0x4                // =4
     b04:      	add	x0, sp, #0x78
     b08:      	mov	w1, #0x8                // =8
     b0c:      	mov	w29, #0x4               // =4
     b10:      	blr	x9
     b14:      	ldr	x8, [sp, #0x78]
     b18:      	mov	w9, #0x4                // =4
     b1c:      	add	x0, sp, #0x80
     b20:      	mov	w1, #0x8                // =8
     b24:      	str	x8, [sp, #0x8]
     b28:      	add	x8, x8, #0x18
     b2c:      	str	x8, [sp, #0x40]
     b30:      	ldr	x8, [sp, #0x28]
     b34:      	add	x21, x8, #0x8
     b38:      	add	x8, sp, #0x80
     b3c:      	mov	x2, x21
     b40:      	blr	x9
     b44:      	ldr	x23, [sp, #0x80]
     b48:      	add	x22, sp, #0x88
     b4c:      	add	x0, sp, #0x88
     b50:      	mov	w1, #0x8                // =8
     b54:      	add	x2, x23, #0x10
     b58:      	blr	x29
     b5c:      	ldr	x8, [sp, #0x88]
     b60:      	cbz	x8, 0xb70 <generic_tracepoint_process_event+0xb70>
     b64:      	ldr	x9, [sp, #0x38]
     b68:      	mov	w8, #0x1000             // =4096
     b6c:      	b	0xbb8 <generic_tracepoint_process_event+0xbb8>
     b70:      	add	x2, x23, #0x18
     b74:      	mov	w8, #0x8                // =8
     b78:      	mov	w9, #0x4                // =4
     b7c:      	add	x10, sp, #0x88
     b80:      	add	x0, sp, #0x88
     b84:      	mov	w1, #0x8                // =8
     b88:      	blr	x9
     b8c:      	ldr	x8, [sp, #0x88]
     b90:      	cmp	x8, x23
     b94:      	b.eq	0xb64 <generic_tracepoint_process_event+0xb64>
     b98:      	mov	w8, #0x2964             // =10596
     b9c:      	add	x9, x24, #0xff6
     ba0:      	strh	w8, [x24, #0xffe]
     ba4:      	adrp	x8, 0x0 <generic_tracepoint_process_event>
     ba8:      	add	x8, x8, #0x0
     bac:      	ldr	x8, [x8]
     bb0:      	str	x8, [x9]
     bb4:      	mov	w8, #0xff6              // =4086
     bb8:      	str	x9, [sp, #0x38]
     bbc:      	str	x9, [sp, #0xb8]
     bc0:      	ldr	x9, [sp, #0x8]
     bc4:      	add	x10, sp, #0x88
     bc8:      	mov	w25, #0x8               // =8
     bcc:      	add	x0, sp, #0x88
     bd0:      	stp	xzr, xzr, [sp, #0x88]
     bd4:      	mov	w1, #0x8                // =8
     bd8:      	add	x23, x22, #0x8
     bdc:      	add	x22, x10, #0x18
     be0:      	mov	w29, #0x4               // =4
     be4:      	add	x2, x9, #0x20
     be8:      	stp	x24, xzr, [sp, #0x98]
     bec:      	stp	xzr, xzr, [sp, #0xa8]
     bf0:      	str	w8, [sp, #0xc0]
     bf4:      	mov	w8, #0x4                // =4
     bf8:      	add	x24, x10, #0x20
     bfc:      	strb	wzr, [sp, #0xc4]
     c00:      	blr	x8
     c04:      	ldr	x2, [sp, #0x40]
     c08:      	mov	w8, #0x4                // =4
     c0c:      	mov	x0, x23
     c10:      	mov	w1, #0x8                // =8
     c14:      	blr	x8
     c18:      	mov	w8, #0x4                // =4
     c1c:      	mov	x0, x22
     c20:      	mov	w1, #0x8                // =8
     c24:      	str	x22, [sp, #0x40]
     c28:      	str	x21, [sp, #0x8]
     c2c:      	mov	x2, x21
     c30:      	blr	x8
     c34:      	ldr	x2, [sp, #0x28]
     c38:      	mov	x0, x24
     c3c:      	mov	w1, #0x8                // =8
     c40:      	blr	x29
     c44:      	ldr	x8, [sp, #0xa8]
     c48:      	sub	x8, x8, #0x20
     c4c:      	str	x8, [sp, #0xb0]
     c50:      	adrp	x8, 0x0 <generic_tracepoint_process_event>
     c54:      	ldr	x8, [x8]
     c58:      	ldrb	w8, [x8]
     c5c:      	cbz	w8, 0xdf0 <generic_tracepoint_process_event+0xdf0>
     c60:      	mov	w23, #0x80              // =128
     c64:      	mov	w24, #0x8               // =8
     c68:      	add	x21, sp, #0xd0
     c6c:      	ldp	x29, x2, [sp, #0xa0]
     c70:      	ldp	x8, x9, [sp, #0x88]
     c74:      	cmp	x29, x8
     c78:      	ccmp	x2, x9, #0x0, eq
     c7c:      	b.eq	0xf7c <generic_tracepoint_process_event+0xf7c>
     c80:      	ldr	x25, [sp, #0xb0]
     c84:      	mov	w8, #0x4                // =4
     c88:      	add	x9, sp, #0xd0
     c8c:      	add	x0, sp, #0xd0
     c90:      	mov	w1, #0x8                // =8
     c94:      	blr	x8
     c98:      	ldr	x8, [x21]
     c9c:      	add	x21, sp, #0xd0
     ca0:      	cmp	x29, x8
     ca4:      	b.eq	0xd98 <generic_tracepoint_process_event+0xd98>
     ca8:      	add	x22, x29, #0x18
     cac:      	mov	w8, #0x4                // =4
     cb0:      	add	x9, sp, #0xf0
     cb4:      	add	x0, sp, #0xf0
     cb8:      	mov	w1, #0x8                // =8
     cbc:      	mov	x2, x22
     cc0:      	blr	x8
     cc4:      	ldr	x8, [x21, #0x20]
     cc8:      	cmp	x8, x29
     ccc:      	b.eq	0xd98 <generic_tracepoint_process_event+0xd98>
     cd0:      	mov	w8, #0x4                // =4
     cd4:      	add	x9, sp, #0xd8
     cd8:      	add	x0, sp, #0xd8
     cdc:      	mov	w1, #0x8                // =8
     ce0:      	mov	x2, x22
     ce4:      	blr	x8
     ce8:      	add	x2, x29, #0x20
     cec:      	mov	w8, #0x4                // =4
     cf0:      	mov	w9, #0x10               // =16
     cf4:      	add	x10, sp, #0xe0
     cf8:      	add	x0, sp, #0xe0
     cfc:      	mov	w1, #0x10               // =16
     d00:      	blr	x8
     d04:      	ldr	w22, [sp, #0xe4]
     d08:      	ldr	x8, [sp, #0x98]
     d0c:      	ldr	x10, [sp, #0xb8]
     d10:      	sub	x12, x10, x8
     d14:      	ldr	w25, [sp, #0xc0]
     d18:      	subs	w10, w22, w25
     d1c:      	ldr	x9, [x21, #0x18]
     d20:      	csel	w10, wzr, w10, lo
     d24:      	cmp	w25, w22
     d28:      	csel	w11, w25, w22, lo
     d2c:      	cinc	w13, w11, hi
     d30:      	sub	w14, w25, w13
     d34:      	subs	x12, x12, x13
     d38:      	str	w14, [sp, #0xc0]
     d3c:      	b.lo	0xf84 <generic_tracepoint_process_event+0xf84>
     d40:      	cmp	x12, #0xfff
     d44:      	b.hi	0xf84 <generic_tracepoint_process_event+0xf84>
     d48:      	cmp	w25, w22
     d4c:      	b.ls	0xd58 <generic_tracepoint_process_event+0xd58>
     d50:      	mov	w13, #0x2f              // =47
     d54:      	strb	w13, [x8, x12]
     d58:      	add	x29, x8, x12
     d5c:      	cmp	w25, w22
     d60:      	add	x2, x9, x10
     d64:      	and	w1, w11, #0xff
     d68:      	mov	w8, #0x4                // =4
     d6c:      	cinc	x0, x29, hi
     d70:      	blr	x8
     d74:      	cmp	w25, w22
     d78:      	str	x29, [sp, #0xb8]
     d7c:      	b.ls	0xf84 <generic_tracepoint_process_event+0xf84>
     d80:      	add	x21, sp, #0xd0
     d84:      	ldr	x8, [x21, #0x8]
     d88:      	str	x8, [sp, #0xa0]
     d8c:      	subs	w23, w23, #0x1
     d90:      	b.ne	0xc6c <generic_tracepoint_process_event+0xc6c>
     d94:      	b	0xf84 <generic_tracepoint_process_event+0xf84>
     d98:      	add	x2, x25, #0x10
     d9c:      	mov	w8, #0x4                // =4
     da0:      	add	x9, sp, #0xf0
     da4:      	add	x0, sp, #0xf0
     da8:      	mov	w1, #0x8                // =8
     dac:      	blr	x8
     db0:      	ldr	x8, [sp, #0xb0]
     db4:      	ldr	x9, [x21, #0x20]
     db8:      	add	x21, sp, #0xd0
     dbc:      	cmp	x8, x9
     dc0:      	b.eq	0xf7c <generic_tracepoint_process_event+0xf7c>
     dc4:      	ldr	x0, [sp, #0x40]
     dc8:      	add	x2, x25, #0x18
     dcc:      	mov	w8, #0x4                // =4
     dd0:      	mov	w1, #0x8                // =8
     dd4:      	blr	x8
     dd8:      	ldr	x8, [x21, #0x20]
     ddc:      	add	x9, x8, #0x20
     de0:      	stp	x9, x8, [sp, #0xa8]
     de4:      	subs	w23, w23, #0x1
     de8:      	b.ne	0xc6c <generic_tracepoint_process_event+0xc6c>
     dec:      	b	0xf84 <generic_tracepoint_process_event+0xf84>
     df0:      	mov	w23, #0x80              // =128
     df4:      	mov	w24, #0x8               // =8
     df8:      	add	x21, sp, #0xd0
     dfc:      	b	0xe08 <generic_tracepoint_process_event+0xe08>
     e00:      	subs	w23, w23, #0x1
     e04:      	b.eq	0xf84 <generic_tracepoint_process_event+0xf84>
     e08:      	ldp	x29, x2, [sp, #0xa0]
     e0c:      	ldp	x8, x9, [sp, #0x88]
     e10:      	cmp	x29, x8
     e14:      	ccmp	x2, x9, #0x0, eq
     e18:      	b.eq	0xf7c <generic_tracepoint_process_event+0xf7c>
     e1c:      	ldr	x25, [sp, #0xb0]
     e20:      	mov	w8, #0x4                // =4
     e24:      	add	x9, sp, #0xd0
     e28:      	add	x0, sp, #0xd0
     e2c:      	mov	w1, #0x8                // =8
     e30:      	blr	x8
     e34:      	ldr	x8, [x21]
     e38:      	add	x21, sp, #0xd0
     e3c:      	cmp	x29, x8
     e40:      	b.eq	0xf2c <generic_tracepoint_process_event+0xf2c>
     e44:      	add	x22, x29, #0x18
     e48:      	mov	w8, #0x4                // =4
     e4c:      	add	x9, sp, #0xf0
     e50:      	add	x0, sp, #0xf0
     e54:      	mov	w1, #0x8                // =8
     e58:      	mov	x2, x22
     e5c:      	blr	x8
     e60:      	ldr	x8, [x21, #0x20]
     e64:      	cmp	x8, x29
     e68:      	b.eq	0xf2c <generic_tracepoint_process_event+0xf2c>
     e6c:      	mov	w8, #0x4                // =4
     e70:      	add	x9, sp, #0xd8
     e74:      	add	x0, sp, #0xd8
     e78:      	mov	w1, #0x8                // =8
     e7c:      	mov	x2, x22
     e80:      	blr	x8
     e84:      	add	x2, x29, #0x20
     e88:      	mov	w8, #0x4                // =4
     e8c:      	mov	w9, #0x10               // =16
     e90:      	add	x10, sp, #0xe0
     e94:      	add	x0, sp, #0xe0
     e98:      	mov	w1, #0x10               // =16
     e9c:      	blr	x8
     ea0:      	ldr	w22, [sp, #0xe4]
     ea4:      	ldr	x8, [sp, #0x98]
     ea8:      	ldr	x10, [sp, #0xb8]
     eac:      	sub	x12, x10, x8
     eb0:      	ldr	w25, [sp, #0xc0]
     eb4:      	subs	w10, w22, w25
     eb8:      	ldr	x9, [x21, #0x18]
     ebc:      	csel	w10, wzr, w10, lo
     ec0:      	cmp	w25, w22
     ec4:      	csel	w11, w25, w22, lo
     ec8:      	cinc	w13, w11, hi
     ecc:      	sub	w14, w25, w13
     ed0:      	subs	x12, x12, x13
     ed4:      	str	w14, [sp, #0xc0]
     ed8:      	b.lo	0xf84 <generic_tracepoint_process_event+0xf84>
     edc:      	cmp	x12, #0xfff
     ee0:      	b.hi	0xf84 <generic_tracepoint_process_event+0xf84>
     ee4:      	cmp	w25, w22
     ee8:      	b.ls	0xef4 <generic_tracepoint_process_event+0xef4>
     eec:      	mov	w13, #0x2f              // =47
     ef0:      	strb	w13, [x8, x12]
     ef4:      	add	x29, x8, x12
     ef8:      	cmp	w25, w22
     efc:      	add	x2, x9, x10
     f00:      	and	w1, w11, #0xff
     f04:      	mov	w8, #0x4                // =4
     f08:      	cinc	x0, x29, hi
     f0c:      	blr	x8
     f10:      	cmp	w25, w22
     f14:      	str	x29, [sp, #0xb8]
     f18:      	b.ls	0xf84 <generic_tracepoint_process_event+0xf84>
     f1c:      	add	x21, sp, #0xd0
     f20:      	ldr	x8, [x21, #0x8]
     f24:      	str	x8, [sp, #0xa0]
     f28:      	b	0xe00 <generic_tracepoint_process_event+0xe00>
     f2c:      	add	x2, x25, #0x10
     f30:      	mov	w8, #0x4                // =4
     f34:      	add	x9, sp, #0xf0
     f38:      	add	x0, sp, #0xf0
     f3c:      	mov	w1, #0x8                // =8
     f40:      	blr	x8
     f44:      	ldr	x8, [sp, #0xb0]
     f48:      	ldr	x9, [x21, #0x20]
     f4c:      	add	x21, sp, #0xd0
     f50:      	cmp	x8, x9
     f54:      	b.eq	0xf7c <generic_tracepoint_process_event+0xf7c>
     f58:      	ldr	x0, [sp, #0x40]
     f5c:      	add	x2, x25, #0x18
     f60:      	mov	w8, #0x4                // =4
     f64:      	mov	w1, #0x8                // =8
     f68:      	blr	x8
     f6c:      	ldr	x8, [x21, #0x20]
     f70:      	add	x9, x8, #0x20
     f74:      	stp	x9, x8, [sp, #0xa8]
     f78:      	b	0xe00 <generic_tracepoint_process_event+0xe00>
     f7c:      	mov	w8, #0x1                // =1
     f80:      	strb	w8, [sp, #0xc4]
     f84:      	ldr	x8, [sp, #0xb8]
     f88:      	ldr	x2, [sp, #0x38]
     f8c:      	adrp	x21, 0x0 <generic_tracepoint_process_event>
     f90:      	cmp	x8, x2
     f94:      	ldr	x21, [x21]
     f98:      	b.eq	0xfd4 <generic_tracepoint_process_event+0xfd4>
     f9c:      	ldrb	w9, [sp, #0xc4]
     fa0:      	ldr	x29, [sp, #0x30]
     fa4:      	mov	w11, #0x1000            // =4096
     fa8:      	cmp	w9, #0x0
     fac:      	ldr	w9, [sp, #0xc0]
     fb0:      	cset	w10, eq
     fb4:      	sub	w11, w11, w9
     fb8:      	cmp	w9, #0x0
     fbc:      	csel	w9, w11, w9, gt
     fc0:      	cbz	x8, 0x111c <generic_tracepoint_process_event+0x111c>
     fc4:      	lsl	w10, w10, #1
     fc8:      	mov	x2, x8
     fcc:      	str	w10, [sp, #0x40]
     fd0:      	b	0xfe0 <generic_tracepoint_process_event+0xfe0>
     fd4:      	ldr	x29, [sp, #0x30]
     fd8:      	mov	w9, wzr
     fdc:      	str	wzr, [sp, #0x40]
     fe0:      	ldr	x23, [sp, #0x10]
     fe4:      	and	w22, w9, #0xfff
     fe8:      	mov	w8, #0x4                // =4
     fec:      	mov	w24, #0x4               // =4
     ff0:      	mov	w1, w22
     ff4:      	add	x0, x23, #0x4
     ff8:      	blr	x8
     ffc:      	str	w22, [x23]
    1000:      	ldr	x2, [sp, #0x8]
    1004:      	mov	w25, #0x8               // =8
    1008:      	add	x8, sp, #0x88
    100c:      	mov	w9, #0x4                // =4
    1010:      	add	x0, sp, #0x88
    1014:      	mov	w1, #0x8                // =8
    1018:      	blr	x9
    101c:      	ldr	x8, [sp, #0x88]
    1020:      	add	x9, sp, #0xe0
    1024:      	mov	w10, #0x4               // =4
    1028:      	add	x0, sp, #0xe0
    102c:      	mov	w1, #0x8                // =8
    1030:      	add	x8, x8, #0x30
    1034:      	ldr	x8, [sp, #0x88]
    1038:      	add	x2, x8, #0x30
    103c:      	blr	x10
    1040:      	add	x11, sp, #0xd0
    1044:      	mov	w9, #0x2                // =2
    1048:      	add	x10, sp, #0xf0
    104c:      	ldr	x8, [x11, #0x10]
    1050:      	add	x0, sp, #0xf0
    1054:      	mov	w1, #0x2                // =2
    1058:      	ldr	x2, [x11, #0x10]
    105c:      	blr	x24
    1060:      	ldr	w9, [sp, #0x40]
    1064:      	add	x8, x23, x22
    1068:      	ldr	x23, [sp, #0x108]
    106c:      	add	w24, w22, #0xa
    1070:      	mov	w25, #0x5efc            // =24316
    1074:      	str	w9, [x8, #0x4]
    1078:      	ldrh	w9, [sp, #0xf0]
    107c:      	ldp	x10, x11, [sp, #0x18]
    1080:      	strh	w9, [x8, #0x8]
    1084:      	mov	w9, #0x5ea0             // =24224
    1088:      	b	0x3078 <generic_tracepoint_process_event+0x3078>
    108c:      	cmp	w23, #0x2c
    1090:      	b.hi	0x1138 <generic_tracepoint_process_event+0x1138>
    1094:      	mov	x9, #0x7cf2             // =31986
    1098:      	mov	w8, #0x1                // =1
    109c:      	movk	x9, #0xf202, lsl #16
    10a0:      	lsl	x8, x8, x23
    10a4:      	movk	x9, #0x11c1, lsl #32
    10a8:      	tst	x8, x9
    10ac:      	b.eq	0x1138 <generic_tracepoint_process_event+0x1138>
    10b0:      	str	x12, [x24, #0x8]
    10b4:      	str	wzr, [sp, #0xd0]
    10b8:      	mov	w8, #0x1                // =1
    10bc:      	add	x9, sp, #0xd0
    10c0:      	add	x1, sp, #0xd0
    10c4:      	mov	x0, x21
    10c8:      	blr	x8
    10cc:      	mov	x24, xzr
    10d0:      	cbz	x0, 0x3064 <generic_tracepoint_process_event+0x3064>
    10d4:      	ldr	x11, [sp, #0x20]
    10d8:      	cmp	w23, #0x10
    10dc:      	b.le	0x11bc <generic_tracepoint_process_event+0x11bc>
    10e0:      	cmp	w23, #0x1e
    10e4:      	b.le	0x12e0 <generic_tracepoint_process_event+0x12e0>
    10e8:      	cmp	w23, #0x26
    10ec:      	b.gt	0x13b8 <generic_tracepoint_process_event+0x13b8>
    10f0:      	sub	w8, w23, #0x1f
    10f4:      	cmp	w8, #0x2
    10f8:      	b.hs	0x1818 <generic_tracepoint_process_event+0x1818>
    10fc:      	mov	w8, #0x1                // =1
    1100:      	add	x9, sp, #0xd8
    1104:      	mov	w10, #0x4               // =4
    1108:      	ldr	x0, [sp, #0x10]
    110c:      	mov	w24, #0x4               // =4
    1110:      	add	x2, sp, #0xd8
    1114:      	mov	w1, #0x1                // =1
    1118:      	b	0x1504 <generic_tracepoint_process_event+0x1504>
    111c:      	mov	x24, xzr
    1120:      	mov	w25, #0x5efc            // =24316
    1124:      	ldr	x23, [sp, #0x108]
    1128:      	b	0x307c <generic_tracepoint_process_event+0x307c>
    112c:      	str	x29, [sp, #0x30]
    1130:      	mov	w29, #0x2               // =2
    1134:      	b	0x11b0 <generic_tracepoint_process_event+0x11b0>
    1138:      	str	wzr, [sp, #0x78]
    113c:      	mov	w8, #0x1                // =1
    1140:      	add	x9, sp, #0x78
    1144:      	add	x1, sp, #0x78
    1148:      	mov	x0, x21
    114c:      	blr	x8
    1150:      	cbz	x0, 0x12d8 <generic_tracepoint_process_event+0x12d8>
    1154:      	mov	x12, xzr
    1158:      	cmp	w23, #0x19
    115c:      	b.gt	0x1388 <generic_tracepoint_process_event+0x1388>
    1160:      	cmp	w23, #0x12
    1164:      	b.le	0x1480 <generic_tracepoint_process_event+0x1480>
    1168:      	cmp	w23, #0x14
    116c:      	b.le	0x175c <generic_tracepoint_process_event+0x175c>
    1170:      	cmp	w23, #0x15
    1174:      	b.eq	0x1e00 <generic_tracepoint_process_event+0x1e00>
    1178:      	cmp	w23, #0x16
    117c:      	b.eq	0x1da0 <generic_tracepoint_process_event+0x1da0>
    1180:      	ldp	x10, x11, [sp, #0x18]
    1184:      	cmp	w23, #0x17
    1188:      	mov	w9, #0x5ea0             // =24224
    118c:      	mov	x24, x12
    1190:      	b.ne	0x2408 <generic_tracepoint_process_event+0x2408>
    1194:      	ldr	x8, [sp, #0x10]
    1198:      	ldr	x12, [sp, #0x40]
    119c:      	mov	w24, #0x8               // =8
    11a0:      	stp	w12, wzr, [x8]
    11a4:      	b	0x2408 <generic_tracepoint_process_event+0x2408>
    11a8:      	str	x29, [sp, #0x30]
    11ac:      	mov	w29, #0x3               // =3
    11b0:      	str	w29, [x8, x9]
    11b4:      	ldr	x29, [sp, #0x30]
    11b8:      	b	0x3c0 <generic_tracepoint_process_event+0x3c0>
    11bc:      	ldr	x10, [sp, #0x18]
    11c0:      	cmp	w23, #0x9
    11c4:      	mov	w9, #0x5ea0             // =24224
    11c8:      	b.gt	0x1310 <generic_tracepoint_process_event+0x1310>
    11cc:      	cmp	w23, #0x4
    11d0:      	add	x21, sp, #0xd0
    11d4:      	b.le	0x150c <generic_tracepoint_process_event+0x150c>
    11d8:      	cmp	w23, #0x5
    11dc:      	b.eq	0x19c0 <generic_tracepoint_process_event+0x19c0>
    11e0:      	cmp	w23, #0x6
    11e4:      	b.eq	0x136c <generic_tracepoint_process_event+0x136c>
    11e8:      	ldp	x10, x11, [sp, #0x18]
    11ec:      	cmp	w23, #0x7
    11f0:      	mov	w9, #0x5ea0             // =24224
    11f4:      	str	x0, [sp, #0x40]
    11f8:      	b.ne	0x306c <generic_tracepoint_process_event+0x306c>
    11fc:      	ldr	x23, [x21, #0x8]
    1200:      	ldr	x25, [sp, #0x10]
    1204:      	mov	w24, #0x2               // =2
    1208:      	mov	w8, #0x4                // =4
    120c:      	mov	w1, #0x2                // =2
    1210:      	mov	w22, #0x4               // =4
    1214:      	str	x23, [x25, #0x28]
    1218:      	add	x0, x25, #0x26
    121c:      	add	x2, x23, #0x10
    1220:      	blr	x8
    1224:      	add	x0, x25, #0x3a
    1228:      	add	x2, x23, #0x12
    122c:      	mov	w8, #0x1                // =1
    1230:      	mov	w9, #0x4                // =4
    1234:      	mov	w1, #0x1                // =1
    1238:      	blr	x9
    123c:      	add	x0, x25, #0x38
    1240:      	add	x2, x23, #0x21e
    1244:      	mov	w8, #0x4                // =4
    1248:      	mov	w1, #0x2                // =2
    124c:      	blr	x8
    1250:      	add	x0, x25, #0x24
    1254:      	add	x2, x23, #0x21c
    1258:      	mov	w8, #0x4                // =4
    125c:      	mov	w1, #0x2                // =2
    1260:      	blr	x8
    1264:      	add	x0, x25, #0x30
    1268:      	add	x2, x23, #0x214
    126c:      	mov	w8, #0x4                // =4
    1270:      	mov	w1, #0x4                // =4
    1274:      	blr	x8
    1278:      	add	x0, x25, #0x34
    127c:      	add	x2, x23, #0x210
    1280:      	mov	w1, #0x4                // =4
    1284:      	blr	x22
    1288:      	ldrh	w8, [x25, #0x26]
    128c:      	mov	x22, x25
    1290:      	stp	xzr, xzr, [x25]
    1294:      	cmp	w8, #0xa
    1298:      	str	xzr, [x25, #0x18]
    129c:      	str	xzr, [x22, #0x10]!
    12a0:      	b.eq	0x20e4 <generic_tracepoint_process_event+0x20e4>
    12a4:      	cmp	w8, #0x2
    12a8:      	b.ne	0x2110 <generic_tracepoint_process_event+0x2110>
    12ac:      	ldr	x0, [sp, #0x10]
    12b0:      	add	x2, x23, #0x4
    12b4:      	mov	w8, #0x4                // =4
    12b8:      	mov	w1, #0x4                // =4
    12bc:      	mov	w24, #0x4               // =4
    12c0:      	blr	x8
    12c4:      	mov	x0, x22
    12c8:      	mov	w1, #0x4                // =4
    12cc:      	mov	x2, x23
    12d0:      	blr	x24
    12d4:      	b	0x2110 <generic_tracepoint_process_event+0x2110>
    12d8:      	mov	x24, xzr
    12dc:      	b	0x2400 <generic_tracepoint_process_event+0x2400>
    12e0:      	cmp	w23, #0x1c
    12e4:      	b.gt	0x14e8 <generic_tracepoint_process_event+0x14e8>
    12e8:      	cmp	w23, #0x11
    12ec:      	b.eq	0x1850 <generic_tracepoint_process_event+0x1850>
    12f0:      	cmp	w23, #0x19
    12f4:      	str	x0, [sp, #0x40]
    12f8:      	b.eq	0x1904 <generic_tracepoint_process_event+0x1904>
    12fc:      	ldr	x10, [sp, #0x18]
    1300:      	cmp	w23, #0x1c
    1304:      	mov	w9, #0x5ea0             // =24224
    1308:      	b.eq	0x151c <generic_tracepoint_process_event+0x151c>
    130c:      	b	0x306c <generic_tracepoint_process_event+0x306c>
    1310:      	sub	w8, w23, #0xa
    1314:      	cmp	w8, #0x2
    1318:      	b.lo	0x151c <generic_tracepoint_process_event+0x151c>
    131c:      	sub	w8, w23, #0xc
    1320:      	cmp	w8, #0x2
    1324:      	b.lo	0x153c <generic_tracepoint_process_event+0x153c>
    1328:      	cmp	w23, #0xe
    132c:      	b.ne	0x306c <generic_tracepoint_process_event+0x306c>
    1330:      	mov	w22, #0x8               // =8
    1334:      	add	x8, sp, #0x88
    1338:      	add	x24, sp, #0xd8
    133c:      	mov	w9, #0x4                // =4
    1340:      	add	x0, sp, #0x88
    1344:      	add	x2, sp, #0xd8
    1348:      	mov	w1, #0x8                // =8
    134c:      	mov	w23, #0x4               // =4
    1350:      	blr	x9
    1354:      	ldr	x8, [sp, #0x88]
    1358:      	add	x0, sp, #0xd8
    135c:      	mov	w1, #0x8                // =8
    1360:      	add	x21, sp, #0xd0
    1364:      	ldr	x2, [sp, #0x88]
    1368:      	blr	x23
    136c:      	ldr	x22, [sp, #0x10]
    1370:      	ldr	x2, [x21, #0x8]
    1374:      	mov	w8, #0x1001             // =4097
    1378:      	mov	w9, #0x2d               // =45
    137c:      	mov	w1, #0x1001             // =4097
    1380:      	add	x0, x22, #0x4
    1384:      	b	0x1b38 <generic_tracepoint_process_event+0x1b38>
    1388:      	cmp	w23, #0x20
    138c:      	b.le	0x1684 <generic_tracepoint_process_event+0x1684>
    1390:      	sub	w8, w23, #0x21
    1394:      	cmp	w8, #0x4
    1398:      	b.hs	0x1564 <generic_tracepoint_process_event+0x1564>
    139c:      	ldr	x0, [sp, #0x10]
    13a0:      	ldr	x2, [sp, #0x40]
    13a4:      	mov	w24, #0x8               // =8
    13a8:      	mov	w8, #0x4                // =4
    13ac:      	mov	w1, #0x8                // =8
    13b0:      	blr	x8
    13b4:      	b	0x2400 <generic_tracepoint_process_event+0x2400>
    13b8:      	cmp	w23, #0x27
    13bc:      	add	x8, sp, #0xd0
    13c0:      	b.eq	0x1b1c <generic_tracepoint_process_event+0x1b1c>
    13c4:      	cmp	w23, #0x28
    13c8:      	b.eq	0x1b54 <generic_tracepoint_process_event+0x1b54>
    13cc:      	ldr	x10, [sp, #0x18]
    13d0:      	cmp	w23, #0x2c
    13d4:      	mov	w9, #0x5ea0             // =24224
    13d8:      	b.ne	0x306c <generic_tracepoint_process_event+0x306c>
    13dc:      	ldr	x0, [sp, #0x10]
    13e0:      	ldr	x22, [x8, #0x8]
    13e4:      	mov	w8, #0x2                // =2
    13e8:      	mov	w9, #0x4                // =4
    13ec:      	mov	w1, #0x2                // =2
    13f0:      	mov	x2, x22
    13f4:      	strb	wzr, [sp, #0x88]
    13f8:      	stp	xzr, xzr, [x0]
    13fc:      	stp	xzr, xzr, [x0, #0x10]
    1400:      	stp	xzr, xzr, [x0, #0x20]
    1404:      	stp	xzr, xzr, [x0, #0x30]
    1408:      	stp	xzr, xzr, [x0, #0x40]
    140c:      	stp	xzr, xzr, [x0, #0x50]
    1410:      	stp	xzr, xzr, [x0, #0x60]
    1414:      	blr	x9
    1418:      	tbnz	x0, #0x3f, 0x2324 <generic_tracepoint_process_event+0x2324>
    141c:      	add	x23, x22, #0x2
    1420:      	mov	w8, #0x1                // =1
    1424:      	mov	w9, #0x4                // =4
    1428:      	add	x10, sp, #0x88
    142c:      	add	x0, sp, #0x88
    1430:      	mov	w1, #0x1                // =1
    1434:      	mov	x2, x23
    1438:      	blr	x9
    143c:      	tbnz	x0, #0x3f, 0x2324 <generic_tracepoint_process_event+0x2324>
    1440:      	ldrb	w8, [sp, #0x88]
    1444:      	ldr	x10, [sp, #0x10]
    1448:      	cmp	w8, #0x0
    144c:      	add	x0, x10, #0x4
    1450:      	cset	w9, eq
    1454:      	strb	w9, [x10, #0x2]
    1458:      	cbz	w8, 0x2300 <generic_tracepoint_process_event+0x2300>
    145c:      	mov	w8, #0x6c               // =108
    1460:      	mov	w9, #0x2d               // =45
    1464:      	mov	w1, #0x6c               // =108
    1468:      	mov	x2, x23
    146c:      	blr	x9
    1470:      	mov	w25, #0x5efc            // =24316
    1474:      	tbnz	w0, #0x1f, 0x2324 <generic_tracepoint_process_event+0x2324>
    1478:      	sub	w22, w0, #0x1
    147c:      	b	0x231c <generic_tracepoint_process_event+0x231c>
    1480:      	ldr	x8, [sp, #0x38]
    1484:      	cmp	w23, #0x7
    1488:      	and	x8, x8, #0xffffffff
    148c:      	b.gt	0x170c <generic_tracepoint_process_event+0x170c>
    1490:      	cmp	w23, #0x2
    1494:      	b.eq	0x1bd4 <generic_tracepoint_process_event+0x1bd4>
    1498:      	ldp	x10, x11, [sp, #0x18]
    149c:      	cmp	w23, #0x3
    14a0:      	mov	w9, #0x5ea0             // =24224
    14a4:      	mov	x24, x12
    14a8:      	str	x0, [sp, #0x38]
    14ac:      	b.ne	0x2408 <generic_tracepoint_process_event+0x2408>
    14b0:      	ldr	x9, [sp, #0x38]
    14b4:      	add	x24, x9, #0x90
    14b8:      	and	w9, w8, #0xf
    14bc:      	add	x25, x24, x22
    14c0:      	cmp	w9, #0x2
    14c4:      	b.le	0x227c <generic_tracepoint_process_event+0x227c>
    14c8:      	cmp	w9, #0x3
    14cc:      	b.eq	0x2410 <generic_tracepoint_process_event+0x2410>
    14d0:      	cmp	w9, #0x4
    14d4:      	b.eq	0x2418 <generic_tracepoint_process_event+0x2418>
    14d8:      	cmp	w9, #0x5
    14dc:      	b.ne	0x2470 <generic_tracepoint_process_event+0x2470>
    14e0:      	mov	w10, #0x5e70            // =24176
    14e4:      	b	0x2424 <generic_tracepoint_process_event+0x2424>
    14e8:      	ldr	x0, [sp, #0x10]
    14ec:      	mov	w8, #0x2                // =2
    14f0:      	add	x9, sp, #0xd8
    14f4:      	mov	w10, #0x4               // =4
    14f8:      	mov	w24, #0x4               // =4
    14fc:      	add	x2, sp, #0xd8
    1500:      	mov	w1, #0x2                // =2
    1504:      	blr	x10
    1508:      	b	0x3064 <generic_tracepoint_process_event+0x3064>
    150c:      	cmp	w23, #0x1
    1510:      	b.eq	0x153c <generic_tracepoint_process_event+0x153c>
    1514:      	cmp	w23, #0x4
    1518:      	b.ne	0x306c <generic_tracepoint_process_event+0x306c>
    151c:      	ldr	x0, [sp, #0x10]
    1520:      	mov	w24, #0x8               // =8
    1524:      	mov	w8, #0x4                // =4
    1528:      	add	x9, sp, #0xd8
    152c:      	add	x2, sp, #0xd8
    1530:      	mov	w1, #0x8                // =8
    1534:      	blr	x8
    1538:      	b	0x3064 <generic_tracepoint_process_event+0x3064>
    153c:      	ldr	x0, [sp, #0x10]
    1540:      	add	x8, sp, #0xd8
    1544:      	mov	w9, #0x4                // =4
    1548:      	add	x2, sp, #0xd8
    154c:      	mov	w1, #0x4                // =4
    1550:      	mov	w24, #0x4               // =4
    1554:      	blr	x9
    1558:      	b	0x3064 <generic_tracepoint_process_event+0x3064>
    155c:      	mov	w29, #0x5               // =5
    1560:      	b	0x11b0 <generic_tracepoint_process_event+0x11b0>
    1564:      	cmp	w23, #0x2b
    1568:      	str	x0, [sp, #0x38]
    156c:      	b.eq	0x1ebc <generic_tracepoint_process_event+0x1ebc>
    1570:      	ldp	x10, x11, [sp, #0x18]
    1574:      	cmp	w23, #0x29
    1578:      	mov	w9, #0x5ea0             // =24224
    157c:      	mov	x24, x12
    1580:      	b.ne	0x2408 <generic_tracepoint_process_event+0x2408>
    1584:      	ldr	x8, [sp, #0x40]
    1588:      	mov	w9, #0x4                // =4
    158c:      	add	x10, sp, #0x88
    1590:      	add	x0, sp, #0x88
    1594:      	mov	w1, #0x8                // =8
    1598:      	add	x2, x8, #0x18
    159c:      	mov	w8, #0x8                // =8
    15a0:      	blr	x9
    15a4:      	ldr	x23, [sp, #0x88]
    15a8:      	cbz	x23, 0x23b4 <generic_tracepoint_process_event+0x23b4>
    15ac:      	ldr	x25, [sp, #0x10]
    15b0:      	add	x2, x23, #0x10
    15b4:      	mov	w24, #0x2               // =2
    15b8:      	mov	w8, #0x4                // =4
    15bc:      	str	x23, [x25, #0x28]
    15c0:      	add	x0, x25, #0x26
    15c4:      	mov	w1, #0x2                // =2
    15c8:      	mov	w22, #0x4               // =4
    15cc:      	blr	x8
    15d0:      	add	x0, x25, #0x3a
    15d4:      	add	x2, x23, #0x12
    15d8:      	mov	w8, #0x1                // =1
    15dc:      	mov	w9, #0x4                // =4
    15e0:      	mov	w1, #0x1                // =1
    15e4:      	blr	x9
    15e8:      	add	x0, x25, #0x38
    15ec:      	add	x2, x23, #0x21e
    15f0:      	mov	w8, #0x4                // =4
    15f4:      	mov	w1, #0x2                // =2
    15f8:      	blr	x8
    15fc:      	add	x0, x25, #0x24
    1600:      	add	x2, x23, #0x21c
    1604:      	mov	w8, #0x4                // =4
    1608:      	mov	w1, #0x2                // =2
    160c:      	blr	x8
    1610:      	add	x0, x25, #0x30
    1614:      	add	x2, x23, #0x214
    1618:      	mov	w8, #0x4                // =4
    161c:      	mov	w1, #0x4                // =4
    1620:      	blr	x8
    1624:      	add	x0, x25, #0x34
    1628:      	add	x2, x23, #0x210
    162c:      	mov	w1, #0x4                // =4
    1630:      	blr	x22
    1634:      	ldrh	w8, [x25, #0x26]
    1638:      	mov	x22, x25
    163c:      	stp	xzr, xzr, [x25]
    1640:      	cmp	w8, #0xa
    1644:      	str	xzr, [x25, #0x18]
    1648:      	str	xzr, [x22, #0x10]!
    164c:      	b.eq	0x2344 <generic_tracepoint_process_event+0x2344>
    1650:      	cmp	w8, #0x2
    1654:      	b.ne	0x2370 <generic_tracepoint_process_event+0x2370>
    1658:      	ldr	x0, [sp, #0x10]
    165c:      	add	x2, x23, #0x4
    1660:      	mov	w8, #0x4                // =4
    1664:      	mov	w1, #0x4                // =4
    1668:      	mov	w24, #0x4               // =4
    166c:      	blr	x8
    1670:      	mov	x0, x22
    1674:      	mov	w1, #0x4                // =4
    1678:      	mov	x2, x23
    167c:      	blr	x24
    1680:      	b	0x2370 <generic_tracepoint_process_event+0x2370>
    1684:      	cmp	w23, #0x1a
    1688:      	b.eq	0x1f4c <generic_tracepoint_process_event+0x1f4c>
    168c:      	ldp	x10, x11, [sp, #0x18]
    1690:      	cmp	w23, #0x1b
    1694:      	mov	w9, #0x5ea0             // =24224
    1698:      	mov	x24, x12
    169c:      	b.ne	0x2408 <generic_tracepoint_process_event+0x2408>
    16a0:      	mov	x22, x10
    16a4:      	ldr	x10, [sp, #0x10]
    16a8:      	ldr	x8, [sp, #0x40]
    16ac:      	mov	w9, #0x2d               // =45
    16b0:      	mov	w1, #0x3f               // =63
    16b4:      	mov	x23, x11
    16b8:      	str	xzr, [x10, #0x18]
    16bc:      	mov	x0, x10
    16c0:      	stp	xzr, xzr, [x10, #0x40]
    16c4:      	stp	xzr, xzr, [x10, #0x30]
    16c8:      	add	x2, x8, #0x18
    16cc:      	stp	xzr, xzr, [x10, #0x20]
    16d0:      	stp	xzr, xzr, [x10]
    16d4:      	mov	w8, #0x3f               // =63
    16d8:      	str	xzr, [x0, #0x10]!
    16dc:      	blr	x9
    16e0:      	tbnz	x0, #0x3f, 0x22e8 <generic_tracepoint_process_event+0x22e8>
    16e4:      	ldr	x8, [sp, #0x10]
    16e8:      	mov	w9, #0x4                // =4
    16ec:      	mov	w1, #0x8                // =8
    16f0:      	add	x0, x8, #0x8
    16f4:      	ldr	x8, [sp, #0x40]
    16f8:      	add	x2, x8, #0x360
    16fc:      	mov	w8, #0x8                // =8
    1700:      	blr	x9
    1704:      	mov	w24, #0x50              // =80
    1708:      	b	0x22ec <generic_tracepoint_process_event+0x22ec>
    170c:      	cmp	w23, #0x8
    1710:      	b.eq	0x1c20 <generic_tracepoint_process_event+0x1c20>
    1714:      	ldp	x10, x11, [sp, #0x18]
    1718:      	cmp	w23, #0x12
    171c:      	mov	w25, #0x5efc            // =24316
    1720:      	mov	w9, #0x5ea0             // =24224
    1724:      	mov	x24, x12
    1728:      	b.ne	0x2408 <generic_tracepoint_process_event+0x2408>
    172c:      	ldr	x0, [sp, #0x10]
    1730:      	ldr	x2, [sp, #0x40]
    1734:      	and	x24, x8, #0x3ff
    1738:      	mov	w8, #0x4                // =4
    173c:      	mov	x22, x10
    1740:      	mov	x23, x11
    1744:      	mov	w1, w24
    1748:      	blr	x8
    174c:      	mov	x11, x23
    1750:      	mov	w9, #0x5ea0             // =24224
    1754:      	mov	x10, x22
    1758:      	b	0x2408 <generic_tracepoint_process_event+0x2408>
    175c:      	cmp	w23, #0x13
    1760:      	b.eq	0x1e78 <generic_tracepoint_process_event+0x1e78>
    1764:      	ldp	x10, x11, [sp, #0x18]
    1768:      	cmp	w23, #0x14
    176c:      	mov	w9, #0x5ea0             // =24224
    1770:      	mov	x24, x12
    1774:      	b.ne	0x2408 <generic_tracepoint_process_event+0x2408>
    1778:      	ldr	x22, [sp, #0x40]
    177c:      	str	xzr, [sp, #0x88]
    1780:      	mov	w12, #0x8               // =8
    1784:      	mov	w9, #0x4                // =4
    1788:      	add	x0, sp, #0x88
    178c:      	mov	w1, #0x8                // =8
    1790:      	mov	w23, #0x4               // =4
    1794:      	add	x8, x22, #0xd8
    1798:      	add	x2, x22, #0x110
    179c:      	str	x8, [sp, #0x38]
    17a0:      	add	x8, sp, #0x88
    17a4:      	blr	x9
    17a8:      	ldr	x8, [sp, #0x88]
    17ac:      	mov	w9, #0x80               // =128
    17b0:      	mov	w10, #0x2d              // =45
    17b4:      	ldr	x24, [sp, #0x10]
    17b8:      	mov	w1, #0x80               // =128
    17bc:      	mov	x0, x24
    17c0:      	ldr	x2, [sp, #0x88]
    17c4:      	blr	x10
    17c8:      	ldr	x2, [sp, #0x38]
    17cc:      	add	x0, x24, #0x90
    17d0:      	mov	w8, #0x4                // =4
    17d4:      	mov	w1, #0x4                // =4
    17d8:      	blr	x8
    17dc:      	add	x0, x24, #0x80
    17e0:      	add	x2, x22, #0xe0
    17e4:      	mov	w8, #0x4                // =4
    17e8:      	mov	w9, #0x8                // =8
    17ec:      	mov	w1, #0x8                // =8
    17f0:      	blr	x8
    17f4:      	add	x0, x24, #0x88
    17f8:      	add	x2, x22, #0x118
    17fc:      	mov	w8, #0x8                // =8
    1800:      	mov	w1, #0x8                // =8
    1804:      	blr	x23
    1808:      	ldp	x10, x11, [sp, #0x18]
    180c:      	mov	w9, #0x5ea0             // =24224
    1810:      	mov	w24, #0x98              // =152
    1814:      	b	0x2408 <generic_tracepoint_process_event+0x2408>
    1818:      	ldr	x10, [sp, #0x18]
    181c:      	cmp	w23, #0x26
    1820:      	mov	w9, #0x5ea0             // =24224
    1824:      	add	x8, sp, #0xd0
    1828:      	b.ne	0x306c <generic_tracepoint_process_event+0x306c>
    182c:      	ldr	x8, [x8, #0x8]
    1830:      	ldr	x22, [sp, #0x10]
    1834:      	add	x2, x19, w8, uxth
    1838:      	ubfx	w8, w8, #16, #12
    183c:      	add	x0, x22, #0x4
    1840:      	add	w1, w8, #0x1
    1844:      	mov	w8, #0x2d               // =45
    1848:      	blr	x8
    184c:      	b	0x1b3c <generic_tracepoint_process_event+0x1b3c>
    1850:      	str	xzr, [sp, #0x90]
    1854:      	mov	w8, #0xe                // =14
    1858:      	blr	x8
    185c:      	lsr	x8, x0, #32
    1860:      	add	x9, sp, #0xe0
    1864:      	add	x10, sp, #0xd8
    1868:      	str	x8, [sp, #0x88]
    186c:      	mov	w8, #0x4                // =4
    1870:      	add	x0, sp, #0xe0
    1874:      	add	x2, sp, #0xd8
    1878:      	mov	w1, #0x4                // =4
    187c:      	blr	x8
    1880:      	ldr	w8, [sp, #0xe0]
    1884:      	adrp	x0, 0x1000 <generic_tracepoint_process_event+0x1000>
    1888:      	add	x9, sp, #0x88
    188c:      	add	x1, sp, #0x88
    1890:      	str	w8, [sp, #0x90]
    1894:      	mov	w8, #0x1                // =1
    1898:      	ldr	x0, [x0]
    189c:      	blr	x8
    18a0:      	cbz	x0, 0x2040 <generic_tracepoint_process_event+0x2040>
    18a4:      	ldr	x25, [sp, #0x10]
    18a8:      	ldr	w23, [x0]
    18ac:      	add	x8, sp, #0xe0
    18b0:      	mov	w9, #0x4                // =4
    18b4:      	add	x2, sp, #0xe0
    18b8:      	mov	x22, x0
    18bc:      	mov	w1, #0x4                // =4
    18c0:      	mov	w24, #0x4               // =4
    18c4:      	mov	x0, x25
    18c8:      	blr	x9
    18cc:      	and	x23, x23, #0xfff
    18d0:      	add	x0, x25, #0x4
    18d4:      	mov	w8, #0x4                // =4
    18d8:      	mov	x2, x22
    18dc:      	add	x1, x23, #0x4
    18e0:      	blr	x8
    18e4:      	add	w23, w23, #0x8
    18e8:      	mov	w1, #0x4                // =4
    18ec:      	add	x8, x23, x22
    18f0:      	add	x0, x25, x23
    18f4:      	sub	x2, x8, #0x4
    18f8:      	blr	x24
    18fc:      	add	x24, x23, #0x4
    1900:      	b	0x3060 <generic_tracepoint_process_event+0x3060>
    1904:      	add	x25, sp, #0xd0
    1908:      	mov	w8, #0x1                // =1
    190c:      	mov	w9, #0x4                // =4
    1910:      	ldr	x23, [x25, #0x8]
    1914:      	add	x10, sp, #0x80
    1918:      	add	x0, sp, #0x80
    191c:      	mov	w1, #0x1                // =1
    1920:      	mov	x2, x23
    1924:      	blr	x9
    1928:      	ldrb	w8, [sp, #0x80]
    192c:      	cmp	w8, #0x1
    1930:      	b.ne	0x2028 <generic_tracepoint_process_event+0x2028>
    1934:      	add	x2, x23, #0x10
    1938:      	mov	w24, #0x8               // =8
    193c:      	add	x8, sp, #0x88
    1940:      	mov	w9, #0x4                // =4
    1944:      	add	x0, sp, #0x88
    1948:      	mov	w1, #0x8                // =8
    194c:      	mov	w23, #0x4               // =4
    1950:      	blr	x9
    1954:      	ldr	x2, [sp, #0x88]
    1958:      	add	x8, sp, #0xe0
    195c:      	mov	w9, #0x4                // =4
    1960:      	add	x0, sp, #0xe0
    1964:      	mov	w1, #0x8                // =8
    1968:      	blr	x9
    196c:      	ldr	x8, [sp, #0x88]
    1970:      	mov	w9, #0x4                // =4
    1974:      	add	x0, sp, #0xf0
    1978:      	mov	w1, #0x8                // =8
    197c:      	add	x2, x8, #0x8
    1980:      	add	x8, sp, #0xf0
    1984:      	blr	x9
    1988:      	ldr	x2, [x25, #0x10]
    198c:      	ldr	x25, [x25, #0x20]
    1990:      	cmp	x25, #0xfff
    1994:      	ldr	x8, [sp, #0x40]
    1998:      	add	x24, x8, x22
    199c:      	mov	w8, #0xfff              // =4095
    19a0:      	csel	x22, x25, x8, lo
    19a4:      	add	x0, x24, #0x98
    19a8:      	mov	w1, w22
    19ac:      	blr	x23
    19b0:      	tbnz	w0, #0x1f, 0x2268 <generic_tracepoint_process_event+0x2268>
    19b4:      	stp	w25, w22, [x24, #0x90]
    19b8:      	add	x24, x22, #0x8
    19bc:      	b	0x3060 <generic_tracepoint_process_event+0x3060>
    19c0:      	ldr	x24, [x21, #0x8]
    19c4:      	ldr	x22, [sp, #0x10]
    19c8:      	mov	w8, #0x4                // =4
    19cc:      	mov	w1, #0x4                // =4
    19d0:      	mov	w23, #0x4               // =4
    19d4:      	add	x0, x22, #0x28
    19d8:      	str	x29, [sp, #0x30]
    19dc:      	add	x2, x24, #0x98
    19e0:      	blr	x8
    19e4:      	add	x0, x22, #0x2c
    19e8:      	add	x2, x24, #0x70
    19ec:      	mov	w8, #0x4                // =4
    19f0:      	mov	w1, #0x4                // =4
    19f4:      	blr	x8
    19f8:      	add	x0, x22, #0x30
    19fc:      	add	x2, x24, #0x90
    1a00:      	mov	w8, #0x4                // =4
    1a04:      	mov	w1, #0x4                // =4
    1a08:      	blr	x8
    1a0c:      	add	x0, x22, #0x34
    1a10:      	add	x2, x24, #0xa8
    1a14:      	mov	w8, #0x4                // =4
    1a18:      	mov	w1, #0x4                // =4
    1a1c:      	blr	x8
    1a20:      	str	xzr, [sp, #0x88]
    1a24:      	add	x2, x24, #0xc8
    1a28:      	mov	w8, #0x8                // =8
    1a2c:      	add	x9, sp, #0x88
    1a30:      	mov	w10, #0x4               // =4
    1a34:      	add	x0, sp, #0x88
    1a38:      	mov	w1, #0x8                // =8
    1a3c:      	blr	x10
    1a40:      	add	x2, x24, #0xb8
    1a44:      	mov	w8, #0x2                // =2
    1a48:      	add	x9, sp, #0x80
    1a4c:      	mov	w10, #0x4               // =4
    1a50:      	add	x0, sp, #0x80
    1a54:      	mov	w1, #0x2                // =2
    1a58:      	blr	x10
    1a5c:      	ldr	x8, [sp, #0x88]
    1a60:      	ldrh	w9, [sp, #0x80]
    1a64:      	add	x0, sp, #0xcc
    1a68:      	mov	w1, #0x1                // =1
    1a6c:      	add	x22, x8, x9
    1a70:      	mov	w8, #0x1                // =1
    1a74:      	add	x9, sp, #0xcc
    1a78:      	mov	x2, x22
    1a7c:      	blr	x23
    1a80:      	ldrb	w8, [sp, #0xcc]
    1a84:      	lsr	w8, w8, #4
    1a88:      	cmp	w8, #0x6
    1a8c:      	b.eq	0x205c <generic_tracepoint_process_event+0x205c>
    1a90:      	cmp	w8, #0x4
    1a94:      	b.ne	0x3058 <generic_tracepoint_process_event+0x3058>
    1a98:      	add	x2, x22, #0x9
    1a9c:      	mov	w8, #0x1                // =1
    1aa0:      	add	x9, sp, #0x74
    1aa4:      	mov	w10, #0x4               // =4
    1aa8:      	add	x0, sp, #0x74
    1aac:      	mov	w1, #0x1                // =1
    1ab0:      	mov	w29, #0x4               // =4
    1ab4:      	blr	x10
    1ab8:      	ldr	x0, [sp, #0x10]
    1abc:      	ldrb	w8, [sp, #0x74]
    1ac0:      	mov	w25, #0x2               // =2
    1ac4:      	add	x2, x22, #0xc
    1ac8:      	mov	w1, #0x4                // =4
    1acc:      	mov	x23, x0
    1ad0:      	strh	w8, [x0, #0x24]
    1ad4:      	strh	w25, [x0, #0x26]
    1ad8:      	stp	xzr, xzr, [x0]
    1adc:      	str	xzr, [x0, #0x18]
    1ae0:      	mov	w8, #0x4                // =4
    1ae4:      	str	xzr, [x23, #0x10]!
    1ae8:      	blr	x8
    1aec:      	add	x2, x22, #0x10
    1af0:      	mov	w8, #0x4                // =4
    1af4:      	mov	x0, x23
    1af8:      	mov	w1, #0x4                // =4
    1afc:      	blr	x8
    1b00:      	add	x2, x24, #0xb6
    1b04:      	add	x8, sp, #0x78
    1b08:      	add	x0, sp, #0x78
    1b0c:      	mov	w1, #0x2                // =2
    1b10:      	blr	x29
    1b14:      	ldrb	w22, [sp, #0x74]
    1b18:      	b	0x2f1c <generic_tracepoint_process_event+0x2f1c>
    1b1c:      	ldr	x8, [x8, #0x8]
    1b20:      	ldr	x22, [sp, #0x10]
    1b24:      	mov	w9, #0x2d               // =45
    1b28:      	mov	w1, #0x11               // =17
    1b2c:      	add	x2, x8, #0x118
    1b30:      	add	x0, x22, #0x4
    1b34:      	mov	w8, #0x11               // =17
    1b38:      	blr	x9
    1b3c:      	mov	x24, x0
    1b40:      	tbnz	x0, #0x3f, 0x3064 <generic_tracepoint_process_event+0x3064>
    1b44:      	sub	w8, w24, #0x1
    1b48:      	add	x24, x24, #0x3
    1b4c:      	str	w8, [x22]
    1b50:      	b	0x3064 <generic_tracepoint_process_event+0x3064>
    1b54:      	ldr	x23, [sp, #0x10]
    1b58:      	ldr	x22, [x8, #0x8]
    1b5c:      	mov	w8, #0x2                // =2
    1b60:      	mov	w9, #0x4                // =4
    1b64:      	mov	w1, #0x2                // =2
    1b68:      	mov	x0, x23
    1b6c:      	str	xzr, [x23]
    1b70:      	stp	xzr, xzr, [x23, #0x8]
    1b74:      	mov	x2, x22
    1b78:      	blr	x9
    1b7c:      	tbnz	x0, #0x3f, 0x22e0 <generic_tracepoint_process_event+0x22e0>
    1b80:      	ldrh	w8, [x23]
    1b84:      	cmp	w8, #0xa
    1b88:      	b.eq	0x2294 <generic_tracepoint_process_event+0x2294>
    1b8c:      	cmp	w8, #0x2
    1b90:      	b.ne	0x22c8 <generic_tracepoint_process_event+0x22c8>
    1b94:      	add	x2, x22, #0x4
    1b98:      	add	x8, sp, #0x88
    1b9c:      	mov	w9, #0x4                // =4
    1ba0:      	add	x0, sp, #0x88
    1ba4:      	mov	w1, #0x4                // =4
    1ba8:      	mov	w23, #0x4               // =4
    1bac:      	blr	x9
    1bb0:      	ldr	w8, [sp, #0x88]
    1bb4:      	ldr	x9, [sp, #0x10]
    1bb8:      	add	x2, x22, #0x2
    1bbc:      	add	x0, x9, #0x2
    1bc0:      	str	x8, [x9, #0x8]
    1bc4:      	mov	w8, #0x2                // =2
    1bc8:      	b	0x22c0 <generic_tracepoint_process_event+0x22c0>
    1bcc:      	mov	w29, #0x6               // =6
    1bd0:      	b	0x82c <generic_tracepoint_process_event+0x82c>
    1bd4:      	add	x8, x0, x22
    1bd8:      	mov	x25, x0
    1bdc:      	str	xzr, [x24]
    1be0:      	add	x23, x8, #0x90
    1be4:      	ldr	x8, [sp, #0x38]
    1be8:      	tbnz	w8, #0x4, 0x219c <generic_tracepoint_process_event+0x219c>
    1bec:      	ldr	x9, [sp, #0x38]
    1bf0:      	mov	x8, xzr
    1bf4:      	and	w9, w9, #0xf
    1bf8:      	cmp	w9, #0x2
    1bfc:      	b.le	0x232c <generic_tracepoint_process_event+0x232c>
    1c00:      	cmp	w9, #0x3
    1c04:      	b.eq	0x25f4 <generic_tracepoint_process_event+0x25f4>
    1c08:      	cmp	w9, #0x4
    1c0c:      	b.eq	0x25fc <generic_tracepoint_process_event+0x25fc>
    1c10:      	cmp	w9, #0x5
    1c14:      	b.ne	0x2610 <generic_tracepoint_process_event+0x2610>
    1c18:      	mov	w8, #0x5e70             // =24176
    1c1c:      	b	0x2608 <generic_tracepoint_process_event+0x2608>
    1c20:      	ldr	x24, [sp, #0x10]
    1c24:      	ldr	x23, [sp, #0x40]
    1c28:      	mov	w1, #0x4                // =4
    1c2c:      	add	x8, x24, #0x40
    1c30:      	add	x2, x23, #0x8
    1c34:      	mov	x0, x24
    1c38:      	add	x22, x24, #0x28
    1c3c:      	str	x8, [sp, #0x38]
    1c40:      	mov	w8, #0x4                // =4
    1c44:      	blr	x8
    1c48:      	add	x0, x24, #0x4
    1c4c:      	add	x2, x23, #0xc
    1c50:      	mov	w8, #0x4                // =4
    1c54:      	mov	w1, #0x4                // =4
    1c58:      	blr	x8
    1c5c:      	add	x0, x24, #0x10
    1c60:      	add	x2, x23, #0x18
    1c64:      	mov	w8, #0x4                // =4
    1c68:      	mov	w1, #0x4                // =4
    1c6c:      	blr	x8
    1c70:      	add	x0, x24, #0x14
    1c74:      	add	x2, x23, #0x1c
    1c78:      	mov	w8, #0x4                // =4
    1c7c:      	mov	w1, #0x4                // =4
    1c80:      	blr	x8
    1c84:      	add	x0, x24, #0x8
    1c88:      	add	x2, x23, #0x10
    1c8c:      	mov	w8, #0x4                // =4
    1c90:      	mov	w1, #0x4                // =4
    1c94:      	blr	x8
    1c98:      	add	x0, x24, #0xc
    1c9c:      	add	x2, x23, #0x14
    1ca0:      	mov	w8, #0x4                // =4
    1ca4:      	mov	w1, #0x4                // =4
    1ca8:      	blr	x8
    1cac:      	add	x0, x24, #0x18
    1cb0:      	add	x2, x23, #0x20
    1cb4:      	mov	w8, #0x4                // =4
    1cb8:      	mov	w1, #0x4                // =4
    1cbc:      	blr	x8
    1cc0:      	add	x0, x24, #0x1c
    1cc4:      	add	x2, x23, #0x24
    1cc8:      	mov	w8, #0x4                // =4
    1ccc:      	mov	w1, #0x4                // =4
    1cd0:      	blr	x8
    1cd4:      	str	wzr, [x24, #0x24]
    1cd8:      	add	x0, x24, #0x20
    1cdc:      	add	x2, x23, #0x28
    1ce0:      	mov	w8, #0x4                // =4
    1ce4:      	mov	w1, #0x4                // =4
    1ce8:      	blr	x8
    1cec:      	add	x0, x24, #0x30
    1cf0:      	add	x2, x23, #0x40
    1cf4:      	mov	w25, #0x8               // =8
    1cf8:      	mov	w8, #0x4                // =4
    1cfc:      	mov	w1, #0x8                // =8
    1d00:      	blr	x8
    1d04:      	add	x0, x24, #0x38
    1d08:      	add	x2, x23, #0x30
    1d0c:      	mov	w8, #0x4                // =4
    1d10:      	mov	w1, #0x8                // =8
    1d14:      	blr	x8
    1d18:      	add	x2, x23, #0x38
    1d1c:      	mov	w8, #0x4                // =4
    1d20:      	mov	x0, x22
    1d24:      	mov	w1, #0x8                // =8
    1d28:      	blr	x8
    1d2c:      	add	x2, x23, #0x90
    1d30:      	add	x8, sp, #0x88
    1d34:      	mov	w9, #0x4                // =4
    1d38:      	add	x0, sp, #0x88
    1d3c:      	mov	w1, #0x8                // =8
    1d40:      	blr	x9
    1d44:      	ldr	x22, [sp, #0x88]
    1d48:      	ldr	x0, [sp, #0x38]
    1d4c:      	mov	w8, #0x4                // =4
    1d50:      	mov	w1, #0x4                // =4
    1d54:      	add	x2, x22, #0xc8
    1d58:      	blr	x8
    1d5c:      	add	x0, x24, #0x44
    1d60:      	add	x2, x22, #0xcc
    1d64:      	mov	w8, #0x4                // =4
    1d68:      	mov	w1, #0x4                // =4
    1d6c:      	blr	x8
    1d70:      	add	x0, x24, #0x48
    1d74:      	add	x2, x22, #0xd0
    1d78:      	mov	w8, #0x4                // =4
    1d7c:      	mov	w1, #0x4                // =4
    1d80:      	blr	x8
    1d84:      	add	x0, x24, #0x4c
    1d88:      	add	x2, x22, #0x158
    1d8c:      	mov	w8, #0x4                // =4
    1d90:      	mov	w1, #0x4                // =4
    1d94:      	blr	x8
    1d98:      	mov	w24, #0x50              // =80
    1d9c:      	b	0x23fc <generic_tracepoint_process_event+0x23fc>
    1da0:      	ldr	x24, [sp, #0x40]
    1da4:      	ldr	x23, [sp, #0x10]
    1da8:      	mov	w8, #0x4                // =4
    1dac:      	mov	w1, #0x4                // =4
    1db0:      	mov	w22, #0x4               // =4
    1db4:      	add	x2, x24, #0xc8
    1db8:      	mov	x0, x23
    1dbc:      	blr	x8
    1dc0:      	add	x0, x23, #0x4
    1dc4:      	add	x2, x24, #0xcc
    1dc8:      	mov	w8, #0x4                // =4
    1dcc:      	mov	w1, #0x4                // =4
    1dd0:      	blr	x8
    1dd4:      	add	x0, x23, #0x8
    1dd8:      	add	x2, x24, #0xd0
    1ddc:      	mov	w8, #0x4                // =4
    1de0:      	mov	w1, #0x4                // =4
    1de4:      	blr	x8
    1de8:      	add	x0, x23, #0xc
    1dec:      	add	x2, x24, #0x158
    1df0:      	mov	w1, #0x4                // =4
    1df4:      	blr	x22
    1df8:      	mov	w24, #0x10              // =16
    1dfc:      	b	0x2400 <generic_tracepoint_process_event+0x2400>
    1e00:      	ldr	x24, [sp, #0x40]
    1e04:      	ldr	x23, [sp, #0x10]
    1e08:      	mov	w8, #0x4                // =4
    1e0c:      	mov	w1, #0x4                // =4
    1e10:      	mov	w22, #0x4               // =4
    1e14:      	add	x2, x24, #0x38
    1e18:      	mov	x0, x23
    1e1c:      	blr	x8
    1e20:      	add	x0, x23, #0x4
    1e24:      	add	x2, x24, #0x3c
    1e28:      	mov	w8, #0x4                // =4
    1e2c:      	mov	w1, #0x4                // =4
    1e30:      	blr	x8
    1e34:      	add	x0, x23, #0x8
    1e38:      	add	x2, x24, #0x40
    1e3c:      	mov	w8, #0x4                // =4
    1e40:      	mov	w1, #0x4                // =4
    1e44:      	blr	x8
    1e48:      	add	x0, x23, #0xc
    1e4c:      	add	x2, x24, #0x44
    1e50:      	mov	w8, #0x4                // =4
    1e54:      	mov	w1, #0x4                // =4
    1e58:      	blr	x8
    1e5c:      	add	x0, x23, #0x10
    1e60:      	add	x2, x24, #0x80
    1e64:      	mov	w8, #0x10               // =16
    1e68:      	mov	w1, #0x10               // =16
    1e6c:      	blr	x22
    1e70:      	mov	w24, #0x20              // =32
    1e74:      	b	0x2400 <generic_tracepoint_process_event+0x2400>
    1e78:      	ldr	x23, [sp, #0x10]
    1e7c:      	ldr	x24, [sp, #0x40]
    1e80:      	mov	w8, #0x4                // =4
    1e84:      	mov	w1, #0x4                // =4
    1e88:      	mov	w22, #0x4               // =4
    1e8c:      	mov	x0, x23
    1e90:      	mov	x2, x24
    1e94:      	blr	x8
    1e98:      	add	x0, x23, #0x4
    1e9c:      	add	x2, x24, #0x4
    1ea0:      	mov	w8, #0x4                // =4
    1ea4:      	mov	w1, #0x4                // =4
    1ea8:      	blr	x8
    1eac:      	add	x0, x23, #0x8
    1eb0:      	add	x2, x24, #0x30
    1eb4:      	mov	w8, #0x10               // =16
    1eb8:      	b	0x1f3c <generic_tracepoint_process_event+0x1f3c>
    1ebc:      	ldr	x24, [sp, #0x40]
    1ec0:      	add	x8, sp, #0x88
    1ec4:      	mov	w9, #0x4                // =4
    1ec8:      	add	x0, sp, #0x88
    1ecc:      	mov	w1, #0x4                // =4
    1ed0:      	mov	w22, #0x4               // =4
    1ed4:      	add	x2, x24, #0x4
    1ed8:      	blr	x9
    1edc:      	ldr	w8, [sp, #0x88]
    1ee0:      	ldr	x23, [sp, #0x10]
    1ee4:      	add	x2, x24, #0xc
    1ee8:      	add	x0, sp, #0x88
    1eec:      	mov	w1, #0x4                // =4
    1ef0:      	str	w8, [x23]
    1ef4:      	add	x8, sp, #0x88
    1ef8:      	blr	x22
    1efc:      	ldr	w8, [sp, #0x88]
    1f00:      	add	x2, x24, #0x50
    1f04:      	add	x9, sp, #0x88
    1f08:      	mov	w10, #0x2d              // =45
    1f0c:      	str	w8, [x23, #0x4]
    1f10:      	mov	w8, #0x8                // =8
    1f14:      	add	x0, sp, #0x88
    1f18:      	mov	w1, #0x8                // =8
    1f1c:      	mov	w22, #0x2d              // =45
    1f20:      	blr	x10
    1f24:      	ldr	x8, [sp, #0x88]
    1f28:      	add	x0, x23, #0x8
    1f2c:      	mov	w9, #0x10               // =16
    1f30:      	add	x8, x8, #0x3f8
    1f34:      	ldr	x8, [sp, #0x88]
    1f38:      	add	x2, x8, #0x3f8
    1f3c:      	mov	w1, #0x10               // =16
    1f40:      	blr	x22
    1f44:      	mov	w24, #0x18              // =24
    1f48:      	b	0x2400 <generic_tracepoint_process_event+0x2400>
    1f4c:      	ldr	x11, [sp, #0x10]
    1f50:      	ldr	x2, [sp, #0x40]
    1f54:      	mov	w8, #0x8                // =8
    1f58:      	mov	w9, #0x4                // =4
    1f5c:      	add	x10, sp, #0x88
    1f60:      	add	x0, sp, #0x88
    1f64:      	mov	w1, #0x8                // =8
    1f68:      	stp	xzr, xzr, [x11, #0x40]
    1f6c:      	stp	xzr, xzr, [x11, #0x30]
    1f70:      	stp	xzr, xzr, [x11, #0x20]
    1f74:      	stp	xzr, xzr, [x11, #0x10]
    1f78:      	stp	xzr, xzr, [x11]
    1f7c:      	blr	x9
    1f80:      	mov	x24, xzr
    1f84:      	cbnz	x0, 0x23fc <generic_tracepoint_process_event+0x23fc>
    1f88:      	ldr	x8, [sp, #0x10]
    1f8c:      	mov	w9, #0x3f               // =63
    1f90:      	mov	w10, #0x2d              // =45
    1f94:      	mov	w1, #0x3f               // =63
    1f98:      	add	x0, x8, #0x10
    1f9c:      	ldr	x8, [sp, #0x88]
    1fa0:      	ldr	x2, [sp, #0x88]
    1fa4:      	blr	x10
    1fa8:      	tbnz	x0, #0x3f, 0x255c <generic_tracepoint_process_event+0x255c>
    1fac:      	ldr	x24, [sp, #0x40]
    1fb0:      	mov	w22, #0x8               // =8
    1fb4:      	add	x8, sp, #0xe0
    1fb8:      	mov	w9, #0x4                // =4
    1fbc:      	add	x0, sp, #0xe0
    1fc0:      	mov	w1, #0x8                // =8
    1fc4:      	mov	w23, #0x4               // =4
    1fc8:      	add	x2, x24, #0x8
    1fcc:      	blr	x9
    1fd0:      	ldr	x8, [sp, #0x10]
    1fd4:      	add	x10, sp, #0xd0
    1fd8:      	mov	w9, #0x4                // =4
    1fdc:      	mov	w1, #0x8                // =8
    1fe0:      	add	x0, x8, #0x8
    1fe4:      	ldr	x8, [x10, #0x10]
    1fe8:      	add	x8, x8, #0x360
    1fec:      	ldr	x8, [x10, #0x10]
    1ff0:      	add	x2, x8, #0x360
    1ff4:      	blr	x9
    1ff8:      	add	x2, x24, #0x58
    1ffc:      	add	x8, sp, #0xe0
    2000:      	add	x0, sp, #0xe0
    2004:      	mov	w1, #0x4                // =4
    2008:      	blr	x23
    200c:      	cbnz	x0, 0x1d98 <generic_tracepoint_process_event+0x1d98>
    2010:      	ldr	w8, [sp, #0xe0]
    2014:      	ldr	x9, [sp, #0x10]
    2018:      	cmp	w8, #0x0
    201c:      	cset	w8, ne
    2020:      	str	w8, [x9]
    2024:      	b	0x1d98 <generic_tracepoint_process_event+0x1d98>
    2028:      	ldr	x8, [sp, #0x40]
    202c:      	mov	w24, #0x8               // =8
    2030:      	mov	w25, #0x5efc            // =24316
    2034:      	add	x8, x8, x22
    2038:      	str	xzr, [x8, #0x90]
    203c:      	b	0x3064 <generic_tracepoint_process_event+0x3064>
    2040:      	mov	x24, #-0x1              // =-1
    2044:      	b	0x3060 <generic_tracepoint_process_event+0x3060>
    2048:      	mov	w29, #0x7               // =7
    204c:      	adrp	x21, 0x2000 <generic_tracepoint_process_event+0x2000>
    2050:      	mov	w25, #0x5efc            // =24316
    2054:      	ldr	x21, [x21]
    2058:      	b	0x82c <generic_tracepoint_process_event+0x82c>
    205c:      	str	wzr, [sp, #0xe0]
    2060:      	adrp	x0, 0x2000 <generic_tracepoint_process_event+0x2000>
    2064:      	ldr	x25, [sp, #0x88]
    2068:      	mov	w8, #0x1                // =1
    206c:      	add	x9, sp, #0xe0
    2070:      	add	x1, sp, #0xe0
    2074:      	ldrh	w22, [sp, #0x80]
    2078:      	ldr	x0, [x0]
    207c:      	add	x21, x25, x22
    2080:      	blr	x8
    2084:      	cbz	x0, 0x2ed8 <generic_tracepoint_process_event+0x2ed8>
    2088:      	mov	w8, #0xff               // =255
    208c:      	strh	w22, [x0]
    2090:      	strb	wzr, [x0, #0x7]
    2094:      	add	x29, x0, #0x6
    2098:      	add	x2, x21, #0x6
    209c:      	mov	w9, #0x4                // =4
    20a0:      	strb	w8, [x0, #0x5]
    20a4:      	mov	w8, #0x1                // =1
    20a8:      	mov	x23, x0
    20ac:      	mov	x0, x29
    20b0:      	mov	w1, #0x1                // =1
    20b4:      	blr	x9
    20b8:      	tbnz	x0, #0x3f, 0x2ed8 <generic_tracepoint_process_event+0x2ed8>
    20bc:      	ldrb	w8, [x23, #0x5]
    20c0:      	cmp	w8, #0x32
    20c4:      	b.gt	0x256c <generic_tracepoint_process_event+0x256c>
    20c8:      	cbz	w8, 0x25e8 <generic_tracepoint_process_event+0x25e8>
    20cc:      	cmp	w8, #0x2b
    20d0:      	b.eq	0x25e8 <generic_tracepoint_process_event+0x25e8>
    20d4:      	cmp	w8, #0x2c
    20d8:      	b.ne	0x29ec <generic_tracepoint_process_event+0x29ec>
    20dc:      	mov	w8, #0x8                // =8
    20e0:      	b	0x2938 <generic_tracepoint_process_event+0x2938>
    20e4:      	ldr	x0, [sp, #0x10]
    20e8:      	add	x2, x23, #0x48
    20ec:      	mov	w24, #0x10              // =16
    20f0:      	mov	w8, #0x4                // =4
    20f4:      	mov	w1, #0x10               // =16
    20f8:      	mov	w25, #0x4               // =4
    20fc:      	blr	x8
    2100:      	add	x2, x23, #0x38
    2104:      	mov	x0, x22
    2108:      	mov	w1, #0x10               // =16
    210c:      	blr	x25
    2110:      	ldr	x25, [sp, #0x10]
    2114:      	add	x22, x23, #0xc
    2118:      	add	x2, x23, #0xe
    211c:      	mov	w23, #0x2               // =2
    2120:      	mov	w8, #0x4                // =4
    2124:      	mov	w1, #0x2                // =2
    2128:      	mov	w24, #0x4               // =4
    212c:      	add	x0, x25, #0x20
    2130:      	blr	x8
    2134:      	add	x0, x25, #0x22
    2138:      	mov	w1, #0x2                // =2
    213c:      	mov	x2, x22
    2140:      	blr	x24
    2144:      	ldrh	w8, [x25, #0x22]
    2148:      	adrp	x0, 0x2000 <generic_tracepoint_process_event+0x2000>
    214c:      	add	x9, sp, #0x88
    2150:      	add	x1, sp, #0x88
    2154:      	rev	w8, w8
    2158:      	lsr	w8, w8, #16
    215c:      	strh	w8, [x25, #0x22]
    2160:      	add	x8, sp, #0xd0
    2164:      	ldr	x8, [x8, #0x8]
    2168:      	str	x8, [sp, #0x88]
    216c:      	mov	w8, #0x1                // =1
    2170:      	ldr	x0, [x0]
    2174:      	blr	x8
    2178:      	cbz	x0, 0x305c <generic_tracepoint_process_event+0x305c>
    217c:      	ldr	w8, [x0]
    2180:      	ldr	x9, [sp, #0x40]
    2184:      	str	w8, [x9, #0x10]
    2188:      	ldr	x8, [x0, #0x8]
    218c:      	str	x8, [x9, #0x18]
    2190:      	ldr	w8, [x0, #0x4]
    2194:      	str	w8, [x9, #0x7c]
    2198:      	b	0x305c <generic_tracepoint_process_event+0x305c>
    219c:      	mov	w8, #0xe                // =14
    21a0:      	blr	x8
    21a4:      	cmn	x0, #0x16
    21a8:      	b.ne	0x21cc <generic_tracepoint_process_event+0x21cc>
    21ac:      	add	x2, x19, #0xe8
    21b0:      	mov	w8, #0x8                // =8
    21b4:      	mov	w9, #0x4                // =4
    21b8:      	add	x10, sp, #0x88
    21bc:      	add	x0, sp, #0x88
    21c0:      	mov	w1, #0x8                // =8
    21c4:      	blr	x9
    21c8:      	ldr	x0, [sp, #0x88]
    21cc:      	ldr	x10, [x25, #0x8]
    21d0:      	ldr	x9, [sp, #0x40]
    21d4:      	mov	x3, xzr
    21d8:      	add	x1, sp, #0xe0
    21dc:      	add	x2, sp, #0x88
    21e0:      	mov	x24, x25
    21e4:      	ldr	x8, [x25, #0x60]
    21e8:      	add	x21, sp, #0xd0
    21ec:      	str	xzr, [sp, #0x98]
    21f0:      	stp	x10, x9, [sp, #0x88]
    21f4:      	add	x9, sp, #0xd0
    21f8:      	add	x10, sp, #0x88
    21fc:      	stp	x8, x0, [x9, #0x10]
    2200:      	adrp	x0, 0x2000 <generic_tracepoint_process_event+0x2000>
    2204:      	mov	w8, #0x2                // =2
    2208:      	add	x9, sp, #0xe0
    220c:      	ldr	x0, [x0]
    2210:      	blr	x8
    2214:      	cbz	x0, 0x25b0 <generic_tracepoint_process_event+0x25b0>
    2218:      	neg	w8, w0
    221c:      	adrp	x22, 0x2000 <generic_tracepoint_process_event+0x2000>
    2220:      	mov	w9, #0x1                // =1
    2224:      	strh	w8, [sp, #0xf0]
    2228:      	mov	w8, #0x5                // =5
    222c:      	add	x1, sp, #0xf0
    2230:      	mov	w24, #0x1               // =1
    2234:      	strh	w8, [sp, #0xf2]
    2238:      	mov	x8, #0x46               // =70
    223c:      	movk	x8, #0x2, lsl #32
    2240:      	stur	x8, [x21, #0x24]
    2244:      	add	x8, sp, #0xf0
    2248:      	ldr	x22, [x22]
    224c:      	mov	x0, x22
    2250:      	blr	x9
    2254:      	cbz	x0, 0x258c <generic_tracepoint_process_event+0x258c>
    2258:      	ldr	w8, [x0]
    225c:      	add	w8, w8, #0x1
    2260:      	str	w8, [x0]
    2264:      	b	0x25b0 <generic_tracepoint_process_event+0x25b0>
    2268:      	mov	w8, #-0x2               // =-2
    226c:      	mov	w25, #0x5efc            // =24316
    2270:      	stur	w8, [x24, #0x90]
    2274:      	mov	w24, #0x4               // =4
    2278:      	b	0x3064 <generic_tracepoint_process_event+0x3064>
    227c:      	cmp	w9, #0x1
    2280:      	b.eq	0x2420 <generic_tracepoint_process_event+0x2420>
    2284:      	cmp	w9, #0x2
    2288:      	b.ne	0x2470 <generic_tracepoint_process_event+0x2470>
    228c:      	mov	w10, #0x5e58            // =24152
    2290:      	b	0x2424 <generic_tracepoint_process_event+0x2424>
    2294:      	ldr	x24, [sp, #0x10]
    2298:      	add	x2, x22, #0x8
    229c:      	mov	w8, #0x10               // =16
    22a0:      	mov	w9, #0x4                // =4
    22a4:      	mov	w1, #0x10               // =16
    22a8:      	mov	w23, #0x4               // =4
    22ac:      	add	x0, x24, #0x8
    22b0:      	blr	x9
    22b4:      	add	x0, x24, #0x2
    22b8:      	add	x2, x22, #0x2
    22bc:      	mov	w8, #0x2                // =2
    22c0:      	mov	w1, #0x2                // =2
    22c4:      	blr	x23
    22c8:      	ldr	x9, [sp, #0x10]
    22cc:      	mov	w25, #0x5efc            // =24316
    22d0:      	ldrh	w8, [x9, #0x2]
    22d4:      	rev	w8, w8
    22d8:      	lsr	w8, w8, #16
    22dc:      	strh	w8, [x9, #0x2]
    22e0:      	mov	w24, #0x18              // =24
    22e4:      	b	0x3064 <generic_tracepoint_process_event+0x3064>
    22e8:      	mov	x24, xzr
    22ec:      	mov	w25, #0x5efc            // =24316
    22f0:      	mov	x10, x22
    22f4:      	mov	w9, #0x5ea0             // =24224
    22f8:      	mov	x11, x23
    22fc:      	b	0x2408 <generic_tracepoint_process_event+0x2408>
    2300:      	add	x2, x22, #0x3
    2304:      	mov	w22, #0x6b              // =107
    2308:      	mov	w8, #0x71               // =113
    230c:      	mov	w1, #0x6b               // =107
    2310:      	blr	x8
    2314:      	mov	w25, #0x5efc            // =24316
    2318:      	tbnz	w0, #0x1f, 0x2324 <generic_tracepoint_process_event+0x2324>
    231c:      	ldr	x8, [sp, #0x10]
    2320:      	strb	w22, [x8, #0x3]
    2324:      	mov	w24, #0x70              // =112
    2328:      	b	0x3064 <generic_tracepoint_process_event+0x3064>
    232c:      	cmp	w9, #0x1
    2330:      	b.eq	0x2604 <generic_tracepoint_process_event+0x2604>
    2334:      	cmp	w9, #0x2
    2338:      	b.ne	0x2610 <generic_tracepoint_process_event+0x2610>
    233c:      	mov	w8, #0x5e58             // =24152
    2340:      	b	0x2608 <generic_tracepoint_process_event+0x2608>
    2344:      	ldr	x0, [sp, #0x10]
    2348:      	add	x2, x23, #0x48
    234c:      	mov	w24, #0x10              // =16
    2350:      	mov	w8, #0x4                // =4
    2354:      	mov	w1, #0x10               // =16
    2358:      	mov	w25, #0x4               // =4
    235c:      	blr	x8
    2360:      	add	x2, x23, #0x38
    2364:      	mov	x0, x22
    2368:      	mov	w1, #0x10               // =16
    236c:      	blr	x25
    2370:      	ldr	x25, [sp, #0x10]
    2374:      	add	x22, x23, #0xc
    2378:      	add	x2, x23, #0xe
    237c:      	mov	w23, #0x2               // =2
    2380:      	mov	w8, #0x4                // =4
    2384:      	mov	w1, #0x2                // =2
    2388:      	mov	w24, #0x4               // =4
    238c:      	add	x0, x25, #0x20
    2390:      	blr	x8
    2394:      	add	x0, x25, #0x22
    2398:      	mov	w1, #0x2                // =2
    239c:      	mov	x2, x22
    23a0:      	blr	x24
    23a4:      	ldrh	w8, [x25, #0x22]
    23a8:      	rev	w8, w8
    23ac:      	lsr	w8, w8, #16
    23b0:      	strh	w8, [x25, #0x22]
    23b4:      	ldr	x8, [sp, #0x10]
    23b8:      	adrp	x0, 0x2000 <generic_tracepoint_process_event+0x2000>
    23bc:      	add	x9, sp, #0x88
    23c0:      	add	x1, sp, #0x88
    23c4:      	ldr	x8, [x8, #0x28]
    23c8:      	str	x8, [sp, #0x88]
    23cc:      	mov	w8, #0x1                // =1
    23d0:      	ldr	x0, [x0]
    23d4:      	blr	x8
    23d8:      	cbz	x0, 0x23f8 <generic_tracepoint_process_event+0x23f8>
    23dc:      	ldr	w8, [x0]
    23e0:      	ldr	x9, [sp, #0x38]
    23e4:      	str	w8, [x9, #0x10]
    23e8:      	ldr	x8, [x0, #0x8]
    23ec:      	str	x8, [x9, #0x18]
    23f0:      	ldr	w8, [x0, #0x4]
    23f4:      	str	w8, [x9, #0x7c]
    23f8:      	mov	w24, #0x40              // =64
    23fc:      	mov	w25, #0x5efc            // =24316
    2400:      	ldp	x10, x11, [sp, #0x18]
    2404:      	mov	w9, #0x5ea0             // =24224
    2408:      	ldr	x23, [sp, #0x108]
    240c:      	b	0x3078 <generic_tracepoint_process_event+0x3078>
    2410:      	mov	w10, #0x5e60            // =24160
    2414:      	b	0x2424 <generic_tracepoint_process_event+0x2424>
    2418:      	mov	w10, #0x5e68            // =24168
    241c:      	b	0x2424 <generic_tracepoint_process_event+0x2424>
    2420:      	mov	w10, #0x5e50            // =24144
    2424:      	ldr	x9, [sp, #0x38]
    2428:      	add	x9, x9, x10
    242c:      	ldr	x23, [x9]
    2430:      	tbnz	w8, #0x4, 0x247c <generic_tracepoint_process_event+0x247c>
    2434:      	cbz	x23, 0x254c <generic_tracepoint_process_event+0x254c>
    2438:      	ldr	x2, [sp, #0x40]
    243c:      	mov	w8, #0x10               // =16
    2440:      	mov	w9, #0x4                // =4
    2444:      	add	x10, sp, #0x88
    2448:      	add	x0, sp, #0x88
    244c:      	mov	w1, #0x10               // =16
    2450:      	blr	x9
    2454:      	tbnz	w0, #0x1f, 0x2920 <generic_tracepoint_process_event+0x2920>
    2458:      	ldr	x22, [sp, #0x90]
    245c:      	cmp	x22, #0xffe
    2460:      	b.ls	0x2690 <generic_tracepoint_process_event+0x2690>
    2464:      	mov	w8, #-0x3               // =-3
    2468:      	str	w8, [x25]
    246c:      	b	0x2674 <generic_tracepoint_process_event+0x2674>
    2470:      	mov	x23, xzr
    2474:      	mov	x22, xzr
    2478:      	tbz	w8, #0x4, 0x2550 <generic_tracepoint_process_event+0x2550>
    247c:      	mov	w8, #0xe                // =14
    2480:      	blr	x8
    2484:      	cmn	x0, #0x16
    2488:      	b.ne	0x24ac <generic_tracepoint_process_event+0x24ac>
    248c:      	add	x2, x19, #0xe8
    2490:      	mov	w8, #0x8                // =8
    2494:      	mov	w9, #0x4                // =4
    2498:      	add	x10, sp, #0x88
    249c:      	add	x0, sp, #0x88
    24a0:      	mov	w1, #0x8                // =8
    24a4:      	blr	x9
    24a8:      	ldr	x0, [sp, #0x88]
    24ac:      	ldp	x11, x8, [sp, #0x38]
    24b0:      	mov	x3, xzr
    24b4:      	add	x1, sp, #0xe0
    24b8:      	add	x2, sp, #0x88
    24bc:      	ldr	x9, [x11, #0x60]
    24c0:      	ldr	x10, [x11, #0x8]
    24c4:      	add	x21, sp, #0xd0
    24c8:      	str	x23, [sp, #0x98]
    24cc:      	stp	x10, x8, [sp, #0x88]
    24d0:      	add	x8, sp, #0xd0
    24d4:      	add	x10, sp, #0x88
    24d8:      	stp	x9, x0, [x8, #0x10]
    24dc:      	adrp	x0, 0x2000 <generic_tracepoint_process_event+0x2000>
    24e0:      	mov	w8, #0x2                // =2
    24e4:      	add	x9, sp, #0xe0
    24e8:      	ldr	x0, [x0]
    24ec:      	blr	x8
    24f0:      	cbz	x0, 0x25dc <generic_tracepoint_process_event+0x25dc>
    24f4:      	neg	w8, w0
    24f8:      	adrp	x22, 0x2000 <generic_tracepoint_process_event+0x2000>
    24fc:      	mov	w9, #0x1                // =1
    2500:      	strh	w8, [sp, #0xf0]
    2504:      	mov	w8, #0x5                // =5
    2508:      	add	x1, sp, #0xf0
    250c:      	mov	w23, #0x1               // =1
    2510:      	strh	w8, [sp, #0xf2]
    2514:      	mov	x8, #0x57               // =87
    2518:      	movk	x8, #0x2, lsl #32
    251c:      	stur	x8, [x21, #0x24]
    2520:      	add	x8, sp, #0xf0
    2524:      	ldr	x22, [x22]
    2528:      	mov	x0, x22
    252c:      	blr	x9
    2530:      	cbz	x0, 0x25b8 <generic_tracepoint_process_event+0x25b8>
    2534:      	ldr	w8, [x0]
    2538:      	add	w8, w8, #0x1
    253c:      	str	w8, [x0]
    2540:      	mov	w8, #-0x4               // =-4
    2544:      	str	w8, [x25]
    2548:      	b	0x2674 <generic_tracepoint_process_event+0x2674>
    254c:      	mov	x22, xzr
    2550:      	stp	w22, w22, [x25]
    2554:      	add	x24, x22, #0x8
    2558:      	b	0x2678 <generic_tracepoint_process_event+0x2678>
    255c:      	mov	x24, xzr
    2560:      	b	0x23fc <generic_tracepoint_process_event+0x23fc>
    2564:      	mov	w29, #0x9               // =9
    2568:      	b	0x204c <generic_tracepoint_process_event+0x204c>
    256c:      	cmp	w8, #0x33
    2570:      	b.eq	0x292c <generic_tracepoint_process_event+0x292c>
    2574:      	cmp	w8, #0x3c
    2578:      	b.eq	0x25e8 <generic_tracepoint_process_event+0x25e8>
    257c:      	cmp	w8, #0xff
    2580:      	b.ne	0x29ec <generic_tracepoint_process_event+0x29ec>
    2584:      	mov	w8, #0x28               // =40
    2588:      	b	0x2938 <generic_tracepoint_process_event+0x2938>
    258c:      	str	w24, [sp, #0x80]
    2590:      	mov	x3, xzr
    2594:      	mov	w8, #0x2                // =2
    2598:      	add	x9, sp, #0xf0
    259c:      	add	x10, sp, #0x80
    25a0:      	add	x1, sp, #0xf0
    25a4:      	add	x2, sp, #0x80
    25a8:      	mov	x0, x22
    25ac:      	blr	x8
    25b0:      	mov	w8, #-0x4               // =-4
    25b4:      	b	0x2670 <generic_tracepoint_process_event+0x2670>
    25b8:      	str	w23, [sp, #0xd8]
    25bc:      	mov	x3, xzr
    25c0:      	mov	w8, #0x2                // =2
    25c4:      	add	x9, sp, #0xf0
    25c8:      	add	x10, sp, #0xd8
    25cc:      	add	x1, sp, #0xf0
    25d0:      	add	x2, sp, #0xd8
    25d4:      	mov	x0, x22
    25d8:      	blr	x8
    25dc:      	mov	w8, #-0x4               // =-4
    25e0:      	str	w8, [x25]
    25e4:      	b	0x2674 <generic_tracepoint_process_event+0x2674>
    25e8:      	ldrb	w8, [x23, #0x7]
    25ec:      	lsl	w8, w8, #3
    25f0:      	b	0x2934 <generic_tracepoint_process_event+0x2934>
    25f4:      	mov	w8, #0x5e60             // =24160
    25f8:      	b	0x2608 <generic_tracepoint_process_event+0x2608>
    25fc:      	mov	w8, #0x5e68             // =24168
    2600:      	b	0x2608 <generic_tracepoint_process_event+0x2608>
    2604:      	mov	w8, #0x5e50             // =24144
    2608:      	add	x8, x25, x8
    260c:      	ldr	x8, [x8]
    2610:      	add	x21, sp, #0xd0
    2614:      	add	x9, sp, #0xd0
    2618:      	add	x10, sp, #0xd8
    261c:      	str	x8, [x21, #0x8]
    2620:      	mov	w8, #0x8                // =8
    2624:      	mov	w11, #0x4               // =4
    2628:      	add	x0, sp, #0xd0
    262c:      	add	x2, sp, #0xd8
    2630:      	mov	w1, #0x8                // =8
    2634:      	mov	w25, #0x4               // =4
    2638:      	blr	x11
    263c:      	ldr	x24, [x21]
    2640:      	mov	w8, #0xfff              // =4095
    2644:      	ldr	x2, [sp, #0x40]
    2648:      	add	x0, x23, #0x8
    264c:      	cmp	x24, #0xfff
    2650:      	csel	x22, x24, x8, lo
    2654:      	mov	w1, w22
    2658:      	blr	x25
    265c:      	tbnz	w0, #0x1f, 0x266c <generic_tracepoint_process_event+0x266c>
    2660:      	stp	w24, w22, [x23]
    2664:      	add	x24, x22, #0x8
    2668:      	b	0x2678 <generic_tracepoint_process_event+0x2678>
    266c:      	mov	w8, #-0x2               // =-2
    2670:      	str	w8, [x23]
    2674:      	mov	w24, #0x4               // =4
    2678:      	adrp	x21, 0x2000 <generic_tracepoint_process_event+0x2000>
    267c:      	ldp	x10, x11, [sp, #0x18]
    2680:      	mov	w25, #0x5efc            // =24316
    2684:      	mov	w9, #0x5ea0             // =24224
    2688:      	ldr	x21, [x21]
    268c:      	b	0x2408 <generic_tracepoint_process_event+0x2408>
    2690:      	ldr	x8, [sp, #0x108]
    2694:      	mov	w9, #0x4                // =4
    2698:      	mov	w1, w22
    269c:      	add	x21, x8, #0xc
    26a0:      	ldr	x8, [sp, #0x88]
    26a4:      	add	x0, x24, x21
    26a8:      	ldr	x2, [sp, #0x88]
    26ac:      	blr	x9
    26b0:      	tbnz	w0, #0x1f, 0x2920 <generic_tracepoint_process_event+0x2920>
    26b4:      	cmp	x23, #0x1
    26b8:      	b.eq	0x2550 <generic_tracepoint_process_event+0x2550>
    26bc:      	ldr	x8, [sp, #0x40]
    26c0:      	mov	w9, #0x4                // =4
    26c4:      	add	x10, sp, #0x88
    26c8:      	add	x0, sp, #0x88
    26cc:      	mov	w1, #0x10               // =16
    26d0:      	add	x2, x8, #0x10
    26d4:      	mov	w8, #0x10               // =16
    26d8:      	blr	x9
    26dc:      	tbnz	w0, #0x1f, 0x2920 <generic_tracepoint_process_event+0x2920>
    26e0:      	ldr	x8, [sp, #0x90]
    26e4:      	cmp	x8, #0xffe
    26e8:      	str	x8, [sp, #0x38]
    26ec:      	b.hi	0x2464 <generic_tracepoint_process_event+0x2464>
    26f0:      	add	x21, x22, x21
    26f4:      	ldr	x8, [sp, #0x88]
    26f8:      	mov	w9, #0x4                // =4
    26fc:      	ldr	x1, [sp, #0x38]
    2700:      	add	x0, x24, x21
    2704:      	ldr	x2, [sp, #0x88]
    2708:      	blr	x9
    270c:      	tbnz	w0, #0x1f, 0x2920 <generic_tracepoint_process_event+0x2920>
    2710:      	ldr	x8, [sp, #0x38]
    2714:      	cmp	x23, #0x3
    2718:      	add	x22, x8, x22
    271c:      	b.lo	0x2550 <generic_tracepoint_process_event+0x2550>
    2720:      	ldr	x8, [sp, #0x40]
    2724:      	mov	w9, #0x4                // =4
    2728:      	add	x10, sp, #0x88
    272c:      	add	x0, sp, #0x88
    2730:      	mov	w1, #0x10               // =16
    2734:      	add	x2, x8, #0x20
    2738:      	mov	w8, #0x10               // =16
    273c:      	blr	x9
    2740:      	tbnz	w0, #0x1f, 0x2920 <generic_tracepoint_process_event+0x2920>
    2744:      	ldr	x8, [sp, #0x90]
    2748:      	cmp	x8, #0xffe
    274c:      	str	x8, [sp, #0x30]
    2750:      	b.hi	0x2464 <generic_tracepoint_process_event+0x2464>
    2754:      	ldp	x1, x8, [sp, #0x30]
    2758:      	mov	w9, #0x4                // =4
    275c:      	add	x21, x8, x21
    2760:      	and	x8, x21, #0x3fff
    2764:      	add	x0, x24, x8
    2768:      	ldr	x8, [sp, #0x88]
    276c:      	ldr	x2, [sp, #0x88]
    2770:      	blr	x9
    2774:      	tbnz	w0, #0x1f, 0x2920 <generic_tracepoint_process_event+0x2920>
    2778:      	ldr	x8, [sp, #0x30]
    277c:      	cmp	x23, #0x3
    2780:      	add	x22, x8, x22
    2784:      	b.eq	0x2550 <generic_tracepoint_process_event+0x2550>
    2788:      	ldr	x8, [sp, #0x40]
    278c:      	mov	w9, #0x4                // =4
    2790:      	add	x10, sp, #0x88
    2794:      	add	x0, sp, #0x88
    2798:      	mov	w1, #0x10               // =16
    279c:      	add	x2, x8, #0x30
    27a0:      	mov	w8, #0x10               // =16
    27a4:      	blr	x9
    27a8:      	tbnz	w0, #0x1f, 0x2920 <generic_tracepoint_process_event+0x2920>
    27ac:      	ldr	x8, [sp, #0x90]
    27b0:      	cmp	x8, #0xffe
    27b4:      	str	x8, [sp, #0x38]
    27b8:      	b.hi	0x2464 <generic_tracepoint_process_event+0x2464>
    27bc:      	ldp	x8, x1, [sp, #0x30]
    27c0:      	mov	w9, #0x4                // =4
    27c4:      	add	x21, x8, x21
    27c8:      	and	x8, x21, #0x3fff
    27cc:      	add	x0, x24, x8
    27d0:      	ldr	x8, [sp, #0x88]
    27d4:      	ldr	x2, [sp, #0x88]
    27d8:      	blr	x9
    27dc:      	tbnz	w0, #0x1f, 0x2920 <generic_tracepoint_process_event+0x2920>
    27e0:      	ldr	x8, [sp, #0x38]
    27e4:      	cmp	x23, #0x5
    27e8:      	add	x22, x8, x22
    27ec:      	b.lo	0x2550 <generic_tracepoint_process_event+0x2550>
    27f0:      	ldr	x8, [sp, #0x40]
    27f4:      	mov	w9, #0x4                // =4
    27f8:      	add	x10, sp, #0x88
    27fc:      	add	x0, sp, #0x88
    2800:      	mov	w1, #0x10               // =16
    2804:      	add	x2, x8, #0x40
    2808:      	mov	w8, #0x10               // =16
    280c:      	blr	x9
    2810:      	tbnz	w0, #0x1f, 0x2920 <generic_tracepoint_process_event+0x2920>
    2814:      	ldr	x8, [sp, #0x90]
    2818:      	cmp	x8, #0xffe
    281c:      	str	x8, [sp, #0x30]
    2820:      	b.hi	0x2464 <generic_tracepoint_process_event+0x2464>
    2824:      	ldp	x1, x8, [sp, #0x30]
    2828:      	mov	w9, #0x4                // =4
    282c:      	add	x21, x8, x21
    2830:      	and	x8, x21, #0x3fff
    2834:      	add	x0, x24, x8
    2838:      	ldr	x8, [sp, #0x88]
    283c:      	ldr	x2, [sp, #0x88]
    2840:      	blr	x9
    2844:      	tbnz	w0, #0x1f, 0x2920 <generic_tracepoint_process_event+0x2920>
    2848:      	ldr	x8, [sp, #0x30]
    284c:      	cmp	x23, #0x5
    2850:      	add	x22, x8, x22
    2854:      	b.eq	0x2550 <generic_tracepoint_process_event+0x2550>
    2858:      	ldr	x8, [sp, #0x40]
    285c:      	mov	w9, #0x4                // =4
    2860:      	add	x10, sp, #0x88
    2864:      	add	x0, sp, #0x88
    2868:      	mov	w1, #0x10               // =16
    286c:      	add	x2, x8, #0x50
    2870:      	mov	w8, #0x10               // =16
    2874:      	blr	x9
    2878:      	tbnz	w0, #0x1f, 0x2920 <generic_tracepoint_process_event+0x2920>
    287c:      	ldr	x8, [sp, #0x90]
    2880:      	cmp	x8, #0xffe
    2884:      	str	x8, [sp, #0x38]
    2888:      	b.hi	0x2464 <generic_tracepoint_process_event+0x2464>
    288c:      	ldp	x8, x1, [sp, #0x30]
    2890:      	mov	w9, #0x4                // =4
    2894:      	add	x21, x8, x21
    2898:      	and	x8, x21, #0x3fff
    289c:      	add	x0, x24, x8
    28a0:      	ldr	x8, [sp, #0x88]
    28a4:      	ldr	x2, [sp, #0x88]
    28a8:      	blr	x9
    28ac:      	tbnz	w0, #0x1f, 0x2920 <generic_tracepoint_process_event+0x2920>
    28b0:      	ldr	x8, [sp, #0x38]
    28b4:      	cmp	x23, #0x7
    28b8:      	add	x22, x8, x22
    28bc:      	b.lo	0x2550 <generic_tracepoint_process_event+0x2550>
    28c0:      	ldr	x8, [sp, #0x40]
    28c4:      	mov	w9, #0x4                // =4
    28c8:      	add	x10, sp, #0x88
    28cc:      	add	x0, sp, #0x88
    28d0:      	mov	w1, #0x10               // =16
    28d4:      	add	x2, x8, #0x60
    28d8:      	mov	w8, #0x10               // =16
    28dc:      	blr	x9
    28e0:      	tbnz	w0, #0x1f, 0x2920 <generic_tracepoint_process_event+0x2920>
    28e4:      	ldr	x23, [sp, #0x90]
    28e8:      	cmp	x23, #0xffe
    28ec:      	b.hi	0x2464 <generic_tracepoint_process_event+0x2464>
    28f0:      	ldr	x8, [sp, #0x38]
    28f4:      	mov	w9, #0x4                // =4
    28f8:      	mov	w1, w23
    28fc:      	add	x8, x8, x21
    2900:      	and	x8, x8, #0x3fff
    2904:      	add	x0, x24, x8
    2908:      	ldr	x8, [sp, #0x88]
    290c:      	ldr	x2, [sp, #0x88]
    2910:      	blr	x9
    2914:      	tbnz	w0, #0x1f, 0x2920 <generic_tracepoint_process_event+0x2920>
    2918:      	add	x22, x23, x22
    291c:      	b	0x2550 <generic_tracepoint_process_event+0x2550>
    2920:      	mov	w8, #-0x2               // =-2
    2924:      	str	w8, [x25]
    2928:      	b	0x2674 <generic_tracepoint_process_event+0x2674>
    292c:      	ldrb	w8, [x23, #0x7]
    2930:      	lsl	w8, w8, #2
    2934:      	add	w8, w8, #0x8
    2938:      	strh	w8, [x23, #0x2]
    293c:      	ldrh	w9, [x23]
    2940:      	ldrb	w22, [x23, #0x6]
    2944:      	add	w8, w9, w8
    2948:      	cmp	w22, #0x3c
    294c:      	strh	w8, [x23]
    2950:      	b.hi	0x2a08 <generic_tracepoint_process_event+0x2a08>
    2954:      	mov	x10, #0x1               // =1
    2958:      	mov	w9, #0x1                // =1
    295c:      	movk	x10, #0x1800, lsl #32
    2960:      	lsl	x9, x9, x22
    2964:      	movk	x10, #0x1008, lsl #48
    2968:      	tst	x9, x10
    296c:      	b.eq	0x2a08 <generic_tracepoint_process_event+0x2a08>
    2970:      	strb	w22, [x23, #0x5]
    2974:      	add	x8, x25, w8, uxth
    2978:      	mov	w9, #0x2                // =2
    297c:      	mov	w10, #0x4               // =4
    2980:      	mov	x0, x29
    2984:      	mov	w1, #0x2                // =2
    2988:      	ldrh	w8, [x23]
    298c:      	add	x2, x25, x8
    2990:      	blr	x10
    2994:      	tbnz	x0, #0x3f, 0x2ed8 <generic_tracepoint_process_event+0x2ed8>
    2998:      	ldrb	w8, [x23, #0x5]
    299c:      	cmp	w8, #0x32
    29a0:      	b.gt	0x29c0 <generic_tracepoint_process_event+0x29c0>
    29a4:      	cbz	w8, 0x29e0 <generic_tracepoint_process_event+0x29e0>
    29a8:      	cmp	w8, #0x2b
    29ac:      	b.eq	0x29e0 <generic_tracepoint_process_event+0x29e0>
    29b0:      	cmp	w8, #0x2c
    29b4:      	b.ne	0x2ad0 <generic_tracepoint_process_event+0x2ad0>
    29b8:      	mov	w8, #0x8                // =8
    29bc:      	b	0x2a1c <generic_tracepoint_process_event+0x2a1c>
    29c0:      	cmp	w8, #0x33
    29c4:      	b.eq	0x2a10 <generic_tracepoint_process_event+0x2a10>
    29c8:      	cmp	w8, #0x3c
    29cc:      	b.eq	0x29e0 <generic_tracepoint_process_event+0x29e0>
    29d0:      	cmp	w8, #0xff
    29d4:      	b.ne	0x2ad0 <generic_tracepoint_process_event+0x2ad0>
    29d8:      	mov	w8, #0x28               // =40
    29dc:      	b	0x2a1c <generic_tracepoint_process_event+0x2a1c>
    29e0:      	ldrb	w8, [x23, #0x7]
    29e4:      	lsl	w8, w8, #3
    29e8:      	b	0x2a18 <generic_tracepoint_process_event+0x2a18>
    29ec:      	ldrh	w8, [x23, #0x2]
    29f0:      	ldrh	w9, [x23]
    29f4:      	ldrb	w22, [x23, #0x6]
    29f8:      	add	w8, w9, w8
    29fc:      	cmp	w22, #0x3c
    2a00:      	strh	w8, [x23]
    2a04:      	b.ls	0x2954 <generic_tracepoint_process_event+0x2954>
    2a08:      	strh	w8, [sp, #0x78]
    2a0c:      	b	0x2edc <generic_tracepoint_process_event+0x2edc>
    2a10:      	ldrb	w8, [x23, #0x7]
    2a14:      	lsl	w8, w8, #2
    2a18:      	add	w8, w8, #0x8
    2a1c:      	strh	w8, [x23, #0x2]
    2a20:      	ldrh	w9, [x23]
    2a24:      	ldrb	w22, [x23, #0x6]
    2a28:      	add	w8, w9, w8
    2a2c:      	cmp	w22, #0x3c
    2a30:      	strh	w8, [x23]
    2a34:      	b.hi	0x30cc <generic_tracepoint_process_event+0x30cc>
    2a38:      	mov	x10, #0x1               // =1
    2a3c:      	mov	w9, #0x1                // =1
    2a40:      	movk	x10, #0x1800, lsl #32
    2a44:      	lsl	x9, x9, x22
    2a48:      	movk	x10, #0x1008, lsl #48
    2a4c:      	tst	x9, x10
    2a50:      	b.eq	0x30cc <generic_tracepoint_process_event+0x30cc>
    2a54:      	strb	w22, [x23, #0x5]
    2a58:      	add	x8, x25, w8, uxth
    2a5c:      	mov	w9, #0x2                // =2
    2a60:      	mov	w10, #0x4               // =4
    2a64:      	mov	x0, x29
    2a68:      	mov	w1, #0x2                // =2
    2a6c:      	ldrh	w8, [x23]
    2a70:      	add	x2, x25, x8
    2a74:      	blr	x10
    2a78:      	tbnz	x0, #0x3f, 0x2ed8 <generic_tracepoint_process_event+0x2ed8>
    2a7c:      	ldrb	w8, [x23, #0x5]
    2a80:      	cmp	w8, #0x32
    2a84:      	b.gt	0x2aa4 <generic_tracepoint_process_event+0x2aa4>
    2a88:      	cbz	w8, 0x2ac4 <generic_tracepoint_process_event+0x2ac4>
    2a8c:      	cmp	w8, #0x2b
    2a90:      	b.eq	0x2ac4 <generic_tracepoint_process_event+0x2ac4>
    2a94:      	cmp	w8, #0x2c
    2a98:      	b.ne	0x2bb0 <generic_tracepoint_process_event+0x2bb0>
    2a9c:      	mov	w8, #0x8                // =8
    2aa0:      	b	0x2afc <generic_tracepoint_process_event+0x2afc>
    2aa4:      	cmp	w8, #0x33
    2aa8:      	b.eq	0x2af0 <generic_tracepoint_process_event+0x2af0>
    2aac:      	cmp	w8, #0x3c
    2ab0:      	b.eq	0x2ac4 <generic_tracepoint_process_event+0x2ac4>
    2ab4:      	cmp	w8, #0xff
    2ab8:      	b.ne	0x2bb0 <generic_tracepoint_process_event+0x2bb0>
    2abc:      	mov	w8, #0x28               // =40
    2ac0:      	b	0x2afc <generic_tracepoint_process_event+0x2afc>
    2ac4:      	ldrb	w8, [x23, #0x7]
    2ac8:      	lsl	w8, w8, #3
    2acc:      	b	0x2af8 <generic_tracepoint_process_event+0x2af8>
    2ad0:      	ldrh	w8, [x23, #0x2]
    2ad4:      	ldrh	w9, [x23]
    2ad8:      	ldrb	w22, [x23, #0x6]
    2adc:      	add	w8, w9, w8
    2ae0:      	cmp	w22, #0x3c
    2ae4:      	strh	w8, [x23]
    2ae8:      	b.ls	0x2a38 <generic_tracepoint_process_event+0x2a38>
    2aec:      	b	0x30cc <generic_tracepoint_process_event+0x30cc>
    2af0:      	ldrb	w8, [x23, #0x7]
    2af4:      	lsl	w8, w8, #2
    2af8:      	add	w8, w8, #0x8
    2afc:      	strh	w8, [x23, #0x2]
    2b00:      	ldrh	w9, [x23]
    2b04:      	ldrb	w22, [x23, #0x6]
    2b08:      	add	w8, w9, w8
    2b0c:      	cmp	w22, #0x3c
    2b10:      	strh	w8, [x23]
    2b14:      	b.hi	0x30cc <generic_tracepoint_process_event+0x30cc>
    2b18:      	mov	x10, #0x1               // =1
    2b1c:      	mov	w9, #0x1                // =1
    2b20:      	movk	x10, #0x1800, lsl #32
    2b24:      	lsl	x9, x9, x22
    2b28:      	movk	x10, #0x1008, lsl #48
    2b2c:      	tst	x9, x10
    2b30:      	b.eq	0x30cc <generic_tracepoint_process_event+0x30cc>
    2b34:      	strb	w22, [x23, #0x5]
    2b38:      	add	x8, x25, w8, uxth
    2b3c:      	mov	w9, #0x2                // =2
    2b40:      	mov	w10, #0x4               // =4
    2b44:      	mov	x0, x29
    2b48:      	mov	w1, #0x2                // =2
    2b4c:      	ldrh	w8, [x23]
    2b50:      	add	x2, x25, x8
    2b54:      	blr	x10
    2b58:      	tbnz	x0, #0x3f, 0x2ed8 <generic_tracepoint_process_event+0x2ed8>
    2b5c:      	ldrb	w8, [x23, #0x5]
    2b60:      	cmp	w8, #0x32
    2b64:      	b.gt	0x2b84 <generic_tracepoint_process_event+0x2b84>
    2b68:      	cbz	w8, 0x2ba4 <generic_tracepoint_process_event+0x2ba4>
    2b6c:      	cmp	w8, #0x2b
    2b70:      	b.eq	0x2ba4 <generic_tracepoint_process_event+0x2ba4>
    2b74:      	cmp	w8, #0x2c
    2b78:      	b.ne	0x2c90 <generic_tracepoint_process_event+0x2c90>
    2b7c:      	mov	w8, #0x8                // =8
    2b80:      	b	0x2bdc <generic_tracepoint_process_event+0x2bdc>
    2b84:      	cmp	w8, #0x33
    2b88:      	b.eq	0x2bd0 <generic_tracepoint_process_event+0x2bd0>
    2b8c:      	cmp	w8, #0x3c
    2b90:      	b.eq	0x2ba4 <generic_tracepoint_process_event+0x2ba4>
    2b94:      	cmp	w8, #0xff
    2b98:      	b.ne	0x2c90 <generic_tracepoint_process_event+0x2c90>
    2b9c:      	mov	w8, #0x28               // =40
    2ba0:      	b	0x2bdc <generic_tracepoint_process_event+0x2bdc>
    2ba4:      	ldrb	w8, [x23, #0x7]
    2ba8:      	lsl	w8, w8, #3
    2bac:      	b	0x2bd8 <generic_tracepoint_process_event+0x2bd8>
    2bb0:      	ldrh	w8, [x23, #0x2]
    2bb4:      	ldrh	w9, [x23]
    2bb8:      	ldrb	w22, [x23, #0x6]
    2bbc:      	add	w8, w9, w8
    2bc0:      	cmp	w22, #0x3c
    2bc4:      	strh	w8, [x23]
    2bc8:      	b.ls	0x2b18 <generic_tracepoint_process_event+0x2b18>
    2bcc:      	b	0x30cc <generic_tracepoint_process_event+0x30cc>
    2bd0:      	ldrb	w8, [x23, #0x7]
    2bd4:      	lsl	w8, w8, #2
    2bd8:      	add	w8, w8, #0x8
    2bdc:      	strh	w8, [x23, #0x2]
    2be0:      	ldrh	w9, [x23]
    2be4:      	ldrb	w22, [x23, #0x6]
    2be8:      	add	w8, w9, w8
    2bec:      	cmp	w22, #0x3c
    2bf0:      	strh	w8, [x23]
    2bf4:      	b.hi	0x30cc <generic_tracepoint_process_event+0x30cc>
    2bf8:      	mov	x10, #0x1               // =1
    2bfc:      	mov	w9, #0x1                // =1
    2c00:      	movk	x10, #0x1800, lsl #32
    2c04:      	lsl	x9, x9, x22
    2c08:      	movk	x10, #0x1008, lsl #48
    2c0c:      	tst	x9, x10
    2c10:      	b.eq	0x30cc <generic_tracepoint_process_event+0x30cc>
    2c14:      	strb	w22, [x23, #0x5]
    2c18:      	add	x8, x25, w8, uxth
    2c1c:      	mov	w9, #0x2                // =2
    2c20:      	mov	w10, #0x4               // =4
    2c24:      	mov	x0, x29
    2c28:      	mov	w1, #0x2                // =2
    2c2c:      	ldrh	w8, [x23]
    2c30:      	add	x2, x25, x8
    2c34:      	blr	x10
    2c38:      	tbnz	x0, #0x3f, 0x2ed8 <generic_tracepoint_process_event+0x2ed8>
    2c3c:      	ldrb	w8, [x23, #0x5]
    2c40:      	cmp	w8, #0x32
    2c44:      	b.gt	0x2c64 <generic_tracepoint_process_event+0x2c64>
    2c48:      	cbz	w8, 0x2c84 <generic_tracepoint_process_event+0x2c84>
    2c4c:      	cmp	w8, #0x2b
    2c50:      	b.eq	0x2c84 <generic_tracepoint_process_event+0x2c84>
    2c54:      	cmp	w8, #0x2c
    2c58:      	b.ne	0x2d70 <generic_tracepoint_process_event+0x2d70>
    2c5c:      	mov	w8, #0x8                // =8
    2c60:      	b	0x2cbc <generic_tracepoint_process_event+0x2cbc>
    2c64:      	cmp	w8, #0x33
    2c68:      	b.eq	0x2cb0 <generic_tracepoint_process_event+0x2cb0>
    2c6c:      	cmp	w8, #0x3c
    2c70:      	b.eq	0x2c84 <generic_tracepoint_process_event+0x2c84>
    2c74:      	cmp	w8, #0xff
    2c78:      	b.ne	0x2d70 <generic_tracepoint_process_event+0x2d70>
    2c7c:      	mov	w8, #0x28               // =40
    2c80:      	b	0x2cbc <generic_tracepoint_process_event+0x2cbc>
    2c84:      	ldrb	w8, [x23, #0x7]
    2c88:      	lsl	w8, w8, #3
    2c8c:      	b	0x2cb8 <generic_tracepoint_process_event+0x2cb8>
    2c90:      	ldrh	w8, [x23, #0x2]
    2c94:      	ldrh	w9, [x23]
    2c98:      	ldrb	w22, [x23, #0x6]
    2c9c:      	add	w8, w9, w8
    2ca0:      	cmp	w22, #0x3c
    2ca4:      	strh	w8, [x23]
    2ca8:      	b.ls	0x2bf8 <generic_tracepoint_process_event+0x2bf8>
    2cac:      	b	0x30cc <generic_tracepoint_process_event+0x30cc>
    2cb0:      	ldrb	w8, [x23, #0x7]
    2cb4:      	lsl	w8, w8, #2
    2cb8:      	add	w8, w8, #0x8
    2cbc:      	strh	w8, [x23, #0x2]
    2cc0:      	ldrh	w9, [x23]
    2cc4:      	ldrb	w22, [x23, #0x6]
    2cc8:      	add	w8, w9, w8
    2ccc:      	cmp	w22, #0x3c
    2cd0:      	strh	w8, [x23]
    2cd4:      	b.hi	0x30cc <generic_tracepoint_process_event+0x30cc>
    2cd8:      	mov	x10, #0x1               // =1
    2cdc:      	mov	w9, #0x1                // =1
    2ce0:      	movk	x10, #0x1800, lsl #32
    2ce4:      	lsl	x9, x9, x22
    2ce8:      	movk	x10, #0x1008, lsl #48
    2cec:      	tst	x9, x10
    2cf0:      	b.eq	0x30cc <generic_tracepoint_process_event+0x30cc>
    2cf4:      	strb	w22, [x23, #0x5]
    2cf8:      	add	x8, x25, w8, uxth
    2cfc:      	mov	w9, #0x2                // =2
    2d00:      	mov	w10, #0x4               // =4
    2d04:      	mov	x0, x29
    2d08:      	mov	w1, #0x2                // =2
    2d0c:      	ldrh	w8, [x23]
    2d10:      	add	x2, x25, x8
    2d14:      	blr	x10
    2d18:      	tbnz	x0, #0x3f, 0x2ed8 <generic_tracepoint_process_event+0x2ed8>
    2d1c:      	ldrb	w8, [x23, #0x5]
    2d20:      	cmp	w8, #0x32
    2d24:      	b.gt	0x2d44 <generic_tracepoint_process_event+0x2d44>
    2d28:      	cbz	w8, 0x2d64 <generic_tracepoint_process_event+0x2d64>
    2d2c:      	cmp	w8, #0x2b
    2d30:      	b.eq	0x2d64 <generic_tracepoint_process_event+0x2d64>
    2d34:      	cmp	w8, #0x2c
    2d38:      	b.ne	0x2e50 <generic_tracepoint_process_event+0x2e50>
    2d3c:      	mov	w8, #0x8                // =8
    2d40:      	b	0x2d9c <generic_tracepoint_process_event+0x2d9c>
    2d44:      	cmp	w8, #0x33
    2d48:      	b.eq	0x2d90 <generic_tracepoint_process_event+0x2d90>
    2d4c:      	cmp	w8, #0x3c
    2d50:      	b.eq	0x2d64 <generic_tracepoint_process_event+0x2d64>
    2d54:      	cmp	w8, #0xff
    2d58:      	b.ne	0x2e50 <generic_tracepoint_process_event+0x2e50>
    2d5c:      	mov	w8, #0x28               // =40
    2d60:      	b	0x2d9c <generic_tracepoint_process_event+0x2d9c>
    2d64:      	ldrb	w8, [x23, #0x7]
    2d68:      	lsl	w8, w8, #3
    2d6c:      	b	0x2d98 <generic_tracepoint_process_event+0x2d98>
    2d70:      	ldrh	w8, [x23, #0x2]
    2d74:      	ldrh	w9, [x23]
    2d78:      	ldrb	w22, [x23, #0x6]
    2d7c:      	add	w8, w9, w8
    2d80:      	cmp	w22, #0x3c
    2d84:      	strh	w8, [x23]
    2d88:      	b.ls	0x2cd8 <generic_tracepoint_process_event+0x2cd8>
    2d8c:      	b	0x30cc <generic_tracepoint_process_event+0x30cc>
    2d90:      	ldrb	w8, [x23, #0x7]
    2d94:      	lsl	w8, w8, #2
    2d98:      	add	w8, w8, #0x8
    2d9c:      	strh	w8, [x23, #0x2]
    2da0:      	ldrh	w9, [x23]
    2da4:      	ldrb	w22, [x23, #0x6]
    2da8:      	add	w8, w9, w8
    2dac:      	cmp	w22, #0x3c
    2db0:      	strh	w8, [x23]
    2db4:      	b.hi	0x30cc <generic_tracepoint_process_event+0x30cc>
    2db8:      	mov	x10, #0x1               // =1
    2dbc:      	mov	w9, #0x1                // =1
    2dc0:      	movk	x10, #0x1800, lsl #32
    2dc4:      	lsl	x9, x9, x22
    2dc8:      	movk	x10, #0x1008, lsl #48
    2dcc:      	tst	x9, x10
    2dd0:      	b.eq	0x30cc <generic_tracepoint_process_event+0x30cc>
    2dd4:      	strb	w22, [x23, #0x5]
    2dd8:      	add	x8, x25, w8, uxth
    2ddc:      	mov	w9, #0x2                // =2
    2de0:      	mov	w10, #0x4               // =4
    2de4:      	mov	x0, x29
    2de8:      	mov	w1, #0x2                // =2
    2dec:      	ldrh	w8, [x23]
    2df0:      	add	x2, x25, x8
    2df4:      	blr	x10
    2df8:      	tbnz	x0, #0x3f, 0x2ed8 <generic_tracepoint_process_event+0x2ed8>
    2dfc:      	ldrb	w8, [x23, #0x5]
    2e00:      	cmp	w8, #0x32
    2e04:      	b.gt	0x2e24 <generic_tracepoint_process_event+0x2e24>
    2e08:      	cbz	w8, 0x2e44 <generic_tracepoint_process_event+0x2e44>
    2e0c:      	cmp	w8, #0x2b
    2e10:      	b.eq	0x2e44 <generic_tracepoint_process_event+0x2e44>
    2e14:      	cmp	w8, #0x2c
    2e18:      	b.ne	0x30b0 <generic_tracepoint_process_event+0x30b0>
    2e1c:      	mov	w8, #0x8                // =8
    2e20:      	b	0x2e7c <generic_tracepoint_process_event+0x2e7c>
    2e24:      	cmp	w8, #0x33
    2e28:      	b.eq	0x2e70 <generic_tracepoint_process_event+0x2e70>
    2e2c:      	cmp	w8, #0x3c
    2e30:      	b.eq	0x2e44 <generic_tracepoint_process_event+0x2e44>
    2e34:      	cmp	w8, #0xff
    2e38:      	b.ne	0x30b0 <generic_tracepoint_process_event+0x30b0>
    2e3c:      	mov	w8, #0x28               // =40
    2e40:      	b	0x2e7c <generic_tracepoint_process_event+0x2e7c>
    2e44:      	ldrb	w8, [x23, #0x7]
    2e48:      	lsl	w8, w8, #3
    2e4c:      	b	0x2e78 <generic_tracepoint_process_event+0x2e78>
    2e50:      	ldrh	w8, [x23, #0x2]
    2e54:      	ldrh	w9, [x23]
    2e58:      	ldrb	w22, [x23, #0x6]
    2e5c:      	add	w8, w9, w8
    2e60:      	cmp	w22, #0x3c
    2e64:      	strh	w8, [x23]
    2e68:      	b.ls	0x2db8 <generic_tracepoint_process_event+0x2db8>
    2e6c:      	b	0x30cc <generic_tracepoint_process_event+0x30cc>
    2e70:      	ldrb	w8, [x23, #0x7]
    2e74:      	lsl	w8, w8, #2
    2e78:      	add	w8, w8, #0x8
    2e7c:      	strh	w8, [x23, #0x2]
    2e80:      	ldrh	w9, [x23]
    2e84:      	ldrb	w22, [x23, #0x6]
    2e88:      	add	w8, w9, w8
    2e8c:      	cmp	w22, #0x3c
    2e90:      	strh	w8, [x23]
    2e94:      	b.hi	0x30cc <generic_tracepoint_process_event+0x30cc>
    2e98:      	mov	x10, #0x1               // =1
    2e9c:      	mov	w9, #0x1                // =1
    2ea0:      	movk	x10, #0x1800, lsl #32
    2ea4:      	lsl	x9, x9, x22
    2ea8:      	movk	x10, #0x1008, lsl #48
    2eac:      	tst	x9, x10
    2eb0:      	b.eq	0x30cc <generic_tracepoint_process_event+0x30cc>
    2eb4:      	strb	w22, [x23, #0x5]
    2eb8:      	add	x8, x25, w8, uxth
    2ebc:      	mov	w9, #0x2                // =2
    2ec0:      	mov	w10, #0x4               // =4
    2ec4:      	mov	x0, x29
    2ec8:      	mov	w1, #0x2                // =2
    2ecc:      	ldrh	w8, [x23]
    2ed0:      	add	x2, x25, x8
    2ed4:      	blr	x10
    2ed8:      	mov	w22, wzr
    2edc:      	ldr	x29, [sp, #0x10]
    2ee0:      	mov	w8, #0xa                // =10
    2ee4:      	strb	w22, [sp, #0x74]
    2ee8:      	add	x2, x21, #0x8
    2eec:      	mov	w23, #0x10              // =16
    2ef0:      	mov	w1, #0x10               // =16
    2ef4:      	mov	w25, #0x4               // =4
    2ef8:      	strh	w22, [x29, #0x24]
    2efc:      	strh	w8, [x29, #0x26]
    2f00:      	mov	w8, #0x4                // =4
    2f04:      	mov	x0, x29
    2f08:      	blr	x8
    2f0c:      	add	x0, x29, #0x10
    2f10:      	add	x2, x21, #0x18
    2f14:      	mov	w1, #0x10               // =16
    2f18:      	blr	x25
    2f1c:      	cmp	w22, #0x11
    2f20:      	b.eq	0x2f64 <generic_tracepoint_process_event+0x2f64>
    2f24:      	cmp	w22, #0x6
    2f28:      	b.ne	0x2fa4 <generic_tracepoint_process_event+0x2fa4>
    2f2c:      	ldr	x8, [sp, #0x88]
    2f30:      	ldrh	w9, [sp, #0x78]
    2f34:      	mov	w23, #0x2               // =2
    2f38:      	mov	w1, #0x2                // =2
    2f3c:      	mov	w25, #0x4               // =4
    2f40:      	add	x22, x8, x9
    2f44:      	ldr	x29, [sp, #0x10]
    2f48:      	add	x0, x29, #0x20
    2f4c:      	mov	w8, #0x4                // =4
    2f50:      	mov	x2, x22
    2f54:      	blr	x8
    2f58:      	add	x0, x29, #0x22
    2f5c:      	add	x2, x22, #0x2
    2f60:      	b	0x2f98 <generic_tracepoint_process_event+0x2f98>
    2f64:      	ldr	x8, [sp, #0x88]
    2f68:      	ldrh	w9, [sp, #0x78]
    2f6c:      	mov	w23, #0x2               // =2
    2f70:      	mov	w1, #0x2                // =2
    2f74:      	mov	w25, #0x4               // =4
    2f78:      	add	x22, x8, x9
    2f7c:      	ldr	x29, [sp, #0x10]
    2f80:      	add	x0, x29, #0x20
    2f84:      	mov	w8, #0x4                // =4
    2f88:      	mov	x2, x22
    2f8c:      	blr	x8
    2f90:      	add	x0, x29, #0x22
    2f94:      	add	x2, x22, #0x2
    2f98:      	mov	w1, #0x2                // =2
    2f9c:      	blr	x25
    2fa0:      	b	0x2fac <generic_tracepoint_process_event+0x2fac>
    2fa4:      	ldr	x8, [sp, #0x10]
    2fa8:      	str	wzr, [x8, #0x20]
    2fac:      	ldr	x9, [sp, #0x10]
    2fb0:      	add	x2, x24, #0xe0
    2fb4:      	add	x10, sp, #0xe0
    2fb8:      	add	x0, sp, #0xe0
    2fbc:      	ldrh	w8, [x9, #0x20]
    2fc0:      	mov	w1, #0x8                // =8
    2fc4:      	rev	w8, w8
    2fc8:      	lsr	w8, w8, #16
    2fcc:      	strh	w8, [x9, #0x20]
    2fd0:      	ldrh	w8, [x9, #0x22]
    2fd4:      	rev	w8, w8
    2fd8:      	lsr	w8, w8, #16
    2fdc:      	strh	w8, [x9, #0x22]
    2fe0:      	mov	w8, #0x8                // =8
    2fe4:      	mov	w9, #0x4                // =4
    2fe8:      	blr	x9
    2fec:      	add	x8, sp, #0xd0
    2ff0:      	ldr	x8, [x8, #0x10]
    2ff4:      	cbz	x8, 0x3058 <generic_tracepoint_process_event+0x3058>
    2ff8:      	add	x8, x8, #0x5
    2ffc:      	mov	w9, #0x8                // =8
    3000:      	add	x10, sp, #0xf0
    3004:      	mov	w11, #0x4               // =4
    3008:      	add	x21, sp, #0xd0
    300c:      	ldr	x8, [x21, #0x10]
    3010:      	add	x0, sp, #0xf0
    3014:      	mov	w1, #0x8                // =8
    3018:      	mov	w22, #0x4               // =4
    301c:      	add	x2, x8, #0x5
    3020:      	blr	x11
    3024:      	ldr	x8, [x21, #0x10]
    3028:      	ldr	x9, [x21, #0x20]
    302c:      	mov	w1, #0x4                // =4
    3030:      	add	x23, x8, x9, lsl #3
    3034:      	ldr	x24, [sp, #0x10]
    3038:      	add	x0, x24, #0x38
    303c:      	mov	w8, #0x4                // =4
    3040:      	add	x2, x23, #0x44
    3044:      	blr	x8
    3048:      	add	x0, x24, #0x3c
    304c:      	add	x2, x23, #0x45
    3050:      	mov	w1, #0x4                // =4
    3054:      	blr	x22
    3058:      	ldr	x29, [sp, #0x30]
    305c:      	mov	w24, #0x40              // =64
    3060:      	mov	w25, #0x5efc            // =24316
    3064:      	ldp	x10, x11, [sp, #0x18]
    3068:      	mov	w9, #0x5ea0             // =24224
    306c:      	adrp	x21, 0x3000 <generic_tracepoint_process_event+0x3000>
    3070:      	ldr	x23, [sp, #0x108]
    3074:      	ldr	x21, [x21]
    3078:      	tbnz	w24, #0x1f, 0x30a0 <generic_tracepoint_process_event+0x30a0>
    307c:      	and	w8, w24, #0x7fffffff
    3080:      	add	w8, w8, #0x4
    3084:      	add	w23, w8, w23
    3088:      	str	w23, [x20, #0x4]
    308c:      	adrp	x22, 0x3000 <generic_tracepoint_process_event+0x3000>
    3090:      	cmp	w29, #0x3
    3094:      	ldr	x22, [x22]
    3098:      	b.le	0x8ec <generic_tracepoint_process_event+0x8ec>
    309c:      	b	0x958 <generic_tracepoint_process_event+0x958>
    30a0:      	mov	w8, #-0x1               // =-1
    30a4:      	str	w8, [x10, x9]
    30a8:      	str	w8, [x11, x23]
    30ac:      	b	0x8b4 <generic_tracepoint_process_event+0x8b4>
    30b0:      	ldrh	w8, [x23, #0x2]
    30b4:      	ldrh	w9, [x23]
    30b8:      	ldrb	w22, [x23, #0x6]
    30bc:      	add	w8, w9, w8
    30c0:      	cmp	w22, #0x3c
    30c4:      	strh	w8, [x23]
    30c8:      	b.ls	0x2e98 <generic_tracepoint_process_event+0x2e98>
    30cc:      	strh	w8, [sp, #0x78]
    30d0:      	b	0x2edc <generic_tracepoint_process_event+0x2edc>
    30d4:      	nop
    30d8:      	nop
    30dc:      	nop

00000000000030e0 <generic_tracepoint_filter>:
    30e0:      	sub	sp, sp, #0x130
    30e4:      	str	x29, [sp, #0xe0]
    30e8:      	stp	x30, x25, [sp, #0xf0]
    30ec:      	stp	x24, x23, [sp, #0x100]
    30f0:      	stp	x22, x21, [sp, #0x110]
    30f4:      	stp	x20, x19, [sp, #0x120]
    30f8:      	mov	x20, x0
    30fc:      	str	wzr, [sp, #0x54]
    3100:      	adrp	x0, 0x3000 <generic_tracepoint_process_event+0x3000>
    3104:      	mov	w8, #0x1                // =1
    3108:      	ldr	x0, [x0]
    310c:      	add	x9, sp, #0x54
    3110:      	add	x1, sp, #0x54
    3114:      	blr	x8
    3118:      	cbz	x0, 0x540c <generic_tracepoint_filter+0x232c>
    311c:      	mov	w8, #0x5ec0             // =24256
    3120:      	mov	x22, x0
    3124:      	add	x29, x0, x8
    3128:      	mov	w8, #0x23               // =35
    312c:      	blr	x8
    3130:      	str	x0, [sp, #0x58]
    3134:      	add	x8, x0, #0x8d4
    3138:      	mov	w9, #0x4                // =4
    313c:      	mov	w10, #0x71              // =113
    3140:      	add	x11, sp, #0xd8
    3144:      	add	x0, sp, #0xd8
    3148:      	mov	w1, #0x4                // =4
    314c:      	ldr	x8, [sp, #0x58]
    3150:      	add	x2, x8, #0x8d4
    3154:      	blr	x10
    3158:      	ldr	w8, [sp, #0xd8]
    315c:      	adrp	x19, 0x3000 <generic_tracepoint_process_event+0x3000>
    3160:      	add	x9, sp, #0xc8
    3164:      	add	x1, sp, #0xc8
    3168:      	str	w8, [sp, #0xc8]
    316c:      	mov	w8, #0x1                // =1
    3170:      	ldr	x19, [x19]
    3174:      	mov	x0, x19
    3178:      	blr	x8
    317c:      	cbz	x0, 0x318c <generic_tracepoint_filter+0xac>
    3180:      	ldr	x8, [x0, #0x8]
    3184:      	mov	x24, x0
    3188:      	cbnz	x8, 0x3f6c <generic_tracepoint_filter+0xe8c>
    318c:      	ldr	x8, [sp, #0x58]
    3190:      	mov	w9, #0x8                // =8
    3194:      	mov	w10, #0x71              // =113
    3198:      	add	x11, sp, #0x58
    319c:      	add	x0, sp, #0x58
    31a0:      	mov	w1, #0x8                // =8
    31a4:      	add	x8, x8, #0x8e0
    31a8:      	ldr	x8, [sp, #0x58]
    31ac:      	add	x2, x8, #0x8e0
    31b0:      	blr	x10
    31b4:      	ldr	x8, [sp, #0x58]
    31b8:      	cbz	x8, 0x3334 <generic_tracepoint_filter+0x254>
    31bc:      	add	x8, x8, #0x8d4
    31c0:      	mov	w9, #0x4                // =4
    31c4:      	mov	w10, #0x71              // =113
    31c8:      	add	x11, sp, #0xd8
    31cc:      	ldr	x8, [sp, #0x58]
    31d0:      	add	x0, sp, #0xd8
    31d4:      	mov	w1, #0x4                // =4
    31d8:      	add	x2, x8, #0x8d4
    31dc:      	blr	x10
    31e0:      	ldr	w8, [sp, #0xd8]
    31e4:      	add	x9, sp, #0xc8
    31e8:      	add	x1, sp, #0xc8
    31ec:      	mov	x0, x19
    31f0:      	str	w8, [sp, #0xc8]
    31f4:      	mov	w8, #0x1                // =1
    31f8:      	blr	x8
    31fc:      	cbz	x0, 0x320c <generic_tracepoint_filter+0x12c>
    3200:      	ldr	x8, [x0, #0x8]
    3204:      	mov	x24, x0
    3208:      	cbnz	x8, 0x3f6c <generic_tracepoint_filter+0xe8c>
    320c:      	ldr	x8, [sp, #0x58]
    3210:      	mov	w9, #0x8                // =8
    3214:      	mov	w10, #0x71              // =113
    3218:      	add	x11, sp, #0x58
    321c:      	add	x0, sp, #0x58
    3220:      	mov	w1, #0x8                // =8
    3224:      	add	x8, x8, #0x8e0
    3228:      	ldr	x8, [sp, #0x58]
    322c:      	add	x2, x8, #0x8e0
    3230:      	blr	x10
    3234:      	ldr	x8, [sp, #0x58]
    3238:      	cbz	x8, 0x3334 <generic_tracepoint_filter+0x254>
    323c:      	add	x8, x8, #0x8d4
    3240:      	mov	w9, #0x4                // =4
    3244:      	mov	w10, #0x71              // =113
    3248:      	add	x11, sp, #0xd8
    324c:      	ldr	x8, [sp, #0x58]
    3250:      	add	x0, sp, #0xd8
    3254:      	mov	w1, #0x4                // =4
    3258:      	add	x2, x8, #0x8d4
    325c:      	blr	x10
    3260:      	ldr	w8, [sp, #0xd8]
    3264:      	add	x9, sp, #0xc8
    3268:      	add	x1, sp, #0xc8
    326c:      	mov	x0, x19
    3270:      	str	w8, [sp, #0xc8]
    3274:      	mov	w8, #0x1                // =1
    3278:      	blr	x8
    327c:      	cbz	x0, 0x328c <generic_tracepoint_filter+0x1ac>
    3280:      	ldr	x8, [x0, #0x8]
    3284:      	mov	x24, x0
    3288:      	cbnz	x8, 0x3f6c <generic_tracepoint_filter+0xe8c>
    328c:      	ldr	x8, [sp, #0x58]
    3290:      	mov	w9, #0x8                // =8
    3294:      	mov	w10, #0x71              // =113
    3298:      	add	x11, sp, #0x58
    329c:      	add	x0, sp, #0x58
    32a0:      	mov	w1, #0x8                // =8
    32a4:      	add	x8, x8, #0x8e0
    32a8:      	ldr	x8, [sp, #0x58]
    32ac:      	add	x2, x8, #0x8e0
    32b0:      	blr	x10
    32b4:      	ldr	x8, [sp, #0x58]
    32b8:      	cbz	x8, 0x3334 <generic_tracepoint_filter+0x254>
    32bc:      	add	x8, x8, #0x8d4
    32c0:      	mov	w9, #0x4                // =4
    32c4:      	mov	w10, #0x71              // =113
    32c8:      	add	x11, sp, #0xd8
    32cc:      	ldr	x8, [sp, #0x58]
    32d0:      	add	x0, sp, #0xd8
    32d4:      	mov	w1, #0x4                // =4
    32d8:      	add	x2, x8, #0x8d4
    32dc:      	blr	x10
    32e0:      	ldr	w8, [sp, #0xd8]
    32e4:      	add	x9, sp, #0xc8
    32e8:      	add	x1, sp, #0xc8
    32ec:      	mov	x0, x19
    32f0:      	str	w8, [sp, #0xc8]
    32f4:      	mov	w8, #0x1                // =1
    32f8:      	blr	x8
    32fc:      	cbz	x0, 0x330c <generic_tracepoint_filter+0x22c>
    3300:      	ldr	x8, [x0, #0x8]
    3304:      	mov	x24, x0
    3308:      	cbnz	x8, 0x3f6c <generic_tracepoint_filter+0xe8c>
    330c:      	ldr	x8, [sp, #0x58]
    3310:      	mov	w9, #0x8                // =8
    3314:      	mov	w10, #0x71              // =113
    3318:      	add	x11, sp, #0x58
    331c:      	add	x0, sp, #0x58
    3320:      	mov	w1, #0x8                // =8
    3324:      	add	x8, x8, #0x8e0
    3328:      	ldr	x8, [sp, #0x58]
    332c:      	add	x2, x8, #0x8e0
    3330:      	blr	x10
    3334:      	str	x20, [sp, #0x38]
    3338:      	mov	w8, #0x23               // =35
    333c:      	blr	x8
    3340:      	add	x2, x0, #0x8d4
    3344:      	mov	w8, #0x4                // =4
    3348:      	add	x9, sp, #0x58
    334c:      	mov	x24, x0
    3350:      	add	x0, sp, #0x58
    3354:      	mov	w1, #0x4                // =4
    3358:      	blr	x8
    335c:      	ldr	w8, [sp, #0x58]
    3360:      	mov	x19, x29
    3364:      	str	w8, [x19, #0x50]!
    3368:      	mov	w8, #0x7d               // =125
    336c:      	blr	x8
    3370:      	str	x0, [x22, #0x5f18]
    3374:      	str	wzr, [x19, #0x10]
    3378:      	add	x2, x24, #0x60
    337c:      	mov	w8, #0x8                // =8
    3380:      	mov	w9, #0x71               // =113
    3384:      	add	x10, sp, #0xc8
    3388:      	str	xzr, [x22, #0x5f28]
    338c:      	str	x19, [sp, #0x48]
    3390:      	add	x0, sp, #0xc8
    3394:      	mov	w1, #0x8                // =8
    3398:      	str	wzr, [x19, #0x20]
    339c:      	blr	x9
    33a0:      	ldr	x8, [sp, #0xc8]
    33a4:      	cbz	x8, 0x3414 <generic_tracepoint_filter+0x334>
    33a8:      	add	x8, x8, #0x4
    33ac:      	mov	w9, #0x4                // =4
    33b0:      	mov	w10, #0x71              // =113
    33b4:      	add	x11, sp, #0xd8
    33b8:      	ldr	x8, [sp, #0xc8]
    33bc:      	add	x0, sp, #0xd8
    33c0:      	mov	w1, #0x4                // =4
    33c4:      	add	x2, x8, #0x4
    33c8:      	blr	x10
    33cc:      	ldr	w8, [sp, #0xd8]
    33d0:      	cbz	w8, 0x3414 <generic_tracepoint_filter+0x334>
    33d4:      	ldr	x9, [sp, #0xc8]
    33d8:      	lsl	w8, w8, #4
    33dc:      	mov	w10, #0x71              // =113
    33e0:      	add	x11, sp, #0x58
    33e4:      	add	x0, sp, #0x58
    33e8:      	mov	w1, #0x10               // =16
    33ec:      	add	x8, x9, x8
    33f0:      	mov	w9, #0x10               // =16
    33f4:      	add	x8, x8, #0x80
    33f8:      	ldr	w9, [sp, #0xd8]
    33fc:      	ldr	x8, [sp, #0xc8]
    3400:      	lsl	w9, w9, #4
    3404:      	add	x8, x8, x9
    3408:      	add	x2, x8, #0x80
    340c:      	blr	x10
    3410:      	ldr	w8, [sp, #0x58]
    3414:      	str	w8, [x29, #0x74]
    3418:      	mov	w8, #0x5f60             // =24416
    341c:      	str	x22, [sp, #0xe8]
    3420:      	add	x23, x24, #0xae0
    3424:      	mov	w19, #0x8               // =8
    3428:      	add	x25, x22, x8
    342c:      	add	x8, sp, #0x58
    3430:      	mov	w9, #0x4                // =4
    3434:      	add	x0, sp, #0x58
    3438:      	mov	w1, #0x8                // =8
    343c:      	mov	x2, x23
    3440:      	mov	w21, #0x4               // =4
    3444:      	blr	x9
    3448:      	ldr	x20, [sp, #0x58]
    344c:      	ldr	x9, [sp, #0xe8]
    3450:      	mov	w8, #0x5f68             // =24424
    3454:      	mov	w1, #0x8                // =8
    3458:      	add	x0, x9, x8
    345c:      	add	x2, x20, #0x40
    3460:      	mov	w8, #0x4                // =4
    3464:      	blr	x8
    3468:      	ldr	x9, [sp, #0xe8]
    346c:      	mov	w8, #0x5f70             // =24432
    3470:      	add	x2, x20, #0x30
    3474:      	mov	w1, #0x8                // =8
    3478:      	add	x0, x9, x8
    347c:      	mov	w8, #0x4                // =4
    3480:      	blr	x8
    3484:      	add	x2, x20, #0x38
    3488:      	mov	w8, #0x4                // =4
    348c:      	mov	x0, x25
    3490:      	mov	w1, #0x8                // =8
    3494:      	blr	x8
    3498:      	ldr	x9, [sp, #0xe8]
    349c:      	mov	w8, #0x5f38             // =24376
    34a0:      	add	x2, x24, #0xb50
    34a4:      	add	x0, sp, #0xd8
    34a8:      	mov	w1, #0x8                // =8
    34ac:      	add	x25, x9, x8
    34b0:      	add	x8, sp, #0xd8
    34b4:      	mov	w9, #0x4                // =4
    34b8:      	blr	x9
    34bc:      	add	x12, sp, #0xd8
    34c0:      	mov	w9, #0x48               // =72
    34c4:      	add	x10, sp, #0x58
    34c8:      	ldr	x8, [x12]
    34cc:      	mov	w11, #0x4               // =4
    34d0:      	add	x0, sp, #0x58
    34d4:      	mov	w1, #0x48               // =72
    34d8:      	ldr	x2, [x12]
    34dc:      	blr	x11
    34e0:      	ldr	x8, [sp, #0x60]
    34e4:      	mov	w9, #0x4                // =4
    34e8:      	mov	x0, x25
    34ec:      	mov	w1, #0x4                // =4
    34f0:      	add	x8, x8, #0x218
    34f4:      	ldr	x8, [sp, #0x60]
    34f8:      	ldr	x22, [sp, #0xe8]
    34fc:      	add	x2, x8, #0x218
    3500:      	blr	x9
    3504:      	mov	w8, #0x5f3c             // =24380
    3508:      	mov	w9, #0x4                // =4
    350c:      	mov	w1, #0x4                // =4
    3510:      	add	x0, x22, x8
    3514:      	ldr	x8, [sp, #0x68]
    3518:      	add	x8, x8, #0x4d8
    351c:      	ldr	x8, [sp, #0x68]
    3520:      	add	x2, x8, #0x4d8
    3524:      	blr	x9
    3528:      	mov	w8, #0x5f40             // =24384
    352c:      	mov	w9, #0x4                // =4
    3530:      	mov	w1, #0x4                // =4
    3534:      	add	x0, x22, x8
    3538:      	ldr	x8, [sp, #0x70]
    353c:      	add	x8, x8, #0x58
    3540:      	ldr	x8, [sp, #0x70]
    3544:      	add	x2, x8, #0x58
    3548:      	blr	x9
    354c:      	str	xzr, [sp, #0xc0]
    3550:      	add	x2, x24, #0x938
    3554:      	add	x8, sp, #0xc0
    3558:      	add	x0, sp, #0xc0
    355c:      	mov	w1, #0x8                // =8
    3560:      	blr	x21
    3564:      	ldr	x8, [sp, #0xc0]
    3568:      	cbz	x8, 0x35f0 <generic_tracepoint_filter+0x510>
    356c:      	str	wzr, [sp, #0xb8]
    3570:      	add	x8, x8, #0x4
    3574:      	add	x9, sp, #0xb8
    3578:      	mov	w10, #0x4               // =4
    357c:      	add	x0, sp, #0xb8
    3580:      	mov	w1, #0x4                // =4
    3584:      	mov	w19, #0x4               // =4
    3588:      	ldr	x8, [sp, #0xc0]
    358c:      	add	x2, x8, #0x4
    3590:      	blr	x10
    3594:      	ldr	x8, [sp, #0xc0]
    3598:      	ldrsw	x9, [sp, #0xb8]
    359c:      	add	x10, sp, #0xc8
    35a0:      	mov	w11, #0x4               // =4
    35a4:      	add	x0, sp, #0xc8
    35a8:      	mov	w1, #0x10               // =16
    35ac:      	add	x8, x8, x9, lsl #4
    35b0:      	mov	w9, #0x10               // =16
    35b4:      	add	x8, x8, #0x80
    35b8:      	ldr	x8, [sp, #0xc0]
    35bc:      	ldrsw	x9, [sp, #0xb8]
    35c0:      	add	x8, x8, x9, lsl #4
    35c4:      	add	x2, x8, #0x80
    35c8:      	blr	x11
    35cc:      	mov	w8, #0x5f44             // =24388
    35d0:      	mov	w1, #0x4                // =4
    35d4:      	add	x0, x22, x8
    35d8:      	ldr	x8, [sp, #0xd0]
    35dc:      	add	x8, x8, #0x158
    35e0:      	ldr	x8, [sp, #0xd0]
    35e4:      	add	x2, x8, #0x158
    35e8:      	blr	x19
    35ec:      	b	0x35f4 <generic_tracepoint_filter+0x514>
    35f0:      	str	wzr, [x29, #0x84]
    35f4:      	mov	w8, #0x5f48             // =24392
    35f8:      	mov	w9, #0x4                // =4
    35fc:      	mov	w1, #0x4                // =4
    3600:      	mov	w19, #0x4               // =4
    3604:      	add	x0, x22, x8
    3608:      	ldr	x8, [sp, #0x78]
    360c:      	add	x8, x8, #0x158
    3610:      	ldr	x8, [sp, #0x78]
    3614:      	add	x2, x8, #0x158
    3618:      	blr	x9
    361c:      	mov	w8, #0x5f4c             // =24396
    3620:      	mov	w9, #0x4                // =4
    3624:      	mov	w1, #0x4                // =4
    3628:      	add	x0, x22, x8
    362c:      	ldr	x8, [sp, #0x80]
    3630:      	add	x8, x8, #0x118
    3634:      	ldr	x8, [sp, #0x80]
    3638:      	add	x2, x8, #0x118
    363c:      	blr	x9
    3640:      	mov	w8, #0x5f50             // =24400
    3644:      	mov	w9, #0x4                // =4
    3648:      	mov	w1, #0x4                // =4
    364c:      	add	x0, x22, x8
    3650:      	ldr	x8, [sp, #0x88]
    3654:      	add	x8, x8, #0x98
    3658:      	ldr	x8, [sp, #0x88]
    365c:      	add	x2, x8, #0x98
    3660:      	blr	x9
    3664:      	mov	w8, #0x5f54             // =24404
    3668:      	mov	w9, #0x4                // =4
    366c:      	mov	w1, #0x4                // =4
    3670:      	add	x0, x22, x8
    3674:      	ldr	x8, [sp, #0x90]
    3678:      	add	x8, x8, #0x98
    367c:      	ldr	x8, [sp, #0x90]
    3680:      	add	x2, x8, #0x98
    3684:      	blr	x9
    3688:      	mov	w8, #0x5f58             // =24408
    368c:      	mov	w9, #0x4                // =4
    3690:      	mov	w1, #0x4                // =4
    3694:      	add	x0, x22, x8
    3698:      	ldr	x8, [sp, #0x98]
    369c:      	add	x8, x8, #0x58
    36a0:      	ldr	x8, [sp, #0x98]
    36a4:      	add	x2, x8, #0x58
    36a8:      	blr	x9
    36ac:      	stp	xzr, xzr, [sp, #0xc0]
    36b0:      	mov	w20, #0x8               // =8
    36b4:      	add	x8, sp, #0xc8
    36b8:      	mov	w9, #0x4                // =4
    36bc:      	add	x0, sp, #0xc8
    36c0:      	mov	w1, #0x8                // =8
    36c4:      	mov	x2, x23
    36c8:      	blr	x9
    36cc:      	ldr	x8, [sp, #0xc8]
    36d0:      	add	x9, sp, #0xc0
    36d4:      	mov	w10, #0x4               // =4
    36d8:      	add	x0, sp, #0xc0
    36dc:      	mov	w1, #0x8                // =8
    36e0:      	add	x8, x8, #0x90
    36e4:      	ldr	x8, [sp, #0xc8]
    36e8:      	add	x2, x8, #0x90
    36ec:      	blr	x10
    36f0:      	mov	w8, #0x5f5c             // =24412
    36f4:      	mov	w1, #0x4                // =4
    36f8:      	add	x0, x22, x8
    36fc:      	ldr	x8, [sp, #0xc0]
    3700:      	add	x8, x8, #0x158
    3704:      	ldr	x8, [sp, #0xc0]
    3708:      	add	x2, x8, #0x158
    370c:      	blr	x19
    3710:      	ldr	w8, [x29, #0x74]
    3714:      	cmp	w8, #0x1
    3718:      	b.ne	0x3728 <generic_tracepoint_filter+0x648>
    371c:      	ldr	w8, [x29, #0x70]
    3720:      	orr	w8, w8, #0x2000000
    3724:      	str	w8, [x29, #0x70]
    3728:      	add	x0, x29, #0xb8
    372c:      	mov	w1, wzr
    3730:      	mov	w2, #0x308              // =776
    3734:      	bl	0x3734 <generic_tracepoint_filter+0x654>
    3738:      	mov	w8, #0x6290             // =25232
    373c:      	add	x2, x24, #0x858
    3740:      	mov	w19, #0x8               // =8
    3744:      	mov	w9, #0x4                // =4
    3748:      	add	x0, sp, #0xc8
    374c:      	mov	w1, #0x8                // =8
    3750:      	mov	w20, #0x4               // =4
    3754:      	add	x21, x22, x8
    3758:      	add	x8, sp, #0xc8
    375c:      	blr	x9
    3760:      	ldr	x8, [sp, #0xc8]
    3764:      	add	x9, sp, #0x58
    3768:      	add	x0, sp, #0x58
    376c:      	mov	w1, #0x8                // =8
    3770:      	add	x8, x8, #0x528
    3774:      	ldr	x8, [sp, #0xc8]
    3778:      	add	x2, x8, #0x528
    377c:      	blr	x20
    3780:      	str	wzr, [sp, #0xa4]
    3784:      	adrp	x0, 0x3000 <generic_tracepoint_process_event+0x3000>
    3788:      	ldr	x19, [sp, #0x58]
    378c:      	mov	w8, #0x1                // =1
    3790:      	add	x9, sp, #0xa4
    3794:      	add	x1, sp, #0xa4
    3798:      	ldr	x0, [x0]
    379c:      	blr	x8
    37a0:      	cbz	x0, 0x3db4 <generic_tracepoint_filter+0xcd4>
    37a4:      	mov	w8, #0x1000             // =4096
    37a8:      	str	x21, [sp, #0x30]
    37ac:      	str	x29, [sp, #0x40]
    37b0:      	mov	x24, x0
    37b4:      	add	x20, x0, #0x1, lsl #12  // =0x1000
    37b8:      	str	w8, [x29, #0x550]
    37bc:      	mov	w8, #0x23               // =35
    37c0:      	blr	x8
    37c4:      	add	x2, x0, #0xb30
    37c8:      	mov	w23, #0x8               // =8
    37cc:      	add	x8, sp, #0xa8
    37d0:      	mov	w9, #0x4                // =4
    37d4:      	add	x0, sp, #0xa8
    37d8:      	mov	w1, #0x8                // =8
    37dc:      	mov	w29, #0x4               // =4
    37e0:      	blr	x9
    37e4:      	ldr	x22, [sp, #0xa8]
    37e8:      	add	x25, x19, #0x48
    37ec:      	add	x8, sp, #0xb0
    37f0:      	mov	w9, #0x4                // =4
    37f4:      	add	x0, sp, #0xb0
    37f8:      	mov	w1, #0x8                // =8
    37fc:      	mov	x2, x25
    3800:      	blr	x9
    3804:      	ldr	x21, [sp, #0xb0]
    3808:      	add	x8, sp, #0x58
    380c:      	add	x0, sp, #0x58
    3810:      	mov	w1, #0x8                // =8
    3814:      	add	x2, x21, #0x10
    3818:      	blr	x29
    381c:      	ldr	x8, [sp, #0x58]
    3820:      	cbz	x8, 0x3a54 <generic_tracepoint_filter+0x974>
    3824:      	ldr	x8, [sp, #0x40]
    3828:      	stp	xzr, xzr, [sp, #0x58]
    382c:      	add	x21, x22, #0x18
    3830:      	add	x9, sp, #0x58
    3834:      	add	x2, x22, #0x20
    3838:      	mov	w22, #0x8               // =8
    383c:      	stp	x24, xzr, [sp, #0x68]
    3840:      	add	x0, sp, #0x58
    3844:      	mov	w1, #0x8                // =8
    3848:      	add	x29, x19, #0x40
    384c:      	add	x19, x9, #0x8
    3850:      	add	x24, x9, #0x18
    3854:      	stp	xzr, xzr, [sp, #0x78]
    3858:      	add	x23, x9, #0x20
    385c:      	str	x20, [sp, #0x88]
    3860:      	str	x20, [sp, #0x28]
    3864:      	mov	w20, #0x4               // =4
    3868:      	ldr	w8, [x8, #0x550]
    386c:      	strb	wzr, [sp, #0x94]
    3870:      	str	w8, [sp, #0x90]
    3874:      	mov	w8, #0x4                // =4
    3878:      	blr	x8
    387c:      	mov	w8, #0x4                // =4
    3880:      	mov	x0, x19
    3884:      	mov	w1, #0x8                // =8
    3888:      	mov	x2, x21
    388c:      	blr	x8
    3890:      	mov	w8, #0x4                // =4
    3894:      	mov	x0, x24
    3898:      	mov	w1, #0x8                // =8
    389c:      	mov	x2, x25
    38a0:      	blr	x8
    38a4:      	mov	x0, x23
    38a8:      	mov	w1, #0x8                // =8
    38ac:      	mov	x2, x29
    38b0:      	blr	x20
    38b4:      	ldr	x8, [sp, #0x78]
    38b8:      	sub	x8, x8, #0x20
    38bc:      	str	x8, [sp, #0x80]
    38c0:      	adrp	x8, 0x3000 <generic_tracepoint_process_event+0x3000>
    38c4:      	ldr	x8, [x8]
    38c8:      	ldrb	w8, [x8]
    38cc:      	cbz	w8, 0x3aa8 <generic_tracepoint_filter+0x9c8>
    38d0:      	mov	w19, #0x80              // =128
    38d4:      	mov	w21, #0x8               // =8
    38d8:      	add	x23, sp, #0xb8
    38dc:      	add	x29, sp, #0xd8
    38e0:      	b	0x3934 <generic_tracepoint_filter+0x854>
    38e4:      	add	x2, x22, #0x10
    38e8:      	mov	w8, #0x4                // =4
    38ec:      	add	x0, sp, #0xd8
    38f0:      	mov	w1, #0x8                // =8
    38f4:      	blr	x8
    38f8:      	add	x20, sp, #0xd8
    38fc:      	ldr	x8, [sp, #0x80]
    3900:      	ldr	x9, [x20]
    3904:      	cmp	x8, x9
    3908:      	b.eq	0x3c30 <generic_tracepoint_filter+0xb50>
    390c:      	add	x2, x22, #0x18
    3910:      	mov	w8, #0x4                // =4
    3914:      	mov	x0, x24
    3918:      	mov	w1, #0x8                // =8
    391c:      	blr	x8
    3920:      	ldr	x8, [x20]
    3924:      	add	x9, x8, #0x20
    3928:      	stp	x9, x8, [sp, #0x78]
    392c:      	subs	w19, w19, #0x1
    3930:      	b.eq	0x3c38 <generic_tracepoint_filter+0xb58>
    3934:      	ldp	x20, x2, [sp, #0x70]
    3938:      	ldp	x8, x9, [sp, #0x58]
    393c:      	cmp	x20, x8
    3940:      	ccmp	x2, x9, #0x0, eq
    3944:      	b.eq	0x3c30 <generic_tracepoint_filter+0xb50>
    3948:      	ldr	x22, [sp, #0x80]
    394c:      	mov	w8, #0x4                // =4
    3950:      	add	x0, sp, #0xb8
    3954:      	mov	w1, #0x8                // =8
    3958:      	blr	x8
    395c:      	ldr	x8, [sp, #0xb8]
    3960:      	cmp	x20, x8
    3964:      	b.eq	0x38e4 <generic_tracepoint_filter+0x804>
    3968:      	add	x25, x20, #0x18
    396c:      	mov	w8, #0x4                // =4
    3970:      	add	x0, sp, #0xd8
    3974:      	mov	w1, #0x8                // =8
    3978:      	mov	x2, x25
    397c:      	blr	x8
    3980:      	add	x8, sp, #0xd8
    3984:      	ldr	x8, [x8]
    3988:      	cmp	x8, x20
    398c:      	b.eq	0x38e4 <generic_tracepoint_filter+0x804>
    3990:      	mov	w8, #0x4                // =4
    3994:      	add	x9, sp, #0xc0
    3998:      	add	x0, sp, #0xc0
    399c:      	mov	w1, #0x8                // =8
    39a0:      	mov	x2, x25
    39a4:      	blr	x8
    39a8:      	add	x2, x20, #0x20
    39ac:      	mov	w8, #0x4                // =4
    39b0:      	mov	w9, #0x10               // =16
    39b4:      	add	x10, sp, #0xc8
    39b8:      	add	x0, sp, #0xc8
    39bc:      	mov	w1, #0x10               // =16
    39c0:      	blr	x8
    39c4:      	ldr	w20, [sp, #0xcc]
    39c8:      	ldr	x8, [sp, #0x68]
    39cc:      	ldr	x10, [sp, #0x88]
    39d0:      	sub	x12, x10, x8
    39d4:      	ldr	w22, [sp, #0x90]
    39d8:      	subs	w10, w20, w22
    39dc:      	ldr	x9, [sp, #0xd0]
    39e0:      	csel	w10, wzr, w10, lo
    39e4:      	cmp	w22, w20
    39e8:      	csel	w11, w22, w20, lo
    39ec:      	cinc	w13, w11, hi
    39f0:      	sub	w14, w22, w13
    39f4:      	subs	x12, x12, x13
    39f8:      	str	w14, [sp, #0x90]
    39fc:      	b.lo	0x3c38 <generic_tracepoint_filter+0xb58>
    3a00:      	cmp	x12, #0xfff
    3a04:      	b.hi	0x3c38 <generic_tracepoint_filter+0xb58>
    3a08:      	cmp	w22, w20
    3a0c:      	b.ls	0x3a18 <generic_tracepoint_filter+0x938>
    3a10:      	mov	w13, #0x2f              // =47
    3a14:      	strb	w13, [x8, x12]
    3a18:      	add	x25, x8, x12
    3a1c:      	cmp	w22, w20
    3a20:      	add	x2, x9, x10
    3a24:      	and	w1, w11, #0xff
    3a28:      	mov	w8, #0x4                // =4
    3a2c:      	cinc	x0, x25, hi
    3a30:      	blr	x8
    3a34:      	cmp	w22, w20
    3a38:      	str	x25, [sp, #0x88]
    3a3c:      	b.ls	0x3c38 <generic_tracepoint_filter+0xb58>
    3a40:      	ldr	x8, [sp, #0xc0]
    3a44:      	str	x8, [sp, #0x70]
    3a48:      	subs	w19, w19, #0x1
    3a4c:      	b.ne	0x3934 <generic_tracepoint_filter+0x854>
    3a50:      	b	0x3c38 <generic_tracepoint_filter+0xb58>
    3a54:      	add	x2, x21, #0x18
    3a58:      	mov	w8, #0x8                // =8
    3a5c:      	mov	w9, #0x4                // =4
    3a60:      	add	x10, sp, #0x58
    3a64:      	add	x0, sp, #0x58
    3a68:      	mov	w1, #0x8                // =8
    3a6c:      	blr	x9
    3a70:      	ldr	x8, [sp, #0x58]
    3a74:      	cmp	x8, x21
    3a78:      	b.eq	0x3824 <generic_tracepoint_filter+0x744>
    3a7c:      	ldr	x29, [sp, #0x40]
    3a80:      	ldr	w9, [x29, #0x550]
    3a84:      	sub	w8, w9, #0xa
    3a88:      	cmp	w9, #0x9
    3a8c:      	str	w8, [x29, #0x550]
    3a90:      	b.gt	0x4160 <generic_tracepoint_filter+0x1080>
    3a94:      	ldr	x21, [sp, #0x30]
    3a98:      	mov	w9, #-0x24              // =-36
    3a9c:      	mov	x24, x20
    3aa0:      	str	w9, [x29, #0x554]
    3aa4:      	b	0x3c9c <generic_tracepoint_filter+0xbbc>
    3aa8:      	mov	w19, #0x80              // =128
    3aac:      	mov	w21, #0x8               // =8
    3ab0:      	add	x23, sp, #0xb8
    3ab4:      	add	x29, sp, #0xd8
    3ab8:      	b	0x3b10 <generic_tracepoint_filter+0xa30>
    3abc:      	nop
    3ac0:      	add	x2, x22, #0x10
    3ac4:      	mov	w8, #0x4                // =4
    3ac8:      	add	x0, sp, #0xd8
    3acc:      	mov	w1, #0x8                // =8
    3ad0:      	blr	x8
    3ad4:      	add	x20, sp, #0xd8
    3ad8:      	ldr	x8, [sp, #0x80]
    3adc:      	ldr	x9, [x20]
    3ae0:      	cmp	x8, x9
    3ae4:      	b.eq	0x3c30 <generic_tracepoint_filter+0xb50>
    3ae8:      	add	x2, x22, #0x18
    3aec:      	mov	w8, #0x4                // =4
    3af0:      	mov	x0, x24
    3af4:      	mov	w1, #0x8                // =8
    3af8:      	blr	x8
    3afc:      	ldr	x8, [x20]
    3b00:      	add	x9, x8, #0x20
    3b04:      	stp	x9, x8, [sp, #0x78]
    3b08:      	subs	w19, w19, #0x1
    3b0c:      	b.eq	0x3c38 <generic_tracepoint_filter+0xb58>
    3b10:      	ldp	x20, x2, [sp, #0x70]
    3b14:      	ldp	x8, x9, [sp, #0x58]
    3b18:      	cmp	x20, x8
    3b1c:      	ccmp	x2, x9, #0x0, eq
    3b20:      	b.eq	0x3c30 <generic_tracepoint_filter+0xb50>
    3b24:      	ldr	x22, [sp, #0x80]
    3b28:      	mov	w8, #0x4                // =4
    3b2c:      	add	x0, sp, #0xb8
    3b30:      	mov	w1, #0x8                // =8
    3b34:      	blr	x8
    3b38:      	ldr	x8, [sp, #0xb8]
    3b3c:      	cmp	x20, x8
    3b40:      	b.eq	0x3ac0 <generic_tracepoint_filter+0x9e0>
    3b44:      	add	x25, x20, #0x18
    3b48:      	mov	w8, #0x4                // =4
    3b4c:      	add	x0, sp, #0xd8
    3b50:      	mov	w1, #0x8                // =8
    3b54:      	mov	x2, x25
    3b58:      	blr	x8
    3b5c:      	add	x8, sp, #0xd8
    3b60:      	ldr	x8, [x8]
    3b64:      	cmp	x8, x20
    3b68:      	b.eq	0x3ac0 <generic_tracepoint_filter+0x9e0>
    3b6c:      	mov	w8, #0x4                // =4
    3b70:      	add	x9, sp, #0xc0
    3b74:      	add	x0, sp, #0xc0
    3b78:      	mov	w1, #0x8                // =8
    3b7c:      	mov	x2, x25
    3b80:      	blr	x8
    3b84:      	add	x2, x20, #0x20
    3b88:      	mov	w8, #0x4                // =4
    3b8c:      	mov	w9, #0x10               // =16
    3b90:      	add	x10, sp, #0xc8
    3b94:      	add	x0, sp, #0xc8
    3b98:      	mov	w1, #0x10               // =16
    3b9c:      	blr	x8
    3ba0:      	ldr	w20, [sp, #0xcc]
    3ba4:      	ldr	x8, [sp, #0x68]
    3ba8:      	ldr	x10, [sp, #0x88]
    3bac:      	sub	x12, x10, x8
    3bb0:      	ldr	w22, [sp, #0x90]
    3bb4:      	subs	w10, w20, w22
    3bb8:      	ldr	x9, [sp, #0xd0]
    3bbc:      	csel	w10, wzr, w10, lo
    3bc0:      	cmp	w22, w20
    3bc4:      	csel	w11, w22, w20, lo
    3bc8:      	cinc	w13, w11, hi
    3bcc:      	sub	w14, w22, w13
    3bd0:      	subs	x12, x12, x13
    3bd4:      	str	w14, [sp, #0x90]
    3bd8:      	b.lo	0x3c38 <generic_tracepoint_filter+0xb58>
    3bdc:      	cmp	x12, #0xfff
    3be0:      	b.hi	0x3c38 <generic_tracepoint_filter+0xb58>
    3be4:      	cmp	w22, w20
    3be8:      	b.ls	0x3bf4 <generic_tracepoint_filter+0xb14>
    3bec:      	mov	w13, #0x2f              // =47
    3bf0:      	strb	w13, [x8, x12]
    3bf4:      	add	x25, x8, x12
    3bf8:      	cmp	w22, w20
    3bfc:      	add	x2, x9, x10
    3c00:      	and	w1, w11, #0xff
    3c04:      	mov	w8, #0x4                // =4
    3c08:      	cinc	x0, x25, hi
    3c0c:      	blr	x8
    3c10:      	cmp	w22, w20
    3c14:      	str	x25, [sp, #0x88]
    3c18:      	b.ls	0x3c38 <generic_tracepoint_filter+0xb58>
    3c1c:      	ldr	x8, [sp, #0xc0]
    3c20:      	str	x8, [sp, #0x70]
    3c24:      	subs	w19, w19, #0x1
    3c28:      	b.ne	0x3b10 <generic_tracepoint_filter+0xa30>
    3c2c:      	b	0x3c38 <generic_tracepoint_filter+0xb58>
    3c30:      	mov	w8, #0x1                // =1
    3c34:      	strb	w8, [sp, #0x94]
    3c38:      	ldr	x24, [sp, #0x88]
    3c3c:      	ldr	x9, [sp, #0x28]
    3c40:      	cmp	x24, x9
    3c44:      	b.eq	0x3c88 <generic_tracepoint_filter+0xba8>
    3c48:      	ldrb	w8, [sp, #0x94]
    3c4c:      	ldr	x29, [sp, #0x40]
    3c50:      	cmp	w8, #0x0
    3c54:      	ldr	x21, [sp, #0x30]
    3c58:      	cset	w8, eq
    3c5c:      	lsl	w9, w8, #1
    3c60:      	ldr	w8, [sp, #0x90]
    3c64:      	cmp	w8, #0x1
    3c68:      	str	w8, [x29, #0x550]
    3c6c:      	str	w9, [x29, #0x554]
    3c70:      	b.lt	0x3c80 <generic_tracepoint_filter+0xba0>
    3c74:      	mov	w9, #0x1000             // =4096
    3c78:      	sub	w8, w9, w8
    3c7c:      	str	w8, [x29, #0x550]
    3c80:      	cbnz	x24, 0x3c9c <generic_tracepoint_filter+0xbbc>
    3c84:      	b	0x3db4 <generic_tracepoint_filter+0xcd4>
    3c88:      	ldr	x29, [sp, #0x40]
    3c8c:      	ldr	x21, [sp, #0x30]
    3c90:      	mov	w8, wzr
    3c94:      	mov	x24, x9
    3c98:      	str	xzr, [x29, #0x550]
    3c9c:      	subs	w9, w8, #0x7f
    3ca0:      	mov	w10, #0x7f              // =127
    3ca4:      	mov	x11, x29
    3ca8:      	mov	x0, x21
    3cac:      	mov	x2, x24
    3cb0:      	csel	w29, w8, w10, lo
    3cb4:      	csel	w19, wzr, w9, lo
    3cb8:      	cmp	w8, #0xff
    3cbc:      	mov	w9, #0xff               // =255
    3cc0:      	csel	w8, w8, w9, lo
    3cc4:      	and	w1, w8, #0xff
    3cc8:      	str	w1, [x11, #0x550]
    3ccc:      	mov	w8, #0x4                // =4
    3cd0:      	blr	x8
    3cd4:      	adrp	x25, 0x3000 <generic_tracepoint_process_event+0x3000>
    3cd8:      	ldr	x25, [x25]
    3cdc:      	cbz	x0, 0x3d4c <generic_tracepoint_filter+0xc6c>
    3ce0:      	neg	w8, w0
    3ce4:      	mov	w9, #0x1                // =1
    3ce8:      	add	x1, sp, #0x58
    3cec:      	strh	w8, [sp, #0x58]
    3cf0:      	mov	w8, #0x8                // =8
    3cf4:      	mov	x0, x25
    3cf8:      	mov	w20, #0x1               // =1
    3cfc:      	strh	w8, [sp, #0x5a]
    3d00:      	mov	x8, #0x2de              // =734
    3d04:      	movk	x8, #0x4, lsl #32
    3d08:      	stur	x8, [sp, #0x5c]
    3d0c:      	add	x8, sp, #0x58
    3d10:      	blr	x9
    3d14:      	cbz	x0, 0x3d28 <generic_tracepoint_filter+0xc48>
    3d18:      	ldr	w8, [x0]
    3d1c:      	add	w8, w8, #0x1
    3d20:      	str	w8, [x0]
    3d24:      	b	0x3d4c <generic_tracepoint_filter+0xc6c>
    3d28:      	str	w20, [sp, #0xc8]
    3d2c:      	mov	x3, xzr
    3d30:      	mov	w8, #0x2                // =2
    3d34:      	add	x9, sp, #0x58
    3d38:      	add	x10, sp, #0xc8
    3d3c:      	add	x1, sp, #0x58
    3d40:      	add	x2, sp, #0xc8
    3d44:      	mov	x0, x25
    3d48:      	blr	x8
    3d4c:      	ldr	x9, [sp, #0xe8]
    3d50:      	mov	w8, #0x6390             // =25488
    3d54:      	add	x2, x24, x19
    3d58:      	mov	w1, w29
    3d5c:      	add	x0, x9, x8
    3d60:      	mov	w8, #0x4                // =4
    3d64:      	blr	x8
    3d68:      	ldr	x29, [sp, #0x40]
    3d6c:      	cbz	x0, 0x3db4 <generic_tracepoint_filter+0xcd4>
    3d70:      	neg	w8, w0
    3d74:      	mov	w9, #0x1                // =1
    3d78:      	add	x1, sp, #0x58
    3d7c:      	strh	w8, [sp, #0x58]
    3d80:      	mov	w8, #0x8                // =8
    3d84:      	mov	x0, x25
    3d88:      	mov	w19, #0x1               // =1
    3d8c:      	strh	w8, [sp, #0x5a]
    3d90:      	mov	x8, #0x2e0              // =736
    3d94:      	movk	x8, #0x4, lsl #32
    3d98:      	stur	x8, [sp, #0x5c]
    3d9c:      	add	x8, sp, #0x58
    3da0:      	blr	x9
    3da4:      	cbz	x0, 0x3ddc <generic_tracepoint_filter+0xcfc>
    3da8:      	ldr	w8, [x0]
    3dac:      	add	w8, w8, #0x1
    3db0:      	str	w8, [x0]
    3db4:      	ldr	w8, [x29, #0x550]
    3db8:      	sub	w9, w8, #0x101
    3dbc:      	cmn	w9, #0x101
    3dc0:      	b.hi	0x3e10 <generic_tracepoint_filter+0xd30>
    3dc4:      	ldr	x20, [sp, #0x38]
    3dc8:      	ldr	x22, [sp, #0xe8]
    3dcc:      	mov	w8, #-0x1               // =-1
    3dd0:      	ldr	x24, [sp, #0x48]
    3dd4:      	stur	w8, [x29, #0xb8]
    3dd8:      	b	0x3f60 <generic_tracepoint_filter+0xe80>
    3ddc:      	str	w19, [sp, #0xc8]
    3de0:      	mov	x3, xzr
    3de4:      	mov	w8, #0x2                // =2
    3de8:      	add	x9, sp, #0x58
    3dec:      	add	x10, sp, #0xc8
    3df0:      	add	x1, sp, #0x58
    3df4:      	add	x2, sp, #0xc8
    3df8:      	mov	x0, x25
    3dfc:      	blr	x8
    3e00:      	ldr	w8, [x29, #0x550]
    3e04:      	sub	w9, w8, #0x101
    3e08:      	cmn	w9, #0x101
    3e0c:      	b.ls	0x3dc4 <generic_tracepoint_filter+0xce4>
    3e10:      	ldr	x22, [sp, #0xe8]
    3e14:      	and	x24, x8, #0xff
    3e18:      	mov	w8, #0x5f80             // =24448
    3e1c:      	mov	x2, x21
    3e20:      	mov	w1, w24
    3e24:      	add	x0, x22, x8
    3e28:      	mov	w8, #0x4                // =4
    3e2c:      	blr	x8
    3e30:      	mov	x23, x0
    3e34:      	cbz	x0, 0x3eb0 <generic_tracepoint_filter+0xdd0>
    3e38:      	neg	w8, w23
    3e3c:      	adrp	x25, 0x3000 <generic_tracepoint_process_event+0x3000>
    3e40:      	mov	w9, #0x1                // =1
    3e44:      	strh	w8, [sp, #0x58]
    3e48:      	mov	w8, #0xf                // =15
    3e4c:      	add	x1, sp, #0x58
    3e50:      	mov	w19, #0x1               // =1
    3e54:      	strh	w8, [sp, #0x5a]
    3e58:      	mov	x8, #0x164              // =356
    3e5c:      	movk	x8, #0x4, lsl #32
    3e60:      	stur	x8, [sp, #0x5c]
    3e64:      	add	x8, sp, #0x58
    3e68:      	ldr	x25, [x25]
    3e6c:      	mov	x0, x25
    3e70:      	blr	x9
    3e74:      	cbz	x0, 0x3e88 <generic_tracepoint_filter+0xda8>
    3e78:      	ldr	w8, [x0]
    3e7c:      	add	w8, w8, #0x1
    3e80:      	str	w8, [x0]
    3e84:      	b	0x3eac <generic_tracepoint_filter+0xdcc>
    3e88:      	str	w19, [sp, #0xc8]
    3e8c:      	mov	x3, xzr
    3e90:      	mov	w8, #0x2                // =2
    3e94:      	add	x9, sp, #0x58
    3e98:      	add	x10, sp, #0xc8
    3e9c:      	add	x1, sp, #0x58
    3ea0:      	add	x2, sp, #0xc8
    3ea4:      	mov	x0, x25
    3ea8:      	blr	x8
    3eac:      	ldr	x22, [sp, #0xe8]
    3eb0:      	cmp	w23, #0x0
    3eb4:      	csel	w8, w24, w23, eq
    3eb8:      	cmp	w24, #0x7f
    3ebc:      	stur	w8, [x29, #0xb8]
    3ec0:      	mov	w8, #0x7f               // =127
    3ec4:      	csel	w1, w24, w8, lo
    3ec8:      	mov	w8, #0x6080             // =24704
    3ecc:      	add	x0, x22, x8
    3ed0:      	mov	w8, #0x6390             // =25488
    3ed4:      	add	x2, x22, x8
    3ed8:      	mov	w8, #0x4                // =4
    3edc:      	blr	x8
    3ee0:      	ldr	x20, [sp, #0x38]
    3ee4:      	ldr	x24, [sp, #0x48]
    3ee8:      	cbz	x0, 0x3f60 <generic_tracepoint_filter+0xe80>
    3eec:      	neg	w8, w0
    3ef0:      	adrp	x23, 0x3000 <generic_tracepoint_process_event+0x3000>
    3ef4:      	mov	w9, #0x1                // =1
    3ef8:      	strh	w8, [sp, #0x58]
    3efc:      	mov	w8, #0xf                // =15
    3f00:      	add	x1, sp, #0x58
    3f04:      	mov	w19, #0x1               // =1
    3f08:      	strh	w8, [sp, #0x5a]
    3f0c:      	mov	x8, #0x16a              // =362
    3f10:      	movk	x8, #0x4, lsl #32
    3f14:      	stur	x8, [sp, #0x5c]
    3f18:      	add	x8, sp, #0x58
    3f1c:      	ldr	x23, [x23]
    3f20:      	mov	x0, x23
    3f24:      	blr	x9
    3f28:      	cbz	x0, 0x3f3c <generic_tracepoint_filter+0xe5c>
    3f2c:      	ldr	w8, [x0]
    3f30:      	add	w8, w8, #0x1
    3f34:      	str	w8, [x0]
    3f38:      	b	0x3f60 <generic_tracepoint_filter+0xe80>
    3f3c:      	str	w19, [sp, #0xc8]
    3f40:      	mov	x3, xzr
    3f44:      	mov	w8, #0x2                // =2
    3f48:      	add	x9, sp, #0x58
    3f4c:      	add	x10, sp, #0xc8
    3f50:      	add	x1, sp, #0x58
    3f54:      	add	x2, sp, #0xc8
    3f58:      	mov	x0, x23
    3f5c:      	blr	x8
    3f60:      	ldrb	w8, [x22, #0x1]
    3f64:      	orr	w8, w8, #0x10
    3f68:      	strb	w8, [x22, #0x1]
    3f6c:      	adrp	x0, 0x3000 <generic_tracepoint_process_event+0x3000>
    3f70:      	mov	w8, #0x5ef8             // =24312
    3f74:      	ldr	x0, [x0]
    3f78:      	add	x1, x22, x8
    3f7c:      	mov	w8, #0x1                // =1
    3f80:      	blr	x8
    3f84:      	cbz	x0, 0x540c <generic_tracepoint_filter+0x232c>
    3f88:      	ldr	x21, [x22, #0x5eb8]
    3f8c:      	cmp	x21, #0x6
    3f90:      	b.hs	0x4128 <generic_tracepoint_filter+0x1048>
    3f94:      	ldrsw	x8, [x0]
    3f98:      	mov	x23, x0
    3f9c:      	cbz	w8, 0x4144 <generic_tracepoint_filter+0x1064>
    3fa0:      	cmp	x21, x8
    3fa4:      	b.hs	0x4128 <generic_tracepoint_filter+0x1048>
    3fa8:      	str	x8, [sp, #0x28]
    3fac:      	stp	x29, x24, [sp, #0x40]
    3fb0:      	adrp	x24, 0x3000 <generic_tracepoint_process_event+0x3000>
    3fb4:      	mov	w8, #0x1                // =1
    3fb8:      	add	x9, sp, #0xd8
    3fbc:      	str	x22, [sp, #0xe8]
    3fc0:      	add	x1, sp, #0xd8
    3fc4:      	str	x20, [sp, #0x38]
    3fc8:      	str	w21, [sp, #0xd8]
    3fcc:      	str	wzr, [sp, #0xc0]
    3fd0:      	ldr	x24, [x24]
    3fd4:      	mov	x0, x24
    3fd8:      	blr	x8
    3fdc:      	cbz	x0, 0x43f4 <generic_tracepoint_filter+0x1314>
    3fe0:      	ldr	w8, [x0]
    3fe4:      	mov	x25, x0
    3fe8:      	cbz	w8, 0x43f4 <generic_tracepoint_filter+0x1314>
    3fec:      	ldr	x9, [sp, #0x48]
    3ff0:      	ldr	w9, [x9, #0x68]
    3ff4:      	tbnz	w9, #0x1f, 0x53b4 <generic_tracepoint_filter+0x22d4>
    3ff8:      	cmp	w8, #0x1b
    3ffc:      	b.hi	0x53b4 <generic_tracepoint_filter+0x22d4>
    4000:      	mov	w9, #0x1                // =1
    4004:      	lsl	w9, w9, w8
    4008:      	tst	w9, #0x60
    400c:      	b.ne	0x4204 <generic_tracepoint_filter+0x1124>
    4010:      	mov	w10, #0x100             // =256
    4014:      	movk	w10, #0x400, lsl #16
    4018:      	tst	w9, w10
    401c:      	b.ne	0x4180 <generic_tracepoint_filter+0x10a0>
    4020:      	mov	w9, #0x1                // =1
    4024:      	lsl	w8, w9, w8
    4028:      	mov	w9, #0x200              // =512
    402c:      	movk	w9, #0x800, lsl #16
    4030:      	tst	w8, w9
    4034:      	b.eq	0x53b4 <generic_tracepoint_filter+0x22d4>
    4038:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    403c:      	add	x1, x25, #0x4
    4040:      	mov	w8, #0x1                // =1
    4044:      	ldr	x0, [x0]
    4048:      	blr	x8
    404c:      	cbz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    4050:      	ldr	x8, [sp, #0x48]
    4054:      	mov	x20, x0
    4058:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    405c:      	mov	w9, #0x7f               // =127
    4060:      	ldr	w8, [x8, #0x68]
    4064:      	ldr	x0, [x0]
    4068:      	add	x1, sp, #0xc0
    406c:      	cmp	w8, #0x7f
    4070:      	csel	w19, w8, w9, lt
    4074:      	mov	w8, #0x1                // =1
    4078:      	add	x9, sp, #0xc0
    407c:      	blr	x8
    4080:      	cbz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    4084:      	sxtw	x1, w19
    4088:      	mov	x29, x0
    408c:      	lsl	w8, w1, #3
    4090:      	str	w8, [x0]
    4094:      	ldr	x8, [sp, #0x48]
    4098:      	ldr	w8, [x8, #0x6c]
    409c:      	cbnz	w8, 0x40fc <generic_tracepoint_filter+0x101c>
    40a0:      	ldr	x11, [sp, #0x48]
    40a4:      	and	w13, w1, #0x7f
    40a8:      	mov	x8, xzr
    40ac:      	ldr	w12, [x11, #0x68]
    40b0:      	add	x9, x11, #0x1f0
    40b4:      	add	x10, x11, #0x170
    40b8:      	sub	w11, w12, w1
    40bc:      	add	w12, w12, w13
    40c0:      	add	w11, w11, w13
    40c4:      	mvn	w13, w1
    40c8:      	add	w12, w13, w12
    40cc:      	cmp	x8, #0x7f
    40d0:      	b.eq	0x40f0 <generic_tracepoint_filter+0x1010>
    40d4:      	and	x13, x12, #0x7f
    40d8:      	sub	w12, w12, #0x1
    40dc:      	ldrb	w13, [x10, x13]
    40e0:      	strb	w13, [x9, x8]
    40e4:      	add	x8, x8, #0x1
    40e8:      	cmp	x11, x8
    40ec:      	b.ne	0x40cc <generic_tracepoint_filter+0xfec>
    40f0:      	ldr	x9, [sp, #0x48]
    40f4:      	mov	w8, #0x1                // =1
    40f8:      	str	w8, [x9, #0x6c]
    40fc:      	cmp	w1, #0x7f
    4100:      	b.hi	0x411c <generic_tracepoint_filter+0x103c>
    4104:      	ldr	x8, [sp, #0x48]
    4108:      	add	x0, x29, #0x4
    410c:      	add	x2, x8, #0x1f0
    4110:      	mov	w8, #0x4                // =4
    4114:      	blr	x8
    4118:      	tbnz	x0, #0x3f, 0x53b4 <generic_tracepoint_filter+0x22d4>
    411c:      	mov	w8, #0x1                // =1
    4120:      	mov	x0, x20
    4124:      	b	0x41fc <generic_tracepoint_filter+0x111c>
    4128:      	ldr	w8, [x24]
    412c:      	str	w8, [x22, #0x10]
    4130:      	ldr	x8, [x24, #0x8]
    4134:      	str	x8, [x22, #0x18]
    4138:      	ldrb	w8, [x29]
    413c:      	cbnz	w8, 0x53f0 <generic_tracepoint_filter+0x2310>
    4140:      	b	0x540c <generic_tracepoint_filter+0x232c>
    4144:      	mov	w8, #0x1                // =1
    4148:      	strb	w8, [x29]
    414c:      	ldr	w8, [x24]
    4150:      	str	w8, [x22, #0x10]
    4154:      	ldr	x8, [x24, #0x8]
    4158:      	str	x8, [x22, #0x18]
    415c:      	b	0x53f0 <generic_tracepoint_filter+0x2310>
    4160:      	mov	w8, #0x2964             // =10596
    4164:      	add	x20, x24, #0xff6
    4168:      	strh	w8, [x24, #0xffe]
    416c:      	adrp	x8, 0x4000 <generic_tracepoint_filter+0xf20>
    4170:      	add	x8, x8, #0x0
    4174:      	ldr	x8, [x8]
    4178:      	str	x8, [x20]
    417c:      	b	0x3824 <generic_tracepoint_filter+0x744>
    4180:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4184:      	add	x1, x25, #0x4
    4188:      	mov	w8, #0x1                // =1
    418c:      	ldr	x0, [x0]
    4190:      	blr	x8
    4194:      	cbz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    4198:      	mov	x19, x0
    419c:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    41a0:      	mov	w8, #0x1                // =1
    41a4:      	ldr	x0, [x0]
    41a8:      	add	x9, sp, #0xc0
    41ac:      	add	x1, sp, #0xc0
    41b0:      	blr	x8
    41b4:      	cbz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    41b8:      	mov	w1, wzr
    41bc:      	mov	w2, #0x104              // =260
    41c0:      	mov	x29, x0
    41c4:      	bl	0x41c4 <generic_tracepoint_filter+0x10e4>
    41c8:      	ldr	x10, [sp, #0x48]
    41cc:      	mov	x0, x29
    41d0:      	ldr	w8, [x10, #0x68]
    41d4:      	add	x2, x10, #0x70
    41d8:      	lsl	w9, w8, #3
    41dc:      	and	x8, x8, #0xff
    41e0:      	str	w9, [x0], #0x4
    41e4:      	mov	w9, #0x4                // =4
    41e8:      	ldrb	w1, [x10, #0x68]
    41ec:      	blr	x9
    41f0:      	tbnz	x0, #0x3f, 0x53b4 <generic_tracepoint_filter+0x22d4>
    41f4:      	mov	w8, #0x1                // =1
    41f8:      	mov	x0, x19
    41fc:      	mov	x1, x29
    4200:      	b	0x43bc <generic_tracepoint_filter+0x12dc>
    4204:      	str	wzr, [sp, #0xc8]
    4208:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    420c:      	mov	w8, #0x1                // =1
    4210:      	add	x9, sp, #0xc8
    4214:      	ldr	x0, [x0]
    4218:      	add	x1, sp, #0xc8
    421c:      	blr	x8
    4220:      	cbz	x0, 0x4368 <generic_tracepoint_filter+0x1288>
    4224:      	ldr	x9, [sp, #0x48]
    4228:      	ldr	x8, [x0]
    422c:      	ldr	x9, [x9, #0x378]
    4230:      	cmp	x8, x9
    4234:      	b.eq	0x4368 <generic_tracepoint_filter+0x1288>
    4238:      	str	x0, [sp, #0x30]
    423c:      	adrp	x8, 0x4000 <generic_tracepoint_filter+0xf20>
    4240:      	ldr	x8, [x8]
    4244:      	ldrb	w8, [x8]
    4248:      	cbz	w8, 0x42d4 <generic_tracepoint_filter+0x11f4>
    424c:      	adrp	x19, 0x4000 <generic_tracepoint_filter+0xf20>
    4250:      	mov	w20, #0x869f            // =34463
    4254:      	mov	x22, xzr
    4258:      	ldr	x19, [x19]
    425c:      	movk	w20, #0x1, lsl #16
    4260:      	b	0x4278 <generic_tracepoint_filter+0x1198>
    4264:      	cmp	x29, x22
    4268:      	mov	x22, x29
    426c:      	ccmp	w20, #0x0, #0x4, ne
    4270:      	sub	w20, w20, #0x1
    4274:      	b.eq	0x4358 <generic_tracepoint_filter+0x1278>
    4278:      	ldr	x8, [sp, #0x48]
    427c:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4280:      	add	x9, sp, #0x58
    4284:      	add	x1, sp, #0x58
    4288:      	ldr	w8, [x8, #0x10]
    428c:      	str	w8, [sp, #0x58]
    4290:      	mov	w8, #0x1                // =1
    4294:      	ldr	x0, [x0]
    4298:      	blr	x8
    429c:      	cbz	x0, 0x4358 <generic_tracepoint_filter+0x1278>
    42a0:      	add	x1, x0, #0x70
    42a4:      	mov	w8, #0x1                // =1
    42a8:      	mov	x29, x0
    42ac:      	mov	x0, x19
    42b0:      	blr	x8
    42b4:      	cbz	x0, 0x4264 <generic_tracepoint_filter+0x1184>
    42b8:      	ldr	x8, [x0]
    42bc:      	cbz	x8, 0x4264 <generic_tracepoint_filter+0x1184>
    42c0:      	ldr	x10, [sp, #0x48]
    42c4:      	ldr	x9, [x10, #0x370]
    42c8:      	orr	x8, x9, x8
    42cc:      	str	x8, [x10, #0x370]
    42d0:      	b	0x4264 <generic_tracepoint_filter+0x1184>
    42d4:      	adrp	x19, 0x4000 <generic_tracepoint_filter+0xf20>
    42d8:      	mov	x22, xzr
    42dc:      	mov	w20, #0x3ff             // =1023
    42e0:      	ldr	x19, [x19]
    42e4:      	b	0x42fc <generic_tracepoint_filter+0x121c>
    42e8:      	cmp	x29, x22
    42ec:      	mov	x22, x29
    42f0:      	ccmp	w20, #0x0, #0x4, ne
    42f4:      	sub	w20, w20, #0x1
    42f8:      	b.eq	0x4358 <generic_tracepoint_filter+0x1278>
    42fc:      	ldr	x8, [sp, #0x48]
    4300:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4304:      	add	x9, sp, #0x58
    4308:      	add	x1, sp, #0x58
    430c:      	ldr	w8, [x8, #0x10]
    4310:      	str	w8, [sp, #0x58]
    4314:      	mov	w8, #0x1                // =1
    4318:      	ldr	x0, [x0]
    431c:      	blr	x8
    4320:      	cbz	x0, 0x4358 <generic_tracepoint_filter+0x1278>
    4324:      	add	x1, x0, #0x70
    4328:      	mov	w8, #0x1                // =1
    432c:      	mov	x29, x0
    4330:      	mov	x0, x19
    4334:      	blr	x8
    4338:      	cbz	x0, 0x42e8 <generic_tracepoint_filter+0x1208>
    433c:      	ldr	x8, [x0]
    4340:      	cbz	x8, 0x42e8 <generic_tracepoint_filter+0x1208>
    4344:      	ldr	x10, [sp, #0x48]
    4348:      	ldr	x9, [x10, #0x370]
    434c:      	orr	x8, x9, x8
    4350:      	str	x8, [x10, #0x370]
    4354:      	b	0x42e8 <generic_tracepoint_filter+0x1208>
    4358:      	ldr	x8, [sp, #0x30]
    435c:      	ldr	x9, [sp, #0x48]
    4360:      	ldr	x8, [x8]
    4364:      	str	x8, [x9, #0x378]
    4368:      	ldr	w8, [x25, #0x8]
    436c:      	cmn	w8, #0x1
    4370:      	b.eq	0x4394 <generic_tracepoint_filter+0x12b4>
    4374:      	ldr	x9, [sp, #0x48]
    4378:      	ldr	x9, [x9, #0x370]
    437c:      	lsr	x8, x9, x8
    4380:      	tbz	w8, #0x0, 0x4394 <generic_tracepoint_filter+0x12b4>
    4384:      	mov	x0, #0xffee             // =65518
    4388:      	movk	x0, #0xadc0, lsl #16
    438c:      	movk	x0, #0xb, lsl #32
    4390:      	b	0x43c0 <generic_tracepoint_filter+0x12e0>
    4394:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4398:      	mov	w8, #0x1                // =1
    439c:      	add	x9, sp, #0xd8
    43a0:      	ldr	x0, [x0]
    43a4:      	add	x1, sp, #0xd8
    43a8:      	blr	x8
    43ac:      	cbz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    43b0:      	ldr	x8, [sp, #0x48]
    43b4:      	add	x1, x8, #0x70
    43b8:      	mov	w8, #0x1                // =1
    43bc:      	blr	x8
    43c0:      	ldr	w8, [x25]
    43c4:      	cmp	w8, #0x25
    43c8:      	b.hi	0x43f0 <generic_tracepoint_filter+0x1310>
    43cc:      	mov	w9, #0x1                // =1
    43d0:      	lsl	x8, x9, x8
    43d4:      	mov	x9, #0x50               // =80
    43d8:      	movk	x9, #0xc00, lsl #16
    43dc:      	movk	x9, #0x20, lsl #32
    43e0:      	tst	x8, x9
    43e4:      	b.eq	0x43f0 <generic_tracepoint_filter+0x1310>
    43e8:      	cbnz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    43ec:      	b	0x43f4 <generic_tracepoint_filter+0x1314>
    43f0:      	cbz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    43f4:      	adrp	x8, 0x4000 <generic_tracepoint_filter+0xf20>
    43f8:      	ldr	x8, [x8]
    43fc:      	ldrb	w8, [x8]
    4400:      	cbz	w8, 0x47cc <generic_tracepoint_filter+0x16ec>
    4404:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4408:      	mov	w8, #0x1                // =1
    440c:      	ldr	x0, [x0]
    4410:      	ldr	x1, [sp, #0x48]
    4414:      	blr	x8
    4418:      	cbz	x0, 0x47cc <generic_tracepoint_filter+0x16ec>
    441c:      	add	w8, w21, #0x5
    4420:      	str	wzr, [sp, #0xc0]
    4424:      	add	x9, sp, #0xd8
    4428:      	mov	x25, x0
    442c:      	str	w8, [sp, #0xd8]
    4430:      	mov	w8, #0x1                // =1
    4434:      	add	x1, sp, #0xd8
    4438:      	mov	x0, x24
    443c:      	blr	x8
    4440:      	cbz	x0, 0x47cc <generic_tracepoint_filter+0x16ec>
    4444:      	ldr	w8, [x0]
    4448:      	mov	x24, x0
    444c:      	cbz	w8, 0x47cc <generic_tracepoint_filter+0x16ec>
    4450:      	ldr	w9, [x25]
    4454:      	tbnz	w9, #0x1f, 0x53b4 <generic_tracepoint_filter+0x22d4>
    4458:      	cmp	w8, #0x1b
    445c:      	b.hi	0x53b4 <generic_tracepoint_filter+0x22d4>
    4460:      	mov	w9, #0x1                // =1
    4464:      	lsl	w9, w9, w8
    4468:      	tst	w9, #0x60
    446c:      	b.ne	0x45f4 <generic_tracepoint_filter+0x1514>
    4470:      	mov	w10, #0x100             // =256
    4474:      	movk	w10, #0x400, lsl #16
    4478:      	tst	w9, w10
    447c:      	b.ne	0x4574 <generic_tracepoint_filter+0x1494>
    4480:      	mov	w9, #0x1                // =1
    4484:      	lsl	w8, w9, w8
    4488:      	mov	w9, #0x200              // =512
    448c:      	movk	w9, #0x800, lsl #16
    4490:      	tst	w8, w9
    4494:      	b.eq	0x53b4 <generic_tracepoint_filter+0x22d4>
    4498:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    449c:      	add	x1, x24, #0x4
    44a0:      	mov	w8, #0x1                // =1
    44a4:      	ldr	x0, [x0]
    44a8:      	blr	x8
    44ac:      	cbz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    44b0:      	ldr	w8, [x25]
    44b4:      	mov	x20, x0
    44b8:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    44bc:      	mov	w9, #0x7f               // =127
    44c0:      	ldr	x0, [x0]
    44c4:      	add	x1, sp, #0xc0
    44c8:      	cmp	w8, #0x7f
    44cc:      	csel	w19, w8, w9, lt
    44d0:      	mov	w8, #0x1                // =1
    44d4:      	add	x9, sp, #0xc0
    44d8:      	blr	x8
    44dc:      	cbz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    44e0:      	sxtw	x1, w19
    44e4:      	mov	x29, x0
    44e8:      	lsl	w8, w1, #3
    44ec:      	str	w8, [x0]
    44f0:      	ldr	w8, [x25, #0x4]
    44f4:      	cbnz	w8, 0x454c <generic_tracepoint_filter+0x146c>
    44f8:      	ldr	w12, [x25]
    44fc:      	and	w13, w1, #0x7f
    4500:      	mov	x8, xzr
    4504:      	add	x9, x25, #0x188
    4508:      	add	x10, x25, #0x108
    450c:      	sub	w11, w12, w1
    4510:      	add	w12, w12, w13
    4514:      	add	w11, w11, w13
    4518:      	mvn	w13, w1
    451c:      	add	w12, w13, w12
    4520:      	cmp	x8, #0x7f
    4524:      	b.eq	0x4544 <generic_tracepoint_filter+0x1464>
    4528:      	and	x13, x12, #0x7f
    452c:      	sub	w12, w12, #0x1
    4530:      	ldrb	w13, [x10, x13]
    4534:      	strb	w13, [x9, x8]
    4538:      	add	x8, x8, #0x1
    453c:      	cmp	x11, x8
    4540:      	b.ne	0x4520 <generic_tracepoint_filter+0x1440>
    4544:      	mov	w8, #0x1                // =1
    4548:      	str	w8, [x25, #0x4]
    454c:      	cmp	w1, #0x7f
    4550:      	b.hi	0x4568 <generic_tracepoint_filter+0x1488>
    4554:      	add	x0, x29, #0x4
    4558:      	add	x2, x25, #0x188
    455c:      	mov	w8, #0x4                // =4
    4560:      	blr	x8
    4564:      	tbnz	x0, #0x3f, 0x53b4 <generic_tracepoint_filter+0x22d4>
    4568:      	mov	w8, #0x1                // =1
    456c:      	mov	x0, x20
    4570:      	b	0x45ec <generic_tracepoint_filter+0x150c>
    4574:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4578:      	add	x1, x24, #0x4
    457c:      	mov	w8, #0x1                // =1
    4580:      	ldr	x0, [x0]
    4584:      	blr	x8
    4588:      	cbz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    458c:      	mov	x19, x0
    4590:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4594:      	mov	w8, #0x1                // =1
    4598:      	ldr	x0, [x0]
    459c:      	add	x9, sp, #0xc0
    45a0:      	add	x1, sp, #0xc0
    45a4:      	blr	x8
    45a8:      	cbz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    45ac:      	mov	w1, wzr
    45b0:      	mov	w2, #0x104              // =260
    45b4:      	mov	x29, x0
    45b8:      	bl	0x45b8 <generic_tracepoint_filter+0x14d8>
    45bc:      	ldr	w8, [x25]
    45c0:      	mov	x0, x29
    45c4:      	add	x2, x25, #0x8
    45c8:      	lsl	w9, w8, #3
    45cc:      	and	x8, x8, #0xff
    45d0:      	str	w9, [x0], #0x4
    45d4:      	mov	w9, #0x4                // =4
    45d8:      	ldrb	w1, [x25]
    45dc:      	blr	x9
    45e0:      	tbnz	x0, #0x3f, 0x53b4 <generic_tracepoint_filter+0x22d4>
    45e4:      	mov	w8, #0x1                // =1
    45e8:      	mov	x0, x19
    45ec:      	mov	x1, x29
    45f0:      	b	0x4794 <generic_tracepoint_filter+0x16b4>
    45f4:      	str	wzr, [sp, #0xc8]
    45f8:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    45fc:      	mov	w8, #0x1                // =1
    4600:      	add	x9, sp, #0xc8
    4604:      	ldr	x0, [x0]
    4608:      	add	x1, sp, #0xc8
    460c:      	blr	x8
    4610:      	cbz	x0, 0x4748 <generic_tracepoint_filter+0x1668>
    4614:      	ldr	x8, [x0]
    4618:      	ldr	x9, [x25, #0x310]
    461c:      	cmp	x8, x9
    4620:      	b.eq	0x4748 <generic_tracepoint_filter+0x1668>
    4624:      	str	x0, [sp, #0x30]
    4628:      	adrp	x8, 0x4000 <generic_tracepoint_filter+0xf20>
    462c:      	ldr	x8, [x8]
    4630:      	ldrb	w8, [x8]
    4634:      	cbz	w8, 0x46bc <generic_tracepoint_filter+0x15dc>
    4638:      	adrp	x19, 0x4000 <generic_tracepoint_filter+0xf20>
    463c:      	mov	w20, #0x869f            // =34463
    4640:      	mov	x22, xzr
    4644:      	ldr	x19, [x19]
    4648:      	movk	w20, #0x1, lsl #16
    464c:      	b	0x4664 <generic_tracepoint_filter+0x1584>
    4650:      	cmp	x29, x22
    4654:      	mov	x22, x29
    4658:      	ccmp	w20, #0x0, #0x4, ne
    465c:      	sub	w20, w20, #0x1
    4660:      	b.eq	0x473c <generic_tracepoint_filter+0x165c>
    4664:      	ldr	x8, [sp, #0x48]
    4668:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    466c:      	add	x9, sp, #0x58
    4670:      	add	x1, sp, #0x58
    4674:      	ldr	w8, [x8, #0x10]
    4678:      	str	w8, [sp, #0x58]
    467c:      	mov	w8, #0x1                // =1
    4680:      	ldr	x0, [x0]
    4684:      	blr	x8
    4688:      	cbz	x0, 0x473c <generic_tracepoint_filter+0x165c>
    468c:      	add	x1, x0, #0x70
    4690:      	mov	w8, #0x1                // =1
    4694:      	mov	x29, x0
    4698:      	mov	x0, x19
    469c:      	blr	x8
    46a0:      	cbz	x0, 0x4650 <generic_tracepoint_filter+0x1570>
    46a4:      	ldr	x8, [x0]
    46a8:      	cbz	x8, 0x4650 <generic_tracepoint_filter+0x1570>
    46ac:      	ldr	x9, [x25, #0x308]
    46b0:      	orr	x8, x9, x8
    46b4:      	str	x8, [x25, #0x308]
    46b8:      	b	0x4650 <generic_tracepoint_filter+0x1570>
    46bc:      	adrp	x19, 0x4000 <generic_tracepoint_filter+0xf20>
    46c0:      	mov	x22, xzr
    46c4:      	mov	w20, #0x3ff             // =1023
    46c8:      	ldr	x19, [x19]
    46cc:      	b	0x46e4 <generic_tracepoint_filter+0x1604>
    46d0:      	cmp	x29, x22
    46d4:      	mov	x22, x29
    46d8:      	ccmp	w20, #0x0, #0x4, ne
    46dc:      	sub	w20, w20, #0x1
    46e0:      	b.eq	0x473c <generic_tracepoint_filter+0x165c>
    46e4:      	ldr	x8, [sp, #0x48]
    46e8:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    46ec:      	add	x9, sp, #0x58
    46f0:      	add	x1, sp, #0x58
    46f4:      	ldr	w8, [x8, #0x10]
    46f8:      	str	w8, [sp, #0x58]
    46fc:      	mov	w8, #0x1                // =1
    4700:      	ldr	x0, [x0]
    4704:      	blr	x8
    4708:      	cbz	x0, 0x473c <generic_tracepoint_filter+0x165c>
    470c:      	add	x1, x0, #0x70
    4710:      	mov	w8, #0x1                // =1
    4714:      	mov	x29, x0
    4718:      	mov	x0, x19
    471c:      	blr	x8
    4720:      	cbz	x0, 0x46d0 <generic_tracepoint_filter+0x15f0>
    4724:      	ldr	x8, [x0]
    4728:      	cbz	x8, 0x46d0 <generic_tracepoint_filter+0x15f0>
    472c:      	ldr	x9, [x25, #0x308]
    4730:      	orr	x8, x9, x8
    4734:      	str	x8, [x25, #0x308]
    4738:      	b	0x46d0 <generic_tracepoint_filter+0x15f0>
    473c:      	ldr	x8, [sp, #0x30]
    4740:      	ldr	x8, [x8]
    4744:      	str	x8, [x25, #0x310]
    4748:      	ldr	w8, [x24, #0x8]
    474c:      	cmn	w8, #0x1
    4750:      	b.eq	0x4770 <generic_tracepoint_filter+0x1690>
    4754:      	ldr	x9, [x25, #0x308]
    4758:      	lsr	x8, x9, x8
    475c:      	tbz	w8, #0x0, 0x4770 <generic_tracepoint_filter+0x1690>
    4760:      	mov	x0, #0xffee             // =65518
    4764:      	movk	x0, #0xadc0, lsl #16
    4768:      	movk	x0, #0xb, lsl #32
    476c:      	b	0x4798 <generic_tracepoint_filter+0x16b8>
    4770:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4774:      	mov	w8, #0x1                // =1
    4778:      	add	x9, sp, #0xd8
    477c:      	ldr	x0, [x0]
    4780:      	add	x1, sp, #0xd8
    4784:      	blr	x8
    4788:      	cbz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    478c:      	add	x1, x25, #0x8
    4790:      	mov	w8, #0x1                // =1
    4794:      	blr	x8
    4798:      	ldr	w8, [x24]
    479c:      	cmp	w8, #0x25
    47a0:      	b.hi	0x47c8 <generic_tracepoint_filter+0x16e8>
    47a4:      	mov	w9, #0x1                // =1
    47a8:      	lsl	x8, x9, x8
    47ac:      	mov	x9, #0x50               // =80
    47b0:      	movk	x9, #0xc00, lsl #16
    47b4:      	movk	x9, #0x20, lsl #32
    47b8:      	tst	x8, x9
    47bc:      	b.eq	0x47c8 <generic_tracepoint_filter+0x16e8>
    47c0:      	cbnz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    47c4:      	b	0x47cc <generic_tracepoint_filter+0x16ec>
    47c8:      	cbz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    47cc:      	lsl	w8, w21, #2
    47d0:      	add	x9, x8, #0x4
    47d4:      	ldr	w8, [x9, x23]
    47d8:      	add	w9, w8, w9
    47dc:      	and	w11, w9, #0x3ff
    47e0:      	add	w9, w9, #0x4
    47e4:      	and	x9, x9, #0x3ff
    47e8:      	add	x10, x11, #0x8
    47ec:      	ldr	w9, [x9, x23]
    47f0:      	cmp	w9, #0x5
    47f4:      	b.lo	0x4884 <generic_tracepoint_filter+0x17a4>
    47f8:      	add	x9, x10, x23
    47fc:      	ldr	w10, [x9, #0x8]
    4800:      	ldp	w12, w22, [x9]
    4804:      	stp	x9, x11, [sp, #0x8]
    4808:      	mov	w9, #0x4                // =4
    480c:      	cmp	w10, #0x4
    4810:      	stp	xzr, xzr, [sp, #0x58]
    4814:      	csel	w9, w10, w9, lo
    4818:      	cmp	w12, #0x6
    481c:      	b.ne	0x4828 <generic_tracepoint_filter+0x1748>
    4820:      	mov	x11, #0x100000001       // =4294967297
    4824:      	stp	x11, x11, [sp, #0x58]
    4828:      	cbz	w10, 0x4c8c <generic_tracepoint_filter+0x1bac>
    482c:      	ldr	x10, [sp, #0x48]
    4830:      	add	w8, w8, w21, lsl #2
    4834:      	tst	x22, #0x1
    4838:      	add	x25, sp, #0x58
    483c:      	str	w12, [sp, #0x30]
    4840:      	add	w8, w8, #0x4
    4844:      	and	x8, x8, #0x3ff
    4848:      	add	x21, x8, #0x14
    484c:      	sub	x8, x9, #0x1
    4850:      	mov	w9, #0x3                // =3
    4854:      	add	x11, x10, #0x24
    4858:      	str	x11, [sp, #0x20]
    485c:      	csel	x11, x10, x11, eq
    4860:      	cmp	x8, #0x3
    4864:      	add	x10, x10, #0x10
    4868:      	csel	x8, x8, x9, lo
    486c:      	and	x9, x21, #0x7fc
    4870:      	mov	x20, x11
    4874:      	str	x10, [sp, #0x18]
    4878:      	add	x19, x23, x9
    487c:      	add	x24, x8, #0x1
    4880:      	b	0x48bc <generic_tracepoint_filter+0x17dc>
    4884:      	mov	w9, #0x1                // =1
    4888:      	mov	w8, w10
    488c:      	b	0x4cd4 <generic_tracepoint_filter+0x1bf4>
    4890:      	mov	w8, #0x1                // =1
    4894:      	ldr	w12, [sp, #0x30]
    4898:      	mov	x11, x20
    489c:      	cmp	w12, #0x6
    48a0:      	eor	w8, w8, #0x1
    48a4:      	csinc	w9, w8, wzr, eq
    48a8:      	str	w9, [x25], #0x4
    48ac:      	add	x21, x21, #0x4
    48b0:      	add	x19, x19, #0x4
    48b4:      	subs	x24, x24, #0x1
    48b8:      	b.eq	0x4c8c <generic_tracepoint_filter+0x1bac>
    48bc:      	cmp	x21, #0x3e8
    48c0:      	b.ls	0x4ae4 <generic_tracepoint_filter+0x1a04>
    48c4:      	mov	x29, xzr
    48c8:      	tbz	w22, #0x1, 0x4aec <generic_tracepoint_filter+0x1a0c>
    48cc:      	tbnz	w22, #0x0, 0x4b18 <generic_tracepoint_filter+0x1a38>
    48d0:      	ldr	x10, [sp, #0x48]
    48d4:      	mov	w8, #0x1                // =1
    48d8:      	ldr	w9, [x10]
    48dc:      	cmp	x29, x9
    48e0:      	b.eq	0x489c <generic_tracepoint_filter+0x17bc>
    48e4:      	ldr	w9, [x10, #0x10]
    48e8:      	cmp	x29, x9
    48ec:      	b.eq	0x489c <generic_tracepoint_filter+0x17bc>
    48f0:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    48f4:      	mov	w8, #0x1                // =1
    48f8:      	ldr	x0, [x0]
    48fc:      	ldr	x1, [sp, #0x18]
    4900:      	blr	x8
    4904:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    4908:      	ldr	w9, [x0]
    490c:      	mov	x1, x0
    4910:      	mov	w8, #0x1                // =1
    4914:      	cmp	x29, x9
    4918:      	b.eq	0x4894 <generic_tracepoint_filter+0x17b4>
    491c:      	ldr	w9, [x1, #0x10]!
    4920:      	ldr	w12, [sp, #0x30]
    4924:      	mov	x11, x20
    4928:      	cmp	x29, x9
    492c:      	b.eq	0x489c <generic_tracepoint_filter+0x17bc>
    4930:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4934:      	mov	w8, #0x1                // =1
    4938:      	ldr	x0, [x0]
    493c:      	blr	x8
    4940:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    4944:      	ldr	w9, [x0]
    4948:      	mov	x1, x0
    494c:      	mov	w8, #0x1                // =1
    4950:      	cmp	x29, x9
    4954:      	b.eq	0x4894 <generic_tracepoint_filter+0x17b4>
    4958:      	ldr	w9, [x1, #0x10]!
    495c:      	ldr	w12, [sp, #0x30]
    4960:      	mov	x11, x20
    4964:      	cmp	x29, x9
    4968:      	b.eq	0x489c <generic_tracepoint_filter+0x17bc>
    496c:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4970:      	mov	w8, #0x1                // =1
    4974:      	ldr	x0, [x0]
    4978:      	blr	x8
    497c:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    4980:      	ldr	w9, [x0]
    4984:      	mov	x1, x0
    4988:      	mov	w8, #0x1                // =1
    498c:      	cmp	x29, x9
    4990:      	b.eq	0x4894 <generic_tracepoint_filter+0x17b4>
    4994:      	ldr	w9, [x1, #0x10]!
    4998:      	ldr	w12, [sp, #0x30]
    499c:      	mov	x11, x20
    49a0:      	cmp	x29, x9
    49a4:      	b.eq	0x489c <generic_tracepoint_filter+0x17bc>
    49a8:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    49ac:      	mov	w8, #0x1                // =1
    49b0:      	ldr	x0, [x0]
    49b4:      	blr	x8
    49b8:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    49bc:      	ldr	w9, [x0]
    49c0:      	mov	x1, x0
    49c4:      	mov	w8, #0x1                // =1
    49c8:      	cmp	x29, x9
    49cc:      	b.eq	0x4894 <generic_tracepoint_filter+0x17b4>
    49d0:      	ldr	w9, [x1, #0x10]!
    49d4:      	ldr	w12, [sp, #0x30]
    49d8:      	mov	x11, x20
    49dc:      	cmp	x29, x9
    49e0:      	b.eq	0x489c <generic_tracepoint_filter+0x17bc>
    49e4:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    49e8:      	mov	w8, #0x1                // =1
    49ec:      	ldr	x0, [x0]
    49f0:      	blr	x8
    49f4:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    49f8:      	ldr	w9, [x0]
    49fc:      	mov	x1, x0
    4a00:      	mov	w8, #0x1                // =1
    4a04:      	cmp	x29, x9
    4a08:      	b.eq	0x4894 <generic_tracepoint_filter+0x17b4>
    4a0c:      	ldr	w9, [x1, #0x10]!
    4a10:      	ldr	w12, [sp, #0x30]
    4a14:      	mov	x11, x20
    4a18:      	cmp	x29, x9
    4a1c:      	b.eq	0x489c <generic_tracepoint_filter+0x17bc>
    4a20:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4a24:      	mov	w8, #0x1                // =1
    4a28:      	ldr	x0, [x0]
    4a2c:      	blr	x8
    4a30:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    4a34:      	ldr	w9, [x0]
    4a38:      	mov	x1, x0
    4a3c:      	mov	w8, #0x1                // =1
    4a40:      	cmp	x29, x9
    4a44:      	b.eq	0x4894 <generic_tracepoint_filter+0x17b4>
    4a48:      	ldr	w9, [x1, #0x10]!
    4a4c:      	ldr	w12, [sp, #0x30]
    4a50:      	mov	x11, x20
    4a54:      	cmp	x29, x9
    4a58:      	b.eq	0x489c <generic_tracepoint_filter+0x17bc>
    4a5c:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4a60:      	mov	w8, #0x1                // =1
    4a64:      	ldr	x0, [x0]
    4a68:      	blr	x8
    4a6c:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    4a70:      	ldr	w9, [x0]
    4a74:      	mov	x1, x0
    4a78:      	mov	w8, #0x1                // =1
    4a7c:      	cmp	x29, x9
    4a80:      	b.eq	0x4894 <generic_tracepoint_filter+0x17b4>
    4a84:      	ldr	w9, [x1, #0x10]!
    4a88:      	ldr	w12, [sp, #0x30]
    4a8c:      	mov	x11, x20
    4a90:      	cmp	x29, x9
    4a94:      	b.eq	0x489c <generic_tracepoint_filter+0x17bc>
    4a98:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4a9c:      	mov	w8, #0x1                // =1
    4aa0:      	ldr	x0, [x0]
    4aa4:      	blr	x8
    4aa8:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    4aac:      	ldr	w9, [x0]
    4ab0:      	mov	x1, x0
    4ab4:      	mov	w8, #0x1                // =1
    4ab8:      	cmp	x29, x9
    4abc:      	b.eq	0x4894 <generic_tracepoint_filter+0x17b4>
    4ac0:      	ldr	w9, [x1, #0x10]!
    4ac4:      	ldr	w12, [sp, #0x30]
    4ac8:      	mov	x11, x20
    4acc:      	cmp	x29, x9
    4ad0:      	b.eq	0x489c <generic_tracepoint_filter+0x17bc>
    4ad4:      	adrp	x9, 0x4000 <generic_tracepoint_filter+0xf20>
    4ad8:      	mov	w8, #0x1                // =1
    4adc:      	ldr	x9, [x9]
    4ae0:      	b	0x4c64 <generic_tracepoint_filter+0x1b84>
    4ae4:      	ldr	w29, [x19]
    4ae8:      	tbnz	w22, #0x1, 0x48cc <generic_tracepoint_filter+0x17ec>
    4aec:      	ldr	w8, [x11]
    4af0:      	cmp	w12, #0x5
    4af4:      	b.ne	0x4b08 <generic_tracepoint_filter+0x1a28>
    4af8:      	cmp	x29, x8
    4afc:      	b.eq	0x4b08 <generic_tracepoint_filter+0x1a28>
    4b00:      	mov	w9, wzr
    4b04:      	b	0x48a8 <generic_tracepoint_filter+0x17c8>
    4b08:      	cmp	w12, #0x6
    4b0c:      	ccmp	x29, x8, #0x0, eq
    4b10:      	cset	w9, ne
    4b14:      	b	0x48a8 <generic_tracepoint_filter+0x17c8>
    4b18:      	ldr	x8, [sp, #0x20]
    4b1c:      	ldr	w9, [x8]
    4b20:      	cbz	w9, 0x48a8 <generic_tracepoint_filter+0x17c8>
    4b24:      	mov	w8, #0x1                // =1
    4b28:      	cbz	x29, 0x489c <generic_tracepoint_filter+0x17bc>
    4b2c:      	cmp	x29, x9
    4b30:      	b.eq	0x489c <generic_tracepoint_filter+0x17bc>
    4b34:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4b38:      	mov	w8, #0x1                // =1
    4b3c:      	ldr	x0, [x0]
    4b40:      	ldr	x1, [sp, #0x18]
    4b44:      	blr	x8
    4b48:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    4b4c:      	ldr	w8, [x0, #0x24]
    4b50:      	cmp	x29, x8
    4b54:      	b.eq	0x4890 <generic_tracepoint_filter+0x17b0>
    4b58:      	add	x1, x0, #0x10
    4b5c:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4b60:      	mov	w8, #0x1                // =1
    4b64:      	ldr	x0, [x0]
    4b68:      	blr	x8
    4b6c:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    4b70:      	ldr	w8, [x0, #0x24]
    4b74:      	cmp	x29, x8
    4b78:      	b.eq	0x4890 <generic_tracepoint_filter+0x17b0>
    4b7c:      	add	x1, x0, #0x10
    4b80:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4b84:      	mov	w8, #0x1                // =1
    4b88:      	ldr	x0, [x0]
    4b8c:      	blr	x8
    4b90:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    4b94:      	ldr	w8, [x0, #0x24]
    4b98:      	cmp	x29, x8
    4b9c:      	b.eq	0x4890 <generic_tracepoint_filter+0x17b0>
    4ba0:      	add	x1, x0, #0x10
    4ba4:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4ba8:      	mov	w8, #0x1                // =1
    4bac:      	ldr	x0, [x0]
    4bb0:      	blr	x8
    4bb4:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    4bb8:      	ldr	w8, [x0, #0x24]
    4bbc:      	cmp	x29, x8
    4bc0:      	b.eq	0x4890 <generic_tracepoint_filter+0x17b0>
    4bc4:      	add	x1, x0, #0x10
    4bc8:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4bcc:      	mov	w8, #0x1                // =1
    4bd0:      	ldr	x0, [x0]
    4bd4:      	blr	x8
    4bd8:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    4bdc:      	ldr	w8, [x0, #0x24]
    4be0:      	cmp	x29, x8
    4be4:      	b.eq	0x4890 <generic_tracepoint_filter+0x17b0>
    4be8:      	add	x1, x0, #0x10
    4bec:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4bf0:      	mov	w8, #0x1                // =1
    4bf4:      	ldr	x0, [x0]
    4bf8:      	blr	x8
    4bfc:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    4c00:      	ldr	w8, [x0, #0x24]
    4c04:      	cmp	x29, x8
    4c08:      	b.eq	0x4890 <generic_tracepoint_filter+0x17b0>
    4c0c:      	add	x1, x0, #0x10
    4c10:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4c14:      	mov	w8, #0x1                // =1
    4c18:      	ldr	x0, [x0]
    4c1c:      	blr	x8
    4c20:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    4c24:      	ldr	w8, [x0, #0x24]
    4c28:      	cmp	x29, x8
    4c2c:      	b.eq	0x4890 <generic_tracepoint_filter+0x17b0>
    4c30:      	add	x1, x0, #0x10
    4c34:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4c38:      	mov	w8, #0x1                // =1
    4c3c:      	ldr	x0, [x0]
    4c40:      	blr	x8
    4c44:      	cbz	x0, 0x4c70 <generic_tracepoint_filter+0x1b90>
    4c48:      	ldr	w8, [x0, #0x24]
    4c4c:      	cmp	x29, x8
    4c50:      	b.eq	0x4890 <generic_tracepoint_filter+0x17b0>
    4c54:      	adrp	x9, 0x4000 <generic_tracepoint_filter+0xf20>
    4c58:      	add	x1, x0, #0x10
    4c5c:      	mov	w8, #0x1                // =1
    4c60:      	ldr	x9, [x9]
    4c64:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4c68:      	ldr	x0, [x0]
    4c6c:      	blr	x8
    4c70:      	ldr	w12, [sp, #0x30]
    4c74:      	mov	w8, wzr
    4c78:      	mov	w9, wzr
    4c7c:      	mov	x11, x20
    4c80:      	cmp	w12, #0x5
    4c84:      	b.ne	0x489c <generic_tracepoint_filter+0x17bc>
    4c88:      	b	0x48a8 <generic_tracepoint_filter+0x17c8>
    4c8c:      	ldp	w8, w9, [sp, #0x58]
    4c90:      	ldp	w10, w11, [sp, #0x60]
    4c94:      	cmp	w12, #0x6
    4c98:      	b.ne	0x4cac <generic_tracepoint_filter+0x1bcc>
    4c9c:      	and	w8, w9, w8
    4ca0:      	and	w9, w10, w11
    4ca4:      	and	w9, w8, w9
    4ca8:      	b	0x4cb8 <generic_tracepoint_filter+0x1bd8>
    4cac:      	orr	w8, w9, w8
    4cb0:      	orr	w9, w10, w11
    4cb4:      	orr	w9, w8, w9
    4cb8:      	ldr	x8, [sp, #0x10]
    4cbc:      	cbz	w9, 0x53b4 <generic_tracepoint_filter+0x22d4>
    4cc0:      	ldr	x10, [sp, #0x8]
    4cc4:      	add	w8, w8, #0x14
    4cc8:      	ldr	w10, [x10, #0x8]
    4ccc:      	ubfiz	w10, w10, #2, #3
    4cd0:      	add	w8, w10, w8
    4cd4:      	and	x10, x8, #0x3ff
    4cd8:      	add	w8, w8, #0x4
    4cdc:      	mov	w19, #0xa               // =10
    4ce0:      	ldr	w10, [x10, x23]
    4ce4:      	mov	w20, #0x4               // =4
    4ce8:      	mov	x25, #0x100000001       // =4294967297
    4cec:      	sub	w22, w10, #0x4
    4cf0:      	ldr	x10, [sp, #0xe8]
    4cf4:      	add	x10, x10, #0x20
    4cf8:      	str	x10, [sp, #0x30]
    4cfc:      	b	0x4d08 <generic_tracepoint_filter+0x1c28>
    4d00:      	subs	x19, x19, #0x1
    4d04:      	b.eq	0x4ed4 <generic_tracepoint_filter+0x1df4>
    4d08:      	cbz	w22, 0x4d00 <generic_tracepoint_filter+0x1c20>
    4d0c:      	and	x9, x8, #0x3ff
    4d10:      	add	x10, x9, x23
    4d14:      	ldr	w29, [x10, #0x8]
    4d18:      	ldp	w9, w24, [x10]
    4d1c:      	stp	xzr, xzr, [sp, #0x58]
    4d20:      	cmp	w29, #0x4
    4d24:      	csel	w10, w29, w20, lo
    4d28:      	cmp	w24, #0x6
    4d2c:      	b.ne	0x4d34 <generic_tracepoint_filter+0x1c54>
    4d30:      	stp	x25, x25, [sp, #0x58]
    4d34:      	add	w21, w8, #0xc
    4d38:      	cbz	w29, 0x4e8c <generic_tracepoint_filter+0x1dac>
    4d3c:      	and	x9, x9, #0xf
    4d40:      	cmp	w9, #0xa
    4d44:      	b.lo	0x4d70 <generic_tracepoint_filter+0x1c90>
    4d48:      	sub	x8, x10, #0x1
    4d4c:      	mov	w9, #0x3                // =3
    4d50:      	add	x0, sp, #0x58
    4d54:      	mov	w1, wzr
    4d58:      	cmp	x8, #0x3
    4d5c:      	csel	x8, x8, x9, lo
    4d60:      	lsl	x8, x8, #2
    4d64:      	add	x2, x8, #0x4
    4d68:      	bl	0x4d68 <generic_tracepoint_filter+0x1c88>
    4d6c:      	b	0x4e8c <generic_tracepoint_filter+0x1dac>
    4d70:      	cmp	w21, #0x3e8
    4d74:      	b.ls	0x4d80 <generic_tracepoint_filter+0x1ca0>
    4d78:      	mov	w11, wzr
    4d7c:      	b	0x4d88 <generic_tracepoint_filter+0x1ca8>
    4d80:      	and	w11, w21, #0xfffffffc
    4d84:      	ldr	w11, [x23, w11, uxtw]
    4d88:      	ldr	x12, [sp, #0x30]
    4d8c:      	cmp	w24, #0x5
    4d90:      	sub	x10, x10, #0x1
    4d94:      	ldr	w9, [x12, x9, lsl #2]
    4d98:      	cset	w12, ne
    4d9c:      	cmp	w24, #0x6
    4da0:      	cset	w13, ne
    4da4:      	cmp	w11, w9
    4da8:      	csinc	w11, w12, wzr, ne
    4dac:      	csinc	w12, w13, wzr, eq
    4db0:      	and	w11, w11, w12
    4db4:      	str	w11, [sp, #0x58]
    4db8:      	cbz	x10, 0x4e8c <generic_tracepoint_filter+0x1dac>
    4dbc:      	add	w11, w8, #0x10
    4dc0:      	cmp	w11, #0x3e8
    4dc4:      	b.ls	0x4dd0 <generic_tracepoint_filter+0x1cf0>
    4dc8:      	mov	w11, wzr
    4dcc:      	b	0x4dd8 <generic_tracepoint_filter+0x1cf8>
    4dd0:      	and	w11, w11, #0xfffffffc
    4dd4:      	ldr	w11, [x23, w11, uxtw]
    4dd8:      	cmp	w24, #0x5
    4ddc:      	cset	w12, ne
    4de0:      	cmp	w24, #0x6
    4de4:      	cset	w13, ne
    4de8:      	cmp	w11, w9
    4dec:      	csinc	w11, w12, wzr, ne
    4df0:      	csinc	w12, w13, wzr, eq
    4df4:      	cmp	x10, #0x1
    4df8:      	and	w11, w11, w12
    4dfc:      	str	w11, [sp, #0x5c]
    4e00:      	b.eq	0x4e8c <generic_tracepoint_filter+0x1dac>
    4e04:      	add	w11, w8, #0x14
    4e08:      	cmp	w11, #0x3e8
    4e0c:      	b.ls	0x4e18 <generic_tracepoint_filter+0x1d38>
    4e10:      	mov	w11, wzr
    4e14:      	b	0x4e20 <generic_tracepoint_filter+0x1d40>
    4e18:      	and	w11, w11, #0xfffffffc
    4e1c:      	ldr	w11, [x23, w11, uxtw]
    4e20:      	cmp	w24, #0x5
    4e24:      	cset	w12, ne
    4e28:      	cmp	w24, #0x6
    4e2c:      	cset	w13, ne
    4e30:      	cmp	w11, w9
    4e34:      	csinc	w11, w12, wzr, ne
    4e38:      	csinc	w12, w13, wzr, eq
    4e3c:      	cmp	x10, #0x2
    4e40:      	and	w11, w11, w12
    4e44:      	str	w11, [sp, #0x60]
    4e48:      	b.eq	0x4e8c <generic_tracepoint_filter+0x1dac>
    4e4c:      	add	w8, w8, #0x18
    4e50:      	cmp	w8, #0x3e8
    4e54:      	b.ls	0x4e60 <generic_tracepoint_filter+0x1d80>
    4e58:      	mov	w8, wzr
    4e5c:      	b	0x4e68 <generic_tracepoint_filter+0x1d88>
    4e60:      	and	w8, w8, #0xfffffffc
    4e64:      	ldr	w8, [x23, w8, uxtw]
    4e68:      	cmp	w24, #0x5
    4e6c:      	cset	w10, ne
    4e70:      	cmp	w24, #0x6
    4e74:      	cset	w11, ne
    4e78:      	cmp	w8, w9
    4e7c:      	csinc	w8, w10, wzr, ne
    4e80:      	csinc	w9, w11, wzr, eq
    4e84:      	and	w8, w8, w9
    4e88:      	str	w8, [sp, #0x64]
    4e8c:      	ldp	w8, w9, [sp, #0x58]
    4e90:      	ldp	w10, w11, [sp, #0x60]
    4e94:      	cmp	w24, #0x6
    4e98:      	b.ne	0x4eac <generic_tracepoint_filter+0x1dcc>
    4e9c:      	and	w8, w9, w8
    4ea0:      	and	w9, w10, w11
    4ea4:      	and	w9, w8, w9
    4ea8:      	b	0x4eb8 <generic_tracepoint_filter+0x1dd8>
    4eac:      	orr	w8, w9, w8
    4eb0:      	orr	w9, w10, w11
    4eb4:      	orr	w9, w8, w9
    4eb8:      	cbz	w9, 0x53b4 <generic_tracepoint_filter+0x22d4>
    4ebc:      	lsl	w8, w29, #2
    4ec0:      	sub	w10, w22, w29, lsl #2
    4ec4:      	and	w8, w8, #0x1c
    4ec8:      	sub	w22, w10, #0xc
    4ecc:      	add	w8, w8, w21
    4ed0:      	b	0x4d00 <generic_tracepoint_filter+0x1c20>
    4ed4:      	mov	w10, w8
    4ed8:      	add	w19, w8, #0x4
    4edc:      	and	x10, x10, #0x3ff
    4ee0:      	ldr	w10, [x10, x23]
    4ee4:      	cmp	w10, #0x4
    4ee8:      	b.ne	0x4f80 <generic_tracepoint_filter+0x1ea0>
    4eec:      	cbz	w9, 0x53b4 <generic_tracepoint_filter+0x22d4>
    4ef0:      	mov	w8, w19
    4ef4:      	and	x8, x8, #0x3ff
    4ef8:      	ldr	w9, [x8, x23]
    4efc:      	add	w8, w19, #0x4
    4f00:      	cmp	w9, #0x4
    4f04:      	mov	w9, w8
    4f08:      	b.eq	0x52b0 <generic_tracepoint_filter+0x21d0>
    4f0c:      	and	x8, x8, #0x3ff
    4f10:      	add	x8, x8, x23
    4f14:      	ldp	w20, w22, [x8]
    4f18:      	mov	w8, #0xe                // =14
    4f1c:      	blr	x8
    4f20:      	lsr	x8, x0, #32
    4f24:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0xf20>
    4f28:      	add	x9, sp, #0x58
    4f2c:      	str	w8, [sp, #0x58]
    4f30:      	mov	w8, #0x1                // =1
    4f34:      	add	x1, sp, #0x58
    4f38:      	ldr	x0, [x0]
    4f3c:      	blr	x8
    4f40:      	cbz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    4f44:      	cmp	w20, #0x5
    4f48:      	b.eq	0x4ffc <generic_tracepoint_filter+0x1f1c>
    4f4c:      	cmp	w20, #0x6
    4f50:      	b.ne	0x53b4 <generic_tracepoint_filter+0x22d4>
    4f54:      	ldr	x11, [sp, #0xe8]
    4f58:      	mov	w8, #0x5ee8             // =24296
    4f5c:      	add	x8, x11, x8
    4f60:      	tbnz	w22, #0x0, 0x5030 <generic_tracepoint_filter+0x1f50>
    4f64:      	ldr	w9, [x0, #0x28]
    4f68:      	cbz	w9, 0x5028 <generic_tracepoint_filter+0x1f48>
    4f6c:      	ldr	x10, [sp, #0x30]
    4f70:      	ldr	w10, [x10]
    4f74:      	cmp	w9, w10
    4f78:      	b.eq	0x5030 <generic_tracepoint_filter+0x1f50>
    4f7c:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    4f80:      	and	x9, x19, #0x3ff
    4f84:      	add	w19, w8, #0x18
    4f88:      	add	x9, x9, x23
    4f8c:      	ldp	w8, w10, [x9]
    4f90:      	ldr	w12, [x9, #0x8]
    4f94:      	ldur	x11, [x9, #0xc]
    4f98:      	cbz	w12, 0x4fbc <generic_tracepoint_filter+0x1edc>
    4f9c:      	ldr	x14, [sp, #0xe8]
    4fa0:      	mov	w9, wzr
    4fa4:      	cmp	w8, #0x2
    4fa8:      	b.hi	0x4eec <generic_tracepoint_filter+0x1e0c>
    4fac:      	ldr	w13, [x14, #0x44]
    4fb0:      	cmp	w13, w12
    4fb4:      	b.ne	0x4fd0 <generic_tracepoint_filter+0x1ef0>
    4fb8:      	b	0x4eec <generic_tracepoint_filter+0x1e0c>
    4fbc:      	ldr	x14, [sp, #0xe8]
    4fc0:      	cmp	w8, #0x2
    4fc4:      	b.ls	0x4fd0 <generic_tracepoint_filter+0x1ef0>
    4fc8:      	mov	w9, wzr
    4fcc:      	b	0x4eec <generic_tracepoint_filter+0x1e0c>
    4fd0:      	add	x9, x14, #0x48
    4fd4:      	cmp	w10, #0x5
    4fd8:      	ldr	x8, [x9, x8, lsl #3]
    4fdc:      	and	x8, x8, x11
    4fe0:      	b.ne	0x4ff0 <generic_tracepoint_filter+0x1f10>
    4fe4:      	cmp	x8, #0x0
    4fe8:      	cset	w9, ne
    4fec:      	b	0x4eec <generic_tracepoint_filter+0x1e0c>
    4ff0:      	cmp	x8, #0x0
    4ff4:      	cset	w9, eq
    4ff8:      	b	0x4eec <generic_tracepoint_filter+0x1e0c>
    4ffc:      	ldr	x11, [sp, #0xe8]
    5000:      	mov	w8, #0x5ee8             // =24296
    5004:      	add	x8, x11, x8
    5008:      	tbz	w22, #0x0, 0x5054 <generic_tracepoint_filter+0x1f74>
    500c:      	ldr	w9, [x0, #0x28]
    5010:      	cbz	w9, 0x504c <generic_tracepoint_filter+0x1f6c>
    5014:      	ldr	x10, [sp, #0x30]
    5018:      	ldr	w10, [x10]
    501c:      	cmp	w9, w10
    5020:      	b.eq	0x5054 <generic_tracepoint_filter+0x1f74>
    5024:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    5028:      	mov	w9, #0x1                // =1
    502c:      	str	x9, [x8]
    5030:      	tbnz	w22, #0x1, 0x5078 <generic_tracepoint_filter+0x1f98>
    5034:      	ldr	w9, [x0, #0x2c]
    5038:      	cbz	w9, 0x5070 <generic_tracepoint_filter+0x1f90>
    503c:      	ldr	w10, [x11, #0x24]
    5040:      	cmp	w9, w10
    5044:      	b.eq	0x5078 <generic_tracepoint_filter+0x1f98>
    5048:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    504c:      	mov	w9, #0x1                // =1
    5050:      	str	x9, [x8]
    5054:      	tbz	w22, #0x1, 0x509c <generic_tracepoint_filter+0x1fbc>
    5058:      	ldr	w9, [x0, #0x2c]
    505c:      	cbz	w9, 0x5094 <generic_tracepoint_filter+0x1fb4>
    5060:      	ldr	w10, [x11, #0x24]
    5064:      	cmp	w9, w10
    5068:      	b.eq	0x509c <generic_tracepoint_filter+0x1fbc>
    506c:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    5070:      	mov	w9, #0x1                // =1
    5074:      	str	x9, [x8]
    5078:      	tbnz	w22, #0x2, 0x50c0 <generic_tracepoint_filter+0x1fe0>
    507c:      	ldr	w9, [x0, #0x30]
    5080:      	cbz	w9, 0x50b8 <generic_tracepoint_filter+0x1fd8>
    5084:      	ldr	w10, [x11, #0x28]
    5088:      	cmp	w9, w10
    508c:      	b.eq	0x50c0 <generic_tracepoint_filter+0x1fe0>
    5090:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    5094:      	mov	w9, #0x1                // =1
    5098:      	str	x9, [x8]
    509c:      	tbz	w22, #0x2, 0x50e4 <generic_tracepoint_filter+0x2004>
    50a0:      	ldr	w9, [x0, #0x30]
    50a4:      	cbz	w9, 0x50dc <generic_tracepoint_filter+0x1ffc>
    50a8:      	ldr	w10, [x11, #0x28]
    50ac:      	cmp	w9, w10
    50b0:      	b.eq	0x50e4 <generic_tracepoint_filter+0x2004>
    50b4:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    50b8:      	mov	w9, #0x1                // =1
    50bc:      	str	x9, [x8]
    50c0:      	tbnz	w22, #0x3, 0x5108 <generic_tracepoint_filter+0x2028>
    50c4:      	ldr	w9, [x0, #0x34]
    50c8:      	cbz	w9, 0x5100 <generic_tracepoint_filter+0x2020>
    50cc:      	ldr	w10, [x11, #0x2c]
    50d0:      	cmp	w9, w10
    50d4:      	b.eq	0x5108 <generic_tracepoint_filter+0x2028>
    50d8:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    50dc:      	mov	w9, #0x1                // =1
    50e0:      	str	x9, [x8]
    50e4:      	tbz	w22, #0x3, 0x512c <generic_tracepoint_filter+0x204c>
    50e8:      	ldr	w9, [x0, #0x34]
    50ec:      	cbz	w9, 0x5124 <generic_tracepoint_filter+0x2044>
    50f0:      	ldr	w10, [x11, #0x2c]
    50f4:      	cmp	w9, w10
    50f8:      	b.eq	0x512c <generic_tracepoint_filter+0x204c>
    50fc:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    5100:      	mov	w9, #0x1                // =1
    5104:      	str	x9, [x8]
    5108:      	tbnz	w22, #0x4, 0x5150 <generic_tracepoint_filter+0x2070>
    510c:      	ldr	w9, [x0, #0x38]
    5110:      	cbz	w9, 0x5148 <generic_tracepoint_filter+0x2068>
    5114:      	ldr	w10, [x11, #0x30]
    5118:      	cmp	w9, w10
    511c:      	b.eq	0x5150 <generic_tracepoint_filter+0x2070>
    5120:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    5124:      	mov	w9, #0x1                // =1
    5128:      	str	x9, [x8]
    512c:      	tbz	w22, #0x4, 0x5174 <generic_tracepoint_filter+0x2094>
    5130:      	ldr	w9, [x0, #0x38]
    5134:      	cbz	w9, 0x516c <generic_tracepoint_filter+0x208c>
    5138:      	ldr	w10, [x11, #0x30]
    513c:      	cmp	w9, w10
    5140:      	b.eq	0x5174 <generic_tracepoint_filter+0x2094>
    5144:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    5148:      	mov	w9, #0x1                // =1
    514c:      	str	x9, [x8]
    5150:      	tbnz	w22, #0x5, 0x5198 <generic_tracepoint_filter+0x20b8>
    5154:      	ldr	w9, [x0, #0x3c]
    5158:      	cbz	w9, 0x5190 <generic_tracepoint_filter+0x20b0>
    515c:      	ldr	w10, [x11, #0x34]
    5160:      	cmp	w9, w10
    5164:      	b.eq	0x5198 <generic_tracepoint_filter+0x20b8>
    5168:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    516c:      	mov	w9, #0x1                // =1
    5170:      	str	x9, [x8]
    5174:      	tbz	w22, #0x5, 0x51bc <generic_tracepoint_filter+0x20dc>
    5178:      	ldr	w9, [x0, #0x3c]
    517c:      	cbz	w9, 0x51b4 <generic_tracepoint_filter+0x20d4>
    5180:      	ldr	w10, [x11, #0x34]
    5184:      	cmp	w9, w10
    5188:      	b.eq	0x51bc <generic_tracepoint_filter+0x20dc>
    518c:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    5190:      	mov	w9, #0x1                // =1
    5194:      	str	x9, [x8]
    5198:      	tbnz	w22, #0x6, 0x51e0 <generic_tracepoint_filter+0x2100>
    519c:      	ldr	w9, [x0, #0x40]
    51a0:      	cbz	w9, 0x51d8 <generic_tracepoint_filter+0x20f8>
    51a4:      	ldr	w10, [x11, #0x38]
    51a8:      	cmp	w9, w10
    51ac:      	b.eq	0x51e0 <generic_tracepoint_filter+0x2100>
    51b0:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    51b4:      	mov	w9, #0x1                // =1
    51b8:      	str	x9, [x8]
    51bc:      	tbz	w22, #0x6, 0x5204 <generic_tracepoint_filter+0x2124>
    51c0:      	ldr	w9, [x0, #0x40]
    51c4:      	cbz	w9, 0x51fc <generic_tracepoint_filter+0x211c>
    51c8:      	ldr	w10, [x11, #0x38]
    51cc:      	cmp	w9, w10
    51d0:      	b.eq	0x5204 <generic_tracepoint_filter+0x2124>
    51d4:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    51d8:      	mov	w9, #0x1                // =1
    51dc:      	str	x9, [x8]
    51e0:      	tbnz	w22, #0x7, 0x5228 <generic_tracepoint_filter+0x2148>
    51e4:      	ldr	w9, [x0, #0x44]
    51e8:      	cbz	w9, 0x5220 <generic_tracepoint_filter+0x2140>
    51ec:      	ldr	w10, [x11, #0x3c]
    51f0:      	cmp	w9, w10
    51f4:      	b.eq	0x5228 <generic_tracepoint_filter+0x2148>
    51f8:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    51fc:      	mov	w9, #0x1                // =1
    5200:      	str	x9, [x8]
    5204:      	tbz	w22, #0x7, 0x5250 <generic_tracepoint_filter+0x2170>
    5208:      	ldr	w9, [x0, #0x44]
    520c:      	cbz	w9, 0x5248 <generic_tracepoint_filter+0x2168>
    5210:      	ldr	w10, [x11, #0x3c]
    5214:      	cmp	w9, w10
    5218:      	b.eq	0x5250 <generic_tracepoint_filter+0x2170>
    521c:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    5220:      	mov	w9, #0x1                // =1
    5224:      	str	x9, [x8]
    5228:      	tbnz	w22, #0x8, 0x5278 <generic_tracepoint_filter+0x2198>
    522c:      	ldr	w9, [x0, #0x48]
    5230:      	cbz	w9, 0x5270 <generic_tracepoint_filter+0x2190>
    5234:      	ldr	x10, [sp, #0xe8]
    5238:      	ldr	w10, [x10, #0x40]
    523c:      	cmp	w9, w10
    5240:      	b.eq	0x5278 <generic_tracepoint_filter+0x2198>
    5244:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    5248:      	mov	w9, #0x1                // =1
    524c:      	str	x9, [x8]
    5250:      	tbz	w22, #0x8, 0x5288 <generic_tracepoint_filter+0x21a8>
    5254:      	ldr	w9, [x0, #0x48]
    5258:      	cbz	w9, 0x5280 <generic_tracepoint_filter+0x21a0>
    525c:      	ldr	x10, [sp, #0xe8]
    5260:      	ldr	w10, [x10, #0x40]
    5264:      	cmp	w9, w10
    5268:      	b.eq	0x5288 <generic_tracepoint_filter+0x21a8>
    526c:      	b	0x52a4 <generic_tracepoint_filter+0x21c4>
    5270:      	mov	w9, #0x1                // =1
    5274:      	str	x9, [x8]
    5278:      	tbz	w22, #0x9, 0x528c <generic_tracepoint_filter+0x21ac>
    527c:      	b	0x53b4 <generic_tracepoint_filter+0x22d4>
    5280:      	mov	w9, #0x1                // =1
    5284:      	str	x9, [x8]
    5288:      	tbz	w22, #0x9, 0x53b4 <generic_tracepoint_filter+0x22d4>
    528c:      	ldr	w9, [x0, #0x4c]
    5290:      	cbz	w9, 0x53ac <generic_tracepoint_filter+0x22cc>
    5294:      	ldr	x10, [sp, #0xe8]
    5298:      	ldr	w10, [x10, #0x44]
    529c:      	cmp	w9, w10
    52a0:      	b.eq	0x53b4 <generic_tracepoint_filter+0x22d4>
    52a4:      	add	w9, w19, #0xc
    52a8:      	mov	w10, #0x1               // =1
    52ac:      	str	x10, [x8]
    52b0:      	and	x8, x9, #0x3ff
    52b4:      	adrp	x24, 0x5000 <generic_tracepoint_filter+0x1f20>
    52b8:      	ldr	w8, [x8, x23]
    52bc:      	ldr	x24, [x24]
    52c0:      	cmp	w8, #0x4
    52c4:      	b.ne	0x52f8 <generic_tracepoint_filter+0x2218>
    52c8:      	ldr	x9, [sp, #0xe8]
    52cc:      	mov	w8, #0x5eb8             // =24248
    52d0:      	add	x8, x9, x8
    52d4:      	ldr	x9, [x9, #0x5eb8]
    52d8:      	and	x9, x9, #0x1f
    52dc:      	add	x8, x8, x9
    52e0:      	mov	w9, #0x1                // =1
    52e4:      	strb	w9, [x8, #0x9]
    52e8:      	ldr	x8, [sp, #0x40]
    52ec:      	strb	w9, [x8, #0x20]
    52f0:      	strb	w9, [x8]
    52f4:      	b	0x53b4 <generic_tracepoint_filter+0x22d4>
    52f8:      	add	w8, w9, #0x4
    52fc:      	and	x8, x8, #0x3ff
    5300:      	add	x8, x8, x23
    5304:      	ldp	w21, w19, [x8]
    5308:      	ldr	w22, [x8, #0x8]
    530c:      	ldur	x20, [x8, #0xc]
    5310:      	mov	w8, #0xe                // =14
    5314:      	blr	x8
    5318:      	lsr	x8, x0, #32
    531c:      	add	x9, sp, #0x58
    5320:      	add	x1, sp, #0x58
    5324:      	str	w8, [sp, #0x58]
    5328:      	mov	w8, #0x1                // =1
    532c:      	mov	x0, x24
    5330:      	blr	x8
    5334:      	cbz	x0, 0x53b4 <generic_tracepoint_filter+0x22d4>
    5338:      	cmp	w21, #0x2
    533c:      	cbz	w22, 0x5358 <generic_tracepoint_filter+0x2278>
    5340:      	b.hi	0x53b4 <generic_tracepoint_filter+0x22d4>
    5344:      	ldr	x8, [sp, #0xe8]
    5348:      	ldr	w8, [x8, #0x44]
    534c:      	cmp	w8, w22
    5350:      	b.ne	0x535c <generic_tracepoint_filter+0x227c>
    5354:      	b	0x53b4 <generic_tracepoint_filter+0x22d4>
    5358:      	b.hi	0x53b4 <generic_tracepoint_filter+0x22d4>
    535c:      	ldr	x8, [sp, #0xe8]
    5360:      	lsl	x10, x21, #3
    5364:      	add	x9, x8, #0x48
    5368:      	add	x8, x0, x21, lsl #3
    536c:      	ldr	x8, [x8, #0x50]
    5370:      	ldr	x9, [x9, x10]
    5374:      	eor	x10, x9, x8
    5378:      	tst	x10, x20
    537c:      	b.eq	0x538c <generic_tracepoint_filter+0x22ac>
    5380:      	cmp	w19, #0x5
    5384:      	b.eq	0x539c <generic_tracepoint_filter+0x22bc>
    5388:      	b	0x53b4 <generic_tracepoint_filter+0x22d4>
    538c:      	cmp	x8, x9
    5390:      	b.eq	0x53b4 <generic_tracepoint_filter+0x22d4>
    5394:      	cmp	w19, #0x6
    5398:      	b.ne	0x53b4 <generic_tracepoint_filter+0x22d4>
    539c:      	ldr	x9, [sp, #0xe8]
    53a0:      	mov	w8, #0x1                // =1
    53a4:      	str	x8, [x9, #0x5ef0]
    53a8:      	b	0x52c8 <generic_tracepoint_filter+0x21e8>
    53ac:      	mov	w9, #0x1                // =1
    53b0:      	str	x9, [x8]
    53b4:      	ldr	x9, [sp, #0xe8]
    53b8:      	ldr	x10, [sp, #0x28]
    53bc:      	ldr	x8, [x9, #0x5eb8]
    53c0:      	add	x8, x8, #0x1
    53c4:      	cmp	x8, x10
    53c8:      	str	x8, [x9, #0x5eb8]
    53cc:      	b.ls	0x542c <generic_tracepoint_filter+0x234c>
    53d0:      	ldr	x10, [sp, #0x48]
    53d4:      	ldr	w8, [x10]
    53d8:      	str	w8, [x9, #0x10]
    53dc:      	ldr	x8, [x10, #0x8]
    53e0:      	str	x8, [x9, #0x18]
    53e4:      	ldp	x20, x8, [sp, #0x38]
    53e8:      	ldrb	w8, [x8]
    53ec:      	cbz	w8, 0x540c <generic_tracepoint_filter+0x232c>
    53f0:      	adrp	x1, 0x5000 <generic_tracepoint_filter+0x1f20>
    53f4:      	mov	w8, #0x1                // =1
    53f8:      	mov	w9, #0xc                // =12
    53fc:      	ldr	x1, [x1]
    5400:      	mov	x0, x20
    5404:      	mov	w2, #0x1                // =1
    5408:      	blr	x9
    540c:      	ldp	x20, x19, [sp, #0x120]
    5410:      	mov	w0, wzr
    5414:      	ldr	x29, [sp, #0xe0]
    5418:      	ldp	x22, x21, [sp, #0x110]
    541c:      	ldp	x24, x23, [sp, #0x100]
    5420:      	ldp	x30, x25, [sp, #0xf0]
    5424:      	add	sp, sp, #0x130
    5428:      	ret
    542c:      	adrp	x1, 0x5000 <generic_tracepoint_filter+0x1f20>
    5430:      	mov	w8, #0x2                // =2
    5434:      	mov	w9, #0xc                // =12
    5438:      	ldr	x1, [x1]
    543c:      	ldr	x0, [sp, #0x38]
    5440:      	mov	w2, #0x2                // =2
    5444:      	b	0x5408 <generic_tracepoint_filter+0x2328>
    5448:      	nop
    544c:      	nop

0000000000005450 <generic_tracepoint_arg>:
    5450:      	sub	sp, sp, #0xf0
    5454:      	str	x29, [sp, #0xa0]
    5458:      	stp	x30, x25, [sp, #0xb0]
    545c:      	stp	x24, x23, [sp, #0xc0]
    5460:      	stp	x22, x21, [sp, #0xd0]
    5464:      	stp	x20, x19, [sp, #0xe0]
    5468:      	mov	x19, x0
    546c:      	str	wzr, [sp, #0xa8]
    5470:      	adrp	x0, 0x5000 <generic_tracepoint_filter+0x1f20>
    5474:      	mov	w8, #0x1                // =1
    5478:      	ldr	x0, [x0]
    547c:      	add	x9, sp, #0xa8
    5480:      	add	x1, sp, #0xa8
    5484:      	blr	x8
    5488:      	cbz	x0, 0x55f8 <generic_tracepoint_arg+0x1a8>
    548c:      	mov	w8, #0x5ec1             // =24257
    5490:      	mov	x20, x0
    5494:      	add	x22, x0, x8
    5498:      	mov	w8, #0x5ef8             // =24312
    549c:      	add	x1, x0, x8
    54a0:      	adrp	x0, 0x5000 <generic_tracepoint_filter+0x1f20>
    54a4:      	ldur	w23, [x22, #0x3f]
    54a8:      	mov	w8, #0x1                // =1
    54ac:      	ldr	x0, [x0]
    54b0:      	blr	x8
    54b4:      	cbz	x0, 0x55dc <generic_tracepoint_arg+0x18c>
    54b8:      	ldrb	w8, [x22, #0x1f]
    54bc:      	cbz	w8, 0x55dc <generic_tracepoint_arg+0x18c>
    54c0:      	and	x8, x23, #0x7
    54c4:      	mov	w10, #0x5ec1            // =24257
    54c8:      	stp	x23, x22, [sp, #0x50]
    54cc:      	add	x9, x20, x8
    54d0:      	ldrb	w9, [x9, x10]
    54d4:      	cbz	w9, 0x554c <generic_tracepoint_arg+0xfc>
    54d8:      	lsl	w8, w8, #2
    54dc:      	mov	x21, x0
    54e0:      	add	x8, x8, #0x4
    54e4:      	ldr	w9, [x8, x0]
    54e8:      	add	x8, x8, x9
    54ec:      	add	x8, x8, #0x4
    54f0:      	and	x9, x8, #0x3ff
    54f4:      	ldr	w9, [x9, x0]
    54f8:      	add	x8, x8, x9
    54fc:      	and	x9, x8, #0x3ff
    5500:      	ldr	w9, [x9, x0]
    5504:      	add	x8, x8, x9
    5508:      	and	x9, x8, #0x3ff
    550c:      	ldr	w9, [x9, x0]
    5510:      	add	x8, x8, x9
    5514:      	and	x9, x8, #0x3ff
    5518:      	ldr	w9, [x9, x0]
    551c:      	add	x8, x8, x9
    5520:      	and	x9, x8, #0x3ff
    5524:      	ldr	w9, [x9, x0]
    5528:      	add	x16, x8, x9
    552c:      	and	x15, x16, #0x3ff
    5530:      	add	x17, x0, x15
    5534:      	ldr	w8, [x17]
    5538:      	cmp	w8, #0x19
    553c:      	b.hs	0x55a0 <generic_tracepoint_arg+0x150>
    5540:      	cmp	w15, #0x1
    5544:      	b.eq	0x55dc <generic_tracepoint_arg+0x18c>
    5548:      	cbnz	w15, 0x55b8 <generic_tracepoint_arg+0x168>
    554c:      	ldr	x8, [sp, #0x50]
    5550:      	cmp	w8, #0x1
    5554:      	b.gt	0x5574 <generic_tracepoint_arg+0x124>
    5558:      	ldr	x9, [sp, #0x58]
    555c:      	cmn	w8, #0x1
    5560:      	b.eq	0x5618 <generic_tracepoint_arg+0x1c8>
    5564:      	cbz	w8, 0x5628 <generic_tracepoint_arg+0x1d8>
    5568:      	cmp	w8, #0x1
    556c:      	b.eq	0x5638 <generic_tracepoint_arg+0x1e8>
    5570:      	b	0x5590 <generic_tracepoint_arg+0x140>
    5574:      	ldr	x9, [sp, #0x58]
    5578:      	cmp	w8, #0x2
    557c:      	b.eq	0x5648 <generic_tracepoint_arg+0x1f8>
    5580:      	cmp	w8, #0x3
    5584:      	b.eq	0x5658 <generic_tracepoint_arg+0x208>
    5588:      	cmp	w8, #0x4
    558c:      	b.eq	0x5668 <generic_tracepoint_arg+0x218>
    5590:      	cmp	w8, #0x4
    5594:      	b.gt	0x5694 <generic_tracepoint_arg+0x244>
    5598:      	add	w8, w8, #0x1
    559c:      	b	0x5674 <generic_tracepoint_arg+0x224>
    55a0:      	mov	x24, xzr
    55a4:      	mov	w2, #0x5ea0             // =24224
    55a8:      	mov	w12, #0x1               // =1
    55ac:      	stp	x19, x17, [sp, #0x30]
    55b0:      	stp	x16, x15, [sp, #0x40]
    55b4:      	b	0x56f4 <generic_tracepoint_arg+0x2a4>
    55b8:      	ldr	x8, [sp, #0x58]
    55bc:      	adrp	x1, 0x5000 <generic_tracepoint_filter+0x1f20>
    55c0:      	mov	w9, #0xc                // =12
    55c4:      	mov	x0, x19
    55c8:      	stur	w15, [x8, #0x43]
    55cc:      	mov	w8, #0x4                // =4
    55d0:      	mov	w2, #0x4                // =4
    55d4:      	ldr	x1, [x1]
    55d8:      	blr	x9
    55dc:      	adrp	x1, 0x5000 <generic_tracepoint_filter+0x1f20>
    55e0:      	mov	w8, #0x5                // =5
    55e4:      	mov	w9, #0xc                // =12
    55e8:      	ldr	x1, [x1]
    55ec:      	mov	x0, x19
    55f0:      	mov	w2, #0x5                // =5
    55f4:      	blr	x9
    55f8:      	ldp	x20, x19, [sp, #0xe0]
    55fc:      	mov	w0, wzr
    5600:      	ldr	x29, [sp, #0xa0]
    5604:      	ldp	x22, x21, [sp, #0xd0]
    5608:      	ldp	x24, x23, [sp, #0xc0]
    560c:      	ldp	x30, x25, [sp, #0xb0]
    5610:      	add	sp, sp, #0xf0
    5614:      	ret
    5618:      	ldrb	w8, [x9]
    561c:      	cbz	w8, 0x5628 <generic_tracepoint_arg+0x1d8>
    5620:      	mov	w8, wzr
    5624:      	b	0x5674 <generic_tracepoint_arg+0x224>
    5628:      	ldrb	w8, [x9, #0x1]
    562c:      	cbz	w8, 0x5638 <generic_tracepoint_arg+0x1e8>
    5630:      	mov	w8, #0x1                // =1
    5634:      	b	0x5674 <generic_tracepoint_arg+0x224>
    5638:      	ldrb	w8, [x9, #0x2]
    563c:      	cbz	w8, 0x5648 <generic_tracepoint_arg+0x1f8>
    5640:      	mov	w8, #0x2                // =2
    5644:      	b	0x5674 <generic_tracepoint_arg+0x224>
    5648:      	ldrb	w8, [x9, #0x3]
    564c:      	cbz	w8, 0x5658 <generic_tracepoint_arg+0x208>
    5650:      	mov	w8, #0x3                // =3
    5654:      	b	0x5674 <generic_tracepoint_arg+0x224>
    5658:      	ldrb	w8, [x9, #0x4]
    565c:      	cbz	w8, 0x5668 <generic_tracepoint_arg+0x218>
    5660:      	mov	w8, #0x4                // =4
    5664:      	b	0x5674 <generic_tracepoint_arg+0x224>
    5668:      	ldrb	w8, [x9, #0x5]
    566c:      	cbz	w8, 0x5694 <generic_tracepoint_arg+0x244>
    5670:      	mov	w8, #0x5                // =5
    5674:      	stur	w8, [x9, #0x3f]
    5678:      	adrp	x1, 0x5000 <generic_tracepoint_filter+0x1f20>
    567c:      	mov	w8, #0x3                // =3
    5680:      	mov	w9, #0xc                // =12
    5684:      	ldr	x1, [x1]
    5688:      	mov	x0, x19
    568c:      	mov	w2, #0x3                // =3
    5690:      	blr	x9
    5694:      	ldr	x19, [x20, #0x60]
    5698:      	mov	w8, #0xe                // =14
    569c:      	blr	x8
    56a0:      	stp	x19, x0, [sp, #0x60]
    56a4:      	adrp	x19, 0x5000 <generic_tracepoint_filter+0x1f20>
    56a8:      	mov	w8, #0x1                // =1
    56ac:      	add	x9, sp, #0x60
    56b0:      	add	x1, sp, #0x60
    56b4:      	ldr	x19, [x19]
    56b8:      	mov	x0, x19
    56bc:      	blr	x8
    56c0:      	cbz	x0, 0x55f8 <generic_tracepoint_arg+0x1a8>
    56c4:      	mov	w8, #0x3                // =3
    56c8:      	add	x9, sp, #0x60
    56cc:      	add	x1, sp, #0x60
    56d0:      	mov	x0, x19
    56d4:      	blr	x8
    56d8:      	b	0x55f8 <generic_tracepoint_arg+0x1a8>
    56dc:      	cmp	w8, #0x3
    56e0:      	cset	w22, eq
    56e4:      	cbz	x22, 0x554c <generic_tracepoint_arg+0xfc>
    56e8:      	add	x24, x24, #0x1
    56ec:      	cmp	x24, #0x5
    56f0:      	b.eq	0x5540 <generic_tracepoint_arg+0xf0>
    56f4:      	add	x8, x17, x24, lsl #2
    56f8:      	ldr	w8, [x8, #0x4]
    56fc:      	tst	w8, #0x3ff
    5700:      	b.eq	0x5540 <generic_tracepoint_arg+0xf0>
    5704:      	add	w8, w16, w8
    5708:      	and	x8, x8, #0x3ff
    570c:      	add	x23, x21, x8
    5710:      	ldr	w8, [x23, #0x4]
    5714:      	cmp	w8, #0x23
    5718:      	b.eq	0x554c <generic_tracepoint_arg+0xfc>
    571c:      	ldr	w9, [x23]
    5720:      	cmp	w9, #0x4
    5724:      	b.hi	0x554c <generic_tracepoint_arg+0xfc>
    5728:      	add	x10, x20, x9, lsl #2
    572c:      	ldr	w10, [x10, x2]
    5730:      	cbnz	w10, 0x554c <generic_tracepoint_arg+0xfc>
    5734:      	add	x9, x20, x9, lsl #3
    5738:      	ldr	x9, [x9, #0x5e78]
    573c:      	and	x9, x9, #0x7ff
    5740:      	add	x9, x20, x9
    5744:      	add	x25, x9, #0x90
    5748:      	ldr	w9, [x23, #0xc]
    574c:      	cmp	w9, #0x1b
    5750:      	b.le	0x5774 <generic_tracepoint_arg+0x324>
    5754:      	cmp	w9, #0x25
    5758:      	b.gt	0x57a4 <generic_tracepoint_arg+0x354>
    575c:      	sub	w10, w9, #0x1c
    5760:      	cmp	w10, #0x9
    5764:      	b.lo	0x57e8 <generic_tracepoint_arg+0x398>
    5768:      	cmp	w9, #0x25
    576c:      	b.eq	0x599c <generic_tracepoint_arg+0x54c>
    5770:      	b	0x56e8 <generic_tracepoint_arg+0x298>
    5774:      	cmp	w9, #0x9
    5778:      	b.le	0x57c8 <generic_tracepoint_arg+0x378>
    577c:      	sub	w10, w9, #0xa
    5780:      	cmp	w10, #0x4
    5784:      	b.lo	0x57e8 <generic_tracepoint_arg+0x398>
    5788:      	sub	w10, w9, #0xf
    578c:      	cmp	w10, #0x2
    5790:      	b.lo	0x599c <generic_tracepoint_arg+0x54c>
    5794:      	cmp	w9, #0x11
    5798:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    579c:      	add	x25, x25, #0x4
    57a0:      	b	0x599c <generic_tracepoint_arg+0x54c>
    57a4:      	cmp	w9, #0x29
    57a8:      	b.gt	0x5914 <generic_tracepoint_arg+0x4c4>
    57ac:      	sub	w10, w9, #0x26
    57b0:      	cmp	w10, #0x2
    57b4:      	b.lo	0x58bc <generic_tracepoint_arg+0x46c>
    57b8:      	sub	w10, w9, #0x28
    57bc:      	cmp	w10, #0x2
    57c0:      	b.lo	0x5894 <generic_tracepoint_arg+0x444>
    57c4:      	b	0x56e8 <generic_tracepoint_arg+0x298>
    57c8:      	cmp	w9, #0x4
    57cc:      	b.gt	0x587c <generic_tracepoint_arg+0x42c>
    57d0:      	cmp	w9, #0x1
    57d4:      	b.eq	0x57e8 <generic_tracepoint_arg+0x398>
    57d8:      	cmp	w9, #0x2
    57dc:      	b.eq	0x5dcc <generic_tracepoint_arg+0x97c>
    57e0:      	cmp	w9, #0x4
    57e4:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    57e8:      	cmp	w9, #0xb
    57ec:      	b.le	0x585c <generic_tracepoint_arg+0x40c>
    57f0:      	cmp	w9, #0x24
    57f4:      	b.hi	0x5a58 <generic_tracepoint_arg+0x608>
    57f8:      	lsl	x10, x12, x9
    57fc:      	tst	x10, #0x1e00000000
    5800:      	b.ne	0x58ec <generic_tracepoint_arg+0x49c>
    5804:      	lsl	x10, x12, x9
    5808:      	tst	x10, #0x60000000
    580c:      	b.ne	0x5c14 <generic_tracepoint_arg+0x7c4>
    5810:      	lsl	x10, x12, x9
    5814:      	tst	x10, #0x180000000
    5818:      	b.eq	0x5a58 <generic_tracepoint_arg+0x608>
    581c:      	cmp	w8, #0x20
    5820:      	b.hi	0x554c <generic_tracepoint_arg+0xfc>
    5824:      	lsl	x9, x12, x8
    5828:      	mov	w10, #0x101e            // =4126
    582c:      	tst	x9, x10
    5830:      	b.eq	0x6254 <generic_tracepoint_arg+0xe04>
    5834:      	ldr	w9, [x23, #0x10]
    5838:      	cmp	w8, #0x2
    583c:      	b.le	0x67f0 <generic_tracepoint_arg+0x13a0>
    5840:      	sub	w10, w8, #0x3
    5844:      	cmp	w10, #0x2
    5848:      	b.hs	0x6da4 <generic_tracepoint_arg+0x1954>
    584c:      	ldrb	w10, [x25]
    5850:      	cmp	w9, w10
    5854:      	b.eq	0x56dc <generic_tracepoint_arg+0x28c>
    5858:      	b	0x6f2c <generic_tracepoint_arg+0x1adc>
    585c:      	sub	w10, w9, #0xa
    5860:      	cmp	w10, #0x2
    5864:      	b.lo	0x5e40 <generic_tracepoint_arg+0x9f0>
    5868:      	cmp	w9, #0x1
    586c:      	b.eq	0x5a64 <generic_tracepoint_arg+0x614>
    5870:      	cmp	w9, #0x4
    5874:      	b.eq	0x5a64 <generic_tracepoint_arg+0x614>
    5878:      	b	0x56e8 <generic_tracepoint_arg+0x298>
    587c:      	cmp	w9, #0x5
    5880:      	b.eq	0x5894 <generic_tracepoint_arg+0x444>
    5884:      	cmp	w9, #0x6
    5888:      	b.eq	0x58bc <generic_tracepoint_arg+0x46c>
    588c:      	cmp	w9, #0x7
    5890:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    5894:      	mov	x22, xzr
    5898:      	cmp	w9, #0x27
    589c:      	stp	xzr, xzr, [sp, #0x78]
    58a0:      	str	xzr, [sp, #0x60]
    58a4:      	stp	xzr, xzr, [sp, #0x68]
    58a8:      	b.gt	0x5aa4 <generic_tracepoint_arg+0x654>
    58ac:      	cmp	w9, #0x5
    58b0:      	b.eq	0x5f60 <generic_tracepoint_arg+0xb10>
    58b4:      	cmp	w9, #0x7
    58b8:      	b	0x5ab0 <generic_tracepoint_arg+0x660>
    58bc:      	ldr	w29, [x25], #0x4
    58c0:      	mov	x22, xzr
    58c4:      	cmp	w8, #0x19
    58c8:      	b.gt	0x5b10 <generic_tracepoint_arg+0x6c0>
    58cc:      	sub	w9, w8, #0x3
    58d0:      	cmp	w9, #0x2
    58d4:      	b.lo	0x61e4 <generic_tracepoint_arg+0xd94>
    58d8:      	cmp	w8, #0x8
    58dc:      	b.eq	0x614c <generic_tracepoint_arg+0xcfc>
    58e0:      	cmp	w8, #0x9
    58e4:      	b.eq	0x5b28 <generic_tracepoint_arg+0x6d8>
    58e8:      	b	0x6710 <generic_tracepoint_arg+0x12c0>
    58ec:      	cmp	w8, #0x9
    58f0:      	b.le	0x5dbc <generic_tracepoint_arg+0x96c>
    58f4:      	cmp	w8, #0x1d
    58f8:      	b.gt	0x610c <generic_tracepoint_arg+0xcbc>
    58fc:      	sub	w10, w8, #0xa
    5900:      	cmp	w10, #0x2
    5904:      	b.lo	0x5ecc <generic_tracepoint_arg+0xa7c>
    5908:      	cmp	w8, #0xc
    590c:      	b.eq	0x5e58 <generic_tracepoint_arg+0xa08>
    5910:      	b	0x554c <generic_tracepoint_arg+0xfc>
    5914:      	cmp	w9, #0x2a
    5918:      	b.eq	0x599c <generic_tracepoint_arg+0x54c>
    591c:      	cmp	w9, #0x2c
    5920:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    5924:      	ldrb	w29, [x25, #0x3]
    5928:      	add	x10, x25, #0x4
    592c:      	cmp	w8, #0x19
    5930:      	b.gt	0x64e0 <generic_tracepoint_arg+0x1090>
    5934:      	sub	w9, w8, #0x3
    5938:      	cmp	w9, #0x2
    593c:      	b.hs	0x6a44 <generic_tracepoint_arg+0x15f4>
    5940:      	cmp	w29, #0x90
    5944:      	str	wzr, [sp, #0x88]
    5948:      	b.hi	0x6ae0 <generic_tracepoint_arg+0x1690>
    594c:      	mov	w8, #0xaaab             // =43691
    5950:      	mov	w9, #0x18               // =24
    5954:      	movk	w8, #0xaaa, lsl #16
    5958:      	umull	x8, w29, w8
    595c:      	lsr	x8, x8, #32
    5960:      	msub	w8, w8, w9, w29
    5964:      	cbz	w29, 0x5970 <generic_tracepoint_arg+0x520>
    5968:      	mov	w13, w29
    596c:      	cbz	w8, 0x5984 <generic_tracepoint_arg+0x534>
    5970:      	sub	w8, w29, w8, uxtb
    5974:      	add	w9, w8, #0x18
    5978:      	cmp	w8, #0x78
    597c:      	and	w13, w9, #0xffff
    5980:      	b.hi	0x6ae4 <generic_tracepoint_arg+0x1694>
    5984:      	and	w8, w13, #0xff
    5988:      	mov	w9, #0xab               // =171
    598c:      	mul	w8, w8, w9
    5990:      	lsr	w8, w8, #12
    5994:      	sub	w11, w8, #0x1
    5998:      	b	0x74d8 <generic_tracepoint_arg+0x2088>
    599c:      	ldr	w29, [x25]
    59a0:      	and	w9, w8, #0xfffffffe
    59a4:      	cmp	w9, #0x24
    59a8:      	b.eq	0x59b0 <generic_tracepoint_arg+0x560>
    59ac:      	cbz	w29, 0x554c <generic_tracepoint_arg+0xfc>
    59b0:      	cmp	w8, #0x25
    59b4:      	b.hi	0x5bf4 <generic_tracepoint_arg+0x7a4>
    59b8:      	mov	w10, #0x100             // =256
    59bc:      	lsl	x9, x12, x8
    59c0:      	movk	w10, #0x400, lsl #16
    59c4:      	tst	x9, x10
    59c8:      	b.ne	0x5d24 <generic_tracepoint_arg+0x8d4>
    59cc:      	mov	w10, #0x200             // =512
    59d0:      	lsl	x9, x12, x8
    59d4:      	movk	w10, #0x800, lsl #16
    59d8:      	tst	x9, x10
    59dc:      	b.ne	0x5c54 <generic_tracepoint_arg+0x804>
    59e0:      	lsl	x9, x12, x8
    59e4:      	tst	x9, #0x3000000000
    59e8:      	b.eq	0x5bf4 <generic_tracepoint_arg+0x7a4>
    59ec:      	cmp	w29, #0x1, lsl #12      // =0x1000
    59f0:      	strh	wzr, [sp, #0x60]
    59f4:      	b.hi	0x5c0c <generic_tracepoint_arg+0x7bc>
    59f8:      	add	x8, x25, #0x4
    59fc:      	mov	w10, #0x4               // =4
    5a00:      	add	x11, sp, #0x60
    5a04:      	mov	w12, #0x2               // =2
    5a08:      	add	x0, sp, #0x60
    5a0c:      	mov	w1, #0x2                // =2
    5a10:      	add	x9, x8, x29
    5a14:      	add	x9, x9, #0x4
    5a18:      	ldr	w9, [x25]
    5a1c:      	add	x8, x8, x9
    5a20:      	add	x2, x8, #0x4
    5a24:      	blr	x10
    5a28:      	ldr	w9, [x23, #0x10]
    5a2c:      	cbz	w9, 0x8230 <generic_tracepoint_arg+0x2de0>
    5a30:      	ldrh	w8, [sp, #0x60]
    5a34:      	ldp	x16, x15, [sp, #0x40]
    5a38:      	mov	w2, #0x5ea0             // =24224
    5a3c:      	mov	w12, #0x1               // =1
    5a40:      	and	w8, w8, #0xf000
    5a44:      	ldr	x17, [sp, #0x38]
    5a48:      	cmp	w9, w8
    5a4c:      	b.ne	0x6dd4 <generic_tracepoint_arg+0x1984>
    5a50:      	mov	w22, #0x1               // =1
    5a54:      	b	0x8244 <generic_tracepoint_arg+0x2df4>
    5a58:      	sub	w10, w9, #0xc
    5a5c:      	cmp	w10, #0x2
    5a60:      	b.hs	0x5e38 <generic_tracepoint_arg+0x9e8>
    5a64:      	cmp	w8, #0x20
    5a68:      	b.hi	0x554c <generic_tracepoint_arg+0xfc>
    5a6c:      	lsl	x10, x12, x8
    5a70:      	mov	w11, #0x101e            // =4126
    5a74:      	tst	x10, x11
    5a78:      	b.eq	0x5abc <generic_tracepoint_arg+0x66c>
    5a7c:      	ldr	w10, [x23, #0x10]
    5a80:      	cmp	w8, #0x2
    5a84:      	b.le	0x5e00 <generic_tracepoint_arg+0x9b0>
    5a88:      	sub	w11, w8, #0x3
    5a8c:      	cmp	w11, #0x2
    5a90:      	b.hs	0x623c <generic_tracepoint_arg+0xdec>
    5a94:      	ldr	w11, [x25]
    5a98:      	cmp	w11, w10
    5a9c:      	b.eq	0x56dc <generic_tracepoint_arg+0x28c>
    5aa0:      	b	0x7300 <generic_tracepoint_arg+0x1eb0>
    5aa4:      	cmp	w9, #0x28
    5aa8:      	b.eq	0x5f68 <generic_tracepoint_arg+0xb18>
    5aac:      	cmp	w9, #0x29
    5ab0:      	mov	x10, x25
    5ab4:      	b.eq	0x5f90 <generic_tracepoint_arg+0xb40>
    5ab8:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    5abc:      	lsl	x10, x12, x8
    5ac0:      	tst	x10, #0xc00
    5ac4:      	b.ne	0x5f28 <generic_tracepoint_arg+0xad8>
    5ac8:      	lsl	x10, x12, x8
    5acc:      	tst	x10, #0x180000000
    5ad0:      	b.eq	0x554c <generic_tracepoint_arg+0xfc>
    5ad4:      	cmp	w8, #0x1f
    5ad8:      	b.ne	0x64b0 <generic_tracepoint_arg+0x1060>
    5adc:      	ldp	w11, w10, [x23, #0x10]
    5ae0:      	cmp	w9, #0xc
    5ae4:      	b.hi	0x6fa0 <generic_tracepoint_arg+0x1b50>
    5ae8:      	lsl	w8, w12, w9
    5aec:      	mov	w13, #0x1402            // =5122
    5af0:      	tst	w8, w13
    5af4:      	b.eq	0x6fa0 <generic_tracepoint_arg+0x1b50>
    5af8:      	ldr	w8, [x25]
    5afc:      	cmp	w11, w8
    5b00:      	b.gt	0x6fb4 <generic_tracepoint_arg+0x1b64>
    5b04:      	cmp	w8, w10
    5b08:      	b.le	0x56e8 <generic_tracepoint_arg+0x298>
    5b0c:      	b	0x6fb4 <generic_tracepoint_arg+0x1b64>
    5b10:      	cmp	w8, #0x20
    5b14:      	b.gt	0x6004 <generic_tracepoint_arg+0xbb4>
    5b18:      	cmp	w8, #0x1a
    5b1c:      	b.eq	0x614c <generic_tracepoint_arg+0xcfc>
    5b20:      	cmp	w8, #0x1b
    5b24:      	b.ne	0x6710 <generic_tracepoint_arg+0x12c0>
    5b28:      	ldr	w8, [x23, #0x10]
    5b2c:      	str	wzr, [sp, #0x88]
    5b30:      	adrp	x0, 0x5000 <generic_tracepoint_filter+0x1f20>
    5b34:      	add	x9, sp, #0x60
    5b38:      	add	x1, sp, #0x60
    5b3c:      	str	w8, [sp, #0x60]
    5b40:      	mov	w8, #0x1                // =1
    5b44:      	ldr	x0, [x0]
    5b48:      	blr	x8
    5b4c:      	mov	x22, xzr
    5b50:      	cbz	w29, 0x6700 <generic_tracepoint_arg+0x12b0>
    5b54:      	cbz	x0, 0x6700 <generic_tracepoint_arg+0x12b0>
    5b58:      	mov	x19, x0
    5b5c:      	adrp	x0, 0x5000 <generic_tracepoint_filter+0x1f20>
    5b60:      	mov	w8, #0x1                // =1
    5b64:      	ldr	x0, [x0]
    5b68:      	add	x9, sp, #0x88
    5b6c:      	add	x1, sp, #0x88
    5b70:      	blr	x8
    5b74:      	cbz	x0, 0x66f8 <generic_tracepoint_arg+0x12a8>
    5b78:      	cmp	w29, #0x7f
    5b7c:      	mov	w9, #0x7f               // =127
    5b80:      	mov	w11, #0x1               // =1
    5b84:      	mov	x1, x0
    5b88:      	mov	x8, xzr
    5b8c:      	sub	w12, w29, #0x2
    5b90:      	sub	w13, w29, #0x1
    5b94:      	csel	w9, w29, w9, lo
    5b98:      	sub	x11, x11, x29
    5b9c:      	lsl	w10, w9, #3
    5ba0:      	mov	x9, x0
    5ba4:      	str	w10, [x9], #0x5
    5ba8:      	neg	x10, x29
    5bac:      	add	w14, w13, w8
    5bb0:      	cmp	x11, x8
    5bb4:      	and	x14, x14, #0xfff
    5bb8:      	ldrb	w14, [x25, x14]
    5bbc:      	sturb	w14, [x9, #-0x1]
    5bc0:      	b.eq	0x5be8 <generic_tracepoint_arg+0x798>
    5bc4:      	cmn	x8, #0x7e
    5bc8:      	b.eq	0x5be8 <generic_tracepoint_arg+0x798>
    5bcc:      	add	w14, w12, w8
    5bd0:      	sub	x8, x8, #0x2
    5bd4:      	and	x14, x14, #0xfff
    5bd8:      	cmp	x10, x8
    5bdc:      	ldrb	w14, [x25, x14]
    5be0:      	strb	w14, [x9], #0x2
    5be4:      	b.ne	0x5bac <generic_tracepoint_arg+0x75c>
    5be8:      	mov	w8, #0x1                // =1
    5bec:      	mov	x0, x19
    5bf0:      	b	0x61d4 <generic_tracepoint_arg+0xd84>
    5bf4:      	sub	w8, w8, #0x3
    5bf8:      	cmp	w8, #0x2
    5bfc:      	b.hs	0x5c0c <generic_tracepoint_arg+0x7bc>
    5c00:      	cmp	w29, #0x1, lsl #12      // =0x1000
    5c04:      	str	wzr, [sp, #0x88]
    5c08:      	b.ls	0x6344 <generic_tracepoint_arg+0xef4>
    5c0c:      	mov	x22, xzr
    5c10:      	b	0x8244 <generic_tracepoint_arg+0x2df4>
    5c14:      	cmp	w8, #0x20
    5c18:      	b.hi	0x554c <generic_tracepoint_arg+0xfc>
    5c1c:      	lsl	x9, x12, x8
    5c20:      	mov	w10, #0x101e            // =4126
    5c24:      	tst	x9, x10
    5c28:      	b.eq	0x6280 <generic_tracepoint_arg+0xe30>
    5c2c:      	ldr	w9, [x23, #0x10]
    5c30:      	cmp	w8, #0x2
    5c34:      	b.le	0x6810 <generic_tracepoint_arg+0x13c0>
    5c38:      	sub	w10, w8, #0x3
    5c3c:      	cmp	w10, #0x2
    5c40:      	b.hs	0x6dbc <generic_tracepoint_arg+0x196c>
    5c44:      	ldrh	w10, [x25]
    5c48:      	cmp	w9, w10
    5c4c:      	b.eq	0x56dc <generic_tracepoint_arg+0x28c>
    5c50:      	b	0x6f6c <generic_tracepoint_arg+0x1b1c>
    5c54:      	ldr	w8, [x23, #0x10]
    5c58:      	str	wzr, [sp, #0x88]
    5c5c:      	adrp	x0, 0x5000 <generic_tracepoint_filter+0x1f20>
    5c60:      	add	x9, sp, #0x60
    5c64:      	add	x1, sp, #0x60
    5c68:      	str	w8, [sp, #0x60]
    5c6c:      	mov	w8, #0x1                // =1
    5c70:      	ldr	x0, [x0]
    5c74:      	blr	x8
    5c78:      	mov	x22, xzr
    5c7c:      	cbz	w29, 0x8234 <generic_tracepoint_arg+0x2de4>
    5c80:      	cbz	x0, 0x8234 <generic_tracepoint_arg+0x2de4>
    5c84:      	mov	x19, x0
    5c88:      	adrp	x0, 0x5000 <generic_tracepoint_filter+0x1f20>
    5c8c:      	mov	w8, #0x1                // =1
    5c90:      	ldr	x0, [x0]
    5c94:      	add	x9, sp, #0x88
    5c98:      	add	x1, sp, #0x88
    5c9c:      	blr	x8
    5ca0:      	cbz	x0, 0x6e24 <generic_tracepoint_arg+0x19d4>
    5ca4:      	cmp	w29, #0x7f
    5ca8:      	mov	w10, #0x7f              // =127
    5cac:      	mov	w12, #0x1               // =1
    5cb0:      	mov	x1, x0
    5cb4:      	mov	x8, xzr
    5cb8:      	add	x9, x25, #0x4
    5cbc:      	sub	w13, w29, #0x2
    5cc0:      	sub	w14, w29, #0x1
    5cc4:      	csel	w10, w29, w10, lo
    5cc8:      	sub	x12, x12, x29
    5ccc:      	lsl	w11, w10, #3
    5cd0:      	mov	x10, x0
    5cd4:      	str	w11, [x10], #0x5
    5cd8:      	neg	x11, x29
    5cdc:      	add	w15, w14, w8
    5ce0:      	cmp	x12, x8
    5ce4:      	and	x15, x15, #0xfff
    5ce8:      	ldrb	w15, [x9, x15]
    5cec:      	sturb	w15, [x10, #-0x1]
    5cf0:      	b.eq	0x5d18 <generic_tracepoint_arg+0x8c8>
    5cf4:      	cmn	x8, #0x7e
    5cf8:      	b.eq	0x5d18 <generic_tracepoint_arg+0x8c8>
    5cfc:      	add	w15, w13, w8
    5d00:      	sub	x8, x8, #0x2
    5d04:      	and	x15, x15, #0xfff
    5d08:      	cmp	x11, x8
    5d0c:      	ldrb	w15, [x9, x15]
    5d10:      	strb	w15, [x10], #0x2
    5d14:      	b.ne	0x5cdc <generic_tracepoint_arg+0x88c>
    5d18:      	mov	w8, #0x1                // =1
    5d1c:      	mov	x0, x19
    5d20:      	b	0x5dac <generic_tracepoint_arg+0x95c>
    5d24:      	ldr	w8, [x23, #0x10]
    5d28:      	str	wzr, [sp, #0x88]
    5d2c:      	adrp	x0, 0x5000 <generic_tracepoint_filter+0x1f20>
    5d30:      	add	x9, sp, #0x60
    5d34:      	add	x1, sp, #0x60
    5d38:      	str	w8, [sp, #0x60]
    5d3c:      	mov	w8, #0x1                // =1
    5d40:      	ldr	x0, [x0]
    5d44:      	blr	x8
    5d48:      	mov	x22, xzr
    5d4c:      	cbz	w29, 0x8234 <generic_tracepoint_arg+0x2de4>
    5d50:      	cbz	x0, 0x8234 <generic_tracepoint_arg+0x2de4>
    5d54:      	mov	x19, x0
    5d58:      	adrp	x0, 0x5000 <generic_tracepoint_filter+0x1f20>
    5d5c:      	mov	w8, #0x1                // =1
    5d60:      	ldr	x0, [x0]
    5d64:      	add	x9, sp, #0x88
    5d68:      	add	x1, sp, #0x88
    5d6c:      	blr	x8
    5d70:      	cbz	x0, 0x6e24 <generic_tracepoint_arg+0x19d4>
    5d74:      	cmp	w29, #0xff
    5d78:      	mov	w8, #0xff               // =255
    5d7c:      	add	x2, x25, #0x4
    5d80:      	mov	x22, x0
    5d84:      	csel	w1, w29, w8, lo
    5d88:      	mov	x8, x0
    5d8c:      	lsl	w9, w1, #3
    5d90:      	str	w9, [x8], #0x4
    5d94:      	mov	w9, #0x4                // =4
    5d98:      	mov	x0, x8
    5d9c:      	blr	x9
    5da0:      	mov	w8, #0x1                // =1
    5da4:      	mov	x0, x19
    5da8:      	mov	x1, x22
    5dac:      	blr	x8
    5db0:      	cmp	x0, #0x0
    5db4:      	cset	w22, ne
    5db8:      	b	0x6e28 <generic_tracepoint_arg+0x19d8>
    5dbc:      	sub	w10, w8, #0x1
    5dc0:      	cmp	w10, #0x4
    5dc4:      	b.lo	0x5e58 <generic_tracepoint_arg+0xa08>
    5dc8:      	b	0x554c <generic_tracepoint_arg+0xfc>
    5dcc:      	add	x29, x25, #0x8
    5dd0:      	ldr	w25, [x25, #0x4]
    5dd4:      	mov	x22, xzr
    5dd8:      	cmp	w8, #0x19
    5ddc:      	b.gt	0x63b4 <generic_tracepoint_arg+0xf64>
    5de0:      	sub	w9, w8, #0x3
    5de4:      	cmp	w9, #0x2
    5de8:      	b.lo	0x6bd0 <generic_tracepoint_arg+0x1780>
    5dec:      	cmp	w8, #0x8
    5df0:      	b.eq	0x6b44 <generic_tracepoint_arg+0x16f4>
    5df4:      	cmp	w8, #0x9
    5df8:      	b.eq	0x63cc <generic_tracepoint_arg+0xf7c>
    5dfc:      	b	0x87d4 <generic_tracepoint_arg+0x3384>
    5e00:      	cmp	w8, #0x1
    5e04:      	b.eq	0x661c <generic_tracepoint_arg+0x11cc>
    5e08:      	cmp	w8, #0x2
    5e0c:      	b.ne	0x7300 <generic_tracepoint_arg+0x1eb0>
    5e10:      	cmp	w9, #0xc
    5e14:      	b.hi	0x72f4 <generic_tracepoint_arg+0x1ea4>
    5e18:      	lsl	w11, w12, w9
    5e1c:      	mov	w13, #0x1402            // =5122
    5e20:      	tst	w11, w13
    5e24:      	b.eq	0x72f4 <generic_tracepoint_arg+0x1ea4>
    5e28:      	ldr	w11, [x25]
    5e2c:      	cmp	w11, w10
    5e30:      	b.lt	0x56e8 <generic_tracepoint_arg+0x298>
    5e34:      	b	0x7300 <generic_tracepoint_arg+0x1eb0>
    5e38:      	cmp	w9, #0x1c
    5e3c:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    5e40:      	cmp	w8, #0x20
    5e44:      	b.hi	0x554c <generic_tracepoint_arg+0xfc>
    5e48:      	lsl	x10, x12, x8
    5e4c:      	mov	w11, #0x101e            // =4126
    5e50:      	tst	x10, x11
    5e54:      	b.eq	0x5e80 <generic_tracepoint_arg+0xa30>
    5e58:      	ldr	x10, [x23, #0x10]
    5e5c:      	cmp	w8, #0x2
    5e60:      	b.le	0x5e9c <generic_tracepoint_arg+0xa4c>
    5e64:      	sub	w11, w8, #0x3
    5e68:      	cmp	w11, #0x2
    5e6c:      	b.hs	0x60f4 <generic_tracepoint_arg+0xca4>
    5e70:      	ldr	x11, [x25]
    5e74:      	cmp	x11, x10
    5e78:      	b.eq	0x56dc <generic_tracepoint_arg+0x28c>
    5e7c:      	b	0x6d18 <generic_tracepoint_arg+0x18c8>
    5e80:      	lsl	x10, x12, x8
    5e84:      	tst	x10, #0xc00
    5e88:      	b.ne	0x5ecc <generic_tracepoint_arg+0xa7c>
    5e8c:      	lsl	x10, x12, x8
    5e90:      	tst	x10, #0x180000000
    5e94:      	b.ne	0x6118 <generic_tracepoint_arg+0xcc8>
    5e98:      	b	0x554c <generic_tracepoint_arg+0xfc>
    5e9c:      	cmp	w8, #0x1
    5ea0:      	b.eq	0x6324 <generic_tracepoint_arg+0xed4>
    5ea4:      	cmp	w8, #0x2
    5ea8:      	b.ne	0x6d18 <generic_tracepoint_arg+0x18c8>
    5eac:      	cmp	w9, #0xc
    5eb0:      	b.eq	0x5ebc <generic_tracepoint_arg+0xa6c>
    5eb4:      	cmp	w9, #0xa
    5eb8:      	b.ne	0x6d0c <generic_tracepoint_arg+0x18bc>
    5ebc:      	ldr	x11, [x25]
    5ec0:      	cmp	x11, x10
    5ec4:      	b.lt	0x56e8 <generic_tracepoint_arg+0x298>
    5ec8:      	b	0x6d18 <generic_tracepoint_arg+0x18c8>
    5ecc:      	ldrb	w8, [x23, #0x10]
    5ed0:      	adrp	x0, 0x5000 <generic_tracepoint_filter+0x1f20>
    5ed4:      	add	x9, sp, #0x88
    5ed8:      	add	x1, sp, #0x88
    5edc:      	str	w8, [sp, #0x88]
    5ee0:      	mov	w8, #0x1                // =1
    5ee4:      	ldr	x0, [x0]
    5ee8:      	blr	x8
    5eec:      	cbz	x0, 0x6498 <generic_tracepoint_arg+0x1048>
    5ef0:      	ldr	x8, [x25]
    5ef4:      	add	x9, sp, #0x60
    5ef8:      	add	x1, sp, #0x60
    5efc:      	str	x8, [sp, #0x60]
    5f00:      	mov	w8, #0x1                // =1
    5f04:      	blr	x8
    5f08:      	ldr	w8, [x23, #0x4]
    5f0c:      	cmp	w8, #0xb
    5f10:      	b.eq	0x68c4 <generic_tracepoint_arg+0x1474>
    5f14:      	cmp	w8, #0xa
    5f18:      	mov	w12, #0x1               // =1
    5f1c:      	b.eq	0x6964 <generic_tracepoint_arg+0x1514>
    5f20:      	mov	w8, wzr
    5f24:      	b	0x696c <generic_tracepoint_arg+0x151c>
    5f28:      	ldrb	w8, [x23, #0x10]
    5f2c:      	adrp	x0, 0x5000 <generic_tracepoint_filter+0x1f20>
    5f30:      	add	x9, sp, #0x88
    5f34:      	add	x1, sp, #0x88
    5f38:      	str	w8, [sp, #0x88]
    5f3c:      	mov	w8, #0x1                // =1
    5f40:      	ldr	x0, [x0]
    5f44:      	blr	x8
    5f48:      	cbz	x0, 0x6ce0 <generic_tracepoint_arg+0x1890>
    5f4c:      	ldr	w8, [x25]
    5f50:      	add	x9, sp, #0x60
    5f54:      	str	x8, [sp, #0x60]
    5f58:      	mov	w8, #0x1                // =1
    5f5c:      	b	0x689c <generic_tracepoint_arg+0x144c>
    5f60:      	mov	x10, xzr
    5f64:      	b	0x5f90 <generic_tracepoint_arg+0xb40>
    5f68:      	ldrh	w11, [x25]
    5f6c:      	mov	x10, xzr
    5f70:      	strh	w11, [sp, #0x86]
    5f74:      	ldrh	w11, [x25, #0x2]
    5f78:      	strh	w11, [sp, #0x80]
    5f7c:      	ldr	x11, [x25, #0x8]
    5f80:      	str	x11, [sp, #0x60]
    5f84:      	ldr	x11, [x25, #0x10]
    5f88:      	add	x25, sp, #0x60
    5f8c:      	str	x11, [sp, #0x68]
    5f90:      	mov	x22, xzr
    5f94:      	cmp	w8, #0x13
    5f98:      	b.le	0x5fc0 <generic_tracepoint_arg+0xb70>
    5f9c:      	cmp	w8, #0x17
    5fa0:      	b.gt	0x5fe8 <generic_tracepoint_arg+0xb98>
    5fa4:      	sub	w9, w8, #0x14
    5fa8:      	cmp	w9, #0x2
    5fac:      	b.lo	0x651c <generic_tracepoint_arg+0x10cc>
    5fb0:      	sub	w9, w8, #0x16
    5fb4:      	cmp	w9, #0x2
    5fb8:      	b.lo	0x6508 <generic_tracepoint_arg+0x10b8>
    5fbc:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    5fc0:      	cmp	w8, #0xf
    5fc4:      	b.le	0x61f8 <generic_tracepoint_arg+0xda8>
    5fc8:      	cmp	w8, #0x11
    5fcc:      	b.gt	0x64f8 <generic_tracepoint_arg+0x10a8>
    5fd0:      	cmp	w8, #0x10
    5fd4:      	b.eq	0x6508 <generic_tracepoint_arg+0x10b8>
    5fd8:      	cmp	w8, #0x11
    5fdc:      	b.ne	0x56e4 <generic_tracepoint_arg+0x294>
    5fe0:      	ldrh	w22, [x25, #0x24]
    5fe4:      	b	0x6c74 <generic_tracepoint_arg+0x1824>
    5fe8:      	cmp	w8, #0x1b
    5fec:      	b.gt	0x6530 <generic_tracepoint_arg+0x10e0>
    5ff0:      	cmp	w8, #0x18
    5ff4:      	b.eq	0x6560 <generic_tracepoint_arg+0x1110>
    5ff8:      	cmp	w8, #0x19
    5ffc:      	b.eq	0x6554 <generic_tracepoint_arg+0x1104>
    6000:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    6004:      	cmp	w8, #0x21
    6008:      	b.eq	0x6644 <generic_tracepoint_arg+0x11f4>
    600c:      	cmp	w8, #0x22
    6010:      	b.ne	0x6710 <generic_tracepoint_arg+0x12c0>
    6014:      	mov	x22, xzr
    6018:      	mov	w19, wzr
    601c:      	add	x8, x23, #0x10
    6020:      	str	x8, [sp, #0x28]
    6024:      	ldr	x8, [sp, #0x28]
    6028:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    602c:      	add	x9, sp, #0x60
    6030:      	add	x1, sp, #0x60
    6034:      	ldr	w8, [x8, x22, lsl #2]
    6038:      	str	w8, [sp, #0x60]
    603c:      	mov	w8, #0x1                // =1
    6040:      	ldr	x0, [x0]
    6044:      	blr	x8
    6048:      	cbz	x0, 0x66f8 <generic_tracepoint_arg+0x12a8>
    604c:      	cbz	w29, 0x60d0 <generic_tracepoint_arg+0xc80>
    6050:      	mov	x8, xzr
    6054:      	mov	x9, x25
    6058:      	mov	x10, x29
    605c:      	b	0x6074 <generic_tracepoint_arg+0xc24>
    6060:      	add	x8, x8, #0x1
    6064:      	sub	x10, x10, #0x1
    6068:      	add	x9, x9, #0x1
    606c:      	cmp	x8, x29
    6070:      	b.eq	0x60d0 <generic_tracepoint_arg+0xc80>
    6074:      	mov	x11, xzr
    6078:      	nop
    607c:      	nop
    6080:      	cmp	x10, x11
    6084:      	b.eq	0x6060 <generic_tracepoint_arg+0xc10>
    6088:      	ldrb	w12, [x0, x11]
    608c:      	cbz	w12, 0x60cc <generic_tracepoint_arg+0xc7c>
    6090:      	ldrb	w13, [x9, x11]
    6094:      	sub	w14, w13, #0x41
    6098:      	orr	w15, w13, #0x20
    609c:      	cmp	w14, #0x1a
    60a0:      	sub	w14, w12, #0x41
    60a4:      	csel	w13, w15, w13, lo
    60a8:      	orr	w15, w12, #0x20
    60ac:      	cmp	w14, #0x1a
    60b0:      	csel	w12, w15, w12, lo
    60b4:      	cmp	x11, #0x62
    60b8:      	b.hi	0x6060 <generic_tracepoint_arg+0xc10>
    60bc:      	add	x11, x11, #0x1
    60c0:      	cmp	w13, w12
    60c4:      	b.eq	0x6080 <generic_tracepoint_arg+0xc30>
    60c8:      	b	0x6060 <generic_tracepoint_arg+0xc10>
    60cc:      	tbz	w8, #0x1f, 0x6f18 <generic_tracepoint_arg+0x1ac8>
    60d0:      	ldr	w9, [x23, #0x8]
    60d4:      	add	w8, w19, #0xc
    60d8:      	cmp	w8, w9
    60dc:      	b.hs	0x66f8 <generic_tracepoint_arg+0x12a8>
    60e0:      	add	x22, x22, #0x1
    60e4:      	add	w19, w19, #0x4
    60e8:      	cmp	x22, #0x64
    60ec:      	b.ne	0x6024 <generic_tracepoint_arg+0xbd4>
    60f0:      	b	0x66f8 <generic_tracepoint_arg+0x12a8>
    60f4:      	cmp	w8, #0xc
    60f8:      	b.ne	0x6d18 <generic_tracepoint_arg+0x18c8>
    60fc:      	ldr	x11, [x25]
    6100:      	tst	x11, x10
    6104:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    6108:      	b	0x6d18 <generic_tracepoint_arg+0x18c8>
    610c:      	sub	w10, w8, #0x1f
    6110:      	cmp	w10, #0x2
    6114:      	b.hs	0x6990 <generic_tracepoint_arg+0x1540>
    6118:      	cmp	w8, #0x1f
    611c:      	b.ne	0x6214 <generic_tracepoint_arg+0xdc4>
    6120:      	ldp	x11, x10, [x23, #0x10]
    6124:      	cmp	w9, #0xa
    6128:      	b.eq	0x6134 <generic_tracepoint_arg+0xce4>
    612c:      	cmp	w9, #0xc
    6130:      	b.ne	0x6be4 <generic_tracepoint_arg+0x1794>
    6134:      	ldr	x8, [x25]
    6138:      	cmp	x11, x8
    613c:      	b.gt	0x6bf8 <generic_tracepoint_arg+0x17a8>
    6140:      	cmp	x8, x10
    6144:      	b.le	0x56e8 <generic_tracepoint_arg+0x298>
    6148:      	b	0x6bf8 <generic_tracepoint_arg+0x17a8>
    614c:      	ldr	w8, [x23, #0x10]
    6150:      	str	wzr, [sp, #0x88]
    6154:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    6158:      	add	x9, sp, #0x60
    615c:      	add	x1, sp, #0x60
    6160:      	str	w8, [sp, #0x60]
    6164:      	mov	w8, #0x1                // =1
    6168:      	ldr	x0, [x0]
    616c:      	blr	x8
    6170:      	mov	x22, xzr
    6174:      	cbz	w29, 0x6700 <generic_tracepoint_arg+0x12b0>
    6178:      	cbz	x0, 0x6700 <generic_tracepoint_arg+0x12b0>
    617c:      	mov	x19, x0
    6180:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    6184:      	mov	w8, #0x1                // =1
    6188:      	ldr	x0, [x0]
    618c:      	add	x9, sp, #0x88
    6190:      	add	x1, sp, #0x88
    6194:      	blr	x8
    6198:      	cbz	x0, 0x66f8 <generic_tracepoint_arg+0x12a8>
    619c:      	cmp	w29, #0xff
    61a0:      	mov	w8, #0xff               // =255
    61a4:      	mov	x22, x0
    61a8:      	mov	x2, x25
    61ac:      	csel	w1, w29, w8, lo
    61b0:      	mov	x8, x0
    61b4:      	lsl	w9, w1, #3
    61b8:      	str	w9, [x8], #0x4
    61bc:      	mov	w9, #0x4                // =4
    61c0:      	mov	x0, x8
    61c4:      	blr	x9
    61c8:      	mov	w8, #0x1                // =1
    61cc:      	mov	x0, x19
    61d0:      	mov	x1, x22
    61d4:      	blr	x8
    61d8:      	cmp	x0, #0x0
    61dc:      	cset	w22, ne
    61e0:      	b	0x66fc <generic_tracepoint_arg+0x12ac>
    61e4:      	cmp	w29, #0x1, lsl #12      // =0x1000
    61e8:      	str	wzr, [sp, #0x88]
    61ec:      	b.ls	0x6738 <generic_tracepoint_arg+0x12e8>
    61f0:      	mov	x22, xzr
    61f4:      	b	0x6710 <generic_tracepoint_arg+0x12c0>
    61f8:      	cmp	w8, #0xd
    61fc:      	b.eq	0x6560 <generic_tracepoint_arg+0x1110>
    6200:      	cmp	w8, #0xe
    6204:      	b.eq	0x6554 <generic_tracepoint_arg+0x1104>
    6208:      	cmp	w8, #0xf
    620c:      	b.eq	0x651c <generic_tracepoint_arg+0x10cc>
    6210:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    6214:      	ldp	x11, x8, [x23, #0x10]
    6218:      	cmp	w9, #0xc
    621c:      	b.eq	0x6228 <generic_tracepoint_arg+0xdd8>
    6220:      	cmp	w9, #0xa
    6224:      	b.ne	0x6c30 <generic_tracepoint_arg+0x17e0>
    6228:      	ldr	x10, [x25]
    622c:      	cmp	x11, x10
    6230:      	ccmp	x10, x8, #0x0, le
    6234:      	cset	w8, le
    6238:      	b	0x6c40 <generic_tracepoint_arg+0x17f0>
    623c:      	cmp	w8, #0xc
    6240:      	b.ne	0x7300 <generic_tracepoint_arg+0x1eb0>
    6244:      	ldr	w11, [x25]
    6248:      	tst	w11, w10
    624c:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    6250:      	b	0x7300 <generic_tracepoint_arg+0x1eb0>
    6254:      	lsl	x9, x12, x8
    6258:      	tst	x9, #0xc00
    625c:      	b.ne	0x6830 <generic_tracepoint_arg+0x13e0>
    6260:      	lsl	x9, x12, x8
    6264:      	tst	x9, #0x180000000
    6268:      	b.eq	0x554c <generic_tracepoint_arg+0xfc>
    626c:      	cmp	w8, #0x1f
    6270:      	b.ne	0x6e54 <generic_tracepoint_arg+0x1a04>
    6274:      	ldr	w9, [x23, #0x10]
    6278:      	ldrb	w8, [x25]
    627c:      	b	0x62a8 <generic_tracepoint_arg+0xe58>
    6280:      	lsl	x9, x12, x8
    6284:      	tst	x9, #0xc00
    6288:      	b.ne	0x6868 <generic_tracepoint_arg+0x1418>
    628c:      	lsl	x9, x12, x8
    6290:      	tst	x9, #0x180000000
    6294:      	b.eq	0x554c <generic_tracepoint_arg+0xfc>
    6298:      	cmp	w8, #0x1f
    629c:      	b.ne	0x6e78 <generic_tracepoint_arg+0x1a28>
    62a0:      	ldr	w9, [x23, #0x10]
    62a4:      	ldrh	w8, [x25]
    62a8:      	cmp	w9, w8
    62ac:      	b.hi	0x62bc <generic_tracepoint_arg+0xe6c>
    62b0:      	ldr	w9, [x23, #0x14]
    62b4:      	cmp	w9, w8
    62b8:      	b.hs	0x56e8 <generic_tracepoint_arg+0x298>
    62bc:      	ldr	w9, [x23, #0x8]
    62c0:      	cmp	w9, #0x11
    62c4:      	b.lo	0x554c <generic_tracepoint_arg+0xfc>
    62c8:      	ldr	w10, [x23, #0x18]
    62cc:      	cmp	w10, w8
    62d0:      	b.hi	0x62e0 <generic_tracepoint_arg+0xe90>
    62d4:      	ldr	w10, [x23, #0x1c]
    62d8:      	cmp	w10, w8
    62dc:      	b.hs	0x56e8 <generic_tracepoint_arg+0x298>
    62e0:      	cmp	w9, #0x19
    62e4:      	b.lo	0x554c <generic_tracepoint_arg+0xfc>
    62e8:      	ldr	w10, [x23, #0x20]
    62ec:      	cmp	w10, w8
    62f0:      	b.hi	0x6300 <generic_tracepoint_arg+0xeb0>
    62f4:      	ldr	w10, [x23, #0x24]
    62f8:      	cmp	w10, w8
    62fc:      	b.hs	0x56e8 <generic_tracepoint_arg+0x298>
    6300:      	cmp	w9, #0x21
    6304:      	b.lo	0x554c <generic_tracepoint_arg+0xfc>
    6308:      	ldr	w9, [x23, #0x28]
    630c:      	cmp	w9, w8
    6310:      	b.hi	0x554c <generic_tracepoint_arg+0xfc>
    6314:      	ldr	w9, [x23, #0x2c]
    6318:      	cmp	w9, w8
    631c:      	b.hs	0x56e8 <generic_tracepoint_arg+0x298>
    6320:      	b	0x554c <generic_tracepoint_arg+0xfc>
    6324:      	cmp	w9, #0xc
    6328:      	b.eq	0x6334 <generic_tracepoint_arg+0xee4>
    632c:      	cmp	w9, #0xa
    6330:      	b.ne	0x6cfc <generic_tracepoint_arg+0x18ac>
    6334:      	ldr	x11, [x25]
    6338:      	cmp	x11, x10
    633c:      	b.gt	0x56e8 <generic_tracepoint_arg+0x298>
    6340:      	b	0x6d18 <generic_tracepoint_arg+0x18c8>
    6344:      	and	w8, w29, #0xffff
    6348:      	cmp	w8, #0x90
    634c:      	b.hi	0x68e4 <generic_tracepoint_arg+0x1494>
    6350:      	and	w8, w29, #0xff
    6354:      	mov	w9, #0xab               // =171
    6358:      	tst	w29, #0xffff
    635c:      	mul	w8, w8, w9
    6360:      	mov	w9, #0x18               // =24
    6364:      	lsr	w8, w8, #12
    6368:      	msub	w8, w8, w9, w29
    636c:      	b.eq	0x6380 <generic_tracepoint_arg+0xf30>
    6370:      	tst	w8, #0xff
    6374:      	mov	w9, w29
    6378:      	mov	w11, w29
    637c:      	b.eq	0x639c <generic_tracepoint_arg+0xf4c>
    6380:      	sub	w8, w29, w8, uxtb
    6384:      	and	w9, w8, #0xffff
    6388:      	add	w8, w8, #0x18
    638c:      	and	w11, w8, #0xffff
    6390:      	cmp	w9, #0x78
    6394:      	b.hi	0x78a0 <generic_tracepoint_arg+0x2450>
    6398:      	mov	w9, w11
    639c:      	and	w8, w9, #0xff
    63a0:      	mov	w9, #0xab               // =171
    63a4:      	mul	w8, w8, w9
    63a8:      	lsr	w8, w8, #12
    63ac:      	sub	w10, w8, #0x1
    63b0:      	b	0x78f0 <generic_tracepoint_arg+0x24a0>
    63b4:      	cmp	w8, #0x20
    63b8:      	b.gt	0x69d0 <generic_tracepoint_arg+0x1580>
    63bc:      	cmp	w8, #0x1a
    63c0:      	b.eq	0x6b44 <generic_tracepoint_arg+0x16f4>
    63c4:      	cmp	w8, #0x1b
    63c8:      	b.ne	0x87d4 <generic_tracepoint_arg+0x3384>
    63cc:      	ldr	w8, [x23, #0x10]
    63d0:      	str	wzr, [sp, #0x88]
    63d4:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    63d8:      	add	x9, sp, #0x60
    63dc:      	add	x1, sp, #0x60
    63e0:      	mov	w19, #0x1               // =1
    63e4:      	str	w8, [sp, #0x60]
    63e8:      	mov	w8, #0x1                // =1
    63ec:      	ldr	x0, [x0]
    63f0:      	blr	x8
    63f4:      	mov	x22, xzr
    63f8:      	cbz	w25, 0x87d0 <generic_tracepoint_arg+0x3380>
    63fc:      	cbz	x0, 0x87d0 <generic_tracepoint_arg+0x3380>
    6400:      	mov	x22, x0
    6404:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    6408:      	mov	w8, #0x1                // =1
    640c:      	ldr	x0, [x0]
    6410:      	add	x9, sp, #0x88
    6414:      	add	x1, sp, #0x88
    6418:      	blr	x8
    641c:      	cbz	x0, 0x87cc <generic_tracepoint_arg+0x337c>
    6420:      	cmp	w25, #0x7f
    6424:      	mov	w9, #0x7f               // =127
    6428:      	mov	x1, x0
    642c:      	mov	x8, xzr
    6430:      	sub	x11, x19, x25
    6434:      	sub	w12, w25, #0x2
    6438:      	sub	w13, w25, #0x1
    643c:      	csel	w9, w25, w9, lo
    6440:      	lsl	w10, w9, #3
    6444:      	mov	x9, x0
    6448:      	str	w10, [x9], #0x5
    644c:      	neg	x10, x25
    6450:      	add	w14, w13, w8
    6454:      	cmp	x11, x8
    6458:      	and	x14, x14, #0xfff
    645c:      	ldrb	w14, [x29, x14]
    6460:      	sturb	w14, [x9, #-0x1]
    6464:      	b.eq	0x648c <generic_tracepoint_arg+0x103c>
    6468:      	cmn	x8, #0x7e
    646c:      	b.eq	0x648c <generic_tracepoint_arg+0x103c>
    6470:      	add	w14, w12, w8
    6474:      	sub	x8, x8, #0x2
    6478:      	and	x14, x14, #0xfff
    647c:      	cmp	x10, x8
    6480:      	ldrb	w14, [x29, x14]
    6484:      	strb	w14, [x9], #0x2
    6488:      	b.ne	0x6450 <generic_tracepoint_arg+0x1000>
    648c:      	mov	w8, #0x1                // =1
    6490:      	mov	x0, x22
    6494:      	b	0x87bc <generic_tracepoint_arg+0x336c>
    6498:      	mov	x22, xzr
    649c:      	ldp	x16, x15, [sp, #0x40]
    64a0:      	mov	w2, #0x5ea0             // =24224
    64a4:      	mov	w12, #0x1               // =1
    64a8:      	ldr	x17, [sp, #0x38]
    64ac:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    64b0:      	ldp	w11, w8, [x23, #0x10]
    64b4:      	cmp	w9, #0xc
    64b8:      	b.hi	0x6ff8 <generic_tracepoint_arg+0x1ba8>
    64bc:      	lsl	w10, w12, w9
    64c0:      	mov	w13, #0x1402            // =5122
    64c4:      	tst	w10, w13
    64c8:      	b.eq	0x6ff8 <generic_tracepoint_arg+0x1ba8>
    64cc:      	ldr	w10, [x25]
    64d0:      	cmp	w11, w10
    64d4:      	ccmp	w10, w8, #0x0, le
    64d8:      	cset	w8, le
    64dc:      	b	0x7008 <generic_tracepoint_arg+0x1bb8>
    64e0:      	cmp	w8, #0x1c
    64e4:      	b.eq	0x6b08 <generic_tracepoint_arg+0x16b8>
    64e8:      	mov	x25, x10
    64ec:      	cmp	w8, #0x1a
    64f0:      	b.eq	0x6a50 <generic_tracepoint_arg+0x1600>
    64f4:      	b	0x554c <generic_tracepoint_arg+0xfc>
    64f8:      	cmp	w8, #0x12
    64fc:      	b.eq	0x651c <generic_tracepoint_arg+0x10cc>
    6500:      	cmp	w8, #0x13
    6504:      	b.ne	0x56e4 <generic_tracepoint_arg+0x294>
    6508:      	ldrh	w29, [x25, #0x22]
    650c:      	mov	w11, wzr
    6510:      	mov	w13, wzr
    6514:      	mov	x19, xzr
    6518:      	b	0x656c <generic_tracepoint_arg+0x111c>
    651c:      	ldrh	w29, [x25, #0x20]
    6520:      	mov	w11, wzr
    6524:      	mov	w13, wzr
    6528:      	mov	x19, xzr
    652c:      	b	0x656c <generic_tracepoint_arg+0x111c>
    6530:      	cmp	w8, #0x1c
    6534:      	b.eq	0x6c70 <generic_tracepoint_arg+0x1820>
    6538:      	cmp	w8, #0x1d
    653c:      	b.ne	0x56e4 <generic_tracepoint_arg+0x294>
    6540:      	cmp	w9, #0x7
    6544:      	b.ne	0x71a4 <generic_tracepoint_arg+0x1d54>
    6548:      	cbnz	x10, 0x71b4 <generic_tracepoint_arg+0x1d64>
    654c:      	mov	x19, xzr
    6550:      	b	0x71c8 <generic_tracepoint_arg+0x1d78>
    6554:      	ldp	w11, w13, [x25, #0x10]
    6558:      	ldr	x19, [x25, #0x18]
    655c:      	b	0x6568 <generic_tracepoint_arg+0x1118>
    6560:      	ldp	w11, w13, [x25]
    6564:      	ldr	x19, [x25, #0x8]
    6568:      	mov	x29, xzr
    656c:      	mov	x22, xzr
    6570:      	cmp	w8, #0x11
    6574:      	b.gt	0x65a0 <generic_tracepoint_arg+0x1150>
    6578:      	sub	w9, w8, #0xd
    657c:      	cmp	w9, #0x2
    6580:      	b.lo	0x65cc <generic_tracepoint_arg+0x117c>
    6584:      	ldr	x19, [sp, #0x30]
    6588:      	sub	w9, w8, #0xf
    658c:      	cmp	w9, #0x2
    6590:      	b.lo	0x67b8 <generic_tracepoint_arg+0x1368>
    6594:      	cmp	w8, #0x11
    6598:      	b.eq	0x6c74 <generic_tracepoint_arg+0x1824>
    659c:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    65a0:      	cmp	w8, #0x19
    65a4:      	b.hi	0x67a8 <generic_tracepoint_arg+0x1358>
    65a8:      	lsl	w9, w12, w8
    65ac:      	mov	w10, #0x500000          // =5242880
    65b0:      	tst	w9, w10
    65b4:      	b.ne	0x68a4 <generic_tracepoint_arg+0x1454>
    65b8:      	mov	w10, #0xa00000          // =10485760
    65bc:      	tst	w9, w10
    65c0:      	b.ne	0x68b4 <generic_tracepoint_arg+0x1464>
    65c4:      	tst	w9, #0x3000000
    65c8:      	b.eq	0x67a8 <generic_tracepoint_arg+0x1358>
    65cc:      	ldrh	w8, [x25, #0x26]
    65d0:      	cmp	w8, #0xa
    65d4:      	b.eq	0x68f4 <generic_tracepoint_arg+0x14a4>
    65d8:      	cmp	w8, #0x2
    65dc:      	b.ne	0x6980 <generic_tracepoint_arg+0x1530>
    65e0:      	ldr	w8, [x23, #0x10]
    65e4:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    65e8:      	add	x9, sp, #0xac
    65ec:      	add	x1, sp, #0xac
    65f0:      	str	w8, [sp, #0xac]
    65f4:      	mov	w8, #0x1                // =1
    65f8:      	mov	w22, w11
    65fc:      	ldr	x0, [x0]
    6600:      	blr	x8
    6604:      	ldr	x19, [sp, #0x30]
    6608:      	cbz	x0, 0x72b0 <generic_tracepoint_arg+0x1e60>
    660c:      	mov	w8, #0x20               // =32
    6610:      	add	x1, sp, #0x88
    6614:      	stp	w8, w22, [sp, #0x88]
    6618:      	b	0x693c <generic_tracepoint_arg+0x14ec>
    661c:      	cmp	w9, #0xc
    6620:      	b.hi	0x72e4 <generic_tracepoint_arg+0x1e94>
    6624:      	lsl	w11, w12, w9
    6628:      	mov	w13, #0x1402            // =5122
    662c:      	tst	w11, w13
    6630:      	b.eq	0x72e4 <generic_tracepoint_arg+0x1e94>
    6634:      	ldr	w11, [x25]
    6638:      	cmp	w11, w10
    663c:      	b.gt	0x56e8 <generic_tracepoint_arg+0x298>
    6640:      	b	0x7300 <generic_tracepoint_arg+0x1eb0>
    6644:      	mov	x19, xzr
    6648:      	mov	w22, wzr
    664c:      	add	x8, x23, #0x10
    6650:      	str	x8, [sp, #0x28]
    6654:      	ldr	x8, [sp, #0x28]
    6658:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    665c:      	add	x9, sp, #0x60
    6660:      	add	x1, sp, #0x60
    6664:      	ldr	w8, [x8, x19, lsl #2]
    6668:      	str	w8, [sp, #0x60]
    666c:      	mov	w8, #0x1                // =1
    6670:      	ldr	x0, [x0]
    6674:      	blr	x8
    6678:      	cbz	x0, 0x66f8 <generic_tracepoint_arg+0x12a8>
    667c:      	cbz	w29, 0x66d8 <generic_tracepoint_arg+0x1288>
    6680:      	mov	x8, xzr
    6684:      	mov	x9, x25
    6688:      	mov	x10, x29
    668c:      	b	0x66a4 <generic_tracepoint_arg+0x1254>
    6690:      	add	x8, x8, #0x1
    6694:      	sub	x10, x10, #0x1
    6698:      	add	x9, x9, #0x1
    669c:      	cmp	x8, x29
    66a0:      	b.eq	0x66d8 <generic_tracepoint_arg+0x1288>
    66a4:      	mov	x11, xzr
    66a8:      	cmp	x10, x11
    66ac:      	b.eq	0x6690 <generic_tracepoint_arg+0x1240>
    66b0:      	ldrb	w12, [x0, x11]
    66b4:      	cbz	w12, 0x66d4 <generic_tracepoint_arg+0x1284>
    66b8:      	cmp	x11, #0x62
    66bc:      	b.hi	0x6690 <generic_tracepoint_arg+0x1240>
    66c0:      	ldrb	w13, [x9, x11]
    66c4:      	add	x11, x11, #0x1
    66c8:      	cmp	w13, w12
    66cc:      	b.eq	0x66a8 <generic_tracepoint_arg+0x1258>
    66d0:      	b	0x6690 <generic_tracepoint_arg+0x1240>
    66d4:      	tbz	w8, #0x1f, 0x6f18 <generic_tracepoint_arg+0x1ac8>
    66d8:      	ldr	w9, [x23, #0x8]
    66dc:      	add	w8, w22, #0xc
    66e0:      	cmp	w8, w9
    66e4:      	b.hs	0x66f8 <generic_tracepoint_arg+0x12a8>
    66e8:      	add	x19, x19, #0x1
    66ec:      	add	w22, w22, #0x4
    66f0:      	cmp	x19, #0x64
    66f4:      	b.ne	0x6654 <generic_tracepoint_arg+0x1204>
    66f8:      	mov	x22, xzr
    66fc:      	ldr	x19, [sp, #0x30]
    6700:      	ldp	x16, x15, [sp, #0x40]
    6704:      	mov	w2, #0x5ea0             // =24224
    6708:      	ldr	x17, [sp, #0x38]
    670c:      	mov	w12, #0x1               // =1
    6710:      	ldr	w8, [x23, #0x4]
    6714:      	cmp	w8, #0x25
    6718:      	b.hi	0x56e4 <generic_tracepoint_arg+0x294>
    671c:      	mov	x9, #0x50               // =80
    6720:      	lsl	x8, x12, x8
    6724:      	movk	x9, #0xc00, lsl #16
    6728:      	movk	x9, #0x20, lsl #32
    672c:      	tst	x8, x9
    6730:      	b.ne	0x8808 <generic_tracepoint_arg+0x33b8>
    6734:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    6738:      	and	w8, w29, #0xffff
    673c:      	cmp	w8, #0x90
    6740:      	b.hi	0x6cec <generic_tracepoint_arg+0x189c>
    6744:      	and	w8, w29, #0xff
    6748:      	mov	w9, #0xab               // =171
    674c:      	tst	w29, #0xffff
    6750:      	mul	w8, w8, w9
    6754:      	mov	w9, #0x18               // =24
    6758:      	lsr	w8, w8, #12
    675c:      	msub	w8, w8, w9, w29
    6760:      	b.eq	0x6774 <generic_tracepoint_arg+0x1324>
    6764:      	tst	w8, #0xff
    6768:      	mov	w9, w29
    676c:      	mov	w11, w29
    6770:      	b.eq	0x6790 <generic_tracepoint_arg+0x1340>
    6774:      	sub	w8, w29, w8, uxtb
    6778:      	and	w9, w8, #0xffff
    677c:      	add	w8, w8, #0x18
    6780:      	and	w11, w8, #0xffff
    6784:      	cmp	w9, #0x78
    6788:      	b.hi	0x7d6c <generic_tracepoint_arg+0x291c>
    678c:      	mov	w9, w11
    6790:      	and	w8, w9, #0xff
    6794:      	mov	w9, #0xab               // =171
    6798:      	mul	w8, w8, w9
    679c:      	lsr	w8, w8, #12
    67a0:      	sub	w10, w8, #0x1
    67a4:      	b	0x7dbc <generic_tracepoint_arg+0x296c>
    67a8:      	ldr	x19, [sp, #0x30]
    67ac:      	sub	w8, w8, #0x12
    67b0:      	cmp	w8, #0x2
    67b4:      	b.hs	0x56e4 <generic_tracepoint_arg+0x294>
    67b8:      	ldrb	w8, [x23, #0x10]
    67bc:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    67c0:      	add	x9, sp, #0xac
    67c4:      	add	x1, sp, #0xac
    67c8:      	str	w8, [sp, #0xac]
    67cc:      	mov	w8, #0x1                // =1
    67d0:      	ldr	x0, [x0]
    67d4:      	blr	x8
    67d8:      	cbz	x0, 0x6ce0 <generic_tracepoint_arg+0x1890>
    67dc:      	str	x29, [sp, #0x88]
    67e0:      	mov	w8, #0x1                // =1
    67e4:      	add	x9, sp, #0x88
    67e8:      	add	x1, sp, #0x88
    67ec:      	b	0x6ca8 <generic_tracepoint_arg+0x1858>
    67f0:      	cmp	w8, #0x1
    67f4:      	b.eq	0x6f20 <generic_tracepoint_arg+0x1ad0>
    67f8:      	cmp	w8, #0x2
    67fc:      	b.ne	0x6f2c <generic_tracepoint_arg+0x1adc>
    6800:      	ldrb	w10, [x25]
    6804:      	cmp	w9, w10
    6808:      	b.hi	0x56e8 <generic_tracepoint_arg+0x298>
    680c:      	b	0x6f2c <generic_tracepoint_arg+0x1adc>
    6810:      	cmp	w8, #0x1
    6814:      	b.eq	0x6f60 <generic_tracepoint_arg+0x1b10>
    6818:      	cmp	w8, #0x2
    681c:      	b.ne	0x6f6c <generic_tracepoint_arg+0x1b1c>
    6820:      	ldrh	w10, [x25]
    6824:      	cmp	w9, w10
    6828:      	b.hi	0x56e8 <generic_tracepoint_arg+0x298>
    682c:      	b	0x6f6c <generic_tracepoint_arg+0x1b1c>
    6830:      	ldrb	w8, [x23, #0x10]
    6834:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    6838:      	add	x9, sp, #0x88
    683c:      	add	x1, sp, #0x88
    6840:      	str	w8, [sp, #0x88]
    6844:      	mov	w8, #0x1                // =1
    6848:      	ldr	x0, [x0]
    684c:      	blr	x8
    6850:      	cbz	x0, 0x6ce0 <generic_tracepoint_arg+0x1890>
    6854:      	ldrb	w8, [x25]
    6858:      	add	x9, sp, #0x60
    685c:      	str	x8, [sp, #0x60]
    6860:      	mov	w8, #0x1                // =1
    6864:      	b	0x689c <generic_tracepoint_arg+0x144c>
    6868:      	ldrb	w8, [x23, #0x10]
    686c:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    6870:      	add	x9, sp, #0x88
    6874:      	add	x1, sp, #0x88
    6878:      	str	w8, [sp, #0x88]
    687c:      	mov	w8, #0x1                // =1
    6880:      	ldr	x0, [x0]
    6884:      	blr	x8
    6888:      	cbz	x0, 0x6ce0 <generic_tracepoint_arg+0x1890>
    688c:      	ldrh	w8, [x25]
    6890:      	add	x9, sp, #0x60
    6894:      	str	x8, [sp, #0x60]
    6898:      	mov	w8, #0x1                // =1
    689c:      	add	x1, sp, #0x60
    68a0:      	b	0x6ca8 <generic_tracepoint_arg+0x1858>
    68a4:      	ldr	x19, [sp, #0x30]
    68a8:      	cmp	x29, #0x400
    68ac:      	cset	w22, lo
    68b0:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    68b4:      	ldr	x19, [sp, #0x30]
    68b8:      	cmp	x29, #0x3ff
    68bc:      	cset	w22, hi
    68c0:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    68c4:      	ldp	x16, x15, [sp, #0x40]
    68c8:      	cmp	x0, #0x0
    68cc:      	mov	w2, #0x5ea0             // =24224
    68d0:      	mov	w12, #0x1               // =1
    68d4:      	cset	w8, eq
    68d8:      	ldr	x17, [sp, #0x38]
    68dc:      	mov	w22, w8
    68e0:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    68e4:      	cmp	w8, #0x101
    68e8:      	b.hs	0x6efc <generic_tracepoint_arg+0x1aac>
    68ec:      	mov	w11, #0x100             // =256
    68f0:      	b	0x78a0 <generic_tracepoint_arg+0x2450>
    68f4:      	ldr	w8, [x23, #0x14]
    68f8:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    68fc:      	add	x9, sp, #0xac
    6900:      	add	x1, sp, #0xac
    6904:      	str	w8, [sp, #0xac]
    6908:      	mov	w8, #0x1                // =1
    690c:      	mov	w25, w13
    6910:      	mov	w22, w11
    6914:      	ldr	x0, [x0]
    6918:      	blr	x8
    691c:      	cbz	x0, 0x72b8 <generic_tracepoint_arg+0x1e68>
    6920:      	mov	w8, #0x80               // =128
    6924:      	stp	w25, w19, [sp, #0x90]
    6928:      	add	x1, sp, #0x88
    692c:      	stp	w8, w22, [sp, #0x88]
    6930:      	lsr	x8, x19, #32
    6934:      	ldr	x19, [sp, #0x30]
    6938:      	str	w8, [sp, #0x98]
    693c:      	mov	w8, #0x1                // =1
    6940:      	blr	x8
    6944:      	ldr	w8, [x23, #0x4]
    6948:      	sub	w9, w8, #0x18
    694c:      	cmp	w9, #0x2
    6950:      	b.lo	0x6f10 <generic_tracepoint_arg+0x1ac0>
    6954:      	sub	w8, w8, #0xd
    6958:      	mov	w12, #0x1               // =1
    695c:      	cmp	w8, #0x1
    6960:      	b.hi	0x5f20 <generic_tracepoint_arg+0xad0>
    6964:      	cmp	x0, #0x0
    6968:      	cset	w8, ne
    696c:      	ldp	x16, x15, [sp, #0x40]
    6970:      	mov	w2, #0x5ea0             // =24224
    6974:      	mov	w22, w8
    6978:      	ldr	x17, [sp, #0x38]
    697c:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    6980:      	ldr	x19, [sp, #0x30]
    6984:      	mov	w8, wzr
    6988:      	mov	w22, wzr
    698c:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    6990:      	cmp	w8, #0x1e
    6994:      	b.ne	0x554c <generic_tracepoint_arg+0xfc>
    6998:      	ldr	w8, [x23, #0x10]
    699c:      	and	x8, x8, #0x7
    69a0:      	add	x9, x20, x8, lsl #2
    69a4:      	ldr	w9, [x9, x2]
    69a8:      	cbnz	w9, 0x554c <generic_tracepoint_arg+0xfc>
    69ac:      	add	x8, x20, x8, lsl #3
    69b0:      	ldr	x9, [x25]
    69b4:      	ldr	x8, [x8, #0x5e78]
    69b8:      	and	x8, x8, #0x7ff
    69bc:      	add	x8, x20, x8
    69c0:      	ldr	x8, [x8, #0x90]
    69c4:      	bics	xzr, x8, x9
    69c8:      	cset	w22, ne
    69cc:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    69d0:      	cmp	w8, #0x21
    69d4:      	b.eq	0x7044 <generic_tracepoint_arg+0x1bf4>
    69d8:      	cmp	w8, #0x22
    69dc:      	b.ne	0x87d4 <generic_tracepoint_arg+0x3384>
    69e0:      	mov	w19, #0x10              // =16
    69e4:      	ldr	w8, [x23, x19]
    69e8:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    69ec:      	add	x9, sp, #0x60
    69f0:      	add	x1, sp, #0x60
    69f4:      	str	w8, [sp, #0x60]
    69f8:      	mov	w8, #0x1                // =1
    69fc:      	ldr	x0, [x0]
    6a00:      	blr	x8
    6a04:      	cbz	x0, 0x87cc <generic_tracepoint_arg+0x337c>
    6a08:      	mov	x1, x0
    6a0c:      	mov	x0, x29
    6a10:      	mov	x2, x25
    6a14:      	bl	0x6a14 <generic_tracepoint_arg+0x15c4>
    6a18:      	tbz	w0, #0x1f, 0x7824 <generic_tracepoint_arg+0x23d4>
    6a1c:      	ldr	w8, [x23, #0x8]
    6a20:      	add	x19, x19, #0x4
    6a24:      	mov	w12, #0x1               // =1
    6a28:      	mov	x22, xzr
    6a2c:      	sub	w9, w19, #0x8
    6a30:      	cmp	w9, w8
    6a34:      	b.hs	0x87d4 <generic_tracepoint_arg+0x3384>
    6a38:      	cmp	x19, #0x1a0
    6a3c:      	b.ne	0x69e4 <generic_tracepoint_arg+0x1594>
    6a40:      	b	0x87d4 <generic_tracepoint_arg+0x3384>
    6a44:      	mov	x25, x10
    6a48:      	cmp	w8, #0x8
    6a4c:      	b.ne	0x554c <generic_tracepoint_arg+0xfc>
    6a50:      	ldr	w8, [x23, #0x10]
    6a54:      	str	wzr, [sp, #0x88]
    6a58:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    6a5c:      	add	x9, sp, #0x60
    6a60:      	add	x1, sp, #0x60
    6a64:      	str	w8, [sp, #0x60]
    6a68:      	mov	w8, #0x1                // =1
    6a6c:      	ldr	x0, [x0]
    6a70:      	blr	x8
    6a74:      	mov	x22, xzr
    6a78:      	cbz	w29, 0x73e4 <generic_tracepoint_arg+0x1f94>
    6a7c:      	cbz	x0, 0x73e4 <generic_tracepoint_arg+0x1f94>
    6a80:      	mov	x19, x0
    6a84:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    6a88:      	mov	w8, #0x1                // =1
    6a8c:      	ldr	x0, [x0]
    6a90:      	add	x9, sp, #0x88
    6a94:      	add	x1, sp, #0x88
    6a98:      	blr	x8
    6a9c:      	cbz	x0, 0x73dc <generic_tracepoint_arg+0x1f8c>
    6aa0:      	lsl	w9, w29, #3
    6aa4:      	mov	x8, x0
    6aa8:      	mov	x2, x25
    6aac:      	mov	w1, w29
    6ab0:      	str	w9, [x8], #0x4
    6ab4:      	mov	w9, #0x4                // =4
    6ab8:      	mov	x25, x0
    6abc:      	mov	x0, x8
    6ac0:      	blr	x9
    6ac4:      	mov	w8, #0x1                // =1
    6ac8:      	mov	x0, x19
    6acc:      	mov	x1, x25
    6ad0:      	blr	x8
    6ad4:      	cmp	x0, #0x0
    6ad8:      	cset	w22, ne
    6adc:      	b	0x73e0 <generic_tracepoint_arg+0x1f90>
    6ae0:      	mov	w13, #0x100             // =256
    6ae4:      	sub	w8, w13, #0x100
    6ae8:      	ror	w8, w8, #0x8
    6aec:      	cmp	w8, #0x2
    6af0:      	b.gt	0x6ee4 <generic_tracepoint_arg+0x1a94>
    6af4:      	cbz	w8, 0x74cc <generic_tracepoint_arg+0x207c>
    6af8:      	cmp	w8, #0x1
    6afc:      	b.ne	0x74c4 <generic_tracepoint_arg+0x2074>
    6b00:      	mov	w11, #0x7               // =7
    6b04:      	b	0x74d8 <generic_tracepoint_arg+0x2088>
    6b08:      	ldrb	w8, [x23, #0x10]
    6b0c:      	ldrh	w19, [x25]
    6b10:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    6b14:      	add	x9, sp, #0x88
    6b18:      	add	x1, sp, #0x88
    6b1c:      	str	w8, [sp, #0x88]
    6b20:      	mov	w8, #0x1                // =1
    6b24:      	ldr	x0, [x0]
    6b28:      	blr	x8
    6b2c:      	cbz	x0, 0x7258 <generic_tracepoint_arg+0x1e08>
    6b30:      	str	x19, [sp, #0x60]
    6b34:      	mov	w8, #0x1                // =1
    6b38:      	add	x9, sp, #0x60
    6b3c:      	add	x1, sp, #0x60
    6b40:      	b	0x71fc <generic_tracepoint_arg+0x1dac>
    6b44:      	ldr	w8, [x23, #0x10]
    6b48:      	str	wzr, [sp, #0x88]
    6b4c:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    6b50:      	add	x9, sp, #0x60
    6b54:      	add	x1, sp, #0x60
    6b58:      	str	w8, [sp, #0x60]
    6b5c:      	mov	w8, #0x1                // =1
    6b60:      	ldr	x0, [x0]
    6b64:      	blr	x8
    6b68:      	mov	x22, xzr
    6b6c:      	cbz	w25, 0x87d0 <generic_tracepoint_arg+0x3380>
    6b70:      	cbz	x0, 0x87d0 <generic_tracepoint_arg+0x3380>
    6b74:      	mov	x19, x0
    6b78:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    6b7c:      	mov	w8, #0x1                // =1
    6b80:      	ldr	x0, [x0]
    6b84:      	add	x9, sp, #0x88
    6b88:      	add	x1, sp, #0x88
    6b8c:      	blr	x8
    6b90:      	cbz	x0, 0x87cc <generic_tracepoint_arg+0x337c>
    6b94:      	cmp	w25, #0xff
    6b98:      	mov	w8, #0xff               // =255
    6b9c:      	mov	x22, x0
    6ba0:      	mov	x2, x29
    6ba4:      	csel	w1, w25, w8, lo
    6ba8:      	mov	x8, x0
    6bac:      	lsl	w9, w1, #3
    6bb0:      	str	w9, [x8], #0x4
    6bb4:      	mov	w9, #0x4                // =4
    6bb8:      	mov	x0, x8
    6bbc:      	blr	x9
    6bc0:      	mov	w8, #0x1                // =1
    6bc4:      	mov	x0, x19
    6bc8:      	mov	x1, x22
    6bcc:      	b	0x87bc <generic_tracepoint_arg+0x336c>
    6bd0:      	cmp	w25, #0x1, lsl #12      // =0x1000
    6bd4:      	str	wzr, [sp, #0x88]
    6bd8:      	b.ls	0x70f8 <generic_tracepoint_arg+0x1ca8>
    6bdc:      	mov	x22, xzr
    6be0:      	b	0x87d4 <generic_tracepoint_arg+0x3384>
    6be4:      	ldr	x8, [x25]
    6be8:      	cmp	x11, x8
    6bec:      	b.hi	0x6bf8 <generic_tracepoint_arg+0x17a8>
    6bf0:      	cmp	x8, x10
    6bf4:      	b.ls	0x56e8 <generic_tracepoint_arg+0x298>
    6bf8:      	ldr	w10, [x23, #0x8]
    6bfc:      	cmp	w10, #0x19
    6c00:      	b.lo	0x554c <generic_tracepoint_arg+0xfc>
    6c04:      	ldp	x12, x11, [x23, #0x20]
    6c08:      	cmp	w9, #0xc
    6c0c:      	b.eq	0x6c18 <generic_tracepoint_arg+0x17c8>
    6c10:      	cmp	w9, #0xa
    6c14:      	b.ne	0x7268 <generic_tracepoint_arg+0x1e18>
    6c18:      	cmp	x12, x8
    6c1c:      	mov	w12, #0x1               // =1
    6c20:      	b.gt	0x727c <generic_tracepoint_arg+0x1e2c>
    6c24:      	cmp	x8, x11
    6c28:      	b.le	0x56e8 <generic_tracepoint_arg+0x298>
    6c2c:      	b	0x727c <generic_tracepoint_arg+0x1e2c>
    6c30:      	ldr	x10, [x25]
    6c34:      	cmp	x11, x10
    6c38:      	ccmp	x10, x8, #0x2, ls
    6c3c:      	cset	w8, ls
    6c40:      	ldr	w11, [x23, #0x8]
    6c44:      	cmp	w11, #0x19
    6c48:      	b.lo	0x7cd8 <generic_tracepoint_arg+0x2888>
    6c4c:      	ldp	x13, x12, [x23, #0x20]
    6c50:      	cmp	w9, #0xc
    6c54:      	b.eq	0x6c60 <generic_tracepoint_arg+0x1810>
    6c58:      	cmp	w9, #0xa
    6c5c:      	b.ne	0x7168 <generic_tracepoint_arg+0x1d18>
    6c60:      	cmp	x13, x10
    6c64:      	ccmp	x10, x12, #0x0, le
    6c68:      	cset	w12, le
    6c6c:      	b	0x7174 <generic_tracepoint_arg+0x1d24>
    6c70:      	ldrh	w22, [x25, #0x26]
    6c74:      	ldrb	w8, [x23, #0x10]
    6c78:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0xbb0>
    6c7c:      	add	x9, sp, #0xac
    6c80:      	add	x1, sp, #0xac
    6c84:      	str	w8, [sp, #0xac]
    6c88:      	mov	w8, #0x1                // =1
    6c8c:      	ldr	x0, [x0]
    6c90:      	blr	x8
    6c94:      	cbz	x0, 0x6ce0 <generic_tracepoint_arg+0x1890>
    6c98:      	str	x22, [sp, #0x88]
    6c9c:      	mov	w8, #0x1                // =1
    6ca0:      	add	x9, sp, #0x88
    6ca4:      	add	x1, sp, #0x88
    6ca8:      	blr	x8
    6cac:      	ldr	w9, [x23, #0x4]
    6cb0:      	mov	w8, wzr
    6cb4:      	mov	w12, #0x1               // =1
    6cb8:      	cmp	w9, #0x1d
    6cbc:      	b.hi	0x7244 <generic_tracepoint_arg+0x1df4>
    6cc0:      	mov	w10, #0x8400            // =33792
    6cc4:      	lsl	w9, w12, w9
    6cc8:      	movk	w10, #0x3003, lsl #16
    6ccc:      	tst	w9, w10
    6cd0:      	b.eq	0x722c <generic_tracepoint_arg+0x1ddc>
    6cd4:      	cmp	x0, #0x0
    6cd8:      	cset	w8, ne
    6cdc:      	b	0x7244 <generic_tracepoint_arg+0x1df4>
    6ce0:      	mov	x22, xzr
    6ce4:      	mov	w12, #0x1               // =1
    6ce8:      	b	0x7248 <generic_tracepoint_arg+0x1df8>
    6cec:      	cmp	w8, #0x101
    6cf0:      	b.hs	0x73c8 <generic_tracepoint_arg+0x1f78>
    6cf4:      	mov	w11, #0x100             // =256
    6cf8:      	b	0x7d6c <generic_tracepoint_arg+0x291c>
    6cfc:      	ldr	x11, [x25]
    6d00:      	cmp	x11, x10
    6d04:      	b.hi	0x56e8 <generic_tracepoint_arg+0x298>
    6d08:      	b	0x6d18 <generic_tracepoint_arg+0x18c8>
    6d0c:      	ldr	x11, [x25]
    6d10:      	cmp	x11, x10
    6d14:      	b.lo	0x56e8 <generic_tracepoint_arg+0x298>
    6d18:      	ldr	w10, [x23, #0x8]
    6d1c:      	cmp	w10, #0x11
    6d20:      	b.lo	0x8844 <generic_tracepoint_arg+0x33f4>
    6d24:      	ldr	x11, [x23, #0x18]
    6d28:      	cmp	w8, #0x2
    6d2c:      	b.le	0x6d50 <generic_tracepoint_arg+0x1900>
    6d30:      	sub	w12, w8, #0x3
    6d34:      	cmp	w12, #0x2
    6d38:      	b.hs	0x6d84 <generic_tracepoint_arg+0x1934>
    6d3c:      	ldr	x12, [x25]
    6d40:      	cmp	x12, x11
    6d44:      	mov	w12, #0x1               // =1
    6d48:      	b.eq	0x56dc <generic_tracepoint_arg+0x28c>
    6d4c:      	b	0x776c <generic_tracepoint_arg+0x231c>
    6d50:      	cmp	w8, #0x1
    6d54:      	b.eq	0x6e30 <generic_tracepoint_arg+0x19e0>
    6d58:      	cmp	w8, #0x2
    6d5c:      	b.ne	0x776c <generic_tracepoint_arg+0x231c>
    6d60:      	cmp	w9, #0xc
    6d64:      	b.eq	0x6d70 <generic_tracepoint_arg+0x1920>
    6d68:      	cmp	w9, #0xa
    6d6c:      	b.ne	0x775c <generic_tracepoint_arg+0x230c>
    6d70:      	ldr	x12, [x25]
    6d74:      	cmp	x12, x11
    6d78:      	mov	w12, #0x1               // =1
    6d7c:      	b.lt	0x56e8 <generic_tracepoint_arg+0x298>
    6d80:      	b	0x776c <generic_tracepoint_arg+0x231c>
    6d84:      	cmp	w8, #0xc
    6d88:      	mov	w12, #0x1               // =1
    6d8c:      	b.ne	0x776c <generic_tracepoint_arg+0x231c>
    6d90:      	ldr	x12, [x25]
    6d94:      	tst	x12, x11
    6d98:      	mov	w12, #0x1               // =1
    6d9c:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    6da0:      	b	0x776c <generic_tracepoint_arg+0x231c>
    6da4:      	cmp	w8, #0xc
    6da8:      	b.ne	0x6f2c <generic_tracepoint_arg+0x1adc>
    6dac:      	ldrb	w10, [x25]
    6db0:      	tst	w9, w10
    6db4:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    6db8:      	b	0x6f2c <generic_tracepoint_arg+0x1adc>
    6dbc:      	cmp	w8, #0xc
    6dc0:      	b.ne	0x6f6c <generic_tracepoint_arg+0x1b1c>
    6dc4:      	ldrh	w10, [x25]
    6dc8:      	tst	w9, w10
    6dcc:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    6dd0:      	b	0x6f6c <generic_tracepoint_arg+0x1b1c>
    6dd4:      	ldr	w9, [x23, #0x8]
    6dd8:      	cmp	w9, #0xd
    6ddc:      	b.lo	0x5c0c <generic_tracepoint_arg+0x7bc>
    6de0:      	ldr	w10, [x23, #0x14]
    6de4:      	cbz	w10, 0x5c0c <generic_tracepoint_arg+0x7bc>
    6de8:      	cmp	w10, w8
    6dec:      	b.eq	0x5a50 <generic_tracepoint_arg+0x600>
    6df0:      	cmp	w9, #0x11
    6df4:      	b.lo	0x5c0c <generic_tracepoint_arg+0x7bc>
    6df8:      	ldr	w10, [x23, #0x18]
    6dfc:      	cbz	w10, 0x5c0c <generic_tracepoint_arg+0x7bc>
    6e00:      	cmp	w10, w8
    6e04:      	b.eq	0x5a50 <generic_tracepoint_arg+0x600>
    6e08:      	cmp	w9, #0x15
    6e0c:      	b.lo	0x6e24 <generic_tracepoint_arg+0x19d4>
    6e10:      	ldr	w9, [x23, #0x1c]
    6e14:      	cbz	w9, 0x6e24 <generic_tracepoint_arg+0x19d4>
    6e18:      	cmp	w9, w8
    6e1c:      	cset	w22, eq
    6e20:      	b	0x6e28 <generic_tracepoint_arg+0x19d8>
    6e24:      	mov	x22, xzr
    6e28:      	ldr	x19, [sp, #0x30]
    6e2c:      	b	0x8234 <generic_tracepoint_arg+0x2de4>
    6e30:      	cmp	w9, #0xc
    6e34:      	b.eq	0x6e40 <generic_tracepoint_arg+0x19f0>
    6e38:      	cmp	w9, #0xa
    6e3c:      	b.ne	0x7748 <generic_tracepoint_arg+0x22f8>
    6e40:      	ldr	x12, [x25]
    6e44:      	cmp	x12, x11
    6e48:      	mov	w12, #0x1               // =1
    6e4c:      	b.gt	0x56e8 <generic_tracepoint_arg+0x298>
    6e50:      	b	0x776c <generic_tracepoint_arg+0x231c>
    6e54:      	ldp	w8, w11, [x23, #0x10]
    6e58:      	ldrb	w9, [x25]
    6e5c:      	cmp	w8, w9
    6e60:      	ldr	w10, [x23, #0x8]
    6e64:      	ccmp	w11, w9, #0x0, ls
    6e68:      	cset	w8, hs
    6e6c:      	cmp	w10, #0x11
    6e70:      	b.lo	0x7fac <generic_tracepoint_arg+0x2b5c>
    6e74:      	b	0x6e98 <generic_tracepoint_arg+0x1a48>
    6e78:      	ldp	w8, w11, [x23, #0x10]
    6e7c:      	ldrh	w9, [x25]
    6e80:      	cmp	w8, w9
    6e84:      	ldr	w10, [x23, #0x8]
    6e88:      	ccmp	w11, w9, #0x0, ls
    6e8c:      	cset	w8, hs
    6e90:      	cmp	w10, #0x11
    6e94:      	b.lo	0x7fac <generic_tracepoint_arg+0x2b5c>
    6e98:      	ldp	w11, w12, [x23, #0x18]
    6e9c:      	cmp	w11, w9
    6ea0:      	ccmp	w12, w9, #0x0, ls
    6ea4:      	mov	w12, #0x1               // =1
    6ea8:      	csinc	w8, w8, wzr, lo
    6eac:      	cmp	w10, #0x19
    6eb0:      	b.lo	0x7fac <generic_tracepoint_arg+0x2b5c>
    6eb4:      	ldp	w11, w12, [x23, #0x20]
    6eb8:      	cmp	w11, w9
    6ebc:      	ccmp	w12, w9, #0x0, ls
    6ec0:      	mov	w12, #0x1               // =1
    6ec4:      	csinc	w8, w8, wzr, lo
    6ec8:      	cmp	w10, #0x21
    6ecc:      	b.lo	0x7fac <generic_tracepoint_arg+0x2b5c>
    6ed0:      	ldp	w10, w11, [x23, #0x28]
    6ed4:      	cmp	w10, w9
    6ed8:      	ccmp	w11, w9, #0x0, ls
    6edc:      	csinc	w8, w8, wzr, lo
    6ee0:      	b	0x7fac <generic_tracepoint_arg+0x2b5c>
    6ee4:      	cmp	w8, #0x3
    6ee8:      	b.eq	0x74d4 <generic_tracepoint_arg+0x2084>
    6eec:      	cmp	w8, #0x7
    6ef0:      	b.ne	0x74c4 <generic_tracepoint_arg+0x2074>
    6ef4:      	mov	w11, #0x9               // =9
    6ef8:      	b	0x74d8 <generic_tracepoint_arg+0x2088>
    6efc:      	and	w8, w29, #0xffff
    6f00:      	cmp	w8, #0x201
    6f04:      	b.hs	0x745c <generic_tracepoint_arg+0x200c>
    6f08:      	mov	w11, #0x200             // =512
    6f0c:      	b	0x78a0 <generic_tracepoint_arg+0x2450>
    6f10:      	cmp	x0, #0x0
    6f14:      	b	0x72c8 <generic_tracepoint_arg+0x1e78>
    6f18:      	mov	w22, #0x1               // =1
    6f1c:      	b	0x66fc <generic_tracepoint_arg+0x12ac>
    6f20:      	ldrb	w10, [x25]
    6f24:      	cmp	w9, w10
    6f28:      	b.lo	0x56e8 <generic_tracepoint_arg+0x298>
    6f2c:      	ldr	w9, [x23, #0x8]
    6f30:      	cmp	w9, #0xd
    6f34:      	b.lo	0x8844 <generic_tracepoint_arg+0x33f4>
    6f38:      	ldr	w10, [x23, #0x14]
    6f3c:      	cmp	w8, #0x2
    6f40:      	b.le	0x741c <generic_tracepoint_arg+0x1fcc>
    6f44:      	sub	w11, w8, #0x3
    6f48:      	cmp	w11, #0x2
    6f4c:      	b.hs	0x77f4 <generic_tracepoint_arg+0x23a4>
    6f50:      	ldrb	w11, [x25]
    6f54:      	cmp	w10, w11
    6f58:      	b.eq	0x56dc <generic_tracepoint_arg+0x28c>
    6f5c:      	b	0x7aa8 <generic_tracepoint_arg+0x2658>
    6f60:      	ldrh	w10, [x25]
    6f64:      	cmp	w9, w10
    6f68:      	b.lo	0x56e8 <generic_tracepoint_arg+0x298>
    6f6c:      	ldr	w9, [x23, #0x8]
    6f70:      	cmp	w9, #0xd
    6f74:      	b.lo	0x8844 <generic_tracepoint_arg+0x33f4>
    6f78:      	ldr	w10, [x23, #0x14]
    6f7c:      	cmp	w8, #0x2
    6f80:      	b.le	0x743c <generic_tracepoint_arg+0x1fec>
    6f84:      	sub	w11, w8, #0x3
    6f88:      	cmp	w11, #0x2
    6f8c:      	b.hs	0x780c <generic_tracepoint_arg+0x23bc>
    6f90:      	ldrh	w11, [x25]
    6f94:      	cmp	w10, w11
    6f98:      	b.eq	0x56dc <generic_tracepoint_arg+0x28c>
    6f9c:      	b	0x7ae4 <generic_tracepoint_arg+0x2694>
    6fa0:      	ldr	w8, [x25]
    6fa4:      	cmp	w11, w8
    6fa8:      	b.hi	0x6fb4 <generic_tracepoint_arg+0x1b64>
    6fac:      	cmp	w8, w10
    6fb0:      	b.ls	0x56e8 <generic_tracepoint_arg+0x298>
    6fb4:      	ldr	w10, [x23, #0x8]
    6fb8:      	cmp	w10, #0x11
    6fbc:      	b.lo	0x554c <generic_tracepoint_arg+0xfc>
    6fc0:      	ldp	w12, w11, [x23, #0x18]
    6fc4:      	mov	w13, #0x1               // =1
    6fc8:      	cmp	w9, #0xc
    6fcc:      	b.hi	0x7664 <generic_tracepoint_arg+0x2214>
    6fd0:      	lsl	w13, w13, w9
    6fd4:      	mov	w14, #0x1402            // =5122
    6fd8:      	tst	w13, w14
    6fdc:      	b.eq	0x7664 <generic_tracepoint_arg+0x2214>
    6fe0:      	cmp	w12, w8
    6fe4:      	mov	w12, #0x1               // =1
    6fe8:      	b.gt	0x7678 <generic_tracepoint_arg+0x2228>
    6fec:      	cmp	w8, w11
    6ff0:      	b.le	0x56e8 <generic_tracepoint_arg+0x298>
    6ff4:      	b	0x7678 <generic_tracepoint_arg+0x2228>
    6ff8:      	ldr	w10, [x25]
    6ffc:      	cmp	w11, w10
    7000:      	ccmp	w10, w8, #0x2, ls
    7004:      	cset	w8, ls
    7008:      	ldr	w11, [x23, #0x8]
    700c:      	cmp	w11, #0x11
    7010:      	b.lo	0x7fac <generic_tracepoint_arg+0x2b5c>
    7014:      	ldp	w13, w12, [x23, #0x18]
    7018:      	mov	w14, #0x1               // =1
    701c:      	cmp	w9, #0xc
    7020:      	b.hi	0x746c <generic_tracepoint_arg+0x201c>
    7024:      	lsl	w14, w14, w9
    7028:      	mov	w1, #0x1402             // =5122
    702c:      	tst	w14, w1
    7030:      	b.eq	0x746c <generic_tracepoint_arg+0x201c>
    7034:      	cmp	w13, w10
    7038:      	ccmp	w10, w12, #0x0, le
    703c:      	cset	w12, le
    7040:      	b	0x7478 <generic_tracepoint_arg+0x2028>
    7044:      	str	x29, [sp, #0x28]
    7048:      	mov	x19, xzr
    704c:      	mov	w22, wzr
    7050:      	add	x29, x23, #0x10
    7054:      	ldr	w8, [x29, x19, lsl #2]
    7058:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    705c:      	add	x9, sp, #0x60
    7060:      	add	x1, sp, #0x60
    7064:      	str	w8, [sp, #0x60]
    7068:      	mov	w8, #0x1                // =1
    706c:      	ldr	x0, [x0]
    7070:      	blr	x8
    7074:      	cbz	x0, 0x87cc <generic_tracepoint_arg+0x337c>
    7078:      	cbz	w25, 0x70d4 <generic_tracepoint_arg+0x1c84>
    707c:      	ldr	x9, [sp, #0x28]
    7080:      	mov	x8, xzr
    7084:      	mov	x10, x25
    7088:      	b	0x70a0 <generic_tracepoint_arg+0x1c50>
    708c:      	add	x8, x8, #0x1
    7090:      	sub	x10, x10, #0x1
    7094:      	add	x9, x9, #0x1
    7098:      	cmp	x8, x25
    709c:      	b.eq	0x70d4 <generic_tracepoint_arg+0x1c84>
    70a0:      	mov	x11, xzr
    70a4:      	cmp	x10, x11
    70a8:      	b.eq	0x708c <generic_tracepoint_arg+0x1c3c>
    70ac:      	ldrb	w12, [x0, x11]
    70b0:      	cbz	w12, 0x70d0 <generic_tracepoint_arg+0x1c80>
    70b4:      	cmp	x11, #0x62
    70b8:      	b.hi	0x708c <generic_tracepoint_arg+0x1c3c>
    70bc:      	ldrb	w13, [x9, x11]
    70c0:      	add	x11, x11, #0x1
    70c4:      	cmp	w13, w12
    70c8:      	b.eq	0x70a4 <generic_tracepoint_arg+0x1c54>
    70cc:      	b	0x708c <generic_tracepoint_arg+0x1c3c>
    70d0:      	tbz	w8, #0x1f, 0x7824 <generic_tracepoint_arg+0x23d4>
    70d4:      	ldr	w9, [x23, #0x8]
    70d8:      	add	w8, w22, #0xc
    70dc:      	cmp	w8, w9
    70e0:      	b.hs	0x87cc <generic_tracepoint_arg+0x337c>
    70e4:      	add	x19, x19, #0x1
    70e8:      	add	w22, w22, #0x4
    70ec:      	cmp	x19, #0x64
    70f0:      	b.ne	0x7054 <generic_tracepoint_arg+0x1c04>
    70f4:      	b	0x87cc <generic_tracepoint_arg+0x337c>
    70f8:      	and	w8, w25, #0xffff
    70fc:      	cmp	w8, #0x90
    7100:      	b.hi	0x76b8 <generic_tracepoint_arg+0x2268>
    7104:      	and	w8, w25, #0xff
    7108:      	mov	w9, #0xab               // =171
    710c:      	tst	w25, #0xffff
    7110:      	mul	w8, w8, w9
    7114:      	mov	w9, #0x18               // =24
    7118:      	lsr	w8, w8, #12
    711c:      	msub	w8, w8, w9, w25
    7120:      	b.eq	0x7134 <generic_tracepoint_arg+0x1ce4>
    7124:      	tst	w8, #0xff
    7128:      	mov	w9, w25
    712c:      	mov	w11, w25
    7130:      	b.eq	0x7150 <generic_tracepoint_arg+0x1d00>
    7134:      	sub	w8, w25, w8, uxtb
    7138:      	and	w9, w8, #0xffff
    713c:      	add	w8, w8, #0x18
    7140:      	and	w11, w8, #0xffff
    7144:      	cmp	w9, #0x78
    7148:      	b.hi	0x84c0 <generic_tracepoint_arg+0x3070>
    714c:      	mov	w9, w11
    7150:      	and	w8, w9, #0xff
    7154:      	mov	w9, #0xab               // =171
    7158:      	mul	w8, w8, w9
    715c:      	lsr	w8, w8, #12
    7160:      	sub	w10, w8, #0x1
    7164:      	b	0x8510 <generic_tracepoint_arg+0x30c0>
    7168:      	cmp	x13, x10
    716c:      	ccmp	x10, x12, #0x2, ls
    7170:      	cset	w12, ls
    7174:      	orr	w8, w8, w12
    7178:      	cmp	w11, #0x29
    717c:      	b.lo	0x7cd8 <generic_tracepoint_arg+0x2888>
    7180:      	ldp	x13, x12, [x23, #0x30]
    7184:      	cmp	w9, #0xc
    7188:      	b.eq	0x7194 <generic_tracepoint_arg+0x1d44>
    718c:      	cmp	w9, #0xa
    7190:      	b.ne	0x76c8 <generic_tracepoint_arg+0x2278>
    7194:      	cmp	x13, x10
    7198:      	ccmp	x10, x12, #0x0, le
    719c:      	cset	w12, le
    71a0:      	b	0x76d4 <generic_tracepoint_arg+0x2284>
    71a4:      	mov	x19, xzr
    71a8:      	cmp	w9, #0x29
    71ac:      	b.ne	0x71b8 <generic_tracepoint_arg+0x1d68>
    71b0:      	cbz	x10, 0x71b8 <generic_tracepoint_arg+0x1d68>
    71b4:      	ldrb	w19, [x10, #0x3a]
    71b8:      	cmp	w9, #0x29
    71bc:      	b.eq	0x71c8 <generic_tracepoint_arg+0x1d78>
    71c0:      	cmp	w9, #0x7
    71c4:      	b.ne	0x74b8 <generic_tracepoint_arg+0x2068>
    71c8:      	ldrb	w8, [x23, #0x10]
    71cc:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    71d0:      	add	x9, sp, #0xac
    71d4:      	add	x1, sp, #0xac
    71d8:      	str	w8, [sp, #0xac]
    71dc:      	mov	w8, #0x1                // =1
    71e0:      	ldr	x0, [x0]
    71e4:      	blr	x8
    71e8:      	cbz	x0, 0x7258 <generic_tracepoint_arg+0x1e08>
    71ec:      	str	x19, [sp, #0x88]
    71f0:      	mov	w8, #0x1                // =1
    71f4:      	add	x9, sp, #0x88
    71f8:      	add	x1, sp, #0x88
    71fc:      	blr	x8
    7200:      	ldr	w9, [x23, #0x4]
    7204:      	mov	w8, wzr
    7208:      	cmp	w9, #0x1d
    720c:      	b.hi	0x8178 <generic_tracepoint_arg+0x2d28>
    7210:      	ldr	x19, [sp, #0x30]
    7214:      	mov	w12, #0x1               // =1
    7218:      	mov	w10, #0x8400            // =33792
    721c:      	lsl	w9, w12, w9
    7220:      	movk	w10, #0x3003, lsl #16
    7224:      	tst	w9, w10
    7228:      	b.ne	0x6cd4 <generic_tracepoint_arg+0x1884>
    722c:      	mov	w10, #0x800             // =2048
    7230:      	movk	w10, #0xc, lsl #16
    7234:      	tst	w9, w10
    7238:      	b.eq	0x7244 <generic_tracepoint_arg+0x1df4>
    723c:      	cmp	x0, #0x0
    7240:      	cset	w8, eq
    7244:      	mov	w22, w8
    7248:      	ldp	x16, x15, [sp, #0x40]
    724c:      	mov	w2, #0x5ea0             // =24224
    7250:      	ldr	x17, [sp, #0x38]
    7254:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    7258:      	ldr	x19, [sp, #0x30]
    725c:      	mov	x22, xzr
    7260:      	mov	w12, #0x1               // =1
    7264:      	b	0x7248 <generic_tracepoint_arg+0x1df8>
    7268:      	cmp	x12, x8
    726c:      	mov	w12, #0x1               // =1
    7270:      	b.hi	0x727c <generic_tracepoint_arg+0x1e2c>
    7274:      	cmp	x8, x11
    7278:      	b.ls	0x56e8 <generic_tracepoint_arg+0x298>
    727c:      	cmp	w10, #0x29
    7280:      	b.lo	0x554c <generic_tracepoint_arg+0xfc>
    7284:      	ldp	x12, x11, [x23, #0x30]
    7288:      	cmp	w9, #0xc
    728c:      	b.eq	0x7298 <generic_tracepoint_arg+0x1e48>
    7290:      	cmp	w9, #0xa
    7294:      	b.ne	0x7704 <generic_tracepoint_arg+0x22b4>
    7298:      	cmp	x12, x8
    729c:      	mov	w12, #0x1               // =1
    72a0:      	b.gt	0x7718 <generic_tracepoint_arg+0x22c8>
    72a4:      	cmp	x8, x11
    72a8:      	b.le	0x56e8 <generic_tracepoint_arg+0x298>
    72ac:      	b	0x7718 <generic_tracepoint_arg+0x22c8>
    72b0:      	ldr	w8, [x23, #0x4]
    72b4:      	b	0x72c0 <generic_tracepoint_arg+0x1e70>
    72b8:      	ldr	w8, [x23, #0x4]
    72bc:      	ldr	x19, [sp, #0x30]
    72c0:      	and	w8, w8, #0xfffffffe
    72c4:      	cmp	w8, #0x18
    72c8:      	cset	w8, eq
    72cc:      	ldp	x16, x15, [sp, #0x40]
    72d0:      	mov	w2, #0x5ea0             // =24224
    72d4:      	mov	w12, #0x1               // =1
    72d8:      	mov	w22, w8
    72dc:      	ldr	x17, [sp, #0x38]
    72e0:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    72e4:      	ldr	w11, [x25]
    72e8:      	cmp	w11, w10
    72ec:      	b.hi	0x56e8 <generic_tracepoint_arg+0x298>
    72f0:      	b	0x7300 <generic_tracepoint_arg+0x1eb0>
    72f4:      	ldr	w11, [x25]
    72f8:      	cmp	w11, w10
    72fc:      	b.lo	0x56e8 <generic_tracepoint_arg+0x298>
    7300:      	ldr	w10, [x23, #0x8]
    7304:      	cmp	w10, #0xd
    7308:      	b.lo	0x8844 <generic_tracepoint_arg+0x33f4>
    730c:      	ldr	w11, [x23, #0x14]
    7310:      	cmp	w8, #0x2
    7314:      	b.le	0x7338 <generic_tracepoint_arg+0x1ee8>
    7318:      	sub	w12, w8, #0x3
    731c:      	cmp	w12, #0x2
    7320:      	b.hs	0x7378 <generic_tracepoint_arg+0x1f28>
    7324:      	ldr	w12, [x25]
    7328:      	cmp	w12, w11
    732c:      	mov	w12, #0x1               // =1
    7330:      	b.eq	0x56dc <generic_tracepoint_arg+0x28c>
    7334:      	b	0x7c04 <generic_tracepoint_arg+0x27b4>
    7338:      	cmp	w8, #0x1
    733c:      	b.eq	0x7398 <generic_tracepoint_arg+0x1f48>
    7340:      	cmp	w8, #0x2
    7344:      	b.ne	0x7c04 <generic_tracepoint_arg+0x27b4>
    7348:      	mov	w12, #0x1               // =1
    734c:      	cmp	w9, #0xc
    7350:      	b.hi	0x7bf4 <generic_tracepoint_arg+0x27a4>
    7354:      	lsl	w12, w12, w9
    7358:      	mov	w13, #0x1402            // =5122
    735c:      	tst	w12, w13
    7360:      	b.eq	0x7bf4 <generic_tracepoint_arg+0x27a4>
    7364:      	ldr	w12, [x25]
    7368:      	cmp	w12, w11
    736c:      	mov	w12, #0x1               // =1
    7370:      	b.lt	0x56e8 <generic_tracepoint_arg+0x298>
    7374:      	b	0x7c04 <generic_tracepoint_arg+0x27b4>
    7378:      	cmp	w8, #0xc
    737c:      	mov	w12, #0x1               // =1
    7380:      	b.ne	0x7c04 <generic_tracepoint_arg+0x27b4>
    7384:      	ldr	w12, [x25]
    7388:      	tst	w12, w11
    738c:      	mov	w12, #0x1               // =1
    7390:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    7394:      	b	0x7c04 <generic_tracepoint_arg+0x27b4>
    7398:      	mov	w12, #0x1               // =1
    739c:      	cmp	w9, #0xc
    73a0:      	b.hi	0x7be0 <generic_tracepoint_arg+0x2790>
    73a4:      	lsl	w12, w12, w9
    73a8:      	mov	w13, #0x1402            // =5122
    73ac:      	tst	w12, w13
    73b0:      	b.eq	0x7be0 <generic_tracepoint_arg+0x2790>
    73b4:      	ldr	w12, [x25]
    73b8:      	cmp	w12, w11
    73bc:      	mov	w12, #0x1               // =1
    73c0:      	b.gt	0x56e8 <generic_tracepoint_arg+0x298>
    73c4:      	b	0x7c04 <generic_tracepoint_arg+0x27b4>
    73c8:      	and	w8, w29, #0xffff
    73cc:      	cmp	w8, #0x201
    73d0:      	b.hs	0x782c <generic_tracepoint_arg+0x23dc>
    73d4:      	mov	w11, #0x200             // =512
    73d8:      	b	0x7d6c <generic_tracepoint_arg+0x291c>
    73dc:      	mov	x22, xzr
    73e0:      	ldr	x19, [sp, #0x30]
    73e4:      	ldr	w8, [x23, #0x4]
    73e8:      	cmp	w8, #0x25
    73ec:      	b.hi	0x649c <generic_tracepoint_arg+0x104c>
    73f0:      	mov	x9, #0x50               // =80
    73f4:      	ldp	x16, x15, [sp, #0x40]
    73f8:      	mov	w12, #0x1               // =1
    73fc:      	mov	w2, #0x5ea0             // =24224
    7400:      	movk	x9, #0xc00, lsl #16
    7404:      	ldr	x17, [sp, #0x38]
    7408:      	lsl	x8, x12, x8
    740c:      	movk	x9, #0x20, lsl #32
    7410:      	tst	x8, x9
    7414:      	b.ne	0x8268 <generic_tracepoint_arg+0x2e18>
    7418:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    741c:      	cmp	w8, #0x1
    7420:      	b.eq	0x7a9c <generic_tracepoint_arg+0x264c>
    7424:      	cmp	w8, #0x2
    7428:      	b.ne	0x7aa8 <generic_tracepoint_arg+0x2658>
    742c:      	ldrb	w11, [x25]
    7430:      	cmp	w10, w11
    7434:      	b.hi	0x56e8 <generic_tracepoint_arg+0x298>
    7438:      	b	0x7aa8 <generic_tracepoint_arg+0x2658>
    743c:      	cmp	w8, #0x1
    7440:      	b.eq	0x7ad8 <generic_tracepoint_arg+0x2688>
    7444:      	cmp	w8, #0x2
    7448:      	b.ne	0x7ae4 <generic_tracepoint_arg+0x2694>
    744c:      	ldrh	w11, [x25]
    7450:      	cmp	w10, w11
    7454:      	b.hi	0x56e8 <generic_tracepoint_arg+0x298>
    7458:      	b	0x7ae4 <generic_tracepoint_arg+0x2694>
    745c:      	cmp	w8, #0x401
    7460:      	b.hs	0x788c <generic_tracepoint_arg+0x243c>
    7464:      	mov	w11, #0x400             // =1024
    7468:      	b	0x78a0 <generic_tracepoint_arg+0x2450>
    746c:      	cmp	w13, w10
    7470:      	ccmp	w10, w12, #0x2, ls
    7474:      	cset	w12, ls
    7478:      	orr	w8, w8, w12
    747c:      	cmp	w11, #0x19
    7480:      	mov	w12, #0x1               // =1
    7484:      	b.lo	0x7fac <generic_tracepoint_arg+0x2b5c>
    7488:      	ldp	w13, w12, [x23, #0x20]
    748c:      	mov	w14, #0x1               // =1
    7490:      	cmp	w9, #0xc
    7494:      	b.hi	0x7b34 <generic_tracepoint_arg+0x26e4>
    7498:      	lsl	w14, w14, w9
    749c:      	mov	w1, #0x1402             // =5122
    74a0:      	tst	w14, w1
    74a4:      	b.eq	0x7b34 <generic_tracepoint_arg+0x26e4>
    74a8:      	cmp	w13, w10
    74ac:      	ccmp	w10, w12, #0x0, le
    74b0:      	cset	w12, le
    74b4:      	b	0x7b40 <generic_tracepoint_arg+0x26f0>
    74b8:      	ldr	x19, [sp, #0x30]
    74bc:      	mov	x22, xzr
    74c0:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    74c4:      	mov	w11, #0xa               // =10
    74c8:      	b	0x74d8 <generic_tracepoint_arg+0x2088>
    74cc:      	mov	w11, #0x6               // =6
    74d0:      	b	0x74d8 <generic_tracepoint_arg+0x2088>
    74d4:      	mov	w11, #0x8               // =8
    74d8:      	add	x8, x23, #0x10
    74dc:      	and	w9, w11, #0xf
    74e0:      	ldr	w8, [x8, w9, uxtw #2]
    74e4:      	cmn	w8, #0x1
    74e8:      	b.eq	0x7598 <generic_tracepoint_arg+0x2148>
    74ec:      	str	w8, [sp, #0x10]
    74f0:      	stp	w13, w11, [sp, #0x1c]
    74f4:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    74f8:      	mov	w8, #0x1                // =1
    74fc:      	add	x22, sp, #0x88
    7500:      	add	x1, sp, #0x88
    7504:      	str	x10, [sp, #0x28]
    7508:      	ldr	x0, [x0]
    750c:      	blr	x8
    7510:      	mov	x25, x0
    7514:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7518:      	mov	w8, #0x1                // =1
    751c:      	ldr	x0, [x0]
    7520:      	add	x1, sp, #0x88
    7524:      	blr	x8
    7528:      	mov	x22, xzr
    752c:      	cbz	x25, 0x8234 <generic_tracepoint_arg+0x2de4>
    7530:      	ldp	x16, x15, [sp, #0x40]
    7534:      	mov	w2, #0x5ea0             // =24224
    7538:      	mov	w12, #0x1               // =1
    753c:      	ldr	x17, [sp, #0x38]
    7540:      	cbz	x0, 0x8244 <generic_tracepoint_arg+0x2df4>
    7544:      	mov	x8, x25
    7548:      	ldr	w25, [sp, #0x20]
    754c:      	mov	x22, x0
    7550:      	mov	x0, x8
    7554:      	str	x8, [sp, #0x8]
    7558:      	cmp	w25, #0x5
    755c:      	b.gt	0x75ac <generic_tracepoint_arg+0x215c>
    7560:      	strb	w29, [x0], #0x1
    7564:      	ldr	x2, [sp, #0x28]
    7568:      	mov	w8, #0x4                // =4
    756c:      	mov	w1, w29
    7570:      	blr	x8
    7574:      	ldr	w8, [sp, #0x1c]
    7578:      	subs	w8, w8, w29
    757c:      	b.ls	0x75e8 <generic_tracepoint_arg+0x2198>
    7580:      	ldr	x9, [sp, #0x8]
    7584:      	and	w1, w8, #0xfff
    7588:      	mov	w8, #0x4                // =4
    758c:      	add	x9, x9, x29
    7590:      	add	x0, x9, #0x1
    7594:      	b	0x75e0 <generic_tracepoint_arg+0x2190>
    7598:      	mov	x22, xzr
    759c:      	ldr	w8, [x23, #0x4]
    75a0:      	cmp	w8, #0x25
    75a4:      	b.ls	0x8250 <generic_tracepoint_arg+0x2e00>
    75a8:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    75ac:      	strh	w29, [x0], #0x2
    75b0:      	ldr	x2, [sp, #0x28]
    75b4:      	mov	w8, #0x4                // =4
    75b8:      	mov	w1, w29
    75bc:      	blr	x8
    75c0:      	ldr	w8, [sp, #0x1c]
    75c4:      	subs	w8, w8, w29
    75c8:      	b.ls	0x75e8 <generic_tracepoint_arg+0x2198>
    75cc:      	ldr	x9, [sp, #0x8]
    75d0:      	and	w1, w8, #0xfff
    75d4:      	mov	w8, #0x4                // =4
    75d8:      	add	x9, x9, x29
    75dc:      	add	x0, x9, #0x2
    75e0:      	mov	x2, x22
    75e4:      	blr	x8
    75e8:      	ldr	w8, [sp, #0x10]
    75ec:      	cmp	w25, #0x4
    75f0:      	mov	w12, #0x1               // =1
    75f4:      	str	w8, [sp, #0x60]
    75f8:      	b.le	0x7630 <generic_tracepoint_arg+0x21e0>
    75fc:      	cmp	w25, #0x7
    7600:      	b.gt	0x7860 <generic_tracepoint_arg+0x2410>
    7604:      	cmp	w25, #0x5
    7608:      	b.eq	0x81e8 <generic_tracepoint_arg+0x2d98>
    760c:      	cmp	w25, #0x6
    7610:      	b.eq	0x81ac <generic_tracepoint_arg+0x2d5c>
    7614:      	cmp	w25, #0x7
    7618:      	b.ne	0x8270 <generic_tracepoint_arg+0x2e20>
    761c:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7620:      	mov	w8, #0x1                // =1
    7624:      	add	x9, sp, #0x60
    7628:      	ldr	x0, [x0]
    762c:      	b	0x820c <generic_tracepoint_arg+0x2dbc>
    7630:      	cmp	w25, #0x1
    7634:      	b.le	0x7ce4 <generic_tracepoint_arg+0x2894>
    7638:      	cmp	w25, #0x2
    763c:      	b.eq	0x81d4 <generic_tracepoint_arg+0x2d84>
    7640:      	cmp	w25, #0x3
    7644:      	b.eq	0x8198 <generic_tracepoint_arg+0x2d48>
    7648:      	cmp	w25, #0x4
    764c:      	b.ne	0x8270 <generic_tracepoint_arg+0x2e20>
    7650:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7654:      	mov	w8, #0x1                // =1
    7658:      	add	x9, sp, #0x60
    765c:      	ldr	x0, [x0]
    7660:      	b	0x820c <generic_tracepoint_arg+0x2dbc>
    7664:      	cmp	w12, w8
    7668:      	mov	w12, #0x1               // =1
    766c:      	b.hi	0x7678 <generic_tracepoint_arg+0x2228>
    7670:      	cmp	w8, w11
    7674:      	b.ls	0x56e8 <generic_tracepoint_arg+0x298>
    7678:      	cmp	w10, #0x19
    767c:      	b.lo	0x554c <generic_tracepoint_arg+0xfc>
    7680:      	ldp	w12, w11, [x23, #0x20]
    7684:      	mov	w13, #0x1               // =1
    7688:      	cmp	w9, #0xc
    768c:      	b.hi	0x7b94 <generic_tracepoint_arg+0x2744>
    7690:      	lsl	w13, w13, w9
    7694:      	mov	w14, #0x1402            // =5122
    7698:      	tst	w13, w14
    769c:      	b.eq	0x7b94 <generic_tracepoint_arg+0x2744>
    76a0:      	cmp	w12, w8
    76a4:      	mov	w12, #0x1               // =1
    76a8:      	b.gt	0x7ba8 <generic_tracepoint_arg+0x2758>
    76ac:      	cmp	w8, w11
    76b0:      	b.le	0x56e8 <generic_tracepoint_arg+0x298>
    76b4:      	b	0x7ba8 <generic_tracepoint_arg+0x2758>
    76b8:      	cmp	w8, #0x101
    76bc:      	b.hs	0x7b80 <generic_tracepoint_arg+0x2730>
    76c0:      	mov	w11, #0x100             // =256
    76c4:      	b	0x84c0 <generic_tracepoint_arg+0x3070>
    76c8:      	cmp	x13, x10
    76cc:      	ccmp	x10, x12, #0x2, ls
    76d0:      	cset	w12, ls
    76d4:      	orr	w8, w8, w12
    76d8:      	cmp	w11, #0x39
    76dc:      	b.lo	0x7cd8 <generic_tracepoint_arg+0x2888>
    76e0:      	ldp	x12, x11, [x23, #0x40]
    76e4:      	cmp	w9, #0xc
    76e8:      	b.eq	0x76f4 <generic_tracepoint_arg+0x22a4>
    76ec:      	cmp	w9, #0xa
    76f0:      	b.ne	0x7cc8 <generic_tracepoint_arg+0x2878>
    76f4:      	cmp	x12, x10
    76f8:      	ccmp	x10, x11, #0x0, le
    76fc:      	cset	w9, le
    7700:      	b	0x7cd4 <generic_tracepoint_arg+0x2884>
    7704:      	cmp	x12, x8
    7708:      	mov	w12, #0x1               // =1
    770c:      	b.hi	0x7718 <generic_tracepoint_arg+0x22c8>
    7710:      	cmp	x8, x11
    7714:      	b.ls	0x56e8 <generic_tracepoint_arg+0x298>
    7718:      	cmp	w10, #0x39
    771c:      	b.lo	0x554c <generic_tracepoint_arg+0xfc>
    7720:      	ldp	x11, x10, [x23, #0x40]
    7724:      	cmp	w9, #0xc
    7728:      	b.eq	0x7734 <generic_tracepoint_arg+0x22e4>
    772c:      	cmp	w9, #0xa
    7730:      	b.ne	0x7d04 <generic_tracepoint_arg+0x28b4>
    7734:      	cmp	x11, x8
    7738:      	b.gt	0x554c <generic_tracepoint_arg+0xfc>
    773c:      	cmp	x8, x10
    7740:      	b.le	0x56e8 <generic_tracepoint_arg+0x298>
    7744:      	b	0x554c <generic_tracepoint_arg+0xfc>
    7748:      	ldr	x12, [x25]
    774c:      	cmp	x12, x11
    7750:      	mov	w12, #0x1               // =1
    7754:      	b.hi	0x56e8 <generic_tracepoint_arg+0x298>
    7758:      	b	0x776c <generic_tracepoint_arg+0x231c>
    775c:      	ldr	x12, [x25]
    7760:      	cmp	x12, x11
    7764:      	mov	w12, #0x1               // =1
    7768:      	b.lo	0x56e8 <generic_tracepoint_arg+0x298>
    776c:      	cmp	w10, #0x19
    7770:      	b.lo	0x8844 <generic_tracepoint_arg+0x33f4>
    7774:      	ldr	x11, [x23, #0x20]
    7778:      	cmp	w8, #0x2
    777c:      	b.le	0x77a0 <generic_tracepoint_arg+0x2350>
    7780:      	sub	w12, w8, #0x3
    7784:      	cmp	w12, #0x2
    7788:      	b.hs	0x77d4 <generic_tracepoint_arg+0x2384>
    778c:      	ldr	x12, [x25]
    7790:      	cmp	x12, x11
    7794:      	mov	w12, #0x1               // =1
    7798:      	b.eq	0x56dc <generic_tracepoint_arg+0x28c>
    779c:      	b	0x7fd8 <generic_tracepoint_arg+0x2b88>
    77a0:      	cmp	w8, #0x1
    77a4:      	b.eq	0x783c <generic_tracepoint_arg+0x23ec>
    77a8:      	cmp	w8, #0x2
    77ac:      	b.ne	0x7fd8 <generic_tracepoint_arg+0x2b88>
    77b0:      	cmp	w9, #0xc
    77b4:      	b.eq	0x77c0 <generic_tracepoint_arg+0x2370>
    77b8:      	cmp	w9, #0xa
    77bc:      	b.ne	0x7fc8 <generic_tracepoint_arg+0x2b78>
    77c0:      	ldr	x12, [x25]
    77c4:      	cmp	x12, x11
    77c8:      	mov	w12, #0x1               // =1
    77cc:      	b.lt	0x56e8 <generic_tracepoint_arg+0x298>
    77d0:      	b	0x7fd8 <generic_tracepoint_arg+0x2b88>
    77d4:      	cmp	w8, #0xc
    77d8:      	mov	w12, #0x1               // =1
    77dc:      	b.ne	0x7fd8 <generic_tracepoint_arg+0x2b88>
    77e0:      	ldr	x12, [x25]
    77e4:      	tst	x12, x11
    77e8:      	mov	w12, #0x1               // =1
    77ec:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    77f0:      	b	0x7fd8 <generic_tracepoint_arg+0x2b88>
    77f4:      	cmp	w8, #0xc
    77f8:      	b.ne	0x7aa8 <generic_tracepoint_arg+0x2658>
    77fc:      	ldrb	w11, [x25]
    7800:      	tst	w10, w11
    7804:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    7808:      	b	0x7aa8 <generic_tracepoint_arg+0x2658>
    780c:      	cmp	w8, #0xc
    7810:      	b.ne	0x7ae4 <generic_tracepoint_arg+0x2694>
    7814:      	ldrh	w11, [x25]
    7818:      	tst	w10, w11
    781c:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    7820:      	b	0x7ae4 <generic_tracepoint_arg+0x2694>
    7824:      	mov	w22, #0x1               // =1
    7828:      	b	0x87d0 <generic_tracepoint_arg+0x3380>
    782c:      	cmp	w8, #0x401
    7830:      	b.hs	0x7d58 <generic_tracepoint_arg+0x2908>
    7834:      	mov	w11, #0x400             // =1024
    7838:      	b	0x7d6c <generic_tracepoint_arg+0x291c>
    783c:      	cmp	w9, #0xc
    7840:      	b.eq	0x784c <generic_tracepoint_arg+0x23fc>
    7844:      	cmp	w9, #0xa
    7848:      	b.ne	0x7fb4 <generic_tracepoint_arg+0x2b64>
    784c:      	ldr	x12, [x25]
    7850:      	cmp	x12, x11
    7854:      	mov	w12, #0x1               // =1
    7858:      	b.gt	0x56e8 <generic_tracepoint_arg+0x298>
    785c:      	b	0x7fd8 <generic_tracepoint_arg+0x2b88>
    7860:      	cmp	w25, #0x8
    7864:      	b.eq	0x81fc <generic_tracepoint_arg+0x2dac>
    7868:      	cmp	w25, #0x9
    786c:      	b.eq	0x81c0 <generic_tracepoint_arg+0x2d70>
    7870:      	cmp	w25, #0xa
    7874:      	b.ne	0x8270 <generic_tracepoint_arg+0x2e20>
    7878:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    787c:      	mov	w8, #0x1                // =1
    7880:      	add	x9, sp, #0x60
    7884:      	ldr	x0, [x0]
    7888:      	b	0x820c <generic_tracepoint_arg+0x2dbc>
    788c:      	and	w8, w29, #0xffff
    7890:      	mov	w9, #0x1000             // =4096
    7894:      	cmp	w8, #0x800
    7898:      	mov	w8, #0x800              // =2048
    789c:      	csel	w11, w9, w8, hi
    78a0:      	sub	w8, w11, #0x100
    78a4:      	ror	w8, w8, #0x8
    78a8:      	cmp	w8, #0x2
    78ac:      	b.gt	0x78c4 <generic_tracepoint_arg+0x2474>
    78b0:      	cbz	w8, 0x78e4 <generic_tracepoint_arg+0x2494>
    78b4:      	cmp	w8, #0x1
    78b8:      	b.ne	0x78dc <generic_tracepoint_arg+0x248c>
    78bc:      	mov	w10, #0x7               // =7
    78c0:      	b	0x78f0 <generic_tracepoint_arg+0x24a0>
    78c4:      	cmp	w8, #0x3
    78c8:      	b.eq	0x78ec <generic_tracepoint_arg+0x249c>
    78cc:      	cmp	w8, #0x7
    78d0:      	b.ne	0x78dc <generic_tracepoint_arg+0x248c>
    78d4:      	mov	w10, #0x9               // =9
    78d8:      	b	0x78f0 <generic_tracepoint_arg+0x24a0>
    78dc:      	mov	w10, #0xa               // =10
    78e0:      	b	0x78f0 <generic_tracepoint_arg+0x24a0>
    78e4:      	mov	w10, #0x6               // =6
    78e8:      	b	0x78f0 <generic_tracepoint_arg+0x24a0>
    78ec:      	mov	w10, #0x8               // =8
    78f0:      	add	x8, x23, #0x10
    78f4:      	and	w9, w10, #0xf
    78f8:      	ldr	w8, [x8, w9, uxtw #2]
    78fc:      	cmn	w8, #0x1
    7900:      	b.eq	0x8230 <generic_tracepoint_arg+0x2de0>
    7904:      	str	w8, [sp, #0x10]
    7908:      	str	w11, [sp, #0x1c]
    790c:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7910:      	mov	w8, #0x1                // =1
    7914:      	add	x22, sp, #0x88
    7918:      	add	x1, sp, #0x88
    791c:      	str	w10, [sp, #0x28]
    7920:      	ldr	x0, [x0]
    7924:      	blr	x8
    7928:      	str	x0, [sp, #0x20]
    792c:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7930:      	mov	w8, #0x1                // =1
    7934:      	add	x1, sp, #0x88
    7938:      	ldr	x0, [x0]
    793c:      	blr	x8
    7940:      	ldr	x9, [sp, #0x20]
    7944:      	mov	x22, xzr
    7948:      	cbz	x9, 0x8234 <generic_tracepoint_arg+0x2de4>
    794c:      	ldp	x16, x15, [sp, #0x40]
    7950:      	mov	w2, #0x5ea0             // =24224
    7954:      	mov	w12, #0x1               // =1
    7958:      	ldr	x17, [sp, #0x38]
    795c:      	cbz	x0, 0x8244 <generic_tracepoint_arg+0x2df4>
    7960:      	mov	x8, x9
    7964:      	ldr	w9, [sp, #0x28]
    7968:      	mov	x22, x0
    796c:      	add	x2, x25, #0x4
    7970:      	mov	x25, x8
    7974:      	mov	x0, x8
    7978:      	cmp	w9, #0x5
    797c:      	b.gt	0x79b0 <generic_tracepoint_arg+0x2560>
    7980:      	strb	w29, [x0], #0x1
    7984:      	mov	w8, #0x4                // =4
    7988:      	mov	w1, w29
    798c:      	blr	x8
    7990:      	ldr	w8, [sp, #0x1c]
    7994:      	subs	w8, w8, w29
    7998:      	b.ls	0x79e4 <generic_tracepoint_arg+0x2594>
    799c:      	add	x9, x25, x29
    79a0:      	and	w1, w8, #0xfff
    79a4:      	mov	w8, #0x4                // =4
    79a8:      	add	x0, x9, #0x1
    79ac:      	b	0x79dc <generic_tracepoint_arg+0x258c>
    79b0:      	strh	w29, [x0], #0x2
    79b4:      	mov	w8, #0x4                // =4
    79b8:      	mov	w1, w29
    79bc:      	blr	x8
    79c0:      	ldr	w8, [sp, #0x1c]
    79c4:      	subs	w8, w8, w29
    79c8:      	b.ls	0x79e4 <generic_tracepoint_arg+0x2594>
    79cc:      	add	x9, x25, x29
    79d0:      	and	w1, w8, #0xfff
    79d4:      	mov	w8, #0x4                // =4
    79d8:      	add	x0, x9, #0x2
    79dc:      	mov	x2, x22
    79e0:      	blr	x8
    79e4:      	ldr	w8, [sp, #0x10]
    79e8:      	ldp	x16, x15, [sp, #0x40]
    79ec:      	mov	w2, #0x5ea0             // =24224
    79f0:      	mov	w12, #0x1               // =1
    79f4:      	ldr	x17, [sp, #0x38]
    79f8:      	str	w8, [sp, #0x60]
    79fc:      	ldr	w8, [sp, #0x28]
    7a00:      	cmp	w8, #0x4
    7a04:      	b.le	0x7a3c <generic_tracepoint_arg+0x25ec>
    7a08:      	cmp	w8, #0x7
    7a0c:      	b.gt	0x7a70 <generic_tracepoint_arg+0x2620>
    7a10:      	cmp	w8, #0x5
    7a14:      	b.eq	0x80ec <generic_tracepoint_arg+0x2c9c>
    7a18:      	cmp	w8, #0x6
    7a1c:      	b.eq	0x80b0 <generic_tracepoint_arg+0x2c60>
    7a20:      	cmp	w8, #0x7
    7a24:      	b.ne	0x5c0c <generic_tracepoint_arg+0x7bc>
    7a28:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7a2c:      	mov	w8, #0x1                // =1
    7a30:      	add	x9, sp, #0x60
    7a34:      	ldr	x0, [x0]
    7a38:      	b	0x8110 <generic_tracepoint_arg+0x2cc0>
    7a3c:      	cmp	w8, #0x1
    7a40:      	b.le	0x7b14 <generic_tracepoint_arg+0x26c4>
    7a44:      	cmp	w8, #0x2
    7a48:      	b.eq	0x80d8 <generic_tracepoint_arg+0x2c88>
    7a4c:      	cmp	w8, #0x3
    7a50:      	b.eq	0x809c <generic_tracepoint_arg+0x2c4c>
    7a54:      	cmp	w8, #0x4
    7a58:      	b.ne	0x5c0c <generic_tracepoint_arg+0x7bc>
    7a5c:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7a60:      	mov	w8, #0x1                // =1
    7a64:      	add	x9, sp, #0x60
    7a68:      	ldr	x0, [x0]
    7a6c:      	b	0x8110 <generic_tracepoint_arg+0x2cc0>
    7a70:      	cmp	w8, #0x8
    7a74:      	b.eq	0x8100 <generic_tracepoint_arg+0x2cb0>
    7a78:      	cmp	w8, #0x9
    7a7c:      	b.eq	0x80c4 <generic_tracepoint_arg+0x2c74>
    7a80:      	cmp	w8, #0xa
    7a84:      	b.ne	0x5c0c <generic_tracepoint_arg+0x7bc>
    7a88:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7a8c:      	mov	w8, #0x1                // =1
    7a90:      	add	x9, sp, #0x60
    7a94:      	ldr	x0, [x0]
    7a98:      	b	0x8110 <generic_tracepoint_arg+0x2cc0>
    7a9c:      	ldrb	w11, [x25]
    7aa0:      	cmp	w10, w11
    7aa4:      	b.lo	0x56e8 <generic_tracepoint_arg+0x298>
    7aa8:      	cmp	w9, #0x11
    7aac:      	b.lo	0x8844 <generic_tracepoint_arg+0x33f4>
    7ab0:      	ldr	w10, [x23, #0x18]
    7ab4:      	cmp	w8, #0x2
    7ab8:      	b.le	0x7d18 <generic_tracepoint_arg+0x28c8>
    7abc:      	sub	w11, w8, #0x3
    7ac0:      	cmp	w11, #0x2
    7ac4:      	b.hs	0x8058 <generic_tracepoint_arg+0x2c08>
    7ac8:      	ldrb	w11, [x25]
    7acc:      	cmp	w10, w11
    7ad0:      	b.eq	0x56dc <generic_tracepoint_arg+0x28c>
    7ad4:      	b	0x8364 <generic_tracepoint_arg+0x2f14>
    7ad8:      	ldrh	w11, [x25]
    7adc:      	cmp	w10, w11
    7ae0:      	b.lo	0x56e8 <generic_tracepoint_arg+0x298>
    7ae4:      	cmp	w9, #0x11
    7ae8:      	b.lo	0x8844 <generic_tracepoint_arg+0x33f4>
    7aec:      	ldr	w10, [x23, #0x18]
    7af0:      	cmp	w8, #0x2
    7af4:      	b.le	0x7d38 <generic_tracepoint_arg+0x28e8>
    7af8:      	sub	w11, w8, #0x3
    7afc:      	cmp	w11, #0x2
    7b00:      	b.hs	0x8070 <generic_tracepoint_arg+0x2c20>
    7b04:      	ldrh	w11, [x25]
    7b08:      	cmp	w10, w11
    7b0c:      	b.eq	0x56dc <generic_tracepoint_arg+0x28c>
    7b10:      	b	0x83a8 <generic_tracepoint_arg+0x2f58>
    7b14:      	cbz	w8, 0x8088 <generic_tracepoint_arg+0x2c38>
    7b18:      	cmp	w8, #0x1
    7b1c:      	b.ne	0x5c0c <generic_tracepoint_arg+0x7bc>
    7b20:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7b24:      	mov	w8, #0x1                // =1
    7b28:      	add	x9, sp, #0x60
    7b2c:      	ldr	x0, [x0]
    7b30:      	b	0x8110 <generic_tracepoint_arg+0x2cc0>
    7b34:      	cmp	w13, w10
    7b38:      	ccmp	w10, w12, #0x2, ls
    7b3c:      	cset	w12, ls
    7b40:      	orr	w8, w8, w12
    7b44:      	cmp	w11, #0x21
    7b48:      	mov	w12, #0x1               // =1
    7b4c:      	b.lo	0x7fac <generic_tracepoint_arg+0x2b5c>
    7b50:      	ldp	w12, w11, [x23, #0x28]
    7b54:      	mov	w13, #0x1               // =1
    7b58:      	cmp	w9, #0xc
    7b5c:      	b.hi	0x7f98 <generic_tracepoint_arg+0x2b48>
    7b60:      	lsl	w9, w13, w9
    7b64:      	mov	w13, #0x1402            // =5122
    7b68:      	tst	w9, w13
    7b6c:      	b.eq	0x7f98 <generic_tracepoint_arg+0x2b48>
    7b70:      	cmp	w12, w10
    7b74:      	ccmp	w10, w11, #0x0, le
    7b78:      	cset	w9, le
    7b7c:      	b	0x7fa4 <generic_tracepoint_arg+0x2b54>
    7b80:      	and	w8, w25, #0xffff
    7b84:      	cmp	w8, #0x201
    7b88:      	b.hs	0x8134 <generic_tracepoint_arg+0x2ce4>
    7b8c:      	mov	w11, #0x200             // =512
    7b90:      	b	0x84c0 <generic_tracepoint_arg+0x3070>
    7b94:      	cmp	w12, w8
    7b98:      	mov	w12, #0x1               // =1
    7b9c:      	b.hi	0x7ba8 <generic_tracepoint_arg+0x2758>
    7ba0:      	cmp	w8, w11
    7ba4:      	b.ls	0x56e8 <generic_tracepoint_arg+0x298>
    7ba8:      	cmp	w10, #0x21
    7bac:      	b.lo	0x554c <generic_tracepoint_arg+0xfc>
    7bb0:      	ldp	w11, w10, [x23, #0x28]
    7bb4:      	cmp	w9, #0xc
    7bb8:      	b.hi	0x8144 <generic_tracepoint_arg+0x2cf4>
    7bbc:      	lsl	w9, w12, w9
    7bc0:      	mov	w13, #0x1402            // =5122
    7bc4:      	tst	w9, w13
    7bc8:      	b.eq	0x8144 <generic_tracepoint_arg+0x2cf4>
    7bcc:      	cmp	w11, w8
    7bd0:      	b.gt	0x554c <generic_tracepoint_arg+0xfc>
    7bd4:      	cmp	w8, w10
    7bd8:      	b.le	0x56e8 <generic_tracepoint_arg+0x298>
    7bdc:      	b	0x554c <generic_tracepoint_arg+0xfc>
    7be0:      	ldr	w12, [x25]
    7be4:      	cmp	w12, w11
    7be8:      	mov	w12, #0x1               // =1
    7bec:      	b.hi	0x56e8 <generic_tracepoint_arg+0x298>
    7bf0:      	b	0x7c04 <generic_tracepoint_arg+0x27b4>
    7bf4:      	ldr	w12, [x25]
    7bf8:      	cmp	w12, w11
    7bfc:      	mov	w12, #0x1               // =1
    7c00:      	b.lo	0x56e8 <generic_tracepoint_arg+0x298>
    7c04:      	cmp	w10, #0x11
    7c08:      	b.lo	0x8844 <generic_tracepoint_arg+0x33f4>
    7c0c:      	ldr	w11, [x23, #0x18]
    7c10:      	cmp	w8, #0x2
    7c14:      	b.le	0x7c38 <generic_tracepoint_arg+0x27e8>
    7c18:      	sub	w12, w8, #0x3
    7c1c:      	cmp	w12, #0x2
    7c20:      	b.hs	0x7c78 <generic_tracepoint_arg+0x2828>
    7c24:      	ldr	w12, [x25]
    7c28:      	cmp	w12, w11
    7c2c:      	mov	w12, #0x1               // =1
    7c30:      	b.eq	0x56dc <generic_tracepoint_arg+0x28c>
    7c34:      	b	0x8404 <generic_tracepoint_arg+0x2fb4>
    7c38:      	cmp	w8, #0x1
    7c3c:      	b.eq	0x7c98 <generic_tracepoint_arg+0x2848>
    7c40:      	cmp	w8, #0x2
    7c44:      	b.ne	0x8404 <generic_tracepoint_arg+0x2fb4>
    7c48:      	mov	w12, #0x1               // =1
    7c4c:      	cmp	w9, #0xc
    7c50:      	b.hi	0x83f4 <generic_tracepoint_arg+0x2fa4>
    7c54:      	lsl	w12, w12, w9
    7c58:      	mov	w13, #0x1402            // =5122
    7c5c:      	tst	w12, w13
    7c60:      	b.eq	0x83f4 <generic_tracepoint_arg+0x2fa4>
    7c64:      	ldr	w12, [x25]
    7c68:      	cmp	w12, w11
    7c6c:      	mov	w12, #0x1               // =1
    7c70:      	b.lt	0x56e8 <generic_tracepoint_arg+0x298>
    7c74:      	b	0x8404 <generic_tracepoint_arg+0x2fb4>
    7c78:      	cmp	w8, #0xc
    7c7c:      	mov	w12, #0x1               // =1
    7c80:      	b.ne	0x8404 <generic_tracepoint_arg+0x2fb4>
    7c84:      	ldr	w12, [x25]
    7c88:      	tst	w12, w11
    7c8c:      	mov	w12, #0x1               // =1
    7c90:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    7c94:      	b	0x8404 <generic_tracepoint_arg+0x2fb4>
    7c98:      	mov	w12, #0x1               // =1
    7c9c:      	cmp	w9, #0xc
    7ca0:      	b.hi	0x83e0 <generic_tracepoint_arg+0x2f90>
    7ca4:      	lsl	w12, w12, w9
    7ca8:      	mov	w13, #0x1402            // =5122
    7cac:      	tst	w12, w13
    7cb0:      	b.eq	0x83e0 <generic_tracepoint_arg+0x2f90>
    7cb4:      	ldr	w12, [x25]
    7cb8:      	cmp	w12, w11
    7cbc:      	mov	w12, #0x1               // =1
    7cc0:      	b.gt	0x56e8 <generic_tracepoint_arg+0x298>
    7cc4:      	b	0x8404 <generic_tracepoint_arg+0x2fb4>
    7cc8:      	cmp	x12, x10
    7ccc:      	ccmp	x10, x11, #0x2, ls
    7cd0:      	cset	w9, ls
    7cd4:      	orr	w8, w8, w9
    7cd8:      	mov	w12, #0x1               // =1
    7cdc:      	tbz	w8, #0x0, 0x56e8 <generic_tracepoint_arg+0x298>
    7ce0:      	b	0x554c <generic_tracepoint_arg+0xfc>
    7ce4:      	cbz	w25, 0x8184 <generic_tracepoint_arg+0x2d34>
    7ce8:      	cmp	w25, #0x1
    7cec:      	b.ne	0x8270 <generic_tracepoint_arg+0x2e20>
    7cf0:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7cf4:      	mov	w8, #0x1                // =1
    7cf8:      	add	x9, sp, #0x60
    7cfc:      	ldr	x0, [x0]
    7d00:      	b	0x820c <generic_tracepoint_arg+0x2dbc>
    7d04:      	cmp	x11, x8
    7d08:      	b.hi	0x554c <generic_tracepoint_arg+0xfc>
    7d0c:      	cmp	x8, x10
    7d10:      	b.ls	0x56e8 <generic_tracepoint_arg+0x298>
    7d14:      	b	0x554c <generic_tracepoint_arg+0xfc>
    7d18:      	cmp	w8, #0x1
    7d1c:      	b.eq	0x8358 <generic_tracepoint_arg+0x2f08>
    7d20:      	cmp	w8, #0x2
    7d24:      	b.ne	0x8364 <generic_tracepoint_arg+0x2f14>
    7d28:      	ldrb	w11, [x25]
    7d2c:      	cmp	w10, w11
    7d30:      	b.hi	0x56e8 <generic_tracepoint_arg+0x298>
    7d34:      	b	0x8364 <generic_tracepoint_arg+0x2f14>
    7d38:      	cmp	w8, #0x1
    7d3c:      	b.eq	0x839c <generic_tracepoint_arg+0x2f4c>
    7d40:      	cmp	w8, #0x2
    7d44:      	b.ne	0x83a8 <generic_tracepoint_arg+0x2f58>
    7d48:      	ldrh	w11, [x25]
    7d4c:      	cmp	w10, w11
    7d50:      	b.hi	0x56e8 <generic_tracepoint_arg+0x298>
    7d54:      	b	0x83a8 <generic_tracepoint_arg+0x2f58>
    7d58:      	and	w8, w29, #0xffff
    7d5c:      	mov	w9, #0x1000             // =4096
    7d60:      	cmp	w8, #0x800
    7d64:      	mov	w8, #0x800              // =2048
    7d68:      	csel	w11, w9, w8, hi
    7d6c:      	sub	w8, w11, #0x100
    7d70:      	ror	w8, w8, #0x8
    7d74:      	cmp	w8, #0x2
    7d78:      	b.gt	0x7d90 <generic_tracepoint_arg+0x2940>
    7d7c:      	cbz	w8, 0x7db0 <generic_tracepoint_arg+0x2960>
    7d80:      	cmp	w8, #0x1
    7d84:      	b.ne	0x7da8 <generic_tracepoint_arg+0x2958>
    7d88:      	mov	w10, #0x7               // =7
    7d8c:      	b	0x7dbc <generic_tracepoint_arg+0x296c>
    7d90:      	cmp	w8, #0x3
    7d94:      	b.eq	0x7db8 <generic_tracepoint_arg+0x2968>
    7d98:      	cmp	w8, #0x7
    7d9c:      	b.ne	0x7da8 <generic_tracepoint_arg+0x2958>
    7da0:      	mov	w10, #0x9               // =9
    7da4:      	b	0x7dbc <generic_tracepoint_arg+0x296c>
    7da8:      	mov	w10, #0xa               // =10
    7dac:      	b	0x7dbc <generic_tracepoint_arg+0x296c>
    7db0:      	mov	w10, #0x6               // =6
    7db4:      	b	0x7dbc <generic_tracepoint_arg+0x296c>
    7db8:      	mov	w10, #0x8               // =8
    7dbc:      	add	x8, x23, #0x10
    7dc0:      	and	w9, w10, #0xf
    7dc4:      	ldr	w8, [x8, w9, uxtw #2]
    7dc8:      	cmn	w8, #0x1
    7dcc:      	b.eq	0x7e80 <generic_tracepoint_arg+0x2a30>
    7dd0:      	str	w8, [sp, #0x1c]
    7dd4:      	str	w11, [sp, #0x10]
    7dd8:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7ddc:      	mov	w8, #0x1                // =1
    7de0:      	add	x22, sp, #0x88
    7de4:      	add	x1, sp, #0x88
    7de8:      	str	w10, [sp, #0x28]
    7dec:      	ldr	x0, [x0]
    7df0:      	blr	x8
    7df4:      	str	x0, [sp, #0x20]
    7df8:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7dfc:      	mov	w8, #0x1                // =1
    7e00:      	add	x1, sp, #0x88
    7e04:      	ldr	x0, [x0]
    7e08:      	blr	x8
    7e0c:      	ldr	x9, [sp, #0x20]
    7e10:      	mov	x22, xzr
    7e14:      	cbz	x9, 0x6700 <generic_tracepoint_arg+0x12b0>
    7e18:      	ldp	x16, x15, [sp, #0x40]
    7e1c:      	mov	w2, #0x5ea0             // =24224
    7e20:      	mov	w12, #0x1               // =1
    7e24:      	ldr	x17, [sp, #0x38]
    7e28:      	cbz	x0, 0x6710 <generic_tracepoint_arg+0x12c0>
    7e2c:      	mov	x8, x9
    7e30:      	ldr	w9, [sp, #0x28]
    7e34:      	mov	x22, x0
    7e38:      	cmp	w9, #0x5
    7e3c:      	b.gt	0x7e88 <generic_tracepoint_arg+0x2a38>
    7e40:      	mov	x0, x8
    7e44:      	mov	x9, x8
    7e48:      	mov	w8, #0x4                // =4
    7e4c:      	mov	w1, w29
    7e50:      	mov	x2, x25
    7e54:      	strb	w29, [x0], #0x1
    7e58:      	mov	x25, x9
    7e5c:      	blr	x8
    7e60:      	ldr	w8, [sp, #0x10]
    7e64:      	subs	w8, w8, w29
    7e68:      	b.ls	0x7ecc <generic_tracepoint_arg+0x2a7c>
    7e6c:      	add	x9, x25, x29
    7e70:      	and	w1, w8, #0xfff
    7e74:      	mov	w8, #0x4                // =4
    7e78:      	add	x0, x9, #0x1
    7e7c:      	b	0x7ec4 <generic_tracepoint_arg+0x2a74>
    7e80:      	mov	x22, xzr
    7e84:      	b	0x670c <generic_tracepoint_arg+0x12bc>
    7e88:      	mov	x0, x8
    7e8c:      	mov	x9, x8
    7e90:      	mov	w8, #0x4                // =4
    7e94:      	mov	w1, w29
    7e98:      	mov	x2, x25
    7e9c:      	strh	w29, [x0], #0x2
    7ea0:      	mov	x25, x9
    7ea4:      	blr	x8
    7ea8:      	ldr	w8, [sp, #0x10]
    7eac:      	subs	w8, w8, w29
    7eb0:      	b.ls	0x7ecc <generic_tracepoint_arg+0x2a7c>
    7eb4:      	add	x9, x25, x29
    7eb8:      	and	w1, w8, #0xfff
    7ebc:      	mov	w8, #0x4                // =4
    7ec0:      	add	x0, x9, #0x2
    7ec4:      	mov	x2, x22
    7ec8:      	blr	x8
    7ecc:      	ldr	w8, [sp, #0x1c]
    7ed0:      	mov	w12, #0x1               // =1
    7ed4:      	str	w8, [sp, #0x60]
    7ed8:      	ldr	w8, [sp, #0x28]
    7edc:      	cmp	w8, #0x4
    7ee0:      	b.le	0x7f18 <generic_tracepoint_arg+0x2ac8>
    7ee4:      	cmp	w8, #0x7
    7ee8:      	b.gt	0x7f4c <generic_tracepoint_arg+0x2afc>
    7eec:      	cmp	w8, #0x5
    7ef0:      	b.eq	0x82f4 <generic_tracepoint_arg+0x2ea4>
    7ef4:      	cmp	w8, #0x6
    7ef8:      	b.eq	0x82b8 <generic_tracepoint_arg+0x2e68>
    7efc:      	cmp	w8, #0x7
    7f00:      	b.ne	0x8344 <generic_tracepoint_arg+0x2ef4>
    7f04:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7f08:      	mov	w8, #0x1                // =1
    7f0c:      	add	x9, sp, #0x60
    7f10:      	ldr	x0, [x0]
    7f14:      	b	0x8318 <generic_tracepoint_arg+0x2ec8>
    7f18:      	cmp	w8, #0x1
    7f1c:      	b.le	0x7f78 <generic_tracepoint_arg+0x2b28>
    7f20:      	cmp	w8, #0x2
    7f24:      	b.eq	0x82e0 <generic_tracepoint_arg+0x2e90>
    7f28:      	cmp	w8, #0x3
    7f2c:      	b.eq	0x82a4 <generic_tracepoint_arg+0x2e54>
    7f30:      	cmp	w8, #0x4
    7f34:      	b.ne	0x8344 <generic_tracepoint_arg+0x2ef4>
    7f38:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7f3c:      	mov	w8, #0x1                // =1
    7f40:      	add	x9, sp, #0x60
    7f44:      	ldr	x0, [x0]
    7f48:      	b	0x8318 <generic_tracepoint_arg+0x2ec8>
    7f4c:      	cmp	w8, #0x8
    7f50:      	b.eq	0x8308 <generic_tracepoint_arg+0x2eb8>
    7f54:      	cmp	w8, #0x9
    7f58:      	b.eq	0x82cc <generic_tracepoint_arg+0x2e7c>
    7f5c:      	cmp	w8, #0xa
    7f60:      	b.ne	0x8344 <generic_tracepoint_arg+0x2ef4>
    7f64:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7f68:      	mov	w8, #0x1                // =1
    7f6c:      	add	x9, sp, #0x60
    7f70:      	ldr	x0, [x0]
    7f74:      	b	0x8318 <generic_tracepoint_arg+0x2ec8>
    7f78:      	cbz	w8, 0x8290 <generic_tracepoint_arg+0x2e40>
    7f7c:      	cmp	w8, #0x1
    7f80:      	b.ne	0x8344 <generic_tracepoint_arg+0x2ef4>
    7f84:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x1bb0>
    7f88:      	mov	w8, #0x1                // =1
    7f8c:      	add	x9, sp, #0x60
    7f90:      	ldr	x0, [x0]
    7f94:      	b	0x8318 <generic_tracepoint_arg+0x2ec8>
    7f98:      	cmp	w12, w10
    7f9c:      	ccmp	w10, w11, #0x2, ls
    7fa0:      	cset	w9, ls
    7fa4:      	orr	w8, w8, w9
    7fa8:      	mov	w12, #0x1               // =1
    7fac:      	tbz	w8, #0x0, 0x56e8 <generic_tracepoint_arg+0x298>
    7fb0:      	b	0x554c <generic_tracepoint_arg+0xfc>
    7fb4:      	ldr	x12, [x25]
    7fb8:      	cmp	x12, x11
    7fbc:      	mov	w12, #0x1               // =1
    7fc0:      	b.hi	0x56e8 <generic_tracepoint_arg+0x298>
    7fc4:      	b	0x7fd8 <generic_tracepoint_arg+0x2b88>
    7fc8:      	ldr	x12, [x25]
    7fcc:      	cmp	x12, x11
    7fd0:      	mov	w12, #0x1               // =1
    7fd4:      	b.lo	0x56e8 <generic_tracepoint_arg+0x298>
    7fd8:      	cmp	w10, #0x21
    7fdc:      	b.lo	0x8844 <generic_tracepoint_arg+0x33f4>
    7fe0:      	ldr	x10, [x23, #0x28]
    7fe4:      	cmp	w8, #0x2
    7fe8:      	b.le	0x8018 <generic_tracepoint_arg+0x2bc8>
    7fec:      	sub	w9, w8, #0x3
    7ff0:      	cmp	w9, #0x2
    7ff4:      	b.lo	0x8048 <generic_tracepoint_arg+0x2bf8>
    7ff8:      	cmp	w8, #0x6
    7ffc:      	b.eq	0x56e8 <generic_tracepoint_arg+0x298>
    8000:      	cmp	w8, #0xc
    8004:      	b.ne	0x554c <generic_tracepoint_arg+0xfc>
    8008:      	ldr	x9, [x25]
    800c:      	tst	x9, x10
    8010:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    8014:      	b	0x8844 <generic_tracepoint_arg+0x33f4>
    8018:      	cmp	w8, #0x1
    801c:      	b.eq	0x8158 <generic_tracepoint_arg+0x2d08>
    8020:      	cmp	w8, #0x2
    8024:      	b.ne	0x554c <generic_tracepoint_arg+0xfc>
    8028:      	cmp	w9, #0xc
    802c:      	b.eq	0x8038 <generic_tracepoint_arg+0x2be8>
    8030:      	cmp	w9, #0xa
    8034:      	b.ne	0x8700 <generic_tracepoint_arg+0x32b0>
    8038:      	ldr	x9, [x25]
    803c:      	cmp	x9, x10
    8040:      	b.lt	0x56e8 <generic_tracepoint_arg+0x298>
    8044:      	b	0x8844 <generic_tracepoint_arg+0x33f4>
    8048:      	ldr	x9, [x25]
    804c:      	cmp	x9, x10
    8050:      	b.ne	0x8844 <generic_tracepoint_arg+0x33f4>
    8054:      	b	0x56dc <generic_tracepoint_arg+0x28c>
    8058:      	cmp	w8, #0xc
    805c:      	b.ne	0x8364 <generic_tracepoint_arg+0x2f14>
    8060:      	ldrb	w11, [x25]
    8064:      	tst	w10, w11
    8068:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    806c:      	b	0x8364 <generic_tracepoint_arg+0x2f14>
    8070:      	cmp	w8, #0xc
    8074:      	b.ne	0x83a8 <generic_tracepoint_arg+0x2f58>
    8078:      	ldrh	w11, [x25]
    807c:      	tst	w10, w11
    8080:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    8084:      	b	0x83a8 <generic_tracepoint_arg+0x2f58>
    8088:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    808c:      	mov	w8, #0x1                // =1
    8090:      	add	x9, sp, #0x60
    8094:      	ldr	x0, [x0]
    8098:      	b	0x8110 <generic_tracepoint_arg+0x2cc0>
    809c:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    80a0:      	mov	w8, #0x1                // =1
    80a4:      	add	x9, sp, #0x60
    80a8:      	ldr	x0, [x0]
    80ac:      	b	0x8110 <generic_tracepoint_arg+0x2cc0>
    80b0:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    80b4:      	mov	w8, #0x1                // =1
    80b8:      	add	x9, sp, #0x60
    80bc:      	ldr	x0, [x0]
    80c0:      	b	0x8110 <generic_tracepoint_arg+0x2cc0>
    80c4:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    80c8:      	mov	w8, #0x1                // =1
    80cc:      	add	x9, sp, #0x60
    80d0:      	ldr	x0, [x0]
    80d4:      	b	0x8110 <generic_tracepoint_arg+0x2cc0>
    80d8:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    80dc:      	mov	w8, #0x1                // =1
    80e0:      	add	x9, sp, #0x60
    80e4:      	ldr	x0, [x0]
    80e8:      	b	0x8110 <generic_tracepoint_arg+0x2cc0>
    80ec:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    80f0:      	mov	w8, #0x1                // =1
    80f4:      	add	x9, sp, #0x60
    80f8:      	ldr	x0, [x0]
    80fc:      	b	0x8110 <generic_tracepoint_arg+0x2cc0>
    8100:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8104:      	mov	w8, #0x1                // =1
    8108:      	add	x9, sp, #0x60
    810c:      	ldr	x0, [x0]
    8110:      	add	x1, sp, #0x60
    8114:      	blr	x8
    8118:      	cbz	x0, 0x8230 <generic_tracepoint_arg+0x2de0>
    811c:      	mov	w8, #0x1                // =1
    8120:      	mov	x1, x25
    8124:      	blr	x8
    8128:      	cmp	x0, #0x0
    812c:      	cset	w22, ne
    8130:      	b	0x8234 <generic_tracepoint_arg+0x2de4>
    8134:      	cmp	w8, #0x401
    8138:      	b.hs	0x84ac <generic_tracepoint_arg+0x305c>
    813c:      	mov	w11, #0x400             // =1024
    8140:      	b	0x84c0 <generic_tracepoint_arg+0x3070>
    8144:      	cmp	w11, w8
    8148:      	b.hi	0x554c <generic_tracepoint_arg+0xfc>
    814c:      	cmp	w8, w10
    8150:      	b.ls	0x56e8 <generic_tracepoint_arg+0x298>
    8154:      	b	0x554c <generic_tracepoint_arg+0xfc>
    8158:      	cmp	w9, #0xc
    815c:      	b.eq	0x8168 <generic_tracepoint_arg+0x2d18>
    8160:      	cmp	w9, #0xa
    8164:      	b.ne	0x8710 <generic_tracepoint_arg+0x32c0>
    8168:      	ldr	x9, [x25]
    816c:      	cmp	x9, x10
    8170:      	b.gt	0x56e8 <generic_tracepoint_arg+0x298>
    8174:      	b	0x8844 <generic_tracepoint_arg+0x33f4>
    8178:      	ldr	x19, [sp, #0x30]
    817c:      	mov	w12, #0x1               // =1
    8180:      	b	0x7244 <generic_tracepoint_arg+0x1df4>
    8184:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8188:      	mov	w8, #0x1                // =1
    818c:      	add	x9, sp, #0x60
    8190:      	ldr	x0, [x0]
    8194:      	b	0x820c <generic_tracepoint_arg+0x2dbc>
    8198:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    819c:      	mov	w8, #0x1                // =1
    81a0:      	add	x9, sp, #0x60
    81a4:      	ldr	x0, [x0]
    81a8:      	b	0x820c <generic_tracepoint_arg+0x2dbc>
    81ac:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    81b0:      	mov	w8, #0x1                // =1
    81b4:      	add	x9, sp, #0x60
    81b8:      	ldr	x0, [x0]
    81bc:      	b	0x820c <generic_tracepoint_arg+0x2dbc>
    81c0:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    81c4:      	mov	w8, #0x1                // =1
    81c8:      	add	x9, sp, #0x60
    81cc:      	ldr	x0, [x0]
    81d0:      	b	0x820c <generic_tracepoint_arg+0x2dbc>
    81d4:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    81d8:      	mov	w8, #0x1                // =1
    81dc:      	add	x9, sp, #0x60
    81e0:      	ldr	x0, [x0]
    81e4:      	b	0x820c <generic_tracepoint_arg+0x2dbc>
    81e8:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    81ec:      	mov	w8, #0x1                // =1
    81f0:      	add	x9, sp, #0x60
    81f4:      	ldr	x0, [x0]
    81f8:      	b	0x820c <generic_tracepoint_arg+0x2dbc>
    81fc:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8200:      	mov	w8, #0x1                // =1
    8204:      	add	x9, sp, #0x60
    8208:      	ldr	x0, [x0]
    820c:      	add	x1, sp, #0x60
    8210:      	blr	x8
    8214:      	cbz	x0, 0x8230 <generic_tracepoint_arg+0x2de0>
    8218:      	ldr	x1, [sp, #0x8]
    821c:      	mov	w8, #0x1                // =1
    8220:      	blr	x8
    8224:      	cmp	x0, #0x0
    8228:      	cset	w22, ne
    822c:      	b	0x8234 <generic_tracepoint_arg+0x2de4>
    8230:      	mov	x22, xzr
    8234:      	ldp	x16, x15, [sp, #0x40]
    8238:      	mov	w2, #0x5ea0             // =24224
    823c:      	mov	w12, #0x1               // =1
    8240:      	ldr	x17, [sp, #0x38]
    8244:      	ldr	w8, [x23, #0x4]
    8248:      	cmp	w8, #0x25
    824c:      	b.hi	0x56e4 <generic_tracepoint_arg+0x294>
    8250:      	mov	x9, #0x50               // =80
    8254:      	lsl	x8, x12, x8
    8258:      	movk	x9, #0xc00, lsl #16
    825c:      	movk	x9, #0x20, lsl #32
    8260:      	tst	x8, x9
    8264:      	b.eq	0x56e4 <generic_tracepoint_arg+0x294>
    8268:      	eor	x22, x22, #0x1
    826c:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    8270:      	ldp	x16, x15, [sp, #0x40]
    8274:      	mov	x22, xzr
    8278:      	mov	w2, #0x5ea0             // =24224
    827c:      	ldr	x17, [sp, #0x38]
    8280:      	ldr	w8, [x23, #0x4]
    8284:      	cmp	w8, #0x25
    8288:      	b.ls	0x8250 <generic_tracepoint_arg+0x2e00>
    828c:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    8290:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8294:      	mov	w8, #0x1                // =1
    8298:      	add	x9, sp, #0x60
    829c:      	ldr	x0, [x0]
    82a0:      	b	0x8318 <generic_tracepoint_arg+0x2ec8>
    82a4:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    82a8:      	mov	w8, #0x1                // =1
    82ac:      	add	x9, sp, #0x60
    82b0:      	ldr	x0, [x0]
    82b4:      	b	0x8318 <generic_tracepoint_arg+0x2ec8>
    82b8:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    82bc:      	mov	w8, #0x1                // =1
    82c0:      	add	x9, sp, #0x60
    82c4:      	ldr	x0, [x0]
    82c8:      	b	0x8318 <generic_tracepoint_arg+0x2ec8>
    82cc:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    82d0:      	mov	w8, #0x1                // =1
    82d4:      	add	x9, sp, #0x60
    82d8:      	ldr	x0, [x0]
    82dc:      	b	0x8318 <generic_tracepoint_arg+0x2ec8>
    82e0:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    82e4:      	mov	w8, #0x1                // =1
    82e8:      	add	x9, sp, #0x60
    82ec:      	ldr	x0, [x0]
    82f0:      	b	0x8318 <generic_tracepoint_arg+0x2ec8>
    82f4:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    82f8:      	mov	w8, #0x1                // =1
    82fc:      	add	x9, sp, #0x60
    8300:      	ldr	x0, [x0]
    8304:      	b	0x8318 <generic_tracepoint_arg+0x2ec8>
    8308:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    830c:      	mov	w8, #0x1                // =1
    8310:      	add	x9, sp, #0x60
    8314:      	ldr	x0, [x0]
    8318:      	add	x1, sp, #0x60
    831c:      	blr	x8
    8320:      	cbz	x0, 0x833c <generic_tracepoint_arg+0x2eec>
    8324:      	mov	w8, #0x1                // =1
    8328:      	mov	x1, x25
    832c:      	blr	x8
    8330:      	cmp	x0, #0x0
    8334:      	cset	w22, ne
    8338:      	b	0x6700 <generic_tracepoint_arg+0x12b0>
    833c:      	mov	x22, xzr
    8340:      	b	0x6700 <generic_tracepoint_arg+0x12b0>
    8344:      	ldp	x16, x15, [sp, #0x40]
    8348:      	mov	x22, xzr
    834c:      	mov	w2, #0x5ea0             // =24224
    8350:      	ldr	x17, [sp, #0x38]
    8354:      	b	0x6710 <generic_tracepoint_arg+0x12c0>
    8358:      	ldrb	w11, [x25]
    835c:      	cmp	w10, w11
    8360:      	b.lo	0x56e8 <generic_tracepoint_arg+0x298>
    8364:      	cmp	w9, #0x15
    8368:      	b.lo	0x8844 <generic_tracepoint_arg+0x33f4>
    836c:      	ldr	w9, [x23, #0x1c]
    8370:      	cmp	w8, #0x2
    8374:      	b.le	0x86b8 <generic_tracepoint_arg+0x3268>
    8378:      	sub	w10, w8, #0x3
    837c:      	cmp	w10, #0x2
    8380:      	b.lo	0x86e8 <generic_tracepoint_arg+0x3298>
    8384:      	cmp	w8, #0x6
    8388:      	b.eq	0x56e8 <generic_tracepoint_arg+0x298>
    838c:      	cmp	w8, #0xc
    8390:      	b.ne	0x554c <generic_tracepoint_arg+0xfc>
    8394:      	ldrb	w10, [x25]
    8398:      	b	0x8438 <generic_tracepoint_arg+0x2fe8>
    839c:      	ldrh	w11, [x25]
    83a0:      	cmp	w10, w11
    83a4:      	b.lo	0x56e8 <generic_tracepoint_arg+0x298>
    83a8:      	cmp	w9, #0x15
    83ac:      	b.lo	0x8844 <generic_tracepoint_arg+0x33f4>
    83b0:      	ldr	w9, [x23, #0x1c]
    83b4:      	cmp	w8, #0x2
    83b8:      	b.le	0x86d0 <generic_tracepoint_arg+0x3280>
    83bc:      	sub	w10, w8, #0x3
    83c0:      	cmp	w10, #0x2
    83c4:      	b.lo	0x86f0 <generic_tracepoint_arg+0x32a0>
    83c8:      	cmp	w8, #0x6
    83cc:      	b.eq	0x56e8 <generic_tracepoint_arg+0x298>
    83d0:      	cmp	w8, #0xc
    83d4:      	b.ne	0x554c <generic_tracepoint_arg+0xfc>
    83d8:      	ldrh	w10, [x25]
    83dc:      	b	0x8438 <generic_tracepoint_arg+0x2fe8>
    83e0:      	ldr	w12, [x25]
    83e4:      	cmp	w12, w11
    83e8:      	mov	w12, #0x1               // =1
    83ec:      	b.hi	0x56e8 <generic_tracepoint_arg+0x298>
    83f0:      	b	0x8404 <generic_tracepoint_arg+0x2fb4>
    83f4:      	ldr	w12, [x25]
    83f8:      	cmp	w12, w11
    83fc:      	mov	w12, #0x1               // =1
    8400:      	b.lo	0x56e8 <generic_tracepoint_arg+0x298>
    8404:      	cmp	w10, #0x15
    8408:      	b.lo	0x8844 <generic_tracepoint_arg+0x33f4>
    840c:      	ldr	w10, [x23, #0x1c]
    8410:      	cmp	w8, #0x2
    8414:      	b.le	0x8444 <generic_tracepoint_arg+0x2ff4>
    8418:      	sub	w9, w8, #0x3
    841c:      	cmp	w9, #0x2
    8420:      	b.lo	0x847c <generic_tracepoint_arg+0x302c>
    8424:      	cmp	w8, #0x6
    8428:      	b.eq	0x56e8 <generic_tracepoint_arg+0x298>
    842c:      	cmp	w8, #0xc
    8430:      	b.ne	0x554c <generic_tracepoint_arg+0xfc>
    8434:      	ldr	w9, [x25]
    8438:      	tst	w9, w10
    843c:      	b.ne	0x56e8 <generic_tracepoint_arg+0x298>
    8440:      	b	0x8844 <generic_tracepoint_arg+0x33f4>
    8444:      	cmp	w8, #0x1
    8448:      	b.eq	0x8484 <generic_tracepoint_arg+0x3034>
    844c:      	cmp	w8, #0x2
    8450:      	b.ne	0x554c <generic_tracepoint_arg+0xfc>
    8454:      	cmp	w9, #0xc
    8458:      	b.hi	0x8828 <generic_tracepoint_arg+0x33d8>
    845c:      	lsl	w9, w12, w9
    8460:      	mov	w11, #0x1402            // =5122
    8464:      	tst	w9, w11
    8468:      	b.eq	0x8828 <generic_tracepoint_arg+0x33d8>
    846c:      	ldr	w9, [x25]
    8470:      	cmp	w9, w10
    8474:      	b.lt	0x56e8 <generic_tracepoint_arg+0x298>
    8478:      	b	0x8844 <generic_tracepoint_arg+0x33f4>
    847c:      	ldr	w9, [x25]
    8480:      	b	0x86f4 <generic_tracepoint_arg+0x32a4>
    8484:      	cmp	w9, #0xc
    8488:      	b.hi	0x8838 <generic_tracepoint_arg+0x33e8>
    848c:      	lsl	w9, w12, w9
    8490:      	mov	w11, #0x1402            // =5122
    8494:      	tst	w9, w11
    8498:      	b.eq	0x8838 <generic_tracepoint_arg+0x33e8>
    849c:      	ldr	w9, [x25]
    84a0:      	cmp	w9, w10
    84a4:      	b.gt	0x56e8 <generic_tracepoint_arg+0x298>
    84a8:      	b	0x8844 <generic_tracepoint_arg+0x33f4>
    84ac:      	and	w8, w25, #0xffff
    84b0:      	mov	w9, #0x1000             // =4096
    84b4:      	cmp	w8, #0x800
    84b8:      	mov	w8, #0x800              // =2048
    84bc:      	csel	w11, w9, w8, hi
    84c0:      	sub	w8, w11, #0x100
    84c4:      	ror	w8, w8, #0x8
    84c8:      	cmp	w8, #0x2
    84cc:      	b.gt	0x84e4 <generic_tracepoint_arg+0x3094>
    84d0:      	cbz	w8, 0x8504 <generic_tracepoint_arg+0x30b4>
    84d4:      	cmp	w8, #0x1
    84d8:      	b.ne	0x84fc <generic_tracepoint_arg+0x30ac>
    84dc:      	mov	w10, #0x7               // =7
    84e0:      	b	0x8510 <generic_tracepoint_arg+0x30c0>
    84e4:      	cmp	w8, #0x3
    84e8:      	b.eq	0x850c <generic_tracepoint_arg+0x30bc>
    84ec:      	cmp	w8, #0x7
    84f0:      	b.ne	0x84fc <generic_tracepoint_arg+0x30ac>
    84f4:      	mov	w10, #0x9               // =9
    84f8:      	b	0x8510 <generic_tracepoint_arg+0x30c0>
    84fc:      	mov	w10, #0xa               // =10
    8500:      	b	0x8510 <generic_tracepoint_arg+0x30c0>
    8504:      	mov	w10, #0x6               // =6
    8508:      	b	0x8510 <generic_tracepoint_arg+0x30c0>
    850c:      	mov	w10, #0x8               // =8
    8510:      	add	x8, x23, #0x10
    8514:      	and	w9, w10, #0xf
    8518:      	ldr	w8, [x8, w9, uxtw #2]
    851c:      	cmn	w8, #0x1
    8520:      	b.eq	0x87cc <generic_tracepoint_arg+0x337c>
    8524:      	stp	w8, w11, [sp, #0x1c]
    8528:      	str	w10, [sp, #0x28]
    852c:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8530:      	mov	w8, #0x1                // =1
    8534:      	add	x19, sp, #0x88
    8538:      	add	x1, sp, #0x88
    853c:      	ldr	x0, [x0]
    8540:      	blr	x8
    8544:      	mov	x9, x0
    8548:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    854c:      	mov	w8, #0x1                // =1
    8550:      	ldr	x0, [x0]
    8554:      	add	x1, sp, #0x88
    8558:      	mov	x19, x9
    855c:      	blr	x8
    8560:      	mov	x22, xzr
    8564:      	cbz	x19, 0x87d0 <generic_tracepoint_arg+0x3380>
    8568:      	mov	w12, #0x1               // =1
    856c:      	cbz	x0, 0x87d4 <generic_tracepoint_arg+0x3384>
    8570:      	ldr	w22, [sp, #0x28]
    8574:      	str	x0, [sp, #0x10]
    8578:      	mov	x0, x19
    857c:      	cmp	w22, #0x5
    8580:      	b.gt	0x85bc <generic_tracepoint_arg+0x316c>
    8584:      	strb	w25, [x0], #0x1
    8588:      	mov	w8, #0x4                // =4
    858c:      	mov	w1, w25
    8590:      	mov	x2, x29
    8594:      	blr	x8
    8598:      	ldr	w8, [sp, #0x20]
    859c:      	subs	w8, w8, w25
    85a0:      	b.ls	0x85f4 <generic_tracepoint_arg+0x31a4>
    85a4:      	add	x9, x19, x25
    85a8:      	and	w1, w8, #0xfff
    85ac:      	mov	w8, #0x4                // =4
    85b0:      	ldr	x2, [sp, #0x10]
    85b4:      	add	x0, x9, #0x1
    85b8:      	b	0x85f0 <generic_tracepoint_arg+0x31a0>
    85bc:      	strh	w25, [x0], #0x2
    85c0:      	mov	w8, #0x4                // =4
    85c4:      	mov	w1, w25
    85c8:      	mov	x2, x29
    85cc:      	blr	x8
    85d0:      	ldr	w8, [sp, #0x20]
    85d4:      	subs	w8, w8, w25
    85d8:      	b.ls	0x85f4 <generic_tracepoint_arg+0x31a4>
    85dc:      	add	x9, x19, x25
    85e0:      	ldr	x2, [sp, #0x10]
    85e4:      	and	w1, w8, #0xfff
    85e8:      	mov	w8, #0x4                // =4
    85ec:      	add	x0, x9, #0x2
    85f0:      	blr	x8
    85f4:      	ldr	w8, [sp, #0x1c]
    85f8:      	cmp	w22, #0x4
    85fc:      	str	w8, [sp, #0x60]
    8600:      	b.le	0x8638 <generic_tracepoint_arg+0x31e8>
    8604:      	cmp	w22, #0x7
    8608:      	b.gt	0x866c <generic_tracepoint_arg+0x321c>
    860c:      	cmp	w22, #0x5
    8610:      	b.eq	0x8784 <generic_tracepoint_arg+0x3334>
    8614:      	cmp	w22, #0x6
    8618:      	b.eq	0x8748 <generic_tracepoint_arg+0x32f8>
    861c:      	cmp	w22, #0x7
    8620:      	b.ne	0x87cc <generic_tracepoint_arg+0x337c>
    8624:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8628:      	mov	w8, #0x1                // =1
    862c:      	add	x9, sp, #0x60
    8630:      	ldr	x0, [x0]
    8634:      	b	0x87a8 <generic_tracepoint_arg+0x3358>
    8638:      	cmp	w22, #0x1
    863c:      	b.le	0x8698 <generic_tracepoint_arg+0x3248>
    8640:      	cmp	w22, #0x2
    8644:      	b.eq	0x8770 <generic_tracepoint_arg+0x3320>
    8648:      	cmp	w22, #0x3
    864c:      	b.eq	0x8734 <generic_tracepoint_arg+0x32e4>
    8650:      	cmp	w22, #0x4
    8654:      	b.ne	0x87cc <generic_tracepoint_arg+0x337c>
    8658:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    865c:      	mov	w8, #0x1                // =1
    8660:      	add	x9, sp, #0x60
    8664:      	ldr	x0, [x0]
    8668:      	b	0x87a8 <generic_tracepoint_arg+0x3358>
    866c:      	cmp	w22, #0x8
    8670:      	b.eq	0x8798 <generic_tracepoint_arg+0x3348>
    8674:      	cmp	w22, #0x9
    8678:      	b.eq	0x875c <generic_tracepoint_arg+0x330c>
    867c:      	cmp	w22, #0xa
    8680:      	b.ne	0x87cc <generic_tracepoint_arg+0x337c>
    8684:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8688:      	mov	w8, #0x1                // =1
    868c:      	add	x9, sp, #0x60
    8690:      	ldr	x0, [x0]
    8694:      	b	0x87a8 <generic_tracepoint_arg+0x3358>
    8698:      	cbz	w22, 0x8720 <generic_tracepoint_arg+0x32d0>
    869c:      	cmp	w22, #0x1
    86a0:      	b.ne	0x87cc <generic_tracepoint_arg+0x337c>
    86a4:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    86a8:      	mov	w8, #0x1                // =1
    86ac:      	add	x9, sp, #0x60
    86b0:      	ldr	x0, [x0]
    86b4:      	b	0x87a8 <generic_tracepoint_arg+0x3358>
    86b8:      	cmp	w8, #0x1
    86bc:      	b.eq	0x8818 <generic_tracepoint_arg+0x33c8>
    86c0:      	cmp	w8, #0x2
    86c4:      	b.ne	0x554c <generic_tracepoint_arg+0xfc>
    86c8:      	ldrb	w10, [x25]
    86cc:      	b	0x883c <generic_tracepoint_arg+0x33ec>
    86d0:      	cmp	w8, #0x1
    86d4:      	b.eq	0x8820 <generic_tracepoint_arg+0x33d0>
    86d8:      	cmp	w8, #0x2
    86dc:      	b.ne	0x554c <generic_tracepoint_arg+0xfc>
    86e0:      	ldrh	w10, [x25]
    86e4:      	b	0x883c <generic_tracepoint_arg+0x33ec>
    86e8:      	ldrb	w10, [x25]
    86ec:      	b	0x86f4 <generic_tracepoint_arg+0x32a4>
    86f0:      	ldrh	w10, [x25]
    86f4:      	cmp	w9, w10
    86f8:      	b.eq	0x56dc <generic_tracepoint_arg+0x28c>
    86fc:      	b	0x8844 <generic_tracepoint_arg+0x33f4>
    8700:      	ldr	x9, [x25]
    8704:      	cmp	x9, x10
    8708:      	b.lo	0x56e8 <generic_tracepoint_arg+0x298>
    870c:      	b	0x8844 <generic_tracepoint_arg+0x33f4>
    8710:      	ldr	x9, [x25]
    8714:      	cmp	x9, x10
    8718:      	b.hi	0x56e8 <generic_tracepoint_arg+0x298>
    871c:      	b	0x8844 <generic_tracepoint_arg+0x33f4>
    8720:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8724:      	mov	w8, #0x1                // =1
    8728:      	add	x9, sp, #0x60
    872c:      	ldr	x0, [x0]
    8730:      	b	0x87a8 <generic_tracepoint_arg+0x3358>
    8734:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8738:      	mov	w8, #0x1                // =1
    873c:      	add	x9, sp, #0x60
    8740:      	ldr	x0, [x0]
    8744:      	b	0x87a8 <generic_tracepoint_arg+0x3358>
    8748:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    874c:      	mov	w8, #0x1                // =1
    8750:      	add	x9, sp, #0x60
    8754:      	ldr	x0, [x0]
    8758:      	b	0x87a8 <generic_tracepoint_arg+0x3358>
    875c:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8760:      	mov	w8, #0x1                // =1
    8764:      	add	x9, sp, #0x60
    8768:      	ldr	x0, [x0]
    876c:      	b	0x87a8 <generic_tracepoint_arg+0x3358>
    8770:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8774:      	mov	w8, #0x1                // =1
    8778:      	add	x9, sp, #0x60
    877c:      	ldr	x0, [x0]
    8780:      	b	0x87a8 <generic_tracepoint_arg+0x3358>
    8784:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8788:      	mov	w8, #0x1                // =1
    878c:      	add	x9, sp, #0x60
    8790:      	ldr	x0, [x0]
    8794:      	b	0x87a8 <generic_tracepoint_arg+0x3358>
    8798:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    879c:      	mov	w8, #0x1                // =1
    87a0:      	add	x9, sp, #0x60
    87a4:      	ldr	x0, [x0]
    87a8:      	add	x1, sp, #0x60
    87ac:      	blr	x8
    87b0:      	cbz	x0, 0x87cc <generic_tracepoint_arg+0x337c>
    87b4:      	mov	w8, #0x1                // =1
    87b8:      	mov	x1, x19
    87bc:      	blr	x8
    87c0:      	cmp	x0, #0x0
    87c4:      	cset	w22, ne
    87c8:      	b	0x87d0 <generic_tracepoint_arg+0x3380>
    87cc:      	mov	x22, xzr
    87d0:      	mov	w12, #0x1               // =1
    87d4:      	ldr	w8, [x23, #0x4]
    87d8:      	ldp	x16, x15, [sp, #0x40]
    87dc:      	mov	w2, #0x5ea0             // =24224
    87e0:      	cmp	w8, #0x25
    87e4:      	ldr	x17, [sp, #0x38]
    87e8:      	b.hi	0x8810 <generic_tracepoint_arg+0x33c0>
    87ec:      	mov	x9, #0x50               // =80
    87f0:      	ldr	x19, [sp, #0x30]
    87f4:      	lsl	x8, x12, x8
    87f8:      	movk	x9, #0xc00, lsl #16
    87fc:      	movk	x9, #0x20, lsl #32
    8800:      	tst	x8, x9
    8804:      	b.eq	0x56e4 <generic_tracepoint_arg+0x294>
    8808:      	cmp	x22, #0x0
    880c:      	b	0x56e0 <generic_tracepoint_arg+0x290>
    8810:      	ldr	x19, [sp, #0x30]
    8814:      	b	0x56e4 <generic_tracepoint_arg+0x294>
    8818:      	ldrb	w10, [x25]
    881c:      	b	0x882c <generic_tracepoint_arg+0x33dc>
    8820:      	ldrh	w10, [x25]
    8824:      	b	0x882c <generic_tracepoint_arg+0x33dc>
    8828:      	ldr	w9, [x25]
    882c:      	cmp	w9, w10
    8830:      	b.lo	0x56e8 <generic_tracepoint_arg+0x298>
    8834:      	b	0x8844 <generic_tracepoint_arg+0x33f4>
    8838:      	ldr	w9, [x25]
    883c:      	cmp	w9, w10
    8840:      	b.hi	0x56e8 <generic_tracepoint_arg+0x298>
    8844:      	orr	w8, w8, #0x2
    8848:      	cmp	w8, #0x6
    884c:      	b.eq	0x56e8 <generic_tracepoint_arg+0x298>
    8850:      	b	0x554c <generic_tracepoint_arg+0xfc>
    8854:      	nop
    8858:      	nop
    885c:      	nop

0000000000008860 <generic_tracepoint_actions>:
    8860:      	sub	sp, sp, #0xf0
    8864:      	str	x29, [sp, #0xa0]
    8868:      	stp	x30, x25, [sp, #0xb0]
    886c:      	stp	x24, x23, [sp, #0xc0]
    8870:      	stp	x22, x21, [sp, #0xd0]
    8874:      	stp	x20, x19, [sp, #0xe0]
    8878:      	str	wzr, [sp, #0x5c]
    887c:      	adrp	x24, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8880:      	mov	w8, #0x1                // =1
    8884:      	add	x9, sp, #0x5c
    8888:      	ldr	x24, [x24]
    888c:      	mov	x25, x0
    8890:      	add	x1, sp, #0x5c
    8894:      	mov	x0, x24
    8898:      	blr	x8
    889c:      	cbz	x0, 0x9560 <generic_tracepoint_actions+0xd00>
    88a0:      	mov	w8, #0x5f04             // =24324
    88a4:      	ldr	w19, [x0, x8]
    88a8:      	cmp	w19, #0x2
    88ac:      	b.lt	0x9560 <generic_tracepoint_actions+0xd00>
    88b0:      	mov	w8, #0x5ef8             // =24312
    88b4:      	add	x1, x0, x8
    88b8:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    88bc:      	mov	w8, #0x1                // =1
    88c0:      	ldr	x0, [x0]
    88c4:      	blr	x8
    88c8:      	cbz	x0, 0x9560 <generic_tracepoint_actions+0xd00>
    88cc:      	and	x8, x19, #0x7ff
    88d0:      	add	x9, sp, #0x60
    88d4:      	add	x1, sp, #0x60
    88d8:      	ldr	w8, [x0, x8]
    88dc:      	str	wzr, [sp, #0x60]
    88e0:      	add	w8, w8, w19
    88e4:      	and	w8, w8, #0x7ff
    88e8:      	add	x22, x0, x8
    88ec:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    88f0:      	mov	w8, #0x1                // =1
    88f4:      	ldr	x0, [x0]
    88f8:      	blr	x8
    88fc:      	cbz	x0, 0x8928 <generic_tracepoint_actions+0xc8>
    8900:      	ldrb	w8, [x0]
    8904:      	tst	w8, #0xff
    8908:      	cset	w8, eq
    890c:      	str	w8, [sp, #0x4c]
    8910:      	mov	w8, #0x8                // =8
    8914:      	cinc	x9, x8, ne
    8918:      	mov	w8, #0x4                // =4
    891c:      	cinc	x8, x8, ne
    8920:      	stp	x8, x9, [sp, #0x28]
    8924:      	b	0x8940 <generic_tracepoint_actions+0xe0>
    8928:      	mov	w8, #0x1                // =1
    892c:      	str	w8, [sp, #0x4c]
    8930:      	mov	w8, #0x4                // =4
    8934:      	str	x8, [sp, #0x28]
    8938:      	mov	w8, #0x8                // =8
    893c:      	str	x8, [sp, #0x30]
    8940:      	mov	w23, wzr
    8944:      	mov	w29, wzr
    8948:      	add	x20, sp, #0x64
    894c:      	str	x22, [sp, #0x50]
    8950:      	str	x25, [sp, #0x40]
    8954:      	mov	w8, #0x1                // =1
    8958:      	str	w8, [sp, #0x3c]
    895c:      	b	0x8970 <generic_tracepoint_actions+0x110>
    8960:      	mov	w29, wzr
    8964:      	add	w23, w23, #0x1
    8968:      	cmp	w23, #0x3
    896c:      	b.eq	0x953c <generic_tracepoint_actions+0xcdc>
    8970:      	ldr	w9, [x22]
    8974:      	lsl	w8, w29, #2
    8978:      	add	w8, w8, #0x4
    897c:      	cmp	w8, w9
    8980:      	b.hs	0x953c <generic_tracepoint_actions+0xcdc>
    8984:      	add	x8, x22, w29, uxtw #2
    8988:      	add	x1, sp, #0x64
    898c:      	mov	x0, x24
    8990:      	ldrsw	x19, [x8, #0x4]
    8994:      	str	wzr, [sp, #0x64]
    8998:      	mov	w8, #0x1                // =1
    899c:      	blr	x8
    89a0:      	cbz	x0, 0x8960 <generic_tracepoint_actions+0x100>
    89a4:      	mov	x21, x0
    89a8:      	cmp	w19, #0x7
    89ac:      	b.gt	0x89e0 <generic_tracepoint_actions+0x180>
    89b0:      	cmp	w19, #0x3
    89b4:      	b.gt	0x8a34 <generic_tracepoint_actions+0x1d4>
    89b8:      	cmp	w19, #0x1
    89bc:      	b.gt	0x8ab4 <generic_tracepoint_actions+0x254>
    89c0:      	cbz	w19, 0x8c10 <generic_tracepoint_actions+0x3b0>
    89c4:      	cmp	w19, #0x1
    89c8:      	b.eq	0x8ac4 <generic_tracepoint_actions+0x264>
    89cc:      	b	0x8e20 <generic_tracepoint_actions+0x5c0>
    89d0:      	nop
    89d4:      	nop
    89d8:      	nop
    89dc:      	nop
    89e0:      	cmp	w19, #0xb
    89e4:      	b.gt	0x8a8c <generic_tracepoint_actions+0x22c>
    89e8:      	sub	w8, w19, #0xa
    89ec:      	cmp	w8, #0x2
    89f0:      	b.lo	0x8b18 <generic_tracepoint_actions+0x2b8>
    89f4:      	cmp	w19, #0x8
    89f8:      	b.eq	0x8b60 <generic_tracepoint_actions+0x300>
    89fc:      	cmp	w19, #0x9
    8a00:      	b.ne	0x8e20 <generic_tracepoint_actions+0x5c0>
    8a04:      	add	w29, w29, #0x1
    8a08:      	add	x8, x22, w29, uxtw #2
    8a0c:      	ldr	w0, [x8, #0x4]
    8a10:      	ldr	w8, [sp, #0x4c]
    8a14:      	cbz	w8, 0x8cb4 <generic_tracepoint_actions+0x454>
    8a18:      	sxtw	x8, w0
    8a1c:      	mov	w9, #0x6d               // =109
    8a20:      	blr	x9
    8a24:      	mov	w20, #0x2               // =2
    8a28:      	mov	w24, w29
    8a2c:      	add	x29, sp, #0x68
    8a30:      	b	0x8dd8 <generic_tracepoint_actions+0x578>
    8a34:      	sub	w8, w19, #0x6
    8a38:      	cmp	w8, #0x2
    8a3c:      	b.lo	0x8b4c <generic_tracepoint_actions+0x2ec>
    8a40:      	cmp	w19, #0x4
    8a44:      	b.eq	0x8b68 <generic_tracepoint_actions+0x308>
    8a48:      	cmp	w19, #0x5
    8a4c:      	b.ne	0x8e20 <generic_tracepoint_actions+0x5c0>
    8a50:      	add	w8, w29, #0x1
    8a54:      	add	x9, x22, #0x4
    8a58:      	add	w29, w29, #0x2
    8a5c:      	ldr	w8, [x9, w8, uxtw #2]
    8a60:      	ldr	w20, [x9, w29, uxtw #2]
    8a64:      	stp	xzr, xzr, [sp, #0x68]
    8a68:      	and	x8, x8, #0x7
    8a6c:      	cmp	w8, #0x4
    8a70:      	b.hi	0x8a84 <generic_tracepoint_actions+0x224>
    8a74:      	add	x9, x21, x8, lsl #2
    8a78:      	mov	w10, #0x5ea0            // =24224
    8a7c:      	ldr	w9, [x9, x10]
    8a80:      	cbz	w9, 0x8fe0 <generic_tracepoint_actions+0x780>
    8a84:      	add	x20, sp, #0x64
    8a88:      	b	0x8e20 <generic_tracepoint_actions+0x5c0>
    8a8c:      	cmp	w19, #0xc
    8a90:      	b.eq	0x8cc4 <generic_tracepoint_actions+0x464>
    8a94:      	cmp	w19, #0xd
    8a98:      	b.eq	0x8b78 <generic_tracepoint_actions+0x318>
    8a9c:      	cmp	w19, #0xe
    8aa0:      	b.ne	0x8e20 <generic_tracepoint_actions+0x5c0>
    8aa4:      	ldr	x20, [sp, #0x30]
    8aa8:      	add	w24, w29, #0x2
    8aac:      	add	x29, sp, #0x68
    8ab0:      	b	0x8dd8 <generic_tracepoint_actions+0x578>
    8ab4:      	cmp	w19, #0x2
    8ab8:      	b.eq	0x8ca8 <generic_tracepoint_actions+0x448>
    8abc:      	cmp	w19, #0x3
    8ac0:      	b.ne	0x8e20 <generic_tracepoint_actions+0x5c0>
    8ac4:      	add	w8, w29, #0x1
    8ac8:      	add	x9, x22, #0x4
    8acc:      	add	w29, w29, #0x2
    8ad0:      	ldr	w22, [x9, w8, uxtw #2]
    8ad4:      	ldr	w20, [x9, w29, uxtw #2]
    8ad8:      	stp	xzr, xzr, [sp, #0x68]
    8adc:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8ae0:      	mov	w8, #0x1                // =1
    8ae4:      	add	x9, sp, #0x88
    8ae8:      	add	x1, sp, #0x88
    8aec:      	str	wzr, [sp, #0x88]
    8af0:      	ldr	x0, [x0]
    8af4:      	blr	x8
    8af8:      	cbz	x0, 0x8b0c <generic_tracepoint_actions+0x2ac>
    8afc:      	and	x8, x22, #0x7
    8b00:      	cmp	w8, #0x4
    8b04:      	b.ls	0x8db0 <generic_tracepoint_actions+0x550>
    8b08:      	mov	w0, wzr
    8b0c:      	ldr	x22, [sp, #0x50]
    8b10:      	add	x20, sp, #0x64
    8b14:      	b	0x8b44 <generic_tracepoint_actions+0x2e4>
    8b18:      	add	w29, w29, #0x1
    8b1c:      	add	x8, x22, w29, uxtw #2
    8b20:      	ldr	w8, [x8, #0x4]
    8b24:      	and	x8, x8, #0x7
    8b28:      	cmp	w8, #0x4
    8b2c:      	b.hi	0x8b40 <generic_tracepoint_actions+0x2e0>
    8b30:      	add	x9, x21, x8, lsl #2
    8b34:      	mov	w10, #0x5ea0            // =24224
    8b38:      	ldr	w9, [x9, x10]
    8b3c:      	cbz	w9, 0x8e38 <generic_tracepoint_actions+0x5d8>
    8b40:      	mov	w0, wzr
    8b44:      	cbnz	w0, 0x8960 <generic_tracepoint_actions+0x100>
    8b48:      	b	0x8e20 <generic_tracepoint_actions+0x5c0>
    8b4c:      	add	w29, w29, #0x1
    8b50:      	add	x8, x22, w29, uxtw #2
    8b54:      	ldr	w8, [x8, #0x4]
    8b58:      	str	w8, [x21, #0x78]
    8b5c:      	b	0x8e20 <generic_tracepoint_actions+0x5c0>
    8b60:      	str	wzr, [sp, #0x3c]
    8b64:      	b	0x8e20 <generic_tracepoint_actions+0x5c0>
    8b68:      	ldr	x20, [sp, #0x28]
    8b6c:      	add	w24, w29, #0x1
    8b70:      	add	x29, sp, #0x68
    8b74:      	b	0x8dd8 <generic_tracepoint_actions+0x578>
    8b78:      	mov	w8, #0xe                // =14
    8b7c:      	blr	x8
    8b80:      	str	x0, [sp, #0x78]
    8b84:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8b88:      	mov	w8, #0x1                // =1
    8b8c:      	add	x9, sp, #0x78
    8b90:      	ldr	x0, [x0]
    8b94:      	add	x1, sp, #0x78
    8b98:      	blr	x8
    8b9c:      	cbz	x0, 0x8e20 <generic_tracepoint_actions+0x5c0>
    8ba0:      	ldur	x8, [x0, #0x4]
    8ba4:      	mov	x22, x25
    8ba8:      	adrp	x25, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8bac:      	add	x9, sp, #0x88
    8bb0:      	str	x8, [sp, #0x88]
    8bb4:      	mov	w8, #0x2                // =2
    8bb8:      	add	x1, sp, #0x88
    8bbc:      	str	w8, [sp, #0x90]
    8bc0:      	mov	w8, #0x1                // =1
    8bc4:      	ldr	x25, [x25]
    8bc8:      	mov	x0, x25
    8bcc:      	blr	x8
    8bd0:      	mov	w9, #0x1                // =1
    8bd4:      	str	w9, [sp, #0xac]
    8bd8:      	cbz	x0, 0x8f6c <generic_tracepoint_actions+0x70c>
    8bdc:      	mov	x25, x22
    8be0:      	ldaxr	w8, [x0]
    8be4:      	add	w8, w8, #0x1
    8be8:      	stlxr	w9, w8, [x0]
    8bec:      	cbnz	w9, 0x8be0 <generic_tracepoint_actions+0x380>
    8bf0:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8bf4:      	mov	w8, #0x3                // =3
    8bf8:      	add	x9, sp, #0x78
    8bfc:      	ldr	x0, [x0]
    8c00:      	add	x1, sp, #0x78
    8c04:      	blr	x8
    8c08:      	ldr	x22, [sp, #0x50]
    8c0c:      	b	0x8e20 <generic_tracepoint_actions+0x5c0>
    8c10:      	add	w8, w29, #0x1
    8c14:      	add	x9, x22, #0x4
    8c18:      	ldr	w25, [x9, w8, uxtw #2]
    8c1c:      	add	w8, w29, #0x2
    8c20:      	ldr	w20, [x9, w8, uxtw #2]
    8c24:      	mov	w8, #0x7d               // =125
    8c28:      	blr	x8
    8c2c:      	str	x0, [sp, #0x68]
    8c30:      	str	wzr, [sp, #0x78]
    8c34:      	str	x25, [sp, #0x10]
    8c38:      	cbz	w25, 0x9398 <generic_tracepoint_actions+0xb38>
    8c3c:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8c40:      	mov	w8, #0x1                // =1
    8c44:      	add	x9, sp, #0x78
    8c48:      	ldr	x0, [x0]
    8c4c:      	add	x1, sp, #0x78
    8c50:      	blr	x8
    8c54:      	cbz	x0, 0x9398 <generic_tracepoint_actions+0xb38>
    8c58:      	mov	x25, x0
    8c5c:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8c60:      	mov	w8, #0x1                // =1
    8c64:      	ldr	x0, [x0]
    8c68:      	add	x9, sp, #0x78
    8c6c:      	add	x1, sp, #0x78
    8c70:      	blr	x8
    8c74:      	ldr	x8, [x21, #0x60]
    8c78:      	mov	x2, x0
    8c7c:      	cmp	w20, #0x2
    8c80:      	str	x25, [sp, #0x8]
    8c84:      	str	x8, [x25]
    8c88:      	ldr	x8, [x21, #0x70]
    8c8c:      	str	x8, [x25, #0x8]
    8c90:      	b.eq	0x91c0 <generic_tracepoint_actions+0x960>
    8c94:      	cmp	w20, #0x1
    8c98:      	b.eq	0x91b8 <generic_tracepoint_actions+0x958>
    8c9c:      	cbnz	w20, 0x9398 <generic_tracepoint_actions+0xb38>
    8ca0:      	ldr	w8, [x21, #0x7c]
    8ca4:      	b	0x91c4 <generic_tracepoint_actions+0x964>
    8ca8:      	mov	w0, #0x9                // =9
    8cac:      	ldr	w8, [sp, #0x4c]
    8cb0:      	cbnz	w8, 0x8a18 <generic_tracepoint_actions+0x1b8>
    8cb4:      	mov	w20, #0x3               // =3
    8cb8:      	mov	w24, w29
    8cbc:      	add	x29, sp, #0x68
    8cc0:      	b	0x8dd8 <generic_tracepoint_actions+0x578>
    8cc4:      	ldr	w8, [sp, #0x4c]
    8cc8:      	add	w24, w29, #0x3
    8ccc:      	cbz	w8, 0x8dd0 <generic_tracepoint_actions+0x570>
    8cd0:      	add	x8, x22, #0x4
    8cd4:      	ldr	w9, [x8, w24, uxtw #2]
    8cd8:      	cmp	w9, #0x4
    8cdc:      	b.hi	0x8cf0 <generic_tracepoint_actions+0x490>
    8ce0:      	add	x10, x21, x9, lsl #2
    8ce4:      	mov	w11, #0x5ea0            // =24224
    8ce8:      	ldr	w10, [x10, x11]
    8cec:      	cbz	w10, 0x9434 <generic_tracepoint_actions+0xbd4>
    8cf0:      	mov	x9, xzr
    8cf4:      	add	w10, w29, #0x2
    8cf8:      	ldr	w20, [x8, w10, uxtw #2]
    8cfc:      	add	w10, w29, #0x1
    8d00:      	ldr	w22, [x8, w10, uxtw #2]
    8d04:      	ldr	w8, [x21, #0x60]
    8d08:      	orr	x25, x8, x9, lsl #32
    8d0c:      	mov	w8, #0xe                // =14
    8d10:      	blr	x8
    8d14:      	str	x0, [sp, #0x98]
    8d18:      	strh	w22, [sp, #0x88]
    8d1c:      	mov	w8, #0x1                // =1
    8d20:      	add	x1, sp, #0x98
    8d24:      	strh	w20, [sp, #0x8a]
    8d28:      	stur	x25, [sp, #0x8c]
    8d2c:      	adrp	x20, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8d30:      	ldr	x20, [x20]
    8d34:      	add	x25, sp, #0x98
    8d38:      	mov	x0, x20
    8d3c:      	blr	x8
    8d40:      	cbz	x0, 0x9098 <generic_tracepoint_actions+0x838>
    8d44:      	ldur	x8, [x0, #0x4]
    8d48:      	mov	w20, #0x1               // =1
    8d4c:      	adrp	x29, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8d50:      	add	x9, sp, #0x78
    8d54:      	str	w20, [sp, #0x80]
    8d58:      	mov	x22, x0
    8d5c:      	add	x1, sp, #0x78
    8d60:      	str	x8, [sp, #0x78]
    8d64:      	mov	w8, #0x1                // =1
    8d68:      	ldr	x29, [x29]
    8d6c:      	mov	x0, x29
    8d70:      	blr	x8
    8d74:      	ldr	x25, [sp, #0x40]
    8d78:      	str	w20, [sp, #0xa8]
    8d7c:      	cbz	x0, 0x9144 <generic_tracepoint_actions+0x8e4>
    8d80:      	ldaxr	w8, [x0]
    8d84:      	add	w8, w8, #0x1
    8d88:      	stlxr	w9, w8, [x0]
    8d8c:      	cbnz	w9, 0x8d80 <generic_tracepoint_actions+0x520>
    8d90:      	ldr	x8, [sp, #0x88]
    8d94:      	ldr	w9, [sp, #0x90]
    8d98:      	add	x29, sp, #0x68
    8d9c:      	str	w9, [x22, #0x8]
    8da0:      	str	x8, [x22]
    8da4:      	ldr	x22, [sp, #0x50]
    8da8:      	mov	w20, #0x6               // =6
    8dac:      	b	0x8dd8 <generic_tracepoint_actions+0x578>
    8db0:      	add	x9, x21, x8, lsl #2
    8db4:      	mov	w10, #0x5ea0            // =24224
    8db8:      	ldr	x22, [sp, #0x50]
    8dbc:      	ldr	w9, [x9, x10]
    8dc0:      	cbz	w9, 0x8ec0 <generic_tracepoint_actions+0x660>
    8dc4:      	mov	w0, wzr
    8dc8:      	add	x20, sp, #0x64
    8dcc:      	b	0x8b44 <generic_tracepoint_actions+0x2e4>
    8dd0:      	mov	w20, #0x7               // =7
    8dd4:      	add	x29, sp, #0x68
    8dd8:      	str	wzr, [sp, #0x68]
    8ddc:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8de0:      	mov	w8, #0x1                // =1
    8de4:      	add	x1, sp, #0x68
    8de8:      	ldr	x0, [x0]
    8dec:      	blr	x8
    8df0:      	cbz	x0, 0x8e10 <generic_tracepoint_actions+0x5b0>
    8df4:      	add	x8, x0, x20, lsl #3
    8df8:      	nop
    8dfc:      	nop
    8e00:      	ldaxr	x9, [x8]
    8e04:      	add	x9, x9, #0x1
    8e08:      	stlxr	w10, x9, [x8]
    8e0c:      	cbnz	w10, 0x8e00 <generic_tracepoint_actions+0x5a0>
    8e10:      	mov	w29, w24
    8e14:      	adrp	x24, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8e18:      	add	x20, sp, #0x64
    8e1c:      	ldr	x24, [x24]
    8e20:      	add	w29, w29, #0x1
    8e24:      	str	x19, [x21, #0x70]
    8e28:      	add	w23, w23, #0x1
    8e2c:      	cmp	w23, #0x3
    8e30:      	b.ne	0x8970 <generic_tracepoint_actions+0x110>
    8e34:      	b	0x953c <generic_tracepoint_actions+0xcdc>
    8e38:      	add	x8, x21, x8, lsl #3
    8e3c:      	ldr	x8, [x8, #0x5e78]
    8e40:      	and	x8, x8, #0x7ff
    8e44:      	add	x8, x21, x8
    8e48:      	ldr	x8, [x8, #0xb8]
    8e4c:      	str	x8, [sp, #0x88]
    8e50:      	cbz	x8, 0x8b40 <generic_tracepoint_actions+0x2e0>
    8e54:      	cmp	w19, #0xa
    8e58:      	b.ne	0x9128 <generic_tracepoint_actions+0x8c8>
    8e5c:      	mov	w8, #0xe                // =14
    8e60:      	blr	x8
    8e64:      	lsr	x8, x0, #32
    8e68:      	mov	x22, x0
    8e6c:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8e70:      	str	w8, [sp, #0x68]
    8e74:      	mov	w8, #0x1                // =1
    8e78:      	add	x9, sp, #0x68
    8e7c:      	add	x1, sp, #0x68
    8e80:      	ldr	x0, [x0]
    8e84:      	blr	x8
    8e88:      	cbz	x0, 0x8f64 <generic_tracepoint_actions+0x704>
    8e8c:      	ldr	w8, [x0]
    8e90:      	mov	x3, xzr
    8e94:      	add	x9, sp, #0x88
    8e98:      	add	x10, sp, #0x68
    8e9c:      	stp	w8, w22, [sp, #0x68]
    8ea0:      	ldr	x8, [x0, #0x8]
    8ea4:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8ea8:      	add	x1, sp, #0x88
    8eac:      	add	x2, sp, #0x68
    8eb0:      	str	x8, [sp, #0x70]
    8eb4:      	mov	w8, #0x2                // =2
    8eb8:      	ldr	x0, [x0]
    8ebc:      	b	0x8f5c <generic_tracepoint_actions+0x6fc>
    8ec0:      	add	x8, x21, x8, lsl #3
    8ec4:      	mov	x22, x0
    8ec8:      	ldr	x8, [x8, #0x5e78]
    8ecc:      	str	wzr, [sp, #0x74]
    8ed0:      	and	x8, x8, #0x7ff
    8ed4:      	add	x8, x21, x8
    8ed8:      	ldr	w8, [x8, #0x90]
    8edc:      	str	w8, [sp, #0x70]
    8ee0:      	mov	w8, #0xe                // =14
    8ee4:      	blr	x8
    8ee8:      	lsr	x8, x0, #32
    8eec:      	cmp	w19, #0x1
    8ef0:      	str	x8, [sp, #0x68]
    8ef4:      	b.ne	0x910c <generic_tracepoint_actions+0x8ac>
    8ef8:      	and	x8, x20, #0x7
    8efc:      	cmp	w8, #0x4
    8f00:      	b.hi	0x8b08 <generic_tracepoint_actions+0x2a8>
    8f04:      	add	x9, x21, x8, lsl #2
    8f08:      	mov	w10, #0x5ea0            // =24224
    8f0c:      	add	x20, sp, #0x64
    8f10:      	ldr	w9, [x9, x10]
    8f14:      	cbnz	w9, 0x8f60 <generic_tracepoint_actions+0x700>
    8f18:      	add	x8, x21, x8, lsl #3
    8f1c:      	mov	x0, x22
    8f20:      	ldr	x8, [x8, #0x5e78]
    8f24:      	and	x8, x8, #0x7ff
    8f28:      	add	x2, x21, x8
    8f2c:      	ldr	w8, [x2, #0x90]!
    8f30:      	and	x8, x8, #0xfff
    8f34:      	add	x1, x8, #0x8
    8f38:      	mov	w8, #0x4                // =4
    8f3c:      	blr	x8
    8f40:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8f44:      	mov	x3, xzr
    8f48:      	mov	w8, #0x2                // =2
    8f4c:      	ldr	x0, [x0]
    8f50:      	add	x9, sp, #0x68
    8f54:      	add	x1, sp, #0x68
    8f58:      	mov	x2, x22
    8f5c:      	blr	x8
    8f60:      	mov	w0, wzr
    8f64:      	ldr	x22, [sp, #0x50]
    8f68:      	b	0x8b44 <generic_tracepoint_actions+0x2e4>
    8f6c:      	mov	w8, #0x2                // =2
    8f70:      	add	x10, sp, #0xac
    8f74:      	add	x11, sp, #0x88
    8f78:      	add	x1, sp, #0x88
    8f7c:      	add	x2, sp, #0xac
    8f80:      	mov	x0, x25
    8f84:      	mov	w3, #0x1                // =1
    8f88:      	blr	x8
    8f8c:      	mov	x25, x22
    8f90:      	cbz	x0, 0x8bf0 <generic_tracepoint_actions+0x390>
    8f94:      	mov	x22, x0
    8f98:      	adrp	x0, 0x8000 <generic_tracepoint_arg+0x2bb0>
    8f9c:      	add	x10, sp, #0x68
    8fa0:      	add	x1, sp, #0x68
    8fa4:      	neg	w8, w22
    8fa8:      	strh	w8, [sp, #0x68]
    8fac:      	mov	w8, #0x3                // =3
    8fb0:      	strh	w8, [sp, #0x6a]
    8fb4:      	mov	x8, #0x3b               // =59
    8fb8:      	movk	x8, #0x2, lsl #32
    8fbc:      	stur	x8, [sp, #0x6c]
    8fc0:      	mov	w8, #0x1                // =1
    8fc4:      	ldr	x0, [x0]
    8fc8:      	blr	x8
    8fcc:      	cbz	x0, 0x944c <generic_tracepoint_actions+0xbec>
    8fd0:      	ldr	w8, [x0]
    8fd4:      	add	w8, w8, #0x1
    8fd8:      	str	w8, [x0]
    8fdc:      	b	0x9478 <generic_tracepoint_actions+0xc18>
    8fe0:      	add	x8, x21, x8, lsl #3
    8fe4:      	ldr	x8, [x8, #0x5e78]
    8fe8:      	and	x8, x8, #0x7ff
    8fec:      	add	x8, x21, x8
    8ff0:      	ldr	w8, [x8, #0x90]
    8ff4:      	str	w8, [sp, #0x70]
    8ff8:      	mov	w8, #0xe                // =14
    8ffc:      	blr	x8
    9000:      	lsr	x8, x0, #32
    9004:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    9008:      	add	x9, sp, #0x68
    900c:      	str	x8, [sp, #0x68]
    9010:      	mov	w8, #0x1                // =1
    9014:      	add	x1, sp, #0x68
    9018:      	ldr	x0, [x0]
    901c:      	blr	x8
    9020:      	cbz	x0, 0x8a84 <generic_tracepoint_actions+0x224>
    9024:      	and	x8, x20, #0x7
    9028:      	cmp	w8, #0x4
    902c:      	b.hi	0x8a84 <generic_tracepoint_actions+0x224>
    9030:      	add	x9, x21, x8, lsl #2
    9034:      	mov	w10, #0x5ea0            // =24224
    9038:      	ldr	w9, [x9, x10]
    903c:      	cbnz	w9, 0x8a84 <generic_tracepoint_actions+0x224>
    9040:      	add	x8, x21, x8, lsl #3
    9044:      	mov	x22, x0
    9048:      	ldr	x8, [x8, #0x5e78]
    904c:      	str	wzr, [sp, #0x74]
    9050:      	and	x8, x8, #0x7ff
    9054:      	add	x8, x21, x8
    9058:      	ldr	w8, [x8, #0x90]
    905c:      	str	w8, [sp, #0x70]
    9060:      	mov	w8, #0xe                // =14
    9064:      	blr	x8
    9068:      	lsr	x8, x0, #32
    906c:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    9070:      	mov	x3, xzr
    9074:      	str	x8, [sp, #0x68]
    9078:      	mov	w8, #0x2                // =2
    907c:      	add	x9, sp, #0x68
    9080:      	mov	x2, x22
    9084:      	ldr	x0, [x0]
    9088:      	add	x1, sp, #0x68
    908c:      	ldr	x22, [sp, #0x50]
    9090:      	blr	x8
    9094:      	b	0x8a84 <generic_tracepoint_actions+0x224>
    9098:      	mov	x3, xzr
    909c:      	mov	w8, #0x2                // =2
    90a0:      	add	x9, sp, #0x88
    90a4:      	add	x1, sp, #0x98
    90a8:      	add	x2, sp, #0x88
    90ac:      	mov	x0, x20
    90b0:      	blr	x8
    90b4:      	ldr	x25, [sp, #0x40]
    90b8:      	ldr	x22, [sp, #0x50]
    90bc:      	add	x29, sp, #0x68
    90c0:      	cbz	x0, 0x8da8 <generic_tracepoint_actions+0x548>
    90c4:      	neg	w8, w0
    90c8:      	adrp	x20, 0x9000 <generic_tracepoint_actions+0x7a0>
    90cc:      	add	x1, sp, #0x68
    90d0:      	strh	w8, [sp, #0x68]
    90d4:      	mov	w8, #0x3                // =3
    90d8:      	strh	w8, [sp, #0x6a]
    90dc:      	mov	x8, #0x6b               // =107
    90e0:      	movk	x8, #0x2, lsl #32
    90e4:      	stur	x8, [sp, #0x6c]
    90e8:      	mov	w8, #0x1                // =1
    90ec:      	ldr	x20, [x20]
    90f0:      	mov	x0, x20
    90f4:      	blr	x8
    90f8:      	cbz	x0, 0x94b4 <generic_tracepoint_actions+0xc54>
    90fc:      	ldr	w8, [x0]
    9100:      	add	w8, w8, #0x1
    9104:      	str	w8, [x0]
    9108:      	b	0x8da8 <generic_tracepoint_actions+0x548>
    910c:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    9110:      	mov	w8, #0x3                // =3
    9114:      	add	x9, sp, #0x68
    9118:      	ldr	x0, [x0]
    911c:      	add	x1, sp, #0x68
    9120:      	blr	x8
    9124:      	b	0x8b0c <generic_tracepoint_actions+0x2ac>
    9128:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    912c:      	mov	w8, #0x3                // =3
    9130:      	add	x9, sp, #0x88
    9134:      	ldr	x0, [x0]
    9138:      	add	x1, sp, #0x88
    913c:      	blr	x8
    9140:      	b	0x8b44 <generic_tracepoint_actions+0x2e4>
    9144:      	mov	w8, #0x2                // =2
    9148:      	add	x9, sp, #0xa8
    914c:      	add	x10, sp, #0x78
    9150:      	add	x1, sp, #0x78
    9154:      	add	x2, sp, #0xa8
    9158:      	mov	x0, x29
    915c:      	mov	w3, #0x1                // =1
    9160:      	blr	x8
    9164:      	cbz	x0, 0x8d90 <generic_tracepoint_actions+0x530>
    9168:      	mov	x29, x0
    916c:      	adrp	x20, 0x9000 <generic_tracepoint_actions+0x7a0>
    9170:      	add	x9, sp, #0x68
    9174:      	add	x1, sp, #0x68
    9178:      	neg	w8, w29
    917c:      	strh	w8, [sp, #0x68]
    9180:      	mov	w8, #0x3                // =3
    9184:      	strh	w8, [sp, #0x6a]
    9188:      	mov	x8, #0x3b               // =59
    918c:      	movk	x8, #0x2, lsl #32
    9190:      	stur	x8, [sp, #0x6c]
    9194:      	mov	w8, #0x1                // =1
    9198:      	ldr	x20, [x20]
    919c:      	mov	x0, x20
    91a0:      	blr	x8
    91a4:      	cbz	x0, 0x94dc <generic_tracepoint_actions+0xc7c>
    91a8:      	ldr	w8, [x0]
    91ac:      	add	w8, w8, #0x1
    91b0:      	str	w8, [x0]
    91b4:      	b	0x9504 <generic_tracepoint_actions+0xca4>
    91b8:      	ldr	w8, [x21, #0x10]
    91bc:      	b	0x91c4 <generic_tracepoint_actions+0x964>
    91c0:      	mov	x8, xzr
    91c4:      	ldr	x9, [sp, #0x8]
    91c8:      	ldr	x25, [sp, #0x40]
    91cc:      	mov	w1, #0xc8               // =200
    91d0:      	add	x0, x9, #0x18
    91d4:      	str	x8, [x9, #0x10]
    91d8:      	mov	w8, #0x4                // =4
    91dc:      	mov	w9, #0xc8               // =200
    91e0:      	str	x0, [sp, #0x18]
    91e4:      	blr	x8
    91e8:      	mov	w8, #0x5e78             // =24184
    91ec:      	mov	x22, xzr
    91f0:      	str	wzr, [sp, #0x24]
    91f4:      	add	x20, x21, x8
    91f8:      	b	0x9210 <generic_tracepoint_actions+0x9b0>
    91fc:      	nop
    9200:      	add	x22, x22, #0x4
    9204:      	add	x20, x20, #0x8
    9208:      	cmp	x22, #0x14
    920c:      	b.eq	0x9334 <generic_tracepoint_actions+0xad4>
    9210:      	str	wzr, [sp, #0x88]
    9214:      	mov	w8, #0x1                // =1
    9218:      	add	x9, sp, #0x88
    921c:      	add	x1, sp, #0x88
    9220:      	mov	x0, x24
    9224:      	blr	x8
    9228:      	cbz	x0, 0x9334 <generic_tracepoint_actions+0xad4>
    922c:      	mov	w8, #0x5ef8             // =24312
    9230:      	add	x1, x0, x8
    9234:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    9238:      	mov	w8, #0x1                // =1
    923c:      	ldr	x0, [x0]
    9240:      	blr	x8
    9244:      	cbz	x0, 0x9334 <generic_tracepoint_actions+0xad4>
    9248:      	add	x8, x0, x22
    924c:      	ldr	w8, [x8, #0x40]
    9250:      	cmn	w8, #0x1
    9254:      	b.eq	0x9334 <generic_tracepoint_actions+0xad4>
    9258:      	ldr	x8, [x20]
    925c:      	ldr	w9, [x21, #0x4]
    9260:      	cmp	x8, x9
    9264:      	b.ge	0x9334 <generic_tracepoint_actions+0xad4>
    9268:      	cmp	x22, #0x10
    926c:      	b.eq	0x92cc <generic_tracepoint_actions+0xa6c>
    9270:      	str	wzr, [sp, #0x88]
    9274:      	mov	w8, #0x1                // =1
    9278:      	add	x9, sp, #0x88
    927c:      	add	x1, sp, #0x88
    9280:      	mov	x0, x24
    9284:      	blr	x8
    9288:      	cbz	x0, 0x92c8 <generic_tracepoint_actions+0xa68>
    928c:      	mov	w8, #0x5ef8             // =24312
    9290:      	add	x1, x0, x8
    9294:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    9298:      	mov	w8, #0x1                // =1
    929c:      	ldr	x0, [x0]
    92a0:      	blr	x8
    92a4:      	cbz	x0, 0x92c8 <generic_tracepoint_actions+0xa68>
    92a8:      	add	x8, x0, x22
    92ac:      	ldr	w9, [x8, #0x44]
    92b0:      	ldr	x8, [x20]
    92b4:      	cmn	w9, #0x1
    92b8:      	b.eq	0x92cc <generic_tracepoint_actions+0xa6c>
    92bc:      	ldr	w9, [x20, #0x8]
    92c0:      	sub	w9, w9, w8
    92c4:      	b	0x92d8 <generic_tracepoint_actions+0xa78>
    92c8:      	ldr	x8, [x20]
    92cc:      	ldr	w9, [x21, #0x4]
    92d0:      	sub	w9, w9, w8
    92d4:      	add	w9, w9, #0x4
    92d8:      	cmp	w9, #0x1
    92dc:      	b.lt	0x9200 <generic_tracepoint_actions+0x9a0>
    92e0:      	mov	w10, #0x3ffc            // =16380
    92e4:      	cmp	w9, #0x28
    92e8:      	add	w8, w8, w10
    92ec:      	mov	w10, #0x28              // =40
    92f0:      	csel	w24, w9, w10, lt
    92f4:      	ldr	w9, [sp, #0x24]
    92f8:      	and	x8, x8, #0x3fff
    92fc:      	add	x8, x21, x8
    9300:      	mov	w1, w24
    9304:      	add	x2, x8, #0x90
    9308:      	mov	w8, #0x4                // =4
    930c:      	and	w25, w9, #0xff
    9310:      	ldr	x9, [sp, #0x18]
    9314:      	add	x0, x9, x25
    9318:      	blr	x8
    931c:      	add	w8, w24, w25
    9320:      	adrp	x24, 0x9000 <generic_tracepoint_actions+0x7a0>
    9324:      	str	w8, [sp, #0x24]
    9328:      	ldr	x24, [x24]
    932c:      	ldr	x25, [sp, #0x40]
    9330:      	b	0x9200 <generic_tracepoint_actions+0x9a0>
    9334:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    9338:      	mov	w8, #0x1                // =1
    933c:      	ldr	x0, [x0]
    9340:      	ldr	x1, [sp, #0x8]
    9344:      	blr	x8
    9348:      	ldr	x22, [sp, #0x50]
    934c:      	cbz	x0, 0x9378 <generic_tracepoint_actions+0xb18>
    9350:      	ldr	x9, [sp, #0x68]
    9354:      	ldr	x11, [sp, #0x10]
    9358:      	mov	x10, #-0x4240           // =-16960
    935c:      	movk	x10, #0xfff0, lsl #16
    9360:      	ldr	x8, [x0]
    9364:      	madd	x9, x11, x10, x9
    9368:      	cmp	x8, x9
    936c:      	b.ls	0x9378 <generic_tracepoint_actions+0xb18>
    9370:      	str	wzr, [sp, #0x3c]
    9374:      	b	0x939c <generic_tracepoint_actions+0xb3c>
    9378:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    937c:      	mov	x3, xzr
    9380:      	mov	w8, #0x2                // =2
    9384:      	ldr	x0, [x0]
    9388:      	ldr	x1, [sp, #0x8]
    938c:      	add	x9, sp, #0x68
    9390:      	add	x2, sp, #0x68
    9394:      	blr	x8
    9398:      	ldr	x25, [sp, #0x40]
    939c:      	add	w8, w29, #0x3
    93a0:      	add	x20, sp, #0x64
    93a4:      	add	x8, x22, w8, uxtw #2
    93a8:      	ldr	w8, [x8, #0x4]
    93ac:      	cbz	w8, 0x93d8 <generic_tracepoint_actions+0xb78>
    93b0:      	ldrb	w8, [x21, #0x1]
    93b4:      	adrp	x1, 0x9000 <generic_tracepoint_actions+0x7a0>
    93b8:      	mov	x2, xzr
    93bc:      	mov	x0, x25
    93c0:      	orr	w8, w8, #0x2
    93c4:      	strb	w8, [x21, #0x1]
    93c8:      	mov	w8, #0x1b               // =27
    93cc:      	ldr	x1, [x1]
    93d0:      	blr	x8
    93d4:      	str	x0, [x21, #0x80]
    93d8:      	add	w8, w29, #0x4
    93dc:      	add	x8, x22, w8, uxtw #2
    93e0:      	ldr	w8, [x8, #0x4]
    93e4:      	cbz	w8, 0x9414 <generic_tracepoint_actions+0xbb4>
    93e8:      	ldrb	w8, [x21, #0x1]
    93ec:      	adrp	x1, 0x9000 <generic_tracepoint_actions+0x7a0>
    93f0:      	mov	w9, #0x100              // =256
    93f4:      	mov	x0, x25
    93f8:      	mov	w2, #0x100              // =256
    93fc:      	orr	w8, w8, #0x4
    9400:      	strb	w8, [x21, #0x1]
    9404:      	mov	w8, #0x1b               // =27
    9408:      	ldr	x1, [x1]
    940c:      	blr	x8
    9410:      	str	x0, [x21, #0x88]
    9414:      	add	w29, w29, #0x5
    9418:      	add	x8, x22, w29, uxtw #2
    941c:      	ldr	w8, [x8, #0x4]
    9420:      	cbz	w8, 0x8e20 <generic_tracepoint_actions+0x5c0>
    9424:      	ldrb	w8, [x21, #0x1]
    9428:      	orr	w8, w8, #0x8
    942c:      	strb	w8, [x21, #0x1]
    9430:      	b	0x8e20 <generic_tracepoint_actions+0x5c0>
    9434:      	add	x9, x21, x9, lsl #3
    9438:      	ldr	x9, [x9, #0x5e78]
    943c:      	and	x9, x9, #0x7ff
    9440:      	add	x9, x21, x9
    9444:      	ldr	x9, [x9, #0x90]
    9448:      	b	0x8cf4 <generic_tracepoint_actions+0x494>
    944c:      	mov	w8, #0x1                // =1
    9450:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    9454:      	mov	x3, xzr
    9458:      	str	w8, [sp, #0x98]
    945c:      	mov	w8, #0x2                // =2
    9460:      	add	x9, sp, #0x98
    9464:      	add	x10, sp, #0x68
    9468:      	ldr	x0, [x0]
    946c:      	add	x1, sp, #0x68
    9470:      	add	x2, sp, #0x98
    9474:      	blr	x8
    9478:      	cbz	w22, 0x8bf0 <generic_tracepoint_actions+0x390>
    947c:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    9480:      	mov	w8, #0x1                // =1
    9484:      	add	x9, sp, #0x88
    9488:      	ldr	x0, [x0]
    948c:      	add	x1, sp, #0x88
    9490:      	blr	x8
    9494:      	cbz	x0, 0x8bf0 <generic_tracepoint_actions+0x390>
    9498:      	ldr	w8, [sp, #0xac]
    949c:      	nop
    94a0:      	ldaxr	w9, [x0]
    94a4:      	add	w9, w9, w8
    94a8:      	stlxr	w10, w9, [x0]
    94ac:      	cbnz	w10, 0x94a0 <generic_tracepoint_actions+0xc40>
    94b0:      	b	0x8bf0 <generic_tracepoint_actions+0x390>
    94b4:      	mov	w8, #0x1                // =1
    94b8:      	mov	x3, xzr
    94bc:      	add	x9, sp, #0x78
    94c0:      	str	w8, [sp, #0x78]
    94c4:      	mov	w8, #0x2                // =2
    94c8:      	add	x1, sp, #0x68
    94cc:      	add	x2, sp, #0x78
    94d0:      	mov	x0, x20
    94d4:      	blr	x8
    94d8:      	b	0x8da8 <generic_tracepoint_actions+0x548>
    94dc:      	mov	w8, #0x1                // =1
    94e0:      	mov	x3, xzr
    94e4:      	add	x9, sp, #0xac
    94e8:      	str	w8, [sp, #0xac]
    94ec:      	mov	w8, #0x2                // =2
    94f0:      	add	x10, sp, #0x68
    94f4:      	add	x1, sp, #0x68
    94f8:      	add	x2, sp, #0xac
    94fc:      	mov	x0, x20
    9500:      	blr	x8
    9504:      	cbz	w29, 0x8d90 <generic_tracepoint_actions+0x530>
    9508:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    950c:      	mov	w8, #0x1                // =1
    9510:      	add	x9, sp, #0x78
    9514:      	ldr	x0, [x0]
    9518:      	add	x1, sp, #0x78
    951c:      	blr	x8
    9520:      	cbz	x0, 0x8d90 <generic_tracepoint_actions+0x530>
    9524:      	ldr	w8, [sp, #0xa8]
    9528:      	ldaxr	w9, [x0]
    952c:      	add	w9, w9, w8
    9530:      	stlxr	w10, w9, [x0]
    9534:      	cbnz	w10, 0x9528 <generic_tracepoint_actions+0xcc8>
    9538:      	b	0x8d90 <generic_tracepoint_actions+0x530>
    953c:      	ldr	w8, [sp, #0x3c]
    9540:      	cbz	w8, 0x9560 <generic_tracepoint_actions+0xd00>
    9544:      	adrp	x1, 0x9000 <generic_tracepoint_actions+0x7a0>
    9548:      	mov	w8, #0x5                // =5
    954c:      	mov	w9, #0xc                // =12
    9550:      	ldr	x1, [x1]
    9554:      	mov	x0, x25
    9558:      	mov	w2, #0x5                // =5
    955c:      	blr	x9
    9560:      	ldp	x20, x19, [sp, #0xe0]
    9564:      	mov	w0, wzr
    9568:      	ldr	x29, [sp, #0xa0]
    956c:      	ldp	x22, x21, [sp, #0xd0]
    9570:      	ldp	x24, x23, [sp, #0xc0]
    9574:      	ldp	x30, x25, [sp, #0xb0]
    9578:      	add	sp, sp, #0xf0
    957c:      	ret

0000000000009580 <generic_tracepoint_output>:
    9580:      	sub	sp, sp, #0xc0
    9584:      	str	x29, [sp, #0x70]
    9588:      	stp	x30, x25, [sp, #0x80]
    958c:      	stp	x24, x23, [sp, #0x90]
    9590:      	stp	x22, x21, [sp, #0xa0]
    9594:      	stp	x20, x19, [sp, #0xb0]
    9598:      	mov	x20, x0
    959c:      	str	wzr, [sp, #0x4]
    95a0:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    95a4:      	mov	w8, #0x1                // =1
    95a8:      	ldr	x0, [x0]
    95ac:      	add	x9, sp, #0x4
    95b0:      	add	x1, sp, #0x4
    95b4:      	blr	x8
    95b8:      	cbz	x0, 0x9b50 <generic_tracepoint_output+0x5d0>
    95bc:      	adrp	x21, 0x9000 <generic_tracepoint_actions+0x7a0>
    95c0:      	ldr	x8, [x0, #0x5ee8]
    95c4:      	mov	x19, x0
    95c8:      	ldr	x21, [x21]
    95cc:      	cbz	x8, 0x9858 <generic_tracepoint_output+0x2d8>
    95d0:      	mov	w8, #0xe                // =14
    95d4:      	blr	x8
    95d8:      	mov	w8, #0x23               // =35
    95dc:      	lsr	x22, x0, #32
    95e0:      	blr	x8
    95e4:      	str	w22, [sp, #0x28]
    95e8:      	mov	w8, #0x1                // =1
    95ec:      	add	x9, sp, #0x28
    95f0:      	mov	x23, x0
    95f4:      	add	x1, sp, #0x28
    95f8:      	mov	x0, x21
    95fc:      	blr	x8
    9600:      	cbz	x0, 0x9858 <generic_tracepoint_output+0x2d8>
    9604:      	add	x2, x23, #0xb50
    9608:      	mov	w29, #0x8               // =8
    960c:      	add	x8, sp, #0x78
    9610:      	mov	w9, #0x4                // =4
    9614:      	mov	x22, x0
    9618:      	add	x24, x0, #0x28
    961c:      	add	x0, sp, #0x78
    9620:      	mov	w1, #0x8                // =8
    9624:      	mov	w25, #0x4               // =4
    9628:      	blr	x9
    962c:      	ldr	x8, [sp, #0x78]
    9630:      	mov	w9, #0x48               // =72
    9634:      	add	x10, sp, #0x28
    9638:      	mov	w11, #0x4               // =4
    963c:      	ldr	x2, [sp, #0x78]
    9640:      	add	x0, sp, #0x28
    9644:      	mov	w1, #0x48               // =72
    9648:      	blr	x11
    964c:      	ldr	x8, [sp, #0x30]
    9650:      	mov	w9, #0x4                // =4
    9654:      	mov	x0, x24
    9658:      	mov	w1, #0x4                // =4
    965c:      	add	x8, x8, #0x218
    9660:      	ldr	x8, [sp, #0x30]
    9664:      	add	x2, x8, #0x218
    9668:      	blr	x9
    966c:      	ldr	x8, [sp, #0x38]
    9670:      	add	x0, x22, #0x2c
    9674:      	mov	w9, #0x4                // =4
    9678:      	mov	w1, #0x4                // =4
    967c:      	add	x8, x8, #0x4d8
    9680:      	ldr	x8, [sp, #0x38]
    9684:      	add	x2, x8, #0x4d8
    9688:      	blr	x9
    968c:      	ldr	x8, [sp, #0x40]
    9690:      	add	x0, x22, #0x30
    9694:      	mov	w9, #0x4                // =4
    9698:      	mov	w1, #0x4                // =4
    969c:      	add	x8, x8, #0x58
    96a0:      	ldr	x8, [sp, #0x40]
    96a4:      	add	x2, x8, #0x58
    96a8:      	blr	x9
    96ac:      	str	xzr, [sp, #0x20]
    96b0:      	add	x2, x23, #0x938
    96b4:      	add	x8, sp, #0x20
    96b8:      	add	x0, sp, #0x20
    96bc:      	mov	w1, #0x8                // =8
    96c0:      	blr	x25
    96c4:      	ldr	x8, [sp, #0x20]
    96c8:      	cbz	x8, 0x974c <generic_tracepoint_output+0x1cc>
    96cc:      	str	wzr, [sp, #0x1c]
    96d0:      	add	x8, x8, #0x4
    96d4:      	add	x9, sp, #0x1c
    96d8:      	mov	w10, #0x4               // =4
    96dc:      	add	x0, sp, #0x1c
    96e0:      	mov	w1, #0x4                // =4
    96e4:      	mov	w24, #0x4               // =4
    96e8:      	ldr	x8, [sp, #0x20]
    96ec:      	add	x2, x8, #0x4
    96f0:      	blr	x10
    96f4:      	ldr	x8, [sp, #0x20]
    96f8:      	ldrsw	x9, [sp, #0x1c]
    96fc:      	add	x10, sp, #0x8
    9700:      	mov	w11, #0x4               // =4
    9704:      	add	x0, sp, #0x8
    9708:      	mov	w1, #0x10               // =16
    970c:      	add	x8, x8, x9, lsl #4
    9710:      	mov	w9, #0x10               // =16
    9714:      	add	x8, x8, #0x80
    9718:      	ldr	x8, [sp, #0x20]
    971c:      	ldrsw	x9, [sp, #0x1c]
    9720:      	add	x8, x8, x9, lsl #4
    9724:      	add	x2, x8, #0x80
    9728:      	blr	x11
    972c:      	ldr	x8, [sp, #0x10]
    9730:      	add	x0, x22, #0x34
    9734:      	mov	w1, #0x4                // =4
    9738:      	add	x8, x8, #0x158
    973c:      	ldr	x8, [sp, #0x10]
    9740:      	add	x2, x8, #0x158
    9744:      	blr	x24
    9748:      	b	0x9750 <generic_tracepoint_output+0x1d0>
    974c:      	str	wzr, [x22, #0x34]
    9750:      	ldr	x8, [sp, #0x48]
    9754:      	add	x0, x22, #0x38
    9758:      	mov	w9, #0x4                // =4
    975c:      	mov	w1, #0x4                // =4
    9760:      	mov	w24, #0x4               // =4
    9764:      	add	x8, x8, #0x158
    9768:      	ldr	x8, [sp, #0x48]
    976c:      	add	x2, x8, #0x158
    9770:      	blr	x9
    9774:      	ldr	x8, [sp, #0x50]
    9778:      	add	x0, x22, #0x3c
    977c:      	mov	w9, #0x4                // =4
    9780:      	mov	w1, #0x4                // =4
    9784:      	add	x8, x8, #0x118
    9788:      	ldr	x8, [sp, #0x50]
    978c:      	add	x2, x8, #0x118
    9790:      	blr	x9
    9794:      	ldr	x8, [sp, #0x58]
    9798:      	add	x0, x22, #0x40
    979c:      	mov	w9, #0x4                // =4
    97a0:      	mov	w1, #0x4                // =4
    97a4:      	add	x8, x8, #0x98
    97a8:      	ldr	x8, [sp, #0x58]
    97ac:      	add	x2, x8, #0x98
    97b0:      	blr	x9
    97b4:      	ldr	x8, [sp, #0x60]
    97b8:      	add	x0, x22, #0x44
    97bc:      	mov	w9, #0x4                // =4
    97c0:      	mov	w1, #0x4                // =4
    97c4:      	add	x8, x8, #0x98
    97c8:      	ldr	x8, [sp, #0x60]
    97cc:      	add	x2, x8, #0x98
    97d0:      	blr	x9
    97d4:      	ldr	x8, [sp, #0x68]
    97d8:      	add	x0, x22, #0x48
    97dc:      	mov	w9, #0x4                // =4
    97e0:      	mov	w1, #0x4                // =4
    97e4:      	add	x8, x8, #0x58
    97e8:      	ldr	x8, [sp, #0x68]
    97ec:      	add	x2, x8, #0x58
    97f0:      	blr	x9
    97f4:      	str	xzr, [sp, #0x8]
    97f8:      	str	xzr, [sp, #0x20]
    97fc:      	add	x2, x23, #0xae0
    9800:      	mov	w23, #0x8               // =8
    9804:      	add	x8, sp, #0x8
    9808:      	mov	w9, #0x4                // =4
    980c:      	add	x0, sp, #0x8
    9810:      	mov	w1, #0x8                // =8
    9814:      	blr	x9
    9818:      	ldr	x8, [sp, #0x8]
    981c:      	add	x9, sp, #0x20
    9820:      	mov	w10, #0x4               // =4
    9824:      	add	x0, sp, #0x20
    9828:      	mov	w1, #0x8                // =8
    982c:      	add	x8, x8, #0x90
    9830:      	ldr	x8, [sp, #0x8]
    9834:      	add	x2, x8, #0x90
    9838:      	blr	x10
    983c:      	ldr	x8, [sp, #0x20]
    9840:      	add	x0, x22, #0x4c
    9844:      	mov	w1, #0x4                // =4
    9848:      	add	x8, x8, #0x158
    984c:      	ldr	x8, [sp, #0x20]
    9850:      	add	x2, x8, #0x158
    9854:      	blr	x24
    9858:      	ldr	x8, [x19, #0x5ef0]
    985c:      	cbz	x8, 0x98f8 <generic_tracepoint_output+0x378>
    9860:      	mov	w8, #0xe                // =14
    9864:      	blr	x8
    9868:      	mov	w8, #0x23               // =35
    986c:      	lsr	x23, x0, #32
    9870:      	blr	x8
    9874:      	str	w23, [sp, #0x28]
    9878:      	mov	w8, #0x1                // =1
    987c:      	add	x9, sp, #0x28
    9880:      	mov	x22, x0
    9884:      	add	x1, sp, #0x28
    9888:      	mov	x0, x21
    988c:      	blr	x8
    9890:      	cbz	x0, 0x98f8 <generic_tracepoint_output+0x378>
    9894:      	add	x2, x22, #0xae0
    9898:      	mov	w22, #0x8               // =8
    989c:      	add	x8, sp, #0x28
    98a0:      	mov	w9, #0x4                // =4
    98a4:      	add	x21, x0, #0x50
    98a8:      	mov	x24, x0
    98ac:      	add	x0, sp, #0x28
    98b0:      	mov	w1, #0x8                // =8
    98b4:      	mov	w23, #0x4               // =4
    98b8:      	blr	x9
    98bc:      	ldr	x25, [sp, #0x28]
    98c0:      	add	x0, x24, #0x58
    98c4:      	mov	w8, #0x4                // =4
    98c8:      	mov	w1, #0x8                // =8
    98cc:      	add	x2, x25, #0x40
    98d0:      	blr	x8
    98d4:      	add	x0, x24, #0x60
    98d8:      	add	x2, x25, #0x30
    98dc:      	mov	w8, #0x4                // =4
    98e0:      	mov	w1, #0x8                // =8
    98e4:      	blr	x8
    98e8:      	add	x2, x25, #0x38
    98ec:      	mov	x0, x21
    98f0:      	mov	w1, #0x8                // =8
    98f4:      	blr	x23
    98f8:      	ldr	w8, [x19, #0x4]
    98fc:      	mov	w9, #0x2328             // =9000
    9900:      	str	wzr, [sp, #0x8]
    9904:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    9908:      	add	x1, sp, #0x8
    990c:      	add	w8, w8, #0x90
    9910:      	ldr	x0, [x0]
    9914:      	and	w8, w8, #0x7fff
    9918:      	cmp	w8, w9
    991c:      	csel	w21, w8, w9, lo
    9920:      	mov	w8, #0x1                // =1
    9924:      	add	x9, sp, #0x8
    9928:      	blr	x8
    992c:      	cbz	x0, 0x9998 <generic_tracepoint_output+0x418>
    9930:      	ldrb	w8, [x0, #0x28]
    9934:      	cbz	w8, 0x9998 <generic_tracepoint_output+0x418>
    9938:      	adrp	x1, 0x9000 <generic_tracepoint_actions+0x7a0>
    993c:      	mov	w8, #-0x1               // =-1
    9940:      	mov	w9, #0x19               // =25
    9944:      	ldr	x1, [x1]
    9948:      	mov	x0, x20
    994c:      	mov	w2, #-0x1               // =-1
    9950:      	mov	x3, x19
    9954:      	mov	x4, x21
    9958:      	blr	x9
    995c:      	tbnz	x0, #0x3f, 0x9a44 <generic_tracepoint_output+0x4c4>
    9960:      	str	wzr, [sp, #0x28]
    9964:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    9968:      	mov	w8, #0x1                // =1
    996c:      	add	x9, sp, #0x28
    9970:      	ldr	x0, [x0]
    9974:      	add	x1, sp, #0x28
    9978:      	blr	x8
    997c:      	cbz	x0, 0x9b50 <generic_tracepoint_output+0x5d0>
    9980:      	add	x8, x0, #0x8
    9984:      	ldaxr	x9, [x8]
    9988:      	add	x9, x9, #0x1
    998c:      	stlxr	w10, x9, [x8]
    9990:      	cbnz	w10, 0x9984 <generic_tracepoint_output+0x404>
    9994:      	b	0x9b50 <generic_tracepoint_output+0x5d0>
    9998:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    999c:      	mov	x3, xzr
    99a0:      	mov	w8, #0x82               // =130
    99a4:      	ldr	x0, [x0]
    99a8:      	mov	x1, x19
    99ac:      	mov	x2, x21
    99b0:      	blr	x8
    99b4:      	tbnz	x0, #0x3f, 0x99f4 <generic_tracepoint_output+0x474>
    99b8:      	str	wzr, [sp, #0x28]
    99bc:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    99c0:      	mov	w8, #0x1                // =1
    99c4:      	add	x9, sp, #0x28
    99c8:      	ldr	x0, [x0]
    99cc:      	add	x1, sp, #0x28
    99d0:      	blr	x8
    99d4:      	cbz	x0, 0x9b50 <generic_tracepoint_output+0x5d0>
    99d8:      	add	x8, x0, #0x8
    99dc:      	nop
    99e0:      	ldaxr	x9, [x8]
    99e4:      	add	x9, x9, #0x1
    99e8:      	stlxr	w10, x9, [x8]
    99ec:      	cbnz	w10, 0x99e0 <generic_tracepoint_output+0x460>
    99f0:      	b	0x9b50 <generic_tracepoint_output+0x5d0>
    99f4:      	mov	x19, x0
    99f8:      	str	wzr, [sp, #0x28]
    99fc:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    9a00:      	mov	w8, #0x1                // =1
    9a04:      	ldr	x0, [x0]
    9a08:      	add	x9, sp, #0x28
    9a0c:      	add	x1, sp, #0x28
    9a10:      	blr	x8
    9a14:      	cbz	x0, 0x9b50 <generic_tracepoint_output+0x5d0>
    9a18:      	mov	x8, x19
    9a1c:      	cmn	x19, #0xc
    9a20:      	b.gt	0x9a94 <generic_tracepoint_output+0x514>
    9a24:      	cmn	x8, #0x1c
    9a28:      	b.eq	0x9ad4 <generic_tracepoint_output+0x554>
    9a2c:      	cmn	x8, #0x16
    9a30:      	b.eq	0x9aec <generic_tracepoint_output+0x56c>
    9a34:      	cmn	x8, #0x10
    9a38:      	b.ne	0x9ae4 <generic_tracepoint_output+0x564>
    9a3c:      	add	x8, x0, #0x328
    9a40:      	b	0x9b00 <generic_tracepoint_output+0x580>
    9a44:      	mov	x19, x0
    9a48:      	str	wzr, [sp, #0x28]
    9a4c:      	adrp	x0, 0x9000 <generic_tracepoint_actions+0x7a0>
    9a50:      	mov	w8, #0x1                // =1
    9a54:      	ldr	x0, [x0]
    9a58:      	add	x9, sp, #0x28
    9a5c:      	add	x1, sp, #0x28
    9a60:      	blr	x8
    9a64:      	cbz	x0, 0x9b50 <generic_tracepoint_output+0x5d0>
    9a68:      	mov	x8, x19
    9a6c:      	cmn	x19, #0xc
    9a70:      	b.gt	0x9ab4 <generic_tracepoint_output+0x534>
    9a74:      	cmn	x8, #0x1c
    9a78:      	b.eq	0x9b14 <generic_tracepoint_output+0x594>
    9a7c:      	cmn	x8, #0x16
    9a80:      	b.eq	0x9b2c <generic_tracepoint_output+0x5ac>
    9a84:      	cmn	x8, #0x10
    9a88:      	b.ne	0x9b24 <generic_tracepoint_output+0x5a4>
    9a8c:      	add	x8, x0, #0x328
    9a90:      	b	0x9b40 <generic_tracepoint_output+0x5c0>
    9a94:      	cmn	x8, #0xb
    9a98:      	b.eq	0x9adc <generic_tracepoint_output+0x55c>
    9a9c:      	cmn	x8, #0x7
    9aa0:      	b.eq	0x9af4 <generic_tracepoint_output+0x574>
    9aa4:      	cmn	x8, #0x2
    9aa8:      	b.ne	0x9ae4 <generic_tracepoint_output+0x564>
    9aac:      	add	x8, x0, #0x318
    9ab0:      	b	0x9b00 <generic_tracepoint_output+0x580>
    9ab4:      	cmn	x8, #0xb
    9ab8:      	b.eq	0x9b1c <generic_tracepoint_output+0x59c>
    9abc:      	cmn	x8, #0x7
    9ac0:      	b.eq	0x9b34 <generic_tracepoint_output+0x5b4>
    9ac4:      	cmn	x8, #0x2
    9ac8:      	b.ne	0x9b24 <generic_tracepoint_output+0x5a4>
    9acc:      	add	x8, x0, #0x318
    9ad0:      	b	0x9b40 <generic_tracepoint_output+0x5c0>
    9ad4:      	add	x8, x0, #0x338
    9ad8:      	b	0x9b00 <generic_tracepoint_output+0x580>
    9adc:      	add	x8, x0, #0x340
    9ae0:      	b	0x9b00 <generic_tracepoint_output+0x580>
    9ae4:      	add	x8, x0, #0x310
    9ae8:      	b	0x9b00 <generic_tracepoint_output+0x580>
    9aec:      	add	x8, x0, #0x330
    9af0:      	b	0x9b00 <generic_tracepoint_output+0x580>
    9af4:      	add	x8, x0, #0x320
    9af8:      	nop
    9afc:      	nop
    9b00:      	ldaxr	x9, [x8]
    9b04:      	add	x9, x9, #0x1
    9b08:      	stlxr	w10, x9, [x8]
    9b0c:      	cbnz	w10, 0x9b00 <generic_tracepoint_output+0x580>
    9b10:      	b	0x9b50 <generic_tracepoint_output+0x5d0>
    9b14:      	add	x8, x0, #0x338
    9b18:      	b	0x9b40 <generic_tracepoint_output+0x5c0>
    9b1c:      	add	x8, x0, #0x340
    9b20:      	b	0x9b40 <generic_tracepoint_output+0x5c0>
    9b24:      	add	x8, x0, #0x310
    9b28:      	b	0x9b40 <generic_tracepoint_output+0x5c0>
    9b2c:      	add	x8, x0, #0x330
    9b30:      	b	0x9b40 <generic_tracepoint_output+0x5c0>
    9b34:      	add	x8, x0, #0x320
    9b38:      	nop
    9b3c:      	nop
    9b40:      	ldaxr	x9, [x8]
    9b44:      	add	x9, x9, #0x1
    9b48:      	stlxr	w10, x9, [x8]
    9b4c:      	cbnz	w10, 0x9b40 <generic_tracepoint_output+0x5c0>
    9b50:      	ldp	x20, x19, [sp, #0xb0]
    9b54:      	mov	w0, wzr
    9b58:      	ldr	x29, [sp, #0x70]
    9b5c:      	ldp	x22, x21, [sp, #0xa0]
    9b60:      	ldp	x24, x23, [sp, #0x90]
    9b64:      	ldp	x30, x25, [sp, #0x80]
    9b68:      	add	sp, sp, #0xc0
    9b6c:      	ret

Disassembly of section tracepoint/generic_tracepoint:

0000000000000000 <generic_tracepoint_event>:
       0:      	sub	sp, sp, #0xd0
       4:      	stp	x30, x25, [sp, #0x90]
       8:      	stp	x24, x23, [sp, #0xa0]
       c:      	stp	x22, x21, [sp, #0xb0]
      10:      	stp	x20, x19, [sp, #0xc0]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <generic_tracepoint_event>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x3184 <generic_tracepoint_event+0x3184>
      38:      	mov	x20, x0
      3c:      	adrp	x0, 0x0 <generic_tracepoint_event>
      40:      	mov	w8, #0x1                // =1
      44:      	ldr	x0, [x0]
      48:      	add	x9, sp, #0xc
      4c:      	add	x1, sp, #0xc
      50:      	blr	x8
      54:      	cbz	x0, 0x3184 <generic_tracepoint_event+0x3184>
      58:      	ldr	w8, [x0, #0x64]
      5c:      	mov	x21, x0
      60:      	str	w8, [sp, #0x1c]
      64:      	cbz	w8, 0x220 <generic_tracepoint_event+0x220>
      68:      	adrp	x22, 0x0 <generic_tracepoint_event>
      6c:      	mov	w8, #0x1                // =1
      70:      	add	x9, sp, #0x1c
      74:      	ldr	x22, [x22]
      78:      	add	x1, sp, #0x1c
      7c:      	mov	x0, x22
      80:      	blr	x8
      84:      	cbz	x0, 0x3184 <generic_tracepoint_event+0x3184>
      88:      	mov	x23, x0
      8c:      	str	wzr, [sp, #0x84]
      90:      	adrp	x0, 0x0 <generic_tracepoint_event>
      94:      	mov	w8, #0x1                // =1
      98:      	ldr	x0, [x0]
      9c:      	add	x9, sp, #0x84
      a0:      	add	x1, sp, #0x84
      a4:      	blr	x8
      a8:      	cbz	x0, 0xd4 <generic_tracepoint_event+0xd4>
      ac:      	ldr	x8, [x0, #0x20]
      b0:      	mov	w9, #0x7270             // =29296
      b4:      	movk	w9, #0x6367, lsl #16
      b8:      	cmp	x8, x9
      bc:      	b.ne	0xdc <generic_tracepoint_event+0xdc>
      c0:      	mov	w8, #0x50               // =80
      c4:      	blr	x8
      c8:      	str	x0, [sp, #0x30]
      cc:      	cbnz	x0, 0x1d0 <generic_tracepoint_event+0x1d0>
      d0:      	b	0x3184 <generic_tracepoint_event+0x3184>
      d4:      	mov	w24, wzr
      d8:      	b	0xe0 <generic_tracepoint_event+0xe0>
      dc:      	ldr	w24, [x0, #0x10]
      e0:      	mov	w8, #0x23               // =35
      e4:      	blr	x8
      e8:      	str	xzr, [sp, #0x88]
      ec:      	add	x2, x0, #0xcd0
      f0:      	mov	w8, #0x8                // =8
      f4:      	mov	w9, #0x71               // =113
      f8:      	add	x10, sp, #0x20
      fc:      	add	x0, sp, #0x20
     100:      	mov	w1, #0x8                // =8
     104:      	blr	x9
     108:      	ldr	x8, [sp, #0x20]
     10c:      	cbz	x8, 0x164 <generic_tracepoint_event+0x164>
     110:      	cmp	w24, #0xb
     114:      	b.hi	0x164 <generic_tracepoint_event+0x164>
     118:      	ubfiz	x9, x24, #3, #32
     11c:      	mov	w10, #0x8               // =8
     120:      	mov	w11, #0x71              // =113
     124:      	add	x12, sp, #0x38
     128:      	add	x0, sp, #0x38
     12c:      	mov	w1, #0x8                // =8
     130:      	add	x8, x8, x9
     134:      	ldr	x8, [sp, #0x20]
     138:      	add	x2, x8, x9
     13c:      	blr	x11
     140:      	ldr	x8, [sp, #0x38]
     144:      	cbz	x8, 0x164 <generic_tracepoint_event+0x164>
     148:      	mov	w9, #0x8                // =8
     14c:      	mov	w10, #0x71              // =113
     150:      	add	x11, sp, #0x88
     154:      	ldr	x2, [sp, #0x38]
     158:      	add	x0, sp, #0x88
     15c:      	mov	w1, #0x8                // =8
     160:      	blr	x10
     164:      	ldr	x8, [sp, #0x88]
     168:      	cbz	x8, 0x3184 <generic_tracepoint_event+0x3184>
     16c:      	str	xzr, [sp, #0x38]
     170:      	add	x2, x8, #0x100
     174:      	mov	w8, #0x8                // =8
     178:      	mov	w9, #0x71               // =113
     17c:      	add	x10, sp, #0x38
     180:      	add	x0, sp, #0x38
     184:      	mov	w1, #0x8                // =8
     188:      	blr	x9
     18c:      	ldr	x8, [sp, #0x38]
     190:      	str	xzr, [sp, #0x38]
     194:      	cbz	x8, 0x1c4 <generic_tracepoint_event+0x1c4>
     198:      	add	x2, x8, #0x60
     19c:      	mov	w8, #0x8                // =8
     1a0:      	mov	w9, #0x71               // =113
     1a4:      	add	x10, sp, #0x38
     1a8:      	add	x0, sp, #0x38
     1ac:      	mov	w1, #0x8                // =8
     1b0:      	blr	x9
     1b4:      	ldr	x0, [sp, #0x38]
     1b8:      	str	x0, [sp, #0x30]
     1bc:      	cbnz	x0, 0x1d0 <generic_tracepoint_event+0x1d0>
     1c0:      	b	0x3184 <generic_tracepoint_event+0x3184>
     1c4:      	mov	x0, xzr
     1c8:      	str	xzr, [sp, #0x30]
     1cc:      	cbz	xzr, 0x3184 <generic_tracepoint_event+0x3184>
     1d0:      	str	x0, [sp, #0x38]
     1d4:      	adrp	x0, 0x0 <generic_tracepoint_event>
     1d8:      	mov	w8, #0x1                // =1
     1dc:      	add	x9, sp, #0x38
     1e0:      	ldr	x0, [x0]
     1e4:      	add	x1, sp, #0x38
     1e8:      	blr	x8
     1ec:      	cbz	x0, 0x204 <generic_tracepoint_event+0x204>
     1f0:      	ldr	x8, [x0]
     1f4:      	str	x8, [sp, #0x10]
     1f8:      	cbz	x8, 0x208 <generic_tracepoint_event+0x208>
     1fc:      	str	x8, [sp, #0x30]
     200:      	b	0x208 <generic_tracepoint_event+0x208>
     204:      	str	xzr, [sp, #0x10]
     208:      	mov	w8, #0x1                // =1
     20c:      	add	x9, sp, #0x30
     210:      	add	x1, sp, #0x30
     214:      	mov	x0, x23
     218:      	blr	x8
     21c:      	cbz	x0, 0x42c <generic_tracepoint_event+0x42c>
     220:      	add	x23, x20, #0x5, lsl #12 // =0x5000
     224:      	mov	x22, xzr
     228:      	str	wzr, [x23, #0xef8]
     22c:      	ldr	w8, [x21]
     230:      	stp	x8, xzr, [x20, #0x60]
     234:      	ldrh	w8, [x21, #0x2c]
     238:      	ldr	w24, [x21, #0x4]
     23c:      	add	x2, x19, x8
     240:      	cmp	w24, #0xb
     244:      	b.gt	0x274 <generic_tracepoint_event+0x274>
     248:      	cmp	w24, #0x3
     24c:      	b.le	0x30c <generic_tracepoint_event+0x30c>
     250:      	cmp	w24, #0x6
     254:      	b.gt	0x480 <generic_tracepoint_event+0x480>
     258:      	cmp	w24, #0x4
     25c:      	b.eq	0x8c8 <generic_tracepoint_event+0x8c8>
     260:      	cmp	w24, #0x5
     264:      	b.eq	0x770 <generic_tracepoint_event+0x770>
     268:      	cmp	w24, #0x6
     26c:      	b.eq	0x328 <generic_tracepoint_event+0x328>
     270:      	b	0xb40 <generic_tracepoint_event+0xb40>
     274:      	cmp	w24, #0x1d
     278:      	b.le	0x39c <generic_tracepoint_event+0x39c>
     27c:      	cmp	w24, #0x25
     280:      	b.gt	0x4f8 <generic_tracepoint_event+0x4f8>
     284:      	cmp	w24, #0x1e
     288:      	b.eq	0x934 <generic_tracepoint_event+0x934>
     28c:      	cmp	w24, #0x1f
     290:      	b.eq	0x7e4 <generic_tracepoint_event+0x7e4>
     294:      	cmp	w24, #0x20
     298:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     29c:      	mov	w8, #0x1                // =1
     2a0:      	mov	w9, #0x4                // =4
     2a4:      	add	x10, sp, #0x88
     2a8:      	add	x0, sp, #0x88
     2ac:      	mov	w1, #0x1                // =1
     2b0:      	blr	x9
     2b4:      	cbz	x0, 0xab8 <generic_tracepoint_event+0xab8>
     2b8:      	neg	w8, w0
     2bc:      	adrp	x22, 0x0 <generic_tracepoint_event>
     2c0:      	mov	w9, #0x1                // =1
     2c4:      	strh	w8, [sp, #0x38]
     2c8:      	mov	w8, #0x7                // =7
     2cc:      	add	x1, sp, #0x38
     2d0:      	mov	w24, #0x1               // =1
     2d4:      	strh	w8, [sp, #0x3a]
     2d8:      	mov	x8, #0x73               // =115
     2dc:      	movk	x8, #0x4, lsl #32
     2e0:      	stur	x8, [sp, #0x3c]
     2e4:      	add	x8, sp, #0x38
     2e8:      	ldr	x22, [x22]
     2ec:      	mov	x0, x22
     2f0:      	blr	x9
     2f4:      	cbz	x0, 0xa94 <generic_tracepoint_event+0xa94>
     2f8:      	ldr	w8, [x0]
     2fc:      	add	w8, w8, #0x1
     300:      	str	w8, [x0]
     304:      	ldrb	w22, [sp, #0x88]
     308:      	b	0xb40 <generic_tracepoint_event+0xb40>
     30c:      	cmn	w24, #0xc
     310:      	b.le	0x584 <generic_tracepoint_event+0x584>
     314:      	add	w8, w24, #0xb
     318:      	cmp	w8, #0x2
     31c:      	b.lo	0x48c <generic_tracepoint_event+0x48c>
     320:      	cmp	w24, #0x2
     324:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     328:      	mov	w8, #0x8                // =8
     32c:      	mov	w9, #0x4                // =4
     330:      	add	x10, sp, #0x20
     334:      	add	x0, sp, #0x20
     338:      	mov	w1, #0x8                // =8
     33c:      	blr	x9
     340:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     344:      	neg	w8, w0
     348:      	adrp	x22, 0x0 <generic_tracepoint_event>
     34c:      	mov	w9, #0x1                // =1
     350:      	strh	w8, [sp, #0x38]
     354:      	mov	w8, #0x7                // =7
     358:      	add	x1, sp, #0x38
     35c:      	mov	w24, #0x1               // =1
     360:      	strh	w8, [sp, #0x3a]
     364:      	mov	x8, #0x81               // =129
     368:      	movk	x8, #0x4, lsl #32
     36c:      	stur	x8, [sp, #0x3c]
     370:      	add	x8, sp, #0x38
     374:      	ldr	x22, [x22]
     378:      	mov	x0, x22
     37c:      	blr	x9
     380:      	cbnz	x0, 0x924 <generic_tracepoint_event+0x924>
     384:      	str	w24, [sp, #0x88]
     388:      	mov	x3, xzr
     38c:      	mov	w8, #0x2                // =2
     390:      	add	x9, sp, #0x38
     394:      	add	x10, sp, #0x88
     398:      	b	0xad4 <generic_tracepoint_event+0xad4>
     39c:      	cmp	w24, #0x11
     3a0:      	b.le	0x598 <generic_tracepoint_event+0x598>
     3a4:      	cmp	w24, #0x12
     3a8:      	b.eq	0x768 <generic_tracepoint_event+0x768>
     3ac:      	cmp	w24, #0x1c
     3b0:      	b.eq	0x48c <generic_tracepoint_event+0x48c>
     3b4:      	cmp	w24, #0x1d
     3b8:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     3bc:      	mov	w8, #0x2                // =2
     3c0:      	mov	w9, #0x4                // =4
     3c4:      	add	x10, sp, #0x88
     3c8:      	add	x0, sp, #0x88
     3cc:      	mov	w1, #0x2                // =2
     3d0:      	blr	x9
     3d4:      	cbz	x0, 0xa60 <generic_tracepoint_event+0xa60>
     3d8:      	neg	w8, w0
     3dc:      	adrp	x22, 0x0 <generic_tracepoint_event>
     3e0:      	mov	w9, #0x1                // =1
     3e4:      	strh	w8, [sp, #0x38]
     3e8:      	mov	w8, #0x7                // =7
     3ec:      	add	x1, sp, #0x38
     3f0:      	mov	w24, #0x1               // =1
     3f4:      	strh	w8, [sp, #0x3a]
     3f8:      	mov	x8, #0x6c               // =108
     3fc:      	movk	x8, #0x4, lsl #32
     400:      	stur	x8, [sp, #0x3c]
     404:      	add	x8, sp, #0x38
     408:      	ldr	x22, [x22]
     40c:      	mov	x0, x22
     410:      	blr	x9
     414:      	cbz	x0, 0xa3c <generic_tracepoint_event+0xa3c>
     418:      	ldr	w8, [x0]
     41c:      	add	w8, w8, #0x1
     420:      	str	w8, [x0]
     424:      	ldrsh	x22, [sp, #0x88]
     428:      	b	0xb40 <generic_tracepoint_event+0xb40>
     42c:      	mov	x8, #-0x1               // =-1
     430:      	mov	w9, #0x1                // =1
     434:      	add	x1, sp, #0x10
     438:      	str	x8, [sp, #0x10]
     43c:      	add	x8, sp, #0x10
     440:      	mov	x0, x23
     444:      	mov	w24, #0x1               // =1
     448:      	blr	x9
     44c:      	cbz	x0, 0x3184 <generic_tracepoint_event+0x3184>
     450:      	str	w24, [sp, #0x1c]
     454:      	add	x8, sp, #0x1c
     458:      	add	x1, sp, #0x1c
     45c:      	mov	x0, x22
     460:      	blr	x24
     464:      	cbz	x0, 0x3184 <generic_tracepoint_event+0x3184>
     468:      	mov	w8, #0x1                // =1
     46c:      	add	x9, sp, #0x30
     470:      	add	x1, sp, #0x30
     474:      	blr	x8
     478:      	cbnz	x0, 0x3184 <generic_tracepoint_event+0x3184>
     47c:      	b	0x220 <generic_tracepoint_event+0x220>
     480:      	sub	w8, w24, #0xa
     484:      	cmp	w8, #0x2
     488:      	b.hs	0x6ec <generic_tracepoint_event+0x6ec>
     48c:      	mov	w8, #0x8                // =8
     490:      	mov	w9, #0x4                // =4
     494:      	add	x10, sp, #0x20
     498:      	add	x0, sp, #0x20
     49c:      	mov	w1, #0x8                // =8
     4a0:      	blr	x9
     4a4:      	cbz	x0, 0x6a8 <generic_tracepoint_event+0x6a8>
     4a8:      	neg	w8, w0
     4ac:      	adrp	x22, 0x0 <generic_tracepoint_event>
     4b0:      	mov	w9, #0x1                // =1
     4b4:      	strh	w8, [sp, #0x38]
     4b8:      	mov	w8, #0x7                // =7
     4bc:      	add	x1, sp, #0x38
     4c0:      	mov	w25, #0x1               // =1
     4c4:      	strh	w8, [sp, #0x3a]
     4c8:      	mov	x8, #0x45               // =69
     4cc:      	movk	x8, #0x4, lsl #32
     4d0:      	stur	x8, [sp, #0x3c]
     4d4:      	add	x8, sp, #0x38
     4d8:      	ldr	x22, [x22]
     4dc:      	mov	x0, x22
     4e0:      	blr	x9
     4e4:      	cbz	x0, 0x684 <generic_tracepoint_event+0x684>
     4e8:      	ldr	w8, [x0]
     4ec:      	add	w8, w8, #0x1
     4f0:      	str	w8, [x0]
     4f4:      	b	0x6a8 <generic_tracepoint_event+0x6a8>
     4f8:      	cmp	w24, #0x26
     4fc:      	b.eq	0x9a4 <generic_tracepoint_event+0x9a4>
     500:      	cmp	w24, #0x28
     504:      	b.eq	0x854 <generic_tracepoint_event+0x854>
     508:      	cmp	w24, #0x29
     50c:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     510:      	mov	w8, #0x8                // =8
     514:      	mov	w9, #0x4                // =4
     518:      	add	x10, sp, #0x20
     51c:      	add	x0, sp, #0x20
     520:      	mov	w1, #0x8                // =8
     524:      	blr	x9
     528:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     52c:      	neg	w8, w0
     530:      	adrp	x22, 0x0 <generic_tracepoint_event>
     534:      	mov	w9, #0x1                // =1
     538:      	strh	w8, [sp, #0x38]
     53c:      	mov	w8, #0x7                // =7
     540:      	add	x1, sp, #0x38
     544:      	mov	w24, #0x1               // =1
     548:      	strh	w8, [sp, #0x3a]
     54c:      	mov	x8, #0xa8               // =168
     550:      	movk	x8, #0x4, lsl #32
     554:      	stur	x8, [sp, #0x3c]
     558:      	add	x8, sp, #0x38
     55c:      	ldr	x22, [x22]
     560:      	mov	x0, x22
     564:      	blr	x9
     568:      	cbnz	x0, 0x924 <generic_tracepoint_event+0x924>
     56c:      	str	w24, [sp, #0x88]
     570:      	mov	x3, xzr
     574:      	mov	w8, #0x2                // =2
     578:      	add	x9, sp, #0x38
     57c:      	add	x10, sp, #0x88
     580:      	b	0xad4 <generic_tracepoint_event+0xad4>
     584:      	cmn	w24, #0xd
     588:      	b.eq	0x618 <generic_tracepoint_event+0x618>
     58c:      	cmn	w24, #0xc
     590:      	b.eq	0x5a8 <generic_tracepoint_event+0x5a8>
     594:      	b	0xb40 <generic_tracepoint_event+0xb40>
     598:      	cmp	w24, #0xc
     59c:      	b.eq	0x618 <generic_tracepoint_event+0x618>
     5a0:      	cmp	w24, #0xd
     5a4:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     5a8:      	mov	w8, #0x4                // =4
     5ac:      	add	x9, sp, #0x88
     5b0:      	add	x0, sp, #0x88
     5b4:      	mov	w1, #0x4                // =4
     5b8:      	blr	x8
     5bc:      	cbz	x0, 0xb3c <generic_tracepoint_event+0xb3c>
     5c0:      	neg	w8, w0
     5c4:      	adrp	x22, 0x0 <generic_tracepoint_event>
     5c8:      	mov	w9, #0x1                // =1
     5cc:      	strh	w8, [sp, #0x38]
     5d0:      	mov	w8, #0x7                // =7
     5d4:      	add	x1, sp, #0x38
     5d8:      	mov	w24, #0x1               // =1
     5dc:      	strh	w8, [sp, #0x3a]
     5e0:      	mov	x8, #0x5e               // =94
     5e4:      	movk	x8, #0x4, lsl #32
     5e8:      	stur	x8, [sp, #0x3c]
     5ec:      	add	x8, sp, #0x38
     5f0:      	ldr	x22, [x22]
     5f4:      	mov	x0, x22
     5f8:      	blr	x9
     5fc:      	cbnz	x0, 0x9fc <generic_tracepoint_event+0x9fc>
     600:      	str	w24, [sp, #0x20]
     604:      	mov	x3, xzr
     608:      	mov	w8, #0x2                // =2
     60c:      	add	x9, sp, #0x38
     610:      	add	x10, sp, #0x20
     614:      	b	0xb2c <generic_tracepoint_event+0xb2c>
     618:      	mov	w8, #0x4                // =4
     61c:      	add	x9, sp, #0x88
     620:      	add	x0, sp, #0x88
     624:      	mov	w1, #0x4                // =4
     628:      	blr	x8
     62c:      	cbz	x0, 0xa34 <generic_tracepoint_event+0xa34>
     630:      	neg	w8, w0
     634:      	adrp	x22, 0x0 <generic_tracepoint_event>
     638:      	mov	w9, #0x1                // =1
     63c:      	strh	w8, [sp, #0x38]
     640:      	mov	w8, #0x7                // =7
     644:      	add	x1, sp, #0x38
     648:      	mov	w24, #0x1               // =1
     64c:      	strh	w8, [sp, #0x3a]
     650:      	mov	x8, #0x56               // =86
     654:      	movk	x8, #0x4, lsl #32
     658:      	stur	x8, [sp, #0x3c]
     65c:      	add	x8, sp, #0x38
     660:      	ldr	x22, [x22]
     664:      	mov	x0, x22
     668:      	blr	x9
     66c:      	cbz	x0, 0xa10 <generic_tracepoint_event+0xa10>
     670:      	ldr	w8, [x0]
     674:      	add	w8, w8, #0x1
     678:      	str	w8, [x0]
     67c:      	ldrsw	x22, [sp, #0x88]
     680:      	b	0xb40 <generic_tracepoint_event+0xb40>
     684:      	str	w25, [sp, #0x88]
     688:      	mov	x3, xzr
     68c:      	mov	w8, #0x2                // =2
     690:      	add	x9, sp, #0x38
     694:      	add	x10, sp, #0x88
     698:      	add	x1, sp, #0x38
     69c:      	add	x2, sp, #0x88
     6a0:      	mov	x0, x22
     6a4:      	blr	x8
     6a8:      	ldr	x22, [sp, #0x20]
     6ac:      	cmp	w24, #0x1c
     6b0:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     6b4:      	mov	w8, #0x23               // =35
     6b8:      	blr	x8
     6bc:      	mov	w8, #0x8                // =8
     6c0:      	mov	w9, #0x4                // =4
     6c4:      	add	x10, sp, #0x38
     6c8:      	mov	x2, x0
     6cc:      	add	x0, sp, #0x38
     6d0:      	mov	w1, #0x8                // =8
     6d4:      	blr	x9
     6d8:      	ldr	w8, [sp, #0x38]
     6dc:      	lsl	w8, w8, #9
     6e0:      	and	x8, x8, #0x80000000
     6e4:      	orr	x22, x8, x22
     6e8:      	b	0xb40 <generic_tracepoint_event+0xb40>
     6ec:      	cmp	w24, #0x7
     6f0:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     6f4:      	mov	w8, #0x8                // =8
     6f8:      	mov	w9, #0x4                // =4
     6fc:      	add	x10, sp, #0x20
     700:      	add	x0, sp, #0x20
     704:      	mov	w1, #0x8                // =8
     708:      	blr	x9
     70c:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     710:      	neg	w8, w0
     714:      	adrp	x22, 0x0 <generic_tracepoint_event>
     718:      	mov	w9, #0x1                // =1
     71c:      	strh	w8, [sp, #0x38]
     720:      	mov	w8, #0x7                // =7
     724:      	add	x1, sp, #0x38
     728:      	mov	w24, #0x1               // =1
     72c:      	strh	w8, [sp, #0x3a]
     730:      	mov	x8, #0x9a               // =154
     734:      	movk	x8, #0x4, lsl #32
     738:      	stur	x8, [sp, #0x3c]
     73c:      	add	x8, sp, #0x38
     740:      	ldr	x22, [x22]
     744:      	mov	x0, x22
     748:      	blr	x9
     74c:      	cbnz	x0, 0x924 <generic_tracepoint_event+0x924>
     750:      	str	w24, [sp, #0x88]
     754:      	mov	x3, xzr
     758:      	mov	w8, #0x2                // =2
     75c:      	add	x9, sp, #0x38
     760:      	add	x10, sp, #0x88
     764:      	b	0xad4 <generic_tracepoint_event+0xad4>
     768:      	mov	x22, x2
     76c:      	b	0xb40 <generic_tracepoint_event+0xb40>
     770:      	mov	w8, #0x8                // =8
     774:      	mov	w9, #0x4                // =4
     778:      	add	x10, sp, #0x20
     77c:      	add	x0, sp, #0x20
     780:      	mov	w1, #0x8                // =8
     784:      	blr	x9
     788:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     78c:      	neg	w8, w0
     790:      	adrp	x22, 0x0 <generic_tracepoint_event>
     794:      	mov	w9, #0x1                // =1
     798:      	strh	w8, [sp, #0x38]
     79c:      	mov	w8, #0x7                // =7
     7a0:      	add	x1, sp, #0x38
     7a4:      	mov	w24, #0x1               // =1
     7a8:      	strh	w8, [sp, #0x3a]
     7ac:      	mov	x8, #0x93               // =147
     7b0:      	movk	x8, #0x4, lsl #32
     7b4:      	stur	x8, [sp, #0x3c]
     7b8:      	add	x8, sp, #0x38
     7bc:      	ldr	x22, [x22]
     7c0:      	mov	x0, x22
     7c4:      	blr	x9
     7c8:      	cbnz	x0, 0x924 <generic_tracepoint_event+0x924>
     7cc:      	str	w24, [sp, #0x88]
     7d0:      	mov	x3, xzr
     7d4:      	mov	w8, #0x2                // =2
     7d8:      	add	x9, sp, #0x38
     7dc:      	add	x10, sp, #0x88
     7e0:      	b	0xad4 <generic_tracepoint_event+0xad4>
     7e4:      	mov	w8, #0x1                // =1
     7e8:      	mov	w9, #0x4                // =4
     7ec:      	add	x10, sp, #0x88
     7f0:      	add	x0, sp, #0x88
     7f4:      	mov	w1, #0x1                // =1
     7f8:      	blr	x9
     7fc:      	cbz	x0, 0xa8c <generic_tracepoint_event+0xa8c>
     800:      	neg	w8, w0
     804:      	adrp	x22, 0x0 <generic_tracepoint_event>
     808:      	mov	w9, #0x1                // =1
     80c:      	strh	w8, [sp, #0x38]
     810:      	mov	w8, #0x7                // =7
     814:      	add	x1, sp, #0x38
     818:      	mov	w24, #0x1               // =1
     81c:      	strh	w8, [sp, #0x3a]
     820:      	mov	x8, #0x7a               // =122
     824:      	movk	x8, #0x4, lsl #32
     828:      	stur	x8, [sp, #0x3c]
     82c:      	add	x8, sp, #0x38
     830:      	ldr	x22, [x22]
     834:      	mov	x0, x22
     838:      	blr	x9
     83c:      	cbz	x0, 0xa68 <generic_tracepoint_event+0xa68>
     840:      	ldr	w8, [x0]
     844:      	add	w8, w8, #0x1
     848:      	str	w8, [x0]
     84c:      	ldrsb	x22, [sp, #0x88]
     850:      	b	0xb40 <generic_tracepoint_event+0xb40>
     854:      	mov	w8, #0x8                // =8
     858:      	mov	w9, #0x4                // =4
     85c:      	add	x10, sp, #0x20
     860:      	add	x0, sp, #0x20
     864:      	mov	w1, #0x8                // =8
     868:      	blr	x9
     86c:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     870:      	neg	w8, w0
     874:      	adrp	x22, 0x0 <generic_tracepoint_event>
     878:      	mov	w9, #0x1                // =1
     87c:      	strh	w8, [sp, #0x38]
     880:      	mov	w8, #0x7                // =7
     884:      	add	x1, sp, #0x38
     888:      	mov	w24, #0x1               // =1
     88c:      	strh	w8, [sp, #0x3a]
     890:      	mov	x8, #0xa1               // =161
     894:      	movk	x8, #0x4, lsl #32
     898:      	stur	x8, [sp, #0x3c]
     89c:      	add	x8, sp, #0x38
     8a0:      	ldr	x22, [x22]
     8a4:      	mov	x0, x22
     8a8:      	blr	x9
     8ac:      	cbnz	x0, 0x924 <generic_tracepoint_event+0x924>
     8b0:      	str	w24, [sp, #0x88]
     8b4:      	mov	x3, xzr
     8b8:      	mov	w8, #0x2                // =2
     8bc:      	add	x9, sp, #0x38
     8c0:      	add	x10, sp, #0x88
     8c4:      	b	0xad4 <generic_tracepoint_event+0xad4>
     8c8:      	mov	w8, #0x8                // =8
     8cc:      	mov	w9, #0x4                // =4
     8d0:      	add	x10, sp, #0x20
     8d4:      	add	x0, sp, #0x20
     8d8:      	mov	w1, #0x8                // =8
     8dc:      	blr	x9
     8e0:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     8e4:      	neg	w8, w0
     8e8:      	adrp	x22, 0x0 <generic_tracepoint_event>
     8ec:      	mov	w9, #0x1                // =1
     8f0:      	strh	w8, [sp, #0x38]
     8f4:      	mov	w8, #0x7                // =7
     8f8:      	add	x1, sp, #0x38
     8fc:      	mov	w24, #0x1               // =1
     900:      	strh	w8, [sp, #0x3a]
     904:      	mov	x8, #0x4e               // =78
     908:      	movk	x8, #0x4, lsl #32
     90c:      	stur	x8, [sp, #0x3c]
     910:      	add	x8, sp, #0x38
     914:      	ldr	x22, [x22]
     918:      	mov	x0, x22
     91c:      	blr	x9
     920:      	cbz	x0, 0xac0 <generic_tracepoint_event+0xac0>
     924:      	ldr	w8, [x0]
     928:      	add	w8, w8, #0x1
     92c:      	str	w8, [x0]
     930:      	b	0xae4 <generic_tracepoint_event+0xae4>
     934:      	mov	w8, #0x2                // =2
     938:      	mov	w9, #0x4                // =4
     93c:      	add	x10, sp, #0x88
     940:      	add	x0, sp, #0x88
     944:      	mov	w1, #0x2                // =2
     948:      	blr	x9
     94c:      	cbz	x0, 0xb10 <generic_tracepoint_event+0xb10>
     950:      	neg	w8, w0
     954:      	adrp	x22, 0x0 <generic_tracepoint_event>
     958:      	mov	w9, #0x1                // =1
     95c:      	strh	w8, [sp, #0x38]
     960:      	mov	w8, #0x7                // =7
     964:      	add	x1, sp, #0x38
     968:      	mov	w24, #0x1               // =1
     96c:      	strh	w8, [sp, #0x3a]
     970:      	mov	x8, #0x65               // =101
     974:      	movk	x8, #0x4, lsl #32
     978:      	stur	x8, [sp, #0x3c]
     97c:      	add	x8, sp, #0x38
     980:      	ldr	x22, [x22]
     984:      	mov	x0, x22
     988:      	blr	x9
     98c:      	cbz	x0, 0xaec <generic_tracepoint_event+0xaec>
     990:      	ldr	w8, [x0]
     994:      	add	w8, w8, #0x1
     998:      	str	w8, [x0]
     99c:      	ldrh	w22, [sp, #0x88]
     9a0:      	b	0xb40 <generic_tracepoint_event+0xb40>
     9a4:      	mov	w8, #0x4                // =4
     9a8:      	add	x9, sp, #0x88
     9ac:      	add	x0, sp, #0x88
     9b0:      	mov	w1, #0x4                // =4
     9b4:      	blr	x8
     9b8:      	cbz	x0, 0xb3c <generic_tracepoint_event+0xb3c>
     9bc:      	neg	w8, w0
     9c0:      	adrp	x22, 0x0 <generic_tracepoint_event>
     9c4:      	mov	w9, #0x1                // =1
     9c8:      	strh	w8, [sp, #0x38]
     9cc:      	mov	w8, #0x7                // =7
     9d0:      	add	x1, sp, #0x38
     9d4:      	mov	w24, #0x1               // =1
     9d8:      	strh	w8, [sp, #0x3a]
     9dc:      	mov	x8, #0x88               // =136
     9e0:      	movk	x8, #0x4, lsl #32
     9e4:      	stur	x8, [sp, #0x3c]
     9e8:      	add	x8, sp, #0x38
     9ec:      	ldr	x22, [x22]
     9f0:      	mov	x0, x22
     9f4:      	blr	x9
     9f8:      	cbz	x0, 0xb18 <generic_tracepoint_event+0xb18>
     9fc:      	ldr	w8, [x0]
     a00:      	add	w8, w8, #0x1
     a04:      	str	w8, [x0]
     a08:      	ldr	w22, [sp, #0x88]
     a0c:      	b	0xb40 <generic_tracepoint_event+0xb40>
     a10:      	str	w24, [sp, #0x20]
     a14:      	mov	x3, xzr
     a18:      	mov	w8, #0x2                // =2
     a1c:      	add	x9, sp, #0x38
     a20:      	add	x10, sp, #0x20
     a24:      	add	x1, sp, #0x38
     a28:      	add	x2, sp, #0x20
     a2c:      	mov	x0, x22
     a30:      	blr	x8
     a34:      	ldrsw	x22, [sp, #0x88]
     a38:      	b	0xb40 <generic_tracepoint_event+0xb40>
     a3c:      	str	w24, [sp, #0x20]
     a40:      	mov	x3, xzr
     a44:      	mov	w8, #0x2                // =2
     a48:      	add	x9, sp, #0x38
     a4c:      	add	x10, sp, #0x20
     a50:      	add	x1, sp, #0x38
     a54:      	add	x2, sp, #0x20
     a58:      	mov	x0, x22
     a5c:      	blr	x8
     a60:      	ldrsh	x22, [sp, #0x88]
     a64:      	b	0xb40 <generic_tracepoint_event+0xb40>
     a68:      	str	w24, [sp, #0x20]
     a6c:      	mov	x3, xzr
     a70:      	mov	w8, #0x2                // =2
     a74:      	add	x9, sp, #0x38
     a78:      	add	x10, sp, #0x20
     a7c:      	add	x1, sp, #0x38
     a80:      	add	x2, sp, #0x20
     a84:      	mov	x0, x22
     a88:      	blr	x8
     a8c:      	ldrsb	x22, [sp, #0x88]
     a90:      	b	0xb40 <generic_tracepoint_event+0xb40>
     a94:      	str	w24, [sp, #0x20]
     a98:      	mov	x3, xzr
     a9c:      	mov	w8, #0x2                // =2
     aa0:      	add	x9, sp, #0x38
     aa4:      	add	x10, sp, #0x20
     aa8:      	add	x1, sp, #0x38
     aac:      	add	x2, sp, #0x20
     ab0:      	mov	x0, x22
     ab4:      	blr	x8
     ab8:      	ldrb	w22, [sp, #0x88]
     abc:      	b	0xb40 <generic_tracepoint_event+0xb40>
     ac0:      	str	w24, [sp, #0x88]
     ac4:      	mov	x3, xzr
     ac8:      	mov	w8, #0x2                // =2
     acc:      	add	x9, sp, #0x38
     ad0:      	add	x10, sp, #0x88
     ad4:      	add	x1, sp, #0x38
     ad8:      	add	x2, sp, #0x88
     adc:      	mov	x0, x22
     ae0:      	blr	x8
     ae4:      	ldr	x22, [sp, #0x20]
     ae8:      	b	0xb40 <generic_tracepoint_event+0xb40>
     aec:      	str	w24, [sp, #0x20]
     af0:      	mov	x3, xzr
     af4:      	mov	w8, #0x2                // =2
     af8:      	add	x9, sp, #0x38
     afc:      	add	x10, sp, #0x20
     b00:      	add	x1, sp, #0x38
     b04:      	add	x2, sp, #0x20
     b08:      	mov	x0, x22
     b0c:      	blr	x8
     b10:      	ldrh	w22, [sp, #0x88]
     b14:      	b	0xb40 <generic_tracepoint_event+0xb40>
     b18:      	str	w24, [sp, #0x20]
     b1c:      	mov	x3, xzr
     b20:      	mov	w8, #0x2                // =2
     b24:      	add	x9, sp, #0x38
     b28:      	add	x10, sp, #0x20
     b2c:      	add	x1, sp, #0x38
     b30:      	add	x2, sp, #0x20
     b34:      	mov	x0, x22
     b38:      	blr	x8
     b3c:      	ldr	w22, [sp, #0x88]
     b40:      	str	x22, [x20, #0x5e50]
     b44:      	mov	x24, xzr
     b48:      	ldrh	w8, [x21, #0x30]
     b4c:      	ldr	w25, [x21, #0x8]
     b50:      	add	x2, x19, x8
     b54:      	cmp	w25, #0xb
     b58:      	b.gt	0xb88 <generic_tracepoint_event+0xb88>
     b5c:      	cmp	w25, #0x3
     b60:      	b.le	0xc20 <generic_tracepoint_event+0xc20>
     b64:      	cmp	w25, #0x6
     b68:      	b.gt	0xd40 <generic_tracepoint_event+0xd40>
     b6c:      	cmp	w25, #0x4
     b70:      	b.eq	0x1188 <generic_tracepoint_event+0x1188>
     b74:      	cmp	w25, #0x5
     b78:      	b.eq	0x1030 <generic_tracepoint_event+0x1030>
     b7c:      	cmp	w25, #0x6
     b80:      	b.eq	0xc3c <generic_tracepoint_event+0xc3c>
     b84:      	b	0x1400 <generic_tracepoint_event+0x1400>
     b88:      	cmp	w25, #0x1d
     b8c:      	b.le	0xcb0 <generic_tracepoint_event+0xcb0>
     b90:      	cmp	w25, #0x25
     b94:      	b.gt	0xdb8 <generic_tracepoint_event+0xdb8>
     b98:      	cmp	w25, #0x1e
     b9c:      	b.eq	0x11f4 <generic_tracepoint_event+0x11f4>
     ba0:      	cmp	w25, #0x1f
     ba4:      	b.eq	0x10a4 <generic_tracepoint_event+0x10a4>
     ba8:      	cmp	w25, #0x20
     bac:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     bb0:      	mov	w8, #0x1                // =1
     bb4:      	mov	w9, #0x4                // =4
     bb8:      	add	x10, sp, #0x88
     bbc:      	add	x0, sp, #0x88
     bc0:      	mov	w1, #0x1                // =1
     bc4:      	blr	x9
     bc8:      	cbz	x0, 0x1378 <generic_tracepoint_event+0x1378>
     bcc:      	neg	w8, w0
     bd0:      	adrp	x22, 0x0 <generic_tracepoint_event>
     bd4:      	mov	w9, #0x1                // =1
     bd8:      	strh	w8, [sp, #0x38]
     bdc:      	mov	w8, #0x7                // =7
     be0:      	add	x1, sp, #0x38
     be4:      	mov	w24, #0x1               // =1
     be8:      	strh	w8, [sp, #0x3a]
     bec:      	mov	x8, #0x73               // =115
     bf0:      	movk	x8, #0x4, lsl #32
     bf4:      	stur	x8, [sp, #0x3c]
     bf8:      	add	x8, sp, #0x38
     bfc:      	ldr	x22, [x22]
     c00:      	mov	x0, x22
     c04:      	blr	x9
     c08:      	cbz	x0, 0x1354 <generic_tracepoint_event+0x1354>
     c0c:      	ldr	w8, [x0]
     c10:      	add	w8, w8, #0x1
     c14:      	str	w8, [x0]
     c18:      	ldrb	w24, [sp, #0x88]
     c1c:      	b	0x1400 <generic_tracepoint_event+0x1400>
     c20:      	cmn	w25, #0xc
     c24:      	b.le	0xe44 <generic_tracepoint_event+0xe44>
     c28:      	add	w8, w25, #0xb
     c2c:      	cmp	w8, #0x2
     c30:      	b.lo	0xd4c <generic_tracepoint_event+0xd4c>
     c34:      	cmp	w25, #0x2
     c38:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     c3c:      	mov	w8, #0x8                // =8
     c40:      	mov	w9, #0x4                // =4
     c44:      	add	x10, sp, #0x20
     c48:      	add	x0, sp, #0x20
     c4c:      	mov	w1, #0x8                // =8
     c50:      	blr	x9
     c54:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
     c58:      	neg	w8, w0
     c5c:      	adrp	x22, 0x0 <generic_tracepoint_event>
     c60:      	mov	w9, #0x1                // =1
     c64:      	strh	w8, [sp, #0x38]
     c68:      	mov	w8, #0x7                // =7
     c6c:      	add	x1, sp, #0x38
     c70:      	mov	w24, #0x1               // =1
     c74:      	strh	w8, [sp, #0x3a]
     c78:      	mov	x8, #0x81               // =129
     c7c:      	movk	x8, #0x4, lsl #32
     c80:      	stur	x8, [sp, #0x3c]
     c84:      	add	x8, sp, #0x38
     c88:      	ldr	x22, [x22]
     c8c:      	mov	x0, x22
     c90:      	blr	x9
     c94:      	cbnz	x0, 0x11e4 <generic_tracepoint_event+0x11e4>
     c98:      	str	w24, [sp, #0x88]
     c9c:      	mov	x3, xzr
     ca0:      	mov	w8, #0x2                // =2
     ca4:      	add	x9, sp, #0x38
     ca8:      	add	x10, sp, #0x88
     cac:      	b	0x1394 <generic_tracepoint_event+0x1394>
     cb0:      	cmp	w25, #0x11
     cb4:      	b.le	0xe58 <generic_tracepoint_event+0xe58>
     cb8:      	cmp	w25, #0x12
     cbc:      	b.eq	0x1028 <generic_tracepoint_event+0x1028>
     cc0:      	cmp	w25, #0x1c
     cc4:      	b.eq	0xd4c <generic_tracepoint_event+0xd4c>
     cc8:      	cmp	w25, #0x1d
     ccc:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     cd0:      	mov	w8, #0x2                // =2
     cd4:      	mov	w9, #0x4                // =4
     cd8:      	add	x10, sp, #0x88
     cdc:      	add	x0, sp, #0x88
     ce0:      	mov	w1, #0x2                // =2
     ce4:      	blr	x9
     ce8:      	cbz	x0, 0x1320 <generic_tracepoint_event+0x1320>
     cec:      	neg	w8, w0
     cf0:      	adrp	x22, 0x0 <generic_tracepoint_event>
     cf4:      	mov	w9, #0x1                // =1
     cf8:      	strh	w8, [sp, #0x38]
     cfc:      	mov	w8, #0x7                // =7
     d00:      	add	x1, sp, #0x38
     d04:      	mov	w24, #0x1               // =1
     d08:      	strh	w8, [sp, #0x3a]
     d0c:      	mov	x8, #0x6c               // =108
     d10:      	movk	x8, #0x4, lsl #32
     d14:      	stur	x8, [sp, #0x3c]
     d18:      	add	x8, sp, #0x38
     d1c:      	ldr	x22, [x22]
     d20:      	mov	x0, x22
     d24:      	blr	x9
     d28:      	cbz	x0, 0x12fc <generic_tracepoint_event+0x12fc>
     d2c:      	ldr	w8, [x0]
     d30:      	add	w8, w8, #0x1
     d34:      	str	w8, [x0]
     d38:      	ldrsh	x24, [sp, #0x88]
     d3c:      	b	0x1400 <generic_tracepoint_event+0x1400>
     d40:      	sub	w8, w25, #0xa
     d44:      	cmp	w8, #0x2
     d48:      	b.hs	0xfac <generic_tracepoint_event+0xfac>
     d4c:      	mov	w8, #0x8                // =8
     d50:      	mov	w9, #0x4                // =4
     d54:      	add	x10, sp, #0x20
     d58:      	add	x0, sp, #0x20
     d5c:      	mov	w1, #0x8                // =8
     d60:      	blr	x9
     d64:      	cbz	x0, 0xf68 <generic_tracepoint_event+0xf68>
     d68:      	neg	w8, w0
     d6c:      	adrp	x22, 0x0 <generic_tracepoint_event>
     d70:      	mov	w9, #0x1                // =1
     d74:      	strh	w8, [sp, #0x38]
     d78:      	mov	w8, #0x7                // =7
     d7c:      	add	x1, sp, #0x38
     d80:      	mov	w24, #0x1               // =1
     d84:      	strh	w8, [sp, #0x3a]
     d88:      	mov	x8, #0x45               // =69
     d8c:      	movk	x8, #0x4, lsl #32
     d90:      	stur	x8, [sp, #0x3c]
     d94:      	add	x8, sp, #0x38
     d98:      	ldr	x22, [x22]
     d9c:      	mov	x0, x22
     da0:      	blr	x9
     da4:      	cbz	x0, 0xf44 <generic_tracepoint_event+0xf44>
     da8:      	ldr	w8, [x0]
     dac:      	add	w8, w8, #0x1
     db0:      	str	w8, [x0]
     db4:      	b	0xf68 <generic_tracepoint_event+0xf68>
     db8:      	cmp	w25, #0x26
     dbc:      	b.eq	0x1264 <generic_tracepoint_event+0x1264>
     dc0:      	cmp	w25, #0x28
     dc4:      	b.eq	0x1114 <generic_tracepoint_event+0x1114>
     dc8:      	cmp	w25, #0x29
     dcc:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     dd0:      	mov	w8, #0x8                // =8
     dd4:      	mov	w9, #0x4                // =4
     dd8:      	add	x10, sp, #0x20
     ddc:      	add	x0, sp, #0x20
     de0:      	mov	w1, #0x8                // =8
     de4:      	blr	x9
     de8:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
     dec:      	neg	w8, w0
     df0:      	adrp	x22, 0x0 <generic_tracepoint_event>
     df4:      	mov	w9, #0x1                // =1
     df8:      	strh	w8, [sp, #0x38]
     dfc:      	mov	w8, #0x7                // =7
     e00:      	add	x1, sp, #0x38
     e04:      	mov	w24, #0x1               // =1
     e08:      	strh	w8, [sp, #0x3a]
     e0c:      	mov	x8, #0xa8               // =168
     e10:      	movk	x8, #0x4, lsl #32
     e14:      	stur	x8, [sp, #0x3c]
     e18:      	add	x8, sp, #0x38
     e1c:      	ldr	x22, [x22]
     e20:      	mov	x0, x22
     e24:      	blr	x9
     e28:      	cbnz	x0, 0x11e4 <generic_tracepoint_event+0x11e4>
     e2c:      	str	w24, [sp, #0x88]
     e30:      	mov	x3, xzr
     e34:      	mov	w8, #0x2                // =2
     e38:      	add	x9, sp, #0x38
     e3c:      	add	x10, sp, #0x88
     e40:      	b	0x1394 <generic_tracepoint_event+0x1394>
     e44:      	cmn	w25, #0xd
     e48:      	b.eq	0xed8 <generic_tracepoint_event+0xed8>
     e4c:      	cmn	w25, #0xc
     e50:      	b.eq	0xe68 <generic_tracepoint_event+0xe68>
     e54:      	b	0x1400 <generic_tracepoint_event+0x1400>
     e58:      	cmp	w25, #0xc
     e5c:      	b.eq	0xed8 <generic_tracepoint_event+0xed8>
     e60:      	cmp	w25, #0xd
     e64:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     e68:      	mov	w8, #0x4                // =4
     e6c:      	add	x9, sp, #0x88
     e70:      	add	x0, sp, #0x88
     e74:      	mov	w1, #0x4                // =4
     e78:      	blr	x8
     e7c:      	cbz	x0, 0x13fc <generic_tracepoint_event+0x13fc>
     e80:      	neg	w8, w0
     e84:      	adrp	x22, 0x0 <generic_tracepoint_event>
     e88:      	mov	w9, #0x1                // =1
     e8c:      	strh	w8, [sp, #0x38]
     e90:      	mov	w8, #0x7                // =7
     e94:      	add	x1, sp, #0x38
     e98:      	mov	w24, #0x1               // =1
     e9c:      	strh	w8, [sp, #0x3a]
     ea0:      	mov	x8, #0x5e               // =94
     ea4:      	movk	x8, #0x4, lsl #32
     ea8:      	stur	x8, [sp, #0x3c]
     eac:      	add	x8, sp, #0x38
     eb0:      	ldr	x22, [x22]
     eb4:      	mov	x0, x22
     eb8:      	blr	x9
     ebc:      	cbnz	x0, 0x12bc <generic_tracepoint_event+0x12bc>
     ec0:      	str	w24, [sp, #0x20]
     ec4:      	mov	x3, xzr
     ec8:      	mov	w8, #0x2                // =2
     ecc:      	add	x9, sp, #0x38
     ed0:      	add	x10, sp, #0x20
     ed4:      	b	0x13ec <generic_tracepoint_event+0x13ec>
     ed8:      	mov	w8, #0x4                // =4
     edc:      	add	x9, sp, #0x88
     ee0:      	add	x0, sp, #0x88
     ee4:      	mov	w1, #0x4                // =4
     ee8:      	blr	x8
     eec:      	cbz	x0, 0x12f4 <generic_tracepoint_event+0x12f4>
     ef0:      	neg	w8, w0
     ef4:      	adrp	x22, 0x0 <generic_tracepoint_event>
     ef8:      	mov	w9, #0x1                // =1
     efc:      	strh	w8, [sp, #0x38]
     f00:      	mov	w8, #0x7                // =7
     f04:      	add	x1, sp, #0x38
     f08:      	mov	w24, #0x1               // =1
     f0c:      	strh	w8, [sp, #0x3a]
     f10:      	mov	x8, #0x56               // =86
     f14:      	movk	x8, #0x4, lsl #32
     f18:      	stur	x8, [sp, #0x3c]
     f1c:      	add	x8, sp, #0x38
     f20:      	ldr	x22, [x22]
     f24:      	mov	x0, x22
     f28:      	blr	x9
     f2c:      	cbz	x0, 0x12d0 <generic_tracepoint_event+0x12d0>
     f30:      	ldr	w8, [x0]
     f34:      	add	w8, w8, #0x1
     f38:      	str	w8, [x0]
     f3c:      	ldrsw	x24, [sp, #0x88]
     f40:      	b	0x1400 <generic_tracepoint_event+0x1400>
     f44:      	str	w24, [sp, #0x88]
     f48:      	mov	x3, xzr
     f4c:      	mov	w8, #0x2                // =2
     f50:      	add	x9, sp, #0x38
     f54:      	add	x10, sp, #0x88
     f58:      	add	x1, sp, #0x38
     f5c:      	add	x2, sp, #0x88
     f60:      	mov	x0, x22
     f64:      	blr	x8
     f68:      	ldr	x24, [sp, #0x20]
     f6c:      	cmp	w25, #0x1c
     f70:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     f74:      	mov	w8, #0x23               // =35
     f78:      	blr	x8
     f7c:      	mov	w8, #0x8                // =8
     f80:      	mov	w9, #0x4                // =4
     f84:      	add	x10, sp, #0x38
     f88:      	mov	x2, x0
     f8c:      	add	x0, sp, #0x38
     f90:      	mov	w1, #0x8                // =8
     f94:      	blr	x9
     f98:      	ldr	w8, [sp, #0x38]
     f9c:      	lsl	w8, w8, #9
     fa0:      	and	x8, x8, #0x80000000
     fa4:      	orr	x24, x8, x24
     fa8:      	b	0x1400 <generic_tracepoint_event+0x1400>
     fac:      	cmp	w25, #0x7
     fb0:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     fb4:      	mov	w8, #0x8                // =8
     fb8:      	mov	w9, #0x4                // =4
     fbc:      	add	x10, sp, #0x20
     fc0:      	add	x0, sp, #0x20
     fc4:      	mov	w1, #0x8                // =8
     fc8:      	blr	x9
     fcc:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
     fd0:      	neg	w8, w0
     fd4:      	adrp	x22, 0x0 <generic_tracepoint_event>
     fd8:      	mov	w9, #0x1                // =1
     fdc:      	strh	w8, [sp, #0x38]
     fe0:      	mov	w8, #0x7                // =7
     fe4:      	add	x1, sp, #0x38
     fe8:      	mov	w24, #0x1               // =1
     fec:      	strh	w8, [sp, #0x3a]
     ff0:      	mov	x8, #0x9a               // =154
     ff4:      	movk	x8, #0x4, lsl #32
     ff8:      	stur	x8, [sp, #0x3c]
     ffc:      	add	x8, sp, #0x38
    1000:      	ldr	x22, [x22]
    1004:      	mov	x0, x22
    1008:      	blr	x9
    100c:      	cbnz	x0, 0x11e4 <generic_tracepoint_event+0x11e4>
    1010:      	str	w24, [sp, #0x88]
    1014:      	mov	x3, xzr
    1018:      	mov	w8, #0x2                // =2
    101c:      	add	x9, sp, #0x38
    1020:      	add	x10, sp, #0x88
    1024:      	b	0x1394 <generic_tracepoint_event+0x1394>
    1028:      	mov	x24, x2
    102c:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1030:      	mov	w8, #0x8                // =8
    1034:      	mov	w9, #0x4                // =4
    1038:      	add	x10, sp, #0x20
    103c:      	add	x0, sp, #0x20
    1040:      	mov	w1, #0x8                // =8
    1044:      	blr	x9
    1048:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
    104c:      	neg	w8, w0
    1050:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1054:      	mov	w9, #0x1                // =1
    1058:      	strh	w8, [sp, #0x38]
    105c:      	mov	w8, #0x7                // =7
    1060:      	add	x1, sp, #0x38
    1064:      	mov	w24, #0x1               // =1
    1068:      	strh	w8, [sp, #0x3a]
    106c:      	mov	x8, #0x93               // =147
    1070:      	movk	x8, #0x4, lsl #32
    1074:      	stur	x8, [sp, #0x3c]
    1078:      	add	x8, sp, #0x38
    107c:      	ldr	x22, [x22]
    1080:      	mov	x0, x22
    1084:      	blr	x9
    1088:      	cbnz	x0, 0x11e4 <generic_tracepoint_event+0x11e4>
    108c:      	str	w24, [sp, #0x88]
    1090:      	mov	x3, xzr
    1094:      	mov	w8, #0x2                // =2
    1098:      	add	x9, sp, #0x38
    109c:      	add	x10, sp, #0x88
    10a0:      	b	0x1394 <generic_tracepoint_event+0x1394>
    10a4:      	mov	w8, #0x1                // =1
    10a8:      	mov	w9, #0x4                // =4
    10ac:      	add	x10, sp, #0x88
    10b0:      	add	x0, sp, #0x88
    10b4:      	mov	w1, #0x1                // =1
    10b8:      	blr	x9
    10bc:      	cbz	x0, 0x134c <generic_tracepoint_event+0x134c>
    10c0:      	neg	w8, w0
    10c4:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    10c8:      	mov	w9, #0x1                // =1
    10cc:      	strh	w8, [sp, #0x38]
    10d0:      	mov	w8, #0x7                // =7
    10d4:      	add	x1, sp, #0x38
    10d8:      	mov	w24, #0x1               // =1
    10dc:      	strh	w8, [sp, #0x3a]
    10e0:      	mov	x8, #0x7a               // =122
    10e4:      	movk	x8, #0x4, lsl #32
    10e8:      	stur	x8, [sp, #0x3c]
    10ec:      	add	x8, sp, #0x38
    10f0:      	ldr	x22, [x22]
    10f4:      	mov	x0, x22
    10f8:      	blr	x9
    10fc:      	cbz	x0, 0x1328 <generic_tracepoint_event+0x1328>
    1100:      	ldr	w8, [x0]
    1104:      	add	w8, w8, #0x1
    1108:      	str	w8, [x0]
    110c:      	ldrsb	x24, [sp, #0x88]
    1110:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1114:      	mov	w8, #0x8                // =8
    1118:      	mov	w9, #0x4                // =4
    111c:      	add	x10, sp, #0x20
    1120:      	add	x0, sp, #0x20
    1124:      	mov	w1, #0x8                // =8
    1128:      	blr	x9
    112c:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
    1130:      	neg	w8, w0
    1134:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1138:      	mov	w9, #0x1                // =1
    113c:      	strh	w8, [sp, #0x38]
    1140:      	mov	w8, #0x7                // =7
    1144:      	add	x1, sp, #0x38
    1148:      	mov	w24, #0x1               // =1
    114c:      	strh	w8, [sp, #0x3a]
    1150:      	mov	x8, #0xa1               // =161
    1154:      	movk	x8, #0x4, lsl #32
    1158:      	stur	x8, [sp, #0x3c]
    115c:      	add	x8, sp, #0x38
    1160:      	ldr	x22, [x22]
    1164:      	mov	x0, x22
    1168:      	blr	x9
    116c:      	cbnz	x0, 0x11e4 <generic_tracepoint_event+0x11e4>
    1170:      	str	w24, [sp, #0x88]
    1174:      	mov	x3, xzr
    1178:      	mov	w8, #0x2                // =2
    117c:      	add	x9, sp, #0x38
    1180:      	add	x10, sp, #0x88
    1184:      	b	0x1394 <generic_tracepoint_event+0x1394>
    1188:      	mov	w8, #0x8                // =8
    118c:      	mov	w9, #0x4                // =4
    1190:      	add	x10, sp, #0x20
    1194:      	add	x0, sp, #0x20
    1198:      	mov	w1, #0x8                // =8
    119c:      	blr	x9
    11a0:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
    11a4:      	neg	w8, w0
    11a8:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    11ac:      	mov	w9, #0x1                // =1
    11b0:      	strh	w8, [sp, #0x38]
    11b4:      	mov	w8, #0x7                // =7
    11b8:      	add	x1, sp, #0x38
    11bc:      	mov	w24, #0x1               // =1
    11c0:      	strh	w8, [sp, #0x3a]
    11c4:      	mov	x8, #0x4e               // =78
    11c8:      	movk	x8, #0x4, lsl #32
    11cc:      	stur	x8, [sp, #0x3c]
    11d0:      	add	x8, sp, #0x38
    11d4:      	ldr	x22, [x22]
    11d8:      	mov	x0, x22
    11dc:      	blr	x9
    11e0:      	cbz	x0, 0x1380 <generic_tracepoint_event+0x1380>
    11e4:      	ldr	w8, [x0]
    11e8:      	add	w8, w8, #0x1
    11ec:      	str	w8, [x0]
    11f0:      	b	0x13a4 <generic_tracepoint_event+0x13a4>
    11f4:      	mov	w8, #0x2                // =2
    11f8:      	mov	w9, #0x4                // =4
    11fc:      	add	x10, sp, #0x88
    1200:      	add	x0, sp, #0x88
    1204:      	mov	w1, #0x2                // =2
    1208:      	blr	x9
    120c:      	cbz	x0, 0x13d0 <generic_tracepoint_event+0x13d0>
    1210:      	neg	w8, w0
    1214:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1218:      	mov	w9, #0x1                // =1
    121c:      	strh	w8, [sp, #0x38]
    1220:      	mov	w8, #0x7                // =7
    1224:      	add	x1, sp, #0x38
    1228:      	mov	w24, #0x1               // =1
    122c:      	strh	w8, [sp, #0x3a]
    1230:      	mov	x8, #0x65               // =101
    1234:      	movk	x8, #0x4, lsl #32
    1238:      	stur	x8, [sp, #0x3c]
    123c:      	add	x8, sp, #0x38
    1240:      	ldr	x22, [x22]
    1244:      	mov	x0, x22
    1248:      	blr	x9
    124c:      	cbz	x0, 0x13ac <generic_tracepoint_event+0x13ac>
    1250:      	ldr	w8, [x0]
    1254:      	add	w8, w8, #0x1
    1258:      	str	w8, [x0]
    125c:      	ldrh	w24, [sp, #0x88]
    1260:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1264:      	mov	w8, #0x4                // =4
    1268:      	add	x9, sp, #0x88
    126c:      	add	x0, sp, #0x88
    1270:      	mov	w1, #0x4                // =4
    1274:      	blr	x8
    1278:      	cbz	x0, 0x13fc <generic_tracepoint_event+0x13fc>
    127c:      	neg	w8, w0
    1280:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1284:      	mov	w9, #0x1                // =1
    1288:      	strh	w8, [sp, #0x38]
    128c:      	mov	w8, #0x7                // =7
    1290:      	add	x1, sp, #0x38
    1294:      	mov	w24, #0x1               // =1
    1298:      	strh	w8, [sp, #0x3a]
    129c:      	mov	x8, #0x88               // =136
    12a0:      	movk	x8, #0x4, lsl #32
    12a4:      	stur	x8, [sp, #0x3c]
    12a8:      	add	x8, sp, #0x38
    12ac:      	ldr	x22, [x22]
    12b0:      	mov	x0, x22
    12b4:      	blr	x9
    12b8:      	cbz	x0, 0x13d8 <generic_tracepoint_event+0x13d8>
    12bc:      	ldr	w8, [x0]
    12c0:      	add	w8, w8, #0x1
    12c4:      	str	w8, [x0]
    12c8:      	ldr	w24, [sp, #0x88]
    12cc:      	b	0x1400 <generic_tracepoint_event+0x1400>
    12d0:      	str	w24, [sp, #0x20]
    12d4:      	mov	x3, xzr
    12d8:      	mov	w8, #0x2                // =2
    12dc:      	add	x9, sp, #0x38
    12e0:      	add	x10, sp, #0x20
    12e4:      	add	x1, sp, #0x38
    12e8:      	add	x2, sp, #0x20
    12ec:      	mov	x0, x22
    12f0:      	blr	x8
    12f4:      	ldrsw	x24, [sp, #0x88]
    12f8:      	b	0x1400 <generic_tracepoint_event+0x1400>
    12fc:      	str	w24, [sp, #0x20]
    1300:      	mov	x3, xzr
    1304:      	mov	w8, #0x2                // =2
    1308:      	add	x9, sp, #0x38
    130c:      	add	x10, sp, #0x20
    1310:      	add	x1, sp, #0x38
    1314:      	add	x2, sp, #0x20
    1318:      	mov	x0, x22
    131c:      	blr	x8
    1320:      	ldrsh	x24, [sp, #0x88]
    1324:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1328:      	str	w24, [sp, #0x20]
    132c:      	mov	x3, xzr
    1330:      	mov	w8, #0x2                // =2
    1334:      	add	x9, sp, #0x38
    1338:      	add	x10, sp, #0x20
    133c:      	add	x1, sp, #0x38
    1340:      	add	x2, sp, #0x20
    1344:      	mov	x0, x22
    1348:      	blr	x8
    134c:      	ldrsb	x24, [sp, #0x88]
    1350:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1354:      	str	w24, [sp, #0x20]
    1358:      	mov	x3, xzr
    135c:      	mov	w8, #0x2                // =2
    1360:      	add	x9, sp, #0x38
    1364:      	add	x10, sp, #0x20
    1368:      	add	x1, sp, #0x38
    136c:      	add	x2, sp, #0x20
    1370:      	mov	x0, x22
    1374:      	blr	x8
    1378:      	ldrb	w24, [sp, #0x88]
    137c:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1380:      	str	w24, [sp, #0x88]
    1384:      	mov	x3, xzr
    1388:      	mov	w8, #0x2                // =2
    138c:      	add	x9, sp, #0x38
    1390:      	add	x10, sp, #0x88
    1394:      	add	x1, sp, #0x38
    1398:      	add	x2, sp, #0x88
    139c:      	mov	x0, x22
    13a0:      	blr	x8
    13a4:      	ldr	x24, [sp, #0x20]
    13a8:      	b	0x1400 <generic_tracepoint_event+0x1400>
    13ac:      	str	w24, [sp, #0x20]
    13b0:      	mov	x3, xzr
    13b4:      	mov	w8, #0x2                // =2
    13b8:      	add	x9, sp, #0x38
    13bc:      	add	x10, sp, #0x20
    13c0:      	add	x1, sp, #0x38
    13c4:      	add	x2, sp, #0x20
    13c8:      	mov	x0, x22
    13cc:      	blr	x8
    13d0:      	ldrh	w24, [sp, #0x88]
    13d4:      	b	0x1400 <generic_tracepoint_event+0x1400>
    13d8:      	str	w24, [sp, #0x20]
    13dc:      	mov	x3, xzr
    13e0:      	mov	w8, #0x2                // =2
    13e4:      	add	x9, sp, #0x38
    13e8:      	add	x10, sp, #0x20
    13ec:      	add	x1, sp, #0x38
    13f0:      	add	x2, sp, #0x20
    13f4:      	mov	x0, x22
    13f8:      	blr	x8
    13fc:      	ldr	w24, [sp, #0x88]
    1400:      	str	x24, [x20, #0x5e58]
    1404:      	mov	x22, xzr
    1408:      	ldrh	w8, [x21, #0x34]
    140c:      	ldr	w24, [x21, #0xc]
    1410:      	add	x2, x19, x8
    1414:      	cmp	w24, #0xb
    1418:      	b.gt	0x1448 <generic_tracepoint_event+0x1448>
    141c:      	cmp	w24, #0x3
    1420:      	b.le	0x14e0 <generic_tracepoint_event+0x14e0>
    1424:      	cmp	w24, #0x6
    1428:      	b.gt	0x1600 <generic_tracepoint_event+0x1600>
    142c:      	cmp	w24, #0x4
    1430:      	b.eq	0x1a48 <generic_tracepoint_event+0x1a48>
    1434:      	cmp	w24, #0x5
    1438:      	b.eq	0x18f0 <generic_tracepoint_event+0x18f0>
    143c:      	cmp	w24, #0x6
    1440:      	b.eq	0x14fc <generic_tracepoint_event+0x14fc>
    1444:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1448:      	cmp	w24, #0x1d
    144c:      	b.le	0x1570 <generic_tracepoint_event+0x1570>
    1450:      	cmp	w24, #0x25
    1454:      	b.gt	0x1678 <generic_tracepoint_event+0x1678>
    1458:      	cmp	w24, #0x1e
    145c:      	b.eq	0x1ab4 <generic_tracepoint_event+0x1ab4>
    1460:      	cmp	w24, #0x1f
    1464:      	b.eq	0x1964 <generic_tracepoint_event+0x1964>
    1468:      	cmp	w24, #0x20
    146c:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1470:      	mov	w8, #0x1                // =1
    1474:      	mov	w9, #0x4                // =4
    1478:      	add	x10, sp, #0x88
    147c:      	add	x0, sp, #0x88
    1480:      	mov	w1, #0x1                // =1
    1484:      	blr	x9
    1488:      	cbz	x0, 0x1c38 <generic_tracepoint_event+0x1c38>
    148c:      	neg	w8, w0
    1490:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1494:      	mov	w9, #0x1                // =1
    1498:      	strh	w8, [sp, #0x38]
    149c:      	mov	w8, #0x7                // =7
    14a0:      	add	x1, sp, #0x38
    14a4:      	mov	w24, #0x1               // =1
    14a8:      	strh	w8, [sp, #0x3a]
    14ac:      	mov	x8, #0x73               // =115
    14b0:      	movk	x8, #0x4, lsl #32
    14b4:      	stur	x8, [sp, #0x3c]
    14b8:      	add	x8, sp, #0x38
    14bc:      	ldr	x22, [x22]
    14c0:      	mov	x0, x22
    14c4:      	blr	x9
    14c8:      	cbz	x0, 0x1c14 <generic_tracepoint_event+0x1c14>
    14cc:      	ldr	w8, [x0]
    14d0:      	add	w8, w8, #0x1
    14d4:      	str	w8, [x0]
    14d8:      	ldrb	w22, [sp, #0x88]
    14dc:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    14e0:      	cmn	w24, #0xc
    14e4:      	b.le	0x1704 <generic_tracepoint_event+0x1704>
    14e8:      	add	w8, w24, #0xb
    14ec:      	cmp	w8, #0x2
    14f0:      	b.lo	0x160c <generic_tracepoint_event+0x160c>
    14f4:      	cmp	w24, #0x2
    14f8:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    14fc:      	mov	w8, #0x8                // =8
    1500:      	mov	w9, #0x4                // =4
    1504:      	add	x10, sp, #0x20
    1508:      	add	x0, sp, #0x20
    150c:      	mov	w1, #0x8                // =8
    1510:      	blr	x9
    1514:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    1518:      	neg	w8, w0
    151c:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1520:      	mov	w9, #0x1                // =1
    1524:      	strh	w8, [sp, #0x38]
    1528:      	mov	w8, #0x7                // =7
    152c:      	add	x1, sp, #0x38
    1530:      	mov	w24, #0x1               // =1
    1534:      	strh	w8, [sp, #0x3a]
    1538:      	mov	x8, #0x81               // =129
    153c:      	movk	x8, #0x4, lsl #32
    1540:      	stur	x8, [sp, #0x3c]
    1544:      	add	x8, sp, #0x38
    1548:      	ldr	x22, [x22]
    154c:      	mov	x0, x22
    1550:      	blr	x9
    1554:      	cbnz	x0, 0x1aa4 <generic_tracepoint_event+0x1aa4>
    1558:      	str	w24, [sp, #0x88]
    155c:      	mov	x3, xzr
    1560:      	mov	w8, #0x2                // =2
    1564:      	add	x9, sp, #0x38
    1568:      	add	x10, sp, #0x88
    156c:      	b	0x1c54 <generic_tracepoint_event+0x1c54>
    1570:      	cmp	w24, #0x11
    1574:      	b.le	0x1718 <generic_tracepoint_event+0x1718>
    1578:      	cmp	w24, #0x12
    157c:      	b.eq	0x18e8 <generic_tracepoint_event+0x18e8>
    1580:      	cmp	w24, #0x1c
    1584:      	b.eq	0x160c <generic_tracepoint_event+0x160c>
    1588:      	cmp	w24, #0x1d
    158c:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1590:      	mov	w8, #0x2                // =2
    1594:      	mov	w9, #0x4                // =4
    1598:      	add	x10, sp, #0x88
    159c:      	add	x0, sp, #0x88
    15a0:      	mov	w1, #0x2                // =2
    15a4:      	blr	x9
    15a8:      	cbz	x0, 0x1be0 <generic_tracepoint_event+0x1be0>
    15ac:      	neg	w8, w0
    15b0:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    15b4:      	mov	w9, #0x1                // =1
    15b8:      	strh	w8, [sp, #0x38]
    15bc:      	mov	w8, #0x7                // =7
    15c0:      	add	x1, sp, #0x38
    15c4:      	mov	w24, #0x1               // =1
    15c8:      	strh	w8, [sp, #0x3a]
    15cc:      	mov	x8, #0x6c               // =108
    15d0:      	movk	x8, #0x4, lsl #32
    15d4:      	stur	x8, [sp, #0x3c]
    15d8:      	add	x8, sp, #0x38
    15dc:      	ldr	x22, [x22]
    15e0:      	mov	x0, x22
    15e4:      	blr	x9
    15e8:      	cbz	x0, 0x1bbc <generic_tracepoint_event+0x1bbc>
    15ec:      	ldr	w8, [x0]
    15f0:      	add	w8, w8, #0x1
    15f4:      	str	w8, [x0]
    15f8:      	ldrsh	x22, [sp, #0x88]
    15fc:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1600:      	sub	w8, w24, #0xa
    1604:      	cmp	w8, #0x2
    1608:      	b.hs	0x186c <generic_tracepoint_event+0x186c>
    160c:      	mov	w8, #0x8                // =8
    1610:      	mov	w9, #0x4                // =4
    1614:      	add	x10, sp, #0x20
    1618:      	add	x0, sp, #0x20
    161c:      	mov	w1, #0x8                // =8
    1620:      	blr	x9
    1624:      	cbz	x0, 0x1828 <generic_tracepoint_event+0x1828>
    1628:      	neg	w8, w0
    162c:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1630:      	mov	w9, #0x1                // =1
    1634:      	strh	w8, [sp, #0x38]
    1638:      	mov	w8, #0x7                // =7
    163c:      	add	x1, sp, #0x38
    1640:      	mov	w25, #0x1               // =1
    1644:      	strh	w8, [sp, #0x3a]
    1648:      	mov	x8, #0x45               // =69
    164c:      	movk	x8, #0x4, lsl #32
    1650:      	stur	x8, [sp, #0x3c]
    1654:      	add	x8, sp, #0x38
    1658:      	ldr	x22, [x22]
    165c:      	mov	x0, x22
    1660:      	blr	x9
    1664:      	cbz	x0, 0x1804 <generic_tracepoint_event+0x1804>
    1668:      	ldr	w8, [x0]
    166c:      	add	w8, w8, #0x1
    1670:      	str	w8, [x0]
    1674:      	b	0x1828 <generic_tracepoint_event+0x1828>
    1678:      	cmp	w24, #0x26
    167c:      	b.eq	0x1b24 <generic_tracepoint_event+0x1b24>
    1680:      	cmp	w24, #0x28
    1684:      	b.eq	0x19d4 <generic_tracepoint_event+0x19d4>
    1688:      	cmp	w24, #0x29
    168c:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1690:      	mov	w8, #0x8                // =8
    1694:      	mov	w9, #0x4                // =4
    1698:      	add	x10, sp, #0x20
    169c:      	add	x0, sp, #0x20
    16a0:      	mov	w1, #0x8                // =8
    16a4:      	blr	x9
    16a8:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    16ac:      	neg	w8, w0
    16b0:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    16b4:      	mov	w9, #0x1                // =1
    16b8:      	strh	w8, [sp, #0x38]
    16bc:      	mov	w8, #0x7                // =7
    16c0:      	add	x1, sp, #0x38
    16c4:      	mov	w24, #0x1               // =1
    16c8:      	strh	w8, [sp, #0x3a]
    16cc:      	mov	x8, #0xa8               // =168
    16d0:      	movk	x8, #0x4, lsl #32
    16d4:      	stur	x8, [sp, #0x3c]
    16d8:      	add	x8, sp, #0x38
    16dc:      	ldr	x22, [x22]
    16e0:      	mov	x0, x22
    16e4:      	blr	x9
    16e8:      	cbnz	x0, 0x1aa4 <generic_tracepoint_event+0x1aa4>
    16ec:      	str	w24, [sp, #0x88]
    16f0:      	mov	x3, xzr
    16f4:      	mov	w8, #0x2                // =2
    16f8:      	add	x9, sp, #0x38
    16fc:      	add	x10, sp, #0x88
    1700:      	b	0x1c54 <generic_tracepoint_event+0x1c54>
    1704:      	cmn	w24, #0xd
    1708:      	b.eq	0x1798 <generic_tracepoint_event+0x1798>
    170c:      	cmn	w24, #0xc
    1710:      	b.eq	0x1728 <generic_tracepoint_event+0x1728>
    1714:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1718:      	cmp	w24, #0xc
    171c:      	b.eq	0x1798 <generic_tracepoint_event+0x1798>
    1720:      	cmp	w24, #0xd
    1724:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1728:      	mov	w8, #0x4                // =4
    172c:      	add	x9, sp, #0x88
    1730:      	add	x0, sp, #0x88
    1734:      	mov	w1, #0x4                // =4
    1738:      	blr	x8
    173c:      	cbz	x0, 0x1cbc <generic_tracepoint_event+0x1cbc>
    1740:      	neg	w8, w0
    1744:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1748:      	mov	w9, #0x1                // =1
    174c:      	strh	w8, [sp, #0x38]
    1750:      	mov	w8, #0x7                // =7
    1754:      	add	x1, sp, #0x38
    1758:      	mov	w24, #0x1               // =1
    175c:      	strh	w8, [sp, #0x3a]
    1760:      	mov	x8, #0x5e               // =94
    1764:      	movk	x8, #0x4, lsl #32
    1768:      	stur	x8, [sp, #0x3c]
    176c:      	add	x8, sp, #0x38
    1770:      	ldr	x22, [x22]
    1774:      	mov	x0, x22
    1778:      	blr	x9
    177c:      	cbnz	x0, 0x1b7c <generic_tracepoint_event+0x1b7c>
    1780:      	str	w24, [sp, #0x20]
    1784:      	mov	x3, xzr
    1788:      	mov	w8, #0x2                // =2
    178c:      	add	x9, sp, #0x38
    1790:      	add	x10, sp, #0x20
    1794:      	b	0x1cac <generic_tracepoint_event+0x1cac>
    1798:      	mov	w8, #0x4                // =4
    179c:      	add	x9, sp, #0x88
    17a0:      	add	x0, sp, #0x88
    17a4:      	mov	w1, #0x4                // =4
    17a8:      	blr	x8
    17ac:      	cbz	x0, 0x1bb4 <generic_tracepoint_event+0x1bb4>
    17b0:      	neg	w8, w0
    17b4:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    17b8:      	mov	w9, #0x1                // =1
    17bc:      	strh	w8, [sp, #0x38]
    17c0:      	mov	w8, #0x7                // =7
    17c4:      	add	x1, sp, #0x38
    17c8:      	mov	w24, #0x1               // =1
    17cc:      	strh	w8, [sp, #0x3a]
    17d0:      	mov	x8, #0x56               // =86
    17d4:      	movk	x8, #0x4, lsl #32
    17d8:      	stur	x8, [sp, #0x3c]
    17dc:      	add	x8, sp, #0x38
    17e0:      	ldr	x22, [x22]
    17e4:      	mov	x0, x22
    17e8:      	blr	x9
    17ec:      	cbz	x0, 0x1b90 <generic_tracepoint_event+0x1b90>
    17f0:      	ldr	w8, [x0]
    17f4:      	add	w8, w8, #0x1
    17f8:      	str	w8, [x0]
    17fc:      	ldrsw	x22, [sp, #0x88]
    1800:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1804:      	str	w25, [sp, #0x88]
    1808:      	mov	x3, xzr
    180c:      	mov	w8, #0x2                // =2
    1810:      	add	x9, sp, #0x38
    1814:      	add	x10, sp, #0x88
    1818:      	add	x1, sp, #0x38
    181c:      	add	x2, sp, #0x88
    1820:      	mov	x0, x22
    1824:      	blr	x8
    1828:      	ldr	x22, [sp, #0x20]
    182c:      	cmp	w24, #0x1c
    1830:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1834:      	mov	w8, #0x23               // =35
    1838:      	blr	x8
    183c:      	mov	w8, #0x8                // =8
    1840:      	mov	w9, #0x4                // =4
    1844:      	add	x10, sp, #0x38
    1848:      	mov	x2, x0
    184c:      	add	x0, sp, #0x38
    1850:      	mov	w1, #0x8                // =8
    1854:      	blr	x9
    1858:      	ldr	w8, [sp, #0x38]
    185c:      	lsl	w8, w8, #9
    1860:      	and	x8, x8, #0x80000000
    1864:      	orr	x22, x8, x22
    1868:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    186c:      	cmp	w24, #0x7
    1870:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1874:      	mov	w8, #0x8                // =8
    1878:      	mov	w9, #0x4                // =4
    187c:      	add	x10, sp, #0x20
    1880:      	add	x0, sp, #0x20
    1884:      	mov	w1, #0x8                // =8
    1888:      	blr	x9
    188c:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    1890:      	neg	w8, w0
    1894:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1898:      	mov	w9, #0x1                // =1
    189c:      	strh	w8, [sp, #0x38]
    18a0:      	mov	w8, #0x7                // =7
    18a4:      	add	x1, sp, #0x38
    18a8:      	mov	w24, #0x1               // =1
    18ac:      	strh	w8, [sp, #0x3a]
    18b0:      	mov	x8, #0x9a               // =154
    18b4:      	movk	x8, #0x4, lsl #32
    18b8:      	stur	x8, [sp, #0x3c]
    18bc:      	add	x8, sp, #0x38
    18c0:      	ldr	x22, [x22]
    18c4:      	mov	x0, x22
    18c8:      	blr	x9
    18cc:      	cbnz	x0, 0x1aa4 <generic_tracepoint_event+0x1aa4>
    18d0:      	str	w24, [sp, #0x88]
    18d4:      	mov	x3, xzr
    18d8:      	mov	w8, #0x2                // =2
    18dc:      	add	x9, sp, #0x38
    18e0:      	add	x10, sp, #0x88
    18e4:      	b	0x1c54 <generic_tracepoint_event+0x1c54>
    18e8:      	mov	x22, x2
    18ec:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    18f0:      	mov	w8, #0x8                // =8
    18f4:      	mov	w9, #0x4                // =4
    18f8:      	add	x10, sp, #0x20
    18fc:      	add	x0, sp, #0x20
    1900:      	mov	w1, #0x8                // =8
    1904:      	blr	x9
    1908:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    190c:      	neg	w8, w0
    1910:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1914:      	mov	w9, #0x1                // =1
    1918:      	strh	w8, [sp, #0x38]
    191c:      	mov	w8, #0x7                // =7
    1920:      	add	x1, sp, #0x38
    1924:      	mov	w24, #0x1               // =1
    1928:      	strh	w8, [sp, #0x3a]
    192c:      	mov	x8, #0x93               // =147
    1930:      	movk	x8, #0x4, lsl #32
    1934:      	stur	x8, [sp, #0x3c]
    1938:      	add	x8, sp, #0x38
    193c:      	ldr	x22, [x22]
    1940:      	mov	x0, x22
    1944:      	blr	x9
    1948:      	cbnz	x0, 0x1aa4 <generic_tracepoint_event+0x1aa4>
    194c:      	str	w24, [sp, #0x88]
    1950:      	mov	x3, xzr
    1954:      	mov	w8, #0x2                // =2
    1958:      	add	x9, sp, #0x38
    195c:      	add	x10, sp, #0x88
    1960:      	b	0x1c54 <generic_tracepoint_event+0x1c54>
    1964:      	mov	w8, #0x1                // =1
    1968:      	mov	w9, #0x4                // =4
    196c:      	add	x10, sp, #0x88
    1970:      	add	x0, sp, #0x88
    1974:      	mov	w1, #0x1                // =1
    1978:      	blr	x9
    197c:      	cbz	x0, 0x1c0c <generic_tracepoint_event+0x1c0c>
    1980:      	neg	w8, w0
    1984:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1988:      	mov	w9, #0x1                // =1
    198c:      	strh	w8, [sp, #0x38]
    1990:      	mov	w8, #0x7                // =7
    1994:      	add	x1, sp, #0x38
    1998:      	mov	w24, #0x1               // =1
    199c:      	strh	w8, [sp, #0x3a]
    19a0:      	mov	x8, #0x7a               // =122
    19a4:      	movk	x8, #0x4, lsl #32
    19a8:      	stur	x8, [sp, #0x3c]
    19ac:      	add	x8, sp, #0x38
    19b0:      	ldr	x22, [x22]
    19b4:      	mov	x0, x22
    19b8:      	blr	x9
    19bc:      	cbz	x0, 0x1be8 <generic_tracepoint_event+0x1be8>
    19c0:      	ldr	w8, [x0]
    19c4:      	add	w8, w8, #0x1
    19c8:      	str	w8, [x0]
    19cc:      	ldrsb	x22, [sp, #0x88]
    19d0:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    19d4:      	mov	w8, #0x8                // =8
    19d8:      	mov	w9, #0x4                // =4
    19dc:      	add	x10, sp, #0x20
    19e0:      	add	x0, sp, #0x20
    19e4:      	mov	w1, #0x8                // =8
    19e8:      	blr	x9
    19ec:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    19f0:      	neg	w8, w0
    19f4:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    19f8:      	mov	w9, #0x1                // =1
    19fc:      	strh	w8, [sp, #0x38]
    1a00:      	mov	w8, #0x7                // =7
    1a04:      	add	x1, sp, #0x38
    1a08:      	mov	w24, #0x1               // =1
    1a0c:      	strh	w8, [sp, #0x3a]
    1a10:      	mov	x8, #0xa1               // =161
    1a14:      	movk	x8, #0x4, lsl #32
    1a18:      	stur	x8, [sp, #0x3c]
    1a1c:      	add	x8, sp, #0x38
    1a20:      	ldr	x22, [x22]
    1a24:      	mov	x0, x22
    1a28:      	blr	x9
    1a2c:      	cbnz	x0, 0x1aa4 <generic_tracepoint_event+0x1aa4>
    1a30:      	str	w24, [sp, #0x88]
    1a34:      	mov	x3, xzr
    1a38:      	mov	w8, #0x2                // =2
    1a3c:      	add	x9, sp, #0x38
    1a40:      	add	x10, sp, #0x88
    1a44:      	b	0x1c54 <generic_tracepoint_event+0x1c54>
    1a48:      	mov	w8, #0x8                // =8
    1a4c:      	mov	w9, #0x4                // =4
    1a50:      	add	x10, sp, #0x20
    1a54:      	add	x0, sp, #0x20
    1a58:      	mov	w1, #0x8                // =8
    1a5c:      	blr	x9
    1a60:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    1a64:      	neg	w8, w0
    1a68:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1a6c:      	mov	w9, #0x1                // =1
    1a70:      	strh	w8, [sp, #0x38]
    1a74:      	mov	w8, #0x7                // =7
    1a78:      	add	x1, sp, #0x38
    1a7c:      	mov	w24, #0x1               // =1
    1a80:      	strh	w8, [sp, #0x3a]
    1a84:      	mov	x8, #0x4e               // =78
    1a88:      	movk	x8, #0x4, lsl #32
    1a8c:      	stur	x8, [sp, #0x3c]
    1a90:      	add	x8, sp, #0x38
    1a94:      	ldr	x22, [x22]
    1a98:      	mov	x0, x22
    1a9c:      	blr	x9
    1aa0:      	cbz	x0, 0x1c40 <generic_tracepoint_event+0x1c40>
    1aa4:      	ldr	w8, [x0]
    1aa8:      	add	w8, w8, #0x1
    1aac:      	str	w8, [x0]
    1ab0:      	b	0x1c64 <generic_tracepoint_event+0x1c64>
    1ab4:      	mov	w8, #0x2                // =2
    1ab8:      	mov	w9, #0x4                // =4
    1abc:      	add	x10, sp, #0x88
    1ac0:      	add	x0, sp, #0x88
    1ac4:      	mov	w1, #0x2                // =2
    1ac8:      	blr	x9
    1acc:      	cbz	x0, 0x1c90 <generic_tracepoint_event+0x1c90>
    1ad0:      	neg	w8, w0
    1ad4:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1ad8:      	mov	w9, #0x1                // =1
    1adc:      	strh	w8, [sp, #0x38]
    1ae0:      	mov	w8, #0x7                // =7
    1ae4:      	add	x1, sp, #0x38
    1ae8:      	mov	w24, #0x1               // =1
    1aec:      	strh	w8, [sp, #0x3a]
    1af0:      	mov	x8, #0x65               // =101
    1af4:      	movk	x8, #0x4, lsl #32
    1af8:      	stur	x8, [sp, #0x3c]
    1afc:      	add	x8, sp, #0x38
    1b00:      	ldr	x22, [x22]
    1b04:      	mov	x0, x22
    1b08:      	blr	x9
    1b0c:      	cbz	x0, 0x1c6c <generic_tracepoint_event+0x1c6c>
    1b10:      	ldr	w8, [x0]
    1b14:      	add	w8, w8, #0x1
    1b18:      	str	w8, [x0]
    1b1c:      	ldrh	w22, [sp, #0x88]
    1b20:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1b24:      	mov	w8, #0x4                // =4
    1b28:      	add	x9, sp, #0x88
    1b2c:      	add	x0, sp, #0x88
    1b30:      	mov	w1, #0x4                // =4
    1b34:      	blr	x8
    1b38:      	cbz	x0, 0x1cbc <generic_tracepoint_event+0x1cbc>
    1b3c:      	neg	w8, w0
    1b40:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1b44:      	mov	w9, #0x1                // =1
    1b48:      	strh	w8, [sp, #0x38]
    1b4c:      	mov	w8, #0x7                // =7
    1b50:      	add	x1, sp, #0x38
    1b54:      	mov	w24, #0x1               // =1
    1b58:      	strh	w8, [sp, #0x3a]
    1b5c:      	mov	x8, #0x88               // =136
    1b60:      	movk	x8, #0x4, lsl #32
    1b64:      	stur	x8, [sp, #0x3c]
    1b68:      	add	x8, sp, #0x38
    1b6c:      	ldr	x22, [x22]
    1b70:      	mov	x0, x22
    1b74:      	blr	x9
    1b78:      	cbz	x0, 0x1c98 <generic_tracepoint_event+0x1c98>
    1b7c:      	ldr	w8, [x0]
    1b80:      	add	w8, w8, #0x1
    1b84:      	str	w8, [x0]
    1b88:      	ldr	w22, [sp, #0x88]
    1b8c:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1b90:      	str	w24, [sp, #0x20]
    1b94:      	mov	x3, xzr
    1b98:      	mov	w8, #0x2                // =2
    1b9c:      	add	x9, sp, #0x38
    1ba0:      	add	x10, sp, #0x20
    1ba4:      	add	x1, sp, #0x38
    1ba8:      	add	x2, sp, #0x20
    1bac:      	mov	x0, x22
    1bb0:      	blr	x8
    1bb4:      	ldrsw	x22, [sp, #0x88]
    1bb8:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1bbc:      	str	w24, [sp, #0x20]
    1bc0:      	mov	x3, xzr
    1bc4:      	mov	w8, #0x2                // =2
    1bc8:      	add	x9, sp, #0x38
    1bcc:      	add	x10, sp, #0x20
    1bd0:      	add	x1, sp, #0x38
    1bd4:      	add	x2, sp, #0x20
    1bd8:      	mov	x0, x22
    1bdc:      	blr	x8
    1be0:      	ldrsh	x22, [sp, #0x88]
    1be4:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1be8:      	str	w24, [sp, #0x20]
    1bec:      	mov	x3, xzr
    1bf0:      	mov	w8, #0x2                // =2
    1bf4:      	add	x9, sp, #0x38
    1bf8:      	add	x10, sp, #0x20
    1bfc:      	add	x1, sp, #0x38
    1c00:      	add	x2, sp, #0x20
    1c04:      	mov	x0, x22
    1c08:      	blr	x8
    1c0c:      	ldrsb	x22, [sp, #0x88]
    1c10:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1c14:      	str	w24, [sp, #0x20]
    1c18:      	mov	x3, xzr
    1c1c:      	mov	w8, #0x2                // =2
    1c20:      	add	x9, sp, #0x38
    1c24:      	add	x10, sp, #0x20
    1c28:      	add	x1, sp, #0x38
    1c2c:      	add	x2, sp, #0x20
    1c30:      	mov	x0, x22
    1c34:      	blr	x8
    1c38:      	ldrb	w22, [sp, #0x88]
    1c3c:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1c40:      	str	w24, [sp, #0x88]
    1c44:      	mov	x3, xzr
    1c48:      	mov	w8, #0x2                // =2
    1c4c:      	add	x9, sp, #0x38
    1c50:      	add	x10, sp, #0x88
    1c54:      	add	x1, sp, #0x38
    1c58:      	add	x2, sp, #0x88
    1c5c:      	mov	x0, x22
    1c60:      	blr	x8
    1c64:      	ldr	x22, [sp, #0x20]
    1c68:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1c6c:      	str	w24, [sp, #0x20]
    1c70:      	mov	x3, xzr
    1c74:      	mov	w8, #0x2                // =2
    1c78:      	add	x9, sp, #0x38
    1c7c:      	add	x10, sp, #0x20
    1c80:      	add	x1, sp, #0x38
    1c84:      	add	x2, sp, #0x20
    1c88:      	mov	x0, x22
    1c8c:      	blr	x8
    1c90:      	ldrh	w22, [sp, #0x88]
    1c94:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1c98:      	str	w24, [sp, #0x20]
    1c9c:      	mov	x3, xzr
    1ca0:      	mov	w8, #0x2                // =2
    1ca4:      	add	x9, sp, #0x38
    1ca8:      	add	x10, sp, #0x20
    1cac:      	add	x1, sp, #0x38
    1cb0:      	add	x2, sp, #0x20
    1cb4:      	mov	x0, x22
    1cb8:      	blr	x8
    1cbc:      	ldr	w22, [sp, #0x88]
    1cc0:      	str	x22, [x20, #0x5e60]
    1cc4:      	mov	x24, xzr
    1cc8:      	ldrh	w8, [x21, #0x38]
    1ccc:      	ldr	w25, [x21, #0x10]
    1cd0:      	add	x2, x19, x8
    1cd4:      	cmp	w25, #0xb
    1cd8:      	b.gt	0x1d08 <generic_tracepoint_event+0x1d08>
    1cdc:      	cmp	w25, #0x3
    1ce0:      	b.le	0x1da0 <generic_tracepoint_event+0x1da0>
    1ce4:      	cmp	w25, #0x6
    1ce8:      	b.gt	0x1ec0 <generic_tracepoint_event+0x1ec0>
    1cec:      	cmp	w25, #0x4
    1cf0:      	b.eq	0x2308 <generic_tracepoint_event+0x2308>
    1cf4:      	cmp	w25, #0x5
    1cf8:      	b.eq	0x21b0 <generic_tracepoint_event+0x21b0>
    1cfc:      	cmp	w25, #0x6
    1d00:      	b.eq	0x1dbc <generic_tracepoint_event+0x1dbc>
    1d04:      	b	0x2580 <generic_tracepoint_event+0x2580>
    1d08:      	cmp	w25, #0x1d
    1d0c:      	b.le	0x1e30 <generic_tracepoint_event+0x1e30>
    1d10:      	cmp	w25, #0x25
    1d14:      	b.gt	0x1f38 <generic_tracepoint_event+0x1f38>
    1d18:      	cmp	w25, #0x1e
    1d1c:      	b.eq	0x2374 <generic_tracepoint_event+0x2374>
    1d20:      	cmp	w25, #0x1f
    1d24:      	b.eq	0x2224 <generic_tracepoint_event+0x2224>
    1d28:      	cmp	w25, #0x20
    1d2c:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    1d30:      	mov	w8, #0x1                // =1
    1d34:      	mov	w9, #0x4                // =4
    1d38:      	add	x10, sp, #0x88
    1d3c:      	add	x0, sp, #0x88
    1d40:      	mov	w1, #0x1                // =1
    1d44:      	blr	x9
    1d48:      	cbz	x0, 0x24f8 <generic_tracepoint_event+0x24f8>
    1d4c:      	neg	w8, w0
    1d50:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1d54:      	mov	w9, #0x1                // =1
    1d58:      	strh	w8, [sp, #0x38]
    1d5c:      	mov	w8, #0x7                // =7
    1d60:      	add	x1, sp, #0x38
    1d64:      	mov	w24, #0x1               // =1
    1d68:      	strh	w8, [sp, #0x3a]
    1d6c:      	mov	x8, #0x73               // =115
    1d70:      	movk	x8, #0x4, lsl #32
    1d74:      	stur	x8, [sp, #0x3c]
    1d78:      	add	x8, sp, #0x38
    1d7c:      	ldr	x22, [x22]
    1d80:      	mov	x0, x22
    1d84:      	blr	x9
    1d88:      	cbz	x0, 0x24d4 <generic_tracepoint_event+0x24d4>
    1d8c:      	ldr	w8, [x0]
    1d90:      	add	w8, w8, #0x1
    1d94:      	str	w8, [x0]
    1d98:      	ldrb	w24, [sp, #0x88]
    1d9c:      	b	0x2580 <generic_tracepoint_event+0x2580>
    1da0:      	cmn	w25, #0xc
    1da4:      	b.le	0x1fc4 <generic_tracepoint_event+0x1fc4>
    1da8:      	add	w8, w25, #0xb
    1dac:      	cmp	w8, #0x2
    1db0:      	b.lo	0x1ecc <generic_tracepoint_event+0x1ecc>
    1db4:      	cmp	w25, #0x2
    1db8:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    1dbc:      	mov	w8, #0x8                // =8
    1dc0:      	mov	w9, #0x4                // =4
    1dc4:      	add	x10, sp, #0x20
    1dc8:      	add	x0, sp, #0x20
    1dcc:      	mov	w1, #0x8                // =8
    1dd0:      	blr	x9
    1dd4:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    1dd8:      	neg	w8, w0
    1ddc:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1de0:      	mov	w9, #0x1                // =1
    1de4:      	strh	w8, [sp, #0x38]
    1de8:      	mov	w8, #0x7                // =7
    1dec:      	add	x1, sp, #0x38
    1df0:      	mov	w24, #0x1               // =1
    1df4:      	strh	w8, [sp, #0x3a]
    1df8:      	mov	x8, #0x81               // =129
    1dfc:      	movk	x8, #0x4, lsl #32
    1e00:      	stur	x8, [sp, #0x3c]
    1e04:      	add	x8, sp, #0x38
    1e08:      	ldr	x22, [x22]
    1e0c:      	mov	x0, x22
    1e10:      	blr	x9
    1e14:      	cbnz	x0, 0x2364 <generic_tracepoint_event+0x2364>
    1e18:      	str	w24, [sp, #0x88]
    1e1c:      	mov	x3, xzr
    1e20:      	mov	w8, #0x2                // =2
    1e24:      	add	x9, sp, #0x38
    1e28:      	add	x10, sp, #0x88
    1e2c:      	b	0x2514 <generic_tracepoint_event+0x2514>
    1e30:      	cmp	w25, #0x11
    1e34:      	b.le	0x1fd8 <generic_tracepoint_event+0x1fd8>
    1e38:      	cmp	w25, #0x12
    1e3c:      	b.eq	0x21a8 <generic_tracepoint_event+0x21a8>
    1e40:      	cmp	w25, #0x1c
    1e44:      	b.eq	0x1ecc <generic_tracepoint_event+0x1ecc>
    1e48:      	cmp	w25, #0x1d
    1e4c:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    1e50:      	mov	w8, #0x2                // =2
    1e54:      	mov	w9, #0x4                // =4
    1e58:      	add	x10, sp, #0x88
    1e5c:      	add	x0, sp, #0x88
    1e60:      	mov	w1, #0x2                // =2
    1e64:      	blr	x9
    1e68:      	cbz	x0, 0x24a0 <generic_tracepoint_event+0x24a0>
    1e6c:      	neg	w8, w0
    1e70:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1e74:      	mov	w9, #0x1                // =1
    1e78:      	strh	w8, [sp, #0x38]
    1e7c:      	mov	w8, #0x7                // =7
    1e80:      	add	x1, sp, #0x38
    1e84:      	mov	w24, #0x1               // =1
    1e88:      	strh	w8, [sp, #0x3a]
    1e8c:      	mov	x8, #0x6c               // =108
    1e90:      	movk	x8, #0x4, lsl #32
    1e94:      	stur	x8, [sp, #0x3c]
    1e98:      	add	x8, sp, #0x38
    1e9c:      	ldr	x22, [x22]
    1ea0:      	mov	x0, x22
    1ea4:      	blr	x9
    1ea8:      	cbz	x0, 0x247c <generic_tracepoint_event+0x247c>
    1eac:      	ldr	w8, [x0]
    1eb0:      	add	w8, w8, #0x1
    1eb4:      	str	w8, [x0]
    1eb8:      	ldrsh	x24, [sp, #0x88]
    1ebc:      	b	0x2580 <generic_tracepoint_event+0x2580>
    1ec0:      	sub	w8, w25, #0xa
    1ec4:      	cmp	w8, #0x2
    1ec8:      	b.hs	0x212c <generic_tracepoint_event+0x212c>
    1ecc:      	mov	w8, #0x8                // =8
    1ed0:      	mov	w9, #0x4                // =4
    1ed4:      	add	x10, sp, #0x20
    1ed8:      	add	x0, sp, #0x20
    1edc:      	mov	w1, #0x8                // =8
    1ee0:      	blr	x9
    1ee4:      	cbz	x0, 0x20e8 <generic_tracepoint_event+0x20e8>
    1ee8:      	neg	w8, w0
    1eec:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1ef0:      	mov	w9, #0x1                // =1
    1ef4:      	strh	w8, [sp, #0x38]
    1ef8:      	mov	w8, #0x7                // =7
    1efc:      	add	x1, sp, #0x38
    1f00:      	mov	w24, #0x1               // =1
    1f04:      	strh	w8, [sp, #0x3a]
    1f08:      	mov	x8, #0x45               // =69
    1f0c:      	movk	x8, #0x4, lsl #32
    1f10:      	stur	x8, [sp, #0x3c]
    1f14:      	add	x8, sp, #0x38
    1f18:      	ldr	x22, [x22]
    1f1c:      	mov	x0, x22
    1f20:      	blr	x9
    1f24:      	cbz	x0, 0x20c4 <generic_tracepoint_event+0x20c4>
    1f28:      	ldr	w8, [x0]
    1f2c:      	add	w8, w8, #0x1
    1f30:      	str	w8, [x0]
    1f34:      	b	0x20e8 <generic_tracepoint_event+0x20e8>
    1f38:      	cmp	w25, #0x26
    1f3c:      	b.eq	0x23e4 <generic_tracepoint_event+0x23e4>
    1f40:      	cmp	w25, #0x28
    1f44:      	b.eq	0x2294 <generic_tracepoint_event+0x2294>
    1f48:      	cmp	w25, #0x29
    1f4c:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    1f50:      	mov	w8, #0x8                // =8
    1f54:      	mov	w9, #0x4                // =4
    1f58:      	add	x10, sp, #0x20
    1f5c:      	add	x0, sp, #0x20
    1f60:      	mov	w1, #0x8                // =8
    1f64:      	blr	x9
    1f68:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    1f6c:      	neg	w8, w0
    1f70:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1f74:      	mov	w9, #0x1                // =1
    1f78:      	strh	w8, [sp, #0x38]
    1f7c:      	mov	w8, #0x7                // =7
    1f80:      	add	x1, sp, #0x38
    1f84:      	mov	w24, #0x1               // =1
    1f88:      	strh	w8, [sp, #0x3a]
    1f8c:      	mov	x8, #0xa8               // =168
    1f90:      	movk	x8, #0x4, lsl #32
    1f94:      	stur	x8, [sp, #0x3c]
    1f98:      	add	x8, sp, #0x38
    1f9c:      	ldr	x22, [x22]
    1fa0:      	mov	x0, x22
    1fa4:      	blr	x9
    1fa8:      	cbnz	x0, 0x2364 <generic_tracepoint_event+0x2364>
    1fac:      	str	w24, [sp, #0x88]
    1fb0:      	mov	x3, xzr
    1fb4:      	mov	w8, #0x2                // =2
    1fb8:      	add	x9, sp, #0x38
    1fbc:      	add	x10, sp, #0x88
    1fc0:      	b	0x2514 <generic_tracepoint_event+0x2514>
    1fc4:      	cmn	w25, #0xd
    1fc8:      	b.eq	0x2058 <generic_tracepoint_event+0x2058>
    1fcc:      	cmn	w25, #0xc
    1fd0:      	b.eq	0x1fe8 <generic_tracepoint_event+0x1fe8>
    1fd4:      	b	0x2580 <generic_tracepoint_event+0x2580>
    1fd8:      	cmp	w25, #0xc
    1fdc:      	b.eq	0x2058 <generic_tracepoint_event+0x2058>
    1fe0:      	cmp	w25, #0xd
    1fe4:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    1fe8:      	mov	w8, #0x4                // =4
    1fec:      	add	x9, sp, #0x88
    1ff0:      	add	x0, sp, #0x88
    1ff4:      	mov	w1, #0x4                // =4
    1ff8:      	blr	x8
    1ffc:      	cbz	x0, 0x257c <generic_tracepoint_event+0x257c>
    2000:      	neg	w8, w0
    2004:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2008:      	mov	w9, #0x1                // =1
    200c:      	strh	w8, [sp, #0x38]
    2010:      	mov	w8, #0x7                // =7
    2014:      	add	x1, sp, #0x38
    2018:      	mov	w24, #0x1               // =1
    201c:      	strh	w8, [sp, #0x3a]
    2020:      	mov	x8, #0x5e               // =94
    2024:      	movk	x8, #0x4, lsl #32
    2028:      	stur	x8, [sp, #0x3c]
    202c:      	add	x8, sp, #0x38
    2030:      	ldr	x22, [x22]
    2034:      	mov	x0, x22
    2038:      	blr	x9
    203c:      	cbnz	x0, 0x243c <generic_tracepoint_event+0x243c>
    2040:      	str	w24, [sp, #0x20]
    2044:      	mov	x3, xzr
    2048:      	mov	w8, #0x2                // =2
    204c:      	add	x9, sp, #0x38
    2050:      	add	x10, sp, #0x20
    2054:      	b	0x256c <generic_tracepoint_event+0x256c>
    2058:      	mov	w8, #0x4                // =4
    205c:      	add	x9, sp, #0x88
    2060:      	add	x0, sp, #0x88
    2064:      	mov	w1, #0x4                // =4
    2068:      	blr	x8
    206c:      	cbz	x0, 0x2474 <generic_tracepoint_event+0x2474>
    2070:      	neg	w8, w0
    2074:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2078:      	mov	w9, #0x1                // =1
    207c:      	strh	w8, [sp, #0x38]
    2080:      	mov	w8, #0x7                // =7
    2084:      	add	x1, sp, #0x38
    2088:      	mov	w24, #0x1               // =1
    208c:      	strh	w8, [sp, #0x3a]
    2090:      	mov	x8, #0x56               // =86
    2094:      	movk	x8, #0x4, lsl #32
    2098:      	stur	x8, [sp, #0x3c]
    209c:      	add	x8, sp, #0x38
    20a0:      	ldr	x22, [x22]
    20a4:      	mov	x0, x22
    20a8:      	blr	x9
    20ac:      	cbz	x0, 0x2450 <generic_tracepoint_event+0x2450>
    20b0:      	ldr	w8, [x0]
    20b4:      	add	w8, w8, #0x1
    20b8:      	str	w8, [x0]
    20bc:      	ldrsw	x24, [sp, #0x88]
    20c0:      	b	0x2580 <generic_tracepoint_event+0x2580>
    20c4:      	str	w24, [sp, #0x88]
    20c8:      	mov	x3, xzr
    20cc:      	mov	w8, #0x2                // =2
    20d0:      	add	x9, sp, #0x38
    20d4:      	add	x10, sp, #0x88
    20d8:      	add	x1, sp, #0x38
    20dc:      	add	x2, sp, #0x88
    20e0:      	mov	x0, x22
    20e4:      	blr	x8
    20e8:      	ldr	x24, [sp, #0x20]
    20ec:      	cmp	w25, #0x1c
    20f0:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    20f4:      	mov	w8, #0x23               // =35
    20f8:      	blr	x8
    20fc:      	mov	w8, #0x8                // =8
    2100:      	mov	w9, #0x4                // =4
    2104:      	add	x10, sp, #0x38
    2108:      	mov	x2, x0
    210c:      	add	x0, sp, #0x38
    2110:      	mov	w1, #0x8                // =8
    2114:      	blr	x9
    2118:      	ldr	w8, [sp, #0x38]
    211c:      	lsl	w8, w8, #9
    2120:      	and	x8, x8, #0x80000000
    2124:      	orr	x24, x8, x24
    2128:      	b	0x2580 <generic_tracepoint_event+0x2580>
    212c:      	cmp	w25, #0x7
    2130:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    2134:      	mov	w8, #0x8                // =8
    2138:      	mov	w9, #0x4                // =4
    213c:      	add	x10, sp, #0x20
    2140:      	add	x0, sp, #0x20
    2144:      	mov	w1, #0x8                // =8
    2148:      	blr	x9
    214c:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    2150:      	neg	w8, w0
    2154:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2158:      	mov	w9, #0x1                // =1
    215c:      	strh	w8, [sp, #0x38]
    2160:      	mov	w8, #0x7                // =7
    2164:      	add	x1, sp, #0x38
    2168:      	mov	w24, #0x1               // =1
    216c:      	strh	w8, [sp, #0x3a]
    2170:      	mov	x8, #0x9a               // =154
    2174:      	movk	x8, #0x4, lsl #32
    2178:      	stur	x8, [sp, #0x3c]
    217c:      	add	x8, sp, #0x38
    2180:      	ldr	x22, [x22]
    2184:      	mov	x0, x22
    2188:      	blr	x9
    218c:      	cbnz	x0, 0x2364 <generic_tracepoint_event+0x2364>
    2190:      	str	w24, [sp, #0x88]
    2194:      	mov	x3, xzr
    2198:      	mov	w8, #0x2                // =2
    219c:      	add	x9, sp, #0x38
    21a0:      	add	x10, sp, #0x88
    21a4:      	b	0x2514 <generic_tracepoint_event+0x2514>
    21a8:      	mov	x24, x2
    21ac:      	b	0x2580 <generic_tracepoint_event+0x2580>
    21b0:      	mov	w8, #0x8                // =8
    21b4:      	mov	w9, #0x4                // =4
    21b8:      	add	x10, sp, #0x20
    21bc:      	add	x0, sp, #0x20
    21c0:      	mov	w1, #0x8                // =8
    21c4:      	blr	x9
    21c8:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    21cc:      	neg	w8, w0
    21d0:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    21d4:      	mov	w9, #0x1                // =1
    21d8:      	strh	w8, [sp, #0x38]
    21dc:      	mov	w8, #0x7                // =7
    21e0:      	add	x1, sp, #0x38
    21e4:      	mov	w24, #0x1               // =1
    21e8:      	strh	w8, [sp, #0x3a]
    21ec:      	mov	x8, #0x93               // =147
    21f0:      	movk	x8, #0x4, lsl #32
    21f4:      	stur	x8, [sp, #0x3c]
    21f8:      	add	x8, sp, #0x38
    21fc:      	ldr	x22, [x22]
    2200:      	mov	x0, x22
    2204:      	blr	x9
    2208:      	cbnz	x0, 0x2364 <generic_tracepoint_event+0x2364>
    220c:      	str	w24, [sp, #0x88]
    2210:      	mov	x3, xzr
    2214:      	mov	w8, #0x2                // =2
    2218:      	add	x9, sp, #0x38
    221c:      	add	x10, sp, #0x88
    2220:      	b	0x2514 <generic_tracepoint_event+0x2514>
    2224:      	mov	w8, #0x1                // =1
    2228:      	mov	w9, #0x4                // =4
    222c:      	add	x10, sp, #0x88
    2230:      	add	x0, sp, #0x88
    2234:      	mov	w1, #0x1                // =1
    2238:      	blr	x9
    223c:      	cbz	x0, 0x24cc <generic_tracepoint_event+0x24cc>
    2240:      	neg	w8, w0
    2244:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2248:      	mov	w9, #0x1                // =1
    224c:      	strh	w8, [sp, #0x38]
    2250:      	mov	w8, #0x7                // =7
    2254:      	add	x1, sp, #0x38
    2258:      	mov	w24, #0x1               // =1
    225c:      	strh	w8, [sp, #0x3a]
    2260:      	mov	x8, #0x7a               // =122
    2264:      	movk	x8, #0x4, lsl #32
    2268:      	stur	x8, [sp, #0x3c]
    226c:      	add	x8, sp, #0x38
    2270:      	ldr	x22, [x22]
    2274:      	mov	x0, x22
    2278:      	blr	x9
    227c:      	cbz	x0, 0x24a8 <generic_tracepoint_event+0x24a8>
    2280:      	ldr	w8, [x0]
    2284:      	add	w8, w8, #0x1
    2288:      	str	w8, [x0]
    228c:      	ldrsb	x24, [sp, #0x88]
    2290:      	b	0x2580 <generic_tracepoint_event+0x2580>
    2294:      	mov	w8, #0x8                // =8
    2298:      	mov	w9, #0x4                // =4
    229c:      	add	x10, sp, #0x20
    22a0:      	add	x0, sp, #0x20
    22a4:      	mov	w1, #0x8                // =8
    22a8:      	blr	x9
    22ac:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    22b0:      	neg	w8, w0
    22b4:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    22b8:      	mov	w9, #0x1                // =1
    22bc:      	strh	w8, [sp, #0x38]
    22c0:      	mov	w8, #0x7                // =7
    22c4:      	add	x1, sp, #0x38
    22c8:      	mov	w24, #0x1               // =1
    22cc:      	strh	w8, [sp, #0x3a]
    22d0:      	mov	x8, #0xa1               // =161
    22d4:      	movk	x8, #0x4, lsl #32
    22d8:      	stur	x8, [sp, #0x3c]
    22dc:      	add	x8, sp, #0x38
    22e0:      	ldr	x22, [x22]
    22e4:      	mov	x0, x22
    22e8:      	blr	x9
    22ec:      	cbnz	x0, 0x2364 <generic_tracepoint_event+0x2364>
    22f0:      	str	w24, [sp, #0x88]
    22f4:      	mov	x3, xzr
    22f8:      	mov	w8, #0x2                // =2
    22fc:      	add	x9, sp, #0x38
    2300:      	add	x10, sp, #0x88
    2304:      	b	0x2514 <generic_tracepoint_event+0x2514>
    2308:      	mov	w8, #0x8                // =8
    230c:      	mov	w9, #0x4                // =4
    2310:      	add	x10, sp, #0x20
    2314:      	add	x0, sp, #0x20
    2318:      	mov	w1, #0x8                // =8
    231c:      	blr	x9
    2320:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    2324:      	neg	w8, w0
    2328:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    232c:      	mov	w9, #0x1                // =1
    2330:      	strh	w8, [sp, #0x38]
    2334:      	mov	w8, #0x7                // =7
    2338:      	add	x1, sp, #0x38
    233c:      	mov	w24, #0x1               // =1
    2340:      	strh	w8, [sp, #0x3a]
    2344:      	mov	x8, #0x4e               // =78
    2348:      	movk	x8, #0x4, lsl #32
    234c:      	stur	x8, [sp, #0x3c]
    2350:      	add	x8, sp, #0x38
    2354:      	ldr	x22, [x22]
    2358:      	mov	x0, x22
    235c:      	blr	x9
    2360:      	cbz	x0, 0x2500 <generic_tracepoint_event+0x2500>
    2364:      	ldr	w8, [x0]
    2368:      	add	w8, w8, #0x1
    236c:      	str	w8, [x0]
    2370:      	b	0x2524 <generic_tracepoint_event+0x2524>
    2374:      	mov	w8, #0x2                // =2
    2378:      	mov	w9, #0x4                // =4
    237c:      	add	x10, sp, #0x88
    2380:      	add	x0, sp, #0x88
    2384:      	mov	w1, #0x2                // =2
    2388:      	blr	x9
    238c:      	cbz	x0, 0x2550 <generic_tracepoint_event+0x2550>
    2390:      	neg	w8, w0
    2394:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2398:      	mov	w9, #0x1                // =1
    239c:      	strh	w8, [sp, #0x38]
    23a0:      	mov	w8, #0x7                // =7
    23a4:      	add	x1, sp, #0x38
    23a8:      	mov	w24, #0x1               // =1
    23ac:      	strh	w8, [sp, #0x3a]
    23b0:      	mov	x8, #0x65               // =101
    23b4:      	movk	x8, #0x4, lsl #32
    23b8:      	stur	x8, [sp, #0x3c]
    23bc:      	add	x8, sp, #0x38
    23c0:      	ldr	x22, [x22]
    23c4:      	mov	x0, x22
    23c8:      	blr	x9
    23cc:      	cbz	x0, 0x252c <generic_tracepoint_event+0x252c>
    23d0:      	ldr	w8, [x0]
    23d4:      	add	w8, w8, #0x1
    23d8:      	str	w8, [x0]
    23dc:      	ldrh	w24, [sp, #0x88]
    23e0:      	b	0x2580 <generic_tracepoint_event+0x2580>
    23e4:      	mov	w8, #0x4                // =4
    23e8:      	add	x9, sp, #0x88
    23ec:      	add	x0, sp, #0x88
    23f0:      	mov	w1, #0x4                // =4
    23f4:      	blr	x8
    23f8:      	cbz	x0, 0x257c <generic_tracepoint_event+0x257c>
    23fc:      	neg	w8, w0
    2400:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2404:      	mov	w9, #0x1                // =1
    2408:      	strh	w8, [sp, #0x38]
    240c:      	mov	w8, #0x7                // =7
    2410:      	add	x1, sp, #0x38
    2414:      	mov	w24, #0x1               // =1
    2418:      	strh	w8, [sp, #0x3a]
    241c:      	mov	x8, #0x88               // =136
    2420:      	movk	x8, #0x4, lsl #32
    2424:      	stur	x8, [sp, #0x3c]
    2428:      	add	x8, sp, #0x38
    242c:      	ldr	x22, [x22]
    2430:      	mov	x0, x22
    2434:      	blr	x9
    2438:      	cbz	x0, 0x2558 <generic_tracepoint_event+0x2558>
    243c:      	ldr	w8, [x0]
    2440:      	add	w8, w8, #0x1
    2444:      	str	w8, [x0]
    2448:      	ldr	w24, [sp, #0x88]
    244c:      	b	0x2580 <generic_tracepoint_event+0x2580>
    2450:      	str	w24, [sp, #0x20]
    2454:      	mov	x3, xzr
    2458:      	mov	w8, #0x2                // =2
    245c:      	add	x9, sp, #0x38
    2460:      	add	x10, sp, #0x20
    2464:      	add	x1, sp, #0x38
    2468:      	add	x2, sp, #0x20
    246c:      	mov	x0, x22
    2470:      	blr	x8
    2474:      	ldrsw	x24, [sp, #0x88]
    2478:      	b	0x2580 <generic_tracepoint_event+0x2580>
    247c:      	str	w24, [sp, #0x20]
    2480:      	mov	x3, xzr
    2484:      	mov	w8, #0x2                // =2
    2488:      	add	x9, sp, #0x38
    248c:      	add	x10, sp, #0x20
    2490:      	add	x1, sp, #0x38
    2494:      	add	x2, sp, #0x20
    2498:      	mov	x0, x22
    249c:      	blr	x8
    24a0:      	ldrsh	x24, [sp, #0x88]
    24a4:      	b	0x2580 <generic_tracepoint_event+0x2580>
    24a8:      	str	w24, [sp, #0x20]
    24ac:      	mov	x3, xzr
    24b0:      	mov	w8, #0x2                // =2
    24b4:      	add	x9, sp, #0x38
    24b8:      	add	x10, sp, #0x20
    24bc:      	add	x1, sp, #0x38
    24c0:      	add	x2, sp, #0x20
    24c4:      	mov	x0, x22
    24c8:      	blr	x8
    24cc:      	ldrsb	x24, [sp, #0x88]
    24d0:      	b	0x2580 <generic_tracepoint_event+0x2580>
    24d4:      	str	w24, [sp, #0x20]
    24d8:      	mov	x3, xzr
    24dc:      	mov	w8, #0x2                // =2
    24e0:      	add	x9, sp, #0x38
    24e4:      	add	x10, sp, #0x20
    24e8:      	add	x1, sp, #0x38
    24ec:      	add	x2, sp, #0x20
    24f0:      	mov	x0, x22
    24f4:      	blr	x8
    24f8:      	ldrb	w24, [sp, #0x88]
    24fc:      	b	0x2580 <generic_tracepoint_event+0x2580>
    2500:      	str	w24, [sp, #0x88]
    2504:      	mov	x3, xzr
    2508:      	mov	w8, #0x2                // =2
    250c:      	add	x9, sp, #0x38
    2510:      	add	x10, sp, #0x88
    2514:      	add	x1, sp, #0x38
    2518:      	add	x2, sp, #0x88
    251c:      	mov	x0, x22
    2520:      	blr	x8
    2524:      	ldr	x24, [sp, #0x20]
    2528:      	b	0x2580 <generic_tracepoint_event+0x2580>
    252c:      	str	w24, [sp, #0x20]
    2530:      	mov	x3, xzr
    2534:      	mov	w8, #0x2                // =2
    2538:      	add	x9, sp, #0x38
    253c:      	add	x10, sp, #0x20
    2540:      	add	x1, sp, #0x38
    2544:      	add	x2, sp, #0x20
    2548:      	mov	x0, x22
    254c:      	blr	x8
    2550:      	ldrh	w24, [sp, #0x88]
    2554:      	b	0x2580 <generic_tracepoint_event+0x2580>
    2558:      	str	w24, [sp, #0x20]
    255c:      	mov	x3, xzr
    2560:      	mov	w8, #0x2                // =2
    2564:      	add	x9, sp, #0x38
    2568:      	add	x10, sp, #0x20
    256c:      	add	x1, sp, #0x38
    2570:      	add	x2, sp, #0x20
    2574:      	mov	x0, x22
    2578:      	blr	x8
    257c:      	ldr	w24, [sp, #0x88]
    2580:      	str	x24, [x20, #0x5e68]
    2584:      	mov	x22, xzr
    2588:      	ldrh	w8, [x21, #0x3c]
    258c:      	ldr	w24, [x21, #0x14]
    2590:      	add	x2, x19, x8
    2594:      	cmp	w24, #0xb
    2598:      	b.gt	0x25c8 <generic_tracepoint_event+0x25c8>
    259c:      	cmp	w24, #0x3
    25a0:      	b.le	0x2660 <generic_tracepoint_event+0x2660>
    25a4:      	cmp	w24, #0x6
    25a8:      	b.gt	0x2780 <generic_tracepoint_event+0x2780>
    25ac:      	cmp	w24, #0x4
    25b0:      	b.eq	0x2bc8 <generic_tracepoint_event+0x2bc8>
    25b4:      	cmp	w24, #0x5
    25b8:      	b.eq	0x2a70 <generic_tracepoint_event+0x2a70>
    25bc:      	cmp	w24, #0x6
    25c0:      	b.eq	0x267c <generic_tracepoint_event+0x267c>
    25c4:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    25c8:      	cmp	w24, #0x1d
    25cc:      	b.le	0x26f0 <generic_tracepoint_event+0x26f0>
    25d0:      	cmp	w24, #0x25
    25d4:      	b.gt	0x27f8 <generic_tracepoint_event+0x27f8>
    25d8:      	cmp	w24, #0x1e
    25dc:      	b.eq	0x2c34 <generic_tracepoint_event+0x2c34>
    25e0:      	cmp	w24, #0x1f
    25e4:      	b.eq	0x2ae4 <generic_tracepoint_event+0x2ae4>
    25e8:      	cmp	w24, #0x20
    25ec:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    25f0:      	mov	w8, #0x1                // =1
    25f4:      	mov	w9, #0x4                // =4
    25f8:      	add	x10, sp, #0x88
    25fc:      	add	x0, sp, #0x88
    2600:      	mov	w1, #0x1                // =1
    2604:      	blr	x9
    2608:      	cbz	x0, 0x2db8 <generic_tracepoint_event+0x2db8>
    260c:      	neg	w8, w0
    2610:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2614:      	mov	w9, #0x1                // =1
    2618:      	strh	w8, [sp, #0x38]
    261c:      	mov	w8, #0x7                // =7
    2620:      	add	x1, sp, #0x38
    2624:      	mov	w22, #0x1               // =1
    2628:      	strh	w8, [sp, #0x3a]
    262c:      	mov	x8, #0x73               // =115
    2630:      	movk	x8, #0x4, lsl #32
    2634:      	stur	x8, [sp, #0x3c]
    2638:      	add	x8, sp, #0x38
    263c:      	ldr	x21, [x21]
    2640:      	mov	x0, x21
    2644:      	blr	x9
    2648:      	cbz	x0, 0x2d94 <generic_tracepoint_event+0x2d94>
    264c:      	ldr	w8, [x0]
    2650:      	add	w8, w8, #0x1
    2654:      	str	w8, [x0]
    2658:      	ldrb	w22, [sp, #0x88]
    265c:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2660:      	cmn	w24, #0xc
    2664:      	b.le	0x2884 <generic_tracepoint_event+0x2884>
    2668:      	add	w8, w24, #0xb
    266c:      	cmp	w8, #0x2
    2670:      	b.lo	0x278c <generic_tracepoint_event+0x278c>
    2674:      	cmp	w24, #0x2
    2678:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    267c:      	mov	w8, #0x8                // =8
    2680:      	mov	w9, #0x4                // =4
    2684:      	add	x10, sp, #0x20
    2688:      	add	x0, sp, #0x20
    268c:      	mov	w1, #0x8                // =8
    2690:      	blr	x9
    2694:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    2698:      	neg	w8, w0
    269c:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    26a0:      	mov	w9, #0x1                // =1
    26a4:      	strh	w8, [sp, #0x38]
    26a8:      	mov	w8, #0x7                // =7
    26ac:      	add	x1, sp, #0x38
    26b0:      	mov	w22, #0x1               // =1
    26b4:      	strh	w8, [sp, #0x3a]
    26b8:      	mov	x8, #0x81               // =129
    26bc:      	movk	x8, #0x4, lsl #32
    26c0:      	stur	x8, [sp, #0x3c]
    26c4:      	add	x8, sp, #0x38
    26c8:      	ldr	x21, [x21]
    26cc:      	mov	x0, x21
    26d0:      	blr	x9
    26d4:      	cbnz	x0, 0x2c24 <generic_tracepoint_event+0x2c24>
    26d8:      	str	w22, [sp, #0x88]
    26dc:      	mov	x3, xzr
    26e0:      	mov	w8, #0x2                // =2
    26e4:      	add	x9, sp, #0x38
    26e8:      	add	x10, sp, #0x88
    26ec:      	b	0x2dd4 <generic_tracepoint_event+0x2dd4>
    26f0:      	cmp	w24, #0x11
    26f4:      	b.le	0x2898 <generic_tracepoint_event+0x2898>
    26f8:      	cmp	w24, #0x12
    26fc:      	b.eq	0x2a68 <generic_tracepoint_event+0x2a68>
    2700:      	cmp	w24, #0x1c
    2704:      	b.eq	0x278c <generic_tracepoint_event+0x278c>
    2708:      	cmp	w24, #0x1d
    270c:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    2710:      	mov	w8, #0x2                // =2
    2714:      	mov	w9, #0x4                // =4
    2718:      	add	x10, sp, #0x88
    271c:      	add	x0, sp, #0x88
    2720:      	mov	w1, #0x2                // =2
    2724:      	blr	x9
    2728:      	cbz	x0, 0x2d60 <generic_tracepoint_event+0x2d60>
    272c:      	neg	w8, w0
    2730:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2734:      	mov	w9, #0x1                // =1
    2738:      	strh	w8, [sp, #0x38]
    273c:      	mov	w8, #0x7                // =7
    2740:      	add	x1, sp, #0x38
    2744:      	mov	w22, #0x1               // =1
    2748:      	strh	w8, [sp, #0x3a]
    274c:      	mov	x8, #0x6c               // =108
    2750:      	movk	x8, #0x4, lsl #32
    2754:      	stur	x8, [sp, #0x3c]
    2758:      	add	x8, sp, #0x38
    275c:      	ldr	x21, [x21]
    2760:      	mov	x0, x21
    2764:      	blr	x9
    2768:      	cbz	x0, 0x2d3c <generic_tracepoint_event+0x2d3c>
    276c:      	ldr	w8, [x0]
    2770:      	add	w8, w8, #0x1
    2774:      	str	w8, [x0]
    2778:      	ldrsh	x22, [sp, #0x88]
    277c:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2780:      	sub	w8, w24, #0xa
    2784:      	cmp	w8, #0x2
    2788:      	b.hs	0x29ec <generic_tracepoint_event+0x29ec>
    278c:      	mov	w8, #0x8                // =8
    2790:      	mov	w9, #0x4                // =4
    2794:      	add	x10, sp, #0x20
    2798:      	add	x0, sp, #0x20
    279c:      	mov	w1, #0x8                // =8
    27a0:      	blr	x9
    27a4:      	cbz	x0, 0x29a8 <generic_tracepoint_event+0x29a8>
    27a8:      	neg	w8, w0
    27ac:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    27b0:      	mov	w9, #0x1                // =1
    27b4:      	strh	w8, [sp, #0x38]
    27b8:      	mov	w8, #0x7                // =7
    27bc:      	add	x1, sp, #0x38
    27c0:      	mov	w22, #0x1               // =1
    27c4:      	strh	w8, [sp, #0x3a]
    27c8:      	mov	x8, #0x45               // =69
    27cc:      	movk	x8, #0x4, lsl #32
    27d0:      	stur	x8, [sp, #0x3c]
    27d4:      	add	x8, sp, #0x38
    27d8:      	ldr	x21, [x21]
    27dc:      	mov	x0, x21
    27e0:      	blr	x9
    27e4:      	cbz	x0, 0x2984 <generic_tracepoint_event+0x2984>
    27e8:      	ldr	w8, [x0]
    27ec:      	add	w8, w8, #0x1
    27f0:      	str	w8, [x0]
    27f4:      	b	0x29a8 <generic_tracepoint_event+0x29a8>
    27f8:      	cmp	w24, #0x26
    27fc:      	b.eq	0x2ca4 <generic_tracepoint_event+0x2ca4>
    2800:      	cmp	w24, #0x28
    2804:      	b.eq	0x2b54 <generic_tracepoint_event+0x2b54>
    2808:      	cmp	w24, #0x29
    280c:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    2810:      	mov	w8, #0x8                // =8
    2814:      	mov	w9, #0x4                // =4
    2818:      	add	x10, sp, #0x20
    281c:      	add	x0, sp, #0x20
    2820:      	mov	w1, #0x8                // =8
    2824:      	blr	x9
    2828:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    282c:      	neg	w8, w0
    2830:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2834:      	mov	w9, #0x1                // =1
    2838:      	strh	w8, [sp, #0x38]
    283c:      	mov	w8, #0x7                // =7
    2840:      	add	x1, sp, #0x38
    2844:      	mov	w22, #0x1               // =1
    2848:      	strh	w8, [sp, #0x3a]
    284c:      	mov	x8, #0xa8               // =168
    2850:      	movk	x8, #0x4, lsl #32
    2854:      	stur	x8, [sp, #0x3c]
    2858:      	add	x8, sp, #0x38
    285c:      	ldr	x21, [x21]
    2860:      	mov	x0, x21
    2864:      	blr	x9
    2868:      	cbnz	x0, 0x2c24 <generic_tracepoint_event+0x2c24>
    286c:      	str	w22, [sp, #0x88]
    2870:      	mov	x3, xzr
    2874:      	mov	w8, #0x2                // =2
    2878:      	add	x9, sp, #0x38
    287c:      	add	x10, sp, #0x88
    2880:      	b	0x2dd4 <generic_tracepoint_event+0x2dd4>
    2884:      	cmn	w24, #0xd
    2888:      	b.eq	0x2918 <generic_tracepoint_event+0x2918>
    288c:      	cmn	w24, #0xc
    2890:      	b.eq	0x28a8 <generic_tracepoint_event+0x28a8>
    2894:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2898:      	cmp	w24, #0xc
    289c:      	b.eq	0x2918 <generic_tracepoint_event+0x2918>
    28a0:      	cmp	w24, #0xd
    28a4:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    28a8:      	mov	w8, #0x4                // =4
    28ac:      	add	x9, sp, #0x88
    28b0:      	add	x0, sp, #0x88
    28b4:      	mov	w1, #0x4                // =4
    28b8:      	blr	x8
    28bc:      	cbz	x0, 0x2e3c <generic_tracepoint_event+0x2e3c>
    28c0:      	neg	w8, w0
    28c4:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    28c8:      	mov	w9, #0x1                // =1
    28cc:      	strh	w8, [sp, #0x38]
    28d0:      	mov	w8, #0x7                // =7
    28d4:      	add	x1, sp, #0x38
    28d8:      	mov	w22, #0x1               // =1
    28dc:      	strh	w8, [sp, #0x3a]
    28e0:      	mov	x8, #0x5e               // =94
    28e4:      	movk	x8, #0x4, lsl #32
    28e8:      	stur	x8, [sp, #0x3c]
    28ec:      	add	x8, sp, #0x38
    28f0:      	ldr	x21, [x21]
    28f4:      	mov	x0, x21
    28f8:      	blr	x9
    28fc:      	cbnz	x0, 0x2cfc <generic_tracepoint_event+0x2cfc>
    2900:      	str	w22, [sp, #0x20]
    2904:      	mov	x3, xzr
    2908:      	mov	w8, #0x2                // =2
    290c:      	add	x9, sp, #0x38
    2910:      	add	x10, sp, #0x20
    2914:      	b	0x2e2c <generic_tracepoint_event+0x2e2c>
    2918:      	mov	w8, #0x4                // =4
    291c:      	add	x9, sp, #0x88
    2920:      	add	x0, sp, #0x88
    2924:      	mov	w1, #0x4                // =4
    2928:      	blr	x8
    292c:      	cbz	x0, 0x2d34 <generic_tracepoint_event+0x2d34>
    2930:      	neg	w8, w0
    2934:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2938:      	mov	w9, #0x1                // =1
    293c:      	strh	w8, [sp, #0x38]
    2940:      	mov	w8, #0x7                // =7
    2944:      	add	x1, sp, #0x38
    2948:      	mov	w22, #0x1               // =1
    294c:      	strh	w8, [sp, #0x3a]
    2950:      	mov	x8, #0x56               // =86
    2954:      	movk	x8, #0x4, lsl #32
    2958:      	stur	x8, [sp, #0x3c]
    295c:      	add	x8, sp, #0x38
    2960:      	ldr	x21, [x21]
    2964:      	mov	x0, x21
    2968:      	blr	x9
    296c:      	cbz	x0, 0x2d10 <generic_tracepoint_event+0x2d10>
    2970:      	ldr	w8, [x0]
    2974:      	add	w8, w8, #0x1
    2978:      	str	w8, [x0]
    297c:      	ldrsw	x22, [sp, #0x88]
    2980:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2984:      	str	w22, [sp, #0x88]
    2988:      	mov	x3, xzr
    298c:      	mov	w8, #0x2                // =2
    2990:      	add	x9, sp, #0x38
    2994:      	add	x10, sp, #0x88
    2998:      	add	x1, sp, #0x38
    299c:      	add	x2, sp, #0x88
    29a0:      	mov	x0, x21
    29a4:      	blr	x8
    29a8:      	ldr	x22, [sp, #0x20]
    29ac:      	cmp	w24, #0x1c
    29b0:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    29b4:      	mov	w8, #0x23               // =35
    29b8:      	blr	x8
    29bc:      	mov	w8, #0x8                // =8
    29c0:      	mov	w9, #0x4                // =4
    29c4:      	add	x10, sp, #0x38
    29c8:      	mov	x2, x0
    29cc:      	add	x0, sp, #0x38
    29d0:      	mov	w1, #0x8                // =8
    29d4:      	blr	x9
    29d8:      	ldr	w8, [sp, #0x38]
    29dc:      	lsl	w8, w8, #9
    29e0:      	and	x8, x8, #0x80000000
    29e4:      	orr	x22, x8, x22
    29e8:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    29ec:      	cmp	w24, #0x7
    29f0:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    29f4:      	mov	w8, #0x8                // =8
    29f8:      	mov	w9, #0x4                // =4
    29fc:      	add	x10, sp, #0x20
    2a00:      	add	x0, sp, #0x20
    2a04:      	mov	w1, #0x8                // =8
    2a08:      	blr	x9
    2a0c:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    2a10:      	neg	w8, w0
    2a14:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2a18:      	mov	w9, #0x1                // =1
    2a1c:      	strh	w8, [sp, #0x38]
    2a20:      	mov	w8, #0x7                // =7
    2a24:      	add	x1, sp, #0x38
    2a28:      	mov	w22, #0x1               // =1
    2a2c:      	strh	w8, [sp, #0x3a]
    2a30:      	mov	x8, #0x9a               // =154
    2a34:      	movk	x8, #0x4, lsl #32
    2a38:      	stur	x8, [sp, #0x3c]
    2a3c:      	add	x8, sp, #0x38
    2a40:      	ldr	x21, [x21]
    2a44:      	mov	x0, x21
    2a48:      	blr	x9
    2a4c:      	cbnz	x0, 0x2c24 <generic_tracepoint_event+0x2c24>
    2a50:      	str	w22, [sp, #0x88]
    2a54:      	mov	x3, xzr
    2a58:      	mov	w8, #0x2                // =2
    2a5c:      	add	x9, sp, #0x38
    2a60:      	add	x10, sp, #0x88
    2a64:      	b	0x2dd4 <generic_tracepoint_event+0x2dd4>
    2a68:      	mov	x22, x2
    2a6c:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2a70:      	mov	w8, #0x8                // =8
    2a74:      	mov	w9, #0x4                // =4
    2a78:      	add	x10, sp, #0x20
    2a7c:      	add	x0, sp, #0x20
    2a80:      	mov	w1, #0x8                // =8
    2a84:      	blr	x9
    2a88:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    2a8c:      	neg	w8, w0
    2a90:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2a94:      	mov	w9, #0x1                // =1
    2a98:      	strh	w8, [sp, #0x38]
    2a9c:      	mov	w8, #0x7                // =7
    2aa0:      	add	x1, sp, #0x38
    2aa4:      	mov	w22, #0x1               // =1
    2aa8:      	strh	w8, [sp, #0x3a]
    2aac:      	mov	x8, #0x93               // =147
    2ab0:      	movk	x8, #0x4, lsl #32
    2ab4:      	stur	x8, [sp, #0x3c]
    2ab8:      	add	x8, sp, #0x38
    2abc:      	ldr	x21, [x21]
    2ac0:      	mov	x0, x21
    2ac4:      	blr	x9
    2ac8:      	cbnz	x0, 0x2c24 <generic_tracepoint_event+0x2c24>
    2acc:      	str	w22, [sp, #0x88]
    2ad0:      	mov	x3, xzr
    2ad4:      	mov	w8, #0x2                // =2
    2ad8:      	add	x9, sp, #0x38
    2adc:      	add	x10, sp, #0x88
    2ae0:      	b	0x2dd4 <generic_tracepoint_event+0x2dd4>
    2ae4:      	mov	w8, #0x1                // =1
    2ae8:      	mov	w9, #0x4                // =4
    2aec:      	add	x10, sp, #0x88
    2af0:      	add	x0, sp, #0x88
    2af4:      	mov	w1, #0x1                // =1
    2af8:      	blr	x9
    2afc:      	cbz	x0, 0x2d8c <generic_tracepoint_event+0x2d8c>
    2b00:      	neg	w8, w0
    2b04:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2b08:      	mov	w9, #0x1                // =1
    2b0c:      	strh	w8, [sp, #0x38]
    2b10:      	mov	w8, #0x7                // =7
    2b14:      	add	x1, sp, #0x38
    2b18:      	mov	w22, #0x1               // =1
    2b1c:      	strh	w8, [sp, #0x3a]
    2b20:      	mov	x8, #0x7a               // =122
    2b24:      	movk	x8, #0x4, lsl #32
    2b28:      	stur	x8, [sp, #0x3c]
    2b2c:      	add	x8, sp, #0x38
    2b30:      	ldr	x21, [x21]
    2b34:      	mov	x0, x21
    2b38:      	blr	x9
    2b3c:      	cbz	x0, 0x2d68 <generic_tracepoint_event+0x2d68>
    2b40:      	ldr	w8, [x0]
    2b44:      	add	w8, w8, #0x1
    2b48:      	str	w8, [x0]
    2b4c:      	ldrsb	x22, [sp, #0x88]
    2b50:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2b54:      	mov	w8, #0x8                // =8
    2b58:      	mov	w9, #0x4                // =4
    2b5c:      	add	x10, sp, #0x20
    2b60:      	add	x0, sp, #0x20
    2b64:      	mov	w1, #0x8                // =8
    2b68:      	blr	x9
    2b6c:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    2b70:      	neg	w8, w0
    2b74:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2b78:      	mov	w9, #0x1                // =1
    2b7c:      	strh	w8, [sp, #0x38]
    2b80:      	mov	w8, #0x7                // =7
    2b84:      	add	x1, sp, #0x38
    2b88:      	mov	w22, #0x1               // =1
    2b8c:      	strh	w8, [sp, #0x3a]
    2b90:      	mov	x8, #0xa1               // =161
    2b94:      	movk	x8, #0x4, lsl #32
    2b98:      	stur	x8, [sp, #0x3c]
    2b9c:      	add	x8, sp, #0x38
    2ba0:      	ldr	x21, [x21]
    2ba4:      	mov	x0, x21
    2ba8:      	blr	x9
    2bac:      	cbnz	x0, 0x2c24 <generic_tracepoint_event+0x2c24>
    2bb0:      	str	w22, [sp, #0x88]
    2bb4:      	mov	x3, xzr
    2bb8:      	mov	w8, #0x2                // =2
    2bbc:      	add	x9, sp, #0x38
    2bc0:      	add	x10, sp, #0x88
    2bc4:      	b	0x2dd4 <generic_tracepoint_event+0x2dd4>
    2bc8:      	mov	w8, #0x8                // =8
    2bcc:      	mov	w9, #0x4                // =4
    2bd0:      	add	x10, sp, #0x20
    2bd4:      	add	x0, sp, #0x20
    2bd8:      	mov	w1, #0x8                // =8
    2bdc:      	blr	x9
    2be0:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    2be4:      	neg	w8, w0
    2be8:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2bec:      	mov	w9, #0x1                // =1
    2bf0:      	strh	w8, [sp, #0x38]
    2bf4:      	mov	w8, #0x7                // =7
    2bf8:      	add	x1, sp, #0x38
    2bfc:      	mov	w22, #0x1               // =1
    2c00:      	strh	w8, [sp, #0x3a]
    2c04:      	mov	x8, #0x4e               // =78
    2c08:      	movk	x8, #0x4, lsl #32
    2c0c:      	stur	x8, [sp, #0x3c]
    2c10:      	add	x8, sp, #0x38
    2c14:      	ldr	x21, [x21]
    2c18:      	mov	x0, x21
    2c1c:      	blr	x9
    2c20:      	cbz	x0, 0x2dc0 <generic_tracepoint_event+0x2dc0>
    2c24:      	ldr	w8, [x0]
    2c28:      	add	w8, w8, #0x1
    2c2c:      	str	w8, [x0]
    2c30:      	b	0x2de4 <generic_tracepoint_event+0x2de4>
    2c34:      	mov	w8, #0x2                // =2
    2c38:      	mov	w9, #0x4                // =4
    2c3c:      	add	x10, sp, #0x88
    2c40:      	add	x0, sp, #0x88
    2c44:      	mov	w1, #0x2                // =2
    2c48:      	blr	x9
    2c4c:      	cbz	x0, 0x2e10 <generic_tracepoint_event+0x2e10>
    2c50:      	neg	w8, w0
    2c54:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2c58:      	mov	w9, #0x1                // =1
    2c5c:      	strh	w8, [sp, #0x38]
    2c60:      	mov	w8, #0x7                // =7
    2c64:      	add	x1, sp, #0x38
    2c68:      	mov	w22, #0x1               // =1
    2c6c:      	strh	w8, [sp, #0x3a]
    2c70:      	mov	x8, #0x65               // =101
    2c74:      	movk	x8, #0x4, lsl #32
    2c78:      	stur	x8, [sp, #0x3c]
    2c7c:      	add	x8, sp, #0x38
    2c80:      	ldr	x21, [x21]
    2c84:      	mov	x0, x21
    2c88:      	blr	x9
    2c8c:      	cbz	x0, 0x2dec <generic_tracepoint_event+0x2dec>
    2c90:      	ldr	w8, [x0]
    2c94:      	add	w8, w8, #0x1
    2c98:      	str	w8, [x0]
    2c9c:      	ldrh	w22, [sp, #0x88]
    2ca0:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2ca4:      	mov	w8, #0x4                // =4
    2ca8:      	add	x9, sp, #0x88
    2cac:      	add	x0, sp, #0x88
    2cb0:      	mov	w1, #0x4                // =4
    2cb4:      	blr	x8
    2cb8:      	cbz	x0, 0x2e3c <generic_tracepoint_event+0x2e3c>
    2cbc:      	neg	w8, w0
    2cc0:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2cc4:      	mov	w9, #0x1                // =1
    2cc8:      	strh	w8, [sp, #0x38]
    2ccc:      	mov	w8, #0x7                // =7
    2cd0:      	add	x1, sp, #0x38
    2cd4:      	mov	w22, #0x1               // =1
    2cd8:      	strh	w8, [sp, #0x3a]
    2cdc:      	mov	x8, #0x88               // =136
    2ce0:      	movk	x8, #0x4, lsl #32
    2ce4:      	stur	x8, [sp, #0x3c]
    2ce8:      	add	x8, sp, #0x38
    2cec:      	ldr	x21, [x21]
    2cf0:      	mov	x0, x21
    2cf4:      	blr	x9
    2cf8:      	cbz	x0, 0x2e18 <generic_tracepoint_event+0x2e18>
    2cfc:      	ldr	w8, [x0]
    2d00:      	add	w8, w8, #0x1
    2d04:      	str	w8, [x0]
    2d08:      	ldr	w22, [sp, #0x88]
    2d0c:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2d10:      	str	w22, [sp, #0x20]
    2d14:      	mov	x3, xzr
    2d18:      	mov	w8, #0x2                // =2
    2d1c:      	add	x9, sp, #0x38
    2d20:      	add	x10, sp, #0x20
    2d24:      	add	x1, sp, #0x38
    2d28:      	add	x2, sp, #0x20
    2d2c:      	mov	x0, x21
    2d30:      	blr	x8
    2d34:      	ldrsw	x22, [sp, #0x88]
    2d38:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2d3c:      	str	w22, [sp, #0x20]
    2d40:      	mov	x3, xzr
    2d44:      	mov	w8, #0x2                // =2
    2d48:      	add	x9, sp, #0x38
    2d4c:      	add	x10, sp, #0x20
    2d50:      	add	x1, sp, #0x38
    2d54:      	add	x2, sp, #0x20
    2d58:      	mov	x0, x21
    2d5c:      	blr	x8
    2d60:      	ldrsh	x22, [sp, #0x88]
    2d64:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2d68:      	str	w22, [sp, #0x20]
    2d6c:      	mov	x3, xzr
    2d70:      	mov	w8, #0x2                // =2
    2d74:      	add	x9, sp, #0x38
    2d78:      	add	x10, sp, #0x20
    2d7c:      	add	x1, sp, #0x38
    2d80:      	add	x2, sp, #0x20
    2d84:      	mov	x0, x21
    2d88:      	blr	x8
    2d8c:      	ldrsb	x22, [sp, #0x88]
    2d90:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2d94:      	str	w22, [sp, #0x20]
    2d98:      	mov	x3, xzr
    2d9c:      	mov	w8, #0x2                // =2
    2da0:      	add	x9, sp, #0x38
    2da4:      	add	x10, sp, #0x20
    2da8:      	add	x1, sp, #0x38
    2dac:      	add	x2, sp, #0x20
    2db0:      	mov	x0, x21
    2db4:      	blr	x8
    2db8:      	ldrb	w22, [sp, #0x88]
    2dbc:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2dc0:      	str	w22, [sp, #0x88]
    2dc4:      	mov	x3, xzr
    2dc8:      	mov	w8, #0x2                // =2
    2dcc:      	add	x9, sp, #0x38
    2dd0:      	add	x10, sp, #0x88
    2dd4:      	add	x1, sp, #0x38
    2dd8:      	add	x2, sp, #0x88
    2ddc:      	mov	x0, x21
    2de0:      	blr	x8
    2de4:      	ldr	x22, [sp, #0x20]
    2de8:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2dec:      	str	w22, [sp, #0x20]
    2df0:      	mov	x3, xzr
    2df4:      	mov	w8, #0x2                // =2
    2df8:      	add	x9, sp, #0x38
    2dfc:      	add	x10, sp, #0x20
    2e00:      	add	x1, sp, #0x38
    2e04:      	add	x2, sp, #0x20
    2e08:      	mov	x0, x21
    2e0c:      	blr	x8
    2e10:      	ldrh	w22, [sp, #0x88]
    2e14:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2e18:      	str	w22, [sp, #0x20]
    2e1c:      	mov	x3, xzr
    2e20:      	mov	w8, #0x2                // =2
    2e24:      	add	x9, sp, #0x38
    2e28:      	add	x10, sp, #0x20
    2e2c:      	add	x1, sp, #0x38
    2e30:      	add	x2, sp, #0x20
    2e34:      	mov	x0, x21
    2e38:      	blr	x8
    2e3c:      	ldr	w22, [sp, #0x88]
    2e40:      	mov	w21, #0xe               // =14
    2e44:      	str	x22, [x20, #0x5e70]
    2e48:      	strh	wzr, [x20, #0x2]
    2e4c:      	mov	w8, #0x7d               // =125
    2e50:      	str	wzr, [x20, #0x4]
    2e54:      	strb	w21, [x20]
    2e58:      	blr	x8
    2e5c:      	str	x0, [x20, #0x8]
    2e60:      	str	xzr, [x20, #0x70]
    2e64:      	mov	w8, #0xe                // =14
    2e68:      	str	wzr, [x20, #0x14]
    2e6c:      	blr	x8
    2e70:      	mov	w8, #0x5eb8             // =24248
    2e74:      	add	x9, x23, #0xefc
    2e78:      	str	w0, [x20, #0x7c]
    2e7c:      	strb	w21, [x20]
    2e80:      	add	x8, x20, x8
    2e84:      	str	xzr, [x9]
    2e88:      	str	xzr, [x20, #0x5eb8]
    2e8c:      	mov	w9, #0x23               // =35
    2e90:      	str	xzr, [x20, #0x5ec0]
    2e94:      	str	xzr, [x20, #0x5ec8]
    2e98:      	str	xzr, [x20, #0x5ed0]
    2e9c:      	str	xzr, [x20, #0x5ed8]
    2ea0:      	strb	wzr, [x8, #0x28]
    2ea4:      	blr	x9
    2ea8:      	add	x2, x0, #0xb50
    2eac:      	mov	w24, #0x8               // =8
    2eb0:      	add	x8, sp, #0x88
    2eb4:      	mov	w9, #0x4                // =4
    2eb8:      	mov	x21, x0
    2ebc:      	add	x0, sp, #0x88
    2ec0:      	mov	w1, #0x8                // =8
    2ec4:      	add	x22, x20, #0x20
    2ec8:      	mov	w23, #0x4               // =4
    2ecc:      	blr	x9
    2ed0:      	ldr	x8, [sp, #0x88]
    2ed4:      	mov	w9, #0x48               // =72
    2ed8:      	add	x10, sp, #0x38
    2edc:      	mov	w11, #0x4               // =4
    2ee0:      	ldr	x2, [sp, #0x88]
    2ee4:      	add	x0, sp, #0x38
    2ee8:      	mov	w1, #0x48               // =72
    2eec:      	blr	x11
    2ef0:      	ldr	x8, [sp, #0x40]
    2ef4:      	mov	w9, #0x4                // =4
    2ef8:      	mov	x0, x22
    2efc:      	mov	w1, #0x4                // =4
    2f00:      	add	x8, x8, #0x218
    2f04:      	ldr	x8, [sp, #0x40]
    2f08:      	add	x2, x8, #0x218
    2f0c:      	blr	x9
    2f10:      	ldr	x8, [sp, #0x48]
    2f14:      	add	x0, x20, #0x24
    2f18:      	mov	w9, #0x4                // =4
    2f1c:      	mov	w1, #0x4                // =4
    2f20:      	add	x8, x8, #0x4d8
    2f24:      	ldr	x8, [sp, #0x48]
    2f28:      	add	x2, x8, #0x4d8
    2f2c:      	blr	x9
    2f30:      	ldr	x8, [sp, #0x50]
    2f34:      	add	x0, x20, #0x28
    2f38:      	mov	w9, #0x4                // =4
    2f3c:      	mov	w1, #0x4                // =4
    2f40:      	add	x8, x8, #0x58
    2f44:      	ldr	x8, [sp, #0x50]
    2f48:      	add	x2, x8, #0x58
    2f4c:      	blr	x9
    2f50:      	str	xzr, [sp, #0x30]
    2f54:      	add	x2, x21, #0x938
    2f58:      	add	x8, sp, #0x30
    2f5c:      	add	x0, sp, #0x30
    2f60:      	mov	w1, #0x8                // =8
    2f64:      	blr	x23
    2f68:      	ldr	x8, [sp, #0x30]
    2f6c:      	cbz	x8, 0x2ff0 <generic_tracepoint_event+0x2ff0>
    2f70:      	str	wzr, [sp, #0x10]
    2f74:      	add	x8, x8, #0x4
    2f78:      	add	x9, sp, #0x10
    2f7c:      	mov	w10, #0x4               // =4
    2f80:      	add	x0, sp, #0x10
    2f84:      	mov	w1, #0x4                // =4
    2f88:      	mov	w22, #0x4               // =4
    2f8c:      	ldr	x8, [sp, #0x30]
    2f90:      	add	x2, x8, #0x4
    2f94:      	blr	x10
    2f98:      	ldr	x8, [sp, #0x30]
    2f9c:      	ldrsw	x9, [sp, #0x10]
    2fa0:      	add	x10, sp, #0x20
    2fa4:      	mov	w11, #0x4               // =4
    2fa8:      	add	x0, sp, #0x20
    2fac:      	mov	w1, #0x10               // =16
    2fb0:      	add	x8, x8, x9, lsl #4
    2fb4:      	mov	w9, #0x10               // =16
    2fb8:      	add	x8, x8, #0x80
    2fbc:      	ldr	x8, [sp, #0x30]
    2fc0:      	ldrsw	x9, [sp, #0x10]
    2fc4:      	add	x8, x8, x9, lsl #4
    2fc8:      	add	x2, x8, #0x80
    2fcc:      	blr	x11
    2fd0:      	ldr	x8, [sp, #0x28]
    2fd4:      	add	x0, x20, #0x2c
    2fd8:      	mov	w1, #0x4                // =4
    2fdc:      	add	x8, x8, #0x158
    2fe0:      	ldr	x8, [sp, #0x28]
    2fe4:      	add	x2, x8, #0x158
    2fe8:      	blr	x22
    2fec:      	b	0x2ff4 <generic_tracepoint_event+0x2ff4>
    2ff0:      	str	wzr, [x20, #0x2c]
    2ff4:      	ldr	x8, [sp, #0x58]
    2ff8:      	add	x0, x20, #0x30
    2ffc:      	mov	w9, #0x4                // =4
    3000:      	mov	w1, #0x4                // =4
    3004:      	mov	w23, #0x4               // =4
    3008:      	add	x8, x8, #0x158
    300c:      	ldr	x8, [sp, #0x58]
    3010:      	add	x2, x8, #0x158
    3014:      	blr	x9
    3018:      	ldr	x8, [sp, #0x60]
    301c:      	add	x0, x20, #0x34
    3020:      	mov	w9, #0x4                // =4
    3024:      	mov	w1, #0x4                // =4
    3028:      	add	x8, x8, #0x118
    302c:      	ldr	x8, [sp, #0x60]
    3030:      	add	x2, x8, #0x118
    3034:      	blr	x9
    3038:      	ldr	x8, [sp, #0x68]
    303c:      	add	x0, x20, #0x38
    3040:      	mov	w9, #0x4                // =4
    3044:      	mov	w1, #0x4                // =4
    3048:      	add	x8, x8, #0x98
    304c:      	ldr	x8, [sp, #0x68]
    3050:      	add	x2, x8, #0x98
    3054:      	blr	x9
    3058:      	ldr	x8, [sp, #0x70]
    305c:      	add	x0, x20, #0x3c
    3060:      	mov	w9, #0x4                // =4
    3064:      	mov	w1, #0x4                // =4
    3068:      	add	x8, x8, #0x98
    306c:      	ldr	x8, [sp, #0x70]
    3070:      	add	x2, x8, #0x98
    3074:      	blr	x9
    3078:      	ldr	x8, [sp, #0x78]
    307c:      	add	x0, x20, #0x40
    3080:      	mov	w9, #0x4                // =4
    3084:      	mov	w1, #0x4                // =4
    3088:      	add	x8, x8, #0x58
    308c:      	ldr	x8, [sp, #0x78]
    3090:      	add	x2, x8, #0x58
    3094:      	blr	x9
    3098:      	str	xzr, [sp, #0x20]
    309c:      	str	xzr, [sp, #0x30]
    30a0:      	add	x21, x21, #0xae0
    30a4:      	mov	w24, #0x8               // =8
    30a8:      	add	x8, sp, #0x20
    30ac:      	mov	w9, #0x4                // =4
    30b0:      	add	x0, sp, #0x20
    30b4:      	mov	w1, #0x8                // =8
    30b8:      	mov	x2, x21
    30bc:      	blr	x9
    30c0:      	ldr	x8, [sp, #0x20]
    30c4:      	add	x9, sp, #0x30
    30c8:      	mov	w10, #0x4               // =4
    30cc:      	add	x0, sp, #0x30
    30d0:      	mov	w1, #0x8                // =8
    30d4:      	add	x8, x8, #0x90
    30d8:      	ldr	x8, [sp, #0x20]
    30dc:      	add	x2, x8, #0x90
    30e0:      	blr	x10
    30e4:      	ldr	x8, [sp, #0x30]
    30e8:      	add	x0, x20, #0x44
    30ec:      	mov	w9, #0x4                // =4
    30f0:      	mov	w1, #0x4                // =4
    30f4:      	add	x8, x8, #0x158
    30f8:      	ldr	x8, [sp, #0x30]
    30fc:      	add	x2, x8, #0x158
    3100:      	blr	x9
    3104:      	add	x8, sp, #0x38
    3108:      	mov	w9, #0x4                // =4
    310c:      	add	x0, sp, #0x38
    3110:      	mov	w1, #0x8                // =8
    3114:      	mov	x2, x21
    3118:      	add	x22, x20, #0x48
    311c:      	blr	x9
    3120:      	ldr	x21, [sp, #0x38]
    3124:      	add	x0, x20, #0x50
    3128:      	mov	w8, #0x4                // =4
    312c:      	mov	w1, #0x8                // =8
    3130:      	add	x2, x21, #0x40
    3134:      	blr	x8
    3138:      	add	x0, x20, #0x58
    313c:      	add	x2, x21, #0x30
    3140:      	mov	w8, #0x4                // =4
    3144:      	mov	w1, #0x8                // =8
    3148:      	blr	x8
    314c:      	add	x2, x21, #0x38
    3150:      	mov	x0, x22
    3154:      	mov	w1, #0x8                // =8
    3158:      	blr	x23
    315c:      	strb	wzr, [x20, #0x1]
    3160:      	str	xzr, [x20, #0x5ee8]
    3164:      	adrp	x1, 0x3000 <generic_tracepoint_event+0x3000>
    3168:      	mov	w8, #0x2                // =2
    316c:      	mov	w9, #0xc                // =12
    3170:      	mov	x0, x19
    3174:      	str	xzr, [x20, #0x5ef0]
    3178:      	ldr	x1, [x1]
    317c:      	mov	w2, #0x2                // =2
    3180:      	blr	x9
    3184:      	ldp	x20, x19, [sp, #0xc0]
    3188:      	mov	w0, wzr
    318c:      	ldp	x22, x21, [sp, #0xb0]
    3190:      	ldp	x24, x23, [sp, #0xa0]
    3194:      	ldp	x30, x25, [sp, #0x90]
    3198:      	add	sp, sp, #0xd0
    319c:      	ret
