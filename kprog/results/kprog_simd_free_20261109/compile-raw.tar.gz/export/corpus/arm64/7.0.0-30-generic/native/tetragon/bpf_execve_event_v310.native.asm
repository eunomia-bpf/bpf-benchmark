
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_execve_event_v310.native.o:	file format elf64-littleaarch64

Disassembly of section tracepoint:

0000000000000000 <execve_rate>:
       0:      	sub	sp, sp, #0x80
       4:      	str	x30, [sp, #0x40]
       8:      	stp	x24, x23, [sp, #0x50]
       c:      	stp	x22, x21, [sp, #0x60]
      10:      	stp	x20, x19, [sp, #0x70]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0x4]
      1c:      	adrp	x0, 0x0 <execve_rate>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0x4
      2c:      	add	x1, sp, #0x4
      30:      	blr	x8
      34:      	cbz	x0, 0x284 <execve_rate+0x284>
      38:      	ldr	x23, [x0, #0x8]
      3c:      	ldr	x8, [x0, #0x10]!
      40:      	add	x9, sp, #0x34
      44:      	add	x1, sp, #0x34
      48:      	mov	x20, x0
      4c:      	str	wzr, [sp, #0x34]
      50:      	adrp	x0, 0x0 <execve_rate>
      54:      	str	x8, [sp, #0x38]
      58:      	mov	w8, #0x1                // =1
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	cbz	x0, 0x268 <execve_rate+0x268>
      68:      	ldr	x22, [x0, #0x8]
      6c:      	cbz	x22, 0x268 <execve_rate+0x268>
      70:      	adrp	x21, 0x0 <execve_rate>
      74:      	mov	w8, #0x1                // =1
      78:      	add	x9, sp, #0x38
      7c:      	ldr	x21, [x21]
      80:      	mov	x24, x0
      84:      	add	x1, sp, #0x38
      88:      	mov	x0, x21
      8c:      	blr	x8
      90:      	cbz	x0, 0xbc <execve_rate+0xbc>
      94:      	ldr	x8, [x0, #0x10]
      98:      	sub	x9, x23, x8
      9c:      	cmp	x9, x22
      a0:      	b.ls	0xf8 <execve_rate+0xf8>
      a4:      	cmp	x9, x22, lsl #1
      a8:      	b.ls	0x104 <execve_rate+0x104>
      ac:      	udiv	x8, x23, x22
      b0:      	mov	x9, xzr
      b4:      	mul	x8, x8, x22
      b8:      	b	0x10c <execve_rate+0x10c>
      bc:      	mov	w8, #0x1                // =1
      c0:      	str	xzr, [sp, #0x28]
      c4:      	mov	x3, xzr
      c8:      	add	x9, sp, #0x38
      cc:      	stp	x8, xzr, [sp, #0x8]
      d0:      	udiv	x8, x23, x22
      d4:      	add	x10, sp, #0x8
      d8:      	add	x1, sp, #0x38
      dc:      	add	x2, sp, #0x8
      e0:      	mov	x0, x21
      e4:      	mul	x8, x8, x22
      e8:      	stp	x8, xzr, [sp, #0x18]
      ec:      	mov	w8, #0x2                // =2
      f0:      	blr	x8
      f4:      	b	0x268 <execve_rate+0x268>
      f8:      	ldp	x10, x9, [x0]
      fc:      	add	x10, x10, #0x1
     100:      	b	0x114 <execve_rate+0x114>
     104:      	ldr	x9, [x0]
     108:      	add	x8, x8, x22
     10c:      	mov	w10, #0x1               // =1
     110:      	stp	x9, x8, [x0, #0x8]
     114:      	sub	x11, x22, x23
     118:      	str	x10, [x0]
     11c:      	add	x8, x11, x8
     120:      	mul	x8, x8, x9
     124:      	ldr	x9, [x0, #0x20]
     128:      	udiv	x8, x8, x22
     12c:      	add	x8, x8, x10
     130:      	str	x8, [x0, #0x18]
     134:      	cbnz	x9, 0x284 <execve_rate+0x284>
     138:      	ldr	x9, [x24]
     13c:      	cmp	x8, x9
     140:      	b.lo	0x268 <execve_rate+0x268>
     144:      	mov	x22, x0
     148:      	str	x23, [x0, #0x20]
     14c:      	str	wzr, [sp, #0x4c]
     150:      	adrp	x0, 0x0 <execve_rate>
     154:      	mov	w8, #0x1                // =1
     158:      	add	x9, sp, #0x4c
     15c:      	ldr	x0, [x0]
     160:      	add	x1, sp, #0x48
     164:      	str	wzr, [sp, #0x48]
     168:      	blr	x8
     16c:      	cbz	x0, 0x260 <execve_rate+0x260>
     170:      	mov	w24, #0xa0              // =160
     174:      	mov	w8, #0x1b               // =27
     178:      	str	x23, [x0, #0x8]
     17c:      	mov	x21, x0
     180:      	str	w24, [x0, #0x4]
     184:      	mov	x1, x20
     188:      	strh	w8, [x0], #0x10
     18c:      	mov	w2, #0x90               // =144
     190:      	bl	0x190 <execve_rate+0x190>
     194:      	adrp	x1, 0x0 <execve_rate>
     198:      	mov	w8, #-0x1               // =-1
     19c:      	mov	w9, #0x19               // =25
     1a0:      	ldr	x1, [x1]
     1a4:      	mov	x0, x19
     1a8:      	mov	w2, #-0x1               // =-1
     1ac:      	mov	x3, x21
     1b0:      	mov	w4, #0xa0               // =160
     1b4:      	blr	x9
     1b8:      	tbz	x0, #0x3f, 0x260 <execve_rate+0x260>
     1bc:      	mov	x20, x0
     1c0:      	str	wzr, [sp, #0x8]
     1c4:      	adrp	x0, 0x0 <execve_rate>
     1c8:      	mov	w8, #0x1                // =1
     1cc:      	ldr	x0, [x0]
     1d0:      	add	x9, sp, #0x8
     1d4:      	add	x1, sp, #0x8
     1d8:      	blr	x8
     1dc:      	cbz	x0, 0x260 <execve_rate+0x260>
     1e0:      	mov	x8, x20
     1e4:      	cmn	x20, #0xc
     1e8:      	b.gt	0x20c <execve_rate+0x20c>
     1ec:      	cmn	x8, #0x1c
     1f0:      	b.eq	0x22c <execve_rate+0x22c>
     1f4:      	cmn	x8, #0x16
     1f8:      	b.eq	0x244 <execve_rate+0x244>
     1fc:      	cmn	x8, #0x10
     200:      	b.ne	0x23c <execve_rate+0x23c>
     204:      	add	x8, x0, #0x600
     208:      	b	0x250 <execve_rate+0x250>
     20c:      	cmn	x8, #0xb
     210:      	b.eq	0x234 <execve_rate+0x234>
     214:      	cmn	x8, #0x7
     218:      	b.eq	0x24c <execve_rate+0x24c>
     21c:      	cmn	x8, #0x2
     220:      	b.ne	0x23c <execve_rate+0x23c>
     224:      	add	x8, x0, #0x5f0
     228:      	b	0x250 <execve_rate+0x250>
     22c:      	add	x8, x0, #0x610
     230:      	b	0x250 <execve_rate+0x250>
     234:      	add	x8, x0, #0x618
     238:      	b	0x250 <execve_rate+0x250>
     23c:      	add	x8, x0, #0x5e8
     240:      	b	0x250 <execve_rate+0x250>
     244:      	add	x8, x0, #0x608
     248:      	b	0x250 <execve_rate+0x250>
     24c:      	add	x8, x0, #0x5f8
     250:      	ldaxr	x9, [x8]
     254:      	add	x9, x9, #0x1
     258:      	stlxr	w10, x9, [x8]
     25c:      	cbnz	w10, 0x250 <execve_rate+0x250>
     260:      	ldr	x8, [x22, #0x20]
     264:      	cbnz	x8, 0x284 <execve_rate+0x284>
     268:      	adrp	x1, 0x0 <execve_rate>
     26c:      	mov	w8, #0x1                // =1
     270:      	mov	w9, #0xc                // =12
     274:      	ldr	x1, [x1]
     278:      	mov	x0, x19
     27c:      	mov	w2, #0x1                // =1
     280:      	blr	x9
     284:      	ldp	x20, x19, [sp, #0x70]
     288:      	mov	w0, wzr
     28c:      	ldr	x30, [sp, #0x40]
     290:      	ldp	x22, x21, [sp, #0x60]
     294:      	ldp	x24, x23, [sp, #0x50]
     298:      	add	sp, sp, #0x80
     29c:      	ret

00000000000002a0 <execve_send>:
     2a0:      	sub	sp, sp, #0x50
     2a4:      	stp	x30, x23, [sp, #0x20]
     2a8:      	stp	x22, x21, [sp, #0x30]
     2ac:      	stp	x20, x19, [sp, #0x40]
     2b0:      	mov	x19, x0
     2b4:      	str	wzr, [sp, #0x8]
     2b8:      	adrp	x0, 0x0 <execve_rate>
     2bc:      	mov	w8, #0x1                // =1
     2c0:      	ldr	x0, [x0]
     2c4:      	add	x9, sp, #0x8
     2c8:      	add	x1, sp, #0x8
     2cc:      	blr	x8
     2d0:      	cbz	x0, 0x6bc <execve_send+0x41c>
     2d4:      	mov	w8, #0xe                // =14
     2d8:      	mov	x20, x0
     2dc:      	blr	x8
     2e0:      	lsr	x8, x0, #32
     2e4:      	adrp	x22, 0x0 <execve_rate>
     2e8:      	add	x9, sp, #0x10
     2ec:      	str	w8, [sp, #0x10]
     2f0:      	mov	w8, #0x1                // =1
     2f4:      	add	x1, sp, #0x10
     2f8:      	ldr	x22, [x22]
     2fc:      	mov	x0, x22
     300:      	blr	x8
     304:      	cbz	x0, 0x5dc <execve_send+0x33c>
     308:      	ldp	x8, x9, [x0]
     30c:      	mov	x21, x0
     310:      	stp	x8, x9, [x20, #0x130]
     314:      	ldr	w8, [x20, #0x144]
     318:      	str	w8, [x0]
     31c:      	ldr	x8, [x20, #0x170]
     320:      	str	x8, [x0, #0x8]
     324:      	ldr	w8, [x20, #0x14c]
     328:      	str	w8, [x0, #0x24]
     32c:      	ldp	x9, x10, [x20, #0xa0]
     330:      	stp	x9, x10, [x0, #0x10]
     334:      	ldr	w9, [x0, #0x20]
     338:      	tbz	w9, #0x0, 0x348 <execve_send+0xa8>
     33c:      	ldr	w10, [x20, #0x15c]
     340:      	orr	w10, w10, #0x4000
     344:      	str	w10, [x20, #0x15c]
     348:      	and	w9, w9, #0xfffffffe
     34c:      	cmp	w8, #0x1
     350:      	orr	w10, w9, #0x2000000
     354:      	csel	w8, w10, w9, eq
     358:      	str	w8, [x21, #0x20]
     35c:      	tbz	w8, #0x19, 0x36c <execve_send+0xcc>
     360:      	ldr	w8, [x20, #0x15c]
     364:      	orr	w8, w8, #0x2000000
     368:      	str	w8, [x20, #0x15c]
     36c:      	add	x0, x21, #0x68
     370:      	mov	w1, wzr
     374:      	mov	w2, #0x308              // =776
     378:      	bl	0x378 <execve_send+0xd8>
     37c:      	ldrh	w8, [x19, #0x8]
     380:      	add	x23, x21, #0x70
     384:      	mov	w9, #0x2d               // =45
     388:      	mov	w1, #0x100              // =256
     38c:      	mov	x0, x23
     390:      	add	x2, x19, x8
     394:      	mov	w8, #0x100              // =256
     398:      	blr	x9
     39c:      	cmp	w0, #0x1
     3a0:      	cset	w8, gt
     3a4:      	sub	w8, w0, w8
     3a8:      	str	w8, [x21, #0x68]
     3ac:      	mov	w8, #0x23               // =35
     3b0:      	blr	x8
     3b4:      	str	x0, [sp, #0x10]
     3b8:      	add	x8, x0, #0x8e0
     3bc:      	mov	w9, #0x8                // =8
     3c0:      	mov	w10, #0x71              // =113
     3c4:      	add	x11, sp, #0x10
     3c8:      	add	x0, sp, #0x10
     3cc:      	mov	w1, #0x8                // =8
     3d0:      	ldr	x8, [sp, #0x10]
     3d4:      	add	x2, x8, #0x8e0
     3d8:      	blr	x10
     3dc:      	ldr	x8, [sp, #0x10]
     3e0:      	cbz	x8, 0x5b4 <execve_send+0x314>
     3e4:      	add	x8, x8, #0x8d4
     3e8:      	mov	w9, #0x4                // =4
     3ec:      	mov	w10, #0x71              // =113
     3f0:      	add	x11, sp, #0xc
     3f4:      	ldr	x8, [sp, #0x10]
     3f8:      	add	x0, sp, #0xc
     3fc:      	mov	w1, #0x4                // =4
     400:      	add	x2, x8, #0x8d4
     404:      	blr	x10
     408:      	ldr	w8, [sp, #0xc]
     40c:      	add	x9, sp, #0x1c
     410:      	add	x1, sp, #0x1c
     414:      	mov	x0, x22
     418:      	str	w8, [sp, #0x1c]
     41c:      	mov	w8, #0x1                // =1
     420:      	blr	x8
     424:      	cbz	x0, 0x430 <execve_send+0x190>
     428:      	ldr	x8, [x0, #0x8]
     42c:      	cbnz	x8, 0x5a4 <execve_send+0x304>
     430:      	ldr	x8, [sp, #0x10]
     434:      	mov	w9, #0x8                // =8
     438:      	mov	w10, #0x71              // =113
     43c:      	add	x11, sp, #0x10
     440:      	add	x0, sp, #0x10
     444:      	mov	w1, #0x8                // =8
     448:      	add	x8, x8, #0x8e0
     44c:      	ldr	x8, [sp, #0x10]
     450:      	add	x2, x8, #0x8e0
     454:      	blr	x10
     458:      	ldr	x8, [sp, #0x10]
     45c:      	cbz	x8, 0x5b4 <execve_send+0x314>
     460:      	add	x8, x8, #0x8d4
     464:      	mov	w9, #0x4                // =4
     468:      	mov	w10, #0x71              // =113
     46c:      	add	x11, sp, #0xc
     470:      	ldr	x8, [sp, #0x10]
     474:      	add	x0, sp, #0xc
     478:      	mov	w1, #0x4                // =4
     47c:      	add	x2, x8, #0x8d4
     480:      	blr	x10
     484:      	ldr	w8, [sp, #0xc]
     488:      	add	x9, sp, #0x1c
     48c:      	add	x1, sp, #0x1c
     490:      	mov	x0, x22
     494:      	str	w8, [sp, #0x1c]
     498:      	mov	w8, #0x1                // =1
     49c:      	blr	x8
     4a0:      	cbz	x0, 0x4ac <execve_send+0x20c>
     4a4:      	ldr	x8, [x0, #0x8]
     4a8:      	cbnz	x8, 0x5a4 <execve_send+0x304>
     4ac:      	ldr	x8, [sp, #0x10]
     4b0:      	mov	w9, #0x8                // =8
     4b4:      	mov	w10, #0x71              // =113
     4b8:      	add	x11, sp, #0x10
     4bc:      	add	x0, sp, #0x10
     4c0:      	mov	w1, #0x8                // =8
     4c4:      	add	x8, x8, #0x8e0
     4c8:      	ldr	x8, [sp, #0x10]
     4cc:      	add	x2, x8, #0x8e0
     4d0:      	blr	x10
     4d4:      	ldr	x8, [sp, #0x10]
     4d8:      	cbz	x8, 0x5b4 <execve_send+0x314>
     4dc:      	add	x8, x8, #0x8d4
     4e0:      	mov	w9, #0x4                // =4
     4e4:      	mov	w10, #0x71              // =113
     4e8:      	add	x11, sp, #0xc
     4ec:      	ldr	x8, [sp, #0x10]
     4f0:      	add	x0, sp, #0xc
     4f4:      	mov	w1, #0x4                // =4
     4f8:      	add	x2, x8, #0x8d4
     4fc:      	blr	x10
     500:      	ldr	w8, [sp, #0xc]
     504:      	add	x9, sp, #0x1c
     508:      	add	x1, sp, #0x1c
     50c:      	mov	x0, x22
     510:      	str	w8, [sp, #0x1c]
     514:      	mov	w8, #0x1                // =1
     518:      	blr	x8
     51c:      	cbz	x0, 0x528 <execve_send+0x288>
     520:      	ldr	x8, [x0, #0x8]
     524:      	cbnz	x8, 0x5a4 <execve_send+0x304>
     528:      	ldr	x8, [sp, #0x10]
     52c:      	mov	w9, #0x8                // =8
     530:      	mov	w10, #0x71              // =113
     534:      	add	x11, sp, #0x10
     538:      	add	x0, sp, #0x10
     53c:      	mov	w1, #0x8                // =8
     540:      	add	x8, x8, #0x8e0
     544:      	ldr	x8, [sp, #0x10]
     548:      	add	x2, x8, #0x8e0
     54c:      	blr	x10
     550:      	ldr	x8, [sp, #0x10]
     554:      	cbz	x8, 0x5b4 <execve_send+0x314>
     558:      	add	x8, x8, #0x8d4
     55c:      	mov	w9, #0x4                // =4
     560:      	mov	w10, #0x71              // =113
     564:      	add	x11, sp, #0xc
     568:      	ldr	x8, [sp, #0x10]
     56c:      	add	x0, sp, #0xc
     570:      	mov	w1, #0x4                // =4
     574:      	add	x2, x8, #0x8d4
     578:      	blr	x10
     57c:      	ldr	w8, [sp, #0xc]
     580:      	add	x9, sp, #0x1c
     584:      	add	x1, sp, #0x1c
     588:      	mov	x0, x22
     58c:      	str	w8, [sp, #0x1c]
     590:      	mov	w8, #0x1                // =1
     594:      	blr	x8
     598:      	cbz	x0, 0x5b4 <execve_send+0x314>
     59c:      	ldr	x8, [x0, #0x8]
     5a0:      	cbz	x8, 0x5b4 <execve_send+0x314>
     5a4:      	ldr	x8, [x0, #0x370]
     5a8:      	ldr	x9, [x21, #0x370]
     5ac:      	orr	x8, x9, x8
     5b0:      	str	x8, [x21, #0x370]
     5b4:      	adrp	x0, 0x0 <execve_rate>
     5b8:      	mov	w8, #0x1                // =1
     5bc:      	mov	x1, x23
     5c0:      	ldr	x0, [x0]
     5c4:      	blr	x8
     5c8:      	cbz	x0, 0x5dc <execve_send+0x33c>
     5cc:      	ldr	x8, [x0]
     5d0:      	ldr	x9, [x21, #0x370]
     5d4:      	orr	x8, x9, x8
     5d8:      	str	x8, [x21, #0x370]
     5dc:      	ldr	w8, [x20, #0x140]
     5e0:      	strb	wzr, [x20, #0x1]
     5e4:      	mov	w9, #0x1580             // =5504
     5e8:      	adrp	x1, 0x0 <execve_rate>
     5ec:      	mov	x0, x19
     5f0:      	mov	w2, #-0x1               // =-1
     5f4:      	mov	x3, x20
     5f8:      	ldr	x1, [x1]
     5fc:      	cmp	w8, w9
     600:      	csel	w8, w8, w9, lo
     604:      	mov	w9, #0x19               // =25
     608:      	add	w4, w8, #0x140
     60c:      	mov	w8, #-0x1               // =-1
     610:      	blr	x9
     614:      	tbz	x0, #0x3f, 0x6bc <execve_send+0x41c>
     618:      	mov	x19, x0
     61c:      	str	wzr, [sp, #0x10]
     620:      	adrp	x0, 0x0 <execve_rate>
     624:      	mov	w8, #0x1                // =1
     628:      	ldr	x0, [x0]
     62c:      	add	x9, sp, #0x10
     630:      	add	x1, sp, #0x10
     634:      	blr	x8
     638:      	cbz	x0, 0x6bc <execve_send+0x41c>
     63c:      	mov	x8, x19
     640:      	cmn	x19, #0xc
     644:      	b.gt	0x668 <execve_send+0x3c8>
     648:      	cmn	x8, #0x1c
     64c:      	b.eq	0x688 <execve_send+0x3e8>
     650:      	cmn	x8, #0x16
     654:      	b.eq	0x6a0 <execve_send+0x400>
     658:      	cmn	x8, #0x10
     65c:      	b.ne	0x698 <execve_send+0x3f8>
     660:      	add	x8, x0, #0x130
     664:      	b	0x6ac <execve_send+0x40c>
     668:      	cmn	x8, #0xb
     66c:      	b.eq	0x690 <execve_send+0x3f0>
     670:      	cmn	x8, #0x7
     674:      	b.eq	0x6a8 <execve_send+0x408>
     678:      	cmn	x8, #0x2
     67c:      	b.ne	0x698 <execve_send+0x3f8>
     680:      	add	x8, x0, #0x120
     684:      	b	0x6ac <execve_send+0x40c>
     688:      	add	x8, x0, #0x140
     68c:      	b	0x6ac <execve_send+0x40c>
     690:      	add	x8, x0, #0x148
     694:      	b	0x6ac <execve_send+0x40c>
     698:      	add	x8, x0, #0x118
     69c:      	b	0x6ac <execve_send+0x40c>
     6a0:      	add	x8, x0, #0x138
     6a4:      	b	0x6ac <execve_send+0x40c>
     6a8:      	add	x8, x0, #0x128
     6ac:      	ldaxr	x9, [x8]
     6b0:      	add	x9, x9, #0x1
     6b4:      	stlxr	w10, x9, [x8]
     6b8:      	cbnz	w10, 0x6ac <execve_send+0x40c>
     6bc:      	ldp	x20, x19, [sp, #0x40]
     6c0:      	mov	w0, wzr
     6c4:      	ldp	x22, x21, [sp, #0x30]
     6c8:      	ldp	x30, x23, [sp, #0x20]
     6cc:      	add	sp, sp, #0x50
     6d0:      	ret

Disassembly of section tracepoint/sys_execve:

0000000000000000 <event_execve>:
       0:      	sub	sp, sp, #0x120
       4:      	str	x29, [sp, #0xd0]
       8:      	stp	x30, x25, [sp, #0xe0]
       c:      	stp	x24, x23, [sp, #0xf0]
      10:      	stp	x22, x21, [sp, #0x100]
      14:      	stp	x20, x19, [sp, #0x110]
      18:      	mov	w8, #0x23               // =35
      1c:      	mov	x25, x0
      20:      	blr	x8
      24:      	mov	x29, x0
      28:      	str	wzr, [sp, #0x3c]
      2c:      	adrp	x0, 0x0 <event_execve>
      30:      	ldrh	w21, [x25, #0x8]
      34:      	mov	w8, #0x1                // =1
      38:      	add	x9, sp, #0x3c
      3c:      	ldr	x0, [x0]
      40:      	add	x1, sp, #0x3c
      44:      	blr	x8
      48:      	cbz	x0, 0x1f34 <event_execve+0x1f34>
      4c:      	mov	w8, #0xe                // =14
      50:      	mov	x20, x0
      54:      	blr	x8
      58:      	mov	w8, #0x23               // =35
      5c:      	mov	x22, x0
      60:      	blr	x8
      64:      	str	x0, [sp, #0x40]
      68:      	add	x8, x0, #0x8e0
      6c:      	mov	w9, #0x8                // =8
      70:      	mov	w10, #0x71              // =113
      74:      	add	x11, sp, #0x40
      78:      	add	x0, sp, #0x40
      7c:      	mov	w1, #0x8                // =8
      80:      	ldr	x8, [sp, #0x40]
      84:      	add	x2, x8, #0x8e0
      88:      	blr	x10
      8c:      	ldr	x8, [sp, #0x40]
      90:      	cbz	x8, 0x26c <event_execve+0x26c>
      94:      	add	x8, x8, #0x8d4
      98:      	mov	w9, #0x4                // =4
      9c:      	mov	w10, #0x71              // =113
      a0:      	add	x11, sp, #0xc8
      a4:      	ldr	x8, [sp, #0x40]
      a8:      	add	x0, sp, #0xc8
      ac:      	mov	w1, #0x4                // =4
      b0:      	add	x2, x8, #0x8d4
      b4:      	blr	x10
      b8:      	ldr	w8, [sp, #0xc8]
      bc:      	adrp	x23, 0x0 <event_execve>
      c0:      	add	x9, sp, #0xb8
      c4:      	add	x1, sp, #0xb8
      c8:      	str	w8, [sp, #0xb8]
      cc:      	mov	w8, #0x1                // =1
      d0:      	ldr	x23, [x23]
      d4:      	mov	x0, x23
      d8:      	blr	x8
      dc:      	cbz	x0, 0xe8 <event_execve+0xe8>
      e0:      	ldr	x8, [x0, #0x8]
      e4:      	cbnz	x8, 0x25c <event_execve+0x25c>
      e8:      	ldr	x8, [sp, #0x40]
      ec:      	mov	w9, #0x8                // =8
      f0:      	mov	w10, #0x71              // =113
      f4:      	add	x11, sp, #0x40
      f8:      	add	x0, sp, #0x40
      fc:      	mov	w1, #0x8                // =8
     100:      	add	x8, x8, #0x8e0
     104:      	ldr	x8, [sp, #0x40]
     108:      	add	x2, x8, #0x8e0
     10c:      	blr	x10
     110:      	ldr	x8, [sp, #0x40]
     114:      	cbz	x8, 0x26c <event_execve+0x26c>
     118:      	add	x8, x8, #0x8d4
     11c:      	mov	w9, #0x4                // =4
     120:      	mov	w10, #0x71              // =113
     124:      	add	x11, sp, #0xc8
     128:      	ldr	x8, [sp, #0x40]
     12c:      	add	x0, sp, #0xc8
     130:      	mov	w1, #0x4                // =4
     134:      	add	x2, x8, #0x8d4
     138:      	blr	x10
     13c:      	ldr	w8, [sp, #0xc8]
     140:      	add	x9, sp, #0xb8
     144:      	add	x1, sp, #0xb8
     148:      	mov	x0, x23
     14c:      	str	w8, [sp, #0xb8]
     150:      	mov	w8, #0x1                // =1
     154:      	blr	x8
     158:      	cbz	x0, 0x164 <event_execve+0x164>
     15c:      	ldr	x8, [x0, #0x8]
     160:      	cbnz	x8, 0x25c <event_execve+0x25c>
     164:      	ldr	x8, [sp, #0x40]
     168:      	mov	w9, #0x8                // =8
     16c:      	mov	w10, #0x71              // =113
     170:      	add	x11, sp, #0x40
     174:      	add	x0, sp, #0x40
     178:      	mov	w1, #0x8                // =8
     17c:      	add	x8, x8, #0x8e0
     180:      	ldr	x8, [sp, #0x40]
     184:      	add	x2, x8, #0x8e0
     188:      	blr	x10
     18c:      	ldr	x8, [sp, #0x40]
     190:      	cbz	x8, 0x26c <event_execve+0x26c>
     194:      	add	x8, x8, #0x8d4
     198:      	mov	w9, #0x4                // =4
     19c:      	mov	w10, #0x71              // =113
     1a0:      	add	x11, sp, #0xc8
     1a4:      	ldr	x8, [sp, #0x40]
     1a8:      	add	x0, sp, #0xc8
     1ac:      	mov	w1, #0x4                // =4
     1b0:      	add	x2, x8, #0x8d4
     1b4:      	blr	x10
     1b8:      	ldr	w8, [sp, #0xc8]
     1bc:      	add	x9, sp, #0xb8
     1c0:      	add	x1, sp, #0xb8
     1c4:      	mov	x0, x23
     1c8:      	str	w8, [sp, #0xb8]
     1cc:      	mov	w8, #0x1                // =1
     1d0:      	blr	x8
     1d4:      	cbz	x0, 0x1e0 <event_execve+0x1e0>
     1d8:      	ldr	x8, [x0, #0x8]
     1dc:      	cbnz	x8, 0x25c <event_execve+0x25c>
     1e0:      	ldr	x8, [sp, #0x40]
     1e4:      	mov	w9, #0x8                // =8
     1e8:      	mov	w10, #0x71              // =113
     1ec:      	add	x11, sp, #0x40
     1f0:      	add	x0, sp, #0x40
     1f4:      	mov	w1, #0x8                // =8
     1f8:      	add	x8, x8, #0x8e0
     1fc:      	ldr	x8, [sp, #0x40]
     200:      	add	x2, x8, #0x8e0
     204:      	blr	x10
     208:      	ldr	x8, [sp, #0x40]
     20c:      	cbz	x8, 0x26c <event_execve+0x26c>
     210:      	add	x8, x8, #0x8d4
     214:      	mov	w9, #0x4                // =4
     218:      	mov	w10, #0x71              // =113
     21c:      	add	x11, sp, #0xc8
     220:      	ldr	x8, [sp, #0x40]
     224:      	add	x0, sp, #0xc8
     228:      	mov	w1, #0x4                // =4
     22c:      	add	x2, x8, #0x8d4
     230:      	blr	x10
     234:      	ldr	w8, [sp, #0xc8]
     238:      	add	x9, sp, #0xb8
     23c:      	add	x1, sp, #0xb8
     240:      	mov	x0, x23
     244:      	str	w8, [sp, #0xb8]
     248:      	mov	w8, #0x1                // =1
     24c:      	blr	x8
     250:      	cbz	x0, 0x26c <event_execve+0x26c>
     254:      	ldr	x8, [x0, #0x8]
     258:      	cbz	x8, 0x26c <event_execve+0x26c>
     25c:      	ldp	x9, x10, [x0]
     260:      	mov	x8, xzr
     264:      	stp	x9, x10, [x20, #0xa0]
     268:      	b	0x2bc <event_execve+0x2bc>
     26c:      	add	x2, x29, #0x8e0
     270:      	mov	w8, #0x8                // =8
     274:      	mov	w9, #0x71               // =113
     278:      	add	x10, sp, #0x40
     27c:      	add	x0, sp, #0x40
     280:      	mov	w1, #0x8                // =8
     284:      	blr	x9
     288:      	ldr	x8, [sp, #0x40]
     28c:      	cbz	x8, 0x2b0 <event_execve+0x2b0>
     290:      	add	x2, x8, #0x8d4
     294:      	mov	w8, #0x4                // =4
     298:      	mov	w9, #0x71               // =113
     29c:      	add	x10, sp, #0x40
     2a0:      	add	x0, sp, #0x40
     2a4:      	mov	w1, #0x4                // =4
     2a8:      	blr	x9
     2ac:      	ldr	w8, [sp, #0x40]
     2b0:      	str	w8, [x20, #0xa0]
     2b4:      	mov	w8, #0x40               // =64
     2b8:      	str	xzr, [x20, #0xa8]
     2bc:      	str	x8, [x20, #0xb0]
     2c0:      	mov	w8, #0x1                // =1
     2c4:      	str	xzr, [x20, #0x178]
     2c8:      	str	w22, [x20, #0x148]
     2cc:      	str	w8, [x20, #0x15c]
     2d0:      	lsr	x8, x22, #32
     2d4:      	str	w8, [x20, #0x144]
     2d8:      	mov	w8, #0x23               // =35
     2dc:      	blr	x8
     2e0:      	add	x2, x0, #0x60
     2e4:      	mov	w8, #0x8                // =8
     2e8:      	mov	w9, #0x71               // =113
     2ec:      	add	x10, sp, #0xb8
     2f0:      	add	x0, sp, #0xb8
     2f4:      	mov	w1, #0x8                // =8
     2f8:      	blr	x9
     2fc:      	ldr	x8, [sp, #0xb8]
     300:      	cbz	x8, 0x370 <event_execve+0x370>
     304:      	add	x8, x8, #0x4
     308:      	mov	w9, #0x4                // =4
     30c:      	mov	w10, #0x71              // =113
     310:      	add	x11, sp, #0xc8
     314:      	ldr	x8, [sp, #0xb8]
     318:      	add	x0, sp, #0xc8
     31c:      	mov	w1, #0x4                // =4
     320:      	add	x2, x8, #0x4
     324:      	blr	x10
     328:      	ldr	w8, [sp, #0xc8]
     32c:      	cbz	w8, 0x370 <event_execve+0x370>
     330:      	ldr	x9, [sp, #0xb8]
     334:      	lsl	w8, w8, #4
     338:      	mov	w10, #0x71              // =113
     33c:      	add	x11, sp, #0x40
     340:      	add	x0, sp, #0x40
     344:      	mov	w1, #0x10               // =16
     348:      	add	x8, x9, x8
     34c:      	mov	w9, #0x10               // =16
     350:      	add	x8, x8, #0x80
     354:      	ldr	w9, [sp, #0xc8]
     358:      	ldr	x8, [sp, #0xb8]
     35c:      	lsl	w9, w9, #4
     360:      	add	x8, x8, x9
     364:      	add	x2, x8, #0x80
     368:      	blr	x10
     36c:      	ldr	w8, [sp, #0x40]
     370:      	str	w8, [x20, #0x14c]
     374:      	mov	w8, #0x5                // =5
     378:      	add	x23, x25, x21
     37c:      	blr	x8
     380:      	mov	w8, #0x40               // =64
     384:      	str	x0, [x20, #0x170]
     388:      	str	w8, [x20, #0x140]
     38c:      	mov	w8, #0x23               // =35
     390:      	blr	x8
     394:      	str	xzr, [sp, #0x40]
     398:      	cbz	x0, 0x3c0 <event_execve+0x3c0>
     39c:      	add	x2, x0, #0x70
     3a0:      	mov	w8, #0x8                // =8
     3a4:      	mov	w9, #0x4                // =4
     3a8:      	add	x10, sp, #0x40
     3ac:      	add	x0, sp, #0x40
     3b0:      	mov	w1, #0x8                // =8
     3b4:      	blr	x9
     3b8:      	ldr	x8, [sp, #0x40]
     3bc:      	b	0x3c4 <event_execve+0x3c4>
     3c0:      	mov	x8, xzr
     3c4:      	str	w8, [x20, #0x158]
     3c8:      	str	x22, [sp, #0x40]
     3cc:      	adrp	x24, 0x0 <event_execve>
     3d0:      	mov	w8, #0x1                // =1
     3d4:      	add	x9, sp, #0x40
     3d8:      	add	x1, sp, #0x40
     3dc:      	ldr	x24, [x24]
     3e0:      	mov	x0, x24
     3e4:      	blr	x8
     3e8:      	cbz	x0, 0x454 <event_execve+0x454>
     3ec:      	ldr	w8, [x0]
     3f0:      	add	x9, sp, #0x40
     3f4:      	add	x1, sp, #0x40
     3f8:      	str	w8, [x20, #0x150]
     3fc:      	ldr	x8, [x0, #0x8]
     400:      	str	x8, [x20, #0x168]
     404:      	ldr	w8, [x0, #0x4]
     408:      	str	x22, [sp, #0x40]
     40c:      	mov	x0, x24
     410:      	str	w8, [x20, #0x160]
     414:      	mov	w8, #0x3                // =3
     418:      	blr	x8
     41c:      	mov	x8, x0
     420:      	adrp	x0, 0x0 <event_execve>
     424:      	ldr	x0, [x0]
     428:      	cbz	w8, 0x464 <event_execve+0x464>
     42c:      	mov	w8, #0x2                // =2
     430:      	add	x9, sp, #0xb8
     434:      	add	x1, sp, #0xb8
     438:      	str	w8, [sp, #0xb8]
     43c:      	mov	w8, #0x1                // =1
     440:      	blr	x8
     444:      	cbz	x0, 0x488 <event_execve+0x488>
     448:      	ldr	x8, [x0]
     44c:      	add	x8, x8, #0x1
     450:      	b	0x484 <event_execve+0x484>
     454:      	str	wzr, [x20, #0x150]
     458:      	str	xzr, [x20, #0x168]
     45c:      	str	wzr, [x20, #0x160]
     460:      	b	0x488 <event_execve+0x488>
     464:      	str	wzr, [sp, #0xb8]
     468:      	mov	w8, #0x1                // =1
     46c:      	add	x9, sp, #0xb8
     470:      	add	x1, sp, #0xb8
     474:      	blr	x8
     478:      	cbz	x0, 0x488 <event_execve+0x488>
     47c:      	ldr	x8, [x0]
     480:      	sub	x8, x8, #0x1
     484:      	str	x8, [x0]
     488:      	add	x0, x20, #0x180
     48c:      	mov	w8, #0xff               // =255
     490:      	mov	w9, #0x2d               // =45
     494:      	mov	w1, #0xff               // =255
     498:      	mov	x2, x23
     49c:      	blr	x9
     4a0:      	str	x25, [sp, #0xd8]
     4a4:      	tbnz	w0, #0x1f, 0x5e0 <event_execve+0x5e0>
     4a8:      	cbz	w0, 0x5ec <event_execve+0x5ec>
     4ac:      	cmp	w0, #0xff
     4b0:      	b.ne	0x5f4 <event_execve+0x5f4>
     4b4:      	str	wzr, [sp, #0xb8]
     4b8:      	adrp	x0, 0x0 <event_execve>
     4bc:      	mov	w8, #0x1                // =1
     4c0:      	add	x9, sp, #0xb8
     4c4:      	ldr	x0, [x0]
     4c8:      	add	x1, sp, #0xb8
     4cc:      	blr	x8
     4d0:      	cbz	x0, 0x5e0 <event_execve+0x5e0>
     4d4:      	mov	w8, #0x18               // =24
     4d8:      	str	x29, [sp, #0x30]
     4dc:      	mov	x22, x0
     4e0:      	str	w8, [x0]
     4e4:      	mov	w8, #0xe                // =14
     4e8:      	blr	x8
     4ec:      	mov	x19, x22
     4f0:      	cmn	x0, #0x16
     4f4:      	str	x0, [x19, #0x10]!
     4f8:      	b.ne	0x520 <event_execve+0x520>
     4fc:      	add	x2, x25, #0xe8
     500:      	mov	w8, #0x8                // =8
     504:      	mov	w9, #0x4                // =4
     508:      	add	x10, sp, #0x40
     50c:      	add	x0, sp, #0x40
     510:      	mov	w1, #0x8                // =8
     514:      	blr	x9
     518:      	ldr	x8, [sp, #0x40]
     51c:      	str	x8, [x19]
     520:      	mov	w8, #0x5                // =5
     524:      	blr	x8
     528:      	str	x0, [x22, #0x18]
     52c:      	add	x25, x22, #0x20
     530:      	mov	w1, #0x7fdf             // =32735
     534:      	mov	x2, x23
     538:      	ldp	x8, x9, [x19]
     53c:      	mov	x0, x25
     540:      	stp	x8, x9, [x20, #0x190]
     544:      	mov	w8, #0x7fdf             // =32735
     548:      	mov	w9, #0x2d               // =45
     54c:      	blr	x9
     550:      	mov	x29, x0
     554:      	tbnz	x0, #0x3f, 0x600 <event_execve+0x600>
     558:      	cbz	x29, 0x608 <event_execve+0x608>
     55c:      	add	w8, w29, #0x1f
     560:      	adrp	x19, 0x0 <event_execve>
     564:      	mov	w9, #0x19               // =25
     568:      	mov	w2, #-0x1               // =-1
     56c:      	mov	x3, x22
     570:      	sub	x21, x29, #0x1
     574:      	and	x4, x8, #0x7fff
     578:      	mov	w8, #-0x1               // =-1
     57c:      	str	w4, [x22, #0x4]
     580:      	ldr	x19, [x19]
     584:      	ldr	x0, [sp, #0xd8]
     588:      	mov	x1, x19
     58c:      	blr	x9
     590:      	tbz	x0, #0x3f, 0x670 <event_execve+0x670>
     594:      	mov	x24, x0
     598:      	str	wzr, [sp, #0x40]
     59c:      	adrp	x0, 0x0 <event_execve>
     5a0:      	mov	w8, #0x1                // =1
     5a4:      	ldr	x0, [x0]
     5a8:      	add	x9, sp, #0x40
     5ac:      	add	x1, sp, #0x40
     5b0:      	blr	x8
     5b4:      	cbz	x0, 0x670 <event_execve+0x670>
     5b8:      	cmn	x24, #0xc
     5bc:      	b.gt	0x61c <event_execve+0x61c>
     5c0:      	cmn	x24, #0x1c
     5c4:      	b.eq	0x63c <event_execve+0x63c>
     5c8:      	cmn	x24, #0x16
     5cc:      	b.eq	0x654 <event_execve+0x654>
     5d0:      	cmn	x24, #0x10
     5d4:      	b.ne	0x64c <event_execve+0x64c>
     5d8:      	add	x8, x0, #0x558
     5dc:      	b	0x660 <event_execve+0x660>
     5e0:      	mov	w8, wzr
     5e4:      	mov	w0, #0x100              // =256
     5e8:      	b	0x750 <event_execve+0x750>
     5ec:      	mov	w8, w0
     5f0:      	b	0x750 <event_execve+0x750>
     5f4:      	sub	w8, w0, #0x1
     5f8:      	mov	w0, wzr
     5fc:      	b	0x750 <event_execve+0x750>
     600:      	mov	x21, x29
     604:      	b	0x724 <event_execve+0x724>
     608:      	ldr	x25, [sp, #0xd8]
     60c:      	ldr	x29, [sp, #0x30]
     610:      	mov	w9, wzr
     614:      	mov	w8, wzr
     618:      	b	0x738 <event_execve+0x738>
     61c:      	cmn	x24, #0xb
     620:      	b.eq	0x644 <event_execve+0x644>
     624:      	cmn	x24, #0x7
     628:      	b.eq	0x65c <event_execve+0x65c>
     62c:      	cmn	x24, #0x2
     630:      	b.ne	0x64c <event_execve+0x64c>
     634:      	add	x8, x0, #0x548
     638:      	b	0x660 <event_execve+0x660>
     63c:      	add	x8, x0, #0x568
     640:      	b	0x660 <event_execve+0x660>
     644:      	add	x8, x0, #0x570
     648:      	b	0x660 <event_execve+0x660>
     64c:      	add	x8, x0, #0x540
     650:      	b	0x660 <event_execve+0x660>
     654:      	add	x8, x0, #0x560
     658:      	b	0x660 <event_execve+0x660>
     65c:      	add	x8, x0, #0x550
     660:      	ldaxr	x9, [x8]
     664:      	add	x9, x9, #0x1
     668:      	stlxr	w10, x9, [x8]
     66c:      	cbnz	w10, 0x660 <event_execve+0x660>
     670:      	mov	w8, #0x7fdf             // =32735
     674:      	cmp	x29, x8
     678:      	b.ne	0x724 <event_execve+0x724>
     67c:      	add	x2, x21, x23
     680:      	mov	w8, #0x7fdf             // =32735
     684:      	mov	w9, #0x2d               // =45
     688:      	mov	x0, x25
     68c:      	mov	w1, #0x7fdf             // =32735
     690:      	blr	x9
     694:      	ldr	x29, [sp, #0x30]
     698:      	tbnz	x0, #0x3f, 0x166c <event_execve+0x166c>
     69c:      	ldr	x25, [sp, #0xd8]
     6a0:      	cbz	x0, 0x72c <event_execve+0x72c>
     6a4:      	add	w8, w0, #0x1f
     6a8:      	mov	w9, #0x19               // =25
     6ac:      	sub	x23, x0, #0x1
     6b0:      	mov	x0, x25
     6b4:      	mov	x1, x19
     6b8:      	mov	w2, #-0x1               // =-1
     6bc:      	mov	x3, x22
     6c0:      	and	x4, x8, #0x7fff
     6c4:      	str	w4, [x22, #0x4]
     6c8:      	mov	w8, #-0x1               // =-1
     6cc:      	blr	x9
     6d0:      	tbz	x0, #0x3f, 0x1760 <event_execve+0x1760>
     6d4:      	mov	x19, x0
     6d8:      	str	wzr, [sp, #0x40]
     6dc:      	adrp	x0, 0x0 <event_execve>
     6e0:      	mov	w8, #0x1                // =1
     6e4:      	ldr	x0, [x0]
     6e8:      	add	x9, sp, #0x40
     6ec:      	add	x1, sp, #0x40
     6f0:      	blr	x8
     6f4:      	cbz	x0, 0x1760 <event_execve+0x1760>
     6f8:      	mov	x8, x19
     6fc:      	cmn	x19, #0xc
     700:      	b.gt	0x170c <event_execve+0x170c>
     704:      	cmn	x8, #0x1c
     708:      	b.eq	0x172c <event_execve+0x172c>
     70c:      	cmn	x8, #0x16
     710:      	b.eq	0x1744 <event_execve+0x1744>
     714:      	cmn	x8, #0x10
     718:      	b.ne	0x173c <event_execve+0x173c>
     71c:      	add	x8, x0, #0x558
     720:      	b	0x1750 <event_execve+0x1750>
     724:      	ldr	x25, [sp, #0xd8]
     728:      	ldr	x29, [sp, #0x30]
     72c:      	asr	w8, w21, #31
     730:      	and	w9, w21, w8
     734:      	bic	w8, w21, w8
     738:      	str	w9, [x20, #0x180]
     73c:      	add	x9, x20, #0x184
     740:      	str	w8, [x20, #0x18c]
     744:      	mov	w8, #0x20               // =32
     748:      	mov	w0, #0x800000           // =8388608
     74c:      	str	xzr, [x9]
     750:      	ldr	w9, [x20, #0x15c]
     754:      	strh	w8, [x20, #0x178]
     758:      	orr	w9, w9, w0
     75c:      	str	w9, [x20, #0x15c]
     760:      	ldr	w9, [x20, #0x140]
     764:      	add	w8, w9, w8
     768:      	str	w8, [x20, #0x140]
     76c:      	mov	w8, #0x23               // =35
     770:      	blr	x8
     774:      	str	wzr, [sp, #0xa0]
     778:      	add	x2, x0, #0x858
     77c:      	mov	w8, #0x8                // =8
     780:      	mov	w9, #0x4                // =4
     784:      	add	x10, sp, #0xb0
     788:      	add	x0, sp, #0xb0
     78c:      	mov	w1, #0x8                // =8
     790:      	blr	x9
     794:      	adrp	x23, 0x0 <event_execve>
     798:      	ldr	x23, [x23]
     79c:      	cbz	x0, 0x7e4 <event_execve+0x7e4>
     7a0:      	neg	w8, w0
     7a4:      	mov	w9, #0x1                // =1
     7a8:      	add	x1, sp, #0x40
     7ac:      	strh	w8, [sp, #0x40]
     7b0:      	mov	w8, #0x9                // =9
     7b4:      	mov	x0, x23
     7b8:      	mov	w19, #0x1               // =1
     7bc:      	strh	w8, [sp, #0x42]
     7c0:      	mov	x8, #0x42               // =66
     7c4:      	movk	x8, #0x4, lsl #32
     7c8:      	stur	x8, [sp, #0x44]
     7cc:      	add	x8, sp, #0x40
     7d0:      	blr	x9
     7d4:      	cbz	x0, 0x860 <event_execve+0x860>
     7d8:      	ldr	w8, [x0]
     7dc:      	add	w8, w8, #0x1
     7e0:      	str	w8, [x0]
     7e4:      	ldr	x8, [sp, #0xb0]
     7e8:      	add	x21, sp, #0xb8
     7ec:      	cbz	x8, 0xa28 <event_execve+0xa28>
     7f0:      	add	x8, x8, #0x278
     7f4:      	mov	w9, #0x8                // =8
     7f8:      	mov	w10, #0x4               // =4
     7fc:      	add	x11, sp, #0xb8
     800:      	ldr	x8, [sp, #0xb0]
     804:      	add	x0, sp, #0xb8
     808:      	mov	w1, #0x8                // =8
     80c:      	add	x2, x8, #0x278
     810:      	blr	x10
     814:      	cbz	x0, 0x8b8 <event_execve+0x8b8>
     818:      	neg	w8, w0
     81c:      	mov	w9, #0x1                // =1
     820:      	add	x1, sp, #0x40
     824:      	strh	w8, [sp, #0x40]
     828:      	mov	w8, #0x9                // =9
     82c:      	mov	x0, x23
     830:      	mov	w19, #0x1               // =1
     834:      	strh	w8, [sp, #0x42]
     838:      	mov	x8, #0x47               // =71
     83c:      	movk	x8, #0x4, lsl #32
     840:      	stur	x8, [sp, #0x44]
     844:      	add	x8, sp, #0x40
     848:      	blr	x9
     84c:      	cbz	x0, 0x894 <event_execve+0x894>
     850:      	ldr	w8, [x0]
     854:      	add	w8, w8, #0x1
     858:      	str	w8, [x0]
     85c:      	b	0x8b8 <event_execve+0x8b8>
     860:      	str	w19, [sp, #0xb8]
     864:      	mov	x3, xzr
     868:      	mov	w8, #0x2                // =2
     86c:      	add	x9, sp, #0x40
     870:      	add	x10, sp, #0xb8
     874:      	add	x1, sp, #0x40
     878:      	add	x2, sp, #0xb8
     87c:      	mov	x0, x23
     880:      	blr	x8
     884:      	ldr	x8, [sp, #0xb0]
     888:      	add	x21, sp, #0xb8
     88c:      	cbnz	x8, 0x7f0 <event_execve+0x7f0>
     890:      	b	0xa28 <event_execve+0xa28>
     894:      	str	w19, [sp, #0xc8]
     898:      	mov	x3, xzr
     89c:      	mov	w8, #0x2                // =2
     8a0:      	add	x9, sp, #0x40
     8a4:      	add	x10, sp, #0xc8
     8a8:      	add	x1, sp, #0x40
     8ac:      	add	x2, sp, #0xc8
     8b0:      	mov	x0, x23
     8b4:      	blr	x8
     8b8:      	ldr	x8, [sp, #0xb0]
     8bc:      	mov	w9, #0x8                // =8
     8c0:      	mov	w10, #0x4               // =4
     8c4:      	add	x11, sp, #0xc8
     8c8:      	add	x0, sp, #0xc8
     8cc:      	mov	w1, #0x8                // =8
     8d0:      	add	x8, x8, #0x280
     8d4:      	ldr	x8, [sp, #0xb0]
     8d8:      	add	x2, x8, #0x280
     8dc:      	blr	x10
     8e0:      	cbz	x0, 0x928 <event_execve+0x928>
     8e4:      	neg	w8, w0
     8e8:      	mov	w9, #0x1                // =1
     8ec:      	add	x1, sp, #0x40
     8f0:      	strh	w8, [sp, #0x40]
     8f4:      	mov	w8, #0x9                // =9
     8f8:      	mov	x0, x23
     8fc:      	mov	w19, #0x1               // =1
     900:      	strh	w8, [sp, #0x42]
     904:      	mov	x8, #0x48               // =72
     908:      	movk	x8, #0x4, lsl #32
     90c:      	stur	x8, [sp, #0x44]
     910:      	add	x8, sp, #0x40
     914:      	blr	x9
     918:      	cbz	x0, 0xa48 <event_execve+0xa48>
     91c:      	ldr	w8, [x0]
     920:      	add	w8, w8, #0x1
     924:      	str	w8, [x0]
     928:      	ldr	x8, [sp, #0xb8]
     92c:      	mov	w24, wzr
     930:      	cbz	x8, 0xa80 <event_execve+0xa80>
     934:      	ldr	x8, [x21, #0x10]
     938:      	cbz	x8, 0xa80 <event_execve+0xa80>
     93c:      	adrp	x0, 0x0 <event_execve>
     940:      	mov	w8, #0x1                // =1
     944:      	add	x9, sp, #0xa0
     948:      	ldr	x0, [x0]
     94c:      	add	x1, sp, #0xa0
     950:      	blr	x8
     954:      	cbz	x0, 0xa28 <event_execve+0xa28>
     958:      	ldr	x8, [sp, #0xb8]
     95c:      	mov	w9, #0x1000             // =4096
     960:      	mov	w10, #0x2d              // =45
     964:      	mov	w1, #0x1000             // =4096
     968:      	ldr	x2, [sp, #0xb8]
     96c:      	blr	x10
     970:      	tbnz	x0, #0x3f, 0xa7c <event_execve+0xa7c>
     974:      	ldr	x8, [sp, #0xb8]
     978:      	add	x9, sp, #0xb8
     97c:      	add	x22, x8, x0
     980:      	ldr	w8, [x20, #0x140]
     984:      	str	x22, [sp, #0xb8]
     988:      	and	x8, x8, #0x1ff
     98c:      	add	x21, x20, x8
     990:      	ldr	x8, [x9, #0x10]
     994:      	sub	x24, x8, x22
     998:      	cmp	x24, #0x3ff
     99c:      	b.hi	0x10dc <event_execve+0x10dc>
     9a0:      	add	x9, x20, #0x140
     9a4:      	add	x0, x21, #0x140
     9a8:      	sub	x9, x9, x0
     9ac:      	add	x9, x9, #0x400
     9b0:      	cmp	x24, x9
     9b4:      	b.hs	0x10dc <event_execve+0x10dc>
     9b8:      	sub	w9, w24, #0x1
     9bc:      	cmp	x8, x22
     9c0:      	mov	w8, #0x4                // =4
     9c4:      	and	w9, w9, #0x3ff
     9c8:      	csel	w24, wzr, w9, eq
     9cc:      	ldr	x2, [sp, #0xb8]
     9d0:      	mov	w1, w24
     9d4:      	blr	x8
     9d8:      	cbz	x0, 0x16f0 <event_execve+0x16f0>
     9dc:      	mov	x22, x0
     9e0:      	mov	w9, #0x1                // =1
     9e4:      	add	x1, sp, #0x40
     9e8:      	mov	x0, x23
     9ec:      	mov	w19, #0x1               // =1
     9f0:      	neg	w8, w22
     9f4:      	strh	w8, [sp, #0x40]
     9f8:      	mov	w8, #0x9                // =9
     9fc:      	strh	w8, [sp, #0x42]
     a00:      	mov	x8, #0x6c               // =108
     a04:      	movk	x8, #0x4, lsl #32
     a08:      	stur	x8, [sp, #0x44]
     a0c:      	add	x8, sp, #0x40
     a10:      	blr	x9
     a14:      	cbz	x0, 0x15c8 <event_execve+0x15c8>
     a18:      	ldr	w8, [x0]
     a1c:      	add	w8, w8, #0x1
     a20:      	str	w8, [x0]
     a24:      	b	0x15ec <event_execve+0x15ec>
     a28:      	mov	w24, wzr
     a2c:      	ldr	w8, [x20, #0x140]
     a30:      	add	w9, w8, w24
     a34:      	ldrb	w8, [x20, #0x15d]
     a38:      	str	w9, [x20, #0x140]
     a3c:      	tbz	w8, #0x5, 0xa94 <event_execve+0xa94>
     a40:      	mov	w8, wzr
     a44:      	b	0x1b18 <event_execve+0x1b18>
     a48:      	str	w19, [sp, #0xa8]
     a4c:      	mov	x3, xzr
     a50:      	mov	w8, #0x2                // =2
     a54:      	add	x9, sp, #0x40
     a58:      	add	x10, sp, #0xa8
     a5c:      	add	x1, sp, #0x40
     a60:      	add	x2, sp, #0xa8
     a64:      	mov	x0, x23
     a68:      	blr	x8
     a6c:      	ldr	x8, [sp, #0xb8]
     a70:      	mov	w24, wzr
     a74:      	cbnz	x8, 0x934 <event_execve+0x934>
     a78:      	b	0xa80 <event_execve+0xa80>
     a7c:      	mov	w24, wzr
     a80:      	ldr	w8, [x20, #0x140]
     a84:      	add	w9, w8, w24
     a88:      	ldrb	w8, [x20, #0x15d]
     a8c:      	str	w9, [x20, #0x140]
     a90:      	tbnz	w8, #0x5, 0xa40 <event_execve+0xa40>
     a94:      	str	w9, [sp, #0x24]
     a98:      	ldr	w23, [x20, #0x144]
     a9c:      	mov	w8, #0x23               // =35
     aa0:      	add	x24, x20, #0x140
     aa4:      	blr	x8
     aa8:      	mov	x22, x0
     aac:      	str	wzr, [sp, #0xb8]
     ab0:      	str	x29, [sp, #0x30]
     ab4:      	cbz	x0, 0x176c <event_execve+0x176c>
     ab8:      	add	x2, x22, #0x8d4
     abc:      	mov	w8, #0x4                // =4
     ac0:      	mov	w9, #0x71               // =113
     ac4:      	add	x10, sp, #0xb8
     ac8:      	add	x0, sp, #0xb8
     acc:      	mov	w1, #0x4                // =4
     ad0:      	blr	x9
     ad4:      	ldr	w8, [sp, #0xb8]
     ad8:      	cmp	w8, w23
     adc:      	b.eq	0x176c <event_execve+0x176c>
     ae0:      	add	x2, x22, #0x8e0
     ae4:      	mov	w8, #0x8                // =8
     ae8:      	mov	w9, #0x71               // =113
     aec:      	add	x10, sp, #0x40
     af0:      	add	x0, sp, #0x40
     af4:      	mov	w1, #0x8                // =8
     af8:      	blr	x9
     afc:      	ldr	x22, [sp, #0x40]
     b00:      	cbz	x22, 0x176c <event_execve+0x176c>
     b04:      	add	x2, x22, #0x8d4
     b08:      	mov	w8, #0x4                // =4
     b0c:      	mov	w9, #0x71               // =113
     b10:      	add	x10, sp, #0xb8
     b14:      	add	x0, sp, #0xb8
     b18:      	mov	w1, #0x4                // =4
     b1c:      	blr	x9
     b20:      	ldr	w8, [sp, #0xb8]
     b24:      	cmp	w8, w23
     b28:      	b.eq	0x176c <event_execve+0x176c>
     b2c:      	add	x2, x22, #0x8e0
     b30:      	mov	w8, #0x8                // =8
     b34:      	mov	w9, #0x71               // =113
     b38:      	add	x10, sp, #0x40
     b3c:      	add	x0, sp, #0x40
     b40:      	mov	w1, #0x8                // =8
     b44:      	blr	x9
     b48:      	ldr	x22, [sp, #0x40]
     b4c:      	cbz	x22, 0x176c <event_execve+0x176c>
     b50:      	add	x2, x22, #0x8d4
     b54:      	mov	w8, #0x4                // =4
     b58:      	mov	w9, #0x71               // =113
     b5c:      	add	x10, sp, #0xb8
     b60:      	add	x0, sp, #0xb8
     b64:      	mov	w1, #0x4                // =4
     b68:      	blr	x9
     b6c:      	ldr	w8, [sp, #0xb8]
     b70:      	cmp	w8, w23
     b74:      	b.eq	0x176c <event_execve+0x176c>
     b78:      	add	x2, x22, #0x8e0
     b7c:      	mov	w8, #0x8                // =8
     b80:      	mov	w9, #0x71               // =113
     b84:      	add	x10, sp, #0x40
     b88:      	add	x0, sp, #0x40
     b8c:      	mov	w1, #0x8                // =8
     b90:      	blr	x9
     b94:      	ldr	x22, [sp, #0x40]
     b98:      	cbz	x22, 0x176c <event_execve+0x176c>
     b9c:      	add	x2, x22, #0x8d4
     ba0:      	mov	w8, #0x4                // =4
     ba4:      	mov	w9, #0x71               // =113
     ba8:      	add	x10, sp, #0xb8
     bac:      	add	x0, sp, #0xb8
     bb0:      	mov	w1, #0x4                // =4
     bb4:      	blr	x9
     bb8:      	ldr	w8, [sp, #0xb8]
     bbc:      	cmp	w8, w23
     bc0:      	b.eq	0x176c <event_execve+0x176c>
     bc4:      	add	x2, x22, #0x8e0
     bc8:      	mov	w8, #0x8                // =8
     bcc:      	mov	w9, #0x71               // =113
     bd0:      	add	x10, sp, #0x40
     bd4:      	add	x0, sp, #0x40
     bd8:      	mov	w1, #0x8                // =8
     bdc:      	blr	x9
     be0:      	ldr	x22, [sp, #0x40]
     be4:      	cbz	x22, 0x176c <event_execve+0x176c>
     be8:      	add	x2, x22, #0x8d4
     bec:      	mov	w8, #0x4                // =4
     bf0:      	mov	w9, #0x71               // =113
     bf4:      	add	x10, sp, #0xb8
     bf8:      	add	x0, sp, #0xb8
     bfc:      	mov	w1, #0x4                // =4
     c00:      	blr	x9
     c04:      	ldr	w8, [sp, #0xb8]
     c08:      	cmp	w8, w23
     c0c:      	b.eq	0x176c <event_execve+0x176c>
     c10:      	add	x2, x22, #0x8e0
     c14:      	mov	w8, #0x8                // =8
     c18:      	mov	w9, #0x71               // =113
     c1c:      	add	x10, sp, #0x40
     c20:      	add	x0, sp, #0x40
     c24:      	mov	w1, #0x8                // =8
     c28:      	blr	x9
     c2c:      	ldr	x22, [sp, #0x40]
     c30:      	cbz	x22, 0x176c <event_execve+0x176c>
     c34:      	add	x2, x22, #0x8d4
     c38:      	mov	w8, #0x4                // =4
     c3c:      	mov	w9, #0x71               // =113
     c40:      	add	x10, sp, #0xb8
     c44:      	add	x0, sp, #0xb8
     c48:      	mov	w1, #0x4                // =4
     c4c:      	blr	x9
     c50:      	ldr	w8, [sp, #0xb8]
     c54:      	cmp	w8, w23
     c58:      	b.eq	0x176c <event_execve+0x176c>
     c5c:      	add	x2, x22, #0x8e0
     c60:      	mov	w8, #0x8                // =8
     c64:      	mov	w9, #0x71               // =113
     c68:      	add	x10, sp, #0x40
     c6c:      	add	x0, sp, #0x40
     c70:      	mov	w1, #0x8                // =8
     c74:      	blr	x9
     c78:      	ldr	x22, [sp, #0x40]
     c7c:      	cbz	x22, 0x176c <event_execve+0x176c>
     c80:      	add	x2, x22, #0x8d4
     c84:      	mov	w8, #0x4                // =4
     c88:      	mov	w9, #0x71               // =113
     c8c:      	add	x10, sp, #0xb8
     c90:      	add	x0, sp, #0xb8
     c94:      	mov	w1, #0x4                // =4
     c98:      	blr	x9
     c9c:      	ldr	w8, [sp, #0xb8]
     ca0:      	cmp	w8, w23
     ca4:      	b.eq	0x176c <event_execve+0x176c>
     ca8:      	add	x2, x22, #0x8e0
     cac:      	mov	w8, #0x8                // =8
     cb0:      	mov	w9, #0x71               // =113
     cb4:      	add	x10, sp, #0x40
     cb8:      	add	x0, sp, #0x40
     cbc:      	mov	w1, #0x8                // =8
     cc0:      	blr	x9
     cc4:      	ldr	x22, [sp, #0x40]
     cc8:      	cbz	x22, 0x176c <event_execve+0x176c>
     ccc:      	add	x2, x22, #0x8d4
     cd0:      	mov	w8, #0x4                // =4
     cd4:      	mov	w9, #0x71               // =113
     cd8:      	add	x10, sp, #0xb8
     cdc:      	add	x0, sp, #0xb8
     ce0:      	mov	w1, #0x4                // =4
     ce4:      	blr	x9
     ce8:      	ldr	w8, [sp, #0xb8]
     cec:      	cmp	w8, w23
     cf0:      	b.eq	0x176c <event_execve+0x176c>
     cf4:      	add	x2, x22, #0x8e0
     cf8:      	mov	w8, #0x8                // =8
     cfc:      	mov	w9, #0x71               // =113
     d00:      	add	x10, sp, #0x40
     d04:      	add	x0, sp, #0x40
     d08:      	mov	w1, #0x8                // =8
     d0c:      	mov	x21, x24
     d10:      	blr	x9
     d14:      	ldr	x22, [sp, #0x40]
     d18:      	cbz	x22, 0x1768 <event_execve+0x1768>
     d1c:      	add	x2, x22, #0x8d4
     d20:      	mov	w8, #0x4                // =4
     d24:      	mov	w9, #0x71               // =113
     d28:      	add	x10, sp, #0xb8
     d2c:      	add	x0, sp, #0xb8
     d30:      	mov	w1, #0x4                // =4
     d34:      	blr	x9
     d38:      	ldr	w8, [sp, #0xb8]
     d3c:      	mov	x24, x21
     d40:      	cmp	w8, w23
     d44:      	b.eq	0x176c <event_execve+0x176c>
     d48:      	add	x2, x22, #0x8e0
     d4c:      	mov	w8, #0x8                // =8
     d50:      	mov	w9, #0x71               // =113
     d54:      	add	x10, sp, #0x40
     d58:      	add	x0, sp, #0x40
     d5c:      	mov	w1, #0x8                // =8
     d60:      	blr	x9
     d64:      	ldr	x22, [sp, #0x40]
     d68:      	cbz	x22, 0x1768 <event_execve+0x1768>
     d6c:      	add	x2, x22, #0x8d4
     d70:      	mov	w8, #0x4                // =4
     d74:      	mov	w9, #0x71               // =113
     d78:      	add	x10, sp, #0xb8
     d7c:      	add	x0, sp, #0xb8
     d80:      	mov	w1, #0x4                // =4
     d84:      	blr	x9
     d88:      	ldr	w8, [sp, #0xb8]
     d8c:      	mov	x24, x21
     d90:      	cmp	w8, w23
     d94:      	b.eq	0x176c <event_execve+0x176c>
     d98:      	add	x2, x22, #0x8e0
     d9c:      	mov	w8, #0x8                // =8
     da0:      	mov	w9, #0x71               // =113
     da4:      	add	x10, sp, #0x40
     da8:      	add	x0, sp, #0x40
     dac:      	mov	w1, #0x8                // =8
     db0:      	blr	x9
     db4:      	ldr	x22, [sp, #0x40]
     db8:      	cbz	x22, 0x1768 <event_execve+0x1768>
     dbc:      	add	x2, x22, #0x8d4
     dc0:      	mov	w8, #0x4                // =4
     dc4:      	mov	w9, #0x71               // =113
     dc8:      	add	x10, sp, #0xb8
     dcc:      	add	x0, sp, #0xb8
     dd0:      	mov	w1, #0x4                // =4
     dd4:      	blr	x9
     dd8:      	ldr	w8, [sp, #0xb8]
     ddc:      	mov	x24, x21
     de0:      	cmp	w8, w23
     de4:      	b.eq	0x176c <event_execve+0x176c>
     de8:      	add	x2, x22, #0x8e0
     dec:      	mov	w8, #0x8                // =8
     df0:      	mov	w9, #0x71               // =113
     df4:      	add	x10, sp, #0x40
     df8:      	add	x0, sp, #0x40
     dfc:      	mov	w1, #0x8                // =8
     e00:      	blr	x9
     e04:      	ldr	x22, [sp, #0x40]
     e08:      	cbz	x22, 0x1768 <event_execve+0x1768>
     e0c:      	add	x2, x22, #0x8d4
     e10:      	mov	w8, #0x4                // =4
     e14:      	mov	w9, #0x71               // =113
     e18:      	add	x10, sp, #0xb8
     e1c:      	add	x0, sp, #0xb8
     e20:      	mov	w1, #0x4                // =4
     e24:      	blr	x9
     e28:      	ldr	w8, [sp, #0xb8]
     e2c:      	mov	x24, x21
     e30:      	cmp	w8, w23
     e34:      	b.eq	0x176c <event_execve+0x176c>
     e38:      	add	x2, x22, #0x8e0
     e3c:      	mov	w8, #0x8                // =8
     e40:      	mov	w9, #0x71               // =113
     e44:      	add	x10, sp, #0x40
     e48:      	add	x0, sp, #0x40
     e4c:      	mov	w1, #0x8                // =8
     e50:      	blr	x9
     e54:      	ldr	x22, [sp, #0x40]
     e58:      	cbz	x22, 0x1768 <event_execve+0x1768>
     e5c:      	add	x2, x22, #0x8d4
     e60:      	mov	w8, #0x4                // =4
     e64:      	mov	w9, #0x71               // =113
     e68:      	add	x10, sp, #0xb8
     e6c:      	add	x0, sp, #0xb8
     e70:      	mov	w1, #0x4                // =4
     e74:      	blr	x9
     e78:      	ldr	w8, [sp, #0xb8]
     e7c:      	mov	x24, x21
     e80:      	cmp	w8, w23
     e84:      	b.eq	0x176c <event_execve+0x176c>
     e88:      	add	x2, x22, #0x8e0
     e8c:      	mov	w8, #0x8                // =8
     e90:      	mov	w9, #0x71               // =113
     e94:      	add	x10, sp, #0x40
     e98:      	add	x0, sp, #0x40
     e9c:      	mov	w1, #0x8                // =8
     ea0:      	blr	x9
     ea4:      	ldr	x22, [sp, #0x40]
     ea8:      	cbz	x22, 0x1768 <event_execve+0x1768>
     eac:      	add	x2, x22, #0x8d4
     eb0:      	mov	w8, #0x4                // =4
     eb4:      	mov	w9, #0x71               // =113
     eb8:      	add	x10, sp, #0xb8
     ebc:      	add	x0, sp, #0xb8
     ec0:      	mov	w1, #0x4                // =4
     ec4:      	blr	x9
     ec8:      	ldr	w8, [sp, #0xb8]
     ecc:      	mov	x24, x21
     ed0:      	cmp	w8, w23
     ed4:      	b.eq	0x176c <event_execve+0x176c>
     ed8:      	add	x2, x22, #0x8e0
     edc:      	mov	w8, #0x8                // =8
     ee0:      	mov	w9, #0x71               // =113
     ee4:      	add	x10, sp, #0x40
     ee8:      	add	x0, sp, #0x40
     eec:      	mov	w1, #0x8                // =8
     ef0:      	blr	x9
     ef4:      	ldr	x22, [sp, #0x40]
     ef8:      	cbz	x22, 0x1768 <event_execve+0x1768>
     efc:      	add	x2, x22, #0x8d4
     f00:      	mov	w8, #0x4                // =4
     f04:      	mov	w9, #0x71               // =113
     f08:      	add	x10, sp, #0xb8
     f0c:      	add	x0, sp, #0xb8
     f10:      	mov	w1, #0x4                // =4
     f14:      	blr	x9
     f18:      	ldr	w8, [sp, #0xb8]
     f1c:      	mov	x24, x21
     f20:      	cmp	w8, w23
     f24:      	b.eq	0x176c <event_execve+0x176c>
     f28:      	add	x2, x22, #0x8e0
     f2c:      	mov	w8, #0x8                // =8
     f30:      	mov	w9, #0x71               // =113
     f34:      	add	x10, sp, #0x40
     f38:      	add	x0, sp, #0x40
     f3c:      	mov	w1, #0x8                // =8
     f40:      	blr	x9
     f44:      	ldr	x22, [sp, #0x40]
     f48:      	cbz	x22, 0x1768 <event_execve+0x1768>
     f4c:      	add	x2, x22, #0x8d4
     f50:      	mov	w8, #0x4                // =4
     f54:      	mov	w9, #0x71               // =113
     f58:      	add	x10, sp, #0xb8
     f5c:      	add	x0, sp, #0xb8
     f60:      	mov	w1, #0x4                // =4
     f64:      	blr	x9
     f68:      	ldr	w8, [sp, #0xb8]
     f6c:      	mov	x24, x21
     f70:      	cmp	w8, w23
     f74:      	b.eq	0x176c <event_execve+0x176c>
     f78:      	add	x2, x22, #0x8e0
     f7c:      	mov	w8, #0x8                // =8
     f80:      	mov	w9, #0x71               // =113
     f84:      	add	x10, sp, #0x40
     f88:      	add	x0, sp, #0x40
     f8c:      	mov	w1, #0x8                // =8
     f90:      	blr	x9
     f94:      	ldr	x22, [sp, #0x40]
     f98:      	cbz	x22, 0x1768 <event_execve+0x1768>
     f9c:      	add	x2, x22, #0x8d4
     fa0:      	mov	w8, #0x4                // =4
     fa4:      	mov	w9, #0x71               // =113
     fa8:      	add	x10, sp, #0xb8
     fac:      	add	x0, sp, #0xb8
     fb0:      	mov	w1, #0x4                // =4
     fb4:      	blr	x9
     fb8:      	ldr	w8, [sp, #0xb8]
     fbc:      	mov	x24, x21
     fc0:      	cmp	w8, w23
     fc4:      	b.eq	0x176c <event_execve+0x176c>
     fc8:      	add	x2, x22, #0x8e0
     fcc:      	mov	w8, #0x8                // =8
     fd0:      	mov	w9, #0x71               // =113
     fd4:      	add	x10, sp, #0x40
     fd8:      	add	x0, sp, #0x40
     fdc:      	mov	w1, #0x8                // =8
     fe0:      	blr	x9
     fe4:      	ldr	x22, [sp, #0x40]
     fe8:      	cbz	x22, 0x1768 <event_execve+0x1768>
     fec:      	add	x2, x22, #0x8d4
     ff0:      	mov	w8, #0x4                // =4
     ff4:      	mov	w9, #0x71               // =113
     ff8:      	add	x10, sp, #0xb8
     ffc:      	add	x0, sp, #0xb8
    1000:      	mov	w1, #0x4                // =4
    1004:      	blr	x9
    1008:      	ldr	w8, [sp, #0xb8]
    100c:      	mov	x24, x21
    1010:      	cmp	w8, w23
    1014:      	b.eq	0x176c <event_execve+0x176c>
    1018:      	add	x2, x22, #0x8e0
    101c:      	mov	w8, #0x8                // =8
    1020:      	mov	w9, #0x71               // =113
    1024:      	add	x10, sp, #0x40
    1028:      	add	x0, sp, #0x40
    102c:      	mov	w1, #0x8                // =8
    1030:      	blr	x9
    1034:      	ldr	x22, [sp, #0x40]
    1038:      	cbz	x22, 0x1768 <event_execve+0x1768>
    103c:      	add	x2, x22, #0x8d4
    1040:      	mov	w8, #0x4                // =4
    1044:      	mov	w9, #0x71               // =113
    1048:      	add	x10, sp, #0xb8
    104c:      	add	x0, sp, #0xb8
    1050:      	mov	w1, #0x4                // =4
    1054:      	blr	x9
    1058:      	ldr	w8, [sp, #0xb8]
    105c:      	mov	x24, x21
    1060:      	cmp	w8, w23
    1064:      	b.eq	0x176c <event_execve+0x176c>
    1068:      	add	x2, x22, #0x8e0
    106c:      	mov	w8, #0x8                // =8
    1070:      	mov	w9, #0x71               // =113
    1074:      	add	x10, sp, #0x40
    1078:      	add	x0, sp, #0x40
    107c:      	mov	w1, #0x8                // =8
    1080:      	blr	x9
    1084:      	ldr	x22, [sp, #0x40]
    1088:      	cbz	x22, 0x1768 <event_execve+0x1768>
    108c:      	add	x2, x22, #0x8d4
    1090:      	mov	w8, #0x4                // =4
    1094:      	mov	w9, #0x71               // =113
    1098:      	add	x10, sp, #0xb8
    109c:      	add	x0, sp, #0xb8
    10a0:      	mov	w1, #0x4                // =4
    10a4:      	blr	x9
    10a8:      	ldr	w8, [sp, #0xb8]
    10ac:      	mov	x24, x21
    10b0:      	cmp	w8, w23
    10b4:      	b.eq	0x176c <event_execve+0x176c>
    10b8:      	add	x2, x22, #0x8e0
    10bc:      	mov	w8, #0x8                // =8
    10c0:      	mov	w9, #0x71               // =113
    10c4:      	add	x10, sp, #0x40
    10c8:      	add	x0, sp, #0x40
    10cc:      	mov	w1, #0x8                // =8
    10d0:      	blr	x9
    10d4:      	ldr	x22, [sp, #0x40]
    10d8:      	b	0x176c <event_execve+0x176c>
    10dc:      	str	wzr, [sp, #0xa8]
    10e0:      	adrp	x0, 0x1000 <event_execve+0x1000>
    10e4:      	mov	w8, #0x1                // =1
    10e8:      	add	x9, sp, #0xa8
    10ec:      	ldr	x0, [x0]
    10f0:      	add	x1, sp, #0xa8
    10f4:      	blr	x8
    10f8:      	cbz	x0, 0x15b8 <event_execve+0x15b8>
    10fc:      	mov	w8, #0x18               // =24
    1100:      	mov	x23, x0
    1104:      	str	w8, [x0]
    1108:      	mov	w8, #0xe                // =14
    110c:      	blr	x8
    1110:      	mov	x19, x23
    1114:      	cmn	x0, #0x16
    1118:      	str	x0, [x19, #0x10]!
    111c:      	b.ne	0x1144 <event_execve+0x1144>
    1120:      	add	x2, x25, #0xe8
    1124:      	mov	w8, #0x8                // =8
    1128:      	mov	w9, #0x4                // =4
    112c:      	add	x10, sp, #0x40
    1130:      	add	x0, sp, #0x40
    1134:      	mov	w1, #0x8                // =8
    1138:      	blr	x9
    113c:      	ldr	x8, [sp, #0x40]
    1140:      	str	x8, [x19]
    1144:      	str	x29, [sp, #0x30]
    1148:      	mov	w8, #0x5                // =5
    114c:      	blr	x8
    1150:      	str	x0, [x23, #0x18]
    1154:      	ldp	x8, x9, [x19]
    1158:      	stp	x8, x9, [x21, #0x150]
    115c:      	tbnz	x24, #0x3f, 0x15c0 <event_execve+0x15c0>
    1160:      	mov	w8, #0x7fe0             // =32736
    1164:      	add	x0, x23, #0x20
    1168:      	mov	x2, x22
    116c:      	cmp	x24, x8
    1170:      	csel	x8, x24, x8, lo
    1174:      	and	x29, x8, #0x3fff
    1178:      	mov	w8, #0x4                // =4
    117c:      	str	x0, [sp, #0x28]
    1180:      	mov	w1, w29
    1184:      	blr	x8
    1188:      	tbnz	w0, #0x1f, 0x11b8 <event_execve+0x11b8>
    118c:      	add	w4, w29, #0x20
    1190:      	adrp	x1, 0x1000 <event_execve+0x1000>
    1194:      	mov	w8, #-0x1               // =-1
    1198:      	str	w4, [x23, #0x4]
    119c:      	mov	w9, #0x19               // =25
    11a0:      	mov	x0, x25
    11a4:      	mov	w2, #-0x1               // =-1
    11a8:      	ldr	x1, [x1]
    11ac:      	mov	x3, x23
    11b0:      	blr	x9
    11b4:      	tbz	w0, #0x1f, 0x11bc <event_execve+0x11bc>
    11b8:      	sxtw	x29, w0
    11bc:      	tbnz	w29, #0x1f, 0x1600 <event_execve+0x1600>
    11c0:      	mov	x19, x25
    11c4:      	subs	x8, x24, x29
    11c8:      	mov	x25, x24
    11cc:      	b.eq	0x16b0 <event_execve+0x16b0>
    11d0:      	b.mi	0x15c0 <event_execve+0x15c0>
    11d4:      	mov	w9, #0x7fe0             // =32736
    11d8:      	ldr	x0, [sp, #0x28]
    11dc:      	add	x2, x29, x22
    11e0:      	cmp	x8, x9
    11e4:      	csel	x8, x8, x9, lo
    11e8:      	and	x25, x8, #0x3fff
    11ec:      	mov	w8, #0x4                // =4
    11f0:      	mov	w1, w25
    11f4:      	blr	x8
    11f8:      	tbnz	w0, #0x1f, 0x1228 <event_execve+0x1228>
    11fc:      	add	w4, w25, #0x20
    1200:      	adrp	x1, 0x1000 <event_execve+0x1000>
    1204:      	mov	w8, #-0x1               // =-1
    1208:      	str	w4, [x23, #0x4]
    120c:      	mov	w9, #0x19               // =25
    1210:      	mov	x0, x19
    1214:      	mov	w2, #-0x1               // =-1
    1218:      	ldr	x1, [x1]
    121c:      	mov	x3, x23
    1220:      	blr	x9
    1224:      	tbz	w0, #0x1f, 0x122c <event_execve+0x122c>
    1228:      	sxtw	x25, w0
    122c:      	tbnz	w25, #0x1f, 0x1604 <event_execve+0x1604>
    1230:      	add	x29, x25, x29
    1234:      	mov	x25, x24
    1238:      	subs	x8, x24, x29
    123c:      	b.eq	0x16b0 <event_execve+0x16b0>
    1240:      	b.mi	0x15c0 <event_execve+0x15c0>
    1244:      	mov	w9, #0x7fe0             // =32736
    1248:      	ldr	x0, [sp, #0x28]
    124c:      	add	x2, x29, x22
    1250:      	cmp	x8, x9
    1254:      	csel	x8, x8, x9, lo
    1258:      	and	x25, x8, #0x3fff
    125c:      	mov	w8, #0x4                // =4
    1260:      	mov	w1, w25
    1264:      	blr	x8
    1268:      	tbnz	w0, #0x1f, 0x1298 <event_execve+0x1298>
    126c:      	add	w4, w25, #0x20
    1270:      	adrp	x1, 0x1000 <event_execve+0x1000>
    1274:      	mov	w8, #-0x1               // =-1
    1278:      	str	w4, [x23, #0x4]
    127c:      	mov	w9, #0x19               // =25
    1280:      	mov	x0, x19
    1284:      	mov	w2, #-0x1               // =-1
    1288:      	ldr	x1, [x1]
    128c:      	mov	x3, x23
    1290:      	blr	x9
    1294:      	tbz	w0, #0x1f, 0x129c <event_execve+0x129c>
    1298:      	sxtw	x25, w0
    129c:      	tbnz	w25, #0x1f, 0x1604 <event_execve+0x1604>
    12a0:      	add	x29, x25, x29
    12a4:      	mov	x25, x24
    12a8:      	subs	x8, x24, x29
    12ac:      	b.eq	0x16b0 <event_execve+0x16b0>
    12b0:      	b.mi	0x15c0 <event_execve+0x15c0>
    12b4:      	mov	w9, #0x7fe0             // =32736
    12b8:      	ldr	x0, [sp, #0x28]
    12bc:      	add	x2, x29, x22
    12c0:      	cmp	x8, x9
    12c4:      	csel	x8, x8, x9, lo
    12c8:      	and	x25, x8, #0x3fff
    12cc:      	mov	w8, #0x4                // =4
    12d0:      	mov	w1, w25
    12d4:      	blr	x8
    12d8:      	tbnz	w0, #0x1f, 0x1308 <event_execve+0x1308>
    12dc:      	add	w4, w25, #0x20
    12e0:      	adrp	x1, 0x1000 <event_execve+0x1000>
    12e4:      	mov	w8, #-0x1               // =-1
    12e8:      	str	w4, [x23, #0x4]
    12ec:      	mov	w9, #0x19               // =25
    12f0:      	mov	x0, x19
    12f4:      	mov	w2, #-0x1               // =-1
    12f8:      	ldr	x1, [x1]
    12fc:      	mov	x3, x23
    1300:      	blr	x9
    1304:      	tbz	w0, #0x1f, 0x130c <event_execve+0x130c>
    1308:      	sxtw	x25, w0
    130c:      	tbnz	w25, #0x1f, 0x1604 <event_execve+0x1604>
    1310:      	add	x29, x25, x29
    1314:      	mov	x25, x24
    1318:      	subs	x8, x24, x29
    131c:      	b.eq	0x16b0 <event_execve+0x16b0>
    1320:      	b.mi	0x15c0 <event_execve+0x15c0>
    1324:      	mov	w9, #0x7fe0             // =32736
    1328:      	ldr	x0, [sp, #0x28]
    132c:      	add	x2, x29, x22
    1330:      	cmp	x8, x9
    1334:      	csel	x8, x8, x9, lo
    1338:      	and	x25, x8, #0x3fff
    133c:      	mov	w8, #0x4                // =4
    1340:      	mov	w1, w25
    1344:      	blr	x8
    1348:      	tbnz	w0, #0x1f, 0x1378 <event_execve+0x1378>
    134c:      	add	w4, w25, #0x20
    1350:      	adrp	x1, 0x1000 <event_execve+0x1000>
    1354:      	mov	w8, #-0x1               // =-1
    1358:      	str	w4, [x23, #0x4]
    135c:      	mov	w9, #0x19               // =25
    1360:      	mov	x0, x19
    1364:      	mov	w2, #-0x1               // =-1
    1368:      	ldr	x1, [x1]
    136c:      	mov	x3, x23
    1370:      	blr	x9
    1374:      	tbz	w0, #0x1f, 0x137c <event_execve+0x137c>
    1378:      	sxtw	x25, w0
    137c:      	tbnz	w25, #0x1f, 0x1604 <event_execve+0x1604>
    1380:      	add	x29, x25, x29
    1384:      	mov	x25, x24
    1388:      	subs	x8, x24, x29
    138c:      	b.eq	0x16b0 <event_execve+0x16b0>
    1390:      	b.mi	0x15c0 <event_execve+0x15c0>
    1394:      	mov	w9, #0x7fe0             // =32736
    1398:      	ldr	x0, [sp, #0x28]
    139c:      	add	x2, x29, x22
    13a0:      	cmp	x8, x9
    13a4:      	csel	x8, x8, x9, lo
    13a8:      	and	x25, x8, #0x3fff
    13ac:      	mov	w8, #0x4                // =4
    13b0:      	mov	w1, w25
    13b4:      	blr	x8
    13b8:      	tbnz	w0, #0x1f, 0x13e8 <event_execve+0x13e8>
    13bc:      	add	w4, w25, #0x20
    13c0:      	adrp	x1, 0x1000 <event_execve+0x1000>
    13c4:      	mov	w8, #-0x1               // =-1
    13c8:      	str	w4, [x23, #0x4]
    13cc:      	mov	w9, #0x19               // =25
    13d0:      	mov	x0, x19
    13d4:      	mov	w2, #-0x1               // =-1
    13d8:      	ldr	x1, [x1]
    13dc:      	mov	x3, x23
    13e0:      	blr	x9
    13e4:      	tbz	w0, #0x1f, 0x13ec <event_execve+0x13ec>
    13e8:      	sxtw	x25, w0
    13ec:      	tbnz	w25, #0x1f, 0x1604 <event_execve+0x1604>
    13f0:      	add	x29, x25, x29
    13f4:      	mov	x25, x24
    13f8:      	subs	x8, x24, x29
    13fc:      	b.eq	0x16b0 <event_execve+0x16b0>
    1400:      	b.mi	0x15c0 <event_execve+0x15c0>
    1404:      	mov	w9, #0x7fe0             // =32736
    1408:      	ldr	x0, [sp, #0x28]
    140c:      	add	x2, x29, x22
    1410:      	cmp	x8, x9
    1414:      	csel	x8, x8, x9, lo
    1418:      	and	x25, x8, #0x3fff
    141c:      	mov	w8, #0x4                // =4
    1420:      	mov	w1, w25
    1424:      	blr	x8
    1428:      	tbnz	w0, #0x1f, 0x1458 <event_execve+0x1458>
    142c:      	add	w4, w25, #0x20
    1430:      	adrp	x1, 0x1000 <event_execve+0x1000>
    1434:      	mov	w8, #-0x1               // =-1
    1438:      	str	w4, [x23, #0x4]
    143c:      	mov	w9, #0x19               // =25
    1440:      	mov	x0, x19
    1444:      	mov	w2, #-0x1               // =-1
    1448:      	ldr	x1, [x1]
    144c:      	mov	x3, x23
    1450:      	blr	x9
    1454:      	tbz	w0, #0x1f, 0x145c <event_execve+0x145c>
    1458:      	sxtw	x25, w0
    145c:      	tbnz	w25, #0x1f, 0x1604 <event_execve+0x1604>
    1460:      	add	x29, x25, x29
    1464:      	mov	x25, x24
    1468:      	subs	x8, x24, x29
    146c:      	b.eq	0x16b0 <event_execve+0x16b0>
    1470:      	b.mi	0x15c0 <event_execve+0x15c0>
    1474:      	mov	w9, #0x7fe0             // =32736
    1478:      	ldr	x0, [sp, #0x28]
    147c:      	add	x2, x29, x22
    1480:      	cmp	x8, x9
    1484:      	csel	x8, x8, x9, lo
    1488:      	and	x25, x8, #0x3fff
    148c:      	mov	w8, #0x4                // =4
    1490:      	mov	w1, w25
    1494:      	blr	x8
    1498:      	tbnz	w0, #0x1f, 0x14c8 <event_execve+0x14c8>
    149c:      	add	w4, w25, #0x20
    14a0:      	adrp	x1, 0x1000 <event_execve+0x1000>
    14a4:      	mov	w8, #-0x1               // =-1
    14a8:      	str	w4, [x23, #0x4]
    14ac:      	mov	w9, #0x19               // =25
    14b0:      	mov	x0, x19
    14b4:      	mov	w2, #-0x1               // =-1
    14b8:      	ldr	x1, [x1]
    14bc:      	mov	x3, x23
    14c0:      	blr	x9
    14c4:      	tbz	w0, #0x1f, 0x14cc <event_execve+0x14cc>
    14c8:      	sxtw	x25, w0
    14cc:      	tbnz	w25, #0x1f, 0x1604 <event_execve+0x1604>
    14d0:      	add	x29, x25, x29
    14d4:      	mov	x25, x24
    14d8:      	subs	x8, x24, x29
    14dc:      	b.eq	0x16b0 <event_execve+0x16b0>
    14e0:      	b.mi	0x15c0 <event_execve+0x15c0>
    14e4:      	mov	w9, #0x7fe0             // =32736
    14e8:      	ldr	x0, [sp, #0x28]
    14ec:      	add	x2, x29, x22
    14f0:      	cmp	x8, x9
    14f4:      	csel	x8, x8, x9, lo
    14f8:      	and	x25, x8, #0x3fff
    14fc:      	mov	w8, #0x4                // =4
    1500:      	mov	w1, w25
    1504:      	blr	x8
    1508:      	tbnz	w0, #0x1f, 0x1538 <event_execve+0x1538>
    150c:      	add	w4, w25, #0x20
    1510:      	adrp	x1, 0x1000 <event_execve+0x1000>
    1514:      	mov	w8, #-0x1               // =-1
    1518:      	str	w4, [x23, #0x4]
    151c:      	mov	w9, #0x19               // =25
    1520:      	mov	x0, x19
    1524:      	mov	w2, #-0x1               // =-1
    1528:      	ldr	x1, [x1]
    152c:      	mov	x3, x23
    1530:      	blr	x9
    1534:      	tbz	w0, #0x1f, 0x153c <event_execve+0x153c>
    1538:      	sxtw	x25, w0
    153c:      	tbnz	w25, #0x1f, 0x1604 <event_execve+0x1604>
    1540:      	add	x29, x25, x29
    1544:      	mov	x25, x24
    1548:      	subs	x8, x24, x29
    154c:      	b.eq	0x16b0 <event_execve+0x16b0>
    1550:      	b.mi	0x15c0 <event_execve+0x15c0>
    1554:      	mov	w9, #0x7fe0             // =32736
    1558:      	ldr	x0, [sp, #0x28]
    155c:      	add	x2, x29, x22
    1560:      	cmp	x8, x9
    1564:      	csel	x8, x8, x9, lo
    1568:      	and	x25, x8, #0x3fff
    156c:      	mov	w8, #0x4                // =4
    1570:      	mov	w1, w25
    1574:      	blr	x8
    1578:      	tbnz	w0, #0x1f, 0x15a8 <event_execve+0x15a8>
    157c:      	add	w4, w25, #0x20
    1580:      	adrp	x1, 0x1000 <event_execve+0x1000>
    1584:      	mov	w8, #-0x1               // =-1
    1588:      	str	w4, [x23, #0x4]
    158c:      	mov	w9, #0x19               // =25
    1590:      	mov	x0, x19
    1594:      	mov	w2, #-0x1               // =-1
    1598:      	ldr	x1, [x1]
    159c:      	mov	x3, x23
    15a0:      	blr	x9
    15a4:      	tbz	w0, #0x1f, 0x15ac <event_execve+0x15ac>
    15a8:      	sxtw	x25, w0
    15ac:      	tbnz	w25, #0x1f, 0x1604 <event_execve+0x1604>
    15b0:      	add	x25, x25, x29
    15b4:      	b	0x16b0 <event_execve+0x16b0>
    15b8:      	mov	w24, wzr
    15bc:      	b	0x16f0 <event_execve+0x16f0>
    15c0:      	mov	x25, #-0x1              // =-1
    15c4:      	b	0x1604 <event_execve+0x1604>
    15c8:      	str	w19, [sp, #0xa8]
    15cc:      	mov	x3, xzr
    15d0:      	mov	w8, #0x2                // =2
    15d4:      	add	x9, sp, #0x40
    15d8:      	add	x10, sp, #0xa8
    15dc:      	add	x1, sp, #0x40
    15e0:      	add	x2, sp, #0xa8
    15e4:      	mov	x0, x23
    15e8:      	blr	x8
    15ec:      	tbz	w22, #0x1f, 0x16f0 <event_execve+0x16f0>
    15f0:      	ldr	w8, [x20, #0x15c]
    15f4:      	mov	w24, wzr
    15f8:      	orr	w8, w8, #0x200
    15fc:      	b	0x16ec <event_execve+0x16ec>
    1600:      	mov	x25, x29
    1604:      	str	wzr, [sp, #0x40]
    1608:      	adrp	x0, 0x1000 <event_execve+0x1000>
    160c:      	mov	w8, #0x1                // =1
    1610:      	add	x9, sp, #0x40
    1614:      	ldr	x0, [x0]
    1618:      	add	x1, sp, #0x40
    161c:      	blr	x8
    1620:      	cbz	x0, 0x16b0 <event_execve+0x16b0>
    1624:      	cmn	x25, #0xc
    1628:      	b.gt	0x164c <event_execve+0x164c>
    162c:      	cmn	x25, #0x1c
    1630:      	b.eq	0x1678 <event_execve+0x1678>
    1634:      	cmn	x25, #0x16
    1638:      	b.eq	0x1690 <event_execve+0x1690>
    163c:      	cmn	x25, #0x10
    1640:      	b.ne	0x1688 <event_execve+0x1688>
    1644:      	add	x8, x0, #0x558
    1648:      	b	0x16a0 <event_execve+0x16a0>
    164c:      	cmn	x25, #0xb
    1650:      	b.eq	0x1680 <event_execve+0x1680>
    1654:      	cmn	x25, #0x7
    1658:      	b.eq	0x1698 <event_execve+0x1698>
    165c:      	cmn	x25, #0x2
    1660:      	b.ne	0x1688 <event_execve+0x1688>
    1664:      	add	x8, x0, #0x548
    1668:      	b	0x16a0 <event_execve+0x16a0>
    166c:      	ldr	x25, [sp, #0xd8]
    1670:      	mov	x21, x0
    1674:      	b	0x72c <event_execve+0x72c>
    1678:      	add	x8, x0, #0x568
    167c:      	b	0x16a0 <event_execve+0x16a0>
    1680:      	add	x8, x0, #0x570
    1684:      	b	0x16a0 <event_execve+0x16a0>
    1688:      	add	x8, x0, #0x540
    168c:      	b	0x16a0 <event_execve+0x16a0>
    1690:      	add	x8, x0, #0x560
    1694:      	b	0x16a0 <event_execve+0x16a0>
    1698:      	add	x8, x0, #0x550
    169c:      	nop
    16a0:      	ldaxr	x9, [x8]
    16a4:      	add	x9, x9, #0x1
    16a8:      	stlxr	w10, x9, [x8]
    16ac:      	cbnz	w10, 0x16a0 <event_execve+0x16a0>
    16b0:      	cmn	x24, #0x1
    16b4:      	sub	w8, w24, w25
    16b8:      	asr	w9, w25, #31
    16bc:      	str	wzr, [x21, #0x144]
    16c0:      	ldr	x29, [sp, #0x30]
    16c4:      	mov	w24, #0x20              // =32
    16c8:      	ccmp	w25, #0x0, #0x8, ne
    16cc:      	and	w10, w25, w9
    16d0:      	str	w10, [x21, #0x140]
    16d4:      	csel	w8, wzr, w8, lt
    16d8:      	str	w8, [x21, #0x148]
    16dc:      	bic	w8, w25, w9
    16e0:      	str	w8, [x21, #0x14c]
    16e4:      	ldr	w8, [x20, #0x15c]
    16e8:      	orr	w8, w8, #0x1000000
    16ec:      	str	w8, [x20, #0x15c]
    16f0:      	strh	w24, [x20, #0x17a]
    16f4:      	ldr	w8, [x20, #0x140]
    16f8:      	add	w9, w8, w24
    16fc:      	ldrb	w8, [x20, #0x15d]
    1700:      	str	w9, [x20, #0x140]
    1704:      	tbz	w8, #0x5, 0xa94 <event_execve+0xa94>
    1708:      	b	0xa40 <event_execve+0xa40>
    170c:      	cmn	x8, #0xb
    1710:      	b.eq	0x1734 <event_execve+0x1734>
    1714:      	cmn	x8, #0x7
    1718:      	b.eq	0x174c <event_execve+0x174c>
    171c:      	cmn	x8, #0x2
    1720:      	b.ne	0x173c <event_execve+0x173c>
    1724:      	add	x8, x0, #0x548
    1728:      	b	0x1750 <event_execve+0x1750>
    172c:      	add	x8, x0, #0x568
    1730:      	b	0x1750 <event_execve+0x1750>
    1734:      	add	x8, x0, #0x570
    1738:      	b	0x1750 <event_execve+0x1750>
    173c:      	add	x8, x0, #0x540
    1740:      	b	0x1750 <event_execve+0x1750>
    1744:      	add	x8, x0, #0x560
    1748:      	b	0x1750 <event_execve+0x1750>
    174c:      	add	x8, x0, #0x550
    1750:      	ldaxr	x9, [x8]
    1754:      	add	x9, x9, #0x1
    1758:      	stlxr	w10, x9, [x8]
    175c:      	cbnz	w10, 0x1750 <event_execve+0x1750>
    1760:      	add	x21, x23, x21
    1764:      	b	0x72c <event_execve+0x72c>
    1768:      	mov	x24, x21
    176c:      	ldr	w8, [sp, #0xb8]
    1770:      	mov	w9, #0x4                // =4
    1774:      	add	x10, sp, #0x88
    1778:      	add	x0, sp, #0x88
    177c:      	mov	w1, #0x8                // =8
    1780:      	cmp	w8, w23
    1784:      	csel	x8, x22, xzr, eq
    1788:      	add	x2, x8, #0xb30
    178c:      	mov	w8, #0x8                // =8
    1790:      	blr	x9
    1794:      	ldr	x21, [sp, #0x88]
    1798:      	cbz	x21, 0x184c <event_execve+0x184c>
    179c:      	str	wzr, [sp, #0x94]
    17a0:      	adrp	x0, 0x1000 <event_execve+0x1000>
    17a4:      	mov	w8, #0x1                // =1
    17a8:      	add	x9, sp, #0x94
    17ac:      	ldr	x0, [x0]
    17b0:      	add	x1, sp, #0x94
    17b4:      	blr	x8
    17b8:      	cbz	x0, 0x1860 <event_execve+0x1860>
    17bc:      	add	x8, x21, #0x28
    17c0:      	mov	x29, x0
    17c4:      	stp	x8, x24, [sp, #0x10]
    17c8:      	add	x8, x0, #0x1, lsl #12   // =0x1000
    17cc:      	str	x8, [sp, #0x28]
    17d0:      	mov	w8, #0x23               // =35
    17d4:      	blr	x8
    17d8:      	add	x2, x0, #0xb30
    17dc:      	mov	w24, #0x8               // =8
    17e0:      	add	x8, sp, #0x98
    17e4:      	mov	w9, #0x4                // =4
    17e8:      	add	x0, sp, #0x98
    17ec:      	mov	w1, #0x8                // =8
    17f0:      	mov	w23, #0x4               // =4
    17f4:      	blr	x9
    17f8:      	ldr	x19, [sp, #0x98]
    17fc:      	add	x25, x21, #0x30
    1800:      	mov	w9, #0x4                // =4
    1804:      	add	x0, sp, #0xa0
    1808:      	mov	w1, #0x8                // =8
    180c:      	mov	x2, x25
    1810:      	add	x8, x19, #0x18
    1814:      	str	x8, [sp, #0x8]
    1818:      	add	x8, sp, #0xa0
    181c:      	blr	x9
    1820:      	ldr	x22, [sp, #0xa0]
    1824:      	add	x21, sp, #0x40
    1828:      	add	x0, sp, #0x40
    182c:      	mov	w1, #0x8                // =8
    1830:      	add	x2, x22, #0x10
    1834:      	blr	x23
    1838:      	ldr	x8, [sp, #0x40]
    183c:      	cbz	x8, 0x186c <event_execve+0x186c>
    1840:      	ldr	x9, [sp, #0x28]
    1844:      	mov	w8, #0x1000             // =4096
    1848:      	b	0x18b4 <event_execve+0x18b4>
    184c:      	ldr	w9, [x20, #0x15c]
    1850:      	ldr	x29, [sp, #0x30]
    1854:      	mov	w8, wzr
    1858:      	orr	w9, w9, #0x2000
    185c:      	b	0x1b10 <event_execve+0x1b10>
    1860:      	ldr	x29, [sp, #0x30]
    1864:      	mov	w8, wzr
    1868:      	b	0x1b14 <event_execve+0x1b14>
    186c:      	add	x2, x22, #0x18
    1870:      	mov	w8, #0x8                // =8
    1874:      	mov	w9, #0x4                // =4
    1878:      	add	x10, sp, #0x40
    187c:      	add	x0, sp, #0x40
    1880:      	mov	w1, #0x8                // =8
    1884:      	blr	x9
    1888:      	ldr	x8, [sp, #0x40]
    188c:      	cmp	x8, x22
    1890:      	b.eq	0x1840 <event_execve+0x1840>
    1894:      	mov	w8, #0x2964             // =10596
    1898:      	add	x9, x29, #0xff6
    189c:      	strh	w8, [x29, #0xffe]
    18a0:      	adrp	x8, 0x1000 <event_execve+0x1000>
    18a4:      	add	x8, x8, #0x0
    18a8:      	ldr	x8, [x8]
    18ac:      	str	x8, [x9]
    18b0:      	mov	w8, #0xff6              // =4086
    18b4:      	stp	xzr, xzr, [sp, #0x40]
    18b8:      	add	x2, x19, #0x20
    18bc:      	mov	w19, #0x8               // =8
    18c0:      	add	x0, sp, #0x40
    18c4:      	mov	w1, #0x8                // =8
    18c8:      	add	x22, x21, #0x8
    18cc:      	stp	x29, xzr, [sp, #0x50]
    18d0:      	add	x24, x21, #0x18
    18d4:      	add	x29, x21, #0x20
    18d8:      	stp	xzr, xzr, [sp, #0x60]
    18dc:      	mov	w23, #0x4               // =4
    18e0:      	str	x9, [sp, #0x28]
    18e4:      	str	x9, [sp, #0x70]
    18e8:      	str	w8, [sp, #0x78]
    18ec:      	mov	w8, #0x4                // =4
    18f0:      	strb	wzr, [sp, #0x7c]
    18f4:      	blr	x8
    18f8:      	ldr	x2, [sp, #0x8]
    18fc:      	mov	w8, #0x4                // =4
    1900:      	mov	x0, x22
    1904:      	mov	w1, #0x8                // =8
    1908:      	blr	x8
    190c:      	mov	w8, #0x4                // =4
    1910:      	mov	x0, x24
    1914:      	mov	w1, #0x8                // =8
    1918:      	str	x24, [sp, #0x8]
    191c:      	mov	x2, x25
    1920:      	blr	x8
    1924:      	ldr	x2, [sp, #0x10]
    1928:      	mov	x0, x29
    192c:      	mov	w1, #0x8                // =8
    1930:      	blr	x23
    1934:      	ldp	x19, x23, [sp, #0x58]
    1938:      	sub	x8, x23, #0x20
    193c:      	ldr	x29, [sp, #0x30]
    1940:      	str	x8, [sp, #0x68]
    1944:      	ldr	x8, [sp, #0x40]
    1948:      	cmp	x19, x8
    194c:      	b.ne	0x19a8 <event_execve+0x19a8>
    1950:      	ldr	x8, [sp, #0x48]
    1954:      	cmp	x23, x8
    1958:      	b.ne	0x19a8 <event_execve+0x19a8>
    195c:      	mov	w8, #0x1                // =1
    1960:      	strb	w8, [sp, #0x7c]
    1964:      	ldr	x8, [sp, #0x70]
    1968:      	ldr	x2, [sp, #0x28]
    196c:      	cmp	x8, x2
    1970:      	ldr	x24, [sp, #0x18]
    1974:      	b.eq	0x1ac8 <event_execve+0x1ac8>
    1978:      	ldrb	w9, [sp, #0x7c]
    197c:      	ldr	w10, [sp, #0x78]
    1980:      	mov	w11, #0x1000            // =4096
    1984:      	cmp	w9, #0x0
    1988:      	sub	w11, w11, w10
    198c:      	cset	w9, eq
    1990:      	cmp	w10, #0x0
    1994:      	csel	w21, w11, w10, gt
    1998:      	cbz	x8, 0x1b14 <event_execve+0x1b14>
    199c:      	lsl	w19, w9, #1
    19a0:      	mov	x2, x8
    19a4:      	b	0x1ad0 <event_execve+0x1ad0>
    19a8:      	mov	w8, #0x8                // =8
    19ac:      	mov	w9, #0x4                // =4
    19b0:      	add	x10, sp, #0xa8
    19b4:      	add	x0, sp, #0xa8
    19b8:      	mov	w1, #0x8                // =8
    19bc:      	mov	x2, x23
    19c0:      	blr	x9
    19c4:      	ldr	x8, [sp, #0xa8]
    19c8:      	add	x21, sp, #0xb8
    19cc:      	cmp	x19, x8
    19d0:      	b.eq	0x1f54 <event_execve+0x1f54>
    19d4:      	add	x24, x19, #0x18
    19d8:      	mov	w8, #0x8                // =8
    19dc:      	mov	w9, #0x4                // =4
    19e0:      	add	x10, sp, #0xc8
    19e4:      	add	x0, sp, #0xc8
    19e8:      	mov	w1, #0x8                // =8
    19ec:      	mov	x2, x24
    19f0:      	blr	x9
    19f4:      	ldr	x8, [x21, #0x10]
    19f8:      	cmp	x8, x19
    19fc:      	b.eq	0x1f54 <event_execve+0x1f54>
    1a00:      	mov	w8, #0x8                // =8
    1a04:      	add	x9, sp, #0xb0
    1a08:      	mov	w10, #0x4               // =4
    1a0c:      	add	x0, sp, #0xb0
    1a10:      	mov	w1, #0x8                // =8
    1a14:      	mov	x2, x24
    1a18:      	add	x22, sp, #0xb8
    1a1c:      	mov	w21, #0x4               // =4
    1a20:      	blr	x10
    1a24:      	add	x2, x19, #0x20
    1a28:      	mov	w8, #0x10               // =16
    1a2c:      	add	x9, sp, #0xb8
    1a30:      	add	x0, sp, #0xb8
    1a34:      	mov	w1, #0x10               // =16
    1a38:      	blr	x21
    1a3c:      	ldr	w19, [sp, #0xbc]
    1a40:      	ldr	x8, [sp, #0x50]
    1a44:      	ldr	x9, [sp, #0x70]
    1a48:      	sub	x11, x9, x8
    1a4c:      	ldr	w21, [sp, #0x78]
    1a50:      	subs	w9, w19, w21
    1a54:      	ldr	x10, [x22, #0x8]
    1a58:      	csel	w12, wzr, w9, lo
    1a5c:      	cmp	w21, w19
    1a60:      	csel	w9, w21, w19, lo
    1a64:      	cinc	w13, w9, hi
    1a68:      	sub	w14, w21, w13
    1a6c:      	subs	x11, x11, x13
    1a70:      	str	w14, [sp, #0x78]
    1a74:      	b.lo	0x1964 <event_execve+0x1964>
    1a78:      	cmp	x11, #0xfff
    1a7c:      	b.hi	0x1964 <event_execve+0x1964>
    1a80:      	add	x2, x10, x12
    1a84:      	cmp	w21, w19
    1a88:      	b.ls	0x1a94 <event_execve+0x1a94>
    1a8c:      	mov	w10, #0x2f              // =47
    1a90:      	strb	w10, [x8, x11]
    1a94:      	add	x22, x8, x11
    1a98:      	cmp	w21, w19
    1a9c:      	and	w1, w9, #0xff
    1aa0:      	mov	w8, #0x4                // =4
    1aa4:      	cinc	x0, x22, hi
    1aa8:      	blr	x8
    1aac:      	cmp	w21, w19
    1ab0:      	str	x22, [sp, #0x70]
    1ab4:      	b.ls	0x1964 <event_execve+0x1964>
    1ab8:      	ldr	x19, [sp, #0xb0]
    1abc:      	ldp	x2, x22, [sp, #0x60]
    1ac0:      	str	x19, [sp, #0x58]
    1ac4:      	b	0x1fa8 <event_execve+0x1fa8>
    1ac8:      	mov	w21, wzr
    1acc:      	mov	w19, wzr
    1ad0:      	ldr	w8, [sp, #0x24]
    1ad4:      	ands	w1, w21, #0xfff
    1ad8:      	and	w8, w8, #0x3ff
    1adc:      	add	x0, x24, x8
    1ae0:      	mov	w8, #0x4                // =4
    1ae4:      	blr	x8
    1ae8:      	ldr	w9, [x20, #0x15c]
    1aec:      	ands	w8, w21, #0xfff
    1af0:      	strh	w8, [x20, #0x17c]
    1af4:      	orr	w10, w9, #0x1000
    1af8:      	csel	w9, w10, w9, eq
    1afc:      	cmp	w19, #0x0
    1b00:      	orr	w10, w9, #0x400000
    1b04:      	csel	w9, w9, w10, eq
    1b08:      	mov	w10, #-0x2401           // =-9217
    1b0c:      	and	w9, w9, w10
    1b10:      	str	w9, [x20, #0x15c]
    1b14:      	ldr	w9, [x24]
    1b18:      	add	w8, w9, w8
    1b1c:      	mov	w9, #0x5                // =5
    1b20:      	add	x22, x29, #0xae0
    1b24:      	strh	w9, [x20]
    1b28:      	ldr	x9, [x20, #0x170]
    1b2c:      	str	w8, [x20, #0x140]
    1b30:      	add	w8, w8, #0x140
    1b34:      	mov	w24, #0x8               // =8
    1b38:      	add	x0, sp, #0x40
    1b3c:      	str	w8, [x20, #0x4]
    1b40:      	add	x8, sp, #0x40
    1b44:      	mov	w1, #0x8                // =8
    1b48:      	mov	x2, x22
    1b4c:      	str	x9, [x20, #0x8]
    1b50:      	mov	w9, #0x4                // =4
    1b54:      	add	x23, x20, #0xb8
    1b58:      	mov	w21, #0x4               // =4
    1b5c:      	blr	x9
    1b60:      	ldr	x8, [sp, #0x40]
    1b64:      	mov	w9, #0x4                // =4
    1b68:      	mov	x0, x23
    1b6c:      	mov	w1, #0x4                // =4
    1b70:      	add	x8, x8, #0x8
    1b74:      	ldr	x8, [sp, #0x40]
    1b78:      	add	x2, x8, #0x8
    1b7c:      	blr	x9
    1b80:      	ldr	x8, [sp, #0x40]
    1b84:      	add	x0, x20, #0xbc
    1b88:      	mov	w9, #0x4                // =4
    1b8c:      	mov	w1, #0x4                // =4
    1b90:      	add	x8, x8, #0xc
    1b94:      	ldr	x8, [sp, #0x40]
    1b98:      	add	x2, x8, #0xc
    1b9c:      	blr	x9
    1ba0:      	ldr	x8, [sp, #0x40]
    1ba4:      	add	x0, x20, #0xc8
    1ba8:      	mov	w9, #0x4                // =4
    1bac:      	mov	w1, #0x4                // =4
    1bb0:      	add	x8, x8, #0x18
    1bb4:      	ldr	x8, [sp, #0x40]
    1bb8:      	add	x2, x8, #0x18
    1bbc:      	blr	x9
    1bc0:      	ldr	x8, [sp, #0x40]
    1bc4:      	add	x0, x20, #0xcc
    1bc8:      	mov	w9, #0x4                // =4
    1bcc:      	mov	w1, #0x4                // =4
    1bd0:      	add	x8, x8, #0x1c
    1bd4:      	ldr	x8, [sp, #0x40]
    1bd8:      	add	x2, x8, #0x1c
    1bdc:      	blr	x9
    1be0:      	ldr	x8, [sp, #0x40]
    1be4:      	add	x0, x20, #0xc0
    1be8:      	mov	w9, #0x4                // =4
    1bec:      	mov	w1, #0x4                // =4
    1bf0:      	add	x8, x8, #0x10
    1bf4:      	ldr	x8, [sp, #0x40]
    1bf8:      	add	x2, x8, #0x10
    1bfc:      	blr	x9
    1c00:      	ldr	x8, [sp, #0x40]
    1c04:      	add	x0, x20, #0xc4
    1c08:      	mov	w9, #0x4                // =4
    1c0c:      	mov	w1, #0x4                // =4
    1c10:      	add	x8, x8, #0x14
    1c14:      	ldr	x8, [sp, #0x40]
    1c18:      	add	x2, x8, #0x14
    1c1c:      	blr	x9
    1c20:      	ldr	x8, [sp, #0x40]
    1c24:      	add	x0, x20, #0xd0
    1c28:      	mov	w9, #0x4                // =4
    1c2c:      	mov	w1, #0x4                // =4
    1c30:      	add	x8, x8, #0x20
    1c34:      	ldr	x8, [sp, #0x40]
    1c38:      	add	x2, x8, #0x20
    1c3c:      	blr	x9
    1c40:      	ldr	x8, [sp, #0x40]
    1c44:      	add	x0, x20, #0xd4
    1c48:      	mov	w9, #0x4                // =4
    1c4c:      	mov	w1, #0x4                // =4
    1c50:      	add	x8, x8, #0x24
    1c54:      	ldr	x8, [sp, #0x40]
    1c58:      	add	x2, x8, #0x24
    1c5c:      	blr	x9
    1c60:      	ldr	x8, [sp, #0x40]
    1c64:      	add	x0, x20, #0xd8
    1c68:      	mov	w9, #0x4                // =4
    1c6c:      	mov	w1, #0x4                // =4
    1c70:      	add	x8, x8, #0x28
    1c74:      	ldr	x8, [sp, #0x40]
    1c78:      	add	x2, x8, #0x28
    1c7c:      	blr	x9
    1c80:      	ldr	x19, [sp, #0x40]
    1c84:      	add	x0, x20, #0xe8
    1c88:      	mov	w8, #0x4                // =4
    1c8c:      	mov	w1, #0x8                // =8
    1c90:      	add	x23, x20, #0xe0
    1c94:      	add	x2, x19, #0x40
    1c98:      	blr	x8
    1c9c:      	add	x0, x20, #0xf0
    1ca0:      	add	x2, x19, #0x30
    1ca4:      	mov	w8, #0x4                // =4
    1ca8:      	mov	w1, #0x8                // =8
    1cac:      	blr	x8
    1cb0:      	add	x2, x19, #0x38
    1cb4:      	mov	w8, #0x4                // =4
    1cb8:      	mov	x0, x23
    1cbc:      	mov	w1, #0x8                // =8
    1cc0:      	blr	x8
    1cc4:      	ldr	w8, [x20, #0xc8]
    1cc8:      	add	x2, x29, #0xb50
    1ccc:      	mov	w9, #0x4                // =4
    1cd0:      	add	x0, sp, #0xc8
    1cd4:      	str	w8, [x20, #0x154]
    1cd8:      	add	x8, sp, #0xc8
    1cdc:      	mov	w1, #0x8                // =8
    1ce0:      	add	x23, x20, #0x108
    1ce4:      	blr	x9
    1ce8:      	add	x25, sp, #0xb8
    1cec:      	mov	w9, #0x48               // =72
    1cf0:      	add	x10, sp, #0x40
    1cf4:      	ldr	x8, [x25, #0x10]
    1cf8:      	mov	w11, #0x4               // =4
    1cfc:      	add	x0, sp, #0x40
    1d00:      	mov	w1, #0x48               // =72
    1d04:      	ldr	x2, [x25, #0x10]
    1d08:      	blr	x11
    1d0c:      	ldr	x8, [sp, #0x48]
    1d10:      	mov	w9, #0x4                // =4
    1d14:      	mov	x0, x23
    1d18:      	mov	w1, #0x4                // =4
    1d1c:      	add	x8, x8, #0x218
    1d20:      	ldr	x8, [sp, #0x48]
    1d24:      	add	x2, x8, #0x218
    1d28:      	blr	x9
    1d2c:      	ldr	x8, [sp, #0x50]
    1d30:      	add	x0, x20, #0x10c
    1d34:      	mov	w9, #0x4                // =4
    1d38:      	mov	w1, #0x4                // =4
    1d3c:      	add	x8, x8, #0x4d8
    1d40:      	ldr	x8, [sp, #0x50]
    1d44:      	add	x2, x8, #0x4d8
    1d48:      	blr	x9
    1d4c:      	ldr	x8, [sp, #0x58]
    1d50:      	add	x0, x20, #0x110
    1d54:      	mov	w9, #0x4                // =4
    1d58:      	mov	w1, #0x4                // =4
    1d5c:      	add	x8, x8, #0x58
    1d60:      	ldr	x8, [sp, #0x58]
    1d64:      	add	x2, x8, #0x58
    1d68:      	blr	x9
    1d6c:      	str	xzr, [sp, #0xb0]
    1d70:      	add	x2, x29, #0x938
    1d74:      	add	x8, sp, #0xb0
    1d78:      	add	x0, sp, #0xb0
    1d7c:      	mov	w1, #0x8                // =8
    1d80:      	blr	x21
    1d84:      	ldr	x8, [sp, #0xb0]
    1d88:      	cbz	x8, 0x1e0c <event_execve+0x1e0c>
    1d8c:      	str	wzr, [sp, #0xa8]
    1d90:      	add	x8, x8, #0x4
    1d94:      	add	x9, sp, #0xa8
    1d98:      	mov	w10, #0x4               // =4
    1d9c:      	add	x0, sp, #0xa8
    1da0:      	mov	w1, #0x4                // =4
    1da4:      	mov	w19, #0x4               // =4
    1da8:      	ldr	x8, [sp, #0xb0]
    1dac:      	add	x2, x8, #0x4
    1db0:      	blr	x10
    1db4:      	ldr	x8, [sp, #0xb0]
    1db8:      	ldrsw	x9, [sp, #0xa8]
    1dbc:      	add	x10, sp, #0xb8
    1dc0:      	mov	w11, #0x4               // =4
    1dc4:      	add	x0, sp, #0xb8
    1dc8:      	mov	w1, #0x10               // =16
    1dcc:      	add	x8, x8, x9, lsl #4
    1dd0:      	mov	w9, #0x10               // =16
    1dd4:      	add	x8, x8, #0x80
    1dd8:      	ldr	x8, [sp, #0xb0]
    1ddc:      	ldrsw	x9, [sp, #0xa8]
    1de0:      	add	x8, x8, x9, lsl #4
    1de4:      	add	x2, x8, #0x80
    1de8:      	blr	x11
    1dec:      	ldr	x8, [x25, #0x8]
    1df0:      	add	x0, x20, #0x114
    1df4:      	mov	w1, #0x4                // =4
    1df8:      	add	x8, x8, #0x158
    1dfc:      	ldr	x8, [x25, #0x8]
    1e00:      	add	x2, x8, #0x158
    1e04:      	blr	x19
    1e08:      	b	0x1e10 <event_execve+0x1e10>
    1e0c:      	str	wzr, [x20, #0x114]
    1e10:      	ldr	x8, [sp, #0x60]
    1e14:      	add	x0, x20, #0x118
    1e18:      	mov	w9, #0x4                // =4
    1e1c:      	mov	w1, #0x4                // =4
    1e20:      	mov	w21, #0x4               // =4
    1e24:      	add	x8, x8, #0x158
    1e28:      	ldr	x8, [sp, #0x60]
    1e2c:      	add	x2, x8, #0x158
    1e30:      	blr	x9
    1e34:      	ldr	x8, [sp, #0x68]
    1e38:      	add	x0, x20, #0x11c
    1e3c:      	mov	w9, #0x4                // =4
    1e40:      	mov	w1, #0x4                // =4
    1e44:      	add	x8, x8, #0x118
    1e48:      	ldr	x8, [sp, #0x68]
    1e4c:      	add	x2, x8, #0x118
    1e50:      	blr	x9
    1e54:      	ldr	x8, [sp, #0x70]
    1e58:      	add	x0, x20, #0x120
    1e5c:      	mov	w9, #0x4                // =4
    1e60:      	mov	w1, #0x4                // =4
    1e64:      	add	x8, x8, #0x98
    1e68:      	ldr	x8, [sp, #0x70]
    1e6c:      	add	x2, x8, #0x98
    1e70:      	blr	x9
    1e74:      	ldr	x8, [sp, #0x78]
    1e78:      	add	x0, x20, #0x124
    1e7c:      	mov	w9, #0x4                // =4
    1e80:      	mov	w1, #0x4                // =4
    1e84:      	add	x8, x8, #0x98
    1e88:      	ldr	x8, [sp, #0x78]
    1e8c:      	add	x2, x8, #0x98
    1e90:      	blr	x9
    1e94:      	ldr	x8, [sp, #0x80]
    1e98:      	add	x0, x20, #0x128
    1e9c:      	mov	w9, #0x4                // =4
    1ea0:      	mov	w1, #0x4                // =4
    1ea4:      	add	x8, x8, #0x58
    1ea8:      	ldr	x8, [sp, #0x80]
    1eac:      	add	x2, x8, #0x58
    1eb0:      	blr	x9
    1eb4:      	stp	xzr, xzr, [sp, #0xb0]
    1eb8:      	mov	w23, #0x8               // =8
    1ebc:      	add	x8, sp, #0xb8
    1ec0:      	mov	w9, #0x4                // =4
    1ec4:      	add	x0, sp, #0xb8
    1ec8:      	mov	w1, #0x8                // =8
    1ecc:      	mov	x2, x22
    1ed0:      	mov	x19, xzr
    1ed4:      	blr	x9
    1ed8:      	ldr	x8, [sp, #0xb8]
    1edc:      	add	x9, sp, #0xb0
    1ee0:      	mov	w10, #0x4               // =4
    1ee4:      	add	x0, sp, #0xb0
    1ee8:      	mov	w1, #0x8                // =8
    1eec:      	add	x8, x8, #0x90
    1ef0:      	ldr	x8, [sp, #0xb8]
    1ef4:      	add	x2, x8, #0x90
    1ef8:      	blr	x10
    1efc:      	ldr	x8, [sp, #0xb0]
    1f00:      	add	x0, x20, #0x12c
    1f04:      	mov	w1, #0x4                // =4
    1f08:      	add	x8, x8, #0x158
    1f0c:      	ldr	x8, [sp, #0xb0]
    1f10:      	add	x2, x8, #0x158
    1f14:      	blr	x21
    1f18:      	stp	xzr, xzr, [x20, #0x130]
    1f1c:      	adrp	x1, 0x1000 <event_execve+0x1000>
    1f20:      	mov	w8, #0xc                // =12
    1f24:      	mov	w2, wzr
    1f28:      	ldr	x1, [x1]
    1f2c:      	ldr	x0, [sp, #0xd8]
    1f30:      	blr	x8
    1f34:      	ldp	x20, x19, [sp, #0x110]
    1f38:      	mov	w0, wzr
    1f3c:      	ldr	x29, [sp, #0xd0]
    1f40:      	ldp	x22, x21, [sp, #0x100]
    1f44:      	ldp	x24, x23, [sp, #0xf0]
    1f48:      	ldp	x30, x25, [sp, #0xe0]
    1f4c:      	add	sp, sp, #0x120
    1f50:      	ret
    1f54:      	sub	x2, x23, #0x10
    1f58:      	mov	w8, #0x8                // =8
    1f5c:      	mov	w9, #0x4                // =4
    1f60:      	add	x10, sp, #0xc8
    1f64:      	add	x0, sp, #0xc8
    1f68:      	mov	w1, #0x8                // =8
    1f6c:      	blr	x9
    1f70:      	ldr	x8, [sp, #0x68]
    1f74:      	ldr	x9, [x21, #0x10]
    1f78:      	cmp	x8, x9
    1f7c:      	b.eq	0x195c <event_execve+0x195c>
    1f80:      	ldr	x0, [sp, #0x8]
    1f84:      	sub	x2, x23, #0x8
    1f88:      	mov	w8, #0x8                // =8
    1f8c:      	mov	w9, #0x4                // =4
    1f90:      	mov	w1, #0x8                // =8
    1f94:      	blr	x9
    1f98:      	ldr	x22, [x21, #0x10]
    1f9c:      	ldr	x19, [sp, #0x58]
    1fa0:      	add	x2, x22, #0x20
    1fa4:      	stp	x2, x22, [sp, #0x60]
    1fa8:      	ldr	x8, [sp, #0x40]
    1fac:      	cmp	x19, x8
    1fb0:      	b.ne	0x1fc0 <event_execve+0x1fc0>
    1fb4:      	ldr	x8, [sp, #0x48]
    1fb8:      	cmp	x2, x8
    1fbc:      	b.eq	0x195c <event_execve+0x195c>
    1fc0:      	mov	w8, #0x8                // =8
    1fc4:      	mov	w9, #0x4                // =4
    1fc8:      	add	x10, sp, #0xa8
    1fcc:      	add	x0, sp, #0xa8
    1fd0:      	mov	w1, #0x8                // =8
    1fd4:      	blr	x9
    1fd8:      	ldr	x8, [sp, #0xa8]
    1fdc:      	add	x21, sp, #0xb8
    1fe0:      	cmp	x19, x8
    1fe4:      	b.eq	0x20dc <event_execve+0x20dc>
    1fe8:      	add	x23, x19, #0x18
    1fec:      	mov	w8, #0x8                // =8
    1ff0:      	mov	w9, #0x4                // =4
    1ff4:      	add	x10, sp, #0xc8
    1ff8:      	add	x0, sp, #0xc8
    1ffc:      	mov	w1, #0x8                // =8
    2000:      	mov	x2, x23
    2004:      	blr	x9
    2008:      	ldr	x8, [x21, #0x10]
    200c:      	cmp	x8, x19
    2010:      	b.eq	0x20dc <event_execve+0x20dc>
    2014:      	mov	w8, #0x8                // =8
    2018:      	add	x9, sp, #0xb0
    201c:      	mov	w10, #0x4               // =4
    2020:      	add	x0, sp, #0xb0
    2024:      	mov	w1, #0x8                // =8
    2028:      	mov	x2, x23
    202c:      	add	x22, sp, #0xb8
    2030:      	mov	w21, #0x4               // =4
    2034:      	blr	x10
    2038:      	add	x2, x19, #0x20
    203c:      	mov	w8, #0x10               // =16
    2040:      	add	x9, sp, #0xb8
    2044:      	add	x0, sp, #0xb8
    2048:      	mov	w1, #0x10               // =16
    204c:      	blr	x21
    2050:      	ldr	w19, [sp, #0xbc]
    2054:      	ldr	x8, [sp, #0x50]
    2058:      	ldr	x9, [sp, #0x70]
    205c:      	sub	x11, x9, x8
    2060:      	ldr	w21, [sp, #0x78]
    2064:      	subs	w9, w19, w21
    2068:      	ldr	x10, [x22, #0x8]
    206c:      	csel	w12, wzr, w9, lo
    2070:      	cmp	w21, w19
    2074:      	csel	w9, w21, w19, lo
    2078:      	cinc	w13, w9, hi
    207c:      	sub	w14, w21, w13
    2080:      	subs	x11, x11, x13
    2084:      	str	w14, [sp, #0x78]
    2088:      	b.lo	0x1964 <event_execve+0x1964>
    208c:      	cmp	x11, #0xfff
    2090:      	b.hi	0x1964 <event_execve+0x1964>
    2094:      	add	x2, x10, x12
    2098:      	cmp	w21, w19
    209c:      	b.ls	0x20a8 <event_execve+0x20a8>
    20a0:      	mov	w10, #0x2f              // =47
    20a4:      	strb	w10, [x8, x11]
    20a8:      	add	x22, x8, x11
    20ac:      	cmp	w21, w19
    20b0:      	and	w1, w9, #0xff
    20b4:      	mov	w8, #0x4                // =4
    20b8:      	cinc	x0, x22, hi
    20bc:      	blr	x8
    20c0:      	cmp	w21, w19
    20c4:      	str	x22, [sp, #0x70]
    20c8:      	b.ls	0x1964 <event_execve+0x1964>
    20cc:      	ldr	x21, [sp, #0xb0]
    20d0:      	ldp	x2, x19, [sp, #0x60]
    20d4:      	str	x21, [sp, #0x58]
    20d8:      	b	0x2130 <event_execve+0x2130>
    20dc:      	add	x2, x22, #0x10
    20e0:      	mov	w8, #0x8                // =8
    20e4:      	mov	w9, #0x4                // =4
    20e8:      	add	x10, sp, #0xc8
    20ec:      	add	x0, sp, #0xc8
    20f0:      	mov	w1, #0x8                // =8
    20f4:      	blr	x9
    20f8:      	ldr	x8, [sp, #0x68]
    20fc:      	ldr	x9, [x21, #0x10]
    2100:      	cmp	x8, x9
    2104:      	b.eq	0x195c <event_execve+0x195c>
    2108:      	ldr	x0, [sp, #0x8]
    210c:      	add	x2, x22, #0x18
    2110:      	mov	w8, #0x8                // =8
    2114:      	mov	w9, #0x4                // =4
    2118:      	mov	w1, #0x8                // =8
    211c:      	blr	x9
    2120:      	ldr	x19, [x21, #0x10]
    2124:      	ldr	x21, [sp, #0x58]
    2128:      	add	x2, x19, #0x20
    212c:      	stp	x2, x19, [sp, #0x60]
    2130:      	ldr	x8, [sp, #0x40]
    2134:      	cmp	x21, x8
    2138:      	b.ne	0x2148 <event_execve+0x2148>
    213c:      	ldr	x8, [sp, #0x48]
    2140:      	cmp	x2, x8
    2144:      	b.eq	0x195c <event_execve+0x195c>
    2148:      	mov	w8, #0x8                // =8
    214c:      	mov	w9, #0x4                // =4
    2150:      	add	x10, sp, #0xa8
    2154:      	add	x0, sp, #0xa8
    2158:      	mov	w1, #0x8                // =8
    215c:      	blr	x9
    2160:      	ldr	x8, [sp, #0xa8]
    2164:      	add	x22, sp, #0xb8
    2168:      	cmp	x21, x8
    216c:      	b.eq	0x2260 <event_execve+0x2260>
    2170:      	add	x23, x21, #0x18
    2174:      	mov	w8, #0x8                // =8
    2178:      	mov	w9, #0x4                // =4
    217c:      	add	x10, sp, #0xc8
    2180:      	add	x0, sp, #0xc8
    2184:      	mov	w1, #0x8                // =8
    2188:      	mov	x2, x23
    218c:      	blr	x9
    2190:      	ldr	x8, [x22, #0x10]
    2194:      	cmp	x8, x21
    2198:      	b.eq	0x2260 <event_execve+0x2260>
    219c:      	mov	w8, #0x8                // =8
    21a0:      	add	x9, sp, #0xb0
    21a4:      	mov	w10, #0x4               // =4
    21a8:      	add	x0, sp, #0xb0
    21ac:      	mov	w1, #0x8                // =8
    21b0:      	mov	x2, x23
    21b4:      	mov	w19, #0x4               // =4
    21b8:      	blr	x10
    21bc:      	add	x2, x21, #0x20
    21c0:      	mov	w8, #0x10               // =16
    21c4:      	add	x9, sp, #0xb8
    21c8:      	add	x0, sp, #0xb8
    21cc:      	mov	w1, #0x10               // =16
    21d0:      	blr	x19
    21d4:      	ldr	w19, [sp, #0xbc]
    21d8:      	ldr	x8, [sp, #0x50]
    21dc:      	ldr	x9, [sp, #0x70]
    21e0:      	sub	x11, x9, x8
    21e4:      	ldr	w21, [sp, #0x78]
    21e8:      	subs	w9, w19, w21
    21ec:      	ldr	x10, [x22, #0x8]
    21f0:      	csel	w12, wzr, w9, lo
    21f4:      	cmp	w21, w19
    21f8:      	csel	w9, w21, w19, lo
    21fc:      	cinc	w13, w9, hi
    2200:      	sub	w14, w21, w13
    2204:      	subs	x11, x11, x13
    2208:      	str	w14, [sp, #0x78]
    220c:      	b.lo	0x1964 <event_execve+0x1964>
    2210:      	cmp	x11, #0xfff
    2214:      	b.hi	0x1964 <event_execve+0x1964>
    2218:      	add	x2, x10, x12
    221c:      	cmp	w21, w19
    2220:      	b.ls	0x222c <event_execve+0x222c>
    2224:      	mov	w10, #0x2f              // =47
    2228:      	strb	w10, [x8, x11]
    222c:      	add	x22, x8, x11
    2230:      	cmp	w21, w19
    2234:      	and	w1, w9, #0xff
    2238:      	mov	w8, #0x4                // =4
    223c:      	cinc	x0, x22, hi
    2240:      	blr	x8
    2244:      	cmp	w21, w19
    2248:      	str	x22, [sp, #0x70]
    224c:      	b.ls	0x1964 <event_execve+0x1964>
    2250:      	ldr	x21, [sp, #0xb0]
    2254:      	ldp	x2, x19, [sp, #0x60]
    2258:      	str	x21, [sp, #0x58]
    225c:      	b	0x22b8 <event_execve+0x22b8>
    2260:      	add	x2, x19, #0x10
    2264:      	mov	w8, #0x8                // =8
    2268:      	mov	w9, #0x4                // =4
    226c:      	add	x10, sp, #0xc8
    2270:      	add	x0, sp, #0xc8
    2274:      	mov	w1, #0x8                // =8
    2278:      	blr	x9
    227c:      	ldr	x8, [sp, #0x68]
    2280:      	ldr	x9, [x22, #0x10]
    2284:      	add	x21, sp, #0xb8
    2288:      	cmp	x8, x9
    228c:      	b.eq	0x195c <event_execve+0x195c>
    2290:      	ldr	x0, [sp, #0x8]
    2294:      	add	x2, x19, #0x18
    2298:      	mov	w8, #0x8                // =8
    229c:      	mov	w9, #0x4                // =4
    22a0:      	mov	w1, #0x8                // =8
    22a4:      	blr	x9
    22a8:      	ldr	x19, [x21, #0x10]
    22ac:      	ldr	x21, [sp, #0x58]
    22b0:      	add	x2, x19, #0x20
    22b4:      	stp	x2, x19, [sp, #0x60]
    22b8:      	ldr	x8, [sp, #0x40]
    22bc:      	cmp	x21, x8
    22c0:      	b.ne	0x22d0 <event_execve+0x22d0>
    22c4:      	ldr	x8, [sp, #0x48]
    22c8:      	cmp	x2, x8
    22cc:      	b.eq	0x195c <event_execve+0x195c>
    22d0:      	mov	w8, #0x8                // =8
    22d4:      	mov	w9, #0x4                // =4
    22d8:      	add	x10, sp, #0xa8
    22dc:      	add	x0, sp, #0xa8
    22e0:      	mov	w1, #0x8                // =8
    22e4:      	blr	x9
    22e8:      	ldr	x8, [sp, #0xa8]
    22ec:      	add	x22, sp, #0xb8
    22f0:      	cmp	x21, x8
    22f4:      	b.eq	0x23ec <event_execve+0x23ec>
    22f8:      	add	x23, x21, #0x18
    22fc:      	mov	w8, #0x8                // =8
    2300:      	mov	w9, #0x4                // =4
    2304:      	add	x10, sp, #0xc8
    2308:      	add	x0, sp, #0xc8
    230c:      	mov	w1, #0x8                // =8
    2310:      	mov	x2, x23
    2314:      	blr	x9
    2318:      	ldr	x8, [x22, #0x10]
    231c:      	cmp	x8, x21
    2320:      	b.eq	0x23ec <event_execve+0x23ec>
    2324:      	mov	w8, #0x8                // =8
    2328:      	add	x9, sp, #0xb0
    232c:      	mov	w10, #0x4               // =4
    2330:      	add	x0, sp, #0xb0
    2334:      	mov	w1, #0x8                // =8
    2338:      	mov	x2, x23
    233c:      	mov	w19, #0x4               // =4
    2340:      	blr	x10
    2344:      	add	x2, x21, #0x20
    2348:      	mov	w8, #0x10               // =16
    234c:      	add	x9, sp, #0xb8
    2350:      	add	x0, sp, #0xb8
    2354:      	mov	w1, #0x10               // =16
    2358:      	blr	x19
    235c:      	ldr	w19, [sp, #0xbc]
    2360:      	ldr	x8, [sp, #0x50]
    2364:      	add	x24, sp, #0xb8
    2368:      	ldr	x9, [sp, #0x70]
    236c:      	sub	x11, x9, x8
    2370:      	ldr	w21, [sp, #0x78]
    2374:      	subs	w9, w19, w21
    2378:      	ldr	x10, [x22, #0x8]
    237c:      	csel	w12, wzr, w9, lo
    2380:      	cmp	w21, w19
    2384:      	csel	w9, w21, w19, lo
    2388:      	cinc	w13, w9, hi
    238c:      	sub	w14, w21, w13
    2390:      	subs	x11, x11, x13
    2394:      	str	w14, [sp, #0x78]
    2398:      	b.lo	0x1964 <event_execve+0x1964>
    239c:      	cmp	x11, #0xfff
    23a0:      	b.hi	0x1964 <event_execve+0x1964>
    23a4:      	add	x2, x10, x12
    23a8:      	cmp	w21, w19
    23ac:      	b.ls	0x23b8 <event_execve+0x23b8>
    23b0:      	mov	w10, #0x2f              // =47
    23b4:      	strb	w10, [x8, x11]
    23b8:      	add	x22, x8, x11
    23bc:      	cmp	w21, w19
    23c0:      	and	w1, w9, #0xff
    23c4:      	mov	w8, #0x4                // =4
    23c8:      	cinc	x0, x22, hi
    23cc:      	blr	x8
    23d0:      	cmp	w21, w19
    23d4:      	str	x22, [sp, #0x70]
    23d8:      	b.ls	0x1964 <event_execve+0x1964>
    23dc:      	ldr	x21, [sp, #0xb0]
    23e0:      	ldp	x2, x19, [sp, #0x60]
    23e4:      	str	x21, [sp, #0x58]
    23e8:      	b	0x2448 <event_execve+0x2448>
    23ec:      	add	x2, x19, #0x10
    23f0:      	mov	w8, #0x8                // =8
    23f4:      	mov	w9, #0x4                // =4
    23f8:      	add	x10, sp, #0xc8
    23fc:      	add	x0, sp, #0xc8
    2400:      	mov	w1, #0x8                // =8
    2404:      	blr	x9
    2408:      	ldr	x8, [sp, #0x68]
    240c:      	ldr	x9, [x22, #0x10]
    2410:      	add	x21, sp, #0xb8
    2414:      	cmp	x8, x9
    2418:      	b.eq	0x195c <event_execve+0x195c>
    241c:      	ldr	x0, [sp, #0x8]
    2420:      	add	x2, x19, #0x18
    2424:      	mov	w8, #0x8                // =8
    2428:      	mov	w9, #0x4                // =4
    242c:      	mov	w1, #0x8                // =8
    2430:      	blr	x9
    2434:      	ldr	x19, [x21, #0x10]
    2438:      	ldr	x21, [sp, #0x58]
    243c:      	add	x24, sp, #0xb8
    2440:      	add	x2, x19, #0x20
    2444:      	stp	x2, x19, [sp, #0x60]
    2448:      	ldr	x8, [sp, #0x40]
    244c:      	cmp	x21, x8
    2450:      	b.ne	0x2460 <event_execve+0x2460>
    2454:      	ldr	x8, [sp, #0x48]
    2458:      	cmp	x2, x8
    245c:      	b.eq	0x195c <event_execve+0x195c>
    2460:      	mov	w8, #0x8                // =8
    2464:      	mov	w9, #0x4                // =4
    2468:      	add	x10, sp, #0xa8
    246c:      	add	x0, sp, #0xa8
    2470:      	mov	w1, #0x8                // =8
    2474:      	blr	x9
    2478:      	ldr	x8, [sp, #0xa8]
    247c:      	cmp	x21, x8
    2480:      	b.eq	0x257c <event_execve+0x257c>
    2484:      	add	x23, x21, #0x18
    2488:      	mov	w8, #0x8                // =8
    248c:      	mov	w9, #0x4                // =4
    2490:      	add	x10, sp, #0xc8
    2494:      	add	x0, sp, #0xc8
    2498:      	mov	w1, #0x8                // =8
    249c:      	mov	x2, x23
    24a0:      	blr	x9
    24a4:      	ldr	x8, [x24, #0x10]
    24a8:      	cmp	x8, x21
    24ac:      	b.eq	0x257c <event_execve+0x257c>
    24b0:      	mov	w8, #0x8                // =8
    24b4:      	add	x9, sp, #0xb0
    24b8:      	mov	w10, #0x4               // =4
    24bc:      	add	x0, sp, #0xb0
    24c0:      	mov	w1, #0x8                // =8
    24c4:      	mov	x2, x23
    24c8:      	mov	w19, #0x4               // =4
    24cc:      	blr	x10
    24d0:      	add	x2, x21, #0x20
    24d4:      	mov	w8, #0x10               // =16
    24d8:      	add	x9, sp, #0xb8
    24dc:      	add	x0, sp, #0xb8
    24e0:      	mov	w1, #0x10               // =16
    24e4:      	blr	x19
    24e8:      	ldr	w19, [sp, #0xbc]
    24ec:      	ldr	x8, [sp, #0x50]
    24f0:      	ldr	x9, [sp, #0x70]
    24f4:      	sub	x11, x9, x8
    24f8:      	ldr	w21, [sp, #0x78]
    24fc:      	subs	w9, w19, w21
    2500:      	ldr	x10, [x24, #0x8]
    2504:      	csel	w12, wzr, w9, lo
    2508:      	cmp	w21, w19
    250c:      	csel	w9, w21, w19, lo
    2510:      	cinc	w13, w9, hi
    2514:      	sub	w14, w21, w13
    2518:      	subs	x11, x11, x13
    251c:      	str	w14, [sp, #0x78]
    2520:      	b.lo	0x1964 <event_execve+0x1964>
    2524:      	cmp	x11, #0xfff
    2528:      	b.hi	0x1964 <event_execve+0x1964>
    252c:      	mov	x23, x29
    2530:      	add	x2, x10, x12
    2534:      	cmp	w21, w19
    2538:      	b.ls	0x2544 <event_execve+0x2544>
    253c:      	mov	w10, #0x2f              // =47
    2540:      	strb	w10, [x8, x11]
    2544:      	add	x22, x8, x11
    2548:      	cmp	w21, w19
    254c:      	and	w1, w9, #0xff
    2550:      	mov	w8, #0x4                // =4
    2554:      	cinc	x0, x22, hi
    2558:      	blr	x8
    255c:      	cmp	w21, w19
    2560:      	mov	x29, x23
    2564:      	str	x22, [sp, #0x70]
    2568:      	b.ls	0x1964 <event_execve+0x1964>
    256c:      	ldr	x21, [sp, #0xb0]
    2570:      	ldp	x2, x19, [sp, #0x60]
    2574:      	str	x21, [sp, #0x58]
    2578:      	b	0x25dc <event_execve+0x25dc>
    257c:      	add	x2, x19, #0x10
    2580:      	mov	w8, #0x8                // =8
    2584:      	mov	w9, #0x4                // =4
    2588:      	add	x10, sp, #0xc8
    258c:      	add	x0, sp, #0xc8
    2590:      	mov	w1, #0x8                // =8
    2594:      	blr	x9
    2598:      	add	x21, sp, #0xb8
    259c:      	ldr	x8, [sp, #0x68]
    25a0:      	ldr	x9, [x21, #0x10]
    25a4:      	cmp	x8, x9
    25a8:      	b.eq	0x195c <event_execve+0x195c>
    25ac:      	ldr	x0, [sp, #0x8]
    25b0:      	add	x2, x19, #0x18
    25b4:      	mov	w8, #0x8                // =8
    25b8:      	mov	w9, #0x4                // =4
    25bc:      	mov	w1, #0x8                // =8
    25c0:      	mov	x23, x29
    25c4:      	blr	x9
    25c8:      	ldr	x19, [x21, #0x10]
    25cc:      	ldr	x21, [sp, #0x58]
    25d0:      	add	x24, sp, #0xb8
    25d4:      	add	x2, x19, #0x20
    25d8:      	stp	x2, x19, [sp, #0x60]
    25dc:      	ldr	x8, [sp, #0x40]
    25e0:      	cmp	x21, x8
    25e4:      	b.ne	0x25f8 <event_execve+0x25f8>
    25e8:      	ldr	x8, [sp, #0x48]
    25ec:      	mov	x29, x23
    25f0:      	cmp	x2, x8
    25f4:      	b.eq	0x195c <event_execve+0x195c>
    25f8:      	mov	w8, #0x8                // =8
    25fc:      	mov	w9, #0x4                // =4
    2600:      	add	x10, sp, #0xa8
    2604:      	add	x0, sp, #0xa8
    2608:      	mov	w1, #0x8                // =8
    260c:      	blr	x9
    2610:      	ldr	x8, [sp, #0xa8]
    2614:      	cmp	x21, x8
    2618:      	b.eq	0x2714 <event_execve+0x2714>
    261c:      	add	x23, x21, #0x18
    2620:      	mov	w8, #0x8                // =8
    2624:      	mov	w9, #0x4                // =4
    2628:      	add	x10, sp, #0xc8
    262c:      	add	x0, sp, #0xc8
    2630:      	mov	w1, #0x8                // =8
    2634:      	mov	x2, x23
    2638:      	blr	x9
    263c:      	ldr	x8, [x24, #0x10]
    2640:      	cmp	x8, x21
    2644:      	b.eq	0x2714 <event_execve+0x2714>
    2648:      	mov	w8, #0x8                // =8
    264c:      	add	x9, sp, #0xb0
    2650:      	mov	w10, #0x4               // =4
    2654:      	add	x0, sp, #0xb0
    2658:      	mov	w1, #0x8                // =8
    265c:      	mov	x2, x23
    2660:      	mov	w19, #0x4               // =4
    2664:      	blr	x10
    2668:      	add	x2, x21, #0x20
    266c:      	mov	w8, #0x10               // =16
    2670:      	add	x9, sp, #0xb8
    2674:      	add	x0, sp, #0xb8
    2678:      	mov	w1, #0x10               // =16
    267c:      	blr	x19
    2680:      	ldr	w19, [sp, #0xbc]
    2684:      	ldr	x8, [sp, #0x50]
    2688:      	ldr	x9, [sp, #0x70]
    268c:      	sub	x11, x9, x8
    2690:      	ldr	w21, [sp, #0x78]
    2694:      	subs	w9, w19, w21
    2698:      	ldr	x10, [x24, #0x8]
    269c:      	ldr	x29, [sp, #0x30]
    26a0:      	csel	w12, wzr, w9, lo
    26a4:      	cmp	w21, w19
    26a8:      	csel	w9, w21, w19, lo
    26ac:      	cinc	w13, w9, hi
    26b0:      	sub	w14, w21, w13
    26b4:      	subs	x11, x11, x13
    26b8:      	str	w14, [sp, #0x78]
    26bc:      	b.lo	0x1964 <event_execve+0x1964>
    26c0:      	cmp	x11, #0xfff
    26c4:      	b.hi	0x1964 <event_execve+0x1964>
    26c8:      	add	x2, x10, x12
    26cc:      	cmp	w21, w19
    26d0:      	b.ls	0x26dc <event_execve+0x26dc>
    26d4:      	mov	w10, #0x2f              // =47
    26d8:      	strb	w10, [x8, x11]
    26dc:      	add	x22, x8, x11
    26e0:      	cmp	w21, w19
    26e4:      	and	w1, w9, #0xff
    26e8:      	mov	w8, #0x4                // =4
    26ec:      	cinc	x0, x22, hi
    26f0:      	blr	x8
    26f4:      	ldr	x29, [sp, #0x30]
    26f8:      	cmp	w21, w19
    26fc:      	str	x22, [sp, #0x70]
    2700:      	b.ls	0x1964 <event_execve+0x1964>
    2704:      	ldr	x21, [sp, #0xb0]
    2708:      	ldp	x2, x19, [sp, #0x60]
    270c:      	str	x21, [sp, #0x58]
    2710:      	b	0x2774 <event_execve+0x2774>
    2714:      	add	x2, x19, #0x10
    2718:      	mov	w8, #0x8                // =8
    271c:      	mov	w9, #0x4                // =4
    2720:      	add	x10, sp, #0xc8
    2724:      	add	x0, sp, #0xc8
    2728:      	mov	w1, #0x8                // =8
    272c:      	blr	x9
    2730:      	add	x21, sp, #0xb8
    2734:      	ldr	x8, [sp, #0x68]
    2738:      	ldr	x29, [sp, #0x30]
    273c:      	ldr	x9, [x21, #0x10]
    2740:      	cmp	x8, x9
    2744:      	b.eq	0x195c <event_execve+0x195c>
    2748:      	ldr	x0, [sp, #0x8]
    274c:      	add	x2, x19, #0x18
    2750:      	mov	w8, #0x8                // =8
    2754:      	mov	w9, #0x4                // =4
    2758:      	mov	w1, #0x8                // =8
    275c:      	blr	x9
    2760:      	ldr	x19, [x21, #0x10]
    2764:      	ldr	x21, [sp, #0x58]
    2768:      	add	x24, sp, #0xb8
    276c:      	add	x2, x19, #0x20
    2770:      	stp	x2, x19, [sp, #0x60]
    2774:      	ldr	x8, [sp, #0x40]
    2778:      	ldr	x29, [sp, #0x30]
    277c:      	cmp	x21, x8
    2780:      	b.ne	0x2790 <event_execve+0x2790>
    2784:      	ldr	x8, [sp, #0x48]
    2788:      	cmp	x2, x8
    278c:      	b.eq	0x195c <event_execve+0x195c>
    2790:      	mov	w8, #0x8                // =8
    2794:      	mov	w9, #0x4                // =4
    2798:      	add	x10, sp, #0xa8
    279c:      	add	x0, sp, #0xa8
    27a0:      	mov	w1, #0x8                // =8
    27a4:      	blr	x9
    27a8:      	ldr	x8, [sp, #0xa8]
    27ac:      	cmp	x21, x8
    27b0:      	b.eq	0x28ac <event_execve+0x28ac>
    27b4:      	add	x23, x21, #0x18
    27b8:      	mov	w8, #0x8                // =8
    27bc:      	mov	w9, #0x4                // =4
    27c0:      	add	x10, sp, #0xc8
    27c4:      	add	x0, sp, #0xc8
    27c8:      	mov	w1, #0x8                // =8
    27cc:      	mov	x2, x23
    27d0:      	blr	x9
    27d4:      	ldr	x8, [x24, #0x10]
    27d8:      	cmp	x8, x21
    27dc:      	b.eq	0x28ac <event_execve+0x28ac>
    27e0:      	mov	w8, #0x8                // =8
    27e4:      	add	x9, sp, #0xb0
    27e8:      	mov	w10, #0x4               // =4
    27ec:      	add	x0, sp, #0xb0
    27f0:      	mov	w1, #0x8                // =8
    27f4:      	mov	x2, x23
    27f8:      	mov	w19, #0x4               // =4
    27fc:      	blr	x10
    2800:      	add	x2, x21, #0x20
    2804:      	mov	w8, #0x10               // =16
    2808:      	add	x9, sp, #0xb8
    280c:      	add	x0, sp, #0xb8
    2810:      	mov	w1, #0x10               // =16
    2814:      	blr	x19
    2818:      	ldr	w19, [sp, #0xbc]
    281c:      	ldr	x8, [sp, #0x50]
    2820:      	ldr	x9, [sp, #0x70]
    2824:      	sub	x11, x9, x8
    2828:      	ldr	w21, [sp, #0x78]
    282c:      	subs	w9, w19, w21
    2830:      	ldr	x10, [x24, #0x8]
    2834:      	ldr	x29, [sp, #0x30]
    2838:      	csel	w12, wzr, w9, lo
    283c:      	cmp	w21, w19
    2840:      	csel	w9, w21, w19, lo
    2844:      	cinc	w13, w9, hi
    2848:      	sub	w14, w21, w13
    284c:      	subs	x11, x11, x13
    2850:      	str	w14, [sp, #0x78]
    2854:      	b.lo	0x1964 <event_execve+0x1964>
    2858:      	cmp	x11, #0xfff
    285c:      	b.hi	0x1964 <event_execve+0x1964>
    2860:      	add	x2, x10, x12
    2864:      	cmp	w21, w19
    2868:      	b.ls	0x2874 <event_execve+0x2874>
    286c:      	mov	w10, #0x2f              // =47
    2870:      	strb	w10, [x8, x11]
    2874:      	add	x22, x8, x11
    2878:      	cmp	w21, w19
    287c:      	and	w1, w9, #0xff
    2880:      	mov	w8, #0x4                // =4
    2884:      	cinc	x0, x22, hi
    2888:      	blr	x8
    288c:      	ldr	x29, [sp, #0x30]
    2890:      	cmp	w21, w19
    2894:      	str	x22, [sp, #0x70]
    2898:      	b.ls	0x1964 <event_execve+0x1964>
    289c:      	ldr	x21, [sp, #0xb0]
    28a0:      	ldp	x2, x19, [sp, #0x60]
    28a4:      	str	x21, [sp, #0x58]
    28a8:      	b	0x290c <event_execve+0x290c>
    28ac:      	add	x2, x19, #0x10
    28b0:      	mov	w8, #0x8                // =8
    28b4:      	mov	w9, #0x4                // =4
    28b8:      	add	x10, sp, #0xc8
    28bc:      	add	x0, sp, #0xc8
    28c0:      	mov	w1, #0x8                // =8
    28c4:      	blr	x9
    28c8:      	add	x21, sp, #0xb8
    28cc:      	ldr	x8, [sp, #0x68]
    28d0:      	ldr	x29, [sp, #0x30]
    28d4:      	ldr	x9, [x21, #0x10]
    28d8:      	cmp	x8, x9
    28dc:      	b.eq	0x195c <event_execve+0x195c>
    28e0:      	ldr	x0, [sp, #0x8]
    28e4:      	add	x2, x19, #0x18
    28e8:      	mov	w8, #0x8                // =8
    28ec:      	mov	w9, #0x4                // =4
    28f0:      	mov	w1, #0x8                // =8
    28f4:      	blr	x9
    28f8:      	ldr	x19, [x21, #0x10]
    28fc:      	ldr	x21, [sp, #0x58]
    2900:      	add	x24, sp, #0xb8
    2904:      	add	x2, x19, #0x20
    2908:      	stp	x2, x19, [sp, #0x60]
    290c:      	ldr	x8, [sp, #0x40]
    2910:      	ldr	x29, [sp, #0x30]
    2914:      	cmp	x21, x8
    2918:      	b.ne	0x2928 <event_execve+0x2928>
    291c:      	ldr	x8, [sp, #0x48]
    2920:      	cmp	x2, x8
    2924:      	b.eq	0x195c <event_execve+0x195c>
    2928:      	mov	w8, #0x8                // =8
    292c:      	mov	w9, #0x4                // =4
    2930:      	add	x10, sp, #0xa8
    2934:      	add	x0, sp, #0xa8
    2938:      	mov	w1, #0x8                // =8
    293c:      	blr	x9
    2940:      	ldr	x8, [sp, #0xa8]
    2944:      	cmp	x21, x8
    2948:      	b.eq	0x2a44 <event_execve+0x2a44>
    294c:      	add	x23, x21, #0x18
    2950:      	mov	w8, #0x8                // =8
    2954:      	mov	w9, #0x4                // =4
    2958:      	add	x10, sp, #0xc8
    295c:      	add	x0, sp, #0xc8
    2960:      	mov	w1, #0x8                // =8
    2964:      	mov	x2, x23
    2968:      	blr	x9
    296c:      	ldr	x8, [x24, #0x10]
    2970:      	cmp	x8, x21
    2974:      	b.eq	0x2a44 <event_execve+0x2a44>
    2978:      	mov	w8, #0x8                // =8
    297c:      	add	x9, sp, #0xb0
    2980:      	mov	w10, #0x4               // =4
    2984:      	add	x0, sp, #0xb0
    2988:      	mov	w1, #0x8                // =8
    298c:      	mov	x2, x23
    2990:      	mov	w19, #0x4               // =4
    2994:      	blr	x10
    2998:      	add	x2, x21, #0x20
    299c:      	mov	w8, #0x10               // =16
    29a0:      	add	x9, sp, #0xb8
    29a4:      	add	x0, sp, #0xb8
    29a8:      	mov	w1, #0x10               // =16
    29ac:      	blr	x19
    29b0:      	ldr	w19, [sp, #0xbc]
    29b4:      	ldr	x8, [sp, #0x50]
    29b8:      	ldr	x9, [sp, #0x70]
    29bc:      	sub	x11, x9, x8
    29c0:      	ldr	w21, [sp, #0x78]
    29c4:      	subs	w9, w19, w21
    29c8:      	ldr	x10, [x24, #0x8]
    29cc:      	ldr	x29, [sp, #0x30]
    29d0:      	csel	w12, wzr, w9, lo
    29d4:      	cmp	w21, w19
    29d8:      	csel	w9, w21, w19, lo
    29dc:      	cinc	w13, w9, hi
    29e0:      	sub	w14, w21, w13
    29e4:      	subs	x11, x11, x13
    29e8:      	str	w14, [sp, #0x78]
    29ec:      	b.lo	0x1964 <event_execve+0x1964>
    29f0:      	cmp	x11, #0xfff
    29f4:      	b.hi	0x1964 <event_execve+0x1964>
    29f8:      	add	x2, x10, x12
    29fc:      	cmp	w21, w19
    2a00:      	b.ls	0x2a0c <event_execve+0x2a0c>
    2a04:      	mov	w10, #0x2f              // =47
    2a08:      	strb	w10, [x8, x11]
    2a0c:      	add	x22, x8, x11
    2a10:      	cmp	w21, w19
    2a14:      	and	w1, w9, #0xff
    2a18:      	mov	w8, #0x4                // =4
    2a1c:      	cinc	x0, x22, hi
    2a20:      	blr	x8
    2a24:      	ldr	x29, [sp, #0x30]
    2a28:      	cmp	w21, w19
    2a2c:      	str	x22, [sp, #0x70]
    2a30:      	b.ls	0x1964 <event_execve+0x1964>
    2a34:      	ldr	x21, [sp, #0xb0]
    2a38:      	ldp	x2, x19, [sp, #0x60]
    2a3c:      	str	x21, [sp, #0x58]
    2a40:      	b	0x2aa4 <event_execve+0x2aa4>
    2a44:      	add	x2, x19, #0x10
    2a48:      	mov	w8, #0x8                // =8
    2a4c:      	mov	w9, #0x4                // =4
    2a50:      	add	x10, sp, #0xc8
    2a54:      	add	x0, sp, #0xc8
    2a58:      	mov	w1, #0x8                // =8
    2a5c:      	blr	x9
    2a60:      	add	x21, sp, #0xb8
    2a64:      	ldr	x8, [sp, #0x68]
    2a68:      	ldr	x29, [sp, #0x30]
    2a6c:      	ldr	x9, [x21, #0x10]
    2a70:      	cmp	x8, x9
    2a74:      	b.eq	0x195c <event_execve+0x195c>
    2a78:      	ldr	x0, [sp, #0x8]
    2a7c:      	add	x2, x19, #0x18
    2a80:      	mov	w8, #0x8                // =8
    2a84:      	mov	w9, #0x4                // =4
    2a88:      	mov	w1, #0x8                // =8
    2a8c:      	blr	x9
    2a90:      	ldr	x19, [x21, #0x10]
    2a94:      	ldr	x21, [sp, #0x58]
    2a98:      	add	x24, sp, #0xb8
    2a9c:      	add	x2, x19, #0x20
    2aa0:      	stp	x2, x19, [sp, #0x60]
    2aa4:      	ldr	x8, [sp, #0x40]
    2aa8:      	ldr	x29, [sp, #0x30]
    2aac:      	cmp	x21, x8
    2ab0:      	b.ne	0x2ac0 <event_execve+0x2ac0>
    2ab4:      	ldr	x8, [sp, #0x48]
    2ab8:      	cmp	x2, x8
    2abc:      	b.eq	0x195c <event_execve+0x195c>
    2ac0:      	mov	w8, #0x8                // =8
    2ac4:      	mov	w9, #0x4                // =4
    2ac8:      	add	x10, sp, #0xa8
    2acc:      	add	x0, sp, #0xa8
    2ad0:      	mov	w1, #0x8                // =8
    2ad4:      	blr	x9
    2ad8:      	ldr	x8, [sp, #0xa8]
    2adc:      	cmp	x21, x8
    2ae0:      	b.eq	0x2bdc <event_execve+0x2bdc>
    2ae4:      	add	x23, x21, #0x18
    2ae8:      	mov	w8, #0x8                // =8
    2aec:      	mov	w9, #0x4                // =4
    2af0:      	add	x10, sp, #0xc8
    2af4:      	add	x0, sp, #0xc8
    2af8:      	mov	w1, #0x8                // =8
    2afc:      	mov	x2, x23
    2b00:      	blr	x9
    2b04:      	ldr	x8, [x24, #0x10]
    2b08:      	cmp	x8, x21
    2b0c:      	b.eq	0x2bdc <event_execve+0x2bdc>
    2b10:      	mov	w8, #0x8                // =8
    2b14:      	add	x9, sp, #0xb0
    2b18:      	mov	w10, #0x4               // =4
    2b1c:      	add	x0, sp, #0xb0
    2b20:      	mov	w1, #0x8                // =8
    2b24:      	mov	x2, x23
    2b28:      	mov	w19, #0x4               // =4
    2b2c:      	blr	x10
    2b30:      	add	x2, x21, #0x20
    2b34:      	mov	w8, #0x10               // =16
    2b38:      	add	x9, sp, #0xb8
    2b3c:      	add	x0, sp, #0xb8
    2b40:      	mov	w1, #0x10               // =16
    2b44:      	blr	x19
    2b48:      	ldr	w19, [sp, #0xbc]
    2b4c:      	ldr	x8, [sp, #0x50]
    2b50:      	ldr	x9, [sp, #0x70]
    2b54:      	sub	x11, x9, x8
    2b58:      	ldr	w21, [sp, #0x78]
    2b5c:      	subs	w9, w19, w21
    2b60:      	ldr	x10, [x24, #0x8]
    2b64:      	ldr	x29, [sp, #0x30]
    2b68:      	csel	w12, wzr, w9, lo
    2b6c:      	cmp	w21, w19
    2b70:      	csel	w9, w21, w19, lo
    2b74:      	cinc	w13, w9, hi
    2b78:      	sub	w14, w21, w13
    2b7c:      	subs	x11, x11, x13
    2b80:      	str	w14, [sp, #0x78]
    2b84:      	b.lo	0x1964 <event_execve+0x1964>
    2b88:      	cmp	x11, #0xfff
    2b8c:      	b.hi	0x1964 <event_execve+0x1964>
    2b90:      	add	x2, x10, x12
    2b94:      	cmp	w21, w19
    2b98:      	b.ls	0x2ba4 <event_execve+0x2ba4>
    2b9c:      	mov	w10, #0x2f              // =47
    2ba0:      	strb	w10, [x8, x11]
    2ba4:      	add	x22, x8, x11
    2ba8:      	cmp	w21, w19
    2bac:      	and	w1, w9, #0xff
    2bb0:      	mov	w8, #0x4                // =4
    2bb4:      	cinc	x0, x22, hi
    2bb8:      	blr	x8
    2bbc:      	ldr	x29, [sp, #0x30]
    2bc0:      	cmp	w21, w19
    2bc4:      	str	x22, [sp, #0x70]
    2bc8:      	b.ls	0x1964 <event_execve+0x1964>
    2bcc:      	ldr	x21, [sp, #0xb0]
    2bd0:      	ldp	x2, x19, [sp, #0x60]
    2bd4:      	str	x21, [sp, #0x58]
    2bd8:      	b	0x2c3c <event_execve+0x2c3c>
    2bdc:      	add	x2, x19, #0x10
    2be0:      	mov	w8, #0x8                // =8
    2be4:      	mov	w9, #0x4                // =4
    2be8:      	add	x10, sp, #0xc8
    2bec:      	add	x0, sp, #0xc8
    2bf0:      	mov	w1, #0x8                // =8
    2bf4:      	blr	x9
    2bf8:      	add	x21, sp, #0xb8
    2bfc:      	ldr	x8, [sp, #0x68]
    2c00:      	ldr	x29, [sp, #0x30]
    2c04:      	ldr	x9, [x21, #0x10]
    2c08:      	cmp	x8, x9
    2c0c:      	b.eq	0x195c <event_execve+0x195c>
    2c10:      	ldr	x0, [sp, #0x8]
    2c14:      	add	x2, x19, #0x18
    2c18:      	mov	w8, #0x8                // =8
    2c1c:      	mov	w9, #0x4                // =4
    2c20:      	mov	w1, #0x8                // =8
    2c24:      	blr	x9
    2c28:      	ldr	x19, [x21, #0x10]
    2c2c:      	ldr	x21, [sp, #0x58]
    2c30:      	add	x24, sp, #0xb8
    2c34:      	add	x2, x19, #0x20
    2c38:      	stp	x2, x19, [sp, #0x60]
    2c3c:      	ldr	x8, [sp, #0x40]
    2c40:      	ldr	x29, [sp, #0x30]
    2c44:      	cmp	x21, x8
    2c48:      	b.ne	0x2c58 <event_execve+0x2c58>
    2c4c:      	ldr	x8, [sp, #0x48]
    2c50:      	cmp	x2, x8
    2c54:      	b.eq	0x195c <event_execve+0x195c>
    2c58:      	mov	w8, #0x8                // =8
    2c5c:      	mov	w9, #0x4                // =4
    2c60:      	add	x10, sp, #0xa8
    2c64:      	add	x0, sp, #0xa8
    2c68:      	mov	w1, #0x8                // =8
    2c6c:      	blr	x9
    2c70:      	ldr	x8, [sp, #0xa8]
    2c74:      	cmp	x21, x8
    2c78:      	b.eq	0x2d74 <event_execve+0x2d74>
    2c7c:      	add	x23, x21, #0x18
    2c80:      	mov	w8, #0x8                // =8
    2c84:      	mov	w9, #0x4                // =4
    2c88:      	add	x10, sp, #0xc8
    2c8c:      	add	x0, sp, #0xc8
    2c90:      	mov	w1, #0x8                // =8
    2c94:      	mov	x2, x23
    2c98:      	blr	x9
    2c9c:      	ldr	x8, [x24, #0x10]
    2ca0:      	cmp	x8, x21
    2ca4:      	b.eq	0x2d74 <event_execve+0x2d74>
    2ca8:      	mov	w8, #0x8                // =8
    2cac:      	add	x9, sp, #0xb0
    2cb0:      	mov	w10, #0x4               // =4
    2cb4:      	add	x0, sp, #0xb0
    2cb8:      	mov	w1, #0x8                // =8
    2cbc:      	mov	x2, x23
    2cc0:      	mov	w19, #0x4               // =4
    2cc4:      	blr	x10
    2cc8:      	add	x2, x21, #0x20
    2ccc:      	mov	w8, #0x10               // =16
    2cd0:      	add	x9, sp, #0xb8
    2cd4:      	add	x0, sp, #0xb8
    2cd8:      	mov	w1, #0x10               // =16
    2cdc:      	blr	x19
    2ce0:      	ldr	w19, [sp, #0xbc]
    2ce4:      	ldr	x8, [sp, #0x50]
    2ce8:      	ldr	x9, [sp, #0x70]
    2cec:      	sub	x11, x9, x8
    2cf0:      	ldr	w21, [sp, #0x78]
    2cf4:      	subs	w9, w19, w21
    2cf8:      	ldr	x10, [x24, #0x8]
    2cfc:      	ldr	x29, [sp, #0x30]
    2d00:      	csel	w12, wzr, w9, lo
    2d04:      	cmp	w21, w19
    2d08:      	csel	w9, w21, w19, lo
    2d0c:      	cinc	w13, w9, hi
    2d10:      	sub	w14, w21, w13
    2d14:      	subs	x11, x11, x13
    2d18:      	str	w14, [sp, #0x78]
    2d1c:      	b.lo	0x1964 <event_execve+0x1964>
    2d20:      	cmp	x11, #0xfff
    2d24:      	b.hi	0x1964 <event_execve+0x1964>
    2d28:      	add	x2, x10, x12
    2d2c:      	cmp	w21, w19
    2d30:      	b.ls	0x2d3c <event_execve+0x2d3c>
    2d34:      	mov	w10, #0x2f              // =47
    2d38:      	strb	w10, [x8, x11]
    2d3c:      	add	x22, x8, x11
    2d40:      	cmp	w21, w19
    2d44:      	and	w1, w9, #0xff
    2d48:      	mov	w8, #0x4                // =4
    2d4c:      	cinc	x0, x22, hi
    2d50:      	blr	x8
    2d54:      	ldr	x29, [sp, #0x30]
    2d58:      	cmp	w21, w19
    2d5c:      	str	x22, [sp, #0x70]
    2d60:      	b.ls	0x1964 <event_execve+0x1964>
    2d64:      	ldr	x21, [sp, #0xb0]
    2d68:      	ldp	x2, x19, [sp, #0x60]
    2d6c:      	str	x21, [sp, #0x58]
    2d70:      	b	0x2dd4 <event_execve+0x2dd4>
    2d74:      	add	x2, x19, #0x10
    2d78:      	mov	w8, #0x8                // =8
    2d7c:      	mov	w9, #0x4                // =4
    2d80:      	add	x10, sp, #0xc8
    2d84:      	add	x0, sp, #0xc8
    2d88:      	mov	w1, #0x8                // =8
    2d8c:      	blr	x9
    2d90:      	add	x21, sp, #0xb8
    2d94:      	ldr	x8, [sp, #0x68]
    2d98:      	ldr	x29, [sp, #0x30]
    2d9c:      	ldr	x9, [x21, #0x10]
    2da0:      	cmp	x8, x9
    2da4:      	b.eq	0x195c <event_execve+0x195c>
    2da8:      	ldr	x0, [sp, #0x8]
    2dac:      	add	x2, x19, #0x18
    2db0:      	mov	w8, #0x8                // =8
    2db4:      	mov	w9, #0x4                // =4
    2db8:      	mov	w1, #0x8                // =8
    2dbc:      	blr	x9
    2dc0:      	ldr	x19, [x21, #0x10]
    2dc4:      	ldr	x21, [sp, #0x58]
    2dc8:      	add	x24, sp, #0xb8
    2dcc:      	add	x2, x19, #0x20
    2dd0:      	stp	x2, x19, [sp, #0x60]
    2dd4:      	ldr	x8, [sp, #0x40]
    2dd8:      	ldr	x29, [sp, #0x30]
    2ddc:      	cmp	x21, x8
    2de0:      	b.ne	0x2df0 <event_execve+0x2df0>
    2de4:      	ldr	x8, [sp, #0x48]
    2de8:      	cmp	x2, x8
    2dec:      	b.eq	0x195c <event_execve+0x195c>
    2df0:      	mov	w8, #0x8                // =8
    2df4:      	mov	w9, #0x4                // =4
    2df8:      	add	x10, sp, #0xa8
    2dfc:      	add	x0, sp, #0xa8
    2e00:      	mov	w1, #0x8                // =8
    2e04:      	blr	x9
    2e08:      	ldr	x8, [sp, #0xa8]
    2e0c:      	cmp	x21, x8
    2e10:      	b.eq	0x2f08 <event_execve+0x2f08>
    2e14:      	add	x23, x21, #0x18
    2e18:      	mov	w8, #0x8                // =8
    2e1c:      	mov	w9, #0x4                // =4
    2e20:      	add	x10, sp, #0xc8
    2e24:      	add	x0, sp, #0xc8
    2e28:      	mov	w1, #0x8                // =8
    2e2c:      	mov	x2, x23
    2e30:      	blr	x9
    2e34:      	ldr	x8, [x24, #0x10]
    2e38:      	cmp	x8, x21
    2e3c:      	b.eq	0x2f08 <event_execve+0x2f08>
    2e40:      	mov	w8, #0x8                // =8
    2e44:      	add	x9, sp, #0xb0
    2e48:      	mov	w10, #0x4               // =4
    2e4c:      	add	x0, sp, #0xb0
    2e50:      	mov	w1, #0x8                // =8
    2e54:      	mov	x2, x23
    2e58:      	mov	w19, #0x4               // =4
    2e5c:      	blr	x10
    2e60:      	add	x2, x21, #0x20
    2e64:      	mov	w8, #0x10               // =16
    2e68:      	add	x9, sp, #0xb8
    2e6c:      	add	x0, sp, #0xb8
    2e70:      	mov	w1, #0x10               // =16
    2e74:      	blr	x19
    2e78:      	ldr	w19, [sp, #0xbc]
    2e7c:      	ldr	x8, [sp, #0x50]
    2e80:      	ldr	x9, [sp, #0x70]
    2e84:      	sub	x11, x9, x8
    2e88:      	ldr	w21, [sp, #0x78]
    2e8c:      	subs	w9, w19, w21
    2e90:      	ldr	x10, [x24, #0x8]
    2e94:      	ldr	x29, [sp, #0x30]
    2e98:      	csel	w12, wzr, w9, lo
    2e9c:      	cmp	w21, w19
    2ea0:      	csel	w9, w21, w19, lo
    2ea4:      	cinc	w13, w9, hi
    2ea8:      	sub	w14, w21, w13
    2eac:      	subs	x11, x11, x13
    2eb0:      	str	w14, [sp, #0x78]
    2eb4:      	b.lo	0x1964 <event_execve+0x1964>
    2eb8:      	cmp	x11, #0xfff
    2ebc:      	b.hi	0x1964 <event_execve+0x1964>
    2ec0:      	add	x2, x10, x12
    2ec4:      	cmp	w21, w19
    2ec8:      	b.ls	0x2ed4 <event_execve+0x2ed4>
    2ecc:      	mov	w10, #0x2f              // =47
    2ed0:      	strb	w10, [x8, x11]
    2ed4:      	add	x22, x8, x11
    2ed8:      	cmp	w21, w19
    2edc:      	and	w1, w9, #0xff
    2ee0:      	mov	w8, #0x4                // =4
    2ee4:      	cinc	x0, x22, hi
    2ee8:      	blr	x8
    2eec:      	ldr	x29, [sp, #0x30]
    2ef0:      	cmp	w21, w19
    2ef4:      	str	x22, [sp, #0x70]
    2ef8:      	b.ls	0x1964 <event_execve+0x1964>
    2efc:      	ldr	x8, [sp, #0xb0]
    2f00:      	str	x8, [sp, #0x58]
    2f04:      	b	0x1964 <event_execve+0x1964>
    2f08:      	add	x2, x19, #0x10
    2f0c:      	mov	w8, #0x8                // =8
    2f10:      	mov	w9, #0x4                // =4
    2f14:      	add	x10, sp, #0xc8
    2f18:      	add	x0, sp, #0xc8
    2f1c:      	mov	w1, #0x8                // =8
    2f20:      	blr	x9
    2f24:      	add	x9, sp, #0xb8
    2f28:      	ldr	x8, [sp, #0x68]
    2f2c:      	ldr	x29, [sp, #0x30]
    2f30:      	ldr	x9, [x9, #0x10]
    2f34:      	cmp	x8, x9
    2f38:      	b.eq	0x195c <event_execve+0x195c>
    2f3c:      	ldr	x0, [sp, #0x8]
    2f40:      	add	x2, x19, #0x18
    2f44:      	mov	w8, #0x8                // =8
    2f48:      	mov	w9, #0x4                // =4
    2f4c:      	mov	w1, #0x8                // =8
    2f50:      	blr	x9
    2f54:      	b	0x1964 <event_execve+0x1964>
