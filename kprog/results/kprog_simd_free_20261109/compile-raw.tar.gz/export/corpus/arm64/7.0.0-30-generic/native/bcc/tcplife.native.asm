
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/bcc/tcplife.native.o:	file format elf64-littleaarch64

Disassembly of section tracepoint/sock/inet_sock_set_state:

0000000000000000 <inet_sock_set_state>:
       0:      	sub	sp, sp, #0xf0
       4:      	str	x29, [sp, #0xa0]
       8:      	stp	x30, x25, [sp, #0xb0]
       c:      	stp	x24, x23, [sp, #0xc0]
      10:      	stp	x22, x21, [sp, #0xd0]
      14:      	stp	x20, x19, [sp, #0xe0]
      18:      	mov	x19, x0
      1c:      	add	x0, sp, #0x8
      20:      	mov	w1, #0x2                // =2
      24:      	str	wzr, [sp, #0x98]
      28:      	stp	xzr, xzr, [sp, #0x88]
      2c:      	add	x2, x19, #0x1e
      30:      	stp	xzr, xzr, [sp, #0x70]
      34:      	stp	xzr, xzr, [sp, #0x60]
      38:      	stp	xzr, xzr, [sp, #0x50]
      3c:      	stp	xzr, xzr, [sp, #0x40]
      40:      	stp	xzr, xzr, [sp, #0x30]
      44:      	stp	xzr, xzr, [sp, #0x20]
      48:      	bl	0x48 <inet_sock_set_state+0x48>
      4c:      	ldrh	w8, [sp, #0x8]
      50:      	cmp	w8, #0x6
      54:      	b.ne	0x414 <inet_sock_set_state+0x414>
      58:      	add	x0, sp, #0x8
      5c:      	add	x2, x19, #0x1c
      60:      	mov	w1, #0x2                // =2
      64:      	bl	0x64 <inet_sock_set_state+0x64>
      68:      	adrp	x8, 0x0 <inet_sock_set_state>
      6c:      	ldrh	w22, [sp, #0x8]
      70:      	ldr	x8, [x8]
      74:      	ldrh	w9, [x8]
      78:      	cbz	w9, 0x88 <inet_sock_set_state+0x88>
      7c:      	ldrh	w8, [x8]
      80:      	cmp	w22, w8
      84:      	b.ne	0x414 <inet_sock_set_state+0x414>
      88:      	add	x0, sp, #0x8
      8c:      	add	x2, x19, #0x18
      90:      	mov	w1, #0x2                // =2
      94:      	bl	0x94 <inet_sock_set_state+0x94>
      98:      	adrp	x8, 0x0 <inet_sock_set_state>
      9c:      	ldrh	w23, [sp, #0x8]
      a0:      	ldr	x8, [x8]
      a4:      	ldrb	w8, [x8]
      a8:      	cbz	w8, 0xe4 <inet_sock_set_state+0xe4>
      ac:      	adrp	x9, 0x0 <inet_sock_set_state>
      b0:      	mov	x8, xzr
      b4:      	ldr	x9, [x9]
      b8:      	nop
      bc:      	nop
      c0:      	ldrh	w10, [x9, x8]
      c4:      	cbz	w10, 0x414 <inet_sock_set_state+0x414>
      c8:      	ldrh	w10, [x9, x8]
      cc:      	cmp	w23, w10
      d0:      	b.eq	0xe4 <inet_sock_set_state+0xe4>
      d4:      	add	x8, x8, #0x2
      d8:      	cmp	x8, #0x800
      dc:      	b.ne	0xc0 <inet_sock_set_state+0xc0>
      e0:      	b	0x414 <inet_sock_set_state+0x414>
      e4:      	add	x0, sp, #0x8
      e8:      	add	x2, x19, #0x1a
      ec:      	mov	w1, #0x2                // =2
      f0:      	bl	0xf0 <inet_sock_set_state+0xf0>
      f4:      	adrp	x8, 0x0 <inet_sock_set_state>
      f8:      	ldrh	w24, [sp, #0x8]
      fc:      	ldr	x8, [x8]
     100:      	ldrb	w8, [x8]
     104:      	cbz	w8, 0x144 <inet_sock_set_state+0x144>
     108:      	adrp	x9, 0x0 <inet_sock_set_state>
     10c:      	mov	x8, xzr
     110:      	ldr	x9, [x9]
     114:      	nop
     118:      	nop
     11c:      	nop
     120:      	ldrh	w10, [x9, x8]
     124:      	cbz	w10, 0x414 <inet_sock_set_state+0x414>
     128:      	ldrh	w10, [x9, x8]
     12c:      	cmp	w24, w10
     130:      	b.eq	0x144 <inet_sock_set_state+0x144>
     134:      	add	x8, x8, #0x2
     138:      	cmp	x8, #0x800
     13c:      	b.ne	0x120 <inet_sock_set_state+0x120>
     140:      	b	0x414 <inet_sock_set_state+0x414>
     144:      	add	x0, sp, #0x18
     148:      	add	x2, x19, #0x8
     14c:      	mov	w1, #0x8                // =8
     150:      	bl	0x150 <inet_sock_set_state+0x150>
     154:      	add	x0, sp, #0x8
     158:      	add	x2, x19, #0x14
     15c:      	mov	w1, #0x4                // =4
     160:      	bl	0x160 <inet_sock_set_state+0x160>
     164:      	ldr	w8, [sp, #0x8]
     168:      	cmp	w8, #0x3
     16c:      	b.gt	0x190 <inet_sock_set_state+0x190>
     170:      	bl	0x170 <inet_sock_set_state+0x170>
     174:      	str	x0, [sp, #0xa8]
     178:      	adrp	x0, 0x0 <inet_sock_set_state>
     17c:      	add	x1, sp, #0x18
     180:      	add	x2, sp, #0xa8
     184:      	ldr	x0, [x0]
     188:      	mov	x3, xzr
     18c:      	bl	0x18c <inet_sock_set_state+0x18c>
     190:      	add	x0, sp, #0x8
     194:      	add	x2, x19, #0x14
     198:      	mov	w1, #0x4                // =4
     19c:      	bl	0x19c <inet_sock_set_state+0x19c>
     1a0:      	ldr	w8, [sp, #0x8]
     1a4:      	cmp	w8, #0x2
     1a8:      	b.eq	0x1c8 <inet_sock_set_state+0x1c8>
     1ac:      	add	x0, sp, #0x8
     1b0:      	add	x2, x19, #0x14
     1b4:      	mov	w1, #0x4                // =4
     1b8:      	bl	0x1b8 <inet_sock_set_state+0x1b8>
     1bc:      	ldr	w8, [sp, #0x8]
     1c0:      	cmp	w8, #0x9
     1c4:      	b.ne	0x218 <inet_sock_set_state+0x218>
     1c8:      	bl	0x1c8 <inet_sock_set_state+0x1c8>
     1cc:      	adrp	x9, 0x0 <inet_sock_set_state>
     1d0:      	lsr	x8, x0, #32
     1d4:      	ldr	x9, [x9]
     1d8:      	ldr	w10, [x9]
     1dc:      	cbz	w10, 0x1ec <inet_sock_set_state+0x1ec>
     1e0:      	ldr	w9, [x9]
     1e4:      	cmp	w9, w8
     1e8:      	b.ne	0x414 <inet_sock_set_state+0x414>
     1ec:      	str	w8, [sp, #0x88]
     1f0:      	add	x8, sp, #0x88
     1f4:      	mov	w1, #0x10               // =16
     1f8:      	orr	x0, x8, #0x4
     1fc:      	bl	0x1fc <inet_sock_set_state+0x1fc>
     200:      	adrp	x0, 0x0 <inet_sock_set_state>
     204:      	add	x1, sp, #0x18
     208:      	add	x2, sp, #0x88
     20c:      	ldr	x0, [x0]
     210:      	mov	x3, xzr
     214:      	bl	0x214 <inet_sock_set_state+0x214>
     218:      	add	x0, sp, #0x8
     21c:      	add	x2, x19, #0x14
     220:      	mov	w1, #0x4                // =4
     224:      	bl	0x224 <inet_sock_set_state+0x224>
     228:      	ldr	w8, [sp, #0x8]
     22c:      	cmp	w8, #0x7
     230:      	b.ne	0x414 <inet_sock_set_state+0x414>
     234:      	adrp	x0, 0x0 <inet_sock_set_state>
     238:      	add	x1, sp, #0x18
     23c:      	ldr	x0, [x0]
     240:      	bl	0x240 <inet_sock_set_state+0x240>
     244:      	cbz	x0, 0x404 <inet_sock_set_state+0x404>
     248:      	mov	x20, x0
     24c:      	bl	0x24c <inet_sock_set_state+0x24c>
     250:      	mov	x21, x0
     254:      	str	x0, [sp, #0xa8]
     258:      	adrp	x0, 0x0 <inet_sock_set_state>
     25c:      	add	x1, sp, #0x18
     260:      	ldr	x29, [x20]
     264:      	ldr	x0, [x0]
     268:      	bl	0x268 <inet_sock_set_state+0x268>
     26c:      	mov	x20, x0
     270:      	cbz	x0, 0x27c <inet_sock_set_state+0x27c>
     274:      	ldr	w25, [x20]
     278:      	b	0x284 <inet_sock_set_state+0x284>
     27c:      	bl	0x27c <inet_sock_set_state+0x27c>
     280:      	lsr	x25, x0, #32
     284:      	adrp	x8, 0x0 <inet_sock_set_state>
     288:      	ldr	x8, [x8]
     28c:      	ldr	w9, [x8]
     290:      	cbz	w9, 0x2a0 <inet_sock_set_state+0x2a0>
     294:      	ldr	w8, [x8]
     298:      	cmp	w25, w8
     29c:      	b.ne	0x3f4 <inet_sock_set_state+0x3f4>
     2a0:      	mov	x9, #0xf7cf             // =63439
     2a4:      	sub	x8, x21, x29
     2a8:      	ldr	x21, [sp, #0x18]
     2ac:      	add	x0, sp, #0x8
     2b0:      	mov	w1, #0x8                // =8
     2b4:      	movk	x9, #0xe353, lsl #16
     2b8:      	lsr	x8, x8, #3
     2bc:      	movk	x9, #0x9ba5, lsl #32
     2c0:      	movk	x9, #0x20c4, lsl #48
     2c4:      	umulh	x8, x8, x9
     2c8:      	add	x2, x21, #0x710
     2cc:      	lsr	x8, x8, #4
     2d0:      	str	x8, [sp]
     2d4:      	bl	0x2d4 <inet_sock_set_state+0x2d4>
     2d8:      	ldr	x29, [sp, #0x8]
     2dc:      	add	x8, sp, #0x20
     2e0:      	add	x2, x21, #0x758
     2e4:      	mov	w1, #0x8                // =8
     2e8:      	add	x0, x8, #0x38
     2ec:      	bl	0x2ec <inet_sock_set_state+0x2ec>
     2f0:      	ldr	x8, [sp, #0xa8]
     2f4:      	mov	x9, #0xf7cf             // =63439
     2f8:      	str	w25, [sp, #0x60]
     2fc:      	movk	x9, #0xe353, lsl #16
     300:      	strh	w23, [sp, #0x64]
     304:      	movk	x9, #0x9ba5, lsl #32
     308:      	strh	w24, [sp, #0x66]
     30c:      	strh	w22, [sp, #0x68]
     310:      	movk	x9, #0x20c4, lsl #48
     314:      	lsr	x8, x8, #3
     318:      	umulh	x8, x8, x9
     31c:      	lsr	x8, x8, #4
     320:      	str	x8, [sp, #0x40]
     324:      	ldr	x8, [sp]
     328:      	stp	x8, x29, [sp, #0x48]
     32c:      	add	x8, sp, #0x20
     330:      	add	x0, x8, #0x4a
     334:      	cbz	x20, 0x348 <inet_sock_set_state+0x348>
     338:      	add	x2, x20, #0x4
     33c:      	mov	w1, #0x10               // =16
     340:      	bl	0x340 <inet_sock_set_state+0x340>
     344:      	b	0x350 <inet_sock_set_state+0x350>
     348:      	mov	w1, #0x10               // =16
     34c:      	bl	0x34c <inet_sock_set_state+0x34c>
     350:      	add	x20, sp, #0x20
     354:      	add	x0, sp, #0x8
     358:      	cmp	w22, #0x2
     35c:      	b.ne	0x39c <inet_sock_set_state+0x39c>
     360:      	add	x2, x19, #0x20
     364:      	mov	w1, #0x4                // =4
     368:      	bl	0x368 <inet_sock_set_state+0x368>
     36c:      	add	x0, sp, #0x20
     370:      	add	x2, sp, #0x8
     374:      	mov	w1, #0x4                // =4
     378:      	bl	0x378 <inet_sock_set_state+0x378>
     37c:      	add	x0, sp, #0x8
     380:      	add	x2, x19, #0x24
     384:      	mov	w1, #0x4                // =4
     388:      	bl	0x388 <inet_sock_set_state+0x388>
     38c:      	add	x0, x20, #0x10
     390:      	add	x2, sp, #0x8
     394:      	mov	w1, #0x4                // =4
     398:      	b	0x3d4 <inet_sock_set_state+0x3d4>
     39c:      	add	x2, x19, #0x28
     3a0:      	mov	w1, #0x10               // =16
     3a4:      	bl	0x3a4 <inet_sock_set_state+0x3a4>
     3a8:      	add	x0, sp, #0x20
     3ac:      	add	x2, sp, #0x8
     3b0:      	mov	w1, #0x10               // =16
     3b4:      	bl	0x3b4 <inet_sock_set_state+0x3b4>
     3b8:      	add	x0, sp, #0x8
     3bc:      	add	x2, x19, #0x38
     3c0:      	mov	w1, #0x10               // =16
     3c4:      	bl	0x3c4 <inet_sock_set_state+0x3c4>
     3c8:      	add	x0, x20, #0x10
     3cc:      	add	x2, sp, #0x8
     3d0:      	mov	w1, #0x10               // =16
     3d4:      	bl	0x3d4 <inet_sock_set_state+0x3d4>
     3d8:      	adrp	x1, 0x0 <inet_sock_set_state>
     3dc:      	add	x3, sp, #0x20
     3e0:      	mov	x0, x19
     3e4:      	ldr	x1, [x1]
     3e8:      	mov	w2, #-0x1               // =-1
     3ec:      	mov	w4, #0x60               // =96
     3f0:      	bl	0x3f0 <inet_sock_set_state+0x3f0>
     3f4:      	adrp	x0, 0x0 <inet_sock_set_state>
     3f8:      	add	x1, sp, #0x18
     3fc:      	ldr	x0, [x0]
     400:      	bl	0x400 <inet_sock_set_state+0x400>
     404:      	adrp	x0, 0x0 <inet_sock_set_state>
     408:      	add	x1, sp, #0x18
     40c:      	ldr	x0, [x0]
     410:      	bl	0x410 <inet_sock_set_state+0x410>
     414:      	ldp	x20, x19, [sp, #0xe0]
     418:      	mov	w0, wzr
     41c:      	ldr	x29, [sp, #0xa0]
     420:      	ldp	x22, x21, [sp, #0xd0]
     424:      	ldp	x24, x23, [sp, #0xc0]
     428:      	ldp	x30, x25, [sp, #0xb0]
     42c:      	add	sp, sp, #0xf0
     430:      	ret
