
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_fork_v511.native.o:	file format elf64-littleaarch64

Disassembly of section kprobe/wake_up_new_task:

0000000000000000 <event_wake_up_new_task>:
       0:      	sub	sp, sp, #0x170
       4:      	str	x29, [sp, #0x120]
       8:      	stp	x30, x25, [sp, #0x130]
       c:      	stp	x24, x23, [sp, #0x140]
      10:      	stp	x22, x21, [sp, #0x150]
      14:      	stp	x20, x19, [sp, #0x160]
      18:      	ldr	x23, [x0]
      1c:      	cbz	x23, 0xe28 <event_wake_up_new_task+0xe28>
      20:      	add	x2, x23, #0x8d4
      24:      	mov	w8, #0x4                // =4
      28:      	add	x9, sp, #0x18
      2c:      	mov	x19, x0
      30:      	add	x0, sp, #0x18
      34:      	mov	w1, #0x4                // =4
      38:      	blr	x8
      3c:      	ldr	w22, [sp, #0x18]
      40:      	str	x23, [sp, #0x18]
      44:      	add	x8, x23, #0x8e0
      48:      	mov	w9, #0x8                // =8
      4c:      	mov	w10, #0x71              // =113
      50:      	add	x11, sp, #0x18
      54:      	add	x0, sp, #0x18
      58:      	mov	w1, #0x8                // =8
      5c:      	ldr	x8, [sp, #0x18]
      60:      	add	x2, x8, #0x8e0
      64:      	blr	x10
      68:      	ldr	x8, [sp, #0x18]
      6c:      	cbz	x8, 0xe28 <event_wake_up_new_task+0xe28>
      70:      	add	x8, x8, #0x8d4
      74:      	mov	w9, #0x4                // =4
      78:      	mov	w10, #0x71              // =113
      7c:      	add	x11, sp, #0xe0
      80:      	ldr	x8, [sp, #0x18]
      84:      	add	x0, sp, #0xe0
      88:      	mov	w1, #0x4                // =4
      8c:      	add	x2, x8, #0x8d4
      90:      	blr	x10
      94:      	ldr	w8, [sp, #0xe0]
      98:      	adrp	x21, 0x0 <event_wake_up_new_task>
      9c:      	add	x9, sp, #0xa8
      a0:      	add	x1, sp, #0xa8
      a4:      	str	w8, [sp, #0xa8]
      a8:      	mov	w8, #0x1                // =1
      ac:      	ldr	x21, [x21]
      b0:      	mov	x0, x21
      b4:      	blr	x8
      b8:      	cbz	x0, 0xc4 <event_wake_up_new_task+0xc4>
      bc:      	ldr	x8, [x0, #0x8]
      c0:      	cbnz	x8, 0x238 <event_wake_up_new_task+0x238>
      c4:      	ldr	x8, [sp, #0x18]
      c8:      	mov	w9, #0x8                // =8
      cc:      	mov	w10, #0x71              // =113
      d0:      	add	x11, sp, #0x18
      d4:      	add	x0, sp, #0x18
      d8:      	mov	w1, #0x8                // =8
      dc:      	add	x8, x8, #0x8e0
      e0:      	ldr	x8, [sp, #0x18]
      e4:      	add	x2, x8, #0x8e0
      e8:      	blr	x10
      ec:      	ldr	x8, [sp, #0x18]
      f0:      	cbz	x8, 0xe28 <event_wake_up_new_task+0xe28>
      f4:      	add	x8, x8, #0x8d4
      f8:      	mov	w9, #0x4                // =4
      fc:      	mov	w10, #0x71              // =113
     100:      	add	x11, sp, #0xe0
     104:      	ldr	x8, [sp, #0x18]
     108:      	add	x0, sp, #0xe0
     10c:      	mov	w1, #0x4                // =4
     110:      	add	x2, x8, #0x8d4
     114:      	blr	x10
     118:      	ldr	w8, [sp, #0xe0]
     11c:      	add	x9, sp, #0xa8
     120:      	add	x1, sp, #0xa8
     124:      	mov	x0, x21
     128:      	str	w8, [sp, #0xa8]
     12c:      	mov	w8, #0x1                // =1
     130:      	blr	x8
     134:      	cbz	x0, 0x140 <event_wake_up_new_task+0x140>
     138:      	ldr	x8, [x0, #0x8]
     13c:      	cbnz	x8, 0x238 <event_wake_up_new_task+0x238>
     140:      	ldr	x8, [sp, #0x18]
     144:      	mov	w9, #0x8                // =8
     148:      	mov	w10, #0x71              // =113
     14c:      	add	x11, sp, #0x18
     150:      	add	x0, sp, #0x18
     154:      	mov	w1, #0x8                // =8
     158:      	add	x8, x8, #0x8e0
     15c:      	ldr	x8, [sp, #0x18]
     160:      	add	x2, x8, #0x8e0
     164:      	blr	x10
     168:      	ldr	x8, [sp, #0x18]
     16c:      	cbz	x8, 0xe28 <event_wake_up_new_task+0xe28>
     170:      	add	x8, x8, #0x8d4
     174:      	mov	w9, #0x4                // =4
     178:      	mov	w10, #0x71              // =113
     17c:      	add	x11, sp, #0xe0
     180:      	ldr	x8, [sp, #0x18]
     184:      	add	x0, sp, #0xe0
     188:      	mov	w1, #0x4                // =4
     18c:      	add	x2, x8, #0x8d4
     190:      	blr	x10
     194:      	ldr	w8, [sp, #0xe0]
     198:      	add	x9, sp, #0xa8
     19c:      	add	x1, sp, #0xa8
     1a0:      	mov	x0, x21
     1a4:      	str	w8, [sp, #0xa8]
     1a8:      	mov	w8, #0x1                // =1
     1ac:      	blr	x8
     1b0:      	cbz	x0, 0x1bc <event_wake_up_new_task+0x1bc>
     1b4:      	ldr	x8, [x0, #0x8]
     1b8:      	cbnz	x8, 0x238 <event_wake_up_new_task+0x238>
     1bc:      	ldr	x8, [sp, #0x18]
     1c0:      	mov	w9, #0x8                // =8
     1c4:      	mov	w10, #0x71              // =113
     1c8:      	add	x11, sp, #0x18
     1cc:      	add	x0, sp, #0x18
     1d0:      	mov	w1, #0x8                // =8
     1d4:      	add	x8, x8, #0x8e0
     1d8:      	ldr	x8, [sp, #0x18]
     1dc:      	add	x2, x8, #0x8e0
     1e0:      	blr	x10
     1e4:      	ldr	x8, [sp, #0x18]
     1e8:      	cbz	x8, 0xe28 <event_wake_up_new_task+0xe28>
     1ec:      	add	x8, x8, #0x8d4
     1f0:      	mov	w9, #0x4                // =4
     1f4:      	mov	w10, #0x71              // =113
     1f8:      	add	x11, sp, #0xe0
     1fc:      	ldr	x8, [sp, #0x18]
     200:      	add	x0, sp, #0xe0
     204:      	mov	w1, #0x4                // =4
     208:      	add	x2, x8, #0x8d4
     20c:      	blr	x10
     210:      	ldr	w8, [sp, #0xe0]
     214:      	add	x9, sp, #0xa8
     218:      	add	x1, sp, #0xa8
     21c:      	mov	x0, x21
     220:      	str	w8, [sp, #0xa8]
     224:      	mov	w8, #0x1                // =1
     228:      	blr	x8
     22c:      	cbz	x0, 0xe28 <event_wake_up_new_task+0xe28>
     230:      	ldr	x8, [x0, #0x8]
     234:      	cbz	x8, 0xe28 <event_wake_up_new_task+0xe28>
     238:      	str	x0, [sp, #0x10]
     23c:      	str	w22, [sp, #0xa8]
     240:      	mov	w8, #0x1                // =1
     244:      	add	x9, sp, #0xa8
     248:      	add	x1, sp, #0xa8
     24c:      	mov	x0, x21
     250:      	blr	x8
     254:      	cbz	x0, 0x4d4 <event_wake_up_new_task+0x4d4>
     258:      	mov	x20, x0
     25c:      	ldr	x8, [x20, #0x8]
     260:      	cbnz	x8, 0xe28 <event_wake_up_new_task+0xe28>
     264:      	mov	w8, #0x1                // =1
     268:      	str	w22, [x20]
     26c:      	str	w8, [x20, #0x20]
     270:      	mov	w8, #0x7d               // =125
     274:      	blr	x8
     278:      	str	x0, [x20, #0x8]
     27c:      	add	x2, x23, #0x60
     280:      	mov	w8, #0x8                // =8
     284:      	mov	w9, #0x71               // =113
     288:      	add	x10, sp, #0xa8
     28c:      	add	x0, sp, #0xa8
     290:      	mov	w1, #0x8                // =8
     294:      	blr	x9
     298:      	ldr	x8, [sp, #0xa8]
     29c:      	cbz	x8, 0x30c <event_wake_up_new_task+0x30c>
     2a0:      	add	x8, x8, #0x4
     2a4:      	mov	w9, #0x4                // =4
     2a8:      	mov	w10, #0x71              // =113
     2ac:      	add	x11, sp, #0xe0
     2b0:      	ldr	x8, [sp, #0xa8]
     2b4:      	add	x0, sp, #0xe0
     2b8:      	mov	w1, #0x4                // =4
     2bc:      	add	x2, x8, #0x4
     2c0:      	blr	x10
     2c4:      	ldr	w8, [sp, #0xe0]
     2c8:      	cbz	w8, 0x30c <event_wake_up_new_task+0x30c>
     2cc:      	ldr	x9, [sp, #0xa8]
     2d0:      	lsl	w8, w8, #4
     2d4:      	mov	w10, #0x71              // =113
     2d8:      	add	x11, sp, #0x18
     2dc:      	add	x0, sp, #0x18
     2e0:      	mov	w1, #0x10               // =16
     2e4:      	add	x8, x9, x8
     2e8:      	mov	w9, #0x10               // =16
     2ec:      	add	x8, x8, #0x80
     2f0:      	ldr	w9, [sp, #0xe0]
     2f4:      	ldr	x8, [sp, #0xa8]
     2f8:      	lsl	w9, w9, #4
     2fc:      	add	x8, x8, x9
     300:      	add	x2, x8, #0x80
     304:      	blr	x10
     308:      	ldr	w8, [sp, #0x18]
     30c:      	ldr	x21, [sp, #0x10]
     310:      	add	x0, x20, #0x68
     314:      	mov	w2, #0x318              // =792
     318:      	str	w8, [x20, #0x24]
     31c:      	add	x1, x21, #0x68
     320:      	bl	0x320 <event_wake_up_new_task+0x320>
     324:      	ldp	x9, x8, [x21]
     328:      	mov	x25, x20
     32c:      	add	x2, x23, #0xae0
     330:      	mov	w24, #0x8               // =8
     334:      	add	x0, sp, #0x18
     338:      	mov	w1, #0x8                // =8
     33c:      	mov	w29, #0x4               // =4
     340:      	stp	x9, x8, [x25, #0x10]!
     344:      	add	x8, sp, #0x18
     348:      	mov	w9, #0x4                // =4
     34c:      	add	x22, x25, #0x40
     350:      	str	x2, [sp, #0x8]
     354:      	blr	x9
     358:      	ldr	x21, [sp, #0x18]
     35c:      	add	x0, x25, #0x48
     360:      	mov	w8, #0x4                // =4
     364:      	mov	w1, #0x8                // =8
     368:      	add	x2, x21, #0x40
     36c:      	blr	x8
     370:      	add	x0, x25, #0x50
     374:      	add	x2, x21, #0x30
     378:      	mov	w8, #0x4                // =4
     37c:      	mov	w1, #0x8                // =8
     380:      	blr	x8
     384:      	add	x2, x21, #0x38
     388:      	mov	w8, #0x4                // =4
     38c:      	mov	x0, x22
     390:      	mov	w1, #0x8                // =8
     394:      	blr	x8
     398:      	add	x2, x23, #0xb50
     39c:      	add	x8, sp, #0xe0
     3a0:      	mov	w9, #0x4                // =4
     3a4:      	add	x0, sp, #0xe0
     3a8:      	mov	w1, #0x8                // =8
     3ac:      	add	x22, x25, #0x18
     3b0:      	blr	x9
     3b4:      	ldr	x8, [sp, #0xe0]
     3b8:      	mov	w9, #0x48               // =72
     3bc:      	add	x10, sp, #0x18
     3c0:      	mov	w11, #0x4               // =4
     3c4:      	ldr	x2, [sp, #0xe0]
     3c8:      	add	x0, sp, #0x18
     3cc:      	mov	w1, #0x48               // =72
     3d0:      	blr	x11
     3d4:      	ldr	x8, [sp, #0x20]
     3d8:      	mov	w9, #0x4                // =4
     3dc:      	mov	x0, x22
     3e0:      	mov	w1, #0x4                // =4
     3e4:      	add	x8, x8, #0x218
     3e8:      	ldr	x8, [sp, #0x20]
     3ec:      	add	x2, x8, #0x218
     3f0:      	blr	x9
     3f4:      	ldr	x8, [sp, #0x28]
     3f8:      	add	x0, x25, #0x1c
     3fc:      	mov	w9, #0x4                // =4
     400:      	mov	w1, #0x4                // =4
     404:      	add	x8, x8, #0x4d8
     408:      	ldr	x8, [sp, #0x28]
     40c:      	add	x2, x8, #0x4d8
     410:      	blr	x9
     414:      	ldr	x8, [sp, #0x30]
     418:      	add	x0, x25, #0x20
     41c:      	mov	w9, #0x4                // =4
     420:      	mov	w1, #0x4                // =4
     424:      	add	x8, x8, #0x58
     428:      	ldr	x8, [sp, #0x30]
     42c:      	add	x2, x8, #0x58
     430:      	blr	x9
     434:      	str	xzr, [sp, #0x118]
     438:      	add	x2, x23, #0x938
     43c:      	add	x8, sp, #0x118
     440:      	add	x0, sp, #0x118
     444:      	mov	w1, #0x8                // =8
     448:      	blr	x29
     44c:      	ldr	x8, [sp, #0x118]
     450:      	cbz	x8, 0x574 <event_wake_up_new_task+0x574>
     454:      	str	wzr, [sp, #0x110]
     458:      	add	x8, x8, #0x4
     45c:      	add	x9, sp, #0x110
     460:      	mov	w10, #0x4               // =4
     464:      	add	x0, sp, #0x110
     468:      	mov	w1, #0x4                // =4
     46c:      	mov	w21, #0x4               // =4
     470:      	ldr	x8, [sp, #0x118]
     474:      	add	x2, x8, #0x4
     478:      	blr	x10
     47c:      	ldr	x8, [sp, #0x118]
     480:      	ldrsw	x9, [sp, #0x110]
     484:      	add	x10, sp, #0xa8
     488:      	mov	w11, #0x4               // =4
     48c:      	add	x0, sp, #0xa8
     490:      	mov	w1, #0x10               // =16
     494:      	add	x8, x8, x9, lsl #4
     498:      	mov	w9, #0x10               // =16
     49c:      	add	x8, x8, #0x80
     4a0:      	ldr	x8, [sp, #0x118]
     4a4:      	ldrsw	x9, [sp, #0x110]
     4a8:      	add	x8, x8, x9, lsl #4
     4ac:      	add	x2, x8, #0x80
     4b0:      	blr	x11
     4b4:      	ldr	x8, [sp, #0xb0]
     4b8:      	add	x0, x20, #0x34
     4bc:      	mov	w1, #0x4                // =4
     4c0:      	add	x8, x8, #0x158
     4c4:      	ldr	x8, [sp, #0xb0]
     4c8:      	add	x2, x8, #0x158
     4cc:      	blr	x21
     4d0:      	b	0x578 <event_wake_up_new_task+0x578>
     4d4:      	str	wzr, [sp, #0xe0]
     4d8:      	adrp	x0, 0x0 <event_wake_up_new_task>
     4dc:      	mov	w8, #0x1                // =1
     4e0:      	add	x9, sp, #0xe0
     4e4:      	ldr	x0, [x0]
     4e8:      	add	x1, sp, #0xe0
     4ec:      	blr	x8
     4f0:      	cbz	x0, 0xe28 <event_wake_up_new_task+0xe28>
     4f4:      	mov	w1, wzr
     4f8:      	mov	w2, #0x380              // =896
     4fc:      	mov	x20, x0
     500:      	bl	0x500 <event_wake_up_new_task+0x500>
     504:      	mov	x3, xzr
     508:      	mov	w8, #0x2                // =2
     50c:      	add	x9, sp, #0xa8
     510:      	add	x1, sp, #0xa8
     514:      	mov	x0, x21
     518:      	mov	x2, x20
     51c:      	blr	x8
     520:      	mov	x8, x0
     524:      	adrp	x0, 0x0 <event_wake_up_new_task>
     528:      	ldr	x0, [x0]
     52c:      	cbz	w8, 0x878 <event_wake_up_new_task+0x878>
     530:      	mov	w8, #0x1                // =1
     534:      	add	x9, sp, #0x18
     538:      	str	w8, [sp, #0x18]
     53c:      	add	x1, sp, #0x18
     540:      	blr	x8
     544:      	cbz	x0, 0x554 <event_wake_up_new_task+0x554>
     548:      	ldr	x8, [x0]
     54c:      	add	x8, x8, #0x1
     550:      	str	x8, [x0]
     554:      	mov	w8, #0x1                // =1
     558:      	add	x9, sp, #0xa8
     55c:      	add	x1, sp, #0xa8
     560:      	mov	x0, x21
     564:      	blr	x8
     568:      	mov	x20, x0
     56c:      	cbnz	x0, 0x25c <event_wake_up_new_task+0x25c>
     570:      	b	0xe28 <event_wake_up_new_task+0xe28>
     574:      	str	wzr, [x20, #0x34]
     578:      	ldr	x8, [sp, #0x38]
     57c:      	add	x0, x20, #0x38
     580:      	mov	w9, #0x4                // =4
     584:      	mov	w1, #0x4                // =4
     588:      	mov	w22, #0x4               // =4
     58c:      	add	x8, x8, #0x158
     590:      	ldr	x8, [sp, #0x38]
     594:      	add	x2, x8, #0x158
     598:      	blr	x9
     59c:      	ldr	x8, [sp, #0x40]
     5a0:      	add	x0, x20, #0x3c
     5a4:      	mov	w9, #0x4                // =4
     5a8:      	mov	w1, #0x4                // =4
     5ac:      	add	x8, x8, #0x118
     5b0:      	ldr	x8, [sp, #0x40]
     5b4:      	add	x2, x8, #0x118
     5b8:      	blr	x9
     5bc:      	ldr	x8, [sp, #0x48]
     5c0:      	add	x0, x20, #0x40
     5c4:      	mov	w9, #0x4                // =4
     5c8:      	mov	w1, #0x4                // =4
     5cc:      	add	x8, x8, #0x98
     5d0:      	ldr	x8, [sp, #0x48]
     5d4:      	add	x2, x8, #0x98
     5d8:      	blr	x9
     5dc:      	ldr	x8, [sp, #0x50]
     5e0:      	add	x0, x20, #0x44
     5e4:      	mov	w9, #0x4                // =4
     5e8:      	mov	w1, #0x4                // =4
     5ec:      	add	x8, x8, #0x98
     5f0:      	ldr	x8, [sp, #0x50]
     5f4:      	add	x2, x8, #0x98
     5f8:      	blr	x9
     5fc:      	ldr	x8, [sp, #0x58]
     600:      	add	x0, x20, #0x48
     604:      	mov	w9, #0x4                // =4
     608:      	mov	w1, #0x4                // =4
     60c:      	add	x8, x8, #0x58
     610:      	ldr	x8, [sp, #0x58]
     614:      	add	x2, x8, #0x58
     618:      	blr	x9
     61c:      	str	xzr, [sp, #0xa8]
     620:      	str	xzr, [sp, #0x118]
     624:      	ldr	x2, [sp, #0x8]
     628:      	mov	w21, #0x8               // =8
     62c:      	add	x8, sp, #0xa8
     630:      	mov	w9, #0x4                // =4
     634:      	add	x0, sp, #0xa8
     638:      	mov	w1, #0x8                // =8
     63c:      	blr	x9
     640:      	ldr	x8, [sp, #0xa8]
     644:      	add	x9, sp, #0x118
     648:      	mov	w10, #0x4               // =4
     64c:      	add	x0, sp, #0x118
     650:      	mov	w1, #0x8                // =8
     654:      	add	x8, x8, #0x90
     658:      	ldr	x8, [sp, #0xa8]
     65c:      	add	x2, x8, #0x90
     660:      	blr	x10
     664:      	ldr	x8, [sp, #0x118]
     668:      	add	x0, x20, #0x4c
     66c:      	mov	w1, #0x4                // =4
     670:      	add	x8, x8, #0x158
     674:      	ldr	x8, [sp, #0x118]
     678:      	add	x2, x8, #0x158
     67c:      	blr	x22
     680:      	ldr	x8, [sp, #0x10]
     684:      	ldrb	w8, [x8, #0x23]
     688:      	tbnz	w8, #0x1, 0x698 <event_wake_up_new_task+0x698>
     68c:      	ldr	w8, [x20, #0x24]
     690:      	cmp	w8, #0x1
     694:      	b.ne	0x6a4 <event_wake_up_new_task+0x6a4>
     698:      	ldr	w8, [x20, #0x20]
     69c:      	orr	w8, w8, #0x2000000
     6a0:      	str	w8, [x20, #0x20]
     6a4:      	mov	w8, #0x17               // =23
     6a8:      	ldp	x9, x10, [x25]
     6ac:      	add	x2, x23, #0x8d0
     6b0:      	add	x0, sp, #0x18
     6b4:      	mov	w1, #0x4                // =4
     6b8:      	strb	w8, [sp, #0xa8]
     6bc:      	mov	w8, #0x38               // =56
     6c0:      	str	w8, [sp, #0xac]
     6c4:      	ldr	x8, [x20, #0x8]
     6c8:      	stp	x9, x10, [sp, #0xb8]
     6cc:      	add	x9, sp, #0x18
     6d0:      	str	x8, [sp, #0xb0]
     6d4:      	ldr	w8, [x20]
     6d8:      	str	w8, [sp, #0xc8]
     6dc:      	mov	w8, #0x4                // =4
     6e0:      	blr	x8
     6e4:      	ldr	w8, [sp, #0x18]
     6e8:      	str	wzr, [sp, #0x12c]
     6ec:      	add	x9, sp, #0x12c
     6f0:      	add	x1, sp, #0x12c
     6f4:      	str	w8, [sp, #0xcc]
     6f8:      	ldr	x8, [x20, #0x8]
     6fc:      	stp	xzr, xzr, [sp, #0x18]
     700:      	stp	xzr, xzr, [sp, #0x28]
     704:      	str	x8, [sp, #0xd8]
     708:      	ldr	w8, [x20, #0x24]
     70c:      	str	w8, [sp, #0xd0]
     710:      	ldr	w8, [x20, #0x20]
     714:      	stp	xzr, xzr, [sp, #0x38]
     718:      	adrp	x20, 0x0 <event_wake_up_new_task>
     71c:      	stp	xzr, xzr, [sp, #0x48]
     720:      	stp	xzr, xzr, [sp, #0x58]
     724:      	str	w8, [sp, #0xd4]
     728:      	stp	xzr, xzr, [sp, #0x68]
     72c:      	stp	xzr, xzr, [sp, #0x78]
     730:      	mov	w8, #0x1                // =1
     734:      	stp	xzr, xzr, [sp, #0x88]
     738:      	stp	xzr, xzr, [sp, #0x98]
     73c:      	ldr	x20, [x20]
     740:      	mov	x0, x20
     744:      	blr	x8
     748:      	cbz	x0, 0x758 <event_wake_up_new_task+0x758>
     74c:      	ldr	x21, [x0, #0x20]
     750:      	ldr	w22, [x0, #0x10]
     754:      	b	0x760 <event_wake_up_new_task+0x760>
     758:      	mov	w22, wzr
     75c:      	mov	x21, xzr
     760:      	str	xzr, [sp, #0x110]
     764:      	add	x2, x23, #0xcd0
     768:      	mov	w8, #0x8                // =8
     76c:      	mov	w9, #0x71               // =113
     770:      	add	x10, sp, #0x118
     774:      	mov	w24, #0x7270            // =29296
     778:      	add	x0, sp, #0x118
     77c:      	mov	w1, #0x8                // =8
     780:      	movk	w24, #0x6367, lsl #16
     784:      	blr	x9
     788:      	ldr	x8, [sp, #0x118]
     78c:      	cbz	x8, 0x80c <event_wake_up_new_task+0x80c>
     790:      	cmp	x21, x24
     794:      	b.ne	0x7b8 <event_wake_up_new_task+0x7b8>
     798:      	add	x8, x8, #0x78
     79c:      	mov	w9, #0x8                // =8
     7a0:      	mov	w10, #0x71              // =113
     7a4:      	add	x11, sp, #0x110
     7a8:      	ldr	x8, [sp, #0x118]
     7ac:      	add	x0, sp, #0x110
     7b0:      	add	x2, x8, #0x78
     7b4:      	b	0x804 <event_wake_up_new_task+0x804>
     7b8:      	cmp	w22, #0xb
     7bc:      	b.hi	0x80c <event_wake_up_new_task+0x80c>
     7c0:      	ubfiz	x9, x22, #3, #32
     7c4:      	mov	w10, #0x8               // =8
     7c8:      	mov	w11, #0x71              // =113
     7cc:      	add	x12, sp, #0xe0
     7d0:      	add	x0, sp, #0xe0
     7d4:      	mov	w1, #0x8                // =8
     7d8:      	add	x8, x8, x9
     7dc:      	ldr	x8, [sp, #0x118]
     7e0:      	add	x2, x8, x9
     7e4:      	blr	x11
     7e8:      	ldr	x8, [sp, #0xe0]
     7ec:      	cbz	x8, 0x80c <event_wake_up_new_task+0x80c>
     7f0:      	mov	w9, #0x8                // =8
     7f4:      	mov	w10, #0x71              // =113
     7f8:      	add	x11, sp, #0x110
     7fc:      	ldr	x2, [sp, #0xe0]
     800:      	add	x0, sp, #0x110
     804:      	mov	w1, #0x8                // =8
     808:      	blr	x10
     80c:      	ldr	x22, [sp, #0x110]
     810:      	cbz	x22, 0x934 <event_wake_up_new_task+0x934>
     814:      	cmp	x21, x24
     818:      	b.ne	0x828 <event_wake_up_new_task+0x828>
     81c:      	mov	w8, #0x50               // =80
     820:      	blr	x8
     824:      	b	0x898 <event_wake_up_new_task+0x898>
     828:      	str	xzr, [sp, #0xe0]
     82c:      	add	x2, x22, #0x100
     830:      	mov	w8, #0x8                // =8
     834:      	mov	w9, #0x71               // =113
     838:      	add	x10, sp, #0xe0
     83c:      	add	x0, sp, #0xe0
     840:      	mov	w1, #0x8                // =8
     844:      	blr	x9
     848:      	ldr	x8, [sp, #0xe0]
     84c:      	str	xzr, [sp, #0xe0]
     850:      	cbz	x8, 0x894 <event_wake_up_new_task+0x894>
     854:      	add	x2, x8, #0x60
     858:      	mov	w8, #0x8                // =8
     85c:      	mov	w9, #0x71               // =113
     860:      	add	x10, sp, #0xe0
     864:      	add	x0, sp, #0xe0
     868:      	mov	w1, #0x8                // =8
     86c:      	blr	x9
     870:      	ldr	x0, [sp, #0xe0]
     874:      	b	0x898 <event_wake_up_new_task+0x898>
     878:      	str	wzr, [sp, #0x18]
     87c:      	mov	w8, #0x1                // =1
     880:      	add	x9, sp, #0x18
     884:      	add	x1, sp, #0x18
     888:      	blr	x8
     88c:      	cbnz	x0, 0x548 <event_wake_up_new_task+0x548>
     890:      	b	0x554 <event_wake_up_new_task+0x554>
     894:      	mov	x0, xzr
     898:      	str	x0, [sp, #0x18]
     89c:      	cbz	x0, 0x8d0 <event_wake_up_new_task+0x8d0>
     8a0:      	str	x0, [sp, #0xe0]
     8a4:      	adrp	x0, 0x0 <event_wake_up_new_task>
     8a8:      	mov	w8, #0x1                // =1
     8ac:      	add	x9, sp, #0xe0
     8b0:      	ldr	x0, [x0]
     8b4:      	add	x1, sp, #0xe0
     8b8:      	blr	x8
     8bc:      	cbz	x0, 0x8c8 <event_wake_up_new_task+0x8c8>
     8c0:      	ldr	x8, [x0]
     8c4:      	b	0x8cc <event_wake_up_new_task+0x8cc>
     8c8:      	mov	x8, xzr
     8cc:      	str	x8, [sp, #0x20]
     8d0:      	add	x2, x22, #0x100
     8d4:      	mov	w21, #0x8               // =8
     8d8:      	add	x8, sp, #0x118
     8dc:      	mov	w9, #0x4                // =4
     8e0:      	add	x0, sp, #0x118
     8e4:      	mov	w1, #0x8                // =8
     8e8:      	mov	w22, #0x4               // =4
     8ec:      	blr	x9
     8f0:      	ldr	x8, [sp, #0x118]
     8f4:      	add	x9, sp, #0xe0
     8f8:      	add	x0, sp, #0xe0
     8fc:      	mov	w1, #0x8                // =8
     900:      	add	x8, x8, #0x10
     904:      	ldr	x8, [sp, #0x118]
     908:      	add	x2, x8, #0x10
     90c:      	blr	x22
     910:      	cbnz	x0, 0x934 <event_wake_up_new_task+0x934>
     914:      	ldr	x2, [sp, #0xe0]
     918:      	cbz	x2, 0x934 <event_wake_up_new_task+0x934>
     91c:      	add	x8, sp, #0x18
     920:      	mov	w9, #0x2d               // =45
     924:      	mov	w1, #0x80               // =128
     928:      	add	x0, x8, #0x10
     92c:      	mov	w8, #0x80               // =128
     930:      	blr	x9
     934:      	ldr	x8, [sp, #0x18]
     938:      	str	wzr, [sp, #0x10c]
     93c:      	adrp	x0, 0x0 <event_wake_up_new_task>
     940:      	add	x9, sp, #0x10c
     944:      	add	x1, sp, #0x10c
     948:      	ldr	x23, [sp, #0xd8]
     94c:      	str	x8, [sp, #0x118]
     950:      	mov	w8, #0x1                // =1
     954:      	ldr	x0, [x0]
     958:      	blr	x8
     95c:      	cbz	x0, 0xc50 <event_wake_up_new_task+0xc50>
     960:      	ldr	x22, [x0, #0x8]
     964:      	cbz	x22, 0xc50 <event_wake_up_new_task+0xc50>
     968:      	adrp	x21, 0x0 <event_wake_up_new_task>
     96c:      	mov	w8, #0x1                // =1
     970:      	add	x9, sp, #0x118
     974:      	ldr	x21, [x21]
     978:      	mov	x24, x0
     97c:      	add	x1, sp, #0x118
     980:      	mov	x0, x21
     984:      	blr	x8
     988:      	cbz	x0, 0x9b4 <event_wake_up_new_task+0x9b4>
     98c:      	ldr	x8, [x0, #0x10]
     990:      	sub	x9, x23, x8
     994:      	cmp	x9, x22
     998:      	b.ls	0x9f0 <event_wake_up_new_task+0x9f0>
     99c:      	cmp	x9, x22, lsl #1
     9a0:      	b.ls	0x9f8 <event_wake_up_new_task+0x9f8>
     9a4:      	udiv	x8, x23, x22
     9a8:      	mov	x9, xzr
     9ac:      	mul	x8, x8, x22
     9b0:      	b	0xa00 <event_wake_up_new_task+0xa00>
     9b4:      	mov	w8, #0x1                // =1
     9b8:      	str	xzr, [sp, #0x100]
     9bc:      	mov	x3, xzr
     9c0:      	add	x9, sp, #0x118
     9c4:      	stp	x8, xzr, [sp, #0xe0]
     9c8:      	udiv	x8, x23, x22
     9cc:      	add	x10, sp, #0xe0
     9d0:      	add	x1, sp, #0x118
     9d4:      	add	x2, sp, #0xe0
     9d8:      	mov	x0, x21
     9dc:      	mul	x8, x8, x22
     9e0:      	stp	x8, xzr, [sp, #0xf0]
     9e4:      	mov	w8, #0x2                // =2
     9e8:      	blr	x8
     9ec:      	b	0xc50 <event_wake_up_new_task+0xc50>
     9f0:      	ldp	x10, x9, [x0]
     9f4:      	b	0xa08 <event_wake_up_new_task+0xa08>
     9f8:      	ldr	x9, [x0]
     9fc:      	add	x8, x8, x22
     a00:      	mov	x10, xzr
     a04:      	stp	x9, x8, [x0, #0x8]
     a08:      	sub	x11, x22, x23
     a0c:      	add	x10, x10, #0x1
     a10:      	add	x8, x11, x8
     a14:      	str	x10, [x0]
     a18:      	mul	x8, x8, x9
     a1c:      	ldr	x9, [x0, #0x20]
     a20:      	udiv	x8, x8, x22
     a24:      	add	x8, x8, x10
     a28:      	str	x8, [x0, #0x18]
     a2c:      	cbnz	x9, 0xe28 <event_wake_up_new_task+0xe28>
     a30:      	ldr	x9, [x24]
     a34:      	cmp	x8, x9
     a38:      	b.lo	0xc50 <event_wake_up_new_task+0xc50>
     a3c:      	mov	x22, x0
     a40:      	str	x23, [x0, #0x20]
     a44:      	str	wzr, [sp, #0x12c]
     a48:      	adrp	x0, 0x0 <event_wake_up_new_task>
     a4c:      	mov	w8, #0x1                // =1
     a50:      	add	x9, sp, #0x12c
     a54:      	ldr	x0, [x0]
     a58:      	add	x1, sp, #0x128
     a5c:      	str	wzr, [sp, #0x128]
     a60:      	blr	x8
     a64:      	cbz	x0, 0xc48 <event_wake_up_new_task+0xc48>
     a68:      	mov	w8, #0xa0               // =160
     a6c:      	mov	x21, x0
     a70:      	str	x23, [x0, #0x8]
     a74:      	add	x1, sp, #0x18
     a78:      	str	w8, [x0, #0x4]
     a7c:      	mov	w8, #0x1b               // =27
     a80:      	mov	w2, #0x90               // =144
     a84:      	strh	w8, [x0], #0x10
     a88:      	bl	0xa88 <event_wake_up_new_task+0xa88>
     a8c:      	str	wzr, [sp, #0x110]
     a90:      	mov	w8, #0x1                // =1
     a94:      	add	x9, sp, #0x110
     a98:      	add	x1, sp, #0x110
     a9c:      	mov	x0, x20
     aa0:      	blr	x8
     aa4:      	cbz	x0, 0xb28 <event_wake_up_new_task+0xb28>
     aa8:      	ldrb	w8, [x0, #0x28]
     aac:      	cbz	w8, 0xb28 <event_wake_up_new_task+0xb28>
     ab0:      	adrp	x1, 0x0 <event_wake_up_new_task>
     ab4:      	mov	w8, #-0x1               // =-1
     ab8:      	mov	w9, #0xa0               // =160
     abc:      	ldr	x1, [x1]
     ac0:      	mov	w10, #0x19              // =25
     ac4:      	mov	x0, x19
     ac8:      	mov	w2, #-0x1               // =-1
     acc:      	mov	x3, x21
     ad0:      	mov	w4, #0xa0               // =160
     ad4:      	blr	x10
     ad8:      	tbz	x0, #0x3f, 0xc48 <event_wake_up_new_task+0xc48>
     adc:      	mov	x21, x0
     ae0:      	str	wzr, [sp, #0xe0]
     ae4:      	adrp	x0, 0x0 <event_wake_up_new_task>
     ae8:      	mov	w8, #0x1                // =1
     aec:      	ldr	x0, [x0]
     af0:      	add	x9, sp, #0xe0
     af4:      	add	x1, sp, #0xe0
     af8:      	blr	x8
     afc:      	cbz	x0, 0xc48 <event_wake_up_new_task+0xc48>
     b00:      	cmn	x21, #0xc
     b04:      	b.gt	0xbbc <event_wake_up_new_task+0xbbc>
     b08:      	cmn	x21, #0x1c
     b0c:      	b.eq	0xc14 <event_wake_up_new_task+0xc14>
     b10:      	cmn	x21, #0x16
     b14:      	b.eq	0xc2c <event_wake_up_new_task+0xc2c>
     b18:      	cmn	x21, #0x10
     b1c:      	b.ne	0xc24 <event_wake_up_new_task+0xc24>
     b20:      	add	x8, x0, #0x600
     b24:      	b	0xc38 <event_wake_up_new_task+0xc38>
     b28:      	adrp	x0, 0x0 <event_wake_up_new_task>
     b2c:      	mov	x3, xzr
     b30:      	mov	w8, #0xa0               // =160
     b34:      	ldr	x0, [x0]
     b38:      	mov	w9, #0x82               // =130
     b3c:      	mov	x1, x21
     b40:      	mov	w2, #0xa0               // =160
     b44:      	blr	x9
     b48:      	tbz	x0, #0x3f, 0xc48 <event_wake_up_new_task+0xc48>
     b4c:      	mov	x21, x0
     b50:      	str	wzr, [sp, #0xe0]
     b54:      	adrp	x0, 0x0 <event_wake_up_new_task>
     b58:      	mov	w8, #0x1                // =1
     b5c:      	ldr	x0, [x0]
     b60:      	add	x9, sp, #0xe0
     b64:      	add	x1, sp, #0xe0
     b68:      	blr	x8
     b6c:      	cbz	x0, 0xc48 <event_wake_up_new_task+0xc48>
     b70:      	mov	x8, x21
     b74:      	cmn	x21, #0xc
     b78:      	b.gt	0xb9c <event_wake_up_new_task+0xb9c>
     b7c:      	cmn	x8, #0x1c
     b80:      	b.eq	0xbdc <event_wake_up_new_task+0xbdc>
     b84:      	cmn	x8, #0x16
     b88:      	b.eq	0xbf4 <event_wake_up_new_task+0xbf4>
     b8c:      	cmn	x8, #0x10
     b90:      	b.ne	0xbec <event_wake_up_new_task+0xbec>
     b94:      	add	x8, x0, #0x600
     b98:      	b	0xc00 <event_wake_up_new_task+0xc00>
     b9c:      	cmn	x8, #0xb
     ba0:      	b.eq	0xbe4 <event_wake_up_new_task+0xbe4>
     ba4:      	cmn	x8, #0x7
     ba8:      	b.eq	0xbfc <event_wake_up_new_task+0xbfc>
     bac:      	cmn	x8, #0x2
     bb0:      	b.ne	0xbec <event_wake_up_new_task+0xbec>
     bb4:      	add	x8, x0, #0x5f0
     bb8:      	b	0xc00 <event_wake_up_new_task+0xc00>
     bbc:      	cmn	x21, #0xb
     bc0:      	b.eq	0xc1c <event_wake_up_new_task+0xc1c>
     bc4:      	cmn	x21, #0x7
     bc8:      	b.eq	0xc34 <event_wake_up_new_task+0xc34>
     bcc:      	cmn	x21, #0x2
     bd0:      	b.ne	0xc24 <event_wake_up_new_task+0xc24>
     bd4:      	add	x8, x0, #0x5f0
     bd8:      	b	0xc38 <event_wake_up_new_task+0xc38>
     bdc:      	add	x8, x0, #0x610
     be0:      	b	0xc00 <event_wake_up_new_task+0xc00>
     be4:      	add	x8, x0, #0x618
     be8:      	b	0xc00 <event_wake_up_new_task+0xc00>
     bec:      	add	x8, x0, #0x5e8
     bf0:      	b	0xc00 <event_wake_up_new_task+0xc00>
     bf4:      	add	x8, x0, #0x608
     bf8:      	b	0xc00 <event_wake_up_new_task+0xc00>
     bfc:      	add	x8, x0, #0x5f8
     c00:      	ldaxr	x9, [x8]
     c04:      	add	x9, x9, #0x1
     c08:      	stlxr	w10, x9, [x8]
     c0c:      	cbnz	w10, 0xc00 <event_wake_up_new_task+0xc00>
     c10:      	b	0xc48 <event_wake_up_new_task+0xc48>
     c14:      	add	x8, x0, #0x610
     c18:      	b	0xc38 <event_wake_up_new_task+0xc38>
     c1c:      	add	x8, x0, #0x618
     c20:      	b	0xc38 <event_wake_up_new_task+0xc38>
     c24:      	add	x8, x0, #0x5e8
     c28:      	b	0xc38 <event_wake_up_new_task+0xc38>
     c2c:      	add	x8, x0, #0x608
     c30:      	b	0xc38 <event_wake_up_new_task+0xc38>
     c34:      	add	x8, x0, #0x5f8
     c38:      	ldaxr	x9, [x8]
     c3c:      	add	x9, x9, #0x1
     c40:      	stlxr	w10, x9, [x8]
     c44:      	cbnz	w10, 0xc38 <event_wake_up_new_task+0xc38>
     c48:      	ldr	x8, [x22, #0x20]
     c4c:      	cbnz	x8, 0xe28 <event_wake_up_new_task+0xe28>
     c50:      	str	wzr, [sp, #0x118]
     c54:      	mov	w8, #0x1                // =1
     c58:      	add	x9, sp, #0x118
     c5c:      	add	x1, sp, #0x118
     c60:      	mov	x0, x20
     c64:      	blr	x8
     c68:      	cbz	x0, 0xcf4 <event_wake_up_new_task+0xcf4>
     c6c:      	ldrb	w8, [x0, #0x28]
     c70:      	cbz	w8, 0xcf4 <event_wake_up_new_task+0xcf4>
     c74:      	adrp	x1, 0x0 <event_wake_up_new_task>
     c78:      	mov	w8, #-0x1               // =-1
     c7c:      	mov	w9, #0x38               // =56
     c80:      	ldr	x1, [x1]
     c84:      	mov	w10, #0x19              // =25
     c88:      	add	x11, sp, #0xa8
     c8c:      	add	x3, sp, #0xa8
     c90:      	mov	x0, x19
     c94:      	mov	w2, #-0x1               // =-1
     c98:      	mov	w4, #0x38               // =56
     c9c:      	blr	x10
     ca0:      	tbz	x0, #0x3f, 0xe28 <event_wake_up_new_task+0xe28>
     ca4:      	mov	x19, x0
     ca8:      	str	wzr, [sp, #0xe0]
     cac:      	adrp	x0, 0x0 <event_wake_up_new_task>
     cb0:      	mov	w8, #0x1                // =1
     cb4:      	ldr	x0, [x0]
     cb8:      	add	x9, sp, #0xe0
     cbc:      	add	x1, sp, #0xe0
     cc0:      	blr	x8
     cc4:      	cbz	x0, 0xe28 <event_wake_up_new_task+0xe28>
     cc8:      	mov	x8, x19
     ccc:      	cmn	x19, #0xc
     cd0:      	b.gt	0xd8c <event_wake_up_new_task+0xd8c>
     cd4:      	cmn	x8, #0x1c
     cd8:      	b.eq	0xdf4 <event_wake_up_new_task+0xdf4>
     cdc:      	cmn	x8, #0x16
     ce0:      	b.eq	0xe0c <event_wake_up_new_task+0xe0c>
     ce4:      	cmn	x8, #0x10
     ce8:      	b.ne	0xe04 <event_wake_up_new_task+0xe04>
     cec:      	add	x8, x0, #0x520
     cf0:      	b	0xe18 <event_wake_up_new_task+0xe18>
     cf4:      	adrp	x0, 0x0 <event_wake_up_new_task>
     cf8:      	mov	x3, xzr
     cfc:      	mov	w8, #0x38               // =56
     d00:      	ldr	x0, [x0]
     d04:      	mov	w9, #0x82               // =130
     d08:      	add	x10, sp, #0xa8
     d0c:      	add	x1, sp, #0xa8
     d10:      	mov	w2, #0x38               // =56
     d14:      	blr	x9
     d18:      	tbz	x0, #0x3f, 0xe28 <event_wake_up_new_task+0xe28>
     d1c:      	mov	x19, x0
     d20:      	str	wzr, [sp, #0xe0]
     d24:      	adrp	x0, 0x0 <event_wake_up_new_task>
     d28:      	mov	w8, #0x1                // =1
     d2c:      	ldr	x0, [x0]
     d30:      	add	x9, sp, #0xe0
     d34:      	add	x1, sp, #0xe0
     d38:      	blr	x8
     d3c:      	cbz	x0, 0xe28 <event_wake_up_new_task+0xe28>
     d40:      	mov	x8, x19
     d44:      	cmn	x19, #0xc
     d48:      	b.gt	0xd6c <event_wake_up_new_task+0xd6c>
     d4c:      	cmn	x8, #0x1c
     d50:      	b.eq	0xdac <event_wake_up_new_task+0xdac>
     d54:      	cmn	x8, #0x16
     d58:      	b.eq	0xdc4 <event_wake_up_new_task+0xdc4>
     d5c:      	cmn	x8, #0x10
     d60:      	b.ne	0xdbc <event_wake_up_new_task+0xdbc>
     d64:      	add	x8, x0, #0x520
     d68:      	b	0xde0 <event_wake_up_new_task+0xde0>
     d6c:      	cmn	x8, #0xb
     d70:      	b.eq	0xdb4 <event_wake_up_new_task+0xdb4>
     d74:      	cmn	x8, #0x7
     d78:      	b.eq	0xdcc <event_wake_up_new_task+0xdcc>
     d7c:      	cmn	x8, #0x2
     d80:      	b.ne	0xdbc <event_wake_up_new_task+0xdbc>
     d84:      	add	x8, x0, #0x510
     d88:      	b	0xde0 <event_wake_up_new_task+0xde0>
     d8c:      	cmn	x8, #0xb
     d90:      	b.eq	0xdfc <event_wake_up_new_task+0xdfc>
     d94:      	cmn	x8, #0x7
     d98:      	b.eq	0xe14 <event_wake_up_new_task+0xe14>
     d9c:      	cmn	x8, #0x2
     da0:      	b.ne	0xe04 <event_wake_up_new_task+0xe04>
     da4:      	add	x8, x0, #0x510
     da8:      	b	0xe18 <event_wake_up_new_task+0xe18>
     dac:      	add	x8, x0, #0x530
     db0:      	b	0xde0 <event_wake_up_new_task+0xde0>
     db4:      	add	x8, x0, #0x538
     db8:      	b	0xde0 <event_wake_up_new_task+0xde0>
     dbc:      	add	x8, x0, #0x508
     dc0:      	b	0xde0 <event_wake_up_new_task+0xde0>
     dc4:      	add	x8, x0, #0x528
     dc8:      	b	0xde0 <event_wake_up_new_task+0xde0>
     dcc:      	add	x8, x0, #0x518
     dd0:      	nop
     dd4:      	nop
     dd8:      	nop
     ddc:      	nop
     de0:      	ldaxr	x9, [x8]
     de4:      	add	x9, x9, #0x1
     de8:      	stlxr	w10, x9, [x8]
     dec:      	cbnz	w10, 0xde0 <event_wake_up_new_task+0xde0>
     df0:      	b	0xe28 <event_wake_up_new_task+0xe28>
     df4:      	add	x8, x0, #0x530
     df8:      	b	0xe18 <event_wake_up_new_task+0xe18>
     dfc:      	add	x8, x0, #0x538
     e00:      	b	0xe18 <event_wake_up_new_task+0xe18>
     e04:      	add	x8, x0, #0x508
     e08:      	b	0xe18 <event_wake_up_new_task+0xe18>
     e0c:      	add	x8, x0, #0x528
     e10:      	b	0xe18 <event_wake_up_new_task+0xe18>
     e14:      	add	x8, x0, #0x518
     e18:      	ldaxr	x9, [x8]
     e1c:      	add	x9, x9, #0x1
     e20:      	stlxr	w10, x9, [x8]
     e24:      	cbnz	w10, 0xe18 <event_wake_up_new_task+0xe18>
     e28:      	ldp	x20, x19, [sp, #0x160]
     e2c:      	mov	w0, wzr
     e30:      	ldr	x29, [sp, #0x120]
     e34:      	ldp	x22, x21, [sp, #0x150]
     e38:      	ldp	x24, x23, [sp, #0x140]
     e3c:      	ldp	x30, x25, [sp, #0x130]
     e40:      	add	sp, sp, #0x170
     e44:      	ret
