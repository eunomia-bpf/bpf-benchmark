
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_tracepoint_v61.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <extract_arg_depth>:
       0:      	cmp	w0, #0x9
       4:      	b.ls	0x10 <extract_arg_depth+0x10>
       8:      	mov	w0, #0x1                // =1
       c:      	ret
      10:      	str	x30, [sp, #-0x20]!
      14:      	stp	x20, x19, [sp, #0x10]
      18:      	ldr	x8, [x1]
      1c:      	add	x9, x8, w0, uxtw #3
      20:      	ldrh	w9, [x9, #0x6]
      24:      	cbz	w9, 0xb4 <extract_arg_depth+0xb4>
      28:      	mov	w9, w0
      2c:      	add	x10, x8, x9, lsl #3
      30:      	ldr	x8, [x1, #0x8]
      34:      	ldr	w11, [x10]
      38:      	ldrh	w10, [x10, #0x4]
      3c:      	ldr	x9, [x8]
      40:      	add	x9, x9, x11
      44:      	str	x9, [x8]
      48:      	cbz	w10, 0x78 <extract_arg_depth+0x78>
      4c:      	ldrb	w10, [x1, #0x10]
      50:      	mov	w19, w0
      54:      	cbz	w10, 0x88 <extract_arg_depth+0x88>
      58:      	mov	w10, #0x8               // =8
      5c:      	mov	w11, #0x94              // =148
      60:      	ldr	x0, [x1, #0x8]
      64:      	mov	x20, x1
      68:      	mov	w1, #0x8                // =8
      6c:      	ldr	x2, [x0]
      70:      	blr	x11
      74:      	tbnz	w0, #0x1f, 0xa8 <extract_arg_depth+0xa8>
      78:      	mov	w0, wzr
      7c:      	ldp	x20, x19, [sp, #0x10]
      80:      	ldr	x30, [sp], #0x20
      84:      	ret
      88:      	mov	w10, #0x8               // =8
      8c:      	mov	w11, #0x4               // =4
      90:      	ldr	x0, [x1, #0x8]
      94:      	mov	x20, x1
      98:      	mov	w1, #0x8                // =8
      9c:      	ldr	x2, [x0]
      a0:      	blr	x11
      a4:      	tbz	w0, #0x1f, 0x78 <extract_arg_depth+0x78>
      a8:      	ldr	x9, [x20, #0x18]
      ac:      	add	w8, w19, #0x1
      b0:      	str	w8, [x9]
      b4:      	mov	w0, #0x1                // =1
      b8:      	ldp	x20, x19, [sp, #0x10]
      bc:      	ldr	x30, [sp], #0x20
      c0:      	ret
      c4:      	nop
      c8:      	nop
      cc:      	nop

00000000000000d0 <filter_64ty>:
      d0:      	str	x30, [sp, #-0x10]!
      d4:      	mov	x8, x0
      d8:      	mov	x0, xzr
      dc:      	ldr	w9, [x8, #0x4]
      e0:      	cmp	w9, #0x20
      e4:      	b.hi	0x144 <filter_64ty+0x74>
      e8:      	mov	w10, #0x1               // =1
      ec:      	mov	w11, #0x101e            // =4126
      f0:      	lsl	x10, x10, x9
      f4:      	tst	x10, x11
      f8:      	b.eq	0x10c <filter_64ty+0x3c>
      fc:      	mov	x0, x8
     100:      	bl	0x2d0 <filter_64ty_selector_val>
     104:      	ldr	x30, [sp], #0x10
     108:      	ret
     10c:      	mov	w10, #0x1               // =1
     110:      	lsl	x10, x10, x9
     114:      	tst	x10, #0xc00
     118:      	b.ne	0x13c <filter_64ty+0x6c>
     11c:      	mov	w10, #0x1               // =1
     120:      	lsl	x9, x10, x9
     124:      	tst	x9, #0x180000000
     128:      	b.eq	0x144 <filter_64ty+0x74>
     12c:      	mov	x0, x8
     130:      	bl	0x6d0 <filter_64ty_range>
     134:      	ldr	x30, [sp], #0x10
     138:      	ret
     13c:      	mov	x0, x8
     140:      	bl	0x630 <filter_64ty_map>
     144:      	ldr	x30, [sp], #0x10
     148:      	ret
     14c:      	nop

0000000000000150 <filter_32ty>:
     150:      	str	x30, [sp, #-0x10]!
     154:      	mov	x8, x0
     158:      	mov	x0, xzr
     15c:      	ldr	w9, [x8, #0x4]
     160:      	cmp	w9, #0x20
     164:      	b.hi	0x1c4 <filter_32ty+0x74>
     168:      	mov	w10, #0x1               // =1
     16c:      	mov	w11, #0x101e            // =4126
     170:      	lsl	x10, x10, x9
     174:      	tst	x10, x11
     178:      	b.eq	0x18c <filter_32ty+0x3c>
     17c:      	mov	x0, x8
     180:      	bl	0x920 <filter_32ty_selector_val>
     184:      	ldr	x30, [sp], #0x10
     188:      	ret
     18c:      	mov	w10, #0x1               // =1
     190:      	lsl	x10, x10, x9
     194:      	tst	x10, #0xc00
     198:      	b.ne	0x1bc <filter_32ty+0x6c>
     19c:      	mov	w10, #0x1               // =1
     1a0:      	lsl	x9, x10, x9
     1a4:      	tst	x9, #0x180000000
     1a8:      	b.eq	0x1c4 <filter_32ty+0x74>
     1ac:      	mov	x0, x8
     1b0:      	bl	0xd40 <filter_32ty_range>
     1b4:      	ldr	x30, [sp], #0x10
     1b8:      	ret
     1bc:      	mov	x0, x8
     1c0:      	bl	0xc80 <filter_32ty_map>
     1c4:      	ldr	x30, [sp], #0x10
     1c8:      	ret
     1cc:      	nop

00000000000001d0 <filter_16ty>:
     1d0:      	str	x30, [sp, #-0x10]!
     1d4:      	mov	x8, x0
     1d8:      	mov	x0, xzr
     1dc:      	ldr	w9, [x8, #0x4]
     1e0:      	cmp	w9, #0x20
     1e4:      	b.hi	0x244 <filter_16ty+0x74>
     1e8:      	mov	w10, #0x1               // =1
     1ec:      	mov	w11, #0x101e            // =4126
     1f0:      	lsl	x10, x10, x9
     1f4:      	tst	x10, x11
     1f8:      	b.eq	0x20c <filter_16ty+0x3c>
     1fc:      	mov	x0, x8
     200:      	bl	0xf90 <filter_16ty_selector_val>
     204:      	ldr	x30, [sp], #0x10
     208:      	ret
     20c:      	mov	w10, #0x1               // =1
     210:      	lsl	x10, x10, x9
     214:      	tst	x10, #0xc00
     218:      	b.ne	0x23c <filter_16ty+0x6c>
     21c:      	mov	w10, #0x1               // =1
     220:      	lsl	x9, x10, x9
     224:      	tst	x9, #0x180000000
     228:      	b.eq	0x244 <filter_16ty+0x74>
     22c:      	mov	x0, x8
     230:      	bl	0x13b0 <filter_16ty_range>
     234:      	ldr	x30, [sp], #0x10
     238:      	ret
     23c:      	mov	x0, x8
     240:      	bl	0x12f0 <filter_16ty_map>
     244:      	ldr	x30, [sp], #0x10
     248:      	ret
     24c:      	nop

0000000000000250 <filter_8ty>:
     250:      	str	x30, [sp, #-0x10]!
     254:      	mov	x8, x0
     258:      	mov	x0, xzr
     25c:      	ldr	w9, [x8, #0x4]
     260:      	cmp	w9, #0x20
     264:      	b.hi	0x2c4 <filter_8ty+0x74>
     268:      	mov	w10, #0x1               // =1
     26c:      	mov	w11, #0x101e            // =4126
     270:      	lsl	x10, x10, x9
     274:      	tst	x10, x11
     278:      	b.eq	0x28c <filter_8ty+0x3c>
     27c:      	mov	x0, x8
     280:      	bl	0x1600 <filter_8ty_selector_val>
     284:      	ldr	x30, [sp], #0x10
     288:      	ret
     28c:      	mov	w10, #0x1               // =1
     290:      	lsl	x10, x10, x9
     294:      	tst	x10, #0xc00
     298:      	b.ne	0x2bc <filter_8ty+0x6c>
     29c:      	mov	w10, #0x1               // =1
     2a0:      	lsl	x9, x10, x9
     2a4:      	tst	x9, #0x180000000
     2a8:      	b.eq	0x2c4 <filter_8ty+0x74>
     2ac:      	mov	x0, x8
     2b0:      	bl	0x1a20 <filter_8ty_range>
     2b4:      	ldr	x30, [sp], #0x10
     2b8:      	ret
     2bc:      	mov	x0, x8
     2c0:      	bl	0x1960 <filter_8ty_map>
     2c4:      	ldr	x30, [sp], #0x10
     2c8:      	ret
     2cc:      	nop

00000000000002d0 <filter_64ty_selector_val>:
     2d0:      	ldr	w8, [x0, #0x4]
     2d4:      	cmp	w8, #0x25
     2d8:      	b.hi	0x34c <filter_64ty_selector_val+0x7c>
     2dc:      	mov	x10, #0x40              // =64
     2e0:      	mov	w9, #0x1                // =1
     2e4:      	movk	x10, #0xc00, lsl #16
     2e8:      	lsl	x9, x9, x8
     2ec:      	movk	x10, #0x20, lsl #32
     2f0:      	tst	x9, x10
     2f4:      	b.eq	0x300 <filter_64ty_selector_val+0x30>
     2f8:      	mov	w0, #0x1                // =1
     2fc:      	ret
     300:      	mov	w9, #0x1                // =1
     304:      	lsl	x9, x9, x8
     308:      	tst	x9, #0x18
     30c:      	b.eq	0x32c <filter_64ty_selector_val+0x5c>
     310:      	ldr	x9, [x1]
     314:      	ldr	x10, [x0, #0x10]
     318:      	cmp	x9, x10
     31c:      	b.ne	0x3cc <filter_64ty_selector_val+0xfc>
     320:      	cmp	w8, #0x3
     324:      	cset	w0, eq
     328:      	ret
     32c:      	cmp	x8, #0xc
     330:      	b.ne	0x34c <filter_64ty_selector_val+0x7c>
     334:      	ldr	x8, [x1]
     338:      	ldr	x9, [x0, #0x10]
     33c:      	tst	x8, x9
     340:      	b.eq	0x478 <filter_64ty_selector_val+0x1a8>
     344:      	mov	w0, #0x1                // =1
     348:      	ret
     34c:      	cmp	w8, #0x1
     350:      	b.eq	0x394 <filter_64ty_selector_val+0xc4>
     354:      	cmp	w8, #0x2
     358:      	b.ne	0x620 <filter_64ty_selector_val+0x350>
     35c:      	ldr	w8, [x0, #0xc]
     360:      	cmp	w8, #0xc
     364:      	b.hi	0x4b0 <filter_64ty_selector_val+0x1e0>
     368:      	mov	w9, #0x1                // =1
     36c:      	lsl	w8, w9, w8
     370:      	mov	w9, #0x1402             // =5122
     374:      	tst	w8, w9
     378:      	b.eq	0x4b0 <filter_64ty_selector_val+0x1e0>
     37c:      	ldr	x8, [x1]
     380:      	ldr	x9, [x0, #0x10]
     384:      	cmp	x8, x9
     388:      	b.ge	0x458 <filter_64ty_selector_val+0x188>
     38c:      	mov	w0, #0x1                // =1
     390:      	ret
     394:      	ldr	w8, [x0, #0xc]
     398:      	cmp	w8, #0xc
     39c:      	b.hi	0x498 <filter_64ty_selector_val+0x1c8>
     3a0:      	mov	w9, #0x1                // =1
     3a4:      	lsl	w8, w9, w8
     3a8:      	mov	w9, #0x1402             // =5122
     3ac:      	tst	w8, w9
     3b0:      	b.eq	0x498 <filter_64ty_selector_val+0x1c8>
     3b4:      	ldr	x8, [x1]
     3b8:      	ldr	x9, [x0, #0x10]
     3bc:      	cmp	x8, x9
     3c0:      	b.le	0x438 <filter_64ty_selector_val+0x168>
     3c4:      	mov	w0, #0x1                // =1
     3c8:      	ret
     3cc:      	ldr	w10, [x0, #0x8]
     3d0:      	cmp	w10, #0x11
     3d4:      	b.lo	0x40c <filter_64ty_selector_val+0x13c>
     3d8:      	ldr	x11, [x0, #0x18]
     3dc:      	cmp	x9, x11
     3e0:      	b.eq	0x320 <filter_64ty_selector_val+0x50>
     3e4:      	cmp	w10, #0x19
     3e8:      	b.lo	0x40c <filter_64ty_selector_val+0x13c>
     3ec:      	ldr	x11, [x0, #0x20]
     3f0:      	cmp	x9, x11
     3f4:      	b.eq	0x320 <filter_64ty_selector_val+0x50>
     3f8:      	cmp	w10, #0x21
     3fc:      	b.lo	0x40c <filter_64ty_selector_val+0x13c>
     400:      	ldr	x10, [x0, #0x28]
     404:      	cmp	x9, x10
     408:      	b.eq	0x320 <filter_64ty_selector_val+0x50>
     40c:      	cmp	w8, #0x25
     410:      	b.hi	0x620 <filter_64ty_selector_val+0x350>
     414:      	mov	w9, #0x1                // =1
     418:      	lsl	x8, x9, x8
     41c:      	mov	x9, #0x50               // =80
     420:      	movk	x9, #0xc00, lsl #16
     424:      	movk	x9, #0x20, lsl #32
     428:      	tst	x8, x9
     42c:      	b.eq	0x620 <filter_64ty_selector_val+0x350>
     430:      	mov	w0, #0x1                // =1
     434:      	ret
     438:      	ldr	w9, [x0, #0x8]
     43c:      	cmp	w9, #0x11
     440:      	b.lo	0x620 <filter_64ty_selector_val+0x350>
     444:      	ldr	x10, [x0, #0x18]
     448:      	cmp	x8, x10
     44c:      	b.le	0x508 <filter_64ty_selector_val+0x238>
     450:      	mov	w0, #0x1                // =1
     454:      	ret
     458:      	ldr	w9, [x0, #0x8]
     45c:      	cmp	w9, #0x11
     460:      	b.lo	0x620 <filter_64ty_selector_val+0x350>
     464:      	ldr	x10, [x0, #0x18]
     468:      	cmp	x8, x10
     46c:      	b.ge	0x524 <filter_64ty_selector_val+0x254>
     470:      	mov	w0, #0x1                // =1
     474:      	ret
     478:      	ldr	w9, [x0, #0x8]
     47c:      	cmp	w9, #0x11
     480:      	b.lo	0x620 <filter_64ty_selector_val+0x350>
     484:      	ldr	x10, [x0, #0x18]
     488:      	tst	x8, x10
     48c:      	b.eq	0x540 <filter_64ty_selector_val+0x270>
     490:      	mov	w0, #0x1                // =1
     494:      	ret
     498:      	ldr	x8, [x1]
     49c:      	ldr	x9, [x0, #0x10]
     4a0:      	cmp	x8, x9
     4a4:      	b.ls	0x4c8 <filter_64ty_selector_val+0x1f8>
     4a8:      	mov	w0, #0x1                // =1
     4ac:      	ret
     4b0:      	ldr	x8, [x1]
     4b4:      	ldr	x9, [x0, #0x10]
     4b8:      	cmp	x8, x9
     4bc:      	b.hs	0x4e8 <filter_64ty_selector_val+0x218>
     4c0:      	mov	w0, #0x1                // =1
     4c4:      	ret
     4c8:      	ldr	w9, [x0, #0x8]
     4cc:      	cmp	w9, #0x11
     4d0:      	b.lo	0x620 <filter_64ty_selector_val+0x350>
     4d4:      	ldr	x10, [x0, #0x18]
     4d8:      	cmp	x8, x10
     4dc:      	b.ls	0x55c <filter_64ty_selector_val+0x28c>
     4e0:      	mov	w0, #0x1                // =1
     4e4:      	ret
     4e8:      	ldr	w9, [x0, #0x8]
     4ec:      	cmp	w9, #0x11
     4f0:      	b.lo	0x620 <filter_64ty_selector_val+0x350>
     4f4:      	ldr	x10, [x0, #0x18]
     4f8:      	cmp	x8, x10
     4fc:      	b.hs	0x578 <filter_64ty_selector_val+0x2a8>
     500:      	mov	w0, #0x1                // =1
     504:      	ret
     508:      	cmp	w9, #0x19
     50c:      	b.lo	0x620 <filter_64ty_selector_val+0x350>
     510:      	ldr	x10, [x0, #0x20]
     514:      	cmp	x8, x10
     518:      	b.le	0x594 <filter_64ty_selector_val+0x2c4>
     51c:      	mov	w0, #0x1                // =1
     520:      	ret
     524:      	cmp	w9, #0x19
     528:      	b.lo	0x620 <filter_64ty_selector_val+0x350>
     52c:      	ldr	x10, [x0, #0x20]
     530:      	cmp	x8, x10
     534:      	b.ge	0x5b0 <filter_64ty_selector_val+0x2e0>
     538:      	mov	w0, #0x1                // =1
     53c:      	ret
     540:      	cmp	w9, #0x19
     544:      	b.lo	0x620 <filter_64ty_selector_val+0x350>
     548:      	ldr	x10, [x0, #0x20]
     54c:      	tst	x8, x10
     550:      	b.eq	0x5cc <filter_64ty_selector_val+0x2fc>
     554:      	mov	w0, #0x1                // =1
     558:      	ret
     55c:      	cmp	w9, #0x19
     560:      	b.lo	0x620 <filter_64ty_selector_val+0x350>
     564:      	ldr	x10, [x0, #0x20]
     568:      	cmp	x8, x10
     56c:      	b.ls	0x5e8 <filter_64ty_selector_val+0x318>
     570:      	mov	w0, #0x1                // =1
     574:      	ret
     578:      	cmp	w9, #0x19
     57c:      	b.lo	0x620 <filter_64ty_selector_val+0x350>
     580:      	ldr	x10, [x0, #0x20]
     584:      	cmp	x8, x10
     588:      	b.hs	0x604 <filter_64ty_selector_val+0x334>
     58c:      	mov	w0, #0x1                // =1
     590:      	ret
     594:      	cmp	w9, #0x21
     598:      	b.lo	0x620 <filter_64ty_selector_val+0x350>
     59c:      	ldr	x9, [x0, #0x28]
     5a0:      	cmp	x8, x9
     5a4:      	b.le	0x620 <filter_64ty_selector_val+0x350>
     5a8:      	mov	w0, #0x1                // =1
     5ac:      	ret
     5b0:      	cmp	w9, #0x21
     5b4:      	b.lo	0x620 <filter_64ty_selector_val+0x350>
     5b8:      	ldr	x9, [x0, #0x28]
     5bc:      	cmp	x8, x9
     5c0:      	b.ge	0x620 <filter_64ty_selector_val+0x350>
     5c4:      	mov	w0, #0x1                // =1
     5c8:      	ret
     5cc:      	cmp	w9, #0x21
     5d0:      	b.lo	0x620 <filter_64ty_selector_val+0x350>
     5d4:      	ldr	x9, [x0, #0x28]
     5d8:      	tst	x8, x9
     5dc:      	b.eq	0x620 <filter_64ty_selector_val+0x350>
     5e0:      	mov	w0, #0x1                // =1
     5e4:      	ret
     5e8:      	cmp	w9, #0x21
     5ec:      	b.lo	0x620 <filter_64ty_selector_val+0x350>
     5f0:      	ldr	x9, [x0, #0x28]
     5f4:      	cmp	x8, x9
     5f8:      	b.ls	0x620 <filter_64ty_selector_val+0x350>
     5fc:      	mov	w0, #0x1                // =1
     600:      	ret
     604:      	cmp	w9, #0x21
     608:      	b.lo	0x620 <filter_64ty_selector_val+0x350>
     60c:      	ldr	x9, [x0, #0x28]
     610:      	cmp	x8, x9
     614:      	b.hs	0x620 <filter_64ty_selector_val+0x350>
     618:      	mov	w0, #0x1                // =1
     61c:      	ret
     620:      	mov	x0, xzr
     624:      	ret
     628:      	nop
     62c:      	nop

0000000000000630 <filter_64ty_map>:
     630:      	sub	sp, sp, #0x30
     634:      	str	x30, [sp, #0x10]
     638:      	stp	x20, x19, [sp, #0x20]
     63c:      	ldrb	w8, [x0, #0x10]
     640:      	mov	x19, x0
     644:      	adrp	x0, 0x0 <extract_arg_depth>
     648:      	add	x9, sp, #0x1c
     64c:      	str	w8, [sp, #0x1c]
     650:      	mov	w8, #0x1                // =1
     654:      	mov	x20, x1
     658:      	add	x1, sp, #0x1c
     65c:      	ldr	x0, [x0]
     660:      	blr	x8
     664:      	cbz	x0, 0x6b4 <filter_64ty_map+0x84>
     668:      	ldr	x8, [x20]
     66c:      	add	x9, sp, #0x8
     670:      	add	x1, sp, #0x8
     674:      	str	x8, [sp, #0x8]
     678:      	mov	w8, #0x1                // =1
     67c:      	blr	x8
     680:      	ldr	w8, [x19, #0x4]
     684:      	cmp	w8, #0xb
     688:      	b.eq	0x6a0 <filter_64ty_map+0x70>
     68c:      	cmp	w8, #0xa
     690:      	b.ne	0x6ac <filter_64ty_map+0x7c>
     694:      	cmp	x0, #0x0
     698:      	cset	w8, ne
     69c:      	b	0x6b0 <filter_64ty_map+0x80>
     6a0:      	cmp	x0, #0x0
     6a4:      	cset	w8, eq
     6a8:      	b	0x6b0 <filter_64ty_map+0x80>
     6ac:      	mov	w8, wzr
     6b0:      	mov	w0, w8
     6b4:      	ldp	x20, x19, [sp, #0x20]
     6b8:      	ldr	x30, [sp, #0x10]
     6bc:      	add	sp, sp, #0x30
     6c0:      	ret
     6c4:      	nop
     6c8:      	nop
     6cc:      	nop

00000000000006d0 <filter_64ty_range>:
     6d0:      	ldr	w9, [x0, #0xc]
     6d4:      	ldr	w8, [x0, #0x4]
     6d8:      	mov	w10, #0x1               // =1
     6dc:      	cmp	w9, #0xc
     6e0:      	lsl	w9, w10, w9
     6e4:      	mov	w10, #0x1402            // =5122
     6e8:      	and	w9, w9, w10
     6ec:      	ccmp	w9, #0x0, #0x4, ls
     6f0:      	b.eq	0x7f0 <filter_64ty_range+0x120>
     6f4:      	ldr	x10, [x1]
     6f8:      	cmp	w8, #0x1f
     6fc:      	b.ne	0x784 <filter_64ty_range+0xb4>
     700:      	ldr	x9, [x0, #0x10]
     704:      	cmp	x9, x10
     708:      	b.gt	0x718 <filter_64ty_range+0x48>
     70c:      	ldr	x9, [x0, #0x18]
     710:      	cmp	x10, x9
     714:      	b.le	0x814 <filter_64ty_range+0x144>
     718:      	ldr	w9, [x0, #0x8]
     71c:      	cmp	w9, #0x19
     720:      	b.lo	0x900 <filter_64ty_range+0x230>
     724:      	ldr	x11, [x0, #0x20]
     728:      	cmp	x11, x10
     72c:      	b.gt	0x73c <filter_64ty_range+0x6c>
     730:      	ldr	x11, [x0, #0x28]
     734:      	cmp	x10, x11
     738:      	b.le	0x814 <filter_64ty_range+0x144>
     73c:      	cmp	w9, #0x29
     740:      	b.lo	0x900 <filter_64ty_range+0x230>
     744:      	ldr	x11, [x0, #0x30]
     748:      	cmp	x11, x10
     74c:      	b.gt	0x75c <filter_64ty_range+0x8c>
     750:      	ldr	x11, [x0, #0x38]
     754:      	cmp	x10, x11
     758:      	b.le	0x814 <filter_64ty_range+0x144>
     75c:      	cmp	w9, #0x39
     760:      	b.lo	0x900 <filter_64ty_range+0x230>
     764:      	ldr	x11, [x0, #0x40]
     768:      	mov	w9, wzr
     76c:      	cmp	x11, x10
     770:      	b.gt	0x8f0 <filter_64ty_range+0x220>
     774:      	ldr	x11, [x0, #0x48]
     778:      	cmp	x10, x11
     77c:      	b.le	0x814 <filter_64ty_range+0x144>
     780:      	b	0x8f0 <filter_64ty_range+0x220>
     784:      	ldp	x9, x12, [x0, #0x10]
     788:      	cmp	x9, x10
     78c:      	ldr	w11, [x0, #0x8]
     790:      	ccmp	x10, x12, #0x0, le
     794:      	cset	w9, le
     798:      	cmp	w11, #0x19
     79c:      	b.lo	0x8f0 <filter_64ty_range+0x220>
     7a0:      	ldp	x12, x13, [x0, #0x20]
     7a4:      	cmp	x12, x10
     7a8:      	ccmp	x10, x13, #0x0, le
     7ac:      	csinc	w9, w9, wzr, gt
     7b0:      	cmp	w11, #0x29
     7b4:      	b.lo	0x8f0 <filter_64ty_range+0x220>
     7b8:      	ldp	x12, x13, [x0, #0x30]
     7bc:      	cmp	x12, x10
     7c0:      	ccmp	x10, x13, #0x0, le
     7c4:      	csinc	w9, w9, wzr, gt
     7c8:      	cmp	w11, #0x39
     7cc:      	b.lo	0x8f0 <filter_64ty_range+0x220>
     7d0:      	ldp	x11, x12, [x0, #0x40]
     7d4:      	cmp	x11, x10
     7d8:      	ccmp	x10, x12, #0x0, le
     7dc:      	csinc	w9, w9, wzr, gt
     7e0:      	cmp	w8, #0x20
     7e4:      	eor	w8, w9, #0x1
     7e8:      	csel	w0, wzr, w8, ne
     7ec:      	ret
     7f0:      	ldr	x10, [x1]
     7f4:      	cmp	w8, #0x1f
     7f8:      	b.ne	0x81c <filter_64ty_range+0x14c>
     7fc:      	ldr	x9, [x0, #0x10]
     800:      	cmp	x9, x10
     804:      	b.hi	0x888 <filter_64ty_range+0x1b8>
     808:      	ldr	x9, [x0, #0x18]
     80c:      	cmp	x10, x9
     810:      	b.hi	0x888 <filter_64ty_range+0x1b8>
     814:      	mov	w0, #0x1                // =1
     818:      	ret
     81c:      	ldp	x9, x12, [x0, #0x10]
     820:      	cmp	x9, x10
     824:      	ldr	w11, [x0, #0x8]
     828:      	ccmp	x10, x12, #0x2, ls
     82c:      	cset	w9, ls
     830:      	cmp	w11, #0x19
     834:      	b.lo	0x8f0 <filter_64ty_range+0x220>
     838:      	ldp	x12, x13, [x0, #0x20]
     83c:      	cmp	x12, x10
     840:      	ccmp	x10, x13, #0x2, ls
     844:      	csinc	w9, w9, wzr, hi
     848:      	cmp	w11, #0x29
     84c:      	b.lo	0x8f0 <filter_64ty_range+0x220>
     850:      	ldp	x12, x13, [x0, #0x30]
     854:      	cmp	x12, x10
     858:      	ccmp	x10, x13, #0x2, ls
     85c:      	csinc	w9, w9, wzr, hi
     860:      	cmp	w11, #0x39
     864:      	b.lo	0x8f0 <filter_64ty_range+0x220>
     868:      	ldp	x11, x12, [x0, #0x40]
     86c:      	cmp	x11, x10
     870:      	ccmp	x10, x12, #0x2, ls
     874:      	csinc	w9, w9, wzr, hi
     878:      	cmp	w8, #0x20
     87c:      	eor	w8, w9, #0x1
     880:      	csel	w0, wzr, w8, ne
     884:      	ret
     888:      	ldr	w9, [x0, #0x8]
     88c:      	cmp	w9, #0x19
     890:      	b.lo	0x900 <filter_64ty_range+0x230>
     894:      	ldr	x11, [x0, #0x20]
     898:      	cmp	x11, x10
     89c:      	b.hi	0x8ac <filter_64ty_range+0x1dc>
     8a0:      	ldr	x11, [x0, #0x28]
     8a4:      	cmp	x10, x11
     8a8:      	b.ls	0x814 <filter_64ty_range+0x144>
     8ac:      	cmp	w9, #0x29
     8b0:      	b.lo	0x900 <filter_64ty_range+0x230>
     8b4:      	ldr	x11, [x0, #0x30]
     8b8:      	cmp	x11, x10
     8bc:      	b.hi	0x8cc <filter_64ty_range+0x1fc>
     8c0:      	ldr	x11, [x0, #0x38]
     8c4:      	cmp	x10, x11
     8c8:      	b.ls	0x814 <filter_64ty_range+0x144>
     8cc:      	cmp	w9, #0x39
     8d0:      	b.lo	0x900 <filter_64ty_range+0x230>
     8d4:      	ldr	x11, [x0, #0x40]
     8d8:      	mov	w9, wzr
     8dc:      	cmp	x11, x10
     8e0:      	b.hi	0x8f0 <filter_64ty_range+0x220>
     8e4:      	ldr	x11, [x0, #0x48]
     8e8:      	cmp	x10, x11
     8ec:      	b.ls	0x814 <filter_64ty_range+0x144>
     8f0:      	cmp	w8, #0x20
     8f4:      	eor	w8, w9, #0x1
     8f8:      	csel	w0, wzr, w8, ne
     8fc:      	ret
     900:      	mov	w9, wzr
     904:      	cmp	w8, #0x20
     908:      	eor	w8, w9, #0x1
     90c:      	csel	w0, wzr, w8, ne
     910:      	ret
     914:      	nop
     918:      	nop
     91c:      	nop

0000000000000920 <filter_32ty_selector_val>:
     920:      	ldr	w8, [x0, #0x4]
     924:      	cmp	w8, #0x25
     928:      	b.hi	0x99c <filter_32ty_selector_val+0x7c>
     92c:      	mov	x10, #0x40              // =64
     930:      	mov	w9, #0x1                // =1
     934:      	movk	x10, #0xc00, lsl #16
     938:      	lsl	x9, x9, x8
     93c:      	movk	x10, #0x20, lsl #32
     940:      	tst	x9, x10
     944:      	b.eq	0x950 <filter_32ty_selector_val+0x30>
     948:      	mov	w0, #0x1                // =1
     94c:      	ret
     950:      	mov	w9, #0x1                // =1
     954:      	lsl	x9, x9, x8
     958:      	tst	x9, #0x18
     95c:      	b.eq	0x97c <filter_32ty_selector_val+0x5c>
     960:      	ldr	w9, [x1]
     964:      	ldr	w10, [x0, #0x10]
     968:      	cmp	w9, w10
     96c:      	b.ne	0xa1c <filter_32ty_selector_val+0xfc>
     970:      	cmp	w8, #0x3
     974:      	cset	w0, eq
     978:      	ret
     97c:      	cmp	x8, #0xc
     980:      	b.ne	0x99c <filter_32ty_selector_val+0x7c>
     984:      	ldr	w8, [x1]
     988:      	ldr	w9, [x0, #0x10]
     98c:      	tst	w8, w9
     990:      	b.eq	0xac8 <filter_32ty_selector_val+0x1a8>
     994:      	mov	w0, #0x1                // =1
     998:      	ret
     99c:      	cmp	w8, #0x1
     9a0:      	b.eq	0x9e4 <filter_32ty_selector_val+0xc4>
     9a4:      	cmp	w8, #0x2
     9a8:      	b.ne	0xc70 <filter_32ty_selector_val+0x350>
     9ac:      	ldr	w8, [x0, #0xc]
     9b0:      	cmp	w8, #0xc
     9b4:      	b.hi	0xb00 <filter_32ty_selector_val+0x1e0>
     9b8:      	mov	w9, #0x1                // =1
     9bc:      	lsl	w8, w9, w8
     9c0:      	mov	w9, #0x1402             // =5122
     9c4:      	tst	w8, w9
     9c8:      	b.eq	0xb00 <filter_32ty_selector_val+0x1e0>
     9cc:      	ldr	w8, [x1]
     9d0:      	ldr	w9, [x0, #0x10]
     9d4:      	cmp	w8, w9
     9d8:      	b.ge	0xaa8 <filter_32ty_selector_val+0x188>
     9dc:      	mov	w0, #0x1                // =1
     9e0:      	ret
     9e4:      	ldr	w8, [x0, #0xc]
     9e8:      	cmp	w8, #0xc
     9ec:      	b.hi	0xae8 <filter_32ty_selector_val+0x1c8>
     9f0:      	mov	w9, #0x1                // =1
     9f4:      	lsl	w8, w9, w8
     9f8:      	mov	w9, #0x1402             // =5122
     9fc:      	tst	w8, w9
     a00:      	b.eq	0xae8 <filter_32ty_selector_val+0x1c8>
     a04:      	ldr	w8, [x1]
     a08:      	ldr	w9, [x0, #0x10]
     a0c:      	cmp	w8, w9
     a10:      	b.le	0xa88 <filter_32ty_selector_val+0x168>
     a14:      	mov	w0, #0x1                // =1
     a18:      	ret
     a1c:      	ldr	w10, [x0, #0x8]
     a20:      	cmp	w10, #0xd
     a24:      	b.lo	0xa5c <filter_32ty_selector_val+0x13c>
     a28:      	ldr	w11, [x0, #0x14]
     a2c:      	cmp	w9, w11
     a30:      	b.eq	0x970 <filter_32ty_selector_val+0x50>
     a34:      	cmp	w10, #0x11
     a38:      	b.lo	0xa5c <filter_32ty_selector_val+0x13c>
     a3c:      	ldr	w11, [x0, #0x18]
     a40:      	cmp	w9, w11
     a44:      	b.eq	0x970 <filter_32ty_selector_val+0x50>
     a48:      	cmp	w10, #0x15
     a4c:      	b.lo	0xa5c <filter_32ty_selector_val+0x13c>
     a50:      	ldr	w10, [x0, #0x1c]
     a54:      	cmp	w9, w10
     a58:      	b.eq	0x970 <filter_32ty_selector_val+0x50>
     a5c:      	cmp	w8, #0x25
     a60:      	b.hi	0xc70 <filter_32ty_selector_val+0x350>
     a64:      	mov	w9, #0x1                // =1
     a68:      	lsl	x8, x9, x8
     a6c:      	mov	x9, #0x50               // =80
     a70:      	movk	x9, #0xc00, lsl #16
     a74:      	movk	x9, #0x20, lsl #32
     a78:      	tst	x8, x9
     a7c:      	b.eq	0xc70 <filter_32ty_selector_val+0x350>
     a80:      	mov	w0, #0x1                // =1
     a84:      	ret
     a88:      	ldr	w9, [x0, #0x8]
     a8c:      	cmp	w9, #0xd
     a90:      	b.lo	0xc70 <filter_32ty_selector_val+0x350>
     a94:      	ldr	w10, [x0, #0x14]
     a98:      	cmp	w8, w10
     a9c:      	b.le	0xb58 <filter_32ty_selector_val+0x238>
     aa0:      	mov	w0, #0x1                // =1
     aa4:      	ret
     aa8:      	ldr	w9, [x0, #0x8]
     aac:      	cmp	w9, #0xd
     ab0:      	b.lo	0xc70 <filter_32ty_selector_val+0x350>
     ab4:      	ldr	w10, [x0, #0x14]
     ab8:      	cmp	w8, w10
     abc:      	b.ge	0xb74 <filter_32ty_selector_val+0x254>
     ac0:      	mov	w0, #0x1                // =1
     ac4:      	ret
     ac8:      	ldr	w9, [x0, #0x8]
     acc:      	cmp	w9, #0xd
     ad0:      	b.lo	0xc70 <filter_32ty_selector_val+0x350>
     ad4:      	ldr	w10, [x0, #0x14]
     ad8:      	tst	w8, w10
     adc:      	b.eq	0xb90 <filter_32ty_selector_val+0x270>
     ae0:      	mov	w0, #0x1                // =1
     ae4:      	ret
     ae8:      	ldr	w8, [x1]
     aec:      	ldr	w9, [x0, #0x10]
     af0:      	cmp	w8, w9
     af4:      	b.ls	0xb18 <filter_32ty_selector_val+0x1f8>
     af8:      	mov	w0, #0x1                // =1
     afc:      	ret
     b00:      	ldr	w8, [x1]
     b04:      	ldr	w9, [x0, #0x10]
     b08:      	cmp	w8, w9
     b0c:      	b.hs	0xb38 <filter_32ty_selector_val+0x218>
     b10:      	mov	w0, #0x1                // =1
     b14:      	ret
     b18:      	ldr	w9, [x0, #0x8]
     b1c:      	cmp	w9, #0xd
     b20:      	b.lo	0xc70 <filter_32ty_selector_val+0x350>
     b24:      	ldr	w10, [x0, #0x14]
     b28:      	cmp	w8, w10
     b2c:      	b.ls	0xbac <filter_32ty_selector_val+0x28c>
     b30:      	mov	w0, #0x1                // =1
     b34:      	ret
     b38:      	ldr	w9, [x0, #0x8]
     b3c:      	cmp	w9, #0xd
     b40:      	b.lo	0xc70 <filter_32ty_selector_val+0x350>
     b44:      	ldr	w10, [x0, #0x14]
     b48:      	cmp	w8, w10
     b4c:      	b.hs	0xbc8 <filter_32ty_selector_val+0x2a8>
     b50:      	mov	w0, #0x1                // =1
     b54:      	ret
     b58:      	cmp	w9, #0x11
     b5c:      	b.lo	0xc70 <filter_32ty_selector_val+0x350>
     b60:      	ldr	w10, [x0, #0x18]
     b64:      	cmp	w8, w10
     b68:      	b.le	0xbe4 <filter_32ty_selector_val+0x2c4>
     b6c:      	mov	w0, #0x1                // =1
     b70:      	ret
     b74:      	cmp	w9, #0x11
     b78:      	b.lo	0xc70 <filter_32ty_selector_val+0x350>
     b7c:      	ldr	w10, [x0, #0x18]
     b80:      	cmp	w8, w10
     b84:      	b.ge	0xc00 <filter_32ty_selector_val+0x2e0>
     b88:      	mov	w0, #0x1                // =1
     b8c:      	ret
     b90:      	cmp	w9, #0x11
     b94:      	b.lo	0xc70 <filter_32ty_selector_val+0x350>
     b98:      	ldr	w10, [x0, #0x18]
     b9c:      	tst	w8, w10
     ba0:      	b.eq	0xc1c <filter_32ty_selector_val+0x2fc>
     ba4:      	mov	w0, #0x1                // =1
     ba8:      	ret
     bac:      	cmp	w9, #0x11
     bb0:      	b.lo	0xc70 <filter_32ty_selector_val+0x350>
     bb4:      	ldr	w10, [x0, #0x18]
     bb8:      	cmp	w8, w10
     bbc:      	b.ls	0xc38 <filter_32ty_selector_val+0x318>
     bc0:      	mov	w0, #0x1                // =1
     bc4:      	ret
     bc8:      	cmp	w9, #0x11
     bcc:      	b.lo	0xc70 <filter_32ty_selector_val+0x350>
     bd0:      	ldr	w10, [x0, #0x18]
     bd4:      	cmp	w8, w10
     bd8:      	b.hs	0xc54 <filter_32ty_selector_val+0x334>
     bdc:      	mov	w0, #0x1                // =1
     be0:      	ret
     be4:      	cmp	w9, #0x15
     be8:      	b.lo	0xc70 <filter_32ty_selector_val+0x350>
     bec:      	ldr	w9, [x0, #0x1c]
     bf0:      	cmp	w8, w9
     bf4:      	b.le	0xc70 <filter_32ty_selector_val+0x350>
     bf8:      	mov	w0, #0x1                // =1
     bfc:      	ret
     c00:      	cmp	w9, #0x15
     c04:      	b.lo	0xc70 <filter_32ty_selector_val+0x350>
     c08:      	ldr	w9, [x0, #0x1c]
     c0c:      	cmp	w8, w9
     c10:      	b.ge	0xc70 <filter_32ty_selector_val+0x350>
     c14:      	mov	w0, #0x1                // =1
     c18:      	ret
     c1c:      	cmp	w9, #0x15
     c20:      	b.lo	0xc70 <filter_32ty_selector_val+0x350>
     c24:      	ldr	w9, [x0, #0x1c]
     c28:      	tst	w8, w9
     c2c:      	b.eq	0xc70 <filter_32ty_selector_val+0x350>
     c30:      	mov	w0, #0x1                // =1
     c34:      	ret
     c38:      	cmp	w9, #0x15
     c3c:      	b.lo	0xc70 <filter_32ty_selector_val+0x350>
     c40:      	ldr	w9, [x0, #0x1c]
     c44:      	cmp	w8, w9
     c48:      	b.ls	0xc70 <filter_32ty_selector_val+0x350>
     c4c:      	mov	w0, #0x1                // =1
     c50:      	ret
     c54:      	cmp	w9, #0x15
     c58:      	b.lo	0xc70 <filter_32ty_selector_val+0x350>
     c5c:      	ldr	w9, [x0, #0x1c]
     c60:      	cmp	w8, w9
     c64:      	b.hs	0xc70 <filter_32ty_selector_val+0x350>
     c68:      	mov	w0, #0x1                // =1
     c6c:      	ret
     c70:      	mov	x0, xzr
     c74:      	ret
     c78:      	nop
     c7c:      	nop

0000000000000c80 <filter_32ty_map>:
     c80:      	sub	sp, sp, #0x30
     c84:      	str	x30, [sp, #0x10]
     c88:      	stp	x20, x19, [sp, #0x20]
     c8c:      	ldrb	w8, [x0, #0x10]
     c90:      	mov	x19, x0
     c94:      	adrp	x0, 0x0 <extract_arg_depth>
     c98:      	add	x9, sp, #0x1c
     c9c:      	str	w8, [sp, #0x1c]
     ca0:      	mov	w8, #0x1                // =1
     ca4:      	mov	x20, x1
     ca8:      	add	x1, sp, #0x1c
     cac:      	ldr	x0, [x0]
     cb0:      	blr	x8
     cb4:      	cbz	x0, 0xd28 <filter_32ty_map+0xa8>
     cb8:      	ldr	w8, [x20]
     cbc:      	mov	w9, #0x1                // =1
     cc0:      	add	x1, sp, #0x8
     cc4:      	mov	w20, #0x1               // =1
     cc8:      	str	x8, [sp, #0x8]
     ccc:      	add	x8, sp, #0x8
     cd0:      	blr	x9
     cd4:      	ldr	w9, [x19, #0x4]
     cd8:      	mov	w8, wzr
     cdc:      	cmp	w9, #0x1d
     ce0:      	b.hi	0xd24 <filter_32ty_map+0xa4>
     ce4:      	mov	w11, #0x8400            // =33792
     ce8:      	lsl	w10, w20, w9
     cec:      	movk	w11, #0x3003, lsl #16
     cf0:      	tst	w10, w11
     cf4:      	b.eq	0xd04 <filter_32ty_map+0x84>
     cf8:      	cmp	x0, #0x0
     cfc:      	cset	w8, ne
     d00:      	b	0xd24 <filter_32ty_map+0xa4>
     d04:      	mov	w10, #0x1               // =1
     d08:      	lsl	w9, w10, w9
     d0c:      	mov	w10, #0x800             // =2048
     d10:      	movk	w10, #0xc, lsl #16
     d14:      	tst	w9, w10
     d18:      	b.eq	0xd24 <filter_32ty_map+0xa4>
     d1c:      	cmp	x0, #0x0
     d20:      	cset	w8, eq
     d24:      	mov	w0, w8
     d28:      	ldp	x20, x19, [sp, #0x20]
     d2c:      	ldr	x30, [sp, #0x10]
     d30:      	add	sp, sp, #0x30
     d34:      	ret
     d38:      	nop
     d3c:      	nop

0000000000000d40 <filter_32ty_range>:
     d40:      	ldr	w9, [x0, #0xc]
     d44:      	ldr	w8, [x0, #0x4]
     d48:      	mov	w10, #0x1               // =1
     d4c:      	cmp	w9, #0xc
     d50:      	lsl	w9, w10, w9
     d54:      	mov	w10, #0x1402            // =5122
     d58:      	and	w9, w9, w10
     d5c:      	ccmp	w9, #0x0, #0x4, ls
     d60:      	b.eq	0xe60 <filter_32ty_range+0x120>
     d64:      	ldr	w10, [x1]
     d68:      	cmp	w8, #0x1f
     d6c:      	b.ne	0xdf4 <filter_32ty_range+0xb4>
     d70:      	ldr	w9, [x0, #0x10]
     d74:      	cmp	w9, w10
     d78:      	b.gt	0xd88 <filter_32ty_range+0x48>
     d7c:      	ldr	w9, [x0, #0x14]
     d80:      	cmp	w10, w9
     d84:      	b.le	0xe84 <filter_32ty_range+0x144>
     d88:      	ldr	w9, [x0, #0x8]
     d8c:      	cmp	w9, #0x11
     d90:      	b.lo	0xf70 <filter_32ty_range+0x230>
     d94:      	ldr	w11, [x0, #0x18]
     d98:      	cmp	w11, w10
     d9c:      	b.gt	0xdac <filter_32ty_range+0x6c>
     da0:      	ldr	w11, [x0, #0x1c]
     da4:      	cmp	w10, w11
     da8:      	b.le	0xe84 <filter_32ty_range+0x144>
     dac:      	cmp	w9, #0x19
     db0:      	b.lo	0xf70 <filter_32ty_range+0x230>
     db4:      	ldr	w11, [x0, #0x20]
     db8:      	cmp	w11, w10
     dbc:      	b.gt	0xdcc <filter_32ty_range+0x8c>
     dc0:      	ldr	w11, [x0, #0x24]
     dc4:      	cmp	w10, w11
     dc8:      	b.le	0xe84 <filter_32ty_range+0x144>
     dcc:      	cmp	w9, #0x21
     dd0:      	b.lo	0xf70 <filter_32ty_range+0x230>
     dd4:      	ldr	w11, [x0, #0x28]
     dd8:      	mov	w9, wzr
     ddc:      	cmp	w11, w10
     de0:      	b.gt	0xf60 <filter_32ty_range+0x220>
     de4:      	ldr	w11, [x0, #0x2c]
     de8:      	cmp	w10, w11
     dec:      	b.le	0xe84 <filter_32ty_range+0x144>
     df0:      	b	0xf60 <filter_32ty_range+0x220>
     df4:      	ldp	w9, w12, [x0, #0x10]
     df8:      	ldr	w11, [x0, #0x8]
     dfc:      	cmp	w9, w10
     e00:      	ccmp	w10, w12, #0x0, le
     e04:      	cset	w9, le
     e08:      	cmp	w11, #0x11
     e0c:      	b.lo	0xf60 <filter_32ty_range+0x220>
     e10:      	ldp	w12, w13, [x0, #0x18]
     e14:      	cmp	w12, w10
     e18:      	ccmp	w10, w13, #0x0, le
     e1c:      	csinc	w9, w9, wzr, gt
     e20:      	cmp	w11, #0x19
     e24:      	b.lo	0xf60 <filter_32ty_range+0x220>
     e28:      	ldp	w12, w13, [x0, #0x20]
     e2c:      	cmp	w12, w10
     e30:      	ccmp	w10, w13, #0x0, le
     e34:      	csinc	w9, w9, wzr, gt
     e38:      	cmp	w11, #0x21
     e3c:      	b.lo	0xf60 <filter_32ty_range+0x220>
     e40:      	ldp	w11, w12, [x0, #0x28]
     e44:      	cmp	w11, w10
     e48:      	ccmp	w10, w12, #0x0, le
     e4c:      	csinc	w9, w9, wzr, gt
     e50:      	cmp	w8, #0x20
     e54:      	eor	w8, w9, #0x1
     e58:      	csel	w0, wzr, w8, ne
     e5c:      	ret
     e60:      	ldr	w10, [x1]
     e64:      	cmp	w8, #0x1f
     e68:      	b.ne	0xe8c <filter_32ty_range+0x14c>
     e6c:      	ldr	w9, [x0, #0x10]
     e70:      	cmp	w9, w10
     e74:      	b.hi	0xef8 <filter_32ty_range+0x1b8>
     e78:      	ldr	w9, [x0, #0x14]
     e7c:      	cmp	w10, w9
     e80:      	b.hi	0xef8 <filter_32ty_range+0x1b8>
     e84:      	mov	w0, #0x1                // =1
     e88:      	ret
     e8c:      	ldp	w9, w12, [x0, #0x10]
     e90:      	ldr	w11, [x0, #0x8]
     e94:      	cmp	w9, w10
     e98:      	ccmp	w10, w12, #0x2, ls
     e9c:      	cset	w9, ls
     ea0:      	cmp	w11, #0x11
     ea4:      	b.lo	0xf60 <filter_32ty_range+0x220>
     ea8:      	ldp	w12, w13, [x0, #0x18]
     eac:      	cmp	w12, w10
     eb0:      	ccmp	w10, w13, #0x2, ls
     eb4:      	csinc	w9, w9, wzr, hi
     eb8:      	cmp	w11, #0x19
     ebc:      	b.lo	0xf60 <filter_32ty_range+0x220>
     ec0:      	ldp	w12, w13, [x0, #0x20]
     ec4:      	cmp	w12, w10
     ec8:      	ccmp	w10, w13, #0x2, ls
     ecc:      	csinc	w9, w9, wzr, hi
     ed0:      	cmp	w11, #0x21
     ed4:      	b.lo	0xf60 <filter_32ty_range+0x220>
     ed8:      	ldp	w11, w12, [x0, #0x28]
     edc:      	cmp	w11, w10
     ee0:      	ccmp	w10, w12, #0x2, ls
     ee4:      	csinc	w9, w9, wzr, hi
     ee8:      	cmp	w8, #0x20
     eec:      	eor	w8, w9, #0x1
     ef0:      	csel	w0, wzr, w8, ne
     ef4:      	ret
     ef8:      	ldr	w9, [x0, #0x8]
     efc:      	cmp	w9, #0x11
     f00:      	b.lo	0xf70 <filter_32ty_range+0x230>
     f04:      	ldr	w11, [x0, #0x18]
     f08:      	cmp	w11, w10
     f0c:      	b.hi	0xf1c <filter_32ty_range+0x1dc>
     f10:      	ldr	w11, [x0, #0x1c]
     f14:      	cmp	w10, w11
     f18:      	b.ls	0xe84 <filter_32ty_range+0x144>
     f1c:      	cmp	w9, #0x19
     f20:      	b.lo	0xf70 <filter_32ty_range+0x230>
     f24:      	ldr	w11, [x0, #0x20]
     f28:      	cmp	w11, w10
     f2c:      	b.hi	0xf3c <filter_32ty_range+0x1fc>
     f30:      	ldr	w11, [x0, #0x24]
     f34:      	cmp	w10, w11
     f38:      	b.ls	0xe84 <filter_32ty_range+0x144>
     f3c:      	cmp	w9, #0x21
     f40:      	b.lo	0xf70 <filter_32ty_range+0x230>
     f44:      	ldr	w11, [x0, #0x28]
     f48:      	mov	w9, wzr
     f4c:      	cmp	w11, w10
     f50:      	b.hi	0xf60 <filter_32ty_range+0x220>
     f54:      	ldr	w11, [x0, #0x2c]
     f58:      	cmp	w10, w11
     f5c:      	b.ls	0xe84 <filter_32ty_range+0x144>
     f60:      	cmp	w8, #0x20
     f64:      	eor	w8, w9, #0x1
     f68:      	csel	w0, wzr, w8, ne
     f6c:      	ret
     f70:      	mov	w9, wzr
     f74:      	cmp	w8, #0x20
     f78:      	eor	w8, w9, #0x1
     f7c:      	csel	w0, wzr, w8, ne
     f80:      	ret
     f84:      	nop
     f88:      	nop
     f8c:      	nop

0000000000000f90 <filter_16ty_selector_val>:
     f90:      	ldr	w8, [x0, #0x4]
     f94:      	cmp	w8, #0x25
     f98:      	b.hi	0x100c <filter_16ty_selector_val+0x7c>
     f9c:      	mov	x10, #0x40              // =64
     fa0:      	mov	w9, #0x1                // =1
     fa4:      	movk	x10, #0xc00, lsl #16
     fa8:      	lsl	x9, x9, x8
     fac:      	movk	x10, #0x20, lsl #32
     fb0:      	tst	x9, x10
     fb4:      	b.eq	0xfc0 <filter_16ty_selector_val+0x30>
     fb8:      	mov	w0, #0x1                // =1
     fbc:      	ret
     fc0:      	mov	w9, #0x1                // =1
     fc4:      	lsl	x9, x9, x8
     fc8:      	tst	x9, #0x18
     fcc:      	b.eq	0xfec <filter_16ty_selector_val+0x5c>
     fd0:      	ldrh	w9, [x1]
     fd4:      	ldr	w10, [x0, #0x10]
     fd8:      	cmp	w10, w9
     fdc:      	b.ne	0x108c <filter_16ty_selector_val+0xfc>
     fe0:      	cmp	w8, #0x3
     fe4:      	cset	w0, eq
     fe8:      	ret
     fec:      	cmp	x8, #0xc
     ff0:      	b.ne	0x100c <filter_16ty_selector_val+0x7c>
     ff4:      	ldrh	w8, [x1]
     ff8:      	ldr	w9, [x0, #0x10]
     ffc:      	tst	w9, w8
    1000:      	b.eq	0x1138 <filter_16ty_selector_val+0x1a8>
    1004:      	mov	w0, #0x1                // =1
    1008:      	ret
    100c:      	cmp	w8, #0x1
    1010:      	b.eq	0x1054 <filter_16ty_selector_val+0xc4>
    1014:      	cmp	w8, #0x2
    1018:      	b.ne	0x12e0 <filter_16ty_selector_val+0x350>
    101c:      	ldr	w8, [x0, #0xc]
    1020:      	cmp	w8, #0xc
    1024:      	b.hi	0x1170 <filter_16ty_selector_val+0x1e0>
    1028:      	mov	w9, #0x1                // =1
    102c:      	lsl	w8, w9, w8
    1030:      	mov	w9, #0x1402             // =5122
    1034:      	tst	w8, w9
    1038:      	b.eq	0x1170 <filter_16ty_selector_val+0x1e0>
    103c:      	ldrsh	w8, [x1]
    1040:      	ldr	w9, [x0, #0x10]
    1044:      	cmp	w9, w8
    1048:      	b.le	0x1118 <filter_16ty_selector_val+0x188>
    104c:      	mov	w0, #0x1                // =1
    1050:      	ret
    1054:      	ldr	w8, [x0, #0xc]
    1058:      	cmp	w8, #0xc
    105c:      	b.hi	0x1158 <filter_16ty_selector_val+0x1c8>
    1060:      	mov	w9, #0x1                // =1
    1064:      	lsl	w8, w9, w8
    1068:      	mov	w9, #0x1402             // =5122
    106c:      	tst	w8, w9
    1070:      	b.eq	0x1158 <filter_16ty_selector_val+0x1c8>
    1074:      	ldrsh	w8, [x1]
    1078:      	ldr	w9, [x0, #0x10]
    107c:      	cmp	w9, w8
    1080:      	b.ge	0x10f8 <filter_16ty_selector_val+0x168>
    1084:      	mov	w0, #0x1                // =1
    1088:      	ret
    108c:      	ldr	w10, [x0, #0x8]
    1090:      	cmp	w10, #0xd
    1094:      	b.lo	0x10cc <filter_16ty_selector_val+0x13c>
    1098:      	ldr	w11, [x0, #0x14]
    109c:      	cmp	w11, w9
    10a0:      	b.eq	0xfe0 <filter_16ty_selector_val+0x50>
    10a4:      	cmp	w10, #0x11
    10a8:      	b.lo	0x10cc <filter_16ty_selector_val+0x13c>
    10ac:      	ldr	w11, [x0, #0x18]
    10b0:      	cmp	w11, w9
    10b4:      	b.eq	0xfe0 <filter_16ty_selector_val+0x50>
    10b8:      	cmp	w10, #0x15
    10bc:      	b.lo	0x10cc <filter_16ty_selector_val+0x13c>
    10c0:      	ldr	w10, [x0, #0x1c]
    10c4:      	cmp	w10, w9
    10c8:      	b.eq	0xfe0 <filter_16ty_selector_val+0x50>
    10cc:      	cmp	w8, #0x25
    10d0:      	b.hi	0x12e0 <filter_16ty_selector_val+0x350>
    10d4:      	mov	w9, #0x1                // =1
    10d8:      	lsl	x8, x9, x8
    10dc:      	mov	x9, #0x50               // =80
    10e0:      	movk	x9, #0xc00, lsl #16
    10e4:      	movk	x9, #0x20, lsl #32
    10e8:      	tst	x8, x9
    10ec:      	b.eq	0x12e0 <filter_16ty_selector_val+0x350>
    10f0:      	mov	w0, #0x1                // =1
    10f4:      	ret
    10f8:      	ldr	w9, [x0, #0x8]
    10fc:      	cmp	w9, #0xd
    1100:      	b.lo	0x12e0 <filter_16ty_selector_val+0x350>
    1104:      	ldr	w10, [x0, #0x14]
    1108:      	cmp	w10, w8
    110c:      	b.ge	0x11c8 <filter_16ty_selector_val+0x238>
    1110:      	mov	w0, #0x1                // =1
    1114:      	ret
    1118:      	ldr	w9, [x0, #0x8]
    111c:      	cmp	w9, #0xd
    1120:      	b.lo	0x12e0 <filter_16ty_selector_val+0x350>
    1124:      	ldr	w10, [x0, #0x14]
    1128:      	cmp	w10, w8
    112c:      	b.le	0x11e4 <filter_16ty_selector_val+0x254>
    1130:      	mov	w0, #0x1                // =1
    1134:      	ret
    1138:      	ldr	w9, [x0, #0x8]
    113c:      	cmp	w9, #0xd
    1140:      	b.lo	0x12e0 <filter_16ty_selector_val+0x350>
    1144:      	ldr	w10, [x0, #0x14]
    1148:      	tst	w10, w8
    114c:      	b.eq	0x1200 <filter_16ty_selector_val+0x270>
    1150:      	mov	w0, #0x1                // =1
    1154:      	ret
    1158:      	ldrh	w8, [x1]
    115c:      	ldr	w9, [x0, #0x10]
    1160:      	cmp	w9, w8
    1164:      	b.hs	0x1188 <filter_16ty_selector_val+0x1f8>
    1168:      	mov	w0, #0x1                // =1
    116c:      	ret
    1170:      	ldrh	w8, [x1]
    1174:      	ldr	w9, [x0, #0x10]
    1178:      	cmp	w9, w8
    117c:      	b.ls	0x11a8 <filter_16ty_selector_val+0x218>
    1180:      	mov	w0, #0x1                // =1
    1184:      	ret
    1188:      	ldr	w9, [x0, #0x8]
    118c:      	cmp	w9, #0xd
    1190:      	b.lo	0x12e0 <filter_16ty_selector_val+0x350>
    1194:      	ldr	w10, [x0, #0x14]
    1198:      	cmp	w10, w8
    119c:      	b.hs	0x121c <filter_16ty_selector_val+0x28c>
    11a0:      	mov	w0, #0x1                // =1
    11a4:      	ret
    11a8:      	ldr	w9, [x0, #0x8]
    11ac:      	cmp	w9, #0xd
    11b0:      	b.lo	0x12e0 <filter_16ty_selector_val+0x350>
    11b4:      	ldr	w10, [x0, #0x14]
    11b8:      	cmp	w10, w8
    11bc:      	b.ls	0x1238 <filter_16ty_selector_val+0x2a8>
    11c0:      	mov	w0, #0x1                // =1
    11c4:      	ret
    11c8:      	cmp	w9, #0x11
    11cc:      	b.lo	0x12e0 <filter_16ty_selector_val+0x350>
    11d0:      	ldr	w10, [x0, #0x18]
    11d4:      	cmp	w10, w8
    11d8:      	b.ge	0x1254 <filter_16ty_selector_val+0x2c4>
    11dc:      	mov	w0, #0x1                // =1
    11e0:      	ret
    11e4:      	cmp	w9, #0x11
    11e8:      	b.lo	0x12e0 <filter_16ty_selector_val+0x350>
    11ec:      	ldr	w10, [x0, #0x18]
    11f0:      	cmp	w10, w8
    11f4:      	b.le	0x1270 <filter_16ty_selector_val+0x2e0>
    11f8:      	mov	w0, #0x1                // =1
    11fc:      	ret
    1200:      	cmp	w9, #0x11
    1204:      	b.lo	0x12e0 <filter_16ty_selector_val+0x350>
    1208:      	ldr	w10, [x0, #0x18]
    120c:      	tst	w10, w8
    1210:      	b.eq	0x128c <filter_16ty_selector_val+0x2fc>
    1214:      	mov	w0, #0x1                // =1
    1218:      	ret
    121c:      	cmp	w9, #0x11
    1220:      	b.lo	0x12e0 <filter_16ty_selector_val+0x350>
    1224:      	ldr	w10, [x0, #0x18]
    1228:      	cmp	w10, w8
    122c:      	b.hs	0x12a8 <filter_16ty_selector_val+0x318>
    1230:      	mov	w0, #0x1                // =1
    1234:      	ret
    1238:      	cmp	w9, #0x11
    123c:      	b.lo	0x12e0 <filter_16ty_selector_val+0x350>
    1240:      	ldr	w10, [x0, #0x18]
    1244:      	cmp	w10, w8
    1248:      	b.ls	0x12c4 <filter_16ty_selector_val+0x334>
    124c:      	mov	w0, #0x1                // =1
    1250:      	ret
    1254:      	cmp	w9, #0x15
    1258:      	b.lo	0x12e0 <filter_16ty_selector_val+0x350>
    125c:      	ldr	w9, [x0, #0x1c]
    1260:      	cmp	w9, w8
    1264:      	b.ge	0x12e0 <filter_16ty_selector_val+0x350>
    1268:      	mov	w0, #0x1                // =1
    126c:      	ret
    1270:      	cmp	w9, #0x15
    1274:      	b.lo	0x12e0 <filter_16ty_selector_val+0x350>
    1278:      	ldr	w9, [x0, #0x1c]
    127c:      	cmp	w9, w8
    1280:      	b.le	0x12e0 <filter_16ty_selector_val+0x350>
    1284:      	mov	w0, #0x1                // =1
    1288:      	ret
    128c:      	cmp	w9, #0x15
    1290:      	b.lo	0x12e0 <filter_16ty_selector_val+0x350>
    1294:      	ldr	w9, [x0, #0x1c]
    1298:      	tst	w9, w8
    129c:      	b.eq	0x12e0 <filter_16ty_selector_val+0x350>
    12a0:      	mov	w0, #0x1                // =1
    12a4:      	ret
    12a8:      	cmp	w9, #0x15
    12ac:      	b.lo	0x12e0 <filter_16ty_selector_val+0x350>
    12b0:      	ldr	w9, [x0, #0x1c]
    12b4:      	cmp	w9, w8
    12b8:      	b.hs	0x12e0 <filter_16ty_selector_val+0x350>
    12bc:      	mov	w0, #0x1                // =1
    12c0:      	ret
    12c4:      	cmp	w9, #0x15
    12c8:      	b.lo	0x12e0 <filter_16ty_selector_val+0x350>
    12cc:      	ldr	w9, [x0, #0x1c]
    12d0:      	cmp	w9, w8
    12d4:      	b.ls	0x12e0 <filter_16ty_selector_val+0x350>
    12d8:      	mov	w0, #0x1                // =1
    12dc:      	ret
    12e0:      	mov	x0, xzr
    12e4:      	ret
    12e8:      	nop
    12ec:      	nop

00000000000012f0 <filter_16ty_map>:
    12f0:      	sub	sp, sp, #0x30
    12f4:      	str	x30, [sp, #0x10]
    12f8:      	stp	x20, x19, [sp, #0x20]
    12fc:      	ldrb	w8, [x0, #0x10]
    1300:      	mov	x19, x0
    1304:      	adrp	x0, 0x1000 <filter_16ty_selector_val+0x70>
    1308:      	add	x9, sp, #0x1c
    130c:      	str	w8, [sp, #0x1c]
    1310:      	mov	w8, #0x1                // =1
    1314:      	mov	x20, x1
    1318:      	add	x1, sp, #0x1c
    131c:      	ldr	x0, [x0]
    1320:      	blr	x8
    1324:      	cbz	x0, 0x1398 <filter_16ty_map+0xa8>
    1328:      	ldrh	w8, [x20]
    132c:      	mov	w9, #0x1                // =1
    1330:      	add	x1, sp, #0x8
    1334:      	mov	w20, #0x1               // =1
    1338:      	str	x8, [sp, #0x8]
    133c:      	add	x8, sp, #0x8
    1340:      	blr	x9
    1344:      	ldr	w9, [x19, #0x4]
    1348:      	mov	w8, wzr
    134c:      	cmp	w9, #0x1d
    1350:      	b.hi	0x1394 <filter_16ty_map+0xa4>
    1354:      	mov	w11, #0x8400            // =33792
    1358:      	lsl	w10, w20, w9
    135c:      	movk	w11, #0x3003, lsl #16
    1360:      	tst	w10, w11
    1364:      	b.eq	0x1374 <filter_16ty_map+0x84>
    1368:      	cmp	x0, #0x0
    136c:      	cset	w8, ne
    1370:      	b	0x1394 <filter_16ty_map+0xa4>
    1374:      	mov	w10, #0x1               // =1
    1378:      	lsl	w9, w10, w9
    137c:      	mov	w10, #0x800             // =2048
    1380:      	movk	w10, #0xc, lsl #16
    1384:      	tst	w9, w10
    1388:      	b.eq	0x1394 <filter_16ty_map+0xa4>
    138c:      	cmp	x0, #0x0
    1390:      	cset	w8, eq
    1394:      	mov	w0, w8
    1398:      	ldp	x20, x19, [sp, #0x20]
    139c:      	ldr	x30, [sp, #0x10]
    13a0:      	add	sp, sp, #0x30
    13a4:      	ret
    13a8:      	nop
    13ac:      	nop

00000000000013b0 <filter_16ty_range>:
    13b0:      	ldr	w9, [x0, #0xc]
    13b4:      	ldr	w8, [x0, #0x4]
    13b8:      	mov	w10, #0x1               // =1
    13bc:      	cmp	w9, #0xc
    13c0:      	lsl	w9, w10, w9
    13c4:      	mov	w10, #0x1402            // =5122
    13c8:      	and	w9, w9, w10
    13cc:      	ccmp	w9, #0x0, #0x4, ls
    13d0:      	b.eq	0x14d0 <filter_16ty_range+0x120>
    13d4:      	ldrsh	w10, [x1]
    13d8:      	cmp	w8, #0x1f
    13dc:      	b.ne	0x1464 <filter_16ty_range+0xb4>
    13e0:      	ldr	w9, [x0, #0x10]
    13e4:      	cmp	w9, w10
    13e8:      	b.gt	0x13f8 <filter_16ty_range+0x48>
    13ec:      	ldr	w9, [x0, #0x14]
    13f0:      	cmp	w9, w10
    13f4:      	b.ge	0x14f4 <filter_16ty_range+0x144>
    13f8:      	ldr	w9, [x0, #0x8]
    13fc:      	cmp	w9, #0x11
    1400:      	b.lo	0x15e0 <filter_16ty_range+0x230>
    1404:      	ldr	w11, [x0, #0x18]
    1408:      	cmp	w11, w10
    140c:      	b.gt	0x141c <filter_16ty_range+0x6c>
    1410:      	ldr	w11, [x0, #0x1c]
    1414:      	cmp	w11, w10
    1418:      	b.ge	0x14f4 <filter_16ty_range+0x144>
    141c:      	cmp	w9, #0x19
    1420:      	b.lo	0x15e0 <filter_16ty_range+0x230>
    1424:      	ldr	w11, [x0, #0x20]
    1428:      	cmp	w11, w10
    142c:      	b.gt	0x143c <filter_16ty_range+0x8c>
    1430:      	ldr	w11, [x0, #0x24]
    1434:      	cmp	w11, w10
    1438:      	b.ge	0x14f4 <filter_16ty_range+0x144>
    143c:      	cmp	w9, #0x21
    1440:      	b.lo	0x15e0 <filter_16ty_range+0x230>
    1444:      	ldr	w11, [x0, #0x28]
    1448:      	mov	w9, wzr
    144c:      	cmp	w11, w10
    1450:      	b.gt	0x15d0 <filter_16ty_range+0x220>
    1454:      	ldr	w11, [x0, #0x2c]
    1458:      	cmp	w11, w10
    145c:      	b.ge	0x14f4 <filter_16ty_range+0x144>
    1460:      	b	0x15d0 <filter_16ty_range+0x220>
    1464:      	ldp	w9, w12, [x0, #0x10]
    1468:      	ldr	w11, [x0, #0x8]
    146c:      	cmp	w9, w10
    1470:      	ccmp	w12, w10, #0x8, le
    1474:      	cset	w9, ge
    1478:      	cmp	w11, #0x11
    147c:      	b.lo	0x15d0 <filter_16ty_range+0x220>
    1480:      	ldp	w12, w13, [x0, #0x18]
    1484:      	cmp	w12, w10
    1488:      	ccmp	w13, w10, #0x8, le
    148c:      	csinc	w9, w9, wzr, lt
    1490:      	cmp	w11, #0x19
    1494:      	b.lo	0x15d0 <filter_16ty_range+0x220>
    1498:      	ldp	w12, w13, [x0, #0x20]
    149c:      	cmp	w12, w10
    14a0:      	ccmp	w13, w10, #0x8, le
    14a4:      	csinc	w9, w9, wzr, lt
    14a8:      	cmp	w11, #0x21
    14ac:      	b.lo	0x15d0 <filter_16ty_range+0x220>
    14b0:      	ldp	w11, w12, [x0, #0x28]
    14b4:      	cmp	w11, w10
    14b8:      	ccmp	w12, w10, #0x8, le
    14bc:      	csinc	w9, w9, wzr, lt
    14c0:      	cmp	w8, #0x20
    14c4:      	eor	w8, w9, #0x1
    14c8:      	csel	w0, wzr, w8, ne
    14cc:      	ret
    14d0:      	ldrh	w10, [x1]
    14d4:      	cmp	w8, #0x1f
    14d8:      	b.ne	0x14fc <filter_16ty_range+0x14c>
    14dc:      	ldr	w9, [x0, #0x10]
    14e0:      	cmp	w9, w10
    14e4:      	b.hi	0x1568 <filter_16ty_range+0x1b8>
    14e8:      	ldr	w9, [x0, #0x14]
    14ec:      	cmp	w9, w10
    14f0:      	b.lo	0x1568 <filter_16ty_range+0x1b8>
    14f4:      	mov	w0, #0x1                // =1
    14f8:      	ret
    14fc:      	ldp	w9, w12, [x0, #0x10]
    1500:      	ldr	w11, [x0, #0x8]
    1504:      	cmp	w9, w10
    1508:      	ccmp	w12, w10, #0x0, ls
    150c:      	cset	w9, hs
    1510:      	cmp	w11, #0x11
    1514:      	b.lo	0x15d0 <filter_16ty_range+0x220>
    1518:      	ldp	w12, w13, [x0, #0x18]
    151c:      	cmp	w12, w10
    1520:      	ccmp	w13, w10, #0x0, ls
    1524:      	csinc	w9, w9, wzr, lo
    1528:      	cmp	w11, #0x19
    152c:      	b.lo	0x15d0 <filter_16ty_range+0x220>
    1530:      	ldp	w12, w13, [x0, #0x20]
    1534:      	cmp	w12, w10
    1538:      	ccmp	w13, w10, #0x0, ls
    153c:      	csinc	w9, w9, wzr, lo
    1540:      	cmp	w11, #0x21
    1544:      	b.lo	0x15d0 <filter_16ty_range+0x220>
    1548:      	ldp	w11, w12, [x0, #0x28]
    154c:      	cmp	w11, w10
    1550:      	ccmp	w12, w10, #0x0, ls
    1554:      	csinc	w9, w9, wzr, lo
    1558:      	cmp	w8, #0x20
    155c:      	eor	w8, w9, #0x1
    1560:      	csel	w0, wzr, w8, ne
    1564:      	ret
    1568:      	ldr	w9, [x0, #0x8]
    156c:      	cmp	w9, #0x11
    1570:      	b.lo	0x15e0 <filter_16ty_range+0x230>
    1574:      	ldr	w11, [x0, #0x18]
    1578:      	cmp	w11, w10
    157c:      	b.hi	0x158c <filter_16ty_range+0x1dc>
    1580:      	ldr	w11, [x0, #0x1c]
    1584:      	cmp	w11, w10
    1588:      	b.hs	0x14f4 <filter_16ty_range+0x144>
    158c:      	cmp	w9, #0x19
    1590:      	b.lo	0x15e0 <filter_16ty_range+0x230>
    1594:      	ldr	w11, [x0, #0x20]
    1598:      	cmp	w11, w10
    159c:      	b.hi	0x15ac <filter_16ty_range+0x1fc>
    15a0:      	ldr	w11, [x0, #0x24]
    15a4:      	cmp	w11, w10
    15a8:      	b.hs	0x14f4 <filter_16ty_range+0x144>
    15ac:      	cmp	w9, #0x21
    15b0:      	b.lo	0x15e0 <filter_16ty_range+0x230>
    15b4:      	ldr	w11, [x0, #0x28]
    15b8:      	mov	w9, wzr
    15bc:      	cmp	w11, w10
    15c0:      	b.hi	0x15d0 <filter_16ty_range+0x220>
    15c4:      	ldr	w11, [x0, #0x2c]
    15c8:      	cmp	w11, w10
    15cc:      	b.hs	0x14f4 <filter_16ty_range+0x144>
    15d0:      	cmp	w8, #0x20
    15d4:      	eor	w8, w9, #0x1
    15d8:      	csel	w0, wzr, w8, ne
    15dc:      	ret
    15e0:      	mov	w9, wzr
    15e4:      	cmp	w8, #0x20
    15e8:      	eor	w8, w9, #0x1
    15ec:      	csel	w0, wzr, w8, ne
    15f0:      	ret
    15f4:      	nop
    15f8:      	nop
    15fc:      	nop

0000000000001600 <filter_8ty_selector_val>:
    1600:      	ldr	w8, [x0, #0x4]
    1604:      	cmp	w8, #0x25
    1608:      	b.hi	0x167c <filter_8ty_selector_val+0x7c>
    160c:      	mov	x10, #0x40              // =64
    1610:      	mov	w9, #0x1                // =1
    1614:      	movk	x10, #0xc00, lsl #16
    1618:      	lsl	x9, x9, x8
    161c:      	movk	x10, #0x20, lsl #32
    1620:      	tst	x9, x10
    1624:      	b.eq	0x1630 <filter_8ty_selector_val+0x30>
    1628:      	mov	w0, #0x1                // =1
    162c:      	ret
    1630:      	mov	w9, #0x1                // =1
    1634:      	lsl	x9, x9, x8
    1638:      	tst	x9, #0x18
    163c:      	b.eq	0x165c <filter_8ty_selector_val+0x5c>
    1640:      	ldrb	w9, [x1]
    1644:      	ldr	w10, [x0, #0x10]
    1648:      	cmp	w10, w9
    164c:      	b.ne	0x16fc <filter_8ty_selector_val+0xfc>
    1650:      	cmp	w8, #0x3
    1654:      	cset	w0, eq
    1658:      	ret
    165c:      	cmp	x8, #0xc
    1660:      	b.ne	0x167c <filter_8ty_selector_val+0x7c>
    1664:      	ldrb	w8, [x1]
    1668:      	ldr	w9, [x0, #0x10]
    166c:      	tst	w9, w8
    1670:      	b.eq	0x17a8 <filter_8ty_selector_val+0x1a8>
    1674:      	mov	w0, #0x1                // =1
    1678:      	ret
    167c:      	cmp	w8, #0x1
    1680:      	b.eq	0x16c4 <filter_8ty_selector_val+0xc4>
    1684:      	cmp	w8, #0x2
    1688:      	b.ne	0x1950 <filter_8ty_selector_val+0x350>
    168c:      	ldr	w8, [x0, #0xc]
    1690:      	cmp	w8, #0xc
    1694:      	b.hi	0x17e0 <filter_8ty_selector_val+0x1e0>
    1698:      	mov	w9, #0x1                // =1
    169c:      	lsl	w8, w9, w8
    16a0:      	mov	w9, #0x1402             // =5122
    16a4:      	tst	w8, w9
    16a8:      	b.eq	0x17e0 <filter_8ty_selector_val+0x1e0>
    16ac:      	ldrsb	w8, [x1]
    16b0:      	ldr	w9, [x0, #0x10]
    16b4:      	cmp	w9, w8
    16b8:      	b.le	0x1788 <filter_8ty_selector_val+0x188>
    16bc:      	mov	w0, #0x1                // =1
    16c0:      	ret
    16c4:      	ldr	w8, [x0, #0xc]
    16c8:      	cmp	w8, #0xc
    16cc:      	b.hi	0x17c8 <filter_8ty_selector_val+0x1c8>
    16d0:      	mov	w9, #0x1                // =1
    16d4:      	lsl	w8, w9, w8
    16d8:      	mov	w9, #0x1402             // =5122
    16dc:      	tst	w8, w9
    16e0:      	b.eq	0x17c8 <filter_8ty_selector_val+0x1c8>
    16e4:      	ldrsb	w8, [x1]
    16e8:      	ldr	w9, [x0, #0x10]
    16ec:      	cmp	w9, w8
    16f0:      	b.ge	0x1768 <filter_8ty_selector_val+0x168>
    16f4:      	mov	w0, #0x1                // =1
    16f8:      	ret
    16fc:      	ldr	w10, [x0, #0x8]
    1700:      	cmp	w10, #0xd
    1704:      	b.lo	0x173c <filter_8ty_selector_val+0x13c>
    1708:      	ldr	w11, [x0, #0x14]
    170c:      	cmp	w11, w9
    1710:      	b.eq	0x1650 <filter_8ty_selector_val+0x50>
    1714:      	cmp	w10, #0x11
    1718:      	b.lo	0x173c <filter_8ty_selector_val+0x13c>
    171c:      	ldr	w11, [x0, #0x18]
    1720:      	cmp	w11, w9
    1724:      	b.eq	0x1650 <filter_8ty_selector_val+0x50>
    1728:      	cmp	w10, #0x15
    172c:      	b.lo	0x173c <filter_8ty_selector_val+0x13c>
    1730:      	ldr	w10, [x0, #0x1c]
    1734:      	cmp	w10, w9
    1738:      	b.eq	0x1650 <filter_8ty_selector_val+0x50>
    173c:      	cmp	w8, #0x25
    1740:      	b.hi	0x1950 <filter_8ty_selector_val+0x350>
    1744:      	mov	w9, #0x1                // =1
    1748:      	lsl	x8, x9, x8
    174c:      	mov	x9, #0x50               // =80
    1750:      	movk	x9, #0xc00, lsl #16
    1754:      	movk	x9, #0x20, lsl #32
    1758:      	tst	x8, x9
    175c:      	b.eq	0x1950 <filter_8ty_selector_val+0x350>
    1760:      	mov	w0, #0x1                // =1
    1764:      	ret
    1768:      	ldr	w9, [x0, #0x8]
    176c:      	cmp	w9, #0xd
    1770:      	b.lo	0x1950 <filter_8ty_selector_val+0x350>
    1774:      	ldr	w10, [x0, #0x14]
    1778:      	cmp	w10, w8
    177c:      	b.ge	0x1838 <filter_8ty_selector_val+0x238>
    1780:      	mov	w0, #0x1                // =1
    1784:      	ret
    1788:      	ldr	w9, [x0, #0x8]
    178c:      	cmp	w9, #0xd
    1790:      	b.lo	0x1950 <filter_8ty_selector_val+0x350>
    1794:      	ldr	w10, [x0, #0x14]
    1798:      	cmp	w10, w8
    179c:      	b.le	0x1854 <filter_8ty_selector_val+0x254>
    17a0:      	mov	w0, #0x1                // =1
    17a4:      	ret
    17a8:      	ldr	w9, [x0, #0x8]
    17ac:      	cmp	w9, #0xd
    17b0:      	b.lo	0x1950 <filter_8ty_selector_val+0x350>
    17b4:      	ldr	w10, [x0, #0x14]
    17b8:      	tst	w10, w8
    17bc:      	b.eq	0x1870 <filter_8ty_selector_val+0x270>
    17c0:      	mov	w0, #0x1                // =1
    17c4:      	ret
    17c8:      	ldrb	w8, [x1]
    17cc:      	ldr	w9, [x0, #0x10]
    17d0:      	cmp	w9, w8
    17d4:      	b.hs	0x17f8 <filter_8ty_selector_val+0x1f8>
    17d8:      	mov	w0, #0x1                // =1
    17dc:      	ret
    17e0:      	ldrb	w8, [x1]
    17e4:      	ldr	w9, [x0, #0x10]
    17e8:      	cmp	w9, w8
    17ec:      	b.ls	0x1818 <filter_8ty_selector_val+0x218>
    17f0:      	mov	w0, #0x1                // =1
    17f4:      	ret
    17f8:      	ldr	w9, [x0, #0x8]
    17fc:      	cmp	w9, #0xd
    1800:      	b.lo	0x1950 <filter_8ty_selector_val+0x350>
    1804:      	ldr	w10, [x0, #0x14]
    1808:      	cmp	w10, w8
    180c:      	b.hs	0x188c <filter_8ty_selector_val+0x28c>
    1810:      	mov	w0, #0x1                // =1
    1814:      	ret
    1818:      	ldr	w9, [x0, #0x8]
    181c:      	cmp	w9, #0xd
    1820:      	b.lo	0x1950 <filter_8ty_selector_val+0x350>
    1824:      	ldr	w10, [x0, #0x14]
    1828:      	cmp	w10, w8
    182c:      	b.ls	0x18a8 <filter_8ty_selector_val+0x2a8>
    1830:      	mov	w0, #0x1                // =1
    1834:      	ret
    1838:      	cmp	w9, #0x11
    183c:      	b.lo	0x1950 <filter_8ty_selector_val+0x350>
    1840:      	ldr	w10, [x0, #0x18]
    1844:      	cmp	w10, w8
    1848:      	b.ge	0x18c4 <filter_8ty_selector_val+0x2c4>
    184c:      	mov	w0, #0x1                // =1
    1850:      	ret
    1854:      	cmp	w9, #0x11
    1858:      	b.lo	0x1950 <filter_8ty_selector_val+0x350>
    185c:      	ldr	w10, [x0, #0x18]
    1860:      	cmp	w10, w8
    1864:      	b.le	0x18e0 <filter_8ty_selector_val+0x2e0>
    1868:      	mov	w0, #0x1                // =1
    186c:      	ret
    1870:      	cmp	w9, #0x11
    1874:      	b.lo	0x1950 <filter_8ty_selector_val+0x350>
    1878:      	ldr	w10, [x0, #0x18]
    187c:      	tst	w10, w8
    1880:      	b.eq	0x18fc <filter_8ty_selector_val+0x2fc>
    1884:      	mov	w0, #0x1                // =1
    1888:      	ret
    188c:      	cmp	w9, #0x11
    1890:      	b.lo	0x1950 <filter_8ty_selector_val+0x350>
    1894:      	ldr	w10, [x0, #0x18]
    1898:      	cmp	w10, w8
    189c:      	b.hs	0x1918 <filter_8ty_selector_val+0x318>
    18a0:      	mov	w0, #0x1                // =1
    18a4:      	ret
    18a8:      	cmp	w9, #0x11
    18ac:      	b.lo	0x1950 <filter_8ty_selector_val+0x350>
    18b0:      	ldr	w10, [x0, #0x18]
    18b4:      	cmp	w10, w8
    18b8:      	b.ls	0x1934 <filter_8ty_selector_val+0x334>
    18bc:      	mov	w0, #0x1                // =1
    18c0:      	ret
    18c4:      	cmp	w9, #0x15
    18c8:      	b.lo	0x1950 <filter_8ty_selector_val+0x350>
    18cc:      	ldr	w9, [x0, #0x1c]
    18d0:      	cmp	w9, w8
    18d4:      	b.ge	0x1950 <filter_8ty_selector_val+0x350>
    18d8:      	mov	w0, #0x1                // =1
    18dc:      	ret
    18e0:      	cmp	w9, #0x15
    18e4:      	b.lo	0x1950 <filter_8ty_selector_val+0x350>
    18e8:      	ldr	w9, [x0, #0x1c]
    18ec:      	cmp	w9, w8
    18f0:      	b.le	0x1950 <filter_8ty_selector_val+0x350>
    18f4:      	mov	w0, #0x1                // =1
    18f8:      	ret
    18fc:      	cmp	w9, #0x15
    1900:      	b.lo	0x1950 <filter_8ty_selector_val+0x350>
    1904:      	ldr	w9, [x0, #0x1c]
    1908:      	tst	w9, w8
    190c:      	b.eq	0x1950 <filter_8ty_selector_val+0x350>
    1910:      	mov	w0, #0x1                // =1
    1914:      	ret
    1918:      	cmp	w9, #0x15
    191c:      	b.lo	0x1950 <filter_8ty_selector_val+0x350>
    1920:      	ldr	w9, [x0, #0x1c]
    1924:      	cmp	w9, w8
    1928:      	b.hs	0x1950 <filter_8ty_selector_val+0x350>
    192c:      	mov	w0, #0x1                // =1
    1930:      	ret
    1934:      	cmp	w9, #0x15
    1938:      	b.lo	0x1950 <filter_8ty_selector_val+0x350>
    193c:      	ldr	w9, [x0, #0x1c]
    1940:      	cmp	w9, w8
    1944:      	b.ls	0x1950 <filter_8ty_selector_val+0x350>
    1948:      	mov	w0, #0x1                // =1
    194c:      	ret
    1950:      	mov	x0, xzr
    1954:      	ret
    1958:      	nop
    195c:      	nop

0000000000001960 <filter_8ty_map>:
    1960:      	sub	sp, sp, #0x30
    1964:      	str	x30, [sp, #0x10]
    1968:      	stp	x20, x19, [sp, #0x20]
    196c:      	ldrb	w8, [x0, #0x10]
    1970:      	mov	x19, x0
    1974:      	adrp	x0, 0x1000 <filter_16ty_selector_val+0x70>
    1978:      	add	x9, sp, #0x1c
    197c:      	str	w8, [sp, #0x1c]
    1980:      	mov	w8, #0x1                // =1
    1984:      	mov	x20, x1
    1988:      	add	x1, sp, #0x1c
    198c:      	ldr	x0, [x0]
    1990:      	blr	x8
    1994:      	cbz	x0, 0x1a08 <filter_8ty_map+0xa8>
    1998:      	ldrb	w8, [x20]
    199c:      	mov	w9, #0x1                // =1
    19a0:      	add	x1, sp, #0x8
    19a4:      	mov	w20, #0x1               // =1
    19a8:      	str	x8, [sp, #0x8]
    19ac:      	add	x8, sp, #0x8
    19b0:      	blr	x9
    19b4:      	ldr	w9, [x19, #0x4]
    19b8:      	mov	w8, wzr
    19bc:      	cmp	w9, #0x1d
    19c0:      	b.hi	0x1a04 <filter_8ty_map+0xa4>
    19c4:      	mov	w11, #0x8400            // =33792
    19c8:      	lsl	w10, w20, w9
    19cc:      	movk	w11, #0x3003, lsl #16
    19d0:      	tst	w10, w11
    19d4:      	b.eq	0x19e4 <filter_8ty_map+0x84>
    19d8:      	cmp	x0, #0x0
    19dc:      	cset	w8, ne
    19e0:      	b	0x1a04 <filter_8ty_map+0xa4>
    19e4:      	mov	w10, #0x1               // =1
    19e8:      	lsl	w9, w10, w9
    19ec:      	mov	w10, #0x800             // =2048
    19f0:      	movk	w10, #0xc, lsl #16
    19f4:      	tst	w9, w10
    19f8:      	b.eq	0x1a04 <filter_8ty_map+0xa4>
    19fc:      	cmp	x0, #0x0
    1a00:      	cset	w8, eq
    1a04:      	mov	w0, w8
    1a08:      	ldp	x20, x19, [sp, #0x20]
    1a0c:      	ldr	x30, [sp, #0x10]
    1a10:      	add	sp, sp, #0x30
    1a14:      	ret
    1a18:      	nop
    1a1c:      	nop

0000000000001a20 <filter_8ty_range>:
    1a20:      	ldr	w9, [x0, #0xc]
    1a24:      	ldr	w8, [x0, #0x4]
    1a28:      	mov	w10, #0x1               // =1
    1a2c:      	cmp	w9, #0xc
    1a30:      	lsl	w9, w10, w9
    1a34:      	mov	w10, #0x1402            // =5122
    1a38:      	and	w9, w9, w10
    1a3c:      	ccmp	w9, #0x0, #0x4, ls
    1a40:      	b.eq	0x1b40 <filter_8ty_range+0x120>
    1a44:      	ldrsb	w10, [x1]
    1a48:      	cmp	w8, #0x1f
    1a4c:      	b.ne	0x1ad4 <filter_8ty_range+0xb4>
    1a50:      	ldr	w9, [x0, #0x10]
    1a54:      	cmp	w9, w10
    1a58:      	b.gt	0x1a68 <filter_8ty_range+0x48>
    1a5c:      	ldr	w9, [x0, #0x14]
    1a60:      	cmp	w9, w10
    1a64:      	b.ge	0x1b64 <filter_8ty_range+0x144>
    1a68:      	ldr	w9, [x0, #0x8]
    1a6c:      	cmp	w9, #0x11
    1a70:      	b.lo	0x1c50 <filter_8ty_range+0x230>
    1a74:      	ldr	w11, [x0, #0x18]
    1a78:      	cmp	w11, w10
    1a7c:      	b.gt	0x1a8c <filter_8ty_range+0x6c>
    1a80:      	ldr	w11, [x0, #0x1c]
    1a84:      	cmp	w11, w10
    1a88:      	b.ge	0x1b64 <filter_8ty_range+0x144>
    1a8c:      	cmp	w9, #0x19
    1a90:      	b.lo	0x1c50 <filter_8ty_range+0x230>
    1a94:      	ldr	w11, [x0, #0x20]
    1a98:      	cmp	w11, w10
    1a9c:      	b.gt	0x1aac <filter_8ty_range+0x8c>
    1aa0:      	ldr	w11, [x0, #0x24]
    1aa4:      	cmp	w11, w10
    1aa8:      	b.ge	0x1b64 <filter_8ty_range+0x144>
    1aac:      	cmp	w9, #0x21
    1ab0:      	b.lo	0x1c50 <filter_8ty_range+0x230>
    1ab4:      	ldr	w11, [x0, #0x28]
    1ab8:      	mov	w9, wzr
    1abc:      	cmp	w11, w10
    1ac0:      	b.gt	0x1c40 <filter_8ty_range+0x220>
    1ac4:      	ldr	w11, [x0, #0x2c]
    1ac8:      	cmp	w11, w10
    1acc:      	b.ge	0x1b64 <filter_8ty_range+0x144>
    1ad0:      	b	0x1c40 <filter_8ty_range+0x220>
    1ad4:      	ldp	w9, w12, [x0, #0x10]
    1ad8:      	ldr	w11, [x0, #0x8]
    1adc:      	cmp	w9, w10
    1ae0:      	ccmp	w12, w10, #0x8, le
    1ae4:      	cset	w9, ge
    1ae8:      	cmp	w11, #0x11
    1aec:      	b.lo	0x1c40 <filter_8ty_range+0x220>
    1af0:      	ldp	w12, w13, [x0, #0x18]
    1af4:      	cmp	w12, w10
    1af8:      	ccmp	w13, w10, #0x8, le
    1afc:      	csinc	w9, w9, wzr, lt
    1b00:      	cmp	w11, #0x19
    1b04:      	b.lo	0x1c40 <filter_8ty_range+0x220>
    1b08:      	ldp	w12, w13, [x0, #0x20]
    1b0c:      	cmp	w12, w10
    1b10:      	ccmp	w13, w10, #0x8, le
    1b14:      	csinc	w9, w9, wzr, lt
    1b18:      	cmp	w11, #0x21
    1b1c:      	b.lo	0x1c40 <filter_8ty_range+0x220>
    1b20:      	ldp	w11, w12, [x0, #0x28]
    1b24:      	cmp	w11, w10
    1b28:      	ccmp	w12, w10, #0x8, le
    1b2c:      	csinc	w9, w9, wzr, lt
    1b30:      	cmp	w8, #0x20
    1b34:      	eor	w8, w9, #0x1
    1b38:      	csel	w0, wzr, w8, ne
    1b3c:      	ret
    1b40:      	ldrb	w10, [x1]
    1b44:      	cmp	w8, #0x1f
    1b48:      	b.ne	0x1b6c <filter_8ty_range+0x14c>
    1b4c:      	ldr	w9, [x0, #0x10]
    1b50:      	cmp	w9, w10
    1b54:      	b.hi	0x1bd8 <filter_8ty_range+0x1b8>
    1b58:      	ldr	w9, [x0, #0x14]
    1b5c:      	cmp	w9, w10
    1b60:      	b.lo	0x1bd8 <filter_8ty_range+0x1b8>
    1b64:      	mov	w0, #0x1                // =1
    1b68:      	ret
    1b6c:      	ldp	w9, w12, [x0, #0x10]
    1b70:      	ldr	w11, [x0, #0x8]
    1b74:      	cmp	w9, w10
    1b78:      	ccmp	w12, w10, #0x0, ls
    1b7c:      	cset	w9, hs
    1b80:      	cmp	w11, #0x11
    1b84:      	b.lo	0x1c40 <filter_8ty_range+0x220>
    1b88:      	ldp	w12, w13, [x0, #0x18]
    1b8c:      	cmp	w12, w10
    1b90:      	ccmp	w13, w10, #0x0, ls
    1b94:      	csinc	w9, w9, wzr, lo
    1b98:      	cmp	w11, #0x19
    1b9c:      	b.lo	0x1c40 <filter_8ty_range+0x220>
    1ba0:      	ldp	w12, w13, [x0, #0x20]
    1ba4:      	cmp	w12, w10
    1ba8:      	ccmp	w13, w10, #0x0, ls
    1bac:      	csinc	w9, w9, wzr, lo
    1bb0:      	cmp	w11, #0x21
    1bb4:      	b.lo	0x1c40 <filter_8ty_range+0x220>
    1bb8:      	ldp	w11, w12, [x0, #0x28]
    1bbc:      	cmp	w11, w10
    1bc0:      	ccmp	w12, w10, #0x0, ls
    1bc4:      	csinc	w9, w9, wzr, lo
    1bc8:      	cmp	w8, #0x20
    1bcc:      	eor	w8, w9, #0x1
    1bd0:      	csel	w0, wzr, w8, ne
    1bd4:      	ret
    1bd8:      	ldr	w9, [x0, #0x8]
    1bdc:      	cmp	w9, #0x11
    1be0:      	b.lo	0x1c50 <filter_8ty_range+0x230>
    1be4:      	ldr	w11, [x0, #0x18]
    1be8:      	cmp	w11, w10
    1bec:      	b.hi	0x1bfc <filter_8ty_range+0x1dc>
    1bf0:      	ldr	w11, [x0, #0x1c]
    1bf4:      	cmp	w11, w10
    1bf8:      	b.hs	0x1b64 <filter_8ty_range+0x144>
    1bfc:      	cmp	w9, #0x19
    1c00:      	b.lo	0x1c50 <filter_8ty_range+0x230>
    1c04:      	ldr	w11, [x0, #0x20]
    1c08:      	cmp	w11, w10
    1c0c:      	b.hi	0x1c1c <filter_8ty_range+0x1fc>
    1c10:      	ldr	w11, [x0, #0x24]
    1c14:      	cmp	w11, w10
    1c18:      	b.hs	0x1b64 <filter_8ty_range+0x144>
    1c1c:      	cmp	w9, #0x21
    1c20:      	b.lo	0x1c50 <filter_8ty_range+0x230>
    1c24:      	ldr	w11, [x0, #0x28]
    1c28:      	mov	w9, wzr
    1c2c:      	cmp	w11, w10
    1c30:      	b.hi	0x1c40 <filter_8ty_range+0x220>
    1c34:      	ldr	w11, [x0, #0x2c]
    1c38:      	cmp	w11, w10
    1c3c:      	b.hs	0x1b64 <filter_8ty_range+0x144>
    1c40:      	cmp	w8, #0x20
    1c44:      	eor	w8, w9, #0x1
    1c48:      	csel	w0, wzr, w8, ne
    1c4c:      	ret
    1c50:      	mov	w9, wzr
    1c54:      	cmp	w8, #0x20
    1c58:      	eor	w8, w9, #0x1
    1c5c:      	csel	w0, wzr, w8, ne
    1c60:      	ret
    1c64:      	nop
    1c68:      	nop
    1c6c:      	nop

0000000000001c70 <filter_file_buf>:
    1c70:      	stp	x30, x19, [sp, #-0x10]!
    1c74:      	ldr	w2, [x1]
    1c78:      	ldr	w8, [x0, #0x4]
    1c7c:      	mov	x19, x0
    1c80:      	cbnz	w2, 0x1c9c <filter_file_buf+0x2c>
    1c84:      	and	w9, w8, #0xfffffffe
    1c88:      	cmp	w9, #0x24
    1c8c:      	b.eq	0x1c9c <filter_file_buf+0x2c>
    1c90:      	mov	x0, xzr
    1c94:      	ldp	x30, x19, [sp], #0x10
    1c98:      	ret
    1c9c:      	cmp	w8, #0x25
    1ca0:      	b.hi	0x1cfc <filter_file_buf+0x8c>
    1ca4:      	mov	w9, #0x1                // =1
    1ca8:      	mov	w10, #0x100             // =256
    1cac:      	lsl	x9, x9, x8
    1cb0:      	movk	w10, #0x400, lsl #16
    1cb4:      	tst	x9, x10
    1cb8:      	b.ne	0x1d40 <filter_file_buf+0xd0>
    1cbc:      	mov	w9, #0x1                // =1
    1cc0:      	mov	w10, #0x200             // =512
    1cc4:      	lsl	x9, x9, x8
    1cc8:      	movk	w10, #0x800, lsl #16
    1ccc:      	tst	x9, x10
    1cd0:      	b.ne	0x1d24 <filter_file_buf+0xb4>
    1cd4:      	mov	w9, #0x1                // =1
    1cd8:      	lsl	x9, x9, x8
    1cdc:      	tst	x9, #0x3000000000
    1ce0:      	b.eq	0x1cfc <filter_file_buf+0x8c>
    1ce4:      	mov	x0, x19
    1ce8:      	bl	0x2950 <filter_file_type>
    1cec:      	ldr	w8, [x19, #0x4]
    1cf0:      	cmp	w8, #0x25
    1cf4:      	b.ls	0x1d68 <filter_file_buf+0xf8>
    1cf8:      	b	0x1d8c <filter_file_buf+0x11c>
    1cfc:      	sub	w9, w8, #0x3
    1d00:      	cmp	w9, #0x2
    1d04:      	b.hs	0x1d5c <filter_file_buf+0xec>
    1d08:      	add	x1, x1, #0x4
    1d0c:      	mov	x0, x19
    1d10:      	bl	0x2380 <filter_char_buf_equal>
    1d14:      	ldr	w8, [x19, #0x4]
    1d18:      	cmp	w8, #0x25
    1d1c:      	b.ls	0x1d68 <filter_file_buf+0xf8>
    1d20:      	b	0x1d8c <filter_file_buf+0x11c>
    1d24:      	ldr	w0, [x19, #0x10]
    1d28:      	add	x1, x1, #0x4
    1d2c:      	bl	0x2870 <filter_char_buf_postfix>
    1d30:      	ldr	w8, [x19, #0x4]
    1d34:      	cmp	w8, #0x25
    1d38:      	b.ls	0x1d68 <filter_file_buf+0xf8>
    1d3c:      	b	0x1d8c <filter_file_buf+0x11c>
    1d40:      	ldr	w0, [x19, #0x10]
    1d44:      	add	x1, x1, #0x4
    1d48:      	bl	0x27b0 <filter_char_buf_prefix>
    1d4c:      	ldr	w8, [x19, #0x4]
    1d50:      	cmp	w8, #0x25
    1d54:      	b.ls	0x1d68 <filter_file_buf+0xf8>
    1d58:      	b	0x1d8c <filter_file_buf+0x11c>
    1d5c:      	mov	x0, xzr
    1d60:      	cmp	w8, #0x25
    1d64:      	b.hi	0x1d8c <filter_file_buf+0x11c>
    1d68:      	mov	w8, w8
    1d6c:      	mov	w9, #0x1                // =1
    1d70:      	lsl	x8, x9, x8
    1d74:      	mov	x9, #0x50               // =80
    1d78:      	movk	x9, #0xc00, lsl #16
    1d7c:      	movk	x9, #0x20, lsl #32
    1d80:      	tst	x8, x9
    1d84:      	b.eq	0x1d8c <filter_file_buf+0x11c>
    1d88:      	eor	x0, x0, #0x1
    1d8c:      	ldp	x30, x19, [sp], #0x10
    1d90:      	ret
    1d94:      	nop
    1d98:      	nop
    1d9c:      	nop

0000000000001da0 <filter_char_buf>:
    1da0:      	stp	x30, x19, [sp, #-0x10]!
    1da4:      	mov	w8, w2
    1da8:      	mov	x19, x0
    1dac:      	add	x9, x1, w2, sxtw
    1db0:      	ldur	w2, [x9, #-0x4]
    1db4:      	add	x1, x1, w8, uxtw
    1db8:      	ldr	w8, [x0, #0x4]
    1dbc:      	mov	x0, xzr
    1dc0:      	cmp	w8, #0x19
    1dc4:      	b.gt	0x1de8 <filter_char_buf+0x48>
    1dc8:      	sub	w9, w8, #0x3
    1dcc:      	cmp	w9, #0x2
    1dd0:      	b.lo	0x1e34 <filter_char_buf+0x94>
    1dd4:      	cmp	w8, #0x8
    1dd8:      	b.eq	0x1e28 <filter_char_buf+0x88>
    1ddc:      	cmp	w8, #0x9
    1de0:      	b.eq	0x1e00 <filter_char_buf+0x60>
    1de4:      	b	0x1e50 <filter_char_buf+0xb0>
    1de8:      	cmp	w8, #0x20
    1dec:      	b.gt	0x1e0c <filter_char_buf+0x6c>
    1df0:      	cmp	w8, #0x1a
    1df4:      	b.eq	0x1e28 <filter_char_buf+0x88>
    1df8:      	cmp	w8, #0x1b
    1dfc:      	b.ne	0x1e50 <filter_char_buf+0xb0>
    1e00:      	ldr	w0, [x19, #0x10]
    1e04:      	bl	0x2870 <filter_char_buf_postfix>
    1e08:      	b	0x1e4c <filter_char_buf+0xac>
    1e0c:      	cmp	w8, #0x21
    1e10:      	b.eq	0x1e40 <filter_char_buf+0xa0>
    1e14:      	cmp	w8, #0x22
    1e18:      	b.ne	0x1e50 <filter_char_buf+0xb0>
    1e1c:      	mov	x0, x19
    1e20:      	mov	w3, #0x1                // =1
    1e24:      	b	0x1e48 <filter_char_buf+0xa8>
    1e28:      	ldr	w0, [x19, #0x10]
    1e2c:      	bl	0x27b0 <filter_char_buf_prefix>
    1e30:      	b	0x1e4c <filter_char_buf+0xac>
    1e34:      	mov	x0, x19
    1e38:      	bl	0x2380 <filter_char_buf_equal>
    1e3c:      	b	0x1e4c <filter_char_buf+0xac>
    1e40:      	mov	x0, x19
    1e44:      	mov	w3, wzr
    1e48:      	bl	0x2a50 <filter_char_substring>
    1e4c:      	ldr	w8, [x19, #0x4]
    1e50:      	cmp	w8, #0x25
    1e54:      	b.hi	0x1e80 <filter_char_buf+0xe0>
    1e58:      	mov	w8, w8
    1e5c:      	mov	w9, #0x1                // =1
    1e60:      	lsl	x8, x9, x8
    1e64:      	mov	x9, #0x50               // =80
    1e68:      	movk	x9, #0xc00, lsl #16
    1e6c:      	movk	x9, #0x20, lsl #32
    1e70:      	tst	x8, x9
    1e74:      	b.eq	0x1e80 <filter_char_buf+0xe0>
    1e78:      	cmp	x0, #0x0
    1e7c:      	cset	w0, eq
    1e80:      	ldp	x30, x19, [sp], #0x10
    1e84:      	ret
    1e88:      	nop
    1e8c:      	nop

0000000000001e90 <filter_inet>:
    1e90:      	sub	sp, sp, #0x80
    1e94:      	str	x30, [sp, #0x50]
    1e98:      	stp	x22, x21, [sp, #0x60]
    1e9c:      	stp	x20, x19, [sp, #0x70]
    1ea0:      	ldr	w10, [x0, #0xc]
    1ea4:      	mov	x8, xzr
    1ea8:      	stp	xzr, xzr, [sp, #0x28]
    1eac:      	cmp	w10, #0x27
    1eb0:      	str	xzr, [sp, #0x10]
    1eb4:      	stp	xzr, xzr, [sp, #0x18]
    1eb8:      	str	wzr, [sp, #0x58]
    1ebc:      	str	wzr, [sp, #0xc]
    1ec0:      	b.gt	0x1f0c <filter_inet+0x7c>
    1ec4:      	cmp	w10, #0x5
    1ec8:      	b.eq	0x1f40 <filter_inet+0xb0>
    1ecc:      	cmp	w10, #0x7
    1ed0:      	mov	x11, x1
    1ed4:      	b.ne	0x2114 <filter_inet+0x284>
    1ed8:      	ldr	w9, [x0, #0x4]
    1edc:      	mov	x8, xzr
    1ee0:      	cmp	w9, #0x13
    1ee4:      	b.le	0x1f88 <filter_inet+0xf8>
    1ee8:      	cmp	w9, #0x17
    1eec:      	b.gt	0x1f24 <filter_inet+0x94>
    1ef0:      	sub	w10, w9, #0x14
    1ef4:      	cmp	w10, #0x2
    1ef8:      	b.lo	0x1fe4 <filter_inet+0x154>
    1efc:      	sub	w10, w9, #0x16
    1f00:      	cmp	w10, #0x2
    1f04:      	b.lo	0x1fdc <filter_inet+0x14c>
    1f08:      	b	0x2114 <filter_inet+0x284>
    1f0c:      	cmp	w10, #0x28
    1f10:      	b.eq	0x1f58 <filter_inet+0xc8>
    1f14:      	cmp	w10, #0x29
    1f18:      	mov	x11, x1
    1f1c:      	b.eq	0x1ed8 <filter_inet+0x48>
    1f20:      	b	0x2114 <filter_inet+0x284>
    1f24:      	cmp	w9, #0x1b
    1f28:      	b.gt	0x2028 <filter_inet+0x198>
    1f2c:      	cmp	w9, #0x18
    1f30:      	b.eq	0x20e4 <filter_inet+0x254>
    1f34:      	cmp	w9, #0x19
    1f38:      	b.eq	0x2048 <filter_inet+0x1b8>
    1f3c:      	b	0x2114 <filter_inet+0x284>
    1f40:      	mov	x11, xzr
    1f44:      	ldr	w9, [x0, #0x4]
    1f48:      	mov	x8, xzr
    1f4c:      	cmp	w9, #0x13
    1f50:      	b.gt	0x1ee8 <filter_inet+0x58>
    1f54:      	b	0x1f88 <filter_inet+0xf8>
    1f58:      	ldrh	w8, [x1]
    1f5c:      	ldrh	w9, [x1, #0x2]
    1f60:      	mov	x11, xzr
    1f64:      	strh	w8, [sp, #0x36]
    1f68:      	strh	w9, [sp, #0x30]
    1f6c:      	ldp	x8, x9, [x1, #0x8]
    1f70:      	add	x1, sp, #0x10
    1f74:      	stp	x8, x9, [sp, #0x10]
    1f78:      	ldr	w9, [x0, #0x4]
    1f7c:      	mov	x8, xzr
    1f80:      	cmp	w9, #0x13
    1f84:      	b.gt	0x1ee8 <filter_inet+0x58>
    1f88:      	cmp	w9, #0xf
    1f8c:      	b.le	0x1fb0 <filter_inet+0x120>
    1f90:      	cmp	w9, #0x11
    1f94:      	b.gt	0x1fcc <filter_inet+0x13c>
    1f98:      	cmp	w9, #0x10
    1f9c:      	b.eq	0x1fdc <filter_inet+0x14c>
    1fa0:      	cmp	w9, #0x11
    1fa4:      	b.ne	0x2114 <filter_inet+0x284>
    1fa8:      	ldrh	w8, [x1, #0x24]
    1fac:      	b	0x21fc <filter_inet+0x36c>
    1fb0:      	cmp	w9, #0xd
    1fb4:      	b.eq	0x20e4 <filter_inet+0x254>
    1fb8:      	cmp	w9, #0xe
    1fbc:      	b.eq	0x2048 <filter_inet+0x1b8>
    1fc0:      	cmp	w9, #0xf
    1fc4:      	b.eq	0x1fe4 <filter_inet+0x154>
    1fc8:      	b	0x2114 <filter_inet+0x284>
    1fcc:      	cmp	w9, #0x12
    1fd0:      	b.eq	0x1fe4 <filter_inet+0x154>
    1fd4:      	cmp	w9, #0x13
    1fd8:      	b.ne	0x2114 <filter_inet+0x284>
    1fdc:      	ldrh	w10, [x1, #0x22]
    1fe0:      	b	0x1fe8 <filter_inet+0x158>
    1fe4:      	ldrh	w10, [x1, #0x20]
    1fe8:      	mov	w19, wzr
    1fec:      	mov	w20, wzr
    1ff0:      	mov	x21, xzr
    1ff4:      	str	w10, [sp, #0xc]
    1ff8:      	mov	x8, xzr
    1ffc:      	cmp	w9, #0x11
    2000:      	b.gt	0x2060 <filter_inet+0x1d0>
    2004:      	sub	w10, w9, #0xd
    2008:      	cmp	w10, #0x2
    200c:      	b.lo	0x2098 <filter_inet+0x208>
    2010:      	sub	w10, w9, #0xf
    2014:      	cmp	w10, #0x2
    2018:      	b.lo	0x210c <filter_inet+0x27c>
    201c:      	cmp	w9, #0x11
    2020:      	b.eq	0x2200 <filter_inet+0x370>
    2024:      	b	0x2114 <filter_inet+0x284>
    2028:      	cmp	w9, #0x1c
    202c:      	b.eq	0x21f8 <filter_inet+0x368>
    2030:      	cmp	w9, #0x1d
    2034:      	b.ne	0x2114 <filter_inet+0x284>
    2038:      	cmp	w10, #0x7
    203c:      	b.ne	0x2250 <filter_inet+0x3c0>
    2040:      	cbnz	x11, 0x225c <filter_inet+0x3cc>
    2044:      	b	0x2200 <filter_inet+0x370>
    2048:      	ldp	w19, w20, [x1, #0x10]
    204c:      	ldr	x21, [x1, #0x18]
    2050:      	mov	w10, wzr
    2054:      	mov	x8, xzr
    2058:      	cmp	w9, #0x11
    205c:      	b.le	0x2004 <filter_inet+0x174>
    2060:      	cmp	w9, #0x19
    2064:      	b.hi	0x2100 <filter_inet+0x270>
    2068:      	mov	w11, #0x1               // =1
    206c:      	mov	w12, #0x500000          // =5242880
    2070:      	lsl	w11, w11, w9
    2074:      	tst	w11, w12
    2078:      	b.ne	0x212c <filter_inet+0x29c>
    207c:      	mov	w12, #0xa00000          // =10485760
    2080:      	tst	w11, w12
    2084:      	b.ne	0x214c <filter_inet+0x2bc>
    2088:      	mov	w10, #0x1               // =1
    208c:      	lsl	w10, w10, w9
    2090:      	tst	w10, #0x3000000
    2094:      	b.eq	0x2100 <filter_inet+0x270>
    2098:      	ldrh	w8, [x1, #0x26]
    209c:      	cmp	w8, #0xa
    20a0:      	b.eq	0x216c <filter_inet+0x2dc>
    20a4:      	cmp	w8, #0x2
    20a8:      	b.ne	0x21dc <filter_inet+0x34c>
    20ac:      	ldr	w8, [x0, #0x10]
    20b0:      	mov	x22, x0
    20b4:      	adrp	x0, 0x2000 <filter_inet+0x170>
    20b8:      	add	x9, sp, #0x5c
    20bc:      	str	w8, [sp, #0x5c]
    20c0:      	mov	w8, #0x1                // =1
    20c4:      	add	x1, sp, #0x5c
    20c8:      	ldr	x0, [x0]
    20cc:      	blr	x8
    20d0:      	cbz	x0, 0x221c <filter_inet+0x38c>
    20d4:      	mov	w8, #0x20               // =32
    20d8:      	add	x1, sp, #0x3c
    20dc:      	stp	w8, w19, [sp, #0x3c]
    20e0:      	b	0x21ac <filter_inet+0x31c>
    20e4:      	ldp	w19, w20, [x1]
    20e8:      	ldr	x21, [x1, #0x8]
    20ec:      	mov	w10, wzr
    20f0:      	mov	x8, xzr
    20f4:      	cmp	w9, #0x11
    20f8:      	b.le	0x2004 <filter_inet+0x174>
    20fc:      	b	0x2060 <filter_inet+0x1d0>
    2100:      	sub	w9, w9, #0x12
    2104:      	cmp	w9, #0x2
    2108:      	b.hs	0x2114 <filter_inet+0x284>
    210c:      	add	x1, sp, #0xc
    2110:      	b	0x2204 <filter_inet+0x374>
    2114:      	ldp	x20, x19, [sp, #0x70]
    2118:      	mov	x0, x8
    211c:      	ldr	x30, [sp, #0x50]
    2120:      	ldp	x22, x21, [sp, #0x60]
    2124:      	add	sp, sp, #0x80
    2128:      	ret
    212c:      	cmp	w10, #0x400
    2130:      	cset	w8, lo
    2134:      	ldp	x20, x19, [sp, #0x70]
    2138:      	mov	x0, x8
    213c:      	ldr	x30, [sp, #0x50]
    2140:      	ldp	x22, x21, [sp, #0x60]
    2144:      	add	sp, sp, #0x80
    2148:      	ret
    214c:      	cmp	w10, #0x3ff
    2150:      	cset	w8, hi
    2154:      	ldp	x20, x19, [sp, #0x70]
    2158:      	mov	x0, x8
    215c:      	ldr	x30, [sp, #0x50]
    2160:      	ldp	x22, x21, [sp, #0x60]
    2164:      	add	sp, sp, #0x80
    2168:      	ret
    216c:      	ldr	w8, [x0, #0x14]
    2170:      	mov	x22, x0
    2174:      	adrp	x0, 0x2000 <filter_inet+0x170>
    2178:      	add	x9, sp, #0x5c
    217c:      	str	w8, [sp, #0x5c]
    2180:      	mov	w8, #0x1                // =1
    2184:      	add	x1, sp, #0x5c
    2188:      	ldr	x0, [x0]
    218c:      	blr	x8
    2190:      	cbz	x0, 0x221c <filter_inet+0x38c>
    2194:      	mov	w8, #0x80               // =128
    2198:      	add	x1, sp, #0x3c
    219c:      	stp	w20, w21, [sp, #0x44]
    21a0:      	stp	w8, w19, [sp, #0x3c]
    21a4:      	lsr	x8, x21, #32
    21a8:      	str	w8, [sp, #0x4c]
    21ac:      	mov	w8, #0x1                // =1
    21b0:      	blr	x8
    21b4:      	ldr	w8, [x22, #0x4]
    21b8:      	sub	w9, w8, #0x18
    21bc:      	cmp	w9, #0x2
    21c0:      	b.lo	0x222c <filter_inet+0x39c>
    21c4:      	sub	w8, w8, #0xd
    21c8:      	cmp	w8, #0x1
    21cc:      	b.hi	0x21dc <filter_inet+0x34c>
    21d0:      	cmp	x0, #0x0
    21d4:      	cset	w8, ne
    21d8:      	b	0x2234 <filter_inet+0x3a4>
    21dc:      	mov	w8, wzr
    21e0:      	ldp	x20, x19, [sp, #0x70]
    21e4:      	mov	x0, x8
    21e8:      	ldr	x30, [sp, #0x50]
    21ec:      	ldp	x22, x21, [sp, #0x60]
    21f0:      	add	sp, sp, #0x80
    21f4:      	ret
    21f8:      	ldrh	w8, [x1, #0x26]
    21fc:      	str	w8, [sp, #0x58]
    2200:      	add	x1, sp, #0x58
    2204:      	bl	0xc80 <filter_32ty_map>
    2208:      	ldp	x20, x19, [sp, #0x70]
    220c:      	ldr	x30, [sp, #0x50]
    2210:      	ldp	x22, x21, [sp, #0x60]
    2214:      	add	sp, sp, #0x80
    2218:      	ret
    221c:      	ldr	w8, [x22, #0x4]
    2220:      	and	w8, w8, #0xfffffffe
    2224:      	cmp	w8, #0x18
    2228:      	b	0x2230 <filter_inet+0x3a0>
    222c:      	cmp	x0, #0x0
    2230:      	cset	w8, eq
    2234:      	mov	w8, w8
    2238:      	ldp	x20, x19, [sp, #0x70]
    223c:      	mov	x0, x8
    2240:      	ldr	x30, [sp, #0x50]
    2244:      	ldp	x22, x21, [sp, #0x60]
    2248:      	add	sp, sp, #0x80
    224c:      	ret
    2250:      	cmp	w10, #0x29
    2254:      	b.ne	0x2264 <filter_inet+0x3d4>
    2258:      	cbz	x11, 0x2264 <filter_inet+0x3d4>
    225c:      	ldrb	w8, [x11, #0x3a]
    2260:      	str	w8, [sp, #0x58]
    2264:      	cmp	w10, #0x29
    2268:      	b.eq	0x2200 <filter_inet+0x370>
    226c:      	cmp	w10, #0x7
    2270:      	b.eq	0x2200 <filter_inet+0x370>
    2274:      	mov	x8, xzr
    2278:      	ldp	x20, x19, [sp, #0x70]
    227c:      	mov	x0, x8
    2280:      	ldr	x30, [sp, #0x50]
    2284:      	ldp	x22, x21, [sp, #0x60]
    2288:      	add	sp, sp, #0x80
    228c:      	ret

0000000000002290 <filter_sockaddr_un>:
    2290:      	sub	sp, sp, #0x20
    2294:      	stp	x30, x19, [sp, #0x10]
    2298:      	mov	x19, x0
    229c:      	ldrb	w2, [x1, #0x3]
    22a0:      	mov	x0, xzr
    22a4:      	ldr	w8, [x19, #0x4]
    22a8:      	cmp	w8, #0x19
    22ac:      	b.gt	0x2300 <filter_sockaddr_un+0x70>
    22b0:      	sub	w9, w8, #0x3
    22b4:      	cmp	w9, #0x2
    22b8:      	b.hs	0x2314 <filter_sockaddr_un+0x84>
    22bc:      	add	x1, x1, #0x4
    22c0:      	mov	x0, x19
    22c4:      	bl	0x2380 <filter_char_buf_equal>
    22c8:      	ldr	w8, [x19, #0x4]
    22cc:      	cmp	w8, #0x25
    22d0:      	b.hi	0x22f4 <filter_sockaddr_un+0x64>
    22d4:      	mov	w9, #0x1                // =1
    22d8:      	lsl	x8, x9, x8
    22dc:      	mov	x9, #0x50               // =80
    22e0:      	movk	x9, #0xc00, lsl #16
    22e4:      	movk	x9, #0x20, lsl #32
    22e8:      	tst	x8, x9
    22ec:      	b.eq	0x22f4 <filter_sockaddr_un+0x64>
    22f0:      	eor	x0, x0, #0x1
    22f4:      	ldp	x30, x19, [sp, #0x10]
    22f8:      	add	sp, sp, #0x20
    22fc:      	ret
    2300:      	cmp	w8, #0x1c
    2304:      	b.eq	0x2360 <filter_sockaddr_un+0xd0>
    2308:      	cmp	w8, #0x1a
    230c:      	b.eq	0x231c <filter_sockaddr_un+0x8c>
    2310:      	b	0x22f4 <filter_sockaddr_un+0x64>
    2314:      	cmp	w8, #0x8
    2318:      	b.ne	0x22f4 <filter_sockaddr_un+0x64>
    231c:      	ldr	w0, [x19, #0x10]
    2320:      	add	x1, x1, #0x4
    2324:      	bl	0x27b0 <filter_char_buf_prefix>
    2328:      	ldr	w8, [x19, #0x4]
    232c:      	cmp	w8, #0x25
    2330:      	b.hi	0x22f4 <filter_sockaddr_un+0x64>
    2334:      	mov	w9, #0x1                // =1
    2338:      	lsl	x8, x9, x8
    233c:      	mov	x9, #0x50               // =80
    2340:      	movk	x9, #0xc00, lsl #16
    2344:      	movk	x9, #0x20, lsl #32
    2348:      	tst	x8, x9
    234c:      	b.eq	0x22f4 <filter_sockaddr_un+0x64>
    2350:      	eor	x0, x0, #0x1
    2354:      	ldp	x30, x19, [sp, #0x10]
    2358:      	add	sp, sp, #0x20
    235c:      	ret
    2360:      	ldrh	w8, [x1]
    2364:      	add	x1, sp, #0xc
    2368:      	mov	x0, x19
    236c:      	str	w8, [sp, #0xc]
    2370:      	bl	0xc80 <filter_32ty_map>
    2374:      	ldp	x30, x19, [sp, #0x10]
    2378:      	add	sp, sp, #0x20
    237c:      	ret

0000000000002380 <filter_char_buf_equal>:
    2380:      	str	x29, [sp, #-0x50]!
    2384:      	stp	x30, x25, [sp, #0x10]
    2388:      	stp	x24, x23, [sp, #0x20]
    238c:      	stp	x22, x21, [sp, #0x30]
    2390:      	stp	x20, x19, [sp, #0x40]
    2394:      	cmp	w2, #0x1, lsl #12       // =0x1000
    2398:      	str	wzr, [sp, #0x8]
    239c:      	b.ls	0x23bc <filter_char_buf_equal+0x3c>
    23a0:      	mov	x0, xzr
    23a4:      	ldp	x20, x19, [sp, #0x40]
    23a8:      	ldp	x22, x21, [sp, #0x30]
    23ac:      	ldp	x24, x23, [sp, #0x20]
    23b0:      	ldp	x30, x25, [sp, #0x10]
    23b4:      	ldr	x29, [sp], #0x50
    23b8:      	ret
    23bc:      	and	w9, w2, #0xffff
    23c0:      	add	x8, x0, #0x10
    23c4:      	cmp	w9, #0x90
    23c8:      	b.hi	0x2438 <filter_char_buf_equal+0xb8>
    23cc:      	and	w9, w2, #0xff
    23d0:      	mov	w10, #0xab              // =171
    23d4:      	tst	w2, #0xffff
    23d8:      	mul	w9, w9, w10
    23dc:      	mov	w10, #0x18              // =24
    23e0:      	lsr	w9, w9, #12
    23e4:      	msub	w9, w9, w10, w2
    23e8:      	b.eq	0x23f8 <filter_char_buf_equal+0x78>
    23ec:      	tst	w9, #0xff
    23f0:      	mov	w23, w2
    23f4:      	b.eq	0x2410 <filter_char_buf_equal+0x90>
    23f8:      	sub	w9, w2, w9, uxtb
    23fc:      	and	w10, w9, #0xffff
    2400:      	add	w9, w9, #0x18
    2404:      	and	w23, w9, #0xffff
    2408:      	cmp	w10, #0x78
    240c:      	b.hi	0x24ac <filter_char_buf_equal+0x12c>
    2410:      	and	w9, w23, #0xff
    2414:      	mov	w10, #0xab              // =171
    2418:      	mul	w9, w9, w10
    241c:      	lsr	w9, w9, #12
    2420:      	sub	w22, w9, #0x1
    2424:      	and	w9, w22, #0xf
    2428:      	ldr	w24, [x8, w9, uxtw #2]
    242c:      	cmn	w24, #0x1
    2430:      	b.ne	0x2524 <filter_char_buf_equal+0x1a4>
    2434:      	b	0x26cc <filter_char_buf_equal+0x34c>
    2438:      	cmp	w9, #0x101
    243c:      	b.hs	0x247c <filter_char_buf_equal+0xfc>
    2440:      	mov	w23, #0x100             // =256
    2444:      	sub	w9, w23, #0x100
    2448:      	ror	w9, w9, #0x8
    244c:      	cmp	w9, #0x2
    2450:      	b.le	0x24bc <filter_char_buf_equal+0x13c>
    2454:      	cmp	w9, #0x3
    2458:      	b.eq	0x24f8 <filter_char_buf_equal+0x178>
    245c:      	cmp	w9, #0x7
    2460:      	b.ne	0x24e0 <filter_char_buf_equal+0x160>
    2464:      	mov	w22, #0x9               // =9
    2468:      	and	w9, w22, #0xf
    246c:      	ldr	w24, [x8, w9, uxtw #2]
    2470:      	cmn	w24, #0x1
    2474:      	b.ne	0x2524 <filter_char_buf_equal+0x1a4>
    2478:      	b	0x26cc <filter_char_buf_equal+0x34c>
    247c:      	and	w9, w2, #0xffff
    2480:      	cmp	w9, #0x201
    2484:      	b.hs	0x24a0 <filter_char_buf_equal+0x120>
    2488:      	mov	w23, #0x200             // =512
    248c:      	sub	w9, w23, #0x100
    2490:      	ror	w9, w9, #0x8
    2494:      	cmp	w9, #0x2
    2498:      	b.le	0x24bc <filter_char_buf_equal+0x13c>
    249c:      	b	0x2454 <filter_char_buf_equal+0xd4>
    24a0:      	cmp	w9, #0x401
    24a4:      	b.hs	0x2684 <filter_char_buf_equal+0x304>
    24a8:      	mov	w23, #0x400             // =1024
    24ac:      	sub	w9, w23, #0x100
    24b0:      	ror	w9, w9, #0x8
    24b4:      	cmp	w9, #0x2
    24b8:      	b.gt	0x2454 <filter_char_buf_equal+0xd4>
    24bc:      	cbz	w9, 0x2510 <filter_char_buf_equal+0x190>
    24c0:      	cmp	w9, #0x1
    24c4:      	b.ne	0x24e0 <filter_char_buf_equal+0x160>
    24c8:      	mov	w22, #0x7               // =7
    24cc:      	and	w9, w22, #0xf
    24d0:      	ldr	w24, [x8, w9, uxtw #2]
    24d4:      	cmn	w24, #0x1
    24d8:      	b.ne	0x2524 <filter_char_buf_equal+0x1a4>
    24dc:      	b	0x26cc <filter_char_buf_equal+0x34c>
    24e0:      	mov	w22, #0xa               // =10
    24e4:      	and	w9, w22, #0xf
    24e8:      	ldr	w24, [x8, w9, uxtw #2]
    24ec:      	cmn	w24, #0x1
    24f0:      	b.ne	0x2524 <filter_char_buf_equal+0x1a4>
    24f4:      	b	0x26cc <filter_char_buf_equal+0x34c>
    24f8:      	mov	w22, #0x8               // =8
    24fc:      	and	w9, w22, #0xf
    2500:      	ldr	w24, [x8, w9, uxtw #2]
    2504:      	cmn	w24, #0x1
    2508:      	b.ne	0x2524 <filter_char_buf_equal+0x1a4>
    250c:      	b	0x26cc <filter_char_buf_equal+0x34c>
    2510:      	mov	w22, #0x6               // =6
    2514:      	and	w9, w22, #0xf
    2518:      	ldr	w24, [x8, w9, uxtw #2]
    251c:      	cmn	w24, #0x1
    2520:      	b.eq	0x26cc <filter_char_buf_equal+0x34c>
    2524:      	adrp	x0, 0x2000 <filter_inet+0x170>
    2528:      	add	x29, sp, #0x8
    252c:      	mov	w8, #0x1                // =1
    2530:      	ldr	x0, [x0]
    2534:      	mov	x25, x1
    2538:      	add	x1, sp, #0x8
    253c:      	mov	w21, w2
    2540:      	mov	w20, #0x1               // =1
    2544:      	blr	x8
    2548:      	mov	x19, x0
    254c:      	adrp	x0, 0x2000 <filter_inet+0x170>
    2550:      	add	x1, sp, #0x8
    2554:      	ldr	x0, [x0]
    2558:      	blr	x20
    255c:      	mov	x20, x0
    2560:      	mov	x0, xzr
    2564:      	cbz	x19, 0x23a4 <filter_char_buf_equal+0x24>
    2568:      	cbz	x20, 0x23a4 <filter_char_buf_equal+0x24>
    256c:      	mov	x0, x19
    2570:      	cmp	w22, #0x5
    2574:      	b.gt	0x25ac <filter_char_buf_equal+0x22c>
    2578:      	strb	w21, [x0], #0x1
    257c:      	mov	w29, w21
    2580:      	mov	w8, #0x4                // =4
    2584:      	mov	x2, x25
    2588:      	mov	w1, w21
    258c:      	blr	x8
    2590:      	subs	w8, w23, w21
    2594:      	b.ls	0x25e4 <filter_char_buf_equal+0x264>
    2598:      	add	x9, x19, x29
    259c:      	and	w1, w8, #0xfff
    25a0:      	mov	w8, #0x4                // =4
    25a4:      	add	x0, x9, #0x1
    25a8:      	b	0x25dc <filter_char_buf_equal+0x25c>
    25ac:      	strh	w21, [x0], #0x2
    25b0:      	mov	w29, w21
    25b4:      	mov	w8, #0x4                // =4
    25b8:      	mov	x2, x25
    25bc:      	mov	w1, w21
    25c0:      	blr	x8
    25c4:      	subs	w8, w23, w21
    25c8:      	b.ls	0x25e4 <filter_char_buf_equal+0x264>
    25cc:      	add	x9, x19, x29
    25d0:      	and	w1, w8, #0xfff
    25d4:      	mov	w8, #0x4                // =4
    25d8:      	add	x0, x9, #0x2
    25dc:      	mov	x2, x20
    25e0:      	blr	x8
    25e4:      	cmp	w22, #0x4
    25e8:      	str	w24, [sp, #0xc]
    25ec:      	b.le	0x2624 <filter_char_buf_equal+0x2a4>
    25f0:      	cmp	w22, #0x7
    25f4:      	b.gt	0x2658 <filter_char_buf_equal+0x2d8>
    25f8:      	cmp	w22, #0x5
    25fc:      	b.eq	0x274c <filter_char_buf_equal+0x3cc>
    2600:      	cmp	w22, #0x6
    2604:      	b.eq	0x2710 <filter_char_buf_equal+0x390>
    2608:      	cmp	w22, #0x7
    260c:      	b.ne	0x26cc <filter_char_buf_equal+0x34c>
    2610:      	adrp	x0, 0x2000 <filter_inet+0x170>
    2614:      	mov	w8, #0x1                // =1
    2618:      	add	x9, sp, #0xc
    261c:      	ldr	x0, [x0]
    2620:      	b	0x2770 <filter_char_buf_equal+0x3f0>
    2624:      	cmp	w22, #0x1
    2628:      	b.le	0x26ac <filter_char_buf_equal+0x32c>
    262c:      	cmp	w22, #0x2
    2630:      	b.eq	0x2738 <filter_char_buf_equal+0x3b8>
    2634:      	cmp	w22, #0x3
    2638:      	b.eq	0x26fc <filter_char_buf_equal+0x37c>
    263c:      	cmp	w22, #0x4
    2640:      	b.ne	0x26cc <filter_char_buf_equal+0x34c>
    2644:      	adrp	x0, 0x2000 <filter_inet+0x170>
    2648:      	mov	w8, #0x1                // =1
    264c:      	add	x9, sp, #0xc
    2650:      	ldr	x0, [x0]
    2654:      	b	0x2770 <filter_char_buf_equal+0x3f0>
    2658:      	cmp	w22, #0x8
    265c:      	b.eq	0x2760 <filter_char_buf_equal+0x3e0>
    2660:      	cmp	w22, #0x9
    2664:      	b.eq	0x2724 <filter_char_buf_equal+0x3a4>
    2668:      	cmp	w22, #0xa
    266c:      	b.ne	0x26cc <filter_char_buf_equal+0x34c>
    2670:      	adrp	x0, 0x2000 <filter_inet+0x170>
    2674:      	mov	w8, #0x1                // =1
    2678:      	add	x9, sp, #0xc
    267c:      	ldr	x0, [x0]
    2680:      	b	0x2770 <filter_char_buf_equal+0x3f0>
    2684:      	and	w9, w2, #0xffff
    2688:      	mov	w10, #0x1000            // =4096
    268c:      	cmp	w9, #0x800
    2690:      	mov	w9, #0x800              // =2048
    2694:      	csel	w23, w10, w9, hi
    2698:      	sub	w9, w23, #0x100
    269c:      	ror	w9, w9, #0x8
    26a0:      	cmp	w9, #0x2
    26a4:      	b.le	0x24bc <filter_char_buf_equal+0x13c>
    26a8:      	b	0x2454 <filter_char_buf_equal+0xd4>
    26ac:      	cbz	w22, 0x26e8 <filter_char_buf_equal+0x368>
    26b0:      	cmp	w22, #0x1
    26b4:      	b.ne	0x26cc <filter_char_buf_equal+0x34c>
    26b8:      	adrp	x0, 0x2000 <filter_inet+0x170>
    26bc:      	mov	w8, #0x1                // =1
    26c0:      	add	x9, sp, #0xc
    26c4:      	ldr	x0, [x0]
    26c8:      	b	0x2770 <filter_char_buf_equal+0x3f0>
    26cc:      	mov	x0, xzr
    26d0:      	ldp	x20, x19, [sp, #0x40]
    26d4:      	ldp	x22, x21, [sp, #0x30]
    26d8:      	ldp	x24, x23, [sp, #0x20]
    26dc:      	ldp	x30, x25, [sp, #0x10]
    26e0:      	ldr	x29, [sp], #0x50
    26e4:      	ret
    26e8:      	adrp	x0, 0x2000 <filter_inet+0x170>
    26ec:      	mov	w8, #0x1                // =1
    26f0:      	add	x9, sp, #0xc
    26f4:      	ldr	x0, [x0]
    26f8:      	b	0x2770 <filter_char_buf_equal+0x3f0>
    26fc:      	adrp	x0, 0x2000 <filter_inet+0x170>
    2700:      	mov	w8, #0x1                // =1
    2704:      	add	x9, sp, #0xc
    2708:      	ldr	x0, [x0]
    270c:      	b	0x2770 <filter_char_buf_equal+0x3f0>
    2710:      	adrp	x0, 0x2000 <filter_inet+0x170>
    2714:      	mov	w8, #0x1                // =1
    2718:      	add	x9, sp, #0xc
    271c:      	ldr	x0, [x0]
    2720:      	b	0x2770 <filter_char_buf_equal+0x3f0>
    2724:      	adrp	x0, 0x2000 <filter_inet+0x170>
    2728:      	mov	w8, #0x1                // =1
    272c:      	add	x9, sp, #0xc
    2730:      	ldr	x0, [x0]
    2734:      	b	0x2770 <filter_char_buf_equal+0x3f0>
    2738:      	adrp	x0, 0x2000 <filter_inet+0x170>
    273c:      	mov	w8, #0x1                // =1
    2740:      	add	x9, sp, #0xc
    2744:      	ldr	x0, [x0]
    2748:      	b	0x2770 <filter_char_buf_equal+0x3f0>
    274c:      	adrp	x0, 0x2000 <filter_inet+0x170>
    2750:      	mov	w8, #0x1                // =1
    2754:      	add	x9, sp, #0xc
    2758:      	ldr	x0, [x0]
    275c:      	b	0x2770 <filter_char_buf_equal+0x3f0>
    2760:      	adrp	x0, 0x2000 <filter_inet+0x170>
    2764:      	mov	w8, #0x1                // =1
    2768:      	add	x9, sp, #0xc
    276c:      	ldr	x0, [x0]
    2770:      	add	x1, sp, #0xc
    2774:      	blr	x8
    2778:      	cbz	x0, 0x23a4 <filter_char_buf_equal+0x24>
    277c:      	mov	w8, #0x1                // =1
    2780:      	mov	x1, x19
    2784:      	blr	x8
    2788:      	cmp	x0, #0x0
    278c:      	cset	w0, ne
    2790:      	ldp	x20, x19, [sp, #0x40]
    2794:      	ldp	x22, x21, [sp, #0x30]
    2798:      	ldp	x24, x23, [sp, #0x20]
    279c:      	ldp	x30, x25, [sp, #0x10]
    27a0:      	ldr	x29, [sp], #0x50
    27a4:      	ret
    27a8:      	nop
    27ac:      	nop

00000000000027b0 <filter_char_buf_prefix>:
    27b0:      	sub	sp, sp, #0x30
    27b4:      	stp	x30, x21, [sp, #0x10]
    27b8:      	stp	x20, x19, [sp, #0x20]
    27bc:      	stp	wzr, w0, [sp, #0x8]
    27c0:      	adrp	x0, 0x2000 <filter_inet+0x170>
    27c4:      	mov	w8, #0x1                // =1
    27c8:      	add	x9, sp, #0xc
    27cc:      	ldr	x0, [x0]
    27d0:      	mov	x19, x1
    27d4:      	add	x1, sp, #0xc
    27d8:      	mov	w20, w2
    27dc:      	blr	x8
    27e0:      	mov	x8, x0
    27e4:      	mov	x0, xzr
    27e8:      	cbz	w20, 0x2854 <filter_char_buf_prefix+0xa4>
    27ec:      	cbz	x8, 0x2854 <filter_char_buf_prefix+0xa4>
    27f0:      	adrp	x0, 0x2000 <filter_inet+0x170>
    27f4:      	mov	x21, x8
    27f8:      	mov	w8, #0x1                // =1
    27fc:      	ldr	x0, [x0]
    2800:      	add	x9, sp, #0x8
    2804:      	add	x1, sp, #0x8
    2808:      	blr	x8
    280c:      	cbz	x0, 0x2854 <filter_char_buf_prefix+0xa4>
    2810:      	cmp	w20, #0xff
    2814:      	mov	w8, #0xff               // =255
    2818:      	mov	x2, x19
    281c:      	csel	w1, w20, w8, lo
    2820:      	mov	x8, x0
    2824:      	mov	x20, x0
    2828:      	lsl	w9, w1, #3
    282c:      	str	w9, [x8], #0x4
    2830:      	mov	w9, #0x4                // =4
    2834:      	mov	x0, x8
    2838:      	blr	x9
    283c:      	mov	w8, #0x1                // =1
    2840:      	mov	x0, x21
    2844:      	mov	x1, x20
    2848:      	blr	x8
    284c:      	cmp	x0, #0x0
    2850:      	cset	w0, ne
    2854:      	ldp	x20, x19, [sp, #0x20]
    2858:      	ldp	x30, x21, [sp, #0x10]
    285c:      	add	sp, sp, #0x30
    2860:      	ret
    2864:      	nop
    2868:      	nop
    286c:      	nop

0000000000002870 <filter_char_buf_postfix>:
    2870:      	sub	sp, sp, #0x30
    2874:      	stp	x30, x21, [sp, #0x10]
    2878:      	stp	x20, x19, [sp, #0x20]
    287c:      	stp	wzr, w0, [sp, #0x8]
    2880:      	adrp	x0, 0x2000 <filter_inet+0x170>
    2884:      	mov	w8, #0x1                // =1
    2888:      	add	x9, sp, #0xc
    288c:      	ldr	x0, [x0]
    2890:      	mov	x19, x1
    2894:      	add	x1, sp, #0xc
    2898:      	mov	w20, w2
    289c:      	blr	x8
    28a0:      	mov	x8, x0
    28a4:      	mov	x0, xzr
    28a8:      	cbz	w20, 0x293c <filter_char_buf_postfix+0xcc>
    28ac:      	cbz	x8, 0x293c <filter_char_buf_postfix+0xcc>
    28b0:      	adrp	x0, 0x2000 <filter_inet+0x170>
    28b4:      	mov	x21, x8
    28b8:      	mov	w8, #0x1                // =1
    28bc:      	ldr	x0, [x0]
    28c0:      	add	x9, sp, #0x8
    28c4:      	add	x1, sp, #0x8
    28c8:      	blr	x8
    28cc:      	cbz	x0, 0x293c <filter_char_buf_postfix+0xcc>
    28d0:      	cmp	w20, #0x7f
    28d4:      	mov	w9, #0x7f               // =127
    28d8:      	mov	x1, x0
    28dc:      	mov	x8, xzr
    28e0:      	sub	w10, w20, #0x1
    28e4:      	csel	w9, w20, w9, lo
    28e8:      	lsl	w9, w9, #3
    28ec:      	str	w9, [x0]
    28f0:      	mov	w9, w20
    28f4:      	nop
    28f8:      	nop
    28fc:      	nop
    2900:      	cmp	x8, #0x7f
    2904:      	b.eq	0x2928 <filter_char_buf_postfix+0xb8>
    2908:      	and	x11, x10, #0xfff
    290c:      	add	x12, x1, x8
    2910:      	add	x8, x8, #0x1
    2914:      	ldrb	w11, [x19, x11]
    2918:      	sub	w10, w10, #0x1
    291c:      	cmp	x9, x8
    2920:      	strb	w11, [x12, #0x4]
    2924:      	b.ne	0x2900 <filter_char_buf_postfix+0x90>
    2928:      	mov	w8, #0x1                // =1
    292c:      	mov	x0, x21
    2930:      	blr	x8
    2934:      	cmp	x0, #0x0
    2938:      	cset	w0, ne
    293c:      	ldp	x20, x19, [sp, #0x20]
    2940:      	ldp	x30, x21, [sp, #0x10]
    2944:      	add	sp, sp, #0x30
    2948:      	ret
    294c:      	nop

0000000000002950 <filter_file_type>:
    2950:      	sub	sp, sp, #0x20
    2954:      	stp	x30, x19, [sp, #0x10]
    2958:      	ldr	w8, [x1]
    295c:      	strh	wzr, [sp, #0xc]
    2960:      	cmp	w8, #0x1, lsl #12       // =0x1000
    2964:      	b.hi	0x2a3c <filter_file_type+0xec>
    2968:      	add	x9, x1, #0x4
    296c:      	mov	w10, #0x2               // =2
    2970:      	mov	w11, #0x4               // =4
    2974:      	add	x12, sp, #0xc
    2978:      	mov	x19, x0
    297c:      	add	x0, sp, #0xc
    2980:      	add	x8, x9, x8
    2984:      	add	x8, x8, #0x4
    2988:      	ldr	w8, [x1]
    298c:      	mov	w1, #0x2                // =2
    2990:      	add	x8, x9, x8
    2994:      	add	x2, x8, #0x4
    2998:      	blr	x11
    299c:      	ldr	w9, [x19, #0x10]
    29a0:      	cbz	w9, 0x2a3c <filter_file_type+0xec>
    29a4:      	ldrh	w8, [sp, #0xc]
    29a8:      	and	w8, w8, #0xf000
    29ac:      	cmp	w9, w8
    29b0:      	b.ne	0x29c4 <filter_file_type+0x74>
    29b4:      	mov	w0, #0x1                // =1
    29b8:      	ldp	x30, x19, [sp, #0x10]
    29bc:      	add	sp, sp, #0x20
    29c0:      	ret
    29c4:      	ldr	w9, [x19, #0x8]
    29c8:      	cmp	w9, #0xc
    29cc:      	b.ls	0x2a3c <filter_file_type+0xec>
    29d0:      	ldr	w10, [x19, #0x14]
    29d4:      	cbz	w10, 0x2a3c <filter_file_type+0xec>
    29d8:      	cmp	w10, w8
    29dc:      	b.ne	0x29f0 <filter_file_type+0xa0>
    29e0:      	mov	w0, #0x1                // =1
    29e4:      	ldp	x30, x19, [sp, #0x10]
    29e8:      	add	sp, sp, #0x20
    29ec:      	ret
    29f0:      	cmp	w9, #0x11
    29f4:      	b.lo	0x2a3c <filter_file_type+0xec>
    29f8:      	ldr	w10, [x19, #0x18]
    29fc:      	cbz	w10, 0x2a3c <filter_file_type+0xec>
    2a00:      	cmp	w10, w8
    2a04:      	b.ne	0x2a18 <filter_file_type+0xc8>
    2a08:      	mov	w0, #0x1                // =1
    2a0c:      	ldp	x30, x19, [sp, #0x10]
    2a10:      	add	sp, sp, #0x20
    2a14:      	ret
    2a18:      	cmp	w9, #0x15
    2a1c:      	b.lo	0x2a3c <filter_file_type+0xec>
    2a20:      	ldr	w9, [x19, #0x1c]
    2a24:      	cbz	w9, 0x2a3c <filter_file_type+0xec>
    2a28:      	cmp	w9, w8
    2a2c:      	cset	w0, eq
    2a30:      	ldp	x30, x19, [sp, #0x10]
    2a34:      	add	sp, sp, #0x20
    2a38:      	ret
    2a3c:      	mov	x0, xzr
    2a40:      	ldp	x30, x19, [sp, #0x10]
    2a44:      	add	sp, sp, #0x20
    2a48:      	ret
    2a4c:      	nop

0000000000002a50 <filter_char_substring>:
    2a50:      	str	x29, [sp, #-0x50]!
    2a54:      	stp	x30, x25, [sp, #0x10]
    2a58:      	stp	x24, x23, [sp, #0x20]
    2a5c:      	stp	x22, x21, [sp, #0x30]
    2a60:      	stp	x20, x19, [sp, #0x40]
    2a64:      	mov	x21, x1
    2a68:      	mov	x19, x0
    2a6c:      	add	x23, x0, #0x10
    2a70:      	mov	w24, w2
    2a74:      	tbz	w3, #0x0, 0x2b68 <filter_char_substring+0x118>
    2a78:      	cbz	w2, 0x2c28 <filter_char_substring+0x1d8>
    2a7c:      	adrp	x22, 0x2000 <filter_inet+0x170>
    2a80:      	mov	x25, xzr
    2a84:      	mov	w29, wzr
    2a88:      	ldr	x22, [x22]
    2a8c:      	add	x20, sp, #0xc
    2a90:      	nop
    2a94:      	nop
    2a98:      	nop
    2a9c:      	nop
    2aa0:      	ldr	w8, [x23, x25, lsl #2]
    2aa4:      	add	x1, sp, #0xc
    2aa8:      	mov	x0, x22
    2aac:      	str	w8, [sp, #0xc]
    2ab0:      	mov	w8, #0x1                // =1
    2ab4:      	blr	x8
    2ab8:      	cbz	x0, 0x2cc8 <filter_char_substring+0x278>
    2abc:      	mov	x8, xzr
    2ac0:      	mov	x9, x21
    2ac4:      	mov	x10, x24
    2ac8:      	b	0x2ae0 <filter_char_substring+0x90>
    2acc:      	add	x8, x8, #0x1
    2ad0:      	sub	x10, x10, #0x1
    2ad4:      	add	x9, x9, #0x1
    2ad8:      	cmp	x8, x24
    2adc:      	b.eq	0x2b44 <filter_char_substring+0xf4>
    2ae0:      	mov	x11, xzr
    2ae4:      	cmp	x10, x11
    2ae8:      	b.eq	0x2acc <filter_char_substring+0x7c>
    2aec:      	ldrb	w12, [x0, x11]
    2af0:      	cbz	w12, 0x2b40 <filter_char_substring+0xf0>
    2af4:      	ldrb	w13, [x9, x11]
    2af8:      	sub	w14, w13, #0x41
    2afc:      	orr	w15, w13, #0x20
    2b00:      	cmp	w14, #0x1a
    2b04:      	sub	w14, w12, #0x41
    2b08:      	csel	w13, w15, w13, lo
    2b0c:      	orr	w15, w12, #0x20
    2b10:      	cmp	w14, #0x1a
    2b14:      	csel	w12, w15, w12, lo
    2b18:      	cmp	x11, #0x62
    2b1c:      	b.hi	0x2acc <filter_char_substring+0x7c>
    2b20:      	add	x11, x11, #0x1
    2b24:      	cmp	w13, w12
    2b28:      	b.eq	0x2ae4 <filter_char_substring+0x94>
    2b2c:      	b	0x2acc <filter_char_substring+0x7c>
    2b30:      	nop
    2b34:      	nop
    2b38:      	nop
    2b3c:      	nop
    2b40:      	tbz	w8, #0x1f, 0x2ce0 <filter_char_substring+0x290>
    2b44:      	ldr	w9, [x19, #0x8]
    2b48:      	add	w8, w29, #0xc
    2b4c:      	cmp	w8, w9
    2b50:      	b.hs	0x2cc4 <filter_char_substring+0x274>
    2b54:      	add	x25, x25, #0x1
    2b58:      	add	w29, w29, #0x4
    2b5c:      	cmp	x25, #0x64
    2b60:      	b.ne	0x2aa0 <filter_char_substring+0x50>
    2b64:      	b	0x2cc4 <filter_char_substring+0x274>
    2b68:      	cbz	w2, 0x2c7c <filter_char_substring+0x22c>
    2b6c:      	adrp	x22, 0x2000 <filter_inet+0x170>
    2b70:      	mov	x25, xzr
    2b74:      	mov	w29, wzr
    2b78:      	ldr	x22, [x22]
    2b7c:      	add	x20, sp, #0xc
    2b80:      	ldr	w8, [x23, x25, lsl #2]
    2b84:      	add	x1, sp, #0xc
    2b88:      	mov	x0, x22
    2b8c:      	str	w8, [sp, #0xc]
    2b90:      	mov	w8, #0x1                // =1
    2b94:      	blr	x8
    2b98:      	cbz	x0, 0x2cc8 <filter_char_substring+0x278>
    2b9c:      	mov	x8, xzr
    2ba0:      	mov	x9, x21
    2ba4:      	mov	x10, x24
    2ba8:      	b	0x2bc0 <filter_char_substring+0x170>
    2bac:      	add	x8, x8, #0x1
    2bb0:      	sub	x10, x10, #0x1
    2bb4:      	add	x9, x9, #0x1
    2bb8:      	cmp	x8, x24
    2bbc:      	b.eq	0x2c04 <filter_char_substring+0x1b4>
    2bc0:      	mov	x11, xzr
    2bc4:      	cmp	x10, x11
    2bc8:      	b.eq	0x2bac <filter_char_substring+0x15c>
    2bcc:      	ldrb	w12, [x0, x11]
    2bd0:      	cbz	w12, 0x2c00 <filter_char_substring+0x1b0>
    2bd4:      	cmp	x11, #0x62
    2bd8:      	b.hi	0x2bac <filter_char_substring+0x15c>
    2bdc:      	ldrb	w13, [x9, x11]
    2be0:      	add	x11, x11, #0x1
    2be4:      	cmp	w13, w12
    2be8:      	b.eq	0x2bc4 <filter_char_substring+0x174>
    2bec:      	b	0x2bac <filter_char_substring+0x15c>
    2bf0:      	nop
    2bf4:      	nop
    2bf8:      	nop
    2bfc:      	nop
    2c00:      	tbz	w8, #0x1f, 0x2ce0 <filter_char_substring+0x290>
    2c04:      	ldr	w9, [x19, #0x8]
    2c08:      	add	w8, w29, #0xc
    2c0c:      	cmp	w8, w9
    2c10:      	b.hs	0x2cc4 <filter_char_substring+0x274>
    2c14:      	add	x25, x25, #0x1
    2c18:      	add	w29, w29, #0x4
    2c1c:      	cmp	x25, #0x64
    2c20:      	b.ne	0x2b80 <filter_char_substring+0x130>
    2c24:      	b	0x2cc4 <filter_char_substring+0x274>
    2c28:      	adrp	x20, 0x2000 <filter_inet+0x170>
    2c2c:      	mov	w21, #0x10              // =16
    2c30:      	add	x22, sp, #0xc
    2c34:      	ldr	x20, [x20]
    2c38:      	nop
    2c3c:      	nop
    2c40:      	ldr	w8, [x19, x21]
    2c44:      	add	x1, sp, #0xc
    2c48:      	mov	x0, x20
    2c4c:      	str	w8, [sp, #0xc]
    2c50:      	mov	w8, #0x1                // =1
    2c54:      	blr	x8
    2c58:      	cbz	x0, 0x2cc8 <filter_char_substring+0x278>
    2c5c:      	ldr	w8, [x19, #0x8]
    2c60:      	add	x21, x21, #0x4
    2c64:      	sub	w9, w21, #0x8
    2c68:      	cmp	w9, w8
    2c6c:      	b.hs	0x2cc4 <filter_char_substring+0x274>
    2c70:      	cmp	x21, #0x1a0
    2c74:      	b.ne	0x2c40 <filter_char_substring+0x1f0>
    2c78:      	b	0x2cc4 <filter_char_substring+0x274>
    2c7c:      	adrp	x20, 0x2000 <filter_inet+0x170>
    2c80:      	mov	w21, #0x10              // =16
    2c84:      	add	x22, sp, #0xc
    2c88:      	ldr	x20, [x20]
    2c8c:      	ldr	w8, [x19, x21]
    2c90:      	add	x1, sp, #0xc
    2c94:      	mov	x0, x20
    2c98:      	str	w8, [sp, #0xc]
    2c9c:      	mov	w8, #0x1                // =1
    2ca0:      	blr	x8
    2ca4:      	cbz	x0, 0x2cc8 <filter_char_substring+0x278>
    2ca8:      	ldr	w8, [x19, #0x8]
    2cac:      	add	x21, x21, #0x4
    2cb0:      	sub	w9, w21, #0x8
    2cb4:      	cmp	w9, w8
    2cb8:      	b.hs	0x2cc4 <filter_char_substring+0x274>
    2cbc:      	cmp	x21, #0x1a0
    2cc0:      	b.ne	0x2c8c <filter_char_substring+0x23c>
    2cc4:      	mov	x0, xzr
    2cc8:      	ldp	x20, x19, [sp, #0x40]
    2ccc:      	ldp	x22, x21, [sp, #0x30]
    2cd0:      	ldp	x24, x23, [sp, #0x20]
    2cd4:      	ldp	x30, x25, [sp, #0x10]
    2cd8:      	ldr	x29, [sp], #0x50
    2cdc:      	ret
    2ce0:      	mov	w0, #0x1                // =1
    2ce4:      	ldp	x20, x19, [sp, #0x40]
    2ce8:      	ldp	x22, x21, [sp, #0x30]
    2cec:      	ldp	x24, x23, [sp, #0x20]
    2cf0:      	ldp	x30, x25, [sp, #0x10]
    2cf4:      	ldr	x29, [sp], #0x50
    2cf8:      	ret
    2cfc:      	nop

0000000000002d00 <do_action>:
    2d00:      	sub	sp, sp, #0xd0
    2d04:      	str	x29, [sp, #0x80]
    2d08:      	stp	x30, x25, [sp, #0x90]
    2d0c:      	stp	x24, x23, [sp, #0xa0]
    2d10:      	stp	x22, x21, [sp, #0xb0]
    2d14:      	stp	x20, x19, [sp, #0xc0]
    2d18:      	add	x8, x2, w1, uxtw #2
    2d1c:      	str	wzr, [sp, #0x44]
    2d20:      	adrp	x24, 0x2000 <filter_inet+0x170>
    2d24:      	add	x9, sp, #0x44
    2d28:      	mov	w20, w1
    2d2c:      	ldrsw	x19, [x8, #0x4]
    2d30:      	ldr	x24, [x24]
    2d34:      	mov	w8, #0x1                // =1
    2d38:      	mov	x22, x0
    2d3c:      	add	x1, sp, #0x44
    2d40:      	mov	w25, w4
    2d44:      	mov	x23, x3
    2d48:      	mov	x21, x2
    2d4c:      	mov	x0, x24
    2d50:      	blr	x8
    2d54:      	cbz	x0, 0x32fc <do_action+0x5fc>
    2d58:      	mov	x29, x0
    2d5c:      	cmp	w19, #0x7
    2d60:      	b.gt	0x2d84 <do_action+0x84>
    2d64:      	cmp	w19, #0x3
    2d68:      	b.gt	0x2dd0 <do_action+0xd0>
    2d6c:      	cmp	w19, #0x1
    2d70:      	b.gt	0x2f00 <do_action+0x200>
    2d74:      	cbz	w19, 0x3108 <do_action+0x408>
    2d78:      	cmp	w19, #0x1
    2d7c:      	b.eq	0x2f10 <do_action+0x210>
    2d80:      	b	0x32f4 <do_action+0x5f4>
    2d84:      	cmp	w19, #0xb
    2d88:      	b.gt	0x2ed4 <do_action+0x1d4>
    2d8c:      	sub	w8, w19, #0xa
    2d90:      	cmp	w8, #0x2
    2d94:      	b.lo	0x3004 <do_action+0x304>
    2d98:      	cmp	w19, #0x8
    2d9c:      	b.eq	0x3050 <do_action+0x350>
    2da0:      	cmp	w19, #0x9
    2da4:      	b.ne	0x32f4 <do_action+0x5f4>
    2da8:      	add	w20, w20, #0x1
    2dac:      	add	x8, x21, w20, uxtw #2
    2db0:      	ldr	w0, [x8, #0x4]
    2db4:      	tbz	w25, #0x0, 0x31b4 <do_action+0x4b4>
    2db8:      	sxtw	x8, w0
    2dbc:      	mov	w9, #0x6d               // =109
    2dc0:      	blr	x9
    2dc4:      	mov	w21, #0x2               // =2
    2dc8:      	mov	w24, w20
    2dcc:      	b	0x32ac <do_action+0x5ac>
    2dd0:      	sub	w8, w19, #0x6
    2dd4:      	cmp	w8, #0x2
    2dd8:      	b.lo	0x303c <do_action+0x33c>
    2ddc:      	cmp	w19, #0x4
    2de0:      	b.eq	0x3058 <do_action+0x358>
    2de4:      	cmp	w19, #0x5
    2de8:      	b.ne	0x32f4 <do_action+0x5f4>
    2dec:      	add	w9, w20, #0x1
    2df0:      	add	x8, x21, #0x4
    2df4:      	add	w20, w20, #0x2
    2df8:      	ldr	w9, [x8, w9, uxtw #2]
    2dfc:      	and	x9, x9, #0x7
    2e00:      	cmp	w9, #0x4
    2e04:      	b.hi	0x32f4 <do_action+0x5f4>
    2e08:      	add	x10, x29, x9, lsl #2
    2e0c:      	mov	w11, #0x5ea0            // =24224
    2e10:      	ldr	w10, [x10, x11]
    2e14:      	cbnz	w10, 0x32f4 <do_action+0x5f4>
    2e18:      	ldr	w22, [x8, w20, uxtw #2]
    2e1c:      	add	x8, x29, x9, lsl #3
    2e20:      	ldr	x8, [x8, #0x5e78]
    2e24:      	str	wzr, [sp, #0x54]
    2e28:      	and	x8, x8, #0x7ff
    2e2c:      	add	x8, x29, x8
    2e30:      	ldr	w8, [x8, #0x90]
    2e34:      	str	w8, [sp, #0x50]
    2e38:      	mov	w8, #0xe                // =14
    2e3c:      	blr	x8
    2e40:      	lsr	x8, x0, #32
    2e44:      	adrp	x21, 0x2000 <filter_inet+0x170>
    2e48:      	add	x9, sp, #0x48
    2e4c:      	str	x8, [sp, #0x48]
    2e50:      	mov	w8, #0x1                // =1
    2e54:      	add	x1, sp, #0x48
    2e58:      	ldr	x21, [x21]
    2e5c:      	mov	x0, x21
    2e60:      	blr	x8
    2e64:      	cbz	x0, 0x32f4 <do_action+0x5f4>
    2e68:      	and	x8, x22, #0x7
    2e6c:      	cmp	w8, #0x4
    2e70:      	b.hi	0x32f4 <do_action+0x5f4>
    2e74:      	add	x9, x29, x8, lsl #2
    2e78:      	mov	w10, #0x5ea0            // =24224
    2e7c:      	ldr	w9, [x9, x10]
    2e80:      	cbnz	w9, 0x32f4 <do_action+0x5f4>
    2e84:      	add	x8, x29, x8, lsl #3
    2e88:      	mov	x22, x0
    2e8c:      	ldr	x8, [x8, #0x5e78]
    2e90:      	str	wzr, [sp, #0x54]
    2e94:      	and	x8, x8, #0x7ff
    2e98:      	add	x8, x29, x8
    2e9c:      	ldr	w8, [x8, #0x90]
    2ea0:      	str	w8, [sp, #0x50]
    2ea4:      	mov	w8, #0xe                // =14
    2ea8:      	blr	x8
    2eac:      	lsr	x8, x0, #32
    2eb0:      	mov	x3, xzr
    2eb4:      	add	x9, sp, #0x48
    2eb8:      	str	x8, [sp, #0x48]
    2ebc:      	mov	w8, #0x2                // =2
    2ec0:      	add	x1, sp, #0x48
    2ec4:      	mov	x0, x21
    2ec8:      	mov	x2, x22
    2ecc:      	blr	x8
    2ed0:      	b	0x32f4 <do_action+0x5f4>
    2ed4:      	cmp	w19, #0xc
    2ed8:      	b.eq	0x31c0 <do_action+0x4c0>
    2edc:      	cmp	w19, #0xd
    2ee0:      	b.eq	0x306c <do_action+0x36c>
    2ee4:      	cmp	w19, #0xe
    2ee8:      	b.ne	0x32f4 <do_action+0x5f4>
    2eec:      	tst	w25, #0x1
    2ef0:      	mov	w8, #0x8                // =8
    2ef4:      	add	w24, w20, #0x2
    2ef8:      	cinc	x21, x8, eq
    2efc:      	b	0x32ac <do_action+0x5ac>
    2f00:      	cmp	w19, #0x2
    2f04:      	b.eq	0x31ac <do_action+0x4ac>
    2f08:      	cmp	w19, #0x3
    2f0c:      	b.ne	0x32f4 <do_action+0x5f4>
    2f10:      	add	w8, w20, #0x1
    2f14:      	add	x9, x21, #0x4
    2f18:      	add	w20, w20, #0x2
    2f1c:      	str	wzr, [sp, #0x68]
    2f20:      	ldr	w22, [x9, w8, uxtw #2]
    2f24:      	adrp	x0, 0x2000 <filter_inet+0x170>
    2f28:      	ldr	w21, [x9, w20, uxtw #2]
    2f2c:      	ldr	x0, [x0]
    2f30:      	mov	w8, #0x1                // =1
    2f34:      	add	x9, sp, #0x68
    2f38:      	add	x1, sp, #0x68
    2f3c:      	blr	x8
    2f40:      	cbz	x0, 0x3030 <do_action+0x330>
    2f44:      	and	x8, x22, #0x7
    2f48:      	cmp	w8, #0x4
    2f4c:      	b.hi	0x302c <do_action+0x32c>
    2f50:      	add	x9, x29, x8, lsl #2
    2f54:      	mov	w10, #0x5ea0            // =24224
    2f58:      	ldr	w9, [x9, x10]
    2f5c:      	cbnz	w9, 0x302c <do_action+0x32c>
    2f60:      	add	x8, x29, x8, lsl #3
    2f64:      	mov	x22, x0
    2f68:      	ldr	x8, [x8, #0x5e78]
    2f6c:      	str	wzr, [sp, #0x54]
    2f70:      	and	x8, x8, #0x7ff
    2f74:      	add	x8, x29, x8
    2f78:      	ldr	w8, [x8, #0x90]
    2f7c:      	str	w8, [sp, #0x50]
    2f80:      	mov	w8, #0xe                // =14
    2f84:      	blr	x8
    2f88:      	lsr	x8, x0, #32
    2f8c:      	cmp	w19, #0x1
    2f90:      	str	x8, [sp, #0x48]
    2f94:      	b.ne	0x3494 <do_action+0x794>
    2f98:      	and	x8, x21, #0x7
    2f9c:      	cmp	w8, #0x4
    2fa0:      	b.hi	0x302c <do_action+0x32c>
    2fa4:      	add	x9, x29, x8, lsl #2
    2fa8:      	mov	w10, #0x5ea0            // =24224
    2fac:      	ldr	w9, [x9, x10]
    2fb0:      	cbnz	w9, 0x302c <do_action+0x32c>
    2fb4:      	add	x8, x29, x8, lsl #3
    2fb8:      	mov	x0, x22
    2fbc:      	mov	x21, x22
    2fc0:      	ldr	x8, [x8, #0x5e78]
    2fc4:      	and	x8, x8, #0x7ff
    2fc8:      	add	x2, x29, x8
    2fcc:      	ldr	w8, [x2, #0x90]!
    2fd0:      	and	x8, x8, #0xfff
    2fd4:      	add	x1, x8, #0x8
    2fd8:      	mov	w8, #0x4                // =4
    2fdc:      	blr	x8
    2fe0:      	adrp	x0, 0x2000 <filter_inet+0x170>
    2fe4:      	mov	x3, xzr
    2fe8:      	mov	w8, #0x2                // =2
    2fec:      	ldr	x0, [x0]
    2ff0:      	add	x9, sp, #0x48
    2ff4:      	add	x1, sp, #0x48
    2ff8:      	mov	x2, x22
    2ffc:      	blr	x8
    3000:      	b	0x302c <do_action+0x32c>
    3004:      	add	w20, w20, #0x1
    3008:      	add	x8, x21, w20, uxtw #2
    300c:      	ldr	w8, [x8, #0x4]
    3010:      	and	x8, x8, #0x7
    3014:      	cmp	w8, #0x4
    3018:      	b.hi	0x302c <do_action+0x32c>
    301c:      	add	x9, x29, x8, lsl #2
    3020:      	mov	w10, #0x5ea0            // =24224
    3024:      	ldr	w9, [x9, x10]
    3028:      	cbz	w9, 0x3318 <do_action+0x618>
    302c:      	mov	w0, wzr
    3030:      	cbz	w0, 0x32f4 <do_action+0x5f4>
    3034:      	mov	w0, wzr
    3038:      	b	0x32fc <do_action+0x5fc>
    303c:      	add	w20, w20, #0x1
    3040:      	add	x8, x21, w20, uxtw #2
    3044:      	ldr	w8, [x8, #0x4]
    3048:      	str	w8, [x29, #0x78]
    304c:      	b	0x32f4 <do_action+0x5f4>
    3050:      	strb	wzr, [x23]
    3054:      	b	0x32f4 <do_action+0x5f4>
    3058:      	tst	w25, #0x1
    305c:      	mov	w8, #0x4                // =4
    3060:      	add	w24, w20, #0x1
    3064:      	cinc	x21, x8, eq
    3068:      	b	0x32ac <do_action+0x5ac>
    306c:      	mov	w8, #0xe                // =14
    3070:      	blr	x8
    3074:      	str	x0, [sp, #0x58]
    3078:      	adrp	x21, 0x3000 <do_action+0x300>
    307c:      	add	x8, sp, #0x58
    3080:      	mov	w9, #0x1                // =1
    3084:      	ldr	x21, [x21]
    3088:      	add	x1, sp, #0x58
    308c:      	mov	w23, #0x1               // =1
    3090:      	mov	x0, x21
    3094:      	blr	x9
    3098:      	cbz	x0, 0x32f4 <do_action+0x5f4>
    309c:      	ldur	x8, [x0, #0x4]
    30a0:      	adrp	x22, 0x3000 <do_action+0x300>
    30a4:      	mov	w9, #0x1                // =1
    30a8:      	add	x1, sp, #0x68
    30ac:      	str	x8, [sp, #0x68]
    30b0:      	mov	w8, #0x2                // =2
    30b4:      	str	w8, [sp, #0x70]
    30b8:      	add	x8, sp, #0x68
    30bc:      	ldr	x22, [x22]
    30c0:      	mov	x0, x22
    30c4:      	blr	x9
    30c8:      	str	w23, [sp, #0x8c]
    30cc:      	cbz	x0, 0x33a4 <do_action+0x6a4>
    30d0:      	nop
    30d4:      	nop
    30d8:      	nop
    30dc:      	nop
    30e0:      	ldaxr	w8, [x0]
    30e4:      	add	w8, w8, #0x1
    30e8:      	stlxr	w9, w8, [x0]
    30ec:      	cbnz	w9, 0x30e0 <do_action+0x3e0>
    30f0:      	mov	w8, #0x3                // =3
    30f4:      	add	x9, sp, #0x58
    30f8:      	add	x1, sp, #0x58
    30fc:      	mov	x0, x21
    3100:      	blr	x8
    3104:      	b	0x32f4 <do_action+0x5f4>
    3108:      	add	w8, w20, #0x1
    310c:      	add	x9, x21, #0x4
    3110:      	str	x22, [sp, #0x30]
    3114:      	ldr	w25, [x9, w8, uxtw #2]
    3118:      	add	w8, w20, #0x2
    311c:      	ldr	w22, [x9, w8, uxtw #2]
    3120:      	mov	w8, #0x7d               // =125
    3124:      	blr	x8
    3128:      	str	x0, [sp, #0x8]
    312c:      	str	x0, [sp, #0x48]
    3130:      	str	wzr, [sp, #0x58]
    3134:      	cbz	w25, 0x373c <do_action+0xa3c>
    3138:      	adrp	x0, 0x3000 <do_action+0x300>
    313c:      	mov	w8, #0x1                // =1
    3140:      	add	x9, sp, #0x58
    3144:      	ldr	x0, [x0]
    3148:      	add	x1, sp, #0x58
    314c:      	blr	x8
    3150:      	cbz	x0, 0x373c <do_action+0xa3c>
    3154:      	mov	x10, x0
    3158:      	adrp	x0, 0x3000 <do_action+0x300>
    315c:      	mov	w8, #0x1                // =1
    3160:      	ldr	x0, [x0]
    3164:      	add	x9, sp, #0x58
    3168:      	add	x1, sp, #0x58
    316c:      	str	x10, [sp, #0x10]
    3170:      	blr	x8
    3174:      	ldr	x9, [sp, #0x10]
    3178:      	ldr	x8, [x29, #0x60]
    317c:      	mov	x2, x0
    3180:      	cmp	w22, #0x2
    3184:      	str	x8, [x9]
    3188:      	ldr	x8, [x29, #0x70]
    318c:      	str	x8, [x9, #0x8]
    3190:      	b.eq	0x3554 <do_action+0x854>
    3194:      	cmp	w22, #0x1
    3198:      	b.eq	0x3548 <do_action+0x848>
    319c:      	cbnz	w22, 0x373c <do_action+0xa3c>
    31a0:      	ldr	w8, [x29, #0x7c]
    31a4:      	str	x25, [sp]
    31a8:      	b	0x355c <do_action+0x85c>
    31ac:      	mov	w0, #0x9                // =9
    31b0:      	tbnz	w25, #0x0, 0x2db8 <do_action+0xb8>
    31b4:      	mov	w21, #0x3               // =3
    31b8:      	mov	w24, w20
    31bc:      	b	0x32ac <do_action+0x5ac>
    31c0:      	add	w24, w20, #0x3
    31c4:      	tbz	w25, #0x0, 0x32a8 <do_action+0x5a8>
    31c8:      	add	x9, x21, #0x4
    31cc:      	add	w10, w20, #0x2
    31d0:      	ldr	w8, [x9, w24, uxtw #2]
    31d4:      	ldr	w21, [x9, w10, uxtw #2]
    31d8:      	add	w10, w20, #0x1
    31dc:      	ldr	w20, [x9, w10, uxtw #2]
    31e0:      	cmp	w8, #0x4
    31e4:      	b.hi	0x31f8 <do_action+0x4f8>
    31e8:      	add	x9, x29, x8, lsl #2
    31ec:      	mov	w10, #0x5ea0            // =24224
    31f0:      	ldr	w9, [x9, x10]
    31f4:      	cbz	w9, 0x37d4 <do_action+0xad4>
    31f8:      	mov	x8, xzr
    31fc:      	ldr	w9, [x29, #0x60]
    3200:      	orr	x22, x9, x8
    3204:      	mov	w8, #0xe                // =14
    3208:      	blr	x8
    320c:      	str	x0, [sp, #0x78]
    3210:      	strh	w20, [sp, #0x68]
    3214:      	add	x8, sp, #0x78
    3218:      	mov	w9, #0x1                // =1
    321c:      	add	x1, sp, #0x78
    3220:      	strh	w21, [sp, #0x6a]
    3224:      	stur	x22, [sp, #0x6c]
    3228:      	adrp	x21, 0x3000 <do_action+0x300>
    322c:      	ldr	x21, [x21]
    3230:      	mov	w22, #0x1               // =1
    3234:      	mov	x0, x21
    3238:      	blr	x9
    323c:      	cbz	x0, 0x3420 <do_action+0x720>
    3240:      	ldur	x8, [x0, #0x4]
    3244:      	str	w22, [sp, #0x60]
    3248:      	adrp	x21, 0x3000 <do_action+0x300>
    324c:      	mov	w9, #0x1                // =1
    3250:      	mov	x20, x0
    3254:      	add	x1, sp, #0x58
    3258:      	str	x8, [sp, #0x58]
    325c:      	add	x8, sp, #0x58
    3260:      	ldr	x21, [x21]
    3264:      	mov	x0, x21
    3268:      	blr	x9
    326c:      	str	w22, [sp, #0x88]
    3270:      	cbz	x0, 0x34cc <do_action+0x7cc>
    3274:      	nop
    3278:      	nop
    327c:      	nop
    3280:      	ldaxr	w8, [x0]
    3284:      	add	w8, w8, #0x1
    3288:      	stlxr	w9, w8, [x0]
    328c:      	cbnz	w9, 0x3280 <do_action+0x580>
    3290:      	ldr	x8, [sp, #0x68]
    3294:      	ldr	w9, [sp, #0x70]
    3298:      	str	w9, [x20, #0x8]
    329c:      	str	x8, [x20]
    32a0:      	mov	w21, #0x6               // =6
    32a4:      	b	0x32ac <do_action+0x5ac>
    32a8:      	mov	w21, #0x7               // =7
    32ac:      	str	wzr, [sp, #0x48]
    32b0:      	adrp	x0, 0x3000 <do_action+0x300>
    32b4:      	mov	w8, #0x1                // =1
    32b8:      	add	x9, sp, #0x48
    32bc:      	ldr	x0, [x0]
    32c0:      	add	x1, sp, #0x48
    32c4:      	blr	x8
    32c8:      	cbz	x0, 0x32f0 <do_action+0x5f0>
    32cc:      	add	x8, x0, x21, lsl #3
    32d0:      	nop
    32d4:      	nop
    32d8:      	nop
    32dc:      	nop
    32e0:      	ldaxr	x9, [x8]
    32e4:      	add	x9, x9, #0x1
    32e8:      	stlxr	w10, x9, [x8]
    32ec:      	cbnz	w10, 0x32e0 <do_action+0x5e0>
    32f0:      	mov	w20, w24
    32f4:      	add	w0, w20, #0x1
    32f8:      	str	x19, [x29, #0x70]
    32fc:      	ldp	x20, x19, [sp, #0xc0]
    3300:      	ldr	x29, [sp, #0x80]
    3304:      	ldp	x22, x21, [sp, #0xb0]
    3308:      	ldp	x24, x23, [sp, #0xa0]
    330c:      	ldp	x30, x25, [sp, #0x90]
    3310:      	add	sp, sp, #0xd0
    3314:      	ret
    3318:      	add	x8, x29, x8, lsl #3
    331c:      	ldr	x8, [x8, #0x5e78]
    3320:      	and	x8, x8, #0x7ff
    3324:      	add	x8, x29, x8
    3328:      	ldr	x8, [x8, #0xb8]
    332c:      	str	x8, [sp, #0x68]
    3330:      	cbz	x8, 0x302c <do_action+0x32c>
    3334:      	cmp	w19, #0xa
    3338:      	b.ne	0x34b0 <do_action+0x7b0>
    333c:      	mov	w8, #0xe                // =14
    3340:      	blr	x8
    3344:      	lsr	x8, x0, #32
    3348:      	mov	x21, x0
    334c:      	adrp	x0, 0x3000 <do_action+0x300>
    3350:      	str	w8, [sp, #0x48]
    3354:      	mov	w8, #0x1                // =1
    3358:      	add	x9, sp, #0x48
    335c:      	add	x1, sp, #0x48
    3360:      	ldr	x0, [x0]
    3364:      	blr	x8
    3368:      	cbz	x0, 0x3030 <do_action+0x330>
    336c:      	ldr	w8, [x0]
    3370:      	mov	x3, xzr
    3374:      	add	x9, sp, #0x68
    3378:      	add	x10, sp, #0x48
    337c:      	stp	w8, w21, [sp, #0x48]
    3380:      	ldr	x8, [x0, #0x8]
    3384:      	adrp	x0, 0x3000 <do_action+0x300>
    3388:      	add	x1, sp, #0x68
    338c:      	add	x2, sp, #0x48
    3390:      	str	x8, [sp, #0x50]
    3394:      	mov	w8, #0x2                // =2
    3398:      	ldr	x0, [x0]
    339c:      	blr	x8
    33a0:      	b	0x302c <do_action+0x32c>
    33a4:      	mov	w8, #0x1                // =1
    33a8:      	mov	w9, #0x2                // =2
    33ac:      	add	x10, sp, #0x68
    33b0:      	add	x11, sp, #0x8c
    33b4:      	add	x1, sp, #0x68
    33b8:      	add	x2, sp, #0x8c
    33bc:      	mov	x0, x22
    33c0:      	mov	w3, #0x1                // =1
    33c4:      	blr	x9
    33c8:      	cbz	x0, 0x30f0 <do_action+0x3f0>
    33cc:      	mov	x23, x0
    33d0:      	adrp	x24, 0x3000 <do_action+0x300>
    33d4:      	mov	w9, #0x1                // =1
    33d8:      	add	x1, sp, #0x48
    33dc:      	mov	w25, #0x1               // =1
    33e0:      	neg	w8, w23
    33e4:      	strh	w8, [sp, #0x48]
    33e8:      	mov	w8, #0x3                // =3
    33ec:      	strh	w8, [sp, #0x4a]
    33f0:      	mov	x8, #0x3b               // =59
    33f4:      	movk	x8, #0x2, lsl #32
    33f8:      	stur	x8, [sp, #0x4c]
    33fc:      	add	x8, sp, #0x48
    3400:      	ldr	x24, [x24]
    3404:      	mov	x0, x24
    3408:      	blr	x9
    340c:      	cbz	x0, 0x37f0 <do_action+0xaf0>
    3410:      	ldr	w8, [x0]
    3414:      	add	w8, w8, #0x1
    3418:      	str	w8, [x0]
    341c:      	b	0x3814 <do_action+0xb14>
    3420:      	mov	x3, xzr
    3424:      	mov	w8, #0x2                // =2
    3428:      	add	x9, sp, #0x78
    342c:      	add	x10, sp, #0x68
    3430:      	add	x1, sp, #0x78
    3434:      	add	x2, sp, #0x68
    3438:      	mov	x0, x21
    343c:      	blr	x8
    3440:      	cbz	x0, 0x32a0 <do_action+0x5a0>
    3444:      	neg	w8, w0
    3448:      	adrp	x20, 0x3000 <do_action+0x300>
    344c:      	mov	w9, #0x1                // =1
    3450:      	strh	w8, [sp, #0x48]
    3454:      	mov	w8, #0x3                // =3
    3458:      	add	x1, sp, #0x48
    345c:      	mov	w21, #0x1               // =1
    3460:      	strh	w8, [sp, #0x4a]
    3464:      	mov	x8, #0x6b               // =107
    3468:      	movk	x8, #0x2, lsl #32
    346c:      	stur	x8, [sp, #0x4c]
    3470:      	add	x8, sp, #0x48
    3474:      	ldr	x20, [x20]
    3478:      	mov	x0, x20
    347c:      	blr	x9
    3480:      	cbz	x0, 0x3848 <do_action+0xb48>
    3484:      	ldr	w8, [x0]
    3488:      	add	w8, w8, #0x1
    348c:      	str	w8, [x0]
    3490:      	b	0x32a0 <do_action+0x5a0>
    3494:      	adrp	x0, 0x3000 <do_action+0x300>
    3498:      	mov	w8, #0x3                // =3
    349c:      	add	x9, sp, #0x48
    34a0:      	ldr	x0, [x0]
    34a4:      	add	x1, sp, #0x48
    34a8:      	blr	x8
    34ac:      	b	0x3030 <do_action+0x330>
    34b0:      	adrp	x0, 0x3000 <do_action+0x300>
    34b4:      	mov	w8, #0x3                // =3
    34b8:      	add	x9, sp, #0x68
    34bc:      	ldr	x0, [x0]
    34c0:      	add	x1, sp, #0x68
    34c4:      	blr	x8
    34c8:      	b	0x3030 <do_action+0x330>
    34cc:      	mov	w8, #0x1                // =1
    34d0:      	mov	w9, #0x2                // =2
    34d4:      	add	x10, sp, #0x58
    34d8:      	add	x11, sp, #0x88
    34dc:      	add	x1, sp, #0x58
    34e0:      	add	x2, sp, #0x88
    34e4:      	mov	x0, x21
    34e8:      	mov	w3, #0x1                // =1
    34ec:      	blr	x9
    34f0:      	cbz	x0, 0x3290 <do_action+0x590>
    34f4:      	mov	x22, x0
    34f8:      	adrp	x23, 0x3000 <do_action+0x300>
    34fc:      	mov	w9, #0x1                // =1
    3500:      	add	x1, sp, #0x48
    3504:      	mov	w25, #0x1               // =1
    3508:      	neg	w8, w22
    350c:      	strh	w8, [sp, #0x48]
    3510:      	mov	w8, #0x3                // =3
    3514:      	strh	w8, [sp, #0x4a]
    3518:      	mov	x8, #0x3b               // =59
    351c:      	movk	x8, #0x2, lsl #32
    3520:      	stur	x8, [sp, #0x4c]
    3524:      	add	x8, sp, #0x48
    3528:      	ldr	x23, [x23]
    352c:      	mov	x0, x23
    3530:      	blr	x9
    3534:      	cbz	x0, 0x3870 <do_action+0xb70>
    3538:      	ldr	w8, [x0]
    353c:      	add	w8, w8, #0x1
    3540:      	str	w8, [x0]
    3544:      	b	0x3894 <do_action+0xb94>
    3548:      	ldr	w8, [x29, #0x10]
    354c:      	str	x25, [sp]
    3550:      	b	0x355c <do_action+0x85c>
    3554:      	str	x25, [sp]
    3558:      	mov	w8, wzr
    355c:      	mov	w8, w8
    3560:      	add	x0, x9, #0x18
    3564:      	mov	w1, #0xc8               // =200
    3568:      	str	x8, [x9, #0x10]
    356c:      	mov	w8, #0xc8               // =200
    3570:      	mov	w9, #0x4                // =4
    3574:      	str	x0, [sp, #0x18]
    3578:      	blr	x9
    357c:      	ldr	x22, [sp, #0x30]
    3580:      	mov	w8, #0x5e78             // =24184
    3584:      	mov	x25, xzr
    3588:      	str	wzr, [sp, #0x2c]
    358c:      	add	x10, x29, x8
    3590:      	str	x19, [sp, #0x20]
    3594:      	b	0x35a8 <do_action+0x8a8>
    3598:      	add	x25, x25, #0x4
    359c:      	add	x10, x10, #0x8
    35a0:      	cmp	x25, #0x14
    35a4:      	b.eq	0x36e0 <do_action+0x9e0>
    35a8:      	str	x10, [sp, #0x38]
    35ac:      	str	wzr, [sp, #0x68]
    35b0:      	mov	w8, #0x1                // =1
    35b4:      	add	x9, sp, #0x68
    35b8:      	add	x1, sp, #0x68
    35bc:      	mov	x0, x24
    35c0:      	blr	x8
    35c4:      	cbz	x0, 0x36e0 <do_action+0x9e0>
    35c8:      	mov	w8, #0x5ef8             // =24312
    35cc:      	add	x1, x0, x8
    35d0:      	adrp	x0, 0x3000 <do_action+0x300>
    35d4:      	mov	w8, #0x1                // =1
    35d8:      	ldr	x0, [x0]
    35dc:      	blr	x8
    35e0:      	cbz	x0, 0x36e0 <do_action+0x9e0>
    35e4:      	add	x8, x0, x25
    35e8:      	ldr	x10, [sp, #0x38]
    35ec:      	ldr	w8, [x8, #0x40]
    35f0:      	cmn	w8, #0x1
    35f4:      	b.eq	0x36e0 <do_action+0x9e0>
    35f8:      	ldr	x8, [x10]
    35fc:      	ldr	w9, [x29, #0x4]
    3600:      	cmp	x8, x9
    3604:      	b.ge	0x36e0 <do_action+0x9e0>
    3608:      	cmp	x25, #0x10
    360c:      	b.eq	0x3674 <do_action+0x974>
    3610:      	str	wzr, [sp, #0x68]
    3614:      	mov	w8, #0x1                // =1
    3618:      	add	x9, sp, #0x68
    361c:      	add	x1, sp, #0x68
    3620:      	mov	x0, x24
    3624:      	blr	x8
    3628:      	cbz	x0, 0x366c <do_action+0x96c>
    362c:      	mov	w8, #0x5ef8             // =24312
    3630:      	add	x1, x0, x8
    3634:      	adrp	x0, 0x3000 <do_action+0x300>
    3638:      	mov	w8, #0x1                // =1
    363c:      	ldr	x0, [x0]
    3640:      	blr	x8
    3644:      	cbz	x0, 0x366c <do_action+0x96c>
    3648:      	ldr	x10, [sp, #0x38]
    364c:      	add	x8, x0, x25
    3650:      	ldr	w9, [x8, #0x44]
    3654:      	ldr	x8, [x10]
    3658:      	cmn	w9, #0x1
    365c:      	b.eq	0x3674 <do_action+0x974>
    3660:      	ldr	w9, [x10, #0x8]
    3664:      	sub	w9, w9, w8
    3668:      	b	0x3680 <do_action+0x980>
    366c:      	ldr	x10, [sp, #0x38]
    3670:      	ldr	x8, [x10]
    3674:      	ldr	w9, [x29, #0x4]
    3678:      	sub	w9, w9, w8
    367c:      	add	w9, w9, #0x4
    3680:      	cmp	w9, #0x1
    3684:      	b.lt	0x3598 <do_action+0x898>
    3688:      	mov	w10, #0x3ffc            // =16380
    368c:      	cmp	w9, #0x28
    3690:      	mov	x19, x29
    3694:      	add	w8, w8, w10
    3698:      	mov	w10, #0x28              // =40
    369c:      	csel	w29, w9, w10, lt
    36a0:      	ldr	w9, [sp, #0x2c]
    36a4:      	and	x8, x8, #0x3fff
    36a8:      	add	x8, x19, x8
    36ac:      	mov	w1, w29
    36b0:      	add	x2, x8, #0x90
    36b4:      	mov	w8, #0x4                // =4
    36b8:      	and	w22, w9, #0xff
    36bc:      	ldr	x9, [sp, #0x18]
    36c0:      	add	x0, x9, x22
    36c4:      	blr	x8
    36c8:      	add	w8, w29, w22
    36cc:      	ldp	x22, x10, [sp, #0x30]
    36d0:      	mov	x29, x19
    36d4:      	ldr	x19, [sp, #0x20]
    36d8:      	str	w8, [sp, #0x2c]
    36dc:      	b	0x3598 <do_action+0x898>
    36e0:      	adrp	x24, 0x3000 <do_action+0x300>
    36e4:      	mov	w8, #0x1                // =1
    36e8:      	ldr	x24, [x24]
    36ec:      	ldr	x1, [sp, #0x10]
    36f0:      	mov	x0, x24
    36f4:      	blr	x8
    36f8:      	cbz	x0, 0x3720 <do_action+0xa20>
    36fc:      	ldp	x10, x11, [sp]
    3700:      	mov	x9, #-0x4240            // =-16960
    3704:      	movk	x9, #0xfff0, lsl #16
    3708:      	ldr	x8, [x0]
    370c:      	madd	x9, x10, x9, x11
    3710:      	cmp	x8, x9
    3714:      	b.ls	0x3720 <do_action+0xa20>
    3718:      	strb	wzr, [x23]
    371c:      	b	0x3740 <do_action+0xa40>
    3720:      	ldr	x1, [sp, #0x10]
    3724:      	mov	x3, xzr
    3728:      	mov	w8, #0x2                // =2
    372c:      	add	x9, sp, #0x48
    3730:      	add	x2, sp, #0x48
    3734:      	mov	x0, x24
    3738:      	blr	x8
    373c:      	ldr	x22, [sp, #0x30]
    3740:      	add	w8, w20, #0x3
    3744:      	adrp	x23, 0x3000 <do_action+0x300>
    3748:      	add	x8, x21, w8, uxtw #2
    374c:      	ldr	w8, [x8, #0x4]
    3750:      	ldr	x23, [x23]
    3754:      	cbz	w8, 0x377c <do_action+0xa7c>
    3758:      	ldrb	w8, [x29, #0x1]
    375c:      	mov	x2, xzr
    3760:      	mov	x0, x22
    3764:      	mov	x1, x23
    3768:      	orr	w8, w8, #0x2
    376c:      	strb	w8, [x29, #0x1]
    3770:      	mov	w8, #0x1b               // =27
    3774:      	blr	x8
    3778:      	str	x0, [x29, #0x80]
    377c:      	add	w8, w20, #0x4
    3780:      	add	x8, x21, w8, uxtw #2
    3784:      	ldr	w8, [x8, #0x4]
    3788:      	cbz	w8, 0x37b4 <do_action+0xab4>
    378c:      	ldrb	w8, [x29, #0x1]
    3790:      	mov	w9, #0x1b               // =27
    3794:      	mov	x0, x22
    3798:      	mov	x1, x23
    379c:      	mov	w2, #0x100              // =256
    37a0:      	orr	w8, w8, #0x4
    37a4:      	strb	w8, [x29, #0x1]
    37a8:      	mov	w8, #0x100              // =256
    37ac:      	blr	x9
    37b0:      	str	x0, [x29, #0x88]
    37b4:      	add	w20, w20, #0x5
    37b8:      	add	x8, x21, w20, uxtw #2
    37bc:      	ldr	w8, [x8, #0x4]
    37c0:      	cbz	w8, 0x32f4 <do_action+0x5f4>
    37c4:      	ldrb	w8, [x29, #0x1]
    37c8:      	orr	w8, w8, #0x8
    37cc:      	strb	w8, [x29, #0x1]
    37d0:      	b	0x32f4 <do_action+0x5f4>
    37d4:      	add	x8, x29, x8, lsl #3
    37d8:      	ldr	x8, [x8, #0x5e78]
    37dc:      	and	x8, x8, #0x7ff
    37e0:      	add	x8, x29, x8
    37e4:      	ldr	x8, [x8, #0x90]
    37e8:      	lsl	x8, x8, #32
    37ec:      	b	0x31fc <do_action+0x4fc>
    37f0:      	str	w25, [sp, #0x78]
    37f4:      	mov	x3, xzr
    37f8:      	mov	w8, #0x2                // =2
    37fc:      	add	x9, sp, #0x48
    3800:      	add	x10, sp, #0x78
    3804:      	add	x1, sp, #0x48
    3808:      	add	x2, sp, #0x78
    380c:      	mov	x0, x24
    3810:      	blr	x8
    3814:      	cbz	w23, 0x30f0 <do_action+0x3f0>
    3818:      	mov	w8, #0x1                // =1
    381c:      	add	x9, sp, #0x68
    3820:      	add	x1, sp, #0x68
    3824:      	mov	x0, x22
    3828:      	blr	x8
    382c:      	cbz	x0, 0x30f0 <do_action+0x3f0>
    3830:      	ldr	w8, [sp, #0x8c]
    3834:      	ldaxr	w9, [x0]
    3838:      	add	w9, w9, w8
    383c:      	stlxr	w10, w9, [x0]
    3840:      	cbnz	w10, 0x3834 <do_action+0xb34>
    3844:      	b	0x30f0 <do_action+0x3f0>
    3848:      	str	w21, [sp, #0x58]
    384c:      	mov	x3, xzr
    3850:      	mov	w8, #0x2                // =2
    3854:      	add	x9, sp, #0x48
    3858:      	add	x10, sp, #0x58
    385c:      	add	x1, sp, #0x48
    3860:      	add	x2, sp, #0x58
    3864:      	mov	x0, x20
    3868:      	blr	x8
    386c:      	b	0x32a0 <do_action+0x5a0>
    3870:      	str	w25, [sp, #0x8c]
    3874:      	mov	x3, xzr
    3878:      	mov	w8, #0x2                // =2
    387c:      	add	x9, sp, #0x48
    3880:      	add	x10, sp, #0x8c
    3884:      	add	x1, sp, #0x48
    3888:      	add	x2, sp, #0x8c
    388c:      	mov	x0, x23
    3890:      	blr	x8
    3894:      	cbz	w22, 0x3290 <do_action+0x590>
    3898:      	mov	w8, #0x1                // =1
    389c:      	add	x9, sp, #0x58
    38a0:      	add	x1, sp, #0x58
    38a4:      	mov	x0, x21
    38a8:      	blr	x8
    38ac:      	cbz	x0, 0x3290 <do_action+0x590>
    38b0:      	ldr	w8, [sp, #0x88]
    38b4:      	ldaxr	w9, [x0]
    38b8:      	add	w9, w9, w8
    38bc:      	stlxr	w10, w9, [x0]
    38c0:      	cbnz	w10, 0x38b4 <do_action+0xbb4>
    38c4:      	b	0x3290 <do_action+0x590>

Disassembly of section tracepoint:

0000000000000000 <generic_tracepoint_process_event>:
       0:      	sub	sp, sp, #0x160
       4:      	str	x29, [sp, #0x110]
       8:      	stp	x30, x25, [sp, #0x120]
       c:      	stp	x24, x23, [sp, #0x130]
      10:      	stp	x22, x21, [sp, #0x140]
      14:      	stp	x20, x19, [sp, #0x150]
      18:      	str	wzr, [sp, #0x5c]
      1c:      	adrp	x21, 0x0 <generic_tracepoint_process_event>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x5c
      28:      	ldr	x21, [x21]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x5c
      34:      	mov	x0, x21
      38:      	blr	x8
      3c:      	cbz	x0, 0x4b8 <generic_tracepoint_process_event+0x4b8>
      40:      	ldr	w24, [x0, #0x4]
      44:      	mov	w25, #0x5efc            // =24316
      48:      	mov	x20, x0
      4c:      	ldr	w23, [x0, x25]
      50:      	lsr	w8, w24, #3
      54:      	cmp	w8, #0x464
      58:      	b.hi	0x41c <generic_tracepoint_process_event+0x41c>
      5c:      	str	wzr, [sp, #0x68]
      60:      	mov	w8, #0x1                // =1
      64:      	add	x9, sp, #0x68
      68:      	add	x1, sp, #0x68
      6c:      	mov	x0, x21
      70:      	blr	x8
      74:      	cbz	x0, 0x41c <generic_tracepoint_process_event+0x41c>
      78:      	mov	w8, #0x5ef8             // =24312
      7c:      	mov	x22, x0
      80:      	add	x1, x0, x8
      84:      	adrp	x0, 0x0 <generic_tracepoint_process_event>
      88:      	mov	w8, #0x1                // =1
      8c:      	ldr	x0, [x0]
      90:      	blr	x8
      94:      	cmp	w23, #0x4
      98:      	ccmp	x0, #0x0, #0x4, le
      9c:      	b.eq	0x41c <generic_tracepoint_process_event+0x41c>
      a0:      	and	x29, x23, #0x7
      a4:      	str	x24, [sp, #0x118]
      a8:      	mov	w9, #0x5ea0             // =24224
      ac:      	add	x8, x0, x29, lsl #2
      b0:      	ldr	w24, [x8, #0x4]
      b4:      	ldrsw	x10, [x8, #0x18]
      b8:      	add	x8, x22, x29, lsl #2
      bc:      	add	x8, x8, x9
      c0:      	add	x9, x22, x29, lsl #3
      c4:      	ldr	x11, [x9, #0x5e50]
      c8:      	str	wzr, [x8]
      cc:      	str	x10, [sp, #0x48]
      d0:      	str	x11, [sp, #0x60]
      d4:      	tbnz	w10, #0x8, 0x128 <generic_tracepoint_process_event+0x128>
      d8:      	cmp	w29, #0x4
      dc:      	b.hi	0x130 <generic_tracepoint_process_event+0x130>
      e0:      	mov	w9, #0x50               // =80
      e4:      	umaddl	x9, w29, w9, x0
      e8:      	ldrh	w10, [x9, #0x76]
      ec:      	cbz	w10, 0x130 <generic_tracepoint_process_event+0x130>
      f0:      	add	x9, x9, #0x70
      f4:      	add	x10, sp, #0x60
      f8:      	str	x23, [sp, #0x40]
      fc:      	strb	wzr, [sp, #0xa8]
     100:      	str	x8, [sp, #0xb0]
     104:      	stp	x9, x10, [sp, #0x98]
     108:      	adrp	x8, 0x0 <generic_tracepoint_process_event>
     10c:      	ldr	x8, [x8]
     110:      	ldrb	w8, [x8]
     114:      	cbz	w8, 0x254 <generic_tracepoint_process_event+0x254>
     118:      	mov	x23, xzr
     11c:      	mov	w22, #0x1               // =1
     120:      	mov	w25, #0x8               // =8
     124:      	b	0x194 <generic_tracepoint_process_event+0x194>
     128:      	mov	x11, xzr
     12c:      	str	xzr, [sp, #0x60]
     130:      	mov	w22, #0x1000            // =4096
     134:      	cmp	w24, #0x15
     138:      	b.gt	0x290 <generic_tracepoint_process_event+0x290>
     13c:      	cmp	w24, #0xb
     140:      	b.gt	0x1ec <generic_tracepoint_process_event+0x1ec>
     144:      	cmp	w24, #0x5
     148:      	b.gt	0x210 <generic_tracepoint_process_event+0x210>
     14c:      	cmp	w24, #0x3
     150:      	b.gt	0x35c <generic_tracepoint_process_event+0x35c>
     154:      	sub	w8, w24, #0x2
     158:      	cmp	w8, #0x2
     15c:      	b.lo	0x318 <generic_tracepoint_process_event+0x318>
     160:      	cmp	w24, #0x1
     164:      	b.eq	0x318 <generic_tracepoint_process_event+0x318>
     168:      	b	0x394 <generic_tracepoint_process_event+0x394>
     16c:      	mov	w10, #0x4               // =4
     170:      	ldr	x0, [sp, #0xa0]
     174:      	mov	w1, #0x8                // =8
     178:      	ldr	x2, [x0]
     17c:      	blr	x10
     180:      	tbnz	w0, #0x1f, 0x1e0 <generic_tracepoint_process_event+0x1e0>
     184:      	add	x23, x23, #0x8
     188:      	add	w22, w22, #0x1
     18c:      	cmp	x23, #0x50
     190:      	b.eq	0x278 <generic_tracepoint_process_event+0x278>
     194:      	ldr	x8, [sp, #0x98]
     198:      	add	x10, x8, x23
     19c:      	ldrh	w8, [x10, #0x6]
     1a0:      	cbz	w8, 0x278 <generic_tracepoint_process_event+0x278>
     1a4:      	ldr	x8, [sp, #0xa0]
     1a8:      	ldr	w11, [x10]
     1ac:      	ldr	x9, [x8]
     1b0:      	add	x9, x9, x11
     1b4:      	str	x9, [x8]
     1b8:      	ldrh	w10, [x10, #0x4]
     1bc:      	cbz	w10, 0x184 <generic_tracepoint_process_event+0x184>
     1c0:      	ldrb	w10, [sp, #0xa8]
     1c4:      	cbz	w10, 0x16c <generic_tracepoint_process_event+0x16c>
     1c8:      	mov	w10, #0x94              // =148
     1cc:      	ldr	x0, [sp, #0xa0]
     1d0:      	mov	w1, #0x8                // =8
     1d4:      	ldr	x2, [x0]
     1d8:      	blr	x10
     1dc:      	tbz	w0, #0x1f, 0x184 <generic_tracepoint_process_event+0x184>
     1e0:      	ldr	x8, [sp, #0xb0]
     1e4:      	str	w22, [x8]
     1e8:      	b	0x278 <generic_tracepoint_process_event+0x278>
     1ec:      	cmp	w24, #0x11
     1f0:      	b.gt	0x234 <generic_tracepoint_process_event+0x234>
     1f4:      	sub	w8, w24, #0xf
     1f8:      	cmp	w8, #0x3
     1fc:      	b.lo	0x398 <generic_tracepoint_process_event+0x398>
     200:      	sub	w8, w24, #0xc
     204:      	cmp	w8, #0x2
     208:      	b.lo	0x318 <generic_tracepoint_process_event+0x318>
     20c:      	b	0x394 <generic_tracepoint_process_event+0x394>
     210:      	cmp	w24, #0x9
     214:      	b.gt	0x374 <generic_tracepoint_process_event+0x374>
     218:      	cmp	w24, #0x6
     21c:      	b.eq	0x398 <generic_tracepoint_process_event+0x398>
     220:      	cmp	w24, #0x7
     224:      	b.eq	0x36c <generic_tracepoint_process_event+0x36c>
     228:      	cmp	w24, #0x8
     22c:      	b.eq	0x38c <generic_tracepoint_process_event+0x38c>
     230:      	b	0x394 <generic_tracepoint_process_event+0x394>
     234:      	cmp	w24, #0x13
     238:      	b.gt	0x328 <generic_tracepoint_process_event+0x328>
     23c:      	ldr	x22, [sp, #0x48]
     240:      	cmp	w24, #0x12
     244:      	b.eq	0x398 <generic_tracepoint_process_event+0x398>
     248:      	cmp	w24, #0x13
     24c:      	b.eq	0x354 <generic_tracepoint_process_event+0x354>
     250:      	b	0x394 <generic_tracepoint_process_event+0x394>
     254:      	mov	x3, xzr
     258:      	adrp	x1, 0x0 <generic_tracepoint_process_event>
     25c:      	add	x1, x1, #0x0
     260:      	mov	w8, #0xa                // =10
     264:      	mov	w9, #0xb5               // =181
     268:      	add	x10, sp, #0x98
     26c:      	add	x2, sp, #0x98
     270:      	mov	w0, #0xa                // =10
     274:      	blr	x9
     278:      	ldr	x11, [sp, #0x60]
     27c:      	ldr	x23, [sp, #0x40]
     280:      	mov	w25, #0x5efc            // =24316
     284:      	mov	w22, #0x1000            // =4096
     288:      	cmp	w24, #0x15
     28c:      	b.le	0x13c <generic_tracepoint_process_event+0x13c>
     290:      	cmp	w24, #0x20
     294:      	b.le	0x2c0 <generic_tracepoint_process_event+0x2c0>
     298:      	cmp	w24, #0x27
     29c:      	b.gt	0x2e4 <generic_tracepoint_process_event+0x2e4>
     2a0:      	sub	w8, w24, #0x21
     2a4:      	cmp	w8, #0x4
     2a8:      	b.lo	0x374 <generic_tracepoint_process_event+0x374>
     2ac:      	cmp	w24, #0x25
     2b0:      	b.eq	0x398 <generic_tracepoint_process_event+0x398>
     2b4:      	cmp	w24, #0x27
     2b8:      	b.eq	0x320 <generic_tracepoint_process_event+0x320>
     2bc:      	b	0x394 <generic_tracepoint_process_event+0x394>
     2c0:      	cmp	w24, #0x1a
     2c4:      	b.gt	0x30c <generic_tracepoint_process_event+0x30c>
     2c8:      	cmp	w24, #0x16
     2cc:      	b.eq	0x320 <generic_tracepoint_process_event+0x320>
     2d0:      	cmp	w24, #0x17
     2d4:      	b.eq	0x374 <generic_tracepoint_process_event+0x374>
     2d8:      	cmp	w24, #0x1a
     2dc:      	b.eq	0x38c <generic_tracepoint_process_event+0x38c>
     2e0:      	b	0x394 <generic_tracepoint_process_event+0x394>
     2e4:      	cmp	w24, #0x29
     2e8:      	b.le	0x340 <generic_tracepoint_process_event+0x340>
     2ec:      	cmp	w24, #0x2a
     2f0:      	b.eq	0x398 <generic_tracepoint_process_event+0x398>
     2f4:      	cmp	w24, #0x2b
     2f8:      	b.eq	0x354 <generic_tracepoint_process_event+0x354>
     2fc:      	cmp	w24, #0x2c
     300:      	b.ne	0x394 <generic_tracepoint_process_event+0x394>
     304:      	mov	w22, #0x70              // =112
     308:      	b	0x398 <generic_tracepoint_process_event+0x398>
     30c:      	sub	w8, w24, #0x1d
     310:      	cmp	w8, #0x4
     314:      	b.hs	0x384 <generic_tracepoint_process_event+0x384>
     318:      	mov	w22, #0x4               // =4
     31c:      	b	0x398 <generic_tracepoint_process_event+0x398>
     320:      	mov	w22, #0x10              // =16
     324:      	b	0x398 <generic_tracepoint_process_event+0x398>
     328:      	cmp	w24, #0x14
     32c:      	b.eq	0x37c <generic_tracepoint_process_event+0x37c>
     330:      	cmp	w24, #0x15
     334:      	b.ne	0x394 <generic_tracepoint_process_event+0x394>
     338:      	mov	w22, #0x20              // =32
     33c:      	b	0x398 <generic_tracepoint_process_event+0x398>
     340:      	cmp	w24, #0x28
     344:      	b.eq	0x354 <generic_tracepoint_process_event+0x354>
     348:      	cmp	w24, #0x29
     34c:      	b.eq	0x36c <generic_tracepoint_process_event+0x36c>
     350:      	b	0x394 <generic_tracepoint_process_event+0x394>
     354:      	mov	w22, #0x18              // =24
     358:      	b	0x398 <generic_tracepoint_process_event+0x398>
     35c:      	cmp	w24, #0x4
     360:      	b.eq	0x374 <generic_tracepoint_process_event+0x374>
     364:      	cmp	w24, #0x5
     368:      	b.ne	0x394 <generic_tracepoint_process_event+0x394>
     36c:      	mov	w22, #0x40              // =64
     370:      	b	0x398 <generic_tracepoint_process_event+0x398>
     374:      	mov	w22, #0x8               // =8
     378:      	b	0x398 <generic_tracepoint_process_event+0x398>
     37c:      	mov	w22, #0x98              // =152
     380:      	b	0x398 <generic_tracepoint_process_event+0x398>
     384:      	cmp	w24, #0x1b
     388:      	b.ne	0x394 <generic_tracepoint_process_event+0x394>
     38c:      	mov	w22, #0x50              // =80
     390:      	b	0x398 <generic_tracepoint_process_event+0x398>
     394:      	mov	x22, xzr
     398:      	str	x11, [sp, #0x50]
     39c:      	str	wzr, [sp, #0x6c]
     3a0:      	mov	w8, #0x1                // =1
     3a4:      	add	x9, sp, #0x6c
     3a8:      	add	x1, sp, #0x6c
     3ac:      	mov	x0, x21
     3b0:      	blr	x8
     3b4:      	cbz	x0, 0x418 <generic_tracepoint_process_event+0x418>
     3b8:      	ldr	x9, [sp, #0x118]
     3bc:      	mov	w8, #0x3ffb             // =16379
     3c0:      	sub	x8, x8, x22
     3c4:      	cmp	x8, x9
     3c8:      	b.ls	0x418 <generic_tracepoint_process_event+0x418>
     3cc:      	add	x22, x0, x29, lsl #2
     3d0:      	mov	w8, #0x5ea0             // =24224
     3d4:      	add	x11, x0, #0x90
     3d8:      	ldr	w9, [x22, x8]
     3dc:      	ldr	x8, [sp, #0x118]
     3e0:      	add	x10, x0, x29, lsl #3
     3e4:      	str	w9, [x11, x8]
     3e8:      	add	x8, x8, #0x4
     3ec:      	str	x8, [x10, #0x5e78]
     3f0:      	cbz	w9, 0x4d8 <generic_tracepoint_process_event+0x4d8>
     3f4:      	ldr	x24, [sp, #0x118]
     3f8:      	mov	w8, #0x4                // =4
     3fc:      	add	w24, w8, w24
     400:      	str	w24, [x20, #0x4]
     404:      	adrp	x22, 0x0 <generic_tracepoint_process_event>
     408:      	cmp	w23, #0x3
     40c:      	ldr	x22, [x22]
     410:      	b.le	0x430 <generic_tracepoint_process_event+0x430>
     414:      	b	0x49c <generic_tracepoint_process_event+0x49c>
     418:      	ldr	x24, [sp, #0x118]
     41c:      	str	w24, [x20, #0x4]
     420:      	adrp	x22, 0x0 <generic_tracepoint_process_event>
     424:      	cmp	w23, #0x3
     428:      	ldr	x22, [x22]
     42c:      	b.gt	0x49c <generic_tracepoint_process_event+0x49c>
     430:      	str	wzr, [sp, #0x98]
     434:      	mov	w8, #0x1                // =1
     438:      	add	x9, sp, #0x98
     43c:      	add	x1, sp, #0x98
     440:      	mov	x0, x21
     444:      	blr	x8
     448:      	cbz	x0, 0x49c <generic_tracepoint_process_event+0x49c>
     44c:      	mov	w8, #0x5ef8             // =24312
     450:      	add	x1, x0, x8
     454:      	adrp	x0, 0x0 <generic_tracepoint_process_event>
     458:      	mov	w8, #0x1                // =1
     45c:      	ldr	x0, [x0]
     460:      	blr	x8
     464:      	cbz	x0, 0x49c <generic_tracepoint_process_event+0x49c>
     468:      	add	w8, w23, #0x1
     46c:      	and	w9, w8, #0x7
     470:      	add	x9, x0, w9, uxtw #2
     474:      	ldr	w9, [x9, #0x40]
     478:      	cmn	w9, #0x1
     47c:      	b.eq	0x49c <generic_tracepoint_process_event+0x49c>
     480:      	str	w8, [x20, x25]
     484:      	mov	w8, #0x1                // =1
     488:      	mov	w9, #0xc                // =12
     48c:      	mov	x0, x19
     490:      	mov	x1, x22
     494:      	mov	w2, #0x1                // =1
     498:      	blr	x9
     49c:      	str	wzr, [x20, x25]
     4a0:      	mov	w8, #0x3                // =3
     4a4:      	mov	w9, #0xc                // =12
     4a8:      	mov	x0, x19
     4ac:      	mov	x1, x22
     4b0:      	mov	w2, #0x3                // =3
     4b4:      	blr	x9
     4b8:      	ldp	x20, x19, [sp, #0x150]
     4bc:      	mov	w0, wzr
     4c0:      	ldr	x29, [sp, #0x110]
     4c4:      	ldp	x22, x21, [sp, #0x140]
     4c8:      	ldp	x24, x23, [sp, #0x130]
     4cc:      	ldp	x30, x25, [sp, #0x120]
     4d0:      	add	sp, sp, #0x160
     4d4:      	ret
     4d8:      	ldr	x10, [sp, #0x50]
     4dc:      	and	x29, x8, #0x3fff
     4e0:      	add	x9, sp, #0xe0
     4e4:      	cmp	w24, #0x17
     4e8:      	str	x19, [sp, #0x38]
     4ec:      	str	xzr, [x9, #0x10]
     4f0:      	add	x8, x11, x29
     4f4:      	stp	x8, x11, [sp, #0x20]
     4f8:      	str	x10, [sp, #0x98]
     4fc:      	b.le	0x528 <generic_tracepoint_process_event+0x528>
     500:      	cmp	w24, #0x18
     504:      	b.eq	0x548 <generic_tracepoint_process_event+0x548>
     508:      	cmp	w24, #0x25
     50c:      	b.eq	0x5a4 <generic_tracepoint_process_event+0x5a4>
     510:      	cmp	w24, #0x2a
     514:      	b.ne	0xb00 <generic_tracepoint_process_event+0xb00>
     518:      	add	x8, sp, #0x70
     51c:      	stp	xzr, x10, [sp, #0x70]
     520:      	str	x8, [sp, #0x30]
     524:      	b	0x60c <generic_tracepoint_process_event+0x60c>
     528:      	cmp	w24, #0xf
     52c:      	b.eq	0x5dc <generic_tracepoint_process_event+0x5dc>
     530:      	cmp	w24, #0x10
     534:      	b.ne	0xb00 <generic_tracepoint_process_event+0xb00>
     538:      	mov	x24, x22
     53c:      	add	x22, sp, #0x100
     540:      	add	x29, sp, #0xe0
     544:      	b	0x574 <generic_tracepoint_process_event+0x574>
     548:      	mov	x24, x22
     54c:      	add	x22, sp, #0x100
     550:      	mov	w8, #0x8                // =8
     554:      	mov	w9, #0x4                // =4
     558:      	ldr	x2, [sp, #0x98]
     55c:      	add	x0, sp, #0x100
     560:      	mov	w1, #0x8                // =8
     564:      	blr	x9
     568:      	add	x29, sp, #0xe0
     56c:      	ldr	x8, [x29, #0x20]
     570:      	str	x8, [sp, #0x98]
     574:      	mov	w8, #0x8                // =8
     578:      	mov	w9, #0x4                // =4
     57c:      	add	x10, sp, #0x98
     580:      	add	x0, sp, #0x100
     584:      	add	x2, sp, #0x98
     588:      	mov	w1, #0x8                // =8
     58c:      	blr	x9
     590:      	ldr	x8, [x29, #0x20]
     594:      	mov	x22, x24
     598:      	add	x8, x8, #0x40
     59c:      	str	x8, [sp, #0x30]
     5a0:      	b	0x60c <generic_tracepoint_process_event+0x60c>
     5a4:      	add	x8, x10, #0x40
     5a8:      	mov	w9, #0x8                // =8
     5ac:      	mov	w10, #0x4               // =4
     5b0:      	str	x8, [sp, #0x98]
     5b4:      	add	x11, sp, #0x100
     5b8:      	add	x0, sp, #0x100
     5bc:      	mov	w1, #0x8                // =8
     5c0:      	ldr	x2, [sp, #0x98]
     5c4:      	blr	x10
     5c8:      	add	x8, sp, #0xe0
     5cc:      	ldr	x8, [x8, #0x20]
     5d0:      	add	x8, x8, #0x40
     5d4:      	str	x8, [sp, #0x30]
     5d8:      	b	0x60c <generic_tracepoint_process_event+0x60c>
     5dc:      	mov	w8, #0x8                // =8
     5e0:      	mov	w9, #0x4                // =4
     5e4:      	add	x10, sp, #0xf0
     5e8:      	add	x11, sp, #0x98
     5ec:      	add	x0, sp, #0xf0
     5f0:      	add	x2, sp, #0x98
     5f4:      	mov	w1, #0x8                // =8
     5f8:      	blr	x9
     5fc:      	add	x8, sp, #0xe0
     600:      	ldr	x8, [x8, #0x10]
     604:      	str	x8, [sp, #0x30]
     608:      	cbz	x8, 0xb98 <generic_tracepoint_process_event+0xb98>
     60c:      	str	wzr, [sp, #0x84]
     610:      	adrp	x0, 0x0 <generic_tracepoint_process_event>
     614:      	mov	w8, #0x1                // =1
     618:      	add	x9, sp, #0x84
     61c:      	ldr	x0, [x0]
     620:      	add	x1, sp, #0x84
     624:      	blr	x8
     628:      	cbz	x0, 0x6c0 <generic_tracepoint_process_event+0x6c0>
     62c:      	add	x8, x0, #0x1, lsl #12   // =0x1000
     630:      	str	x22, [sp, #0x10]
     634:      	mov	x24, x0
     638:      	stp	x23, x8, [sp, #0x40]
     63c:      	mov	w8, #0x23               // =35
     640:      	blr	x8
     644:      	add	x2, x0, #0xb30
     648:      	mov	w25, #0x8               // =8
     64c:      	add	x8, sp, #0x88
     650:      	mov	w9, #0x4                // =4
     654:      	add	x0, sp, #0x88
     658:      	mov	w1, #0x8                // =8
     65c:      	mov	w29, #0x4               // =4
     660:      	blr	x9
     664:      	ldr	x8, [sp, #0x88]
     668:      	mov	w9, #0x4                // =4
     66c:      	add	x0, sp, #0x90
     670:      	mov	w1, #0x8                // =8
     674:      	str	x8, [sp, #0x8]
     678:      	add	x8, x8, #0x18
     67c:      	str	x8, [sp, #0x50]
     680:      	ldr	x8, [sp, #0x30]
     684:      	add	x2, x8, #0x8
     688:      	add	x8, sp, #0x90
     68c:      	str	x2, [sp, #0x18]
     690:      	blr	x9
     694:      	ldr	x23, [sp, #0x90]
     698:      	add	x22, sp, #0x98
     69c:      	add	x0, sp, #0x98
     6a0:      	mov	w1, #0x8                // =8
     6a4:      	add	x2, x23, #0x10
     6a8:      	blr	x29
     6ac:      	ldr	x8, [sp, #0x98]
     6b0:      	cbz	x8, 0x6c8 <generic_tracepoint_process_event+0x6c8>
     6b4:      	ldr	x9, [sp, #0x48]
     6b8:      	mov	w8, #0x1000             // =4096
     6bc:      	b	0x710 <generic_tracepoint_process_event+0x710>
     6c0:      	mov	x22, xzr
     6c4:      	b	0xe48 <generic_tracepoint_process_event+0xe48>
     6c8:      	add	x2, x23, #0x18
     6cc:      	mov	w8, #0x8                // =8
     6d0:      	mov	w9, #0x4                // =4
     6d4:      	add	x10, sp, #0x98
     6d8:      	add	x0, sp, #0x98
     6dc:      	mov	w1, #0x8                // =8
     6e0:      	blr	x9
     6e4:      	ldr	x8, [sp, #0x98]
     6e8:      	cmp	x8, x23
     6ec:      	b.eq	0x6b4 <generic_tracepoint_process_event+0x6b4>
     6f0:      	mov	w8, #0x2964             // =10596
     6f4:      	add	x9, x24, #0xff6
     6f8:      	strh	w8, [x24, #0xffe]
     6fc:      	adrp	x8, 0x0 <generic_tracepoint_process_event>
     700:      	add	x8, x8, #0x0
     704:      	ldr	x8, [x8]
     708:      	str	x8, [x9]
     70c:      	mov	w8, #0xff6              // =4086
     710:      	str	x9, [sp, #0x48]
     714:      	str	x9, [sp, #0xc8]
     718:      	ldr	x9, [sp, #0x8]
     71c:      	add	x10, sp, #0x98
     720:      	mov	w25, #0x8               // =8
     724:      	add	x0, sp, #0x98
     728:      	stp	xzr, xzr, [sp, #0x98]
     72c:      	mov	w1, #0x8                // =8
     730:      	add	x23, x22, #0x8
     734:      	add	x22, x10, #0x18
     738:      	mov	w29, #0x4               // =4
     73c:      	add	x2, x9, #0x20
     740:      	stp	x24, xzr, [sp, #0xa8]
     744:      	stp	xzr, xzr, [sp, #0xb8]
     748:      	str	w8, [sp, #0xd0]
     74c:      	mov	w8, #0x4                // =4
     750:      	add	x24, x10, #0x20
     754:      	strb	wzr, [sp, #0xd4]
     758:      	blr	x8
     75c:      	ldr	x2, [sp, #0x50]
     760:      	mov	w8, #0x4                // =4
     764:      	mov	x0, x23
     768:      	mov	w1, #0x8                // =8
     76c:      	blr	x8
     770:      	ldr	x2, [sp, #0x18]
     774:      	mov	w8, #0x4                // =4
     778:      	mov	x0, x22
     77c:      	mov	w1, #0x8                // =8
     780:      	str	x22, [sp, #0x50]
     784:      	blr	x8
     788:      	ldr	x2, [sp, #0x30]
     78c:      	mov	x0, x24
     790:      	mov	w1, #0x8                // =8
     794:      	blr	x29
     798:      	ldr	x8, [sp, #0xb8]
     79c:      	sub	x8, x8, #0x20
     7a0:      	str	x8, [sp, #0xc0]
     7a4:      	adrp	x8, 0x0 <generic_tracepoint_process_event>
     7a8:      	ldr	x8, [x8]
     7ac:      	ldrb	w8, [x8]
     7b0:      	cbz	w8, 0x960 <generic_tracepoint_process_event+0x960>
     7b4:      	mov	w23, #0x800             // =2048
     7b8:      	mov	w10, #0x8               // =8
     7bc:      	add	x22, sp, #0xe0
     7c0:      	ldp	x25, x2, [sp, #0xb0]
     7c4:      	ldp	x8, x9, [sp, #0x98]
     7c8:      	cmp	x25, x8
     7cc:      	ccmp	x2, x9, #0x0, eq
     7d0:      	b.eq	0xd40 <generic_tracepoint_process_event+0xd40>
     7d4:      	ldr	x29, [sp, #0xc0]
     7d8:      	mov	w8, #0x4                // =4
     7dc:      	add	x9, sp, #0xe0
     7e0:      	add	x0, sp, #0xe0
     7e4:      	mov	w1, #0x8                // =8
     7e8:      	blr	x8
     7ec:      	ldr	x8, [x22]
     7f0:      	mov	w21, #0x8               // =8
     7f4:      	add	x24, sp, #0xe0
     7f8:      	cmp	x25, x8
     7fc:      	b.eq	0x8fc <generic_tracepoint_process_event+0x8fc>
     800:      	add	x22, x25, #0x18
     804:      	mov	w8, #0x4                // =4
     808:      	add	x9, sp, #0x100
     80c:      	add	x0, sp, #0x100
     810:      	mov	w1, #0x8                // =8
     814:      	mov	x2, x22
     818:      	blr	x8
     81c:      	ldr	x8, [x24, #0x20]
     820:      	cmp	x8, x25
     824:      	b.eq	0x8fc <generic_tracepoint_process_event+0x8fc>
     828:      	mov	w8, #0x4                // =4
     82c:      	add	x9, sp, #0xe8
     830:      	add	x0, sp, #0xe8
     834:      	mov	w1, #0x8                // =8
     838:      	mov	x2, x22
     83c:      	blr	x8
     840:      	add	x2, x25, #0x20
     844:      	mov	w8, #0x4                // =4
     848:      	mov	w9, #0x10               // =16
     84c:      	add	x10, sp, #0xf0
     850:      	add	x0, sp, #0xf0
     854:      	mov	w1, #0x10               // =16
     858:      	blr	x8
     85c:      	ldr	w22, [sp, #0xf4]
     860:      	ldr	x8, [sp, #0xa8]
     864:      	adrp	x21, 0x0 <generic_tracepoint_process_event>
     868:      	ldr	x10, [sp, #0xc8]
     86c:      	sub	x12, x10, x8
     870:      	ldr	w25, [sp, #0xd0]
     874:      	subs	w10, w22, w25
     878:      	ldr	x9, [x24, #0x18]
     87c:      	csel	w10, wzr, w10, lo
     880:      	cmp	w25, w22
     884:      	csel	w11, w25, w22, lo
     888:      	cinc	w13, w11, hi
     88c:      	sub	w14, w25, w13
     890:      	subs	x12, x12, x13
     894:      	str	w14, [sp, #0xd0]
     898:      	ldr	x21, [x21]
     89c:      	b.lo	0xd48 <generic_tracepoint_process_event+0xd48>
     8a0:      	cmp	x12, #0xfff
     8a4:      	b.hi	0xd48 <generic_tracepoint_process_event+0xd48>
     8a8:      	cmp	w25, w22
     8ac:      	b.ls	0x8b8 <generic_tracepoint_process_event+0x8b8>
     8b0:      	mov	w13, #0x2f              // =47
     8b4:      	strb	w13, [x8, x12]
     8b8:      	add	x29, x8, x12
     8bc:      	cmp	w25, w22
     8c0:      	add	x2, x9, x10
     8c4:      	and	w1, w11, #0xff
     8c8:      	mov	w8, #0x4                // =4
     8cc:      	cinc	x0, x29, hi
     8d0:      	blr	x8
     8d4:      	cmp	w25, w22
     8d8:      	str	x29, [sp, #0xc8]
     8dc:      	b.ls	0xd48 <generic_tracepoint_process_event+0xd48>
     8e0:      	add	x22, sp, #0xe0
     8e4:      	mov	w10, #0x8               // =8
     8e8:      	ldr	x8, [x22, #0x8]
     8ec:      	str	x8, [sp, #0xb0]
     8f0:      	subs	w23, w23, #0x1
     8f4:      	b.ne	0x7c0 <generic_tracepoint_process_event+0x7c0>
     8f8:      	b	0xd48 <generic_tracepoint_process_event+0xd48>
     8fc:      	add	x2, x29, #0x10
     900:      	mov	w8, #0x4                // =4
     904:      	add	x9, sp, #0x100
     908:      	add	x0, sp, #0x100
     90c:      	mov	w1, #0x8                // =8
     910:      	blr	x8
     914:      	ldr	x8, [sp, #0xc0]
     918:      	ldr	x9, [x24, #0x20]
     91c:      	add	x22, sp, #0xe0
     920:      	cmp	x8, x9
     924:      	b.eq	0xc0c <generic_tracepoint_process_event+0xc0c>
     928:      	ldr	x0, [sp, #0x50]
     92c:      	add	x2, x29, #0x18
     930:      	mov	w8, #0x4                // =4
     934:      	mov	w1, #0x8                // =8
     938:      	blr	x8
     93c:      	ldr	x8, [x22, #0x20]
     940:      	adrp	x21, 0x0 <generic_tracepoint_process_event>
     944:      	mov	w10, #0x8               // =8
     948:      	add	x9, x8, #0x20
     94c:      	stp	x9, x8, [sp, #0xb8]
     950:      	ldr	x21, [x21]
     954:      	subs	w23, w23, #0x1
     958:      	b.ne	0x7c0 <generic_tracepoint_process_event+0x7c0>
     95c:      	b	0xd48 <generic_tracepoint_process_event+0xd48>
     960:      	mov	w23, #0x800             // =2048
     964:      	mov	w10, #0x8               // =8
     968:      	add	x22, sp, #0xe0
     96c:      	b	0x978 <generic_tracepoint_process_event+0x978>
     970:      	subs	w23, w23, #0x1
     974:      	b.eq	0xd48 <generic_tracepoint_process_event+0xd48>
     978:      	ldp	x25, x2, [sp, #0xb0]
     97c:      	ldp	x8, x9, [sp, #0x98]
     980:      	cmp	x25, x8
     984:      	ccmp	x2, x9, #0x0, eq
     988:      	b.eq	0xd40 <generic_tracepoint_process_event+0xd40>
     98c:      	ldr	x29, [sp, #0xc0]
     990:      	mov	w8, #0x4                // =4
     994:      	add	x9, sp, #0xe0
     998:      	add	x0, sp, #0xe0
     99c:      	mov	w1, #0x8                // =8
     9a0:      	blr	x8
     9a4:      	ldr	x8, [x22]
     9a8:      	mov	w19, #0x8               // =8
     9ac:      	add	x24, sp, #0xe0
     9b0:      	cmp	x25, x8
     9b4:      	b.eq	0xaa8 <generic_tracepoint_process_event+0xaa8>
     9b8:      	add	x22, x25, #0x18
     9bc:      	mov	w8, #0x4                // =4
     9c0:      	add	x9, sp, #0x100
     9c4:      	add	x0, sp, #0x100
     9c8:      	mov	w1, #0x8                // =8
     9cc:      	mov	x2, x22
     9d0:      	blr	x8
     9d4:      	ldr	x8, [x24, #0x20]
     9d8:      	cmp	x8, x25
     9dc:      	b.eq	0xaa8 <generic_tracepoint_process_event+0xaa8>
     9e0:      	mov	w8, #0x4                // =4
     9e4:      	add	x9, sp, #0xe8
     9e8:      	add	x0, sp, #0xe8
     9ec:      	mov	w1, #0x8                // =8
     9f0:      	mov	x2, x22
     9f4:      	blr	x8
     9f8:      	add	x2, x25, #0x20
     9fc:      	mov	w8, #0x4                // =4
     a00:      	mov	w9, #0x10               // =16
     a04:      	add	x10, sp, #0xf0
     a08:      	add	x0, sp, #0xf0
     a0c:      	mov	w1, #0x10               // =16
     a10:      	blr	x8
     a14:      	ldr	w22, [sp, #0xf4]
     a18:      	ldr	x8, [sp, #0xa8]
     a1c:      	ldr	x10, [sp, #0xc8]
     a20:      	sub	x12, x10, x8
     a24:      	ldr	w25, [sp, #0xd0]
     a28:      	subs	w10, w22, w25
     a2c:      	ldr	x9, [x24, #0x18]
     a30:      	ldr	x19, [sp, #0x38]
     a34:      	csel	w10, wzr, w10, lo
     a38:      	cmp	w25, w22
     a3c:      	csel	w11, w25, w22, lo
     a40:      	cinc	w13, w11, hi
     a44:      	sub	w14, w25, w13
     a48:      	subs	x12, x12, x13
     a4c:      	str	w14, [sp, #0xd0]
     a50:      	b.lo	0xd48 <generic_tracepoint_process_event+0xd48>
     a54:      	cmp	x12, #0xfff
     a58:      	b.hi	0xd48 <generic_tracepoint_process_event+0xd48>
     a5c:      	cmp	w25, w22
     a60:      	b.ls	0xa6c <generic_tracepoint_process_event+0xa6c>
     a64:      	mov	w13, #0x2f              // =47
     a68:      	strb	w13, [x8, x12]
     a6c:      	add	x29, x8, x12
     a70:      	cmp	w25, w22
     a74:      	add	x2, x9, x10
     a78:      	and	w1, w11, #0xff
     a7c:      	mov	w8, #0x4                // =4
     a80:      	cinc	x0, x29, hi
     a84:      	blr	x8
     a88:      	cmp	w25, w22
     a8c:      	str	x29, [sp, #0xc8]
     a90:      	b.ls	0xd48 <generic_tracepoint_process_event+0xd48>
     a94:      	add	x22, sp, #0xe0
     a98:      	mov	w10, #0x8               // =8
     a9c:      	ldr	x8, [x22, #0x8]
     aa0:      	str	x8, [sp, #0xb0]
     aa4:      	b	0x970 <generic_tracepoint_process_event+0x970>
     aa8:      	add	x2, x29, #0x10
     aac:      	mov	w8, #0x4                // =4
     ab0:      	add	x9, sp, #0x100
     ab4:      	add	x0, sp, #0x100
     ab8:      	mov	w1, #0x8                // =8
     abc:      	blr	x8
     ac0:      	ldr	x8, [sp, #0xc0]
     ac4:      	ldr	x9, [x24, #0x20]
     ac8:      	add	x22, sp, #0xe0
     acc:      	cmp	x8, x9
     ad0:      	b.eq	0xd3c <generic_tracepoint_process_event+0xd3c>
     ad4:      	ldr	x0, [sp, #0x50]
     ad8:      	add	x2, x29, #0x18
     adc:      	mov	w8, #0x4                // =4
     ae0:      	mov	w1, #0x8                // =8
     ae4:      	blr	x8
     ae8:      	ldr	x8, [x22, #0x20]
     aec:      	ldr	x19, [sp, #0x38]
     af0:      	mov	w10, #0x8               // =8
     af4:      	add	x9, x8, #0x20
     af8:      	stp	x9, x8, [sp, #0xb8]
     afc:      	b	0x970 <generic_tracepoint_process_event+0x970>
     b00:      	cmp	w24, #0x2c
     b04:      	b.hi	0xb98 <generic_tracepoint_process_event+0xb98>
     b08:      	mov	x9, #0x7cf2             // =31986
     b0c:      	mov	w8, #0x1                // =1
     b10:      	movk	x9, #0xf202, lsl #16
     b14:      	lsl	x8, x8, x24
     b18:      	movk	x9, #0x11c1, lsl #32
     b1c:      	tst	x8, x9
     b20:      	b.eq	0xb98 <generic_tracepoint_process_event+0xb98>
     b24:      	add	x8, sp, #0xe0
     b28:      	str	x22, [sp, #0x10]
     b2c:      	str	wzr, [sp, #0xe0]
     b30:      	add	x9, sp, #0xe0
     b34:      	add	x1, sp, #0xe0
     b38:      	mov	x0, x21
     b3c:      	str	x10, [x8, #0x8]
     b40:      	mov	w8, #0x1                // =1
     b44:      	blr	x8
     b48:      	mov	x22, xzr
     b4c:      	cbz	x0, 0x1f08 <generic_tracepoint_process_event+0x1f08>
     b50:      	ldr	x11, [sp, #0x28]
     b54:      	cmp	w24, #0x10
     b58:      	b.le	0xc20 <generic_tracepoint_process_event+0xc20>
     b5c:      	cmp	w24, #0x1e
     b60:      	b.le	0xe50 <generic_tracepoint_process_event+0xe50>
     b64:      	cmp	w24, #0x26
     b68:      	b.gt	0xf34 <generic_tracepoint_process_event+0xf34>
     b6c:      	sub	w8, w24, #0x1f
     b70:      	cmp	w8, #0x2
     b74:      	b.hs	0x1364 <generic_tracepoint_process_event+0x1364>
     b78:      	mov	w8, #0x1                // =1
     b7c:      	add	x9, sp, #0xe8
     b80:      	mov	w10, #0x4               // =4
     b84:      	ldr	x0, [sp, #0x20]
     b88:      	mov	w22, #0x4               // =4
     b8c:      	add	x2, sp, #0xe8
     b90:      	mov	w1, #0x1                // =1
     b94:      	b	0x1084 <generic_tracepoint_process_event+0x1084>
     b98:      	str	x22, [sp, #0x10]
     b9c:      	str	wzr, [sp, #0x88]
     ba0:      	mov	w8, #0x1                // =1
     ba4:      	add	x9, sp, #0x88
     ba8:      	add	x1, sp, #0x88
     bac:      	mov	x0, x21
     bb0:      	blr	x8
     bb4:      	mov	x22, xzr
     bb8:      	str	x23, [sp, #0x40]
     bbc:      	cbz	x0, 0x1aa8 <generic_tracepoint_process_event+0x1aa8>
     bc0:      	cmp	w24, #0x19
     bc4:      	b.gt	0xf00 <generic_tracepoint_process_event+0xf00>
     bc8:      	cmp	w24, #0x12
     bcc:      	b.le	0x1008 <generic_tracepoint_process_event+0x1008>
     bd0:      	cmp	w24, #0x14
     bd4:      	b.le	0x12b4 <generic_tracepoint_process_event+0x12b4>
     bd8:      	cmp	w24, #0x15
     bdc:      	b.eq	0x1964 <generic_tracepoint_process_event+0x1964>
     be0:      	cmp	w24, #0x16
     be4:      	b.eq	0x1904 <generic_tracepoint_process_event+0x1904>
     be8:      	ldr	x11, [sp, #0x28]
     bec:      	ldr	x9, [sp, #0x50]
     bf0:      	cmp	w24, #0x17
     bf4:      	mov	w10, #0x5ea0            // =24224
     bf8:      	b.ne	0x24c8 <generic_tracepoint_process_event+0x24c8>
     bfc:      	ldr	x8, [sp, #0x20]
     c00:      	mov	w22, #0x8               // =8
     c04:      	stp	w9, wzr, [x8]
     c08:      	b	0x24c8 <generic_tracepoint_process_event+0x24c8>
     c0c:      	mov	w8, #0x1                // =1
     c10:      	adrp	x21, 0x0 <generic_tracepoint_process_event>
     c14:      	strb	w8, [sp, #0xd4]
     c18:      	ldr	x21, [x21]
     c1c:      	b	0xd48 <generic_tracepoint_process_event+0xd48>
     c20:      	cmp	w24, #0x9
     c24:      	mov	w10, #0x5ea0            // =24224
     c28:      	b.gt	0xe80 <generic_tracepoint_process_event+0xe80>
     c2c:      	cmp	w24, #0x4
     c30:      	b.le	0x108c <generic_tracepoint_process_event+0x108c>
     c34:      	cmp	w24, #0x5
     c38:      	b.eq	0x150c <generic_tracepoint_process_event+0x150c>
     c3c:      	cmp	w24, #0x6
     c40:      	b.eq	0xee0 <generic_tracepoint_process_event+0xee0>
     c44:      	ldr	x11, [sp, #0x28]
     c48:      	cmp	w24, #0x7
     c4c:      	mov	w10, #0x5ea0            // =24224
     c50:      	b.ne	0x2bd8 <generic_tracepoint_process_event+0x2bd8>
     c54:      	add	x8, sp, #0xe0
     c58:      	str	x23, [sp, #0x40]
     c5c:      	ldr	x25, [sp, #0x20]
     c60:      	mov	x29, x0
     c64:      	mov	w24, #0x2               // =2
     c68:      	mov	w1, #0x2                // =2
     c6c:      	ldr	x23, [x8, #0x8]
     c70:      	mov	w8, #0x4                // =4
     c74:      	mov	w22, #0x4               // =4
     c78:      	str	x23, [x25, #0x28]
     c7c:      	add	x0, x25, #0x26
     c80:      	add	x2, x23, #0x10
     c84:      	blr	x8
     c88:      	add	x0, x25, #0x3a
     c8c:      	add	x2, x23, #0x12
     c90:      	mov	w8, #0x1                // =1
     c94:      	mov	w9, #0x4                // =4
     c98:      	mov	w1, #0x1                // =1
     c9c:      	blr	x9
     ca0:      	add	x0, x25, #0x38
     ca4:      	add	x2, x23, #0x21e
     ca8:      	mov	w8, #0x4                // =4
     cac:      	mov	w1, #0x2                // =2
     cb0:      	blr	x8
     cb4:      	add	x0, x25, #0x24
     cb8:      	add	x2, x23, #0x21c
     cbc:      	mov	w8, #0x4                // =4
     cc0:      	mov	w1, #0x2                // =2
     cc4:      	blr	x8
     cc8:      	add	x0, x25, #0x30
     ccc:      	add	x2, x23, #0x214
     cd0:      	mov	w8, #0x4                // =4
     cd4:      	mov	w1, #0x4                // =4
     cd8:      	blr	x8
     cdc:      	add	x0, x25, #0x34
     ce0:      	add	x2, x23, #0x210
     ce4:      	mov	w1, #0x4                // =4
     ce8:      	blr	x22
     cec:      	ldrh	w8, [x25, #0x26]
     cf0:      	mov	x22, x25
     cf4:      	stp	xzr, xzr, [x25]
     cf8:      	cmp	w8, #0xa
     cfc:      	str	xzr, [x25, #0x18]
     d00:      	str	xzr, [x22, #0x10]!
     d04:      	b.eq	0x1cac <generic_tracepoint_process_event+0x1cac>
     d08:      	cmp	w8, #0x2
     d0c:      	b.ne	0x1cd8 <generic_tracepoint_process_event+0x1cd8>
     d10:      	ldr	x0, [sp, #0x20]
     d14:      	add	x2, x23, #0x4
     d18:      	mov	w8, #0x4                // =4
     d1c:      	mov	w1, #0x4                // =4
     d20:      	mov	w24, #0x4               // =4
     d24:      	blr	x8
     d28:      	mov	x0, x22
     d2c:      	mov	w1, #0x4                // =4
     d30:      	mov	x2, x23
     d34:      	blr	x24
     d38:      	b	0x1cd8 <generic_tracepoint_process_event+0x1cd8>
     d3c:      	ldr	x19, [sp, #0x38]
     d40:      	mov	w8, #0x1                // =1
     d44:      	strb	w8, [sp, #0xd4]
     d48:      	ldr	x8, [sp, #0xc8]
     d4c:      	ldr	x2, [sp, #0x48]
     d50:      	cmp	x8, x2
     d54:      	b.eq	0xd88 <generic_tracepoint_process_event+0xd88>
     d58:      	ldrb	w9, [sp, #0xd4]
     d5c:      	mov	w11, #0x1000            // =4096
     d60:      	cmp	w9, #0x0
     d64:      	ldr	w9, [sp, #0xd0]
     d68:      	cset	w10, eq
     d6c:      	sub	w11, w11, w9
     d70:      	cmp	w9, #0x0
     d74:      	csel	w9, w11, w9, gt
     d78:      	cbz	x8, 0xe3c <generic_tracepoint_process_event+0xe3c>
     d7c:      	lsl	w23, w10, #1
     d80:      	mov	x2, x8
     d84:      	b	0xd90 <generic_tracepoint_process_event+0xd90>
     d88:      	mov	w23, wzr
     d8c:      	mov	w9, wzr
     d90:      	ldr	x29, [sp, #0x20]
     d94:      	and	w22, w9, #0xfff
     d98:      	mov	w8, #0x4                // =4
     d9c:      	mov	w24, #0x4               // =4
     da0:      	mov	w1, w22
     da4:      	add	x0, x29, #0x4
     da8:      	blr	x8
     dac:      	str	w22, [x29]
     db0:      	ldr	x2, [sp, #0x18]
     db4:      	mov	w25, #0x8               // =8
     db8:      	add	x8, sp, #0x98
     dbc:      	mov	w9, #0x4                // =4
     dc0:      	add	x0, sp, #0x98
     dc4:      	mov	w1, #0x8                // =8
     dc8:      	blr	x9
     dcc:      	ldr	x8, [sp, #0x98]
     dd0:      	add	x9, sp, #0xf0
     dd4:      	mov	w10, #0x4               // =4
     dd8:      	add	x0, sp, #0xf0
     ddc:      	mov	w1, #0x8                // =8
     de0:      	add	x8, x8, #0x30
     de4:      	ldr	x8, [sp, #0x98]
     de8:      	add	x2, x8, #0x30
     dec:      	blr	x10
     df0:      	add	x11, sp, #0xe0
     df4:      	mov	w9, #0x2                // =2
     df8:      	add	x10, sp, #0x100
     dfc:      	ldr	x8, [x11, #0x10]
     e00:      	add	x0, sp, #0x100
     e04:      	mov	w1, #0x2                // =2
     e08:      	ldr	x2, [x11, #0x10]
     e0c:      	blr	x24
     e10:      	add	x8, x29, x22
     e14:      	ldr	x24, [sp, #0x118]
     e18:      	ldr	x11, [sp, #0x28]
     e1c:      	add	w22, w22, #0xa
     e20:      	mov	w25, #0x5efc            // =24316
     e24:      	mov	w10, #0x5ea0            // =24224
     e28:      	str	w23, [x8, #0x4]
     e2c:      	ldr	x23, [sp, #0x40]
     e30:      	ldrh	w9, [sp, #0x100]
     e34:      	strh	w9, [x8, #0x8]
     e38:      	b	0x2bdc <generic_tracepoint_process_event+0x2bdc>
     e3c:      	ldr	x23, [sp, #0x40]
     e40:      	mov	x22, xzr
     e44:      	mov	w25, #0x5efc            // =24316
     e48:      	ldr	x24, [sp, #0x118]
     e4c:      	b	0x2be0 <generic_tracepoint_process_event+0x2be0>
     e50:      	cmp	w24, #0x1c
     e54:      	b.gt	0x1068 <generic_tracepoint_process_event+0x1068>
     e58:      	cmp	w24, #0x11
     e5c:      	str	x23, [sp, #0x40]
     e60:      	b.eq	0x1398 <generic_tracepoint_process_event+0x1398>
     e64:      	cmp	w24, #0x19
     e68:      	b.eq	0x144c <generic_tracepoint_process_event+0x144c>
     e6c:      	ldr	x23, [sp, #0x40]
     e70:      	cmp	w24, #0x1c
     e74:      	mov	w10, #0x5ea0            // =24224
     e78:      	b.eq	0x109c <generic_tracepoint_process_event+0x109c>
     e7c:      	b	0x2bd8 <generic_tracepoint_process_event+0x2bd8>
     e80:      	sub	w8, w24, #0xa
     e84:      	cmp	w8, #0x2
     e88:      	b.lo	0x109c <generic_tracepoint_process_event+0x109c>
     e8c:      	sub	w8, w24, #0xc
     e90:      	cmp	w8, #0x2
     e94:      	b.lo	0x10bc <generic_tracepoint_process_event+0x10bc>
     e98:      	cmp	w24, #0xe
     e9c:      	b.ne	0x2bd8 <generic_tracepoint_process_event+0x2bd8>
     ea0:      	mov	w22, #0x8               // =8
     ea4:      	add	x8, sp, #0x98
     ea8:      	add	x24, sp, #0xe8
     eac:      	mov	w9, #0x4                // =4
     eb0:      	add	x0, sp, #0x98
     eb4:      	add	x2, sp, #0xe8
     eb8:      	mov	w1, #0x8                // =8
     ebc:      	mov	x29, x23
     ec0:      	mov	w23, #0x4               // =4
     ec4:      	blr	x9
     ec8:      	ldr	x8, [sp, #0x98]
     ecc:      	add	x0, sp, #0xe8
     ed0:      	mov	w1, #0x8                // =8
     ed4:      	ldr	x2, [sp, #0x98]
     ed8:      	blr	x23
     edc:      	mov	x23, x29
     ee0:      	ldr	x24, [sp, #0x20]
     ee4:      	add	x8, sp, #0xe0
     ee8:      	mov	w9, #0x2d               // =45
     eec:      	mov	w1, #0x1001             // =4097
     ef0:      	ldr	x2, [x8, #0x8]
     ef4:      	mov	w8, #0x1001             // =4097
     ef8:      	add	x0, x24, #0x4
     efc:      	b	0x1694 <generic_tracepoint_process_event+0x1694>
     f00:      	ldr	x2, [sp, #0x50]
     f04:      	cmp	w24, #0x20
     f08:      	b.le	0x11f4 <generic_tracepoint_process_event+0x11f4>
     f0c:      	ldr	x23, [sp, #0x20]
     f10:      	sub	w8, w24, #0x21
     f14:      	cmp	w8, #0x4
     f18:      	b.hs	0x10dc <generic_tracepoint_process_event+0x10dc>
     f1c:      	mov	w22, #0x8               // =8
     f20:      	mov	w8, #0x4                // =4
     f24:      	mov	x0, x23
     f28:      	mov	w1, #0x8                // =8
     f2c:      	blr	x8
     f30:      	b	0x1aa8 <generic_tracepoint_process_event+0x1aa8>
     f34:      	cmp	w24, #0x27
     f38:      	b.eq	0x1674 <generic_tracepoint_process_event+0x1674>
     f3c:      	cmp	w24, #0x28
     f40:      	b.eq	0x16b0 <generic_tracepoint_process_event+0x16b0>
     f44:      	cmp	w24, #0x2c
     f48:      	mov	w10, #0x5ea0            // =24224
     f4c:      	b.ne	0x2bd8 <generic_tracepoint_process_event+0x2bd8>
     f50:      	ldr	x0, [sp, #0x20]
     f54:      	add	x8, sp, #0xe0
     f58:      	strb	wzr, [sp, #0x98]
     f5c:      	mov	w9, #0x4                // =4
     f60:      	mov	w1, #0x2                // =2
     f64:      	mov	x24, x23
     f68:      	ldr	x22, [x8, #0x8]
     f6c:      	mov	w8, #0x2                // =2
     f70:      	stp	xzr, xzr, [x0]
     f74:      	stp	xzr, xzr, [x0, #0x10]
     f78:      	mov	x2, x22
     f7c:      	stp	xzr, xzr, [x0, #0x20]
     f80:      	stp	xzr, xzr, [x0, #0x30]
     f84:      	stp	xzr, xzr, [x0, #0x40]
     f88:      	stp	xzr, xzr, [x0, #0x50]
     f8c:      	stp	xzr, xzr, [x0, #0x60]
     f90:      	blr	x9
     f94:      	tbnz	x0, #0x3f, 0x1f00 <generic_tracepoint_process_event+0x1f00>
     f98:      	add	x23, x22, #0x2
     f9c:      	mov	w8, #0x1                // =1
     fa0:      	mov	w9, #0x4                // =4
     fa4:      	add	x10, sp, #0x98
     fa8:      	add	x0, sp, #0x98
     fac:      	mov	w1, #0x1                // =1
     fb0:      	mov	x2, x23
     fb4:      	blr	x9
     fb8:      	tbnz	x0, #0x3f, 0x1f00 <generic_tracepoint_process_event+0x1f00>
     fbc:      	ldrb	w8, [sp, #0x98]
     fc0:      	ldr	x10, [sp, #0x20]
     fc4:      	cmp	w8, #0x0
     fc8:      	add	x0, x10, #0x4
     fcc:      	cset	w9, eq
     fd0:      	strb	w9, [x10, #0x2]
     fd4:      	cbz	w8, 0x1ed0 <generic_tracepoint_process_event+0x1ed0>
     fd8:      	mov	w8, #0x6c               // =108
     fdc:      	mov	w9, #0x2d               // =45
     fe0:      	mov	w1, #0x6c               // =108
     fe4:      	mov	x2, x23
     fe8:      	blr	x9
     fec:      	adrp	x21, 0x0 <generic_tracepoint_process_event>
     ff0:      	mov	w25, #0x5efc            // =24316
     ff4:      	ldr	x21, [x21]
     ff8:      	ldr	x19, [sp, #0x38]
     ffc:      	tbnz	w0, #0x1f, 0x1f00 <generic_tracepoint_process_event+0x1f00>
    1000:      	sub	w22, w0, #0x1
    1004:      	b	0x1ef8 <generic_tracepoint_process_event+0x1ef8>
    1008:      	ldr	x8, [sp, #0x48]
    100c:      	cmp	w24, #0x7
    1010:      	and	x8, x8, #0xffffffff
    1014:      	b.gt	0x1270 <generic_tracepoint_process_event+0x1270>
    1018:      	cmp	w24, #0x2
    101c:      	b.eq	0x1730 <generic_tracepoint_process_event+0x1730>
    1020:      	ldr	x11, [sp, #0x28]
    1024:      	cmp	w24, #0x3
    1028:      	mov	w10, #0x5ea0            // =24224
    102c:      	b.ne	0x24c8 <generic_tracepoint_process_event+0x24c8>
    1030:      	add	x24, x0, #0x90
    1034:      	and	w9, w8, #0xf
    1038:      	mov	x23, x0
    103c:      	add	x25, x24, x29
    1040:      	cmp	w9, #0x2
    1044:      	b.le	0x1e40 <generic_tracepoint_process_event+0x1e40>
    1048:      	cmp	w9, #0x3
    104c:      	b.eq	0x1fe4 <generic_tracepoint_process_event+0x1fe4>
    1050:      	cmp	w9, #0x4
    1054:      	b.eq	0x1fec <generic_tracepoint_process_event+0x1fec>
    1058:      	cmp	w9, #0x5
    105c:      	b.ne	0x203c <generic_tracepoint_process_event+0x203c>
    1060:      	mov	w9, #0x5e70             // =24176
    1064:      	b	0x1ff8 <generic_tracepoint_process_event+0x1ff8>
    1068:      	ldr	x0, [sp, #0x20]
    106c:      	mov	w8, #0x2                // =2
    1070:      	add	x9, sp, #0xe8
    1074:      	mov	w10, #0x4               // =4
    1078:      	mov	w22, #0x4               // =4
    107c:      	add	x2, sp, #0xe8
    1080:      	mov	w1, #0x2                // =2
    1084:      	blr	x10
    1088:      	b	0x1f08 <generic_tracepoint_process_event+0x1f08>
    108c:      	cmp	w24, #0x1
    1090:      	b.eq	0x10bc <generic_tracepoint_process_event+0x10bc>
    1094:      	cmp	w24, #0x4
    1098:      	b.ne	0x2bd8 <generic_tracepoint_process_event+0x2bd8>
    109c:      	ldr	x0, [sp, #0x20]
    10a0:      	mov	w22, #0x8               // =8
    10a4:      	mov	w8, #0x4                // =4
    10a8:      	add	x9, sp, #0xe8
    10ac:      	add	x2, sp, #0xe8
    10b0:      	mov	w1, #0x8                // =8
    10b4:      	blr	x8
    10b8:      	b	0x1f08 <generic_tracepoint_process_event+0x1f08>
    10bc:      	ldr	x0, [sp, #0x20]
    10c0:      	add	x8, sp, #0xe8
    10c4:      	mov	w9, #0x4                // =4
    10c8:      	add	x2, sp, #0xe8
    10cc:      	mov	w1, #0x4                // =4
    10d0:      	mov	w22, #0x4               // =4
    10d4:      	blr	x9
    10d8:      	b	0x1f08 <generic_tracepoint_process_event+0x1f08>
    10dc:      	cmp	w24, #0x2b
    10e0:      	b.eq	0x1a20 <generic_tracepoint_process_event+0x1a20>
    10e4:      	ldr	x11, [sp, #0x28]
    10e8:      	cmp	w24, #0x29
    10ec:      	mov	w10, #0x5ea0            // =24224
    10f0:      	b.ne	0x24c8 <generic_tracepoint_process_event+0x24c8>
    10f4:      	add	x2, x2, #0x18
    10f8:      	mov	w8, #0x8                // =8
    10fc:      	mov	w9, #0x4                // =4
    1100:      	add	x10, sp, #0x98
    1104:      	mov	x29, x0
    1108:      	add	x0, sp, #0x98
    110c:      	mov	w1, #0x8                // =8
    1110:      	blr	x9
    1114:      	ldr	x23, [sp, #0x98]
    1118:      	cbz	x23, 0x1f9c <generic_tracepoint_process_event+0x1f9c>
    111c:      	ldr	x25, [sp, #0x20]
    1120:      	add	x2, x23, #0x10
    1124:      	mov	w24, #0x2               // =2
    1128:      	mov	w8, #0x4                // =4
    112c:      	str	x23, [x25, #0x28]
    1130:      	add	x0, x25, #0x26
    1134:      	mov	w1, #0x2                // =2
    1138:      	mov	w22, #0x4               // =4
    113c:      	blr	x8
    1140:      	add	x0, x25, #0x3a
    1144:      	add	x2, x23, #0x12
    1148:      	mov	w8, #0x1                // =1
    114c:      	mov	w9, #0x4                // =4
    1150:      	mov	w1, #0x1                // =1
    1154:      	blr	x9
    1158:      	add	x0, x25, #0x38
    115c:      	add	x2, x23, #0x21e
    1160:      	mov	w8, #0x4                // =4
    1164:      	mov	w1, #0x2                // =2
    1168:      	blr	x8
    116c:      	add	x0, x25, #0x24
    1170:      	add	x2, x23, #0x21c
    1174:      	mov	w8, #0x4                // =4
    1178:      	mov	w1, #0x2                // =2
    117c:      	blr	x8
    1180:      	add	x0, x25, #0x30
    1184:      	add	x2, x23, #0x214
    1188:      	mov	w8, #0x4                // =4
    118c:      	mov	w1, #0x4                // =4
    1190:      	blr	x8
    1194:      	add	x0, x25, #0x34
    1198:      	add	x2, x23, #0x210
    119c:      	mov	w1, #0x4                // =4
    11a0:      	blr	x22
    11a4:      	ldrh	w8, [x25, #0x26]
    11a8:      	mov	x22, x25
    11ac:      	stp	xzr, xzr, [x25]
    11b0:      	cmp	w8, #0xa
    11b4:      	str	xzr, [x25, #0x18]
    11b8:      	str	xzr, [x22, #0x10]!
    11bc:      	b.eq	0x1f2c <generic_tracepoint_process_event+0x1f2c>
    11c0:      	cmp	w8, #0x2
    11c4:      	b.ne	0x1f58 <generic_tracepoint_process_event+0x1f58>
    11c8:      	ldr	x0, [sp, #0x20]
    11cc:      	add	x2, x23, #0x4
    11d0:      	mov	w8, #0x4                // =4
    11d4:      	mov	w1, #0x4                // =4
    11d8:      	mov	w24, #0x4               // =4
    11dc:      	blr	x8
    11e0:      	mov	x0, x22
    11e4:      	mov	w1, #0x4                // =4
    11e8:      	mov	x2, x23
    11ec:      	blr	x24
    11f0:      	b	0x1f58 <generic_tracepoint_process_event+0x1f58>
    11f4:      	cmp	w24, #0x1a
    11f8:      	b.eq	0x1ab4 <generic_tracepoint_process_event+0x1ab4>
    11fc:      	ldr	x11, [sp, #0x28]
    1200:      	cmp	w24, #0x1b
    1204:      	mov	w10, #0x5ea0            // =24224
    1208:      	b.ne	0x24c8 <generic_tracepoint_process_event+0x24c8>
    120c:      	ldr	x10, [sp, #0x20]
    1210:      	add	x2, x2, #0x18
    1214:      	mov	w8, #0x3f               // =63
    1218:      	mov	w9, #0x2d               // =45
    121c:      	stp	xzr, xzr, [x10, #0x40]
    1220:      	mov	x0, x10
    1224:      	stp	xzr, xzr, [x10, #0x30]
    1228:      	stp	xzr, xzr, [x10, #0x20]
    122c:      	str	xzr, [x10, #0x18]
    1230:      	stp	xzr, xzr, [x10]
    1234:      	mov	w1, #0x3f               // =63
    1238:      	mov	x23, x11
    123c:      	str	xzr, [x0, #0x10]!
    1240:      	blr	x9
    1244:      	tbnz	x0, #0x3f, 0x1ebc <generic_tracepoint_process_event+0x1ebc>
    1248:      	ldr	x8, [sp, #0x20]
    124c:      	mov	w9, #0x4                // =4
    1250:      	mov	w1, #0x8                // =8
    1254:      	add	x0, x8, #0x8
    1258:      	ldr	x8, [sp, #0x50]
    125c:      	add	x2, x8, #0x360
    1260:      	mov	w8, #0x8                // =8
    1264:      	blr	x9
    1268:      	mov	w22, #0x50              // =80
    126c:      	b	0x1ec0 <generic_tracepoint_process_event+0x1ec0>
    1270:      	cmp	w24, #0x8
    1274:      	b.eq	0x1780 <generic_tracepoint_process_event+0x1780>
    1278:      	ldr	x11, [sp, #0x28]
    127c:      	ldr	x2, [sp, #0x50]
    1280:      	cmp	w24, #0x12
    1284:      	mov	w25, #0x5efc            // =24316
    1288:      	mov	w10, #0x5ea0            // =24224
    128c:      	b.ne	0x24c8 <generic_tracepoint_process_event+0x24c8>
    1290:      	ldr	x0, [sp, #0x20]
    1294:      	and	x22, x8, #0x3ff
    1298:      	mov	w8, #0x4                // =4
    129c:      	mov	x23, x11
    12a0:      	mov	w1, w22
    12a4:      	blr	x8
    12a8:      	mov	x11, x23
    12ac:      	mov	w10, #0x5ea0            // =24224
    12b0:      	b	0x24c8 <generic_tracepoint_process_event+0x24c8>
    12b4:      	cmp	w24, #0x13
    12b8:      	b.eq	0x19dc <generic_tracepoint_process_event+0x19dc>
    12bc:      	ldr	x11, [sp, #0x28]
    12c0:      	ldr	x29, [sp, #0x50]
    12c4:      	cmp	w24, #0x14
    12c8:      	mov	w10, #0x5ea0            // =24224
    12cc:      	b.ne	0x24c8 <generic_tracepoint_process_event+0x24c8>
    12d0:      	str	xzr, [sp, #0x98]
    12d4:      	add	x2, x29, #0x110
    12d8:      	mov	w10, #0x8               // =8
    12dc:      	add	x8, sp, #0x98
    12e0:      	mov	w9, #0x4                // =4
    12e4:      	add	x0, sp, #0x98
    12e8:      	mov	w1, #0x8                // =8
    12ec:      	add	x22, x29, #0xd8
    12f0:      	mov	w23, #0x4               // =4
    12f4:      	blr	x9
    12f8:      	ldr	x8, [sp, #0x98]
    12fc:      	mov	w9, #0x80               // =128
    1300:      	mov	w10, #0x2d              // =45
    1304:      	ldr	x24, [sp, #0x20]
    1308:      	mov	w1, #0x80               // =128
    130c:      	mov	x0, x24
    1310:      	ldr	x2, [sp, #0x98]
    1314:      	blr	x10
    1318:      	add	x0, x24, #0x90
    131c:      	mov	w8, #0x4                // =4
    1320:      	mov	w1, #0x4                // =4
    1324:      	mov	x2, x22
    1328:      	blr	x8
    132c:      	add	x0, x24, #0x80
    1330:      	add	x2, x29, #0xe0
    1334:      	mov	w8, #0x4                // =4
    1338:      	mov	w22, #0x8               // =8
    133c:      	mov	w1, #0x8                // =8
    1340:      	blr	x8
    1344:      	add	x0, x24, #0x88
    1348:      	add	x2, x29, #0x118
    134c:      	mov	w1, #0x8                // =8
    1350:      	blr	x23
    1354:      	ldr	x11, [sp, #0x28]
    1358:      	mov	w10, #0x5ea0            // =24224
    135c:      	mov	w22, #0x98              // =152
    1360:      	b	0x24c8 <generic_tracepoint_process_event+0x24c8>
    1364:      	cmp	w24, #0x26
    1368:      	mov	w10, #0x5ea0            // =24224
    136c:      	b.ne	0x2bd8 <generic_tracepoint_process_event+0x2bd8>
    1370:      	add	x8, sp, #0xe0
    1374:      	ldr	x24, [sp, #0x20]
    1378:      	ldr	x8, [x8, #0x8]
    137c:      	add	x0, x24, #0x4
    1380:      	add	x2, x19, w8, uxth
    1384:      	ubfx	w8, w8, #16, #12
    1388:      	add	w1, w8, #0x1
    138c:      	mov	w8, #0x2d               // =45
    1390:      	blr	x8
    1394:      	b	0x1698 <generic_tracepoint_process_event+0x1698>
    1398:      	str	xzr, [sp, #0xa0]
    139c:      	mov	w8, #0xe                // =14
    13a0:      	blr	x8
    13a4:      	lsr	x8, x0, #32
    13a8:      	add	x9, sp, #0xf0
    13ac:      	add	x10, sp, #0xe8
    13b0:      	str	x8, [sp, #0x98]
    13b4:      	mov	w8, #0x4                // =4
    13b8:      	add	x0, sp, #0xf0
    13bc:      	add	x2, sp, #0xe8
    13c0:      	mov	w1, #0x4                // =4
    13c4:      	blr	x8
    13c8:      	ldr	w8, [sp, #0xf0]
    13cc:      	adrp	x0, 0x1000 <generic_tracepoint_process_event+0x1000>
    13d0:      	add	x9, sp, #0x98
    13d4:      	add	x1, sp, #0x98
    13d8:      	str	w8, [sp, #0xa0]
    13dc:      	mov	w8, #0x1                // =1
    13e0:      	ldr	x0, [x0]
    13e4:      	blr	x8
    13e8:      	cbz	x0, 0x1b90 <generic_tracepoint_process_event+0x1b90>
    13ec:      	ldr	x25, [sp, #0x20]
    13f0:      	ldr	w23, [x0]
    13f4:      	add	x8, sp, #0xf0
    13f8:      	mov	w9, #0x4                // =4
    13fc:      	add	x2, sp, #0xf0
    1400:      	mov	x22, x0
    1404:      	mov	w1, #0x4                // =4
    1408:      	mov	w24, #0x4               // =4
    140c:      	mov	x0, x25
    1410:      	blr	x9
    1414:      	and	x23, x23, #0xfff
    1418:      	add	x0, x25, #0x4
    141c:      	mov	w8, #0x4                // =4
    1420:      	mov	x2, x22
    1424:      	add	x1, x23, #0x4
    1428:      	blr	x8
    142c:      	add	w23, w23, #0x8
    1430:      	mov	w1, #0x4                // =4
    1434:      	add	x8, x23, x22
    1438:      	add	x0, x25, x23
    143c:      	sub	x2, x8, #0x4
    1440:      	blr	x24
    1444:      	add	x22, x23, #0x4
    1448:      	b	0x2bc0 <generic_tracepoint_process_event+0x2bc0>
    144c:      	add	x8, sp, #0xe0
    1450:      	mov	w9, #0x4                // =4
    1454:      	add	x10, sp, #0x90
    1458:      	ldr	x22, [x8, #0x8]
    145c:      	mov	w8, #0x1                // =1
    1460:      	mov	x23, x0
    1464:      	add	x0, sp, #0x90
    1468:      	mov	w1, #0x1                // =1
    146c:      	mov	x2, x22
    1470:      	blr	x9
    1474:      	ldrb	w8, [sp, #0x90]
    1478:      	cbz	w8, 0x1b98 <generic_tracepoint_process_event+0x1b98>
    147c:      	cmp	w8, #0x1
    1480:      	b.ne	0x1d64 <generic_tracepoint_process_event+0x1d64>
    1484:      	add	x2, x22, #0x10
    1488:      	mov	w22, #0x8               // =8
    148c:      	add	x8, sp, #0x98
    1490:      	mov	w9, #0x4                // =4
    1494:      	add	x0, sp, #0x98
    1498:      	mov	w1, #0x8                // =8
    149c:      	mov	w24, #0x4               // =4
    14a0:      	blr	x9
    14a4:      	ldr	x2, [sp, #0x98]
    14a8:      	add	x8, sp, #0xf0
    14ac:      	mov	w9, #0x4                // =4
    14b0:      	add	x0, sp, #0xf0
    14b4:      	mov	w1, #0x8                // =8
    14b8:      	blr	x9
    14bc:      	ldr	x8, [sp, #0x98]
    14c0:      	mov	w9, #0x4                // =4
    14c4:      	add	x0, sp, #0x100
    14c8:      	mov	w1, #0x8                // =8
    14cc:      	add	x2, x8, #0x8
    14d0:      	add	x8, sp, #0x100
    14d4:      	blr	x9
    14d8:      	add	x8, sp, #0xe0
    14dc:      	add	x23, x23, x29
    14e0:      	ldr	x25, [x8, #0x20]
    14e4:      	ldr	x2, [x8, #0x10]
    14e8:      	mov	w8, #0xfff              // =4095
    14ec:      	add	x0, x23, #0x98
    14f0:      	cmp	x25, #0xfff
    14f4:      	csel	x22, x25, x8, lo
    14f8:      	mov	w1, w22
    14fc:      	blr	x24
    1500:      	tbnz	w0, #0x1f, 0x1c0c <generic_tracepoint_process_event+0x1c0c>
    1504:      	stur	w25, [x23, #0x90]
    1508:      	b	0x1c00 <generic_tracepoint_process_event+0x1c00>
    150c:      	add	x8, sp, #0xe0
    1510:      	ldr	x22, [sp, #0x20]
    1514:      	str	x23, [sp, #0x40]
    1518:      	mov	w1, #0x4                // =4
    151c:      	mov	w23, #0x4               // =4
    1520:      	add	x0, x22, #0x28
    1524:      	ldr	x24, [x8, #0x8]
    1528:      	mov	w8, #0x4                // =4
    152c:      	add	x2, x24, #0x98
    1530:      	blr	x8
    1534:      	add	x0, x22, #0x2c
    1538:      	add	x2, x24, #0x70
    153c:      	mov	w8, #0x4                // =4
    1540:      	mov	w1, #0x4                // =4
    1544:      	blr	x8
    1548:      	add	x0, x22, #0x30
    154c:      	add	x2, x24, #0x90
    1550:      	mov	w8, #0x4                // =4
    1554:      	mov	w1, #0x4                // =4
    1558:      	blr	x8
    155c:      	add	x0, x22, #0x34
    1560:      	add	x2, x24, #0xa8
    1564:      	mov	w8, #0x4                // =4
    1568:      	mov	w1, #0x4                // =4
    156c:      	blr	x8
    1570:      	str	xzr, [sp, #0x98]
    1574:      	add	x2, x24, #0xc8
    1578:      	mov	w8, #0x8                // =8
    157c:      	add	x9, sp, #0x98
    1580:      	mov	w10, #0x4               // =4
    1584:      	add	x0, sp, #0x98
    1588:      	mov	w1, #0x8                // =8
    158c:      	blr	x10
    1590:      	str	x24, [sp, #0x50]
    1594:      	add	x2, x24, #0xb8
    1598:      	mov	w8, #0x2                // =2
    159c:      	add	x9, sp, #0x90
    15a0:      	mov	w10, #0x4               // =4
    15a4:      	add	x0, sp, #0x90
    15a8:      	mov	w1, #0x2                // =2
    15ac:      	blr	x10
    15b0:      	ldr	x8, [sp, #0x98]
    15b4:      	ldrh	w9, [sp, #0x90]
    15b8:      	add	x0, sp, #0xdc
    15bc:      	mov	w1, #0x1                // =1
    15c0:      	add	x22, x8, x9
    15c4:      	mov	w8, #0x1                // =1
    15c8:      	add	x9, sp, #0xdc
    15cc:      	mov	x2, x22
    15d0:      	blr	x23
    15d4:      	ldrb	w8, [sp, #0xdc]
    15d8:      	lsr	w8, w8, #4
    15dc:      	cmp	w8, #0x6
    15e0:      	b.eq	0x1c1c <generic_tracepoint_process_event+0x1c1c>
    15e4:      	cmp	w8, #0x4
    15e8:      	b.ne	0x2bbc <generic_tracepoint_process_event+0x2bbc>
    15ec:      	add	x2, x22, #0x9
    15f0:      	mov	w8, #0x1                // =1
    15f4:      	add	x9, sp, #0x84
    15f8:      	mov	w10, #0x4               // =4
    15fc:      	add	x0, sp, #0x84
    1600:      	mov	w1, #0x1                // =1
    1604:      	mov	w25, #0x4               // =4
    1608:      	blr	x10
    160c:      	ldr	x0, [sp, #0x20]
    1610:      	ldrb	w8, [sp, #0x84]
    1614:      	mov	w29, #0x2               // =2
    1618:      	add	x2, x22, #0xc
    161c:      	mov	w1, #0x4                // =4
    1620:      	mov	x23, x0
    1624:      	strh	w8, [x0, #0x24]
    1628:      	strh	w29, [x0, #0x26]
    162c:      	stp	xzr, xzr, [x0]
    1630:      	str	xzr, [x0, #0x18]
    1634:      	mov	w8, #0x4                // =4
    1638:      	str	xzr, [x23, #0x10]!
    163c:      	blr	x8
    1640:      	add	x2, x22, #0x10
    1644:      	mov	w8, #0x4                // =4
    1648:      	mov	x0, x23
    164c:      	mov	w1, #0x4                // =4
    1650:      	blr	x8
    1654:      	ldr	x8, [sp, #0x50]
    1658:      	add	x0, sp, #0x88
    165c:      	mov	w1, #0x2                // =2
    1660:      	add	x2, x8, #0xb6
    1664:      	add	x8, sp, #0x88
    1668:      	blr	x25
    166c:      	ldrb	w29, [sp, #0x84]
    1670:      	b	0x2a7c <generic_tracepoint_process_event+0x2a7c>
    1674:      	add	x8, sp, #0xe0
    1678:      	ldr	x24, [sp, #0x20]
    167c:      	mov	w9, #0x2d               // =45
    1680:      	mov	w1, #0x11               // =17
    1684:      	ldr	x8, [x8, #0x8]
    1688:      	add	x0, x24, #0x4
    168c:      	add	x2, x8, #0x118
    1690:      	mov	w8, #0x11               // =17
    1694:      	blr	x9
    1698:      	mov	x22, x0
    169c:      	tbnz	x0, #0x3f, 0x1f08 <generic_tracepoint_process_event+0x1f08>
    16a0:      	sub	w8, w22, #0x1
    16a4:      	add	x22, x22, #0x3
    16a8:      	str	w8, [x24]
    16ac:      	b	0x1f08 <generic_tracepoint_process_event+0x1f08>
    16b0:      	ldr	x29, [sp, #0x20]
    16b4:      	add	x8, sp, #0xe0
    16b8:      	mov	w9, #0x4                // =4
    16bc:      	mov	w1, #0x2                // =2
    16c0:      	ldr	x22, [x8, #0x8]
    16c4:      	mov	w8, #0x2                // =2
    16c8:      	str	xzr, [x29]
    16cc:      	stp	xzr, xzr, [x29, #0x8]
    16d0:      	mov	x0, x29
    16d4:      	mov	x2, x22
    16d8:      	blr	x9
    16dc:      	tbnz	x0, #0x3f, 0x1eb4 <generic_tracepoint_process_event+0x1eb4>
    16e0:      	ldrh	w8, [x29]
    16e4:      	mov	x24, x23
    16e8:      	cmp	w8, #0xa
    16ec:      	b.eq	0x1e58 <generic_tracepoint_process_event+0x1e58>
    16f0:      	cmp	w8, #0x2
    16f4:      	b.ne	0x1e8c <generic_tracepoint_process_event+0x1e8c>
    16f8:      	add	x2, x22, #0x4
    16fc:      	add	x8, sp, #0x98
    1700:      	mov	w9, #0x4                // =4
    1704:      	add	x0, sp, #0x98
    1708:      	mov	w1, #0x4                // =4
    170c:      	mov	w23, #0x4               // =4
    1710:      	blr	x9
    1714:      	ldr	w8, [sp, #0x98]
    1718:      	ldr	x9, [sp, #0x20]
    171c:      	add	x2, x22, #0x2
    1720:      	add	x0, x9, #0x2
    1724:      	str	x8, [x9, #0x8]
    1728:      	mov	w8, #0x2                // =2
    172c:      	b	0x1e84 <generic_tracepoint_process_event+0x1e84>
    1730:      	add	x8, x0, x29
    1734:      	mov	x22, x0
    1738:      	add	x24, x8, #0x90
    173c:      	add	x8, sp, #0xe0
    1740:      	str	xzr, [x8]
    1744:      	ldr	x8, [sp, #0x48]
    1748:      	tbnz	w8, #0x4, 0x1d74 <generic_tracepoint_process_event+0x1d74>
    174c:      	ldr	x9, [sp, #0x48]
    1750:      	mov	x8, xzr
    1754:      	and	w9, w9, #0xf
    1758:      	cmp	w9, #0x2
    175c:      	b.le	0x1f14 <generic_tracepoint_process_event+0x1f14>
    1760:      	cmp	w9, #0x3
    1764:      	b.eq	0x21b4 <generic_tracepoint_process_event+0x21b4>
    1768:      	cmp	w9, #0x4
    176c:      	b.eq	0x21bc <generic_tracepoint_process_event+0x21bc>
    1770:      	cmp	w9, #0x5
    1774:      	b.ne	0x21d0 <generic_tracepoint_process_event+0x21d0>
    1778:      	mov	w8, #0x5e70             // =24176
    177c:      	b	0x21c8 <generic_tracepoint_process_event+0x21c8>
    1780:      	ldr	x29, [sp, #0x20]
    1784:      	ldr	x24, [sp, #0x50]
    1788:      	mov	w1, #0x4                // =4
    178c:      	mov	w23, #0x4               // =4
    1790:      	add	x8, x29, #0x40
    1794:      	add	x2, x24, #0x8
    1798:      	mov	x0, x29
    179c:      	add	x22, x29, #0x28
    17a0:      	str	x8, [sp, #0x48]
    17a4:      	mov	w8, #0x4                // =4
    17a8:      	blr	x8
    17ac:      	add	x0, x29, #0x4
    17b0:      	add	x2, x24, #0xc
    17b4:      	mov	w8, #0x4                // =4
    17b8:      	mov	w1, #0x4                // =4
    17bc:      	blr	x8
    17c0:      	add	x0, x29, #0x10
    17c4:      	add	x2, x24, #0x18
    17c8:      	mov	w8, #0x4                // =4
    17cc:      	mov	w1, #0x4                // =4
    17d0:      	blr	x8
    17d4:      	add	x0, x29, #0x14
    17d8:      	add	x2, x24, #0x1c
    17dc:      	mov	w8, #0x4                // =4
    17e0:      	mov	w1, #0x4                // =4
    17e4:      	blr	x8
    17e8:      	add	x0, x29, #0x8
    17ec:      	add	x2, x24, #0x10
    17f0:      	mov	w8, #0x4                // =4
    17f4:      	mov	w1, #0x4                // =4
    17f8:      	blr	x8
    17fc:      	add	x0, x29, #0xc
    1800:      	add	x2, x24, #0x14
    1804:      	mov	w8, #0x4                // =4
    1808:      	mov	w1, #0x4                // =4
    180c:      	blr	x8
    1810:      	add	x0, x29, #0x18
    1814:      	add	x2, x24, #0x20
    1818:      	mov	w8, #0x4                // =4
    181c:      	mov	w1, #0x4                // =4
    1820:      	blr	x8
    1824:      	add	x0, x29, #0x1c
    1828:      	add	x2, x24, #0x24
    182c:      	mov	w8, #0x4                // =4
    1830:      	mov	w1, #0x4                // =4
    1834:      	blr	x8
    1838:      	str	wzr, [x29, #0x24]
    183c:      	add	x0, x29, #0x20
    1840:      	add	x2, x24, #0x28
    1844:      	mov	w8, #0x4                // =4
    1848:      	mov	w1, #0x4                // =4
    184c:      	blr	x8
    1850:      	add	x0, x29, #0x30
    1854:      	add	x2, x24, #0x40
    1858:      	mov	w25, #0x8               // =8
    185c:      	mov	w8, #0x4                // =4
    1860:      	mov	w1, #0x8                // =8
    1864:      	blr	x8
    1868:      	add	x0, x29, #0x38
    186c:      	add	x2, x24, #0x30
    1870:      	mov	w8, #0x4                // =4
    1874:      	mov	w1, #0x8                // =8
    1878:      	blr	x8
    187c:      	add	x2, x24, #0x38
    1880:      	mov	w8, #0x4                // =4
    1884:      	mov	x0, x22
    1888:      	mov	w1, #0x8                // =8
    188c:      	blr	x8
    1890:      	add	x2, x24, #0x90
    1894:      	add	x8, sp, #0x98
    1898:      	mov	w9, #0x4                // =4
    189c:      	add	x0, sp, #0x98
    18a0:      	mov	w1, #0x8                // =8
    18a4:      	blr	x9
    18a8:      	ldr	x22, [sp, #0x98]
    18ac:      	ldr	x0, [sp, #0x48]
    18b0:      	mov	w8, #0x4                // =4
    18b4:      	mov	w1, #0x4                // =4
    18b8:      	add	x2, x22, #0xc8
    18bc:      	blr	x8
    18c0:      	add	x0, x29, #0x44
    18c4:      	add	x2, x22, #0xcc
    18c8:      	mov	w8, #0x4                // =4
    18cc:      	mov	w1, #0x4                // =4
    18d0:      	blr	x8
    18d4:      	add	x0, x29, #0x48
    18d8:      	add	x2, x22, #0xd0
    18dc:      	mov	w8, #0x4                // =4
    18e0:      	mov	w1, #0x4                // =4
    18e4:      	blr	x8
    18e8:      	add	x0, x29, #0x4c
    18ec:      	add	x2, x22, #0x158
    18f0:      	mov	w1, #0x4                // =4
    18f4:      	blr	x23
    18f8:      	mov	w22, #0x50              // =80
    18fc:      	mov	w25, #0x5efc            // =24316
    1900:      	b	0x1aa8 <generic_tracepoint_process_event+0x1aa8>
    1904:      	ldr	x24, [sp, #0x50]
    1908:      	ldr	x23, [sp, #0x20]
    190c:      	mov	w8, #0x4                // =4
    1910:      	mov	w1, #0x4                // =4
    1914:      	mov	w22, #0x4               // =4
    1918:      	add	x2, x24, #0xc8
    191c:      	mov	x0, x23
    1920:      	blr	x8
    1924:      	add	x0, x23, #0x4
    1928:      	add	x2, x24, #0xcc
    192c:      	mov	w8, #0x4                // =4
    1930:      	mov	w1, #0x4                // =4
    1934:      	blr	x8
    1938:      	add	x0, x23, #0x8
    193c:      	add	x2, x24, #0xd0
    1940:      	mov	w8, #0x4                // =4
    1944:      	mov	w1, #0x4                // =4
    1948:      	blr	x8
    194c:      	add	x0, x23, #0xc
    1950:      	add	x2, x24, #0x158
    1954:      	mov	w1, #0x4                // =4
    1958:      	blr	x22
    195c:      	mov	w22, #0x10              // =16
    1960:      	b	0x1aa8 <generic_tracepoint_process_event+0x1aa8>
    1964:      	ldr	x24, [sp, #0x50]
    1968:      	ldr	x23, [sp, #0x20]
    196c:      	mov	w8, #0x4                // =4
    1970:      	mov	w1, #0x4                // =4
    1974:      	mov	w22, #0x4               // =4
    1978:      	add	x2, x24, #0x38
    197c:      	mov	x0, x23
    1980:      	blr	x8
    1984:      	add	x0, x23, #0x4
    1988:      	add	x2, x24, #0x3c
    198c:      	mov	w8, #0x4                // =4
    1990:      	mov	w1, #0x4                // =4
    1994:      	blr	x8
    1998:      	add	x0, x23, #0x8
    199c:      	add	x2, x24, #0x40
    19a0:      	mov	w8, #0x4                // =4
    19a4:      	mov	w1, #0x4                // =4
    19a8:      	blr	x8
    19ac:      	add	x0, x23, #0xc
    19b0:      	add	x2, x24, #0x44
    19b4:      	mov	w8, #0x4                // =4
    19b8:      	mov	w1, #0x4                // =4
    19bc:      	blr	x8
    19c0:      	add	x0, x23, #0x10
    19c4:      	add	x2, x24, #0x80
    19c8:      	mov	w8, #0x10               // =16
    19cc:      	mov	w1, #0x10               // =16
    19d0:      	blr	x22
    19d4:      	mov	w22, #0x20              // =32
    19d8:      	b	0x1aa8 <generic_tracepoint_process_event+0x1aa8>
    19dc:      	ldr	x23, [sp, #0x20]
    19e0:      	ldr	x24, [sp, #0x50]
    19e4:      	mov	w8, #0x4                // =4
    19e8:      	mov	w1, #0x4                // =4
    19ec:      	mov	w22, #0x4               // =4
    19f0:      	mov	x0, x23
    19f4:      	mov	x2, x24
    19f8:      	blr	x8
    19fc:      	add	x0, x23, #0x4
    1a00:      	add	x2, x24, #0x4
    1a04:      	mov	w8, #0x4                // =4
    1a08:      	mov	w1, #0x4                // =4
    1a0c:      	blr	x8
    1a10:      	add	x0, x23, #0x8
    1a14:      	add	x2, x24, #0x30
    1a18:      	mov	w8, #0x10               // =16
    1a1c:      	b	0x1a9c <generic_tracepoint_process_event+0x1a9c>
    1a20:      	mov	x24, x2
    1a24:      	add	x2, x2, #0x4
    1a28:      	add	x8, sp, #0x98
    1a2c:      	mov	w9, #0x4                // =4
    1a30:      	add	x0, sp, #0x98
    1a34:      	mov	w1, #0x4                // =4
    1a38:      	mov	w22, #0x4               // =4
    1a3c:      	blr	x9
    1a40:      	ldr	w8, [sp, #0x98]
    1a44:      	add	x2, x24, #0xc
    1a48:      	add	x0, sp, #0x98
    1a4c:      	mov	w1, #0x4                // =4
    1a50:      	str	w8, [x23]
    1a54:      	add	x8, sp, #0x98
    1a58:      	blr	x22
    1a5c:      	ldr	w8, [sp, #0x98]
    1a60:      	add	x2, x24, #0x50
    1a64:      	add	x9, sp, #0x98
    1a68:      	mov	w10, #0x2d              // =45
    1a6c:      	str	w8, [x23, #0x4]
    1a70:      	mov	w8, #0x8                // =8
    1a74:      	add	x0, sp, #0x98
    1a78:      	mov	w1, #0x8                // =8
    1a7c:      	mov	w22, #0x2d              // =45
    1a80:      	blr	x10
    1a84:      	ldr	x8, [sp, #0x98]
    1a88:      	add	x0, x23, #0x8
    1a8c:      	mov	w9, #0x10               // =16
    1a90:      	add	x8, x8, #0x3f8
    1a94:      	ldr	x8, [sp, #0x98]
    1a98:      	add	x2, x8, #0x3f8
    1a9c:      	mov	w1, #0x10               // =16
    1aa0:      	blr	x22
    1aa4:      	mov	w22, #0x18              // =24
    1aa8:      	ldr	x11, [sp, #0x28]
    1aac:      	mov	w10, #0x5ea0            // =24224
    1ab0:      	b	0x24c8 <generic_tracepoint_process_event+0x24c8>
    1ab4:      	ldr	x11, [sp, #0x20]
    1ab8:      	mov	w8, #0x8                // =8
    1abc:      	mov	w9, #0x4                // =4
    1ac0:      	add	x10, sp, #0x98
    1ac4:      	stp	xzr, xzr, [x11, #0x40]
    1ac8:      	add	x0, sp, #0x98
    1acc:      	stp	xzr, xzr, [x11, #0x30]
    1ad0:      	stp	xzr, xzr, [x11, #0x20]
    1ad4:      	mov	w1, #0x8                // =8
    1ad8:      	stp	xzr, xzr, [x11, #0x10]
    1adc:      	stp	xzr, xzr, [x11]
    1ae0:      	blr	x9
    1ae4:      	mov	x22, xzr
    1ae8:      	cbnz	x0, 0x24b0 <generic_tracepoint_process_event+0x24b0>
    1aec:      	ldr	x8, [sp, #0x20]
    1af0:      	mov	w9, #0x3f               // =63
    1af4:      	mov	w10, #0x2d              // =45
    1af8:      	mov	w1, #0x3f               // =63
    1afc:      	add	x0, x8, #0x10
    1b00:      	ldr	x8, [sp, #0x98]
    1b04:      	ldr	x2, [sp, #0x98]
    1b08:      	blr	x10
    1b0c:      	tbnz	x0, #0x3f, 0x2128 <generic_tracepoint_process_event+0x2128>
    1b10:      	ldr	x24, [sp, #0x50]
    1b14:      	mov	w22, #0x8               // =8
    1b18:      	add	x8, sp, #0xf0
    1b1c:      	mov	w9, #0x4                // =4
    1b20:      	add	x0, sp, #0xf0
    1b24:      	mov	w1, #0x8                // =8
    1b28:      	mov	w23, #0x4               // =4
    1b2c:      	add	x2, x24, #0x8
    1b30:      	blr	x9
    1b34:      	ldr	x8, [sp, #0x20]
    1b38:      	add	x10, sp, #0xe0
    1b3c:      	mov	w9, #0x4                // =4
    1b40:      	mov	w1, #0x8                // =8
    1b44:      	add	x0, x8, #0x8
    1b48:      	ldr	x8, [x10, #0x10]
    1b4c:      	add	x8, x8, #0x360
    1b50:      	ldr	x8, [x10, #0x10]
    1b54:      	add	x2, x8, #0x360
    1b58:      	blr	x9
    1b5c:      	add	x2, x24, #0x58
    1b60:      	add	x8, sp, #0xf0
    1b64:      	add	x0, sp, #0xf0
    1b68:      	mov	w1, #0x4                // =4
    1b6c:      	blr	x23
    1b70:      	cbnz	x0, 0x1b88 <generic_tracepoint_process_event+0x1b88>
    1b74:      	ldr	w8, [sp, #0xf0]
    1b78:      	ldr	x9, [sp, #0x20]
    1b7c:      	cmp	w8, #0x0
    1b80:      	cset	w8, ne
    1b84:      	str	w8, [x9]
    1b88:      	mov	w22, #0x50              // =80
    1b8c:      	b	0x24b0 <generic_tracepoint_process_event+0x24b0>
    1b90:      	mov	x22, #-0x1              // =-1
    1b94:      	b	0x2bc0 <generic_tracepoint_process_event+0x2bc0>
    1b98:      	add	x2, x22, #0x10
    1b9c:      	mov	w24, #0x8               // =8
    1ba0:      	add	x8, sp, #0xf0
    1ba4:      	mov	w9, #0x4                // =4
    1ba8:      	add	x0, sp, #0xf0
    1bac:      	mov	w1, #0x8                // =8
    1bb0:      	mov	w25, #0x4               // =4
    1bb4:      	blr	x9
    1bb8:      	add	x2, x22, #0x18
    1bbc:      	add	x8, sp, #0x100
    1bc0:      	mov	w9, #0x4                // =4
    1bc4:      	add	x0, sp, #0x100
    1bc8:      	mov	w1, #0x8                // =8
    1bcc:      	blr	x9
    1bd0:      	add	x8, sp, #0xe0
    1bd4:      	add	x23, x23, x29
    1bd8:      	ldr	x24, [x8, #0x20]
    1bdc:      	ldr	x2, [x8, #0x10]
    1be0:      	mov	w8, #0xfff              // =4095
    1be4:      	add	x0, x23, #0x98
    1be8:      	cmp	x24, #0xfff
    1bec:      	csel	x22, x24, x8, lo
    1bf0:      	mov	w1, w22
    1bf4:      	blr	x25
    1bf8:      	tbnz	w0, #0x1f, 0x1c0c <generic_tracepoint_process_event+0x1c0c>
    1bfc:      	stur	w24, [x23, #0x90]
    1c00:      	stur	w22, [x23, #0x94]
    1c04:      	add	x22, x22, #0x8
    1c08:      	b	0x2bc0 <generic_tracepoint_process_event+0x2bc0>
    1c0c:      	mov	w8, #-0x2               // =-2
    1c10:      	mov	w22, #0x4               // =4
    1c14:      	stur	w8, [x23, #0x90]
    1c18:      	b	0x2bc0 <generic_tracepoint_process_event+0x2bc0>
    1c1c:      	ldr	x24, [sp, #0x98]
    1c20:      	ldrh	w22, [sp, #0x90]
    1c24:      	adrp	x0, 0x1000 <generic_tracepoint_process_event+0x1000>
    1c28:      	add	x9, sp, #0xf0
    1c2c:      	add	x1, sp, #0xf0
    1c30:      	add	x8, x24, x22
    1c34:      	str	wzr, [sp, #0xf0]
    1c38:      	str	x8, [sp, #0x48]
    1c3c:      	mov	w8, #0x1                // =1
    1c40:      	ldr	x0, [x0]
    1c44:      	blr	x8
    1c48:      	cbz	x0, 0x2a34 <generic_tracepoint_process_event+0x2a34>
    1c4c:      	mov	w8, #0xff               // =255
    1c50:      	strh	w22, [x0]
    1c54:      	strb	wzr, [x0, #0x7]
    1c58:      	add	x22, x0, #0x6
    1c5c:      	mov	w9, #0x4                // =4
    1c60:      	mov	x23, x0
    1c64:      	strb	w8, [x0, #0x5]
    1c68:      	ldr	x8, [sp, #0x48]
    1c6c:      	mov	x0, x22
    1c70:      	mov	w1, #0x1                // =1
    1c74:      	add	x2, x8, #0x6
    1c78:      	mov	w8, #0x1                // =1
    1c7c:      	blr	x9
    1c80:      	tbnz	x0, #0x3f, 0x2a34 <generic_tracepoint_process_event+0x2a34>
    1c84:      	ldrb	w8, [x23, #0x5]
    1c88:      	cmp	w8, #0x32
    1c8c:      	b.gt	0x2130 <generic_tracepoint_process_event+0x2130>
    1c90:      	cbz	w8, 0x21a8 <generic_tracepoint_process_event+0x21a8>
    1c94:      	cmp	w8, #0x2b
    1c98:      	b.eq	0x21a8 <generic_tracepoint_process_event+0x21a8>
    1c9c:      	cmp	w8, #0x2c
    1ca0:      	b.ne	0x2590 <generic_tracepoint_process_event+0x2590>
    1ca4:      	mov	w8, #0x8                // =8
    1ca8:      	b	0x24dc <generic_tracepoint_process_event+0x24dc>
    1cac:      	ldr	x0, [sp, #0x20]
    1cb0:      	add	x2, x23, #0x48
    1cb4:      	mov	w24, #0x10              // =16
    1cb8:      	mov	w8, #0x4                // =4
    1cbc:      	mov	w1, #0x10               // =16
    1cc0:      	mov	w25, #0x4               // =4
    1cc4:      	blr	x8
    1cc8:      	add	x2, x23, #0x38
    1ccc:      	mov	x0, x22
    1cd0:      	mov	w1, #0x10               // =16
    1cd4:      	blr	x25
    1cd8:      	ldr	x25, [sp, #0x20]
    1cdc:      	add	x22, x23, #0xc
    1ce0:      	add	x2, x23, #0xe
    1ce4:      	mov	w23, #0x2               // =2
    1ce8:      	mov	w8, #0x4                // =4
    1cec:      	mov	w1, #0x2                // =2
    1cf0:      	mov	w24, #0x4               // =4
    1cf4:      	add	x0, x25, #0x20
    1cf8:      	blr	x8
    1cfc:      	add	x0, x25, #0x22
    1d00:      	mov	w1, #0x2                // =2
    1d04:      	mov	x2, x22
    1d08:      	blr	x24
    1d0c:      	ldrh	w8, [x25, #0x22]
    1d10:      	adrp	x0, 0x1000 <generic_tracepoint_process_event+0x1000>
    1d14:      	add	x9, sp, #0x98
    1d18:      	add	x1, sp, #0x98
    1d1c:      	rev	w8, w8
    1d20:      	lsr	w8, w8, #16
    1d24:      	strh	w8, [x25, #0x22]
    1d28:      	add	x8, sp, #0xe0
    1d2c:      	ldr	x8, [x8, #0x8]
    1d30:      	str	x8, [sp, #0x98]
    1d34:      	mov	w8, #0x1                // =1
    1d38:      	ldr	x0, [x0]
    1d3c:      	blr	x8
    1d40:      	cbz	x0, 0x2bbc <generic_tracepoint_process_event+0x2bbc>
    1d44:      	ldr	w8, [x0]
    1d48:      	mov	w22, #0x40              // =64
    1d4c:      	str	w8, [x29, #0x10]
    1d50:      	ldr	x8, [x0, #0x8]
    1d54:      	str	x8, [x29, #0x18]
    1d58:      	ldr	w8, [x0, #0x4]
    1d5c:      	str	w8, [x29, #0x7c]
    1d60:      	b	0x2bc0 <generic_tracepoint_process_event+0x2bc0>
    1d64:      	add	x8, x23, x29
    1d68:      	mov	w22, #0x8               // =8
    1d6c:      	str	xzr, [x8, #0x90]
    1d70:      	b	0x2bc0 <generic_tracepoint_process_event+0x2bc0>
    1d74:      	mov	w8, #0xe                // =14
    1d78:      	blr	x8
    1d7c:      	cmn	x0, #0x16
    1d80:      	b.ne	0x1da8 <generic_tracepoint_process_event+0x1da8>
    1d84:      	ldr	x8, [sp, #0x38]
    1d88:      	mov	w9, #0x4                // =4
    1d8c:      	add	x10, sp, #0x98
    1d90:      	add	x0, sp, #0x98
    1d94:      	mov	w1, #0x8                // =8
    1d98:      	add	x2, x8, #0xe8
    1d9c:      	mov	w8, #0x8                // =8
    1da0:      	blr	x9
    1da4:      	ldr	x0, [sp, #0x98]
    1da8:      	ldr	x10, [x22, #0x8]
    1dac:      	ldr	x9, [sp, #0x50]
    1db0:      	mov	x3, xzr
    1db4:      	add	x1, sp, #0xf0
    1db8:      	add	x2, sp, #0x98
    1dbc:      	ldr	x8, [x22, #0x60]
    1dc0:      	add	x22, sp, #0xe0
    1dc4:      	str	xzr, [sp, #0xa8]
    1dc8:      	stp	x10, x9, [sp, #0x98]
    1dcc:      	add	x9, sp, #0xe0
    1dd0:      	add	x10, sp, #0x98
    1dd4:      	stp	x8, x0, [x9, #0x10]
    1dd8:      	adrp	x0, 0x1000 <generic_tracepoint_process_event+0x1000>
    1ddc:      	mov	w8, #0x2                // =2
    1de0:      	add	x9, sp, #0xf0
    1de4:      	ldr	x0, [x0]
    1de8:      	blr	x8
    1dec:      	cbz	x0, 0x2174 <generic_tracepoint_process_event+0x2174>
    1df0:      	neg	w8, w0
    1df4:      	mov	w9, #0x1                // =1
    1df8:      	add	x1, sp, #0x100
    1dfc:      	strh	w8, [sp, #0x100]
    1e00:      	mov	w8, #0x5                // =5
    1e04:      	mov	w23, #0x1               // =1
    1e08:      	strh	w8, [sp, #0x102]
    1e0c:      	mov	x8, #0x46               // =70
    1e10:      	movk	x8, #0x2, lsl #32
    1e14:      	stur	x8, [x22, #0x24]
    1e18:      	adrp	x22, 0x1000 <generic_tracepoint_process_event+0x1000>
    1e1c:      	add	x8, sp, #0x100
    1e20:      	ldr	x22, [x22]
    1e24:      	mov	x0, x22
    1e28:      	blr	x9
    1e2c:      	cbz	x0, 0x2150 <generic_tracepoint_process_event+0x2150>
    1e30:      	ldr	w8, [x0]
    1e34:      	add	w8, w8, #0x1
    1e38:      	str	w8, [x0]
    1e3c:      	b	0x2174 <generic_tracepoint_process_event+0x2174>
    1e40:      	cmp	w9, #0x1
    1e44:      	b.eq	0x1ff4 <generic_tracepoint_process_event+0x1ff4>
    1e48:      	cmp	w9, #0x2
    1e4c:      	b.ne	0x203c <generic_tracepoint_process_event+0x203c>
    1e50:      	mov	w9, #0x5e58             // =24152
    1e54:      	b	0x1ff8 <generic_tracepoint_process_event+0x1ff8>
    1e58:      	ldr	x25, [sp, #0x20]
    1e5c:      	add	x2, x22, #0x8
    1e60:      	mov	w8, #0x10               // =16
    1e64:      	mov	w9, #0x4                // =4
    1e68:      	mov	w1, #0x10               // =16
    1e6c:      	mov	w23, #0x4               // =4
    1e70:      	add	x0, x25, #0x8
    1e74:      	blr	x9
    1e78:      	add	x0, x25, #0x2
    1e7c:      	add	x2, x22, #0x2
    1e80:      	mov	w8, #0x2                // =2
    1e84:      	mov	w1, #0x2                // =2
    1e88:      	blr	x23
    1e8c:      	ldr	x9, [sp, #0x20]
    1e90:      	adrp	x21, 0x1000 <generic_tracepoint_process_event+0x1000>
    1e94:      	mov	w25, #0x5efc            // =24316
    1e98:      	mov	x23, x24
    1e9c:      	ldrh	w8, [x9, #0x2]
    1ea0:      	rev	w8, w8
    1ea4:      	lsr	w8, w8, #16
    1ea8:      	strh	w8, [x9, #0x2]
    1eac:      	ldr	x21, [x21]
    1eb0:      	ldr	x19, [sp, #0x38]
    1eb4:      	mov	w22, #0x18              // =24
    1eb8:      	b	0x1f08 <generic_tracepoint_process_event+0x1f08>
    1ebc:      	mov	x22, xzr
    1ec0:      	mov	w25, #0x5efc            // =24316
    1ec4:      	mov	w10, #0x5ea0            // =24224
    1ec8:      	mov	x11, x23
    1ecc:      	b	0x24bc <generic_tracepoint_process_event+0x24bc>
    1ed0:      	add	x2, x22, #0x3
    1ed4:      	mov	w22, #0x6b              // =107
    1ed8:      	mov	w8, #0x71               // =113
    1edc:      	mov	w1, #0x6b               // =107
    1ee0:      	blr	x8
    1ee4:      	adrp	x21, 0x1000 <generic_tracepoint_process_event+0x1000>
    1ee8:      	mov	w25, #0x5efc            // =24316
    1eec:      	ldr	x21, [x21]
    1ef0:      	ldr	x19, [sp, #0x38]
    1ef4:      	tbnz	w0, #0x1f, 0x1f00 <generic_tracepoint_process_event+0x1f00>
    1ef8:      	ldr	x8, [sp, #0x20]
    1efc:      	strb	w22, [x8, #0x3]
    1f00:      	mov	w22, #0x70              // =112
    1f04:      	mov	x23, x24
    1f08:      	ldr	x11, [sp, #0x28]
    1f0c:      	mov	w10, #0x5ea0            // =24224
    1f10:      	b	0x2bd8 <generic_tracepoint_process_event+0x2bd8>
    1f14:      	cmp	w9, #0x1
    1f18:      	b.eq	0x21c4 <generic_tracepoint_process_event+0x21c4>
    1f1c:      	cmp	w9, #0x2
    1f20:      	b.ne	0x21d0 <generic_tracepoint_process_event+0x21d0>
    1f24:      	mov	w8, #0x5e58             // =24152
    1f28:      	b	0x21c8 <generic_tracepoint_process_event+0x21c8>
    1f2c:      	ldr	x0, [sp, #0x20]
    1f30:      	add	x2, x23, #0x48
    1f34:      	mov	w24, #0x10              // =16
    1f38:      	mov	w8, #0x4                // =4
    1f3c:      	mov	w1, #0x10               // =16
    1f40:      	mov	w25, #0x4               // =4
    1f44:      	blr	x8
    1f48:      	add	x2, x23, #0x38
    1f4c:      	mov	x0, x22
    1f50:      	mov	w1, #0x10               // =16
    1f54:      	blr	x25
    1f58:      	ldr	x25, [sp, #0x20]
    1f5c:      	add	x22, x23, #0xc
    1f60:      	add	x2, x23, #0xe
    1f64:      	mov	w23, #0x2               // =2
    1f68:      	mov	w8, #0x4                // =4
    1f6c:      	mov	w1, #0x2                // =2
    1f70:      	mov	w24, #0x4               // =4
    1f74:      	add	x0, x25, #0x20
    1f78:      	blr	x8
    1f7c:      	add	x0, x25, #0x22
    1f80:      	mov	w1, #0x2                // =2
    1f84:      	mov	x2, x22
    1f88:      	blr	x24
    1f8c:      	ldrh	w8, [x25, #0x22]
    1f90:      	rev	w8, w8
    1f94:      	lsr	w8, w8, #16
    1f98:      	strh	w8, [x25, #0x22]
    1f9c:      	ldr	x8, [sp, #0x20]
    1fa0:      	adrp	x0, 0x1000 <generic_tracepoint_process_event+0x1000>
    1fa4:      	add	x9, sp, #0x98
    1fa8:      	add	x1, sp, #0x98
    1fac:      	ldr	x8, [x8, #0x28]
    1fb0:      	str	x8, [sp, #0x98]
    1fb4:      	mov	w8, #0x1                // =1
    1fb8:      	ldr	x0, [x0]
    1fbc:      	blr	x8
    1fc0:      	cbz	x0, 0x1fdc <generic_tracepoint_process_event+0x1fdc>
    1fc4:      	ldr	w8, [x0]
    1fc8:      	str	w8, [x29, #0x10]
    1fcc:      	ldr	x8, [x0, #0x8]
    1fd0:      	str	x8, [x29, #0x18]
    1fd4:      	ldr	w8, [x0, #0x4]
    1fd8:      	str	w8, [x29, #0x7c]
    1fdc:      	mov	w22, #0x40              // =64
    1fe0:      	b	0x24b0 <generic_tracepoint_process_event+0x24b0>
    1fe4:      	mov	w9, #0x5e60             // =24160
    1fe8:      	b	0x1ff8 <generic_tracepoint_process_event+0x1ff8>
    1fec:      	mov	w9, #0x5e68             // =24168
    1ff0:      	b	0x1ff8 <generic_tracepoint_process_event+0x1ff8>
    1ff4:      	mov	w9, #0x5e50             // =24144
    1ff8:      	add	x9, x23, x9
    1ffc:      	ldr	x29, [x9]
    2000:      	tbnz	w8, #0x4, 0x2048 <generic_tracepoint_process_event+0x2048>
    2004:      	cbz	x29, 0x2118 <generic_tracepoint_process_event+0x2118>
    2008:      	ldr	x2, [sp, #0x50]
    200c:      	mov	w8, #0x10               // =16
    2010:      	mov	w9, #0x4                // =4
    2014:      	add	x10, sp, #0x98
    2018:      	add	x0, sp, #0x98
    201c:      	mov	w1, #0x10               // =16
    2020:      	blr	x9
    2024:      	tbnz	w0, #0x1f, 0x24a4 <generic_tracepoint_process_event+0x24a4>
    2028:      	ldr	x22, [sp, #0xa0]
    202c:      	cmp	x22, #0xffe
    2030:      	b.ls	0x2238 <generic_tracepoint_process_event+0x2238>
    2034:      	mov	w8, #-0x3               // =-3
    2038:      	b	0x24a8 <generic_tracepoint_process_event+0x24a8>
    203c:      	mov	x29, xzr
    2040:      	mov	x22, xzr
    2044:      	tbz	w8, #0x4, 0x211c <generic_tracepoint_process_event+0x211c>
    2048:      	mov	w8, #0xe                // =14
    204c:      	blr	x8
    2050:      	cmn	x0, #0x16
    2054:      	b.ne	0x207c <generic_tracepoint_process_event+0x207c>
    2058:      	ldr	x8, [sp, #0x38]
    205c:      	mov	w9, #0x4                // =4
    2060:      	add	x10, sp, #0x98
    2064:      	add	x0, sp, #0x98
    2068:      	mov	w1, #0x8                // =8
    206c:      	add	x2, x8, #0xe8
    2070:      	mov	w8, #0x8                // =8
    2074:      	blr	x9
    2078:      	ldr	x0, [sp, #0x98]
    207c:      	ldr	x10, [x23, #0x8]
    2080:      	ldr	x9, [sp, #0x50]
    2084:      	mov	x3, xzr
    2088:      	add	x1, sp, #0xf0
    208c:      	add	x2, sp, #0x98
    2090:      	add	x22, sp, #0xe0
    2094:      	ldr	x8, [x23, #0x60]
    2098:      	str	x29, [sp, #0xa8]
    209c:      	stp	x10, x9, [sp, #0x98]
    20a0:      	add	x9, sp, #0xe0
    20a4:      	add	x10, sp, #0x98
    20a8:      	stp	x8, x0, [x9, #0x10]
    20ac:      	adrp	x0, 0x2000 <generic_tracepoint_process_event+0x2000>
    20b0:      	mov	w8, #0x2                // =2
    20b4:      	add	x9, sp, #0xf0
    20b8:      	ldr	x0, [x0]
    20bc:      	blr	x8
    20c0:      	cbz	x0, 0x21a0 <generic_tracepoint_process_event+0x21a0>
    20c4:      	neg	w8, w0
    20c8:      	mov	w9, #0x1                // =1
    20cc:      	add	x1, sp, #0x100
    20d0:      	strh	w8, [sp, #0x100]
    20d4:      	mov	w8, #0x5                // =5
    20d8:      	mov	w23, #0x1               // =1
    20dc:      	strh	w8, [sp, #0x102]
    20e0:      	mov	x8, #0x57               // =87
    20e4:      	movk	x8, #0x2, lsl #32
    20e8:      	stur	x8, [x22, #0x24]
    20ec:      	adrp	x22, 0x2000 <generic_tracepoint_process_event+0x2000>
    20f0:      	add	x8, sp, #0x100
    20f4:      	ldr	x22, [x22]
    20f8:      	mov	x0, x22
    20fc:      	blr	x9
    2100:      	cbz	x0, 0x217c <generic_tracepoint_process_event+0x217c>
    2104:      	ldr	w8, [x0]
    2108:      	add	w8, w8, #0x1
    210c:      	str	w8, [x0]
    2110:      	mov	w8, #-0x4               // =-4
    2114:      	b	0x24a8 <generic_tracepoint_process_event+0x24a8>
    2118:      	mov	x22, xzr
    211c:      	stp	w22, w22, [x25]
    2120:      	add	x22, x22, #0x8
    2124:      	b	0x24b0 <generic_tracepoint_process_event+0x24b0>
    2128:      	mov	x22, xzr
    212c:      	b	0x24b0 <generic_tracepoint_process_event+0x24b0>
    2130:      	cmp	w8, #0x33
    2134:      	b.eq	0x24d0 <generic_tracepoint_process_event+0x24d0>
    2138:      	cmp	w8, #0x3c
    213c:      	b.eq	0x21a8 <generic_tracepoint_process_event+0x21a8>
    2140:      	cmp	w8, #0xff
    2144:      	b.ne	0x2590 <generic_tracepoint_process_event+0x2590>
    2148:      	mov	w8, #0x28               // =40
    214c:      	b	0x24dc <generic_tracepoint_process_event+0x24dc>
    2150:      	str	w23, [sp, #0x90]
    2154:      	mov	x3, xzr
    2158:      	mov	w8, #0x2                // =2
    215c:      	add	x9, sp, #0x100
    2160:      	add	x10, sp, #0x90
    2164:      	add	x1, sp, #0x100
    2168:      	add	x2, sp, #0x90
    216c:      	mov	x0, x22
    2170:      	blr	x8
    2174:      	mov	w8, #-0x4               // =-4
    2178:      	b	0x2230 <generic_tracepoint_process_event+0x2230>
    217c:      	str	w23, [sp, #0xe8]
    2180:      	mov	x3, xzr
    2184:      	mov	w8, #0x2                // =2
    2188:      	add	x9, sp, #0x100
    218c:      	add	x10, sp, #0xe8
    2190:      	add	x1, sp, #0x100
    2194:      	add	x2, sp, #0xe8
    2198:      	mov	x0, x22
    219c:      	blr	x8
    21a0:      	mov	w8, #-0x4               // =-4
    21a4:      	b	0x24a8 <generic_tracepoint_process_event+0x24a8>
    21a8:      	ldrb	w8, [x23, #0x7]
    21ac:      	lsl	w8, w8, #3
    21b0:      	b	0x24d8 <generic_tracepoint_process_event+0x24d8>
    21b4:      	mov	w8, #0x5e60             // =24160
    21b8:      	b	0x21c8 <generic_tracepoint_process_event+0x21c8>
    21bc:      	mov	w8, #0x5e68             // =24168
    21c0:      	b	0x21c8 <generic_tracepoint_process_event+0x21c8>
    21c4:      	mov	w8, #0x5e50             // =24144
    21c8:      	add	x8, x22, x8
    21cc:      	ldr	x8, [x8]
    21d0:      	add	x22, sp, #0xe0
    21d4:      	add	x9, sp, #0xe0
    21d8:      	add	x10, sp, #0xe8
    21dc:      	str	x8, [x22, #0x8]
    21e0:      	mov	w8, #0x8                // =8
    21e4:      	mov	w11, #0x4               // =4
    21e8:      	add	x0, sp, #0xe0
    21ec:      	add	x2, sp, #0xe8
    21f0:      	mov	w1, #0x8                // =8
    21f4:      	mov	w25, #0x4               // =4
    21f8:      	blr	x11
    21fc:      	ldr	x23, [x22]
    2200:      	mov	w8, #0xfff              // =4095
    2204:      	ldr	x2, [sp, #0x50]
    2208:      	add	x0, x24, #0x8
    220c:      	cmp	x23, #0xfff
    2210:      	csel	x22, x23, x8, lo
    2214:      	mov	w1, w22
    2218:      	blr	x25
    221c:      	tbnz	w0, #0x1f, 0x222c <generic_tracepoint_process_event+0x222c>
    2220:      	stp	w23, w22, [x24]
    2224:      	add	x22, x22, #0x8
    2228:      	b	0x24b0 <generic_tracepoint_process_event+0x24b0>
    222c:      	mov	w8, #-0x2               // =-2
    2230:      	str	w8, [x24]
    2234:      	b	0x24ac <generic_tracepoint_process_event+0x24ac>
    2238:      	ldr	x8, [sp, #0x118]
    223c:      	mov	w9, #0x4                // =4
    2240:      	mov	w1, w22
    2244:      	add	x23, x8, #0xc
    2248:      	and	x8, x23, #0x3fff
    224c:      	add	x0, x24, x8
    2250:      	ldr	x8, [sp, #0x98]
    2254:      	ldr	x2, [sp, #0x98]
    2258:      	blr	x9
    225c:      	tbnz	w0, #0x1f, 0x24a4 <generic_tracepoint_process_event+0x24a4>
    2260:      	cmp	x29, #0x1
    2264:      	b.eq	0x211c <generic_tracepoint_process_event+0x211c>
    2268:      	ldr	x8, [sp, #0x50]
    226c:      	mov	w9, #0x4                // =4
    2270:      	add	x10, sp, #0x98
    2274:      	add	x0, sp, #0x98
    2278:      	mov	w1, #0x10               // =16
    227c:      	add	x2, x8, #0x10
    2280:      	mov	w8, #0x10               // =16
    2284:      	blr	x9
    2288:      	tbnz	w0, #0x1f, 0x24a4 <generic_tracepoint_process_event+0x24a4>
    228c:      	ldr	x19, [sp, #0xa0]
    2290:      	cmp	x19, #0xffe
    2294:      	b.hi	0x2034 <generic_tracepoint_process_event+0x2034>
    2298:      	add	x23, x22, x23
    229c:      	mov	w9, #0x4                // =4
    22a0:      	mov	w1, w19
    22a4:      	and	x8, x23, #0x3fff
    22a8:      	add	x0, x24, x8
    22ac:      	ldr	x8, [sp, #0x98]
    22b0:      	ldr	x2, [sp, #0x98]
    22b4:      	blr	x9
    22b8:      	tbnz	w0, #0x1f, 0x24a4 <generic_tracepoint_process_event+0x24a4>
    22bc:      	add	x22, x19, x22
    22c0:      	cmp	x29, #0x3
    22c4:      	b.lo	0x211c <generic_tracepoint_process_event+0x211c>
    22c8:      	ldr	x8, [sp, #0x50]
    22cc:      	mov	w9, #0x4                // =4
    22d0:      	add	x10, sp, #0x98
    22d4:      	add	x0, sp, #0x98
    22d8:      	mov	w1, #0x10               // =16
    22dc:      	add	x2, x8, #0x20
    22e0:      	mov	w8, #0x10               // =16
    22e4:      	blr	x9
    22e8:      	tbnz	w0, #0x1f, 0x24a4 <generic_tracepoint_process_event+0x24a4>
    22ec:      	ldr	x21, [sp, #0xa0]
    22f0:      	cmp	x21, #0xffe
    22f4:      	b.hi	0x2034 <generic_tracepoint_process_event+0x2034>
    22f8:      	add	x23, x19, x23
    22fc:      	mov	w9, #0x4                // =4
    2300:      	mov	w1, w21
    2304:      	and	x8, x23, #0x3fff
    2308:      	add	x0, x24, x8
    230c:      	ldr	x8, [sp, #0x98]
    2310:      	ldr	x2, [sp, #0x98]
    2314:      	blr	x9
    2318:      	tbnz	w0, #0x1f, 0x24a4 <generic_tracepoint_process_event+0x24a4>
    231c:      	add	x22, x21, x22
    2320:      	cmp	x29, #0x3
    2324:      	b.eq	0x211c <generic_tracepoint_process_event+0x211c>
    2328:      	ldr	x8, [sp, #0x50]
    232c:      	mov	w9, #0x4                // =4
    2330:      	add	x10, sp, #0x98
    2334:      	add	x0, sp, #0x98
    2338:      	mov	w1, #0x10               // =16
    233c:      	add	x2, x8, #0x30
    2340:      	mov	w8, #0x10               // =16
    2344:      	blr	x9
    2348:      	tbnz	w0, #0x1f, 0x24a4 <generic_tracepoint_process_event+0x24a4>
    234c:      	ldr	x19, [sp, #0xa0]
    2350:      	cmp	x19, #0xffe
    2354:      	b.hi	0x2034 <generic_tracepoint_process_event+0x2034>
    2358:      	add	x23, x21, x23
    235c:      	mov	w9, #0x4                // =4
    2360:      	mov	w1, w19
    2364:      	and	x8, x23, #0x3fff
    2368:      	add	x0, x24, x8
    236c:      	ldr	x8, [sp, #0x98]
    2370:      	ldr	x2, [sp, #0x98]
    2374:      	blr	x9
    2378:      	tbnz	w0, #0x1f, 0x24a4 <generic_tracepoint_process_event+0x24a4>
    237c:      	add	x22, x19, x22
    2380:      	cmp	x29, #0x5
    2384:      	b.lo	0x211c <generic_tracepoint_process_event+0x211c>
    2388:      	ldr	x8, [sp, #0x50]
    238c:      	mov	w9, #0x4                // =4
    2390:      	add	x10, sp, #0x98
    2394:      	add	x0, sp, #0x98
    2398:      	mov	w1, #0x10               // =16
    239c:      	add	x2, x8, #0x40
    23a0:      	mov	w8, #0x10               // =16
    23a4:      	blr	x9
    23a8:      	tbnz	w0, #0x1f, 0x24a4 <generic_tracepoint_process_event+0x24a4>
    23ac:      	ldr	x21, [sp, #0xa0]
    23b0:      	cmp	x21, #0xffe
    23b4:      	b.hi	0x2034 <generic_tracepoint_process_event+0x2034>
    23b8:      	add	x23, x19, x23
    23bc:      	mov	w9, #0x4                // =4
    23c0:      	mov	w1, w21
    23c4:      	and	x8, x23, #0x3fff
    23c8:      	add	x0, x24, x8
    23cc:      	ldr	x8, [sp, #0x98]
    23d0:      	ldr	x2, [sp, #0x98]
    23d4:      	blr	x9
    23d8:      	tbnz	w0, #0x1f, 0x24a4 <generic_tracepoint_process_event+0x24a4>
    23dc:      	add	x22, x21, x22
    23e0:      	cmp	x29, #0x5
    23e4:      	b.eq	0x211c <generic_tracepoint_process_event+0x211c>
    23e8:      	ldr	x8, [sp, #0x50]
    23ec:      	mov	w9, #0x4                // =4
    23f0:      	add	x10, sp, #0x98
    23f4:      	add	x0, sp, #0x98
    23f8:      	mov	w1, #0x10               // =16
    23fc:      	add	x2, x8, #0x50
    2400:      	mov	w8, #0x10               // =16
    2404:      	blr	x9
    2408:      	tbnz	w0, #0x1f, 0x24a4 <generic_tracepoint_process_event+0x24a4>
    240c:      	ldr	x19, [sp, #0xa0]
    2410:      	cmp	x19, #0xffe
    2414:      	b.hi	0x2034 <generic_tracepoint_process_event+0x2034>
    2418:      	add	x23, x21, x23
    241c:      	mov	w9, #0x4                // =4
    2420:      	mov	w1, w19
    2424:      	and	x8, x23, #0x3fff
    2428:      	add	x0, x24, x8
    242c:      	ldr	x8, [sp, #0x98]
    2430:      	ldr	x2, [sp, #0x98]
    2434:      	blr	x9
    2438:      	tbnz	w0, #0x1f, 0x24a4 <generic_tracepoint_process_event+0x24a4>
    243c:      	add	x22, x19, x22
    2440:      	cmp	x29, #0x7
    2444:      	b.lo	0x211c <generic_tracepoint_process_event+0x211c>
    2448:      	ldr	x8, [sp, #0x50]
    244c:      	mov	w9, #0x4                // =4
    2450:      	add	x10, sp, #0x98
    2454:      	add	x0, sp, #0x98
    2458:      	mov	w1, #0x10               // =16
    245c:      	add	x2, x8, #0x60
    2460:      	mov	w8, #0x10               // =16
    2464:      	blr	x9
    2468:      	tbnz	w0, #0x1f, 0x24a4 <generic_tracepoint_process_event+0x24a4>
    246c:      	ldr	x29, [sp, #0xa0]
    2470:      	cmp	x29, #0xffe
    2474:      	b.hi	0x2034 <generic_tracepoint_process_event+0x2034>
    2478:      	add	x8, x19, x23
    247c:      	mov	w9, #0x4                // =4
    2480:      	mov	w1, w29
    2484:      	and	x8, x8, #0x3fff
    2488:      	add	x0, x24, x8
    248c:      	ldr	x8, [sp, #0x98]
    2490:      	ldr	x2, [sp, #0x98]
    2494:      	blr	x9
    2498:      	tbnz	w0, #0x1f, 0x24a4 <generic_tracepoint_process_event+0x24a4>
    249c:      	add	x22, x29, x22
    24a0:      	b	0x211c <generic_tracepoint_process_event+0x211c>
    24a4:      	mov	w8, #-0x2               // =-2
    24a8:      	str	w8, [x25]
    24ac:      	mov	w22, #0x4               // =4
    24b0:      	ldr	x11, [sp, #0x28]
    24b4:      	mov	w25, #0x5efc            // =24316
    24b8:      	mov	w10, #0x5ea0            // =24224
    24bc:      	adrp	x21, 0x2000 <generic_tracepoint_process_event+0x2000>
    24c0:      	ldr	x21, [x21]
    24c4:      	ldr	x19, [sp, #0x38]
    24c8:      	ldr	x23, [sp, #0x40]
    24cc:      	b	0x2bd8 <generic_tracepoint_process_event+0x2bd8>
    24d0:      	ldrb	w8, [x23, #0x7]
    24d4:      	lsl	w8, w8, #2
    24d8:      	add	w8, w8, #0x8
    24dc:      	strh	w8, [x23, #0x2]
    24e0:      	ldrh	w9, [x23]
    24e4:      	ldrb	w29, [x23, #0x6]
    24e8:      	add	w8, w9, w8
    24ec:      	cmp	w29, #0x3c
    24f0:      	strh	w8, [x23]
    24f4:      	b.hi	0x25ac <generic_tracepoint_process_event+0x25ac>
    24f8:      	mov	x25, #0x1               // =1
    24fc:      	mov	w9, #0x1                // =1
    2500:      	movk	x25, #0x1800, lsl #32
    2504:      	lsl	x9, x9, x29
    2508:      	movk	x25, #0x1008, lsl #48
    250c:      	tst	x9, x25
    2510:      	b.eq	0x25ac <generic_tracepoint_process_event+0x25ac>
    2514:      	strb	w29, [x23, #0x5]
    2518:      	add	x8, x24, w8, uxth
    251c:      	mov	w9, #0x2                // =2
    2520:      	mov	w10, #0x4               // =4
    2524:      	mov	x0, x22
    2528:      	mov	w1, #0x2                // =2
    252c:      	ldrh	w8, [x23]
    2530:      	add	x2, x24, x8
    2534:      	blr	x10
    2538:      	tbnz	x0, #0x3f, 0x2a34 <generic_tracepoint_process_event+0x2a34>
    253c:      	ldrb	w8, [x23, #0x5]
    2540:      	cmp	w8, #0x32
    2544:      	b.gt	0x2564 <generic_tracepoint_process_event+0x2564>
    2548:      	cbz	w8, 0x2584 <generic_tracepoint_process_event+0x2584>
    254c:      	cmp	w8, #0x2b
    2550:      	b.eq	0x2584 <generic_tracepoint_process_event+0x2584>
    2554:      	cmp	w8, #0x2c
    2558:      	b.ne	0x2668 <generic_tracepoint_process_event+0x2668>
    255c:      	mov	w8, #0x8                // =8
    2560:      	b	0x25c0 <generic_tracepoint_process_event+0x25c0>
    2564:      	cmp	w8, #0x33
    2568:      	b.eq	0x25b4 <generic_tracepoint_process_event+0x25b4>
    256c:      	cmp	w8, #0x3c
    2570:      	b.eq	0x2584 <generic_tracepoint_process_event+0x2584>
    2574:      	cmp	w8, #0xff
    2578:      	b.ne	0x2668 <generic_tracepoint_process_event+0x2668>
    257c:      	mov	w8, #0x28               // =40
    2580:      	b	0x25c0 <generic_tracepoint_process_event+0x25c0>
    2584:      	ldrb	w8, [x23, #0x7]
    2588:      	lsl	w8, w8, #3
    258c:      	b	0x25bc <generic_tracepoint_process_event+0x25bc>
    2590:      	ldrh	w8, [x23, #0x2]
    2594:      	ldrh	w9, [x23]
    2598:      	ldrb	w29, [x23, #0x6]
    259c:      	add	w8, w9, w8
    25a0:      	cmp	w29, #0x3c
    25a4:      	strh	w8, [x23]
    25a8:      	b.ls	0x24f8 <generic_tracepoint_process_event+0x24f8>
    25ac:      	strh	w8, [sp, #0x88]
    25b0:      	b	0x2a38 <generic_tracepoint_process_event+0x2a38>
    25b4:      	ldrb	w8, [x23, #0x7]
    25b8:      	lsl	w8, w8, #2
    25bc:      	add	w8, w8, #0x8
    25c0:      	strh	w8, [x23, #0x2]
    25c4:      	ldrh	w9, [x23]
    25c8:      	ldrb	w29, [x23, #0x6]
    25cc:      	add	w8, w9, w8
    25d0:      	cmp	w29, #0x3c
    25d4:      	strh	w8, [x23]
    25d8:      	b.hi	0x2c34 <generic_tracepoint_process_event+0x2c34>
    25dc:      	mov	w9, #0x1                // =1
    25e0:      	lsl	x9, x9, x29
    25e4:      	tst	x9, x25
    25e8:      	b.eq	0x2c34 <generic_tracepoint_process_event+0x2c34>
    25ec:      	strb	w29, [x23, #0x5]
    25f0:      	add	x8, x24, w8, uxth
    25f4:      	mov	w9, #0x2                // =2
    25f8:      	mov	w10, #0x4               // =4
    25fc:      	mov	x0, x22
    2600:      	mov	w1, #0x2                // =2
    2604:      	ldrh	w8, [x23]
    2608:      	add	x2, x24, x8
    260c:      	blr	x10
    2610:      	tbnz	x0, #0x3f, 0x2a34 <generic_tracepoint_process_event+0x2a34>
    2614:      	ldrb	w8, [x23, #0x5]
    2618:      	cmp	w8, #0x32
    261c:      	b.gt	0x263c <generic_tracepoint_process_event+0x263c>
    2620:      	cbz	w8, 0x265c <generic_tracepoint_process_event+0x265c>
    2624:      	cmp	w8, #0x2b
    2628:      	b.eq	0x265c <generic_tracepoint_process_event+0x265c>
    262c:      	cmp	w8, #0x2c
    2630:      	b.ne	0x273c <generic_tracepoint_process_event+0x273c>
    2634:      	mov	w8, #0x8                // =8
    2638:      	b	0x2694 <generic_tracepoint_process_event+0x2694>
    263c:      	cmp	w8, #0x33
    2640:      	b.eq	0x2688 <generic_tracepoint_process_event+0x2688>
    2644:      	cmp	w8, #0x3c
    2648:      	b.eq	0x265c <generic_tracepoint_process_event+0x265c>
    264c:      	cmp	w8, #0xff
    2650:      	b.ne	0x273c <generic_tracepoint_process_event+0x273c>
    2654:      	mov	w8, #0x28               // =40
    2658:      	b	0x2694 <generic_tracepoint_process_event+0x2694>
    265c:      	ldrb	w8, [x23, #0x7]
    2660:      	lsl	w8, w8, #3
    2664:      	b	0x2690 <generic_tracepoint_process_event+0x2690>
    2668:      	ldrh	w8, [x23, #0x2]
    266c:      	ldrh	w9, [x23]
    2670:      	ldrb	w29, [x23, #0x6]
    2674:      	add	w8, w9, w8
    2678:      	cmp	w29, #0x3c
    267c:      	strh	w8, [x23]
    2680:      	b.ls	0x25dc <generic_tracepoint_process_event+0x25dc>
    2684:      	b	0x2c34 <generic_tracepoint_process_event+0x2c34>
    2688:      	ldrb	w8, [x23, #0x7]
    268c:      	lsl	w8, w8, #2
    2690:      	add	w8, w8, #0x8
    2694:      	strh	w8, [x23, #0x2]
    2698:      	ldrh	w9, [x23]
    269c:      	ldrb	w29, [x23, #0x6]
    26a0:      	add	w8, w9, w8
    26a4:      	cmp	w29, #0x3c
    26a8:      	strh	w8, [x23]
    26ac:      	b.hi	0x2c34 <generic_tracepoint_process_event+0x2c34>
    26b0:      	mov	w9, #0x1                // =1
    26b4:      	lsl	x9, x9, x29
    26b8:      	tst	x9, x25
    26bc:      	b.eq	0x2c34 <generic_tracepoint_process_event+0x2c34>
    26c0:      	strb	w29, [x23, #0x5]
    26c4:      	add	x8, x24, w8, uxth
    26c8:      	mov	w9, #0x2                // =2
    26cc:      	mov	w10, #0x4               // =4
    26d0:      	mov	x0, x22
    26d4:      	mov	w1, #0x2                // =2
    26d8:      	ldrh	w8, [x23]
    26dc:      	add	x2, x24, x8
    26e0:      	blr	x10
    26e4:      	tbnz	x0, #0x3f, 0x2a34 <generic_tracepoint_process_event+0x2a34>
    26e8:      	ldrb	w8, [x23, #0x5]
    26ec:      	cmp	w8, #0x32
    26f0:      	b.gt	0x2710 <generic_tracepoint_process_event+0x2710>
    26f4:      	cbz	w8, 0x2730 <generic_tracepoint_process_event+0x2730>
    26f8:      	cmp	w8, #0x2b
    26fc:      	b.eq	0x2730 <generic_tracepoint_process_event+0x2730>
    2700:      	cmp	w8, #0x2c
    2704:      	b.ne	0x2810 <generic_tracepoint_process_event+0x2810>
    2708:      	mov	w8, #0x8                // =8
    270c:      	b	0x2768 <generic_tracepoint_process_event+0x2768>
    2710:      	cmp	w8, #0x33
    2714:      	b.eq	0x275c <generic_tracepoint_process_event+0x275c>
    2718:      	cmp	w8, #0x3c
    271c:      	b.eq	0x2730 <generic_tracepoint_process_event+0x2730>
    2720:      	cmp	w8, #0xff
    2724:      	b.ne	0x2810 <generic_tracepoint_process_event+0x2810>
    2728:      	mov	w8, #0x28               // =40
    272c:      	b	0x2768 <generic_tracepoint_process_event+0x2768>
    2730:      	ldrb	w8, [x23, #0x7]
    2734:      	lsl	w8, w8, #3
    2738:      	b	0x2764 <generic_tracepoint_process_event+0x2764>
    273c:      	ldrh	w8, [x23, #0x2]
    2740:      	ldrh	w9, [x23]
    2744:      	ldrb	w29, [x23, #0x6]
    2748:      	add	w8, w9, w8
    274c:      	cmp	w29, #0x3c
    2750:      	strh	w8, [x23]
    2754:      	b.ls	0x26b0 <generic_tracepoint_process_event+0x26b0>
    2758:      	b	0x2c34 <generic_tracepoint_process_event+0x2c34>
    275c:      	ldrb	w8, [x23, #0x7]
    2760:      	lsl	w8, w8, #2
    2764:      	add	w8, w8, #0x8
    2768:      	strh	w8, [x23, #0x2]
    276c:      	ldrh	w9, [x23]
    2770:      	ldrb	w29, [x23, #0x6]
    2774:      	add	w8, w9, w8
    2778:      	cmp	w29, #0x3c
    277c:      	strh	w8, [x23]
    2780:      	b.hi	0x2c34 <generic_tracepoint_process_event+0x2c34>
    2784:      	mov	w9, #0x1                // =1
    2788:      	lsl	x9, x9, x29
    278c:      	tst	x9, x25
    2790:      	b.eq	0x2c34 <generic_tracepoint_process_event+0x2c34>
    2794:      	strb	w29, [x23, #0x5]
    2798:      	add	x8, x24, w8, uxth
    279c:      	mov	w9, #0x2                // =2
    27a0:      	mov	w10, #0x4               // =4
    27a4:      	mov	x0, x22
    27a8:      	mov	w1, #0x2                // =2
    27ac:      	ldrh	w8, [x23]
    27b0:      	add	x2, x24, x8
    27b4:      	blr	x10
    27b8:      	tbnz	x0, #0x3f, 0x2a34 <generic_tracepoint_process_event+0x2a34>
    27bc:      	ldrb	w8, [x23, #0x5]
    27c0:      	cmp	w8, #0x32
    27c4:      	b.gt	0x27e4 <generic_tracepoint_process_event+0x27e4>
    27c8:      	cbz	w8, 0x2804 <generic_tracepoint_process_event+0x2804>
    27cc:      	cmp	w8, #0x2b
    27d0:      	b.eq	0x2804 <generic_tracepoint_process_event+0x2804>
    27d4:      	cmp	w8, #0x2c
    27d8:      	b.ne	0x28e4 <generic_tracepoint_process_event+0x28e4>
    27dc:      	mov	w8, #0x8                // =8
    27e0:      	b	0x283c <generic_tracepoint_process_event+0x283c>
    27e4:      	cmp	w8, #0x33
    27e8:      	b.eq	0x2830 <generic_tracepoint_process_event+0x2830>
    27ec:      	cmp	w8, #0x3c
    27f0:      	b.eq	0x2804 <generic_tracepoint_process_event+0x2804>
    27f4:      	cmp	w8, #0xff
    27f8:      	b.ne	0x28e4 <generic_tracepoint_process_event+0x28e4>
    27fc:      	mov	w8, #0x28               // =40
    2800:      	b	0x283c <generic_tracepoint_process_event+0x283c>
    2804:      	ldrb	w8, [x23, #0x7]
    2808:      	lsl	w8, w8, #3
    280c:      	b	0x2838 <generic_tracepoint_process_event+0x2838>
    2810:      	ldrh	w8, [x23, #0x2]
    2814:      	ldrh	w9, [x23]
    2818:      	ldrb	w29, [x23, #0x6]
    281c:      	add	w8, w9, w8
    2820:      	cmp	w29, #0x3c
    2824:      	strh	w8, [x23]
    2828:      	b.ls	0x2784 <generic_tracepoint_process_event+0x2784>
    282c:      	b	0x2c34 <generic_tracepoint_process_event+0x2c34>
    2830:      	ldrb	w8, [x23, #0x7]
    2834:      	lsl	w8, w8, #2
    2838:      	add	w8, w8, #0x8
    283c:      	strh	w8, [x23, #0x2]
    2840:      	ldrh	w9, [x23]
    2844:      	ldrb	w29, [x23, #0x6]
    2848:      	add	w8, w9, w8
    284c:      	cmp	w29, #0x3c
    2850:      	strh	w8, [x23]
    2854:      	b.hi	0x2c34 <generic_tracepoint_process_event+0x2c34>
    2858:      	mov	w9, #0x1                // =1
    285c:      	lsl	x9, x9, x29
    2860:      	tst	x9, x25
    2864:      	b.eq	0x2c34 <generic_tracepoint_process_event+0x2c34>
    2868:      	strb	w29, [x23, #0x5]
    286c:      	add	x8, x24, w8, uxth
    2870:      	mov	w9, #0x2                // =2
    2874:      	mov	w10, #0x4               // =4
    2878:      	mov	x0, x22
    287c:      	mov	w1, #0x2                // =2
    2880:      	ldrh	w8, [x23]
    2884:      	add	x2, x24, x8
    2888:      	blr	x10
    288c:      	tbnz	x0, #0x3f, 0x2a34 <generic_tracepoint_process_event+0x2a34>
    2890:      	ldrb	w8, [x23, #0x5]
    2894:      	cmp	w8, #0x32
    2898:      	b.gt	0x28b8 <generic_tracepoint_process_event+0x28b8>
    289c:      	cbz	w8, 0x28d8 <generic_tracepoint_process_event+0x28d8>
    28a0:      	cmp	w8, #0x2b
    28a4:      	b.eq	0x28d8 <generic_tracepoint_process_event+0x28d8>
    28a8:      	cmp	w8, #0x2c
    28ac:      	b.ne	0x29b8 <generic_tracepoint_process_event+0x29b8>
    28b0:      	mov	w8, #0x8                // =8
    28b4:      	b	0x2910 <generic_tracepoint_process_event+0x2910>
    28b8:      	cmp	w8, #0x33
    28bc:      	b.eq	0x2904 <generic_tracepoint_process_event+0x2904>
    28c0:      	cmp	w8, #0x3c
    28c4:      	b.eq	0x28d8 <generic_tracepoint_process_event+0x28d8>
    28c8:      	cmp	w8, #0xff
    28cc:      	b.ne	0x29b8 <generic_tracepoint_process_event+0x29b8>
    28d0:      	mov	w8, #0x28               // =40
    28d4:      	b	0x2910 <generic_tracepoint_process_event+0x2910>
    28d8:      	ldrb	w8, [x23, #0x7]
    28dc:      	lsl	w8, w8, #3
    28e0:      	b	0x290c <generic_tracepoint_process_event+0x290c>
    28e4:      	ldrh	w8, [x23, #0x2]
    28e8:      	ldrh	w9, [x23]
    28ec:      	ldrb	w29, [x23, #0x6]
    28f0:      	add	w8, w9, w8
    28f4:      	cmp	w29, #0x3c
    28f8:      	strh	w8, [x23]
    28fc:      	b.ls	0x2858 <generic_tracepoint_process_event+0x2858>
    2900:      	b	0x2c34 <generic_tracepoint_process_event+0x2c34>
    2904:      	ldrb	w8, [x23, #0x7]
    2908:      	lsl	w8, w8, #2
    290c:      	add	w8, w8, #0x8
    2910:      	strh	w8, [x23, #0x2]
    2914:      	ldrh	w9, [x23]
    2918:      	ldrb	w29, [x23, #0x6]
    291c:      	add	w8, w9, w8
    2920:      	cmp	w29, #0x3c
    2924:      	strh	w8, [x23]
    2928:      	b.hi	0x2c34 <generic_tracepoint_process_event+0x2c34>
    292c:      	mov	w9, #0x1                // =1
    2930:      	lsl	x9, x9, x29
    2934:      	tst	x9, x25
    2938:      	b.eq	0x2c34 <generic_tracepoint_process_event+0x2c34>
    293c:      	strb	w29, [x23, #0x5]
    2940:      	add	x8, x24, w8, uxth
    2944:      	mov	w9, #0x2                // =2
    2948:      	mov	w10, #0x4               // =4
    294c:      	mov	x0, x22
    2950:      	mov	w1, #0x2                // =2
    2954:      	ldrh	w8, [x23]
    2958:      	add	x2, x24, x8
    295c:      	blr	x10
    2960:      	tbnz	x0, #0x3f, 0x2a34 <generic_tracepoint_process_event+0x2a34>
    2964:      	ldrb	w8, [x23, #0x5]
    2968:      	cmp	w8, #0x32
    296c:      	b.gt	0x298c <generic_tracepoint_process_event+0x298c>
    2970:      	cbz	w8, 0x29ac <generic_tracepoint_process_event+0x29ac>
    2974:      	cmp	w8, #0x2b
    2978:      	b.eq	0x29ac <generic_tracepoint_process_event+0x29ac>
    297c:      	cmp	w8, #0x2c
    2980:      	b.ne	0x2c18 <generic_tracepoint_process_event+0x2c18>
    2984:      	mov	w8, #0x8                // =8
    2988:      	b	0x29e4 <generic_tracepoint_process_event+0x29e4>
    298c:      	cmp	w8, #0x33
    2990:      	b.eq	0x29d8 <generic_tracepoint_process_event+0x29d8>
    2994:      	cmp	w8, #0x3c
    2998:      	b.eq	0x29ac <generic_tracepoint_process_event+0x29ac>
    299c:      	cmp	w8, #0xff
    29a0:      	b.ne	0x2c18 <generic_tracepoint_process_event+0x2c18>
    29a4:      	mov	w8, #0x28               // =40
    29a8:      	b	0x29e4 <generic_tracepoint_process_event+0x29e4>
    29ac:      	ldrb	w8, [x23, #0x7]
    29b0:      	lsl	w8, w8, #3
    29b4:      	b	0x29e0 <generic_tracepoint_process_event+0x29e0>
    29b8:      	ldrh	w8, [x23, #0x2]
    29bc:      	ldrh	w9, [x23]
    29c0:      	ldrb	w29, [x23, #0x6]
    29c4:      	add	w8, w9, w8
    29c8:      	cmp	w29, #0x3c
    29cc:      	strh	w8, [x23]
    29d0:      	b.ls	0x292c <generic_tracepoint_process_event+0x292c>
    29d4:      	b	0x2c34 <generic_tracepoint_process_event+0x2c34>
    29d8:      	ldrb	w8, [x23, #0x7]
    29dc:      	lsl	w8, w8, #2
    29e0:      	add	w8, w8, #0x8
    29e4:      	strh	w8, [x23, #0x2]
    29e8:      	ldrh	w9, [x23]
    29ec:      	ldrb	w29, [x23, #0x6]
    29f0:      	add	w8, w9, w8
    29f4:      	cmp	w29, #0x3c
    29f8:      	strh	w8, [x23]
    29fc:      	b.hi	0x2c34 <generic_tracepoint_process_event+0x2c34>
    2a00:      	mov	w9, #0x1                // =1
    2a04:      	lsl	x9, x9, x29
    2a08:      	tst	x9, x25
    2a0c:      	b.eq	0x2c34 <generic_tracepoint_process_event+0x2c34>
    2a10:      	strb	w29, [x23, #0x5]
    2a14:      	add	x8, x24, w8, uxth
    2a18:      	mov	w9, #0x2                // =2
    2a1c:      	mov	w10, #0x4               // =4
    2a20:      	mov	x0, x22
    2a24:      	mov	w1, #0x2                // =2
    2a28:      	ldrh	w8, [x23]
    2a2c:      	add	x2, x24, x8
    2a30:      	blr	x10
    2a34:      	mov	w29, wzr
    2a38:      	ldr	x25, [sp, #0x20]
    2a3c:      	ldr	x24, [sp, #0x48]
    2a40:      	mov	w8, #0xa                // =10
    2a44:      	mov	w22, #0x10              // =16
    2a48:      	mov	w1, #0x10               // =16
    2a4c:      	mov	w23, #0x4               // =4
    2a50:      	strb	w29, [sp, #0x84]
    2a54:      	strh	w29, [x25, #0x24]
    2a58:      	strh	w8, [x25, #0x26]
    2a5c:      	add	x2, x24, #0x8
    2a60:      	mov	w8, #0x4                // =4
    2a64:      	mov	x0, x25
    2a68:      	blr	x8
    2a6c:      	add	x0, x25, #0x10
    2a70:      	add	x2, x24, #0x18
    2a74:      	mov	w1, #0x10               // =16
    2a78:      	blr	x23
    2a7c:      	cmp	w29, #0x11
    2a80:      	b.eq	0x2ac4 <generic_tracepoint_process_event+0x2ac4>
    2a84:      	cmp	w29, #0x6
    2a88:      	b.ne	0x2b04 <generic_tracepoint_process_event+0x2b04>
    2a8c:      	ldr	x8, [sp, #0x98]
    2a90:      	ldrh	w9, [sp, #0x88]
    2a94:      	mov	w23, #0x2               // =2
    2a98:      	mov	w1, #0x2                // =2
    2a9c:      	mov	w25, #0x4               // =4
    2aa0:      	add	x22, x8, x9
    2aa4:      	ldr	x29, [sp, #0x20]
    2aa8:      	add	x0, x29, #0x20
    2aac:      	mov	w8, #0x4                // =4
    2ab0:      	mov	x2, x22
    2ab4:      	blr	x8
    2ab8:      	add	x0, x29, #0x22
    2abc:      	add	x2, x22, #0x2
    2ac0:      	b	0x2af8 <generic_tracepoint_process_event+0x2af8>
    2ac4:      	ldr	x8, [sp, #0x98]
    2ac8:      	ldrh	w9, [sp, #0x88]
    2acc:      	mov	w23, #0x2               // =2
    2ad0:      	mov	w1, #0x2                // =2
    2ad4:      	mov	w25, #0x4               // =4
    2ad8:      	add	x22, x8, x9
    2adc:      	ldr	x29, [sp, #0x20]
    2ae0:      	add	x0, x29, #0x20
    2ae4:      	mov	w8, #0x4                // =4
    2ae8:      	mov	x2, x22
    2aec:      	blr	x8
    2af0:      	add	x0, x29, #0x22
    2af4:      	add	x2, x22, #0x2
    2af8:      	mov	w1, #0x2                // =2
    2afc:      	blr	x25
    2b00:      	b	0x2b0c <generic_tracepoint_process_event+0x2b0c>
    2b04:      	ldr	x8, [sp, #0x20]
    2b08:      	str	wzr, [x8, #0x20]
    2b0c:      	ldr	x9, [sp, #0x20]
    2b10:      	add	x10, sp, #0xf0
    2b14:      	add	x0, sp, #0xf0
    2b18:      	mov	w1, #0x8                // =8
    2b1c:      	ldrh	w8, [x9, #0x20]
    2b20:      	rev	w8, w8
    2b24:      	lsr	w8, w8, #16
    2b28:      	strh	w8, [x9, #0x20]
    2b2c:      	ldrh	w8, [x9, #0x22]
    2b30:      	rev	w8, w8
    2b34:      	lsr	w8, w8, #16
    2b38:      	strh	w8, [x9, #0x22]
    2b3c:      	ldr	x8, [sp, #0x50]
    2b40:      	mov	w9, #0x4                // =4
    2b44:      	add	x2, x8, #0xe0
    2b48:      	mov	w8, #0x8                // =8
    2b4c:      	blr	x9
    2b50:      	add	x8, sp, #0xe0
    2b54:      	ldr	x8, [x8, #0x10]
    2b58:      	cbz	x8, 0x2bbc <generic_tracepoint_process_event+0x2bbc>
    2b5c:      	add	x8, x8, #0x5
    2b60:      	mov	w9, #0x8                // =8
    2b64:      	add	x10, sp, #0x100
    2b68:      	mov	w11, #0x4               // =4
    2b6c:      	add	x23, sp, #0xe0
    2b70:      	ldr	x8, [x23, #0x10]
    2b74:      	add	x0, sp, #0x100
    2b78:      	mov	w1, #0x8                // =8
    2b7c:      	mov	w22, #0x4               // =4
    2b80:      	add	x2, x8, #0x5
    2b84:      	blr	x11
    2b88:      	ldr	x8, [x23, #0x10]
    2b8c:      	ldr	x9, [x23, #0x20]
    2b90:      	mov	w1, #0x4                // =4
    2b94:      	add	x23, x8, x9, lsl #3
    2b98:      	ldr	x24, [sp, #0x20]
    2b9c:      	add	x0, x24, #0x38
    2ba0:      	mov	w8, #0x4                // =4
    2ba4:      	add	x2, x23, #0x44
    2ba8:      	blr	x8
    2bac:      	add	x0, x24, #0x3c
    2bb0:      	add	x2, x23, #0x45
    2bb4:      	mov	w1, #0x4                // =4
    2bb8:      	blr	x22
    2bbc:      	mov	w22, #0x40              // =64
    2bc0:      	adrp	x21, 0x2000 <generic_tracepoint_process_event+0x2000>
    2bc4:      	ldp	x19, x23, [sp, #0x38]
    2bc8:      	mov	w25, #0x5efc            // =24316
    2bcc:      	mov	w10, #0x5ea0            // =24224
    2bd0:      	ldr	x11, [sp, #0x28]
    2bd4:      	ldr	x21, [x21]
    2bd8:      	ldr	x24, [sp, #0x118]
    2bdc:      	tbnz	w22, #0x1f, 0x2c04 <generic_tracepoint_process_event+0x2c04>
    2be0:      	and	w8, w22, #0x7fffffff
    2be4:      	add	w8, w8, #0x4
    2be8:      	add	w24, w8, w24
    2bec:      	str	w24, [x20, #0x4]
    2bf0:      	adrp	x22, 0x2000 <generic_tracepoint_process_event+0x2000>
    2bf4:      	cmp	w23, #0x3
    2bf8:      	ldr	x22, [x22]
    2bfc:      	b.le	0x430 <generic_tracepoint_process_event+0x430>
    2c00:      	b	0x49c <generic_tracepoint_process_event+0x49c>
    2c04:      	ldr	x9, [sp, #0x10]
    2c08:      	mov	w8, #-0x1               // =-1
    2c0c:      	str	w8, [x9, x10]
    2c10:      	str	w8, [x11, x24]
    2c14:      	b	0x3f8 <generic_tracepoint_process_event+0x3f8>
    2c18:      	ldrh	w8, [x23, #0x2]
    2c1c:      	ldrh	w9, [x23]
    2c20:      	ldrb	w29, [x23, #0x6]
    2c24:      	add	w8, w9, w8
    2c28:      	cmp	w29, #0x3c
    2c2c:      	strh	w8, [x23]
    2c30:      	b.ls	0x2a00 <generic_tracepoint_process_event+0x2a00>
    2c34:      	strh	w8, [sp, #0x88]
    2c38:      	b	0x2a38 <generic_tracepoint_process_event+0x2a38>
    2c3c:      	nop

0000000000002c40 <generic_tracepoint_filter>:
    2c40:      	sub	sp, sp, #0x130
    2c44:      	str	x29, [sp, #0xe0]
    2c48:      	stp	x30, x25, [sp, #0xf0]
    2c4c:      	stp	x24, x23, [sp, #0x100]
    2c50:      	stp	x22, x21, [sp, #0x110]
    2c54:      	stp	x20, x19, [sp, #0x120]
    2c58:      	mov	x20, x0
    2c5c:      	str	wzr, [sp, #0x54]
    2c60:      	adrp	x0, 0x2000 <generic_tracepoint_process_event+0x2000>
    2c64:      	mov	w8, #0x1                // =1
    2c68:      	ldr	x0, [x0]
    2c6c:      	add	x9, sp, #0x54
    2c70:      	add	x1, sp, #0x54
    2c74:      	blr	x8
    2c78:      	cbz	x0, 0x4f6c <generic_tracepoint_filter+0x232c>
    2c7c:      	mov	w8, #0x5ec0             // =24256
    2c80:      	mov	x22, x0
    2c84:      	add	x29, x0, x8
    2c88:      	mov	w8, #0x23               // =35
    2c8c:      	blr	x8
    2c90:      	str	x0, [sp, #0x58]
    2c94:      	add	x8, x0, #0x8d4
    2c98:      	mov	w9, #0x4                // =4
    2c9c:      	mov	w10, #0x71              // =113
    2ca0:      	add	x11, sp, #0xd8
    2ca4:      	add	x0, sp, #0xd8
    2ca8:      	mov	w1, #0x4                // =4
    2cac:      	ldr	x8, [sp, #0x58]
    2cb0:      	add	x2, x8, #0x8d4
    2cb4:      	blr	x10
    2cb8:      	ldr	w8, [sp, #0xd8]
    2cbc:      	adrp	x19, 0x2000 <generic_tracepoint_process_event+0x2000>
    2cc0:      	add	x9, sp, #0xc8
    2cc4:      	add	x1, sp, #0xc8
    2cc8:      	str	w8, [sp, #0xc8]
    2ccc:      	mov	w8, #0x1                // =1
    2cd0:      	ldr	x19, [x19]
    2cd4:      	mov	x0, x19
    2cd8:      	blr	x8
    2cdc:      	cbz	x0, 0x2cec <generic_tracepoint_filter+0xac>
    2ce0:      	ldr	x8, [x0, #0x8]
    2ce4:      	mov	x24, x0
    2ce8:      	cbnz	x8, 0x3acc <generic_tracepoint_filter+0xe8c>
    2cec:      	ldr	x8, [sp, #0x58]
    2cf0:      	mov	w9, #0x8                // =8
    2cf4:      	mov	w10, #0x71              // =113
    2cf8:      	add	x11, sp, #0x58
    2cfc:      	add	x0, sp, #0x58
    2d00:      	mov	w1, #0x8                // =8
    2d04:      	add	x8, x8, #0x8e0
    2d08:      	ldr	x8, [sp, #0x58]
    2d0c:      	add	x2, x8, #0x8e0
    2d10:      	blr	x10
    2d14:      	ldr	x8, [sp, #0x58]
    2d18:      	cbz	x8, 0x2e94 <generic_tracepoint_filter+0x254>
    2d1c:      	add	x8, x8, #0x8d4
    2d20:      	mov	w9, #0x4                // =4
    2d24:      	mov	w10, #0x71              // =113
    2d28:      	add	x11, sp, #0xd8
    2d2c:      	ldr	x8, [sp, #0x58]
    2d30:      	add	x0, sp, #0xd8
    2d34:      	mov	w1, #0x4                // =4
    2d38:      	add	x2, x8, #0x8d4
    2d3c:      	blr	x10
    2d40:      	ldr	w8, [sp, #0xd8]
    2d44:      	add	x9, sp, #0xc8
    2d48:      	add	x1, sp, #0xc8
    2d4c:      	mov	x0, x19
    2d50:      	str	w8, [sp, #0xc8]
    2d54:      	mov	w8, #0x1                // =1
    2d58:      	blr	x8
    2d5c:      	cbz	x0, 0x2d6c <generic_tracepoint_filter+0x12c>
    2d60:      	ldr	x8, [x0, #0x8]
    2d64:      	mov	x24, x0
    2d68:      	cbnz	x8, 0x3acc <generic_tracepoint_filter+0xe8c>
    2d6c:      	ldr	x8, [sp, #0x58]
    2d70:      	mov	w9, #0x8                // =8
    2d74:      	mov	w10, #0x71              // =113
    2d78:      	add	x11, sp, #0x58
    2d7c:      	add	x0, sp, #0x58
    2d80:      	mov	w1, #0x8                // =8
    2d84:      	add	x8, x8, #0x8e0
    2d88:      	ldr	x8, [sp, #0x58]
    2d8c:      	add	x2, x8, #0x8e0
    2d90:      	blr	x10
    2d94:      	ldr	x8, [sp, #0x58]
    2d98:      	cbz	x8, 0x2e94 <generic_tracepoint_filter+0x254>
    2d9c:      	add	x8, x8, #0x8d4
    2da0:      	mov	w9, #0x4                // =4
    2da4:      	mov	w10, #0x71              // =113
    2da8:      	add	x11, sp, #0xd8
    2dac:      	ldr	x8, [sp, #0x58]
    2db0:      	add	x0, sp, #0xd8
    2db4:      	mov	w1, #0x4                // =4
    2db8:      	add	x2, x8, #0x8d4
    2dbc:      	blr	x10
    2dc0:      	ldr	w8, [sp, #0xd8]
    2dc4:      	add	x9, sp, #0xc8
    2dc8:      	add	x1, sp, #0xc8
    2dcc:      	mov	x0, x19
    2dd0:      	str	w8, [sp, #0xc8]
    2dd4:      	mov	w8, #0x1                // =1
    2dd8:      	blr	x8
    2ddc:      	cbz	x0, 0x2dec <generic_tracepoint_filter+0x1ac>
    2de0:      	ldr	x8, [x0, #0x8]
    2de4:      	mov	x24, x0
    2de8:      	cbnz	x8, 0x3acc <generic_tracepoint_filter+0xe8c>
    2dec:      	ldr	x8, [sp, #0x58]
    2df0:      	mov	w9, #0x8                // =8
    2df4:      	mov	w10, #0x71              // =113
    2df8:      	add	x11, sp, #0x58
    2dfc:      	add	x0, sp, #0x58
    2e00:      	mov	w1, #0x8                // =8
    2e04:      	add	x8, x8, #0x8e0
    2e08:      	ldr	x8, [sp, #0x58]
    2e0c:      	add	x2, x8, #0x8e0
    2e10:      	blr	x10
    2e14:      	ldr	x8, [sp, #0x58]
    2e18:      	cbz	x8, 0x2e94 <generic_tracepoint_filter+0x254>
    2e1c:      	add	x8, x8, #0x8d4
    2e20:      	mov	w9, #0x4                // =4
    2e24:      	mov	w10, #0x71              // =113
    2e28:      	add	x11, sp, #0xd8
    2e2c:      	ldr	x8, [sp, #0x58]
    2e30:      	add	x0, sp, #0xd8
    2e34:      	mov	w1, #0x4                // =4
    2e38:      	add	x2, x8, #0x8d4
    2e3c:      	blr	x10
    2e40:      	ldr	w8, [sp, #0xd8]
    2e44:      	add	x9, sp, #0xc8
    2e48:      	add	x1, sp, #0xc8
    2e4c:      	mov	x0, x19
    2e50:      	str	w8, [sp, #0xc8]
    2e54:      	mov	w8, #0x1                // =1
    2e58:      	blr	x8
    2e5c:      	cbz	x0, 0x2e6c <generic_tracepoint_filter+0x22c>
    2e60:      	ldr	x8, [x0, #0x8]
    2e64:      	mov	x24, x0
    2e68:      	cbnz	x8, 0x3acc <generic_tracepoint_filter+0xe8c>
    2e6c:      	ldr	x8, [sp, #0x58]
    2e70:      	mov	w9, #0x8                // =8
    2e74:      	mov	w10, #0x71              // =113
    2e78:      	add	x11, sp, #0x58
    2e7c:      	add	x0, sp, #0x58
    2e80:      	mov	w1, #0x8                // =8
    2e84:      	add	x8, x8, #0x8e0
    2e88:      	ldr	x8, [sp, #0x58]
    2e8c:      	add	x2, x8, #0x8e0
    2e90:      	blr	x10
    2e94:      	str	x20, [sp, #0x38]
    2e98:      	mov	w8, #0x23               // =35
    2e9c:      	blr	x8
    2ea0:      	add	x2, x0, #0x8d4
    2ea4:      	mov	w8, #0x4                // =4
    2ea8:      	add	x9, sp, #0x58
    2eac:      	mov	x24, x0
    2eb0:      	add	x0, sp, #0x58
    2eb4:      	mov	w1, #0x4                // =4
    2eb8:      	blr	x8
    2ebc:      	ldr	w8, [sp, #0x58]
    2ec0:      	mov	x19, x29
    2ec4:      	str	w8, [x19, #0x50]!
    2ec8:      	mov	w8, #0x7d               // =125
    2ecc:      	blr	x8
    2ed0:      	str	x0, [x22, #0x5f18]
    2ed4:      	str	wzr, [x19, #0x10]
    2ed8:      	add	x2, x24, #0x60
    2edc:      	mov	w8, #0x8                // =8
    2ee0:      	mov	w9, #0x71               // =113
    2ee4:      	add	x10, sp, #0xc8
    2ee8:      	str	xzr, [x22, #0x5f28]
    2eec:      	str	x19, [sp, #0x48]
    2ef0:      	add	x0, sp, #0xc8
    2ef4:      	mov	w1, #0x8                // =8
    2ef8:      	str	wzr, [x19, #0x20]
    2efc:      	blr	x9
    2f00:      	ldr	x8, [sp, #0xc8]
    2f04:      	cbz	x8, 0x2f74 <generic_tracepoint_filter+0x334>
    2f08:      	add	x8, x8, #0x4
    2f0c:      	mov	w9, #0x4                // =4
    2f10:      	mov	w10, #0x71              // =113
    2f14:      	add	x11, sp, #0xd8
    2f18:      	ldr	x8, [sp, #0xc8]
    2f1c:      	add	x0, sp, #0xd8
    2f20:      	mov	w1, #0x4                // =4
    2f24:      	add	x2, x8, #0x4
    2f28:      	blr	x10
    2f2c:      	ldr	w8, [sp, #0xd8]
    2f30:      	cbz	w8, 0x2f74 <generic_tracepoint_filter+0x334>
    2f34:      	ldr	x9, [sp, #0xc8]
    2f38:      	lsl	w8, w8, #4
    2f3c:      	mov	w10, #0x71              // =113
    2f40:      	add	x11, sp, #0x58
    2f44:      	add	x0, sp, #0x58
    2f48:      	mov	w1, #0x10               // =16
    2f4c:      	add	x8, x9, x8
    2f50:      	mov	w9, #0x10               // =16
    2f54:      	add	x8, x8, #0x80
    2f58:      	ldr	w9, [sp, #0xd8]
    2f5c:      	ldr	x8, [sp, #0xc8]
    2f60:      	lsl	w9, w9, #4
    2f64:      	add	x8, x8, x9
    2f68:      	add	x2, x8, #0x80
    2f6c:      	blr	x10
    2f70:      	ldr	w8, [sp, #0x58]
    2f74:      	str	w8, [x29, #0x74]
    2f78:      	mov	w8, #0x5f60             // =24416
    2f7c:      	str	x22, [sp, #0xe8]
    2f80:      	add	x23, x24, #0xae0
    2f84:      	mov	w19, #0x8               // =8
    2f88:      	add	x25, x22, x8
    2f8c:      	add	x8, sp, #0x58
    2f90:      	mov	w9, #0x4                // =4
    2f94:      	add	x0, sp, #0x58
    2f98:      	mov	w1, #0x8                // =8
    2f9c:      	mov	x2, x23
    2fa0:      	mov	w21, #0x4               // =4
    2fa4:      	blr	x9
    2fa8:      	ldr	x20, [sp, #0x58]
    2fac:      	ldr	x9, [sp, #0xe8]
    2fb0:      	mov	w8, #0x5f68             // =24424
    2fb4:      	mov	w1, #0x8                // =8
    2fb8:      	add	x0, x9, x8
    2fbc:      	add	x2, x20, #0x40
    2fc0:      	mov	w8, #0x4                // =4
    2fc4:      	blr	x8
    2fc8:      	ldr	x9, [sp, #0xe8]
    2fcc:      	mov	w8, #0x5f70             // =24432
    2fd0:      	add	x2, x20, #0x30
    2fd4:      	mov	w1, #0x8                // =8
    2fd8:      	add	x0, x9, x8
    2fdc:      	mov	w8, #0x4                // =4
    2fe0:      	blr	x8
    2fe4:      	add	x2, x20, #0x38
    2fe8:      	mov	w8, #0x4                // =4
    2fec:      	mov	x0, x25
    2ff0:      	mov	w1, #0x8                // =8
    2ff4:      	blr	x8
    2ff8:      	ldr	x9, [sp, #0xe8]
    2ffc:      	mov	w8, #0x5f38             // =24376
    3000:      	add	x2, x24, #0xb50
    3004:      	add	x0, sp, #0xd8
    3008:      	mov	w1, #0x8                // =8
    300c:      	add	x25, x9, x8
    3010:      	add	x8, sp, #0xd8
    3014:      	mov	w9, #0x4                // =4
    3018:      	blr	x9
    301c:      	add	x12, sp, #0xd8
    3020:      	mov	w9, #0x48               // =72
    3024:      	add	x10, sp, #0x58
    3028:      	ldr	x8, [x12]
    302c:      	mov	w11, #0x4               // =4
    3030:      	add	x0, sp, #0x58
    3034:      	mov	w1, #0x48               // =72
    3038:      	ldr	x2, [x12]
    303c:      	blr	x11
    3040:      	ldr	x8, [sp, #0x60]
    3044:      	mov	w9, #0x4                // =4
    3048:      	mov	x0, x25
    304c:      	mov	w1, #0x4                // =4
    3050:      	add	x8, x8, #0x218
    3054:      	ldr	x8, [sp, #0x60]
    3058:      	ldr	x22, [sp, #0xe8]
    305c:      	add	x2, x8, #0x218
    3060:      	blr	x9
    3064:      	mov	w8, #0x5f3c             // =24380
    3068:      	mov	w9, #0x4                // =4
    306c:      	mov	w1, #0x4                // =4
    3070:      	add	x0, x22, x8
    3074:      	ldr	x8, [sp, #0x68]
    3078:      	add	x8, x8, #0x4d8
    307c:      	ldr	x8, [sp, #0x68]
    3080:      	add	x2, x8, #0x4d8
    3084:      	blr	x9
    3088:      	mov	w8, #0x5f40             // =24384
    308c:      	mov	w9, #0x4                // =4
    3090:      	mov	w1, #0x4                // =4
    3094:      	add	x0, x22, x8
    3098:      	ldr	x8, [sp, #0x70]
    309c:      	add	x8, x8, #0x58
    30a0:      	ldr	x8, [sp, #0x70]
    30a4:      	add	x2, x8, #0x58
    30a8:      	blr	x9
    30ac:      	str	xzr, [sp, #0xc0]
    30b0:      	add	x2, x24, #0x938
    30b4:      	add	x8, sp, #0xc0
    30b8:      	add	x0, sp, #0xc0
    30bc:      	mov	w1, #0x8                // =8
    30c0:      	blr	x21
    30c4:      	ldr	x8, [sp, #0xc0]
    30c8:      	cbz	x8, 0x3150 <generic_tracepoint_filter+0x510>
    30cc:      	str	wzr, [sp, #0xb8]
    30d0:      	add	x8, x8, #0x4
    30d4:      	add	x9, sp, #0xb8
    30d8:      	mov	w10, #0x4               // =4
    30dc:      	add	x0, sp, #0xb8
    30e0:      	mov	w1, #0x4                // =4
    30e4:      	mov	w19, #0x4               // =4
    30e8:      	ldr	x8, [sp, #0xc0]
    30ec:      	add	x2, x8, #0x4
    30f0:      	blr	x10
    30f4:      	ldr	x8, [sp, #0xc0]
    30f8:      	ldrsw	x9, [sp, #0xb8]
    30fc:      	add	x10, sp, #0xc8
    3100:      	mov	w11, #0x4               // =4
    3104:      	add	x0, sp, #0xc8
    3108:      	mov	w1, #0x10               // =16
    310c:      	add	x8, x8, x9, lsl #4
    3110:      	mov	w9, #0x10               // =16
    3114:      	add	x8, x8, #0x80
    3118:      	ldr	x8, [sp, #0xc0]
    311c:      	ldrsw	x9, [sp, #0xb8]
    3120:      	add	x8, x8, x9, lsl #4
    3124:      	add	x2, x8, #0x80
    3128:      	blr	x11
    312c:      	mov	w8, #0x5f44             // =24388
    3130:      	mov	w1, #0x4                // =4
    3134:      	add	x0, x22, x8
    3138:      	ldr	x8, [sp, #0xd0]
    313c:      	add	x8, x8, #0x158
    3140:      	ldr	x8, [sp, #0xd0]
    3144:      	add	x2, x8, #0x158
    3148:      	blr	x19
    314c:      	b	0x3154 <generic_tracepoint_filter+0x514>
    3150:      	str	wzr, [x29, #0x84]
    3154:      	mov	w8, #0x5f48             // =24392
    3158:      	mov	w9, #0x4                // =4
    315c:      	mov	w1, #0x4                // =4
    3160:      	mov	w19, #0x4               // =4
    3164:      	add	x0, x22, x8
    3168:      	ldr	x8, [sp, #0x78]
    316c:      	add	x8, x8, #0x158
    3170:      	ldr	x8, [sp, #0x78]
    3174:      	add	x2, x8, #0x158
    3178:      	blr	x9
    317c:      	mov	w8, #0x5f4c             // =24396
    3180:      	mov	w9, #0x4                // =4
    3184:      	mov	w1, #0x4                // =4
    3188:      	add	x0, x22, x8
    318c:      	ldr	x8, [sp, #0x80]
    3190:      	add	x8, x8, #0x118
    3194:      	ldr	x8, [sp, #0x80]
    3198:      	add	x2, x8, #0x118
    319c:      	blr	x9
    31a0:      	mov	w8, #0x5f50             // =24400
    31a4:      	mov	w9, #0x4                // =4
    31a8:      	mov	w1, #0x4                // =4
    31ac:      	add	x0, x22, x8
    31b0:      	ldr	x8, [sp, #0x88]
    31b4:      	add	x8, x8, #0x98
    31b8:      	ldr	x8, [sp, #0x88]
    31bc:      	add	x2, x8, #0x98
    31c0:      	blr	x9
    31c4:      	mov	w8, #0x5f54             // =24404
    31c8:      	mov	w9, #0x4                // =4
    31cc:      	mov	w1, #0x4                // =4
    31d0:      	add	x0, x22, x8
    31d4:      	ldr	x8, [sp, #0x90]
    31d8:      	add	x8, x8, #0x98
    31dc:      	ldr	x8, [sp, #0x90]
    31e0:      	add	x2, x8, #0x98
    31e4:      	blr	x9
    31e8:      	mov	w8, #0x5f58             // =24408
    31ec:      	mov	w9, #0x4                // =4
    31f0:      	mov	w1, #0x4                // =4
    31f4:      	add	x0, x22, x8
    31f8:      	ldr	x8, [sp, #0x98]
    31fc:      	add	x8, x8, #0x58
    3200:      	ldr	x8, [sp, #0x98]
    3204:      	add	x2, x8, #0x58
    3208:      	blr	x9
    320c:      	stp	xzr, xzr, [sp, #0xc0]
    3210:      	mov	w20, #0x8               // =8
    3214:      	add	x8, sp, #0xc8
    3218:      	mov	w9, #0x4                // =4
    321c:      	add	x0, sp, #0xc8
    3220:      	mov	w1, #0x8                // =8
    3224:      	mov	x2, x23
    3228:      	blr	x9
    322c:      	ldr	x8, [sp, #0xc8]
    3230:      	add	x9, sp, #0xc0
    3234:      	mov	w10, #0x4               // =4
    3238:      	add	x0, sp, #0xc0
    323c:      	mov	w1, #0x8                // =8
    3240:      	add	x8, x8, #0x90
    3244:      	ldr	x8, [sp, #0xc8]
    3248:      	add	x2, x8, #0x90
    324c:      	blr	x10
    3250:      	mov	w8, #0x5f5c             // =24412
    3254:      	mov	w1, #0x4                // =4
    3258:      	add	x0, x22, x8
    325c:      	ldr	x8, [sp, #0xc0]
    3260:      	add	x8, x8, #0x158
    3264:      	ldr	x8, [sp, #0xc0]
    3268:      	add	x2, x8, #0x158
    326c:      	blr	x19
    3270:      	ldr	w8, [x29, #0x74]
    3274:      	cmp	w8, #0x1
    3278:      	b.ne	0x3288 <generic_tracepoint_filter+0x648>
    327c:      	ldr	w8, [x29, #0x70]
    3280:      	orr	w8, w8, #0x2000000
    3284:      	str	w8, [x29, #0x70]
    3288:      	add	x0, x29, #0xb8
    328c:      	mov	w1, wzr
    3290:      	mov	w2, #0x308              // =776
    3294:      	bl	0x3294 <generic_tracepoint_filter+0x654>
    3298:      	mov	w8, #0x6290             // =25232
    329c:      	add	x2, x24, #0x858
    32a0:      	mov	w19, #0x8               // =8
    32a4:      	mov	w9, #0x4                // =4
    32a8:      	add	x0, sp, #0xc8
    32ac:      	mov	w1, #0x8                // =8
    32b0:      	mov	w20, #0x4               // =4
    32b4:      	add	x21, x22, x8
    32b8:      	add	x8, sp, #0xc8
    32bc:      	blr	x9
    32c0:      	ldr	x8, [sp, #0xc8]
    32c4:      	add	x9, sp, #0x58
    32c8:      	add	x0, sp, #0x58
    32cc:      	mov	w1, #0x8                // =8
    32d0:      	add	x8, x8, #0x528
    32d4:      	ldr	x8, [sp, #0xc8]
    32d8:      	add	x2, x8, #0x528
    32dc:      	blr	x20
    32e0:      	str	wzr, [sp, #0xa4]
    32e4:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x3c0>
    32e8:      	ldr	x19, [sp, #0x58]
    32ec:      	mov	w8, #0x1                // =1
    32f0:      	add	x9, sp, #0xa4
    32f4:      	add	x1, sp, #0xa4
    32f8:      	ldr	x0, [x0]
    32fc:      	blr	x8
    3300:      	cbz	x0, 0x3914 <generic_tracepoint_filter+0xcd4>
    3304:      	mov	w8, #0x1000             // =4096
    3308:      	str	x21, [sp, #0x30]
    330c:      	str	x29, [sp, #0x40]
    3310:      	mov	x24, x0
    3314:      	add	x20, x0, #0x1, lsl #12  // =0x1000
    3318:      	str	w8, [x29, #0x550]
    331c:      	mov	w8, #0x23               // =35
    3320:      	blr	x8
    3324:      	add	x2, x0, #0xb30
    3328:      	mov	w23, #0x8               // =8
    332c:      	add	x8, sp, #0xa8
    3330:      	mov	w9, #0x4                // =4
    3334:      	add	x0, sp, #0xa8
    3338:      	mov	w1, #0x8                // =8
    333c:      	mov	w29, #0x4               // =4
    3340:      	blr	x9
    3344:      	ldr	x22, [sp, #0xa8]
    3348:      	add	x25, x19, #0x48
    334c:      	add	x8, sp, #0xb0
    3350:      	mov	w9, #0x4                // =4
    3354:      	add	x0, sp, #0xb0
    3358:      	mov	w1, #0x8                // =8
    335c:      	mov	x2, x25
    3360:      	blr	x9
    3364:      	ldr	x21, [sp, #0xb0]
    3368:      	add	x8, sp, #0x58
    336c:      	add	x0, sp, #0x58
    3370:      	mov	w1, #0x8                // =8
    3374:      	add	x2, x21, #0x10
    3378:      	blr	x29
    337c:      	ldr	x8, [sp, #0x58]
    3380:      	cbz	x8, 0x35b4 <generic_tracepoint_filter+0x974>
    3384:      	ldr	x8, [sp, #0x40]
    3388:      	stp	xzr, xzr, [sp, #0x58]
    338c:      	add	x21, x22, #0x18
    3390:      	add	x9, sp, #0x58
    3394:      	add	x2, x22, #0x20
    3398:      	mov	w22, #0x8               // =8
    339c:      	stp	x24, xzr, [sp, #0x68]
    33a0:      	add	x0, sp, #0x58
    33a4:      	mov	w1, #0x8                // =8
    33a8:      	add	x29, x19, #0x40
    33ac:      	add	x19, x9, #0x8
    33b0:      	add	x24, x9, #0x18
    33b4:      	stp	xzr, xzr, [sp, #0x78]
    33b8:      	add	x23, x9, #0x20
    33bc:      	str	x20, [sp, #0x88]
    33c0:      	str	x20, [sp, #0x28]
    33c4:      	mov	w20, #0x4               // =4
    33c8:      	ldr	w8, [x8, #0x550]
    33cc:      	strb	wzr, [sp, #0x94]
    33d0:      	str	w8, [sp, #0x90]
    33d4:      	mov	w8, #0x4                // =4
    33d8:      	blr	x8
    33dc:      	mov	w8, #0x4                // =4
    33e0:      	mov	x0, x19
    33e4:      	mov	w1, #0x8                // =8
    33e8:      	mov	x2, x21
    33ec:      	blr	x8
    33f0:      	mov	w8, #0x4                // =4
    33f4:      	mov	x0, x24
    33f8:      	mov	w1, #0x8                // =8
    33fc:      	mov	x2, x25
    3400:      	blr	x8
    3404:      	mov	x0, x23
    3408:      	mov	w1, #0x8                // =8
    340c:      	mov	x2, x29
    3410:      	blr	x20
    3414:      	ldr	x8, [sp, #0x78]
    3418:      	sub	x8, x8, #0x20
    341c:      	str	x8, [sp, #0x80]
    3420:      	adrp	x8, 0x3000 <generic_tracepoint_filter+0x3c0>
    3424:      	ldr	x8, [x8]
    3428:      	ldrb	w8, [x8]
    342c:      	cbz	w8, 0x3608 <generic_tracepoint_filter+0x9c8>
    3430:      	mov	w19, #0x800             // =2048
    3434:      	mov	w21, #0x8               // =8
    3438:      	add	x23, sp, #0xb8
    343c:      	add	x29, sp, #0xd8
    3440:      	b	0x3494 <generic_tracepoint_filter+0x854>
    3444:      	add	x2, x22, #0x10
    3448:      	mov	w8, #0x4                // =4
    344c:      	add	x0, sp, #0xd8
    3450:      	mov	w1, #0x8                // =8
    3454:      	blr	x8
    3458:      	add	x20, sp, #0xd8
    345c:      	ldr	x8, [sp, #0x80]
    3460:      	ldr	x9, [x20]
    3464:      	cmp	x8, x9
    3468:      	b.eq	0x3790 <generic_tracepoint_filter+0xb50>
    346c:      	add	x2, x22, #0x18
    3470:      	mov	w8, #0x4                // =4
    3474:      	mov	x0, x24
    3478:      	mov	w1, #0x8                // =8
    347c:      	blr	x8
    3480:      	ldr	x8, [x20]
    3484:      	add	x9, x8, #0x20
    3488:      	stp	x9, x8, [sp, #0x78]
    348c:      	subs	w19, w19, #0x1
    3490:      	b.eq	0x3798 <generic_tracepoint_filter+0xb58>
    3494:      	ldp	x20, x2, [sp, #0x70]
    3498:      	ldp	x8, x9, [sp, #0x58]
    349c:      	cmp	x20, x8
    34a0:      	ccmp	x2, x9, #0x0, eq
    34a4:      	b.eq	0x3790 <generic_tracepoint_filter+0xb50>
    34a8:      	ldr	x22, [sp, #0x80]
    34ac:      	mov	w8, #0x4                // =4
    34b0:      	add	x0, sp, #0xb8
    34b4:      	mov	w1, #0x8                // =8
    34b8:      	blr	x8
    34bc:      	ldr	x8, [sp, #0xb8]
    34c0:      	cmp	x20, x8
    34c4:      	b.eq	0x3444 <generic_tracepoint_filter+0x804>
    34c8:      	add	x25, x20, #0x18
    34cc:      	mov	w8, #0x4                // =4
    34d0:      	add	x0, sp, #0xd8
    34d4:      	mov	w1, #0x8                // =8
    34d8:      	mov	x2, x25
    34dc:      	blr	x8
    34e0:      	add	x8, sp, #0xd8
    34e4:      	ldr	x8, [x8]
    34e8:      	cmp	x8, x20
    34ec:      	b.eq	0x3444 <generic_tracepoint_filter+0x804>
    34f0:      	mov	w8, #0x4                // =4
    34f4:      	add	x9, sp, #0xc0
    34f8:      	add	x0, sp, #0xc0
    34fc:      	mov	w1, #0x8                // =8
    3500:      	mov	x2, x25
    3504:      	blr	x8
    3508:      	add	x2, x20, #0x20
    350c:      	mov	w8, #0x4                // =4
    3510:      	mov	w9, #0x10               // =16
    3514:      	add	x10, sp, #0xc8
    3518:      	add	x0, sp, #0xc8
    351c:      	mov	w1, #0x10               // =16
    3520:      	blr	x8
    3524:      	ldr	w20, [sp, #0xcc]
    3528:      	ldr	x8, [sp, #0x68]
    352c:      	ldr	x10, [sp, #0x88]
    3530:      	sub	x12, x10, x8
    3534:      	ldr	w22, [sp, #0x90]
    3538:      	subs	w10, w20, w22
    353c:      	ldr	x9, [sp, #0xd0]
    3540:      	csel	w10, wzr, w10, lo
    3544:      	cmp	w22, w20
    3548:      	csel	w11, w22, w20, lo
    354c:      	cinc	w13, w11, hi
    3550:      	sub	w14, w22, w13
    3554:      	subs	x12, x12, x13
    3558:      	str	w14, [sp, #0x90]
    355c:      	b.lo	0x3798 <generic_tracepoint_filter+0xb58>
    3560:      	cmp	x12, #0xfff
    3564:      	b.hi	0x3798 <generic_tracepoint_filter+0xb58>
    3568:      	cmp	w22, w20
    356c:      	b.ls	0x3578 <generic_tracepoint_filter+0x938>
    3570:      	mov	w13, #0x2f              // =47
    3574:      	strb	w13, [x8, x12]
    3578:      	add	x25, x8, x12
    357c:      	cmp	w22, w20
    3580:      	add	x2, x9, x10
    3584:      	and	w1, w11, #0xff
    3588:      	mov	w8, #0x4                // =4
    358c:      	cinc	x0, x25, hi
    3590:      	blr	x8
    3594:      	cmp	w22, w20
    3598:      	str	x25, [sp, #0x88]
    359c:      	b.ls	0x3798 <generic_tracepoint_filter+0xb58>
    35a0:      	ldr	x8, [sp, #0xc0]
    35a4:      	str	x8, [sp, #0x70]
    35a8:      	subs	w19, w19, #0x1
    35ac:      	b.ne	0x3494 <generic_tracepoint_filter+0x854>
    35b0:      	b	0x3798 <generic_tracepoint_filter+0xb58>
    35b4:      	add	x2, x21, #0x18
    35b8:      	mov	w8, #0x8                // =8
    35bc:      	mov	w9, #0x4                // =4
    35c0:      	add	x10, sp, #0x58
    35c4:      	add	x0, sp, #0x58
    35c8:      	mov	w1, #0x8                // =8
    35cc:      	blr	x9
    35d0:      	ldr	x8, [sp, #0x58]
    35d4:      	cmp	x8, x21
    35d8:      	b.eq	0x3384 <generic_tracepoint_filter+0x744>
    35dc:      	ldr	x29, [sp, #0x40]
    35e0:      	ldr	w9, [x29, #0x550]
    35e4:      	sub	w8, w9, #0xa
    35e8:      	cmp	w9, #0x9
    35ec:      	str	w8, [x29, #0x550]
    35f0:      	b.gt	0x3cc0 <generic_tracepoint_filter+0x1080>
    35f4:      	ldr	x21, [sp, #0x30]
    35f8:      	mov	w9, #-0x24              // =-36
    35fc:      	mov	x24, x20
    3600:      	str	w9, [x29, #0x554]
    3604:      	b	0x37fc <generic_tracepoint_filter+0xbbc>
    3608:      	mov	w19, #0x800             // =2048
    360c:      	mov	w21, #0x8               // =8
    3610:      	add	x23, sp, #0xb8
    3614:      	add	x29, sp, #0xd8
    3618:      	b	0x3670 <generic_tracepoint_filter+0xa30>
    361c:      	nop
    3620:      	add	x2, x22, #0x10
    3624:      	mov	w8, #0x4                // =4
    3628:      	add	x0, sp, #0xd8
    362c:      	mov	w1, #0x8                // =8
    3630:      	blr	x8
    3634:      	add	x20, sp, #0xd8
    3638:      	ldr	x8, [sp, #0x80]
    363c:      	ldr	x9, [x20]
    3640:      	cmp	x8, x9
    3644:      	b.eq	0x3790 <generic_tracepoint_filter+0xb50>
    3648:      	add	x2, x22, #0x18
    364c:      	mov	w8, #0x4                // =4
    3650:      	mov	x0, x24
    3654:      	mov	w1, #0x8                // =8
    3658:      	blr	x8
    365c:      	ldr	x8, [x20]
    3660:      	add	x9, x8, #0x20
    3664:      	stp	x9, x8, [sp, #0x78]
    3668:      	subs	w19, w19, #0x1
    366c:      	b.eq	0x3798 <generic_tracepoint_filter+0xb58>
    3670:      	ldp	x20, x2, [sp, #0x70]
    3674:      	ldp	x8, x9, [sp, #0x58]
    3678:      	cmp	x20, x8
    367c:      	ccmp	x2, x9, #0x0, eq
    3680:      	b.eq	0x3790 <generic_tracepoint_filter+0xb50>
    3684:      	ldr	x22, [sp, #0x80]
    3688:      	mov	w8, #0x4                // =4
    368c:      	add	x0, sp, #0xb8
    3690:      	mov	w1, #0x8                // =8
    3694:      	blr	x8
    3698:      	ldr	x8, [sp, #0xb8]
    369c:      	cmp	x20, x8
    36a0:      	b.eq	0x3620 <generic_tracepoint_filter+0x9e0>
    36a4:      	add	x25, x20, #0x18
    36a8:      	mov	w8, #0x4                // =4
    36ac:      	add	x0, sp, #0xd8
    36b0:      	mov	w1, #0x8                // =8
    36b4:      	mov	x2, x25
    36b8:      	blr	x8
    36bc:      	add	x8, sp, #0xd8
    36c0:      	ldr	x8, [x8]
    36c4:      	cmp	x8, x20
    36c8:      	b.eq	0x3620 <generic_tracepoint_filter+0x9e0>
    36cc:      	mov	w8, #0x4                // =4
    36d0:      	add	x9, sp, #0xc0
    36d4:      	add	x0, sp, #0xc0
    36d8:      	mov	w1, #0x8                // =8
    36dc:      	mov	x2, x25
    36e0:      	blr	x8
    36e4:      	add	x2, x20, #0x20
    36e8:      	mov	w8, #0x4                // =4
    36ec:      	mov	w9, #0x10               // =16
    36f0:      	add	x10, sp, #0xc8
    36f4:      	add	x0, sp, #0xc8
    36f8:      	mov	w1, #0x10               // =16
    36fc:      	blr	x8
    3700:      	ldr	w20, [sp, #0xcc]
    3704:      	ldr	x8, [sp, #0x68]
    3708:      	ldr	x10, [sp, #0x88]
    370c:      	sub	x12, x10, x8
    3710:      	ldr	w22, [sp, #0x90]
    3714:      	subs	w10, w20, w22
    3718:      	ldr	x9, [sp, #0xd0]
    371c:      	csel	w10, wzr, w10, lo
    3720:      	cmp	w22, w20
    3724:      	csel	w11, w22, w20, lo
    3728:      	cinc	w13, w11, hi
    372c:      	sub	w14, w22, w13
    3730:      	subs	x12, x12, x13
    3734:      	str	w14, [sp, #0x90]
    3738:      	b.lo	0x3798 <generic_tracepoint_filter+0xb58>
    373c:      	cmp	x12, #0xfff
    3740:      	b.hi	0x3798 <generic_tracepoint_filter+0xb58>
    3744:      	cmp	w22, w20
    3748:      	b.ls	0x3754 <generic_tracepoint_filter+0xb14>
    374c:      	mov	w13, #0x2f              // =47
    3750:      	strb	w13, [x8, x12]
    3754:      	add	x25, x8, x12
    3758:      	cmp	w22, w20
    375c:      	add	x2, x9, x10
    3760:      	and	w1, w11, #0xff
    3764:      	mov	w8, #0x4                // =4
    3768:      	cinc	x0, x25, hi
    376c:      	blr	x8
    3770:      	cmp	w22, w20
    3774:      	str	x25, [sp, #0x88]
    3778:      	b.ls	0x3798 <generic_tracepoint_filter+0xb58>
    377c:      	ldr	x8, [sp, #0xc0]
    3780:      	str	x8, [sp, #0x70]
    3784:      	subs	w19, w19, #0x1
    3788:      	b.ne	0x3670 <generic_tracepoint_filter+0xa30>
    378c:      	b	0x3798 <generic_tracepoint_filter+0xb58>
    3790:      	mov	w8, #0x1                // =1
    3794:      	strb	w8, [sp, #0x94]
    3798:      	ldr	x24, [sp, #0x88]
    379c:      	ldr	x9, [sp, #0x28]
    37a0:      	cmp	x24, x9
    37a4:      	b.eq	0x37e8 <generic_tracepoint_filter+0xba8>
    37a8:      	ldrb	w8, [sp, #0x94]
    37ac:      	ldr	x29, [sp, #0x40]
    37b0:      	cmp	w8, #0x0
    37b4:      	ldr	x21, [sp, #0x30]
    37b8:      	cset	w8, eq
    37bc:      	lsl	w9, w8, #1
    37c0:      	ldr	w8, [sp, #0x90]
    37c4:      	cmp	w8, #0x1
    37c8:      	str	w8, [x29, #0x550]
    37cc:      	str	w9, [x29, #0x554]
    37d0:      	b.lt	0x37e0 <generic_tracepoint_filter+0xba0>
    37d4:      	mov	w9, #0x1000             // =4096
    37d8:      	sub	w8, w9, w8
    37dc:      	str	w8, [x29, #0x550]
    37e0:      	cbnz	x24, 0x37fc <generic_tracepoint_filter+0xbbc>
    37e4:      	b	0x3914 <generic_tracepoint_filter+0xcd4>
    37e8:      	ldr	x29, [sp, #0x40]
    37ec:      	ldr	x21, [sp, #0x30]
    37f0:      	mov	w8, wzr
    37f4:      	mov	x24, x9
    37f8:      	str	xzr, [x29, #0x550]
    37fc:      	subs	w9, w8, #0x7f
    3800:      	mov	w10, #0x7f              // =127
    3804:      	mov	x11, x29
    3808:      	mov	x0, x21
    380c:      	mov	x2, x24
    3810:      	csel	w29, w8, w10, lo
    3814:      	csel	w19, wzr, w9, lo
    3818:      	cmp	w8, #0xff
    381c:      	mov	w9, #0xff               // =255
    3820:      	csel	w8, w8, w9, lo
    3824:      	and	w1, w8, #0xff
    3828:      	str	w1, [x11, #0x550]
    382c:      	mov	w8, #0x4                // =4
    3830:      	blr	x8
    3834:      	adrp	x25, 0x3000 <generic_tracepoint_filter+0x3c0>
    3838:      	ldr	x25, [x25]
    383c:      	cbz	x0, 0x38ac <generic_tracepoint_filter+0xc6c>
    3840:      	neg	w8, w0
    3844:      	mov	w9, #0x1                // =1
    3848:      	add	x1, sp, #0x58
    384c:      	strh	w8, [sp, #0x58]
    3850:      	mov	w8, #0x8                // =8
    3854:      	mov	x0, x25
    3858:      	mov	w20, #0x1               // =1
    385c:      	strh	w8, [sp, #0x5a]
    3860:      	mov	x8, #0x2de              // =734
    3864:      	movk	x8, #0x4, lsl #32
    3868:      	stur	x8, [sp, #0x5c]
    386c:      	add	x8, sp, #0x58
    3870:      	blr	x9
    3874:      	cbz	x0, 0x3888 <generic_tracepoint_filter+0xc48>
    3878:      	ldr	w8, [x0]
    387c:      	add	w8, w8, #0x1
    3880:      	str	w8, [x0]
    3884:      	b	0x38ac <generic_tracepoint_filter+0xc6c>
    3888:      	str	w20, [sp, #0xc8]
    388c:      	mov	x3, xzr
    3890:      	mov	w8, #0x2                // =2
    3894:      	add	x9, sp, #0x58
    3898:      	add	x10, sp, #0xc8
    389c:      	add	x1, sp, #0x58
    38a0:      	add	x2, sp, #0xc8
    38a4:      	mov	x0, x25
    38a8:      	blr	x8
    38ac:      	ldr	x9, [sp, #0xe8]
    38b0:      	mov	w8, #0x6390             // =25488
    38b4:      	add	x2, x24, x19
    38b8:      	mov	w1, w29
    38bc:      	add	x0, x9, x8
    38c0:      	mov	w8, #0x4                // =4
    38c4:      	blr	x8
    38c8:      	ldr	x29, [sp, #0x40]
    38cc:      	cbz	x0, 0x3914 <generic_tracepoint_filter+0xcd4>
    38d0:      	neg	w8, w0
    38d4:      	mov	w9, #0x1                // =1
    38d8:      	add	x1, sp, #0x58
    38dc:      	strh	w8, [sp, #0x58]
    38e0:      	mov	w8, #0x8                // =8
    38e4:      	mov	x0, x25
    38e8:      	mov	w19, #0x1               // =1
    38ec:      	strh	w8, [sp, #0x5a]
    38f0:      	mov	x8, #0x2e0              // =736
    38f4:      	movk	x8, #0x4, lsl #32
    38f8:      	stur	x8, [sp, #0x5c]
    38fc:      	add	x8, sp, #0x58
    3900:      	blr	x9
    3904:      	cbz	x0, 0x393c <generic_tracepoint_filter+0xcfc>
    3908:      	ldr	w8, [x0]
    390c:      	add	w8, w8, #0x1
    3910:      	str	w8, [x0]
    3914:      	ldr	w8, [x29, #0x550]
    3918:      	sub	w9, w8, #0x101
    391c:      	cmn	w9, #0x101
    3920:      	b.hi	0x3970 <generic_tracepoint_filter+0xd30>
    3924:      	ldr	x20, [sp, #0x38]
    3928:      	ldr	x22, [sp, #0xe8]
    392c:      	mov	w8, #-0x1               // =-1
    3930:      	ldr	x24, [sp, #0x48]
    3934:      	stur	w8, [x29, #0xb8]
    3938:      	b	0x3ac0 <generic_tracepoint_filter+0xe80>
    393c:      	str	w19, [sp, #0xc8]
    3940:      	mov	x3, xzr
    3944:      	mov	w8, #0x2                // =2
    3948:      	add	x9, sp, #0x58
    394c:      	add	x10, sp, #0xc8
    3950:      	add	x1, sp, #0x58
    3954:      	add	x2, sp, #0xc8
    3958:      	mov	x0, x25
    395c:      	blr	x8
    3960:      	ldr	w8, [x29, #0x550]
    3964:      	sub	w9, w8, #0x101
    3968:      	cmn	w9, #0x101
    396c:      	b.ls	0x3924 <generic_tracepoint_filter+0xce4>
    3970:      	ldr	x22, [sp, #0xe8]
    3974:      	and	x24, x8, #0xff
    3978:      	mov	w8, #0x5f80             // =24448
    397c:      	mov	x2, x21
    3980:      	mov	w1, w24
    3984:      	add	x0, x22, x8
    3988:      	mov	w8, #0x4                // =4
    398c:      	blr	x8
    3990:      	mov	x23, x0
    3994:      	cbz	x0, 0x3a10 <generic_tracepoint_filter+0xdd0>
    3998:      	neg	w8, w23
    399c:      	adrp	x25, 0x3000 <generic_tracepoint_filter+0x3c0>
    39a0:      	mov	w9, #0x1                // =1
    39a4:      	strh	w8, [sp, #0x58]
    39a8:      	mov	w8, #0xf                // =15
    39ac:      	add	x1, sp, #0x58
    39b0:      	mov	w19, #0x1               // =1
    39b4:      	strh	w8, [sp, #0x5a]
    39b8:      	mov	x8, #0x164              // =356
    39bc:      	movk	x8, #0x4, lsl #32
    39c0:      	stur	x8, [sp, #0x5c]
    39c4:      	add	x8, sp, #0x58
    39c8:      	ldr	x25, [x25]
    39cc:      	mov	x0, x25
    39d0:      	blr	x9
    39d4:      	cbz	x0, 0x39e8 <generic_tracepoint_filter+0xda8>
    39d8:      	ldr	w8, [x0]
    39dc:      	add	w8, w8, #0x1
    39e0:      	str	w8, [x0]
    39e4:      	b	0x3a0c <generic_tracepoint_filter+0xdcc>
    39e8:      	str	w19, [sp, #0xc8]
    39ec:      	mov	x3, xzr
    39f0:      	mov	w8, #0x2                // =2
    39f4:      	add	x9, sp, #0x58
    39f8:      	add	x10, sp, #0xc8
    39fc:      	add	x1, sp, #0x58
    3a00:      	add	x2, sp, #0xc8
    3a04:      	mov	x0, x25
    3a08:      	blr	x8
    3a0c:      	ldr	x22, [sp, #0xe8]
    3a10:      	cmp	w23, #0x0
    3a14:      	csel	w8, w24, w23, eq
    3a18:      	cmp	w24, #0x7f
    3a1c:      	stur	w8, [x29, #0xb8]
    3a20:      	mov	w8, #0x7f               // =127
    3a24:      	csel	w1, w24, w8, lo
    3a28:      	mov	w8, #0x6080             // =24704
    3a2c:      	add	x0, x22, x8
    3a30:      	mov	w8, #0x6390             // =25488
    3a34:      	add	x2, x22, x8
    3a38:      	mov	w8, #0x4                // =4
    3a3c:      	blr	x8
    3a40:      	ldr	x20, [sp, #0x38]
    3a44:      	ldr	x24, [sp, #0x48]
    3a48:      	cbz	x0, 0x3ac0 <generic_tracepoint_filter+0xe80>
    3a4c:      	neg	w8, w0
    3a50:      	adrp	x23, 0x3000 <generic_tracepoint_filter+0x3c0>
    3a54:      	mov	w9, #0x1                // =1
    3a58:      	strh	w8, [sp, #0x58]
    3a5c:      	mov	w8, #0xf                // =15
    3a60:      	add	x1, sp, #0x58
    3a64:      	mov	w19, #0x1               // =1
    3a68:      	strh	w8, [sp, #0x5a]
    3a6c:      	mov	x8, #0x16a              // =362
    3a70:      	movk	x8, #0x4, lsl #32
    3a74:      	stur	x8, [sp, #0x5c]
    3a78:      	add	x8, sp, #0x58
    3a7c:      	ldr	x23, [x23]
    3a80:      	mov	x0, x23
    3a84:      	blr	x9
    3a88:      	cbz	x0, 0x3a9c <generic_tracepoint_filter+0xe5c>
    3a8c:      	ldr	w8, [x0]
    3a90:      	add	w8, w8, #0x1
    3a94:      	str	w8, [x0]
    3a98:      	b	0x3ac0 <generic_tracepoint_filter+0xe80>
    3a9c:      	str	w19, [sp, #0xc8]
    3aa0:      	mov	x3, xzr
    3aa4:      	mov	w8, #0x2                // =2
    3aa8:      	add	x9, sp, #0x58
    3aac:      	add	x10, sp, #0xc8
    3ab0:      	add	x1, sp, #0x58
    3ab4:      	add	x2, sp, #0xc8
    3ab8:      	mov	x0, x23
    3abc:      	blr	x8
    3ac0:      	ldrb	w8, [x22, #0x1]
    3ac4:      	orr	w8, w8, #0x10
    3ac8:      	strb	w8, [x22, #0x1]
    3acc:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x3c0>
    3ad0:      	mov	w8, #0x5ef8             // =24312
    3ad4:      	ldr	x0, [x0]
    3ad8:      	add	x1, x22, x8
    3adc:      	mov	w8, #0x1                // =1
    3ae0:      	blr	x8
    3ae4:      	cbz	x0, 0x4f6c <generic_tracepoint_filter+0x232c>
    3ae8:      	ldr	x21, [x22, #0x5eb8]
    3aec:      	cmp	x21, #0x6
    3af0:      	b.hs	0x3c88 <generic_tracepoint_filter+0x1048>
    3af4:      	ldrsw	x8, [x0]
    3af8:      	mov	x23, x0
    3afc:      	cbz	w8, 0x3ca4 <generic_tracepoint_filter+0x1064>
    3b00:      	cmp	x21, x8
    3b04:      	b.hs	0x3c88 <generic_tracepoint_filter+0x1048>
    3b08:      	str	x8, [sp, #0x28]
    3b0c:      	stp	x29, x24, [sp, #0x40]
    3b10:      	adrp	x24, 0x3000 <generic_tracepoint_filter+0x3c0>
    3b14:      	mov	w8, #0x1                // =1
    3b18:      	add	x9, sp, #0xd8
    3b1c:      	str	x22, [sp, #0xe8]
    3b20:      	add	x1, sp, #0xd8
    3b24:      	str	x20, [sp, #0x38]
    3b28:      	str	w21, [sp, #0xd8]
    3b2c:      	str	wzr, [sp, #0xc0]
    3b30:      	ldr	x24, [x24]
    3b34:      	mov	x0, x24
    3b38:      	blr	x8
    3b3c:      	cbz	x0, 0x3f4c <generic_tracepoint_filter+0x130c>
    3b40:      	ldr	w8, [x0]
    3b44:      	mov	x25, x0
    3b48:      	cbz	w8, 0x3f4c <generic_tracepoint_filter+0x130c>
    3b4c:      	ldr	x9, [sp, #0x48]
    3b50:      	ldr	w9, [x9, #0x68]
    3b54:      	tbnz	w9, #0x1f, 0x4f14 <generic_tracepoint_filter+0x22d4>
    3b58:      	cmp	w8, #0x1b
    3b5c:      	b.hi	0x4f14 <generic_tracepoint_filter+0x22d4>
    3b60:      	mov	w9, #0x1                // =1
    3b64:      	lsl	w9, w9, w8
    3b68:      	tst	w9, #0x60
    3b6c:      	b.ne	0x3d64 <generic_tracepoint_filter+0x1124>
    3b70:      	mov	w10, #0x100             // =256
    3b74:      	movk	w10, #0x400, lsl #16
    3b78:      	tst	w9, w10
    3b7c:      	b.ne	0x3ce0 <generic_tracepoint_filter+0x10a0>
    3b80:      	mov	w9, #0x1                // =1
    3b84:      	lsl	w8, w9, w8
    3b88:      	mov	w9, #0x200              // =512
    3b8c:      	movk	w9, #0x800, lsl #16
    3b90:      	tst	w8, w9
    3b94:      	b.eq	0x4f14 <generic_tracepoint_filter+0x22d4>
    3b98:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x3c0>
    3b9c:      	add	x1, x25, #0x4
    3ba0:      	mov	w8, #0x1                // =1
    3ba4:      	ldr	x0, [x0]
    3ba8:      	blr	x8
    3bac:      	cbz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    3bb0:      	ldr	x8, [sp, #0x48]
    3bb4:      	mov	x20, x0
    3bb8:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x3c0>
    3bbc:      	mov	w9, #0x7f               // =127
    3bc0:      	ldr	w8, [x8, #0x68]
    3bc4:      	ldr	x0, [x0]
    3bc8:      	add	x1, sp, #0xc0
    3bcc:      	cmp	w8, #0x7f
    3bd0:      	csel	w19, w8, w9, lt
    3bd4:      	mov	w8, #0x1                // =1
    3bd8:      	add	x9, sp, #0xc0
    3bdc:      	blr	x8
    3be0:      	cbz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    3be4:      	sxtw	x1, w19
    3be8:      	mov	x29, x0
    3bec:      	lsl	w8, w1, #3
    3bf0:      	str	w8, [x0]
    3bf4:      	ldr	x8, [sp, #0x48]
    3bf8:      	ldr	w8, [x8, #0x6c]
    3bfc:      	cbnz	w8, 0x3c5c <generic_tracepoint_filter+0x101c>
    3c00:      	ldr	x11, [sp, #0x48]
    3c04:      	and	w13, w1, #0x7f
    3c08:      	mov	x8, xzr
    3c0c:      	ldr	w12, [x11, #0x68]
    3c10:      	add	x9, x11, #0x1f0
    3c14:      	add	x10, x11, #0x170
    3c18:      	sub	w11, w12, w1
    3c1c:      	add	w12, w12, w13
    3c20:      	add	w11, w11, w13
    3c24:      	mvn	w13, w1
    3c28:      	add	w12, w13, w12
    3c2c:      	cmp	x8, #0x7f
    3c30:      	b.eq	0x3c50 <generic_tracepoint_filter+0x1010>
    3c34:      	and	x13, x12, #0x7f
    3c38:      	sub	w12, w12, #0x1
    3c3c:      	ldrb	w13, [x10, x13]
    3c40:      	strb	w13, [x9, x8]
    3c44:      	add	x8, x8, #0x1
    3c48:      	cmp	x11, x8
    3c4c:      	b.ne	0x3c2c <generic_tracepoint_filter+0xfec>
    3c50:      	ldr	x9, [sp, #0x48]
    3c54:      	mov	w8, #0x1                // =1
    3c58:      	str	w8, [x9, #0x6c]
    3c5c:      	cmp	w1, #0x7f
    3c60:      	b.hi	0x3c7c <generic_tracepoint_filter+0x103c>
    3c64:      	ldr	x8, [sp, #0x48]
    3c68:      	add	x0, x29, #0x4
    3c6c:      	add	x2, x8, #0x1f0
    3c70:      	mov	w8, #0x4                // =4
    3c74:      	blr	x8
    3c78:      	tbnz	x0, #0x3f, 0x4f14 <generic_tracepoint_filter+0x22d4>
    3c7c:      	mov	w8, #0x1                // =1
    3c80:      	mov	x0, x20
    3c84:      	b	0x3d5c <generic_tracepoint_filter+0x111c>
    3c88:      	ldr	w8, [x24]
    3c8c:      	str	w8, [x22, #0x10]
    3c90:      	ldr	x8, [x24, #0x8]
    3c94:      	str	x8, [x22, #0x18]
    3c98:      	ldrb	w8, [x29]
    3c9c:      	cbnz	w8, 0x4f50 <generic_tracepoint_filter+0x2310>
    3ca0:      	b	0x4f6c <generic_tracepoint_filter+0x232c>
    3ca4:      	mov	w8, #0x1                // =1
    3ca8:      	strb	w8, [x29]
    3cac:      	ldr	w8, [x24]
    3cb0:      	str	w8, [x22, #0x10]
    3cb4:      	ldr	x8, [x24, #0x8]
    3cb8:      	str	x8, [x22, #0x18]
    3cbc:      	b	0x4f50 <generic_tracepoint_filter+0x2310>
    3cc0:      	mov	w8, #0x2964             // =10596
    3cc4:      	add	x20, x24, #0xff6
    3cc8:      	strh	w8, [x24, #0xffe]
    3ccc:      	adrp	x8, 0x3000 <generic_tracepoint_filter+0x3c0>
    3cd0:      	add	x8, x8, #0x0
    3cd4:      	ldr	x8, [x8]
    3cd8:      	str	x8, [x20]
    3cdc:      	b	0x3384 <generic_tracepoint_filter+0x744>
    3ce0:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x3c0>
    3ce4:      	add	x1, x25, #0x4
    3ce8:      	mov	w8, #0x1                // =1
    3cec:      	ldr	x0, [x0]
    3cf0:      	blr	x8
    3cf4:      	cbz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    3cf8:      	mov	x19, x0
    3cfc:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x3c0>
    3d00:      	mov	w8, #0x1                // =1
    3d04:      	ldr	x0, [x0]
    3d08:      	add	x9, sp, #0xc0
    3d0c:      	add	x1, sp, #0xc0
    3d10:      	blr	x8
    3d14:      	cbz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    3d18:      	mov	w1, wzr
    3d1c:      	mov	w2, #0x104              // =260
    3d20:      	mov	x29, x0
    3d24:      	bl	0x3d24 <generic_tracepoint_filter+0x10e4>
    3d28:      	ldr	x10, [sp, #0x48]
    3d2c:      	mov	x0, x29
    3d30:      	ldr	w8, [x10, #0x68]
    3d34:      	add	x2, x10, #0x70
    3d38:      	lsl	w9, w8, #3
    3d3c:      	and	x8, x8, #0xff
    3d40:      	str	w9, [x0], #0x4
    3d44:      	mov	w9, #0x4                // =4
    3d48:      	ldrb	w1, [x10, #0x68]
    3d4c:      	blr	x9
    3d50:      	tbnz	x0, #0x3f, 0x4f14 <generic_tracepoint_filter+0x22d4>
    3d54:      	mov	w8, #0x1                // =1
    3d58:      	mov	x0, x19
    3d5c:      	mov	x1, x29
    3d60:      	b	0x3f14 <generic_tracepoint_filter+0x12d4>
    3d64:      	str	wzr, [sp, #0xc8]
    3d68:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x3c0>
    3d6c:      	mov	w8, #0x1                // =1
    3d70:      	add	x9, sp, #0xc8
    3d74:      	ldr	x0, [x0]
    3d78:      	add	x1, sp, #0xc8
    3d7c:      	blr	x8
    3d80:      	cbz	x0, 0x3ec0 <generic_tracepoint_filter+0x1280>
    3d84:      	ldr	x9, [sp, #0x48]
    3d88:      	ldr	x8, [x0]
    3d8c:      	ldr	x9, [x9, #0x378]
    3d90:      	cmp	x8, x9
    3d94:      	b.eq	0x3ec0 <generic_tracepoint_filter+0x1280>
    3d98:      	str	x0, [sp, #0x30]
    3d9c:      	adrp	x8, 0x3000 <generic_tracepoint_filter+0x3c0>
    3da0:      	mov	w20, wzr
    3da4:      	mov	x19, xzr
    3da8:      	ldr	x8, [x8]
    3dac:      	ldrb	w8, [x8]
    3db0:      	ldr	x9, [sp, #0x48]
    3db4:      	add	x22, x9, #0x370
    3db8:      	cbz	w8, 0x3e88 <generic_tracepoint_filter+0x1248>
    3dbc:      	ldr	x8, [sp, #0x48]
    3dc0:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x3c0>
    3dc4:      	add	x9, sp, #0x58
    3dc8:      	add	x1, sp, #0x58
    3dcc:      	ldr	w8, [x8, #0x10]
    3dd0:      	str	w8, [sp, #0x58]
    3dd4:      	mov	w8, #0x1                // =1
    3dd8:      	ldr	x0, [x0]
    3ddc:      	blr	x8
    3de0:      	cbz	x0, 0x3eb0 <generic_tracepoint_filter+0x1270>
    3de4:      	mov	x29, x0
    3de8:      	add	x1, x0, #0x70
    3dec:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x3c0>
    3df0:      	ldr	x0, [x0]
    3df4:      	mov	w8, #0x1                // =1
    3df8:      	blr	x8
    3dfc:      	cbz	x0, 0x3e18 <generic_tracepoint_filter+0x11d8>
    3e00:      	ldr	x8, [x0]
    3e04:      	cbz	x8, 0x3e18 <generic_tracepoint_filter+0x11d8>
    3e08:      	ldaxr	x9, [x22]
    3e0c:      	orr	x9, x9, x8
    3e10:      	stlxr	w10, x9, [x22]
    3e14:      	cbnz	w10, 0x3e08 <generic_tracepoint_filter+0x11c8>
    3e18:      	cmp	x29, x19
    3e1c:      	b.eq	0x3eb0 <generic_tracepoint_filter+0x1270>
    3e20:      	mov	w8, #0x86a0             // =34464
    3e24:      	add	w20, w20, #0x1
    3e28:      	mov	x19, x29
    3e2c:      	movk	w8, #0x1, lsl #16
    3e30:      	cmp	w20, w8
    3e34:      	b.ne	0x3dbc <generic_tracepoint_filter+0x117c>
    3e38:      	b	0x3eb0 <generic_tracepoint_filter+0x1270>
    3e3c:      	mov	x29, x0
    3e40:      	add	x1, x0, #0x70
    3e44:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x3c0>
    3e48:      	ldr	x0, [x0]
    3e4c:      	mov	w8, #0x1                // =1
    3e50:      	blr	x8
    3e54:      	cbz	x0, 0x3e70 <generic_tracepoint_filter+0x1230>
    3e58:      	ldr	x8, [x0]
    3e5c:      	cbz	x8, 0x3e70 <generic_tracepoint_filter+0x1230>
    3e60:      	ldaxr	x9, [x22]
    3e64:      	orr	x9, x9, x8
    3e68:      	stlxr	w10, x9, [x22]
    3e6c:      	cbnz	w10, 0x3e60 <generic_tracepoint_filter+0x1220>
    3e70:      	cmp	x29, x19
    3e74:      	b.eq	0x3eb0 <generic_tracepoint_filter+0x1270>
    3e78:      	add	w20, w20, #0x1
    3e7c:      	mov	x19, x29
    3e80:      	cmp	w20, #0x400
    3e84:      	b.eq	0x3eb0 <generic_tracepoint_filter+0x1270>
    3e88:      	ldr	x8, [sp, #0x48]
    3e8c:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x3c0>
    3e90:      	add	x9, sp, #0x58
    3e94:      	add	x1, sp, #0x58
    3e98:      	ldr	w8, [x8, #0x10]
    3e9c:      	str	w8, [sp, #0x58]
    3ea0:      	mov	w8, #0x1                // =1
    3ea4:      	ldr	x0, [x0]
    3ea8:      	blr	x8
    3eac:      	cbnz	x0, 0x3e3c <generic_tracepoint_filter+0x11fc>
    3eb0:      	ldr	x8, [sp, #0x30]
    3eb4:      	ldr	x9, [sp, #0x48]
    3eb8:      	ldr	x8, [x8]
    3ebc:      	str	x8, [x9, #0x378]
    3ec0:      	ldr	w8, [x25, #0x8]
    3ec4:      	cmn	w8, #0x1
    3ec8:      	b.eq	0x3eec <generic_tracepoint_filter+0x12ac>
    3ecc:      	ldr	x9, [sp, #0x48]
    3ed0:      	ldr	x9, [x9, #0x370]
    3ed4:      	lsr	x8, x9, x8
    3ed8:      	tbz	w8, #0x0, 0x3eec <generic_tracepoint_filter+0x12ac>
    3edc:      	mov	x0, #0xffee             // =65518
    3ee0:      	movk	x0, #0xadc0, lsl #16
    3ee4:      	movk	x0, #0xb, lsl #32
    3ee8:      	b	0x3f18 <generic_tracepoint_filter+0x12d8>
    3eec:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x3c0>
    3ef0:      	mov	w8, #0x1                // =1
    3ef4:      	add	x9, sp, #0xd8
    3ef8:      	ldr	x0, [x0]
    3efc:      	add	x1, sp, #0xd8
    3f00:      	blr	x8
    3f04:      	cbz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    3f08:      	ldr	x8, [sp, #0x48]
    3f0c:      	add	x1, x8, #0x70
    3f10:      	mov	w8, #0x1                // =1
    3f14:      	blr	x8
    3f18:      	ldr	w8, [x25]
    3f1c:      	cmp	w8, #0x25
    3f20:      	b.hi	0x3f48 <generic_tracepoint_filter+0x1308>
    3f24:      	mov	w9, #0x1                // =1
    3f28:      	lsl	x8, x9, x8
    3f2c:      	mov	x9, #0x50               // =80
    3f30:      	movk	x9, #0xc00, lsl #16
    3f34:      	movk	x9, #0x20, lsl #32
    3f38:      	tst	x8, x9
    3f3c:      	b.eq	0x3f48 <generic_tracepoint_filter+0x1308>
    3f40:      	cbnz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    3f44:      	b	0x3f4c <generic_tracepoint_filter+0x130c>
    3f48:      	cbz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    3f4c:      	adrp	x8, 0x3000 <generic_tracepoint_filter+0x3c0>
    3f50:      	ldr	x8, [x8]
    3f54:      	ldrb	w8, [x8]
    3f58:      	cbz	w8, 0x4320 <generic_tracepoint_filter+0x16e0>
    3f5c:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x3c0>
    3f60:      	mov	w8, #0x1                // =1
    3f64:      	ldr	x0, [x0]
    3f68:      	ldr	x1, [sp, #0x48]
    3f6c:      	blr	x8
    3f70:      	cbz	x0, 0x4320 <generic_tracepoint_filter+0x16e0>
    3f74:      	add	w8, w21, #0x5
    3f78:      	str	wzr, [sp, #0xc0]
    3f7c:      	add	x9, sp, #0xd8
    3f80:      	mov	x25, x0
    3f84:      	str	w8, [sp, #0xd8]
    3f88:      	mov	w8, #0x1                // =1
    3f8c:      	add	x1, sp, #0xd8
    3f90:      	mov	x0, x24
    3f94:      	blr	x8
    3f98:      	cbz	x0, 0x4320 <generic_tracepoint_filter+0x16e0>
    3f9c:      	ldr	w8, [x0]
    3fa0:      	mov	x24, x0
    3fa4:      	cbz	w8, 0x4320 <generic_tracepoint_filter+0x16e0>
    3fa8:      	ldr	w9, [x25]
    3fac:      	tbnz	w9, #0x1f, 0x4f14 <generic_tracepoint_filter+0x22d4>
    3fb0:      	cmp	w8, #0x1b
    3fb4:      	b.hi	0x4f14 <generic_tracepoint_filter+0x22d4>
    3fb8:      	mov	w9, #0x1                // =1
    3fbc:      	lsl	w9, w9, w8
    3fc0:      	tst	w9, #0x60
    3fc4:      	b.ne	0x414c <generic_tracepoint_filter+0x150c>
    3fc8:      	mov	w10, #0x100             // =256
    3fcc:      	movk	w10, #0x400, lsl #16
    3fd0:      	tst	w9, w10
    3fd4:      	b.ne	0x40cc <generic_tracepoint_filter+0x148c>
    3fd8:      	mov	w9, #0x1                // =1
    3fdc:      	lsl	w8, w9, w8
    3fe0:      	mov	w9, #0x200              // =512
    3fe4:      	movk	w9, #0x800, lsl #16
    3fe8:      	tst	w8, w9
    3fec:      	b.eq	0x4f14 <generic_tracepoint_filter+0x22d4>
    3ff0:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x3c0>
    3ff4:      	add	x1, x24, #0x4
    3ff8:      	mov	w8, #0x1                // =1
    3ffc:      	ldr	x0, [x0]
    4000:      	blr	x8
    4004:      	cbz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    4008:      	ldr	w8, [x25]
    400c:      	mov	x20, x0
    4010:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    4014:      	mov	w9, #0x7f               // =127
    4018:      	ldr	x0, [x0]
    401c:      	add	x1, sp, #0xc0
    4020:      	cmp	w8, #0x7f
    4024:      	csel	w19, w8, w9, lt
    4028:      	mov	w8, #0x1                // =1
    402c:      	add	x9, sp, #0xc0
    4030:      	blr	x8
    4034:      	cbz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    4038:      	sxtw	x1, w19
    403c:      	mov	x29, x0
    4040:      	lsl	w8, w1, #3
    4044:      	str	w8, [x0]
    4048:      	ldr	w8, [x25, #0x4]
    404c:      	cbnz	w8, 0x40a4 <generic_tracepoint_filter+0x1464>
    4050:      	ldr	w12, [x25]
    4054:      	and	w13, w1, #0x7f
    4058:      	mov	x8, xzr
    405c:      	add	x9, x25, #0x188
    4060:      	add	x10, x25, #0x108
    4064:      	sub	w11, w12, w1
    4068:      	add	w12, w12, w13
    406c:      	add	w11, w11, w13
    4070:      	mvn	w13, w1
    4074:      	add	w12, w13, w12
    4078:      	cmp	x8, #0x7f
    407c:      	b.eq	0x409c <generic_tracepoint_filter+0x145c>
    4080:      	and	x13, x12, #0x7f
    4084:      	sub	w12, w12, #0x1
    4088:      	ldrb	w13, [x10, x13]
    408c:      	strb	w13, [x9, x8]
    4090:      	add	x8, x8, #0x1
    4094:      	cmp	x11, x8
    4098:      	b.ne	0x4078 <generic_tracepoint_filter+0x1438>
    409c:      	mov	w8, #0x1                // =1
    40a0:      	str	w8, [x25, #0x4]
    40a4:      	cmp	w1, #0x7f
    40a8:      	b.hi	0x40c0 <generic_tracepoint_filter+0x1480>
    40ac:      	add	x0, x29, #0x4
    40b0:      	add	x2, x25, #0x188
    40b4:      	mov	w8, #0x4                // =4
    40b8:      	blr	x8
    40bc:      	tbnz	x0, #0x3f, 0x4f14 <generic_tracepoint_filter+0x22d4>
    40c0:      	mov	w8, #0x1                // =1
    40c4:      	mov	x0, x20
    40c8:      	b	0x4144 <generic_tracepoint_filter+0x1504>
    40cc:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    40d0:      	add	x1, x24, #0x4
    40d4:      	mov	w8, #0x1                // =1
    40d8:      	ldr	x0, [x0]
    40dc:      	blr	x8
    40e0:      	cbz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    40e4:      	mov	x19, x0
    40e8:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    40ec:      	mov	w8, #0x1                // =1
    40f0:      	ldr	x0, [x0]
    40f4:      	add	x9, sp, #0xc0
    40f8:      	add	x1, sp, #0xc0
    40fc:      	blr	x8
    4100:      	cbz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    4104:      	mov	w1, wzr
    4108:      	mov	w2, #0x104              // =260
    410c:      	mov	x29, x0
    4110:      	bl	0x4110 <generic_tracepoint_filter+0x14d0>
    4114:      	ldr	w8, [x25]
    4118:      	mov	x0, x29
    411c:      	add	x2, x25, #0x8
    4120:      	lsl	w9, w8, #3
    4124:      	and	x8, x8, #0xff
    4128:      	str	w9, [x0], #0x4
    412c:      	mov	w9, #0x4                // =4
    4130:      	ldrb	w1, [x25]
    4134:      	blr	x9
    4138:      	tbnz	x0, #0x3f, 0x4f14 <generic_tracepoint_filter+0x22d4>
    413c:      	mov	w8, #0x1                // =1
    4140:      	mov	x0, x19
    4144:      	mov	x1, x29
    4148:      	b	0x42e8 <generic_tracepoint_filter+0x16a8>
    414c:      	str	wzr, [sp, #0xc8]
    4150:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    4154:      	mov	w8, #0x1                // =1
    4158:      	add	x9, sp, #0xc8
    415c:      	ldr	x0, [x0]
    4160:      	add	x1, sp, #0xc8
    4164:      	blr	x8
    4168:      	cbz	x0, 0x429c <generic_tracepoint_filter+0x165c>
    416c:      	ldr	x8, [x0]
    4170:      	ldr	x9, [x25, #0x310]
    4174:      	cmp	x8, x9
    4178:      	b.eq	0x429c <generic_tracepoint_filter+0x165c>
    417c:      	str	x0, [sp, #0x30]
    4180:      	adrp	x8, 0x4000 <generic_tracepoint_filter+0x13c0>
    4184:      	add	x22, x25, #0x308
    4188:      	mov	w20, wzr
    418c:      	ldr	x8, [x8]
    4190:      	mov	x19, xzr
    4194:      	ldrb	w8, [x8]
    4198:      	cbz	w8, 0x4268 <generic_tracepoint_filter+0x1628>
    419c:      	ldr	x8, [sp, #0x48]
    41a0:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    41a4:      	add	x9, sp, #0x58
    41a8:      	add	x1, sp, #0x58
    41ac:      	ldr	w8, [x8, #0x10]
    41b0:      	str	w8, [sp, #0x58]
    41b4:      	mov	w8, #0x1                // =1
    41b8:      	ldr	x0, [x0]
    41bc:      	blr	x8
    41c0:      	cbz	x0, 0x4290 <generic_tracepoint_filter+0x1650>
    41c4:      	mov	x29, x0
    41c8:      	add	x1, x0, #0x70
    41cc:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    41d0:      	ldr	x0, [x0]
    41d4:      	mov	w8, #0x1                // =1
    41d8:      	blr	x8
    41dc:      	cbz	x0, 0x41f8 <generic_tracepoint_filter+0x15b8>
    41e0:      	ldr	x8, [x0]
    41e4:      	cbz	x8, 0x41f8 <generic_tracepoint_filter+0x15b8>
    41e8:      	ldaxr	x9, [x22]
    41ec:      	orr	x9, x9, x8
    41f0:      	stlxr	w10, x9, [x22]
    41f4:      	cbnz	w10, 0x41e8 <generic_tracepoint_filter+0x15a8>
    41f8:      	cmp	x29, x19
    41fc:      	b.eq	0x4290 <generic_tracepoint_filter+0x1650>
    4200:      	mov	w8, #0x86a0             // =34464
    4204:      	add	w20, w20, #0x1
    4208:      	mov	x19, x29
    420c:      	movk	w8, #0x1, lsl #16
    4210:      	cmp	w20, w8
    4214:      	b.ne	0x419c <generic_tracepoint_filter+0x155c>
    4218:      	b	0x4290 <generic_tracepoint_filter+0x1650>
    421c:      	mov	x29, x0
    4220:      	add	x1, x0, #0x70
    4224:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    4228:      	ldr	x0, [x0]
    422c:      	mov	w8, #0x1                // =1
    4230:      	blr	x8
    4234:      	cbz	x0, 0x4250 <generic_tracepoint_filter+0x1610>
    4238:      	ldr	x8, [x0]
    423c:      	cbz	x8, 0x4250 <generic_tracepoint_filter+0x1610>
    4240:      	ldaxr	x9, [x22]
    4244:      	orr	x9, x9, x8
    4248:      	stlxr	w10, x9, [x22]
    424c:      	cbnz	w10, 0x4240 <generic_tracepoint_filter+0x1600>
    4250:      	cmp	x29, x19
    4254:      	b.eq	0x4290 <generic_tracepoint_filter+0x1650>
    4258:      	add	w20, w20, #0x1
    425c:      	mov	x19, x29
    4260:      	cmp	w20, #0x400
    4264:      	b.eq	0x4290 <generic_tracepoint_filter+0x1650>
    4268:      	ldr	x8, [sp, #0x48]
    426c:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    4270:      	add	x9, sp, #0x58
    4274:      	add	x1, sp, #0x58
    4278:      	ldr	w8, [x8, #0x10]
    427c:      	str	w8, [sp, #0x58]
    4280:      	mov	w8, #0x1                // =1
    4284:      	ldr	x0, [x0]
    4288:      	blr	x8
    428c:      	cbnz	x0, 0x421c <generic_tracepoint_filter+0x15dc>
    4290:      	ldr	x8, [sp, #0x30]
    4294:      	ldr	x8, [x8]
    4298:      	str	x8, [x25, #0x310]
    429c:      	ldr	w8, [x24, #0x8]
    42a0:      	cmn	w8, #0x1
    42a4:      	b.eq	0x42c4 <generic_tracepoint_filter+0x1684>
    42a8:      	ldr	x9, [x25, #0x308]
    42ac:      	lsr	x8, x9, x8
    42b0:      	tbz	w8, #0x0, 0x42c4 <generic_tracepoint_filter+0x1684>
    42b4:      	mov	x0, #0xffee             // =65518
    42b8:      	movk	x0, #0xadc0, lsl #16
    42bc:      	movk	x0, #0xb, lsl #32
    42c0:      	b	0x42ec <generic_tracepoint_filter+0x16ac>
    42c4:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    42c8:      	mov	w8, #0x1                // =1
    42cc:      	add	x9, sp, #0xd8
    42d0:      	ldr	x0, [x0]
    42d4:      	add	x1, sp, #0xd8
    42d8:      	blr	x8
    42dc:      	cbz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    42e0:      	add	x1, x25, #0x8
    42e4:      	mov	w8, #0x1                // =1
    42e8:      	blr	x8
    42ec:      	ldr	w8, [x24]
    42f0:      	cmp	w8, #0x25
    42f4:      	b.hi	0x431c <generic_tracepoint_filter+0x16dc>
    42f8:      	mov	w9, #0x1                // =1
    42fc:      	lsl	x8, x9, x8
    4300:      	mov	x9, #0x50               // =80
    4304:      	movk	x9, #0xc00, lsl #16
    4308:      	movk	x9, #0x20, lsl #32
    430c:      	tst	x8, x9
    4310:      	b.eq	0x431c <generic_tracepoint_filter+0x16dc>
    4314:      	cbnz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    4318:      	b	0x4320 <generic_tracepoint_filter+0x16e0>
    431c:      	cbz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    4320:      	lsl	w8, w21, #2
    4324:      	add	x9, x8, #0x4
    4328:      	ldr	w8, [x9, x23]
    432c:      	add	w9, w8, w9
    4330:      	and	w11, w9, #0x3ff
    4334:      	add	w9, w9, #0x4
    4338:      	and	x9, x9, #0x3ff
    433c:      	add	x10, x11, #0x8
    4340:      	ldr	w9, [x9, x23]
    4344:      	cmp	w9, #0x5
    4348:      	b.lo	0x43d8 <generic_tracepoint_filter+0x1798>
    434c:      	add	x9, x10, x23
    4350:      	ldr	w10, [x9, #0x8]
    4354:      	ldp	w12, w22, [x9]
    4358:      	stp	x9, x11, [sp, #0x8]
    435c:      	mov	w9, #0x4                // =4
    4360:      	cmp	w10, #0x4
    4364:      	stp	xzr, xzr, [sp, #0x58]
    4368:      	csel	w9, w10, w9, lo
    436c:      	cmp	w12, #0x6
    4370:      	b.ne	0x437c <generic_tracepoint_filter+0x173c>
    4374:      	mov	x11, #0x100000001       // =4294967297
    4378:      	stp	x11, x11, [sp, #0x58]
    437c:      	cbz	w10, 0x47e0 <generic_tracepoint_filter+0x1ba0>
    4380:      	ldr	x10, [sp, #0x48]
    4384:      	add	w8, w8, w21, lsl #2
    4388:      	tst	x22, #0x1
    438c:      	add	x25, sp, #0x58
    4390:      	str	w12, [sp, #0x30]
    4394:      	add	w8, w8, #0x4
    4398:      	and	x8, x8, #0x3ff
    439c:      	add	x21, x8, #0x14
    43a0:      	sub	x8, x9, #0x1
    43a4:      	mov	w9, #0x3                // =3
    43a8:      	add	x11, x10, #0x24
    43ac:      	str	x11, [sp, #0x20]
    43b0:      	csel	x11, x10, x11, eq
    43b4:      	cmp	x8, #0x3
    43b8:      	add	x10, x10, #0x10
    43bc:      	csel	x8, x8, x9, lo
    43c0:      	and	x9, x21, #0x7fc
    43c4:      	mov	x20, x11
    43c8:      	str	x10, [sp, #0x18]
    43cc:      	add	x19, x23, x9
    43d0:      	add	x24, x8, #0x1
    43d4:      	b	0x4410 <generic_tracepoint_filter+0x17d0>
    43d8:      	mov	w9, #0x1                // =1
    43dc:      	mov	w8, w10
    43e0:      	b	0x4828 <generic_tracepoint_filter+0x1be8>
    43e4:      	mov	w8, #0x1                // =1
    43e8:      	ldr	w12, [sp, #0x30]
    43ec:      	mov	x11, x20
    43f0:      	cmp	w12, #0x6
    43f4:      	eor	w8, w8, #0x1
    43f8:      	csinc	w9, w8, wzr, eq
    43fc:      	str	w9, [x25], #0x4
    4400:      	add	x21, x21, #0x4
    4404:      	add	x19, x19, #0x4
    4408:      	subs	x24, x24, #0x1
    440c:      	b.eq	0x47e0 <generic_tracepoint_filter+0x1ba0>
    4410:      	cmp	x21, #0x3e8
    4414:      	b.ls	0x4638 <generic_tracepoint_filter+0x19f8>
    4418:      	mov	x29, xzr
    441c:      	tbz	w22, #0x1, 0x4640 <generic_tracepoint_filter+0x1a00>
    4420:      	tbnz	w22, #0x0, 0x466c <generic_tracepoint_filter+0x1a2c>
    4424:      	ldr	x10, [sp, #0x48]
    4428:      	mov	w8, #0x1                // =1
    442c:      	ldr	w9, [x10]
    4430:      	cmp	x29, x9
    4434:      	b.eq	0x43f0 <generic_tracepoint_filter+0x17b0>
    4438:      	ldr	w9, [x10, #0x10]
    443c:      	cmp	x29, x9
    4440:      	b.eq	0x43f0 <generic_tracepoint_filter+0x17b0>
    4444:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    4448:      	mov	w8, #0x1                // =1
    444c:      	ldr	x0, [x0]
    4450:      	ldr	x1, [sp, #0x18]
    4454:      	blr	x8
    4458:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    445c:      	ldr	w9, [x0]
    4460:      	mov	x1, x0
    4464:      	mov	w8, #0x1                // =1
    4468:      	cmp	x29, x9
    446c:      	b.eq	0x43e8 <generic_tracepoint_filter+0x17a8>
    4470:      	ldr	w9, [x1, #0x10]!
    4474:      	ldr	w12, [sp, #0x30]
    4478:      	mov	x11, x20
    447c:      	cmp	x29, x9
    4480:      	b.eq	0x43f0 <generic_tracepoint_filter+0x17b0>
    4484:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    4488:      	mov	w8, #0x1                // =1
    448c:      	ldr	x0, [x0]
    4490:      	blr	x8
    4494:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    4498:      	ldr	w9, [x0]
    449c:      	mov	x1, x0
    44a0:      	mov	w8, #0x1                // =1
    44a4:      	cmp	x29, x9
    44a8:      	b.eq	0x43e8 <generic_tracepoint_filter+0x17a8>
    44ac:      	ldr	w9, [x1, #0x10]!
    44b0:      	ldr	w12, [sp, #0x30]
    44b4:      	mov	x11, x20
    44b8:      	cmp	x29, x9
    44bc:      	b.eq	0x43f0 <generic_tracepoint_filter+0x17b0>
    44c0:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    44c4:      	mov	w8, #0x1                // =1
    44c8:      	ldr	x0, [x0]
    44cc:      	blr	x8
    44d0:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    44d4:      	ldr	w9, [x0]
    44d8:      	mov	x1, x0
    44dc:      	mov	w8, #0x1                // =1
    44e0:      	cmp	x29, x9
    44e4:      	b.eq	0x43e8 <generic_tracepoint_filter+0x17a8>
    44e8:      	ldr	w9, [x1, #0x10]!
    44ec:      	ldr	w12, [sp, #0x30]
    44f0:      	mov	x11, x20
    44f4:      	cmp	x29, x9
    44f8:      	b.eq	0x43f0 <generic_tracepoint_filter+0x17b0>
    44fc:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    4500:      	mov	w8, #0x1                // =1
    4504:      	ldr	x0, [x0]
    4508:      	blr	x8
    450c:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    4510:      	ldr	w9, [x0]
    4514:      	mov	x1, x0
    4518:      	mov	w8, #0x1                // =1
    451c:      	cmp	x29, x9
    4520:      	b.eq	0x43e8 <generic_tracepoint_filter+0x17a8>
    4524:      	ldr	w9, [x1, #0x10]!
    4528:      	ldr	w12, [sp, #0x30]
    452c:      	mov	x11, x20
    4530:      	cmp	x29, x9
    4534:      	b.eq	0x43f0 <generic_tracepoint_filter+0x17b0>
    4538:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    453c:      	mov	w8, #0x1                // =1
    4540:      	ldr	x0, [x0]
    4544:      	blr	x8
    4548:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    454c:      	ldr	w9, [x0]
    4550:      	mov	x1, x0
    4554:      	mov	w8, #0x1                // =1
    4558:      	cmp	x29, x9
    455c:      	b.eq	0x43e8 <generic_tracepoint_filter+0x17a8>
    4560:      	ldr	w9, [x1, #0x10]!
    4564:      	ldr	w12, [sp, #0x30]
    4568:      	mov	x11, x20
    456c:      	cmp	x29, x9
    4570:      	b.eq	0x43f0 <generic_tracepoint_filter+0x17b0>
    4574:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    4578:      	mov	w8, #0x1                // =1
    457c:      	ldr	x0, [x0]
    4580:      	blr	x8
    4584:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    4588:      	ldr	w9, [x0]
    458c:      	mov	x1, x0
    4590:      	mov	w8, #0x1                // =1
    4594:      	cmp	x29, x9
    4598:      	b.eq	0x43e8 <generic_tracepoint_filter+0x17a8>
    459c:      	ldr	w9, [x1, #0x10]!
    45a0:      	ldr	w12, [sp, #0x30]
    45a4:      	mov	x11, x20
    45a8:      	cmp	x29, x9
    45ac:      	b.eq	0x43f0 <generic_tracepoint_filter+0x17b0>
    45b0:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    45b4:      	mov	w8, #0x1                // =1
    45b8:      	ldr	x0, [x0]
    45bc:      	blr	x8
    45c0:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    45c4:      	ldr	w9, [x0]
    45c8:      	mov	x1, x0
    45cc:      	mov	w8, #0x1                // =1
    45d0:      	cmp	x29, x9
    45d4:      	b.eq	0x43e8 <generic_tracepoint_filter+0x17a8>
    45d8:      	ldr	w9, [x1, #0x10]!
    45dc:      	ldr	w12, [sp, #0x30]
    45e0:      	mov	x11, x20
    45e4:      	cmp	x29, x9
    45e8:      	b.eq	0x43f0 <generic_tracepoint_filter+0x17b0>
    45ec:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    45f0:      	mov	w8, #0x1                // =1
    45f4:      	ldr	x0, [x0]
    45f8:      	blr	x8
    45fc:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    4600:      	ldr	w9, [x0]
    4604:      	mov	x1, x0
    4608:      	mov	w8, #0x1                // =1
    460c:      	cmp	x29, x9
    4610:      	b.eq	0x43e8 <generic_tracepoint_filter+0x17a8>
    4614:      	ldr	w9, [x1, #0x10]!
    4618:      	ldr	w12, [sp, #0x30]
    461c:      	mov	x11, x20
    4620:      	cmp	x29, x9
    4624:      	b.eq	0x43f0 <generic_tracepoint_filter+0x17b0>
    4628:      	adrp	x9, 0x4000 <generic_tracepoint_filter+0x13c0>
    462c:      	mov	w8, #0x1                // =1
    4630:      	ldr	x9, [x9]
    4634:      	b	0x47b8 <generic_tracepoint_filter+0x1b78>
    4638:      	ldr	w29, [x19]
    463c:      	tbnz	w22, #0x1, 0x4420 <generic_tracepoint_filter+0x17e0>
    4640:      	ldr	w8, [x11]
    4644:      	cmp	w12, #0x5
    4648:      	b.ne	0x465c <generic_tracepoint_filter+0x1a1c>
    464c:      	cmp	x29, x8
    4650:      	b.eq	0x465c <generic_tracepoint_filter+0x1a1c>
    4654:      	mov	w9, wzr
    4658:      	b	0x43fc <generic_tracepoint_filter+0x17bc>
    465c:      	cmp	w12, #0x6
    4660:      	ccmp	x29, x8, #0x0, eq
    4664:      	cset	w9, ne
    4668:      	b	0x43fc <generic_tracepoint_filter+0x17bc>
    466c:      	ldr	x8, [sp, #0x20]
    4670:      	ldr	w9, [x8]
    4674:      	cbz	w9, 0x43fc <generic_tracepoint_filter+0x17bc>
    4678:      	mov	w8, #0x1                // =1
    467c:      	cbz	x29, 0x43f0 <generic_tracepoint_filter+0x17b0>
    4680:      	cmp	x29, x9
    4684:      	b.eq	0x43f0 <generic_tracepoint_filter+0x17b0>
    4688:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    468c:      	mov	w8, #0x1                // =1
    4690:      	ldr	x0, [x0]
    4694:      	ldr	x1, [sp, #0x18]
    4698:      	blr	x8
    469c:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    46a0:      	ldr	w8, [x0, #0x24]
    46a4:      	cmp	x29, x8
    46a8:      	b.eq	0x43e4 <generic_tracepoint_filter+0x17a4>
    46ac:      	add	x1, x0, #0x10
    46b0:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    46b4:      	mov	w8, #0x1                // =1
    46b8:      	ldr	x0, [x0]
    46bc:      	blr	x8
    46c0:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    46c4:      	ldr	w8, [x0, #0x24]
    46c8:      	cmp	x29, x8
    46cc:      	b.eq	0x43e4 <generic_tracepoint_filter+0x17a4>
    46d0:      	add	x1, x0, #0x10
    46d4:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    46d8:      	mov	w8, #0x1                // =1
    46dc:      	ldr	x0, [x0]
    46e0:      	blr	x8
    46e4:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    46e8:      	ldr	w8, [x0, #0x24]
    46ec:      	cmp	x29, x8
    46f0:      	b.eq	0x43e4 <generic_tracepoint_filter+0x17a4>
    46f4:      	add	x1, x0, #0x10
    46f8:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    46fc:      	mov	w8, #0x1                // =1
    4700:      	ldr	x0, [x0]
    4704:      	blr	x8
    4708:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    470c:      	ldr	w8, [x0, #0x24]
    4710:      	cmp	x29, x8
    4714:      	b.eq	0x43e4 <generic_tracepoint_filter+0x17a4>
    4718:      	add	x1, x0, #0x10
    471c:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    4720:      	mov	w8, #0x1                // =1
    4724:      	ldr	x0, [x0]
    4728:      	blr	x8
    472c:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    4730:      	ldr	w8, [x0, #0x24]
    4734:      	cmp	x29, x8
    4738:      	b.eq	0x43e4 <generic_tracepoint_filter+0x17a4>
    473c:      	add	x1, x0, #0x10
    4740:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    4744:      	mov	w8, #0x1                // =1
    4748:      	ldr	x0, [x0]
    474c:      	blr	x8
    4750:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    4754:      	ldr	w8, [x0, #0x24]
    4758:      	cmp	x29, x8
    475c:      	b.eq	0x43e4 <generic_tracepoint_filter+0x17a4>
    4760:      	add	x1, x0, #0x10
    4764:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    4768:      	mov	w8, #0x1                // =1
    476c:      	ldr	x0, [x0]
    4770:      	blr	x8
    4774:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    4778:      	ldr	w8, [x0, #0x24]
    477c:      	cmp	x29, x8
    4780:      	b.eq	0x43e4 <generic_tracepoint_filter+0x17a4>
    4784:      	add	x1, x0, #0x10
    4788:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    478c:      	mov	w8, #0x1                // =1
    4790:      	ldr	x0, [x0]
    4794:      	blr	x8
    4798:      	cbz	x0, 0x47c4 <generic_tracepoint_filter+0x1b84>
    479c:      	ldr	w8, [x0, #0x24]
    47a0:      	cmp	x29, x8
    47a4:      	b.eq	0x43e4 <generic_tracepoint_filter+0x17a4>
    47a8:      	adrp	x9, 0x4000 <generic_tracepoint_filter+0x13c0>
    47ac:      	add	x1, x0, #0x10
    47b0:      	mov	w8, #0x1                // =1
    47b4:      	ldr	x9, [x9]
    47b8:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    47bc:      	ldr	x0, [x0]
    47c0:      	blr	x8
    47c4:      	ldr	w12, [sp, #0x30]
    47c8:      	mov	w8, wzr
    47cc:      	mov	w9, wzr
    47d0:      	mov	x11, x20
    47d4:      	cmp	w12, #0x5
    47d8:      	b.ne	0x43f0 <generic_tracepoint_filter+0x17b0>
    47dc:      	b	0x43fc <generic_tracepoint_filter+0x17bc>
    47e0:      	ldp	w8, w9, [sp, #0x58]
    47e4:      	ldp	w10, w11, [sp, #0x60]
    47e8:      	cmp	w12, #0x6
    47ec:      	b.ne	0x4800 <generic_tracepoint_filter+0x1bc0>
    47f0:      	and	w8, w9, w8
    47f4:      	and	w9, w10, w11
    47f8:      	and	w9, w8, w9
    47fc:      	b	0x480c <generic_tracepoint_filter+0x1bcc>
    4800:      	orr	w8, w9, w8
    4804:      	orr	w9, w10, w11
    4808:      	orr	w9, w8, w9
    480c:      	ldr	x8, [sp, #0x10]
    4810:      	cbz	w9, 0x4f14 <generic_tracepoint_filter+0x22d4>
    4814:      	ldr	x10, [sp, #0x8]
    4818:      	add	w8, w8, #0x14
    481c:      	ldr	w10, [x10, #0x8]
    4820:      	ubfiz	w10, w10, #2, #3
    4824:      	add	w8, w10, w8
    4828:      	and	x10, x8, #0x3ff
    482c:      	add	w8, w8, #0x4
    4830:      	mov	w19, #0xa               // =10
    4834:      	ldr	w10, [x10, x23]
    4838:      	mov	w20, #0x4               // =4
    483c:      	mov	x25, #0x100000001       // =4294967297
    4840:      	sub	w22, w10, #0x4
    4844:      	ldr	x10, [sp, #0xe8]
    4848:      	add	x10, x10, #0x20
    484c:      	str	x10, [sp, #0x30]
    4850:      	b	0x4868 <generic_tracepoint_filter+0x1c28>
    4854:      	nop
    4858:      	nop
    485c:      	nop
    4860:      	subs	x19, x19, #0x1
    4864:      	b.eq	0x4a34 <generic_tracepoint_filter+0x1df4>
    4868:      	cbz	w22, 0x4860 <generic_tracepoint_filter+0x1c20>
    486c:      	and	x9, x8, #0x3ff
    4870:      	add	x10, x9, x23
    4874:      	ldr	w29, [x10, #0x8]
    4878:      	ldp	w9, w24, [x10]
    487c:      	stp	xzr, xzr, [sp, #0x58]
    4880:      	cmp	w29, #0x4
    4884:      	csel	w10, w29, w20, lo
    4888:      	cmp	w24, #0x6
    488c:      	b.ne	0x4894 <generic_tracepoint_filter+0x1c54>
    4890:      	stp	x25, x25, [sp, #0x58]
    4894:      	add	w21, w8, #0xc
    4898:      	cbz	w29, 0x49ec <generic_tracepoint_filter+0x1dac>
    489c:      	and	x9, x9, #0xf
    48a0:      	cmp	w9, #0xa
    48a4:      	b.lo	0x48d0 <generic_tracepoint_filter+0x1c90>
    48a8:      	sub	x8, x10, #0x1
    48ac:      	mov	w9, #0x3                // =3
    48b0:      	add	x0, sp, #0x58
    48b4:      	mov	w1, wzr
    48b8:      	cmp	x8, #0x3
    48bc:      	csel	x8, x8, x9, lo
    48c0:      	lsl	x8, x8, #2
    48c4:      	add	x2, x8, #0x4
    48c8:      	bl	0x48c8 <generic_tracepoint_filter+0x1c88>
    48cc:      	b	0x49ec <generic_tracepoint_filter+0x1dac>
    48d0:      	cmp	w21, #0x3e8
    48d4:      	b.ls	0x48e0 <generic_tracepoint_filter+0x1ca0>
    48d8:      	mov	w11, wzr
    48dc:      	b	0x48e8 <generic_tracepoint_filter+0x1ca8>
    48e0:      	and	w11, w21, #0xfffffffc
    48e4:      	ldr	w11, [x23, w11, uxtw]
    48e8:      	ldr	x12, [sp, #0x30]
    48ec:      	cmp	w24, #0x5
    48f0:      	sub	x10, x10, #0x1
    48f4:      	ldr	w9, [x12, x9, lsl #2]
    48f8:      	cset	w12, ne
    48fc:      	cmp	w24, #0x6
    4900:      	cset	w13, ne
    4904:      	cmp	w11, w9
    4908:      	csinc	w11, w12, wzr, ne
    490c:      	csinc	w12, w13, wzr, eq
    4910:      	and	w11, w11, w12
    4914:      	str	w11, [sp, #0x58]
    4918:      	cbz	x10, 0x49ec <generic_tracepoint_filter+0x1dac>
    491c:      	add	w11, w8, #0x10
    4920:      	cmp	w11, #0x3e8
    4924:      	b.ls	0x4930 <generic_tracepoint_filter+0x1cf0>
    4928:      	mov	w11, wzr
    492c:      	b	0x4938 <generic_tracepoint_filter+0x1cf8>
    4930:      	and	w11, w11, #0xfffffffc
    4934:      	ldr	w11, [x23, w11, uxtw]
    4938:      	cmp	w24, #0x5
    493c:      	cset	w12, ne
    4940:      	cmp	w24, #0x6
    4944:      	cset	w13, ne
    4948:      	cmp	w11, w9
    494c:      	csinc	w11, w12, wzr, ne
    4950:      	csinc	w12, w13, wzr, eq
    4954:      	cmp	x10, #0x1
    4958:      	and	w11, w11, w12
    495c:      	str	w11, [sp, #0x5c]
    4960:      	b.eq	0x49ec <generic_tracepoint_filter+0x1dac>
    4964:      	add	w11, w8, #0x14
    4968:      	cmp	w11, #0x3e8
    496c:      	b.ls	0x4978 <generic_tracepoint_filter+0x1d38>
    4970:      	mov	w11, wzr
    4974:      	b	0x4980 <generic_tracepoint_filter+0x1d40>
    4978:      	and	w11, w11, #0xfffffffc
    497c:      	ldr	w11, [x23, w11, uxtw]
    4980:      	cmp	w24, #0x5
    4984:      	cset	w12, ne
    4988:      	cmp	w24, #0x6
    498c:      	cset	w13, ne
    4990:      	cmp	w11, w9
    4994:      	csinc	w11, w12, wzr, ne
    4998:      	csinc	w12, w13, wzr, eq
    499c:      	cmp	x10, #0x2
    49a0:      	and	w11, w11, w12
    49a4:      	str	w11, [sp, #0x60]
    49a8:      	b.eq	0x49ec <generic_tracepoint_filter+0x1dac>
    49ac:      	add	w8, w8, #0x18
    49b0:      	cmp	w8, #0x3e8
    49b4:      	b.ls	0x49c0 <generic_tracepoint_filter+0x1d80>
    49b8:      	mov	w8, wzr
    49bc:      	b	0x49c8 <generic_tracepoint_filter+0x1d88>
    49c0:      	and	w8, w8, #0xfffffffc
    49c4:      	ldr	w8, [x23, w8, uxtw]
    49c8:      	cmp	w24, #0x5
    49cc:      	cset	w10, ne
    49d0:      	cmp	w24, #0x6
    49d4:      	cset	w11, ne
    49d8:      	cmp	w8, w9
    49dc:      	csinc	w8, w10, wzr, ne
    49e0:      	csinc	w9, w11, wzr, eq
    49e4:      	and	w8, w8, w9
    49e8:      	str	w8, [sp, #0x64]
    49ec:      	ldp	w8, w9, [sp, #0x58]
    49f0:      	ldp	w10, w11, [sp, #0x60]
    49f4:      	cmp	w24, #0x6
    49f8:      	b.ne	0x4a0c <generic_tracepoint_filter+0x1dcc>
    49fc:      	and	w8, w9, w8
    4a00:      	and	w9, w10, w11
    4a04:      	and	w9, w8, w9
    4a08:      	b	0x4a18 <generic_tracepoint_filter+0x1dd8>
    4a0c:      	orr	w8, w9, w8
    4a10:      	orr	w9, w10, w11
    4a14:      	orr	w9, w8, w9
    4a18:      	cbz	w9, 0x4f14 <generic_tracepoint_filter+0x22d4>
    4a1c:      	lsl	w8, w29, #2
    4a20:      	sub	w10, w22, w29, lsl #2
    4a24:      	and	w8, w8, #0x1c
    4a28:      	sub	w22, w10, #0xc
    4a2c:      	add	w8, w8, w21
    4a30:      	b	0x4860 <generic_tracepoint_filter+0x1c20>
    4a34:      	mov	w10, w8
    4a38:      	add	w19, w8, #0x4
    4a3c:      	and	x10, x10, #0x3ff
    4a40:      	ldr	w10, [x10, x23]
    4a44:      	cmp	w10, #0x4
    4a48:      	b.ne	0x4ae0 <generic_tracepoint_filter+0x1ea0>
    4a4c:      	cbz	w9, 0x4f14 <generic_tracepoint_filter+0x22d4>
    4a50:      	mov	w8, w19
    4a54:      	and	x8, x8, #0x3ff
    4a58:      	ldr	w9, [x8, x23]
    4a5c:      	add	w8, w19, #0x4
    4a60:      	cmp	w9, #0x4
    4a64:      	mov	w9, w8
    4a68:      	b.eq	0x4e10 <generic_tracepoint_filter+0x21d0>
    4a6c:      	and	x8, x8, #0x3ff
    4a70:      	add	x8, x8, x23
    4a74:      	ldp	w20, w22, [x8]
    4a78:      	mov	w8, #0xe                // =14
    4a7c:      	blr	x8
    4a80:      	lsr	x8, x0, #32
    4a84:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    4a88:      	add	x9, sp, #0x58
    4a8c:      	str	w8, [sp, #0x58]
    4a90:      	mov	w8, #0x1                // =1
    4a94:      	add	x1, sp, #0x58
    4a98:      	ldr	x0, [x0]
    4a9c:      	blr	x8
    4aa0:      	cbz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    4aa4:      	cmp	w20, #0x5
    4aa8:      	b.eq	0x4b5c <generic_tracepoint_filter+0x1f1c>
    4aac:      	cmp	w20, #0x6
    4ab0:      	b.ne	0x4f14 <generic_tracepoint_filter+0x22d4>
    4ab4:      	ldr	x11, [sp, #0xe8]
    4ab8:      	mov	w8, #0x5ee8             // =24296
    4abc:      	add	x8, x11, x8
    4ac0:      	tbnz	w22, #0x0, 0x4b90 <generic_tracepoint_filter+0x1f50>
    4ac4:      	ldr	w9, [x0, #0x28]
    4ac8:      	cbz	w9, 0x4b88 <generic_tracepoint_filter+0x1f48>
    4acc:      	ldr	x10, [sp, #0x30]
    4ad0:      	ldr	w10, [x10]
    4ad4:      	cmp	w9, w10
    4ad8:      	b.eq	0x4b90 <generic_tracepoint_filter+0x1f50>
    4adc:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4ae0:      	and	x9, x19, #0x3ff
    4ae4:      	add	w19, w8, #0x18
    4ae8:      	add	x9, x9, x23
    4aec:      	ldp	w8, w10, [x9]
    4af0:      	ldr	w12, [x9, #0x8]
    4af4:      	ldur	x11, [x9, #0xc]
    4af8:      	cbz	w12, 0x4b1c <generic_tracepoint_filter+0x1edc>
    4afc:      	ldr	x14, [sp, #0xe8]
    4b00:      	mov	w9, wzr
    4b04:      	cmp	w8, #0x2
    4b08:      	b.hi	0x4a4c <generic_tracepoint_filter+0x1e0c>
    4b0c:      	ldr	w13, [x14, #0x44]
    4b10:      	cmp	w13, w12
    4b14:      	b.ne	0x4b30 <generic_tracepoint_filter+0x1ef0>
    4b18:      	b	0x4a4c <generic_tracepoint_filter+0x1e0c>
    4b1c:      	ldr	x14, [sp, #0xe8]
    4b20:      	cmp	w8, #0x2
    4b24:      	b.ls	0x4b30 <generic_tracepoint_filter+0x1ef0>
    4b28:      	mov	w9, wzr
    4b2c:      	b	0x4a4c <generic_tracepoint_filter+0x1e0c>
    4b30:      	add	x9, x14, #0x48
    4b34:      	cmp	w10, #0x5
    4b38:      	ldr	x8, [x9, x8, lsl #3]
    4b3c:      	and	x8, x8, x11
    4b40:      	b.ne	0x4b50 <generic_tracepoint_filter+0x1f10>
    4b44:      	cmp	x8, #0x0
    4b48:      	cset	w9, ne
    4b4c:      	b	0x4a4c <generic_tracepoint_filter+0x1e0c>
    4b50:      	cmp	x8, #0x0
    4b54:      	cset	w9, eq
    4b58:      	b	0x4a4c <generic_tracepoint_filter+0x1e0c>
    4b5c:      	ldr	x11, [sp, #0xe8]
    4b60:      	mov	w8, #0x5ee8             // =24296
    4b64:      	add	x8, x11, x8
    4b68:      	tbz	w22, #0x0, 0x4bb4 <generic_tracepoint_filter+0x1f74>
    4b6c:      	ldr	w9, [x0, #0x28]
    4b70:      	cbz	w9, 0x4bac <generic_tracepoint_filter+0x1f6c>
    4b74:      	ldr	x10, [sp, #0x30]
    4b78:      	ldr	w10, [x10]
    4b7c:      	cmp	w9, w10
    4b80:      	b.eq	0x4bb4 <generic_tracepoint_filter+0x1f74>
    4b84:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4b88:      	mov	w9, #0x1                // =1
    4b8c:      	str	x9, [x8]
    4b90:      	tbnz	w22, #0x1, 0x4bd8 <generic_tracepoint_filter+0x1f98>
    4b94:      	ldr	w9, [x0, #0x2c]
    4b98:      	cbz	w9, 0x4bd0 <generic_tracepoint_filter+0x1f90>
    4b9c:      	ldr	w10, [x11, #0x24]
    4ba0:      	cmp	w9, w10
    4ba4:      	b.eq	0x4bd8 <generic_tracepoint_filter+0x1f98>
    4ba8:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4bac:      	mov	w9, #0x1                // =1
    4bb0:      	str	x9, [x8]
    4bb4:      	tbz	w22, #0x1, 0x4bfc <generic_tracepoint_filter+0x1fbc>
    4bb8:      	ldr	w9, [x0, #0x2c]
    4bbc:      	cbz	w9, 0x4bf4 <generic_tracepoint_filter+0x1fb4>
    4bc0:      	ldr	w10, [x11, #0x24]
    4bc4:      	cmp	w9, w10
    4bc8:      	b.eq	0x4bfc <generic_tracepoint_filter+0x1fbc>
    4bcc:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4bd0:      	mov	w9, #0x1                // =1
    4bd4:      	str	x9, [x8]
    4bd8:      	tbnz	w22, #0x2, 0x4c20 <generic_tracepoint_filter+0x1fe0>
    4bdc:      	ldr	w9, [x0, #0x30]
    4be0:      	cbz	w9, 0x4c18 <generic_tracepoint_filter+0x1fd8>
    4be4:      	ldr	w10, [x11, #0x28]
    4be8:      	cmp	w9, w10
    4bec:      	b.eq	0x4c20 <generic_tracepoint_filter+0x1fe0>
    4bf0:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4bf4:      	mov	w9, #0x1                // =1
    4bf8:      	str	x9, [x8]
    4bfc:      	tbz	w22, #0x2, 0x4c44 <generic_tracepoint_filter+0x2004>
    4c00:      	ldr	w9, [x0, #0x30]
    4c04:      	cbz	w9, 0x4c3c <generic_tracepoint_filter+0x1ffc>
    4c08:      	ldr	w10, [x11, #0x28]
    4c0c:      	cmp	w9, w10
    4c10:      	b.eq	0x4c44 <generic_tracepoint_filter+0x2004>
    4c14:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4c18:      	mov	w9, #0x1                // =1
    4c1c:      	str	x9, [x8]
    4c20:      	tbnz	w22, #0x3, 0x4c68 <generic_tracepoint_filter+0x2028>
    4c24:      	ldr	w9, [x0, #0x34]
    4c28:      	cbz	w9, 0x4c60 <generic_tracepoint_filter+0x2020>
    4c2c:      	ldr	w10, [x11, #0x2c]
    4c30:      	cmp	w9, w10
    4c34:      	b.eq	0x4c68 <generic_tracepoint_filter+0x2028>
    4c38:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4c3c:      	mov	w9, #0x1                // =1
    4c40:      	str	x9, [x8]
    4c44:      	tbz	w22, #0x3, 0x4c8c <generic_tracepoint_filter+0x204c>
    4c48:      	ldr	w9, [x0, #0x34]
    4c4c:      	cbz	w9, 0x4c84 <generic_tracepoint_filter+0x2044>
    4c50:      	ldr	w10, [x11, #0x2c]
    4c54:      	cmp	w9, w10
    4c58:      	b.eq	0x4c8c <generic_tracepoint_filter+0x204c>
    4c5c:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4c60:      	mov	w9, #0x1                // =1
    4c64:      	str	x9, [x8]
    4c68:      	tbnz	w22, #0x4, 0x4cb0 <generic_tracepoint_filter+0x2070>
    4c6c:      	ldr	w9, [x0, #0x38]
    4c70:      	cbz	w9, 0x4ca8 <generic_tracepoint_filter+0x2068>
    4c74:      	ldr	w10, [x11, #0x30]
    4c78:      	cmp	w9, w10
    4c7c:      	b.eq	0x4cb0 <generic_tracepoint_filter+0x2070>
    4c80:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4c84:      	mov	w9, #0x1                // =1
    4c88:      	str	x9, [x8]
    4c8c:      	tbz	w22, #0x4, 0x4cd4 <generic_tracepoint_filter+0x2094>
    4c90:      	ldr	w9, [x0, #0x38]
    4c94:      	cbz	w9, 0x4ccc <generic_tracepoint_filter+0x208c>
    4c98:      	ldr	w10, [x11, #0x30]
    4c9c:      	cmp	w9, w10
    4ca0:      	b.eq	0x4cd4 <generic_tracepoint_filter+0x2094>
    4ca4:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4ca8:      	mov	w9, #0x1                // =1
    4cac:      	str	x9, [x8]
    4cb0:      	tbnz	w22, #0x5, 0x4cf8 <generic_tracepoint_filter+0x20b8>
    4cb4:      	ldr	w9, [x0, #0x3c]
    4cb8:      	cbz	w9, 0x4cf0 <generic_tracepoint_filter+0x20b0>
    4cbc:      	ldr	w10, [x11, #0x34]
    4cc0:      	cmp	w9, w10
    4cc4:      	b.eq	0x4cf8 <generic_tracepoint_filter+0x20b8>
    4cc8:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4ccc:      	mov	w9, #0x1                // =1
    4cd0:      	str	x9, [x8]
    4cd4:      	tbz	w22, #0x5, 0x4d1c <generic_tracepoint_filter+0x20dc>
    4cd8:      	ldr	w9, [x0, #0x3c]
    4cdc:      	cbz	w9, 0x4d14 <generic_tracepoint_filter+0x20d4>
    4ce0:      	ldr	w10, [x11, #0x34]
    4ce4:      	cmp	w9, w10
    4ce8:      	b.eq	0x4d1c <generic_tracepoint_filter+0x20dc>
    4cec:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4cf0:      	mov	w9, #0x1                // =1
    4cf4:      	str	x9, [x8]
    4cf8:      	tbnz	w22, #0x6, 0x4d40 <generic_tracepoint_filter+0x2100>
    4cfc:      	ldr	w9, [x0, #0x40]
    4d00:      	cbz	w9, 0x4d38 <generic_tracepoint_filter+0x20f8>
    4d04:      	ldr	w10, [x11, #0x38]
    4d08:      	cmp	w9, w10
    4d0c:      	b.eq	0x4d40 <generic_tracepoint_filter+0x2100>
    4d10:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4d14:      	mov	w9, #0x1                // =1
    4d18:      	str	x9, [x8]
    4d1c:      	tbz	w22, #0x6, 0x4d64 <generic_tracepoint_filter+0x2124>
    4d20:      	ldr	w9, [x0, #0x40]
    4d24:      	cbz	w9, 0x4d5c <generic_tracepoint_filter+0x211c>
    4d28:      	ldr	w10, [x11, #0x38]
    4d2c:      	cmp	w9, w10
    4d30:      	b.eq	0x4d64 <generic_tracepoint_filter+0x2124>
    4d34:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4d38:      	mov	w9, #0x1                // =1
    4d3c:      	str	x9, [x8]
    4d40:      	tbnz	w22, #0x7, 0x4d88 <generic_tracepoint_filter+0x2148>
    4d44:      	ldr	w9, [x0, #0x44]
    4d48:      	cbz	w9, 0x4d80 <generic_tracepoint_filter+0x2140>
    4d4c:      	ldr	w10, [x11, #0x3c]
    4d50:      	cmp	w9, w10
    4d54:      	b.eq	0x4d88 <generic_tracepoint_filter+0x2148>
    4d58:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4d5c:      	mov	w9, #0x1                // =1
    4d60:      	str	x9, [x8]
    4d64:      	tbz	w22, #0x7, 0x4db0 <generic_tracepoint_filter+0x2170>
    4d68:      	ldr	w9, [x0, #0x44]
    4d6c:      	cbz	w9, 0x4da8 <generic_tracepoint_filter+0x2168>
    4d70:      	ldr	w10, [x11, #0x3c]
    4d74:      	cmp	w9, w10
    4d78:      	b.eq	0x4db0 <generic_tracepoint_filter+0x2170>
    4d7c:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4d80:      	mov	w9, #0x1                // =1
    4d84:      	str	x9, [x8]
    4d88:      	tbnz	w22, #0x8, 0x4dd8 <generic_tracepoint_filter+0x2198>
    4d8c:      	ldr	w9, [x0, #0x48]
    4d90:      	cbz	w9, 0x4dd0 <generic_tracepoint_filter+0x2190>
    4d94:      	ldr	x10, [sp, #0xe8]
    4d98:      	ldr	w10, [x10, #0x40]
    4d9c:      	cmp	w9, w10
    4da0:      	b.eq	0x4dd8 <generic_tracepoint_filter+0x2198>
    4da4:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4da8:      	mov	w9, #0x1                // =1
    4dac:      	str	x9, [x8]
    4db0:      	tbz	w22, #0x8, 0x4de8 <generic_tracepoint_filter+0x21a8>
    4db4:      	ldr	w9, [x0, #0x48]
    4db8:      	cbz	w9, 0x4de0 <generic_tracepoint_filter+0x21a0>
    4dbc:      	ldr	x10, [sp, #0xe8]
    4dc0:      	ldr	w10, [x10, #0x40]
    4dc4:      	cmp	w9, w10
    4dc8:      	b.eq	0x4de8 <generic_tracepoint_filter+0x21a8>
    4dcc:      	b	0x4e04 <generic_tracepoint_filter+0x21c4>
    4dd0:      	mov	w9, #0x1                // =1
    4dd4:      	str	x9, [x8]
    4dd8:      	tbz	w22, #0x9, 0x4dec <generic_tracepoint_filter+0x21ac>
    4ddc:      	b	0x4f14 <generic_tracepoint_filter+0x22d4>
    4de0:      	mov	w9, #0x1                // =1
    4de4:      	str	x9, [x8]
    4de8:      	tbz	w22, #0x9, 0x4f14 <generic_tracepoint_filter+0x22d4>
    4dec:      	ldr	w9, [x0, #0x4c]
    4df0:      	cbz	w9, 0x4f0c <generic_tracepoint_filter+0x22cc>
    4df4:      	ldr	x10, [sp, #0xe8]
    4df8:      	ldr	w10, [x10, #0x44]
    4dfc:      	cmp	w9, w10
    4e00:      	b.eq	0x4f14 <generic_tracepoint_filter+0x22d4>
    4e04:      	add	w9, w19, #0xc
    4e08:      	mov	w10, #0x1               // =1
    4e0c:      	str	x10, [x8]
    4e10:      	and	x8, x9, #0x3ff
    4e14:      	adrp	x24, 0x4000 <generic_tracepoint_filter+0x13c0>
    4e18:      	ldr	w8, [x8, x23]
    4e1c:      	ldr	x24, [x24]
    4e20:      	cmp	w8, #0x4
    4e24:      	b.ne	0x4e58 <generic_tracepoint_filter+0x2218>
    4e28:      	ldr	x9, [sp, #0xe8]
    4e2c:      	mov	w8, #0x5eb8             // =24248
    4e30:      	add	x8, x9, x8
    4e34:      	ldr	x9, [x9, #0x5eb8]
    4e38:      	and	x9, x9, #0x1f
    4e3c:      	add	x8, x8, x9
    4e40:      	mov	w9, #0x1                // =1
    4e44:      	strb	w9, [x8, #0x9]
    4e48:      	ldr	x8, [sp, #0x40]
    4e4c:      	strb	w9, [x8, #0x20]
    4e50:      	strb	w9, [x8]
    4e54:      	b	0x4f14 <generic_tracepoint_filter+0x22d4>
    4e58:      	add	w8, w9, #0x4
    4e5c:      	and	x8, x8, #0x3ff
    4e60:      	add	x8, x8, x23
    4e64:      	ldp	w21, w19, [x8]
    4e68:      	ldr	w22, [x8, #0x8]
    4e6c:      	ldur	x20, [x8, #0xc]
    4e70:      	mov	w8, #0xe                // =14
    4e74:      	blr	x8
    4e78:      	lsr	x8, x0, #32
    4e7c:      	add	x9, sp, #0x58
    4e80:      	add	x1, sp, #0x58
    4e84:      	str	w8, [sp, #0x58]
    4e88:      	mov	w8, #0x1                // =1
    4e8c:      	mov	x0, x24
    4e90:      	blr	x8
    4e94:      	cbz	x0, 0x4f14 <generic_tracepoint_filter+0x22d4>
    4e98:      	cmp	w21, #0x2
    4e9c:      	cbz	w22, 0x4eb8 <generic_tracepoint_filter+0x2278>
    4ea0:      	b.hi	0x4f14 <generic_tracepoint_filter+0x22d4>
    4ea4:      	ldr	x8, [sp, #0xe8]
    4ea8:      	ldr	w8, [x8, #0x44]
    4eac:      	cmp	w8, w22
    4eb0:      	b.ne	0x4ebc <generic_tracepoint_filter+0x227c>
    4eb4:      	b	0x4f14 <generic_tracepoint_filter+0x22d4>
    4eb8:      	b.hi	0x4f14 <generic_tracepoint_filter+0x22d4>
    4ebc:      	ldr	x8, [sp, #0xe8]
    4ec0:      	lsl	x10, x21, #3
    4ec4:      	add	x9, x8, #0x48
    4ec8:      	add	x8, x0, x21, lsl #3
    4ecc:      	ldr	x8, [x8, #0x50]
    4ed0:      	ldr	x9, [x9, x10]
    4ed4:      	eor	x10, x9, x8
    4ed8:      	tst	x10, x20
    4edc:      	b.eq	0x4eec <generic_tracepoint_filter+0x22ac>
    4ee0:      	cmp	w19, #0x5
    4ee4:      	b.eq	0x4efc <generic_tracepoint_filter+0x22bc>
    4ee8:      	b	0x4f14 <generic_tracepoint_filter+0x22d4>
    4eec:      	cmp	x8, x9
    4ef0:      	b.eq	0x4f14 <generic_tracepoint_filter+0x22d4>
    4ef4:      	cmp	w19, #0x6
    4ef8:      	b.ne	0x4f14 <generic_tracepoint_filter+0x22d4>
    4efc:      	ldr	x9, [sp, #0xe8]
    4f00:      	mov	w8, #0x1                // =1
    4f04:      	str	x8, [x9, #0x5ef0]
    4f08:      	b	0x4e28 <generic_tracepoint_filter+0x21e8>
    4f0c:      	mov	w9, #0x1                // =1
    4f10:      	str	x9, [x8]
    4f14:      	ldr	x9, [sp, #0xe8]
    4f18:      	ldr	x10, [sp, #0x28]
    4f1c:      	ldr	x8, [x9, #0x5eb8]
    4f20:      	add	x8, x8, #0x1
    4f24:      	cmp	x8, x10
    4f28:      	str	x8, [x9, #0x5eb8]
    4f2c:      	b.ls	0x4f8c <generic_tracepoint_filter+0x234c>
    4f30:      	ldr	x10, [sp, #0x48]
    4f34:      	ldr	w8, [x10]
    4f38:      	str	w8, [x9, #0x10]
    4f3c:      	ldr	x8, [x10, #0x8]
    4f40:      	str	x8, [x9, #0x18]
    4f44:      	ldp	x20, x8, [sp, #0x38]
    4f48:      	ldrb	w8, [x8]
    4f4c:      	cbz	w8, 0x4f6c <generic_tracepoint_filter+0x232c>
    4f50:      	adrp	x1, 0x4000 <generic_tracepoint_filter+0x13c0>
    4f54:      	mov	w8, #0x1                // =1
    4f58:      	mov	w9, #0xc                // =12
    4f5c:      	ldr	x1, [x1]
    4f60:      	mov	x0, x20
    4f64:      	mov	w2, #0x1                // =1
    4f68:      	blr	x9
    4f6c:      	ldp	x20, x19, [sp, #0x120]
    4f70:      	mov	w0, wzr
    4f74:      	ldr	x29, [sp, #0xe0]
    4f78:      	ldp	x22, x21, [sp, #0x110]
    4f7c:      	ldp	x24, x23, [sp, #0x100]
    4f80:      	ldp	x30, x25, [sp, #0xf0]
    4f84:      	add	sp, sp, #0x130
    4f88:      	ret
    4f8c:      	adrp	x1, 0x4000 <generic_tracepoint_filter+0x13c0>
    4f90:      	mov	w8, #0x2                // =2
    4f94:      	mov	w9, #0xc                // =12
    4f98:      	ldr	x1, [x1]
    4f9c:      	ldr	x0, [sp, #0x38]
    4fa0:      	mov	w2, #0x2                // =2
    4fa4:      	b	0x4f68 <generic_tracepoint_filter+0x2328>
    4fa8:      	nop
    4fac:      	nop

0000000000004fb0 <generic_tracepoint_arg>:
    4fb0:      	sub	sp, sp, #0x70
    4fb4:      	str	x29, [sp, #0x20]
    4fb8:      	stp	x30, x25, [sp, #0x30]
    4fbc:      	stp	x24, x23, [sp, #0x40]
    4fc0:      	stp	x22, x21, [sp, #0x50]
    4fc4:      	stp	x20, x19, [sp, #0x60]
    4fc8:      	mov	x19, x0
    4fcc:      	str	wzr, [sp, #0x2c]
    4fd0:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x13c0>
    4fd4:      	mov	w8, #0x1                // =1
    4fd8:      	ldr	x0, [x0]
    4fdc:      	add	x9, sp, #0x2c
    4fe0:      	add	x1, sp, #0x2c
    4fe4:      	blr	x8
    4fe8:      	cbz	x0, 0x5374 <generic_tracepoint_arg+0x3c4>
    4fec:      	mov	w8, #0x5ec1             // =24257
    4ff0:      	mov	x20, x0
    4ff4:      	add	x22, x0, x8
    4ff8:      	mov	w8, #0x5ef8             // =24312
    4ffc:      	add	x1, x0, x8
    5000:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x50>
    5004:      	ldur	w23, [x22, #0x3f]
    5008:      	mov	w8, #0x1                // =1
    500c:      	ldr	x0, [x0]
    5010:      	blr	x8
    5014:      	cbz	x0, 0x5358 <generic_tracepoint_arg+0x3a8>
    5018:      	ldrb	w8, [x22, #0x1f]
    501c:      	cbz	w8, 0x5358 <generic_tracepoint_arg+0x3a8>
    5020:      	and	x8, x23, #0x7
    5024:      	mov	w10, #0x5ec1            // =24257
    5028:      	add	x9, x20, x8
    502c:      	ldrb	w9, [x9, x10]
    5030:      	cbz	w9, 0x50b0 <generic_tracepoint_arg+0x100>
    5034:      	lsl	w8, w8, #2
    5038:      	mov	x21, x0
    503c:      	add	x8, x8, #0x4
    5040:      	ldr	w9, [x8, x0]
    5044:      	add	x8, x8, x9
    5048:      	add	x8, x8, #0x4
    504c:      	and	x9, x8, #0x3ff
    5050:      	ldr	w9, [x9, x0]
    5054:      	add	x8, x8, x9
    5058:      	and	x9, x8, #0x3ff
    505c:      	ldr	w9, [x9, x0]
    5060:      	add	x8, x8, x9
    5064:      	and	x9, x8, #0x3ff
    5068:      	ldr	w9, [x9, x0]
    506c:      	add	x8, x8, x9
    5070:      	and	x9, x8, #0x3ff
    5074:      	ldr	w9, [x9, x0]
    5078:      	add	x8, x8, x9
    507c:      	and	x9, x8, #0x3ff
    5080:      	ldr	w9, [x9, x0]
    5084:      	add	x25, x8, x9
    5088:      	and	x8, x25, #0x3ff
    508c:      	add	x29, x0, x8
    5090:      	str	x8, [sp, #0x8]
    5094:      	ldr	w8, [x29]
    5098:      	cmp	w8, #0x19
    509c:      	b.hs	0x50f8 <generic_tracepoint_arg+0x148>
    50a0:      	ldr	x8, [sp, #0x8]
    50a4:      	cmp	w8, #0x1
    50a8:      	b.eq	0x5358 <generic_tracepoint_arg+0x3a8>
    50ac:      	cbnz	w8, 0x5334 <generic_tracepoint_arg+0x384>
    50b0:      	cmp	w23, #0x1
    50b4:      	b.gt	0x50d0 <generic_tracepoint_arg+0x120>
    50b8:      	cmn	w23, #0x1
    50bc:      	b.eq	0x5394 <generic_tracepoint_arg+0x3e4>
    50c0:      	cbz	w23, 0x53a4 <generic_tracepoint_arg+0x3f4>
    50c4:      	cmp	w23, #0x1
    50c8:      	b.eq	0x53b4 <generic_tracepoint_arg+0x404>
    50cc:      	b	0x50e8 <generic_tracepoint_arg+0x138>
    50d0:      	cmp	w23, #0x2
    50d4:      	b.eq	0x53c4 <generic_tracepoint_arg+0x414>
    50d8:      	cmp	w23, #0x3
    50dc:      	b.eq	0x53d4 <generic_tracepoint_arg+0x424>
    50e0:      	cmp	w23, #0x4
    50e4:      	b.eq	0x53e4 <generic_tracepoint_arg+0x434>
    50e8:      	cmp	w23, #0x4
    50ec:      	b.gt	0x5410 <generic_tracepoint_arg+0x460>
    50f0:      	add	w8, w23, #0x1
    50f4:      	b	0x53f0 <generic_tracepoint_arg+0x440>
    50f8:      	mov	w24, #0x4               // =4
    50fc:      	nop
    5100:      	ldr	w8, [x29, x24]
    5104:      	tst	w8, #0x3ff
    5108:      	b.eq	0x50a0 <generic_tracepoint_arg+0xf0>
    510c:      	add	w8, w25, w8
    5110:      	and	x8, x8, #0x3ff
    5114:      	add	x0, x21, x8
    5118:      	ldr	w9, [x0, #0x4]
    511c:      	cmp	w9, #0x23
    5120:      	b.eq	0x50b0 <generic_tracepoint_arg+0x100>
    5124:      	ldr	w8, [x0]
    5128:      	cmp	w8, #0x4
    512c:      	b.hi	0x50b0 <generic_tracepoint_arg+0x100>
    5130:      	add	x10, x20, x8, lsl #2
    5134:      	mov	w11, #0x5ea0            // =24224
    5138:      	ldr	w10, [x10, x11]
    513c:      	cbnz	w10, 0x50b0 <generic_tracepoint_arg+0x100>
    5140:      	add	x8, x20, x8, lsl #3
    5144:      	ldr	x8, [x8, #0x5e78]
    5148:      	and	x8, x8, #0x7ff
    514c:      	add	x8, x20, x8
    5150:      	add	x1, x8, #0x90
    5154:      	ldr	w8, [x0, #0xc]
    5158:      	cmp	w8, #0x1b
    515c:      	b.le	0x5180 <generic_tracepoint_arg+0x1d0>
    5160:      	cmp	w8, #0x25
    5164:      	b.gt	0x51b4 <generic_tracepoint_arg+0x204>
    5168:      	sub	w10, w8, #0x1c
    516c:      	cmp	w10, #0x9
    5170:      	b.lo	0x51f8 <generic_tracepoint_arg+0x248>
    5174:      	cmp	w8, #0x25
    5178:      	b.eq	0x52e0 <generic_tracepoint_arg+0x330>
    517c:      	b	0x5324 <generic_tracepoint_arg+0x374>
    5180:      	cmp	w8, #0x9
    5184:      	b.le	0x51d8 <generic_tracepoint_arg+0x228>
    5188:      	sub	w10, w8, #0xa
    518c:      	cmp	w10, #0x4
    5190:      	b.lo	0x51f8 <generic_tracepoint_arg+0x248>
    5194:      	sub	w9, w8, #0xf
    5198:      	cmp	w9, #0x2
    519c:      	b.lo	0x52e0 <generic_tracepoint_arg+0x330>
    51a0:      	cmp	w8, #0x11
    51a4:      	b.ne	0x5324 <generic_tracepoint_arg+0x374>
    51a8:      	add	x1, x1, #0x4
    51ac:      	bl	0x51ac <generic_tracepoint_arg+0x1fc>
    51b0:      	b	0x5320 <generic_tracepoint_arg+0x370>
    51b4:      	cmp	w8, #0x29
    51b8:      	b.gt	0x52c8 <generic_tracepoint_arg+0x318>
    51bc:      	sub	w9, w8, #0x26
    51c0:      	cmp	w9, #0x2
    51c4:      	b.lo	0x527c <generic_tracepoint_arg+0x2cc>
    51c8:      	sub	w8, w8, #0x28
    51cc:      	cmp	w8, #0x2
    51d0:      	b.lo	0x5274 <generic_tracepoint_arg+0x2c4>
    51d4:      	b	0x5324 <generic_tracepoint_arg+0x374>
    51d8:      	cmp	w8, #0x4
    51dc:      	b.gt	0x525c <generic_tracepoint_arg+0x2ac>
    51e0:      	cmp	w8, #0x1
    51e4:      	b.eq	0x51f8 <generic_tracepoint_arg+0x248>
    51e8:      	cmp	w8, #0x2
    51ec:      	b.eq	0x5304 <generic_tracepoint_arg+0x354>
    51f0:      	cmp	w8, #0x4
    51f4:      	b.ne	0x5324 <generic_tracepoint_arg+0x374>
    51f8:      	cmp	w8, #0xb
    51fc:      	b.le	0x523c <generic_tracepoint_arg+0x28c>
    5200:      	cmp	w8, #0x24
    5204:      	b.hi	0x52e8 <generic_tracepoint_arg+0x338>
    5208:      	mov	w11, #0x1               // =1
    520c:      	lsl	x10, x11, x8
    5210:      	tst	x10, #0x1e00000000
    5214:      	b.ne	0x5284 <generic_tracepoint_arg+0x2d4>
    5218:      	lsl	x9, x11, x8
    521c:      	tst	x9, #0x60000000
    5220:      	mov	w9, #0x1                // =1
    5224:      	b.ne	0x52fc <generic_tracepoint_arg+0x34c>
    5228:      	lsl	x9, x9, x8
    522c:      	tst	x9, #0x180000000
    5230:      	b.eq	0x52e8 <generic_tracepoint_arg+0x338>
    5234:      	bl	0x5234 <generic_tracepoint_arg+0x284>
    5238:      	b	0x5320 <generic_tracepoint_arg+0x370>
    523c:      	sub	w9, w8, #0xa
    5240:      	cmp	w9, #0x2
    5244:      	b.lo	0x5318 <generic_tracepoint_arg+0x368>
    5248:      	cmp	w8, #0x1
    524c:      	b.eq	0x52f4 <generic_tracepoint_arg+0x344>
    5250:      	cmp	w8, #0x4
    5254:      	b.eq	0x52f4 <generic_tracepoint_arg+0x344>
    5258:      	b	0x5324 <generic_tracepoint_arg+0x374>
    525c:      	cmp	w8, #0x5
    5260:      	b.eq	0x5274 <generic_tracepoint_arg+0x2c4>
    5264:      	cmp	w8, #0x6
    5268:      	b.eq	0x527c <generic_tracepoint_arg+0x2cc>
    526c:      	cmp	w8, #0x7
    5270:      	b.ne	0x5324 <generic_tracepoint_arg+0x374>
    5274:      	bl	0x5274 <generic_tracepoint_arg+0x2c4>
    5278:      	b	0x5320 <generic_tracepoint_arg+0x370>
    527c:      	mov	w2, #0x4                // =4
    5280:      	b	0x5308 <generic_tracepoint_arg+0x358>
    5284:      	cmp	w9, #0x1e
    5288:      	b.ne	0x5318 <generic_tracepoint_arg+0x368>
    528c:      	ldr	w8, [x0, #0x10]
    5290:      	mov	w10, #0x5ea0            // =24224
    5294:      	and	x8, x8, #0x7
    5298:      	add	x9, x20, x8, lsl #2
    529c:      	ldr	w9, [x9, x10]
    52a0:      	cbnz	w9, 0x50b0 <generic_tracepoint_arg+0x100>
    52a4:      	add	x8, x20, x8, lsl #3
    52a8:      	ldr	x9, [x1]
    52ac:      	ldr	x8, [x8, #0x5e78]
    52b0:      	and	x8, x8, #0x7ff
    52b4:      	add	x8, x20, x8
    52b8:      	ldr	x8, [x8, #0x90]
    52bc:      	bics	xzr, x8, x9
    52c0:      	cset	w0, ne
    52c4:      	b	0x5320 <generic_tracepoint_arg+0x370>
    52c8:      	cmp	w8, #0x2a
    52cc:      	b.eq	0x52e0 <generic_tracepoint_arg+0x330>
    52d0:      	cmp	w8, #0x2c
    52d4:      	b.ne	0x5324 <generic_tracepoint_arg+0x374>
    52d8:      	bl	0x52d8 <generic_tracepoint_arg+0x328>
    52dc:      	b	0x5320 <generic_tracepoint_arg+0x370>
    52e0:      	bl	0x52e0 <generic_tracepoint_arg+0x330>
    52e4:      	b	0x5320 <generic_tracepoint_arg+0x370>
    52e8:      	sub	w9, w8, #0xc
    52ec:      	cmp	w9, #0x2
    52f0:      	b.hs	0x5310 <generic_tracepoint_arg+0x360>
    52f4:      	bl	0x52f4 <generic_tracepoint_arg+0x344>
    52f8:      	b	0x5320 <generic_tracepoint_arg+0x370>
    52fc:      	bl	0x52fc <generic_tracepoint_arg+0x34c>
    5300:      	b	0x5320 <generic_tracepoint_arg+0x370>
    5304:      	mov	w2, #0x8                // =8
    5308:      	bl	0x5308 <generic_tracepoint_arg+0x358>
    530c:      	b	0x5320 <generic_tracepoint_arg+0x370>
    5310:      	cmp	w8, #0x1c
    5314:      	b.ne	0x5324 <generic_tracepoint_arg+0x374>
    5318:      	bl	0x5318 <generic_tracepoint_arg+0x368>
    531c:      	nop
    5320:      	cbz	x0, 0x50b0 <generic_tracepoint_arg+0x100>
    5324:      	add	x24, x24, #0x4
    5328:      	cmp	x24, #0x18
    532c:      	b.ne	0x5100 <generic_tracepoint_arg+0x150>
    5330:      	b	0x50a0 <generic_tracepoint_arg+0xf0>
    5334:      	ldr	x8, [sp, #0x8]
    5338:      	adrp	x1, 0x5000 <generic_tracepoint_arg+0x50>
    533c:      	mov	w9, #0xc                // =12
    5340:      	mov	x0, x19
    5344:      	stur	w8, [x22, #0x43]
    5348:      	mov	w8, #0x4                // =4
    534c:      	mov	w2, #0x4                // =4
    5350:      	ldr	x1, [x1]
    5354:      	blr	x9
    5358:      	adrp	x1, 0x5000 <generic_tracepoint_arg+0x50>
    535c:      	mov	w8, #0x5                // =5
    5360:      	mov	w9, #0xc                // =12
    5364:      	ldr	x1, [x1]
    5368:      	mov	x0, x19
    536c:      	mov	w2, #0x5                // =5
    5370:      	blr	x9
    5374:      	ldp	x20, x19, [sp, #0x60]
    5378:      	mov	w0, wzr
    537c:      	ldr	x29, [sp, #0x20]
    5380:      	ldp	x22, x21, [sp, #0x50]
    5384:      	ldp	x24, x23, [sp, #0x40]
    5388:      	ldp	x30, x25, [sp, #0x30]
    538c:      	add	sp, sp, #0x70
    5390:      	ret
    5394:      	ldrb	w8, [x22]
    5398:      	cbz	w8, 0x53a4 <generic_tracepoint_arg+0x3f4>
    539c:      	mov	w8, wzr
    53a0:      	b	0x53f0 <generic_tracepoint_arg+0x440>
    53a4:      	ldrb	w8, [x22, #0x1]
    53a8:      	cbz	w8, 0x53b4 <generic_tracepoint_arg+0x404>
    53ac:      	mov	w8, #0x1                // =1
    53b0:      	b	0x53f0 <generic_tracepoint_arg+0x440>
    53b4:      	ldrb	w8, [x22, #0x2]
    53b8:      	cbz	w8, 0x53c4 <generic_tracepoint_arg+0x414>
    53bc:      	mov	w8, #0x2                // =2
    53c0:      	b	0x53f0 <generic_tracepoint_arg+0x440>
    53c4:      	ldrb	w8, [x22, #0x3]
    53c8:      	cbz	w8, 0x53d4 <generic_tracepoint_arg+0x424>
    53cc:      	mov	w8, #0x3                // =3
    53d0:      	b	0x53f0 <generic_tracepoint_arg+0x440>
    53d4:      	ldrb	w8, [x22, #0x4]
    53d8:      	cbz	w8, 0x53e4 <generic_tracepoint_arg+0x434>
    53dc:      	mov	w8, #0x4                // =4
    53e0:      	b	0x53f0 <generic_tracepoint_arg+0x440>
    53e4:      	ldrb	w8, [x22, #0x5]
    53e8:      	cbz	w8, 0x5410 <generic_tracepoint_arg+0x460>
    53ec:      	mov	w8, #0x5                // =5
    53f0:      	stur	w8, [x22, #0x3f]
    53f4:      	adrp	x1, 0x5000 <generic_tracepoint_arg+0x50>
    53f8:      	mov	w8, #0x3                // =3
    53fc:      	mov	w9, #0xc                // =12
    5400:      	ldr	x1, [x1]
    5404:      	mov	x0, x19
    5408:      	mov	w2, #0x3                // =3
    540c:      	blr	x9
    5410:      	ldr	x19, [x20, #0x60]
    5414:      	mov	w8, #0xe                // =14
    5418:      	blr	x8
    541c:      	stp	x19, x0, [sp, #0x10]
    5420:      	adrp	x19, 0x5000 <generic_tracepoint_arg+0x50>
    5424:      	mov	w8, #0x1                // =1
    5428:      	add	x9, sp, #0x10
    542c:      	add	x1, sp, #0x10
    5430:      	ldr	x19, [x19]
    5434:      	mov	x0, x19
    5438:      	blr	x8
    543c:      	cbz	x0, 0x5374 <generic_tracepoint_arg+0x3c4>
    5440:      	mov	w8, #0x3                // =3
    5444:      	add	x9, sp, #0x10
    5448:      	add	x1, sp, #0x10
    544c:      	mov	x0, x19
    5450:      	blr	x8
    5454:      	b	0x5374 <generic_tracepoint_arg+0x3c4>
    5458:      	nop
    545c:      	nop

0000000000005460 <generic_tracepoint_actions>:
    5460:      	sub	sp, sp, #0x40
    5464:      	str	x30, [sp, #0x10]
    5468:      	stp	x22, x21, [sp, #0x20]
    546c:      	stp	x20, x19, [sp, #0x30]
    5470:      	mov	x19, x0
    5474:      	str	wzr, [sp, #0xc]
    5478:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x50>
    547c:      	mov	w8, #0x1                // =1
    5480:      	ldr	x0, [x0]
    5484:      	add	x9, sp, #0xc
    5488:      	add	x1, sp, #0xc
    548c:      	blr	x8
    5490:      	cbz	x0, 0x55a8 <generic_tracepoint_actions+0x148>
    5494:      	mov	w8, #0x5f04             // =24324
    5498:      	ldr	w22, [x0, x8]
    549c:      	cmp	w22, #0x2
    54a0:      	b.lt	0x55a8 <generic_tracepoint_actions+0x148>
    54a4:      	mov	w8, #0x5ef8             // =24312
    54a8:      	mov	w20, #0x1               // =1
    54ac:      	add	x1, x0, x8
    54b0:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x50>
    54b4:      	mov	w8, #0x1                // =1
    54b8:      	ldr	x0, [x0]
    54bc:      	blr	x8
    54c0:      	cbz	x0, 0x55a8 <generic_tracepoint_actions+0x148>
    54c4:      	and	x8, x22, #0x7ff
    54c8:      	mov	x21, x0
    54cc:      	strb	w20, [sp, #0x1c]
    54d0:      	mov	w9, #0x1                // =1
    54d4:      	ldr	w8, [x0, x8]
    54d8:      	str	wzr, [sp, #0x18]
    54dc:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x50>
    54e0:      	add	x1, sp, #0x18
    54e4:      	ldr	x0, [x0]
    54e8:      	add	w8, w8, w22
    54ec:      	and	w22, w8, #0x7ff
    54f0:      	add	x8, sp, #0x18
    54f4:      	blr	x9
    54f8:      	cbz	x0, 0x5508 <generic_tracepoint_actions+0xa8>
    54fc:      	ldrb	w8, [x0]
    5500:      	cmp	w8, #0x0
    5504:      	cset	w20, eq
    5508:      	ldr	w8, [x21, x22]
    550c:      	cmp	w8, #0x5
    5510:      	b.lo	0x5584 <generic_tracepoint_actions+0x124>
    5514:      	add	x2, x21, x22
    5518:      	add	x3, sp, #0x1c
    551c:      	mov	x0, x19
    5520:      	mov	w1, wzr
    5524:      	mov	w4, w20
    5528:      	bl	0x5528 <generic_tracepoint_actions+0xc8>
    552c:      	ldr	w9, [x21, x22]
    5530:      	lsl	w8, w0, #2
    5534:      	add	w8, w8, #0x4
    5538:      	cmp	w8, w9
    553c:      	b.hs	0x5584 <generic_tracepoint_actions+0x124>
    5540:      	mov	w1, w0
    5544:      	add	x2, x21, x22
    5548:      	add	x3, sp, #0x1c
    554c:      	mov	x0, x19
    5550:      	mov	w4, w20
    5554:      	bl	0x5554 <generic_tracepoint_actions+0xf4>
    5558:      	ldr	w9, [x21, x22]
    555c:      	lsl	w8, w0, #2
    5560:      	add	w8, w8, #0x4
    5564:      	cmp	w8, w9
    5568:      	b.hs	0x5584 <generic_tracepoint_actions+0x124>
    556c:      	mov	w1, w0
    5570:      	add	x2, x21, x22
    5574:      	add	x3, sp, #0x1c
    5578:      	mov	x0, x19
    557c:      	mov	w4, w20
    5580:      	bl	0x5580 <generic_tracepoint_actions+0x120>
    5584:      	ldrb	w8, [sp, #0x1c]
    5588:      	cbz	w8, 0x55a8 <generic_tracepoint_actions+0x148>
    558c:      	adrp	x1, 0x5000 <generic_tracepoint_arg+0x50>
    5590:      	mov	w8, #0x5                // =5
    5594:      	mov	w9, #0xc                // =12
    5598:      	ldr	x1, [x1]
    559c:      	mov	x0, x19
    55a0:      	mov	w2, #0x5                // =5
    55a4:      	blr	x9
    55a8:      	ldp	x20, x19, [sp, #0x30]
    55ac:      	mov	w0, wzr
    55b0:      	ldr	x30, [sp, #0x10]
    55b4:      	ldp	x22, x21, [sp, #0x20]
    55b8:      	add	sp, sp, #0x40
    55bc:      	ret

00000000000055c0 <generic_tracepoint_output>:
    55c0:      	sub	sp, sp, #0xc0
    55c4:      	str	x29, [sp, #0x70]
    55c8:      	stp	x30, x25, [sp, #0x80]
    55cc:      	stp	x24, x23, [sp, #0x90]
    55d0:      	stp	x22, x21, [sp, #0xa0]
    55d4:      	stp	x20, x19, [sp, #0xb0]
    55d8:      	mov	x20, x0
    55dc:      	str	wzr, [sp, #0x4]
    55e0:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x50>
    55e4:      	mov	w8, #0x1                // =1
    55e8:      	ldr	x0, [x0]
    55ec:      	add	x9, sp, #0x4
    55f0:      	add	x1, sp, #0x4
    55f4:      	blr	x8
    55f8:      	cbz	x0, 0x5b90 <generic_tracepoint_output+0x5d0>
    55fc:      	adrp	x21, 0x5000 <generic_tracepoint_arg+0x50>
    5600:      	ldr	x8, [x0, #0x5ee8]
    5604:      	mov	x19, x0
    5608:      	ldr	x21, [x21]
    560c:      	cbz	x8, 0x5898 <generic_tracepoint_output+0x2d8>
    5610:      	mov	w8, #0xe                // =14
    5614:      	blr	x8
    5618:      	mov	w8, #0x23               // =35
    561c:      	lsr	x22, x0, #32
    5620:      	blr	x8
    5624:      	str	w22, [sp, #0x28]
    5628:      	mov	w8, #0x1                // =1
    562c:      	add	x9, sp, #0x28
    5630:      	mov	x23, x0
    5634:      	add	x1, sp, #0x28
    5638:      	mov	x0, x21
    563c:      	blr	x8
    5640:      	cbz	x0, 0x5898 <generic_tracepoint_output+0x2d8>
    5644:      	add	x2, x23, #0xb50
    5648:      	mov	w29, #0x8               // =8
    564c:      	add	x8, sp, #0x78
    5650:      	mov	w9, #0x4                // =4
    5654:      	mov	x22, x0
    5658:      	add	x24, x0, #0x28
    565c:      	add	x0, sp, #0x78
    5660:      	mov	w1, #0x8                // =8
    5664:      	mov	w25, #0x4               // =4
    5668:      	blr	x9
    566c:      	ldr	x8, [sp, #0x78]
    5670:      	mov	w9, #0x48               // =72
    5674:      	add	x10, sp, #0x28
    5678:      	mov	w11, #0x4               // =4
    567c:      	ldr	x2, [sp, #0x78]
    5680:      	add	x0, sp, #0x28
    5684:      	mov	w1, #0x48               // =72
    5688:      	blr	x11
    568c:      	ldr	x8, [sp, #0x30]
    5690:      	mov	w9, #0x4                // =4
    5694:      	mov	x0, x24
    5698:      	mov	w1, #0x4                // =4
    569c:      	add	x8, x8, #0x218
    56a0:      	ldr	x8, [sp, #0x30]
    56a4:      	add	x2, x8, #0x218
    56a8:      	blr	x9
    56ac:      	ldr	x8, [sp, #0x38]
    56b0:      	add	x0, x22, #0x2c
    56b4:      	mov	w9, #0x4                // =4
    56b8:      	mov	w1, #0x4                // =4
    56bc:      	add	x8, x8, #0x4d8
    56c0:      	ldr	x8, [sp, #0x38]
    56c4:      	add	x2, x8, #0x4d8
    56c8:      	blr	x9
    56cc:      	ldr	x8, [sp, #0x40]
    56d0:      	add	x0, x22, #0x30
    56d4:      	mov	w9, #0x4                // =4
    56d8:      	mov	w1, #0x4                // =4
    56dc:      	add	x8, x8, #0x58
    56e0:      	ldr	x8, [sp, #0x40]
    56e4:      	add	x2, x8, #0x58
    56e8:      	blr	x9
    56ec:      	str	xzr, [sp, #0x20]
    56f0:      	add	x2, x23, #0x938
    56f4:      	add	x8, sp, #0x20
    56f8:      	add	x0, sp, #0x20
    56fc:      	mov	w1, #0x8                // =8
    5700:      	blr	x25
    5704:      	ldr	x8, [sp, #0x20]
    5708:      	cbz	x8, 0x578c <generic_tracepoint_output+0x1cc>
    570c:      	str	wzr, [sp, #0x1c]
    5710:      	add	x8, x8, #0x4
    5714:      	add	x9, sp, #0x1c
    5718:      	mov	w10, #0x4               // =4
    571c:      	add	x0, sp, #0x1c
    5720:      	mov	w1, #0x4                // =4
    5724:      	mov	w24, #0x4               // =4
    5728:      	ldr	x8, [sp, #0x20]
    572c:      	add	x2, x8, #0x4
    5730:      	blr	x10
    5734:      	ldr	x8, [sp, #0x20]
    5738:      	ldrsw	x9, [sp, #0x1c]
    573c:      	add	x10, sp, #0x8
    5740:      	mov	w11, #0x4               // =4
    5744:      	add	x0, sp, #0x8
    5748:      	mov	w1, #0x10               // =16
    574c:      	add	x8, x8, x9, lsl #4
    5750:      	mov	w9, #0x10               // =16
    5754:      	add	x8, x8, #0x80
    5758:      	ldr	x8, [sp, #0x20]
    575c:      	ldrsw	x9, [sp, #0x1c]
    5760:      	add	x8, x8, x9, lsl #4
    5764:      	add	x2, x8, #0x80
    5768:      	blr	x11
    576c:      	ldr	x8, [sp, #0x10]
    5770:      	add	x0, x22, #0x34
    5774:      	mov	w1, #0x4                // =4
    5778:      	add	x8, x8, #0x158
    577c:      	ldr	x8, [sp, #0x10]
    5780:      	add	x2, x8, #0x158
    5784:      	blr	x24
    5788:      	b	0x5790 <generic_tracepoint_output+0x1d0>
    578c:      	str	wzr, [x22, #0x34]
    5790:      	ldr	x8, [sp, #0x48]
    5794:      	add	x0, x22, #0x38
    5798:      	mov	w9, #0x4                // =4
    579c:      	mov	w1, #0x4                // =4
    57a0:      	mov	w24, #0x4               // =4
    57a4:      	add	x8, x8, #0x158
    57a8:      	ldr	x8, [sp, #0x48]
    57ac:      	add	x2, x8, #0x158
    57b0:      	blr	x9
    57b4:      	ldr	x8, [sp, #0x50]
    57b8:      	add	x0, x22, #0x3c
    57bc:      	mov	w9, #0x4                // =4
    57c0:      	mov	w1, #0x4                // =4
    57c4:      	add	x8, x8, #0x118
    57c8:      	ldr	x8, [sp, #0x50]
    57cc:      	add	x2, x8, #0x118
    57d0:      	blr	x9
    57d4:      	ldr	x8, [sp, #0x58]
    57d8:      	add	x0, x22, #0x40
    57dc:      	mov	w9, #0x4                // =4
    57e0:      	mov	w1, #0x4                // =4
    57e4:      	add	x8, x8, #0x98
    57e8:      	ldr	x8, [sp, #0x58]
    57ec:      	add	x2, x8, #0x98
    57f0:      	blr	x9
    57f4:      	ldr	x8, [sp, #0x60]
    57f8:      	add	x0, x22, #0x44
    57fc:      	mov	w9, #0x4                // =4
    5800:      	mov	w1, #0x4                // =4
    5804:      	add	x8, x8, #0x98
    5808:      	ldr	x8, [sp, #0x60]
    580c:      	add	x2, x8, #0x98
    5810:      	blr	x9
    5814:      	ldr	x8, [sp, #0x68]
    5818:      	add	x0, x22, #0x48
    581c:      	mov	w9, #0x4                // =4
    5820:      	mov	w1, #0x4                // =4
    5824:      	add	x8, x8, #0x58
    5828:      	ldr	x8, [sp, #0x68]
    582c:      	add	x2, x8, #0x58
    5830:      	blr	x9
    5834:      	str	xzr, [sp, #0x8]
    5838:      	str	xzr, [sp, #0x20]
    583c:      	add	x2, x23, #0xae0
    5840:      	mov	w23, #0x8               // =8
    5844:      	add	x8, sp, #0x8
    5848:      	mov	w9, #0x4                // =4
    584c:      	add	x0, sp, #0x8
    5850:      	mov	w1, #0x8                // =8
    5854:      	blr	x9
    5858:      	ldr	x8, [sp, #0x8]
    585c:      	add	x9, sp, #0x20
    5860:      	mov	w10, #0x4               // =4
    5864:      	add	x0, sp, #0x20
    5868:      	mov	w1, #0x8                // =8
    586c:      	add	x8, x8, #0x90
    5870:      	ldr	x8, [sp, #0x8]
    5874:      	add	x2, x8, #0x90
    5878:      	blr	x10
    587c:      	ldr	x8, [sp, #0x20]
    5880:      	add	x0, x22, #0x4c
    5884:      	mov	w1, #0x4                // =4
    5888:      	add	x8, x8, #0x158
    588c:      	ldr	x8, [sp, #0x20]
    5890:      	add	x2, x8, #0x158
    5894:      	blr	x24
    5898:      	ldr	x8, [x19, #0x5ef0]
    589c:      	cbz	x8, 0x5938 <generic_tracepoint_output+0x378>
    58a0:      	mov	w8, #0xe                // =14
    58a4:      	blr	x8
    58a8:      	mov	w8, #0x23               // =35
    58ac:      	lsr	x23, x0, #32
    58b0:      	blr	x8
    58b4:      	str	w23, [sp, #0x28]
    58b8:      	mov	w8, #0x1                // =1
    58bc:      	add	x9, sp, #0x28
    58c0:      	mov	x22, x0
    58c4:      	add	x1, sp, #0x28
    58c8:      	mov	x0, x21
    58cc:      	blr	x8
    58d0:      	cbz	x0, 0x5938 <generic_tracepoint_output+0x378>
    58d4:      	add	x2, x22, #0xae0
    58d8:      	mov	w22, #0x8               // =8
    58dc:      	add	x8, sp, #0x28
    58e0:      	mov	w9, #0x4                // =4
    58e4:      	add	x21, x0, #0x50
    58e8:      	mov	x24, x0
    58ec:      	add	x0, sp, #0x28
    58f0:      	mov	w1, #0x8                // =8
    58f4:      	mov	w23, #0x4               // =4
    58f8:      	blr	x9
    58fc:      	ldr	x25, [sp, #0x28]
    5900:      	add	x0, x24, #0x58
    5904:      	mov	w8, #0x4                // =4
    5908:      	mov	w1, #0x8                // =8
    590c:      	add	x2, x25, #0x40
    5910:      	blr	x8
    5914:      	add	x0, x24, #0x60
    5918:      	add	x2, x25, #0x30
    591c:      	mov	w8, #0x4                // =4
    5920:      	mov	w1, #0x8                // =8
    5924:      	blr	x8
    5928:      	add	x2, x25, #0x38
    592c:      	mov	x0, x21
    5930:      	mov	w1, #0x8                // =8
    5934:      	blr	x23
    5938:      	ldr	w8, [x19, #0x4]
    593c:      	mov	w9, #0x2328             // =9000
    5940:      	str	wzr, [sp, #0x8]
    5944:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x50>
    5948:      	add	x1, sp, #0x8
    594c:      	add	w8, w8, #0x90
    5950:      	ldr	x0, [x0]
    5954:      	and	w8, w8, #0x7fff
    5958:      	cmp	w8, w9
    595c:      	csel	w21, w8, w9, lo
    5960:      	mov	w8, #0x1                // =1
    5964:      	add	x9, sp, #0x8
    5968:      	blr	x8
    596c:      	cbz	x0, 0x59d8 <generic_tracepoint_output+0x418>
    5970:      	ldrb	w8, [x0, #0x28]
    5974:      	cbz	w8, 0x59d8 <generic_tracepoint_output+0x418>
    5978:      	adrp	x1, 0x5000 <generic_tracepoint_arg+0x50>
    597c:      	mov	w8, #-0x1               // =-1
    5980:      	mov	w9, #0x19               // =25
    5984:      	ldr	x1, [x1]
    5988:      	mov	x0, x20
    598c:      	mov	w2, #-0x1               // =-1
    5990:      	mov	x3, x19
    5994:      	mov	x4, x21
    5998:      	blr	x9
    599c:      	tbnz	x0, #0x3f, 0x5a84 <generic_tracepoint_output+0x4c4>
    59a0:      	str	wzr, [sp, #0x28]
    59a4:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x50>
    59a8:      	mov	w8, #0x1                // =1
    59ac:      	add	x9, sp, #0x28
    59b0:      	ldr	x0, [x0]
    59b4:      	add	x1, sp, #0x28
    59b8:      	blr	x8
    59bc:      	cbz	x0, 0x5b90 <generic_tracepoint_output+0x5d0>
    59c0:      	add	x8, x0, #0x8
    59c4:      	ldaxr	x9, [x8]
    59c8:      	add	x9, x9, #0x1
    59cc:      	stlxr	w10, x9, [x8]
    59d0:      	cbnz	w10, 0x59c4 <generic_tracepoint_output+0x404>
    59d4:      	b	0x5b90 <generic_tracepoint_output+0x5d0>
    59d8:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x50>
    59dc:      	mov	x3, xzr
    59e0:      	mov	w8, #0x82               // =130
    59e4:      	ldr	x0, [x0]
    59e8:      	mov	x1, x19
    59ec:      	mov	x2, x21
    59f0:      	blr	x8
    59f4:      	tbnz	x0, #0x3f, 0x5a34 <generic_tracepoint_output+0x474>
    59f8:      	str	wzr, [sp, #0x28]
    59fc:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x50>
    5a00:      	mov	w8, #0x1                // =1
    5a04:      	add	x9, sp, #0x28
    5a08:      	ldr	x0, [x0]
    5a0c:      	add	x1, sp, #0x28
    5a10:      	blr	x8
    5a14:      	cbz	x0, 0x5b90 <generic_tracepoint_output+0x5d0>
    5a18:      	add	x8, x0, #0x8
    5a1c:      	nop
    5a20:      	ldaxr	x9, [x8]
    5a24:      	add	x9, x9, #0x1
    5a28:      	stlxr	w10, x9, [x8]
    5a2c:      	cbnz	w10, 0x5a20 <generic_tracepoint_output+0x460>
    5a30:      	b	0x5b90 <generic_tracepoint_output+0x5d0>
    5a34:      	mov	x19, x0
    5a38:      	str	wzr, [sp, #0x28]
    5a3c:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x50>
    5a40:      	mov	w8, #0x1                // =1
    5a44:      	ldr	x0, [x0]
    5a48:      	add	x9, sp, #0x28
    5a4c:      	add	x1, sp, #0x28
    5a50:      	blr	x8
    5a54:      	cbz	x0, 0x5b90 <generic_tracepoint_output+0x5d0>
    5a58:      	mov	x8, x19
    5a5c:      	cmn	x19, #0xc
    5a60:      	b.gt	0x5ad4 <generic_tracepoint_output+0x514>
    5a64:      	cmn	x8, #0x1c
    5a68:      	b.eq	0x5b14 <generic_tracepoint_output+0x554>
    5a6c:      	cmn	x8, #0x16
    5a70:      	b.eq	0x5b2c <generic_tracepoint_output+0x56c>
    5a74:      	cmn	x8, #0x10
    5a78:      	b.ne	0x5b24 <generic_tracepoint_output+0x564>
    5a7c:      	add	x8, x0, #0x328
    5a80:      	b	0x5b40 <generic_tracepoint_output+0x580>
    5a84:      	mov	x19, x0
    5a88:      	str	wzr, [sp, #0x28]
    5a8c:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x50>
    5a90:      	mov	w8, #0x1                // =1
    5a94:      	ldr	x0, [x0]
    5a98:      	add	x9, sp, #0x28
    5a9c:      	add	x1, sp, #0x28
    5aa0:      	blr	x8
    5aa4:      	cbz	x0, 0x5b90 <generic_tracepoint_output+0x5d0>
    5aa8:      	mov	x8, x19
    5aac:      	cmn	x19, #0xc
    5ab0:      	b.gt	0x5af4 <generic_tracepoint_output+0x534>
    5ab4:      	cmn	x8, #0x1c
    5ab8:      	b.eq	0x5b54 <generic_tracepoint_output+0x594>
    5abc:      	cmn	x8, #0x16
    5ac0:      	b.eq	0x5b6c <generic_tracepoint_output+0x5ac>
    5ac4:      	cmn	x8, #0x10
    5ac8:      	b.ne	0x5b64 <generic_tracepoint_output+0x5a4>
    5acc:      	add	x8, x0, #0x328
    5ad0:      	b	0x5b80 <generic_tracepoint_output+0x5c0>
    5ad4:      	cmn	x8, #0xb
    5ad8:      	b.eq	0x5b1c <generic_tracepoint_output+0x55c>
    5adc:      	cmn	x8, #0x7
    5ae0:      	b.eq	0x5b34 <generic_tracepoint_output+0x574>
    5ae4:      	cmn	x8, #0x2
    5ae8:      	b.ne	0x5b24 <generic_tracepoint_output+0x564>
    5aec:      	add	x8, x0, #0x318
    5af0:      	b	0x5b40 <generic_tracepoint_output+0x580>
    5af4:      	cmn	x8, #0xb
    5af8:      	b.eq	0x5b5c <generic_tracepoint_output+0x59c>
    5afc:      	cmn	x8, #0x7
    5b00:      	b.eq	0x5b74 <generic_tracepoint_output+0x5b4>
    5b04:      	cmn	x8, #0x2
    5b08:      	b.ne	0x5b64 <generic_tracepoint_output+0x5a4>
    5b0c:      	add	x8, x0, #0x318
    5b10:      	b	0x5b80 <generic_tracepoint_output+0x5c0>
    5b14:      	add	x8, x0, #0x338
    5b18:      	b	0x5b40 <generic_tracepoint_output+0x580>
    5b1c:      	add	x8, x0, #0x340
    5b20:      	b	0x5b40 <generic_tracepoint_output+0x580>
    5b24:      	add	x8, x0, #0x310
    5b28:      	b	0x5b40 <generic_tracepoint_output+0x580>
    5b2c:      	add	x8, x0, #0x330
    5b30:      	b	0x5b40 <generic_tracepoint_output+0x580>
    5b34:      	add	x8, x0, #0x320
    5b38:      	nop
    5b3c:      	nop
    5b40:      	ldaxr	x9, [x8]
    5b44:      	add	x9, x9, #0x1
    5b48:      	stlxr	w10, x9, [x8]
    5b4c:      	cbnz	w10, 0x5b40 <generic_tracepoint_output+0x580>
    5b50:      	b	0x5b90 <generic_tracepoint_output+0x5d0>
    5b54:      	add	x8, x0, #0x338
    5b58:      	b	0x5b80 <generic_tracepoint_output+0x5c0>
    5b5c:      	add	x8, x0, #0x340
    5b60:      	b	0x5b80 <generic_tracepoint_output+0x5c0>
    5b64:      	add	x8, x0, #0x310
    5b68:      	b	0x5b80 <generic_tracepoint_output+0x5c0>
    5b6c:      	add	x8, x0, #0x330
    5b70:      	b	0x5b80 <generic_tracepoint_output+0x5c0>
    5b74:      	add	x8, x0, #0x320
    5b78:      	nop
    5b7c:      	nop
    5b80:      	ldaxr	x9, [x8]
    5b84:      	add	x9, x9, #0x1
    5b88:      	stlxr	w10, x9, [x8]
    5b8c:      	cbnz	w10, 0x5b80 <generic_tracepoint_output+0x5c0>
    5b90:      	ldp	x20, x19, [sp, #0xb0]
    5b94:      	mov	w0, wzr
    5b98:      	ldr	x29, [sp, #0x70]
    5b9c:      	ldp	x22, x21, [sp, #0xa0]
    5ba0:      	ldp	x24, x23, [sp, #0x90]
    5ba4:      	ldp	x30, x25, [sp, #0x80]
    5ba8:      	add	sp, sp, #0xc0
    5bac:      	ret

Disassembly of section tracepoint/generic_tracepoint:

0000000000000000 <generic_tracepoint_event>:
       0:      	sub	sp, sp, #0xd0
       4:      	stp	x30, x25, [sp, #0x90]
       8:      	stp	x24, x23, [sp, #0xa0]
       c:      	stp	x22, x21, [sp, #0xb0]
      10:      	stp	x20, x19, [sp, #0xc0]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <generic_tracepoint_event>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x3184 <generic_tracepoint_event+0x3184>
      38:      	mov	x20, x0
      3c:      	adrp	x0, 0x0 <generic_tracepoint_event>
      40:      	mov	w8, #0x1                // =1
      44:      	ldr	x0, [x0]
      48:      	add	x9, sp, #0xc
      4c:      	add	x1, sp, #0xc
      50:      	blr	x8
      54:      	cbz	x0, 0x3184 <generic_tracepoint_event+0x3184>
      58:      	ldr	w8, [x0, #0x64]
      5c:      	mov	x21, x0
      60:      	str	w8, [sp, #0x1c]
      64:      	cbz	w8, 0x220 <generic_tracepoint_event+0x220>
      68:      	adrp	x22, 0x0 <generic_tracepoint_event>
      6c:      	mov	w8, #0x1                // =1
      70:      	add	x9, sp, #0x1c
      74:      	ldr	x22, [x22]
      78:      	add	x1, sp, #0x1c
      7c:      	mov	x0, x22
      80:      	blr	x8
      84:      	cbz	x0, 0x3184 <generic_tracepoint_event+0x3184>
      88:      	mov	x23, x0
      8c:      	str	wzr, [sp, #0x84]
      90:      	adrp	x0, 0x0 <generic_tracepoint_event>
      94:      	mov	w8, #0x1                // =1
      98:      	ldr	x0, [x0]
      9c:      	add	x9, sp, #0x84
      a0:      	add	x1, sp, #0x84
      a4:      	blr	x8
      a8:      	cbz	x0, 0xd4 <generic_tracepoint_event+0xd4>
      ac:      	ldr	x8, [x0, #0x20]
      b0:      	mov	w9, #0x7270             // =29296
      b4:      	movk	w9, #0x6367, lsl #16
      b8:      	cmp	x8, x9
      bc:      	b.ne	0xdc <generic_tracepoint_event+0xdc>
      c0:      	mov	w8, #0x50               // =80
      c4:      	blr	x8
      c8:      	str	x0, [sp, #0x30]
      cc:      	cbnz	x0, 0x1d0 <generic_tracepoint_event+0x1d0>
      d0:      	b	0x3184 <generic_tracepoint_event+0x3184>
      d4:      	mov	w24, wzr
      d8:      	b	0xe0 <generic_tracepoint_event+0xe0>
      dc:      	ldr	w24, [x0, #0x10]
      e0:      	mov	w8, #0x23               // =35
      e4:      	blr	x8
      e8:      	str	xzr, [sp, #0x88]
      ec:      	add	x2, x0, #0xcd0
      f0:      	mov	w8, #0x8                // =8
      f4:      	mov	w9, #0x71               // =113
      f8:      	add	x10, sp, #0x20
      fc:      	add	x0, sp, #0x20
     100:      	mov	w1, #0x8                // =8
     104:      	blr	x9
     108:      	ldr	x8, [sp, #0x20]
     10c:      	cbz	x8, 0x164 <generic_tracepoint_event+0x164>
     110:      	cmp	w24, #0xb
     114:      	b.hi	0x164 <generic_tracepoint_event+0x164>
     118:      	ubfiz	x9, x24, #3, #32
     11c:      	mov	w10, #0x8               // =8
     120:      	mov	w11, #0x71              // =113
     124:      	add	x12, sp, #0x38
     128:      	add	x0, sp, #0x38
     12c:      	mov	w1, #0x8                // =8
     130:      	add	x8, x8, x9
     134:      	ldr	x8, [sp, #0x20]
     138:      	add	x2, x8, x9
     13c:      	blr	x11
     140:      	ldr	x8, [sp, #0x38]
     144:      	cbz	x8, 0x164 <generic_tracepoint_event+0x164>
     148:      	mov	w9, #0x8                // =8
     14c:      	mov	w10, #0x71              // =113
     150:      	add	x11, sp, #0x88
     154:      	ldr	x2, [sp, #0x38]
     158:      	add	x0, sp, #0x88
     15c:      	mov	w1, #0x8                // =8
     160:      	blr	x10
     164:      	ldr	x8, [sp, #0x88]
     168:      	cbz	x8, 0x3184 <generic_tracepoint_event+0x3184>
     16c:      	str	xzr, [sp, #0x38]
     170:      	add	x2, x8, #0x100
     174:      	mov	w8, #0x8                // =8
     178:      	mov	w9, #0x71               // =113
     17c:      	add	x10, sp, #0x38
     180:      	add	x0, sp, #0x38
     184:      	mov	w1, #0x8                // =8
     188:      	blr	x9
     18c:      	ldr	x8, [sp, #0x38]
     190:      	str	xzr, [sp, #0x38]
     194:      	cbz	x8, 0x1c4 <generic_tracepoint_event+0x1c4>
     198:      	add	x2, x8, #0x60
     19c:      	mov	w8, #0x8                // =8
     1a0:      	mov	w9, #0x71               // =113
     1a4:      	add	x10, sp, #0x38
     1a8:      	add	x0, sp, #0x38
     1ac:      	mov	w1, #0x8                // =8
     1b0:      	blr	x9
     1b4:      	ldr	x0, [sp, #0x38]
     1b8:      	str	x0, [sp, #0x30]
     1bc:      	cbnz	x0, 0x1d0 <generic_tracepoint_event+0x1d0>
     1c0:      	b	0x3184 <generic_tracepoint_event+0x3184>
     1c4:      	mov	x0, xzr
     1c8:      	str	xzr, [sp, #0x30]
     1cc:      	cbz	xzr, 0x3184 <generic_tracepoint_event+0x3184>
     1d0:      	str	x0, [sp, #0x38]
     1d4:      	adrp	x0, 0x0 <generic_tracepoint_event>
     1d8:      	mov	w8, #0x1                // =1
     1dc:      	add	x9, sp, #0x38
     1e0:      	ldr	x0, [x0]
     1e4:      	add	x1, sp, #0x38
     1e8:      	blr	x8
     1ec:      	cbz	x0, 0x204 <generic_tracepoint_event+0x204>
     1f0:      	ldr	x8, [x0]
     1f4:      	str	x8, [sp, #0x10]
     1f8:      	cbz	x8, 0x208 <generic_tracepoint_event+0x208>
     1fc:      	str	x8, [sp, #0x30]
     200:      	b	0x208 <generic_tracepoint_event+0x208>
     204:      	str	xzr, [sp, #0x10]
     208:      	mov	w8, #0x1                // =1
     20c:      	add	x9, sp, #0x30
     210:      	add	x1, sp, #0x30
     214:      	mov	x0, x23
     218:      	blr	x8
     21c:      	cbz	x0, 0x42c <generic_tracepoint_event+0x42c>
     220:      	add	x23, x20, #0x5, lsl #12 // =0x5000
     224:      	mov	x22, xzr
     228:      	str	wzr, [x23, #0xef8]
     22c:      	ldr	w8, [x21]
     230:      	stp	x8, xzr, [x20, #0x60]
     234:      	ldrh	w8, [x21, #0x2c]
     238:      	ldr	w24, [x21, #0x4]
     23c:      	add	x2, x19, x8
     240:      	cmp	w24, #0xb
     244:      	b.gt	0x274 <generic_tracepoint_event+0x274>
     248:      	cmp	w24, #0x3
     24c:      	b.le	0x30c <generic_tracepoint_event+0x30c>
     250:      	cmp	w24, #0x6
     254:      	b.gt	0x480 <generic_tracepoint_event+0x480>
     258:      	cmp	w24, #0x4
     25c:      	b.eq	0x8c8 <generic_tracepoint_event+0x8c8>
     260:      	cmp	w24, #0x5
     264:      	b.eq	0x770 <generic_tracepoint_event+0x770>
     268:      	cmp	w24, #0x6
     26c:      	b.eq	0x328 <generic_tracepoint_event+0x328>
     270:      	b	0xb40 <generic_tracepoint_event+0xb40>
     274:      	cmp	w24, #0x1d
     278:      	b.le	0x39c <generic_tracepoint_event+0x39c>
     27c:      	cmp	w24, #0x25
     280:      	b.gt	0x4f8 <generic_tracepoint_event+0x4f8>
     284:      	cmp	w24, #0x1e
     288:      	b.eq	0x934 <generic_tracepoint_event+0x934>
     28c:      	cmp	w24, #0x1f
     290:      	b.eq	0x7e4 <generic_tracepoint_event+0x7e4>
     294:      	cmp	w24, #0x20
     298:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     29c:      	mov	w8, #0x1                // =1
     2a0:      	mov	w9, #0x4                // =4
     2a4:      	add	x10, sp, #0x88
     2a8:      	add	x0, sp, #0x88
     2ac:      	mov	w1, #0x1                // =1
     2b0:      	blr	x9
     2b4:      	cbz	x0, 0xab8 <generic_tracepoint_event+0xab8>
     2b8:      	neg	w8, w0
     2bc:      	adrp	x22, 0x0 <generic_tracepoint_event>
     2c0:      	mov	w9, #0x1                // =1
     2c4:      	strh	w8, [sp, #0x38]
     2c8:      	mov	w8, #0x7                // =7
     2cc:      	add	x1, sp, #0x38
     2d0:      	mov	w24, #0x1               // =1
     2d4:      	strh	w8, [sp, #0x3a]
     2d8:      	mov	x8, #0x73               // =115
     2dc:      	movk	x8, #0x4, lsl #32
     2e0:      	stur	x8, [sp, #0x3c]
     2e4:      	add	x8, sp, #0x38
     2e8:      	ldr	x22, [x22]
     2ec:      	mov	x0, x22
     2f0:      	blr	x9
     2f4:      	cbz	x0, 0xa94 <generic_tracepoint_event+0xa94>
     2f8:      	ldr	w8, [x0]
     2fc:      	add	w8, w8, #0x1
     300:      	str	w8, [x0]
     304:      	ldrb	w22, [sp, #0x88]
     308:      	b	0xb40 <generic_tracepoint_event+0xb40>
     30c:      	cmn	w24, #0xc
     310:      	b.le	0x584 <generic_tracepoint_event+0x584>
     314:      	add	w8, w24, #0xb
     318:      	cmp	w8, #0x2
     31c:      	b.lo	0x48c <generic_tracepoint_event+0x48c>
     320:      	cmp	w24, #0x2
     324:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     328:      	mov	w8, #0x8                // =8
     32c:      	mov	w9, #0x4                // =4
     330:      	add	x10, sp, #0x20
     334:      	add	x0, sp, #0x20
     338:      	mov	w1, #0x8                // =8
     33c:      	blr	x9
     340:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     344:      	neg	w8, w0
     348:      	adrp	x22, 0x0 <generic_tracepoint_event>
     34c:      	mov	w9, #0x1                // =1
     350:      	strh	w8, [sp, #0x38]
     354:      	mov	w8, #0x7                // =7
     358:      	add	x1, sp, #0x38
     35c:      	mov	w24, #0x1               // =1
     360:      	strh	w8, [sp, #0x3a]
     364:      	mov	x8, #0x81               // =129
     368:      	movk	x8, #0x4, lsl #32
     36c:      	stur	x8, [sp, #0x3c]
     370:      	add	x8, sp, #0x38
     374:      	ldr	x22, [x22]
     378:      	mov	x0, x22
     37c:      	blr	x9
     380:      	cbnz	x0, 0x924 <generic_tracepoint_event+0x924>
     384:      	str	w24, [sp, #0x88]
     388:      	mov	x3, xzr
     38c:      	mov	w8, #0x2                // =2
     390:      	add	x9, sp, #0x38
     394:      	add	x10, sp, #0x88
     398:      	b	0xad4 <generic_tracepoint_event+0xad4>
     39c:      	cmp	w24, #0x11
     3a0:      	b.le	0x598 <generic_tracepoint_event+0x598>
     3a4:      	cmp	w24, #0x12
     3a8:      	b.eq	0x768 <generic_tracepoint_event+0x768>
     3ac:      	cmp	w24, #0x1c
     3b0:      	b.eq	0x48c <generic_tracepoint_event+0x48c>
     3b4:      	cmp	w24, #0x1d
     3b8:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     3bc:      	mov	w8, #0x2                // =2
     3c0:      	mov	w9, #0x4                // =4
     3c4:      	add	x10, sp, #0x88
     3c8:      	add	x0, sp, #0x88
     3cc:      	mov	w1, #0x2                // =2
     3d0:      	blr	x9
     3d4:      	cbz	x0, 0xa60 <generic_tracepoint_event+0xa60>
     3d8:      	neg	w8, w0
     3dc:      	adrp	x22, 0x0 <generic_tracepoint_event>
     3e0:      	mov	w9, #0x1                // =1
     3e4:      	strh	w8, [sp, #0x38]
     3e8:      	mov	w8, #0x7                // =7
     3ec:      	add	x1, sp, #0x38
     3f0:      	mov	w24, #0x1               // =1
     3f4:      	strh	w8, [sp, #0x3a]
     3f8:      	mov	x8, #0x6c               // =108
     3fc:      	movk	x8, #0x4, lsl #32
     400:      	stur	x8, [sp, #0x3c]
     404:      	add	x8, sp, #0x38
     408:      	ldr	x22, [x22]
     40c:      	mov	x0, x22
     410:      	blr	x9
     414:      	cbz	x0, 0xa3c <generic_tracepoint_event+0xa3c>
     418:      	ldr	w8, [x0]
     41c:      	add	w8, w8, #0x1
     420:      	str	w8, [x0]
     424:      	ldrsh	x22, [sp, #0x88]
     428:      	b	0xb40 <generic_tracepoint_event+0xb40>
     42c:      	mov	x8, #-0x1               // =-1
     430:      	mov	w9, #0x1                // =1
     434:      	add	x1, sp, #0x10
     438:      	str	x8, [sp, #0x10]
     43c:      	add	x8, sp, #0x10
     440:      	mov	x0, x23
     444:      	mov	w24, #0x1               // =1
     448:      	blr	x9
     44c:      	cbz	x0, 0x3184 <generic_tracepoint_event+0x3184>
     450:      	str	w24, [sp, #0x1c]
     454:      	add	x8, sp, #0x1c
     458:      	add	x1, sp, #0x1c
     45c:      	mov	x0, x22
     460:      	blr	x24
     464:      	cbz	x0, 0x3184 <generic_tracepoint_event+0x3184>
     468:      	mov	w8, #0x1                // =1
     46c:      	add	x9, sp, #0x30
     470:      	add	x1, sp, #0x30
     474:      	blr	x8
     478:      	cbnz	x0, 0x3184 <generic_tracepoint_event+0x3184>
     47c:      	b	0x220 <generic_tracepoint_event+0x220>
     480:      	sub	w8, w24, #0xa
     484:      	cmp	w8, #0x2
     488:      	b.hs	0x6ec <generic_tracepoint_event+0x6ec>
     48c:      	mov	w8, #0x8                // =8
     490:      	mov	w9, #0x4                // =4
     494:      	add	x10, sp, #0x20
     498:      	add	x0, sp, #0x20
     49c:      	mov	w1, #0x8                // =8
     4a0:      	blr	x9
     4a4:      	cbz	x0, 0x6a8 <generic_tracepoint_event+0x6a8>
     4a8:      	neg	w8, w0
     4ac:      	adrp	x22, 0x0 <generic_tracepoint_event>
     4b0:      	mov	w9, #0x1                // =1
     4b4:      	strh	w8, [sp, #0x38]
     4b8:      	mov	w8, #0x7                // =7
     4bc:      	add	x1, sp, #0x38
     4c0:      	mov	w25, #0x1               // =1
     4c4:      	strh	w8, [sp, #0x3a]
     4c8:      	mov	x8, #0x45               // =69
     4cc:      	movk	x8, #0x4, lsl #32
     4d0:      	stur	x8, [sp, #0x3c]
     4d4:      	add	x8, sp, #0x38
     4d8:      	ldr	x22, [x22]
     4dc:      	mov	x0, x22
     4e0:      	blr	x9
     4e4:      	cbz	x0, 0x684 <generic_tracepoint_event+0x684>
     4e8:      	ldr	w8, [x0]
     4ec:      	add	w8, w8, #0x1
     4f0:      	str	w8, [x0]
     4f4:      	b	0x6a8 <generic_tracepoint_event+0x6a8>
     4f8:      	cmp	w24, #0x26
     4fc:      	b.eq	0x9a4 <generic_tracepoint_event+0x9a4>
     500:      	cmp	w24, #0x28
     504:      	b.eq	0x854 <generic_tracepoint_event+0x854>
     508:      	cmp	w24, #0x29
     50c:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     510:      	mov	w8, #0x8                // =8
     514:      	mov	w9, #0x4                // =4
     518:      	add	x10, sp, #0x20
     51c:      	add	x0, sp, #0x20
     520:      	mov	w1, #0x8                // =8
     524:      	blr	x9
     528:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     52c:      	neg	w8, w0
     530:      	adrp	x22, 0x0 <generic_tracepoint_event>
     534:      	mov	w9, #0x1                // =1
     538:      	strh	w8, [sp, #0x38]
     53c:      	mov	w8, #0x7                // =7
     540:      	add	x1, sp, #0x38
     544:      	mov	w24, #0x1               // =1
     548:      	strh	w8, [sp, #0x3a]
     54c:      	mov	x8, #0xa8               // =168
     550:      	movk	x8, #0x4, lsl #32
     554:      	stur	x8, [sp, #0x3c]
     558:      	add	x8, sp, #0x38
     55c:      	ldr	x22, [x22]
     560:      	mov	x0, x22
     564:      	blr	x9
     568:      	cbnz	x0, 0x924 <generic_tracepoint_event+0x924>
     56c:      	str	w24, [sp, #0x88]
     570:      	mov	x3, xzr
     574:      	mov	w8, #0x2                // =2
     578:      	add	x9, sp, #0x38
     57c:      	add	x10, sp, #0x88
     580:      	b	0xad4 <generic_tracepoint_event+0xad4>
     584:      	cmn	w24, #0xd
     588:      	b.eq	0x618 <generic_tracepoint_event+0x618>
     58c:      	cmn	w24, #0xc
     590:      	b.eq	0x5a8 <generic_tracepoint_event+0x5a8>
     594:      	b	0xb40 <generic_tracepoint_event+0xb40>
     598:      	cmp	w24, #0xc
     59c:      	b.eq	0x618 <generic_tracepoint_event+0x618>
     5a0:      	cmp	w24, #0xd
     5a4:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     5a8:      	mov	w8, #0x4                // =4
     5ac:      	add	x9, sp, #0x88
     5b0:      	add	x0, sp, #0x88
     5b4:      	mov	w1, #0x4                // =4
     5b8:      	blr	x8
     5bc:      	cbz	x0, 0xb3c <generic_tracepoint_event+0xb3c>
     5c0:      	neg	w8, w0
     5c4:      	adrp	x22, 0x0 <generic_tracepoint_event>
     5c8:      	mov	w9, #0x1                // =1
     5cc:      	strh	w8, [sp, #0x38]
     5d0:      	mov	w8, #0x7                // =7
     5d4:      	add	x1, sp, #0x38
     5d8:      	mov	w24, #0x1               // =1
     5dc:      	strh	w8, [sp, #0x3a]
     5e0:      	mov	x8, #0x5e               // =94
     5e4:      	movk	x8, #0x4, lsl #32
     5e8:      	stur	x8, [sp, #0x3c]
     5ec:      	add	x8, sp, #0x38
     5f0:      	ldr	x22, [x22]
     5f4:      	mov	x0, x22
     5f8:      	blr	x9
     5fc:      	cbnz	x0, 0x9fc <generic_tracepoint_event+0x9fc>
     600:      	str	w24, [sp, #0x20]
     604:      	mov	x3, xzr
     608:      	mov	w8, #0x2                // =2
     60c:      	add	x9, sp, #0x38
     610:      	add	x10, sp, #0x20
     614:      	b	0xb2c <generic_tracepoint_event+0xb2c>
     618:      	mov	w8, #0x4                // =4
     61c:      	add	x9, sp, #0x88
     620:      	add	x0, sp, #0x88
     624:      	mov	w1, #0x4                // =4
     628:      	blr	x8
     62c:      	cbz	x0, 0xa34 <generic_tracepoint_event+0xa34>
     630:      	neg	w8, w0
     634:      	adrp	x22, 0x0 <generic_tracepoint_event>
     638:      	mov	w9, #0x1                // =1
     63c:      	strh	w8, [sp, #0x38]
     640:      	mov	w8, #0x7                // =7
     644:      	add	x1, sp, #0x38
     648:      	mov	w24, #0x1               // =1
     64c:      	strh	w8, [sp, #0x3a]
     650:      	mov	x8, #0x56               // =86
     654:      	movk	x8, #0x4, lsl #32
     658:      	stur	x8, [sp, #0x3c]
     65c:      	add	x8, sp, #0x38
     660:      	ldr	x22, [x22]
     664:      	mov	x0, x22
     668:      	blr	x9
     66c:      	cbz	x0, 0xa10 <generic_tracepoint_event+0xa10>
     670:      	ldr	w8, [x0]
     674:      	add	w8, w8, #0x1
     678:      	str	w8, [x0]
     67c:      	ldrsw	x22, [sp, #0x88]
     680:      	b	0xb40 <generic_tracepoint_event+0xb40>
     684:      	str	w25, [sp, #0x88]
     688:      	mov	x3, xzr
     68c:      	mov	w8, #0x2                // =2
     690:      	add	x9, sp, #0x38
     694:      	add	x10, sp, #0x88
     698:      	add	x1, sp, #0x38
     69c:      	add	x2, sp, #0x88
     6a0:      	mov	x0, x22
     6a4:      	blr	x8
     6a8:      	ldr	x22, [sp, #0x20]
     6ac:      	cmp	w24, #0x1c
     6b0:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     6b4:      	mov	w8, #0x23               // =35
     6b8:      	blr	x8
     6bc:      	mov	w8, #0x8                // =8
     6c0:      	mov	w9, #0x4                // =4
     6c4:      	add	x10, sp, #0x38
     6c8:      	mov	x2, x0
     6cc:      	add	x0, sp, #0x38
     6d0:      	mov	w1, #0x8                // =8
     6d4:      	blr	x9
     6d8:      	ldr	w8, [sp, #0x38]
     6dc:      	lsl	w8, w8, #9
     6e0:      	and	x8, x8, #0x80000000
     6e4:      	orr	x22, x8, x22
     6e8:      	b	0xb40 <generic_tracepoint_event+0xb40>
     6ec:      	cmp	w24, #0x7
     6f0:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     6f4:      	mov	w8, #0x8                // =8
     6f8:      	mov	w9, #0x4                // =4
     6fc:      	add	x10, sp, #0x20
     700:      	add	x0, sp, #0x20
     704:      	mov	w1, #0x8                // =8
     708:      	blr	x9
     70c:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     710:      	neg	w8, w0
     714:      	adrp	x22, 0x0 <generic_tracepoint_event>
     718:      	mov	w9, #0x1                // =1
     71c:      	strh	w8, [sp, #0x38]
     720:      	mov	w8, #0x7                // =7
     724:      	add	x1, sp, #0x38
     728:      	mov	w24, #0x1               // =1
     72c:      	strh	w8, [sp, #0x3a]
     730:      	mov	x8, #0x9a               // =154
     734:      	movk	x8, #0x4, lsl #32
     738:      	stur	x8, [sp, #0x3c]
     73c:      	add	x8, sp, #0x38
     740:      	ldr	x22, [x22]
     744:      	mov	x0, x22
     748:      	blr	x9
     74c:      	cbnz	x0, 0x924 <generic_tracepoint_event+0x924>
     750:      	str	w24, [sp, #0x88]
     754:      	mov	x3, xzr
     758:      	mov	w8, #0x2                // =2
     75c:      	add	x9, sp, #0x38
     760:      	add	x10, sp, #0x88
     764:      	b	0xad4 <generic_tracepoint_event+0xad4>
     768:      	mov	x22, x2
     76c:      	b	0xb40 <generic_tracepoint_event+0xb40>
     770:      	mov	w8, #0x8                // =8
     774:      	mov	w9, #0x4                // =4
     778:      	add	x10, sp, #0x20
     77c:      	add	x0, sp, #0x20
     780:      	mov	w1, #0x8                // =8
     784:      	blr	x9
     788:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     78c:      	neg	w8, w0
     790:      	adrp	x22, 0x0 <generic_tracepoint_event>
     794:      	mov	w9, #0x1                // =1
     798:      	strh	w8, [sp, #0x38]
     79c:      	mov	w8, #0x7                // =7
     7a0:      	add	x1, sp, #0x38
     7a4:      	mov	w24, #0x1               // =1
     7a8:      	strh	w8, [sp, #0x3a]
     7ac:      	mov	x8, #0x93               // =147
     7b0:      	movk	x8, #0x4, lsl #32
     7b4:      	stur	x8, [sp, #0x3c]
     7b8:      	add	x8, sp, #0x38
     7bc:      	ldr	x22, [x22]
     7c0:      	mov	x0, x22
     7c4:      	blr	x9
     7c8:      	cbnz	x0, 0x924 <generic_tracepoint_event+0x924>
     7cc:      	str	w24, [sp, #0x88]
     7d0:      	mov	x3, xzr
     7d4:      	mov	w8, #0x2                // =2
     7d8:      	add	x9, sp, #0x38
     7dc:      	add	x10, sp, #0x88
     7e0:      	b	0xad4 <generic_tracepoint_event+0xad4>
     7e4:      	mov	w8, #0x1                // =1
     7e8:      	mov	w9, #0x4                // =4
     7ec:      	add	x10, sp, #0x88
     7f0:      	add	x0, sp, #0x88
     7f4:      	mov	w1, #0x1                // =1
     7f8:      	blr	x9
     7fc:      	cbz	x0, 0xa8c <generic_tracepoint_event+0xa8c>
     800:      	neg	w8, w0
     804:      	adrp	x22, 0x0 <generic_tracepoint_event>
     808:      	mov	w9, #0x1                // =1
     80c:      	strh	w8, [sp, #0x38]
     810:      	mov	w8, #0x7                // =7
     814:      	add	x1, sp, #0x38
     818:      	mov	w24, #0x1               // =1
     81c:      	strh	w8, [sp, #0x3a]
     820:      	mov	x8, #0x7a               // =122
     824:      	movk	x8, #0x4, lsl #32
     828:      	stur	x8, [sp, #0x3c]
     82c:      	add	x8, sp, #0x38
     830:      	ldr	x22, [x22]
     834:      	mov	x0, x22
     838:      	blr	x9
     83c:      	cbz	x0, 0xa68 <generic_tracepoint_event+0xa68>
     840:      	ldr	w8, [x0]
     844:      	add	w8, w8, #0x1
     848:      	str	w8, [x0]
     84c:      	ldrsb	x22, [sp, #0x88]
     850:      	b	0xb40 <generic_tracepoint_event+0xb40>
     854:      	mov	w8, #0x8                // =8
     858:      	mov	w9, #0x4                // =4
     85c:      	add	x10, sp, #0x20
     860:      	add	x0, sp, #0x20
     864:      	mov	w1, #0x8                // =8
     868:      	blr	x9
     86c:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     870:      	neg	w8, w0
     874:      	adrp	x22, 0x0 <generic_tracepoint_event>
     878:      	mov	w9, #0x1                // =1
     87c:      	strh	w8, [sp, #0x38]
     880:      	mov	w8, #0x7                // =7
     884:      	add	x1, sp, #0x38
     888:      	mov	w24, #0x1               // =1
     88c:      	strh	w8, [sp, #0x3a]
     890:      	mov	x8, #0xa1               // =161
     894:      	movk	x8, #0x4, lsl #32
     898:      	stur	x8, [sp, #0x3c]
     89c:      	add	x8, sp, #0x38
     8a0:      	ldr	x22, [x22]
     8a4:      	mov	x0, x22
     8a8:      	blr	x9
     8ac:      	cbnz	x0, 0x924 <generic_tracepoint_event+0x924>
     8b0:      	str	w24, [sp, #0x88]
     8b4:      	mov	x3, xzr
     8b8:      	mov	w8, #0x2                // =2
     8bc:      	add	x9, sp, #0x38
     8c0:      	add	x10, sp, #0x88
     8c4:      	b	0xad4 <generic_tracepoint_event+0xad4>
     8c8:      	mov	w8, #0x8                // =8
     8cc:      	mov	w9, #0x4                // =4
     8d0:      	add	x10, sp, #0x20
     8d4:      	add	x0, sp, #0x20
     8d8:      	mov	w1, #0x8                // =8
     8dc:      	blr	x9
     8e0:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     8e4:      	neg	w8, w0
     8e8:      	adrp	x22, 0x0 <generic_tracepoint_event>
     8ec:      	mov	w9, #0x1                // =1
     8f0:      	strh	w8, [sp, #0x38]
     8f4:      	mov	w8, #0x7                // =7
     8f8:      	add	x1, sp, #0x38
     8fc:      	mov	w24, #0x1               // =1
     900:      	strh	w8, [sp, #0x3a]
     904:      	mov	x8, #0x4e               // =78
     908:      	movk	x8, #0x4, lsl #32
     90c:      	stur	x8, [sp, #0x3c]
     910:      	add	x8, sp, #0x38
     914:      	ldr	x22, [x22]
     918:      	mov	x0, x22
     91c:      	blr	x9
     920:      	cbz	x0, 0xac0 <generic_tracepoint_event+0xac0>
     924:      	ldr	w8, [x0]
     928:      	add	w8, w8, #0x1
     92c:      	str	w8, [x0]
     930:      	b	0xae4 <generic_tracepoint_event+0xae4>
     934:      	mov	w8, #0x2                // =2
     938:      	mov	w9, #0x4                // =4
     93c:      	add	x10, sp, #0x88
     940:      	add	x0, sp, #0x88
     944:      	mov	w1, #0x2                // =2
     948:      	blr	x9
     94c:      	cbz	x0, 0xb10 <generic_tracepoint_event+0xb10>
     950:      	neg	w8, w0
     954:      	adrp	x22, 0x0 <generic_tracepoint_event>
     958:      	mov	w9, #0x1                // =1
     95c:      	strh	w8, [sp, #0x38]
     960:      	mov	w8, #0x7                // =7
     964:      	add	x1, sp, #0x38
     968:      	mov	w24, #0x1               // =1
     96c:      	strh	w8, [sp, #0x3a]
     970:      	mov	x8, #0x65               // =101
     974:      	movk	x8, #0x4, lsl #32
     978:      	stur	x8, [sp, #0x3c]
     97c:      	add	x8, sp, #0x38
     980:      	ldr	x22, [x22]
     984:      	mov	x0, x22
     988:      	blr	x9
     98c:      	cbz	x0, 0xaec <generic_tracepoint_event+0xaec>
     990:      	ldr	w8, [x0]
     994:      	add	w8, w8, #0x1
     998:      	str	w8, [x0]
     99c:      	ldrh	w22, [sp, #0x88]
     9a0:      	b	0xb40 <generic_tracepoint_event+0xb40>
     9a4:      	mov	w8, #0x4                // =4
     9a8:      	add	x9, sp, #0x88
     9ac:      	add	x0, sp, #0x88
     9b0:      	mov	w1, #0x4                // =4
     9b4:      	blr	x8
     9b8:      	cbz	x0, 0xb3c <generic_tracepoint_event+0xb3c>
     9bc:      	neg	w8, w0
     9c0:      	adrp	x22, 0x0 <generic_tracepoint_event>
     9c4:      	mov	w9, #0x1                // =1
     9c8:      	strh	w8, [sp, #0x38]
     9cc:      	mov	w8, #0x7                // =7
     9d0:      	add	x1, sp, #0x38
     9d4:      	mov	w24, #0x1               // =1
     9d8:      	strh	w8, [sp, #0x3a]
     9dc:      	mov	x8, #0x88               // =136
     9e0:      	movk	x8, #0x4, lsl #32
     9e4:      	stur	x8, [sp, #0x3c]
     9e8:      	add	x8, sp, #0x38
     9ec:      	ldr	x22, [x22]
     9f0:      	mov	x0, x22
     9f4:      	blr	x9
     9f8:      	cbz	x0, 0xb18 <generic_tracepoint_event+0xb18>
     9fc:      	ldr	w8, [x0]
     a00:      	add	w8, w8, #0x1
     a04:      	str	w8, [x0]
     a08:      	ldr	w22, [sp, #0x88]
     a0c:      	b	0xb40 <generic_tracepoint_event+0xb40>
     a10:      	str	w24, [sp, #0x20]
     a14:      	mov	x3, xzr
     a18:      	mov	w8, #0x2                // =2
     a1c:      	add	x9, sp, #0x38
     a20:      	add	x10, sp, #0x20
     a24:      	add	x1, sp, #0x38
     a28:      	add	x2, sp, #0x20
     a2c:      	mov	x0, x22
     a30:      	blr	x8
     a34:      	ldrsw	x22, [sp, #0x88]
     a38:      	b	0xb40 <generic_tracepoint_event+0xb40>
     a3c:      	str	w24, [sp, #0x20]
     a40:      	mov	x3, xzr
     a44:      	mov	w8, #0x2                // =2
     a48:      	add	x9, sp, #0x38
     a4c:      	add	x10, sp, #0x20
     a50:      	add	x1, sp, #0x38
     a54:      	add	x2, sp, #0x20
     a58:      	mov	x0, x22
     a5c:      	blr	x8
     a60:      	ldrsh	x22, [sp, #0x88]
     a64:      	b	0xb40 <generic_tracepoint_event+0xb40>
     a68:      	str	w24, [sp, #0x20]
     a6c:      	mov	x3, xzr
     a70:      	mov	w8, #0x2                // =2
     a74:      	add	x9, sp, #0x38
     a78:      	add	x10, sp, #0x20
     a7c:      	add	x1, sp, #0x38
     a80:      	add	x2, sp, #0x20
     a84:      	mov	x0, x22
     a88:      	blr	x8
     a8c:      	ldrsb	x22, [sp, #0x88]
     a90:      	b	0xb40 <generic_tracepoint_event+0xb40>
     a94:      	str	w24, [sp, #0x20]
     a98:      	mov	x3, xzr
     a9c:      	mov	w8, #0x2                // =2
     aa0:      	add	x9, sp, #0x38
     aa4:      	add	x10, sp, #0x20
     aa8:      	add	x1, sp, #0x38
     aac:      	add	x2, sp, #0x20
     ab0:      	mov	x0, x22
     ab4:      	blr	x8
     ab8:      	ldrb	w22, [sp, #0x88]
     abc:      	b	0xb40 <generic_tracepoint_event+0xb40>
     ac0:      	str	w24, [sp, #0x88]
     ac4:      	mov	x3, xzr
     ac8:      	mov	w8, #0x2                // =2
     acc:      	add	x9, sp, #0x38
     ad0:      	add	x10, sp, #0x88
     ad4:      	add	x1, sp, #0x38
     ad8:      	add	x2, sp, #0x88
     adc:      	mov	x0, x22
     ae0:      	blr	x8
     ae4:      	ldr	x22, [sp, #0x20]
     ae8:      	b	0xb40 <generic_tracepoint_event+0xb40>
     aec:      	str	w24, [sp, #0x20]
     af0:      	mov	x3, xzr
     af4:      	mov	w8, #0x2                // =2
     af8:      	add	x9, sp, #0x38
     afc:      	add	x10, sp, #0x20
     b00:      	add	x1, sp, #0x38
     b04:      	add	x2, sp, #0x20
     b08:      	mov	x0, x22
     b0c:      	blr	x8
     b10:      	ldrh	w22, [sp, #0x88]
     b14:      	b	0xb40 <generic_tracepoint_event+0xb40>
     b18:      	str	w24, [sp, #0x20]
     b1c:      	mov	x3, xzr
     b20:      	mov	w8, #0x2                // =2
     b24:      	add	x9, sp, #0x38
     b28:      	add	x10, sp, #0x20
     b2c:      	add	x1, sp, #0x38
     b30:      	add	x2, sp, #0x20
     b34:      	mov	x0, x22
     b38:      	blr	x8
     b3c:      	ldr	w22, [sp, #0x88]
     b40:      	str	x22, [x20, #0x5e50]
     b44:      	mov	x24, xzr
     b48:      	ldrh	w8, [x21, #0x30]
     b4c:      	ldr	w25, [x21, #0x8]
     b50:      	add	x2, x19, x8
     b54:      	cmp	w25, #0xb
     b58:      	b.gt	0xb88 <generic_tracepoint_event+0xb88>
     b5c:      	cmp	w25, #0x3
     b60:      	b.le	0xc20 <generic_tracepoint_event+0xc20>
     b64:      	cmp	w25, #0x6
     b68:      	b.gt	0xd40 <generic_tracepoint_event+0xd40>
     b6c:      	cmp	w25, #0x4
     b70:      	b.eq	0x1188 <generic_tracepoint_event+0x1188>
     b74:      	cmp	w25, #0x5
     b78:      	b.eq	0x1030 <generic_tracepoint_event+0x1030>
     b7c:      	cmp	w25, #0x6
     b80:      	b.eq	0xc3c <generic_tracepoint_event+0xc3c>
     b84:      	b	0x1400 <generic_tracepoint_event+0x1400>
     b88:      	cmp	w25, #0x1d
     b8c:      	b.le	0xcb0 <generic_tracepoint_event+0xcb0>
     b90:      	cmp	w25, #0x25
     b94:      	b.gt	0xdb8 <generic_tracepoint_event+0xdb8>
     b98:      	cmp	w25, #0x1e
     b9c:      	b.eq	0x11f4 <generic_tracepoint_event+0x11f4>
     ba0:      	cmp	w25, #0x1f
     ba4:      	b.eq	0x10a4 <generic_tracepoint_event+0x10a4>
     ba8:      	cmp	w25, #0x20
     bac:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     bb0:      	mov	w8, #0x1                // =1
     bb4:      	mov	w9, #0x4                // =4
     bb8:      	add	x10, sp, #0x88
     bbc:      	add	x0, sp, #0x88
     bc0:      	mov	w1, #0x1                // =1
     bc4:      	blr	x9
     bc8:      	cbz	x0, 0x1378 <generic_tracepoint_event+0x1378>
     bcc:      	neg	w8, w0
     bd0:      	adrp	x22, 0x0 <generic_tracepoint_event>
     bd4:      	mov	w9, #0x1                // =1
     bd8:      	strh	w8, [sp, #0x38]
     bdc:      	mov	w8, #0x7                // =7
     be0:      	add	x1, sp, #0x38
     be4:      	mov	w24, #0x1               // =1
     be8:      	strh	w8, [sp, #0x3a]
     bec:      	mov	x8, #0x73               // =115
     bf0:      	movk	x8, #0x4, lsl #32
     bf4:      	stur	x8, [sp, #0x3c]
     bf8:      	add	x8, sp, #0x38
     bfc:      	ldr	x22, [x22]
     c00:      	mov	x0, x22
     c04:      	blr	x9
     c08:      	cbz	x0, 0x1354 <generic_tracepoint_event+0x1354>
     c0c:      	ldr	w8, [x0]
     c10:      	add	w8, w8, #0x1
     c14:      	str	w8, [x0]
     c18:      	ldrb	w24, [sp, #0x88]
     c1c:      	b	0x1400 <generic_tracepoint_event+0x1400>
     c20:      	cmn	w25, #0xc
     c24:      	b.le	0xe44 <generic_tracepoint_event+0xe44>
     c28:      	add	w8, w25, #0xb
     c2c:      	cmp	w8, #0x2
     c30:      	b.lo	0xd4c <generic_tracepoint_event+0xd4c>
     c34:      	cmp	w25, #0x2
     c38:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     c3c:      	mov	w8, #0x8                // =8
     c40:      	mov	w9, #0x4                // =4
     c44:      	add	x10, sp, #0x20
     c48:      	add	x0, sp, #0x20
     c4c:      	mov	w1, #0x8                // =8
     c50:      	blr	x9
     c54:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
     c58:      	neg	w8, w0
     c5c:      	adrp	x22, 0x0 <generic_tracepoint_event>
     c60:      	mov	w9, #0x1                // =1
     c64:      	strh	w8, [sp, #0x38]
     c68:      	mov	w8, #0x7                // =7
     c6c:      	add	x1, sp, #0x38
     c70:      	mov	w24, #0x1               // =1
     c74:      	strh	w8, [sp, #0x3a]
     c78:      	mov	x8, #0x81               // =129
     c7c:      	movk	x8, #0x4, lsl #32
     c80:      	stur	x8, [sp, #0x3c]
     c84:      	add	x8, sp, #0x38
     c88:      	ldr	x22, [x22]
     c8c:      	mov	x0, x22
     c90:      	blr	x9
     c94:      	cbnz	x0, 0x11e4 <generic_tracepoint_event+0x11e4>
     c98:      	str	w24, [sp, #0x88]
     c9c:      	mov	x3, xzr
     ca0:      	mov	w8, #0x2                // =2
     ca4:      	add	x9, sp, #0x38
     ca8:      	add	x10, sp, #0x88
     cac:      	b	0x1394 <generic_tracepoint_event+0x1394>
     cb0:      	cmp	w25, #0x11
     cb4:      	b.le	0xe58 <generic_tracepoint_event+0xe58>
     cb8:      	cmp	w25, #0x12
     cbc:      	b.eq	0x1028 <generic_tracepoint_event+0x1028>
     cc0:      	cmp	w25, #0x1c
     cc4:      	b.eq	0xd4c <generic_tracepoint_event+0xd4c>
     cc8:      	cmp	w25, #0x1d
     ccc:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     cd0:      	mov	w8, #0x2                // =2
     cd4:      	mov	w9, #0x4                // =4
     cd8:      	add	x10, sp, #0x88
     cdc:      	add	x0, sp, #0x88
     ce0:      	mov	w1, #0x2                // =2
     ce4:      	blr	x9
     ce8:      	cbz	x0, 0x1320 <generic_tracepoint_event+0x1320>
     cec:      	neg	w8, w0
     cf0:      	adrp	x22, 0x0 <generic_tracepoint_event>
     cf4:      	mov	w9, #0x1                // =1
     cf8:      	strh	w8, [sp, #0x38]
     cfc:      	mov	w8, #0x7                // =7
     d00:      	add	x1, sp, #0x38
     d04:      	mov	w24, #0x1               // =1
     d08:      	strh	w8, [sp, #0x3a]
     d0c:      	mov	x8, #0x6c               // =108
     d10:      	movk	x8, #0x4, lsl #32
     d14:      	stur	x8, [sp, #0x3c]
     d18:      	add	x8, sp, #0x38
     d1c:      	ldr	x22, [x22]
     d20:      	mov	x0, x22
     d24:      	blr	x9
     d28:      	cbz	x0, 0x12fc <generic_tracepoint_event+0x12fc>
     d2c:      	ldr	w8, [x0]
     d30:      	add	w8, w8, #0x1
     d34:      	str	w8, [x0]
     d38:      	ldrsh	x24, [sp, #0x88]
     d3c:      	b	0x1400 <generic_tracepoint_event+0x1400>
     d40:      	sub	w8, w25, #0xa
     d44:      	cmp	w8, #0x2
     d48:      	b.hs	0xfac <generic_tracepoint_event+0xfac>
     d4c:      	mov	w8, #0x8                // =8
     d50:      	mov	w9, #0x4                // =4
     d54:      	add	x10, sp, #0x20
     d58:      	add	x0, sp, #0x20
     d5c:      	mov	w1, #0x8                // =8
     d60:      	blr	x9
     d64:      	cbz	x0, 0xf68 <generic_tracepoint_event+0xf68>
     d68:      	neg	w8, w0
     d6c:      	adrp	x22, 0x0 <generic_tracepoint_event>
     d70:      	mov	w9, #0x1                // =1
     d74:      	strh	w8, [sp, #0x38]
     d78:      	mov	w8, #0x7                // =7
     d7c:      	add	x1, sp, #0x38
     d80:      	mov	w24, #0x1               // =1
     d84:      	strh	w8, [sp, #0x3a]
     d88:      	mov	x8, #0x45               // =69
     d8c:      	movk	x8, #0x4, lsl #32
     d90:      	stur	x8, [sp, #0x3c]
     d94:      	add	x8, sp, #0x38
     d98:      	ldr	x22, [x22]
     d9c:      	mov	x0, x22
     da0:      	blr	x9
     da4:      	cbz	x0, 0xf44 <generic_tracepoint_event+0xf44>
     da8:      	ldr	w8, [x0]
     dac:      	add	w8, w8, #0x1
     db0:      	str	w8, [x0]
     db4:      	b	0xf68 <generic_tracepoint_event+0xf68>
     db8:      	cmp	w25, #0x26
     dbc:      	b.eq	0x1264 <generic_tracepoint_event+0x1264>
     dc0:      	cmp	w25, #0x28
     dc4:      	b.eq	0x1114 <generic_tracepoint_event+0x1114>
     dc8:      	cmp	w25, #0x29
     dcc:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     dd0:      	mov	w8, #0x8                // =8
     dd4:      	mov	w9, #0x4                // =4
     dd8:      	add	x10, sp, #0x20
     ddc:      	add	x0, sp, #0x20
     de0:      	mov	w1, #0x8                // =8
     de4:      	blr	x9
     de8:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
     dec:      	neg	w8, w0
     df0:      	adrp	x22, 0x0 <generic_tracepoint_event>
     df4:      	mov	w9, #0x1                // =1
     df8:      	strh	w8, [sp, #0x38]
     dfc:      	mov	w8, #0x7                // =7
     e00:      	add	x1, sp, #0x38
     e04:      	mov	w24, #0x1               // =1
     e08:      	strh	w8, [sp, #0x3a]
     e0c:      	mov	x8, #0xa8               // =168
     e10:      	movk	x8, #0x4, lsl #32
     e14:      	stur	x8, [sp, #0x3c]
     e18:      	add	x8, sp, #0x38
     e1c:      	ldr	x22, [x22]
     e20:      	mov	x0, x22
     e24:      	blr	x9
     e28:      	cbnz	x0, 0x11e4 <generic_tracepoint_event+0x11e4>
     e2c:      	str	w24, [sp, #0x88]
     e30:      	mov	x3, xzr
     e34:      	mov	w8, #0x2                // =2
     e38:      	add	x9, sp, #0x38
     e3c:      	add	x10, sp, #0x88
     e40:      	b	0x1394 <generic_tracepoint_event+0x1394>
     e44:      	cmn	w25, #0xd
     e48:      	b.eq	0xed8 <generic_tracepoint_event+0xed8>
     e4c:      	cmn	w25, #0xc
     e50:      	b.eq	0xe68 <generic_tracepoint_event+0xe68>
     e54:      	b	0x1400 <generic_tracepoint_event+0x1400>
     e58:      	cmp	w25, #0xc
     e5c:      	b.eq	0xed8 <generic_tracepoint_event+0xed8>
     e60:      	cmp	w25, #0xd
     e64:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     e68:      	mov	w8, #0x4                // =4
     e6c:      	add	x9, sp, #0x88
     e70:      	add	x0, sp, #0x88
     e74:      	mov	w1, #0x4                // =4
     e78:      	blr	x8
     e7c:      	cbz	x0, 0x13fc <generic_tracepoint_event+0x13fc>
     e80:      	neg	w8, w0
     e84:      	adrp	x22, 0x0 <generic_tracepoint_event>
     e88:      	mov	w9, #0x1                // =1
     e8c:      	strh	w8, [sp, #0x38]
     e90:      	mov	w8, #0x7                // =7
     e94:      	add	x1, sp, #0x38
     e98:      	mov	w24, #0x1               // =1
     e9c:      	strh	w8, [sp, #0x3a]
     ea0:      	mov	x8, #0x5e               // =94
     ea4:      	movk	x8, #0x4, lsl #32
     ea8:      	stur	x8, [sp, #0x3c]
     eac:      	add	x8, sp, #0x38
     eb0:      	ldr	x22, [x22]
     eb4:      	mov	x0, x22
     eb8:      	blr	x9
     ebc:      	cbnz	x0, 0x12bc <generic_tracepoint_event+0x12bc>
     ec0:      	str	w24, [sp, #0x20]
     ec4:      	mov	x3, xzr
     ec8:      	mov	w8, #0x2                // =2
     ecc:      	add	x9, sp, #0x38
     ed0:      	add	x10, sp, #0x20
     ed4:      	b	0x13ec <generic_tracepoint_event+0x13ec>
     ed8:      	mov	w8, #0x4                // =4
     edc:      	add	x9, sp, #0x88
     ee0:      	add	x0, sp, #0x88
     ee4:      	mov	w1, #0x4                // =4
     ee8:      	blr	x8
     eec:      	cbz	x0, 0x12f4 <generic_tracepoint_event+0x12f4>
     ef0:      	neg	w8, w0
     ef4:      	adrp	x22, 0x0 <generic_tracepoint_event>
     ef8:      	mov	w9, #0x1                // =1
     efc:      	strh	w8, [sp, #0x38]
     f00:      	mov	w8, #0x7                // =7
     f04:      	add	x1, sp, #0x38
     f08:      	mov	w24, #0x1               // =1
     f0c:      	strh	w8, [sp, #0x3a]
     f10:      	mov	x8, #0x56               // =86
     f14:      	movk	x8, #0x4, lsl #32
     f18:      	stur	x8, [sp, #0x3c]
     f1c:      	add	x8, sp, #0x38
     f20:      	ldr	x22, [x22]
     f24:      	mov	x0, x22
     f28:      	blr	x9
     f2c:      	cbz	x0, 0x12d0 <generic_tracepoint_event+0x12d0>
     f30:      	ldr	w8, [x0]
     f34:      	add	w8, w8, #0x1
     f38:      	str	w8, [x0]
     f3c:      	ldrsw	x24, [sp, #0x88]
     f40:      	b	0x1400 <generic_tracepoint_event+0x1400>
     f44:      	str	w24, [sp, #0x88]
     f48:      	mov	x3, xzr
     f4c:      	mov	w8, #0x2                // =2
     f50:      	add	x9, sp, #0x38
     f54:      	add	x10, sp, #0x88
     f58:      	add	x1, sp, #0x38
     f5c:      	add	x2, sp, #0x88
     f60:      	mov	x0, x22
     f64:      	blr	x8
     f68:      	ldr	x24, [sp, #0x20]
     f6c:      	cmp	w25, #0x1c
     f70:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     f74:      	mov	w8, #0x23               // =35
     f78:      	blr	x8
     f7c:      	mov	w8, #0x8                // =8
     f80:      	mov	w9, #0x4                // =4
     f84:      	add	x10, sp, #0x38
     f88:      	mov	x2, x0
     f8c:      	add	x0, sp, #0x38
     f90:      	mov	w1, #0x8                // =8
     f94:      	blr	x9
     f98:      	ldr	w8, [sp, #0x38]
     f9c:      	lsl	w8, w8, #9
     fa0:      	and	x8, x8, #0x80000000
     fa4:      	orr	x24, x8, x24
     fa8:      	b	0x1400 <generic_tracepoint_event+0x1400>
     fac:      	cmp	w25, #0x7
     fb0:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     fb4:      	mov	w8, #0x8                // =8
     fb8:      	mov	w9, #0x4                // =4
     fbc:      	add	x10, sp, #0x20
     fc0:      	add	x0, sp, #0x20
     fc4:      	mov	w1, #0x8                // =8
     fc8:      	blr	x9
     fcc:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
     fd0:      	neg	w8, w0
     fd4:      	adrp	x22, 0x0 <generic_tracepoint_event>
     fd8:      	mov	w9, #0x1                // =1
     fdc:      	strh	w8, [sp, #0x38]
     fe0:      	mov	w8, #0x7                // =7
     fe4:      	add	x1, sp, #0x38
     fe8:      	mov	w24, #0x1               // =1
     fec:      	strh	w8, [sp, #0x3a]
     ff0:      	mov	x8, #0x9a               // =154
     ff4:      	movk	x8, #0x4, lsl #32
     ff8:      	stur	x8, [sp, #0x3c]
     ffc:      	add	x8, sp, #0x38
    1000:      	ldr	x22, [x22]
    1004:      	mov	x0, x22
    1008:      	blr	x9
    100c:      	cbnz	x0, 0x11e4 <generic_tracepoint_event+0x11e4>
    1010:      	str	w24, [sp, #0x88]
    1014:      	mov	x3, xzr
    1018:      	mov	w8, #0x2                // =2
    101c:      	add	x9, sp, #0x38
    1020:      	add	x10, sp, #0x88
    1024:      	b	0x1394 <generic_tracepoint_event+0x1394>
    1028:      	mov	x24, x2
    102c:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1030:      	mov	w8, #0x8                // =8
    1034:      	mov	w9, #0x4                // =4
    1038:      	add	x10, sp, #0x20
    103c:      	add	x0, sp, #0x20
    1040:      	mov	w1, #0x8                // =8
    1044:      	blr	x9
    1048:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
    104c:      	neg	w8, w0
    1050:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1054:      	mov	w9, #0x1                // =1
    1058:      	strh	w8, [sp, #0x38]
    105c:      	mov	w8, #0x7                // =7
    1060:      	add	x1, sp, #0x38
    1064:      	mov	w24, #0x1               // =1
    1068:      	strh	w8, [sp, #0x3a]
    106c:      	mov	x8, #0x93               // =147
    1070:      	movk	x8, #0x4, lsl #32
    1074:      	stur	x8, [sp, #0x3c]
    1078:      	add	x8, sp, #0x38
    107c:      	ldr	x22, [x22]
    1080:      	mov	x0, x22
    1084:      	blr	x9
    1088:      	cbnz	x0, 0x11e4 <generic_tracepoint_event+0x11e4>
    108c:      	str	w24, [sp, #0x88]
    1090:      	mov	x3, xzr
    1094:      	mov	w8, #0x2                // =2
    1098:      	add	x9, sp, #0x38
    109c:      	add	x10, sp, #0x88
    10a0:      	b	0x1394 <generic_tracepoint_event+0x1394>
    10a4:      	mov	w8, #0x1                // =1
    10a8:      	mov	w9, #0x4                // =4
    10ac:      	add	x10, sp, #0x88
    10b0:      	add	x0, sp, #0x88
    10b4:      	mov	w1, #0x1                // =1
    10b8:      	blr	x9
    10bc:      	cbz	x0, 0x134c <generic_tracepoint_event+0x134c>
    10c0:      	neg	w8, w0
    10c4:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    10c8:      	mov	w9, #0x1                // =1
    10cc:      	strh	w8, [sp, #0x38]
    10d0:      	mov	w8, #0x7                // =7
    10d4:      	add	x1, sp, #0x38
    10d8:      	mov	w24, #0x1               // =1
    10dc:      	strh	w8, [sp, #0x3a]
    10e0:      	mov	x8, #0x7a               // =122
    10e4:      	movk	x8, #0x4, lsl #32
    10e8:      	stur	x8, [sp, #0x3c]
    10ec:      	add	x8, sp, #0x38
    10f0:      	ldr	x22, [x22]
    10f4:      	mov	x0, x22
    10f8:      	blr	x9
    10fc:      	cbz	x0, 0x1328 <generic_tracepoint_event+0x1328>
    1100:      	ldr	w8, [x0]
    1104:      	add	w8, w8, #0x1
    1108:      	str	w8, [x0]
    110c:      	ldrsb	x24, [sp, #0x88]
    1110:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1114:      	mov	w8, #0x8                // =8
    1118:      	mov	w9, #0x4                // =4
    111c:      	add	x10, sp, #0x20
    1120:      	add	x0, sp, #0x20
    1124:      	mov	w1, #0x8                // =8
    1128:      	blr	x9
    112c:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
    1130:      	neg	w8, w0
    1134:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1138:      	mov	w9, #0x1                // =1
    113c:      	strh	w8, [sp, #0x38]
    1140:      	mov	w8, #0x7                // =7
    1144:      	add	x1, sp, #0x38
    1148:      	mov	w24, #0x1               // =1
    114c:      	strh	w8, [sp, #0x3a]
    1150:      	mov	x8, #0xa1               // =161
    1154:      	movk	x8, #0x4, lsl #32
    1158:      	stur	x8, [sp, #0x3c]
    115c:      	add	x8, sp, #0x38
    1160:      	ldr	x22, [x22]
    1164:      	mov	x0, x22
    1168:      	blr	x9
    116c:      	cbnz	x0, 0x11e4 <generic_tracepoint_event+0x11e4>
    1170:      	str	w24, [sp, #0x88]
    1174:      	mov	x3, xzr
    1178:      	mov	w8, #0x2                // =2
    117c:      	add	x9, sp, #0x38
    1180:      	add	x10, sp, #0x88
    1184:      	b	0x1394 <generic_tracepoint_event+0x1394>
    1188:      	mov	w8, #0x8                // =8
    118c:      	mov	w9, #0x4                // =4
    1190:      	add	x10, sp, #0x20
    1194:      	add	x0, sp, #0x20
    1198:      	mov	w1, #0x8                // =8
    119c:      	blr	x9
    11a0:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
    11a4:      	neg	w8, w0
    11a8:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    11ac:      	mov	w9, #0x1                // =1
    11b0:      	strh	w8, [sp, #0x38]
    11b4:      	mov	w8, #0x7                // =7
    11b8:      	add	x1, sp, #0x38
    11bc:      	mov	w24, #0x1               // =1
    11c0:      	strh	w8, [sp, #0x3a]
    11c4:      	mov	x8, #0x4e               // =78
    11c8:      	movk	x8, #0x4, lsl #32
    11cc:      	stur	x8, [sp, #0x3c]
    11d0:      	add	x8, sp, #0x38
    11d4:      	ldr	x22, [x22]
    11d8:      	mov	x0, x22
    11dc:      	blr	x9
    11e0:      	cbz	x0, 0x1380 <generic_tracepoint_event+0x1380>
    11e4:      	ldr	w8, [x0]
    11e8:      	add	w8, w8, #0x1
    11ec:      	str	w8, [x0]
    11f0:      	b	0x13a4 <generic_tracepoint_event+0x13a4>
    11f4:      	mov	w8, #0x2                // =2
    11f8:      	mov	w9, #0x4                // =4
    11fc:      	add	x10, sp, #0x88
    1200:      	add	x0, sp, #0x88
    1204:      	mov	w1, #0x2                // =2
    1208:      	blr	x9
    120c:      	cbz	x0, 0x13d0 <generic_tracepoint_event+0x13d0>
    1210:      	neg	w8, w0
    1214:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1218:      	mov	w9, #0x1                // =1
    121c:      	strh	w8, [sp, #0x38]
    1220:      	mov	w8, #0x7                // =7
    1224:      	add	x1, sp, #0x38
    1228:      	mov	w24, #0x1               // =1
    122c:      	strh	w8, [sp, #0x3a]
    1230:      	mov	x8, #0x65               // =101
    1234:      	movk	x8, #0x4, lsl #32
    1238:      	stur	x8, [sp, #0x3c]
    123c:      	add	x8, sp, #0x38
    1240:      	ldr	x22, [x22]
    1244:      	mov	x0, x22
    1248:      	blr	x9
    124c:      	cbz	x0, 0x13ac <generic_tracepoint_event+0x13ac>
    1250:      	ldr	w8, [x0]
    1254:      	add	w8, w8, #0x1
    1258:      	str	w8, [x0]
    125c:      	ldrh	w24, [sp, #0x88]
    1260:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1264:      	mov	w8, #0x4                // =4
    1268:      	add	x9, sp, #0x88
    126c:      	add	x0, sp, #0x88
    1270:      	mov	w1, #0x4                // =4
    1274:      	blr	x8
    1278:      	cbz	x0, 0x13fc <generic_tracepoint_event+0x13fc>
    127c:      	neg	w8, w0
    1280:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1284:      	mov	w9, #0x1                // =1
    1288:      	strh	w8, [sp, #0x38]
    128c:      	mov	w8, #0x7                // =7
    1290:      	add	x1, sp, #0x38
    1294:      	mov	w24, #0x1               // =1
    1298:      	strh	w8, [sp, #0x3a]
    129c:      	mov	x8, #0x88               // =136
    12a0:      	movk	x8, #0x4, lsl #32
    12a4:      	stur	x8, [sp, #0x3c]
    12a8:      	add	x8, sp, #0x38
    12ac:      	ldr	x22, [x22]
    12b0:      	mov	x0, x22
    12b4:      	blr	x9
    12b8:      	cbz	x0, 0x13d8 <generic_tracepoint_event+0x13d8>
    12bc:      	ldr	w8, [x0]
    12c0:      	add	w8, w8, #0x1
    12c4:      	str	w8, [x0]
    12c8:      	ldr	w24, [sp, #0x88]
    12cc:      	b	0x1400 <generic_tracepoint_event+0x1400>
    12d0:      	str	w24, [sp, #0x20]
    12d4:      	mov	x3, xzr
    12d8:      	mov	w8, #0x2                // =2
    12dc:      	add	x9, sp, #0x38
    12e0:      	add	x10, sp, #0x20
    12e4:      	add	x1, sp, #0x38
    12e8:      	add	x2, sp, #0x20
    12ec:      	mov	x0, x22
    12f0:      	blr	x8
    12f4:      	ldrsw	x24, [sp, #0x88]
    12f8:      	b	0x1400 <generic_tracepoint_event+0x1400>
    12fc:      	str	w24, [sp, #0x20]
    1300:      	mov	x3, xzr
    1304:      	mov	w8, #0x2                // =2
    1308:      	add	x9, sp, #0x38
    130c:      	add	x10, sp, #0x20
    1310:      	add	x1, sp, #0x38
    1314:      	add	x2, sp, #0x20
    1318:      	mov	x0, x22
    131c:      	blr	x8
    1320:      	ldrsh	x24, [sp, #0x88]
    1324:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1328:      	str	w24, [sp, #0x20]
    132c:      	mov	x3, xzr
    1330:      	mov	w8, #0x2                // =2
    1334:      	add	x9, sp, #0x38
    1338:      	add	x10, sp, #0x20
    133c:      	add	x1, sp, #0x38
    1340:      	add	x2, sp, #0x20
    1344:      	mov	x0, x22
    1348:      	blr	x8
    134c:      	ldrsb	x24, [sp, #0x88]
    1350:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1354:      	str	w24, [sp, #0x20]
    1358:      	mov	x3, xzr
    135c:      	mov	w8, #0x2                // =2
    1360:      	add	x9, sp, #0x38
    1364:      	add	x10, sp, #0x20
    1368:      	add	x1, sp, #0x38
    136c:      	add	x2, sp, #0x20
    1370:      	mov	x0, x22
    1374:      	blr	x8
    1378:      	ldrb	w24, [sp, #0x88]
    137c:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1380:      	str	w24, [sp, #0x88]
    1384:      	mov	x3, xzr
    1388:      	mov	w8, #0x2                // =2
    138c:      	add	x9, sp, #0x38
    1390:      	add	x10, sp, #0x88
    1394:      	add	x1, sp, #0x38
    1398:      	add	x2, sp, #0x88
    139c:      	mov	x0, x22
    13a0:      	blr	x8
    13a4:      	ldr	x24, [sp, #0x20]
    13a8:      	b	0x1400 <generic_tracepoint_event+0x1400>
    13ac:      	str	w24, [sp, #0x20]
    13b0:      	mov	x3, xzr
    13b4:      	mov	w8, #0x2                // =2
    13b8:      	add	x9, sp, #0x38
    13bc:      	add	x10, sp, #0x20
    13c0:      	add	x1, sp, #0x38
    13c4:      	add	x2, sp, #0x20
    13c8:      	mov	x0, x22
    13cc:      	blr	x8
    13d0:      	ldrh	w24, [sp, #0x88]
    13d4:      	b	0x1400 <generic_tracepoint_event+0x1400>
    13d8:      	str	w24, [sp, #0x20]
    13dc:      	mov	x3, xzr
    13e0:      	mov	w8, #0x2                // =2
    13e4:      	add	x9, sp, #0x38
    13e8:      	add	x10, sp, #0x20
    13ec:      	add	x1, sp, #0x38
    13f0:      	add	x2, sp, #0x20
    13f4:      	mov	x0, x22
    13f8:      	blr	x8
    13fc:      	ldr	w24, [sp, #0x88]
    1400:      	str	x24, [x20, #0x5e58]
    1404:      	mov	x22, xzr
    1408:      	ldrh	w8, [x21, #0x34]
    140c:      	ldr	w24, [x21, #0xc]
    1410:      	add	x2, x19, x8
    1414:      	cmp	w24, #0xb
    1418:      	b.gt	0x1448 <generic_tracepoint_event+0x1448>
    141c:      	cmp	w24, #0x3
    1420:      	b.le	0x14e0 <generic_tracepoint_event+0x14e0>
    1424:      	cmp	w24, #0x6
    1428:      	b.gt	0x1600 <generic_tracepoint_event+0x1600>
    142c:      	cmp	w24, #0x4
    1430:      	b.eq	0x1a48 <generic_tracepoint_event+0x1a48>
    1434:      	cmp	w24, #0x5
    1438:      	b.eq	0x18f0 <generic_tracepoint_event+0x18f0>
    143c:      	cmp	w24, #0x6
    1440:      	b.eq	0x14fc <generic_tracepoint_event+0x14fc>
    1444:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1448:      	cmp	w24, #0x1d
    144c:      	b.le	0x1570 <generic_tracepoint_event+0x1570>
    1450:      	cmp	w24, #0x25
    1454:      	b.gt	0x1678 <generic_tracepoint_event+0x1678>
    1458:      	cmp	w24, #0x1e
    145c:      	b.eq	0x1ab4 <generic_tracepoint_event+0x1ab4>
    1460:      	cmp	w24, #0x1f
    1464:      	b.eq	0x1964 <generic_tracepoint_event+0x1964>
    1468:      	cmp	w24, #0x20
    146c:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1470:      	mov	w8, #0x1                // =1
    1474:      	mov	w9, #0x4                // =4
    1478:      	add	x10, sp, #0x88
    147c:      	add	x0, sp, #0x88
    1480:      	mov	w1, #0x1                // =1
    1484:      	blr	x9
    1488:      	cbz	x0, 0x1c38 <generic_tracepoint_event+0x1c38>
    148c:      	neg	w8, w0
    1490:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1494:      	mov	w9, #0x1                // =1
    1498:      	strh	w8, [sp, #0x38]
    149c:      	mov	w8, #0x7                // =7
    14a0:      	add	x1, sp, #0x38
    14a4:      	mov	w24, #0x1               // =1
    14a8:      	strh	w8, [sp, #0x3a]
    14ac:      	mov	x8, #0x73               // =115
    14b0:      	movk	x8, #0x4, lsl #32
    14b4:      	stur	x8, [sp, #0x3c]
    14b8:      	add	x8, sp, #0x38
    14bc:      	ldr	x22, [x22]
    14c0:      	mov	x0, x22
    14c4:      	blr	x9
    14c8:      	cbz	x0, 0x1c14 <generic_tracepoint_event+0x1c14>
    14cc:      	ldr	w8, [x0]
    14d0:      	add	w8, w8, #0x1
    14d4:      	str	w8, [x0]
    14d8:      	ldrb	w22, [sp, #0x88]
    14dc:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    14e0:      	cmn	w24, #0xc
    14e4:      	b.le	0x1704 <generic_tracepoint_event+0x1704>
    14e8:      	add	w8, w24, #0xb
    14ec:      	cmp	w8, #0x2
    14f0:      	b.lo	0x160c <generic_tracepoint_event+0x160c>
    14f4:      	cmp	w24, #0x2
    14f8:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    14fc:      	mov	w8, #0x8                // =8
    1500:      	mov	w9, #0x4                // =4
    1504:      	add	x10, sp, #0x20
    1508:      	add	x0, sp, #0x20
    150c:      	mov	w1, #0x8                // =8
    1510:      	blr	x9
    1514:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    1518:      	neg	w8, w0
    151c:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1520:      	mov	w9, #0x1                // =1
    1524:      	strh	w8, [sp, #0x38]
    1528:      	mov	w8, #0x7                // =7
    152c:      	add	x1, sp, #0x38
    1530:      	mov	w24, #0x1               // =1
    1534:      	strh	w8, [sp, #0x3a]
    1538:      	mov	x8, #0x81               // =129
    153c:      	movk	x8, #0x4, lsl #32
    1540:      	stur	x8, [sp, #0x3c]
    1544:      	add	x8, sp, #0x38
    1548:      	ldr	x22, [x22]
    154c:      	mov	x0, x22
    1550:      	blr	x9
    1554:      	cbnz	x0, 0x1aa4 <generic_tracepoint_event+0x1aa4>
    1558:      	str	w24, [sp, #0x88]
    155c:      	mov	x3, xzr
    1560:      	mov	w8, #0x2                // =2
    1564:      	add	x9, sp, #0x38
    1568:      	add	x10, sp, #0x88
    156c:      	b	0x1c54 <generic_tracepoint_event+0x1c54>
    1570:      	cmp	w24, #0x11
    1574:      	b.le	0x1718 <generic_tracepoint_event+0x1718>
    1578:      	cmp	w24, #0x12
    157c:      	b.eq	0x18e8 <generic_tracepoint_event+0x18e8>
    1580:      	cmp	w24, #0x1c
    1584:      	b.eq	0x160c <generic_tracepoint_event+0x160c>
    1588:      	cmp	w24, #0x1d
    158c:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1590:      	mov	w8, #0x2                // =2
    1594:      	mov	w9, #0x4                // =4
    1598:      	add	x10, sp, #0x88
    159c:      	add	x0, sp, #0x88
    15a0:      	mov	w1, #0x2                // =2
    15a4:      	blr	x9
    15a8:      	cbz	x0, 0x1be0 <generic_tracepoint_event+0x1be0>
    15ac:      	neg	w8, w0
    15b0:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    15b4:      	mov	w9, #0x1                // =1
    15b8:      	strh	w8, [sp, #0x38]
    15bc:      	mov	w8, #0x7                // =7
    15c0:      	add	x1, sp, #0x38
    15c4:      	mov	w24, #0x1               // =1
    15c8:      	strh	w8, [sp, #0x3a]
    15cc:      	mov	x8, #0x6c               // =108
    15d0:      	movk	x8, #0x4, lsl #32
    15d4:      	stur	x8, [sp, #0x3c]
    15d8:      	add	x8, sp, #0x38
    15dc:      	ldr	x22, [x22]
    15e0:      	mov	x0, x22
    15e4:      	blr	x9
    15e8:      	cbz	x0, 0x1bbc <generic_tracepoint_event+0x1bbc>
    15ec:      	ldr	w8, [x0]
    15f0:      	add	w8, w8, #0x1
    15f4:      	str	w8, [x0]
    15f8:      	ldrsh	x22, [sp, #0x88]
    15fc:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1600:      	sub	w8, w24, #0xa
    1604:      	cmp	w8, #0x2
    1608:      	b.hs	0x186c <generic_tracepoint_event+0x186c>
    160c:      	mov	w8, #0x8                // =8
    1610:      	mov	w9, #0x4                // =4
    1614:      	add	x10, sp, #0x20
    1618:      	add	x0, sp, #0x20
    161c:      	mov	w1, #0x8                // =8
    1620:      	blr	x9
    1624:      	cbz	x0, 0x1828 <generic_tracepoint_event+0x1828>
    1628:      	neg	w8, w0
    162c:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1630:      	mov	w9, #0x1                // =1
    1634:      	strh	w8, [sp, #0x38]
    1638:      	mov	w8, #0x7                // =7
    163c:      	add	x1, sp, #0x38
    1640:      	mov	w25, #0x1               // =1
    1644:      	strh	w8, [sp, #0x3a]
    1648:      	mov	x8, #0x45               // =69
    164c:      	movk	x8, #0x4, lsl #32
    1650:      	stur	x8, [sp, #0x3c]
    1654:      	add	x8, sp, #0x38
    1658:      	ldr	x22, [x22]
    165c:      	mov	x0, x22
    1660:      	blr	x9
    1664:      	cbz	x0, 0x1804 <generic_tracepoint_event+0x1804>
    1668:      	ldr	w8, [x0]
    166c:      	add	w8, w8, #0x1
    1670:      	str	w8, [x0]
    1674:      	b	0x1828 <generic_tracepoint_event+0x1828>
    1678:      	cmp	w24, #0x26
    167c:      	b.eq	0x1b24 <generic_tracepoint_event+0x1b24>
    1680:      	cmp	w24, #0x28
    1684:      	b.eq	0x19d4 <generic_tracepoint_event+0x19d4>
    1688:      	cmp	w24, #0x29
    168c:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1690:      	mov	w8, #0x8                // =8
    1694:      	mov	w9, #0x4                // =4
    1698:      	add	x10, sp, #0x20
    169c:      	add	x0, sp, #0x20
    16a0:      	mov	w1, #0x8                // =8
    16a4:      	blr	x9
    16a8:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    16ac:      	neg	w8, w0
    16b0:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    16b4:      	mov	w9, #0x1                // =1
    16b8:      	strh	w8, [sp, #0x38]
    16bc:      	mov	w8, #0x7                // =7
    16c0:      	add	x1, sp, #0x38
    16c4:      	mov	w24, #0x1               // =1
    16c8:      	strh	w8, [sp, #0x3a]
    16cc:      	mov	x8, #0xa8               // =168
    16d0:      	movk	x8, #0x4, lsl #32
    16d4:      	stur	x8, [sp, #0x3c]
    16d8:      	add	x8, sp, #0x38
    16dc:      	ldr	x22, [x22]
    16e0:      	mov	x0, x22
    16e4:      	blr	x9
    16e8:      	cbnz	x0, 0x1aa4 <generic_tracepoint_event+0x1aa4>
    16ec:      	str	w24, [sp, #0x88]
    16f0:      	mov	x3, xzr
    16f4:      	mov	w8, #0x2                // =2
    16f8:      	add	x9, sp, #0x38
    16fc:      	add	x10, sp, #0x88
    1700:      	b	0x1c54 <generic_tracepoint_event+0x1c54>
    1704:      	cmn	w24, #0xd
    1708:      	b.eq	0x1798 <generic_tracepoint_event+0x1798>
    170c:      	cmn	w24, #0xc
    1710:      	b.eq	0x1728 <generic_tracepoint_event+0x1728>
    1714:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1718:      	cmp	w24, #0xc
    171c:      	b.eq	0x1798 <generic_tracepoint_event+0x1798>
    1720:      	cmp	w24, #0xd
    1724:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1728:      	mov	w8, #0x4                // =4
    172c:      	add	x9, sp, #0x88
    1730:      	add	x0, sp, #0x88
    1734:      	mov	w1, #0x4                // =4
    1738:      	blr	x8
    173c:      	cbz	x0, 0x1cbc <generic_tracepoint_event+0x1cbc>
    1740:      	neg	w8, w0
    1744:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1748:      	mov	w9, #0x1                // =1
    174c:      	strh	w8, [sp, #0x38]
    1750:      	mov	w8, #0x7                // =7
    1754:      	add	x1, sp, #0x38
    1758:      	mov	w24, #0x1               // =1
    175c:      	strh	w8, [sp, #0x3a]
    1760:      	mov	x8, #0x5e               // =94
    1764:      	movk	x8, #0x4, lsl #32
    1768:      	stur	x8, [sp, #0x3c]
    176c:      	add	x8, sp, #0x38
    1770:      	ldr	x22, [x22]
    1774:      	mov	x0, x22
    1778:      	blr	x9
    177c:      	cbnz	x0, 0x1b7c <generic_tracepoint_event+0x1b7c>
    1780:      	str	w24, [sp, #0x20]
    1784:      	mov	x3, xzr
    1788:      	mov	w8, #0x2                // =2
    178c:      	add	x9, sp, #0x38
    1790:      	add	x10, sp, #0x20
    1794:      	b	0x1cac <generic_tracepoint_event+0x1cac>
    1798:      	mov	w8, #0x4                // =4
    179c:      	add	x9, sp, #0x88
    17a0:      	add	x0, sp, #0x88
    17a4:      	mov	w1, #0x4                // =4
    17a8:      	blr	x8
    17ac:      	cbz	x0, 0x1bb4 <generic_tracepoint_event+0x1bb4>
    17b0:      	neg	w8, w0
    17b4:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    17b8:      	mov	w9, #0x1                // =1
    17bc:      	strh	w8, [sp, #0x38]
    17c0:      	mov	w8, #0x7                // =7
    17c4:      	add	x1, sp, #0x38
    17c8:      	mov	w24, #0x1               // =1
    17cc:      	strh	w8, [sp, #0x3a]
    17d0:      	mov	x8, #0x56               // =86
    17d4:      	movk	x8, #0x4, lsl #32
    17d8:      	stur	x8, [sp, #0x3c]
    17dc:      	add	x8, sp, #0x38
    17e0:      	ldr	x22, [x22]
    17e4:      	mov	x0, x22
    17e8:      	blr	x9
    17ec:      	cbz	x0, 0x1b90 <generic_tracepoint_event+0x1b90>
    17f0:      	ldr	w8, [x0]
    17f4:      	add	w8, w8, #0x1
    17f8:      	str	w8, [x0]
    17fc:      	ldrsw	x22, [sp, #0x88]
    1800:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1804:      	str	w25, [sp, #0x88]
    1808:      	mov	x3, xzr
    180c:      	mov	w8, #0x2                // =2
    1810:      	add	x9, sp, #0x38
    1814:      	add	x10, sp, #0x88
    1818:      	add	x1, sp, #0x38
    181c:      	add	x2, sp, #0x88
    1820:      	mov	x0, x22
    1824:      	blr	x8
    1828:      	ldr	x22, [sp, #0x20]
    182c:      	cmp	w24, #0x1c
    1830:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1834:      	mov	w8, #0x23               // =35
    1838:      	blr	x8
    183c:      	mov	w8, #0x8                // =8
    1840:      	mov	w9, #0x4                // =4
    1844:      	add	x10, sp, #0x38
    1848:      	mov	x2, x0
    184c:      	add	x0, sp, #0x38
    1850:      	mov	w1, #0x8                // =8
    1854:      	blr	x9
    1858:      	ldr	w8, [sp, #0x38]
    185c:      	lsl	w8, w8, #9
    1860:      	and	x8, x8, #0x80000000
    1864:      	orr	x22, x8, x22
    1868:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    186c:      	cmp	w24, #0x7
    1870:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1874:      	mov	w8, #0x8                // =8
    1878:      	mov	w9, #0x4                // =4
    187c:      	add	x10, sp, #0x20
    1880:      	add	x0, sp, #0x20
    1884:      	mov	w1, #0x8                // =8
    1888:      	blr	x9
    188c:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    1890:      	neg	w8, w0
    1894:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1898:      	mov	w9, #0x1                // =1
    189c:      	strh	w8, [sp, #0x38]
    18a0:      	mov	w8, #0x7                // =7
    18a4:      	add	x1, sp, #0x38
    18a8:      	mov	w24, #0x1               // =1
    18ac:      	strh	w8, [sp, #0x3a]
    18b0:      	mov	x8, #0x9a               // =154
    18b4:      	movk	x8, #0x4, lsl #32
    18b8:      	stur	x8, [sp, #0x3c]
    18bc:      	add	x8, sp, #0x38
    18c0:      	ldr	x22, [x22]
    18c4:      	mov	x0, x22
    18c8:      	blr	x9
    18cc:      	cbnz	x0, 0x1aa4 <generic_tracepoint_event+0x1aa4>
    18d0:      	str	w24, [sp, #0x88]
    18d4:      	mov	x3, xzr
    18d8:      	mov	w8, #0x2                // =2
    18dc:      	add	x9, sp, #0x38
    18e0:      	add	x10, sp, #0x88
    18e4:      	b	0x1c54 <generic_tracepoint_event+0x1c54>
    18e8:      	mov	x22, x2
    18ec:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    18f0:      	mov	w8, #0x8                // =8
    18f4:      	mov	w9, #0x4                // =4
    18f8:      	add	x10, sp, #0x20
    18fc:      	add	x0, sp, #0x20
    1900:      	mov	w1, #0x8                // =8
    1904:      	blr	x9
    1908:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    190c:      	neg	w8, w0
    1910:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1914:      	mov	w9, #0x1                // =1
    1918:      	strh	w8, [sp, #0x38]
    191c:      	mov	w8, #0x7                // =7
    1920:      	add	x1, sp, #0x38
    1924:      	mov	w24, #0x1               // =1
    1928:      	strh	w8, [sp, #0x3a]
    192c:      	mov	x8, #0x93               // =147
    1930:      	movk	x8, #0x4, lsl #32
    1934:      	stur	x8, [sp, #0x3c]
    1938:      	add	x8, sp, #0x38
    193c:      	ldr	x22, [x22]
    1940:      	mov	x0, x22
    1944:      	blr	x9
    1948:      	cbnz	x0, 0x1aa4 <generic_tracepoint_event+0x1aa4>
    194c:      	str	w24, [sp, #0x88]
    1950:      	mov	x3, xzr
    1954:      	mov	w8, #0x2                // =2
    1958:      	add	x9, sp, #0x38
    195c:      	add	x10, sp, #0x88
    1960:      	b	0x1c54 <generic_tracepoint_event+0x1c54>
    1964:      	mov	w8, #0x1                // =1
    1968:      	mov	w9, #0x4                // =4
    196c:      	add	x10, sp, #0x88
    1970:      	add	x0, sp, #0x88
    1974:      	mov	w1, #0x1                // =1
    1978:      	blr	x9
    197c:      	cbz	x0, 0x1c0c <generic_tracepoint_event+0x1c0c>
    1980:      	neg	w8, w0
    1984:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1988:      	mov	w9, #0x1                // =1
    198c:      	strh	w8, [sp, #0x38]
    1990:      	mov	w8, #0x7                // =7
    1994:      	add	x1, sp, #0x38
    1998:      	mov	w24, #0x1               // =1
    199c:      	strh	w8, [sp, #0x3a]
    19a0:      	mov	x8, #0x7a               // =122
    19a4:      	movk	x8, #0x4, lsl #32
    19a8:      	stur	x8, [sp, #0x3c]
    19ac:      	add	x8, sp, #0x38
    19b0:      	ldr	x22, [x22]
    19b4:      	mov	x0, x22
    19b8:      	blr	x9
    19bc:      	cbz	x0, 0x1be8 <generic_tracepoint_event+0x1be8>
    19c0:      	ldr	w8, [x0]
    19c4:      	add	w8, w8, #0x1
    19c8:      	str	w8, [x0]
    19cc:      	ldrsb	x22, [sp, #0x88]
    19d0:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    19d4:      	mov	w8, #0x8                // =8
    19d8:      	mov	w9, #0x4                // =4
    19dc:      	add	x10, sp, #0x20
    19e0:      	add	x0, sp, #0x20
    19e4:      	mov	w1, #0x8                // =8
    19e8:      	blr	x9
    19ec:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    19f0:      	neg	w8, w0
    19f4:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    19f8:      	mov	w9, #0x1                // =1
    19fc:      	strh	w8, [sp, #0x38]
    1a00:      	mov	w8, #0x7                // =7
    1a04:      	add	x1, sp, #0x38
    1a08:      	mov	w24, #0x1               // =1
    1a0c:      	strh	w8, [sp, #0x3a]
    1a10:      	mov	x8, #0xa1               // =161
    1a14:      	movk	x8, #0x4, lsl #32
    1a18:      	stur	x8, [sp, #0x3c]
    1a1c:      	add	x8, sp, #0x38
    1a20:      	ldr	x22, [x22]
    1a24:      	mov	x0, x22
    1a28:      	blr	x9
    1a2c:      	cbnz	x0, 0x1aa4 <generic_tracepoint_event+0x1aa4>
    1a30:      	str	w24, [sp, #0x88]
    1a34:      	mov	x3, xzr
    1a38:      	mov	w8, #0x2                // =2
    1a3c:      	add	x9, sp, #0x38
    1a40:      	add	x10, sp, #0x88
    1a44:      	b	0x1c54 <generic_tracepoint_event+0x1c54>
    1a48:      	mov	w8, #0x8                // =8
    1a4c:      	mov	w9, #0x4                // =4
    1a50:      	add	x10, sp, #0x20
    1a54:      	add	x0, sp, #0x20
    1a58:      	mov	w1, #0x8                // =8
    1a5c:      	blr	x9
    1a60:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    1a64:      	neg	w8, w0
    1a68:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1a6c:      	mov	w9, #0x1                // =1
    1a70:      	strh	w8, [sp, #0x38]
    1a74:      	mov	w8, #0x7                // =7
    1a78:      	add	x1, sp, #0x38
    1a7c:      	mov	w24, #0x1               // =1
    1a80:      	strh	w8, [sp, #0x3a]
    1a84:      	mov	x8, #0x4e               // =78
    1a88:      	movk	x8, #0x4, lsl #32
    1a8c:      	stur	x8, [sp, #0x3c]
    1a90:      	add	x8, sp, #0x38
    1a94:      	ldr	x22, [x22]
    1a98:      	mov	x0, x22
    1a9c:      	blr	x9
    1aa0:      	cbz	x0, 0x1c40 <generic_tracepoint_event+0x1c40>
    1aa4:      	ldr	w8, [x0]
    1aa8:      	add	w8, w8, #0x1
    1aac:      	str	w8, [x0]
    1ab0:      	b	0x1c64 <generic_tracepoint_event+0x1c64>
    1ab4:      	mov	w8, #0x2                // =2
    1ab8:      	mov	w9, #0x4                // =4
    1abc:      	add	x10, sp, #0x88
    1ac0:      	add	x0, sp, #0x88
    1ac4:      	mov	w1, #0x2                // =2
    1ac8:      	blr	x9
    1acc:      	cbz	x0, 0x1c90 <generic_tracepoint_event+0x1c90>
    1ad0:      	neg	w8, w0
    1ad4:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1ad8:      	mov	w9, #0x1                // =1
    1adc:      	strh	w8, [sp, #0x38]
    1ae0:      	mov	w8, #0x7                // =7
    1ae4:      	add	x1, sp, #0x38
    1ae8:      	mov	w24, #0x1               // =1
    1aec:      	strh	w8, [sp, #0x3a]
    1af0:      	mov	x8, #0x65               // =101
    1af4:      	movk	x8, #0x4, lsl #32
    1af8:      	stur	x8, [sp, #0x3c]
    1afc:      	add	x8, sp, #0x38
    1b00:      	ldr	x22, [x22]
    1b04:      	mov	x0, x22
    1b08:      	blr	x9
    1b0c:      	cbz	x0, 0x1c6c <generic_tracepoint_event+0x1c6c>
    1b10:      	ldr	w8, [x0]
    1b14:      	add	w8, w8, #0x1
    1b18:      	str	w8, [x0]
    1b1c:      	ldrh	w22, [sp, #0x88]
    1b20:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1b24:      	mov	w8, #0x4                // =4
    1b28:      	add	x9, sp, #0x88
    1b2c:      	add	x0, sp, #0x88
    1b30:      	mov	w1, #0x4                // =4
    1b34:      	blr	x8
    1b38:      	cbz	x0, 0x1cbc <generic_tracepoint_event+0x1cbc>
    1b3c:      	neg	w8, w0
    1b40:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1b44:      	mov	w9, #0x1                // =1
    1b48:      	strh	w8, [sp, #0x38]
    1b4c:      	mov	w8, #0x7                // =7
    1b50:      	add	x1, sp, #0x38
    1b54:      	mov	w24, #0x1               // =1
    1b58:      	strh	w8, [sp, #0x3a]
    1b5c:      	mov	x8, #0x88               // =136
    1b60:      	movk	x8, #0x4, lsl #32
    1b64:      	stur	x8, [sp, #0x3c]
    1b68:      	add	x8, sp, #0x38
    1b6c:      	ldr	x22, [x22]
    1b70:      	mov	x0, x22
    1b74:      	blr	x9
    1b78:      	cbz	x0, 0x1c98 <generic_tracepoint_event+0x1c98>
    1b7c:      	ldr	w8, [x0]
    1b80:      	add	w8, w8, #0x1
    1b84:      	str	w8, [x0]
    1b88:      	ldr	w22, [sp, #0x88]
    1b8c:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1b90:      	str	w24, [sp, #0x20]
    1b94:      	mov	x3, xzr
    1b98:      	mov	w8, #0x2                // =2
    1b9c:      	add	x9, sp, #0x38
    1ba0:      	add	x10, sp, #0x20
    1ba4:      	add	x1, sp, #0x38
    1ba8:      	add	x2, sp, #0x20
    1bac:      	mov	x0, x22
    1bb0:      	blr	x8
    1bb4:      	ldrsw	x22, [sp, #0x88]
    1bb8:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1bbc:      	str	w24, [sp, #0x20]
    1bc0:      	mov	x3, xzr
    1bc4:      	mov	w8, #0x2                // =2
    1bc8:      	add	x9, sp, #0x38
    1bcc:      	add	x10, sp, #0x20
    1bd0:      	add	x1, sp, #0x38
    1bd4:      	add	x2, sp, #0x20
    1bd8:      	mov	x0, x22
    1bdc:      	blr	x8
    1be0:      	ldrsh	x22, [sp, #0x88]
    1be4:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1be8:      	str	w24, [sp, #0x20]
    1bec:      	mov	x3, xzr
    1bf0:      	mov	w8, #0x2                // =2
    1bf4:      	add	x9, sp, #0x38
    1bf8:      	add	x10, sp, #0x20
    1bfc:      	add	x1, sp, #0x38
    1c00:      	add	x2, sp, #0x20
    1c04:      	mov	x0, x22
    1c08:      	blr	x8
    1c0c:      	ldrsb	x22, [sp, #0x88]
    1c10:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1c14:      	str	w24, [sp, #0x20]
    1c18:      	mov	x3, xzr
    1c1c:      	mov	w8, #0x2                // =2
    1c20:      	add	x9, sp, #0x38
    1c24:      	add	x10, sp, #0x20
    1c28:      	add	x1, sp, #0x38
    1c2c:      	add	x2, sp, #0x20
    1c30:      	mov	x0, x22
    1c34:      	blr	x8
    1c38:      	ldrb	w22, [sp, #0x88]
    1c3c:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1c40:      	str	w24, [sp, #0x88]
    1c44:      	mov	x3, xzr
    1c48:      	mov	w8, #0x2                // =2
    1c4c:      	add	x9, sp, #0x38
    1c50:      	add	x10, sp, #0x88
    1c54:      	add	x1, sp, #0x38
    1c58:      	add	x2, sp, #0x88
    1c5c:      	mov	x0, x22
    1c60:      	blr	x8
    1c64:      	ldr	x22, [sp, #0x20]
    1c68:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1c6c:      	str	w24, [sp, #0x20]
    1c70:      	mov	x3, xzr
    1c74:      	mov	w8, #0x2                // =2
    1c78:      	add	x9, sp, #0x38
    1c7c:      	add	x10, sp, #0x20
    1c80:      	add	x1, sp, #0x38
    1c84:      	add	x2, sp, #0x20
    1c88:      	mov	x0, x22
    1c8c:      	blr	x8
    1c90:      	ldrh	w22, [sp, #0x88]
    1c94:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1c98:      	str	w24, [sp, #0x20]
    1c9c:      	mov	x3, xzr
    1ca0:      	mov	w8, #0x2                // =2
    1ca4:      	add	x9, sp, #0x38
    1ca8:      	add	x10, sp, #0x20
    1cac:      	add	x1, sp, #0x38
    1cb0:      	add	x2, sp, #0x20
    1cb4:      	mov	x0, x22
    1cb8:      	blr	x8
    1cbc:      	ldr	w22, [sp, #0x88]
    1cc0:      	str	x22, [x20, #0x5e60]
    1cc4:      	mov	x24, xzr
    1cc8:      	ldrh	w8, [x21, #0x38]
    1ccc:      	ldr	w25, [x21, #0x10]
    1cd0:      	add	x2, x19, x8
    1cd4:      	cmp	w25, #0xb
    1cd8:      	b.gt	0x1d08 <generic_tracepoint_event+0x1d08>
    1cdc:      	cmp	w25, #0x3
    1ce0:      	b.le	0x1da0 <generic_tracepoint_event+0x1da0>
    1ce4:      	cmp	w25, #0x6
    1ce8:      	b.gt	0x1ec0 <generic_tracepoint_event+0x1ec0>
    1cec:      	cmp	w25, #0x4
    1cf0:      	b.eq	0x2308 <generic_tracepoint_event+0x2308>
    1cf4:      	cmp	w25, #0x5
    1cf8:      	b.eq	0x21b0 <generic_tracepoint_event+0x21b0>
    1cfc:      	cmp	w25, #0x6
    1d00:      	b.eq	0x1dbc <generic_tracepoint_event+0x1dbc>
    1d04:      	b	0x2580 <generic_tracepoint_event+0x2580>
    1d08:      	cmp	w25, #0x1d
    1d0c:      	b.le	0x1e30 <generic_tracepoint_event+0x1e30>
    1d10:      	cmp	w25, #0x25
    1d14:      	b.gt	0x1f38 <generic_tracepoint_event+0x1f38>
    1d18:      	cmp	w25, #0x1e
    1d1c:      	b.eq	0x2374 <generic_tracepoint_event+0x2374>
    1d20:      	cmp	w25, #0x1f
    1d24:      	b.eq	0x2224 <generic_tracepoint_event+0x2224>
    1d28:      	cmp	w25, #0x20
    1d2c:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    1d30:      	mov	w8, #0x1                // =1
    1d34:      	mov	w9, #0x4                // =4
    1d38:      	add	x10, sp, #0x88
    1d3c:      	add	x0, sp, #0x88
    1d40:      	mov	w1, #0x1                // =1
    1d44:      	blr	x9
    1d48:      	cbz	x0, 0x24f8 <generic_tracepoint_event+0x24f8>
    1d4c:      	neg	w8, w0
    1d50:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1d54:      	mov	w9, #0x1                // =1
    1d58:      	strh	w8, [sp, #0x38]
    1d5c:      	mov	w8, #0x7                // =7
    1d60:      	add	x1, sp, #0x38
    1d64:      	mov	w24, #0x1               // =1
    1d68:      	strh	w8, [sp, #0x3a]
    1d6c:      	mov	x8, #0x73               // =115
    1d70:      	movk	x8, #0x4, lsl #32
    1d74:      	stur	x8, [sp, #0x3c]
    1d78:      	add	x8, sp, #0x38
    1d7c:      	ldr	x22, [x22]
    1d80:      	mov	x0, x22
    1d84:      	blr	x9
    1d88:      	cbz	x0, 0x24d4 <generic_tracepoint_event+0x24d4>
    1d8c:      	ldr	w8, [x0]
    1d90:      	add	w8, w8, #0x1
    1d94:      	str	w8, [x0]
    1d98:      	ldrb	w24, [sp, #0x88]
    1d9c:      	b	0x2580 <generic_tracepoint_event+0x2580>
    1da0:      	cmn	w25, #0xc
    1da4:      	b.le	0x1fc4 <generic_tracepoint_event+0x1fc4>
    1da8:      	add	w8, w25, #0xb
    1dac:      	cmp	w8, #0x2
    1db0:      	b.lo	0x1ecc <generic_tracepoint_event+0x1ecc>
    1db4:      	cmp	w25, #0x2
    1db8:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    1dbc:      	mov	w8, #0x8                // =8
    1dc0:      	mov	w9, #0x4                // =4
    1dc4:      	add	x10, sp, #0x20
    1dc8:      	add	x0, sp, #0x20
    1dcc:      	mov	w1, #0x8                // =8
    1dd0:      	blr	x9
    1dd4:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    1dd8:      	neg	w8, w0
    1ddc:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1de0:      	mov	w9, #0x1                // =1
    1de4:      	strh	w8, [sp, #0x38]
    1de8:      	mov	w8, #0x7                // =7
    1dec:      	add	x1, sp, #0x38
    1df0:      	mov	w24, #0x1               // =1
    1df4:      	strh	w8, [sp, #0x3a]
    1df8:      	mov	x8, #0x81               // =129
    1dfc:      	movk	x8, #0x4, lsl #32
    1e00:      	stur	x8, [sp, #0x3c]
    1e04:      	add	x8, sp, #0x38
    1e08:      	ldr	x22, [x22]
    1e0c:      	mov	x0, x22
    1e10:      	blr	x9
    1e14:      	cbnz	x0, 0x2364 <generic_tracepoint_event+0x2364>
    1e18:      	str	w24, [sp, #0x88]
    1e1c:      	mov	x3, xzr
    1e20:      	mov	w8, #0x2                // =2
    1e24:      	add	x9, sp, #0x38
    1e28:      	add	x10, sp, #0x88
    1e2c:      	b	0x2514 <generic_tracepoint_event+0x2514>
    1e30:      	cmp	w25, #0x11
    1e34:      	b.le	0x1fd8 <generic_tracepoint_event+0x1fd8>
    1e38:      	cmp	w25, #0x12
    1e3c:      	b.eq	0x21a8 <generic_tracepoint_event+0x21a8>
    1e40:      	cmp	w25, #0x1c
    1e44:      	b.eq	0x1ecc <generic_tracepoint_event+0x1ecc>
    1e48:      	cmp	w25, #0x1d
    1e4c:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    1e50:      	mov	w8, #0x2                // =2
    1e54:      	mov	w9, #0x4                // =4
    1e58:      	add	x10, sp, #0x88
    1e5c:      	add	x0, sp, #0x88
    1e60:      	mov	w1, #0x2                // =2
    1e64:      	blr	x9
    1e68:      	cbz	x0, 0x24a0 <generic_tracepoint_event+0x24a0>
    1e6c:      	neg	w8, w0
    1e70:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1e74:      	mov	w9, #0x1                // =1
    1e78:      	strh	w8, [sp, #0x38]
    1e7c:      	mov	w8, #0x7                // =7
    1e80:      	add	x1, sp, #0x38
    1e84:      	mov	w24, #0x1               // =1
    1e88:      	strh	w8, [sp, #0x3a]
    1e8c:      	mov	x8, #0x6c               // =108
    1e90:      	movk	x8, #0x4, lsl #32
    1e94:      	stur	x8, [sp, #0x3c]
    1e98:      	add	x8, sp, #0x38
    1e9c:      	ldr	x22, [x22]
    1ea0:      	mov	x0, x22
    1ea4:      	blr	x9
    1ea8:      	cbz	x0, 0x247c <generic_tracepoint_event+0x247c>
    1eac:      	ldr	w8, [x0]
    1eb0:      	add	w8, w8, #0x1
    1eb4:      	str	w8, [x0]
    1eb8:      	ldrsh	x24, [sp, #0x88]
    1ebc:      	b	0x2580 <generic_tracepoint_event+0x2580>
    1ec0:      	sub	w8, w25, #0xa
    1ec4:      	cmp	w8, #0x2
    1ec8:      	b.hs	0x212c <generic_tracepoint_event+0x212c>
    1ecc:      	mov	w8, #0x8                // =8
    1ed0:      	mov	w9, #0x4                // =4
    1ed4:      	add	x10, sp, #0x20
    1ed8:      	add	x0, sp, #0x20
    1edc:      	mov	w1, #0x8                // =8
    1ee0:      	blr	x9
    1ee4:      	cbz	x0, 0x20e8 <generic_tracepoint_event+0x20e8>
    1ee8:      	neg	w8, w0
    1eec:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1ef0:      	mov	w9, #0x1                // =1
    1ef4:      	strh	w8, [sp, #0x38]
    1ef8:      	mov	w8, #0x7                // =7
    1efc:      	add	x1, sp, #0x38
    1f00:      	mov	w24, #0x1               // =1
    1f04:      	strh	w8, [sp, #0x3a]
    1f08:      	mov	x8, #0x45               // =69
    1f0c:      	movk	x8, #0x4, lsl #32
    1f10:      	stur	x8, [sp, #0x3c]
    1f14:      	add	x8, sp, #0x38
    1f18:      	ldr	x22, [x22]
    1f1c:      	mov	x0, x22
    1f20:      	blr	x9
    1f24:      	cbz	x0, 0x20c4 <generic_tracepoint_event+0x20c4>
    1f28:      	ldr	w8, [x0]
    1f2c:      	add	w8, w8, #0x1
    1f30:      	str	w8, [x0]
    1f34:      	b	0x20e8 <generic_tracepoint_event+0x20e8>
    1f38:      	cmp	w25, #0x26
    1f3c:      	b.eq	0x23e4 <generic_tracepoint_event+0x23e4>
    1f40:      	cmp	w25, #0x28
    1f44:      	b.eq	0x2294 <generic_tracepoint_event+0x2294>
    1f48:      	cmp	w25, #0x29
    1f4c:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    1f50:      	mov	w8, #0x8                // =8
    1f54:      	mov	w9, #0x4                // =4
    1f58:      	add	x10, sp, #0x20
    1f5c:      	add	x0, sp, #0x20
    1f60:      	mov	w1, #0x8                // =8
    1f64:      	blr	x9
    1f68:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    1f6c:      	neg	w8, w0
    1f70:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1f74:      	mov	w9, #0x1                // =1
    1f78:      	strh	w8, [sp, #0x38]
    1f7c:      	mov	w8, #0x7                // =7
    1f80:      	add	x1, sp, #0x38
    1f84:      	mov	w24, #0x1               // =1
    1f88:      	strh	w8, [sp, #0x3a]
    1f8c:      	mov	x8, #0xa8               // =168
    1f90:      	movk	x8, #0x4, lsl #32
    1f94:      	stur	x8, [sp, #0x3c]
    1f98:      	add	x8, sp, #0x38
    1f9c:      	ldr	x22, [x22]
    1fa0:      	mov	x0, x22
    1fa4:      	blr	x9
    1fa8:      	cbnz	x0, 0x2364 <generic_tracepoint_event+0x2364>
    1fac:      	str	w24, [sp, #0x88]
    1fb0:      	mov	x3, xzr
    1fb4:      	mov	w8, #0x2                // =2
    1fb8:      	add	x9, sp, #0x38
    1fbc:      	add	x10, sp, #0x88
    1fc0:      	b	0x2514 <generic_tracepoint_event+0x2514>
    1fc4:      	cmn	w25, #0xd
    1fc8:      	b.eq	0x2058 <generic_tracepoint_event+0x2058>
    1fcc:      	cmn	w25, #0xc
    1fd0:      	b.eq	0x1fe8 <generic_tracepoint_event+0x1fe8>
    1fd4:      	b	0x2580 <generic_tracepoint_event+0x2580>
    1fd8:      	cmp	w25, #0xc
    1fdc:      	b.eq	0x2058 <generic_tracepoint_event+0x2058>
    1fe0:      	cmp	w25, #0xd
    1fe4:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    1fe8:      	mov	w8, #0x4                // =4
    1fec:      	add	x9, sp, #0x88
    1ff0:      	add	x0, sp, #0x88
    1ff4:      	mov	w1, #0x4                // =4
    1ff8:      	blr	x8
    1ffc:      	cbz	x0, 0x257c <generic_tracepoint_event+0x257c>
    2000:      	neg	w8, w0
    2004:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2008:      	mov	w9, #0x1                // =1
    200c:      	strh	w8, [sp, #0x38]
    2010:      	mov	w8, #0x7                // =7
    2014:      	add	x1, sp, #0x38
    2018:      	mov	w24, #0x1               // =1
    201c:      	strh	w8, [sp, #0x3a]
    2020:      	mov	x8, #0x5e               // =94
    2024:      	movk	x8, #0x4, lsl #32
    2028:      	stur	x8, [sp, #0x3c]
    202c:      	add	x8, sp, #0x38
    2030:      	ldr	x22, [x22]
    2034:      	mov	x0, x22
    2038:      	blr	x9
    203c:      	cbnz	x0, 0x243c <generic_tracepoint_event+0x243c>
    2040:      	str	w24, [sp, #0x20]
    2044:      	mov	x3, xzr
    2048:      	mov	w8, #0x2                // =2
    204c:      	add	x9, sp, #0x38
    2050:      	add	x10, sp, #0x20
    2054:      	b	0x256c <generic_tracepoint_event+0x256c>
    2058:      	mov	w8, #0x4                // =4
    205c:      	add	x9, sp, #0x88
    2060:      	add	x0, sp, #0x88
    2064:      	mov	w1, #0x4                // =4
    2068:      	blr	x8
    206c:      	cbz	x0, 0x2474 <generic_tracepoint_event+0x2474>
    2070:      	neg	w8, w0
    2074:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2078:      	mov	w9, #0x1                // =1
    207c:      	strh	w8, [sp, #0x38]
    2080:      	mov	w8, #0x7                // =7
    2084:      	add	x1, sp, #0x38
    2088:      	mov	w24, #0x1               // =1
    208c:      	strh	w8, [sp, #0x3a]
    2090:      	mov	x8, #0x56               // =86
    2094:      	movk	x8, #0x4, lsl #32
    2098:      	stur	x8, [sp, #0x3c]
    209c:      	add	x8, sp, #0x38
    20a0:      	ldr	x22, [x22]
    20a4:      	mov	x0, x22
    20a8:      	blr	x9
    20ac:      	cbz	x0, 0x2450 <generic_tracepoint_event+0x2450>
    20b0:      	ldr	w8, [x0]
    20b4:      	add	w8, w8, #0x1
    20b8:      	str	w8, [x0]
    20bc:      	ldrsw	x24, [sp, #0x88]
    20c0:      	b	0x2580 <generic_tracepoint_event+0x2580>
    20c4:      	str	w24, [sp, #0x88]
    20c8:      	mov	x3, xzr
    20cc:      	mov	w8, #0x2                // =2
    20d0:      	add	x9, sp, #0x38
    20d4:      	add	x10, sp, #0x88
    20d8:      	add	x1, sp, #0x38
    20dc:      	add	x2, sp, #0x88
    20e0:      	mov	x0, x22
    20e4:      	blr	x8
    20e8:      	ldr	x24, [sp, #0x20]
    20ec:      	cmp	w25, #0x1c
    20f0:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    20f4:      	mov	w8, #0x23               // =35
    20f8:      	blr	x8
    20fc:      	mov	w8, #0x8                // =8
    2100:      	mov	w9, #0x4                // =4
    2104:      	add	x10, sp, #0x38
    2108:      	mov	x2, x0
    210c:      	add	x0, sp, #0x38
    2110:      	mov	w1, #0x8                // =8
    2114:      	blr	x9
    2118:      	ldr	w8, [sp, #0x38]
    211c:      	lsl	w8, w8, #9
    2120:      	and	x8, x8, #0x80000000
    2124:      	orr	x24, x8, x24
    2128:      	b	0x2580 <generic_tracepoint_event+0x2580>
    212c:      	cmp	w25, #0x7
    2130:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    2134:      	mov	w8, #0x8                // =8
    2138:      	mov	w9, #0x4                // =4
    213c:      	add	x10, sp, #0x20
    2140:      	add	x0, sp, #0x20
    2144:      	mov	w1, #0x8                // =8
    2148:      	blr	x9
    214c:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    2150:      	neg	w8, w0
    2154:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2158:      	mov	w9, #0x1                // =1
    215c:      	strh	w8, [sp, #0x38]
    2160:      	mov	w8, #0x7                // =7
    2164:      	add	x1, sp, #0x38
    2168:      	mov	w24, #0x1               // =1
    216c:      	strh	w8, [sp, #0x3a]
    2170:      	mov	x8, #0x9a               // =154
    2174:      	movk	x8, #0x4, lsl #32
    2178:      	stur	x8, [sp, #0x3c]
    217c:      	add	x8, sp, #0x38
    2180:      	ldr	x22, [x22]
    2184:      	mov	x0, x22
    2188:      	blr	x9
    218c:      	cbnz	x0, 0x2364 <generic_tracepoint_event+0x2364>
    2190:      	str	w24, [sp, #0x88]
    2194:      	mov	x3, xzr
    2198:      	mov	w8, #0x2                // =2
    219c:      	add	x9, sp, #0x38
    21a0:      	add	x10, sp, #0x88
    21a4:      	b	0x2514 <generic_tracepoint_event+0x2514>
    21a8:      	mov	x24, x2
    21ac:      	b	0x2580 <generic_tracepoint_event+0x2580>
    21b0:      	mov	w8, #0x8                // =8
    21b4:      	mov	w9, #0x4                // =4
    21b8:      	add	x10, sp, #0x20
    21bc:      	add	x0, sp, #0x20
    21c0:      	mov	w1, #0x8                // =8
    21c4:      	blr	x9
    21c8:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    21cc:      	neg	w8, w0
    21d0:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    21d4:      	mov	w9, #0x1                // =1
    21d8:      	strh	w8, [sp, #0x38]
    21dc:      	mov	w8, #0x7                // =7
    21e0:      	add	x1, sp, #0x38
    21e4:      	mov	w24, #0x1               // =1
    21e8:      	strh	w8, [sp, #0x3a]
    21ec:      	mov	x8, #0x93               // =147
    21f0:      	movk	x8, #0x4, lsl #32
    21f4:      	stur	x8, [sp, #0x3c]
    21f8:      	add	x8, sp, #0x38
    21fc:      	ldr	x22, [x22]
    2200:      	mov	x0, x22
    2204:      	blr	x9
    2208:      	cbnz	x0, 0x2364 <generic_tracepoint_event+0x2364>
    220c:      	str	w24, [sp, #0x88]
    2210:      	mov	x3, xzr
    2214:      	mov	w8, #0x2                // =2
    2218:      	add	x9, sp, #0x38
    221c:      	add	x10, sp, #0x88
    2220:      	b	0x2514 <generic_tracepoint_event+0x2514>
    2224:      	mov	w8, #0x1                // =1
    2228:      	mov	w9, #0x4                // =4
    222c:      	add	x10, sp, #0x88
    2230:      	add	x0, sp, #0x88
    2234:      	mov	w1, #0x1                // =1
    2238:      	blr	x9
    223c:      	cbz	x0, 0x24cc <generic_tracepoint_event+0x24cc>
    2240:      	neg	w8, w0
    2244:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2248:      	mov	w9, #0x1                // =1
    224c:      	strh	w8, [sp, #0x38]
    2250:      	mov	w8, #0x7                // =7
    2254:      	add	x1, sp, #0x38
    2258:      	mov	w24, #0x1               // =1
    225c:      	strh	w8, [sp, #0x3a]
    2260:      	mov	x8, #0x7a               // =122
    2264:      	movk	x8, #0x4, lsl #32
    2268:      	stur	x8, [sp, #0x3c]
    226c:      	add	x8, sp, #0x38
    2270:      	ldr	x22, [x22]
    2274:      	mov	x0, x22
    2278:      	blr	x9
    227c:      	cbz	x0, 0x24a8 <generic_tracepoint_event+0x24a8>
    2280:      	ldr	w8, [x0]
    2284:      	add	w8, w8, #0x1
    2288:      	str	w8, [x0]
    228c:      	ldrsb	x24, [sp, #0x88]
    2290:      	b	0x2580 <generic_tracepoint_event+0x2580>
    2294:      	mov	w8, #0x8                // =8
    2298:      	mov	w9, #0x4                // =4
    229c:      	add	x10, sp, #0x20
    22a0:      	add	x0, sp, #0x20
    22a4:      	mov	w1, #0x8                // =8
    22a8:      	blr	x9
    22ac:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    22b0:      	neg	w8, w0
    22b4:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    22b8:      	mov	w9, #0x1                // =1
    22bc:      	strh	w8, [sp, #0x38]
    22c0:      	mov	w8, #0x7                // =7
    22c4:      	add	x1, sp, #0x38
    22c8:      	mov	w24, #0x1               // =1
    22cc:      	strh	w8, [sp, #0x3a]
    22d0:      	mov	x8, #0xa1               // =161
    22d4:      	movk	x8, #0x4, lsl #32
    22d8:      	stur	x8, [sp, #0x3c]
    22dc:      	add	x8, sp, #0x38
    22e0:      	ldr	x22, [x22]
    22e4:      	mov	x0, x22
    22e8:      	blr	x9
    22ec:      	cbnz	x0, 0x2364 <generic_tracepoint_event+0x2364>
    22f0:      	str	w24, [sp, #0x88]
    22f4:      	mov	x3, xzr
    22f8:      	mov	w8, #0x2                // =2
    22fc:      	add	x9, sp, #0x38
    2300:      	add	x10, sp, #0x88
    2304:      	b	0x2514 <generic_tracepoint_event+0x2514>
    2308:      	mov	w8, #0x8                // =8
    230c:      	mov	w9, #0x4                // =4
    2310:      	add	x10, sp, #0x20
    2314:      	add	x0, sp, #0x20
    2318:      	mov	w1, #0x8                // =8
    231c:      	blr	x9
    2320:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    2324:      	neg	w8, w0
    2328:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    232c:      	mov	w9, #0x1                // =1
    2330:      	strh	w8, [sp, #0x38]
    2334:      	mov	w8, #0x7                // =7
    2338:      	add	x1, sp, #0x38
    233c:      	mov	w24, #0x1               // =1
    2340:      	strh	w8, [sp, #0x3a]
    2344:      	mov	x8, #0x4e               // =78
    2348:      	movk	x8, #0x4, lsl #32
    234c:      	stur	x8, [sp, #0x3c]
    2350:      	add	x8, sp, #0x38
    2354:      	ldr	x22, [x22]
    2358:      	mov	x0, x22
    235c:      	blr	x9
    2360:      	cbz	x0, 0x2500 <generic_tracepoint_event+0x2500>
    2364:      	ldr	w8, [x0]
    2368:      	add	w8, w8, #0x1
    236c:      	str	w8, [x0]
    2370:      	b	0x2524 <generic_tracepoint_event+0x2524>
    2374:      	mov	w8, #0x2                // =2
    2378:      	mov	w9, #0x4                // =4
    237c:      	add	x10, sp, #0x88
    2380:      	add	x0, sp, #0x88
    2384:      	mov	w1, #0x2                // =2
    2388:      	blr	x9
    238c:      	cbz	x0, 0x2550 <generic_tracepoint_event+0x2550>
    2390:      	neg	w8, w0
    2394:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2398:      	mov	w9, #0x1                // =1
    239c:      	strh	w8, [sp, #0x38]
    23a0:      	mov	w8, #0x7                // =7
    23a4:      	add	x1, sp, #0x38
    23a8:      	mov	w24, #0x1               // =1
    23ac:      	strh	w8, [sp, #0x3a]
    23b0:      	mov	x8, #0x65               // =101
    23b4:      	movk	x8, #0x4, lsl #32
    23b8:      	stur	x8, [sp, #0x3c]
    23bc:      	add	x8, sp, #0x38
    23c0:      	ldr	x22, [x22]
    23c4:      	mov	x0, x22
    23c8:      	blr	x9
    23cc:      	cbz	x0, 0x252c <generic_tracepoint_event+0x252c>
    23d0:      	ldr	w8, [x0]
    23d4:      	add	w8, w8, #0x1
    23d8:      	str	w8, [x0]
    23dc:      	ldrh	w24, [sp, #0x88]
    23e0:      	b	0x2580 <generic_tracepoint_event+0x2580>
    23e4:      	mov	w8, #0x4                // =4
    23e8:      	add	x9, sp, #0x88
    23ec:      	add	x0, sp, #0x88
    23f0:      	mov	w1, #0x4                // =4
    23f4:      	blr	x8
    23f8:      	cbz	x0, 0x257c <generic_tracepoint_event+0x257c>
    23fc:      	neg	w8, w0
    2400:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2404:      	mov	w9, #0x1                // =1
    2408:      	strh	w8, [sp, #0x38]
    240c:      	mov	w8, #0x7                // =7
    2410:      	add	x1, sp, #0x38
    2414:      	mov	w24, #0x1               // =1
    2418:      	strh	w8, [sp, #0x3a]
    241c:      	mov	x8, #0x88               // =136
    2420:      	movk	x8, #0x4, lsl #32
    2424:      	stur	x8, [sp, #0x3c]
    2428:      	add	x8, sp, #0x38
    242c:      	ldr	x22, [x22]
    2430:      	mov	x0, x22
    2434:      	blr	x9
    2438:      	cbz	x0, 0x2558 <generic_tracepoint_event+0x2558>
    243c:      	ldr	w8, [x0]
    2440:      	add	w8, w8, #0x1
    2444:      	str	w8, [x0]
    2448:      	ldr	w24, [sp, #0x88]
    244c:      	b	0x2580 <generic_tracepoint_event+0x2580>
    2450:      	str	w24, [sp, #0x20]
    2454:      	mov	x3, xzr
    2458:      	mov	w8, #0x2                // =2
    245c:      	add	x9, sp, #0x38
    2460:      	add	x10, sp, #0x20
    2464:      	add	x1, sp, #0x38
    2468:      	add	x2, sp, #0x20
    246c:      	mov	x0, x22
    2470:      	blr	x8
    2474:      	ldrsw	x24, [sp, #0x88]
    2478:      	b	0x2580 <generic_tracepoint_event+0x2580>
    247c:      	str	w24, [sp, #0x20]
    2480:      	mov	x3, xzr
    2484:      	mov	w8, #0x2                // =2
    2488:      	add	x9, sp, #0x38
    248c:      	add	x10, sp, #0x20
    2490:      	add	x1, sp, #0x38
    2494:      	add	x2, sp, #0x20
    2498:      	mov	x0, x22
    249c:      	blr	x8
    24a0:      	ldrsh	x24, [sp, #0x88]
    24a4:      	b	0x2580 <generic_tracepoint_event+0x2580>
    24a8:      	str	w24, [sp, #0x20]
    24ac:      	mov	x3, xzr
    24b0:      	mov	w8, #0x2                // =2
    24b4:      	add	x9, sp, #0x38
    24b8:      	add	x10, sp, #0x20
    24bc:      	add	x1, sp, #0x38
    24c0:      	add	x2, sp, #0x20
    24c4:      	mov	x0, x22
    24c8:      	blr	x8
    24cc:      	ldrsb	x24, [sp, #0x88]
    24d0:      	b	0x2580 <generic_tracepoint_event+0x2580>
    24d4:      	str	w24, [sp, #0x20]
    24d8:      	mov	x3, xzr
    24dc:      	mov	w8, #0x2                // =2
    24e0:      	add	x9, sp, #0x38
    24e4:      	add	x10, sp, #0x20
    24e8:      	add	x1, sp, #0x38
    24ec:      	add	x2, sp, #0x20
    24f0:      	mov	x0, x22
    24f4:      	blr	x8
    24f8:      	ldrb	w24, [sp, #0x88]
    24fc:      	b	0x2580 <generic_tracepoint_event+0x2580>
    2500:      	str	w24, [sp, #0x88]
    2504:      	mov	x3, xzr
    2508:      	mov	w8, #0x2                // =2
    250c:      	add	x9, sp, #0x38
    2510:      	add	x10, sp, #0x88
    2514:      	add	x1, sp, #0x38
    2518:      	add	x2, sp, #0x88
    251c:      	mov	x0, x22
    2520:      	blr	x8
    2524:      	ldr	x24, [sp, #0x20]
    2528:      	b	0x2580 <generic_tracepoint_event+0x2580>
    252c:      	str	w24, [sp, #0x20]
    2530:      	mov	x3, xzr
    2534:      	mov	w8, #0x2                // =2
    2538:      	add	x9, sp, #0x38
    253c:      	add	x10, sp, #0x20
    2540:      	add	x1, sp, #0x38
    2544:      	add	x2, sp, #0x20
    2548:      	mov	x0, x22
    254c:      	blr	x8
    2550:      	ldrh	w24, [sp, #0x88]
    2554:      	b	0x2580 <generic_tracepoint_event+0x2580>
    2558:      	str	w24, [sp, #0x20]
    255c:      	mov	x3, xzr
    2560:      	mov	w8, #0x2                // =2
    2564:      	add	x9, sp, #0x38
    2568:      	add	x10, sp, #0x20
    256c:      	add	x1, sp, #0x38
    2570:      	add	x2, sp, #0x20
    2574:      	mov	x0, x22
    2578:      	blr	x8
    257c:      	ldr	w24, [sp, #0x88]
    2580:      	str	x24, [x20, #0x5e68]
    2584:      	mov	x22, xzr
    2588:      	ldrh	w8, [x21, #0x3c]
    258c:      	ldr	w24, [x21, #0x14]
    2590:      	add	x2, x19, x8
    2594:      	cmp	w24, #0xb
    2598:      	b.gt	0x25c8 <generic_tracepoint_event+0x25c8>
    259c:      	cmp	w24, #0x3
    25a0:      	b.le	0x2660 <generic_tracepoint_event+0x2660>
    25a4:      	cmp	w24, #0x6
    25a8:      	b.gt	0x2780 <generic_tracepoint_event+0x2780>
    25ac:      	cmp	w24, #0x4
    25b0:      	b.eq	0x2bc8 <generic_tracepoint_event+0x2bc8>
    25b4:      	cmp	w24, #0x5
    25b8:      	b.eq	0x2a70 <generic_tracepoint_event+0x2a70>
    25bc:      	cmp	w24, #0x6
    25c0:      	b.eq	0x267c <generic_tracepoint_event+0x267c>
    25c4:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    25c8:      	cmp	w24, #0x1d
    25cc:      	b.le	0x26f0 <generic_tracepoint_event+0x26f0>
    25d0:      	cmp	w24, #0x25
    25d4:      	b.gt	0x27f8 <generic_tracepoint_event+0x27f8>
    25d8:      	cmp	w24, #0x1e
    25dc:      	b.eq	0x2c34 <generic_tracepoint_event+0x2c34>
    25e0:      	cmp	w24, #0x1f
    25e4:      	b.eq	0x2ae4 <generic_tracepoint_event+0x2ae4>
    25e8:      	cmp	w24, #0x20
    25ec:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    25f0:      	mov	w8, #0x1                // =1
    25f4:      	mov	w9, #0x4                // =4
    25f8:      	add	x10, sp, #0x88
    25fc:      	add	x0, sp, #0x88
    2600:      	mov	w1, #0x1                // =1
    2604:      	blr	x9
    2608:      	cbz	x0, 0x2db8 <generic_tracepoint_event+0x2db8>
    260c:      	neg	w8, w0
    2610:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2614:      	mov	w9, #0x1                // =1
    2618:      	strh	w8, [sp, #0x38]
    261c:      	mov	w8, #0x7                // =7
    2620:      	add	x1, sp, #0x38
    2624:      	mov	w22, #0x1               // =1
    2628:      	strh	w8, [sp, #0x3a]
    262c:      	mov	x8, #0x73               // =115
    2630:      	movk	x8, #0x4, lsl #32
    2634:      	stur	x8, [sp, #0x3c]
    2638:      	add	x8, sp, #0x38
    263c:      	ldr	x21, [x21]
    2640:      	mov	x0, x21
    2644:      	blr	x9
    2648:      	cbz	x0, 0x2d94 <generic_tracepoint_event+0x2d94>
    264c:      	ldr	w8, [x0]
    2650:      	add	w8, w8, #0x1
    2654:      	str	w8, [x0]
    2658:      	ldrb	w22, [sp, #0x88]
    265c:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2660:      	cmn	w24, #0xc
    2664:      	b.le	0x2884 <generic_tracepoint_event+0x2884>
    2668:      	add	w8, w24, #0xb
    266c:      	cmp	w8, #0x2
    2670:      	b.lo	0x278c <generic_tracepoint_event+0x278c>
    2674:      	cmp	w24, #0x2
    2678:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    267c:      	mov	w8, #0x8                // =8
    2680:      	mov	w9, #0x4                // =4
    2684:      	add	x10, sp, #0x20
    2688:      	add	x0, sp, #0x20
    268c:      	mov	w1, #0x8                // =8
    2690:      	blr	x9
    2694:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    2698:      	neg	w8, w0
    269c:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    26a0:      	mov	w9, #0x1                // =1
    26a4:      	strh	w8, [sp, #0x38]
    26a8:      	mov	w8, #0x7                // =7
    26ac:      	add	x1, sp, #0x38
    26b0:      	mov	w22, #0x1               // =1
    26b4:      	strh	w8, [sp, #0x3a]
    26b8:      	mov	x8, #0x81               // =129
    26bc:      	movk	x8, #0x4, lsl #32
    26c0:      	stur	x8, [sp, #0x3c]
    26c4:      	add	x8, sp, #0x38
    26c8:      	ldr	x21, [x21]
    26cc:      	mov	x0, x21
    26d0:      	blr	x9
    26d4:      	cbnz	x0, 0x2c24 <generic_tracepoint_event+0x2c24>
    26d8:      	str	w22, [sp, #0x88]
    26dc:      	mov	x3, xzr
    26e0:      	mov	w8, #0x2                // =2
    26e4:      	add	x9, sp, #0x38
    26e8:      	add	x10, sp, #0x88
    26ec:      	b	0x2dd4 <generic_tracepoint_event+0x2dd4>
    26f0:      	cmp	w24, #0x11
    26f4:      	b.le	0x2898 <generic_tracepoint_event+0x2898>
    26f8:      	cmp	w24, #0x12
    26fc:      	b.eq	0x2a68 <generic_tracepoint_event+0x2a68>
    2700:      	cmp	w24, #0x1c
    2704:      	b.eq	0x278c <generic_tracepoint_event+0x278c>
    2708:      	cmp	w24, #0x1d
    270c:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    2710:      	mov	w8, #0x2                // =2
    2714:      	mov	w9, #0x4                // =4
    2718:      	add	x10, sp, #0x88
    271c:      	add	x0, sp, #0x88
    2720:      	mov	w1, #0x2                // =2
    2724:      	blr	x9
    2728:      	cbz	x0, 0x2d60 <generic_tracepoint_event+0x2d60>
    272c:      	neg	w8, w0
    2730:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2734:      	mov	w9, #0x1                // =1
    2738:      	strh	w8, [sp, #0x38]
    273c:      	mov	w8, #0x7                // =7
    2740:      	add	x1, sp, #0x38
    2744:      	mov	w22, #0x1               // =1
    2748:      	strh	w8, [sp, #0x3a]
    274c:      	mov	x8, #0x6c               // =108
    2750:      	movk	x8, #0x4, lsl #32
    2754:      	stur	x8, [sp, #0x3c]
    2758:      	add	x8, sp, #0x38
    275c:      	ldr	x21, [x21]
    2760:      	mov	x0, x21
    2764:      	blr	x9
    2768:      	cbz	x0, 0x2d3c <generic_tracepoint_event+0x2d3c>
    276c:      	ldr	w8, [x0]
    2770:      	add	w8, w8, #0x1
    2774:      	str	w8, [x0]
    2778:      	ldrsh	x22, [sp, #0x88]
    277c:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2780:      	sub	w8, w24, #0xa
    2784:      	cmp	w8, #0x2
    2788:      	b.hs	0x29ec <generic_tracepoint_event+0x29ec>
    278c:      	mov	w8, #0x8                // =8
    2790:      	mov	w9, #0x4                // =4
    2794:      	add	x10, sp, #0x20
    2798:      	add	x0, sp, #0x20
    279c:      	mov	w1, #0x8                // =8
    27a0:      	blr	x9
    27a4:      	cbz	x0, 0x29a8 <generic_tracepoint_event+0x29a8>
    27a8:      	neg	w8, w0
    27ac:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    27b0:      	mov	w9, #0x1                // =1
    27b4:      	strh	w8, [sp, #0x38]
    27b8:      	mov	w8, #0x7                // =7
    27bc:      	add	x1, sp, #0x38
    27c0:      	mov	w22, #0x1               // =1
    27c4:      	strh	w8, [sp, #0x3a]
    27c8:      	mov	x8, #0x45               // =69
    27cc:      	movk	x8, #0x4, lsl #32
    27d0:      	stur	x8, [sp, #0x3c]
    27d4:      	add	x8, sp, #0x38
    27d8:      	ldr	x21, [x21]
    27dc:      	mov	x0, x21
    27e0:      	blr	x9
    27e4:      	cbz	x0, 0x2984 <generic_tracepoint_event+0x2984>
    27e8:      	ldr	w8, [x0]
    27ec:      	add	w8, w8, #0x1
    27f0:      	str	w8, [x0]
    27f4:      	b	0x29a8 <generic_tracepoint_event+0x29a8>
    27f8:      	cmp	w24, #0x26
    27fc:      	b.eq	0x2ca4 <generic_tracepoint_event+0x2ca4>
    2800:      	cmp	w24, #0x28
    2804:      	b.eq	0x2b54 <generic_tracepoint_event+0x2b54>
    2808:      	cmp	w24, #0x29
    280c:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    2810:      	mov	w8, #0x8                // =8
    2814:      	mov	w9, #0x4                // =4
    2818:      	add	x10, sp, #0x20
    281c:      	add	x0, sp, #0x20
    2820:      	mov	w1, #0x8                // =8
    2824:      	blr	x9
    2828:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    282c:      	neg	w8, w0
    2830:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2834:      	mov	w9, #0x1                // =1
    2838:      	strh	w8, [sp, #0x38]
    283c:      	mov	w8, #0x7                // =7
    2840:      	add	x1, sp, #0x38
    2844:      	mov	w22, #0x1               // =1
    2848:      	strh	w8, [sp, #0x3a]
    284c:      	mov	x8, #0xa8               // =168
    2850:      	movk	x8, #0x4, lsl #32
    2854:      	stur	x8, [sp, #0x3c]
    2858:      	add	x8, sp, #0x38
    285c:      	ldr	x21, [x21]
    2860:      	mov	x0, x21
    2864:      	blr	x9
    2868:      	cbnz	x0, 0x2c24 <generic_tracepoint_event+0x2c24>
    286c:      	str	w22, [sp, #0x88]
    2870:      	mov	x3, xzr
    2874:      	mov	w8, #0x2                // =2
    2878:      	add	x9, sp, #0x38
    287c:      	add	x10, sp, #0x88
    2880:      	b	0x2dd4 <generic_tracepoint_event+0x2dd4>
    2884:      	cmn	w24, #0xd
    2888:      	b.eq	0x2918 <generic_tracepoint_event+0x2918>
    288c:      	cmn	w24, #0xc
    2890:      	b.eq	0x28a8 <generic_tracepoint_event+0x28a8>
    2894:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2898:      	cmp	w24, #0xc
    289c:      	b.eq	0x2918 <generic_tracepoint_event+0x2918>
    28a0:      	cmp	w24, #0xd
    28a4:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    28a8:      	mov	w8, #0x4                // =4
    28ac:      	add	x9, sp, #0x88
    28b0:      	add	x0, sp, #0x88
    28b4:      	mov	w1, #0x4                // =4
    28b8:      	blr	x8
    28bc:      	cbz	x0, 0x2e3c <generic_tracepoint_event+0x2e3c>
    28c0:      	neg	w8, w0
    28c4:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    28c8:      	mov	w9, #0x1                // =1
    28cc:      	strh	w8, [sp, #0x38]
    28d0:      	mov	w8, #0x7                // =7
    28d4:      	add	x1, sp, #0x38
    28d8:      	mov	w22, #0x1               // =1
    28dc:      	strh	w8, [sp, #0x3a]
    28e0:      	mov	x8, #0x5e               // =94
    28e4:      	movk	x8, #0x4, lsl #32
    28e8:      	stur	x8, [sp, #0x3c]
    28ec:      	add	x8, sp, #0x38
    28f0:      	ldr	x21, [x21]
    28f4:      	mov	x0, x21
    28f8:      	blr	x9
    28fc:      	cbnz	x0, 0x2cfc <generic_tracepoint_event+0x2cfc>
    2900:      	str	w22, [sp, #0x20]
    2904:      	mov	x3, xzr
    2908:      	mov	w8, #0x2                // =2
    290c:      	add	x9, sp, #0x38
    2910:      	add	x10, sp, #0x20
    2914:      	b	0x2e2c <generic_tracepoint_event+0x2e2c>
    2918:      	mov	w8, #0x4                // =4
    291c:      	add	x9, sp, #0x88
    2920:      	add	x0, sp, #0x88
    2924:      	mov	w1, #0x4                // =4
    2928:      	blr	x8
    292c:      	cbz	x0, 0x2d34 <generic_tracepoint_event+0x2d34>
    2930:      	neg	w8, w0
    2934:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2938:      	mov	w9, #0x1                // =1
    293c:      	strh	w8, [sp, #0x38]
    2940:      	mov	w8, #0x7                // =7
    2944:      	add	x1, sp, #0x38
    2948:      	mov	w22, #0x1               // =1
    294c:      	strh	w8, [sp, #0x3a]
    2950:      	mov	x8, #0x56               // =86
    2954:      	movk	x8, #0x4, lsl #32
    2958:      	stur	x8, [sp, #0x3c]
    295c:      	add	x8, sp, #0x38
    2960:      	ldr	x21, [x21]
    2964:      	mov	x0, x21
    2968:      	blr	x9
    296c:      	cbz	x0, 0x2d10 <generic_tracepoint_event+0x2d10>
    2970:      	ldr	w8, [x0]
    2974:      	add	w8, w8, #0x1
    2978:      	str	w8, [x0]
    297c:      	ldrsw	x22, [sp, #0x88]
    2980:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2984:      	str	w22, [sp, #0x88]
    2988:      	mov	x3, xzr
    298c:      	mov	w8, #0x2                // =2
    2990:      	add	x9, sp, #0x38
    2994:      	add	x10, sp, #0x88
    2998:      	add	x1, sp, #0x38
    299c:      	add	x2, sp, #0x88
    29a0:      	mov	x0, x21
    29a4:      	blr	x8
    29a8:      	ldr	x22, [sp, #0x20]
    29ac:      	cmp	w24, #0x1c
    29b0:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    29b4:      	mov	w8, #0x23               // =35
    29b8:      	blr	x8
    29bc:      	mov	w8, #0x8                // =8
    29c0:      	mov	w9, #0x4                // =4
    29c4:      	add	x10, sp, #0x38
    29c8:      	mov	x2, x0
    29cc:      	add	x0, sp, #0x38
    29d0:      	mov	w1, #0x8                // =8
    29d4:      	blr	x9
    29d8:      	ldr	w8, [sp, #0x38]
    29dc:      	lsl	w8, w8, #9
    29e0:      	and	x8, x8, #0x80000000
    29e4:      	orr	x22, x8, x22
    29e8:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    29ec:      	cmp	w24, #0x7
    29f0:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    29f4:      	mov	w8, #0x8                // =8
    29f8:      	mov	w9, #0x4                // =4
    29fc:      	add	x10, sp, #0x20
    2a00:      	add	x0, sp, #0x20
    2a04:      	mov	w1, #0x8                // =8
    2a08:      	blr	x9
    2a0c:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    2a10:      	neg	w8, w0
    2a14:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2a18:      	mov	w9, #0x1                // =1
    2a1c:      	strh	w8, [sp, #0x38]
    2a20:      	mov	w8, #0x7                // =7
    2a24:      	add	x1, sp, #0x38
    2a28:      	mov	w22, #0x1               // =1
    2a2c:      	strh	w8, [sp, #0x3a]
    2a30:      	mov	x8, #0x9a               // =154
    2a34:      	movk	x8, #0x4, lsl #32
    2a38:      	stur	x8, [sp, #0x3c]
    2a3c:      	add	x8, sp, #0x38
    2a40:      	ldr	x21, [x21]
    2a44:      	mov	x0, x21
    2a48:      	blr	x9
    2a4c:      	cbnz	x0, 0x2c24 <generic_tracepoint_event+0x2c24>
    2a50:      	str	w22, [sp, #0x88]
    2a54:      	mov	x3, xzr
    2a58:      	mov	w8, #0x2                // =2
    2a5c:      	add	x9, sp, #0x38
    2a60:      	add	x10, sp, #0x88
    2a64:      	b	0x2dd4 <generic_tracepoint_event+0x2dd4>
    2a68:      	mov	x22, x2
    2a6c:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2a70:      	mov	w8, #0x8                // =8
    2a74:      	mov	w9, #0x4                // =4
    2a78:      	add	x10, sp, #0x20
    2a7c:      	add	x0, sp, #0x20
    2a80:      	mov	w1, #0x8                // =8
    2a84:      	blr	x9
    2a88:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    2a8c:      	neg	w8, w0
    2a90:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2a94:      	mov	w9, #0x1                // =1
    2a98:      	strh	w8, [sp, #0x38]
    2a9c:      	mov	w8, #0x7                // =7
    2aa0:      	add	x1, sp, #0x38
    2aa4:      	mov	w22, #0x1               // =1
    2aa8:      	strh	w8, [sp, #0x3a]
    2aac:      	mov	x8, #0x93               // =147
    2ab0:      	movk	x8, #0x4, lsl #32
    2ab4:      	stur	x8, [sp, #0x3c]
    2ab8:      	add	x8, sp, #0x38
    2abc:      	ldr	x21, [x21]
    2ac0:      	mov	x0, x21
    2ac4:      	blr	x9
    2ac8:      	cbnz	x0, 0x2c24 <generic_tracepoint_event+0x2c24>
    2acc:      	str	w22, [sp, #0x88]
    2ad0:      	mov	x3, xzr
    2ad4:      	mov	w8, #0x2                // =2
    2ad8:      	add	x9, sp, #0x38
    2adc:      	add	x10, sp, #0x88
    2ae0:      	b	0x2dd4 <generic_tracepoint_event+0x2dd4>
    2ae4:      	mov	w8, #0x1                // =1
    2ae8:      	mov	w9, #0x4                // =4
    2aec:      	add	x10, sp, #0x88
    2af0:      	add	x0, sp, #0x88
    2af4:      	mov	w1, #0x1                // =1
    2af8:      	blr	x9
    2afc:      	cbz	x0, 0x2d8c <generic_tracepoint_event+0x2d8c>
    2b00:      	neg	w8, w0
    2b04:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2b08:      	mov	w9, #0x1                // =1
    2b0c:      	strh	w8, [sp, #0x38]
    2b10:      	mov	w8, #0x7                // =7
    2b14:      	add	x1, sp, #0x38
    2b18:      	mov	w22, #0x1               // =1
    2b1c:      	strh	w8, [sp, #0x3a]
    2b20:      	mov	x8, #0x7a               // =122
    2b24:      	movk	x8, #0x4, lsl #32
    2b28:      	stur	x8, [sp, #0x3c]
    2b2c:      	add	x8, sp, #0x38
    2b30:      	ldr	x21, [x21]
    2b34:      	mov	x0, x21
    2b38:      	blr	x9
    2b3c:      	cbz	x0, 0x2d68 <generic_tracepoint_event+0x2d68>
    2b40:      	ldr	w8, [x0]
    2b44:      	add	w8, w8, #0x1
    2b48:      	str	w8, [x0]
    2b4c:      	ldrsb	x22, [sp, #0x88]
    2b50:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2b54:      	mov	w8, #0x8                // =8
    2b58:      	mov	w9, #0x4                // =4
    2b5c:      	add	x10, sp, #0x20
    2b60:      	add	x0, sp, #0x20
    2b64:      	mov	w1, #0x8                // =8
    2b68:      	blr	x9
    2b6c:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    2b70:      	neg	w8, w0
    2b74:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2b78:      	mov	w9, #0x1                // =1
    2b7c:      	strh	w8, [sp, #0x38]
    2b80:      	mov	w8, #0x7                // =7
    2b84:      	add	x1, sp, #0x38
    2b88:      	mov	w22, #0x1               // =1
    2b8c:      	strh	w8, [sp, #0x3a]
    2b90:      	mov	x8, #0xa1               // =161
    2b94:      	movk	x8, #0x4, lsl #32
    2b98:      	stur	x8, [sp, #0x3c]
    2b9c:      	add	x8, sp, #0x38
    2ba0:      	ldr	x21, [x21]
    2ba4:      	mov	x0, x21
    2ba8:      	blr	x9
    2bac:      	cbnz	x0, 0x2c24 <generic_tracepoint_event+0x2c24>
    2bb0:      	str	w22, [sp, #0x88]
    2bb4:      	mov	x3, xzr
    2bb8:      	mov	w8, #0x2                // =2
    2bbc:      	add	x9, sp, #0x38
    2bc0:      	add	x10, sp, #0x88
    2bc4:      	b	0x2dd4 <generic_tracepoint_event+0x2dd4>
    2bc8:      	mov	w8, #0x8                // =8
    2bcc:      	mov	w9, #0x4                // =4
    2bd0:      	add	x10, sp, #0x20
    2bd4:      	add	x0, sp, #0x20
    2bd8:      	mov	w1, #0x8                // =8
    2bdc:      	blr	x9
    2be0:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    2be4:      	neg	w8, w0
    2be8:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2bec:      	mov	w9, #0x1                // =1
    2bf0:      	strh	w8, [sp, #0x38]
    2bf4:      	mov	w8, #0x7                // =7
    2bf8:      	add	x1, sp, #0x38
    2bfc:      	mov	w22, #0x1               // =1
    2c00:      	strh	w8, [sp, #0x3a]
    2c04:      	mov	x8, #0x4e               // =78
    2c08:      	movk	x8, #0x4, lsl #32
    2c0c:      	stur	x8, [sp, #0x3c]
    2c10:      	add	x8, sp, #0x38
    2c14:      	ldr	x21, [x21]
    2c18:      	mov	x0, x21
    2c1c:      	blr	x9
    2c20:      	cbz	x0, 0x2dc0 <generic_tracepoint_event+0x2dc0>
    2c24:      	ldr	w8, [x0]
    2c28:      	add	w8, w8, #0x1
    2c2c:      	str	w8, [x0]
    2c30:      	b	0x2de4 <generic_tracepoint_event+0x2de4>
    2c34:      	mov	w8, #0x2                // =2
    2c38:      	mov	w9, #0x4                // =4
    2c3c:      	add	x10, sp, #0x88
    2c40:      	add	x0, sp, #0x88
    2c44:      	mov	w1, #0x2                // =2
    2c48:      	blr	x9
    2c4c:      	cbz	x0, 0x2e10 <generic_tracepoint_event+0x2e10>
    2c50:      	neg	w8, w0
    2c54:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2c58:      	mov	w9, #0x1                // =1
    2c5c:      	strh	w8, [sp, #0x38]
    2c60:      	mov	w8, #0x7                // =7
    2c64:      	add	x1, sp, #0x38
    2c68:      	mov	w22, #0x1               // =1
    2c6c:      	strh	w8, [sp, #0x3a]
    2c70:      	mov	x8, #0x65               // =101
    2c74:      	movk	x8, #0x4, lsl #32
    2c78:      	stur	x8, [sp, #0x3c]
    2c7c:      	add	x8, sp, #0x38
    2c80:      	ldr	x21, [x21]
    2c84:      	mov	x0, x21
    2c88:      	blr	x9
    2c8c:      	cbz	x0, 0x2dec <generic_tracepoint_event+0x2dec>
    2c90:      	ldr	w8, [x0]
    2c94:      	add	w8, w8, #0x1
    2c98:      	str	w8, [x0]
    2c9c:      	ldrh	w22, [sp, #0x88]
    2ca0:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2ca4:      	mov	w8, #0x4                // =4
    2ca8:      	add	x9, sp, #0x88
    2cac:      	add	x0, sp, #0x88
    2cb0:      	mov	w1, #0x4                // =4
    2cb4:      	blr	x8
    2cb8:      	cbz	x0, 0x2e3c <generic_tracepoint_event+0x2e3c>
    2cbc:      	neg	w8, w0
    2cc0:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2cc4:      	mov	w9, #0x1                // =1
    2cc8:      	strh	w8, [sp, #0x38]
    2ccc:      	mov	w8, #0x7                // =7
    2cd0:      	add	x1, sp, #0x38
    2cd4:      	mov	w22, #0x1               // =1
    2cd8:      	strh	w8, [sp, #0x3a]
    2cdc:      	mov	x8, #0x88               // =136
    2ce0:      	movk	x8, #0x4, lsl #32
    2ce4:      	stur	x8, [sp, #0x3c]
    2ce8:      	add	x8, sp, #0x38
    2cec:      	ldr	x21, [x21]
    2cf0:      	mov	x0, x21
    2cf4:      	blr	x9
    2cf8:      	cbz	x0, 0x2e18 <generic_tracepoint_event+0x2e18>
    2cfc:      	ldr	w8, [x0]
    2d00:      	add	w8, w8, #0x1
    2d04:      	str	w8, [x0]
    2d08:      	ldr	w22, [sp, #0x88]
    2d0c:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2d10:      	str	w22, [sp, #0x20]
    2d14:      	mov	x3, xzr
    2d18:      	mov	w8, #0x2                // =2
    2d1c:      	add	x9, sp, #0x38
    2d20:      	add	x10, sp, #0x20
    2d24:      	add	x1, sp, #0x38
    2d28:      	add	x2, sp, #0x20
    2d2c:      	mov	x0, x21
    2d30:      	blr	x8
    2d34:      	ldrsw	x22, [sp, #0x88]
    2d38:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2d3c:      	str	w22, [sp, #0x20]
    2d40:      	mov	x3, xzr
    2d44:      	mov	w8, #0x2                // =2
    2d48:      	add	x9, sp, #0x38
    2d4c:      	add	x10, sp, #0x20
    2d50:      	add	x1, sp, #0x38
    2d54:      	add	x2, sp, #0x20
    2d58:      	mov	x0, x21
    2d5c:      	blr	x8
    2d60:      	ldrsh	x22, [sp, #0x88]
    2d64:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2d68:      	str	w22, [sp, #0x20]
    2d6c:      	mov	x3, xzr
    2d70:      	mov	w8, #0x2                // =2
    2d74:      	add	x9, sp, #0x38
    2d78:      	add	x10, sp, #0x20
    2d7c:      	add	x1, sp, #0x38
    2d80:      	add	x2, sp, #0x20
    2d84:      	mov	x0, x21
    2d88:      	blr	x8
    2d8c:      	ldrsb	x22, [sp, #0x88]
    2d90:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2d94:      	str	w22, [sp, #0x20]
    2d98:      	mov	x3, xzr
    2d9c:      	mov	w8, #0x2                // =2
    2da0:      	add	x9, sp, #0x38
    2da4:      	add	x10, sp, #0x20
    2da8:      	add	x1, sp, #0x38
    2dac:      	add	x2, sp, #0x20
    2db0:      	mov	x0, x21
    2db4:      	blr	x8
    2db8:      	ldrb	w22, [sp, #0x88]
    2dbc:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2dc0:      	str	w22, [sp, #0x88]
    2dc4:      	mov	x3, xzr
    2dc8:      	mov	w8, #0x2                // =2
    2dcc:      	add	x9, sp, #0x38
    2dd0:      	add	x10, sp, #0x88
    2dd4:      	add	x1, sp, #0x38
    2dd8:      	add	x2, sp, #0x88
    2ddc:      	mov	x0, x21
    2de0:      	blr	x8
    2de4:      	ldr	x22, [sp, #0x20]
    2de8:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2dec:      	str	w22, [sp, #0x20]
    2df0:      	mov	x3, xzr
    2df4:      	mov	w8, #0x2                // =2
    2df8:      	add	x9, sp, #0x38
    2dfc:      	add	x10, sp, #0x20
    2e00:      	add	x1, sp, #0x38
    2e04:      	add	x2, sp, #0x20
    2e08:      	mov	x0, x21
    2e0c:      	blr	x8
    2e10:      	ldrh	w22, [sp, #0x88]
    2e14:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2e18:      	str	w22, [sp, #0x20]
    2e1c:      	mov	x3, xzr
    2e20:      	mov	w8, #0x2                // =2
    2e24:      	add	x9, sp, #0x38
    2e28:      	add	x10, sp, #0x20
    2e2c:      	add	x1, sp, #0x38
    2e30:      	add	x2, sp, #0x20
    2e34:      	mov	x0, x21
    2e38:      	blr	x8
    2e3c:      	ldr	w22, [sp, #0x88]
    2e40:      	mov	w21, #0xe               // =14
    2e44:      	str	x22, [x20, #0x5e70]
    2e48:      	strh	wzr, [x20, #0x2]
    2e4c:      	mov	w8, #0x7d               // =125
    2e50:      	str	wzr, [x20, #0x4]
    2e54:      	strb	w21, [x20]
    2e58:      	blr	x8
    2e5c:      	str	x0, [x20, #0x8]
    2e60:      	str	xzr, [x20, #0x70]
    2e64:      	mov	w8, #0xe                // =14
    2e68:      	str	wzr, [x20, #0x14]
    2e6c:      	blr	x8
    2e70:      	mov	w8, #0x5eb8             // =24248
    2e74:      	add	x9, x23, #0xefc
    2e78:      	str	w0, [x20, #0x7c]
    2e7c:      	strb	w21, [x20]
    2e80:      	add	x8, x20, x8
    2e84:      	str	xzr, [x9]
    2e88:      	str	xzr, [x20, #0x5eb8]
    2e8c:      	mov	w9, #0x23               // =35
    2e90:      	str	xzr, [x20, #0x5ec0]
    2e94:      	str	xzr, [x20, #0x5ec8]
    2e98:      	str	xzr, [x20, #0x5ed0]
    2e9c:      	str	xzr, [x20, #0x5ed8]
    2ea0:      	strb	wzr, [x8, #0x28]
    2ea4:      	blr	x9
    2ea8:      	add	x2, x0, #0xb50
    2eac:      	mov	w24, #0x8               // =8
    2eb0:      	add	x8, sp, #0x88
    2eb4:      	mov	w9, #0x4                // =4
    2eb8:      	mov	x21, x0
    2ebc:      	add	x0, sp, #0x88
    2ec0:      	mov	w1, #0x8                // =8
    2ec4:      	add	x22, x20, #0x20
    2ec8:      	mov	w23, #0x4               // =4
    2ecc:      	blr	x9
    2ed0:      	ldr	x8, [sp, #0x88]
    2ed4:      	mov	w9, #0x48               // =72
    2ed8:      	add	x10, sp, #0x38
    2edc:      	mov	w11, #0x4               // =4
    2ee0:      	ldr	x2, [sp, #0x88]
    2ee4:      	add	x0, sp, #0x38
    2ee8:      	mov	w1, #0x48               // =72
    2eec:      	blr	x11
    2ef0:      	ldr	x8, [sp, #0x40]
    2ef4:      	mov	w9, #0x4                // =4
    2ef8:      	mov	x0, x22
    2efc:      	mov	w1, #0x4                // =4
    2f00:      	add	x8, x8, #0x218
    2f04:      	ldr	x8, [sp, #0x40]
    2f08:      	add	x2, x8, #0x218
    2f0c:      	blr	x9
    2f10:      	ldr	x8, [sp, #0x48]
    2f14:      	add	x0, x20, #0x24
    2f18:      	mov	w9, #0x4                // =4
    2f1c:      	mov	w1, #0x4                // =4
    2f20:      	add	x8, x8, #0x4d8
    2f24:      	ldr	x8, [sp, #0x48]
    2f28:      	add	x2, x8, #0x4d8
    2f2c:      	blr	x9
    2f30:      	ldr	x8, [sp, #0x50]
    2f34:      	add	x0, x20, #0x28
    2f38:      	mov	w9, #0x4                // =4
    2f3c:      	mov	w1, #0x4                // =4
    2f40:      	add	x8, x8, #0x58
    2f44:      	ldr	x8, [sp, #0x50]
    2f48:      	add	x2, x8, #0x58
    2f4c:      	blr	x9
    2f50:      	str	xzr, [sp, #0x30]
    2f54:      	add	x2, x21, #0x938
    2f58:      	add	x8, sp, #0x30
    2f5c:      	add	x0, sp, #0x30
    2f60:      	mov	w1, #0x8                // =8
    2f64:      	blr	x23
    2f68:      	ldr	x8, [sp, #0x30]
    2f6c:      	cbz	x8, 0x2ff0 <generic_tracepoint_event+0x2ff0>
    2f70:      	str	wzr, [sp, #0x10]
    2f74:      	add	x8, x8, #0x4
    2f78:      	add	x9, sp, #0x10
    2f7c:      	mov	w10, #0x4               // =4
    2f80:      	add	x0, sp, #0x10
    2f84:      	mov	w1, #0x4                // =4
    2f88:      	mov	w22, #0x4               // =4
    2f8c:      	ldr	x8, [sp, #0x30]
    2f90:      	add	x2, x8, #0x4
    2f94:      	blr	x10
    2f98:      	ldr	x8, [sp, #0x30]
    2f9c:      	ldrsw	x9, [sp, #0x10]
    2fa0:      	add	x10, sp, #0x20
    2fa4:      	mov	w11, #0x4               // =4
    2fa8:      	add	x0, sp, #0x20
    2fac:      	mov	w1, #0x10               // =16
    2fb0:      	add	x8, x8, x9, lsl #4
    2fb4:      	mov	w9, #0x10               // =16
    2fb8:      	add	x8, x8, #0x80
    2fbc:      	ldr	x8, [sp, #0x30]
    2fc0:      	ldrsw	x9, [sp, #0x10]
    2fc4:      	add	x8, x8, x9, lsl #4
    2fc8:      	add	x2, x8, #0x80
    2fcc:      	blr	x11
    2fd0:      	ldr	x8, [sp, #0x28]
    2fd4:      	add	x0, x20, #0x2c
    2fd8:      	mov	w1, #0x4                // =4
    2fdc:      	add	x8, x8, #0x158
    2fe0:      	ldr	x8, [sp, #0x28]
    2fe4:      	add	x2, x8, #0x158
    2fe8:      	blr	x22
    2fec:      	b	0x2ff4 <generic_tracepoint_event+0x2ff4>
    2ff0:      	str	wzr, [x20, #0x2c]
    2ff4:      	ldr	x8, [sp, #0x58]
    2ff8:      	add	x0, x20, #0x30
    2ffc:      	mov	w9, #0x4                // =4
    3000:      	mov	w1, #0x4                // =4
    3004:      	mov	w23, #0x4               // =4
    3008:      	add	x8, x8, #0x158
    300c:      	ldr	x8, [sp, #0x58]
    3010:      	add	x2, x8, #0x158
    3014:      	blr	x9
    3018:      	ldr	x8, [sp, #0x60]
    301c:      	add	x0, x20, #0x34
    3020:      	mov	w9, #0x4                // =4
    3024:      	mov	w1, #0x4                // =4
    3028:      	add	x8, x8, #0x118
    302c:      	ldr	x8, [sp, #0x60]
    3030:      	add	x2, x8, #0x118
    3034:      	blr	x9
    3038:      	ldr	x8, [sp, #0x68]
    303c:      	add	x0, x20, #0x38
    3040:      	mov	w9, #0x4                // =4
    3044:      	mov	w1, #0x4                // =4
    3048:      	add	x8, x8, #0x98
    304c:      	ldr	x8, [sp, #0x68]
    3050:      	add	x2, x8, #0x98
    3054:      	blr	x9
    3058:      	ldr	x8, [sp, #0x70]
    305c:      	add	x0, x20, #0x3c
    3060:      	mov	w9, #0x4                // =4
    3064:      	mov	w1, #0x4                // =4
    3068:      	add	x8, x8, #0x98
    306c:      	ldr	x8, [sp, #0x70]
    3070:      	add	x2, x8, #0x98
    3074:      	blr	x9
    3078:      	ldr	x8, [sp, #0x78]
    307c:      	add	x0, x20, #0x40
    3080:      	mov	w9, #0x4                // =4
    3084:      	mov	w1, #0x4                // =4
    3088:      	add	x8, x8, #0x58
    308c:      	ldr	x8, [sp, #0x78]
    3090:      	add	x2, x8, #0x58
    3094:      	blr	x9
    3098:      	str	xzr, [sp, #0x20]
    309c:      	str	xzr, [sp, #0x30]
    30a0:      	add	x21, x21, #0xae0
    30a4:      	mov	w24, #0x8               // =8
    30a8:      	add	x8, sp, #0x20
    30ac:      	mov	w9, #0x4                // =4
    30b0:      	add	x0, sp, #0x20
    30b4:      	mov	w1, #0x8                // =8
    30b8:      	mov	x2, x21
    30bc:      	blr	x9
    30c0:      	ldr	x8, [sp, #0x20]
    30c4:      	add	x9, sp, #0x30
    30c8:      	mov	w10, #0x4               // =4
    30cc:      	add	x0, sp, #0x30
    30d0:      	mov	w1, #0x8                // =8
    30d4:      	add	x8, x8, #0x90
    30d8:      	ldr	x8, [sp, #0x20]
    30dc:      	add	x2, x8, #0x90
    30e0:      	blr	x10
    30e4:      	ldr	x8, [sp, #0x30]
    30e8:      	add	x0, x20, #0x44
    30ec:      	mov	w9, #0x4                // =4
    30f0:      	mov	w1, #0x4                // =4
    30f4:      	add	x8, x8, #0x158
    30f8:      	ldr	x8, [sp, #0x30]
    30fc:      	add	x2, x8, #0x158
    3100:      	blr	x9
    3104:      	add	x8, sp, #0x38
    3108:      	mov	w9, #0x4                // =4
    310c:      	add	x0, sp, #0x38
    3110:      	mov	w1, #0x8                // =8
    3114:      	mov	x2, x21
    3118:      	add	x22, x20, #0x48
    311c:      	blr	x9
    3120:      	ldr	x21, [sp, #0x38]
    3124:      	add	x0, x20, #0x50
    3128:      	mov	w8, #0x4                // =4
    312c:      	mov	w1, #0x8                // =8
    3130:      	add	x2, x21, #0x40
    3134:      	blr	x8
    3138:      	add	x0, x20, #0x58
    313c:      	add	x2, x21, #0x30
    3140:      	mov	w8, #0x4                // =4
    3144:      	mov	w1, #0x8                // =8
    3148:      	blr	x8
    314c:      	add	x2, x21, #0x38
    3150:      	mov	x0, x22
    3154:      	mov	w1, #0x8                // =8
    3158:      	blr	x23
    315c:      	strb	wzr, [x20, #0x1]
    3160:      	str	xzr, [x20, #0x5ee8]
    3164:      	adrp	x1, 0x3000 <generic_tracepoint_event+0x3000>
    3168:      	mov	w8, #0x2                // =2
    316c:      	mov	w9, #0xc                // =12
    3170:      	mov	x0, x19
    3174:      	str	xzr, [x20, #0x5ef0]
    3178:      	ldr	x1, [x1]
    317c:      	mov	w2, #0x2                // =2
    3180:      	blr	x9
    3184:      	ldp	x20, x19, [sp, #0xc0]
    3188:      	mov	w0, wzr
    318c:      	ldp	x22, x21, [sp, #0xb0]
    3190:      	ldp	x24, x23, [sp, #0xa0]
    3194:      	ldp	x30, x25, [sp, #0x90]
    3198:      	add	sp, sp, #0xd0
    319c:      	ret
