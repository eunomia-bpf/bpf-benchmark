
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_multi_retkprobe_v61.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <filter_64ty>:
       0:      	str	x30, [sp, #-0x10]!
       4:      	mov	x8, x0
       8:      	mov	x0, xzr
       c:      	ldr	w9, [x8, #0x4]
      10:      	cmp	w9, #0x20
      14:      	b.hi	0x74 <filter_64ty+0x74>
      18:      	mov	w10, #0x1               // =1
      1c:      	mov	w11, #0x101e            // =4126
      20:      	lsl	x10, x10, x9
      24:      	tst	x10, x11
      28:      	b.eq	0x3c <filter_64ty+0x3c>
      2c:      	mov	x0, x8
      30:      	bl	0x200 <filter_64ty_selector_val>
      34:      	ldr	x30, [sp], #0x10
      38:      	ret
      3c:      	mov	w10, #0x1               // =1
      40:      	lsl	x10, x10, x9
      44:      	tst	x10, #0xc00
      48:      	b.ne	0x6c <filter_64ty+0x6c>
      4c:      	mov	w10, #0x1               // =1
      50:      	lsl	x9, x10, x9
      54:      	tst	x9, #0x180000000
      58:      	b.eq	0x74 <filter_64ty+0x74>
      5c:      	mov	x0, x8
      60:      	bl	0x600 <filter_64ty_range>
      64:      	ldr	x30, [sp], #0x10
      68:      	ret
      6c:      	mov	x0, x8
      70:      	bl	0x560 <filter_64ty_map>
      74:      	ldr	x30, [sp], #0x10
      78:      	ret
      7c:      	nop

0000000000000080 <filter_32ty>:
      80:      	str	x30, [sp, #-0x10]!
      84:      	mov	x8, x0
      88:      	mov	x0, xzr
      8c:      	ldr	w9, [x8, #0x4]
      90:      	cmp	w9, #0x20
      94:      	b.hi	0xf4 <filter_32ty+0x74>
      98:      	mov	w10, #0x1               // =1
      9c:      	mov	w11, #0x101e            // =4126
      a0:      	lsl	x10, x10, x9
      a4:      	tst	x10, x11
      a8:      	b.eq	0xbc <filter_32ty+0x3c>
      ac:      	mov	x0, x8
      b0:      	bl	0x850 <filter_32ty_selector_val>
      b4:      	ldr	x30, [sp], #0x10
      b8:      	ret
      bc:      	mov	w10, #0x1               // =1
      c0:      	lsl	x10, x10, x9
      c4:      	tst	x10, #0xc00
      c8:      	b.ne	0xec <filter_32ty+0x6c>
      cc:      	mov	w10, #0x1               // =1
      d0:      	lsl	x9, x10, x9
      d4:      	tst	x9, #0x180000000
      d8:      	b.eq	0xf4 <filter_32ty+0x74>
      dc:      	mov	x0, x8
      e0:      	bl	0xc70 <filter_32ty_range>
      e4:      	ldr	x30, [sp], #0x10
      e8:      	ret
      ec:      	mov	x0, x8
      f0:      	bl	0xbb0 <filter_32ty_map>
      f4:      	ldr	x30, [sp], #0x10
      f8:      	ret
      fc:      	nop

0000000000000100 <filter_16ty>:
     100:      	str	x30, [sp, #-0x10]!
     104:      	mov	x8, x0
     108:      	mov	x0, xzr
     10c:      	ldr	w9, [x8, #0x4]
     110:      	cmp	w9, #0x20
     114:      	b.hi	0x174 <filter_16ty+0x74>
     118:      	mov	w10, #0x1               // =1
     11c:      	mov	w11, #0x101e            // =4126
     120:      	lsl	x10, x10, x9
     124:      	tst	x10, x11
     128:      	b.eq	0x13c <filter_16ty+0x3c>
     12c:      	mov	x0, x8
     130:      	bl	0xec0 <filter_16ty_selector_val>
     134:      	ldr	x30, [sp], #0x10
     138:      	ret
     13c:      	mov	w10, #0x1               // =1
     140:      	lsl	x10, x10, x9
     144:      	tst	x10, #0xc00
     148:      	b.ne	0x16c <filter_16ty+0x6c>
     14c:      	mov	w10, #0x1               // =1
     150:      	lsl	x9, x10, x9
     154:      	tst	x9, #0x180000000
     158:      	b.eq	0x174 <filter_16ty+0x74>
     15c:      	mov	x0, x8
     160:      	bl	0x12e0 <filter_16ty_range>
     164:      	ldr	x30, [sp], #0x10
     168:      	ret
     16c:      	mov	x0, x8
     170:      	bl	0x1220 <filter_16ty_map>
     174:      	ldr	x30, [sp], #0x10
     178:      	ret
     17c:      	nop

0000000000000180 <filter_8ty>:
     180:      	str	x30, [sp, #-0x10]!
     184:      	mov	x8, x0
     188:      	mov	x0, xzr
     18c:      	ldr	w9, [x8, #0x4]
     190:      	cmp	w9, #0x20
     194:      	b.hi	0x1f4 <filter_8ty+0x74>
     198:      	mov	w10, #0x1               // =1
     19c:      	mov	w11, #0x101e            // =4126
     1a0:      	lsl	x10, x10, x9
     1a4:      	tst	x10, x11
     1a8:      	b.eq	0x1bc <filter_8ty+0x3c>
     1ac:      	mov	x0, x8
     1b0:      	bl	0x1530 <filter_8ty_selector_val>
     1b4:      	ldr	x30, [sp], #0x10
     1b8:      	ret
     1bc:      	mov	w10, #0x1               // =1
     1c0:      	lsl	x10, x10, x9
     1c4:      	tst	x10, #0xc00
     1c8:      	b.ne	0x1ec <filter_8ty+0x6c>
     1cc:      	mov	w10, #0x1               // =1
     1d0:      	lsl	x9, x10, x9
     1d4:      	tst	x9, #0x180000000
     1d8:      	b.eq	0x1f4 <filter_8ty+0x74>
     1dc:      	mov	x0, x8
     1e0:      	bl	0x1950 <filter_8ty_range>
     1e4:      	ldr	x30, [sp], #0x10
     1e8:      	ret
     1ec:      	mov	x0, x8
     1f0:      	bl	0x1890 <filter_8ty_map>
     1f4:      	ldr	x30, [sp], #0x10
     1f8:      	ret
     1fc:      	nop

0000000000000200 <filter_64ty_selector_val>:
     200:      	ldr	w8, [x0, #0x4]
     204:      	cmp	w8, #0x25
     208:      	b.hi	0x27c <filter_64ty_selector_val+0x7c>
     20c:      	mov	x10, #0x40              // =64
     210:      	mov	w9, #0x1                // =1
     214:      	movk	x10, #0xc00, lsl #16
     218:      	lsl	x9, x9, x8
     21c:      	movk	x10, #0x20, lsl #32
     220:      	tst	x9, x10
     224:      	b.eq	0x230 <filter_64ty_selector_val+0x30>
     228:      	mov	w0, #0x1                // =1
     22c:      	ret
     230:      	mov	w9, #0x1                // =1
     234:      	lsl	x9, x9, x8
     238:      	tst	x9, #0x18
     23c:      	b.eq	0x25c <filter_64ty_selector_val+0x5c>
     240:      	ldr	x9, [x1]
     244:      	ldr	x10, [x0, #0x10]
     248:      	cmp	x9, x10
     24c:      	b.ne	0x2fc <filter_64ty_selector_val+0xfc>
     250:      	cmp	w8, #0x3
     254:      	cset	w0, eq
     258:      	ret
     25c:      	cmp	x8, #0xc
     260:      	b.ne	0x27c <filter_64ty_selector_val+0x7c>
     264:      	ldr	x8, [x1]
     268:      	ldr	x9, [x0, #0x10]
     26c:      	tst	x8, x9
     270:      	b.eq	0x3a8 <filter_64ty_selector_val+0x1a8>
     274:      	mov	w0, #0x1                // =1
     278:      	ret
     27c:      	cmp	w8, #0x1
     280:      	b.eq	0x2c4 <filter_64ty_selector_val+0xc4>
     284:      	cmp	w8, #0x2
     288:      	b.ne	0x550 <filter_64ty_selector_val+0x350>
     28c:      	ldr	w8, [x0, #0xc]
     290:      	cmp	w8, #0xc
     294:      	b.hi	0x3e0 <filter_64ty_selector_val+0x1e0>
     298:      	mov	w9, #0x1                // =1
     29c:      	lsl	w8, w9, w8
     2a0:      	mov	w9, #0x1402             // =5122
     2a4:      	tst	w8, w9
     2a8:      	b.eq	0x3e0 <filter_64ty_selector_val+0x1e0>
     2ac:      	ldr	x8, [x1]
     2b0:      	ldr	x9, [x0, #0x10]
     2b4:      	cmp	x8, x9
     2b8:      	b.ge	0x388 <filter_64ty_selector_val+0x188>
     2bc:      	mov	w0, #0x1                // =1
     2c0:      	ret
     2c4:      	ldr	w8, [x0, #0xc]
     2c8:      	cmp	w8, #0xc
     2cc:      	b.hi	0x3c8 <filter_64ty_selector_val+0x1c8>
     2d0:      	mov	w9, #0x1                // =1
     2d4:      	lsl	w8, w9, w8
     2d8:      	mov	w9, #0x1402             // =5122
     2dc:      	tst	w8, w9
     2e0:      	b.eq	0x3c8 <filter_64ty_selector_val+0x1c8>
     2e4:      	ldr	x8, [x1]
     2e8:      	ldr	x9, [x0, #0x10]
     2ec:      	cmp	x8, x9
     2f0:      	b.le	0x368 <filter_64ty_selector_val+0x168>
     2f4:      	mov	w0, #0x1                // =1
     2f8:      	ret
     2fc:      	ldr	w10, [x0, #0x8]
     300:      	cmp	w10, #0x11
     304:      	b.lo	0x33c <filter_64ty_selector_val+0x13c>
     308:      	ldr	x11, [x0, #0x18]
     30c:      	cmp	x9, x11
     310:      	b.eq	0x250 <filter_64ty_selector_val+0x50>
     314:      	cmp	w10, #0x19
     318:      	b.lo	0x33c <filter_64ty_selector_val+0x13c>
     31c:      	ldr	x11, [x0, #0x20]
     320:      	cmp	x9, x11
     324:      	b.eq	0x250 <filter_64ty_selector_val+0x50>
     328:      	cmp	w10, #0x21
     32c:      	b.lo	0x33c <filter_64ty_selector_val+0x13c>
     330:      	ldr	x10, [x0, #0x28]
     334:      	cmp	x9, x10
     338:      	b.eq	0x250 <filter_64ty_selector_val+0x50>
     33c:      	cmp	w8, #0x25
     340:      	b.hi	0x550 <filter_64ty_selector_val+0x350>
     344:      	mov	w9, #0x1                // =1
     348:      	lsl	x8, x9, x8
     34c:      	mov	x9, #0x50               // =80
     350:      	movk	x9, #0xc00, lsl #16
     354:      	movk	x9, #0x20, lsl #32
     358:      	tst	x8, x9
     35c:      	b.eq	0x550 <filter_64ty_selector_val+0x350>
     360:      	mov	w0, #0x1                // =1
     364:      	ret
     368:      	ldr	w9, [x0, #0x8]
     36c:      	cmp	w9, #0x11
     370:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     374:      	ldr	x10, [x0, #0x18]
     378:      	cmp	x8, x10
     37c:      	b.le	0x438 <filter_64ty_selector_val+0x238>
     380:      	mov	w0, #0x1                // =1
     384:      	ret
     388:      	ldr	w9, [x0, #0x8]
     38c:      	cmp	w9, #0x11
     390:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     394:      	ldr	x10, [x0, #0x18]
     398:      	cmp	x8, x10
     39c:      	b.ge	0x454 <filter_64ty_selector_val+0x254>
     3a0:      	mov	w0, #0x1                // =1
     3a4:      	ret
     3a8:      	ldr	w9, [x0, #0x8]
     3ac:      	cmp	w9, #0x11
     3b0:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     3b4:      	ldr	x10, [x0, #0x18]
     3b8:      	tst	x8, x10
     3bc:      	b.eq	0x470 <filter_64ty_selector_val+0x270>
     3c0:      	mov	w0, #0x1                // =1
     3c4:      	ret
     3c8:      	ldr	x8, [x1]
     3cc:      	ldr	x9, [x0, #0x10]
     3d0:      	cmp	x8, x9
     3d4:      	b.ls	0x3f8 <filter_64ty_selector_val+0x1f8>
     3d8:      	mov	w0, #0x1                // =1
     3dc:      	ret
     3e0:      	ldr	x8, [x1]
     3e4:      	ldr	x9, [x0, #0x10]
     3e8:      	cmp	x8, x9
     3ec:      	b.hs	0x418 <filter_64ty_selector_val+0x218>
     3f0:      	mov	w0, #0x1                // =1
     3f4:      	ret
     3f8:      	ldr	w9, [x0, #0x8]
     3fc:      	cmp	w9, #0x11
     400:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     404:      	ldr	x10, [x0, #0x18]
     408:      	cmp	x8, x10
     40c:      	b.ls	0x48c <filter_64ty_selector_val+0x28c>
     410:      	mov	w0, #0x1                // =1
     414:      	ret
     418:      	ldr	w9, [x0, #0x8]
     41c:      	cmp	w9, #0x11
     420:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     424:      	ldr	x10, [x0, #0x18]
     428:      	cmp	x8, x10
     42c:      	b.hs	0x4a8 <filter_64ty_selector_val+0x2a8>
     430:      	mov	w0, #0x1                // =1
     434:      	ret
     438:      	cmp	w9, #0x19
     43c:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     440:      	ldr	x10, [x0, #0x20]
     444:      	cmp	x8, x10
     448:      	b.le	0x4c4 <filter_64ty_selector_val+0x2c4>
     44c:      	mov	w0, #0x1                // =1
     450:      	ret
     454:      	cmp	w9, #0x19
     458:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     45c:      	ldr	x10, [x0, #0x20]
     460:      	cmp	x8, x10
     464:      	b.ge	0x4e0 <filter_64ty_selector_val+0x2e0>
     468:      	mov	w0, #0x1                // =1
     46c:      	ret
     470:      	cmp	w9, #0x19
     474:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     478:      	ldr	x10, [x0, #0x20]
     47c:      	tst	x8, x10
     480:      	b.eq	0x4fc <filter_64ty_selector_val+0x2fc>
     484:      	mov	w0, #0x1                // =1
     488:      	ret
     48c:      	cmp	w9, #0x19
     490:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     494:      	ldr	x10, [x0, #0x20]
     498:      	cmp	x8, x10
     49c:      	b.ls	0x518 <filter_64ty_selector_val+0x318>
     4a0:      	mov	w0, #0x1                // =1
     4a4:      	ret
     4a8:      	cmp	w9, #0x19
     4ac:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     4b0:      	ldr	x10, [x0, #0x20]
     4b4:      	cmp	x8, x10
     4b8:      	b.hs	0x534 <filter_64ty_selector_val+0x334>
     4bc:      	mov	w0, #0x1                // =1
     4c0:      	ret
     4c4:      	cmp	w9, #0x21
     4c8:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     4cc:      	ldr	x9, [x0, #0x28]
     4d0:      	cmp	x8, x9
     4d4:      	b.le	0x550 <filter_64ty_selector_val+0x350>
     4d8:      	mov	w0, #0x1                // =1
     4dc:      	ret
     4e0:      	cmp	w9, #0x21
     4e4:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     4e8:      	ldr	x9, [x0, #0x28]
     4ec:      	cmp	x8, x9
     4f0:      	b.ge	0x550 <filter_64ty_selector_val+0x350>
     4f4:      	mov	w0, #0x1                // =1
     4f8:      	ret
     4fc:      	cmp	w9, #0x21
     500:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     504:      	ldr	x9, [x0, #0x28]
     508:      	tst	x8, x9
     50c:      	b.eq	0x550 <filter_64ty_selector_val+0x350>
     510:      	mov	w0, #0x1                // =1
     514:      	ret
     518:      	cmp	w9, #0x21
     51c:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     520:      	ldr	x9, [x0, #0x28]
     524:      	cmp	x8, x9
     528:      	b.ls	0x550 <filter_64ty_selector_val+0x350>
     52c:      	mov	w0, #0x1                // =1
     530:      	ret
     534:      	cmp	w9, #0x21
     538:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     53c:      	ldr	x9, [x0, #0x28]
     540:      	cmp	x8, x9
     544:      	b.hs	0x550 <filter_64ty_selector_val+0x350>
     548:      	mov	w0, #0x1                // =1
     54c:      	ret
     550:      	mov	x0, xzr
     554:      	ret
     558:      	nop
     55c:      	nop

0000000000000560 <filter_64ty_map>:
     560:      	sub	sp, sp, #0x30
     564:      	str	x30, [sp, #0x10]
     568:      	stp	x20, x19, [sp, #0x20]
     56c:      	ldrb	w8, [x0, #0x10]
     570:      	mov	x19, x0
     574:      	adrp	x0, 0x0 <filter_64ty>
     578:      	add	x9, sp, #0x1c
     57c:      	str	w8, [sp, #0x1c]
     580:      	mov	w8, #0x1                // =1
     584:      	mov	x20, x1
     588:      	add	x1, sp, #0x1c
     58c:      	ldr	x0, [x0]
     590:      	blr	x8
     594:      	cbz	x0, 0x5e4 <filter_64ty_map+0x84>
     598:      	ldr	x8, [x20]
     59c:      	add	x9, sp, #0x8
     5a0:      	add	x1, sp, #0x8
     5a4:      	str	x8, [sp, #0x8]
     5a8:      	mov	w8, #0x1                // =1
     5ac:      	blr	x8
     5b0:      	ldr	w8, [x19, #0x4]
     5b4:      	cmp	w8, #0xb
     5b8:      	b.eq	0x5d0 <filter_64ty_map+0x70>
     5bc:      	cmp	w8, #0xa
     5c0:      	b.ne	0x5dc <filter_64ty_map+0x7c>
     5c4:      	cmp	x0, #0x0
     5c8:      	cset	w8, ne
     5cc:      	b	0x5e0 <filter_64ty_map+0x80>
     5d0:      	cmp	x0, #0x0
     5d4:      	cset	w8, eq
     5d8:      	b	0x5e0 <filter_64ty_map+0x80>
     5dc:      	mov	w8, wzr
     5e0:      	mov	w0, w8
     5e4:      	ldp	x20, x19, [sp, #0x20]
     5e8:      	ldr	x30, [sp, #0x10]
     5ec:      	add	sp, sp, #0x30
     5f0:      	ret
     5f4:      	nop
     5f8:      	nop
     5fc:      	nop

0000000000000600 <filter_64ty_range>:
     600:      	ldr	w9, [x0, #0xc]
     604:      	ldr	w8, [x0, #0x4]
     608:      	mov	w10, #0x1               // =1
     60c:      	cmp	w9, #0xc
     610:      	lsl	w9, w10, w9
     614:      	mov	w10, #0x1402            // =5122
     618:      	and	w9, w9, w10
     61c:      	ccmp	w9, #0x0, #0x4, ls
     620:      	b.eq	0x720 <filter_64ty_range+0x120>
     624:      	ldr	x10, [x1]
     628:      	cmp	w8, #0x1f
     62c:      	b.ne	0x6b4 <filter_64ty_range+0xb4>
     630:      	ldr	x9, [x0, #0x10]
     634:      	cmp	x9, x10
     638:      	b.gt	0x648 <filter_64ty_range+0x48>
     63c:      	ldr	x9, [x0, #0x18]
     640:      	cmp	x10, x9
     644:      	b.le	0x744 <filter_64ty_range+0x144>
     648:      	ldr	w9, [x0, #0x8]
     64c:      	cmp	w9, #0x19
     650:      	b.lo	0x830 <filter_64ty_range+0x230>
     654:      	ldr	x11, [x0, #0x20]
     658:      	cmp	x11, x10
     65c:      	b.gt	0x66c <filter_64ty_range+0x6c>
     660:      	ldr	x11, [x0, #0x28]
     664:      	cmp	x10, x11
     668:      	b.le	0x744 <filter_64ty_range+0x144>
     66c:      	cmp	w9, #0x29
     670:      	b.lo	0x830 <filter_64ty_range+0x230>
     674:      	ldr	x11, [x0, #0x30]
     678:      	cmp	x11, x10
     67c:      	b.gt	0x68c <filter_64ty_range+0x8c>
     680:      	ldr	x11, [x0, #0x38]
     684:      	cmp	x10, x11
     688:      	b.le	0x744 <filter_64ty_range+0x144>
     68c:      	cmp	w9, #0x39
     690:      	b.lo	0x830 <filter_64ty_range+0x230>
     694:      	ldr	x11, [x0, #0x40]
     698:      	mov	w9, wzr
     69c:      	cmp	x11, x10
     6a0:      	b.gt	0x820 <filter_64ty_range+0x220>
     6a4:      	ldr	x11, [x0, #0x48]
     6a8:      	cmp	x10, x11
     6ac:      	b.le	0x744 <filter_64ty_range+0x144>
     6b0:      	b	0x820 <filter_64ty_range+0x220>
     6b4:      	ldp	x9, x12, [x0, #0x10]
     6b8:      	cmp	x9, x10
     6bc:      	ldr	w11, [x0, #0x8]
     6c0:      	ccmp	x10, x12, #0x0, le
     6c4:      	cset	w9, le
     6c8:      	cmp	w11, #0x19
     6cc:      	b.lo	0x820 <filter_64ty_range+0x220>
     6d0:      	ldp	x12, x13, [x0, #0x20]
     6d4:      	cmp	x12, x10
     6d8:      	ccmp	x10, x13, #0x0, le
     6dc:      	csinc	w9, w9, wzr, gt
     6e0:      	cmp	w11, #0x29
     6e4:      	b.lo	0x820 <filter_64ty_range+0x220>
     6e8:      	ldp	x12, x13, [x0, #0x30]
     6ec:      	cmp	x12, x10
     6f0:      	ccmp	x10, x13, #0x0, le
     6f4:      	csinc	w9, w9, wzr, gt
     6f8:      	cmp	w11, #0x39
     6fc:      	b.lo	0x820 <filter_64ty_range+0x220>
     700:      	ldp	x11, x12, [x0, #0x40]
     704:      	cmp	x11, x10
     708:      	ccmp	x10, x12, #0x0, le
     70c:      	csinc	w9, w9, wzr, gt
     710:      	cmp	w8, #0x20
     714:      	eor	w8, w9, #0x1
     718:      	csel	w0, wzr, w8, ne
     71c:      	ret
     720:      	ldr	x10, [x1]
     724:      	cmp	w8, #0x1f
     728:      	b.ne	0x74c <filter_64ty_range+0x14c>
     72c:      	ldr	x9, [x0, #0x10]
     730:      	cmp	x9, x10
     734:      	b.hi	0x7b8 <filter_64ty_range+0x1b8>
     738:      	ldr	x9, [x0, #0x18]
     73c:      	cmp	x10, x9
     740:      	b.hi	0x7b8 <filter_64ty_range+0x1b8>
     744:      	mov	w0, #0x1                // =1
     748:      	ret
     74c:      	ldp	x9, x12, [x0, #0x10]
     750:      	cmp	x9, x10
     754:      	ldr	w11, [x0, #0x8]
     758:      	ccmp	x10, x12, #0x2, ls
     75c:      	cset	w9, ls
     760:      	cmp	w11, #0x19
     764:      	b.lo	0x820 <filter_64ty_range+0x220>
     768:      	ldp	x12, x13, [x0, #0x20]
     76c:      	cmp	x12, x10
     770:      	ccmp	x10, x13, #0x2, ls
     774:      	csinc	w9, w9, wzr, hi
     778:      	cmp	w11, #0x29
     77c:      	b.lo	0x820 <filter_64ty_range+0x220>
     780:      	ldp	x12, x13, [x0, #0x30]
     784:      	cmp	x12, x10
     788:      	ccmp	x10, x13, #0x2, ls
     78c:      	csinc	w9, w9, wzr, hi
     790:      	cmp	w11, #0x39
     794:      	b.lo	0x820 <filter_64ty_range+0x220>
     798:      	ldp	x11, x12, [x0, #0x40]
     79c:      	cmp	x11, x10
     7a0:      	ccmp	x10, x12, #0x2, ls
     7a4:      	csinc	w9, w9, wzr, hi
     7a8:      	cmp	w8, #0x20
     7ac:      	eor	w8, w9, #0x1
     7b0:      	csel	w0, wzr, w8, ne
     7b4:      	ret
     7b8:      	ldr	w9, [x0, #0x8]
     7bc:      	cmp	w9, #0x19
     7c0:      	b.lo	0x830 <filter_64ty_range+0x230>
     7c4:      	ldr	x11, [x0, #0x20]
     7c8:      	cmp	x11, x10
     7cc:      	b.hi	0x7dc <filter_64ty_range+0x1dc>
     7d0:      	ldr	x11, [x0, #0x28]
     7d4:      	cmp	x10, x11
     7d8:      	b.ls	0x744 <filter_64ty_range+0x144>
     7dc:      	cmp	w9, #0x29
     7e0:      	b.lo	0x830 <filter_64ty_range+0x230>
     7e4:      	ldr	x11, [x0, #0x30]
     7e8:      	cmp	x11, x10
     7ec:      	b.hi	0x7fc <filter_64ty_range+0x1fc>
     7f0:      	ldr	x11, [x0, #0x38]
     7f4:      	cmp	x10, x11
     7f8:      	b.ls	0x744 <filter_64ty_range+0x144>
     7fc:      	cmp	w9, #0x39
     800:      	b.lo	0x830 <filter_64ty_range+0x230>
     804:      	ldr	x11, [x0, #0x40]
     808:      	mov	w9, wzr
     80c:      	cmp	x11, x10
     810:      	b.hi	0x820 <filter_64ty_range+0x220>
     814:      	ldr	x11, [x0, #0x48]
     818:      	cmp	x10, x11
     81c:      	b.ls	0x744 <filter_64ty_range+0x144>
     820:      	cmp	w8, #0x20
     824:      	eor	w8, w9, #0x1
     828:      	csel	w0, wzr, w8, ne
     82c:      	ret
     830:      	mov	w9, wzr
     834:      	cmp	w8, #0x20
     838:      	eor	w8, w9, #0x1
     83c:      	csel	w0, wzr, w8, ne
     840:      	ret
     844:      	nop
     848:      	nop
     84c:      	nop

0000000000000850 <filter_32ty_selector_val>:
     850:      	ldr	w8, [x0, #0x4]
     854:      	cmp	w8, #0x25
     858:      	b.hi	0x8cc <filter_32ty_selector_val+0x7c>
     85c:      	mov	x10, #0x40              // =64
     860:      	mov	w9, #0x1                // =1
     864:      	movk	x10, #0xc00, lsl #16
     868:      	lsl	x9, x9, x8
     86c:      	movk	x10, #0x20, lsl #32
     870:      	tst	x9, x10
     874:      	b.eq	0x880 <filter_32ty_selector_val+0x30>
     878:      	mov	w0, #0x1                // =1
     87c:      	ret
     880:      	mov	w9, #0x1                // =1
     884:      	lsl	x9, x9, x8
     888:      	tst	x9, #0x18
     88c:      	b.eq	0x8ac <filter_32ty_selector_val+0x5c>
     890:      	ldr	w9, [x1]
     894:      	ldr	w10, [x0, #0x10]
     898:      	cmp	w9, w10
     89c:      	b.ne	0x94c <filter_32ty_selector_val+0xfc>
     8a0:      	cmp	w8, #0x3
     8a4:      	cset	w0, eq
     8a8:      	ret
     8ac:      	cmp	x8, #0xc
     8b0:      	b.ne	0x8cc <filter_32ty_selector_val+0x7c>
     8b4:      	ldr	w8, [x1]
     8b8:      	ldr	w9, [x0, #0x10]
     8bc:      	tst	w8, w9
     8c0:      	b.eq	0x9f8 <filter_32ty_selector_val+0x1a8>
     8c4:      	mov	w0, #0x1                // =1
     8c8:      	ret
     8cc:      	cmp	w8, #0x1
     8d0:      	b.eq	0x914 <filter_32ty_selector_val+0xc4>
     8d4:      	cmp	w8, #0x2
     8d8:      	b.ne	0xba0 <filter_32ty_selector_val+0x350>
     8dc:      	ldr	w8, [x0, #0xc]
     8e0:      	cmp	w8, #0xc
     8e4:      	b.hi	0xa30 <filter_32ty_selector_val+0x1e0>
     8e8:      	mov	w9, #0x1                // =1
     8ec:      	lsl	w8, w9, w8
     8f0:      	mov	w9, #0x1402             // =5122
     8f4:      	tst	w8, w9
     8f8:      	b.eq	0xa30 <filter_32ty_selector_val+0x1e0>
     8fc:      	ldr	w8, [x1]
     900:      	ldr	w9, [x0, #0x10]
     904:      	cmp	w8, w9
     908:      	b.ge	0x9d8 <filter_32ty_selector_val+0x188>
     90c:      	mov	w0, #0x1                // =1
     910:      	ret
     914:      	ldr	w8, [x0, #0xc]
     918:      	cmp	w8, #0xc
     91c:      	b.hi	0xa18 <filter_32ty_selector_val+0x1c8>
     920:      	mov	w9, #0x1                // =1
     924:      	lsl	w8, w9, w8
     928:      	mov	w9, #0x1402             // =5122
     92c:      	tst	w8, w9
     930:      	b.eq	0xa18 <filter_32ty_selector_val+0x1c8>
     934:      	ldr	w8, [x1]
     938:      	ldr	w9, [x0, #0x10]
     93c:      	cmp	w8, w9
     940:      	b.le	0x9b8 <filter_32ty_selector_val+0x168>
     944:      	mov	w0, #0x1                // =1
     948:      	ret
     94c:      	ldr	w10, [x0, #0x8]
     950:      	cmp	w10, #0xd
     954:      	b.lo	0x98c <filter_32ty_selector_val+0x13c>
     958:      	ldr	w11, [x0, #0x14]
     95c:      	cmp	w9, w11
     960:      	b.eq	0x8a0 <filter_32ty_selector_val+0x50>
     964:      	cmp	w10, #0x11
     968:      	b.lo	0x98c <filter_32ty_selector_val+0x13c>
     96c:      	ldr	w11, [x0, #0x18]
     970:      	cmp	w9, w11
     974:      	b.eq	0x8a0 <filter_32ty_selector_val+0x50>
     978:      	cmp	w10, #0x15
     97c:      	b.lo	0x98c <filter_32ty_selector_val+0x13c>
     980:      	ldr	w10, [x0, #0x1c]
     984:      	cmp	w9, w10
     988:      	b.eq	0x8a0 <filter_32ty_selector_val+0x50>
     98c:      	cmp	w8, #0x25
     990:      	b.hi	0xba0 <filter_32ty_selector_val+0x350>
     994:      	mov	w9, #0x1                // =1
     998:      	lsl	x8, x9, x8
     99c:      	mov	x9, #0x50               // =80
     9a0:      	movk	x9, #0xc00, lsl #16
     9a4:      	movk	x9, #0x20, lsl #32
     9a8:      	tst	x8, x9
     9ac:      	b.eq	0xba0 <filter_32ty_selector_val+0x350>
     9b0:      	mov	w0, #0x1                // =1
     9b4:      	ret
     9b8:      	ldr	w9, [x0, #0x8]
     9bc:      	cmp	w9, #0xd
     9c0:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     9c4:      	ldr	w10, [x0, #0x14]
     9c8:      	cmp	w8, w10
     9cc:      	b.le	0xa88 <filter_32ty_selector_val+0x238>
     9d0:      	mov	w0, #0x1                // =1
     9d4:      	ret
     9d8:      	ldr	w9, [x0, #0x8]
     9dc:      	cmp	w9, #0xd
     9e0:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     9e4:      	ldr	w10, [x0, #0x14]
     9e8:      	cmp	w8, w10
     9ec:      	b.ge	0xaa4 <filter_32ty_selector_val+0x254>
     9f0:      	mov	w0, #0x1                // =1
     9f4:      	ret
     9f8:      	ldr	w9, [x0, #0x8]
     9fc:      	cmp	w9, #0xd
     a00:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     a04:      	ldr	w10, [x0, #0x14]
     a08:      	tst	w8, w10
     a0c:      	b.eq	0xac0 <filter_32ty_selector_val+0x270>
     a10:      	mov	w0, #0x1                // =1
     a14:      	ret
     a18:      	ldr	w8, [x1]
     a1c:      	ldr	w9, [x0, #0x10]
     a20:      	cmp	w8, w9
     a24:      	b.ls	0xa48 <filter_32ty_selector_val+0x1f8>
     a28:      	mov	w0, #0x1                // =1
     a2c:      	ret
     a30:      	ldr	w8, [x1]
     a34:      	ldr	w9, [x0, #0x10]
     a38:      	cmp	w8, w9
     a3c:      	b.hs	0xa68 <filter_32ty_selector_val+0x218>
     a40:      	mov	w0, #0x1                // =1
     a44:      	ret
     a48:      	ldr	w9, [x0, #0x8]
     a4c:      	cmp	w9, #0xd
     a50:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     a54:      	ldr	w10, [x0, #0x14]
     a58:      	cmp	w8, w10
     a5c:      	b.ls	0xadc <filter_32ty_selector_val+0x28c>
     a60:      	mov	w0, #0x1                // =1
     a64:      	ret
     a68:      	ldr	w9, [x0, #0x8]
     a6c:      	cmp	w9, #0xd
     a70:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     a74:      	ldr	w10, [x0, #0x14]
     a78:      	cmp	w8, w10
     a7c:      	b.hs	0xaf8 <filter_32ty_selector_val+0x2a8>
     a80:      	mov	w0, #0x1                // =1
     a84:      	ret
     a88:      	cmp	w9, #0x11
     a8c:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     a90:      	ldr	w10, [x0, #0x18]
     a94:      	cmp	w8, w10
     a98:      	b.le	0xb14 <filter_32ty_selector_val+0x2c4>
     a9c:      	mov	w0, #0x1                // =1
     aa0:      	ret
     aa4:      	cmp	w9, #0x11
     aa8:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     aac:      	ldr	w10, [x0, #0x18]
     ab0:      	cmp	w8, w10
     ab4:      	b.ge	0xb30 <filter_32ty_selector_val+0x2e0>
     ab8:      	mov	w0, #0x1                // =1
     abc:      	ret
     ac0:      	cmp	w9, #0x11
     ac4:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     ac8:      	ldr	w10, [x0, #0x18]
     acc:      	tst	w8, w10
     ad0:      	b.eq	0xb4c <filter_32ty_selector_val+0x2fc>
     ad4:      	mov	w0, #0x1                // =1
     ad8:      	ret
     adc:      	cmp	w9, #0x11
     ae0:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     ae4:      	ldr	w10, [x0, #0x18]
     ae8:      	cmp	w8, w10
     aec:      	b.ls	0xb68 <filter_32ty_selector_val+0x318>
     af0:      	mov	w0, #0x1                // =1
     af4:      	ret
     af8:      	cmp	w9, #0x11
     afc:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     b00:      	ldr	w10, [x0, #0x18]
     b04:      	cmp	w8, w10
     b08:      	b.hs	0xb84 <filter_32ty_selector_val+0x334>
     b0c:      	mov	w0, #0x1                // =1
     b10:      	ret
     b14:      	cmp	w9, #0x15
     b18:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     b1c:      	ldr	w9, [x0, #0x1c]
     b20:      	cmp	w8, w9
     b24:      	b.le	0xba0 <filter_32ty_selector_val+0x350>
     b28:      	mov	w0, #0x1                // =1
     b2c:      	ret
     b30:      	cmp	w9, #0x15
     b34:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     b38:      	ldr	w9, [x0, #0x1c]
     b3c:      	cmp	w8, w9
     b40:      	b.ge	0xba0 <filter_32ty_selector_val+0x350>
     b44:      	mov	w0, #0x1                // =1
     b48:      	ret
     b4c:      	cmp	w9, #0x15
     b50:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     b54:      	ldr	w9, [x0, #0x1c]
     b58:      	tst	w8, w9
     b5c:      	b.eq	0xba0 <filter_32ty_selector_val+0x350>
     b60:      	mov	w0, #0x1                // =1
     b64:      	ret
     b68:      	cmp	w9, #0x15
     b6c:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     b70:      	ldr	w9, [x0, #0x1c]
     b74:      	cmp	w8, w9
     b78:      	b.ls	0xba0 <filter_32ty_selector_val+0x350>
     b7c:      	mov	w0, #0x1                // =1
     b80:      	ret
     b84:      	cmp	w9, #0x15
     b88:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     b8c:      	ldr	w9, [x0, #0x1c]
     b90:      	cmp	w8, w9
     b94:      	b.hs	0xba0 <filter_32ty_selector_val+0x350>
     b98:      	mov	w0, #0x1                // =1
     b9c:      	ret
     ba0:      	mov	x0, xzr
     ba4:      	ret
     ba8:      	nop
     bac:      	nop

0000000000000bb0 <filter_32ty_map>:
     bb0:      	sub	sp, sp, #0x30
     bb4:      	str	x30, [sp, #0x10]
     bb8:      	stp	x20, x19, [sp, #0x20]
     bbc:      	ldrb	w8, [x0, #0x10]
     bc0:      	mov	x19, x0
     bc4:      	adrp	x0, 0x0 <filter_64ty>
     bc8:      	add	x9, sp, #0x1c
     bcc:      	str	w8, [sp, #0x1c]
     bd0:      	mov	w8, #0x1                // =1
     bd4:      	mov	x20, x1
     bd8:      	add	x1, sp, #0x1c
     bdc:      	ldr	x0, [x0]
     be0:      	blr	x8
     be4:      	cbz	x0, 0xc58 <filter_32ty_map+0xa8>
     be8:      	ldr	w8, [x20]
     bec:      	mov	w9, #0x1                // =1
     bf0:      	add	x1, sp, #0x8
     bf4:      	mov	w20, #0x1               // =1
     bf8:      	str	x8, [sp, #0x8]
     bfc:      	add	x8, sp, #0x8
     c00:      	blr	x9
     c04:      	ldr	w9, [x19, #0x4]
     c08:      	mov	w8, wzr
     c0c:      	cmp	w9, #0x1d
     c10:      	b.hi	0xc54 <filter_32ty_map+0xa4>
     c14:      	mov	w11, #0x8400            // =33792
     c18:      	lsl	w10, w20, w9
     c1c:      	movk	w11, #0x3003, lsl #16
     c20:      	tst	w10, w11
     c24:      	b.eq	0xc34 <filter_32ty_map+0x84>
     c28:      	cmp	x0, #0x0
     c2c:      	cset	w8, ne
     c30:      	b	0xc54 <filter_32ty_map+0xa4>
     c34:      	mov	w10, #0x1               // =1
     c38:      	lsl	w9, w10, w9
     c3c:      	mov	w10, #0x800             // =2048
     c40:      	movk	w10, #0xc, lsl #16
     c44:      	tst	w9, w10
     c48:      	b.eq	0xc54 <filter_32ty_map+0xa4>
     c4c:      	cmp	x0, #0x0
     c50:      	cset	w8, eq
     c54:      	mov	w0, w8
     c58:      	ldp	x20, x19, [sp, #0x20]
     c5c:      	ldr	x30, [sp, #0x10]
     c60:      	add	sp, sp, #0x30
     c64:      	ret
     c68:      	nop
     c6c:      	nop

0000000000000c70 <filter_32ty_range>:
     c70:      	ldr	w9, [x0, #0xc]
     c74:      	ldr	w8, [x0, #0x4]
     c78:      	mov	w10, #0x1               // =1
     c7c:      	cmp	w9, #0xc
     c80:      	lsl	w9, w10, w9
     c84:      	mov	w10, #0x1402            // =5122
     c88:      	and	w9, w9, w10
     c8c:      	ccmp	w9, #0x0, #0x4, ls
     c90:      	b.eq	0xd90 <filter_32ty_range+0x120>
     c94:      	ldr	w10, [x1]
     c98:      	cmp	w8, #0x1f
     c9c:      	b.ne	0xd24 <filter_32ty_range+0xb4>
     ca0:      	ldr	w9, [x0, #0x10]
     ca4:      	cmp	w9, w10
     ca8:      	b.gt	0xcb8 <filter_32ty_range+0x48>
     cac:      	ldr	w9, [x0, #0x14]
     cb0:      	cmp	w10, w9
     cb4:      	b.le	0xdb4 <filter_32ty_range+0x144>
     cb8:      	ldr	w9, [x0, #0x8]
     cbc:      	cmp	w9, #0x11
     cc0:      	b.lo	0xea0 <filter_32ty_range+0x230>
     cc4:      	ldr	w11, [x0, #0x18]
     cc8:      	cmp	w11, w10
     ccc:      	b.gt	0xcdc <filter_32ty_range+0x6c>
     cd0:      	ldr	w11, [x0, #0x1c]
     cd4:      	cmp	w10, w11
     cd8:      	b.le	0xdb4 <filter_32ty_range+0x144>
     cdc:      	cmp	w9, #0x19
     ce0:      	b.lo	0xea0 <filter_32ty_range+0x230>
     ce4:      	ldr	w11, [x0, #0x20]
     ce8:      	cmp	w11, w10
     cec:      	b.gt	0xcfc <filter_32ty_range+0x8c>
     cf0:      	ldr	w11, [x0, #0x24]
     cf4:      	cmp	w10, w11
     cf8:      	b.le	0xdb4 <filter_32ty_range+0x144>
     cfc:      	cmp	w9, #0x21
     d00:      	b.lo	0xea0 <filter_32ty_range+0x230>
     d04:      	ldr	w11, [x0, #0x28]
     d08:      	mov	w9, wzr
     d0c:      	cmp	w11, w10
     d10:      	b.gt	0xe90 <filter_32ty_range+0x220>
     d14:      	ldr	w11, [x0, #0x2c]
     d18:      	cmp	w10, w11
     d1c:      	b.le	0xdb4 <filter_32ty_range+0x144>
     d20:      	b	0xe90 <filter_32ty_range+0x220>
     d24:      	ldp	w9, w12, [x0, #0x10]
     d28:      	ldr	w11, [x0, #0x8]
     d2c:      	cmp	w9, w10
     d30:      	ccmp	w10, w12, #0x0, le
     d34:      	cset	w9, le
     d38:      	cmp	w11, #0x11
     d3c:      	b.lo	0xe90 <filter_32ty_range+0x220>
     d40:      	ldp	w12, w13, [x0, #0x18]
     d44:      	cmp	w12, w10
     d48:      	ccmp	w10, w13, #0x0, le
     d4c:      	csinc	w9, w9, wzr, gt
     d50:      	cmp	w11, #0x19
     d54:      	b.lo	0xe90 <filter_32ty_range+0x220>
     d58:      	ldp	w12, w13, [x0, #0x20]
     d5c:      	cmp	w12, w10
     d60:      	ccmp	w10, w13, #0x0, le
     d64:      	csinc	w9, w9, wzr, gt
     d68:      	cmp	w11, #0x21
     d6c:      	b.lo	0xe90 <filter_32ty_range+0x220>
     d70:      	ldp	w11, w12, [x0, #0x28]
     d74:      	cmp	w11, w10
     d78:      	ccmp	w10, w12, #0x0, le
     d7c:      	csinc	w9, w9, wzr, gt
     d80:      	cmp	w8, #0x20
     d84:      	eor	w8, w9, #0x1
     d88:      	csel	w0, wzr, w8, ne
     d8c:      	ret
     d90:      	ldr	w10, [x1]
     d94:      	cmp	w8, #0x1f
     d98:      	b.ne	0xdbc <filter_32ty_range+0x14c>
     d9c:      	ldr	w9, [x0, #0x10]
     da0:      	cmp	w9, w10
     da4:      	b.hi	0xe28 <filter_32ty_range+0x1b8>
     da8:      	ldr	w9, [x0, #0x14]
     dac:      	cmp	w10, w9
     db0:      	b.hi	0xe28 <filter_32ty_range+0x1b8>
     db4:      	mov	w0, #0x1                // =1
     db8:      	ret
     dbc:      	ldp	w9, w12, [x0, #0x10]
     dc0:      	ldr	w11, [x0, #0x8]
     dc4:      	cmp	w9, w10
     dc8:      	ccmp	w10, w12, #0x2, ls
     dcc:      	cset	w9, ls
     dd0:      	cmp	w11, #0x11
     dd4:      	b.lo	0xe90 <filter_32ty_range+0x220>
     dd8:      	ldp	w12, w13, [x0, #0x18]
     ddc:      	cmp	w12, w10
     de0:      	ccmp	w10, w13, #0x2, ls
     de4:      	csinc	w9, w9, wzr, hi
     de8:      	cmp	w11, #0x19
     dec:      	b.lo	0xe90 <filter_32ty_range+0x220>
     df0:      	ldp	w12, w13, [x0, #0x20]
     df4:      	cmp	w12, w10
     df8:      	ccmp	w10, w13, #0x2, ls
     dfc:      	csinc	w9, w9, wzr, hi
     e00:      	cmp	w11, #0x21
     e04:      	b.lo	0xe90 <filter_32ty_range+0x220>
     e08:      	ldp	w11, w12, [x0, #0x28]
     e0c:      	cmp	w11, w10
     e10:      	ccmp	w10, w12, #0x2, ls
     e14:      	csinc	w9, w9, wzr, hi
     e18:      	cmp	w8, #0x20
     e1c:      	eor	w8, w9, #0x1
     e20:      	csel	w0, wzr, w8, ne
     e24:      	ret
     e28:      	ldr	w9, [x0, #0x8]
     e2c:      	cmp	w9, #0x11
     e30:      	b.lo	0xea0 <filter_32ty_range+0x230>
     e34:      	ldr	w11, [x0, #0x18]
     e38:      	cmp	w11, w10
     e3c:      	b.hi	0xe4c <filter_32ty_range+0x1dc>
     e40:      	ldr	w11, [x0, #0x1c]
     e44:      	cmp	w10, w11
     e48:      	b.ls	0xdb4 <filter_32ty_range+0x144>
     e4c:      	cmp	w9, #0x19
     e50:      	b.lo	0xea0 <filter_32ty_range+0x230>
     e54:      	ldr	w11, [x0, #0x20]
     e58:      	cmp	w11, w10
     e5c:      	b.hi	0xe6c <filter_32ty_range+0x1fc>
     e60:      	ldr	w11, [x0, #0x24]
     e64:      	cmp	w10, w11
     e68:      	b.ls	0xdb4 <filter_32ty_range+0x144>
     e6c:      	cmp	w9, #0x21
     e70:      	b.lo	0xea0 <filter_32ty_range+0x230>
     e74:      	ldr	w11, [x0, #0x28]
     e78:      	mov	w9, wzr
     e7c:      	cmp	w11, w10
     e80:      	b.hi	0xe90 <filter_32ty_range+0x220>
     e84:      	ldr	w11, [x0, #0x2c]
     e88:      	cmp	w10, w11
     e8c:      	b.ls	0xdb4 <filter_32ty_range+0x144>
     e90:      	cmp	w8, #0x20
     e94:      	eor	w8, w9, #0x1
     e98:      	csel	w0, wzr, w8, ne
     e9c:      	ret
     ea0:      	mov	w9, wzr
     ea4:      	cmp	w8, #0x20
     ea8:      	eor	w8, w9, #0x1
     eac:      	csel	w0, wzr, w8, ne
     eb0:      	ret
     eb4:      	nop
     eb8:      	nop
     ebc:      	nop

0000000000000ec0 <filter_16ty_selector_val>:
     ec0:      	ldr	w8, [x0, #0x4]
     ec4:      	cmp	w8, #0x25
     ec8:      	b.hi	0xf3c <filter_16ty_selector_val+0x7c>
     ecc:      	mov	x10, #0x40              // =64
     ed0:      	mov	w9, #0x1                // =1
     ed4:      	movk	x10, #0xc00, lsl #16
     ed8:      	lsl	x9, x9, x8
     edc:      	movk	x10, #0x20, lsl #32
     ee0:      	tst	x9, x10
     ee4:      	b.eq	0xef0 <filter_16ty_selector_val+0x30>
     ee8:      	mov	w0, #0x1                // =1
     eec:      	ret
     ef0:      	mov	w9, #0x1                // =1
     ef4:      	lsl	x9, x9, x8
     ef8:      	tst	x9, #0x18
     efc:      	b.eq	0xf1c <filter_16ty_selector_val+0x5c>
     f00:      	ldrh	w9, [x1]
     f04:      	ldr	w10, [x0, #0x10]
     f08:      	cmp	w10, w9
     f0c:      	b.ne	0xfbc <filter_16ty_selector_val+0xfc>
     f10:      	cmp	w8, #0x3
     f14:      	cset	w0, eq
     f18:      	ret
     f1c:      	cmp	x8, #0xc
     f20:      	b.ne	0xf3c <filter_16ty_selector_val+0x7c>
     f24:      	ldrh	w8, [x1]
     f28:      	ldr	w9, [x0, #0x10]
     f2c:      	tst	w9, w8
     f30:      	b.eq	0x1068 <filter_16ty_selector_val+0x1a8>
     f34:      	mov	w0, #0x1                // =1
     f38:      	ret
     f3c:      	cmp	w8, #0x1
     f40:      	b.eq	0xf84 <filter_16ty_selector_val+0xc4>
     f44:      	cmp	w8, #0x2
     f48:      	b.ne	0x1210 <filter_16ty_selector_val+0x350>
     f4c:      	ldr	w8, [x0, #0xc]
     f50:      	cmp	w8, #0xc
     f54:      	b.hi	0x10a0 <filter_16ty_selector_val+0x1e0>
     f58:      	mov	w9, #0x1                // =1
     f5c:      	lsl	w8, w9, w8
     f60:      	mov	w9, #0x1402             // =5122
     f64:      	tst	w8, w9
     f68:      	b.eq	0x10a0 <filter_16ty_selector_val+0x1e0>
     f6c:      	ldrsh	w8, [x1]
     f70:      	ldr	w9, [x0, #0x10]
     f74:      	cmp	w9, w8
     f78:      	b.le	0x1048 <filter_16ty_selector_val+0x188>
     f7c:      	mov	w0, #0x1                // =1
     f80:      	ret
     f84:      	ldr	w8, [x0, #0xc]
     f88:      	cmp	w8, #0xc
     f8c:      	b.hi	0x1088 <filter_16ty_selector_val+0x1c8>
     f90:      	mov	w9, #0x1                // =1
     f94:      	lsl	w8, w9, w8
     f98:      	mov	w9, #0x1402             // =5122
     f9c:      	tst	w8, w9
     fa0:      	b.eq	0x1088 <filter_16ty_selector_val+0x1c8>
     fa4:      	ldrsh	w8, [x1]
     fa8:      	ldr	w9, [x0, #0x10]
     fac:      	cmp	w9, w8
     fb0:      	b.ge	0x1028 <filter_16ty_selector_val+0x168>
     fb4:      	mov	w0, #0x1                // =1
     fb8:      	ret
     fbc:      	ldr	w10, [x0, #0x8]
     fc0:      	cmp	w10, #0xd
     fc4:      	b.lo	0xffc <filter_16ty_selector_val+0x13c>
     fc8:      	ldr	w11, [x0, #0x14]
     fcc:      	cmp	w11, w9
     fd0:      	b.eq	0xf10 <filter_16ty_selector_val+0x50>
     fd4:      	cmp	w10, #0x11
     fd8:      	b.lo	0xffc <filter_16ty_selector_val+0x13c>
     fdc:      	ldr	w11, [x0, #0x18]
     fe0:      	cmp	w11, w9
     fe4:      	b.eq	0xf10 <filter_16ty_selector_val+0x50>
     fe8:      	cmp	w10, #0x15
     fec:      	b.lo	0xffc <filter_16ty_selector_val+0x13c>
     ff0:      	ldr	w10, [x0, #0x1c]
     ff4:      	cmp	w10, w9
     ff8:      	b.eq	0xf10 <filter_16ty_selector_val+0x50>
     ffc:      	cmp	w8, #0x25
    1000:      	b.hi	0x1210 <filter_16ty_selector_val+0x350>
    1004:      	mov	w9, #0x1                // =1
    1008:      	lsl	x8, x9, x8
    100c:      	mov	x9, #0x50               // =80
    1010:      	movk	x9, #0xc00, lsl #16
    1014:      	movk	x9, #0x20, lsl #32
    1018:      	tst	x8, x9
    101c:      	b.eq	0x1210 <filter_16ty_selector_val+0x350>
    1020:      	mov	w0, #0x1                // =1
    1024:      	ret
    1028:      	ldr	w9, [x0, #0x8]
    102c:      	cmp	w9, #0xd
    1030:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    1034:      	ldr	w10, [x0, #0x14]
    1038:      	cmp	w10, w8
    103c:      	b.ge	0x10f8 <filter_16ty_selector_val+0x238>
    1040:      	mov	w0, #0x1                // =1
    1044:      	ret
    1048:      	ldr	w9, [x0, #0x8]
    104c:      	cmp	w9, #0xd
    1050:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    1054:      	ldr	w10, [x0, #0x14]
    1058:      	cmp	w10, w8
    105c:      	b.le	0x1114 <filter_16ty_selector_val+0x254>
    1060:      	mov	w0, #0x1                // =1
    1064:      	ret
    1068:      	ldr	w9, [x0, #0x8]
    106c:      	cmp	w9, #0xd
    1070:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    1074:      	ldr	w10, [x0, #0x14]
    1078:      	tst	w10, w8
    107c:      	b.eq	0x1130 <filter_16ty_selector_val+0x270>
    1080:      	mov	w0, #0x1                // =1
    1084:      	ret
    1088:      	ldrh	w8, [x1]
    108c:      	ldr	w9, [x0, #0x10]
    1090:      	cmp	w9, w8
    1094:      	b.hs	0x10b8 <filter_16ty_selector_val+0x1f8>
    1098:      	mov	w0, #0x1                // =1
    109c:      	ret
    10a0:      	ldrh	w8, [x1]
    10a4:      	ldr	w9, [x0, #0x10]
    10a8:      	cmp	w9, w8
    10ac:      	b.ls	0x10d8 <filter_16ty_selector_val+0x218>
    10b0:      	mov	w0, #0x1                // =1
    10b4:      	ret
    10b8:      	ldr	w9, [x0, #0x8]
    10bc:      	cmp	w9, #0xd
    10c0:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    10c4:      	ldr	w10, [x0, #0x14]
    10c8:      	cmp	w10, w8
    10cc:      	b.hs	0x114c <filter_16ty_selector_val+0x28c>
    10d0:      	mov	w0, #0x1                // =1
    10d4:      	ret
    10d8:      	ldr	w9, [x0, #0x8]
    10dc:      	cmp	w9, #0xd
    10e0:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    10e4:      	ldr	w10, [x0, #0x14]
    10e8:      	cmp	w10, w8
    10ec:      	b.ls	0x1168 <filter_16ty_selector_val+0x2a8>
    10f0:      	mov	w0, #0x1                // =1
    10f4:      	ret
    10f8:      	cmp	w9, #0x11
    10fc:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    1100:      	ldr	w10, [x0, #0x18]
    1104:      	cmp	w10, w8
    1108:      	b.ge	0x1184 <filter_16ty_selector_val+0x2c4>
    110c:      	mov	w0, #0x1                // =1
    1110:      	ret
    1114:      	cmp	w9, #0x11
    1118:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    111c:      	ldr	w10, [x0, #0x18]
    1120:      	cmp	w10, w8
    1124:      	b.le	0x11a0 <filter_16ty_selector_val+0x2e0>
    1128:      	mov	w0, #0x1                // =1
    112c:      	ret
    1130:      	cmp	w9, #0x11
    1134:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    1138:      	ldr	w10, [x0, #0x18]
    113c:      	tst	w10, w8
    1140:      	b.eq	0x11bc <filter_16ty_selector_val+0x2fc>
    1144:      	mov	w0, #0x1                // =1
    1148:      	ret
    114c:      	cmp	w9, #0x11
    1150:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    1154:      	ldr	w10, [x0, #0x18]
    1158:      	cmp	w10, w8
    115c:      	b.hs	0x11d8 <filter_16ty_selector_val+0x318>
    1160:      	mov	w0, #0x1                // =1
    1164:      	ret
    1168:      	cmp	w9, #0x11
    116c:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    1170:      	ldr	w10, [x0, #0x18]
    1174:      	cmp	w10, w8
    1178:      	b.ls	0x11f4 <filter_16ty_selector_val+0x334>
    117c:      	mov	w0, #0x1                // =1
    1180:      	ret
    1184:      	cmp	w9, #0x15
    1188:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    118c:      	ldr	w9, [x0, #0x1c]
    1190:      	cmp	w9, w8
    1194:      	b.ge	0x1210 <filter_16ty_selector_val+0x350>
    1198:      	mov	w0, #0x1                // =1
    119c:      	ret
    11a0:      	cmp	w9, #0x15
    11a4:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    11a8:      	ldr	w9, [x0, #0x1c]
    11ac:      	cmp	w9, w8
    11b0:      	b.le	0x1210 <filter_16ty_selector_val+0x350>
    11b4:      	mov	w0, #0x1                // =1
    11b8:      	ret
    11bc:      	cmp	w9, #0x15
    11c0:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    11c4:      	ldr	w9, [x0, #0x1c]
    11c8:      	tst	w9, w8
    11cc:      	b.eq	0x1210 <filter_16ty_selector_val+0x350>
    11d0:      	mov	w0, #0x1                // =1
    11d4:      	ret
    11d8:      	cmp	w9, #0x15
    11dc:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    11e0:      	ldr	w9, [x0, #0x1c]
    11e4:      	cmp	w9, w8
    11e8:      	b.hs	0x1210 <filter_16ty_selector_val+0x350>
    11ec:      	mov	w0, #0x1                // =1
    11f0:      	ret
    11f4:      	cmp	w9, #0x15
    11f8:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    11fc:      	ldr	w9, [x0, #0x1c]
    1200:      	cmp	w9, w8
    1204:      	b.ls	0x1210 <filter_16ty_selector_val+0x350>
    1208:      	mov	w0, #0x1                // =1
    120c:      	ret
    1210:      	mov	x0, xzr
    1214:      	ret
    1218:      	nop
    121c:      	nop

0000000000001220 <filter_16ty_map>:
    1220:      	sub	sp, sp, #0x30
    1224:      	str	x30, [sp, #0x10]
    1228:      	stp	x20, x19, [sp, #0x20]
    122c:      	ldrb	w8, [x0, #0x10]
    1230:      	mov	x19, x0
    1234:      	adrp	x0, 0x1000 <filter_16ty_selector_val+0x140>
    1238:      	add	x9, sp, #0x1c
    123c:      	str	w8, [sp, #0x1c]
    1240:      	mov	w8, #0x1                // =1
    1244:      	mov	x20, x1
    1248:      	add	x1, sp, #0x1c
    124c:      	ldr	x0, [x0]
    1250:      	blr	x8
    1254:      	cbz	x0, 0x12c8 <filter_16ty_map+0xa8>
    1258:      	ldrh	w8, [x20]
    125c:      	mov	w9, #0x1                // =1
    1260:      	add	x1, sp, #0x8
    1264:      	mov	w20, #0x1               // =1
    1268:      	str	x8, [sp, #0x8]
    126c:      	add	x8, sp, #0x8
    1270:      	blr	x9
    1274:      	ldr	w9, [x19, #0x4]
    1278:      	mov	w8, wzr
    127c:      	cmp	w9, #0x1d
    1280:      	b.hi	0x12c4 <filter_16ty_map+0xa4>
    1284:      	mov	w11, #0x8400            // =33792
    1288:      	lsl	w10, w20, w9
    128c:      	movk	w11, #0x3003, lsl #16
    1290:      	tst	w10, w11
    1294:      	b.eq	0x12a4 <filter_16ty_map+0x84>
    1298:      	cmp	x0, #0x0
    129c:      	cset	w8, ne
    12a0:      	b	0x12c4 <filter_16ty_map+0xa4>
    12a4:      	mov	w10, #0x1               // =1
    12a8:      	lsl	w9, w10, w9
    12ac:      	mov	w10, #0x800             // =2048
    12b0:      	movk	w10, #0xc, lsl #16
    12b4:      	tst	w9, w10
    12b8:      	b.eq	0x12c4 <filter_16ty_map+0xa4>
    12bc:      	cmp	x0, #0x0
    12c0:      	cset	w8, eq
    12c4:      	mov	w0, w8
    12c8:      	ldp	x20, x19, [sp, #0x20]
    12cc:      	ldr	x30, [sp, #0x10]
    12d0:      	add	sp, sp, #0x30
    12d4:      	ret
    12d8:      	nop
    12dc:      	nop

00000000000012e0 <filter_16ty_range>:
    12e0:      	ldr	w9, [x0, #0xc]
    12e4:      	ldr	w8, [x0, #0x4]
    12e8:      	mov	w10, #0x1               // =1
    12ec:      	cmp	w9, #0xc
    12f0:      	lsl	w9, w10, w9
    12f4:      	mov	w10, #0x1402            // =5122
    12f8:      	and	w9, w9, w10
    12fc:      	ccmp	w9, #0x0, #0x4, ls
    1300:      	b.eq	0x1400 <filter_16ty_range+0x120>
    1304:      	ldrsh	w10, [x1]
    1308:      	cmp	w8, #0x1f
    130c:      	b.ne	0x1394 <filter_16ty_range+0xb4>
    1310:      	ldr	w9, [x0, #0x10]
    1314:      	cmp	w9, w10
    1318:      	b.gt	0x1328 <filter_16ty_range+0x48>
    131c:      	ldr	w9, [x0, #0x14]
    1320:      	cmp	w9, w10
    1324:      	b.ge	0x1424 <filter_16ty_range+0x144>
    1328:      	ldr	w9, [x0, #0x8]
    132c:      	cmp	w9, #0x11
    1330:      	b.lo	0x1510 <filter_16ty_range+0x230>
    1334:      	ldr	w11, [x0, #0x18]
    1338:      	cmp	w11, w10
    133c:      	b.gt	0x134c <filter_16ty_range+0x6c>
    1340:      	ldr	w11, [x0, #0x1c]
    1344:      	cmp	w11, w10
    1348:      	b.ge	0x1424 <filter_16ty_range+0x144>
    134c:      	cmp	w9, #0x19
    1350:      	b.lo	0x1510 <filter_16ty_range+0x230>
    1354:      	ldr	w11, [x0, #0x20]
    1358:      	cmp	w11, w10
    135c:      	b.gt	0x136c <filter_16ty_range+0x8c>
    1360:      	ldr	w11, [x0, #0x24]
    1364:      	cmp	w11, w10
    1368:      	b.ge	0x1424 <filter_16ty_range+0x144>
    136c:      	cmp	w9, #0x21
    1370:      	b.lo	0x1510 <filter_16ty_range+0x230>
    1374:      	ldr	w11, [x0, #0x28]
    1378:      	mov	w9, wzr
    137c:      	cmp	w11, w10
    1380:      	b.gt	0x1500 <filter_16ty_range+0x220>
    1384:      	ldr	w11, [x0, #0x2c]
    1388:      	cmp	w11, w10
    138c:      	b.ge	0x1424 <filter_16ty_range+0x144>
    1390:      	b	0x1500 <filter_16ty_range+0x220>
    1394:      	ldp	w9, w12, [x0, #0x10]
    1398:      	ldr	w11, [x0, #0x8]
    139c:      	cmp	w9, w10
    13a0:      	ccmp	w12, w10, #0x8, le
    13a4:      	cset	w9, ge
    13a8:      	cmp	w11, #0x11
    13ac:      	b.lo	0x1500 <filter_16ty_range+0x220>
    13b0:      	ldp	w12, w13, [x0, #0x18]
    13b4:      	cmp	w12, w10
    13b8:      	ccmp	w13, w10, #0x8, le
    13bc:      	csinc	w9, w9, wzr, lt
    13c0:      	cmp	w11, #0x19
    13c4:      	b.lo	0x1500 <filter_16ty_range+0x220>
    13c8:      	ldp	w12, w13, [x0, #0x20]
    13cc:      	cmp	w12, w10
    13d0:      	ccmp	w13, w10, #0x8, le
    13d4:      	csinc	w9, w9, wzr, lt
    13d8:      	cmp	w11, #0x21
    13dc:      	b.lo	0x1500 <filter_16ty_range+0x220>
    13e0:      	ldp	w11, w12, [x0, #0x28]
    13e4:      	cmp	w11, w10
    13e8:      	ccmp	w12, w10, #0x8, le
    13ec:      	csinc	w9, w9, wzr, lt
    13f0:      	cmp	w8, #0x20
    13f4:      	eor	w8, w9, #0x1
    13f8:      	csel	w0, wzr, w8, ne
    13fc:      	ret
    1400:      	ldrh	w10, [x1]
    1404:      	cmp	w8, #0x1f
    1408:      	b.ne	0x142c <filter_16ty_range+0x14c>
    140c:      	ldr	w9, [x0, #0x10]
    1410:      	cmp	w9, w10
    1414:      	b.hi	0x1498 <filter_16ty_range+0x1b8>
    1418:      	ldr	w9, [x0, #0x14]
    141c:      	cmp	w9, w10
    1420:      	b.lo	0x1498 <filter_16ty_range+0x1b8>
    1424:      	mov	w0, #0x1                // =1
    1428:      	ret
    142c:      	ldp	w9, w12, [x0, #0x10]
    1430:      	ldr	w11, [x0, #0x8]
    1434:      	cmp	w9, w10
    1438:      	ccmp	w12, w10, #0x0, ls
    143c:      	cset	w9, hs
    1440:      	cmp	w11, #0x11
    1444:      	b.lo	0x1500 <filter_16ty_range+0x220>
    1448:      	ldp	w12, w13, [x0, #0x18]
    144c:      	cmp	w12, w10
    1450:      	ccmp	w13, w10, #0x0, ls
    1454:      	csinc	w9, w9, wzr, lo
    1458:      	cmp	w11, #0x19
    145c:      	b.lo	0x1500 <filter_16ty_range+0x220>
    1460:      	ldp	w12, w13, [x0, #0x20]
    1464:      	cmp	w12, w10
    1468:      	ccmp	w13, w10, #0x0, ls
    146c:      	csinc	w9, w9, wzr, lo
    1470:      	cmp	w11, #0x21
    1474:      	b.lo	0x1500 <filter_16ty_range+0x220>
    1478:      	ldp	w11, w12, [x0, #0x28]
    147c:      	cmp	w11, w10
    1480:      	ccmp	w12, w10, #0x0, ls
    1484:      	csinc	w9, w9, wzr, lo
    1488:      	cmp	w8, #0x20
    148c:      	eor	w8, w9, #0x1
    1490:      	csel	w0, wzr, w8, ne
    1494:      	ret
    1498:      	ldr	w9, [x0, #0x8]
    149c:      	cmp	w9, #0x11
    14a0:      	b.lo	0x1510 <filter_16ty_range+0x230>
    14a4:      	ldr	w11, [x0, #0x18]
    14a8:      	cmp	w11, w10
    14ac:      	b.hi	0x14bc <filter_16ty_range+0x1dc>
    14b0:      	ldr	w11, [x0, #0x1c]
    14b4:      	cmp	w11, w10
    14b8:      	b.hs	0x1424 <filter_16ty_range+0x144>
    14bc:      	cmp	w9, #0x19
    14c0:      	b.lo	0x1510 <filter_16ty_range+0x230>
    14c4:      	ldr	w11, [x0, #0x20]
    14c8:      	cmp	w11, w10
    14cc:      	b.hi	0x14dc <filter_16ty_range+0x1fc>
    14d0:      	ldr	w11, [x0, #0x24]
    14d4:      	cmp	w11, w10
    14d8:      	b.hs	0x1424 <filter_16ty_range+0x144>
    14dc:      	cmp	w9, #0x21
    14e0:      	b.lo	0x1510 <filter_16ty_range+0x230>
    14e4:      	ldr	w11, [x0, #0x28]
    14e8:      	mov	w9, wzr
    14ec:      	cmp	w11, w10
    14f0:      	b.hi	0x1500 <filter_16ty_range+0x220>
    14f4:      	ldr	w11, [x0, #0x2c]
    14f8:      	cmp	w11, w10
    14fc:      	b.hs	0x1424 <filter_16ty_range+0x144>
    1500:      	cmp	w8, #0x20
    1504:      	eor	w8, w9, #0x1
    1508:      	csel	w0, wzr, w8, ne
    150c:      	ret
    1510:      	mov	w9, wzr
    1514:      	cmp	w8, #0x20
    1518:      	eor	w8, w9, #0x1
    151c:      	csel	w0, wzr, w8, ne
    1520:      	ret
    1524:      	nop
    1528:      	nop
    152c:      	nop

0000000000001530 <filter_8ty_selector_val>:
    1530:      	ldr	w8, [x0, #0x4]
    1534:      	cmp	w8, #0x25
    1538:      	b.hi	0x15ac <filter_8ty_selector_val+0x7c>
    153c:      	mov	x10, #0x40              // =64
    1540:      	mov	w9, #0x1                // =1
    1544:      	movk	x10, #0xc00, lsl #16
    1548:      	lsl	x9, x9, x8
    154c:      	movk	x10, #0x20, lsl #32
    1550:      	tst	x9, x10
    1554:      	b.eq	0x1560 <filter_8ty_selector_val+0x30>
    1558:      	mov	w0, #0x1                // =1
    155c:      	ret
    1560:      	mov	w9, #0x1                // =1
    1564:      	lsl	x9, x9, x8
    1568:      	tst	x9, #0x18
    156c:      	b.eq	0x158c <filter_8ty_selector_val+0x5c>
    1570:      	ldrb	w9, [x1]
    1574:      	ldr	w10, [x0, #0x10]
    1578:      	cmp	w10, w9
    157c:      	b.ne	0x162c <filter_8ty_selector_val+0xfc>
    1580:      	cmp	w8, #0x3
    1584:      	cset	w0, eq
    1588:      	ret
    158c:      	cmp	x8, #0xc
    1590:      	b.ne	0x15ac <filter_8ty_selector_val+0x7c>
    1594:      	ldrb	w8, [x1]
    1598:      	ldr	w9, [x0, #0x10]
    159c:      	tst	w9, w8
    15a0:      	b.eq	0x16d8 <filter_8ty_selector_val+0x1a8>
    15a4:      	mov	w0, #0x1                // =1
    15a8:      	ret
    15ac:      	cmp	w8, #0x1
    15b0:      	b.eq	0x15f4 <filter_8ty_selector_val+0xc4>
    15b4:      	cmp	w8, #0x2
    15b8:      	b.ne	0x1880 <filter_8ty_selector_val+0x350>
    15bc:      	ldr	w8, [x0, #0xc]
    15c0:      	cmp	w8, #0xc
    15c4:      	b.hi	0x1710 <filter_8ty_selector_val+0x1e0>
    15c8:      	mov	w9, #0x1                // =1
    15cc:      	lsl	w8, w9, w8
    15d0:      	mov	w9, #0x1402             // =5122
    15d4:      	tst	w8, w9
    15d8:      	b.eq	0x1710 <filter_8ty_selector_val+0x1e0>
    15dc:      	ldrsb	w8, [x1]
    15e0:      	ldr	w9, [x0, #0x10]
    15e4:      	cmp	w9, w8
    15e8:      	b.le	0x16b8 <filter_8ty_selector_val+0x188>
    15ec:      	mov	w0, #0x1                // =1
    15f0:      	ret
    15f4:      	ldr	w8, [x0, #0xc]
    15f8:      	cmp	w8, #0xc
    15fc:      	b.hi	0x16f8 <filter_8ty_selector_val+0x1c8>
    1600:      	mov	w9, #0x1                // =1
    1604:      	lsl	w8, w9, w8
    1608:      	mov	w9, #0x1402             // =5122
    160c:      	tst	w8, w9
    1610:      	b.eq	0x16f8 <filter_8ty_selector_val+0x1c8>
    1614:      	ldrsb	w8, [x1]
    1618:      	ldr	w9, [x0, #0x10]
    161c:      	cmp	w9, w8
    1620:      	b.ge	0x1698 <filter_8ty_selector_val+0x168>
    1624:      	mov	w0, #0x1                // =1
    1628:      	ret
    162c:      	ldr	w10, [x0, #0x8]
    1630:      	cmp	w10, #0xd
    1634:      	b.lo	0x166c <filter_8ty_selector_val+0x13c>
    1638:      	ldr	w11, [x0, #0x14]
    163c:      	cmp	w11, w9
    1640:      	b.eq	0x1580 <filter_8ty_selector_val+0x50>
    1644:      	cmp	w10, #0x11
    1648:      	b.lo	0x166c <filter_8ty_selector_val+0x13c>
    164c:      	ldr	w11, [x0, #0x18]
    1650:      	cmp	w11, w9
    1654:      	b.eq	0x1580 <filter_8ty_selector_val+0x50>
    1658:      	cmp	w10, #0x15
    165c:      	b.lo	0x166c <filter_8ty_selector_val+0x13c>
    1660:      	ldr	w10, [x0, #0x1c]
    1664:      	cmp	w10, w9
    1668:      	b.eq	0x1580 <filter_8ty_selector_val+0x50>
    166c:      	cmp	w8, #0x25
    1670:      	b.hi	0x1880 <filter_8ty_selector_val+0x350>
    1674:      	mov	w9, #0x1                // =1
    1678:      	lsl	x8, x9, x8
    167c:      	mov	x9, #0x50               // =80
    1680:      	movk	x9, #0xc00, lsl #16
    1684:      	movk	x9, #0x20, lsl #32
    1688:      	tst	x8, x9
    168c:      	b.eq	0x1880 <filter_8ty_selector_val+0x350>
    1690:      	mov	w0, #0x1                // =1
    1694:      	ret
    1698:      	ldr	w9, [x0, #0x8]
    169c:      	cmp	w9, #0xd
    16a0:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    16a4:      	ldr	w10, [x0, #0x14]
    16a8:      	cmp	w10, w8
    16ac:      	b.ge	0x1768 <filter_8ty_selector_val+0x238>
    16b0:      	mov	w0, #0x1                // =1
    16b4:      	ret
    16b8:      	ldr	w9, [x0, #0x8]
    16bc:      	cmp	w9, #0xd
    16c0:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    16c4:      	ldr	w10, [x0, #0x14]
    16c8:      	cmp	w10, w8
    16cc:      	b.le	0x1784 <filter_8ty_selector_val+0x254>
    16d0:      	mov	w0, #0x1                // =1
    16d4:      	ret
    16d8:      	ldr	w9, [x0, #0x8]
    16dc:      	cmp	w9, #0xd
    16e0:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    16e4:      	ldr	w10, [x0, #0x14]
    16e8:      	tst	w10, w8
    16ec:      	b.eq	0x17a0 <filter_8ty_selector_val+0x270>
    16f0:      	mov	w0, #0x1                // =1
    16f4:      	ret
    16f8:      	ldrb	w8, [x1]
    16fc:      	ldr	w9, [x0, #0x10]
    1700:      	cmp	w9, w8
    1704:      	b.hs	0x1728 <filter_8ty_selector_val+0x1f8>
    1708:      	mov	w0, #0x1                // =1
    170c:      	ret
    1710:      	ldrb	w8, [x1]
    1714:      	ldr	w9, [x0, #0x10]
    1718:      	cmp	w9, w8
    171c:      	b.ls	0x1748 <filter_8ty_selector_val+0x218>
    1720:      	mov	w0, #0x1                // =1
    1724:      	ret
    1728:      	ldr	w9, [x0, #0x8]
    172c:      	cmp	w9, #0xd
    1730:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    1734:      	ldr	w10, [x0, #0x14]
    1738:      	cmp	w10, w8
    173c:      	b.hs	0x17bc <filter_8ty_selector_val+0x28c>
    1740:      	mov	w0, #0x1                // =1
    1744:      	ret
    1748:      	ldr	w9, [x0, #0x8]
    174c:      	cmp	w9, #0xd
    1750:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    1754:      	ldr	w10, [x0, #0x14]
    1758:      	cmp	w10, w8
    175c:      	b.ls	0x17d8 <filter_8ty_selector_val+0x2a8>
    1760:      	mov	w0, #0x1                // =1
    1764:      	ret
    1768:      	cmp	w9, #0x11
    176c:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    1770:      	ldr	w10, [x0, #0x18]
    1774:      	cmp	w10, w8
    1778:      	b.ge	0x17f4 <filter_8ty_selector_val+0x2c4>
    177c:      	mov	w0, #0x1                // =1
    1780:      	ret
    1784:      	cmp	w9, #0x11
    1788:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    178c:      	ldr	w10, [x0, #0x18]
    1790:      	cmp	w10, w8
    1794:      	b.le	0x1810 <filter_8ty_selector_val+0x2e0>
    1798:      	mov	w0, #0x1                // =1
    179c:      	ret
    17a0:      	cmp	w9, #0x11
    17a4:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    17a8:      	ldr	w10, [x0, #0x18]
    17ac:      	tst	w10, w8
    17b0:      	b.eq	0x182c <filter_8ty_selector_val+0x2fc>
    17b4:      	mov	w0, #0x1                // =1
    17b8:      	ret
    17bc:      	cmp	w9, #0x11
    17c0:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    17c4:      	ldr	w10, [x0, #0x18]
    17c8:      	cmp	w10, w8
    17cc:      	b.hs	0x1848 <filter_8ty_selector_val+0x318>
    17d0:      	mov	w0, #0x1                // =1
    17d4:      	ret
    17d8:      	cmp	w9, #0x11
    17dc:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    17e0:      	ldr	w10, [x0, #0x18]
    17e4:      	cmp	w10, w8
    17e8:      	b.ls	0x1864 <filter_8ty_selector_val+0x334>
    17ec:      	mov	w0, #0x1                // =1
    17f0:      	ret
    17f4:      	cmp	w9, #0x15
    17f8:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    17fc:      	ldr	w9, [x0, #0x1c]
    1800:      	cmp	w9, w8
    1804:      	b.ge	0x1880 <filter_8ty_selector_val+0x350>
    1808:      	mov	w0, #0x1                // =1
    180c:      	ret
    1810:      	cmp	w9, #0x15
    1814:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    1818:      	ldr	w9, [x0, #0x1c]
    181c:      	cmp	w9, w8
    1820:      	b.le	0x1880 <filter_8ty_selector_val+0x350>
    1824:      	mov	w0, #0x1                // =1
    1828:      	ret
    182c:      	cmp	w9, #0x15
    1830:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    1834:      	ldr	w9, [x0, #0x1c]
    1838:      	tst	w9, w8
    183c:      	b.eq	0x1880 <filter_8ty_selector_val+0x350>
    1840:      	mov	w0, #0x1                // =1
    1844:      	ret
    1848:      	cmp	w9, #0x15
    184c:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    1850:      	ldr	w9, [x0, #0x1c]
    1854:      	cmp	w9, w8
    1858:      	b.hs	0x1880 <filter_8ty_selector_val+0x350>
    185c:      	mov	w0, #0x1                // =1
    1860:      	ret
    1864:      	cmp	w9, #0x15
    1868:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    186c:      	ldr	w9, [x0, #0x1c]
    1870:      	cmp	w9, w8
    1874:      	b.ls	0x1880 <filter_8ty_selector_val+0x350>
    1878:      	mov	w0, #0x1                // =1
    187c:      	ret
    1880:      	mov	x0, xzr
    1884:      	ret
    1888:      	nop
    188c:      	nop

0000000000001890 <filter_8ty_map>:
    1890:      	sub	sp, sp, #0x30
    1894:      	str	x30, [sp, #0x10]
    1898:      	stp	x20, x19, [sp, #0x20]
    189c:      	ldrb	w8, [x0, #0x10]
    18a0:      	mov	x19, x0
    18a4:      	adrp	x0, 0x1000 <filter_16ty_selector_val+0x140>
    18a8:      	add	x9, sp, #0x1c
    18ac:      	str	w8, [sp, #0x1c]
    18b0:      	mov	w8, #0x1                // =1
    18b4:      	mov	x20, x1
    18b8:      	add	x1, sp, #0x1c
    18bc:      	ldr	x0, [x0]
    18c0:      	blr	x8
    18c4:      	cbz	x0, 0x1938 <filter_8ty_map+0xa8>
    18c8:      	ldrb	w8, [x20]
    18cc:      	mov	w9, #0x1                // =1
    18d0:      	add	x1, sp, #0x8
    18d4:      	mov	w20, #0x1               // =1
    18d8:      	str	x8, [sp, #0x8]
    18dc:      	add	x8, sp, #0x8
    18e0:      	blr	x9
    18e4:      	ldr	w9, [x19, #0x4]
    18e8:      	mov	w8, wzr
    18ec:      	cmp	w9, #0x1d
    18f0:      	b.hi	0x1934 <filter_8ty_map+0xa4>
    18f4:      	mov	w11, #0x8400            // =33792
    18f8:      	lsl	w10, w20, w9
    18fc:      	movk	w11, #0x3003, lsl #16
    1900:      	tst	w10, w11
    1904:      	b.eq	0x1914 <filter_8ty_map+0x84>
    1908:      	cmp	x0, #0x0
    190c:      	cset	w8, ne
    1910:      	b	0x1934 <filter_8ty_map+0xa4>
    1914:      	mov	w10, #0x1               // =1
    1918:      	lsl	w9, w10, w9
    191c:      	mov	w10, #0x800             // =2048
    1920:      	movk	w10, #0xc, lsl #16
    1924:      	tst	w9, w10
    1928:      	b.eq	0x1934 <filter_8ty_map+0xa4>
    192c:      	cmp	x0, #0x0
    1930:      	cset	w8, eq
    1934:      	mov	w0, w8
    1938:      	ldp	x20, x19, [sp, #0x20]
    193c:      	ldr	x30, [sp, #0x10]
    1940:      	add	sp, sp, #0x30
    1944:      	ret
    1948:      	nop
    194c:      	nop

0000000000001950 <filter_8ty_range>:
    1950:      	ldr	w9, [x0, #0xc]
    1954:      	ldr	w8, [x0, #0x4]
    1958:      	mov	w10, #0x1               // =1
    195c:      	cmp	w9, #0xc
    1960:      	lsl	w9, w10, w9
    1964:      	mov	w10, #0x1402            // =5122
    1968:      	and	w9, w9, w10
    196c:      	ccmp	w9, #0x0, #0x4, ls
    1970:      	b.eq	0x1a70 <filter_8ty_range+0x120>
    1974:      	ldrsb	w10, [x1]
    1978:      	cmp	w8, #0x1f
    197c:      	b.ne	0x1a04 <filter_8ty_range+0xb4>
    1980:      	ldr	w9, [x0, #0x10]
    1984:      	cmp	w9, w10
    1988:      	b.gt	0x1998 <filter_8ty_range+0x48>
    198c:      	ldr	w9, [x0, #0x14]
    1990:      	cmp	w9, w10
    1994:      	b.ge	0x1a94 <filter_8ty_range+0x144>
    1998:      	ldr	w9, [x0, #0x8]
    199c:      	cmp	w9, #0x11
    19a0:      	b.lo	0x1b80 <filter_8ty_range+0x230>
    19a4:      	ldr	w11, [x0, #0x18]
    19a8:      	cmp	w11, w10
    19ac:      	b.gt	0x19bc <filter_8ty_range+0x6c>
    19b0:      	ldr	w11, [x0, #0x1c]
    19b4:      	cmp	w11, w10
    19b8:      	b.ge	0x1a94 <filter_8ty_range+0x144>
    19bc:      	cmp	w9, #0x19
    19c0:      	b.lo	0x1b80 <filter_8ty_range+0x230>
    19c4:      	ldr	w11, [x0, #0x20]
    19c8:      	cmp	w11, w10
    19cc:      	b.gt	0x19dc <filter_8ty_range+0x8c>
    19d0:      	ldr	w11, [x0, #0x24]
    19d4:      	cmp	w11, w10
    19d8:      	b.ge	0x1a94 <filter_8ty_range+0x144>
    19dc:      	cmp	w9, #0x21
    19e0:      	b.lo	0x1b80 <filter_8ty_range+0x230>
    19e4:      	ldr	w11, [x0, #0x28]
    19e8:      	mov	w9, wzr
    19ec:      	cmp	w11, w10
    19f0:      	b.gt	0x1b70 <filter_8ty_range+0x220>
    19f4:      	ldr	w11, [x0, #0x2c]
    19f8:      	cmp	w11, w10
    19fc:      	b.ge	0x1a94 <filter_8ty_range+0x144>
    1a00:      	b	0x1b70 <filter_8ty_range+0x220>
    1a04:      	ldp	w9, w12, [x0, #0x10]
    1a08:      	ldr	w11, [x0, #0x8]
    1a0c:      	cmp	w9, w10
    1a10:      	ccmp	w12, w10, #0x8, le
    1a14:      	cset	w9, ge
    1a18:      	cmp	w11, #0x11
    1a1c:      	b.lo	0x1b70 <filter_8ty_range+0x220>
    1a20:      	ldp	w12, w13, [x0, #0x18]
    1a24:      	cmp	w12, w10
    1a28:      	ccmp	w13, w10, #0x8, le
    1a2c:      	csinc	w9, w9, wzr, lt
    1a30:      	cmp	w11, #0x19
    1a34:      	b.lo	0x1b70 <filter_8ty_range+0x220>
    1a38:      	ldp	w12, w13, [x0, #0x20]
    1a3c:      	cmp	w12, w10
    1a40:      	ccmp	w13, w10, #0x8, le
    1a44:      	csinc	w9, w9, wzr, lt
    1a48:      	cmp	w11, #0x21
    1a4c:      	b.lo	0x1b70 <filter_8ty_range+0x220>
    1a50:      	ldp	w11, w12, [x0, #0x28]
    1a54:      	cmp	w11, w10
    1a58:      	ccmp	w12, w10, #0x8, le
    1a5c:      	csinc	w9, w9, wzr, lt
    1a60:      	cmp	w8, #0x20
    1a64:      	eor	w8, w9, #0x1
    1a68:      	csel	w0, wzr, w8, ne
    1a6c:      	ret
    1a70:      	ldrb	w10, [x1]
    1a74:      	cmp	w8, #0x1f
    1a78:      	b.ne	0x1a9c <filter_8ty_range+0x14c>
    1a7c:      	ldr	w9, [x0, #0x10]
    1a80:      	cmp	w9, w10
    1a84:      	b.hi	0x1b08 <filter_8ty_range+0x1b8>
    1a88:      	ldr	w9, [x0, #0x14]
    1a8c:      	cmp	w9, w10
    1a90:      	b.lo	0x1b08 <filter_8ty_range+0x1b8>
    1a94:      	mov	w0, #0x1                // =1
    1a98:      	ret
    1a9c:      	ldp	w9, w12, [x0, #0x10]
    1aa0:      	ldr	w11, [x0, #0x8]
    1aa4:      	cmp	w9, w10
    1aa8:      	ccmp	w12, w10, #0x0, ls
    1aac:      	cset	w9, hs
    1ab0:      	cmp	w11, #0x11
    1ab4:      	b.lo	0x1b70 <filter_8ty_range+0x220>
    1ab8:      	ldp	w12, w13, [x0, #0x18]
    1abc:      	cmp	w12, w10
    1ac0:      	ccmp	w13, w10, #0x0, ls
    1ac4:      	csinc	w9, w9, wzr, lo
    1ac8:      	cmp	w11, #0x19
    1acc:      	b.lo	0x1b70 <filter_8ty_range+0x220>
    1ad0:      	ldp	w12, w13, [x0, #0x20]
    1ad4:      	cmp	w12, w10
    1ad8:      	ccmp	w13, w10, #0x0, ls
    1adc:      	csinc	w9, w9, wzr, lo
    1ae0:      	cmp	w11, #0x21
    1ae4:      	b.lo	0x1b70 <filter_8ty_range+0x220>
    1ae8:      	ldp	w11, w12, [x0, #0x28]
    1aec:      	cmp	w11, w10
    1af0:      	ccmp	w12, w10, #0x0, ls
    1af4:      	csinc	w9, w9, wzr, lo
    1af8:      	cmp	w8, #0x20
    1afc:      	eor	w8, w9, #0x1
    1b00:      	csel	w0, wzr, w8, ne
    1b04:      	ret
    1b08:      	ldr	w9, [x0, #0x8]
    1b0c:      	cmp	w9, #0x11
    1b10:      	b.lo	0x1b80 <filter_8ty_range+0x230>
    1b14:      	ldr	w11, [x0, #0x18]
    1b18:      	cmp	w11, w10
    1b1c:      	b.hi	0x1b2c <filter_8ty_range+0x1dc>
    1b20:      	ldr	w11, [x0, #0x1c]
    1b24:      	cmp	w11, w10
    1b28:      	b.hs	0x1a94 <filter_8ty_range+0x144>
    1b2c:      	cmp	w9, #0x19
    1b30:      	b.lo	0x1b80 <filter_8ty_range+0x230>
    1b34:      	ldr	w11, [x0, #0x20]
    1b38:      	cmp	w11, w10
    1b3c:      	b.hi	0x1b4c <filter_8ty_range+0x1fc>
    1b40:      	ldr	w11, [x0, #0x24]
    1b44:      	cmp	w11, w10
    1b48:      	b.hs	0x1a94 <filter_8ty_range+0x144>
    1b4c:      	cmp	w9, #0x21
    1b50:      	b.lo	0x1b80 <filter_8ty_range+0x230>
    1b54:      	ldr	w11, [x0, #0x28]
    1b58:      	mov	w9, wzr
    1b5c:      	cmp	w11, w10
    1b60:      	b.hi	0x1b70 <filter_8ty_range+0x220>
    1b64:      	ldr	w11, [x0, #0x2c]
    1b68:      	cmp	w11, w10
    1b6c:      	b.hs	0x1a94 <filter_8ty_range+0x144>
    1b70:      	cmp	w8, #0x20
    1b74:      	eor	w8, w9, #0x1
    1b78:      	csel	w0, wzr, w8, ne
    1b7c:      	ret
    1b80:      	mov	w9, wzr
    1b84:      	cmp	w8, #0x20
    1b88:      	eor	w8, w9, #0x1
    1b8c:      	csel	w0, wzr, w8, ne
    1b90:      	ret
    1b94:      	nop
    1b98:      	nop
    1b9c:      	nop

0000000000001ba0 <filter_file_buf>:
    1ba0:      	stp	x30, x19, [sp, #-0x10]!
    1ba4:      	ldr	w2, [x1]
    1ba8:      	ldr	w8, [x0, #0x4]
    1bac:      	mov	x19, x0
    1bb0:      	cbnz	w2, 0x1bcc <filter_file_buf+0x2c>
    1bb4:      	and	w9, w8, #0xfffffffe
    1bb8:      	cmp	w9, #0x24
    1bbc:      	b.eq	0x1bcc <filter_file_buf+0x2c>
    1bc0:      	mov	x0, xzr
    1bc4:      	ldp	x30, x19, [sp], #0x10
    1bc8:      	ret
    1bcc:      	cmp	w8, #0x25
    1bd0:      	b.hi	0x1c2c <filter_file_buf+0x8c>
    1bd4:      	mov	w9, #0x1                // =1
    1bd8:      	mov	w10, #0x100             // =256
    1bdc:      	lsl	x9, x9, x8
    1be0:      	movk	w10, #0x400, lsl #16
    1be4:      	tst	x9, x10
    1be8:      	b.ne	0x1c70 <filter_file_buf+0xd0>
    1bec:      	mov	w9, #0x1                // =1
    1bf0:      	mov	w10, #0x200             // =512
    1bf4:      	lsl	x9, x9, x8
    1bf8:      	movk	w10, #0x800, lsl #16
    1bfc:      	tst	x9, x10
    1c00:      	b.ne	0x1c54 <filter_file_buf+0xb4>
    1c04:      	mov	w9, #0x1                // =1
    1c08:      	lsl	x9, x9, x8
    1c0c:      	tst	x9, #0x3000000000
    1c10:      	b.eq	0x1c2c <filter_file_buf+0x8c>
    1c14:      	mov	x0, x19
    1c18:      	bl	0x2870 <filter_file_type>
    1c1c:      	ldr	w8, [x19, #0x4]
    1c20:      	cmp	w8, #0x25
    1c24:      	b.ls	0x1c98 <filter_file_buf+0xf8>
    1c28:      	b	0x1cbc <filter_file_buf+0x11c>
    1c2c:      	sub	w9, w8, #0x3
    1c30:      	cmp	w9, #0x2
    1c34:      	b.hs	0x1c8c <filter_file_buf+0xec>
    1c38:      	add	x1, x1, #0x4
    1c3c:      	mov	x0, x19
    1c40:      	bl	0x22b0 <filter_char_buf_equal>
    1c44:      	ldr	w8, [x19, #0x4]
    1c48:      	cmp	w8, #0x25
    1c4c:      	b.ls	0x1c98 <filter_file_buf+0xf8>
    1c50:      	b	0x1cbc <filter_file_buf+0x11c>
    1c54:      	ldr	w0, [x19, #0x10]
    1c58:      	add	x1, x1, #0x4
    1c5c:      	bl	0x27a0 <filter_char_buf_postfix>
    1c60:      	ldr	w8, [x19, #0x4]
    1c64:      	cmp	w8, #0x25
    1c68:      	b.ls	0x1c98 <filter_file_buf+0xf8>
    1c6c:      	b	0x1cbc <filter_file_buf+0x11c>
    1c70:      	ldr	w0, [x19, #0x10]
    1c74:      	add	x1, x1, #0x4
    1c78:      	bl	0x26e0 <filter_char_buf_prefix>
    1c7c:      	ldr	w8, [x19, #0x4]
    1c80:      	cmp	w8, #0x25
    1c84:      	b.ls	0x1c98 <filter_file_buf+0xf8>
    1c88:      	b	0x1cbc <filter_file_buf+0x11c>
    1c8c:      	mov	x0, xzr
    1c90:      	cmp	w8, #0x25
    1c94:      	b.hi	0x1cbc <filter_file_buf+0x11c>
    1c98:      	mov	w8, w8
    1c9c:      	mov	w9, #0x1                // =1
    1ca0:      	lsl	x8, x9, x8
    1ca4:      	mov	x9, #0x50               // =80
    1ca8:      	movk	x9, #0xc00, lsl #16
    1cac:      	movk	x9, #0x20, lsl #32
    1cb0:      	tst	x8, x9
    1cb4:      	b.eq	0x1cbc <filter_file_buf+0x11c>
    1cb8:      	eor	x0, x0, #0x1
    1cbc:      	ldp	x30, x19, [sp], #0x10
    1cc0:      	ret
    1cc4:      	nop
    1cc8:      	nop
    1ccc:      	nop

0000000000001cd0 <filter_char_buf>:
    1cd0:      	stp	x30, x19, [sp, #-0x10]!
    1cd4:      	mov	w8, w2
    1cd8:      	mov	x19, x0
    1cdc:      	add	x9, x1, w2, sxtw
    1ce0:      	ldur	w2, [x9, #-0x4]
    1ce4:      	add	x1, x1, w8, uxtw
    1ce8:      	ldr	w8, [x0, #0x4]
    1cec:      	mov	x0, xzr
    1cf0:      	cmp	w8, #0x19
    1cf4:      	b.gt	0x1d18 <filter_char_buf+0x48>
    1cf8:      	sub	w9, w8, #0x3
    1cfc:      	cmp	w9, #0x2
    1d00:      	b.lo	0x1d64 <filter_char_buf+0x94>
    1d04:      	cmp	w8, #0x8
    1d08:      	b.eq	0x1d58 <filter_char_buf+0x88>
    1d0c:      	cmp	w8, #0x9
    1d10:      	b.eq	0x1d30 <filter_char_buf+0x60>
    1d14:      	b	0x1d80 <filter_char_buf+0xb0>
    1d18:      	cmp	w8, #0x20
    1d1c:      	b.gt	0x1d3c <filter_char_buf+0x6c>
    1d20:      	cmp	w8, #0x1a
    1d24:      	b.eq	0x1d58 <filter_char_buf+0x88>
    1d28:      	cmp	w8, #0x1b
    1d2c:      	b.ne	0x1d80 <filter_char_buf+0xb0>
    1d30:      	ldr	w0, [x19, #0x10]
    1d34:      	bl	0x27a0 <filter_char_buf_postfix>
    1d38:      	b	0x1d7c <filter_char_buf+0xac>
    1d3c:      	cmp	w8, #0x21
    1d40:      	b.eq	0x1d70 <filter_char_buf+0xa0>
    1d44:      	cmp	w8, #0x22
    1d48:      	b.ne	0x1d80 <filter_char_buf+0xb0>
    1d4c:      	mov	x0, x19
    1d50:      	mov	w3, #0x1                // =1
    1d54:      	b	0x1d78 <filter_char_buf+0xa8>
    1d58:      	ldr	w0, [x19, #0x10]
    1d5c:      	bl	0x26e0 <filter_char_buf_prefix>
    1d60:      	b	0x1d7c <filter_char_buf+0xac>
    1d64:      	mov	x0, x19
    1d68:      	bl	0x22b0 <filter_char_buf_equal>
    1d6c:      	b	0x1d7c <filter_char_buf+0xac>
    1d70:      	mov	x0, x19
    1d74:      	mov	w3, wzr
    1d78:      	bl	0x2970 <filter_char_substring>
    1d7c:      	ldr	w8, [x19, #0x4]
    1d80:      	cmp	w8, #0x25
    1d84:      	b.hi	0x1db0 <filter_char_buf+0xe0>
    1d88:      	mov	w8, w8
    1d8c:      	mov	w9, #0x1                // =1
    1d90:      	lsl	x8, x9, x8
    1d94:      	mov	x9, #0x50               // =80
    1d98:      	movk	x9, #0xc00, lsl #16
    1d9c:      	movk	x9, #0x20, lsl #32
    1da0:      	tst	x8, x9
    1da4:      	b.eq	0x1db0 <filter_char_buf+0xe0>
    1da8:      	cmp	x0, #0x0
    1dac:      	cset	w0, eq
    1db0:      	ldp	x30, x19, [sp], #0x10
    1db4:      	ret
    1db8:      	nop
    1dbc:      	nop

0000000000001dc0 <filter_inet>:
    1dc0:      	sub	sp, sp, #0x80
    1dc4:      	str	x30, [sp, #0x50]
    1dc8:      	stp	x22, x21, [sp, #0x60]
    1dcc:      	stp	x20, x19, [sp, #0x70]
    1dd0:      	ldr	w10, [x0, #0xc]
    1dd4:      	mov	x8, xzr
    1dd8:      	stp	xzr, xzr, [sp, #0x28]
    1ddc:      	cmp	w10, #0x27
    1de0:      	str	xzr, [sp, #0x10]
    1de4:      	stp	xzr, xzr, [sp, #0x18]
    1de8:      	str	wzr, [sp, #0x58]
    1dec:      	str	wzr, [sp, #0xc]
    1df0:      	b.gt	0x1e3c <filter_inet+0x7c>
    1df4:      	cmp	w10, #0x5
    1df8:      	b.eq	0x1e70 <filter_inet+0xb0>
    1dfc:      	cmp	w10, #0x7
    1e00:      	mov	x11, x1
    1e04:      	b.ne	0x2044 <filter_inet+0x284>
    1e08:      	ldr	w9, [x0, #0x4]
    1e0c:      	mov	x8, xzr
    1e10:      	cmp	w9, #0x13
    1e14:      	b.le	0x1eb8 <filter_inet+0xf8>
    1e18:      	cmp	w9, #0x17
    1e1c:      	b.gt	0x1e54 <filter_inet+0x94>
    1e20:      	sub	w10, w9, #0x14
    1e24:      	cmp	w10, #0x2
    1e28:      	b.lo	0x1f14 <filter_inet+0x154>
    1e2c:      	sub	w10, w9, #0x16
    1e30:      	cmp	w10, #0x2
    1e34:      	b.lo	0x1f0c <filter_inet+0x14c>
    1e38:      	b	0x2044 <filter_inet+0x284>
    1e3c:      	cmp	w10, #0x28
    1e40:      	b.eq	0x1e88 <filter_inet+0xc8>
    1e44:      	cmp	w10, #0x29
    1e48:      	mov	x11, x1
    1e4c:      	b.eq	0x1e08 <filter_inet+0x48>
    1e50:      	b	0x2044 <filter_inet+0x284>
    1e54:      	cmp	w9, #0x1b
    1e58:      	b.gt	0x1f58 <filter_inet+0x198>
    1e5c:      	cmp	w9, #0x18
    1e60:      	b.eq	0x2014 <filter_inet+0x254>
    1e64:      	cmp	w9, #0x19
    1e68:      	b.eq	0x1f78 <filter_inet+0x1b8>
    1e6c:      	b	0x2044 <filter_inet+0x284>
    1e70:      	mov	x11, xzr
    1e74:      	ldr	w9, [x0, #0x4]
    1e78:      	mov	x8, xzr
    1e7c:      	cmp	w9, #0x13
    1e80:      	b.gt	0x1e18 <filter_inet+0x58>
    1e84:      	b	0x1eb8 <filter_inet+0xf8>
    1e88:      	ldrh	w8, [x1]
    1e8c:      	ldrh	w9, [x1, #0x2]
    1e90:      	mov	x11, xzr
    1e94:      	strh	w8, [sp, #0x36]
    1e98:      	strh	w9, [sp, #0x30]
    1e9c:      	ldp	x8, x9, [x1, #0x8]
    1ea0:      	add	x1, sp, #0x10
    1ea4:      	stp	x8, x9, [sp, #0x10]
    1ea8:      	ldr	w9, [x0, #0x4]
    1eac:      	mov	x8, xzr
    1eb0:      	cmp	w9, #0x13
    1eb4:      	b.gt	0x1e18 <filter_inet+0x58>
    1eb8:      	cmp	w9, #0xf
    1ebc:      	b.le	0x1ee0 <filter_inet+0x120>
    1ec0:      	cmp	w9, #0x11
    1ec4:      	b.gt	0x1efc <filter_inet+0x13c>
    1ec8:      	cmp	w9, #0x10
    1ecc:      	b.eq	0x1f0c <filter_inet+0x14c>
    1ed0:      	cmp	w9, #0x11
    1ed4:      	b.ne	0x2044 <filter_inet+0x284>
    1ed8:      	ldrh	w8, [x1, #0x24]
    1edc:      	b	0x212c <filter_inet+0x36c>
    1ee0:      	cmp	w9, #0xd
    1ee4:      	b.eq	0x2014 <filter_inet+0x254>
    1ee8:      	cmp	w9, #0xe
    1eec:      	b.eq	0x1f78 <filter_inet+0x1b8>
    1ef0:      	cmp	w9, #0xf
    1ef4:      	b.eq	0x1f14 <filter_inet+0x154>
    1ef8:      	b	0x2044 <filter_inet+0x284>
    1efc:      	cmp	w9, #0x12
    1f00:      	b.eq	0x1f14 <filter_inet+0x154>
    1f04:      	cmp	w9, #0x13
    1f08:      	b.ne	0x2044 <filter_inet+0x284>
    1f0c:      	ldrh	w10, [x1, #0x22]
    1f10:      	b	0x1f18 <filter_inet+0x158>
    1f14:      	ldrh	w10, [x1, #0x20]
    1f18:      	mov	w19, wzr
    1f1c:      	mov	w20, wzr
    1f20:      	mov	x21, xzr
    1f24:      	str	w10, [sp, #0xc]
    1f28:      	mov	x8, xzr
    1f2c:      	cmp	w9, #0x11
    1f30:      	b.gt	0x1f90 <filter_inet+0x1d0>
    1f34:      	sub	w10, w9, #0xd
    1f38:      	cmp	w10, #0x2
    1f3c:      	b.lo	0x1fc8 <filter_inet+0x208>
    1f40:      	sub	w10, w9, #0xf
    1f44:      	cmp	w10, #0x2
    1f48:      	b.lo	0x203c <filter_inet+0x27c>
    1f4c:      	cmp	w9, #0x11
    1f50:      	b.eq	0x2130 <filter_inet+0x370>
    1f54:      	b	0x2044 <filter_inet+0x284>
    1f58:      	cmp	w9, #0x1c
    1f5c:      	b.eq	0x2128 <filter_inet+0x368>
    1f60:      	cmp	w9, #0x1d
    1f64:      	b.ne	0x2044 <filter_inet+0x284>
    1f68:      	cmp	w10, #0x7
    1f6c:      	b.ne	0x2180 <filter_inet+0x3c0>
    1f70:      	cbnz	x11, 0x218c <filter_inet+0x3cc>
    1f74:      	b	0x2130 <filter_inet+0x370>
    1f78:      	ldp	w19, w20, [x1, #0x10]
    1f7c:      	ldr	x21, [x1, #0x18]
    1f80:      	mov	w10, wzr
    1f84:      	mov	x8, xzr
    1f88:      	cmp	w9, #0x11
    1f8c:      	b.le	0x1f34 <filter_inet+0x174>
    1f90:      	cmp	w9, #0x19
    1f94:      	b.hi	0x2030 <filter_inet+0x270>
    1f98:      	mov	w11, #0x1               // =1
    1f9c:      	mov	w12, #0x500000          // =5242880
    1fa0:      	lsl	w11, w11, w9
    1fa4:      	tst	w11, w12
    1fa8:      	b.ne	0x205c <filter_inet+0x29c>
    1fac:      	mov	w12, #0xa00000          // =10485760
    1fb0:      	tst	w11, w12
    1fb4:      	b.ne	0x207c <filter_inet+0x2bc>
    1fb8:      	mov	w10, #0x1               // =1
    1fbc:      	lsl	w10, w10, w9
    1fc0:      	tst	w10, #0x3000000
    1fc4:      	b.eq	0x2030 <filter_inet+0x270>
    1fc8:      	ldrh	w8, [x1, #0x26]
    1fcc:      	cmp	w8, #0xa
    1fd0:      	b.eq	0x209c <filter_inet+0x2dc>
    1fd4:      	cmp	w8, #0x2
    1fd8:      	b.ne	0x210c <filter_inet+0x34c>
    1fdc:      	ldr	w8, [x0, #0x10]
    1fe0:      	mov	x22, x0
    1fe4:      	adrp	x0, 0x1000 <filter_16ty_selector_val+0x140>
    1fe8:      	add	x9, sp, #0x5c
    1fec:      	str	w8, [sp, #0x5c]
    1ff0:      	mov	w8, #0x1                // =1
    1ff4:      	add	x1, sp, #0x5c
    1ff8:      	ldr	x0, [x0]
    1ffc:      	blr	x8
    2000:      	cbz	x0, 0x214c <filter_inet+0x38c>
    2004:      	mov	w8, #0x20               // =32
    2008:      	add	x1, sp, #0x3c
    200c:      	stp	w8, w19, [sp, #0x3c]
    2010:      	b	0x20dc <filter_inet+0x31c>
    2014:      	ldp	w19, w20, [x1]
    2018:      	ldr	x21, [x1, #0x8]
    201c:      	mov	w10, wzr
    2020:      	mov	x8, xzr
    2024:      	cmp	w9, #0x11
    2028:      	b.le	0x1f34 <filter_inet+0x174>
    202c:      	b	0x1f90 <filter_inet+0x1d0>
    2030:      	sub	w9, w9, #0x12
    2034:      	cmp	w9, #0x2
    2038:      	b.hs	0x2044 <filter_inet+0x284>
    203c:      	add	x1, sp, #0xc
    2040:      	b	0x2134 <filter_inet+0x374>
    2044:      	ldp	x20, x19, [sp, #0x70]
    2048:      	mov	x0, x8
    204c:      	ldr	x30, [sp, #0x50]
    2050:      	ldp	x22, x21, [sp, #0x60]
    2054:      	add	sp, sp, #0x80
    2058:      	ret
    205c:      	cmp	w10, #0x400
    2060:      	cset	w8, lo
    2064:      	ldp	x20, x19, [sp, #0x70]
    2068:      	mov	x0, x8
    206c:      	ldr	x30, [sp, #0x50]
    2070:      	ldp	x22, x21, [sp, #0x60]
    2074:      	add	sp, sp, #0x80
    2078:      	ret
    207c:      	cmp	w10, #0x3ff
    2080:      	cset	w8, hi
    2084:      	ldp	x20, x19, [sp, #0x70]
    2088:      	mov	x0, x8
    208c:      	ldr	x30, [sp, #0x50]
    2090:      	ldp	x22, x21, [sp, #0x60]
    2094:      	add	sp, sp, #0x80
    2098:      	ret
    209c:      	ldr	w8, [x0, #0x14]
    20a0:      	mov	x22, x0
    20a4:      	adrp	x0, 0x2000 <filter_inet+0x240>
    20a8:      	add	x9, sp, #0x5c
    20ac:      	str	w8, [sp, #0x5c]
    20b0:      	mov	w8, #0x1                // =1
    20b4:      	add	x1, sp, #0x5c
    20b8:      	ldr	x0, [x0]
    20bc:      	blr	x8
    20c0:      	cbz	x0, 0x214c <filter_inet+0x38c>
    20c4:      	mov	w8, #0x80               // =128
    20c8:      	add	x1, sp, #0x3c
    20cc:      	stp	w20, w21, [sp, #0x44]
    20d0:      	stp	w8, w19, [sp, #0x3c]
    20d4:      	lsr	x8, x21, #32
    20d8:      	str	w8, [sp, #0x4c]
    20dc:      	mov	w8, #0x1                // =1
    20e0:      	blr	x8
    20e4:      	ldr	w8, [x22, #0x4]
    20e8:      	sub	w9, w8, #0x18
    20ec:      	cmp	w9, #0x2
    20f0:      	b.lo	0x215c <filter_inet+0x39c>
    20f4:      	sub	w8, w8, #0xd
    20f8:      	cmp	w8, #0x1
    20fc:      	b.hi	0x210c <filter_inet+0x34c>
    2100:      	cmp	x0, #0x0
    2104:      	cset	w8, ne
    2108:      	b	0x2164 <filter_inet+0x3a4>
    210c:      	mov	w8, wzr
    2110:      	ldp	x20, x19, [sp, #0x70]
    2114:      	mov	x0, x8
    2118:      	ldr	x30, [sp, #0x50]
    211c:      	ldp	x22, x21, [sp, #0x60]
    2120:      	add	sp, sp, #0x80
    2124:      	ret
    2128:      	ldrh	w8, [x1, #0x26]
    212c:      	str	w8, [sp, #0x58]
    2130:      	add	x1, sp, #0x58
    2134:      	bl	0xbb0 <filter_32ty_map>
    2138:      	ldp	x20, x19, [sp, #0x70]
    213c:      	ldr	x30, [sp, #0x50]
    2140:      	ldp	x22, x21, [sp, #0x60]
    2144:      	add	sp, sp, #0x80
    2148:      	ret
    214c:      	ldr	w8, [x22, #0x4]
    2150:      	and	w8, w8, #0xfffffffe
    2154:      	cmp	w8, #0x18
    2158:      	b	0x2160 <filter_inet+0x3a0>
    215c:      	cmp	x0, #0x0
    2160:      	cset	w8, eq
    2164:      	mov	w8, w8
    2168:      	ldp	x20, x19, [sp, #0x70]
    216c:      	mov	x0, x8
    2170:      	ldr	x30, [sp, #0x50]
    2174:      	ldp	x22, x21, [sp, #0x60]
    2178:      	add	sp, sp, #0x80
    217c:      	ret
    2180:      	cmp	w10, #0x29
    2184:      	b.ne	0x2194 <filter_inet+0x3d4>
    2188:      	cbz	x11, 0x2194 <filter_inet+0x3d4>
    218c:      	ldrb	w8, [x11, #0x3a]
    2190:      	str	w8, [sp, #0x58]
    2194:      	cmp	w10, #0x29
    2198:      	b.eq	0x2130 <filter_inet+0x370>
    219c:      	cmp	w10, #0x7
    21a0:      	b.eq	0x2130 <filter_inet+0x370>
    21a4:      	mov	x8, xzr
    21a8:      	ldp	x20, x19, [sp, #0x70]
    21ac:      	mov	x0, x8
    21b0:      	ldr	x30, [sp, #0x50]
    21b4:      	ldp	x22, x21, [sp, #0x60]
    21b8:      	add	sp, sp, #0x80
    21bc:      	ret

00000000000021c0 <filter_sockaddr_un>:
    21c0:      	sub	sp, sp, #0x20
    21c4:      	stp	x30, x19, [sp, #0x10]
    21c8:      	mov	x19, x0
    21cc:      	ldrb	w2, [x1, #0x3]
    21d0:      	mov	x0, xzr
    21d4:      	ldr	w8, [x19, #0x4]
    21d8:      	cmp	w8, #0x19
    21dc:      	b.gt	0x2230 <filter_sockaddr_un+0x70>
    21e0:      	sub	w9, w8, #0x3
    21e4:      	cmp	w9, #0x2
    21e8:      	b.hs	0x2244 <filter_sockaddr_un+0x84>
    21ec:      	add	x1, x1, #0x4
    21f0:      	mov	x0, x19
    21f4:      	bl	0x22b0 <filter_char_buf_equal>
    21f8:      	ldr	w8, [x19, #0x4]
    21fc:      	cmp	w8, #0x25
    2200:      	b.hi	0x2224 <filter_sockaddr_un+0x64>
    2204:      	mov	w9, #0x1                // =1
    2208:      	lsl	x8, x9, x8
    220c:      	mov	x9, #0x50               // =80
    2210:      	movk	x9, #0xc00, lsl #16
    2214:      	movk	x9, #0x20, lsl #32
    2218:      	tst	x8, x9
    221c:      	b.eq	0x2224 <filter_sockaddr_un+0x64>
    2220:      	eor	x0, x0, #0x1
    2224:      	ldp	x30, x19, [sp, #0x10]
    2228:      	add	sp, sp, #0x20
    222c:      	ret
    2230:      	cmp	w8, #0x1c
    2234:      	b.eq	0x2290 <filter_sockaddr_un+0xd0>
    2238:      	cmp	w8, #0x1a
    223c:      	b.eq	0x224c <filter_sockaddr_un+0x8c>
    2240:      	b	0x2224 <filter_sockaddr_un+0x64>
    2244:      	cmp	w8, #0x8
    2248:      	b.ne	0x2224 <filter_sockaddr_un+0x64>
    224c:      	ldr	w0, [x19, #0x10]
    2250:      	add	x1, x1, #0x4
    2254:      	bl	0x26e0 <filter_char_buf_prefix>
    2258:      	ldr	w8, [x19, #0x4]
    225c:      	cmp	w8, #0x25
    2260:      	b.hi	0x2224 <filter_sockaddr_un+0x64>
    2264:      	mov	w9, #0x1                // =1
    2268:      	lsl	x8, x9, x8
    226c:      	mov	x9, #0x50               // =80
    2270:      	movk	x9, #0xc00, lsl #16
    2274:      	movk	x9, #0x20, lsl #32
    2278:      	tst	x8, x9
    227c:      	b.eq	0x2224 <filter_sockaddr_un+0x64>
    2280:      	eor	x0, x0, #0x1
    2284:      	ldp	x30, x19, [sp, #0x10]
    2288:      	add	sp, sp, #0x20
    228c:      	ret
    2290:      	ldrh	w8, [x1]
    2294:      	add	x1, sp, #0xc
    2298:      	mov	x0, x19
    229c:      	str	w8, [sp, #0xc]
    22a0:      	bl	0xbb0 <filter_32ty_map>
    22a4:      	ldp	x30, x19, [sp, #0x10]
    22a8:      	add	sp, sp, #0x20
    22ac:      	ret

00000000000022b0 <filter_char_buf_equal>:
    22b0:      	str	x29, [sp, #-0x50]!
    22b4:      	stp	x30, x25, [sp, #0x10]
    22b8:      	stp	x24, x23, [sp, #0x20]
    22bc:      	stp	x22, x21, [sp, #0x30]
    22c0:      	stp	x20, x19, [sp, #0x40]
    22c4:      	cmp	w2, #0x1, lsl #12       // =0x1000
    22c8:      	str	wzr, [sp, #0x8]
    22cc:      	b.ls	0x22ec <filter_char_buf_equal+0x3c>
    22d0:      	mov	x0, xzr
    22d4:      	ldp	x20, x19, [sp, #0x40]
    22d8:      	ldp	x22, x21, [sp, #0x30]
    22dc:      	ldp	x24, x23, [sp, #0x20]
    22e0:      	ldp	x30, x25, [sp, #0x10]
    22e4:      	ldr	x29, [sp], #0x50
    22e8:      	ret
    22ec:      	and	w9, w2, #0xffff
    22f0:      	add	x8, x0, #0x10
    22f4:      	cmp	w9, #0x90
    22f8:      	b.hi	0x2368 <filter_char_buf_equal+0xb8>
    22fc:      	and	w9, w2, #0xff
    2300:      	mov	w10, #0xab              // =171
    2304:      	tst	w2, #0xffff
    2308:      	mul	w9, w9, w10
    230c:      	mov	w10, #0x18              // =24
    2310:      	lsr	w9, w9, #12
    2314:      	msub	w9, w9, w10, w2
    2318:      	b.eq	0x2328 <filter_char_buf_equal+0x78>
    231c:      	tst	w9, #0xff
    2320:      	mov	w23, w2
    2324:      	b.eq	0x2340 <filter_char_buf_equal+0x90>
    2328:      	sub	w9, w2, w9, uxtb
    232c:      	and	w10, w9, #0xffff
    2330:      	add	w9, w9, #0x18
    2334:      	and	w23, w9, #0xffff
    2338:      	cmp	w10, #0x78
    233c:      	b.hi	0x23dc <filter_char_buf_equal+0x12c>
    2340:      	and	w9, w23, #0xff
    2344:      	mov	w10, #0xab              // =171
    2348:      	mul	w9, w9, w10
    234c:      	lsr	w9, w9, #12
    2350:      	sub	w22, w9, #0x1
    2354:      	and	w9, w22, #0xf
    2358:      	ldr	w24, [x8, w9, uxtw #2]
    235c:      	cmn	w24, #0x1
    2360:      	b.ne	0x2454 <filter_char_buf_equal+0x1a4>
    2364:      	b	0x25fc <filter_char_buf_equal+0x34c>
    2368:      	cmp	w9, #0x101
    236c:      	b.hs	0x23ac <filter_char_buf_equal+0xfc>
    2370:      	mov	w23, #0x100             // =256
    2374:      	sub	w9, w23, #0x100
    2378:      	ror	w9, w9, #0x8
    237c:      	cmp	w9, #0x2
    2380:      	b.le	0x23ec <filter_char_buf_equal+0x13c>
    2384:      	cmp	w9, #0x3
    2388:      	b.eq	0x2428 <filter_char_buf_equal+0x178>
    238c:      	cmp	w9, #0x7
    2390:      	b.ne	0x2410 <filter_char_buf_equal+0x160>
    2394:      	mov	w22, #0x9               // =9
    2398:      	and	w9, w22, #0xf
    239c:      	ldr	w24, [x8, w9, uxtw #2]
    23a0:      	cmn	w24, #0x1
    23a4:      	b.ne	0x2454 <filter_char_buf_equal+0x1a4>
    23a8:      	b	0x25fc <filter_char_buf_equal+0x34c>
    23ac:      	and	w9, w2, #0xffff
    23b0:      	cmp	w9, #0x201
    23b4:      	b.hs	0x23d0 <filter_char_buf_equal+0x120>
    23b8:      	mov	w23, #0x200             // =512
    23bc:      	sub	w9, w23, #0x100
    23c0:      	ror	w9, w9, #0x8
    23c4:      	cmp	w9, #0x2
    23c8:      	b.le	0x23ec <filter_char_buf_equal+0x13c>
    23cc:      	b	0x2384 <filter_char_buf_equal+0xd4>
    23d0:      	cmp	w9, #0x401
    23d4:      	b.hs	0x25b4 <filter_char_buf_equal+0x304>
    23d8:      	mov	w23, #0x400             // =1024
    23dc:      	sub	w9, w23, #0x100
    23e0:      	ror	w9, w9, #0x8
    23e4:      	cmp	w9, #0x2
    23e8:      	b.gt	0x2384 <filter_char_buf_equal+0xd4>
    23ec:      	cbz	w9, 0x2440 <filter_char_buf_equal+0x190>
    23f0:      	cmp	w9, #0x1
    23f4:      	b.ne	0x2410 <filter_char_buf_equal+0x160>
    23f8:      	mov	w22, #0x7               // =7
    23fc:      	and	w9, w22, #0xf
    2400:      	ldr	w24, [x8, w9, uxtw #2]
    2404:      	cmn	w24, #0x1
    2408:      	b.ne	0x2454 <filter_char_buf_equal+0x1a4>
    240c:      	b	0x25fc <filter_char_buf_equal+0x34c>
    2410:      	mov	w22, #0xa               // =10
    2414:      	and	w9, w22, #0xf
    2418:      	ldr	w24, [x8, w9, uxtw #2]
    241c:      	cmn	w24, #0x1
    2420:      	b.ne	0x2454 <filter_char_buf_equal+0x1a4>
    2424:      	b	0x25fc <filter_char_buf_equal+0x34c>
    2428:      	mov	w22, #0x8               // =8
    242c:      	and	w9, w22, #0xf
    2430:      	ldr	w24, [x8, w9, uxtw #2]
    2434:      	cmn	w24, #0x1
    2438:      	b.ne	0x2454 <filter_char_buf_equal+0x1a4>
    243c:      	b	0x25fc <filter_char_buf_equal+0x34c>
    2440:      	mov	w22, #0x6               // =6
    2444:      	and	w9, w22, #0xf
    2448:      	ldr	w24, [x8, w9, uxtw #2]
    244c:      	cmn	w24, #0x1
    2450:      	b.eq	0x25fc <filter_char_buf_equal+0x34c>
    2454:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2458:      	add	x29, sp, #0x8
    245c:      	mov	w8, #0x1                // =1
    2460:      	ldr	x0, [x0]
    2464:      	mov	x25, x1
    2468:      	add	x1, sp, #0x8
    246c:      	mov	w21, w2
    2470:      	mov	w20, #0x1               // =1
    2474:      	blr	x8
    2478:      	mov	x19, x0
    247c:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2480:      	add	x1, sp, #0x8
    2484:      	ldr	x0, [x0]
    2488:      	blr	x20
    248c:      	mov	x20, x0
    2490:      	mov	x0, xzr
    2494:      	cbz	x19, 0x22d4 <filter_char_buf_equal+0x24>
    2498:      	cbz	x20, 0x22d4 <filter_char_buf_equal+0x24>
    249c:      	mov	x0, x19
    24a0:      	cmp	w22, #0x5
    24a4:      	b.gt	0x24dc <filter_char_buf_equal+0x22c>
    24a8:      	strb	w21, [x0], #0x1
    24ac:      	mov	w29, w21
    24b0:      	mov	w8, #0x4                // =4
    24b4:      	mov	x2, x25
    24b8:      	mov	w1, w21
    24bc:      	blr	x8
    24c0:      	subs	w8, w23, w21
    24c4:      	b.ls	0x2514 <filter_char_buf_equal+0x264>
    24c8:      	add	x9, x19, x29
    24cc:      	and	w1, w8, #0xfff
    24d0:      	mov	w8, #0x4                // =4
    24d4:      	add	x0, x9, #0x1
    24d8:      	b	0x250c <filter_char_buf_equal+0x25c>
    24dc:      	strh	w21, [x0], #0x2
    24e0:      	mov	w29, w21
    24e4:      	mov	w8, #0x4                // =4
    24e8:      	mov	x2, x25
    24ec:      	mov	w1, w21
    24f0:      	blr	x8
    24f4:      	subs	w8, w23, w21
    24f8:      	b.ls	0x2514 <filter_char_buf_equal+0x264>
    24fc:      	add	x9, x19, x29
    2500:      	and	w1, w8, #0xfff
    2504:      	mov	w8, #0x4                // =4
    2508:      	add	x0, x9, #0x2
    250c:      	mov	x2, x20
    2510:      	blr	x8
    2514:      	cmp	w22, #0x4
    2518:      	str	w24, [sp, #0xc]
    251c:      	b.le	0x2554 <filter_char_buf_equal+0x2a4>
    2520:      	cmp	w22, #0x7
    2524:      	b.gt	0x2588 <filter_char_buf_equal+0x2d8>
    2528:      	cmp	w22, #0x5
    252c:      	b.eq	0x267c <filter_char_buf_equal+0x3cc>
    2530:      	cmp	w22, #0x6
    2534:      	b.eq	0x2640 <filter_char_buf_equal+0x390>
    2538:      	cmp	w22, #0x7
    253c:      	b.ne	0x25fc <filter_char_buf_equal+0x34c>
    2540:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2544:      	mov	w8, #0x1                // =1
    2548:      	add	x9, sp, #0xc
    254c:      	ldr	x0, [x0]
    2550:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    2554:      	cmp	w22, #0x1
    2558:      	b.le	0x25dc <filter_char_buf_equal+0x32c>
    255c:      	cmp	w22, #0x2
    2560:      	b.eq	0x2668 <filter_char_buf_equal+0x3b8>
    2564:      	cmp	w22, #0x3
    2568:      	b.eq	0x262c <filter_char_buf_equal+0x37c>
    256c:      	cmp	w22, #0x4
    2570:      	b.ne	0x25fc <filter_char_buf_equal+0x34c>
    2574:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2578:      	mov	w8, #0x1                // =1
    257c:      	add	x9, sp, #0xc
    2580:      	ldr	x0, [x0]
    2584:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    2588:      	cmp	w22, #0x8
    258c:      	b.eq	0x2690 <filter_char_buf_equal+0x3e0>
    2590:      	cmp	w22, #0x9
    2594:      	b.eq	0x2654 <filter_char_buf_equal+0x3a4>
    2598:      	cmp	w22, #0xa
    259c:      	b.ne	0x25fc <filter_char_buf_equal+0x34c>
    25a0:      	adrp	x0, 0x2000 <filter_inet+0x240>
    25a4:      	mov	w8, #0x1                // =1
    25a8:      	add	x9, sp, #0xc
    25ac:      	ldr	x0, [x0]
    25b0:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    25b4:      	and	w9, w2, #0xffff
    25b8:      	mov	w10, #0x1000            // =4096
    25bc:      	cmp	w9, #0x800
    25c0:      	mov	w9, #0x800              // =2048
    25c4:      	csel	w23, w10, w9, hi
    25c8:      	sub	w9, w23, #0x100
    25cc:      	ror	w9, w9, #0x8
    25d0:      	cmp	w9, #0x2
    25d4:      	b.le	0x23ec <filter_char_buf_equal+0x13c>
    25d8:      	b	0x2384 <filter_char_buf_equal+0xd4>
    25dc:      	cbz	w22, 0x2618 <filter_char_buf_equal+0x368>
    25e0:      	cmp	w22, #0x1
    25e4:      	b.ne	0x25fc <filter_char_buf_equal+0x34c>
    25e8:      	adrp	x0, 0x2000 <filter_inet+0x240>
    25ec:      	mov	w8, #0x1                // =1
    25f0:      	add	x9, sp, #0xc
    25f4:      	ldr	x0, [x0]
    25f8:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    25fc:      	mov	x0, xzr
    2600:      	ldp	x20, x19, [sp, #0x40]
    2604:      	ldp	x22, x21, [sp, #0x30]
    2608:      	ldp	x24, x23, [sp, #0x20]
    260c:      	ldp	x30, x25, [sp, #0x10]
    2610:      	ldr	x29, [sp], #0x50
    2614:      	ret
    2618:      	adrp	x0, 0x2000 <filter_inet+0x240>
    261c:      	mov	w8, #0x1                // =1
    2620:      	add	x9, sp, #0xc
    2624:      	ldr	x0, [x0]
    2628:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    262c:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2630:      	mov	w8, #0x1                // =1
    2634:      	add	x9, sp, #0xc
    2638:      	ldr	x0, [x0]
    263c:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    2640:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2644:      	mov	w8, #0x1                // =1
    2648:      	add	x9, sp, #0xc
    264c:      	ldr	x0, [x0]
    2650:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    2654:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2658:      	mov	w8, #0x1                // =1
    265c:      	add	x9, sp, #0xc
    2660:      	ldr	x0, [x0]
    2664:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    2668:      	adrp	x0, 0x2000 <filter_inet+0x240>
    266c:      	mov	w8, #0x1                // =1
    2670:      	add	x9, sp, #0xc
    2674:      	ldr	x0, [x0]
    2678:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    267c:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2680:      	mov	w8, #0x1                // =1
    2684:      	add	x9, sp, #0xc
    2688:      	ldr	x0, [x0]
    268c:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    2690:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2694:      	mov	w8, #0x1                // =1
    2698:      	add	x9, sp, #0xc
    269c:      	ldr	x0, [x0]
    26a0:      	add	x1, sp, #0xc
    26a4:      	blr	x8
    26a8:      	cbz	x0, 0x22d4 <filter_char_buf_equal+0x24>
    26ac:      	mov	w8, #0x1                // =1
    26b0:      	mov	x1, x19
    26b4:      	blr	x8
    26b8:      	cmp	x0, #0x0
    26bc:      	cset	w0, ne
    26c0:      	ldp	x20, x19, [sp, #0x40]
    26c4:      	ldp	x22, x21, [sp, #0x30]
    26c8:      	ldp	x24, x23, [sp, #0x20]
    26cc:      	ldp	x30, x25, [sp, #0x10]
    26d0:      	ldr	x29, [sp], #0x50
    26d4:      	ret
    26d8:      	nop
    26dc:      	nop

00000000000026e0 <filter_char_buf_prefix>:
    26e0:      	sub	sp, sp, #0x30
    26e4:      	stp	x30, x21, [sp, #0x10]
    26e8:      	stp	x20, x19, [sp, #0x20]
    26ec:      	stp	wzr, w0, [sp, #0x8]
    26f0:      	adrp	x0, 0x2000 <filter_inet+0x240>
    26f4:      	mov	w8, #0x1                // =1
    26f8:      	add	x9, sp, #0xc
    26fc:      	ldr	x0, [x0]
    2700:      	mov	x19, x1
    2704:      	add	x1, sp, #0xc
    2708:      	mov	w20, w2
    270c:      	blr	x8
    2710:      	mov	x8, x0
    2714:      	mov	x0, xzr
    2718:      	cbz	w20, 0x2784 <filter_char_buf_prefix+0xa4>
    271c:      	cbz	x8, 0x2784 <filter_char_buf_prefix+0xa4>
    2720:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2724:      	mov	x21, x8
    2728:      	mov	w8, #0x1                // =1
    272c:      	ldr	x0, [x0]
    2730:      	add	x9, sp, #0x8
    2734:      	add	x1, sp, #0x8
    2738:      	blr	x8
    273c:      	cbz	x0, 0x2784 <filter_char_buf_prefix+0xa4>
    2740:      	cmp	w20, #0xff
    2744:      	mov	w8, #0xff               // =255
    2748:      	mov	x2, x19
    274c:      	csel	w1, w20, w8, lo
    2750:      	mov	x8, x0
    2754:      	mov	x20, x0
    2758:      	lsl	w9, w1, #3
    275c:      	str	w9, [x8], #0x4
    2760:      	mov	w9, #0x4                // =4
    2764:      	mov	x0, x8
    2768:      	blr	x9
    276c:      	mov	w8, #0x1                // =1
    2770:      	mov	x0, x21
    2774:      	mov	x1, x20
    2778:      	blr	x8
    277c:      	cmp	x0, #0x0
    2780:      	cset	w0, ne
    2784:      	ldp	x20, x19, [sp, #0x20]
    2788:      	ldp	x30, x21, [sp, #0x10]
    278c:      	add	sp, sp, #0x30
    2790:      	ret
    2794:      	nop
    2798:      	nop
    279c:      	nop

00000000000027a0 <filter_char_buf_postfix>:
    27a0:      	sub	sp, sp, #0x30
    27a4:      	stp	x30, x21, [sp, #0x10]
    27a8:      	stp	x20, x19, [sp, #0x20]
    27ac:      	stp	wzr, w0, [sp, #0x8]
    27b0:      	adrp	x0, 0x2000 <filter_inet+0x240>
    27b4:      	mov	w8, #0x1                // =1
    27b8:      	add	x9, sp, #0xc
    27bc:      	ldr	x0, [x0]
    27c0:      	mov	x19, x1
    27c4:      	add	x1, sp, #0xc
    27c8:      	mov	w20, w2
    27cc:      	blr	x8
    27d0:      	mov	x8, x0
    27d4:      	mov	x0, xzr
    27d8:      	cbz	w20, 0x2860 <filter_char_buf_postfix+0xc0>
    27dc:      	cbz	x8, 0x2860 <filter_char_buf_postfix+0xc0>
    27e0:      	adrp	x0, 0x2000 <filter_inet+0x240>
    27e4:      	mov	x21, x8
    27e8:      	mov	w8, #0x1                // =1
    27ec:      	ldr	x0, [x0]
    27f0:      	add	x9, sp, #0x8
    27f4:      	add	x1, sp, #0x8
    27f8:      	blr	x8
    27fc:      	cbz	x0, 0x2860 <filter_char_buf_postfix+0xc0>
    2800:      	cmp	w20, #0x7f
    2804:      	mov	w9, #0x7f               // =127
    2808:      	mov	x1, x0
    280c:      	mov	x8, xzr
    2810:      	sub	w10, w20, #0x1
    2814:      	csel	w9, w20, w9, lo
    2818:      	lsl	w9, w9, #3
    281c:      	str	w9, [x0]
    2820:      	mov	w9, w20
    2824:      	cmp	x8, #0x7f
    2828:      	b.eq	0x284c <filter_char_buf_postfix+0xac>
    282c:      	and	x11, x10, #0xfff
    2830:      	add	x12, x1, x8
    2834:      	add	x8, x8, #0x1
    2838:      	ldrb	w11, [x19, x11]
    283c:      	sub	w10, w10, #0x1
    2840:      	cmp	x9, x8
    2844:      	strb	w11, [x12, #0x4]
    2848:      	b.ne	0x2824 <filter_char_buf_postfix+0x84>
    284c:      	mov	w8, #0x1                // =1
    2850:      	mov	x0, x21
    2854:      	blr	x8
    2858:      	cmp	x0, #0x0
    285c:      	cset	w0, ne
    2860:      	ldp	x20, x19, [sp, #0x20]
    2864:      	ldp	x30, x21, [sp, #0x10]
    2868:      	add	sp, sp, #0x30
    286c:      	ret

0000000000002870 <filter_file_type>:
    2870:      	sub	sp, sp, #0x20
    2874:      	stp	x30, x19, [sp, #0x10]
    2878:      	ldr	w8, [x1]
    287c:      	strh	wzr, [sp, #0xc]
    2880:      	cmp	w8, #0x1, lsl #12       // =0x1000
    2884:      	b.hi	0x295c <filter_file_type+0xec>
    2888:      	add	x9, x1, #0x4
    288c:      	mov	w10, #0x2               // =2
    2890:      	mov	w11, #0x4               // =4
    2894:      	add	x12, sp, #0xc
    2898:      	mov	x19, x0
    289c:      	add	x0, sp, #0xc
    28a0:      	add	x8, x9, x8
    28a4:      	add	x8, x8, #0x4
    28a8:      	ldr	w8, [x1]
    28ac:      	mov	w1, #0x2                // =2
    28b0:      	add	x8, x9, x8
    28b4:      	add	x2, x8, #0x4
    28b8:      	blr	x11
    28bc:      	ldr	w9, [x19, #0x10]
    28c0:      	cbz	w9, 0x295c <filter_file_type+0xec>
    28c4:      	ldrh	w8, [sp, #0xc]
    28c8:      	and	w8, w8, #0xf000
    28cc:      	cmp	w9, w8
    28d0:      	b.ne	0x28e4 <filter_file_type+0x74>
    28d4:      	mov	w0, #0x1                // =1
    28d8:      	ldp	x30, x19, [sp, #0x10]
    28dc:      	add	sp, sp, #0x20
    28e0:      	ret
    28e4:      	ldr	w9, [x19, #0x8]
    28e8:      	cmp	w9, #0xc
    28ec:      	b.ls	0x295c <filter_file_type+0xec>
    28f0:      	ldr	w10, [x19, #0x14]
    28f4:      	cbz	w10, 0x295c <filter_file_type+0xec>
    28f8:      	cmp	w10, w8
    28fc:      	b.ne	0x2910 <filter_file_type+0xa0>
    2900:      	mov	w0, #0x1                // =1
    2904:      	ldp	x30, x19, [sp, #0x10]
    2908:      	add	sp, sp, #0x20
    290c:      	ret
    2910:      	cmp	w9, #0x11
    2914:      	b.lo	0x295c <filter_file_type+0xec>
    2918:      	ldr	w10, [x19, #0x18]
    291c:      	cbz	w10, 0x295c <filter_file_type+0xec>
    2920:      	cmp	w10, w8
    2924:      	b.ne	0x2938 <filter_file_type+0xc8>
    2928:      	mov	w0, #0x1                // =1
    292c:      	ldp	x30, x19, [sp, #0x10]
    2930:      	add	sp, sp, #0x20
    2934:      	ret
    2938:      	cmp	w9, #0x15
    293c:      	b.lo	0x295c <filter_file_type+0xec>
    2940:      	ldr	w9, [x19, #0x1c]
    2944:      	cbz	w9, 0x295c <filter_file_type+0xec>
    2948:      	cmp	w9, w8
    294c:      	cset	w0, eq
    2950:      	ldp	x30, x19, [sp, #0x10]
    2954:      	add	sp, sp, #0x20
    2958:      	ret
    295c:      	mov	x0, xzr
    2960:      	ldp	x30, x19, [sp, #0x10]
    2964:      	add	sp, sp, #0x20
    2968:      	ret
    296c:      	nop

0000000000002970 <filter_char_substring>:
    2970:      	str	x29, [sp, #-0x50]!
    2974:      	stp	x30, x25, [sp, #0x10]
    2978:      	stp	x24, x23, [sp, #0x20]
    297c:      	stp	x22, x21, [sp, #0x30]
    2980:      	stp	x20, x19, [sp, #0x40]
    2984:      	mov	x21, x1
    2988:      	mov	x19, x0
    298c:      	add	x23, x0, #0x10
    2990:      	mov	w24, w2
    2994:      	tbz	w3, #0x0, 0x2a88 <filter_char_substring+0x118>
    2998:      	cbz	w2, 0x2b48 <filter_char_substring+0x1d8>
    299c:      	adrp	x22, 0x2000 <filter_inet+0x240>
    29a0:      	mov	x25, xzr
    29a4:      	mov	w29, wzr
    29a8:      	ldr	x22, [x22]
    29ac:      	add	x20, sp, #0xc
    29b0:      	nop
    29b4:      	nop
    29b8:      	nop
    29bc:      	nop
    29c0:      	ldr	w8, [x23, x25, lsl #2]
    29c4:      	add	x1, sp, #0xc
    29c8:      	mov	x0, x22
    29cc:      	str	w8, [sp, #0xc]
    29d0:      	mov	w8, #0x1                // =1
    29d4:      	blr	x8
    29d8:      	cbz	x0, 0x2be8 <filter_char_substring+0x278>
    29dc:      	mov	x8, xzr
    29e0:      	mov	x9, x21
    29e4:      	mov	x10, x24
    29e8:      	b	0x2a00 <filter_char_substring+0x90>
    29ec:      	add	x8, x8, #0x1
    29f0:      	sub	x10, x10, #0x1
    29f4:      	add	x9, x9, #0x1
    29f8:      	cmp	x8, x24
    29fc:      	b.eq	0x2a64 <filter_char_substring+0xf4>
    2a00:      	mov	x11, xzr
    2a04:      	cmp	x10, x11
    2a08:      	b.eq	0x29ec <filter_char_substring+0x7c>
    2a0c:      	ldrb	w12, [x0, x11]
    2a10:      	cbz	w12, 0x2a60 <filter_char_substring+0xf0>
    2a14:      	ldrb	w13, [x9, x11]
    2a18:      	sub	w14, w13, #0x41
    2a1c:      	orr	w15, w13, #0x20
    2a20:      	cmp	w14, #0x1a
    2a24:      	sub	w14, w12, #0x41
    2a28:      	csel	w13, w15, w13, lo
    2a2c:      	orr	w15, w12, #0x20
    2a30:      	cmp	w14, #0x1a
    2a34:      	csel	w12, w15, w12, lo
    2a38:      	cmp	x11, #0x62
    2a3c:      	b.hi	0x29ec <filter_char_substring+0x7c>
    2a40:      	add	x11, x11, #0x1
    2a44:      	cmp	w13, w12
    2a48:      	b.eq	0x2a04 <filter_char_substring+0x94>
    2a4c:      	b	0x29ec <filter_char_substring+0x7c>
    2a50:      	nop
    2a54:      	nop
    2a58:      	nop
    2a5c:      	nop
    2a60:      	tbz	w8, #0x1f, 0x2c00 <filter_char_substring+0x290>
    2a64:      	ldr	w9, [x19, #0x8]
    2a68:      	add	w8, w29, #0xc
    2a6c:      	cmp	w8, w9
    2a70:      	b.hs	0x2be4 <filter_char_substring+0x274>
    2a74:      	add	x25, x25, #0x1
    2a78:      	add	w29, w29, #0x4
    2a7c:      	cmp	x25, #0x64
    2a80:      	b.ne	0x29c0 <filter_char_substring+0x50>
    2a84:      	b	0x2be4 <filter_char_substring+0x274>
    2a88:      	cbz	w2, 0x2b9c <filter_char_substring+0x22c>
    2a8c:      	adrp	x22, 0x2000 <filter_inet+0x240>
    2a90:      	mov	x25, xzr
    2a94:      	mov	w29, wzr
    2a98:      	ldr	x22, [x22]
    2a9c:      	add	x20, sp, #0xc
    2aa0:      	ldr	w8, [x23, x25, lsl #2]
    2aa4:      	add	x1, sp, #0xc
    2aa8:      	mov	x0, x22
    2aac:      	str	w8, [sp, #0xc]
    2ab0:      	mov	w8, #0x1                // =1
    2ab4:      	blr	x8
    2ab8:      	cbz	x0, 0x2be8 <filter_char_substring+0x278>
    2abc:      	mov	x8, xzr
    2ac0:      	mov	x9, x21
    2ac4:      	mov	x10, x24
    2ac8:      	b	0x2ae0 <filter_char_substring+0x170>
    2acc:      	add	x8, x8, #0x1
    2ad0:      	sub	x10, x10, #0x1
    2ad4:      	add	x9, x9, #0x1
    2ad8:      	cmp	x8, x24
    2adc:      	b.eq	0x2b24 <filter_char_substring+0x1b4>
    2ae0:      	mov	x11, xzr
    2ae4:      	cmp	x10, x11
    2ae8:      	b.eq	0x2acc <filter_char_substring+0x15c>
    2aec:      	ldrb	w12, [x0, x11]
    2af0:      	cbz	w12, 0x2b20 <filter_char_substring+0x1b0>
    2af4:      	cmp	x11, #0x62
    2af8:      	b.hi	0x2acc <filter_char_substring+0x15c>
    2afc:      	ldrb	w13, [x9, x11]
    2b00:      	add	x11, x11, #0x1
    2b04:      	cmp	w13, w12
    2b08:      	b.eq	0x2ae4 <filter_char_substring+0x174>
    2b0c:      	b	0x2acc <filter_char_substring+0x15c>
    2b10:      	nop
    2b14:      	nop
    2b18:      	nop
    2b1c:      	nop
    2b20:      	tbz	w8, #0x1f, 0x2c00 <filter_char_substring+0x290>
    2b24:      	ldr	w9, [x19, #0x8]
    2b28:      	add	w8, w29, #0xc
    2b2c:      	cmp	w8, w9
    2b30:      	b.hs	0x2be4 <filter_char_substring+0x274>
    2b34:      	add	x25, x25, #0x1
    2b38:      	add	w29, w29, #0x4
    2b3c:      	cmp	x25, #0x64
    2b40:      	b.ne	0x2aa0 <filter_char_substring+0x130>
    2b44:      	b	0x2be4 <filter_char_substring+0x274>
    2b48:      	adrp	x20, 0x2000 <filter_inet+0x240>
    2b4c:      	mov	w21, #0x10              // =16
    2b50:      	add	x22, sp, #0xc
    2b54:      	ldr	x20, [x20]
    2b58:      	nop
    2b5c:      	nop
    2b60:      	ldr	w8, [x19, x21]
    2b64:      	add	x1, sp, #0xc
    2b68:      	mov	x0, x20
    2b6c:      	str	w8, [sp, #0xc]
    2b70:      	mov	w8, #0x1                // =1
    2b74:      	blr	x8
    2b78:      	cbz	x0, 0x2be8 <filter_char_substring+0x278>
    2b7c:      	ldr	w8, [x19, #0x8]
    2b80:      	add	x21, x21, #0x4
    2b84:      	sub	w9, w21, #0x8
    2b88:      	cmp	w9, w8
    2b8c:      	b.hs	0x2be4 <filter_char_substring+0x274>
    2b90:      	cmp	x21, #0x1a0
    2b94:      	b.ne	0x2b60 <filter_char_substring+0x1f0>
    2b98:      	b	0x2be4 <filter_char_substring+0x274>
    2b9c:      	adrp	x20, 0x2000 <filter_inet+0x240>
    2ba0:      	mov	w21, #0x10              // =16
    2ba4:      	add	x22, sp, #0xc
    2ba8:      	ldr	x20, [x20]
    2bac:      	ldr	w8, [x19, x21]
    2bb0:      	add	x1, sp, #0xc
    2bb4:      	mov	x0, x20
    2bb8:      	str	w8, [sp, #0xc]
    2bbc:      	mov	w8, #0x1                // =1
    2bc0:      	blr	x8
    2bc4:      	cbz	x0, 0x2be8 <filter_char_substring+0x278>
    2bc8:      	ldr	w8, [x19, #0x8]
    2bcc:      	add	x21, x21, #0x4
    2bd0:      	sub	w9, w21, #0x8
    2bd4:      	cmp	w9, w8
    2bd8:      	b.hs	0x2be4 <filter_char_substring+0x274>
    2bdc:      	cmp	x21, #0x1a0
    2be0:      	b.ne	0x2bac <filter_char_substring+0x23c>
    2be4:      	mov	x0, xzr
    2be8:      	ldp	x20, x19, [sp, #0x40]
    2bec:      	ldp	x22, x21, [sp, #0x30]
    2bf0:      	ldp	x24, x23, [sp, #0x20]
    2bf4:      	ldp	x30, x25, [sp, #0x10]
    2bf8:      	ldr	x29, [sp], #0x50
    2bfc:      	ret
    2c00:      	mov	w0, #0x1                // =1
    2c04:      	ldp	x20, x19, [sp, #0x40]
    2c08:      	ldp	x22, x21, [sp, #0x30]
    2c0c:      	ldp	x24, x23, [sp, #0x20]
    2c10:      	ldp	x30, x25, [sp, #0x10]
    2c14:      	ldr	x29, [sp], #0x50
    2c18:      	ret
    2c1c:      	nop

0000000000002c20 <do_action>:
    2c20:      	sub	sp, sp, #0xc0
    2c24:      	str	x29, [sp, #0x70]
    2c28:      	stp	x30, x25, [sp, #0x80]
    2c2c:      	stp	x24, x23, [sp, #0x90]
    2c30:      	stp	x22, x21, [sp, #0xa0]
    2c34:      	stp	x20, x19, [sp, #0xb0]
    2c38:      	add	x8, x2, w1, uxtw #2
    2c3c:      	str	wzr, [sp, #0x44]
    2c40:      	adrp	x24, 0x2000 <filter_inet+0x240>
    2c44:      	add	x9, sp, #0x44
    2c48:      	mov	w19, w1
    2c4c:      	ldrsw	x22, [x8, #0x4]
    2c50:      	ldr	x24, [x24]
    2c54:      	mov	w8, #0x1                // =1
    2c58:      	mov	x20, x0
    2c5c:      	add	x1, sp, #0x44
    2c60:      	mov	w25, w4
    2c64:      	mov	x23, x3
    2c68:      	mov	x21, x2
    2c6c:      	mov	x0, x24
    2c70:      	blr	x8
    2c74:      	cbz	x0, 0x3118 <do_action+0x4f8>
    2c78:      	mov	x29, x0
    2c7c:      	cmp	w22, #0x7
    2c80:      	b.gt	0x2ca4 <do_action+0x84>
    2c84:      	cmp	w22, #0x3
    2c88:      	b.gt	0x2cec <do_action+0xcc>
    2c8c:      	cmp	w22, #0x1
    2c90:      	b.gt	0x2e18 <do_action+0x1f8>
    2c94:      	cbz	w22, 0x3008 <do_action+0x3e8>
    2c98:      	cmp	w22, #0x1
    2c9c:      	b.eq	0x2e28 <do_action+0x208>
    2ca0:      	b	0x3110 <do_action+0x4f0>
    2ca4:      	cmp	w22, #0xb
    2ca8:      	b.gt	0x2df0 <do_action+0x1d0>
    2cac:      	sub	w8, w22, #0xa
    2cb0:      	cmp	w8, #0x2
    2cb4:      	b.lo	0x2f18 <do_action+0x2f8>
    2cb8:      	cmp	w22, #0x8
    2cbc:      	b.eq	0x2f64 <do_action+0x344>
    2cc0:      	cmp	w22, #0x9
    2cc4:      	b.ne	0x3110 <do_action+0x4f0>
    2cc8:      	add	w19, w19, #0x1
    2ccc:      	add	x8, x21, w19, uxtw #2
    2cd0:      	ldr	w0, [x8, #0x4]
    2cd4:      	tbz	w25, #0x0, 0x30b4 <do_action+0x494>
    2cd8:      	sxtw	x8, w0
    2cdc:      	mov	w9, #0x6d               // =109
    2ce0:      	blr	x9
    2ce4:      	mov	w20, #0x2               // =2
    2ce8:      	b	0x30cc <do_action+0x4ac>
    2cec:      	sub	w8, w22, #0x6
    2cf0:      	cmp	w8, #0x2
    2cf4:      	b.lo	0x2f50 <do_action+0x330>
    2cf8:      	cmp	w22, #0x4
    2cfc:      	b.eq	0x2f6c <do_action+0x34c>
    2d00:      	cmp	w22, #0x5
    2d04:      	b.ne	0x3110 <do_action+0x4f0>
    2d08:      	add	w9, w19, #0x1
    2d0c:      	add	x8, x21, #0x4
    2d10:      	add	w19, w19, #0x2
    2d14:      	ldr	w9, [x8, w9, uxtw #2]
    2d18:      	and	x9, x9, #0x7
    2d1c:      	cmp	w9, #0x4
    2d20:      	b.hi	0x3110 <do_action+0x4f0>
    2d24:      	add	x10, x29, x9, lsl #2
    2d28:      	mov	w11, #0x5ea0            // =24224
    2d2c:      	ldr	w10, [x10, x11]
    2d30:      	cbnz	w10, 0x3110 <do_action+0x4f0>
    2d34:      	ldr	w20, [x8, w19, uxtw #2]
    2d38:      	add	x8, x29, x9, lsl #3
    2d3c:      	ldr	x8, [x8, #0x5e78]
    2d40:      	str	wzr, [sp, #0x54]
    2d44:      	and	x8, x8, #0x7ff
    2d48:      	add	x8, x29, x8
    2d4c:      	ldr	w8, [x8, #0x90]
    2d50:      	str	w8, [sp, #0x50]
    2d54:      	mov	w8, #0xe                // =14
    2d58:      	blr	x8
    2d5c:      	lsr	x8, x0, #32
    2d60:      	adrp	x21, 0x2000 <filter_inet+0x240>
    2d64:      	add	x9, sp, #0x48
    2d68:      	str	x8, [sp, #0x48]
    2d6c:      	mov	w8, #0x1                // =1
    2d70:      	add	x1, sp, #0x48
    2d74:      	ldr	x21, [x21]
    2d78:      	mov	x0, x21
    2d7c:      	blr	x8
    2d80:      	cbz	x0, 0x3110 <do_action+0x4f0>
    2d84:      	and	x8, x20, #0x7
    2d88:      	cmp	w8, #0x4
    2d8c:      	b.hi	0x3110 <do_action+0x4f0>
    2d90:      	add	x9, x29, x8, lsl #2
    2d94:      	mov	w10, #0x5ea0            // =24224
    2d98:      	ldr	w9, [x9, x10]
    2d9c:      	cbnz	w9, 0x3110 <do_action+0x4f0>
    2da0:      	add	x8, x29, x8, lsl #3
    2da4:      	mov	x23, x0
    2da8:      	ldr	x8, [x8, #0x5e78]
    2dac:      	str	wzr, [sp, #0x54]
    2db0:      	and	x8, x8, #0x7ff
    2db4:      	add	x8, x29, x8
    2db8:      	ldr	w8, [x8, #0x90]
    2dbc:      	str	w8, [sp, #0x50]
    2dc0:      	mov	w8, #0xe                // =14
    2dc4:      	blr	x8
    2dc8:      	lsr	x8, x0, #32
    2dcc:      	mov	x3, xzr
    2dd0:      	add	x9, sp, #0x48
    2dd4:      	str	x8, [sp, #0x48]
    2dd8:      	mov	w8, #0x2                // =2
    2ddc:      	add	x1, sp, #0x48
    2de0:      	mov	x0, x21
    2de4:      	mov	x2, x23
    2de8:      	blr	x8
    2dec:      	b	0x3110 <do_action+0x4f0>
    2df0:      	cmp	w22, #0xc
    2df4:      	b.eq	0x30bc <do_action+0x49c>
    2df8:      	cmp	w22, #0xd
    2dfc:      	b.eq	0x2f7c <do_action+0x35c>
    2e00:      	cmp	w22, #0xe
    2e04:      	b.ne	0x3110 <do_action+0x4f0>
    2e08:      	tst	w25, #0x1
    2e0c:      	mov	w8, #0x8                // =8
    2e10:      	add	w19, w19, #0x2
    2e14:      	b	0x30c8 <do_action+0x4a8>
    2e18:      	cmp	w22, #0x2
    2e1c:      	b.eq	0x30ac <do_action+0x48c>
    2e20:      	cmp	w22, #0x3
    2e24:      	b.ne	0x3110 <do_action+0x4f0>
    2e28:      	add	w8, w19, #0x1
    2e2c:      	add	x9, x21, #0x4
    2e30:      	add	w19, w19, #0x2
    2e34:      	str	wzr, [sp, #0x58]
    2e38:      	ldr	w21, [x9, w8, uxtw #2]
    2e3c:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2e40:      	ldr	w20, [x9, w19, uxtw #2]
    2e44:      	ldr	x0, [x0]
    2e48:      	mov	w8, #0x1                // =1
    2e4c:      	add	x9, sp, #0x58
    2e50:      	add	x1, sp, #0x58
    2e54:      	blr	x8
    2e58:      	cbz	x0, 0x2f44 <do_action+0x324>
    2e5c:      	and	x8, x21, #0x7
    2e60:      	cmp	w8, #0x4
    2e64:      	b.hi	0x2f40 <do_action+0x320>
    2e68:      	add	x9, x29, x8, lsl #2
    2e6c:      	mov	w10, #0x5ea0            // =24224
    2e70:      	ldr	w9, [x9, x10]
    2e74:      	cbnz	w9, 0x2f40 <do_action+0x320>
    2e78:      	add	x8, x29, x8, lsl #3
    2e7c:      	mov	x21, x0
    2e80:      	ldr	x8, [x8, #0x5e78]
    2e84:      	str	wzr, [sp, #0x54]
    2e88:      	and	x8, x8, #0x7ff
    2e8c:      	add	x8, x29, x8
    2e90:      	ldr	w8, [x8, #0x90]
    2e94:      	str	w8, [sp, #0x50]
    2e98:      	mov	w8, #0xe                // =14
    2e9c:      	blr	x8
    2ea0:      	lsr	x8, x0, #32
    2ea4:      	cmp	w22, #0x1
    2ea8:      	str	x8, [sp, #0x48]
    2eac:      	b.ne	0x323c <do_action+0x61c>
    2eb0:      	and	x8, x20, #0x7
    2eb4:      	cmp	w8, #0x4
    2eb8:      	b.hi	0x2f40 <do_action+0x320>
    2ebc:      	add	x9, x29, x8, lsl #2
    2ec0:      	mov	w10, #0x5ea0            // =24224
    2ec4:      	ldr	w9, [x9, x10]
    2ec8:      	cbnz	w9, 0x2f40 <do_action+0x320>
    2ecc:      	add	x8, x29, x8, lsl #3
    2ed0:      	mov	x0, x21
    2ed4:      	ldr	x8, [x8, #0x5e78]
    2ed8:      	and	x8, x8, #0x7ff
    2edc:      	add	x2, x29, x8
    2ee0:      	ldr	w8, [x2, #0x90]!
    2ee4:      	and	x8, x8, #0xfff
    2ee8:      	add	x1, x8, #0x8
    2eec:      	mov	w8, #0x4                // =4
    2ef0:      	blr	x8
    2ef4:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2ef8:      	mov	x3, xzr
    2efc:      	mov	w8, #0x2                // =2
    2f00:      	ldr	x0, [x0]
    2f04:      	add	x9, sp, #0x48
    2f08:      	add	x1, sp, #0x48
    2f0c:      	mov	x2, x21
    2f10:      	blr	x8
    2f14:      	b	0x2f40 <do_action+0x320>
    2f18:      	add	w19, w19, #0x1
    2f1c:      	add	x8, x21, w19, uxtw #2
    2f20:      	ldr	w8, [x8, #0x4]
    2f24:      	and	x8, x8, #0x7
    2f28:      	cmp	w8, #0x4
    2f2c:      	b.hi	0x2f40 <do_action+0x320>
    2f30:      	add	x9, x29, x8, lsl #2
    2f34:      	mov	w10, #0x5ea0            // =24224
    2f38:      	ldr	w9, [x9, x10]
    2f3c:      	cbz	w9, 0x3134 <do_action+0x514>
    2f40:      	mov	w0, wzr
    2f44:      	cbz	w0, 0x3110 <do_action+0x4f0>
    2f48:      	mov	w0, wzr
    2f4c:      	b	0x3118 <do_action+0x4f8>
    2f50:      	add	w19, w19, #0x1
    2f54:      	add	x8, x21, w19, uxtw #2
    2f58:      	ldr	w8, [x8, #0x4]
    2f5c:      	str	w8, [x29, #0x78]
    2f60:      	b	0x3110 <do_action+0x4f0>
    2f64:      	strb	wzr, [x23]
    2f68:      	b	0x3110 <do_action+0x4f0>
    2f6c:      	tst	w25, #0x1
    2f70:      	mov	w8, #0x4                // =4
    2f74:      	add	w19, w19, #0x1
    2f78:      	b	0x30c8 <do_action+0x4a8>
    2f7c:      	mov	w8, #0xe                // =14
    2f80:      	blr	x8
    2f84:      	str	x0, [sp, #0x68]
    2f88:      	adrp	x21, 0x2000 <filter_inet+0x240>
    2f8c:      	add	x8, sp, #0x68
    2f90:      	mov	w9, #0x1                // =1
    2f94:      	ldr	x21, [x21]
    2f98:      	add	x1, sp, #0x68
    2f9c:      	mov	w20, #0x1               // =1
    2fa0:      	mov	x0, x21
    2fa4:      	blr	x9
    2fa8:      	cbz	x0, 0x3110 <do_action+0x4f0>
    2fac:      	ldur	x8, [x0, #0x4]
    2fb0:      	adrp	x25, 0x2000 <filter_inet+0x240>
    2fb4:      	mov	w9, #0x1                // =1
    2fb8:      	add	x1, sp, #0x58
    2fbc:      	str	x8, [sp, #0x58]
    2fc0:      	mov	w8, #0x2                // =2
    2fc4:      	str	w8, [sp, #0x60]
    2fc8:      	add	x8, sp, #0x58
    2fcc:      	ldr	x25, [x25]
    2fd0:      	mov	x0, x25
    2fd4:      	blr	x9
    2fd8:      	str	w20, [sp, #0x78]
    2fdc:      	cbz	x0, 0x31c0 <do_action+0x5a0>
    2fe0:      	ldaxr	w8, [x0]
    2fe4:      	add	w8, w8, #0x1
    2fe8:      	stlxr	w9, w8, [x0]
    2fec:      	cbnz	w9, 0x2fe0 <do_action+0x3c0>
    2ff0:      	mov	w8, #0x3                // =3
    2ff4:      	add	x9, sp, #0x68
    2ff8:      	add	x1, sp, #0x68
    2ffc:      	mov	x0, x21
    3000:      	blr	x8
    3004:      	b	0x3110 <do_action+0x4f0>
    3008:      	add	w8, w19, #0x1
    300c:      	add	x9, x21, #0x4
    3010:      	str	x20, [sp, #0x30]
    3014:      	ldr	w25, [x9, w8, uxtw #2]
    3018:      	add	w8, w19, #0x2
    301c:      	ldr	w20, [x9, w8, uxtw #2]
    3020:      	mov	w8, #0x7d               // =125
    3024:      	blr	x8
    3028:      	str	x0, [sp, #0x8]
    302c:      	str	x0, [sp, #0x48]
    3030:      	str	wzr, [sp, #0x68]
    3034:      	cbz	w25, 0x3468 <do_action+0x848>
    3038:      	adrp	x0, 0x3000 <do_action+0x3e0>
    303c:      	mov	w8, #0x1                // =1
    3040:      	add	x9, sp, #0x68
    3044:      	ldr	x0, [x0]
    3048:      	add	x1, sp, #0x68
    304c:      	blr	x8
    3050:      	cbz	x0, 0x3468 <do_action+0x848>
    3054:      	mov	x10, x0
    3058:      	adrp	x0, 0x3000 <do_action+0x3e0>
    305c:      	mov	w8, #0x1                // =1
    3060:      	ldr	x0, [x0]
    3064:      	add	x9, sp, #0x68
    3068:      	add	x1, sp, #0x68
    306c:      	str	x10, [sp, #0x10]
    3070:      	blr	x8
    3074:      	ldr	x9, [sp, #0x10]
    3078:      	ldr	x8, [x29, #0x60]
    307c:      	mov	x2, x0
    3080:      	cmp	w20, #0x2
    3084:      	str	x8, [x9]
    3088:      	ldr	x8, [x29, #0x70]
    308c:      	str	x8, [x9, #0x8]
    3090:      	b.eq	0x3280 <do_action+0x660>
    3094:      	cmp	w20, #0x1
    3098:      	b.eq	0x3274 <do_action+0x654>
    309c:      	cbnz	w20, 0x3468 <do_action+0x848>
    30a0:      	ldr	w8, [x29, #0x7c]
    30a4:      	str	x25, [sp]
    30a8:      	b	0x3288 <do_action+0x668>
    30ac:      	mov	w0, #0x9                // =9
    30b0:      	tbnz	w25, #0x0, 0x2cd8 <do_action+0xb8>
    30b4:      	mov	w20, #0x3               // =3
    30b8:      	b	0x30cc <do_action+0x4ac>
    30bc:      	tst	w25, #0x1
    30c0:      	mov	w8, #0x6                // =6
    30c4:      	add	w19, w19, #0x3
    30c8:      	cinc	x20, x8, eq
    30cc:      	str	wzr, [sp, #0x48]
    30d0:      	adrp	x0, 0x3000 <do_action+0x3e0>
    30d4:      	mov	w8, #0x1                // =1
    30d8:      	add	x9, sp, #0x48
    30dc:      	ldr	x0, [x0]
    30e0:      	add	x1, sp, #0x48
    30e4:      	blr	x8
    30e8:      	cbz	x0, 0x3110 <do_action+0x4f0>
    30ec:      	add	x8, x0, x20, lsl #3
    30f0:      	nop
    30f4:      	nop
    30f8:      	nop
    30fc:      	nop
    3100:      	ldaxr	x9, [x8]
    3104:      	add	x9, x9, #0x1
    3108:      	stlxr	w10, x9, [x8]
    310c:      	cbnz	w10, 0x3100 <do_action+0x4e0>
    3110:      	add	w0, w19, #0x1
    3114:      	str	x22, [x29, #0x70]
    3118:      	ldp	x20, x19, [sp, #0xb0]
    311c:      	ldr	x29, [sp, #0x70]
    3120:      	ldp	x22, x21, [sp, #0xa0]
    3124:      	ldp	x24, x23, [sp, #0x90]
    3128:      	ldp	x30, x25, [sp, #0x80]
    312c:      	add	sp, sp, #0xc0
    3130:      	ret
    3134:      	add	x8, x29, x8, lsl #3
    3138:      	ldr	x8, [x8, #0x5e78]
    313c:      	and	x8, x8, #0x7ff
    3140:      	add	x8, x29, x8
    3144:      	ldr	x8, [x8, #0xb8]
    3148:      	str	x8, [sp, #0x58]
    314c:      	cbz	x8, 0x2f40 <do_action+0x320>
    3150:      	cmp	w22, #0xa
    3154:      	b.ne	0x3258 <do_action+0x638>
    3158:      	mov	w8, #0xe                // =14
    315c:      	blr	x8
    3160:      	lsr	x8, x0, #32
    3164:      	mov	x21, x0
    3168:      	adrp	x0, 0x3000 <do_action+0x3e0>
    316c:      	str	w8, [sp, #0x48]
    3170:      	mov	w8, #0x1                // =1
    3174:      	add	x9, sp, #0x48
    3178:      	add	x1, sp, #0x48
    317c:      	ldr	x0, [x0]
    3180:      	blr	x8
    3184:      	cbz	x0, 0x2f44 <do_action+0x324>
    3188:      	ldr	w8, [x0]
    318c:      	mov	x3, xzr
    3190:      	add	x9, sp, #0x58
    3194:      	add	x10, sp, #0x48
    3198:      	stp	w8, w21, [sp, #0x48]
    319c:      	ldr	x8, [x0, #0x8]
    31a0:      	adrp	x0, 0x3000 <do_action+0x3e0>
    31a4:      	add	x1, sp, #0x58
    31a8:      	add	x2, sp, #0x48
    31ac:      	str	x8, [sp, #0x50]
    31b0:      	mov	w8, #0x2                // =2
    31b4:      	ldr	x0, [x0]
    31b8:      	blr	x8
    31bc:      	b	0x2f40 <do_action+0x320>
    31c0:      	mov	w8, #0x1                // =1
    31c4:      	mov	w9, #0x2                // =2
    31c8:      	add	x10, sp, #0x58
    31cc:      	add	x11, sp, #0x78
    31d0:      	add	x1, sp, #0x58
    31d4:      	add	x2, sp, #0x78
    31d8:      	mov	x0, x25
    31dc:      	mov	w3, #0x1                // =1
    31e0:      	blr	x9
    31e4:      	cbz	x0, 0x2ff0 <do_action+0x3d0>
    31e8:      	mov	x23, x0
    31ec:      	adrp	x24, 0x3000 <do_action+0x3e0>
    31f0:      	mov	w9, #0x1                // =1
    31f4:      	add	x1, sp, #0x48
    31f8:      	mov	w20, #0x1               // =1
    31fc:      	neg	w8, w23
    3200:      	strh	w8, [sp, #0x48]
    3204:      	mov	w8, #0x3                // =3
    3208:      	strh	w8, [sp, #0x4a]
    320c:      	mov	x8, #0x3b               // =59
    3210:      	movk	x8, #0x2, lsl #32
    3214:      	stur	x8, [sp, #0x4c]
    3218:      	add	x8, sp, #0x48
    321c:      	ldr	x24, [x24]
    3220:      	mov	x0, x24
    3224:      	blr	x9
    3228:      	cbz	x0, 0x3500 <do_action+0x8e0>
    322c:      	ldr	w8, [x0]
    3230:      	add	w8, w8, #0x1
    3234:      	str	w8, [x0]
    3238:      	b	0x3524 <do_action+0x904>
    323c:      	adrp	x0, 0x3000 <do_action+0x3e0>
    3240:      	mov	w8, #0x3                // =3
    3244:      	add	x9, sp, #0x48
    3248:      	ldr	x0, [x0]
    324c:      	add	x1, sp, #0x48
    3250:      	blr	x8
    3254:      	b	0x2f44 <do_action+0x324>
    3258:      	adrp	x0, 0x3000 <do_action+0x3e0>
    325c:      	mov	w8, #0x3                // =3
    3260:      	add	x9, sp, #0x58
    3264:      	ldr	x0, [x0]
    3268:      	add	x1, sp, #0x58
    326c:      	blr	x8
    3270:      	b	0x2f44 <do_action+0x324>
    3274:      	ldr	w8, [x29, #0x10]
    3278:      	str	x25, [sp]
    327c:      	b	0x3288 <do_action+0x668>
    3280:      	str	x25, [sp]
    3284:      	mov	w8, wzr
    3288:      	mov	w8, w8
    328c:      	add	x0, x9, #0x18
    3290:      	mov	w1, #0xc8               // =200
    3294:      	str	x8, [x9, #0x10]
    3298:      	mov	w8, #0xc8               // =200
    329c:      	mov	w9, #0x4                // =4
    32a0:      	str	x0, [sp, #0x18]
    32a4:      	blr	x9
    32a8:      	ldr	x20, [sp, #0x30]
    32ac:      	mov	w8, #0x5e78             // =24184
    32b0:      	mov	x25, xzr
    32b4:      	str	wzr, [sp, #0x2c]
    32b8:      	add	x10, x29, x8
    32bc:      	str	x23, [sp, #0x20]
    32c0:      	b	0x32d4 <do_action+0x6b4>
    32c4:      	add	x25, x25, #0x4
    32c8:      	add	x10, x10, #0x8
    32cc:      	cmp	x25, #0x14
    32d0:      	b.eq	0x340c <do_action+0x7ec>
    32d4:      	str	x10, [sp, #0x38]
    32d8:      	str	wzr, [sp, #0x58]
    32dc:      	mov	w8, #0x1                // =1
    32e0:      	add	x9, sp, #0x58
    32e4:      	add	x1, sp, #0x58
    32e8:      	mov	x0, x24
    32ec:      	blr	x8
    32f0:      	cbz	x0, 0x340c <do_action+0x7ec>
    32f4:      	mov	w8, #0x5ef8             // =24312
    32f8:      	add	x1, x0, x8
    32fc:      	adrp	x0, 0x3000 <do_action+0x3e0>
    3300:      	mov	w8, #0x1                // =1
    3304:      	ldr	x0, [x0]
    3308:      	blr	x8
    330c:      	cbz	x0, 0x340c <do_action+0x7ec>
    3310:      	add	x8, x0, x25
    3314:      	ldr	x10, [sp, #0x38]
    3318:      	ldr	w8, [x8, #0x40]
    331c:      	cmn	w8, #0x1
    3320:      	b.eq	0x340c <do_action+0x7ec>
    3324:      	ldr	x8, [x10]
    3328:      	ldr	w9, [x29, #0x4]
    332c:      	cmp	x8, x9
    3330:      	b.ge	0x340c <do_action+0x7ec>
    3334:      	cmp	x25, #0x10
    3338:      	b.eq	0x33a0 <do_action+0x780>
    333c:      	str	wzr, [sp, #0x58]
    3340:      	mov	w8, #0x1                // =1
    3344:      	add	x9, sp, #0x58
    3348:      	add	x1, sp, #0x58
    334c:      	mov	x0, x24
    3350:      	blr	x8
    3354:      	cbz	x0, 0x3398 <do_action+0x778>
    3358:      	mov	w8, #0x5ef8             // =24312
    335c:      	add	x1, x0, x8
    3360:      	adrp	x0, 0x3000 <do_action+0x3e0>
    3364:      	mov	w8, #0x1                // =1
    3368:      	ldr	x0, [x0]
    336c:      	blr	x8
    3370:      	cbz	x0, 0x3398 <do_action+0x778>
    3374:      	ldr	x10, [sp, #0x38]
    3378:      	add	x8, x0, x25
    337c:      	ldr	w9, [x8, #0x44]
    3380:      	ldr	x8, [x10]
    3384:      	cmn	w9, #0x1
    3388:      	b.eq	0x33a0 <do_action+0x780>
    338c:      	ldr	w9, [x10, #0x8]
    3390:      	sub	w9, w9, w8
    3394:      	b	0x33ac <do_action+0x78c>
    3398:      	ldr	x10, [sp, #0x38]
    339c:      	ldr	x8, [x10]
    33a0:      	ldr	w9, [x29, #0x4]
    33a4:      	sub	w9, w9, w8
    33a8:      	add	w9, w9, #0x4
    33ac:      	cmp	w9, #0x1
    33b0:      	b.lt	0x32c4 <do_action+0x6a4>
    33b4:      	mov	w10, #0x3ffc            // =16380
    33b8:      	cmp	w9, #0x28
    33bc:      	mov	x23, x29
    33c0:      	add	w8, w8, w10
    33c4:      	mov	w10, #0x28              // =40
    33c8:      	csel	w29, w9, w10, lt
    33cc:      	ldr	w9, [sp, #0x2c]
    33d0:      	and	x8, x8, #0x3fff
    33d4:      	add	x8, x23, x8
    33d8:      	mov	w1, w29
    33dc:      	add	x2, x8, #0x90
    33e0:      	mov	w8, #0x4                // =4
    33e4:      	and	w20, w9, #0xff
    33e8:      	ldr	x9, [sp, #0x18]
    33ec:      	add	x0, x9, x20
    33f0:      	blr	x8
    33f4:      	add	w8, w29, w20
    33f8:      	ldp	x20, x10, [sp, #0x30]
    33fc:      	mov	x29, x23
    3400:      	ldr	x23, [sp, #0x20]
    3404:      	str	w8, [sp, #0x2c]
    3408:      	b	0x32c4 <do_action+0x6a4>
    340c:      	adrp	x24, 0x3000 <do_action+0x3e0>
    3410:      	mov	w8, #0x1                // =1
    3414:      	ldr	x24, [x24]
    3418:      	ldr	x1, [sp, #0x10]
    341c:      	mov	x0, x24
    3420:      	blr	x8
    3424:      	cbz	x0, 0x344c <do_action+0x82c>
    3428:      	ldp	x10, x11, [sp]
    342c:      	mov	x9, #-0x4240            // =-16960
    3430:      	movk	x9, #0xfff0, lsl #16
    3434:      	ldr	x8, [x0]
    3438:      	madd	x9, x10, x9, x11
    343c:      	cmp	x8, x9
    3440:      	b.ls	0x344c <do_action+0x82c>
    3444:      	strb	wzr, [x23]
    3448:      	b	0x346c <do_action+0x84c>
    344c:      	ldr	x1, [sp, #0x10]
    3450:      	mov	x3, xzr
    3454:      	mov	w8, #0x2                // =2
    3458:      	add	x9, sp, #0x48
    345c:      	add	x2, sp, #0x48
    3460:      	mov	x0, x24
    3464:      	blr	x8
    3468:      	ldr	x20, [sp, #0x30]
    346c:      	add	w8, w19, #0x3
    3470:      	adrp	x23, 0x3000 <do_action+0x3e0>
    3474:      	add	x8, x21, w8, uxtw #2
    3478:      	ldr	w8, [x8, #0x4]
    347c:      	ldr	x23, [x23]
    3480:      	cbz	w8, 0x34a8 <do_action+0x888>
    3484:      	ldrb	w8, [x29, #0x1]
    3488:      	mov	x2, xzr
    348c:      	mov	x0, x20
    3490:      	mov	x1, x23
    3494:      	orr	w8, w8, #0x2
    3498:      	strb	w8, [x29, #0x1]
    349c:      	mov	w8, #0x1b               // =27
    34a0:      	blr	x8
    34a4:      	str	x0, [x29, #0x80]
    34a8:      	add	w8, w19, #0x4
    34ac:      	add	x8, x21, w8, uxtw #2
    34b0:      	ldr	w8, [x8, #0x4]
    34b4:      	cbz	w8, 0x34e0 <do_action+0x8c0>
    34b8:      	ldrb	w8, [x29, #0x1]
    34bc:      	mov	w9, #0x1b               // =27
    34c0:      	mov	x0, x20
    34c4:      	mov	x1, x23
    34c8:      	mov	w2, #0x100              // =256
    34cc:      	orr	w8, w8, #0x4
    34d0:      	strb	w8, [x29, #0x1]
    34d4:      	mov	w8, #0x100              // =256
    34d8:      	blr	x9
    34dc:      	str	x0, [x29, #0x88]
    34e0:      	add	w19, w19, #0x5
    34e4:      	add	x8, x21, w19, uxtw #2
    34e8:      	ldr	w8, [x8, #0x4]
    34ec:      	cbz	w8, 0x3110 <do_action+0x4f0>
    34f0:      	ldrb	w8, [x29, #0x1]
    34f4:      	orr	w8, w8, #0x8
    34f8:      	strb	w8, [x29, #0x1]
    34fc:      	b	0x3110 <do_action+0x4f0>
    3500:      	str	w20, [sp, #0x7c]
    3504:      	mov	x3, xzr
    3508:      	mov	w8, #0x2                // =2
    350c:      	add	x9, sp, #0x48
    3510:      	add	x10, sp, #0x7c
    3514:      	add	x1, sp, #0x48
    3518:      	add	x2, sp, #0x7c
    351c:      	mov	x0, x24
    3520:      	blr	x8
    3524:      	cbz	w23, 0x2ff0 <do_action+0x3d0>
    3528:      	mov	w8, #0x1                // =1
    352c:      	add	x9, sp, #0x58
    3530:      	add	x1, sp, #0x58
    3534:      	mov	x0, x25
    3538:      	blr	x8
    353c:      	cbz	x0, 0x2ff0 <do_action+0x3d0>
    3540:      	ldr	w8, [sp, #0x78]
    3544:      	ldaxr	w9, [x0]
    3548:      	add	w9, w9, w8
    354c:      	stlxr	w10, w9, [x0]
    3550:      	cbnz	w10, 0x3544 <do_action+0x924>
    3554:      	b	0x2ff0 <do_action+0x3d0>

Disassembly of section kprobe.multi:

0000000000000000 <generic_retkprobe_filter_arg>:
       0:      	sub	sp, sp, #0x70
       4:      	str	x29, [sp, #0x20]
       8:      	stp	x30, x25, [sp, #0x30]
       c:      	stp	x24, x23, [sp, #0x40]
      10:      	stp	x22, x21, [sp, #0x50]
      14:      	stp	x20, x19, [sp, #0x60]
      18:      	mov	x19, x0
      1c:      	str	wzr, [sp, #0x2c]
      20:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
      24:      	mov	w8, #0x1                // =1
      28:      	ldr	x0, [x0]
      2c:      	add	x9, sp, #0x2c
      30:      	add	x1, sp, #0x2c
      34:      	blr	x8
      38:      	cbz	x0, 0x394 <generic_retkprobe_filter_arg+0x394>
      3c:      	mov	w8, #0x5ec1             // =24257
      40:      	mov	x20, x0
      44:      	add	x22, x0, x8
      48:      	mov	w8, #0x5ef8             // =24312
      4c:      	add	x1, x0, x8
      50:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
      54:      	ldur	w23, [x22, #0x3f]
      58:      	mov	w8, #0x1                // =1
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	cbz	x0, 0x378 <generic_retkprobe_filter_arg+0x378>
      68:      	ldrb	w8, [x22, #0x1f]
      6c:      	cbz	w8, 0x378 <generic_retkprobe_filter_arg+0x378>
      70:      	and	x8, x23, #0x7
      74:      	mov	w10, #0x5ec1            // =24257
      78:      	add	x9, x20, x8
      7c:      	ldrb	w9, [x9, x10]
      80:      	cbz	w9, 0xc4 <generic_retkprobe_filter_arg+0xc4>
      84:      	lsl	w8, w8, #2
      88:      	mov	x21, x0
      8c:      	add	x8, x8, #0x4
      90:      	ldr	w9, [x8, x0]
      94:      	add	x8, x8, x9
      98:      	add	x25, x8, #0x4
      9c:      	and	x8, x25, #0x3ff
      a0:      	add	x29, x0, x8
      a4:      	str	x8, [sp, #0x8]
      a8:      	ldr	w8, [x29]
      ac:      	cmp	w8, #0x19
      b0:      	b.hs	0x10c <generic_retkprobe_filter_arg+0x10c>
      b4:      	ldr	x8, [sp, #0x8]
      b8:      	cmp	w8, #0x1
      bc:      	b.eq	0x378 <generic_retkprobe_filter_arg+0x378>
      c0:      	cbnz	w8, 0x354 <generic_retkprobe_filter_arg+0x354>
      c4:      	cmp	w23, #0x1
      c8:      	b.gt	0xe4 <generic_retkprobe_filter_arg+0xe4>
      cc:      	cmn	w23, #0x1
      d0:      	b.eq	0x3b4 <generic_retkprobe_filter_arg+0x3b4>
      d4:      	cbz	w23, 0x3c4 <generic_retkprobe_filter_arg+0x3c4>
      d8:      	cmp	w23, #0x1
      dc:      	b.eq	0x3d4 <generic_retkprobe_filter_arg+0x3d4>
      e0:      	b	0xfc <generic_retkprobe_filter_arg+0xfc>
      e4:      	cmp	w23, #0x2
      e8:      	b.eq	0x3e4 <generic_retkprobe_filter_arg+0x3e4>
      ec:      	cmp	w23, #0x3
      f0:      	b.eq	0x3f4 <generic_retkprobe_filter_arg+0x3f4>
      f4:      	cmp	w23, #0x4
      f8:      	b.eq	0x404 <generic_retkprobe_filter_arg+0x404>
      fc:      	cmp	w23, #0x4
     100:      	b.gt	0x430 <generic_retkprobe_filter_arg+0x430>
     104:      	add	w8, w23, #0x1
     108:      	b	0x410 <generic_retkprobe_filter_arg+0x410>
     10c:      	mov	w24, #0x4               // =4
     110:      	nop
     114:      	nop
     118:      	nop
     11c:      	nop
     120:      	ldr	w8, [x29, x24]
     124:      	tst	w8, #0x3ff
     128:      	b.eq	0xb4 <generic_retkprobe_filter_arg+0xb4>
     12c:      	add	w8, w25, w8
     130:      	and	x8, x8, #0x3ff
     134:      	add	x0, x21, x8
     138:      	ldr	w9, [x0, #0x4]
     13c:      	cmp	w9, #0x23
     140:      	b.eq	0xc4 <generic_retkprobe_filter_arg+0xc4>
     144:      	ldr	w8, [x0]
     148:      	cmp	w8, #0x4
     14c:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
     150:      	add	x10, x20, x8, lsl #2
     154:      	mov	w11, #0x5ea0            // =24224
     158:      	ldr	w10, [x10, x11]
     15c:      	cbnz	w10, 0xc4 <generic_retkprobe_filter_arg+0xc4>
     160:      	add	x8, x20, x8, lsl #3
     164:      	ldr	x8, [x8, #0x5e78]
     168:      	and	x8, x8, #0x7ff
     16c:      	add	x8, x20, x8
     170:      	add	x1, x8, #0x90
     174:      	ldr	w8, [x0, #0xc]
     178:      	cmp	w8, #0x1b
     17c:      	b.le	0x1a0 <generic_retkprobe_filter_arg+0x1a0>
     180:      	cmp	w8, #0x25
     184:      	b.gt	0x1d4 <generic_retkprobe_filter_arg+0x1d4>
     188:      	sub	w10, w8, #0x1c
     18c:      	cmp	w10, #0x9
     190:      	b.lo	0x218 <generic_retkprobe_filter_arg+0x218>
     194:      	cmp	w8, #0x25
     198:      	b.eq	0x300 <generic_retkprobe_filter_arg+0x300>
     19c:      	b	0x344 <generic_retkprobe_filter_arg+0x344>
     1a0:      	cmp	w8, #0x9
     1a4:      	b.le	0x1f8 <generic_retkprobe_filter_arg+0x1f8>
     1a8:      	sub	w10, w8, #0xa
     1ac:      	cmp	w10, #0x4
     1b0:      	b.lo	0x218 <generic_retkprobe_filter_arg+0x218>
     1b4:      	sub	w9, w8, #0xf
     1b8:      	cmp	w9, #0x2
     1bc:      	b.lo	0x300 <generic_retkprobe_filter_arg+0x300>
     1c0:      	cmp	w8, #0x11
     1c4:      	b.ne	0x344 <generic_retkprobe_filter_arg+0x344>
     1c8:      	add	x1, x1, #0x4
     1cc:      	bl	0x1cc <generic_retkprobe_filter_arg+0x1cc>
     1d0:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     1d4:      	cmp	w8, #0x29
     1d8:      	b.gt	0x2e8 <generic_retkprobe_filter_arg+0x2e8>
     1dc:      	sub	w9, w8, #0x26
     1e0:      	cmp	w9, #0x2
     1e4:      	b.lo	0x29c <generic_retkprobe_filter_arg+0x29c>
     1e8:      	sub	w8, w8, #0x28
     1ec:      	cmp	w8, #0x2
     1f0:      	b.lo	0x294 <generic_retkprobe_filter_arg+0x294>
     1f4:      	b	0x344 <generic_retkprobe_filter_arg+0x344>
     1f8:      	cmp	w8, #0x4
     1fc:      	b.gt	0x27c <generic_retkprobe_filter_arg+0x27c>
     200:      	cmp	w8, #0x1
     204:      	b.eq	0x218 <generic_retkprobe_filter_arg+0x218>
     208:      	cmp	w8, #0x2
     20c:      	b.eq	0x324 <generic_retkprobe_filter_arg+0x324>
     210:      	cmp	w8, #0x4
     214:      	b.ne	0x344 <generic_retkprobe_filter_arg+0x344>
     218:      	cmp	w8, #0xb
     21c:      	b.le	0x25c <generic_retkprobe_filter_arg+0x25c>
     220:      	cmp	w8, #0x24
     224:      	b.hi	0x308 <generic_retkprobe_filter_arg+0x308>
     228:      	mov	w11, #0x1               // =1
     22c:      	lsl	x10, x11, x8
     230:      	tst	x10, #0x1e00000000
     234:      	b.ne	0x2a4 <generic_retkprobe_filter_arg+0x2a4>
     238:      	lsl	x9, x11, x8
     23c:      	tst	x9, #0x60000000
     240:      	mov	w9, #0x1                // =1
     244:      	b.ne	0x31c <generic_retkprobe_filter_arg+0x31c>
     248:      	lsl	x9, x9, x8
     24c:      	tst	x9, #0x180000000
     250:      	b.eq	0x308 <generic_retkprobe_filter_arg+0x308>
     254:      	bl	0x254 <generic_retkprobe_filter_arg+0x254>
     258:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     25c:      	sub	w9, w8, #0xa
     260:      	cmp	w9, #0x2
     264:      	b.lo	0x338 <generic_retkprobe_filter_arg+0x338>
     268:      	cmp	w8, #0x1
     26c:      	b.eq	0x314 <generic_retkprobe_filter_arg+0x314>
     270:      	cmp	w8, #0x4
     274:      	b.eq	0x314 <generic_retkprobe_filter_arg+0x314>
     278:      	b	0x344 <generic_retkprobe_filter_arg+0x344>
     27c:      	cmp	w8, #0x5
     280:      	b.eq	0x294 <generic_retkprobe_filter_arg+0x294>
     284:      	cmp	w8, #0x6
     288:      	b.eq	0x29c <generic_retkprobe_filter_arg+0x29c>
     28c:      	cmp	w8, #0x7
     290:      	b.ne	0x344 <generic_retkprobe_filter_arg+0x344>
     294:      	bl	0x294 <generic_retkprobe_filter_arg+0x294>
     298:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     29c:      	mov	w2, #0x4                // =4
     2a0:      	b	0x328 <generic_retkprobe_filter_arg+0x328>
     2a4:      	cmp	w9, #0x1e
     2a8:      	b.ne	0x338 <generic_retkprobe_filter_arg+0x338>
     2ac:      	ldr	w8, [x0, #0x10]
     2b0:      	mov	w10, #0x5ea0            // =24224
     2b4:      	and	x8, x8, #0x7
     2b8:      	add	x9, x20, x8, lsl #2
     2bc:      	ldr	w9, [x9, x10]
     2c0:      	cbnz	w9, 0xc4 <generic_retkprobe_filter_arg+0xc4>
     2c4:      	add	x8, x20, x8, lsl #3
     2c8:      	ldr	x9, [x1]
     2cc:      	ldr	x8, [x8, #0x5e78]
     2d0:      	and	x8, x8, #0x7ff
     2d4:      	add	x8, x20, x8
     2d8:      	ldr	x8, [x8, #0x90]
     2dc:      	bics	xzr, x8, x9
     2e0:      	cset	w0, ne
     2e4:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     2e8:      	cmp	w8, #0x2a
     2ec:      	b.eq	0x300 <generic_retkprobe_filter_arg+0x300>
     2f0:      	cmp	w8, #0x2c
     2f4:      	b.ne	0x344 <generic_retkprobe_filter_arg+0x344>
     2f8:      	bl	0x2f8 <generic_retkprobe_filter_arg+0x2f8>
     2fc:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     300:      	bl	0x300 <generic_retkprobe_filter_arg+0x300>
     304:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     308:      	sub	w9, w8, #0xc
     30c:      	cmp	w9, #0x2
     310:      	b.hs	0x330 <generic_retkprobe_filter_arg+0x330>
     314:      	bl	0x314 <generic_retkprobe_filter_arg+0x314>
     318:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     31c:      	bl	0x31c <generic_retkprobe_filter_arg+0x31c>
     320:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     324:      	mov	w2, #0x8                // =8
     328:      	bl	0x328 <generic_retkprobe_filter_arg+0x328>
     32c:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     330:      	cmp	w8, #0x1c
     334:      	b.ne	0x344 <generic_retkprobe_filter_arg+0x344>
     338:      	bl	0x338 <generic_retkprobe_filter_arg+0x338>
     33c:      	nop
     340:      	cbz	x0, 0xc4 <generic_retkprobe_filter_arg+0xc4>
     344:      	add	x24, x24, #0x4
     348:      	cmp	x24, #0x18
     34c:      	b.ne	0x120 <generic_retkprobe_filter_arg+0x120>
     350:      	b	0xb4 <generic_retkprobe_filter_arg+0xb4>
     354:      	ldr	x8, [sp, #0x8]
     358:      	adrp	x1, 0x0 <generic_retkprobe_filter_arg>
     35c:      	mov	w9, #0xc                // =12
     360:      	mov	x0, x19
     364:      	stur	w8, [x22, #0x43]
     368:      	mov	w8, #0x4                // =4
     36c:      	mov	w2, #0x4                // =4
     370:      	ldr	x1, [x1]
     374:      	blr	x9
     378:      	adrp	x1, 0x0 <generic_retkprobe_filter_arg>
     37c:      	mov	w8, #0x5                // =5
     380:      	mov	w9, #0xc                // =12
     384:      	ldr	x1, [x1]
     388:      	mov	x0, x19
     38c:      	mov	w2, #0x5                // =5
     390:      	blr	x9
     394:      	ldp	x20, x19, [sp, #0x60]
     398:      	mov	w0, wzr
     39c:      	ldr	x29, [sp, #0x20]
     3a0:      	ldp	x22, x21, [sp, #0x50]
     3a4:      	ldp	x24, x23, [sp, #0x40]
     3a8:      	ldp	x30, x25, [sp, #0x30]
     3ac:      	add	sp, sp, #0x70
     3b0:      	ret
     3b4:      	ldrb	w8, [x22]
     3b8:      	cbz	w8, 0x3c4 <generic_retkprobe_filter_arg+0x3c4>
     3bc:      	mov	w8, wzr
     3c0:      	b	0x410 <generic_retkprobe_filter_arg+0x410>
     3c4:      	ldrb	w8, [x22, #0x1]
     3c8:      	cbz	w8, 0x3d4 <generic_retkprobe_filter_arg+0x3d4>
     3cc:      	mov	w8, #0x1                // =1
     3d0:      	b	0x410 <generic_retkprobe_filter_arg+0x410>
     3d4:      	ldrb	w8, [x22, #0x2]
     3d8:      	cbz	w8, 0x3e4 <generic_retkprobe_filter_arg+0x3e4>
     3dc:      	mov	w8, #0x2                // =2
     3e0:      	b	0x410 <generic_retkprobe_filter_arg+0x410>
     3e4:      	ldrb	w8, [x22, #0x3]
     3e8:      	cbz	w8, 0x3f4 <generic_retkprobe_filter_arg+0x3f4>
     3ec:      	mov	w8, #0x3                // =3
     3f0:      	b	0x410 <generic_retkprobe_filter_arg+0x410>
     3f4:      	ldrb	w8, [x22, #0x4]
     3f8:      	cbz	w8, 0x404 <generic_retkprobe_filter_arg+0x404>
     3fc:      	mov	w8, #0x4                // =4
     400:      	b	0x410 <generic_retkprobe_filter_arg+0x410>
     404:      	ldrb	w8, [x22, #0x5]
     408:      	cbz	w8, 0x430 <generic_retkprobe_filter_arg+0x430>
     40c:      	mov	w8, #0x5                // =5
     410:      	stur	w8, [x22, #0x3f]
     414:      	adrp	x1, 0x0 <generic_retkprobe_filter_arg>
     418:      	mov	w8, #0x3                // =3
     41c:      	mov	w9, #0xc                // =12
     420:      	ldr	x1, [x1]
     424:      	mov	x0, x19
     428:      	mov	w2, #0x3                // =3
     42c:      	blr	x9
     430:      	ldr	x19, [x20, #0x60]
     434:      	mov	w8, #0xe                // =14
     438:      	blr	x8
     43c:      	stp	x19, x0, [sp, #0x10]
     440:      	adrp	x19, 0x0 <generic_retkprobe_filter_arg>
     444:      	mov	w8, #0x1                // =1
     448:      	add	x9, sp, #0x10
     44c:      	add	x1, sp, #0x10
     450:      	ldr	x19, [x19]
     454:      	mov	x0, x19
     458:      	blr	x8
     45c:      	cbz	x0, 0x394 <generic_retkprobe_filter_arg+0x394>
     460:      	mov	w8, #0x3                // =3
     464:      	add	x9, sp, #0x10
     468:      	add	x1, sp, #0x10
     46c:      	mov	x0, x19
     470:      	blr	x8
     474:      	b	0x394 <generic_retkprobe_filter_arg+0x394>
     478:      	nop
     47c:      	nop

0000000000000480 <generic_retkprobe_actions>:
     480:      	sub	sp, sp, #0x40
     484:      	str	x30, [sp, #0x10]
     488:      	stp	x22, x21, [sp, #0x20]
     48c:      	stp	x20, x19, [sp, #0x30]
     490:      	mov	x19, x0
     494:      	str	wzr, [sp, #0xc]
     498:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     49c:      	mov	w8, #0x1                // =1
     4a0:      	ldr	x0, [x0]
     4a4:      	add	x9, sp, #0xc
     4a8:      	add	x1, sp, #0xc
     4ac:      	blr	x8
     4b0:      	cbz	x0, 0x5c8 <generic_retkprobe_actions+0x148>
     4b4:      	mov	w8, #0x5f04             // =24324
     4b8:      	ldr	w22, [x0, x8]
     4bc:      	cmp	w22, #0x2
     4c0:      	b.lt	0x5c8 <generic_retkprobe_actions+0x148>
     4c4:      	mov	w8, #0x5ef8             // =24312
     4c8:      	mov	w20, #0x1               // =1
     4cc:      	add	x1, x0, x8
     4d0:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     4d4:      	mov	w8, #0x1                // =1
     4d8:      	ldr	x0, [x0]
     4dc:      	blr	x8
     4e0:      	cbz	x0, 0x5c8 <generic_retkprobe_actions+0x148>
     4e4:      	and	x8, x22, #0x7ff
     4e8:      	mov	x21, x0
     4ec:      	strb	w20, [sp, #0x1c]
     4f0:      	mov	w9, #0x1                // =1
     4f4:      	ldr	w8, [x0, x8]
     4f8:      	str	wzr, [sp, #0x18]
     4fc:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     500:      	add	x1, sp, #0x18
     504:      	ldr	x0, [x0]
     508:      	add	w8, w8, w22
     50c:      	and	w22, w8, #0x7ff
     510:      	add	x8, sp, #0x18
     514:      	blr	x9
     518:      	cbz	x0, 0x528 <generic_retkprobe_actions+0xa8>
     51c:      	ldrb	w8, [x0]
     520:      	cmp	w8, #0x0
     524:      	cset	w20, eq
     528:      	ldr	w8, [x21, x22]
     52c:      	cmp	w8, #0x5
     530:      	b.lo	0x5a4 <generic_retkprobe_actions+0x124>
     534:      	add	x2, x21, x22
     538:      	add	x3, sp, #0x1c
     53c:      	mov	x0, x19
     540:      	mov	w1, wzr
     544:      	mov	w4, w20
     548:      	bl	0x548 <generic_retkprobe_actions+0xc8>
     54c:      	ldr	w9, [x21, x22]
     550:      	lsl	w8, w0, #2
     554:      	add	w8, w8, #0x4
     558:      	cmp	w8, w9
     55c:      	b.hs	0x5a4 <generic_retkprobe_actions+0x124>
     560:      	mov	w1, w0
     564:      	add	x2, x21, x22
     568:      	add	x3, sp, #0x1c
     56c:      	mov	x0, x19
     570:      	mov	w4, w20
     574:      	bl	0x574 <generic_retkprobe_actions+0xf4>
     578:      	ldr	w9, [x21, x22]
     57c:      	lsl	w8, w0, #2
     580:      	add	w8, w8, #0x4
     584:      	cmp	w8, w9
     588:      	b.hs	0x5a4 <generic_retkprobe_actions+0x124>
     58c:      	mov	w1, w0
     590:      	add	x2, x21, x22
     594:      	add	x3, sp, #0x1c
     598:      	mov	x0, x19
     59c:      	mov	w4, w20
     5a0:      	bl	0x5a0 <generic_retkprobe_actions+0x120>
     5a4:      	ldrb	w8, [sp, #0x1c]
     5a8:      	cbz	w8, 0x5c8 <generic_retkprobe_actions+0x148>
     5ac:      	adrp	x1, 0x0 <generic_retkprobe_filter_arg>
     5b0:      	mov	w8, #0x5                // =5
     5b4:      	mov	w9, #0xc                // =12
     5b8:      	ldr	x1, [x1]
     5bc:      	mov	x0, x19
     5c0:      	mov	w2, #0x5                // =5
     5c4:      	blr	x9
     5c8:      	ldp	x20, x19, [sp, #0x30]
     5cc:      	mov	w0, wzr
     5d0:      	ldr	x30, [sp, #0x10]
     5d4:      	ldp	x22, x21, [sp, #0x20]
     5d8:      	add	sp, sp, #0x40
     5dc:      	ret

00000000000005e0 <generic_retkprobe_output>:
     5e0:      	sub	sp, sp, #0x30
     5e4:      	stp	x30, x21, [sp, #0x10]
     5e8:      	stp	x20, x19, [sp, #0x20]
     5ec:      	mov	x20, x0
     5f0:      	str	wzr, [sp, #0x4]
     5f4:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     5f8:      	mov	w8, #0x1                // =1
     5fc:      	ldr	x0, [x0]
     600:      	add	x9, sp, #0x4
     604:      	add	x1, sp, #0x4
     608:      	blr	x8
     60c:      	cbz	x0, 0x870 <generic_retkprobe_output+0x290>
     610:      	ldr	w8, [x0, #0x4]
     614:      	mov	x19, x0
     618:      	mov	w9, #0x2328             // =9000
     61c:      	str	wzr, [sp, #0x8]
     620:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     624:      	add	x1, sp, #0x8
     628:      	ldr	x0, [x0]
     62c:      	add	w8, w8, #0x90
     630:      	and	w8, w8, #0x7fff
     634:      	cmp	w8, w9
     638:      	csel	w21, w8, w9, lo
     63c:      	mov	w8, #0x1                // =1
     640:      	add	x9, sp, #0x8
     644:      	blr	x8
     648:      	cbz	x0, 0x6b4 <generic_retkprobe_output+0xd4>
     64c:      	ldrb	w8, [x0, #0x28]
     650:      	cbz	w8, 0x6b4 <generic_retkprobe_output+0xd4>
     654:      	adrp	x1, 0x0 <generic_retkprobe_filter_arg>
     658:      	mov	w8, #-0x1               // =-1
     65c:      	mov	w9, #0x19               // =25
     660:      	ldr	x1, [x1]
     664:      	mov	x0, x20
     668:      	mov	w2, #-0x1               // =-1
     66c:      	mov	x3, x19
     670:      	mov	x4, x21
     674:      	blr	x9
     678:      	tbnz	x0, #0x3f, 0x764 <generic_retkprobe_output+0x184>
     67c:      	str	wzr, [sp, #0xc]
     680:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     684:      	mov	w8, #0x1                // =1
     688:      	add	x9, sp, #0xc
     68c:      	ldr	x0, [x0]
     690:      	add	x1, sp, #0xc
     694:      	blr	x8
     698:      	cbz	x0, 0x870 <generic_retkprobe_output+0x290>
     69c:      	add	x8, x0, #0x8
     6a0:      	ldaxr	x9, [x8]
     6a4:      	add	x9, x9, #0x1
     6a8:      	stlxr	w10, x9, [x8]
     6ac:      	cbnz	w10, 0x6a0 <generic_retkprobe_output+0xc0>
     6b0:      	b	0x870 <generic_retkprobe_output+0x290>
     6b4:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     6b8:      	mov	x3, xzr
     6bc:      	mov	w8, #0x82               // =130
     6c0:      	ldr	x0, [x0]
     6c4:      	mov	x1, x19
     6c8:      	mov	x2, x21
     6cc:      	blr	x8
     6d0:      	tbnz	x0, #0x3f, 0x714 <generic_retkprobe_output+0x134>
     6d4:      	str	wzr, [sp, #0xc]
     6d8:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     6dc:      	mov	w8, #0x1                // =1
     6e0:      	add	x9, sp, #0xc
     6e4:      	ldr	x0, [x0]
     6e8:      	add	x1, sp, #0xc
     6ec:      	blr	x8
     6f0:      	cbz	x0, 0x870 <generic_retkprobe_output+0x290>
     6f4:      	add	x8, x0, #0x8
     6f8:      	nop
     6fc:      	nop
     700:      	ldaxr	x9, [x8]
     704:      	add	x9, x9, #0x1
     708:      	stlxr	w10, x9, [x8]
     70c:      	cbnz	w10, 0x700 <generic_retkprobe_output+0x120>
     710:      	b	0x870 <generic_retkprobe_output+0x290>
     714:      	mov	x19, x0
     718:      	str	wzr, [sp, #0xc]
     71c:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     720:      	mov	w8, #0x1                // =1
     724:      	ldr	x0, [x0]
     728:      	add	x9, sp, #0xc
     72c:      	add	x1, sp, #0xc
     730:      	blr	x8
     734:      	cbz	x0, 0x870 <generic_retkprobe_output+0x290>
     738:      	mov	x8, x19
     73c:      	cmn	x19, #0xc
     740:      	b.gt	0x7b4 <generic_retkprobe_output+0x1d4>
     744:      	cmn	x8, #0x1c
     748:      	b.eq	0x7f4 <generic_retkprobe_output+0x214>
     74c:      	cmn	x8, #0x16
     750:      	b.eq	0x80c <generic_retkprobe_output+0x22c>
     754:      	cmn	x8, #0x10
     758:      	b.ne	0x804 <generic_retkprobe_output+0x224>
     75c:      	add	x8, x0, #0x2f0
     760:      	b	0x820 <generic_retkprobe_output+0x240>
     764:      	mov	x19, x0
     768:      	str	wzr, [sp, #0xc]
     76c:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     770:      	mov	w8, #0x1                // =1
     774:      	ldr	x0, [x0]
     778:      	add	x9, sp, #0xc
     77c:      	add	x1, sp, #0xc
     780:      	blr	x8
     784:      	cbz	x0, 0x870 <generic_retkprobe_output+0x290>
     788:      	mov	x8, x19
     78c:      	cmn	x19, #0xc
     790:      	b.gt	0x7d4 <generic_retkprobe_output+0x1f4>
     794:      	cmn	x8, #0x1c
     798:      	b.eq	0x834 <generic_retkprobe_output+0x254>
     79c:      	cmn	x8, #0x16
     7a0:      	b.eq	0x84c <generic_retkprobe_output+0x26c>
     7a4:      	cmn	x8, #0x10
     7a8:      	b.ne	0x844 <generic_retkprobe_output+0x264>
     7ac:      	add	x8, x0, #0x2f0
     7b0:      	b	0x860 <generic_retkprobe_output+0x280>
     7b4:      	cmn	x8, #0xb
     7b8:      	b.eq	0x7fc <generic_retkprobe_output+0x21c>
     7bc:      	cmn	x8, #0x7
     7c0:      	b.eq	0x814 <generic_retkprobe_output+0x234>
     7c4:      	cmn	x8, #0x2
     7c8:      	b.ne	0x804 <generic_retkprobe_output+0x224>
     7cc:      	add	x8, x0, #0x2e0
     7d0:      	b	0x820 <generic_retkprobe_output+0x240>
     7d4:      	cmn	x8, #0xb
     7d8:      	b.eq	0x83c <generic_retkprobe_output+0x25c>
     7dc:      	cmn	x8, #0x7
     7e0:      	b.eq	0x854 <generic_retkprobe_output+0x274>
     7e4:      	cmn	x8, #0x2
     7e8:      	b.ne	0x844 <generic_retkprobe_output+0x264>
     7ec:      	add	x8, x0, #0x2e0
     7f0:      	b	0x860 <generic_retkprobe_output+0x280>
     7f4:      	add	x8, x0, #0x300
     7f8:      	b	0x820 <generic_retkprobe_output+0x240>
     7fc:      	add	x8, x0, #0x308
     800:      	b	0x820 <generic_retkprobe_output+0x240>
     804:      	add	x8, x0, #0x2d8
     808:      	b	0x820 <generic_retkprobe_output+0x240>
     80c:      	add	x8, x0, #0x2f8
     810:      	b	0x820 <generic_retkprobe_output+0x240>
     814:      	add	x8, x0, #0x2e8
     818:      	nop
     81c:      	nop
     820:      	ldaxr	x9, [x8]
     824:      	add	x9, x9, #0x1
     828:      	stlxr	w10, x9, [x8]
     82c:      	cbnz	w10, 0x820 <generic_retkprobe_output+0x240>
     830:      	b	0x870 <generic_retkprobe_output+0x290>
     834:      	add	x8, x0, #0x300
     838:      	b	0x860 <generic_retkprobe_output+0x280>
     83c:      	add	x8, x0, #0x308
     840:      	b	0x860 <generic_retkprobe_output+0x280>
     844:      	add	x8, x0, #0x2d8
     848:      	b	0x860 <generic_retkprobe_output+0x280>
     84c:      	add	x8, x0, #0x2f8
     850:      	b	0x860 <generic_retkprobe_output+0x280>
     854:      	add	x8, x0, #0x2e8
     858:      	nop
     85c:      	nop
     860:      	ldaxr	x9, [x8]
     864:      	add	x9, x9, #0x1
     868:      	stlxr	w10, x9, [x8]
     86c:      	cbnz	w10, 0x860 <generic_retkprobe_output+0x280>
     870:      	ldp	x20, x19, [sp, #0x20]
     874:      	mov	w0, wzr
     878:      	ldp	x30, x21, [sp, #0x10]
     87c:      	add	sp, sp, #0x30
     880:      	ret

Disassembly of section kprobe.multi/generic_retkprobe:

0000000000000000 <generic_retkprobe_event>:
       0:      	sub	sp, sp, #0x150
       4:      	str	x29, [sp, #0x100]
       8:      	stp	x30, x25, [sp, #0x110]
       c:      	stp	x24, x23, [sp, #0x120]
      10:      	stp	x22, x21, [sp, #0x130]
      14:      	stp	x20, x19, [sp, #0x140]
      18:      	ldr	x8, [x0]
      1c:      	str	wzr, [sp, #0x5c]
      20:      	adrp	x24, 0x0 <generic_retkprobe_event>
      24:      	add	x9, sp, #0x5c
      28:      	mov	x19, x0
      2c:      	add	x1, sp, #0x5c
      30:      	str	x8, [sp, #0x60]
      34:      	mov	w8, #0x1                // =1
      38:      	ldr	x24, [x24]
      3c:      	mov	x0, x24
      40:      	blr	x8
      44:      	cbz	x0, 0x5b0 <generic_retkprobe_event+0x5b0>
      48:      	mov	w8, #0x5ea0             // =24224
      4c:      	mov	x20, x0
      50:      	add	x25, x0, x8
      54:      	mov	w8, #0xae               // =174
      58:      	mov	x0, x19
      5c:      	blr	x8
      60:      	mov	x1, x25
      64:      	mov	w8, #0x1                // =1
      68:      	str	w0, [x1, #0x58]!
      6c:      	adrp	x0, 0x0 <generic_retkprobe_event>
      70:      	ldr	x0, [x0]
      74:      	blr	x8
      78:      	cbz	x0, 0x5b0 <generic_retkprobe_event+0x5b0>
      7c:      	ldr	w8, [x0]
      80:      	mov	x29, x0
      84:      	str	x8, [x20, #0x60]
      88:      	mov	w8, #0xe                // =14
      8c:      	blr	x8
      90:      	cmn	x0, #0x16
      94:      	b.ne	0xb8 <generic_retkprobe_event+0xb8>
      98:      	add	x2, x19, #0xe8
      9c:      	mov	w8, #0x8                // =8
      a0:      	mov	w9, #0x4                // =4
      a4:      	add	x10, sp, #0x98
      a8:      	add	x0, sp, #0x98
      ac:      	mov	w1, #0x8                // =8
      b0:      	blr	x9
      b4:      	ldr	x0, [sp, #0x98]
      b8:      	str	x0, [x20, #0x68]
      bc:      	mov	w8, #0xe                // =14
      c0:      	blr	x8
      c4:      	ldp	x8, x9, [x20, #0x60]
      c8:      	adrp	x22, 0x0 <generic_retkprobe_event>
      cc:      	add	x1, sp, #0x98
      d0:      	str	w0, [x20, #0x7c]
      d4:      	stp	x8, x9, [sp, #0x98]
      d8:      	mov	w8, #0x1                // =1
      dc:      	add	x9, sp, #0x98
      e0:      	ldr	x22, [x22]
      e4:      	mov	x0, x22
      e8:      	blr	x8
      ec:      	cbz	x0, 0x5b0 <generic_retkprobe_event+0x5b0>
      f0:      	ldp	x21, x8, [x0]
      f4:      	add	x9, sp, #0x98
      f8:      	add	x1, sp, #0x98
      fc:      	str	x8, [sp, #0x108]
     100:      	ldr	x8, [x0, #0x10]
     104:      	mov	x0, x22
     108:      	str	x8, [sp, #0x50]
     10c:      	mov	w8, #0x3                // =3
     110:      	blr	x8
     114:      	mov	x22, x20
     118:      	str	x21, [x22, #0x90]!
     11c:      	ldp	w8, w23, [x29, #0x58]
     120:      	cbz	w23, 0x214 <generic_retkprobe_event+0x214>
     124:      	str	w8, [sp, #0x48]
     128:      	str	wzr, [x25]
     12c:      	mov	w8, #0x1                // =1
     130:      	add	x9, sp, #0x6c
     134:      	add	x1, sp, #0x6c
     138:      	mov	x0, x24
     13c:      	str	wzr, [sp, #0x6c]
     140:      	ldr	x25, [sp, #0x60]
     144:      	blr	x8
     148:      	cbz	x0, 0x280 <generic_retkprobe_event+0x280>
     14c:      	mov	w8, #0x5ea0             // =24224
     150:      	mov	w9, #0xc                // =12
     154:      	ldr	w8, [x0, x8]
     158:      	str	x9, [x0, #0x5e78]
     15c:      	str	w8, [x0, #0x98]
     160:      	cbz	w8, 0x2d0 <generic_retkprobe_event+0x2d0>
     164:      	mov	w8, #0x4                // =4
     168:      	add	x21, x8, #0x8
     16c:      	ldr	w8, [x29, #0x60]
     170:      	cmp	w8, #0xb
     174:      	b.eq	0x294 <generic_retkprobe_event+0x294>
     178:      	cmp	w8, #0xa
     17c:      	b.ne	0x1b8 <generic_retkprobe_event+0x1b8>
     180:      	ldr	w8, [x20, #0x10]
     184:      	ldr	w9, [x20, #0x7c]
     188:      	adrp	x0, 0x0 <generic_retkprobe_event>
     18c:      	mov	x3, xzr
     190:      	add	x10, sp, #0x98
     194:      	add	x1, sp, #0x60
     198:      	stp	w8, w9, [sp, #0x98]
     19c:      	ldr	x8, [x20, #0x18]
     1a0:      	add	x9, sp, #0x60
     1a4:      	add	x2, sp, #0x98
     1a8:      	str	x8, [sp, #0xa0]
     1ac:      	mov	w8, #0x2                // =2
     1b0:      	ldr	x0, [x0]
     1b4:      	blr	x8
     1b8:      	ldr	w8, [sp, #0x48]
     1bc:      	and	x24, x21, #0x1fff
     1c0:      	cmp	w8, #0x3
     1c4:      	b.eq	0x220 <generic_retkprobe_event+0x220>
     1c8:      	cmp	w8, #0x2
     1cc:      	b.ne	0x348 <generic_retkprobe_event+0x348>
     1d0:      	str	wzr, [x22, x24]
     1d4:      	add	x21, x24, #0x4
     1d8:      	mov	w8, #0xfff              // =4095
     1dc:      	ldr	x2, [sp, #0x108]
     1e0:      	mov	w25, #0x4               // =4
     1e4:      	add	x23, x22, x21
     1e8:      	ldr	x24, [sp, #0x60]
     1ec:      	add	x0, x23, #0x8
     1f0:      	cmp	x24, #0xfff
     1f4:      	csel	x22, x24, x8, lo
     1f8:      	mov	w8, #0x4                // =4
     1fc:      	mov	w1, w22
     200:      	blr	x8
     204:      	tbnz	w0, #0x1f, 0x2c0 <generic_retkprobe_event+0x2c0>
     208:      	add	x25, x22, #0x8
     20c:      	str	w22, [x23, #0x4]
     210:      	b	0x2c4 <generic_retkprobe_event+0x2c4>
     214:      	mov	w24, #0x8               // =8
     218:      	cmp	w8, #0x3
     21c:      	b.ne	0x1c8 <generic_retkprobe_event+0x1c8>
     220:      	ldr	x8, [sp, #0x50]
     224:      	add	x25, x24, #0x4
     228:      	str	wzr, [x22, x24]
     22c:      	cbz	x8, 0x318 <generic_retkprobe_event+0x318>
     230:      	ldr	x2, [sp, #0x108]
     234:      	ldr	x21, [sp, #0x60]
     238:      	mov	w8, #0x10               // =16
     23c:      	mov	w9, #0x4                // =4
     240:      	add	x10, sp, #0x98
     244:      	add	x0, sp, #0x98
     248:      	mov	w1, #0x10               // =16
     24c:      	blr	x9
     250:      	tbnz	w0, #0x1f, 0x338 <generic_retkprobe_event+0x338>
     254:      	ldr	x8, [sp, #0xa0]
     258:      	str	x29, [sp, #0x40]
     25c:      	cmp	x8, x21
     260:      	csel	x23, x8, x21, lo
     264:      	cmp	x21, #0x0
     268:      	csel	x29, x8, x23, eq
     26c:      	cmp	x29, #0xffe
     270:      	b.ls	0x5e8 <generic_retkprobe_event+0x5e8>
     274:      	ldr	x29, [sp, #0x40]
     278:      	mov	w8, #-0x3               // =-3
     27c:      	b	0x33c <generic_retkprobe_event+0x33c>
     280:      	mov	x8, xzr
     284:      	add	x21, x8, #0x8
     288:      	ldr	w8, [x29, #0x60]
     28c:      	cmp	w8, #0xb
     290:      	b.ne	0x178 <generic_retkprobe_event+0x178>
     294:      	adrp	x0, 0x0 <generic_retkprobe_event>
     298:      	mov	w8, #0x3                // =3
     29c:      	add	x9, sp, #0x60
     2a0:      	ldr	x0, [x0]
     2a4:      	add	x1, sp, #0x60
     2a8:      	blr	x8
     2ac:      	ldr	w8, [sp, #0x48]
     2b0:      	and	x24, x21, #0x1fff
     2b4:      	cmp	w8, #0x3
     2b8:      	b.ne	0x1c8 <generic_retkprobe_event+0x1c8>
     2bc:      	b	0x220 <generic_retkprobe_event+0x220>
     2c0:      	mov	w24, #-0x2              // =-2
     2c4:      	str	w24, [x23]
     2c8:      	add	x24, x25, x21
     2cc:      	b	0x348 <generic_retkprobe_event+0x348>
     2d0:      	add	x9, sp, #0xe0
     2d4:      	add	x8, x0, #0x9c
     2d8:      	add	x21, sp, #0xe0
     2dc:      	str	x25, [sp, #0x98]
     2e0:      	str	x29, [sp, #0x40]
     2e4:      	cmp	w23, #0x17
     2e8:      	stp	x8, x0, [sp, #0x20]
     2ec:      	str	xzr, [x9, #0x8]
     2f0:      	b.le	0x5cc <generic_retkprobe_event+0x5cc>
     2f4:      	cmp	w23, #0x18
     2f8:      	b.eq	0x680 <generic_retkprobe_event+0x680>
     2fc:      	cmp	w23, #0x25
     300:      	b.eq	0x6d0 <generic_retkprobe_event+0x6d0>
     304:      	cmp	w23, #0x2a
     308:      	b.ne	0xbdc <generic_retkprobe_event+0xbdc>
     30c:      	stp	xzr, x25, [sp, #0x70]
     310:      	add	x21, sp, #0x70
     314:      	b	0x728 <generic_retkprobe_event+0x728>
     318:      	mov	x24, x22
     31c:      	str	x29, [sp, #0x40]
     320:      	mov	x29, xzr
     324:      	add	x8, x24, x25
     328:      	stp	w29, w29, [x8]
     32c:      	add	x8, x29, #0x8
     330:      	ldr	x29, [sp, #0x40]
     334:      	b	0x344 <generic_retkprobe_event+0x344>
     338:      	mov	w8, #-0x2               // =-2
     33c:      	str	w8, [x22, x25]
     340:      	mov	w8, #0x4                // =4
     344:      	add	x24, x8, x25
     348:      	mov	w8, #0x23               // =35
     34c:      	blr	x8
     350:      	str	x0, [sp, #0x98]
     354:      	add	x8, x0, #0x8d4
     358:      	mov	w9, #0x4                // =4
     35c:      	mov	w10, #0x71              // =113
     360:      	add	x11, sp, #0x70
     364:      	add	x0, sp, #0x70
     368:      	mov	w1, #0x4                // =4
     36c:      	ldr	x8, [sp, #0x98]
     370:      	add	x2, x8, #0x8d4
     374:      	blr	x10
     378:      	ldr	w8, [sp, #0x70]
     37c:      	adrp	x22, 0x0 <generic_retkprobe_event>
     380:      	add	x9, sp, #0xe8
     384:      	add	x1, sp, #0xe8
     388:      	str	w8, [sp, #0xe8]
     38c:      	mov	w8, #0x1                // =1
     390:      	ldr	x22, [x22]
     394:      	mov	x0, x22
     398:      	blr	x8
     39c:      	cbz	x0, 0x3ac <generic_retkprobe_event+0x3ac>
     3a0:      	ldr	x8, [x0, #0x8]
     3a4:      	mov	x23, x0
     3a8:      	cbnz	x8, 0x558 <generic_retkprobe_event+0x558>
     3ac:      	ldr	x8, [sp, #0x98]
     3b0:      	mov	w9, #0x8                // =8
     3b4:      	mov	w10, #0x71              // =113
     3b8:      	add	x11, sp, #0x98
     3bc:      	add	x0, sp, #0x98
     3c0:      	mov	w1, #0x8                // =8
     3c4:      	add	x8, x8, #0x8e0
     3c8:      	ldr	x8, [sp, #0x98]
     3cc:      	add	x2, x8, #0x8e0
     3d0:      	blr	x10
     3d4:      	ldr	x8, [sp, #0x98]
     3d8:      	cbz	x8, 0x554 <generic_retkprobe_event+0x554>
     3dc:      	add	x8, x8, #0x8d4
     3e0:      	mov	w9, #0x4                // =4
     3e4:      	mov	w10, #0x71              // =113
     3e8:      	add	x11, sp, #0x70
     3ec:      	ldr	x8, [sp, #0x98]
     3f0:      	add	x0, sp, #0x70
     3f4:      	mov	w1, #0x4                // =4
     3f8:      	add	x2, x8, #0x8d4
     3fc:      	blr	x10
     400:      	ldr	w8, [sp, #0x70]
     404:      	add	x9, sp, #0xe8
     408:      	add	x1, sp, #0xe8
     40c:      	mov	x0, x22
     410:      	str	w8, [sp, #0xe8]
     414:      	mov	w8, #0x1                // =1
     418:      	blr	x8
     41c:      	cbz	x0, 0x42c <generic_retkprobe_event+0x42c>
     420:      	ldr	x8, [x0, #0x8]
     424:      	mov	x23, x0
     428:      	cbnz	x8, 0x558 <generic_retkprobe_event+0x558>
     42c:      	ldr	x8, [sp, #0x98]
     430:      	mov	w9, #0x8                // =8
     434:      	mov	w10, #0x71              // =113
     438:      	add	x11, sp, #0x98
     43c:      	add	x0, sp, #0x98
     440:      	mov	w1, #0x8                // =8
     444:      	add	x8, x8, #0x8e0
     448:      	ldr	x8, [sp, #0x98]
     44c:      	add	x2, x8, #0x8e0
     450:      	blr	x10
     454:      	ldr	x8, [sp, #0x98]
     458:      	cbz	x8, 0x554 <generic_retkprobe_event+0x554>
     45c:      	add	x8, x8, #0x8d4
     460:      	mov	w9, #0x4                // =4
     464:      	mov	w10, #0x71              // =113
     468:      	add	x11, sp, #0x70
     46c:      	ldr	x8, [sp, #0x98]
     470:      	add	x0, sp, #0x70
     474:      	mov	w1, #0x4                // =4
     478:      	add	x2, x8, #0x8d4
     47c:      	blr	x10
     480:      	ldr	w8, [sp, #0x70]
     484:      	add	x9, sp, #0xe8
     488:      	add	x1, sp, #0xe8
     48c:      	mov	x0, x22
     490:      	str	w8, [sp, #0xe8]
     494:      	mov	w8, #0x1                // =1
     498:      	blr	x8
     49c:      	cbz	x0, 0x4ac <generic_retkprobe_event+0x4ac>
     4a0:      	ldr	x8, [x0, #0x8]
     4a4:      	mov	x23, x0
     4a8:      	cbnz	x8, 0x558 <generic_retkprobe_event+0x558>
     4ac:      	ldr	x8, [sp, #0x98]
     4b0:      	mov	w9, #0x8                // =8
     4b4:      	mov	w10, #0x71              // =113
     4b8:      	add	x11, sp, #0x98
     4bc:      	add	x0, sp, #0x98
     4c0:      	mov	w1, #0x8                // =8
     4c4:      	add	x8, x8, #0x8e0
     4c8:      	ldr	x8, [sp, #0x98]
     4cc:      	add	x2, x8, #0x8e0
     4d0:      	blr	x10
     4d4:      	ldr	x8, [sp, #0x98]
     4d8:      	cbz	x8, 0x554 <generic_retkprobe_event+0x554>
     4dc:      	add	x8, x8, #0x8d4
     4e0:      	mov	w9, #0x4                // =4
     4e4:      	mov	w10, #0x71              // =113
     4e8:      	add	x11, sp, #0x70
     4ec:      	ldr	x8, [sp, #0x98]
     4f0:      	add	x0, sp, #0x70
     4f4:      	mov	w1, #0x4                // =4
     4f8:      	add	x2, x8, #0x8d4
     4fc:      	blr	x10
     500:      	ldr	w8, [sp, #0x70]
     504:      	add	x9, sp, #0xe8
     508:      	add	x1, sp, #0xe8
     50c:      	mov	x0, x22
     510:      	str	w8, [sp, #0xe8]
     514:      	mov	w8, #0x1                // =1
     518:      	blr	x8
     51c:      	cbz	x0, 0x52c <generic_retkprobe_event+0x52c>
     520:      	ldr	x8, [x0, #0x8]
     524:      	mov	x23, x0
     528:      	cbnz	x8, 0x558 <generic_retkprobe_event+0x558>
     52c:      	ldr	x8, [sp, #0x98]
     530:      	mov	w9, #0x8                // =8
     534:      	mov	w10, #0x71              // =113
     538:      	add	x11, sp, #0x98
     53c:      	add	x0, sp, #0x98
     540:      	mov	w1, #0x8                // =8
     544:      	add	x8, x8, #0x8e0
     548:      	ldr	x8, [sp, #0x98]
     54c:      	add	x2, x8, #0x8e0
     550:      	blr	x10
     554:      	mov	x23, xzr
     558:      	mov	w8, #0x10d              // =269
     55c:      	stp	w8, w24, [x20]
     560:      	mov	w8, #0x7d               // =125
     564:      	blr	x8
     568:      	str	x0, [x20, #0x8]
     56c:      	cbz	x23, 0x580 <generic_retkprobe_event+0x580>
     570:      	ldr	w8, [x23]
     574:      	str	w8, [x20, #0x10]
     578:      	ldr	x8, [x23, #0x8]
     57c:      	str	x8, [x20, #0x18]
     580:      	str	wzr, [x20, #0x14]
     584:      	adrp	x1, 0x0 <generic_retkprobe_event>
     588:      	mov	w9, #0xc                // =12
     58c:      	mov	x0, x19
     590:      	ldr	w8, [x29]
     594:      	str	w24, [x20, #0x4]
     598:      	mov	w2, #0x3                // =3
     59c:      	str	x8, [x20, #0x60]
     5a0:      	mov	w8, #0x3                // =3
     5a4:      	ldr	x1, [x1]
     5a8:      	blr	x9
     5ac:      	mov	w0, #0x1                // =1
     5b0:      	ldp	x20, x19, [sp, #0x140]
     5b4:      	ldr	x29, [sp, #0x100]
     5b8:      	ldp	x22, x21, [sp, #0x130]
     5bc:      	ldp	x24, x23, [sp, #0x120]
     5c0:      	ldp	x30, x25, [sp, #0x110]
     5c4:      	add	sp, sp, #0x150
     5c8:      	ret
     5cc:      	cmp	w23, #0xf
     5d0:      	b.eq	0x700 <generic_retkprobe_event+0x700>
     5d4:      	cmp	w23, #0x10
     5d8:      	b.ne	0xbdc <generic_retkprobe_event+0xbdc>
     5dc:      	add	x21, sp, #0xf8
     5e0:      	add	x23, sp, #0xe0
     5e4:      	b	0x6a8 <generic_retkprobe_event+0x6a8>
     5e8:      	mov	x8, x22
     5ec:      	add	x22, x24, #0xc
     5f0:      	mov	w9, #0x4                // =4
     5f4:      	mov	w1, w29
     5f8:      	mov	x24, x8
     5fc:      	add	x0, x8, x22
     600:      	ldr	x8, [sp, #0x98]
     604:      	ldr	x2, [sp, #0x98]
     608:      	blr	x9
     60c:      	tbnz	w0, #0x1f, 0x670 <generic_retkprobe_event+0x670>
     610:      	cbz	x21, 0x61c <generic_retkprobe_event+0x61c>
     614:      	subs	x21, x21, x23
     618:      	b.eq	0xf28 <generic_retkprobe_event+0xf28>
     61c:      	ldr	x8, [sp, #0x50]
     620:      	cmp	x8, #0x1
     624:      	b.eq	0x324 <generic_retkprobe_event+0x324>
     628:      	ldr	x8, [sp, #0x108]
     62c:      	mov	w9, #0x4                // =4
     630:      	add	x10, sp, #0x98
     634:      	add	x0, sp, #0x98
     638:      	mov	w1, #0x10               // =16
     63c:      	add	x2, x8, #0x10
     640:      	mov	w8, #0x10               // =16
     644:      	blr	x9
     648:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
     64c:      	ldr	x8, [sp, #0xa0]
     650:      	cmp	x8, x21
     654:      	csel	x23, x8, x21, lo
     658:      	cmp	x21, #0x0
     65c:      	csel	x10, x8, x23, eq
     660:      	cmp	x10, #0xffe
     664:      	b.ls	0x1004 <generic_retkprobe_event+0x1004>
     668:      	mov	w8, #-0x3               // =-3
     66c:      	b	0x12ec <generic_retkprobe_event+0x12ec>
     670:      	ldr	x29, [sp, #0x40]
     674:      	mov	w8, #-0x2               // =-2
     678:      	mov	x22, x24
     67c:      	b	0x33c <generic_retkprobe_event+0x33c>
     680:      	add	x21, sp, #0xf8
     684:      	mov	w8, #0x8                // =8
     688:      	mov	w9, #0x4                // =4
     68c:      	ldr	x2, [sp, #0x98]
     690:      	add	x0, sp, #0xf8
     694:      	mov	w1, #0x8                // =8
     698:      	blr	x9
     69c:      	add	x23, sp, #0xe0
     6a0:      	ldr	x8, [x23, #0x18]
     6a4:      	str	x8, [sp, #0x98]
     6a8:      	mov	w8, #0x8                // =8
     6ac:      	mov	w9, #0x4                // =4
     6b0:      	add	x10, sp, #0x98
     6b4:      	add	x0, sp, #0xf8
     6b8:      	add	x2, sp, #0x98
     6bc:      	mov	w1, #0x8                // =8
     6c0:      	blr	x9
     6c4:      	ldr	x8, [x23, #0x18]
     6c8:      	add	x21, x8, #0x40
     6cc:      	b	0x728 <generic_retkprobe_event+0x728>
     6d0:      	add	x8, x25, #0x40
     6d4:      	mov	w9, #0x8                // =8
     6d8:      	mov	w10, #0x4               // =4
     6dc:      	str	x8, [sp, #0x98]
     6e0:      	add	x11, sp, #0xf8
     6e4:      	add	x0, sp, #0xf8
     6e8:      	mov	w1, #0x8                // =8
     6ec:      	ldr	x2, [sp, #0x98]
     6f0:      	blr	x10
     6f4:      	ldr	x8, [x21, #0x18]
     6f8:      	add	x21, x8, #0x40
     6fc:      	b	0x728 <generic_retkprobe_event+0x728>
     700:      	mov	w8, #0x8                // =8
     704:      	mov	w9, #0x4                // =4
     708:      	add	x10, sp, #0xe8
     70c:      	add	x11, sp, #0x98
     710:      	add	x0, sp, #0xe8
     714:      	add	x2, sp, #0x98
     718:      	mov	w1, #0x8                // =8
     71c:      	blr	x9
     720:      	ldr	x21, [x21, #0x8]
     724:      	cbz	x21, 0xdb0 <generic_retkprobe_event+0xdb0>
     728:      	str	wzr, [sp, #0x84]
     72c:      	adrp	x0, 0x0 <generic_retkprobe_event>
     730:      	mov	w8, #0x1                // =1
     734:      	add	x9, sp, #0x84
     738:      	ldr	x0, [x0]
     73c:      	add	x1, sp, #0x84
     740:      	blr	x8
     744:      	cbz	x0, 0xd8c <generic_retkprobe_event+0xd8c>
     748:      	add	x8, x0, #0x1, lsl #12   // =0x1000
     74c:      	str	x22, [sp, #0x10]
     750:      	mov	x23, x0
     754:      	str	x8, [sp, #0x30]
     758:      	mov	w8, #0x23               // =35
     75c:      	blr	x8
     760:      	add	x2, x0, #0xb30
     764:      	mov	w24, #0x8               // =8
     768:      	add	x8, sp, #0x88
     76c:      	mov	w9, #0x4                // =4
     770:      	add	x0, sp, #0x88
     774:      	mov	w1, #0x8                // =8
     778:      	mov	w25, #0x4               // =4
     77c:      	blr	x9
     780:      	ldr	x29, [sp, #0x88]
     784:      	str	x21, [sp, #0x8]
     788:      	add	x2, x21, #0x8
     78c:      	mov	w9, #0x4                // =4
     790:      	add	x0, sp, #0x90
     794:      	mov	w1, #0x8                // =8
     798:      	add	x8, x29, #0x18
     79c:      	str	x8, [sp, #0x38]
     7a0:      	add	x8, sp, #0x90
     7a4:      	str	x2, [sp, #0x18]
     7a8:      	blr	x9
     7ac:      	ldr	x21, [sp, #0x90]
     7b0:      	add	x22, sp, #0x98
     7b4:      	add	x0, sp, #0x98
     7b8:      	mov	w1, #0x8                // =8
     7bc:      	add	x2, x21, #0x10
     7c0:      	blr	x25
     7c4:      	ldr	x8, [sp, #0x98]
     7c8:      	cbz	x8, 0x7d8 <generic_retkprobe_event+0x7d8>
     7cc:      	ldr	x9, [sp, #0x30]
     7d0:      	mov	w8, #0x1000             // =4096
     7d4:      	b	0x820 <generic_retkprobe_event+0x820>
     7d8:      	add	x2, x21, #0x18
     7dc:      	mov	w8, #0x8                // =8
     7e0:      	mov	w9, #0x4                // =4
     7e4:      	add	x10, sp, #0x98
     7e8:      	add	x0, sp, #0x98
     7ec:      	mov	w1, #0x8                // =8
     7f0:      	blr	x9
     7f4:      	ldr	x8, [sp, #0x98]
     7f8:      	cmp	x8, x21
     7fc:      	b.eq	0x7cc <generic_retkprobe_event+0x7cc>
     800:      	mov	w8, #0x2964             // =10596
     804:      	add	x9, x23, #0xff6
     808:      	strh	w8, [x23, #0xffe]
     80c:      	adrp	x8, 0x0 <generic_retkprobe_event>
     810:      	add	x8, x8, #0x0
     814:      	ldr	x8, [x8]
     818:      	str	x8, [x9]
     81c:      	mov	w8, #0xff6              // =4086
     820:      	stp	xzr, xzr, [sp, #0x98]
     824:      	add	x2, x29, #0x20
     828:      	mov	w21, #0x8               // =8
     82c:      	add	x0, sp, #0x98
     830:      	mov	w1, #0x8                // =8
     834:      	add	x25, x22, #0x8
     838:      	stp	x23, xzr, [sp, #0xa8]
     83c:      	add	x24, x22, #0x18
     840:      	add	x23, x22, #0x20
     844:      	stp	xzr, xzr, [sp, #0xb8]
     848:      	mov	w29, #0x4               // =4
     84c:      	str	x9, [sp, #0x30]
     850:      	str	x9, [sp, #0xc8]
     854:      	str	w8, [sp, #0xd0]
     858:      	mov	w8, #0x4                // =4
     85c:      	strb	wzr, [sp, #0xd4]
     860:      	blr	x8
     864:      	ldr	x2, [sp, #0x38]
     868:      	mov	w8, #0x4                // =4
     86c:      	mov	x0, x25
     870:      	mov	w1, #0x8                // =8
     874:      	blr	x8
     878:      	ldr	x2, [sp, #0x18]
     87c:      	mov	w8, #0x4                // =4
     880:      	mov	x0, x24
     884:      	mov	w1, #0x8                // =8
     888:      	str	x24, [sp, #0x38]
     88c:      	blr	x8
     890:      	ldr	x2, [sp, #0x8]
     894:      	mov	x0, x23
     898:      	mov	w1, #0x8                // =8
     89c:      	blr	x29
     8a0:      	ldr	x8, [sp, #0xb8]
     8a4:      	sub	x8, x8, #0x20
     8a8:      	str	x8, [sp, #0xc0]
     8ac:      	adrp	x8, 0x0 <generic_retkprobe_event>
     8b0:      	ldr	x8, [x8]
     8b4:      	ldrb	w8, [x8]
     8b8:      	cbz	w8, 0xa4c <generic_retkprobe_event+0xa4c>
     8bc:      	mov	w23, #0x800             // =2048
     8c0:      	mov	w25, #0x8               // =8
     8c4:      	ldp	x29, x2, [sp, #0xb0]
     8c8:      	ldp	x8, x9, [sp, #0x98]
     8cc:      	cmp	x29, x8
     8d0:      	ccmp	x2, x9, #0x0, eq
     8d4:      	b.eq	0xc74 <generic_retkprobe_event+0xc74>
     8d8:      	ldr	x21, [sp, #0xc0]
     8dc:      	mov	w8, #0x4                // =4
     8e0:      	add	x9, sp, #0xd8
     8e4:      	add	x0, sp, #0xd8
     8e8:      	mov	w1, #0x8                // =8
     8ec:      	blr	x8
     8f0:      	ldr	x8, [sp, #0xd8]
     8f4:      	add	x24, sp, #0xe0
     8f8:      	cmp	x29, x8
     8fc:      	b.eq	0x9f4 <generic_retkprobe_event+0x9f4>
     900:      	add	x22, x29, #0x18
     904:      	mov	w8, #0x4                // =4
     908:      	add	x9, sp, #0xf8
     90c:      	add	x0, sp, #0xf8
     910:      	mov	w1, #0x8                // =8
     914:      	mov	x2, x22
     918:      	blr	x8
     91c:      	ldr	x8, [x24, #0x18]
     920:      	cmp	x8, x29
     924:      	b.eq	0x9f4 <generic_retkprobe_event+0x9f4>
     928:      	mov	w8, #0x4                // =4
     92c:      	add	x9, sp, #0xe0
     930:      	add	x0, sp, #0xe0
     934:      	mov	w1, #0x8                // =8
     938:      	mov	x2, x22
     93c:      	blr	x8
     940:      	add	x2, x29, #0x20
     944:      	mov	w8, #0x4                // =4
     948:      	mov	w9, #0x10               // =16
     94c:      	add	x10, sp, #0xe8
     950:      	add	x0, sp, #0xe8
     954:      	mov	w1, #0x10               // =16
     958:      	blr	x8
     95c:      	ldr	w21, [sp, #0xec]
     960:      	ldr	x8, [sp, #0xa8]
     964:      	add	x29, sp, #0xe0
     968:      	ldr	x10, [sp, #0xc8]
     96c:      	sub	x12, x10, x8
     970:      	ldr	w22, [sp, #0xd0]
     974:      	subs	w10, w21, w22
     978:      	ldr	x9, [x24, #0x10]
     97c:      	csel	w10, wzr, w10, lo
     980:      	cmp	w22, w21
     984:      	csel	w11, w22, w21, lo
     988:      	cinc	w13, w11, hi
     98c:      	sub	w14, w22, w13
     990:      	subs	x12, x12, x13
     994:      	str	w14, [sp, #0xd0]
     998:      	b.lo	0xc88 <generic_retkprobe_event+0xc88>
     99c:      	cmp	x12, #0xfff
     9a0:      	b.hi	0xc88 <generic_retkprobe_event+0xc88>
     9a4:      	cmp	w22, w21
     9a8:      	b.ls	0x9b4 <generic_retkprobe_event+0x9b4>
     9ac:      	mov	w13, #0x2f              // =47
     9b0:      	strb	w13, [x8, x12]
     9b4:      	add	x29, x8, x12
     9b8:      	cmp	w22, w21
     9bc:      	add	x2, x9, x10
     9c0:      	and	w1, w11, #0xff
     9c4:      	mov	w8, #0x4                // =4
     9c8:      	cinc	x0, x29, hi
     9cc:      	blr	x8
     9d0:      	cmp	w22, w21
     9d4:      	str	x29, [sp, #0xc8]
     9d8:      	add	x29, sp, #0xe0
     9dc:      	b.ls	0xc88 <generic_retkprobe_event+0xc88>
     9e0:      	ldr	x8, [x29]
     9e4:      	str	x8, [sp, #0xb0]
     9e8:      	subs	w23, w23, #0x1
     9ec:      	b.ne	0x8c4 <generic_retkprobe_event+0x8c4>
     9f0:      	b	0xc88 <generic_retkprobe_event+0xc88>
     9f4:      	add	x2, x21, #0x10
     9f8:      	mov	w8, #0x4                // =4
     9fc:      	add	x9, sp, #0xf8
     a00:      	add	x0, sp, #0xf8
     a04:      	mov	w1, #0x8                // =8
     a08:      	blr	x8
     a0c:      	ldr	x8, [sp, #0xc0]
     a10:      	ldr	x9, [x24, #0x18]
     a14:      	add	x29, sp, #0xe0
     a18:      	cmp	x8, x9
     a1c:      	b.eq	0xc80 <generic_retkprobe_event+0xc80>
     a20:      	ldr	x0, [sp, #0x38]
     a24:      	add	x2, x21, #0x18
     a28:      	mov	w8, #0x4                // =4
     a2c:      	mov	w1, #0x8                // =8
     a30:      	blr	x8
     a34:      	ldr	x8, [x29, #0x18]
     a38:      	add	x9, x8, #0x20
     a3c:      	stp	x9, x8, [sp, #0xb8]
     a40:      	subs	w23, w23, #0x1
     a44:      	b.ne	0x8c4 <generic_retkprobe_event+0x8c4>
     a48:      	b	0xc88 <generic_retkprobe_event+0xc88>
     a4c:      	mov	w23, #0x800             // =2048
     a50:      	mov	w25, #0x8               // =8
     a54:      	ldp	x29, x2, [sp, #0xb0]
     a58:      	ldp	x8, x9, [sp, #0x98]
     a5c:      	cmp	x29, x8
     a60:      	ccmp	x2, x9, #0x0, eq
     a64:      	b.eq	0xc74 <generic_retkprobe_event+0xc74>
     a68:      	ldr	x21, [sp, #0xc0]
     a6c:      	mov	w8, #0x4                // =4
     a70:      	add	x9, sp, #0xd8
     a74:      	add	x0, sp, #0xd8
     a78:      	mov	w1, #0x8                // =8
     a7c:      	blr	x8
     a80:      	ldr	x8, [sp, #0xd8]
     a84:      	add	x24, sp, #0xe0
     a88:      	cmp	x29, x8
     a8c:      	b.eq	0xb84 <generic_retkprobe_event+0xb84>
     a90:      	add	x22, x29, #0x18
     a94:      	mov	w8, #0x4                // =4
     a98:      	add	x9, sp, #0xf8
     a9c:      	add	x0, sp, #0xf8
     aa0:      	mov	w1, #0x8                // =8
     aa4:      	mov	x2, x22
     aa8:      	blr	x8
     aac:      	ldr	x8, [x24, #0x18]
     ab0:      	cmp	x8, x29
     ab4:      	b.eq	0xb84 <generic_retkprobe_event+0xb84>
     ab8:      	mov	w8, #0x4                // =4
     abc:      	add	x9, sp, #0xe0
     ac0:      	add	x0, sp, #0xe0
     ac4:      	mov	w1, #0x8                // =8
     ac8:      	mov	x2, x22
     acc:      	blr	x8
     ad0:      	add	x2, x29, #0x20
     ad4:      	mov	w8, #0x4                // =4
     ad8:      	mov	w9, #0x10               // =16
     adc:      	add	x10, sp, #0xe8
     ae0:      	add	x0, sp, #0xe8
     ae4:      	mov	w1, #0x10               // =16
     ae8:      	blr	x8
     aec:      	ldr	w21, [sp, #0xec]
     af0:      	ldr	x8, [sp, #0xa8]
     af4:      	add	x29, sp, #0xe0
     af8:      	ldr	x10, [sp, #0xc8]
     afc:      	sub	x12, x10, x8
     b00:      	ldr	w22, [sp, #0xd0]
     b04:      	subs	w10, w21, w22
     b08:      	ldr	x9, [x24, #0x10]
     b0c:      	csel	w10, wzr, w10, lo
     b10:      	cmp	w22, w21
     b14:      	csel	w11, w22, w21, lo
     b18:      	cinc	w13, w11, hi
     b1c:      	sub	w14, w22, w13
     b20:      	subs	x12, x12, x13
     b24:      	str	w14, [sp, #0xd0]
     b28:      	b.lo	0xc88 <generic_retkprobe_event+0xc88>
     b2c:      	cmp	x12, #0xfff
     b30:      	b.hi	0xc88 <generic_retkprobe_event+0xc88>
     b34:      	cmp	w22, w21
     b38:      	b.ls	0xb44 <generic_retkprobe_event+0xb44>
     b3c:      	mov	w13, #0x2f              // =47
     b40:      	strb	w13, [x8, x12]
     b44:      	add	x29, x8, x12
     b48:      	cmp	w22, w21
     b4c:      	add	x2, x9, x10
     b50:      	and	w1, w11, #0xff
     b54:      	mov	w8, #0x4                // =4
     b58:      	cinc	x0, x29, hi
     b5c:      	blr	x8
     b60:      	cmp	w22, w21
     b64:      	str	x29, [sp, #0xc8]
     b68:      	add	x29, sp, #0xe0
     b6c:      	b.ls	0xc88 <generic_retkprobe_event+0xc88>
     b70:      	ldr	x8, [x29]
     b74:      	str	x8, [sp, #0xb0]
     b78:      	subs	w23, w23, #0x1
     b7c:      	b.ne	0xa54 <generic_retkprobe_event+0xa54>
     b80:      	b	0xc88 <generic_retkprobe_event+0xc88>
     b84:      	add	x2, x21, #0x10
     b88:      	mov	w8, #0x4                // =4
     b8c:      	add	x9, sp, #0xf8
     b90:      	add	x0, sp, #0xf8
     b94:      	mov	w1, #0x8                // =8
     b98:      	blr	x8
     b9c:      	ldr	x8, [sp, #0xc0]
     ba0:      	ldr	x9, [x24, #0x18]
     ba4:      	add	x29, sp, #0xe0
     ba8:      	cmp	x8, x9
     bac:      	b.eq	0xc80 <generic_retkprobe_event+0xc80>
     bb0:      	ldr	x0, [sp, #0x38]
     bb4:      	add	x2, x21, #0x18
     bb8:      	mov	w8, #0x4                // =4
     bbc:      	mov	w1, #0x8                // =8
     bc0:      	blr	x8
     bc4:      	ldr	x8, [x29, #0x18]
     bc8:      	add	x9, x8, #0x20
     bcc:      	stp	x9, x8, [sp, #0xb8]
     bd0:      	subs	w23, w23, #0x1
     bd4:      	b.ne	0xa54 <generic_retkprobe_event+0xa54>
     bd8:      	b	0xc88 <generic_retkprobe_event+0xc88>
     bdc:      	cmp	w23, #0x2c
     be0:      	b.hi	0xdb0 <generic_retkprobe_event+0xdb0>
     be4:      	mov	x9, #0x7cf2             // =31986
     be8:      	mov	w8, #0x1                // =1
     bec:      	movk	x9, #0xf202, lsl #16
     bf0:      	lsl	x8, x8, x23
     bf4:      	movk	x9, #0x11c1, lsl #32
     bf8:      	tst	x8, x9
     bfc:      	b.eq	0xdb0 <generic_retkprobe_event+0xdb0>
     c00:      	add	x8, sp, #0xe0
     c04:      	str	wzr, [sp, #0xe0]
     c08:      	add	x9, sp, #0xe0
     c0c:      	add	x1, sp, #0xe0
     c10:      	str	x25, [x8, #0x18]
     c14:      	mov	w8, #0x1                // =1
     c18:      	mov	x0, x24
     c1c:      	blr	x8
     c20:      	cbz	x0, 0x15d0 <generic_retkprobe_event+0x15d0>
     c24:      	add	x25, sp, #0xe0
     c28:      	mov	x29, xzr
     c2c:      	cmp	w23, #0x10
     c30:      	b.le	0xe14 <generic_retkprobe_event+0xe14>
     c34:      	cmp	w23, #0x1e
     c38:      	b.le	0xf30 <generic_retkprobe_event+0xf30>
     c3c:      	cmp	w23, #0x26
     c40:      	b.gt	0x12f8 <generic_retkprobe_event+0x12f8>
     c44:      	ldr	x0, [sp, #0x20]
     c48:      	sub	w8, w23, #0x1f
     c4c:      	cmp	w8, #0x2
     c50:      	b.hs	0x16b0 <generic_retkprobe_event+0x16b0>
     c54:      	mov	w8, #0x1                // =1
     c58:      	add	x9, sp, #0xf8
     c5c:      	mov	w10, #0x4               // =4
     c60:      	add	x2, sp, #0xf8
     c64:      	mov	w1, #0x1                // =1
     c68:      	mov	w29, #0x4               // =4
     c6c:      	blr	x10
     c70:      	b	0xd68 <generic_retkprobe_event+0xd68>
     c74:      	mov	w8, #0x1                // =1
     c78:      	add	x29, sp, #0xe0
     c7c:      	b	0xc84 <generic_retkprobe_event+0xc84>
     c80:      	mov	w8, #0x1                // =1
     c84:      	strb	w8, [sp, #0xd4]
     c88:      	ldr	x8, [sp, #0xc8]
     c8c:      	ldr	x2, [sp, #0x30]
     c90:      	cmp	x8, x2
     c94:      	b.eq	0xcc8 <generic_retkprobe_event+0xcc8>
     c98:      	ldrb	w9, [sp, #0xd4]
     c9c:      	mov	w11, #0x1000            // =4096
     ca0:      	cmp	w9, #0x0
     ca4:      	ldr	w9, [sp, #0xd0]
     ca8:      	cset	w10, eq
     cac:      	sub	w11, w11, w9
     cb0:      	cmp	w9, #0x0
     cb4:      	csel	w9, w11, w9, gt
     cb8:      	cbz	x8, 0xd88 <generic_retkprobe_event+0xd88>
     cbc:      	lsl	w23, w10, #1
     cc0:      	mov	x2, x8
     cc4:      	b	0xcd0 <generic_retkprobe_event+0xcd0>
     cc8:      	mov	w23, wzr
     ccc:      	mov	w9, wzr
     cd0:      	ldr	x21, [sp, #0x28]
     cd4:      	and	w22, w9, #0xfff
     cd8:      	mov	w8, #0x4                // =4
     cdc:      	mov	w24, #0x4               // =4
     ce0:      	mov	w1, w22
     ce4:      	add	x0, x21, #0xa0
     ce8:      	blr	x8
     cec:      	str	w22, [x21, #0x9c]
     cf0:      	ldr	x2, [sp, #0x18]
     cf4:      	mov	w21, #0x8               // =8
     cf8:      	add	x8, sp, #0x98
     cfc:      	mov	w9, #0x4                // =4
     d00:      	add	x0, sp, #0x98
     d04:      	mov	w1, #0x8                // =8
     d08:      	blr	x9
     d0c:      	ldr	x8, [sp, #0x98]
     d10:      	add	x9, sp, #0xe8
     d14:      	mov	w10, #0x4               // =4
     d18:      	add	x0, sp, #0xe8
     d1c:      	mov	w1, #0x8                // =8
     d20:      	add	x8, x8, #0x30
     d24:      	ldr	x8, [sp, #0x98]
     d28:      	add	x2, x8, #0x30
     d2c:      	blr	x10
     d30:      	ldr	x8, [x29, #0x8]
     d34:      	mov	w9, #0x2                // =2
     d38:      	add	x10, sp, #0xf8
     d3c:      	add	x0, sp, #0xf8
     d40:      	ldr	x2, [x29, #0x8]
     d44:      	mov	w1, #0x2                // =2
     d48:      	blr	x24
     d4c:      	ldr	x8, [sp, #0x20]
     d50:      	add	w29, w22, #0xa
     d54:      	add	x8, x8, x22
     d58:      	ldr	x22, [sp, #0x10]
     d5c:      	str	w23, [x8, #0x4]
     d60:      	ldrh	w9, [sp, #0xf8]
     d64:      	strh	w9, [x8, #0x8]
     d68:      	mov	w10, #0x5ea0            // =24224
     d6c:      	tbz	w29, #0x1f, 0xd90 <generic_retkprobe_event+0xd90>
     d70:      	ldr	x9, [sp, #0x28]
     d74:      	mov	w8, #-0x1               // =-1
     d78:      	str	w8, [x9, x10]
     d7c:      	str	w8, [x9, #0x98]
     d80:      	mov	w8, #0x4                // =4
     d84:      	b	0xd98 <generic_retkprobe_event+0xd98>
     d88:      	ldr	x22, [sp, #0x10]
     d8c:      	mov	x29, xzr
     d90:      	and	x8, x29, #0x7fffffff
     d94:      	add	x8, x8, #0x4
     d98:      	ldr	x29, [sp, #0x40]
     d9c:      	add	x21, x8, #0x8
     da0:      	ldr	w8, [x29, #0x60]
     da4:      	cmp	w8, #0xb
     da8:      	b.ne	0x178 <generic_retkprobe_event+0x178>
     dac:      	b	0x294 <generic_retkprobe_event+0x294>
     db0:      	str	wzr, [sp, #0x70]
     db4:      	mov	w8, #0x1                // =1
     db8:      	add	x9, sp, #0x70
     dbc:      	add	x1, sp, #0x70
     dc0:      	mov	x0, x24
     dc4:      	blr	x8
     dc8:      	cbz	x0, 0x15d0 <generic_retkprobe_event+0x15d0>
     dcc:      	mov	x29, xzr
     dd0:      	cmp	w23, #0x19
     dd4:      	b.gt	0xfdc <generic_retkprobe_event+0xfdc>
     dd8:      	cmp	w23, #0x12
     ddc:      	b.le	0x13b8 <generic_retkprobe_event+0x13b8>
     de0:      	cmp	w23, #0x14
     de4:      	b.le	0x1608 <generic_retkprobe_event+0x1608>
     de8:      	cmp	w23, #0x15
     dec:      	b.eq	0x1ca8 <generic_retkprobe_event+0x1ca8>
     df0:      	cmp	w23, #0x16
     df4:      	b.eq	0x1c48 <generic_retkprobe_event+0x1c48>
     df8:      	cmp	w23, #0x17
     dfc:      	mov	w10, #0x5ea0            // =24224
     e00:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
     e04:      	ldr	x8, [sp, #0x28]
     e08:      	mov	w29, #0x8               // =8
     e0c:      	stp	w25, wzr, [x8, #0x9c]
     e10:      	b	0xd6c <generic_retkprobe_event+0xd6c>
     e14:      	cmp	w23, #0x9
     e18:      	mov	w10, #0x5ea0            // =24224
     e1c:      	b.gt	0xf5c <generic_retkprobe_event+0xf5c>
     e20:      	cmp	w23, #0x4
     e24:      	b.le	0x1404 <generic_retkprobe_event+0x1404>
     e28:      	cmp	w23, #0x5
     e2c:      	b.eq	0x184c <generic_retkprobe_event+0x184c>
     e30:      	cmp	w23, #0x6
     e34:      	b.eq	0xfc0 <generic_retkprobe_event+0xfc0>
     e38:      	cmp	w23, #0x7
     e3c:      	mov	w10, #0x5ea0            // =24224
     e40:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
     e44:      	add	x29, sp, #0xe0
     e48:      	str	x22, [sp, #0x10]
     e4c:      	ldr	x25, [sp, #0x28]
     e50:      	mov	x24, x0
     e54:      	mov	w21, #0x2               // =2
     e58:      	mov	w8, #0x4                // =4
     e5c:      	ldr	x22, [x29, #0x18]
     e60:      	mov	w1, #0x2                // =2
     e64:      	mov	w23, #0x4               // =4
     e68:      	stur	x22, [x25, #0xc4]
     e6c:      	add	x0, x25, #0xc2
     e70:      	add	x2, x22, #0x10
     e74:      	blr	x8
     e78:      	add	x0, x25, #0xd6
     e7c:      	add	x2, x22, #0x12
     e80:      	mov	w8, #0x1                // =1
     e84:      	mov	w9, #0x4                // =4
     e88:      	mov	w1, #0x1                // =1
     e8c:      	blr	x9
     e90:      	add	x0, x25, #0xd4
     e94:      	add	x2, x22, #0x21e
     e98:      	mov	w8, #0x4                // =4
     e9c:      	mov	w1, #0x2                // =2
     ea0:      	blr	x8
     ea4:      	add	x0, x25, #0xc0
     ea8:      	add	x2, x22, #0x21c
     eac:      	mov	w8, #0x4                // =4
     eb0:      	mov	w1, #0x2                // =2
     eb4:      	blr	x8
     eb8:      	add	x0, x25, #0xcc
     ebc:      	add	x2, x22, #0x214
     ec0:      	mov	w8, #0x4                // =4
     ec4:      	mov	w1, #0x4                // =4
     ec8:      	blr	x8
     ecc:      	add	x0, x25, #0xd0
     ed0:      	add	x2, x22, #0x210
     ed4:      	mov	w1, #0x4                // =4
     ed8:      	blr	x23
     edc:      	ldrh	w8, [x25, #0xc2]
     ee0:      	ldr	x0, [sp, #0x20]
     ee4:      	add	x23, x25, #0xac
     ee8:      	cmp	w8, #0xa
     eec:      	stp	xzr, xzr, [x0]
     ef0:      	stp	xzr, xzr, [x0, #0x10]
     ef4:      	b.eq	0x1ff0 <generic_retkprobe_event+0x1ff0>
     ef8:      	cmp	w8, #0x2
     efc:      	b.ne	0x2018 <generic_retkprobe_event+0x2018>
     f00:      	add	x2, x22, #0x4
     f04:      	mov	w8, #0x4                // =4
     f08:      	mov	w1, #0x4                // =4
     f0c:      	mov	w21, #0x4               // =4
     f10:      	blr	x8
     f14:      	mov	x0, x23
     f18:      	mov	w1, #0x4                // =4
     f1c:      	mov	x2, x22
     f20:      	blr	x21
     f24:      	b	0x2018 <generic_retkprobe_event+0x2018>
     f28:      	mov	x29, x23
     f2c:      	b	0x324 <generic_retkprobe_event+0x324>
     f30:      	cmp	w23, #0x1c
     f34:      	b.gt	0x13e0 <generic_retkprobe_event+0x13e0>
     f38:      	cmp	w23, #0x11
     f3c:      	b.eq	0x16e0 <generic_retkprobe_event+0x16e0>
     f40:      	cmp	w23, #0x19
     f44:      	b.eq	0x17a0 <generic_retkprobe_event+0x17a0>
     f48:      	ldr	x0, [sp, #0x20]
     f4c:      	cmp	w23, #0x1c
     f50:      	mov	w10, #0x5ea0            // =24224
     f54:      	b.eq	0x1418 <generic_retkprobe_event+0x1418>
     f58:      	b	0xd6c <generic_retkprobe_event+0xd6c>
     f5c:      	ldr	x0, [sp, #0x20]
     f60:      	sub	w8, w23, #0xa
     f64:      	cmp	w8, #0x2
     f68:      	b.lo	0x1418 <generic_retkprobe_event+0x1418>
     f6c:      	sub	w8, w23, #0xc
     f70:      	cmp	w8, #0x2
     f74:      	b.lo	0x1430 <generic_retkprobe_event+0x1430>
     f78:      	cmp	w23, #0xe
     f7c:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
     f80:      	mov	w21, #0x8               // =8
     f84:      	add	x8, sp, #0x98
     f88:      	add	x23, sp, #0xf8
     f8c:      	mov	w9, #0x4                // =4
     f90:      	add	x0, sp, #0x98
     f94:      	add	x2, sp, #0xf8
     f98:      	mov	w1, #0x8                // =8
     f9c:      	mov	x24, x22
     fa0:      	mov	w22, #0x4               // =4
     fa4:      	blr	x9
     fa8:      	ldr	x8, [sp, #0x98]
     fac:      	add	x0, sp, #0xf8
     fb0:      	mov	w1, #0x8                // =8
     fb4:      	ldr	x2, [sp, #0x98]
     fb8:      	blr	x22
     fbc:      	mov	x22, x24
     fc0:      	ldr	x8, [sp, #0x28]
     fc4:      	ldr	x2, [x25, #0x18]
     fc8:      	mov	w9, #0x2d               // =45
     fcc:      	mov	w1, #0x1001             // =4097
     fd0:      	add	x0, x8, #0xa0
     fd4:      	mov	w8, #0x1001             // =4097
     fd8:      	b	0x19c0 <generic_retkprobe_event+0x19c0>
     fdc:      	cmp	w23, #0x20
     fe0:      	b.le	0x1564 <generic_retkprobe_event+0x1564>
     fe4:      	sub	w8, w23, #0x21
     fe8:      	cmp	w8, #0x4
     fec:      	b.hs	0x144c <generic_retkprobe_event+0x144c>
     ff0:      	ldr	x0, [sp, #0x20]
     ff4:      	mov	w29, #0x8               // =8
     ff8:      	mov	w8, #0x4                // =4
     ffc:      	mov	w1, #0x8                // =8
    1000:      	b	0x15fc <generic_retkprobe_event+0x15fc>
    1004:      	add	x8, x29, x22
    1008:      	mov	w9, #0x4                // =4
    100c:      	mov	x22, x10
    1010:      	str	x8, [sp, #0x48]
    1014:      	add	x0, x24, x8
    1018:      	ldr	x8, [sp, #0x98]
    101c:      	mov	w1, w22
    1020:      	ldr	x2, [sp, #0x98]
    1024:      	blr	x9
    1028:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    102c:      	add	x29, x22, x29
    1030:      	cbz	x21, 0x103c <generic_retkprobe_event+0x103c>
    1034:      	subs	x21, x21, x23
    1038:      	b.eq	0x324 <generic_retkprobe_event+0x324>
    103c:      	ldr	x8, [sp, #0x50]
    1040:      	cmp	x8, #0x3
    1044:      	b.lo	0x324 <generic_retkprobe_event+0x324>
    1048:      	ldr	x8, [sp, #0x108]
    104c:      	mov	w9, #0x4                // =4
    1050:      	add	x10, sp, #0x98
    1054:      	add	x0, sp, #0x98
    1058:      	mov	w1, #0x10               // =16
    105c:      	add	x2, x8, #0x20
    1060:      	mov	w8, #0x10               // =16
    1064:      	blr	x9
    1068:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    106c:      	ldr	x8, [sp, #0xa0]
    1070:      	cmp	x8, x21
    1074:      	csel	x23, x8, x21, lo
    1078:      	cmp	x21, #0x0
    107c:      	csel	x8, x8, x23, eq
    1080:      	cmp	x8, #0xffe
    1084:      	str	x8, [sp, #0x38]
    1088:      	b.hi	0x668 <generic_retkprobe_event+0x668>
    108c:      	ldr	x8, [sp, #0x48]
    1090:      	mov	w9, #0x4                // =4
    1094:      	ldr	x1, [sp, #0x38]
    1098:      	add	x22, x22, x8
    109c:      	and	x8, x22, #0x3fff
    10a0:      	add	x0, x24, x8
    10a4:      	ldr	x8, [sp, #0x98]
    10a8:      	ldr	x2, [sp, #0x98]
    10ac:      	blr	x9
    10b0:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    10b4:      	ldr	x8, [sp, #0x38]
    10b8:      	add	x29, x8, x29
    10bc:      	cbz	x21, 0x10c8 <generic_retkprobe_event+0x10c8>
    10c0:      	subs	x21, x21, x23
    10c4:      	b.eq	0x324 <generic_retkprobe_event+0x324>
    10c8:      	ldr	x8, [sp, #0x50]
    10cc:      	cmp	x8, #0x3
    10d0:      	b.eq	0x324 <generic_retkprobe_event+0x324>
    10d4:      	ldr	x8, [sp, #0x108]
    10d8:      	mov	w9, #0x4                // =4
    10dc:      	add	x10, sp, #0x98
    10e0:      	add	x0, sp, #0x98
    10e4:      	mov	w1, #0x10               // =16
    10e8:      	add	x2, x8, #0x30
    10ec:      	mov	w8, #0x10               // =16
    10f0:      	blr	x9
    10f4:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    10f8:      	ldr	x8, [sp, #0xa0]
    10fc:      	cmp	x8, x21
    1100:      	csel	x23, x8, x21, lo
    1104:      	cmp	x21, #0x0
    1108:      	csel	x8, x8, x23, eq
    110c:      	cmp	x8, #0xffe
    1110:      	str	x8, [sp, #0x48]
    1114:      	b.hi	0x668 <generic_retkprobe_event+0x668>
    1118:      	ldr	x8, [sp, #0x38]
    111c:      	mov	w9, #0x4                // =4
    1120:      	ldr	x1, [sp, #0x48]
    1124:      	add	x22, x8, x22
    1128:      	and	x8, x22, #0x3fff
    112c:      	add	x0, x24, x8
    1130:      	ldr	x8, [sp, #0x98]
    1134:      	ldr	x2, [sp, #0x98]
    1138:      	blr	x9
    113c:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    1140:      	ldr	x8, [sp, #0x48]
    1144:      	add	x29, x8, x29
    1148:      	cbz	x21, 0x1154 <generic_retkprobe_event+0x1154>
    114c:      	subs	x21, x21, x23
    1150:      	b.eq	0x324 <generic_retkprobe_event+0x324>
    1154:      	ldr	x8, [sp, #0x50]
    1158:      	cmp	x8, #0x5
    115c:      	b.lo	0x324 <generic_retkprobe_event+0x324>
    1160:      	ldr	x8, [sp, #0x108]
    1164:      	mov	w9, #0x4                // =4
    1168:      	add	x10, sp, #0x98
    116c:      	add	x0, sp, #0x98
    1170:      	mov	w1, #0x10               // =16
    1174:      	add	x2, x8, #0x40
    1178:      	mov	w8, #0x10               // =16
    117c:      	blr	x9
    1180:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    1184:      	ldr	x8, [sp, #0xa0]
    1188:      	cmp	x8, x21
    118c:      	csel	x23, x8, x21, lo
    1190:      	cmp	x21, #0x0
    1194:      	csel	x8, x8, x23, eq
    1198:      	cmp	x8, #0xffe
    119c:      	str	x8, [sp, #0x38]
    11a0:      	b.hi	0x668 <generic_retkprobe_event+0x668>
    11a4:      	ldr	x8, [sp, #0x48]
    11a8:      	mov	w9, #0x4                // =4
    11ac:      	ldr	x1, [sp, #0x38]
    11b0:      	add	x22, x8, x22
    11b4:      	and	x8, x22, #0x3fff
    11b8:      	add	x0, x24, x8
    11bc:      	ldr	x8, [sp, #0x98]
    11c0:      	ldr	x2, [sp, #0x98]
    11c4:      	blr	x9
    11c8:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    11cc:      	ldr	x8, [sp, #0x38]
    11d0:      	add	x29, x8, x29
    11d4:      	cbz	x21, 0x11e0 <generic_retkprobe_event+0x11e0>
    11d8:      	subs	x21, x21, x23
    11dc:      	b.eq	0x324 <generic_retkprobe_event+0x324>
    11e0:      	ldr	x8, [sp, #0x50]
    11e4:      	cmp	x8, #0x5
    11e8:      	b.eq	0x324 <generic_retkprobe_event+0x324>
    11ec:      	ldr	x8, [sp, #0x108]
    11f0:      	mov	w9, #0x4                // =4
    11f4:      	add	x10, sp, #0x98
    11f8:      	add	x0, sp, #0x98
    11fc:      	mov	w1, #0x10               // =16
    1200:      	add	x2, x8, #0x50
    1204:      	mov	w8, #0x10               // =16
    1208:      	blr	x9
    120c:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    1210:      	ldr	x8, [sp, #0xa0]
    1214:      	cmp	x8, x21
    1218:      	csel	x23, x8, x21, lo
    121c:      	cmp	x21, #0x0
    1220:      	csel	x8, x8, x23, eq
    1224:      	cmp	x8, #0xffe
    1228:      	str	x8, [sp, #0x48]
    122c:      	b.hi	0x668 <generic_retkprobe_event+0x668>
    1230:      	ldr	x8, [sp, #0x38]
    1234:      	mov	w9, #0x4                // =4
    1238:      	ldr	x1, [sp, #0x48]
    123c:      	add	x22, x8, x22
    1240:      	and	x8, x22, #0x3fff
    1244:      	add	x0, x24, x8
    1248:      	ldr	x8, [sp, #0x98]
    124c:      	ldr	x2, [sp, #0x98]
    1250:      	blr	x9
    1254:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    1258:      	ldr	x8, [sp, #0x48]
    125c:      	add	x29, x8, x29
    1260:      	cbz	x21, 0x126c <generic_retkprobe_event+0x126c>
    1264:      	subs	x21, x21, x23
    1268:      	b.eq	0x324 <generic_retkprobe_event+0x324>
    126c:      	ldr	x8, [sp, #0x50]
    1270:      	cmp	x8, #0x7
    1274:      	b.lo	0x324 <generic_retkprobe_event+0x324>
    1278:      	ldr	x8, [sp, #0x108]
    127c:      	mov	w9, #0x4                // =4
    1280:      	add	x10, sp, #0x98
    1284:      	add	x0, sp, #0x98
    1288:      	mov	w1, #0x10               // =16
    128c:      	add	x2, x8, #0x60
    1290:      	mov	w8, #0x10               // =16
    1294:      	blr	x9
    1298:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    129c:      	ldr	x8, [sp, #0xa0]
    12a0:      	cmp	x8, x21
    12a4:      	csel	x9, x8, x21, lo
    12a8:      	cmp	x21, #0x0
    12ac:      	csel	x21, x8, x9, eq
    12b0:      	cmp	x21, #0xffe
    12b4:      	b.hi	0x668 <generic_retkprobe_event+0x668>
    12b8:      	ldr	x8, [sp, #0x48]
    12bc:      	mov	w9, #0x4                // =4
    12c0:      	mov	w1, w21
    12c4:      	add	x8, x8, x22
    12c8:      	and	x8, x8, #0x3fff
    12cc:      	add	x0, x24, x8
    12d0:      	ldr	x8, [sp, #0x98]
    12d4:      	ldr	x2, [sp, #0x98]
    12d8:      	blr	x9
    12dc:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    12e0:      	add	x29, x21, x29
    12e4:      	b	0x324 <generic_retkprobe_event+0x324>
    12e8:      	mov	w8, #-0x2               // =-2
    12ec:      	str	w8, [x24, x25]
    12f0:      	mov	w8, #0x4                // =4
    12f4:      	b	0x330 <generic_retkprobe_event+0x330>
    12f8:      	ldr	x0, [sp, #0x20]
    12fc:      	cmp	w23, #0x27
    1300:      	b.eq	0x19a4 <generic_retkprobe_event+0x19a4>
    1304:      	cmp	w23, #0x28
    1308:      	b.eq	0x19e0 <generic_retkprobe_event+0x19e0>
    130c:      	cmp	w23, #0x2c
    1310:      	mov	w10, #0x5ea0            // =24224
    1314:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    1318:      	mov	x24, x22
    131c:      	ldr	x22, [x25, #0x18]
    1320:      	strb	wzr, [sp, #0x98]
    1324:      	mov	w8, #0x2                // =2
    1328:      	mov	w9, #0x4                // =4
    132c:      	mov	w1, #0x2                // =2
    1330:      	mov	x2, x22
    1334:      	stp	xzr, xzr, [x0]
    1338:      	stp	xzr, xzr, [x0, #0x10]
    133c:      	stp	xzr, xzr, [x0, #0x20]
    1340:      	stp	xzr, xzr, [x0, #0x30]
    1344:      	stp	xzr, xzr, [x0, #0x40]
    1348:      	stp	xzr, xzr, [x0, #0x50]
    134c:      	stp	xzr, xzr, [x0, #0x60]
    1350:      	blr	x9
    1354:      	tbnz	x0, #0x3f, 0x2118 <generic_retkprobe_event+0x2118>
    1358:      	add	x23, x22, #0x2
    135c:      	mov	w8, #0x1                // =1
    1360:      	mov	w9, #0x4                // =4
    1364:      	add	x10, sp, #0x98
    1368:      	add	x0, sp, #0x98
    136c:      	mov	w1, #0x1                // =1
    1370:      	mov	x2, x23
    1374:      	blr	x9
    1378:      	tbnz	x0, #0x3f, 0x2118 <generic_retkprobe_event+0x2118>
    137c:      	ldrb	w8, [sp, #0x98]
    1380:      	ldr	x10, [sp, #0x28]
    1384:      	cmp	w8, #0x0
    1388:      	add	x0, x10, #0xa0
    138c:      	cset	w9, eq
    1390:      	strb	w9, [x10, #0x9e]
    1394:      	cbz	w8, 0x20f8 <generic_retkprobe_event+0x20f8>
    1398:      	mov	w8, #0x6c               // =108
    139c:      	mov	w9, #0x2d               // =45
    13a0:      	mov	w1, #0x6c               // =108
    13a4:      	mov	x2, x23
    13a8:      	blr	x9
    13ac:      	tbnz	w0, #0x1f, 0x2118 <generic_retkprobe_event+0x2118>
    13b0:      	sub	w21, w0, #0x1
    13b4:      	b	0x2110 <generic_retkprobe_event+0x2110>
    13b8:      	cmp	w23, #0x7
    13bc:      	b.gt	0x15d8 <generic_retkprobe_event+0x15d8>
    13c0:      	cmp	w23, #0x2
    13c4:      	b.eq	0x1a58 <generic_retkprobe_event+0x1a58>
    13c8:      	cmp	w23, #0x3
    13cc:      	mov	w10, #0x5ea0            // =24224
    13d0:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    13d4:      	stur	xzr, [x0, #0x9c]
    13d8:      	mov	w29, #0x8               // =8
    13dc:      	b	0xd6c <generic_retkprobe_event+0xd6c>
    13e0:      	ldr	x0, [sp, #0x20]
    13e4:      	mov	w8, #0x2                // =2
    13e8:      	add	x9, sp, #0xf8
    13ec:      	mov	w10, #0x4               // =4
    13f0:      	add	x2, sp, #0xf8
    13f4:      	mov	w1, #0x2                // =2
    13f8:      	mov	w29, #0x4               // =4
    13fc:      	blr	x10
    1400:      	b	0xd68 <generic_retkprobe_event+0xd68>
    1404:      	ldr	x0, [sp, #0x20]
    1408:      	cmp	w23, #0x1
    140c:      	b.eq	0x1430 <generic_retkprobe_event+0x1430>
    1410:      	cmp	w23, #0x4
    1414:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    1418:      	mov	w29, #0x8               // =8
    141c:      	mov	w8, #0x4                // =4
    1420:      	add	x9, sp, #0xf8
    1424:      	add	x2, sp, #0xf8
    1428:      	mov	w1, #0x8                // =8
    142c:      	b	0x1600 <generic_retkprobe_event+0x1600>
    1430:      	add	x8, sp, #0xf8
    1434:      	mov	w9, #0x4                // =4
    1438:      	add	x2, sp, #0xf8
    143c:      	mov	w1, #0x4                // =4
    1440:      	mov	w29, #0x4               // =4
    1444:      	blr	x9
    1448:      	b	0xd68 <generic_retkprobe_event+0xd68>
    144c:      	cmp	w23, #0x2b
    1450:      	b.eq	0x1d68 <generic_retkprobe_event+0x1d68>
    1454:      	cmp	w23, #0x29
    1458:      	mov	w10, #0x5ea0            // =24224
    145c:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    1460:      	str	x22, [sp, #0x10]
    1464:      	add	x2, x25, #0x18
    1468:      	mov	w8, #0x8                // =8
    146c:      	mov	w9, #0x4                // =4
    1470:      	add	x10, sp, #0x98
    1474:      	mov	x24, x0
    1478:      	add	x0, sp, #0x98
    147c:      	mov	w1, #0x8                // =8
    1480:      	blr	x9
    1484:      	ldr	x22, [sp, #0x98]
    1488:      	cbz	x22, 0x2194 <generic_retkprobe_event+0x2194>
    148c:      	ldr	x25, [sp, #0x28]
    1490:      	add	x2, x22, #0x10
    1494:      	mov	w21, #0x2               // =2
    1498:      	mov	w8, #0x4                // =4
    149c:      	stur	x22, [x25, #0xc4]
    14a0:      	add	x0, x25, #0xc2
    14a4:      	mov	w1, #0x2                // =2
    14a8:      	mov	w23, #0x4               // =4
    14ac:      	blr	x8
    14b0:      	add	x0, x25, #0xd6
    14b4:      	add	x2, x22, #0x12
    14b8:      	mov	w8, #0x1                // =1
    14bc:      	mov	w9, #0x4                // =4
    14c0:      	mov	w1, #0x1                // =1
    14c4:      	blr	x9
    14c8:      	add	x0, x25, #0xd4
    14cc:      	add	x2, x22, #0x21e
    14d0:      	mov	w8, #0x4                // =4
    14d4:      	mov	w1, #0x2                // =2
    14d8:      	blr	x8
    14dc:      	add	x0, x25, #0xc0
    14e0:      	add	x2, x22, #0x21c
    14e4:      	mov	w8, #0x4                // =4
    14e8:      	mov	w1, #0x2                // =2
    14ec:      	blr	x8
    14f0:      	add	x0, x25, #0xcc
    14f4:      	add	x2, x22, #0x214
    14f8:      	mov	w8, #0x4                // =4
    14fc:      	mov	w1, #0x4                // =4
    1500:      	blr	x8
    1504:      	add	x0, x25, #0xd0
    1508:      	add	x2, x22, #0x210
    150c:      	mov	w1, #0x4                // =4
    1510:      	blr	x23
    1514:      	ldr	x8, [sp, #0x20]
    1518:      	add	x23, x25, #0xac
    151c:      	stp	xzr, xzr, [x8]
    1520:      	stp	xzr, xzr, [x8, #0x10]
    1524:      	ldrh	w8, [x25, #0xc2]
    1528:      	cmp	w8, #0xa
    152c:      	b.eq	0x2124 <generic_retkprobe_event+0x2124>
    1530:      	cmp	w8, #0x2
    1534:      	b.ne	0x2150 <generic_retkprobe_event+0x2150>
    1538:      	ldr	x0, [sp, #0x20]
    153c:      	add	x2, x22, #0x4
    1540:      	mov	w8, #0x4                // =4
    1544:      	mov	w1, #0x4                // =4
    1548:      	mov	w21, #0x4               // =4
    154c:      	blr	x8
    1550:      	mov	x0, x23
    1554:      	mov	w1, #0x4                // =4
    1558:      	mov	x2, x22
    155c:      	blr	x21
    1560:      	b	0x2150 <generic_retkprobe_event+0x2150>
    1564:      	cmp	w23, #0x1a
    1568:      	b.eq	0x1df8 <generic_retkprobe_event+0x1df8>
    156c:      	cmp	w23, #0x1b
    1570:      	mov	w10, #0x5ea0            // =24224
    1574:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    1578:      	ldp	x9, x8, [sp, #0x20]
    157c:      	add	x2, x25, #0x18
    1580:      	mov	w1, #0x3f               // =63
    1584:      	add	x0, x8, #0xac
    1588:      	stp	xzr, xzr, [x9, #0x40]
    158c:      	stp	xzr, xzr, [x9, #0x30]
    1590:      	stp	xzr, xzr, [x9, #0x20]
    1594:      	mov	w8, #0x3f               // =63
    1598:      	stp	xzr, xzr, [x9, #0x10]
    159c:      	stp	xzr, xzr, [x9]
    15a0:      	mov	w9, #0x2d               // =45
    15a4:      	blr	x9
    15a8:      	tbnz	x0, #0x3f, 0x15d0 <generic_retkprobe_event+0x15d0>
    15ac:      	ldr	x8, [sp, #0x28]
    15b0:      	add	x2, x25, #0x360
    15b4:      	mov	w9, #0x4                // =4
    15b8:      	mov	w1, #0x8                // =8
    15bc:      	add	x0, x8, #0xa4
    15c0:      	mov	w8, #0x8                // =8
    15c4:      	blr	x9
    15c8:      	mov	w29, #0x50              // =80
    15cc:      	b	0xd68 <generic_retkprobe_event+0xd68>
    15d0:      	mov	x29, xzr
    15d4:      	b	0xd68 <generic_retkprobe_event+0xd68>
    15d8:      	cmp	w23, #0x8
    15dc:      	b.eq	0x1ac8 <generic_retkprobe_event+0x1ac8>
    15e0:      	cmp	w23, #0x12
    15e4:      	mov	w10, #0x5ea0            // =24224
    15e8:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    15ec:      	mov	x29, xzr
    15f0:      	mov	w8, #0x4                // =4
    15f4:      	ldr	x0, [sp, #0x20]
    15f8:      	mov	w1, wzr
    15fc:      	mov	x2, x25
    1600:      	blr	x8
    1604:      	b	0xd68 <generic_retkprobe_event+0xd68>
    1608:      	cmp	w23, #0x13
    160c:      	b.eq	0x1d28 <generic_retkprobe_event+0x1d28>
    1610:      	cmp	w23, #0x14
    1614:      	mov	w10, #0x5ea0            // =24224
    1618:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    161c:      	str	xzr, [sp, #0x98]
    1620:      	add	x2, x25, #0x110
    1624:      	mov	w24, #0x8               // =8
    1628:      	add	x8, sp, #0x98
    162c:      	mov	w9, #0x4                // =4
    1630:      	add	x0, sp, #0x98
    1634:      	mov	w1, #0x8                // =8
    1638:      	mov	x21, x22
    163c:      	add	x22, x25, #0xd8
    1640:      	mov	w23, #0x4               // =4
    1644:      	blr	x9
    1648:      	ldr	x8, [sp, #0x98]
    164c:      	mov	w9, #0x80               // =128
    1650:      	mov	w10, #0x2d              // =45
    1654:      	ldr	x0, [sp, #0x20]
    1658:      	mov	w1, #0x80               // =128
    165c:      	ldr	x2, [sp, #0x98]
    1660:      	blr	x10
    1664:      	ldr	x29, [sp, #0x28]
    1668:      	mov	w8, #0x4                // =4
    166c:      	mov	w1, #0x4                // =4
    1670:      	mov	x2, x22
    1674:      	add	x0, x29, #0x12c
    1678:      	mov	x22, x21
    167c:      	blr	x8
    1680:      	add	x0, x29, #0x11c
    1684:      	add	x2, x25, #0xe0
    1688:      	mov	w8, #0x4                // =4
    168c:      	mov	w1, #0x8                // =8
    1690:      	blr	x8
    1694:      	add	x0, x29, #0x124
    1698:      	add	x2, x25, #0x118
    169c:      	mov	w1, #0x8                // =8
    16a0:      	blr	x23
    16a4:      	mov	w10, #0x5ea0            // =24224
    16a8:      	mov	w29, #0x98              // =152
    16ac:      	b	0xd6c <generic_retkprobe_event+0xd6c>
    16b0:      	cmp	w23, #0x26
    16b4:      	mov	w10, #0x5ea0            // =24224
    16b8:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    16bc:      	ldr	x8, [x25, #0x18]
    16c0:      	ldr	x9, [sp, #0x28]
    16c4:      	add	x2, x19, w8, uxth
    16c8:      	ubfx	w8, w8, #16, #12
    16cc:      	add	x0, x9, #0xa0
    16d0:      	add	w1, w8, #0x1
    16d4:      	mov	w8, #0x2d               // =45
    16d8:      	blr	x8
    16dc:      	b	0x19c4 <generic_retkprobe_event+0x19c4>
    16e0:      	stp	xzr, xzr, [sp, #0x98]
    16e4:      	mov	w8, #0xe                // =14
    16e8:      	mov	x24, x22
    16ec:      	blr	x8
    16f0:      	lsr	x8, x0, #32
    16f4:      	add	x9, sp, #0xe8
    16f8:      	add	x10, sp, #0xf8
    16fc:      	str	x8, [sp, #0x98]
    1700:      	mov	w8, #0x4                // =4
    1704:      	add	x0, sp, #0xe8
    1708:      	add	x2, sp, #0xf8
    170c:      	mov	w1, #0x4                // =4
    1710:      	blr	x8
    1714:      	ldr	w8, [sp, #0xe8]
    1718:      	adrp	x0, 0x1000 <generic_retkprobe_event+0x1000>
    171c:      	add	x9, sp, #0x98
    1720:      	add	x1, sp, #0x98
    1724:      	str	w8, [sp, #0xa0]
    1728:      	mov	w8, #0x1                // =1
    172c:      	ldr	x0, [x0]
    1730:      	blr	x8
    1734:      	cbz	x0, 0x1edc <generic_retkprobe_event+0x1edc>
    1738:      	ldr	x25, [sp, #0x20]
    173c:      	ldr	w21, [x0]
    1740:      	add	x8, sp, #0xe8
    1744:      	mov	w9, #0x4                // =4
    1748:      	add	x2, sp, #0xe8
    174c:      	mov	x22, x0
    1750:      	mov	w1, #0x4                // =4
    1754:      	mov	w23, #0x4               // =4
    1758:      	mov	x0, x25
    175c:      	blr	x9
    1760:      	ldr	x8, [sp, #0x28]
    1764:      	and	x21, x21, #0xfff
    1768:      	mov	x2, x22
    176c:      	add	x1, x21, #0x4
    1770:      	add	x0, x8, #0xa0
    1774:      	mov	w8, #0x4                // =4
    1778:      	blr	x8
    177c:      	add	w21, w21, #0x8
    1780:      	mov	w1, #0x4                // =4
    1784:      	add	x8, x21, x22
    1788:      	add	x0, x25, x21
    178c:      	sub	x2, x8, #0x4
    1790:      	blr	x23
    1794:      	add	x29, x21, #0x4
    1798:      	mov	x22, x24
    179c:      	b	0xd68 <generic_retkprobe_event+0xd68>
    17a0:      	add	x29, sp, #0xe0
    17a4:      	mov	x25, x22
    17a8:      	mov	w8, #0x1                // =1
    17ac:      	ldr	x22, [x29, #0x18]
    17b0:      	mov	w9, #0x4                // =4
    17b4:      	add	x10, sp, #0xd8
    17b8:      	mov	x23, x0
    17bc:      	add	x0, sp, #0xd8
    17c0:      	mov	w1, #0x1                // =1
    17c4:      	mov	x2, x22
    17c8:      	blr	x9
    17cc:      	ldrb	w8, [sp, #0xd8]
    17d0:      	cbz	w8, 0x1ee8 <generic_retkprobe_event+0x1ee8>
    17d4:      	cmp	w8, #0x1
    17d8:      	b.ne	0x2084 <generic_retkprobe_event+0x2084>
    17dc:      	add	x2, x22, #0x10
    17e0:      	mov	w21, #0x8               // =8
    17e4:      	add	x8, sp, #0x98
    17e8:      	mov	w9, #0x4                // =4
    17ec:      	add	x0, sp, #0x98
    17f0:      	mov	w1, #0x8                // =8
    17f4:      	mov	w24, #0x4               // =4
    17f8:      	blr	x9
    17fc:      	ldr	x2, [sp, #0x98]
    1800:      	add	x8, sp, #0xe8
    1804:      	mov	w9, #0x4                // =4
    1808:      	add	x0, sp, #0xe8
    180c:      	mov	w1, #0x8                // =8
    1810:      	blr	x9
    1814:      	ldr	x8, [sp, #0x98]
    1818:      	mov	w9, #0x4                // =4
    181c:      	add	x0, sp, #0x70
    1820:      	mov	w1, #0x8                // =8
    1824:      	add	x2, x8, #0x8
    1828:      	add	x8, sp, #0x70
    182c:      	blr	x9
    1830:      	ldr	x21, [sp, #0x70]
    1834:      	mov	w8, #0xfff              // =4095
    1838:      	ldr	x2, [x29, #0x8]
    183c:      	add	x0, x23, #0xa4
    1840:      	cmp	x21, #0xfff
    1844:      	csel	x22, x21, x8, lo
    1848:      	b	0x1f38 <generic_retkprobe_event+0x1f38>
    184c:      	add	x8, sp, #0xe0
    1850:      	ldr	x21, [sp, #0x28]
    1854:      	str	x22, [sp, #0x10]
    1858:      	mov	w1, #0x4                // =4
    185c:      	mov	w23, #0x4               // =4
    1860:      	add	x0, x21, #0xc4
    1864:      	ldr	x24, [x8, #0x18]
    1868:      	mov	w8, #0x4                // =4
    186c:      	add	x2, x24, #0x98
    1870:      	blr	x8
    1874:      	add	x0, x21, #0xc8
    1878:      	add	x2, x24, #0x70
    187c:      	mov	w8, #0x4                // =4
    1880:      	mov	w1, #0x4                // =4
    1884:      	blr	x8
    1888:      	add	x0, x21, #0xcc
    188c:      	add	x2, x24, #0x90
    1890:      	mov	w8, #0x4                // =4
    1894:      	mov	w1, #0x4                // =4
    1898:      	blr	x8
    189c:      	add	x0, x21, #0xd0
    18a0:      	add	x2, x24, #0xa8
    18a4:      	mov	w8, #0x4                // =4
    18a8:      	mov	w1, #0x4                // =4
    18ac:      	blr	x8
    18b0:      	str	xzr, [sp, #0x98]
    18b4:      	add	x2, x24, #0xc8
    18b8:      	mov	w8, #0x8                // =8
    18bc:      	add	x9, sp, #0x98
    18c0:      	mov	w10, #0x4               // =4
    18c4:      	add	x0, sp, #0x98
    18c8:      	mov	w1, #0x8                // =8
    18cc:      	blr	x10
    18d0:      	add	x2, x24, #0xb8
    18d4:      	mov	w8, #0x2                // =2
    18d8:      	add	x9, sp, #0xd8
    18dc:      	mov	w10, #0x4               // =4
    18e0:      	add	x0, sp, #0xd8
    18e4:      	mov	w1, #0x2                // =2
    18e8:      	blr	x10
    18ec:      	ldr	x8, [sp, #0x98]
    18f0:      	ldrh	w9, [sp, #0xd8]
    18f4:      	add	x0, sp, #0x84
    18f8:      	mov	w1, #0x1                // =1
    18fc:      	add	x22, x8, x9
    1900:      	mov	w8, #0x1                // =1
    1904:      	add	x9, sp, #0x84
    1908:      	mov	x2, x22
    190c:      	blr	x23
    1910:      	ldrb	w8, [sp, #0x84]
    1914:      	lsr	w8, w8, #4
    1918:      	cmp	w8, #0x6
    191c:      	b.eq	0x1f68 <generic_retkprobe_event+0x1f68>
    1920:      	cmp	w8, #0x4
    1924:      	b.ne	0x28ec <generic_retkprobe_event+0x28ec>
    1928:      	add	x2, x22, #0x9
    192c:      	mov	w8, #0x1                // =1
    1930:      	add	x9, sp, #0x88
    1934:      	mov	w10, #0x4               // =4
    1938:      	add	x0, sp, #0x88
    193c:      	mov	w1, #0x1                // =1
    1940:      	mov	w25, #0x4               // =4
    1944:      	blr	x10
    1948:      	ldrb	w8, [sp, #0x88]
    194c:      	ldp	x0, x9, [sp, #0x20]
    1950:      	mov	w21, #0x2               // =2
    1954:      	add	x2, x22, #0xc
    1958:      	mov	w1, #0x4                // =4
    195c:      	add	x23, x9, #0xac
    1960:      	strh	w8, [x9, #0xc0]
    1964:      	strh	w21, [x9, #0xc2]
    1968:      	stp	xzr, xzr, [x0]
    196c:      	mov	w8, #0x4                // =4
    1970:      	stp	xzr, xzr, [x0, #0x10]
    1974:      	blr	x8
    1978:      	add	x2, x22, #0x10
    197c:      	mov	w8, #0x4                // =4
    1980:      	mov	x0, x23
    1984:      	mov	w1, #0x4                // =4
    1988:      	blr	x8
    198c:      	add	x2, x24, #0xb6
    1990:      	add	x8, sp, #0x90
    1994:      	add	x0, sp, #0x90
    1998:      	mov	w1, #0x2                // =2
    199c:      	blr	x25
    19a0:      	b	0x27b4 <generic_retkprobe_event+0x27b4>
    19a4:      	ldr	x8, [x25, #0x18]
    19a8:      	mov	w9, #0x2d               // =45
    19ac:      	mov	w1, #0x11               // =17
    19b0:      	add	x2, x8, #0x118
    19b4:      	ldr	x8, [sp, #0x28]
    19b8:      	add	x0, x8, #0xa0
    19bc:      	mov	w8, #0x11               // =17
    19c0:      	blr	x9
    19c4:      	mov	x29, x0
    19c8:      	tbnz	x0, #0x3f, 0xd68 <generic_retkprobe_event+0xd68>
    19cc:      	ldr	x9, [sp, #0x20]
    19d0:      	sub	w8, w29, #0x1
    19d4:      	add	x29, x29, #0x3
    19d8:      	str	w8, [x9]
    19dc:      	b	0xd68 <generic_retkprobe_event+0xd68>
    19e0:      	mov	x23, x22
    19e4:      	ldr	x22, [x25, #0x18]
    19e8:      	stp	xzr, xzr, [x0, #0x8]
    19ec:      	mov	w8, #0x2                // =2
    19f0:      	mov	w9, #0x4                // =4
    19f4:      	mov	w1, #0x2                // =2
    19f8:      	str	xzr, [x0]
    19fc:      	mov	x24, x0
    1a00:      	mov	x2, x22
    1a04:      	blr	x9
    1a08:      	tbnz	x0, #0x3f, 0x20ec <generic_retkprobe_event+0x20ec>
    1a0c:      	ldrh	w8, [x24]
    1a10:      	cmp	w8, #0xa
    1a14:      	b.eq	0x20a4 <generic_retkprobe_event+0x20a4>
    1a18:      	cmp	w8, #0x2
    1a1c:      	b.ne	0x20d8 <generic_retkprobe_event+0x20d8>
    1a20:      	add	x2, x22, #0x4
    1a24:      	add	x8, sp, #0x98
    1a28:      	mov	w9, #0x4                // =4
    1a2c:      	add	x0, sp, #0x98
    1a30:      	mov	w1, #0x4                // =4
    1a34:      	mov	w21, #0x4               // =4
    1a38:      	blr	x9
    1a3c:      	ldr	w8, [sp, #0x98]
    1a40:      	ldr	x9, [sp, #0x28]
    1a44:      	add	x2, x22, #0x2
    1a48:      	add	x0, x9, #0x9e
    1a4c:      	stur	x8, [x9, #0xa4]
    1a50:      	mov	w8, #0x2                // =2
    1a54:      	b	0x20d0 <generic_retkprobe_event+0x20d0>
    1a58:      	add	x21, sp, #0xe0
    1a5c:      	str	x22, [sp, #0x10]
    1a60:      	str	xzr, [sp, #0x98]
    1a64:      	mov	w8, #0x8                // =8
    1a68:      	add	x9, sp, #0xe8
    1a6c:      	add	x10, sp, #0x98
    1a70:      	str	xzr, [x21, #0x8]
    1a74:      	mov	w11, #0x4               // =4
    1a78:      	mov	x24, x0
    1a7c:      	add	x0, sp, #0xe8
    1a80:      	add	x2, sp, #0x98
    1a84:      	mov	w1, #0x8                // =8
    1a88:      	mov	w29, #0x4               // =4
    1a8c:      	blr	x11
    1a90:      	ldr	x21, [x21, #0x8]
    1a94:      	mov	w8, #0xfff              // =4095
    1a98:      	add	x0, x24, #0xa4
    1a9c:      	mov	x2, x25
    1aa0:      	mov	x23, x24
    1aa4:      	cmp	x21, #0xfff
    1aa8:      	csel	x22, x21, x8, lo
    1aac:      	mov	w8, #0x4                // =4
    1ab0:      	mov	w1, w22
    1ab4:      	blr	x8
    1ab8:      	tbnz	w0, #0x1f, 0x2094 <generic_retkprobe_event+0x2094>
    1abc:      	add	x29, x22, #0x8
    1ac0:      	str	w22, [x23, #0xa0]
    1ac4:      	b	0x2098 <generic_retkprobe_event+0x2098>
    1ac8:      	ldp	x0, x29, [sp, #0x20]
    1acc:      	add	x2, x25, #0x8
    1ad0:      	mov	w8, #0x4                // =4
    1ad4:      	mov	w1, #0x4                // =4
    1ad8:      	mov	w23, #0x4               // =4
    1adc:      	str	x22, [sp, #0x10]
    1ae0:      	add	x24, x29, #0xc4
    1ae4:      	add	x22, x29, #0xdc
    1ae8:      	blr	x8
    1aec:      	add	x0, x29, #0xa0
    1af0:      	add	x2, x25, #0xc
    1af4:      	mov	w8, #0x4                // =4
    1af8:      	mov	w1, #0x4                // =4
    1afc:      	blr	x8
    1b00:      	add	x0, x29, #0xac
    1b04:      	add	x2, x25, #0x18
    1b08:      	mov	w8, #0x4                // =4
    1b0c:      	mov	w1, #0x4                // =4
    1b10:      	blr	x8
    1b14:      	add	x0, x29, #0xb0
    1b18:      	add	x2, x25, #0x1c
    1b1c:      	mov	w8, #0x4                // =4
    1b20:      	mov	w1, #0x4                // =4
    1b24:      	blr	x8
    1b28:      	add	x0, x29, #0xa4
    1b2c:      	add	x2, x25, #0x10
    1b30:      	mov	w8, #0x4                // =4
    1b34:      	mov	w1, #0x4                // =4
    1b38:      	blr	x8
    1b3c:      	add	x0, x29, #0xa8
    1b40:      	add	x2, x25, #0x14
    1b44:      	mov	w8, #0x4                // =4
    1b48:      	mov	w1, #0x4                // =4
    1b4c:      	blr	x8
    1b50:      	add	x0, x29, #0xb4
    1b54:      	add	x2, x25, #0x20
    1b58:      	mov	w8, #0x4                // =4
    1b5c:      	mov	w1, #0x4                // =4
    1b60:      	blr	x8
    1b64:      	add	x0, x29, #0xb8
    1b68:      	add	x2, x25, #0x24
    1b6c:      	mov	w8, #0x4                // =4
    1b70:      	mov	w1, #0x4                // =4
    1b74:      	blr	x8
    1b78:      	str	wzr, [x29, #0xc0]
    1b7c:      	add	x0, x29, #0xbc
    1b80:      	add	x2, x25, #0x28
    1b84:      	mov	w8, #0x4                // =4
    1b88:      	mov	w1, #0x4                // =4
    1b8c:      	blr	x8
    1b90:      	add	x0, x29, #0xcc
    1b94:      	add	x2, x25, #0x40
    1b98:      	mov	w21, #0x8               // =8
    1b9c:      	mov	w8, #0x4                // =4
    1ba0:      	mov	w1, #0x8                // =8
    1ba4:      	blr	x8
    1ba8:      	add	x0, x29, #0xd4
    1bac:      	add	x2, x25, #0x30
    1bb0:      	mov	w8, #0x4                // =4
    1bb4:      	mov	w1, #0x8                // =8
    1bb8:      	blr	x8
    1bbc:      	add	x2, x25, #0x38
    1bc0:      	mov	w8, #0x4                // =4
    1bc4:      	mov	x0, x24
    1bc8:      	mov	w1, #0x8                // =8
    1bcc:      	blr	x8
    1bd0:      	add	x2, x25, #0x90
    1bd4:      	add	x8, sp, #0x98
    1bd8:      	mov	w9, #0x4                // =4
    1bdc:      	add	x0, sp, #0x98
    1be0:      	mov	w1, #0x8                // =8
    1be4:      	blr	x9
    1be8:      	ldr	x21, [sp, #0x98]
    1bec:      	mov	w8, #0x4                // =4
    1bf0:      	mov	x0, x22
    1bf4:      	mov	w1, #0x4                // =4
    1bf8:      	add	x2, x21, #0xc8
    1bfc:      	ldr	x22, [sp, #0x10]
    1c00:      	blr	x8
    1c04:      	add	x0, x29, #0xe0
    1c08:      	add	x2, x21, #0xcc
    1c0c:      	mov	w8, #0x4                // =4
    1c10:      	mov	w1, #0x4                // =4
    1c14:      	blr	x8
    1c18:      	add	x0, x29, #0xe4
    1c1c:      	add	x2, x21, #0xd0
    1c20:      	mov	w8, #0x4                // =4
    1c24:      	mov	w1, #0x4                // =4
    1c28:      	blr	x8
    1c2c:      	add	x0, x29, #0xe8
    1c30:      	add	x2, x21, #0x158
    1c34:      	mov	w1, #0x4                // =4
    1c38:      	blr	x23
    1c3c:      	mov	w10, #0x5ea0            // =24224
    1c40:      	mov	w29, #0x50              // =80
    1c44:      	b	0xd6c <generic_retkprobe_event+0xd6c>
    1c48:      	ldr	x0, [sp, #0x20]
    1c4c:      	add	x2, x25, #0xc8
    1c50:      	mov	w8, #0x4                // =4
    1c54:      	mov	w1, #0x4                // =4
    1c58:      	mov	w21, #0x4               // =4
    1c5c:      	blr	x8
    1c60:      	ldr	x23, [sp, #0x28]
    1c64:      	add	x2, x25, #0xcc
    1c68:      	mov	w8, #0x4                // =4
    1c6c:      	mov	w1, #0x4                // =4
    1c70:      	add	x0, x23, #0xa0
    1c74:      	blr	x8
    1c78:      	add	x0, x23, #0xa4
    1c7c:      	add	x2, x25, #0xd0
    1c80:      	mov	w8, #0x4                // =4
    1c84:      	mov	w1, #0x4                // =4
    1c88:      	blr	x8
    1c8c:      	add	x0, x23, #0xa8
    1c90:      	add	x2, x25, #0x158
    1c94:      	mov	w1, #0x4                // =4
    1c98:      	blr	x21
    1c9c:      	mov	w10, #0x5ea0            // =24224
    1ca0:      	mov	w29, #0x10              // =16
    1ca4:      	b	0xd6c <generic_retkprobe_event+0xd6c>
    1ca8:      	ldr	x0, [sp, #0x20]
    1cac:      	add	x2, x25, #0x38
    1cb0:      	mov	w8, #0x4                // =4
    1cb4:      	mov	w1, #0x4                // =4
    1cb8:      	mov	x21, x22
    1cbc:      	mov	w22, #0x4               // =4
    1cc0:      	blr	x8
    1cc4:      	ldr	x23, [sp, #0x28]
    1cc8:      	add	x2, x25, #0x3c
    1ccc:      	mov	w8, #0x4                // =4
    1cd0:      	mov	w1, #0x4                // =4
    1cd4:      	add	x0, x23, #0xa0
    1cd8:      	blr	x8
    1cdc:      	add	x0, x23, #0xa4
    1ce0:      	add	x2, x25, #0x40
    1ce4:      	mov	w8, #0x4                // =4
    1ce8:      	mov	w1, #0x4                // =4
    1cec:      	blr	x8
    1cf0:      	add	x0, x23, #0xa8
    1cf4:      	add	x2, x25, #0x44
    1cf8:      	mov	w8, #0x4                // =4
    1cfc:      	mov	w1, #0x4                // =4
    1d00:      	blr	x8
    1d04:      	add	x0, x23, #0xac
    1d08:      	add	x2, x25, #0x80
    1d0c:      	mov	w8, #0x10               // =16
    1d10:      	mov	w1, #0x10               // =16
    1d14:      	blr	x22
    1d18:      	mov	x22, x21
    1d1c:      	mov	w10, #0x5ea0            // =24224
    1d20:      	mov	w29, #0x20              // =32
    1d24:      	b	0xd6c <generic_retkprobe_event+0xd6c>
    1d28:      	ldr	x0, [sp, #0x20]
    1d2c:      	mov	w8, #0x4                // =4
    1d30:      	mov	w1, #0x4                // =4
    1d34:      	mov	x2, x25
    1d38:      	mov	w21, #0x4               // =4
    1d3c:      	blr	x8
    1d40:      	ldr	x23, [sp, #0x28]
    1d44:      	add	x2, x25, #0x4
    1d48:      	mov	w8, #0x4                // =4
    1d4c:      	mov	w1, #0x4                // =4
    1d50:      	add	x0, x23, #0xa0
    1d54:      	blr	x8
    1d58:      	add	x0, x23, #0xa4
    1d5c:      	add	x2, x25, #0x30
    1d60:      	mov	w8, #0x10               // =16
    1d64:      	b	0x1de4 <generic_retkprobe_event+0x1de4>
    1d68:      	add	x2, x25, #0x4
    1d6c:      	add	x8, sp, #0x98
    1d70:      	mov	w9, #0x4                // =4
    1d74:      	add	x0, sp, #0x98
    1d78:      	mov	w1, #0x4                // =4
    1d7c:      	mov	w21, #0x4               // =4
    1d80:      	blr	x9
    1d84:      	ldr	w8, [sp, #0x98]
    1d88:      	ldr	x23, [sp, #0x28]
    1d8c:      	add	x2, x25, #0xc
    1d90:      	add	x0, sp, #0x98
    1d94:      	mov	w1, #0x4                // =4
    1d98:      	str	w8, [x23, #0x9c]
    1d9c:      	add	x8, sp, #0x98
    1da0:      	blr	x21
    1da4:      	ldr	w8, [sp, #0x98]
    1da8:      	add	x2, x25, #0x50
    1dac:      	add	x9, sp, #0x98
    1db0:      	mov	w10, #0x2d              // =45
    1db4:      	str	w8, [x23, #0xa0]
    1db8:      	mov	w8, #0x8                // =8
    1dbc:      	add	x0, sp, #0x98
    1dc0:      	mov	w1, #0x8                // =8
    1dc4:      	mov	w21, #0x2d              // =45
    1dc8:      	blr	x10
    1dcc:      	ldr	x8, [sp, #0x98]
    1dd0:      	add	x0, x23, #0xa4
    1dd4:      	mov	w9, #0x10               // =16
    1dd8:      	add	x8, x8, #0x3f8
    1ddc:      	ldr	x8, [sp, #0x98]
    1de0:      	add	x2, x8, #0x3f8
    1de4:      	mov	w1, #0x10               // =16
    1de8:      	blr	x21
    1dec:      	mov	w10, #0x5ea0            // =24224
    1df0:      	mov	w29, #0x18              // =24
    1df4:      	b	0xd6c <generic_retkprobe_event+0xd6c>
    1df8:      	ldr	x11, [sp, #0x20]
    1dfc:      	mov	w8, #0x8                // =8
    1e00:      	mov	w9, #0x4                // =4
    1e04:      	add	x10, sp, #0x98
    1e08:      	stp	xzr, xzr, [x11, #0x40]
    1e0c:      	add	x0, sp, #0x98
    1e10:      	stp	xzr, xzr, [x11, #0x30]
    1e14:      	stp	xzr, xzr, [x11, #0x20]
    1e18:      	mov	w1, #0x8                // =8
    1e1c:      	mov	x2, x25
    1e20:      	stp	xzr, xzr, [x11, #0x10]
    1e24:      	stp	xzr, xzr, [x11]
    1e28:      	blr	x9
    1e2c:      	mov	x29, xzr
    1e30:      	cbnz	x0, 0xd68 <generic_retkprobe_event+0xd68>
    1e34:      	ldr	x8, [sp, #0x28]
    1e38:      	mov	w9, #0x3f               // =63
    1e3c:      	mov	w10, #0x2d              // =45
    1e40:      	mov	w1, #0x3f               // =63
    1e44:      	mov	x23, x22
    1e48:      	add	x0, x8, #0xac
    1e4c:      	ldr	x8, [sp, #0x98]
    1e50:      	ldr	x2, [sp, #0x98]
    1e54:      	blr	x10
    1e58:      	tbnz	x0, #0x3f, 0x21d8 <generic_retkprobe_event+0x21d8>
    1e5c:      	add	x2, x25, #0x8
    1e60:      	mov	w21, #0x8               // =8
    1e64:      	add	x8, sp, #0xe8
    1e68:      	mov	w9, #0x4                // =4
    1e6c:      	add	x0, sp, #0xe8
    1e70:      	mov	w1, #0x8                // =8
    1e74:      	mov	w22, #0x4               // =4
    1e78:      	blr	x9
    1e7c:      	ldr	x8, [sp, #0x28]
    1e80:      	add	x10, sp, #0xe0
    1e84:      	mov	w9, #0x4                // =4
    1e88:      	mov	w1, #0x8                // =8
    1e8c:      	add	x0, x8, #0xa4
    1e90:      	ldr	x8, [x10, #0x8]
    1e94:      	add	x8, x8, #0x360
    1e98:      	ldr	x8, [x10, #0x8]
    1e9c:      	add	x2, x8, #0x360
    1ea0:      	blr	x9
    1ea4:      	add	x2, x25, #0x58
    1ea8:      	add	x8, sp, #0xe8
    1eac:      	add	x0, sp, #0xe8
    1eb0:      	mov	w1, #0x4                // =4
    1eb4:      	blr	x22
    1eb8:      	cbnz	x0, 0x1ed0 <generic_retkprobe_event+0x1ed0>
    1ebc:      	ldr	w8, [sp, #0xe8]
    1ec0:      	ldr	x9, [sp, #0x20]
    1ec4:      	cmp	w8, #0x0
    1ec8:      	cset	w8, ne
    1ecc:      	str	w8, [x9]
    1ed0:      	mov	w29, #0x50              // =80
    1ed4:      	mov	x22, x23
    1ed8:      	b	0xd68 <generic_retkprobe_event+0xd68>
    1edc:      	mov	x29, #-0x1              // =-1
    1ee0:      	mov	x22, x24
    1ee4:      	b	0xd68 <generic_retkprobe_event+0xd68>
    1ee8:      	add	x2, x22, #0x10
    1eec:      	mov	w21, #0x8               // =8
    1ef0:      	add	x8, sp, #0xe8
    1ef4:      	mov	w9, #0x4                // =4
    1ef8:      	add	x0, sp, #0xe8
    1efc:      	mov	w1, #0x8                // =8
    1f00:      	mov	w24, #0x4               // =4
    1f04:      	blr	x9
    1f08:      	add	x2, x22, #0x18
    1f0c:      	add	x8, sp, #0x70
    1f10:      	mov	w9, #0x4                // =4
    1f14:      	add	x0, sp, #0x70
    1f18:      	mov	w1, #0x8                // =8
    1f1c:      	blr	x9
    1f20:      	ldr	x21, [sp, #0x70]
    1f24:      	ldr	x2, [x29, #0x8]
    1f28:      	mov	w8, #0xfff              // =4095
    1f2c:      	add	x0, x23, #0xa4
    1f30:      	cmp	x21, #0xfff
    1f34:      	csel	x22, x21, x8, lo
    1f38:      	mov	w1, w22
    1f3c:      	blr	x24
    1f40:      	tbnz	w0, #0x1f, 0x1f54 <generic_retkprobe_event+0x1f54>
    1f44:      	stp	w21, w22, [x23, #0x9c]
    1f48:      	add	x29, x22, #0x8
    1f4c:      	mov	x22, x25
    1f50:      	b	0xd68 <generic_retkprobe_event+0xd68>
    1f54:      	mov	w8, #-0x2               // =-2
    1f58:      	mov	w29, #0x4               // =4
    1f5c:      	mov	x22, x25
    1f60:      	str	w8, [x23, #0x9c]
    1f64:      	b	0xd68 <generic_retkprobe_event+0xd68>
    1f68:      	str	wzr, [sp, #0xe8]
    1f6c:      	adrp	x0, 0x1000 <generic_retkprobe_event+0x1000>
    1f70:      	ldr	x23, [sp, #0x98]
    1f74:      	mov	w8, #0x1                // =1
    1f78:      	add	x9, sp, #0xe8
    1f7c:      	add	x1, sp, #0xe8
    1f80:      	ldrh	w21, [sp, #0xd8]
    1f84:      	ldr	x0, [x0]
    1f88:      	add	x22, x23, x21
    1f8c:      	blr	x8
    1f90:      	cbz	x0, 0x2774 <generic_retkprobe_event+0x2774>
    1f94:      	mov	w8, #0xff               // =255
    1f98:      	strh	w21, [x0]
    1f9c:      	strb	wzr, [x0, #0x7]
    1fa0:      	add	x29, x0, #0x6
    1fa4:      	add	x2, x22, #0x6
    1fa8:      	mov	w9, #0x4                // =4
    1fac:      	strb	w8, [x0, #0x5]
    1fb0:      	mov	w8, #0x1                // =1
    1fb4:      	mov	x25, x0
    1fb8:      	mov	x0, x29
    1fbc:      	mov	w1, #0x1                // =1
    1fc0:      	blr	x9
    1fc4:      	tbnz	x0, #0x3f, 0x2774 <generic_retkprobe_event+0x2774>
    1fc8:      	ldrb	w8, [x25, #0x5]
    1fcc:      	cmp	w8, #0x32
    1fd0:      	b.gt	0x21e4 <generic_retkprobe_event+0x21e4>
    1fd4:      	cbz	w8, 0x2204 <generic_retkprobe_event+0x2204>
    1fd8:      	cmp	w8, #0x2b
    1fdc:      	b.eq	0x2204 <generic_retkprobe_event+0x2204>
    1fe0:      	cmp	w8, #0x2c
    1fe4:      	b.ne	0x22d0 <generic_retkprobe_event+0x22d0>
    1fe8:      	mov	w8, #0x8                // =8
    1fec:      	b	0x221c <generic_retkprobe_event+0x221c>
    1ff0:      	add	x2, x22, #0x48
    1ff4:      	mov	w21, #0x10              // =16
    1ff8:      	mov	w8, #0x4                // =4
    1ffc:      	mov	w1, #0x10               // =16
    2000:      	mov	w25, #0x4               // =4
    2004:      	blr	x8
    2008:      	add	x2, x22, #0x38
    200c:      	mov	x0, x23
    2010:      	mov	w1, #0x10               // =16
    2014:      	blr	x25
    2018:      	ldr	x25, [sp, #0x28]
    201c:      	add	x2, x22, #0xe
    2020:      	mov	w21, #0x2               // =2
    2024:      	mov	w8, #0x4                // =4
    2028:      	mov	w1, #0x2                // =2
    202c:      	add	x23, x22, #0xc
    2030:      	mov	w22, #0x4               // =4
    2034:      	add	x0, x25, #0xbc
    2038:      	blr	x8
    203c:      	add	x0, x25, #0xbe
    2040:      	mov	w1, #0x2                // =2
    2044:      	mov	x2, x23
    2048:      	blr	x22
    204c:      	ldrh	w8, [x25, #0xbe]
    2050:      	adrp	x0, 0x2000 <generic_retkprobe_event+0x2000>
    2054:      	add	x9, sp, #0x98
    2058:      	add	x1, sp, #0x98
    205c:      	rev	w8, w8
    2060:      	lsr	w8, w8, #16
    2064:      	strh	w8, [x25, #0xbe]
    2068:      	ldr	x8, [x29, #0x18]
    206c:      	str	x8, [sp, #0x98]
    2070:      	mov	w8, #0x1                // =1
    2074:      	ldr	x0, [x0]
    2078:      	blr	x8
    207c:      	cbnz	x0, 0x21bc <generic_retkprobe_event+0x21bc>
    2080:      	b	0x28ec <generic_retkprobe_event+0x28ec>
    2084:      	stur	xzr, [x23, #0x9c]
    2088:      	mov	w29, #0x8               // =8
    208c:      	mov	x22, x25
    2090:      	b	0xd68 <generic_retkprobe_event+0xd68>
    2094:      	mov	w21, #-0x2              // =-2
    2098:      	ldr	x22, [sp, #0x10]
    209c:      	str	w21, [x23, #0x9c]
    20a0:      	b	0xd68 <generic_retkprobe_event+0xd68>
    20a4:      	ldr	x24, [sp, #0x28]
    20a8:      	add	x2, x22, #0x8
    20ac:      	mov	w8, #0x10               // =16
    20b0:      	mov	w9, #0x4                // =4
    20b4:      	mov	w1, #0x10               // =16
    20b8:      	mov	w21, #0x4               // =4
    20bc:      	add	x0, x24, #0xa4
    20c0:      	blr	x9
    20c4:      	add	x0, x24, #0x9e
    20c8:      	add	x2, x22, #0x2
    20cc:      	mov	w8, #0x2                // =2
    20d0:      	mov	w1, #0x2                // =2
    20d4:      	blr	x21
    20d8:      	ldr	x9, [sp, #0x28]
    20dc:      	ldrh	w8, [x9, #0x9e]
    20e0:      	rev	w8, w8
    20e4:      	lsr	w8, w8, #16
    20e8:      	strh	w8, [x9, #0x9e]
    20ec:      	mov	w29, #0x18              // =24
    20f0:      	mov	x22, x23
    20f4:      	b	0xd68 <generic_retkprobe_event+0xd68>
    20f8:      	add	x2, x22, #0x3
    20fc:      	mov	w21, #0x6b              // =107
    2100:      	mov	w8, #0x71               // =113
    2104:      	mov	w1, #0x6b               // =107
    2108:      	blr	x8
    210c:      	tbnz	w0, #0x1f, 0x2118 <generic_retkprobe_event+0x2118>
    2110:      	ldr	x8, [sp, #0x28]
    2114:      	strb	w21, [x8, #0x9f]
    2118:      	mov	w29, #0x70              // =112
    211c:      	mov	x22, x24
    2120:      	b	0xd68 <generic_retkprobe_event+0xd68>
    2124:      	ldr	x0, [sp, #0x20]
    2128:      	add	x2, x22, #0x48
    212c:      	mov	w21, #0x10              // =16
    2130:      	mov	w8, #0x4                // =4
    2134:      	mov	w1, #0x10               // =16
    2138:      	mov	w25, #0x4               // =4
    213c:      	blr	x8
    2140:      	add	x2, x22, #0x38
    2144:      	mov	x0, x23
    2148:      	mov	w1, #0x10               // =16
    214c:      	blr	x25
    2150:      	ldr	x25, [sp, #0x28]
    2154:      	add	x2, x22, #0xe
    2158:      	mov	w21, #0x2               // =2
    215c:      	mov	w8, #0x4                // =4
    2160:      	mov	w1, #0x2                // =2
    2164:      	add	x23, x22, #0xc
    2168:      	mov	w22, #0x4               // =4
    216c:      	add	x0, x25, #0xbc
    2170:      	blr	x8
    2174:      	add	x0, x25, #0xbe
    2178:      	mov	w1, #0x2                // =2
    217c:      	mov	x2, x23
    2180:      	blr	x22
    2184:      	ldrh	w8, [x25, #0xbe]
    2188:      	rev	w8, w8
    218c:      	lsr	w8, w8, #16
    2190:      	strh	w8, [x25, #0xbe]
    2194:      	ldr	x8, [sp, #0x28]
    2198:      	adrp	x0, 0x2000 <generic_retkprobe_event+0x2000>
    219c:      	add	x9, sp, #0x98
    21a0:      	add	x1, sp, #0x98
    21a4:      	ldur	x8, [x8, #0xc4]
    21a8:      	str	x8, [sp, #0x98]
    21ac:      	mov	w8, #0x1                // =1
    21b0:      	ldr	x0, [x0]
    21b4:      	blr	x8
    21b8:      	cbz	x0, 0x28ec <generic_retkprobe_event+0x28ec>
    21bc:      	ldr	w8, [x0]
    21c0:      	str	w8, [x24, #0x10]
    21c4:      	ldr	x8, [x0, #0x8]
    21c8:      	str	x8, [x24, #0x18]
    21cc:      	ldr	w8, [x0, #0x4]
    21d0:      	str	w8, [x24, #0x7c]
    21d4:      	b	0x28ec <generic_retkprobe_event+0x28ec>
    21d8:      	mov	x29, xzr
    21dc:      	mov	x22, x23
    21e0:      	b	0xd68 <generic_retkprobe_event+0xd68>
    21e4:      	cmp	w8, #0x33
    21e8:      	b.eq	0x2210 <generic_retkprobe_event+0x2210>
    21ec:      	cmp	w8, #0x3c
    21f0:      	b.eq	0x2204 <generic_retkprobe_event+0x2204>
    21f4:      	cmp	w8, #0xff
    21f8:      	b.ne	0x22d0 <generic_retkprobe_event+0x22d0>
    21fc:      	mov	w8, #0x28               // =40
    2200:      	b	0x221c <generic_retkprobe_event+0x221c>
    2204:      	ldrb	w8, [x25, #0x7]
    2208:      	lsl	w8, w8, #3
    220c:      	b	0x2218 <generic_retkprobe_event+0x2218>
    2210:      	ldrb	w8, [x25, #0x7]
    2214:      	lsl	w8, w8, #2
    2218:      	add	w8, w8, #0x8
    221c:      	strh	w8, [x25, #0x2]
    2220:      	ldrh	w9, [x25]
    2224:      	add	w9, w9, w8
    2228:      	ldrb	w8, [x25, #0x6]
    222c:      	strh	w9, [x25]
    2230:      	cmp	w8, #0x3c
    2234:      	b.hi	0x22ec <generic_retkprobe_event+0x22ec>
    2238:      	mov	x21, #0x1               // =1
    223c:      	mov	w10, #0x1               // =1
    2240:      	movk	x21, #0x1800, lsl #32
    2244:      	lsl	x10, x10, x8
    2248:      	movk	x21, #0x1008, lsl #48
    224c:      	tst	x10, x21
    2250:      	b.eq	0x22ec <generic_retkprobe_event+0x22ec>
    2254:      	strb	w8, [x25, #0x5]
    2258:      	add	x8, x23, w9, uxth
    225c:      	mov	w9, #0x2                // =2
    2260:      	mov	w10, #0x4               // =4
    2264:      	mov	x0, x29
    2268:      	mov	w1, #0x2                // =2
    226c:      	ldrh	w8, [x25]
    2270:      	add	x2, x23, x8
    2274:      	blr	x10
    2278:      	tbnz	x0, #0x3f, 0x2774 <generic_retkprobe_event+0x2774>
    227c:      	ldrb	w8, [x25, #0x5]
    2280:      	cmp	w8, #0x32
    2284:      	b.gt	0x22a4 <generic_retkprobe_event+0x22a4>
    2288:      	cbz	w8, 0x22c4 <generic_retkprobe_event+0x22c4>
    228c:      	cmp	w8, #0x2b
    2290:      	b.eq	0x22c4 <generic_retkprobe_event+0x22c4>
    2294:      	cmp	w8, #0x2c
    2298:      	b.ne	0x23a8 <generic_retkprobe_event+0x23a8>
    229c:      	mov	w8, #0x8                // =8
    22a0:      	b	0x2300 <generic_retkprobe_event+0x2300>
    22a4:      	cmp	w8, #0x33
    22a8:      	b.eq	0x22f4 <generic_retkprobe_event+0x22f4>
    22ac:      	cmp	w8, #0x3c
    22b0:      	b.eq	0x22c4 <generic_retkprobe_event+0x22c4>
    22b4:      	cmp	w8, #0xff
    22b8:      	b.ne	0x23a8 <generic_retkprobe_event+0x23a8>
    22bc:      	mov	w8, #0x28               // =40
    22c0:      	b	0x2300 <generic_retkprobe_event+0x2300>
    22c4:      	ldrb	w8, [x25, #0x7]
    22c8:      	lsl	w8, w8, #3
    22cc:      	b	0x22fc <generic_retkprobe_event+0x22fc>
    22d0:      	ldrh	w8, [x25, #0x2]
    22d4:      	ldrh	w9, [x25]
    22d8:      	add	w9, w9, w8
    22dc:      	ldrb	w8, [x25, #0x6]
    22e0:      	strh	w9, [x25]
    22e4:      	cmp	w8, #0x3c
    22e8:      	b.ls	0x2238 <generic_retkprobe_event+0x2238>
    22ec:      	strh	w9, [sp, #0x90]
    22f0:      	b	0x2778 <generic_retkprobe_event+0x2778>
    22f4:      	ldrb	w8, [x25, #0x7]
    22f8:      	lsl	w8, w8, #2
    22fc:      	add	w8, w8, #0x8
    2300:      	strh	w8, [x25, #0x2]
    2304:      	ldrh	w9, [x25]
    2308:      	add	w9, w9, w8
    230c:      	ldrb	w8, [x25, #0x6]
    2310:      	strh	w9, [x25]
    2314:      	cmp	w8, #0x3c
    2318:      	b.hi	0x2914 <generic_retkprobe_event+0x2914>
    231c:      	mov	w10, #0x1               // =1
    2320:      	lsl	x10, x10, x8
    2324:      	tst	x10, x21
    2328:      	b.eq	0x2914 <generic_retkprobe_event+0x2914>
    232c:      	strb	w8, [x25, #0x5]
    2330:      	add	x8, x23, w9, uxth
    2334:      	mov	w9, #0x2                // =2
    2338:      	mov	w10, #0x4               // =4
    233c:      	mov	x0, x29
    2340:      	mov	w1, #0x2                // =2
    2344:      	ldrh	w8, [x25]
    2348:      	add	x2, x23, x8
    234c:      	blr	x10
    2350:      	tbnz	x0, #0x3f, 0x2774 <generic_retkprobe_event+0x2774>
    2354:      	ldrb	w8, [x25, #0x5]
    2358:      	cmp	w8, #0x32
    235c:      	b.gt	0x237c <generic_retkprobe_event+0x237c>
    2360:      	cbz	w8, 0x239c <generic_retkprobe_event+0x239c>
    2364:      	cmp	w8, #0x2b
    2368:      	b.eq	0x239c <generic_retkprobe_event+0x239c>
    236c:      	cmp	w8, #0x2c
    2370:      	b.ne	0x247c <generic_retkprobe_event+0x247c>
    2374:      	mov	w8, #0x8                // =8
    2378:      	b	0x23d4 <generic_retkprobe_event+0x23d4>
    237c:      	cmp	w8, #0x33
    2380:      	b.eq	0x23c8 <generic_retkprobe_event+0x23c8>
    2384:      	cmp	w8, #0x3c
    2388:      	b.eq	0x239c <generic_retkprobe_event+0x239c>
    238c:      	cmp	w8, #0xff
    2390:      	b.ne	0x247c <generic_retkprobe_event+0x247c>
    2394:      	mov	w8, #0x28               // =40
    2398:      	b	0x23d4 <generic_retkprobe_event+0x23d4>
    239c:      	ldrb	w8, [x25, #0x7]
    23a0:      	lsl	w8, w8, #3
    23a4:      	b	0x23d0 <generic_retkprobe_event+0x23d0>
    23a8:      	ldrh	w8, [x25, #0x2]
    23ac:      	ldrh	w9, [x25]
    23b0:      	add	w9, w9, w8
    23b4:      	ldrb	w8, [x25, #0x6]
    23b8:      	strh	w9, [x25]
    23bc:      	cmp	w8, #0x3c
    23c0:      	b.ls	0x231c <generic_retkprobe_event+0x231c>
    23c4:      	b	0x2914 <generic_retkprobe_event+0x2914>
    23c8:      	ldrb	w8, [x25, #0x7]
    23cc:      	lsl	w8, w8, #2
    23d0:      	add	w8, w8, #0x8
    23d4:      	strh	w8, [x25, #0x2]
    23d8:      	ldrh	w9, [x25]
    23dc:      	add	w9, w9, w8
    23e0:      	ldrb	w8, [x25, #0x6]
    23e4:      	strh	w9, [x25]
    23e8:      	cmp	w8, #0x3c
    23ec:      	b.hi	0x2914 <generic_retkprobe_event+0x2914>
    23f0:      	mov	w10, #0x1               // =1
    23f4:      	lsl	x10, x10, x8
    23f8:      	tst	x10, x21
    23fc:      	b.eq	0x2914 <generic_retkprobe_event+0x2914>
    2400:      	strb	w8, [x25, #0x5]
    2404:      	add	x8, x23, w9, uxth
    2408:      	mov	w9, #0x2                // =2
    240c:      	mov	w10, #0x4               // =4
    2410:      	mov	x0, x29
    2414:      	mov	w1, #0x2                // =2
    2418:      	ldrh	w8, [x25]
    241c:      	add	x2, x23, x8
    2420:      	blr	x10
    2424:      	tbnz	x0, #0x3f, 0x2774 <generic_retkprobe_event+0x2774>
    2428:      	ldrb	w8, [x25, #0x5]
    242c:      	cmp	w8, #0x32
    2430:      	b.gt	0x2450 <generic_retkprobe_event+0x2450>
    2434:      	cbz	w8, 0x2470 <generic_retkprobe_event+0x2470>
    2438:      	cmp	w8, #0x2b
    243c:      	b.eq	0x2470 <generic_retkprobe_event+0x2470>
    2440:      	cmp	w8, #0x2c
    2444:      	b.ne	0x2550 <generic_retkprobe_event+0x2550>
    2448:      	mov	w8, #0x8                // =8
    244c:      	b	0x24a8 <generic_retkprobe_event+0x24a8>
    2450:      	cmp	w8, #0x33
    2454:      	b.eq	0x249c <generic_retkprobe_event+0x249c>
    2458:      	cmp	w8, #0x3c
    245c:      	b.eq	0x2470 <generic_retkprobe_event+0x2470>
    2460:      	cmp	w8, #0xff
    2464:      	b.ne	0x2550 <generic_retkprobe_event+0x2550>
    2468:      	mov	w8, #0x28               // =40
    246c:      	b	0x24a8 <generic_retkprobe_event+0x24a8>
    2470:      	ldrb	w8, [x25, #0x7]
    2474:      	lsl	w8, w8, #3
    2478:      	b	0x24a4 <generic_retkprobe_event+0x24a4>
    247c:      	ldrh	w8, [x25, #0x2]
    2480:      	ldrh	w9, [x25]
    2484:      	add	w9, w9, w8
    2488:      	ldrb	w8, [x25, #0x6]
    248c:      	strh	w9, [x25]
    2490:      	cmp	w8, #0x3c
    2494:      	b.ls	0x23f0 <generic_retkprobe_event+0x23f0>
    2498:      	b	0x2914 <generic_retkprobe_event+0x2914>
    249c:      	ldrb	w8, [x25, #0x7]
    24a0:      	lsl	w8, w8, #2
    24a4:      	add	w8, w8, #0x8
    24a8:      	strh	w8, [x25, #0x2]
    24ac:      	ldrh	w9, [x25]
    24b0:      	add	w9, w9, w8
    24b4:      	ldrb	w8, [x25, #0x6]
    24b8:      	strh	w9, [x25]
    24bc:      	cmp	w8, #0x3c
    24c0:      	b.hi	0x2914 <generic_retkprobe_event+0x2914>
    24c4:      	mov	w10, #0x1               // =1
    24c8:      	lsl	x10, x10, x8
    24cc:      	tst	x10, x21
    24d0:      	b.eq	0x2914 <generic_retkprobe_event+0x2914>
    24d4:      	strb	w8, [x25, #0x5]
    24d8:      	add	x8, x23, w9, uxth
    24dc:      	mov	w9, #0x2                // =2
    24e0:      	mov	w10, #0x4               // =4
    24e4:      	mov	x0, x29
    24e8:      	mov	w1, #0x2                // =2
    24ec:      	ldrh	w8, [x25]
    24f0:      	add	x2, x23, x8
    24f4:      	blr	x10
    24f8:      	tbnz	x0, #0x3f, 0x2774 <generic_retkprobe_event+0x2774>
    24fc:      	ldrb	w8, [x25, #0x5]
    2500:      	cmp	w8, #0x32
    2504:      	b.gt	0x2524 <generic_retkprobe_event+0x2524>
    2508:      	cbz	w8, 0x2544 <generic_retkprobe_event+0x2544>
    250c:      	cmp	w8, #0x2b
    2510:      	b.eq	0x2544 <generic_retkprobe_event+0x2544>
    2514:      	cmp	w8, #0x2c
    2518:      	b.ne	0x2624 <generic_retkprobe_event+0x2624>
    251c:      	mov	w8, #0x8                // =8
    2520:      	b	0x257c <generic_retkprobe_event+0x257c>
    2524:      	cmp	w8, #0x33
    2528:      	b.eq	0x2570 <generic_retkprobe_event+0x2570>
    252c:      	cmp	w8, #0x3c
    2530:      	b.eq	0x2544 <generic_retkprobe_event+0x2544>
    2534:      	cmp	w8, #0xff
    2538:      	b.ne	0x2624 <generic_retkprobe_event+0x2624>
    253c:      	mov	w8, #0x28               // =40
    2540:      	b	0x257c <generic_retkprobe_event+0x257c>
    2544:      	ldrb	w8, [x25, #0x7]
    2548:      	lsl	w8, w8, #3
    254c:      	b	0x2578 <generic_retkprobe_event+0x2578>
    2550:      	ldrh	w8, [x25, #0x2]
    2554:      	ldrh	w9, [x25]
    2558:      	add	w9, w9, w8
    255c:      	ldrb	w8, [x25, #0x6]
    2560:      	strh	w9, [x25]
    2564:      	cmp	w8, #0x3c
    2568:      	b.ls	0x24c4 <generic_retkprobe_event+0x24c4>
    256c:      	b	0x2914 <generic_retkprobe_event+0x2914>
    2570:      	ldrb	w8, [x25, #0x7]
    2574:      	lsl	w8, w8, #2
    2578:      	add	w8, w8, #0x8
    257c:      	strh	w8, [x25, #0x2]
    2580:      	ldrh	w9, [x25]
    2584:      	add	w9, w9, w8
    2588:      	ldrb	w8, [x25, #0x6]
    258c:      	strh	w9, [x25]
    2590:      	cmp	w8, #0x3c
    2594:      	b.hi	0x2914 <generic_retkprobe_event+0x2914>
    2598:      	mov	w10, #0x1               // =1
    259c:      	lsl	x10, x10, x8
    25a0:      	tst	x10, x21
    25a4:      	b.eq	0x2914 <generic_retkprobe_event+0x2914>
    25a8:      	strb	w8, [x25, #0x5]
    25ac:      	add	x8, x23, w9, uxth
    25b0:      	mov	w9, #0x2                // =2
    25b4:      	mov	w10, #0x4               // =4
    25b8:      	mov	x0, x29
    25bc:      	mov	w1, #0x2                // =2
    25c0:      	ldrh	w8, [x25]
    25c4:      	add	x2, x23, x8
    25c8:      	blr	x10
    25cc:      	tbnz	x0, #0x3f, 0x2774 <generic_retkprobe_event+0x2774>
    25d0:      	ldrb	w8, [x25, #0x5]
    25d4:      	cmp	w8, #0x32
    25d8:      	b.gt	0x25f8 <generic_retkprobe_event+0x25f8>
    25dc:      	cbz	w8, 0x2618 <generic_retkprobe_event+0x2618>
    25e0:      	cmp	w8, #0x2b
    25e4:      	b.eq	0x2618 <generic_retkprobe_event+0x2618>
    25e8:      	cmp	w8, #0x2c
    25ec:      	b.ne	0x26f8 <generic_retkprobe_event+0x26f8>
    25f0:      	mov	w8, #0x8                // =8
    25f4:      	b	0x2650 <generic_retkprobe_event+0x2650>
    25f8:      	cmp	w8, #0x33
    25fc:      	b.eq	0x2644 <generic_retkprobe_event+0x2644>
    2600:      	cmp	w8, #0x3c
    2604:      	b.eq	0x2618 <generic_retkprobe_event+0x2618>
    2608:      	cmp	w8, #0xff
    260c:      	b.ne	0x26f8 <generic_retkprobe_event+0x26f8>
    2610:      	mov	w8, #0x28               // =40
    2614:      	b	0x2650 <generic_retkprobe_event+0x2650>
    2618:      	ldrb	w8, [x25, #0x7]
    261c:      	lsl	w8, w8, #3
    2620:      	b	0x264c <generic_retkprobe_event+0x264c>
    2624:      	ldrh	w8, [x25, #0x2]
    2628:      	ldrh	w9, [x25]
    262c:      	add	w9, w9, w8
    2630:      	ldrb	w8, [x25, #0x6]
    2634:      	strh	w9, [x25]
    2638:      	cmp	w8, #0x3c
    263c:      	b.ls	0x2598 <generic_retkprobe_event+0x2598>
    2640:      	b	0x2914 <generic_retkprobe_event+0x2914>
    2644:      	ldrb	w8, [x25, #0x7]
    2648:      	lsl	w8, w8, #2
    264c:      	add	w8, w8, #0x8
    2650:      	strh	w8, [x25, #0x2]
    2654:      	ldrh	w9, [x25]
    2658:      	add	w9, w9, w8
    265c:      	ldrb	w8, [x25, #0x6]
    2660:      	strh	w9, [x25]
    2664:      	cmp	w8, #0x3c
    2668:      	b.hi	0x2914 <generic_retkprobe_event+0x2914>
    266c:      	mov	w10, #0x1               // =1
    2670:      	lsl	x10, x10, x8
    2674:      	tst	x10, x21
    2678:      	b.eq	0x2914 <generic_retkprobe_event+0x2914>
    267c:      	strb	w8, [x25, #0x5]
    2680:      	add	x8, x23, w9, uxth
    2684:      	mov	w9, #0x2                // =2
    2688:      	mov	w10, #0x4               // =4
    268c:      	mov	x0, x29
    2690:      	mov	w1, #0x2                // =2
    2694:      	ldrh	w8, [x25]
    2698:      	add	x2, x23, x8
    269c:      	blr	x10
    26a0:      	tbnz	x0, #0x3f, 0x2774 <generic_retkprobe_event+0x2774>
    26a4:      	ldrb	w8, [x25, #0x5]
    26a8:      	cmp	w8, #0x32
    26ac:      	b.gt	0x26cc <generic_retkprobe_event+0x26cc>
    26b0:      	cbz	w8, 0x26ec <generic_retkprobe_event+0x26ec>
    26b4:      	cmp	w8, #0x2b
    26b8:      	b.eq	0x26ec <generic_retkprobe_event+0x26ec>
    26bc:      	cmp	w8, #0x2c
    26c0:      	b.ne	0x28f8 <generic_retkprobe_event+0x28f8>
    26c4:      	mov	w8, #0x8                // =8
    26c8:      	b	0x2724 <generic_retkprobe_event+0x2724>
    26cc:      	cmp	w8, #0x33
    26d0:      	b.eq	0x2718 <generic_retkprobe_event+0x2718>
    26d4:      	cmp	w8, #0x3c
    26d8:      	b.eq	0x26ec <generic_retkprobe_event+0x26ec>
    26dc:      	cmp	w8, #0xff
    26e0:      	b.ne	0x28f8 <generic_retkprobe_event+0x28f8>
    26e4:      	mov	w8, #0x28               // =40
    26e8:      	b	0x2724 <generic_retkprobe_event+0x2724>
    26ec:      	ldrb	w8, [x25, #0x7]
    26f0:      	lsl	w8, w8, #3
    26f4:      	b	0x2720 <generic_retkprobe_event+0x2720>
    26f8:      	ldrh	w8, [x25, #0x2]
    26fc:      	ldrh	w9, [x25]
    2700:      	add	w9, w9, w8
    2704:      	ldrb	w8, [x25, #0x6]
    2708:      	strh	w9, [x25]
    270c:      	cmp	w8, #0x3c
    2710:      	b.ls	0x266c <generic_retkprobe_event+0x266c>
    2714:      	b	0x2914 <generic_retkprobe_event+0x2914>
    2718:      	ldrb	w8, [x25, #0x7]
    271c:      	lsl	w8, w8, #2
    2720:      	add	w8, w8, #0x8
    2724:      	strh	w8, [x25, #0x2]
    2728:      	ldrh	w9, [x25]
    272c:      	add	w9, w9, w8
    2730:      	ldrb	w8, [x25, #0x6]
    2734:      	strh	w9, [x25]
    2738:      	cmp	w8, #0x3c
    273c:      	b.hi	0x2914 <generic_retkprobe_event+0x2914>
    2740:      	mov	w10, #0x1               // =1
    2744:      	lsl	x10, x10, x8
    2748:      	tst	x10, x21
    274c:      	b.eq	0x2914 <generic_retkprobe_event+0x2914>
    2750:      	strb	w8, [x25, #0x5]
    2754:      	add	x8, x23, w9, uxth
    2758:      	mov	w9, #0x2                // =2
    275c:      	mov	w10, #0x4               // =4
    2760:      	mov	x0, x29
    2764:      	mov	w1, #0x2                // =2
    2768:      	ldrh	w8, [x25]
    276c:      	add	x2, x23, x8
    2770:      	blr	x10
    2774:      	mov	w8, wzr
    2778:      	ldp	x0, x25, [sp, #0x20]
    277c:      	add	x2, x22, #0x8
    2780:      	mov	w21, #0x10              // =16
    2784:      	mov	w1, #0x10               // =16
    2788:      	mov	w23, #0x4               // =4
    278c:      	strb	w8, [sp, #0x88]
    2790:      	strh	w8, [x25, #0xc0]
    2794:      	mov	w8, #0xa                // =10
    2798:      	strh	w8, [x25, #0xc2]
    279c:      	mov	w8, #0x4                // =4
    27a0:      	blr	x8
    27a4:      	add	x0, x25, #0xac
    27a8:      	add	x2, x22, #0x18
    27ac:      	mov	w1, #0x10               // =16
    27b0:      	blr	x23
    27b4:      	ldrb	w8, [sp, #0x88]
    27b8:      	cmp	w8, #0x11
    27bc:      	b.eq	0x2800 <generic_retkprobe_event+0x2800>
    27c0:      	cmp	w8, #0x6
    27c4:      	b.ne	0x2840 <generic_retkprobe_event+0x2840>
    27c8:      	ldr	x8, [sp, #0x98]
    27cc:      	ldrh	w9, [sp, #0x90]
    27d0:      	mov	w21, #0x2               // =2
    27d4:      	mov	w1, #0x2                // =2
    27d8:      	mov	w23, #0x4               // =4
    27dc:      	add	x22, x8, x9
    27e0:      	ldr	x25, [sp, #0x28]
    27e4:      	add	x0, x25, #0xbc
    27e8:      	mov	w8, #0x4                // =4
    27ec:      	mov	x2, x22
    27f0:      	blr	x8
    27f4:      	add	x0, x25, #0xbe
    27f8:      	add	x2, x22, #0x2
    27fc:      	b	0x2834 <generic_retkprobe_event+0x2834>
    2800:      	ldr	x8, [sp, #0x98]
    2804:      	ldrh	w9, [sp, #0x90]
    2808:      	mov	w21, #0x2               // =2
    280c:      	mov	w1, #0x2                // =2
    2810:      	mov	w23, #0x4               // =4
    2814:      	add	x22, x8, x9
    2818:      	ldr	x25, [sp, #0x28]
    281c:      	add	x0, x25, #0xbc
    2820:      	mov	w8, #0x4                // =4
    2824:      	mov	x2, x22
    2828:      	blr	x8
    282c:      	add	x0, x25, #0xbe
    2830:      	add	x2, x22, #0x2
    2834:      	mov	w1, #0x2                // =2
    2838:      	blr	x23
    283c:      	b	0x2848 <generic_retkprobe_event+0x2848>
    2840:      	ldr	x25, [sp, #0x28]
    2844:      	str	wzr, [x25, #0xbc]
    2848:      	ldrh	w8, [x25, #0xbc]
    284c:      	add	x2, x24, #0xe0
    2850:      	mov	w9, #0x4                // =4
    2854:      	add	x10, sp, #0xe8
    2858:      	add	x0, sp, #0xe8
    285c:      	mov	w1, #0x8                // =8
    2860:      	rev	w8, w8
    2864:      	lsr	w8, w8, #16
    2868:      	strh	w8, [x25, #0xbc]
    286c:      	ldrh	w8, [x25, #0xbe]
    2870:      	rev	w8, w8
    2874:      	lsr	w8, w8, #16
    2878:      	strh	w8, [x25, #0xbe]
    287c:      	mov	w8, #0x8                // =8
    2880:      	blr	x9
    2884:      	add	x22, sp, #0xe0
    2888:      	ldr	x8, [x22, #0x8]
    288c:      	cbz	x8, 0x28ec <generic_retkprobe_event+0x28ec>
    2890:      	add	x8, x8, #0x5
    2894:      	mov	w9, #0x8                // =8
    2898:      	add	x10, sp, #0x70
    289c:      	mov	w11, #0x4               // =4
    28a0:      	ldr	x8, [x22, #0x8]
    28a4:      	add	x0, sp, #0x70
    28a8:      	mov	w1, #0x8                // =8
    28ac:      	mov	w21, #0x4               // =4
    28b0:      	add	x2, x8, #0x5
    28b4:      	blr	x11
    28b8:      	ldr	x8, [x22, #0x8]
    28bc:      	ldr	x9, [sp, #0x70]
    28c0:      	mov	w1, #0x4                // =4
    28c4:      	add	x22, x8, x9, lsl #3
    28c8:      	ldr	x23, [sp, #0x28]
    28cc:      	add	x0, x23, #0xd4
    28d0:      	mov	w8, #0x4                // =4
    28d4:      	add	x2, x22, #0x44
    28d8:      	blr	x8
    28dc:      	add	x0, x23, #0xd8
    28e0:      	add	x2, x22, #0x45
    28e4:      	mov	w1, #0x4                // =4
    28e8:      	blr	x21
    28ec:      	ldr	x22, [sp, #0x10]
    28f0:      	mov	w29, #0x40              // =64
    28f4:      	b	0xd68 <generic_retkprobe_event+0xd68>
    28f8:      	ldrh	w8, [x25, #0x2]
    28fc:      	ldrh	w9, [x25]
    2900:      	add	w9, w9, w8
    2904:      	ldrb	w8, [x25, #0x6]
    2908:      	strh	w9, [x25]
    290c:      	cmp	w8, #0x3c
    2910:      	b.ls	0x2740 <generic_retkprobe_event+0x2740>
    2914:      	strh	w9, [sp, #0x90]
    2918:      	b	0x2778 <generic_retkprobe_event+0x2778>
