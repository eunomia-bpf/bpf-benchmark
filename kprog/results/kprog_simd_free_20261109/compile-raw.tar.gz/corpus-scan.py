from pathlib import Path
import collections,concurrent.futures,hashlib,json,re,subprocess
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S14')
paths=sorted((R/'vendor/build/native-bpf').glob('*/stage/**/*.native.o'))
paths+=sorted((R/'vendor/build/native-bpf').glob('*/*/native/**/*.native.o'))
pattern=re.compile(r'\b(?:[xyz]mm\d+|mm[0-7]|st\([0-7]\)|[vqdsbh](?:[12]?\d|3[01])(?:\.[0-9]*[bhsd])?)\b',re.I)
def check(p):
 arch='arm64' if 'arm64' in p.relative_to(R).parts else 'x86'
 text=subprocess.check_output(['llvm-objdump-18','-d','--no-show-raw-insn',str(p)],text=True)
 # Match operands on disassembled instruction lines, leaving symbols and labels alone.
 hits=[s for s in text.splitlines() if re.match(r'^\s*[0-9a-f]+:\s',s) and pattern.search(s.split(':', 1)[1])]
 return dict(path=str(p.relative_to(R)),arch=arch,app=p.parent.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),simd_fp_lines=hits)
with concurrent.futures.ThreadPoolExecutor(4) as pool: rows=list(pool.map(check,paths))
summary=dict(objects=len(rows),by_arch_app=dict(collections.Counter(x['arch']+'/'+x['app'] for x in rows)),simd_objects=sum(bool(x['simd_fp_lines']) for x in rows),rows=rows)
(O/'corpus-object-census.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='rows'},indent=2),flush=True)
