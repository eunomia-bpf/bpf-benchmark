from pathlib import Path
import concurrent.futures,hashlib,json,subprocess
from elftools.elf.elffile import ELFFile
O=Path('/var/tmp/kprog-tmp/S14');paths=sorted((O/'corpus-final').glob('*/*/native/**/*.native.o'))
def export(p):
 rel=p.relative_to(O/'corpus-final');dst=O/'export/corpus'/rel;dst.parent.mkdir(parents=True,exist_ok=True)
 subprocess.run(['llvm-objcopy-18','--strip-debug',str(p),str(dst)],check=True)
 inputs=[]
 with p.open('rb') as f:
  elf=ELFFile(f);sections=[dict(name=s.name,bytes=s['sh_size'],sha256=hashlib.sha256(s.data()).hexdigest()) for s in elf.iter_sections() if s['sh_flags']&4]
  dwarf=elf.get_dwarf_info()
  for unit in dwarf.iter_CUs():
   line=dwarf.line_program_for_CU(unit)
   if line:
    for entry in line.header.file_entry:
     raw=entry.get('MD5');name=entry.name.decode(errors='replace')
     inputs.append(dict(name=name,directory=entry.dir_index,md5=raw.hex() if isinstance(raw,bytes) else str(raw)))
 listing=subprocess.check_output(['llvm-objdump-18','-d','--no-show-raw-insn',str(dst)],text=True);dst.with_suffix('.asm').write_text(listing)
 return dict(original=str(p.relative_to(O)),original_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),export=str(dst.relative_to(O/'export')),export_sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),executable_sections=sections,source_line_checksums=inputs)
with concurrent.futures.ThreadPoolExecutor(4) as pool:rows=list(pool.map(export,paths))
(O/'corpus-export.json').write_text(json.dumps(rows,indent=2)+'\n');print('exported native corpus objects',len(rows),flush=True)
