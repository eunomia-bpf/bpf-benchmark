/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/tetragon_process_event_arg_filter.native.so: \
  tetragon_process_event_arg_filter.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h:
