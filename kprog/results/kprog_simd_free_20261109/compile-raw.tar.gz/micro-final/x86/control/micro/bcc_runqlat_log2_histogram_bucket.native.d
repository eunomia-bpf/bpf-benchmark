/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/bcc_runqlat_log2_histogram_bucket.native.so: \
  bcc_runqlat_log2_histogram_bucket.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h:
