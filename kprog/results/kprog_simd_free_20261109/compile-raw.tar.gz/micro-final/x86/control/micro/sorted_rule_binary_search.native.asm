
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/sorted_rule_binary_search.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <sorted_rule_binary_search_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rsi
       7:      	movq	%rcx, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rsi, %rdx
       f:      	jbe	0x12 <sorted_rule_binary_search_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rdx), %rdi
      16:      	cmpq	%rsi, %rdi
      19:      	ja	0x11 <sorted_rule_binary_search_xdp+0x11>
      1b:      	leaq	0x190(%rdx), %rdi
      22:      	cmpq	%rsi, %rdi
      25:      	ja	0x11 <sorted_rule_binary_search_xdp+0x11>
      27:      	cmpl	$0x20, 0x8(%rdx)
      2b:      	jne	0x11 <sorted_rule_binary_search_xdp+0x11>
      2d:      	cmpl	$0x10, 0xc(%rdx)
      31:      	jne	0x11 <sorted_rule_binary_search_xdp+0x11>
      33:      	pushq	%rbx
      34:      	xorl	%eax, %eax
      36:      	xorl	%esi, %esi
      38:      	nopl	(%rax,%rax)
      40:      	movq	0x110(%rdx,%rax,8), %rdi
      48:      	xorl	%r9d, %r9d
      4b:      	xorl	%r8d, %r8d
      4e:      	xorl	%r10d, %r10d
      51:      	nopw	%cs:(%rax,%rax)
      60:      	cmpq	%rdi, 0x10(%rdx,%r9,8)
      65:      	sete	%r11b
      69:      	movq	%r8, %rbx
      6c:      	cmoveq	%r9, %rbx
      70:      	orb	%r10b, %r11b
      73:      	testb	$0x1, %r10b
      77:      	cmovneq	%r8, %rbx
      7b:      	leaq	0x1(%r9), %r8
      7f:      	cmpq	%rdi, 0x18(%rdx,%r9,8)
      84:      	sete	%r10b
      88:      	cmovneq	%rbx, %r8
      8c:      	orb	%r11b, %r10b
      8f:      	testb	$0x1, %r11b
      93:      	cmovneq	%rbx, %r8
      97:      	addq	$0x2, %r9
      9b:      	cmpq	$0x20, %r9
      9f:      	jne	0x60 <sorted_rule_binary_search_xdp+0x60>
      a1:      	addq	%rsi, %r8
      a4:      	addq	$0x20, %rdi
      a8:      	xorq	%rdi, %rsi
      ab:      	testb	$0x1, %r10b
      af:      	cmovneq	%r8, %rsi
      b3:      	incq	%rax
      b6:      	cmpq	$0x10, %rax
      ba:      	jne	0x40 <sorted_rule_binary_search_xdp+0x40>
      bc:      	movq	%rsi, (%rcx)
      bf:      	movl	$0x2, %eax
      c4:      	popq	%rbx
      c5:      	retq
