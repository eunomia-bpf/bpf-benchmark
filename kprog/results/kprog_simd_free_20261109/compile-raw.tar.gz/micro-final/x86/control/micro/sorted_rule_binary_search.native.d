/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/sorted_rule_binary_search.native.so: \
  sorted_rule_binary_search.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h:
