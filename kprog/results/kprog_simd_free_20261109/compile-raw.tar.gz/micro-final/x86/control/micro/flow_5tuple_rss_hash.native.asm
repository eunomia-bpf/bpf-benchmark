
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/flow_5tuple_rss_hash.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <flow_5tuple_rss_hash_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rdx
       7:      	xorl	%eax, %eax
       9:      	cmpq	%rdx, %rcx
       c:      	ja	0x204 <flow_5tuple_rss_hash_xdp+0x204>
      12:      	leaq	0x8(%rcx), %rsi
      16:      	cmpq	%rdx, %rsi
      19:      	ja	0x204 <flow_5tuple_rss_hash_xdp+0x204>
      1f:      	leaq	0x16(%rcx), %rsi
      23:      	cmpq	%rdx, %rsi
      26:      	ja	0x204 <flow_5tuple_rss_hash_xdp+0x204>
      2c:      	pushq	%rbp
      2d:      	pushq	%r15
      2f:      	pushq	%r14
      31:      	pushq	%rbx
      32:      	movbew	0x14(%rcx), %di
      38:      	movzwl	%di, %edi
      3b:      	cmpl	$0x800, %edi            # imm = 0x800
      41:      	jne	0x1fe <flow_5tuple_rss_hash_xdp+0x1fe>
      47:      	leaq	0x2a(%rcx), %rdi
      4b:      	cmpq	%rdx, %rdi
      4e:      	ja	0x1fe <flow_5tuple_rss_hash_xdp+0x1fe>
      54:      	movzbl	(%rsi), %edi
      57:      	movl	%edi, %r8d
      5a:      	andb	$-0x10, %r8b
      5e:      	cmpb	$0x40, %r8b
      62:      	jne	0x1fe <flow_5tuple_rss_hash_xdp+0x1fe>
      68:      	andl	$0xf, %edi
      6b:      	cmpb	$0x5, %dil
      6f:      	jb	0x1fe <flow_5tuple_rss_hash_xdp+0x1fe>
      75:      	leaq	(%rsi,%rdi,4), %rdi
      79:      	cmpq	%rdx, %rdi
      7c:      	ja	0x1fe <flow_5tuple_rss_hash_xdp+0x1fe>
      82:      	movzbl	0x18(%rcx), %r8d
      87:      	movzbl	0x19(%rcx), %esi
      8b:      	movzbl	0x1f(%rcx), %ebx
      8f:      	cmpl	$0x11, %ebx
      92:      	je	0x9d <flow_5tuple_rss_hash_xdp+0x9d>
      94:      	cmpl	$0x6, %ebx
      97:      	jne	0x1fe <flow_5tuple_rss_hash_xdp+0x1fe>
      9d:      	leaq	0x4(%rdi), %r9
      a1:      	cmpq	%rdx, %r9
      a4:      	ja	0x1fe <flow_5tuple_rss_hash_xdp+0x1fe>
      aa:      	movl	%r8d, %eax
      ad:      	movbel	0x26(%rcx), %edx
      b2:      	shll	$0x8, %eax
      b5:      	movbel	0x22(%rcx), %r9d
      bb:      	movbew	(%rdi), %r10w
      c1:      	orl	%esi, %eax
      c3:      	movzwl	%r10w, %esi
      c7:      	movbew	0x2(%rdi), %di
      cd:      	movzwl	%di, %edi
      d0:      	leal	(%rax,%r9), %r10d
      d4:      	leal	-0x61c88647(%rdx), %ebp
      da:      	movl	%esi, %r11d
      dd:      	shll	$0x10, %r11d
      e1:      	orl	%edi, %r11d
      e4:      	leal	(%rbx,%r11), %r14d
      e8:      	leal	(%rbx,%r11), %r15d
      ec:      	addl	$0x12345678, %r15d      # imm = 0x12345678
      f3:      	subl	%r15d, %r10d
      f6:      	addl	$0xdeadbeef, %r10d      # imm = 0xDEADBEEF
      fd:      	rorxl	$0x1c, %r15d, %r15d
     103:      	xorl	%r10d, %r15d
     106:      	leal	(%rdx,%r14), %r10d
     10a:      	addl	$0xb06bd031, %r10d      # imm = 0xB06BD031
     111:      	subl	%r15d, %ebp
     114:      	rorxl	$0x1a, %r15d, %r14d
     11a:      	xorl	%ebp, %r14d
     11d:      	addl	%r10d, %r15d
     120:      	subl	%r14d, %r10d
     123:      	rorxl	$0x18, %r14d, %ebp
     129:      	xorl	%r10d, %ebp
     12c:      	addl	%r15d, %r14d
     12f:      	subl	%ebp, %r15d
     132:      	rorxl	$0x10, %ebp, %r10d
     138:      	xorl	%r15d, %r10d
     13b:      	addl	%r14d, %ebp
     13e:      	subl	%r10d, %r14d
     141:      	rorxl	$0xd, %r10d, %r15d
     147:      	xorl	%r14d, %r15d
     14a:      	addl	%ebp, %r10d
     14d:      	subl	%r15d, %ebp
     150:      	rorxl	$0x1c, %r15d, %r14d
     156:      	xorl	%ebp, %r14d
     159:      	xorl	%edx, %r9d
     15c:      	rorxl	$0x19, %r9d, %r9d
     162:      	addl	%r10d, %r9d
     165:      	addl	%r11d, %r10d
     168:      	addl	%r15d, %r10d
     16b:      	movl	%ebx, %edx
     16d:      	shll	$0x18, %edx
     170:      	orl	%eax, %edx
     172:      	addl	%r14d, %edx
     175:      	xorl	%r10d, %edx
     178:      	rorxl	$0x12, %r10d, %r11d
     17e:      	subl	%r11d, %edx
     181:      	xorl	%edx, %r9d
     184:      	rorxl	$0x15, %edx, %r11d
     18a:      	subl	%r11d, %r9d
     18d:      	xorl	%r9d, %r10d
     190:      	rorxl	$0x7, %r9d, %r11d
     196:      	subl	%r11d, %r10d
     199:      	xorl	%r10d, %edx
     19c:      	rorxl	$0x10, %r10d, %r11d
     1a2:      	subl	%r11d, %edx
     1a5:      	xorl	%edx, %r9d
     1a8:      	rorxl	$0x1c, %edx, %r11d
     1ae:      	subl	%r11d, %r9d
     1b1:      	xorl	%r9d, %r10d
     1b4:      	rorxl	$0x12, %r9d, %r9d
     1ba:      	subl	%r9d, %r10d
     1bd:      	xorl	%r10d, %edx
     1c0:      	rorxl	$0x8, %r10d, %r9d
     1c6:      	shll	$0x10, %eax
     1c9:      	shll	$0x8, %esi
     1cc:      	orl	%esi, %ebx
     1ce:      	xorl	%edi, %ebx
     1d0:      	movb	%bl, (%rcx)
     1d2:      	movb	%bh, 0x1(%rcx)
     1d5:      	xorl	%eax, %esi
     1d7:      	shrl	$0x10, %esi
     1da:      	movb	%sil, 0x2(%rcx)
     1de:      	movb	%r8b, 0x3(%rcx)
     1e2:      	subl	%r9d, %edx
     1e5:      	movb	%dl, 0x4(%rcx)
     1e8:      	movb	%dh, 0x5(%rcx)
     1eb:      	movl	%edx, %eax
     1ed:      	shrl	$0x10, %eax
     1f0:      	movb	%al, 0x6(%rcx)
     1f3:      	shrl	$0x18, %edx
     1f6:      	movb	%dl, 0x7(%rcx)
     1f9:      	movl	$0x2, %eax
     1fe:      	popq	%rbx
     1ff:      	popq	%r14
     201:      	popq	%r15
     203:      	popq	%rbp
     204:      	retq
