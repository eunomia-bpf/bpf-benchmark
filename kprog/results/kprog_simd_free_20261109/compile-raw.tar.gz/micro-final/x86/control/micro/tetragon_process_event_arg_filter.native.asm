
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/tetragon_process_event_arg_filter.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <tetragon_process_event_arg_filter_xdp>:
       0:      	movq	(%rdi), %r8
       3:      	movq	0x8(%rdi), %rcx
       7:      	movq	%r8, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rcx, %rdx
       f:      	jbe	0x12 <tetragon_process_event_arg_filter_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rdx), %rsi
      16:      	cmpq	%rcx, %rsi
      19:      	ja	0x11 <tetragon_process_event_arg_filter_xdp+0x11>
      1b:      	leaq	0x410(%rdx), %rsi
      22:      	cmpq	%rcx, %rsi
      25:      	ja	0x11 <tetragon_process_event_arg_filter_xdp+0x11>
      27:      	cmpl	$0x20, 0x8(%rdx)
      2b:      	jne	0x11 <tetragon_process_event_arg_filter_xdp+0x11>
      2d:      	cmpl	$0x20, 0xc(%rdx)
      31:      	jne	0x11 <tetragon_process_event_arg_filter_xdp+0x11>
      33:      	pushq	%rbp
      34:      	pushq	%r15
      36:      	pushq	%r14
      38:      	pushq	%r13
      3a:      	pushq	%r12
      3c:      	pushq	%rbx
      3d:      	subq	$0x40, %rsp
      41:      	movq	%r8, 0x18(%rsp)
      46:      	addq	$0x2f, %rdx
      4a:      	movabsq	$-0x18fc812e5f4bd725, %r9 # imm = 0xE7037ED1A0B428DB
      54:      	xorl	%esi, %esi
      56:      	jmp	0x7e <tetragon_process_event_arg_filter_xdp+0x7e>
      58:      	nopl	(%rax,%rax)
      60:      	shlq	$0x20, %r10
      64:      	movl	%r8d, %eax
      67:      	orq	%r10, %rax
      6a:      	xorq	%rax, %r9
      6d:      	incq	%rsi
      70:      	addq	$0x20, %rdx
      74:      	cmpq	$0x20, %rsi
      78:      	je	0x2fc <tetragon_process_event_arg_filter_xdp+0x2fc>
      7e:      	movzbl	-0x13(%rdx), %r11d
      83:      	movzbl	-0x12(%rdx), %r10d
      88:      	shll	$0x8, %r10d
      8c:      	orq	%r11, %r10
      8f:      	cmpl	$0x4, %r10d
      93:      	jg	0xb0 <tetragon_process_event_arg_filter_xdp+0xb0>
      95:      	cmpl	$0x1, %r10d
      99:      	je	0xda <tetragon_process_event_arg_filter_xdp+0xda>
      9b:      	cmpl	$0x2, %r10d
      9f:      	jne	0xc4 <tetragon_process_event_arg_filter_xdp+0xc4>
      a1:      	movl	$0x23, %r14d
      a7:      	jmp	0xf0 <tetragon_process_event_arg_filter_xdp+0xf0>
      a9:      	nopl	(%rax)
      b0:      	cmpl	$0x5, %r10d
      b4:      	je	0xe2 <tetragon_process_event_arg_filter_xdp+0xe2>
      b6:      	cmpl	$0x9, %r10d
      ba:      	jne	0xc4 <tetragon_process_event_arg_filter_xdp+0xc4>
      bc:      	movl	$0x41, %r14d
      c2:      	jmp	0xf0 <tetragon_process_event_arg_filter_xdp+0xf0>
      c4:      	cmpw	$0xd, %r10w
      c9:      	movl	$0x0, %r14d
      cf:      	movl	$0x59, %eax
      d4:      	cmovel	%eax, %r14d
      d8:      	jmp	0xf0 <tetragon_process_event_arg_filter_xdp+0xf0>
      da:      	movl	$0x11, %r14d
      e0:      	jmp	0xf0 <tetragon_process_event_arg_filter_xdp+0xf0>
      e2:      	movl	$0x37, %r14d
      e8:      	nopl	(%rax,%rax)
      f0:      	movzwl	-0x7(%rdx), %eax
      f4:      	movzbl	-0x5(%rdx), %ecx
      f8:      	shll	$0x10, %ecx
      fb:      	orq	%rax, %rcx
      fe:      	movzbl	-0x4(%rdx), %eax
     102:      	shll	$0x18, %eax
     105:      	orq	%rcx, %rax
     108:      	movzbl	-0x3(%rdx), %edi
     10c:      	shlq	$0x20, %rdi
     110:      	movzbl	-0x2(%rdx), %ebp
     114:      	shlq	$0x28, %rbp
     118:      	orq	%rdi, %rbp
     11b:      	orq	%rax, %rbp
     11e:      	cmpq	$0x68736162, %rax       # imm = 0x68736162
     124:      	je	0x140 <tetragon_process_event_arg_filter_xdp+0x140>
     126:      	cmpl	$0x6c727563, %eax       # imm = 0x6C727563
     12b:      	jne	0x150 <tetragon_process_event_arg_filter_xdp+0x150>
     12d:      	movl	$0x2, %eax
     132:      	jmp	0x180 <tetragon_process_event_arg_filter_xdp+0x180>
     134:      	nopw	%cs:(%rax,%rax)
     140:      	movl	$0x1, %eax
     145:      	jmp	0x180 <tetragon_process_event_arg_filter_xdp+0x180>
     147:      	nopw	(%rax,%rax)
     150:      	movl	$0x3, %eax
     155:      	movabsq	$0x6e6f68747970, %rdi   # imm = 0x6E6F68747970
     15f:      	cmpq	%rdi, %rbp
     162:      	je	0x180 <tetragon_process_event_arg_filter_xdp+0x180>
     164:      	xorl	%eax, %eax
     166:      	cmpl	$0x6873, %ecx           # imm = 0x6873
     16c:      	sete	%al
     16f:      	shll	$0x2, %eax
     172:      	nopw	%cs:(%rax,%rax)
     180:      	movl	-0x1f(%rdx), %r8d
     184:      	testl	%r14d, %r14d
     187:      	je	0x60 <tetragon_process_event_arg_filter_xdp+0x60>
     18d:      	movq	%r11, 0x20(%rsp)
     192:      	movq	%r9, 0x8(%rsp)
     197:      	movzbl	-0x17(%rdx), %ecx
     19b:      	movzwl	-0x11(%rdx), %edi
     19f:      	movl	%edi, 0x4(%rsp)
     1a3:      	movzbl	-0xf(%rdx), %edi
     1a7:      	movq	%rdi, 0x28(%rsp)
     1ac:      	movzbl	-0xe(%rdx), %r15d
     1b1:      	movzbl	-0xd(%rdx), %edi
     1b5:      	movl	%edi, 0x14(%rsp)
     1b9:      	movzbl	-0xc(%rdx), %ebx
     1bd:      	movzbl	-0xb(%rdx), %edi
     1c1:      	movq	%rdi, 0x30(%rsp)
     1c6:      	movzbl	-0xa(%rdx), %r12d
     1cb:      	movzbl	-0x9(%rdx), %edi
     1cf:      	movq	%rdi, 0x38(%rsp)
     1d4:      	movzbl	-0x8(%rdx), %r13d
     1d9:      	movzbl	-0x1(%rdx), %edi
     1dd:      	movzbl	(%rdx), %r11d
     1e1:      	movl	-0x1b(%rdx), %r10d
     1e5:      	cmpb	$0x42, %cl
     1e8:      	je	0x230 <tetragon_process_event_arg_filter_xdp+0x230>
     1ea:      	movl	%r15d, %r9d
     1ed:      	andl	$0x24, %r9d
     1f1:      	jne	0x230 <tetragon_process_event_arg_filter_xdp+0x230>
     1f3:      	movzbl	-0x16(%rdx), %eax
     1f7:      	shll	$0x8, %eax
     1fa:      	movzwl	-0x15(%rdx), %edi
     1fe:      	shll	$0x10, %edi
     201:      	orq	%rcx, %rax
     204:      	orq	%rdi, %rax
     207:      	shlq	$0x10, %r10
     20b:      	xorq	%rax, %r10
     20e:      	movq	0x8(%rsp), %r9
     213:      	addq	%r10, %r9
     216:      	incq	%rsi
     219:      	addq	$0x20, %rdx
     21d:      	cmpq	$0x20, %rsi
     221:      	jne	0x7e <tetragon_process_event_arg_filter_xdp+0x7e>
     227:      	jmp	0x2fc <tetragon_process_event_arg_filter_xdp+0x2fc>
     22c:      	nopl	(%rax)
     230:      	shlq	$0x30, %r14
     234:      	movq	%rax, %rcx
     237:      	shlq	$0x28, %rcx
     23b:      	orq	%r14, %rcx
     23e:      	movl	0x4(%rsp), %r14d
     243:      	movzwl	%r14w, %r9d
     247:      	shlq	$0x18, %r9
     24b:      	orq	%rcx, %r9
     24e:      	movl	%r8d, %r8d
     251:      	orq	%r9, %r8
     254:      	testb	$0x2, %r14b
     258:      	je	0x289 <tetragon_process_event_arg_filter_xdp+0x289>
     25a:      	testl	%eax, %eax
     25c:      	je	0x289 <tetragon_process_event_arg_filter_xdp+0x289>
     25e:      	shlq	$0x30, %rdi
     262:      	shlq	$0x38, %r11
     266:      	orq	%rdi, %r11
     269:      	orq	%rbp, %r11
     26c:      	movq	0x20(%rsp), %rcx
     271:      	andb	$0x7, %cl
     274:      	leal	0x1(%rcx), %eax
     277:      	shlxq	%rax, %r11, %rax
     27c:      	notb	%cl
     27e:      	shrxq	%rcx, %r11, %rcx
     283:      	orq	%rax, %rcx
     286:      	xorq	%rcx, %r8
     289:      	movq	0x8(%rsp), %r9
     28e:      	shll	$0x8, %r15d
     292:      	addq	0x28(%rsp), %r15
     297:      	movl	0x14(%rsp), %eax
     29b:      	shll	$0x10, %eax
     29e:      	shll	$0x18, %ebx
     2a1:      	orl	%eax, %ebx
     2a3:      	movq	0x30(%rsp), %rax
     2a8:      	shlq	$0x20, %rax
     2ac:      	shlq	$0x28, %r12
     2b0:      	orq	%rax, %r12
     2b3:      	movq	0x38(%rsp), %rax
     2b8:      	shlq	$0x30, %rax
     2bc:      	shlq	$0x38, %r13
     2c0:      	orq	%rax, %r13
     2c3:      	orq	%r15, %rbx
     2c6:      	orq	%r12, %rbx
     2c9:      	orq	%r13, %rbx
     2cc:      	xorq	%rbx, %r10
     2cf:      	testb	$0x4, 0x4(%rsp)
     2d4:      	movl	$0x0, %eax
     2d9:      	cmovneq	%r10, %rax
     2dd:      	addq	%r8, %rax
     2e0:      	movl	%esi, %ecx
     2e2:      	andb	$0x7, %cl
     2e5:      	leal	0x1(%rcx), %edi
     2e8:      	shlxq	%rdi, %rax, %rdi
     2ed:      	notb	%cl
     2ef:      	shrxq	%rcx, %rax, %rax
     2f4:      	orq	%rdi, %rax
     2f7:      	jmp	0x6a <tetragon_process_event_arg_filter_xdp+0x6a>
     2fc:      	movq	0x18(%rsp), %rax
     301:      	movq	%r9, (%rax)
     304:      	movl	$0x2, %eax
     309:      	addq	$0x40, %rsp
     30d:      	popq	%rbx
     30e:      	popq	%r12
     310:      	popq	%r13
     312:      	popq	%r14
     314:      	popq	%r15
     316:      	popq	%rbp
     317:      	retq
