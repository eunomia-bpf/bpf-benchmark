/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/payload_prefix_memcmp_scan.native.so: \
  payload_prefix_memcmp_scan.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h:
