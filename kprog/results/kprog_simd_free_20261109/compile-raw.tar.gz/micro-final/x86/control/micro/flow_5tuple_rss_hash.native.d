/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/flow_5tuple_rss_hash.native.so: \
  flow_5tuple_rss_hash.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h:
