/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/trace_event_type_switch_dispatch.native.so: \
  trace_event_type_switch_dispatch.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h:
