
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/packed_header_bitfield_decode.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <packed_header_bitfield_decode_xdp>:
       0:      	movq	(%rdi), %r8
       3:      	movq	0x8(%rdi), %rcx
       7:      	movq	%r8, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rcx, %rdx
       f:      	jbe	0x12 <packed_header_bitfield_decode_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rdx), %rsi
      16:      	cmpq	%rcx, %rsi
      19:      	ja	0x11 <packed_header_bitfield_decode_xdp+0x11>
      1b:      	leaq	0x210(%rdx), %rsi
      22:      	cmpq	%rcx, %rsi
      25:      	ja	0x11 <packed_header_bitfield_decode_xdp+0x11>
      27:      	cmpl	$0x20, 0x8(%rdx)
      2b:      	jne	0x11 <packed_header_bitfield_decode_xdp+0x11>
      2d:      	cmpl	$0x2, 0xc(%rdx)
      31:      	jne	0x11 <packed_header_bitfield_decode_xdp+0x11>
      33:      	pushq	%rbp
      34:      	pushq	%r15
      36:      	pushq	%r14
      38:      	pushq	%r13
      3a:      	pushq	%r12
      3c:      	pushq	%rbx
      3d:      	subq	$0x18, %rsp
      41:      	movq	%r8, 0x10(%rsp)
      46:      	addq	$0x1f, %rdx
      4a:      	movabsq	$0x6a09e667f3bcc909, %rax # imm = 0x6A09E667F3BCC909
      54:      	movq	%rax, (%rsp)
      58:      	xorl	%eax, %eax
      5a:      	movq	%rax, 0x8(%rsp)
      5f:      	nop
      60:      	movzbl	-0xf(%rdx), %edi
      64:      	movzbl	-0xe(%rdx), %esi
      68:      	movl	%esi, %r13d
      6b:      	shll	$0x8, %r13d
      6f:      	movzbl	-0xd(%rdx), %eax
      73:      	shll	$0x10, %eax
      76:      	movzbl	-0xc(%rdx), %r12d
      7b:      	shll	$0x18, %r12d
      7f:      	orl	%eax, %r12d
      82:      	movzbl	-0xb(%rdx), %r8d
      87:      	shlq	$0x20, %r8
      8b:      	movzbl	-0xa(%rdx), %ebp
      8f:      	shlq	$0x28, %rbp
      93:      	movzbl	-0x9(%rdx), %r9d
      98:      	shlq	$0x30, %r9
      9c:      	movzbl	-0x4(%rdx), %eax
      a0:      	shll	$0x18, %eax
      a3:      	movzbl	-0x3(%rdx), %r15d
      a8:      	shlq	$0x20, %r15
      ac:      	movzbl	-0x2(%rdx), %ecx
      b0:      	shlq	$0x28, %rcx
      b4:      	leaq	(%r15,%rcx), %r14
      b8:      	orq	%rax, %r15
      bb:      	movzbl	-0x1(%rdx), %eax
      bf:      	shlq	$0x30, %rax
      c3:      	movzbl	(%rdx), %r10d
      c7:      	shlq	$0x38, %r10
      cb:      	orq	%rax, %r10
      ce:      	movzbl	-0x8(%rdx), %r11d
      d3:      	shlq	$0x38, %r11
      d7:      	orl	%edi, %r13d
      da:      	orq	%rbp, %r8
      dd:      	orq	%r9, %r11
      e0:      	orq	%rbp, %r9
      e3:      	leal	(%r12,%r13), %ebp
      e7:      	orq	%rcx, %r10
      ea:      	movl	%edi, %ecx
      ec:      	andl	$0x3f, %ecx
      ef:      	shrl	$0x6, %r13d
      f3:      	andl	$0x1f, %r13d
      f7:      	shrq	$0x36, %r11
      fb:      	addq	%r11, %rcx
      fe:      	addq	%r13, %rcx
     101:      	movzbl	-0x7(%rdx), %eax
     105:      	orq	%rbp, %r8
     108:      	shrl	$0xb, %ebp
     10b:      	andl	$0x7ff, %ebp            # imm = 0x7FF
     111:      	shrl	$0x16, %r12d
     115:      	movzbl	%r12b, %r12d
     119:      	addq	%rbp, %rcx
     11c:      	addq	%r12, %rcx
     11f:      	movzbl	-0x6(%rdx), %r13d
     124:      	shll	$0x8, %r13d
     128:      	shrq	$0x1e, %r8
     12c:      	andl	$0x3fff, %r8d           # imm = 0x3FFF
     133:      	shrq	$0x2c, %r9
     137:      	andl	$0x3ff, %r9d            # imm = 0x3FF
     13e:      	addq	%r8, %r9
     141:      	addq	%rcx, %r9
     144:      	movzbl	-0x5(%rdx), %r12d
     149:      	shll	$0x10, %r12d
     14d:      	orl	%r13d, %r12d
     150:      	orl	%eax, %r13d
     153:      	andl	$0xf, %eax
     156:      	shrq	$0x18, %r15
     15a:      	shrq	$0x28, %r10
     15e:      	shrl	%esi
     160:      	andl	$0x1f, %esi
     163:      	shrq	$0x26, %r14
     167:      	andl	$0x7f, %r14d
     16b:      	addq	%r15, %rax
     16e:      	addq	%r10, %rax
     171:      	shrl	$0xc, %r12d
     175:      	addq	%rax, %r12
     178:      	shrl	$0x4, %r13d
     17c:      	movzbl	%r13b, %eax
     180:      	addq	%r14, %r12
     183:      	addq	%rax, %r12
     186:      	movq	0x8(%rsp), %rbx
     18b:      	addq	%rbx, %r12
     18e:      	addq	%rsi, %r12
     191:      	leaq	(,%rbp,2), %rcx
     199:      	addq	%rbp, %rcx
     19c:      	leaq	(,%rax,8), %r13
     1a4:      	subq	%rax, %r13
     1a7:      	leaq	(%r8,%r8,4), %rax
     1ab:      	xorq	%rcx, %r13
     1ae:      	xorq	%rax, %r13
     1b1:      	leaq	(%r11,%r11,4), %rax
     1b5:      	leaq	(%r11,%rax,2), %rax
     1b9:      	leaq	(%r15,%r15,2), %rcx
     1bd:      	leaq	(%r15,%rcx,4), %rcx
     1c1:      	leaq	(%r10,%r10,8), %r15
     1c5:      	xorq	%rcx, %r15
     1c8:      	movl	%esi, %ecx
     1ca:      	shll	$0x4, %ecx
     1cd:      	addq	%rsi, %rcx
     1d0:      	xorq	%rax, %rcx
     1d3:      	xorq	%r15, %rcx
     1d6:      	leaq	(%r14,%r14,8), %rax
     1da:      	leaq	(%r14,%rax,2), %rax
     1de:      	xorq	%rcx, %rax
     1e1:      	addq	%r13, %rax
     1e4:      	andb	$0x7, %dil
     1e8:      	leal	0x1(%rdi), %ecx
     1eb:      	shlxq	%rcx, %r12, %rcx
     1f0:      	notb	%dil
     1f3:      	shrxq	%rdi, %r12, %rdi
     1f8:      	orq	%rcx, %rdi
     1fb:      	xorq	%r9, %rdi
     1fe:      	addq	(%rsp), %rdi
     202:      	xorq	%rax, %rdi
     205:      	leaq	(%r10,%rsi), %rax
     209:      	addq	%r8, %rax
     20c:      	addq	%rdi, %rax
     20f:      	xorl	%r11d, %r10d
     212:      	andb	$0xf, %r10b
     216:      	leal	0x1(%r10), %ecx
     21a:      	shlxq	%rcx, %rax, %rcx
     21f:      	notb	%r10b
     222:      	shrxq	%r10, %rax, %rax
     227:      	orq	%rcx, %rax
     22a:      	movq	%rax, (%rsp)
     22e:      	incq	%rbx
     231:      	addq	$0x10, %rdx
     235:      	movq	%rbx, %rax
     238:      	movq	%rbx, 0x8(%rsp)
     23d:      	cmpq	$0x20, %rbx
     241:      	jne	0x60 <packed_header_bitfield_decode_xdp+0x60>
     247:      	movq	0x10(%rsp), %rdx
     24c:      	movq	(%rsp), %rax
     250:      	movb	%al, (%rdx)
     252:      	movb	%ah, 0x1(%rdx)
     255:      	movl	%ecx, %eax
     257:      	shrl	$0x10, %eax
     25a:      	movb	%al, 0x2(%rdx)
     25d:      	movl	%ecx, %eax
     25f:      	shrl	$0x18, %eax
     262:      	movb	%al, 0x3(%rdx)
     265:      	movq	%rcx, %rax
     268:      	shrq	$0x20, %rax
     26c:      	movb	%al, 0x4(%rdx)
     26f:      	movq	%rcx, %rax
     272:      	shrq	$0x28, %rax
     276:      	movb	%al, 0x5(%rdx)
     279:      	movq	%rcx, %rax
     27c:      	shrq	$0x30, %rax
     280:      	movb	%al, 0x6(%rdx)
     283:      	shrq	$0x38, %rcx
     287:      	movb	%cl, 0x7(%rdx)
     28a:      	movl	$0x2, %eax
     28f:      	addq	$0x18, %rsp
     293:      	popq	%rbx
     294:      	popq	%r12
     296:      	popq	%r13
     298:      	popq	%r14
     29a:      	popq	%r15
     29c:      	popq	%rbp
     29d:      	retq
