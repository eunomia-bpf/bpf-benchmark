
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/simple_packet.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <simple_packet_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rdx
       7:      	movq	%rcx, %rsi
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rdx, %rsi
       f:      	ja	0x33 <simple_packet_xdp+0x33>
      11:      	addq	$0x8, %rsi
      15:      	cmpq	%rdx, %rsi
      18:      	ja	0x33 <simple_packet_xdp+0x33>
      1a:      	movw	$0x614e, (%rcx)         # imm = 0x614E
      1f:      	movb	$-0x44, 0x2(%rcx)
      23:      	movl	$0x0, 0x3(%rcx)
      2a:      	movb	$0x0, 0x7(%rcx)
      2e:      	movl	$0x2, %eax
      33:      	retq
