/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/packed_header_bitfield_decode.native.so: \
  packed_header_bitfield_decode.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h:
