/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/tracee_syscall_name_table_lookup.native.so: \
  tracee_syscall_name_table_lookup.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h:
