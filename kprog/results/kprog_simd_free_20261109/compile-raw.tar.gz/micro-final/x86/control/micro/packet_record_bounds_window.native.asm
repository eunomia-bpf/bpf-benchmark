
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/packet_record_bounds_window.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <packet_record_bounds_window_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rsi
       7:      	movq	%rcx, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rsi, %rdx
       f:      	jbe	0x12 <packet_record_bounds_window_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rdx), %rdi
      16:      	cmpq	%rsi, %rdi
      19:      	ja	0x11 <packet_record_bounds_window_xdp+0x11>
      1b:      	leaq	0x310(%rdx), %rdi
      22:      	cmpq	%rsi, %rdi
      25:      	ja	0x11 <packet_record_bounds_window_xdp+0x11>
      27:      	cmpl	$0x20, 0x8(%rdx)
      2b:      	jne	0x11 <packet_record_bounds_window_xdp+0x11>
      2d:      	cmpl	$0x18, 0xc(%rdx)
      31:      	jne	0x11 <packet_record_bounds_window_xdp+0x11>
      33:      	pushq	%r14
      35:      	pushq	%rbx
      36:      	addq	$0x27, %rdx
      3a:      	movabsq	$-0x2917014799a6026d, %r9 # imm = 0xD6E8FEB86659FD93
      44:      	movl	$0x300, %eax            # imm = 0x300
      49:      	xorl	%esi, %esi
      4b:      	jmp	0xab <packet_record_bounds_window_xdp+0xab>
      4d:      	nopl	(%rax)
      50:      	shlq	$0x20, %rbx
      54:      	movl	%r11d, %r11d
      57:      	orq	%rbx, %r11
      5a:      	addq	%r11, %r10
      5d:      	movzwl	-0x1(%rdx), %r11d
      62:      	leal	(,%rdi,4), %ebx
      69:      	andb	$0x1c, %bl
      6c:      	shlxq	%rbx, %r9, %r9
      71:      	xorq	%r10, %r9
      74:      	movl	%esi, %r10d
      77:      	andb	$0x18, %r10b
      7b:      	shlxq	%r10, %r11, %r10
      80:      	addq	%r9, %r10
      83:      	andl	$0x7, %edi
      86:      	xorl	%r8d, %edi
      89:      	leal	0x1(%rdi), %r8d
      8d:      	shlxq	%r8, %r10, %r8
      92:      	notb	%dil
      95:      	shrxq	%rdi, %r10, %r9
      9a:      	orq	%r8, %r9
      9d:      	addq	$0x8, %rsi
      a1:      	addq	$0x18, %rdx
      a5:      	addq	$-0x18, %rax
      a9:      	je	0xf7 <packet_record_bounds_window_xdp+0xf7>
      ab:      	movzbl	-0x17(%rdx), %r8d
      b0:      	andl	$0x3, %r8d
      b4:      	leaq	0x18(%r8), %rdi
      b8:      	cmpq	%rdi, %rax
      bb:      	jb	0x9d <packet_record_bounds_window_xdp+0x9d>
      bd:      	movzbl	-0x16(%rdx), %edi
      c1:      	movl	-0x13(%rdx), %r14d
      c5:      	movl	-0xf(%rdx), %ebx
      c8:      	movl	-0xb(%rdx), %r11d
      cc:      	movzwl	-0x3(%rdx), %r10d
      d1:      	addq	%r9, %r14
      d4:      	addq	%rbx, %r10
      d7:      	addq	%r14, %r10
      da:      	movl	-0x7(%rdx), %r9d
      de:      	testb	$0x1, %dil
      e2:      	je	0x50 <packet_record_bounds_window_xdp+0x50>
      e8:      	shlq	$0x20, %r11
      ec:      	orq	%r9, %r11
      ef:      	xorq	%r11, %r10
      f2:      	jmp	0x5d <packet_record_bounds_window_xdp+0x5d>
      f7:      	movq	%r9, (%rcx)
      fa:      	movl	$0x2, %eax
      ff:      	popq	%rbx
     100:      	popq	%r14
     102:      	retq
