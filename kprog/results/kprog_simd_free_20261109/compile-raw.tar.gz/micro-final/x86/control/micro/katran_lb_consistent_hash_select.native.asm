
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/katran_lb_consistent_hash_select.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <katran_lb_consistent_hash_select_xdp>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	pushq	%rax
       b:      	movq	(%rdi), %rcx
       e:      	movq	0x8(%rdi), %rbx
      12:      	xorl	%eax, %eax
      14:      	cmpq	%rbx, %rcx
      17:      	ja	0x50e <katran_lb_consistent_hash_select_xdp+0x50e>
      1d:      	leaq	0x8(%rcx), %rsi
      21:      	cmpq	%rbx, %rsi
      24:      	ja	0x50e <katran_lb_consistent_hash_select_xdp+0x50e>
      2a:      	leaq	0x16(%rcx), %rdx
      2e:      	cmpq	%rbx, %rdx
      31:      	ja	0x50e <katran_lb_consistent_hash_select_xdp+0x50e>
      37:      	movabsq	$-0x61c8864680b583eb, %rax # imm = 0x9E3779B97F4A7C15
      41:      	movq	%rbx, %r10
      44:      	subq	%rsi, %r10
      47:      	movzwl	0x14(%rcx), %esi
      4b:      	cmpl	$0xdd86, %esi           # imm = 0xDD86
      51:      	je	0xe8 <katran_lb_consistent_hash_select_xdp+0xe8>
      57:      	cmpl	$0x8, %esi
      5a:      	jne	0x117 <katran_lb_consistent_hash_select_xdp+0x117>
      60:      	leaq	0x2a(%rcx), %rsi
      64:      	movl	$0x1, %r9d
      6a:      	cmpq	%rbx, %rsi
      6d:      	ja	0x4e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
      73:      	movzbl	(%rdx), %edx
      76:      	andb	$0xf, %dl
      79:      	cmpb	$0x5, %dl
      7c:      	jne	0x4e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
      82:      	movzbl	0x1c(%rcx), %edx
      86:      	movzbl	0x1d(%rcx), %esi
      8a:      	andl	$0x3f, %edx
      8d:      	orw	%si, %dx
      90:      	jne	0x4e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
      96:      	movzbl	0x1f(%rcx), %r14d
      9b:      	movl	$0x2, %esi
      a0:      	cmpl	$0x1, %r14d
      a4:      	je	0x135 <katran_lb_consistent_hash_select_xdp+0x135>
      aa:      	movbew	0x18(%rcx), %bp
      b0:      	movzbl	0x17(%rcx), %edi
      b4:      	movzwl	0x22(%rcx), %r11d
      b9:      	movzbl	0x24(%rcx), %r8d
      be:      	movzbl	0x25(%rcx), %edx
      c2:      	movl	0x26(%rcx), %r15d
      c6:      	cmpl	$0x11, %r14d
      ca:      	je	0x4de <katran_lb_consistent_hash_select_xdp+0x4de>
      d0:      	cmpl	$0x6, %r14d
      d4:      	jne	0x135 <katran_lb_consistent_hash_select_xdp+0x135>
      d6:      	leaq	0x3e(%rcx), %r12
      da:      	cmpq	%rbx, %r12
      dd:      	ja	0x4e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
      e3:      	jmp	0x51d <katran_lb_consistent_hash_select_xdp+0x51d>
      e8:      	leaq	0x3e(%rcx), %rdx
      ec:      	movl	$0x1, %r9d
      f2:      	cmpq	%rbx, %rdx
      f5:      	ja	0x4e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
      fb:      	movzbl	0x1c(%rcx), %r12d
     100:      	cmpl	$0x2c, %r12d
     104:      	je	0x4e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
     10a:      	cmpl	$0x3a, %r12d
     10e:      	jne	0x140 <katran_lb_consistent_hash_select_xdp+0x140>
     110:      	movl	$0x2, %esi
     115:      	jmp	0x135 <katran_lb_consistent_hash_select_xdp+0x135>
     117:      	addq	%rax, %r10
     11a:      	movq	%r10, %rdx
     11d:      	shlq	$0x6, %rdx
     121:      	addq	%rax, %rdx
     124:      	movq	%r10, %rsi
     127:      	shrq	$0x2, %rsi
     12b:      	addq	%rdx, %rsi
     12e:      	addq	$0x2, %rsi
     132:      	xorq	%r10, %rsi
     135:      	movl	$0x2, %r9d
     13b:      	jmp	0x4ec <katran_lb_consistent_hash_select_xdp+0x4ec>
     140:      	movzbl	0x16(%rcx), %edx
     144:      	movzbl	0x17(%rcx), %r15d
     149:      	movbew	0x1a(%rcx), %bp
     14f:      	movl	0x1e(%rcx), %edi
     152:      	movl	0x26(%rcx), %r14d
     156:      	movl	0x2a(%rcx), %r8d
     15a:      	movl	0x2e(%rcx), %r13d
     15e:      	movl	$0xdeadc0ff, %r11d      # imm = 0xDEADC0FF
     164:      	addl	0x22(%rcx), %r11d
     168:      	movl	$0x2, %esi
     16d:      	cmpl	$0x11, %r12d
     171:      	je	0x18c <katran_lb_consistent_hash_select_xdp+0x18c>
     173:      	cmpl	$0x6, %r12d
     177:      	jne	0x135 <katran_lb_consistent_hash_select_xdp+0x135>
     179:      	movq	%rdi, (%rsp)
     17d:      	leaq	0x52(%rcx), %rdi
     181:      	cmpq	%rbx, %rdi
     184:      	ja	0x4e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
     18a:      	jmp	0x19d <katran_lb_consistent_hash_select_xdp+0x19d>
     18c:      	movq	%rdi, (%rsp)
     190:      	leaq	0x46(%rcx), %rdi
     194:      	cmpq	%rbx, %rdi
     197:      	ja	0x4e7 <katran_lb_consistent_hash_select_xdp+0x4e7>
     19d:      	cmpl	$0x6, %r12d
     1a1:      	jne	0x135 <katran_lb_consistent_hash_select_xdp+0x135>
     1a3:      	cmpl	$0x101640a, %r13d       # imm = 0x101640A
     1aa:      	jne	0x135 <katran_lb_consistent_hash_select_xdp+0x135>
     1ac:      	movzwl	0x40(%rcx), %edi
     1b0:      	movl	$0x2, %r9d
     1b6:      	cmpl	$0x901f, %edi           # imm = 0x901F
     1bc:      	jne	0x4ec <katran_lb_consistent_hash_select_xdp+0x4ec>
     1c2:      	movl	$0x1, %esi
     1c7:      	movl	$0x1, %r9d
     1cd:      	cmpq	$0x5ea, %r10            # imm = 0x5EA
     1d4:      	jg	0x4ec <katran_lb_consistent_hash_select_xdp+0x4ec>
     1da:      	shrb	$0x4, %r15b
     1de:      	movl	%edx, %r12d
     1e1:      	shlb	$0x4, %r12b
     1e5:      	orb	%r15b, %r12b
     1e8:      	movzwl	%bp, %esi
     1eb:      	movl	%r8d, %edi
     1ee:      	andl	$0xff000000, %edi       # imm = 0xFF000000
     1f4:      	leal	-0x21523f01(%r14), %r10d
     1fb:      	movl	%r8d, %r9d
     1fe:      	andl	$0xff0000, %r9d         # imm = 0xFF0000
     205:      	addl	%edi, %r9d
     208:      	movl	%r8d, %edi
     20b:      	andl	$0xff00, %edi           # imm = 0xFF00
     211:      	addl	%r9d, %edi
     214:      	movzbl	%r8b, %r9d
     218:      	addl	%edi, %r9d
     21b:      	movzwl	0x3e(%rcx), %r8d
     220:      	movq	(%rsp), %rdx
     224:      	movl	%edx, %edi
     226:      	subl	%r14d, %edi
     229:      	rorxl	$0x1c, %r10d, %ebx
     22f:      	xorl	%edi, %ebx
     231:      	addl	%r11d, %r10d
     234:      	subl	%ebx, %r11d
     237:      	rorxl	$0x1a, %ebx, %edi
     23d:      	xorl	%r11d, %edi
     240:      	addl	%r10d, %ebx
     243:      	leal	(%rdi,%rbx), %ebp
     246:      	subl	%edi, %r10d
     249:      	rorxl	$0x18, %edi, %edi
     24f:      	xorl	%r10d, %edi
     252:      	subl	%edi, %ebx
     254:      	rorxl	$0x10, %edi, %r11d
     25a:      	xorl	%ebx, %r11d
     25d:      	addl	%ebp, %edi
     25f:      	subl	%r11d, %ebp
     262:      	rorxl	$0xd, %r11d, %ebx
     268:      	xorl	%ebp, %ebx
     26a:      	addl	%edi, %r11d
     26d:      	leal	(%rbx,%r11), %r10d
     271:      	subl	%ebx, %edi
     273:      	rorxl	$0x1c, %ebx, %ebx
     279:      	xorl	%edi, %ebx
     27b:      	addl	%r9d, %r11d
     27e:      	xorl	%r10d, %ebx
     281:      	rorxl	$0x12, %r10d, %edi
     287:      	subl	%edi, %ebx
     289:      	xorl	%ebx, %r11d
     28c:      	rorxl	$0x15, %ebx, %edi
     292:      	subl	%edi, %r11d
     295:      	xorl	%r11d, %r10d
     298:      	rorxl	$0x7, %r11d, %edi
     29e:      	subl	%edi, %r10d
     2a1:      	xorl	%r10d, %ebx
     2a4:      	rorxl	$0x10, %r10d, %edi
     2aa:      	subl	%edi, %ebx
     2ac:      	xorl	%ebx, %r11d
     2af:      	rorxl	$0x1c, %ebx, %edi
     2b5:      	subl	%edi, %r11d
     2b8:      	xorl	%r11d, %r10d
     2bb:      	rorxl	$0x12, %r11d, %edi
     2c1:      	subl	%edi, %r10d
     2c4:      	rorxl	$0x8, %r10d, %edi
     2ca:      	xorl	%ebx, %r10d
     2cd:      	subl	%edi, %r10d
     2d0:      	addl	$0xe0adc0f7, %r10d      # imm = 0xE0ADC0F7
     2d7:      	movl	%r8d, %r11d
     2da:      	addl	$0x70ccc0f7, %r11d      # imm = 0x70CCC0F7
     2e1:      	movl	%r11d, %r9d
     2e4:      	xorl	$0xe0adc0f7, %r9d       # imm = 0xE0ADC0F7
     2eb:      	movl	$0x70cc0000, %edi       # imm = 0x70CC0000
     2f0:      	shrdl	$0x12, %r11d, %edi
     2f5:      	subl	%edi, %r9d
     2f8:      	xorl	%r9d, %r10d
     2fb:      	rorxl	$0x15, %r9d, %edi
     301:      	subl	%edi, %r10d
     304:      	xorl	%r10d, %r11d
     307:      	rorxl	$0x7, %r10d, %edi
     30d:      	subl	%edi, %r11d
     310:      	xorl	%r11d, %r9d
     313:      	rorxl	$0x10, %r11d, %edi
     319:      	subl	%edi, %r9d
     31c:      	xorl	%r9d, %r10d
     31f:      	rorxl	$0x1c, %r9d, %edi
     325:      	subl	%edi, %r10d
     328:      	xorl	%r10d, %r11d
     32b:      	rorxl	$0x12, %r10d, %edi
     331:      	subl	%edi, %r11d
     334:      	xorl	%r11d, %r9d
     337:      	rorxl	$0x8, %r11d, %edi
     33d:      	subl	%edi, %r9d
     340:      	movl	$0xffff0001, %edi       # imm = 0xFFFF0001
     345:      	imulq	%r9, %rdi
     349:      	shrq	$0x30, %rdi
     34d:      	movl	%edi, %r10d
     350:      	shll	$0x10, %r10d
     354:      	orl	%edi, %r10d
     357:      	subl	%r10d, %r9d
     35a:      	movq	%rdx, %rdi
     35d:      	addq	%rax, %rdi
     360:      	movq	%rdi, %r10
     363:      	shlq	$0x6, %r10
     367:      	addq	%rax, %r10
     36a:      	movq	%rdi, %r11
     36d:      	shrq	$0x2, %r11
     371:      	addq	%r11, %r10
     374:      	addq	$0x101640a, %r10        # imm = 0x101640A
     37b:      	xorq	%rdi, %r10
     37e:      	movq	%r10, %r11
     381:      	shlq	$0x6, %r11
     385:      	addq	%r8, %r11
     388:      	addq	%rax, %r11
     38b:      	movq	%r10, %rdi
     38e:      	shrq	$0x2, %rdi
     392:      	movl	$0x901f0000, %ebx       # imm = 0x901F0000
     397:      	addq	%rdi, %rbx
     39a:      	addq	%r11, %rbx
     39d:      	xorq	%r10, %rbx
     3a0:      	movq	%rbx, %rdi
     3a3:      	shlq	$0x6, %rdi
     3a7:      	movq	%rbx, %r10
     3aa:      	shrq	$0x2, %r10
     3ae:      	addq	%rax, %rdi
     3b1:      	addq	%r10, %rdi
     3b4:      	addq	%r9, %rdi
     3b7:      	xorq	%rbx, %rdi
     3ba:      	movq	%rdi, %r9
     3bd:      	shlq	$0x6, %r9
     3c1:      	addq	%rax, %r9
     3c4:      	movq	%rdi, %r10
     3c7:      	shrq	$0x2, %r10
     3cb:      	addq	%r10, %r9
     3ce:      	incq	%r9
     3d1:      	xorq	%rdi, %r9
     3d4:      	movq	%r9, %rdi
     3d7:      	shlq	$0x6, %rdi
     3db:      	addq	%rax, %rdi
     3de:      	movq	%r9, %r10
     3e1:      	shrq	$0x2, %r10
     3e5:      	addq	%rdi, %r10
     3e8:      	xorq	%r9, %r10
     3eb:      	movq	%r10, %r11
     3ee:      	shlq	$0x6, %r11
     3f2:      	addq	%rsi, %r11
     3f5:      	addq	%rax, %r11
     3f8:      	movq	%r10, %r9
     3fb:      	shrq	$0x2, %r9
     3ff:      	addq	%r11, %r9
     402:      	rolw	$0x8, %r8w
     407:      	shll	$0x10, %r8d
     40b:      	andl	$0xffff0000, %edx       # imm = 0xFFFF0000
     411:      	xorl	%r8d, %edx
     414:      	movl	%esi, %edi
     416:      	addl	$0x14, %edi
     419:      	rolw	$0x8, %di
     41d:      	movzbl	%r12b, %r8d
     421:      	movzwl	%di, %edi
     424:      	movl	%edx, %r11d
     427:      	shrl	$0x10, %r11d
     42b:      	addq	%r8, %rdi
     42e:      	addq	%r11, %rdi
     431:      	addq	$0xdf3b, %rdi           # imm = 0xDF3B
     438:      	movl	%edi, %r8d
     43b:      	shrl	$0x10, %r8d
     43f:      	movzwl	%di, %r11d
     443:      	addq	%r8, %r11
     446:      	cmpq	$0x10000, %rdi          # imm = 0x10000
     44d:      	cmovbq	%rdi, %r11
     451:      	movl	%r11d, %edi
     454:      	shrl	$0x10, %edi
     457:      	movzwl	%r11w, %r8d
     45b:      	addq	%rdi, %r8
     45e:      	cmpq	$0x10000, %r11          # imm = 0x10000
     465:      	cmovbq	%r11, %r8
     469:      	movl	%r8d, %edi
     46c:      	shrl	$0x10, %edi
     46f:      	movzwl	%r8w, %r11d
     473:      	addq	%rdi, %r11
     476:      	cmpq	$0x10000, %r8           # imm = 0x10000
     47d:      	cmovbq	%r8, %r11
     481:      	movl	%r11d, %edi
     484:      	shrl	$0x10, %edi
     487:      	addl	%r11d, %edi
     48a:      	xorq	%r10, %r9
     48d:      	orl	$0x10ac, %edx           # imm = 0x10AC
     493:      	shlq	$0x20, %rdx
     497:      	orq	$0x200c80a, %rdx        # imm = 0x200C80A
     49e:      	cmpq	$0x10000, %r11          # imm = 0x10000
     4a5:      	cmovbl	%r11d, %edi
     4a9:      	shll	$0x10, %edi
     4ac:      	xorq	%rsi, %rdx
     4af:      	movabsq	$0x200ffff000b, %rsi    # imm = 0x200FFFF000B
     4b9:      	xorq	%rdx, %rsi
     4bc:      	xorq	%rdi, %rsi
     4bf:      	movq	%r9, %rdx
     4c2:      	shlq	$0x6, %rdx
     4c6:      	movq	%r9, %rdi
     4c9:      	shrq	$0x2, %rdi
     4cd:      	addq	%rsi, %rdi
     4d0:      	addq	%rax, %rdx
     4d3:      	addq	%rdi, %rdx
     4d6:      	xorq	%r9, %rdx
     4d9:      	jmp	0x771 <katran_lb_consistent_hash_select_xdp+0x771>
     4de:      	leaq	0x32(%rcx), %r12
     4e2:      	cmpq	%rbx, %r12
     4e5:      	jbe	0x51d <katran_lb_consistent_hash_select_xdp+0x51d>
     4e7:      	movl	$0x1, %esi
     4ec:      	movq	%rsi, %rdx
     4ef:      	shlq	$0x6, %rdx
     4f3:      	movq	%rsi, %rdi
     4f6:      	shrq	$0x2, %rdi
     4fa:      	addq	%r9, %rdi
     4fd:      	addq	%rax, %rdx
     500:      	addq	%rdi, %rdx
     503:      	xorq	%rsi, %rdx
     506:      	movq	%rdx, (%rcx)
     509:      	movl	$0x2, %eax
     50e:      	addq	$0x8, %rsp
     512:      	popq	%rbx
     513:      	popq	%r12
     515:      	popq	%r13
     517:      	popq	%r14
     519:      	popq	%r15
     51b:      	popq	%rbp
     51c:      	retq
     51d:      	cmpl	$0x101640a, %r15d       # imm = 0x101640A
     524:      	jne	0x135 <katran_lb_consistent_hash_select_xdp+0x135>
     52a:      	movzwl	0x2c(%rcx), %r9d
     52f:      	cmpl	$0x901f, %r9d           # imm = 0x901F
     536:      	jne	0x135 <katran_lb_consistent_hash_select_xdp+0x135>
     53c:      	movl	$0x2, %r9d
     542:      	cmpb	$0x6, %r14b
     546:      	jne	0x4ec <katran_lb_consistent_hash_select_xdp+0x4ec>
     548:      	movl	$0x1, %esi
     54d:      	movl	$0x1, %r9d
     553:      	cmpq	$0x5ea, %r10            # imm = 0x5EA
     55a:      	jg	0x4ec <katran_lb_consistent_hash_select_xdp+0x4ec>
     55c:      	movzwl	%bp, %esi
     55f:      	shll	$0x10, %r8d
     563:      	shll	$0x18, %edx
     566:      	orl	%r8d, %r11d
     569:      	orl	%edx, %r11d
     56c:      	movzwl	0x2a(%rcx), %r9d
     571:      	movl	%r9d, %ebx
     574:      	addl	$0x70ccc0f7, %ebx       # imm = 0x70CCC0F7
     57a:      	movl	%ebx, %r10d
     57d:      	xorl	$0xe0adc0f7, %r10d      # imm = 0xE0ADC0F7
     584:      	movl	$0x70cc0000, %ebp       # imm = 0x70CC0000
     589:      	shrdl	$0x12, %ebx, %ebp
     58d:      	subl	%ebp, %r10d
     590:      	leal	-0x1f523f09(%r11), %ebp
     597:      	xorl	%r10d, %ebp
     59a:      	rorxl	$0x15, %r10d, %r14d
     5a0:      	subl	%r14d, %ebp
     5a3:      	xorl	%ebp, %ebx
     5a5:      	rorxl	$0x7, %ebp, %r14d
     5ab:      	subl	%r14d, %ebx
     5ae:      	xorl	%ebx, %r10d
     5b1:      	rorxl	$0x10, %ebx, %r14d
     5b7:      	subl	%r14d, %r10d
     5ba:      	xorl	%r10d, %ebp
     5bd:      	rorxl	$0x1c, %r10d, %r14d
     5c3:      	subl	%r14d, %ebp
     5c6:      	xorl	%ebp, %ebx
     5c8:      	rorxl	$0x12, %ebp, %ebp
     5ce:      	subl	%ebp, %ebx
     5d0:      	xorl	%ebx, %r10d
     5d3:      	rorxl	$0x8, %ebx, %ebx
     5d9:      	subl	%ebx, %r10d
     5dc:      	movl	$0xffff0001, %ebx       # imm = 0xFFFF0001
     5e1:      	imulq	%r10, %rbx
     5e5:      	shrq	$0x30, %rbx
     5e9:      	movl	%ebx, %ebp
     5eb:      	shll	$0x10, %ebp
     5ee:      	orl	%ebx, %ebp
     5f0:      	subl	%ebp, %r10d
     5f3:      	movl	%r11d, %r11d
     5f6:      	addq	%rax, %r11
     5f9:      	movq	%r11, %rbx
     5fc:      	shlq	$0x6, %rbx
     600:      	movq	%r11, %r14
     603:      	shrq	$0x2, %r14
     607:      	addq	%rax, %rbx
     60a:      	addq	%r14, %rbx
     60d:      	addq	$0x101640a, %rbx        # imm = 0x101640A
     614:      	xorq	%r11, %rbx
     617:      	movq	%rbx, %r11
     61a:      	shlq	$0x6, %r11
     61e:      	movq	%rbx, %r14
     621:      	shrq	$0x2, %r14
     625:      	addq	%r9, %r14
     628:      	addq	%rax, %r11
     62b:      	addq	%r14, %r11
     62e:      	movl	$0x901f0000, %r14d      # imm = 0x901F0000
     634:      	addq	%r11, %r14
     637:      	xorq	%rbx, %r14
     63a:      	movq	%r14, %r11
     63d:      	shlq	$0x6, %r11
     641:      	movq	%r14, %rbx
     644:      	shrq	$0x2, %rbx
     648:      	addq	%rax, %r11
     64b:      	addq	%rbx, %r11
     64e:      	addq	%r10, %r11
     651:      	xorq	%r14, %r11
     654:      	movq	%r11, %r10
     657:      	shlq	$0x6, %r10
     65b:      	addq	%rax, %r10
     65e:      	movq	%r11, %rbx
     661:      	shrq	$0x2, %rbx
     665:      	addq	%rbx, %r10
     668:      	incq	%r10
     66b:      	xorq	%r11, %r10
     66e:      	movq	%r10, %rbx
     671:      	shlq	$0x6, %rbx
     675:      	addq	%rax, %rbx
     678:      	movq	%r10, %r11
     67b:      	shrq	$0x2, %r11
     67f:      	addq	%rbx, %r11
     682:      	xorq	%r10, %r11
     685:      	movq	%r11, %rbx
     688:      	shlq	$0x6, %rbx
     68c:      	addq	%rsi, %rbx
     68f:      	addq	%rax, %rbx
     692:      	movq	%r11, %r10
     695:      	shrq	$0x2, %r10
     699:      	addq	%rbx, %r10
     69c:      	rolw	$0x8, %r9w
     6a1:      	shll	$0x10, %r9d
     6a5:      	orl	%r8d, %edx
     6a8:      	xorl	%r9d, %edx
     6ab:      	movl	%esi, %r8d
     6ae:      	addl	$0x14, %r8d
     6b2:      	rolw	$0x8, %r8w
     6b7:      	movzwl	%r8w, %r8d
     6bb:      	movl	%edx, %r9d
     6be:      	shrl	$0x10, %r9d
     6c2:      	addq	%rdi, %r8
     6c5:      	leaq	(%r9,%r8), %rdi
     6c9:      	addq	$0xdf3b, %rdi           # imm = 0xDF3B
     6d0:      	movl	%edi, %r8d
     6d3:      	shrl	$0x10, %r8d
     6d7:      	movzwl	%di, %r9d
     6db:      	addq	%r8, %r9
     6de:      	cmpq	$0x10000, %rdi          # imm = 0x10000
     6e5:      	cmovbq	%rdi, %r9
     6e9:      	movl	%r9d, %edi
     6ec:      	shrl	$0x10, %edi
     6ef:      	movzwl	%r9w, %r8d
     6f3:      	addq	%rdi, %r8
     6f6:      	cmpq	$0x10000, %r9           # imm = 0x10000
     6fd:      	cmovbq	%r9, %r8
     701:      	movl	%r8d, %edi
     704:      	shrl	$0x10, %edi
     707:      	movzwl	%r8w, %r9d
     70b:      	addq	%rdi, %r9
     70e:      	cmpq	$0x10000, %r8           # imm = 0x10000
     715:      	cmovbq	%r8, %r9
     719:      	movl	%r9d, %edi
     71c:      	shrl	$0x10, %edi
     71f:      	addl	%r9d, %edi
     722:      	xorq	%r11, %r10
     725:      	orl	$0x10ac, %edx           # imm = 0x10AC
     72b:      	shlq	$0x20, %rdx
     72f:      	orq	$0x200c80a, %rdx        # imm = 0x200C80A
     736:      	cmpq	$0x10000, %r9           # imm = 0x10000
     73d:      	cmovbl	%r9d, %edi
     741:      	shll	$0x10, %edi
     744:      	xorq	%rsi, %rdx
     747:      	movabsq	$0x200ffff000b, %rsi    # imm = 0x200FFFF000B
     751:      	xorq	%rdx, %rsi
     754:      	xorq	%rdi, %rsi
     757:      	movq	%r10, %rdx
     75a:      	shlq	$0x6, %rdx
     75e:      	movq	%r10, %rdi
     761:      	shrq	$0x2, %rdi
     765:      	addq	%rsi, %rdi
     768:      	addq	%rax, %rdx
     76b:      	addq	%rdi, %rdx
     76e:      	xorq	%r10, %rdx
     771:      	movq	%rdx, %rsi
     774:      	shlq	$0x6, %rsi
     778:      	addq	%rax, %rsi
     77b:      	movq	%rdx, %rdi
     77e:      	shrq	$0x2, %rdi
     782:      	addq	%rdi, %rsi
     785:      	addq	$0x3, %rsi
     789:      	xorq	%rdx, %rsi
     78c:      	movl	$0x3, %r9d
     792:      	jmp	0x4ec <katran_lb_consistent_hash_select_xdp+0x4ec>
