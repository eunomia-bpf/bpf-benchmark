
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/siphash_rotate64_mixer.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <siphash_rotate64_mixer_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rsi
       7:      	movq	%rcx, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rsi, %rdx
       f:      	ja	0x560 <siphash_rotate64_mixer_xdp+0x560>
      15:      	leaq	0x8(%rdx), %rdi
      19:      	cmpq	%rsi, %rdi
      1c:      	ja	0x560 <siphash_rotate64_mixer_xdp+0x560>
      22:      	leaq	0x48(%rdx), %rdi
      26:      	cmpq	%rsi, %rdi
      29:      	ja	0x560 <siphash_rotate64_mixer_xdp+0x560>
      2f:      	pushq	%r15
      31:      	pushq	%r14
      33:      	pushq	%r12
      35:      	pushq	%rbx
      36:      	movq	0x8(%rdx), %r11
      3a:      	movq	0x10(%rdx), %r10
      3e:      	movq	0x18(%rdx), %r9
      42:      	movq	0x20(%rdx), %r8
      46:      	movq	0x28(%rdx), %rdi
      4a:      	movq	0x30(%rdx), %rsi
      4e:      	movq	0x40(%rdx), %rax
      52:      	movq	0x38(%rdx), %rdx
      56:      	movabsq	$0x7465646279746573, %rbx # imm = 0x7465646279746573
      60:      	xorq	%r11, %rbx
      63:      	movabsq	$0x6c7967656e657261, %r14 # imm = 0x6C7967656E657261
      6d:      	addq	%rbx, %r14
      70:      	rorxq	$0x30, %rbx, %r15
      76:      	xorq	%r14, %r15
      79:      	movabsq	$-0x21282b1d2821203a, %r14 # imm = 0xDED7D4E2D7DEDFC6
      83:      	addq	%r15, %r14
      86:      	rorxq	$0x2b, %r15, %r15
      8c:      	xorq	%r14, %r15
      8f:      	movabsq	$-0x59f3a6903e601530, %r12 # imm = 0xA60C596FC19FEAD0
      99:      	addq	%rbx, %r12
      9c:      	movabsq	$-0x1beb598b0f218cdb, %rbx # imm = 0xE414A674F0DE7325
      a6:      	xorq	%r12, %rbx
      a9:      	rorxq	$0x20, %r12, %r12
      af:      	addq	%rbx, %r14
      b2:      	rorxq	$0x33, %rbx, %rbx
      b8:      	xorq	%r14, %rbx
      bb:      	rorxq	$0x20, %r14, %r14
      c1:      	addq	%r15, %r12
      c4:      	rorxq	$0x30, %r15, %r15
      ca:      	xorq	%r12, %r15
      cd:      	addq	%r15, %r14
      d0:      	rorxq	$0x2b, %r15, %r15
      d6:      	xorq	%r14, %r15
      d9:      	addq	%rbx, %r12
      dc:      	rorxq	$0x2f, %rbx, %rbx
      e2:      	xorq	%r12, %rbx
      e5:      	rorxq	$0x20, %r12, %r12
      eb:      	xorq	%r11, %r14
      ee:      	xorq	%r10, %r15
      f1:      	addq	%rbx, %r14
      f4:      	rorxq	$0x33, %rbx, %r11
      fa:      	xorq	%r14, %r11
      fd:      	rorxq	$0x20, %r14, %rbx
     103:      	addq	%r15, %r12
     106:      	rorxq	$0x30, %r15, %r14
     10c:      	xorq	%r12, %r14
     10f:      	addq	%r14, %rbx
     112:      	rorxq	$0x2b, %r14, %r14
     118:      	xorq	%rbx, %r14
     11b:      	addq	%r11, %r12
     11e:      	rorxq	$0x2f, %r11, %r11
     124:      	xorq	%r12, %r11
     127:      	rorxq	$0x20, %r12, %r15
     12d:      	addq	%r11, %rbx
     130:      	rorxq	$0x33, %r11, %r11
     136:      	xorq	%rbx, %r11
     139:      	rorxq	$0x20, %rbx, %rbx
     13f:      	addq	%r14, %r15
     142:      	rorxq	$0x30, %r14, %r14
     148:      	xorq	%r15, %r14
     14b:      	addq	%r14, %rbx
     14e:      	rorxq	$0x2b, %r14, %r14
     154:      	xorq	%rbx, %r14
     157:      	addq	%r11, %r15
     15a:      	rorxq	$0x2f, %r11, %r11
     160:      	xorq	%r15, %r11
     163:      	rorxq	$0x20, %r15, %r15
     169:      	xorq	%r10, %rbx
     16c:      	xorq	%r9, %r14
     16f:      	addq	%r11, %rbx
     172:      	rorxq	$0x33, %r11, %r10
     178:      	xorq	%rbx, %r10
     17b:      	rorxq	$0x20, %rbx, %r11
     181:      	addq	%r14, %r15
     184:      	rorxq	$0x30, %r14, %rbx
     18a:      	xorq	%r15, %rbx
     18d:      	addq	%rbx, %r11
     190:      	rorxq	$0x2b, %rbx, %rbx
     196:      	xorq	%r11, %rbx
     199:      	addq	%r10, %r15
     19c:      	rorxq	$0x2f, %r10, %r10
     1a2:      	xorq	%r15, %r10
     1a5:      	rorxq	$0x20, %r15, %r14
     1ab:      	addq	%r10, %r11
     1ae:      	rorxq	$0x33, %r10, %r10
     1b4:      	xorq	%r11, %r10
     1b7:      	rorxq	$0x20, %r11, %r11
     1bd:      	addq	%rbx, %r14
     1c0:      	rorxq	$0x30, %rbx, %rbx
     1c6:      	xorq	%r14, %rbx
     1c9:      	addq	%rbx, %r11
     1cc:      	rorxq	$0x2b, %rbx, %rbx
     1d2:      	xorq	%r11, %rbx
     1d5:      	addq	%r10, %r14
     1d8:      	rorxq	$0x2f, %r10, %r10
     1de:      	xorq	%r14, %r10
     1e1:      	rorxq	$0x20, %r14, %r14
     1e7:      	xorq	%r9, %r11
     1ea:      	xorq	%r8, %rbx
     1ed:      	addq	%r10, %r11
     1f0:      	rorxq	$0x33, %r10, %r9
     1f6:      	xorq	%r11, %r9
     1f9:      	rorxq	$0x20, %r11, %r10
     1ff:      	addq	%rbx, %r14
     202:      	rorxq	$0x30, %rbx, %r11
     208:      	xorq	%r14, %r11
     20b:      	addq	%r11, %r10
     20e:      	rorxq	$0x2b, %r11, %r11
     214:      	xorq	%r10, %r11
     217:      	addq	%r9, %r14
     21a:      	rorxq	$0x2f, %r9, %r9
     220:      	xorq	%r14, %r9
     223:      	rorxq	$0x20, %r14, %rbx
     229:      	addq	%r9, %r10
     22c:      	rorxq	$0x33, %r9, %r9
     232:      	xorq	%r10, %r9
     235:      	rorxq	$0x20, %r10, %r10
     23b:      	addq	%r11, %rbx
     23e:      	rorxq	$0x30, %r11, %r11
     244:      	xorq	%rbx, %r11
     247:      	addq	%r11, %r10
     24a:      	rorxq	$0x2b, %r11, %r11
     250:      	xorq	%r10, %r11
     253:      	addq	%r9, %rbx
     256:      	rorxq	$0x2f, %r9, %r9
     25c:      	xorq	%rbx, %r9
     25f:      	rorxq	$0x20, %rbx, %rbx
     265:      	xorq	%r8, %r10
     268:      	xorq	%rdi, %r11
     26b:      	addq	%r9, %r10
     26e:      	rorxq	$0x33, %r9, %r8
     274:      	xorq	%r10, %r8
     277:      	rorxq	$0x20, %r10, %r9
     27d:      	addq	%r11, %rbx
     280:      	rorxq	$0x30, %r11, %r10
     286:      	xorq	%rbx, %r10
     289:      	addq	%r10, %r9
     28c:      	rorxq	$0x2b, %r10, %r10
     292:      	xorq	%r9, %r10
     295:      	addq	%r8, %rbx
     298:      	rorxq	$0x2f, %r8, %r8
     29e:      	xorq	%rbx, %r8
     2a1:      	rorxq	$0x20, %rbx, %r11
     2a7:      	addq	%r8, %r9
     2aa:      	rorxq	$0x33, %r8, %r8
     2b0:      	xorq	%r9, %r8
     2b3:      	rorxq	$0x20, %r9, %r9
     2b9:      	addq	%r10, %r11
     2bc:      	rorxq	$0x30, %r10, %r10
     2c2:      	xorq	%r11, %r10
     2c5:      	addq	%r10, %r9
     2c8:      	rorxq	$0x2b, %r10, %r10
     2ce:      	xorq	%r9, %r10
     2d1:      	addq	%r8, %r11
     2d4:      	rorxq	$0x2f, %r8, %r8
     2da:      	xorq	%r11, %r8
     2dd:      	rorxq	$0x20, %r11, %r11
     2e3:      	xorq	%rdi, %r9
     2e6:      	xorq	%rsi, %r10
     2e9:      	addq	%r8, %r9
     2ec:      	rorxq	$0x33, %r8, %rdi
     2f2:      	xorq	%r9, %rdi
     2f5:      	rorxq	$0x20, %r9, %r8
     2fb:      	addq	%r10, %r11
     2fe:      	rorxq	$0x30, %r10, %r9
     304:      	xorq	%r11, %r9
     307:      	addq	%r9, %r8
     30a:      	rorxq	$0x2b, %r9, %r9
     310:      	xorq	%r8, %r9
     313:      	addq	%rdi, %r11
     316:      	rorxq	$0x2f, %rdi, %rdi
     31c:      	xorq	%r11, %rdi
     31f:      	rorxq	$0x20, %r11, %r10
     325:      	addq	%rdi, %r8
     328:      	rorxq	$0x33, %rdi, %rdi
     32e:      	xorq	%r8, %rdi
     331:      	rorxq	$0x20, %r8, %r8
     337:      	addq	%r9, %r10
     33a:      	rorxq	$0x30, %r9, %r9
     340:      	xorq	%r10, %r9
     343:      	addq	%r9, %r8
     346:      	rorxq	$0x2b, %r9, %r9
     34c:      	xorq	%r8, %r9
     34f:      	addq	%rdi, %r10
     352:      	rorxq	$0x2f, %rdi, %rdi
     358:      	xorq	%r10, %rdi
     35b:      	rorxq	$0x20, %r10, %r10
     361:      	xorq	%rsi, %r8
     364:      	xorq	%rdx, %r9
     367:      	addq	%rdi, %r8
     36a:      	rorxq	$0x33, %rdi, %rsi
     370:      	xorq	%r8, %rsi
     373:      	rorxq	$0x20, %r8, %rdi
     379:      	addq	%r9, %r10
     37c:      	rorxq	$0x30, %r9, %r8
     382:      	xorq	%r10, %r8
     385:      	addq	%r8, %rdi
     388:      	rorxq	$0x2b, %r8, %r8
     38e:      	xorq	%rdi, %r8
     391:      	addq	%rsi, %r10
     394:      	rorxq	$0x2f, %rsi, %rsi
     39a:      	xorq	%r10, %rsi
     39d:      	rorxq	$0x20, %r10, %r9
     3a3:      	addq	%rsi, %rdi
     3a6:      	rorxq	$0x33, %rsi, %rsi
     3ac:      	xorq	%rdi, %rsi
     3af:      	rorxq	$0x20, %rdi, %rdi
     3b5:      	addq	%r8, %r9
     3b8:      	rorxq	$0x30, %r8, %r8
     3be:      	xorq	%r9, %r8
     3c1:      	addq	%r8, %rdi
     3c4:      	rorxq	$0x2b, %r8, %r8
     3ca:      	xorq	%rdi, %r8
     3cd:      	addq	%rsi, %r9
     3d0:      	rorxq	$0x2f, %rsi, %rsi
     3d6:      	xorq	%r9, %rsi
     3d9:      	rorxq	$0x20, %r9, %r9
     3df:      	xorq	%rdx, %rdi
     3e2:      	xorq	%rax, %r8
     3e5:      	addq	%rsi, %rdi
     3e8:      	rorxq	$0x33, %rsi, %rdx
     3ee:      	xorq	%rdi, %rdx
     3f1:      	rorxq	$0x20, %rdi, %rsi
     3f7:      	addq	%r8, %r9
     3fa:      	rorxq	$0x30, %r8, %rdi
     400:      	xorq	%r9, %rdi
     403:      	addq	%rdi, %rsi
     406:      	rorxq	$0x2b, %rdi, %rdi
     40c:      	xorq	%rsi, %rdi
     40f:      	addq	%rdx, %r9
     412:      	rorxq	$0x2f, %rdx, %rdx
     418:      	xorq	%r9, %rdx
     41b:      	rorxq	$0x20, %r9, %r8
     421:      	addq	%rdx, %rsi
     424:      	rorxq	$0x33, %rdx, %rdx
     42a:      	xorq	%rsi, %rdx
     42d:      	rorxq	$0x20, %rsi, %rsi
     433:      	addq	%rdi, %r8
     436:      	rorxq	$0x30, %rdi, %rdi
     43c:      	xorq	%r8, %rdi
     43f:      	addq	%rdi, %rsi
     442:      	rorxq	$0x2b, %rdi, %rdi
     448:      	xorq	%rsi, %rdi
     44b:      	addq	%rdx, %r8
     44e:      	rorxq	$0x2f, %rdx, %rdx
     454:      	xorq	%r8, %rdx
     457:      	rorxq	$0x20, %r8, %r8
     45d:      	xorq	%rax, %rsi
     460:      	xorq	$0xff, %r8
     467:      	addq	%rdx, %rsi
     46a:      	rorxq	$0x33, %rdx, %rax
     470:      	xorq	%rsi, %rax
     473:      	rorxq	$0x20, %rsi, %rdx
     479:      	addq	%rdi, %r8
     47c:      	rorxq	$0x30, %rdi, %rsi
     482:      	xorq	%r8, %rsi
     485:      	addq	%rsi, %rdx
     488:      	rorxq	$0x2b, %rsi, %rsi
     48e:      	xorq	%rdx, %rsi
     491:      	addq	%rax, %r8
     494:      	rorxq	$0x2f, %rax, %rax
     49a:      	xorq	%r8, %rax
     49d:      	rorxq	$0x20, %r8, %rdi
     4a3:      	addq	%rax, %rdx
     4a6:      	rorxq	$0x33, %rax, %rax
     4ac:      	xorq	%rdx, %rax
     4af:      	rorxq	$0x20, %rdx, %rdx
     4b5:      	addq	%rsi, %rdi
     4b8:      	rorxq	$0x30, %rsi, %rsi
     4be:      	xorq	%rdi, %rsi
     4c1:      	addq	%rsi, %rdx
     4c4:      	rorxq	$0x2b, %rsi, %rsi
     4ca:      	xorq	%rdx, %rsi
     4cd:      	addq	%rax, %rdi
     4d0:      	rorxq	$0x2f, %rax, %rax
     4d6:      	xorq	%rdi, %rax
     4d9:      	rorxq	$0x20, %rdi, %rdi
     4df:      	addq	%rax, %rdx
     4e2:      	rorxq	$0x33, %rax, %rax
     4e8:      	xorq	%rdx, %rax
     4eb:      	rorxq	$0x20, %rdx, %rdx
     4f1:      	addq	%rsi, %rdi
     4f4:      	rorxq	$0x30, %rsi, %rsi
     4fa:      	xorq	%rdi, %rsi
     4fd:      	addq	%rsi, %rdx
     500:      	rorxq	$0x2b, %rsi, %rsi
     506:      	xorq	%rdx, %rsi
     509:      	addq	%rax, %rdi
     50c:      	rorxq	$0x2f, %rax, %rax
     512:      	xorq	%rdi, %rax
     515:      	rorxq	$0x20, %rdi, %rdi
     51b:      	addq	%rax, %rdx
     51e:      	rorxq	$0x33, %rax, %rax
     524:      	xorq	%rdx, %rax
     527:      	addq	%rsi, %rdi
     52a:      	rorxq	$0x30, %rsi, %rdx
     530:      	xorq	%rdi, %rdx
     533:      	rorxq	$0x2b, %rdx, %rdx
     539:      	addq	%rax, %rdi
     53c:      	rorxq	$0x2f, %rax, %rax
     542:      	xorq	%rdx, %rax
     545:      	rorxq	$0x20, %rdi, %rdx
     54b:      	xorq	%rdi, %rdx
     54e:      	xorq	%rax, %rdx
     551:      	movq	%rdx, (%rcx)
     554:      	movl	$0x2, %eax
     559:      	popq	%rbx
     55a:      	popq	%r12
     55c:      	popq	%r14
     55e:      	popq	%r15
     560:      	retq
