/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/simple_packet.native.so: \
  simple_packet.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h:
