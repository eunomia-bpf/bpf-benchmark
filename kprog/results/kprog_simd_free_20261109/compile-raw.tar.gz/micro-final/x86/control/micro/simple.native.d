/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/simple.native.so: \
  simple.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/kernel_offsets.h:
