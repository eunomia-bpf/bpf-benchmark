
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/bcc_runqlat_log2_histogram_bucket.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <bcc_runqlat_log2_histogram_bucket_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rsi
       7:      	movq	%rcx, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rsi, %rdx
       f:      	jbe	0x12 <bcc_runqlat_log2_histogram_bucket_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rdx), %rdi
      16:      	cmpq	%rsi, %rdi
      19:      	ja	0x11 <bcc_runqlat_log2_histogram_bucket_xdp+0x11>
      1b:      	leaq	0x410(%rdx), %r8
      22:      	cmpq	%rsi, %r8
      25:      	ja	0x11 <bcc_runqlat_log2_histogram_bucket_xdp+0x11>
      27:      	cmpl	$0x80, (%rdi)
      2d:      	jne	0x11 <bcc_runqlat_log2_histogram_bucket_xdp+0x11>
      2f:      	pushq	%rbx
      30:      	movl	0xc(%rdx), %esi
      33:      	xorl	%eax, %eax
      35:      	jmp	0x64 <bcc_runqlat_log2_histogram_bucket_xdp+0x64>
      37:      	nopw	(%rax,%rax)
      40:      	shlq	$0x3, %rax
      44:      	movl	%r10d, %esi
      47:      	andb	$0x38, %al
      49:      	shlxq	%rax, %rsi, %rax
      4e:      	xorq	%rax, %r11
      51:      	movq	%r11, %rsi
      54:      	movq	%r8, %rax
      57:      	cmpq	$0x80, %r8
      5e:      	je	0x14a <bcc_runqlat_log2_histogram_bucket_xdp+0x14a>
      64:      	movzwl	0x10(%rdx,%rax,8), %edi
      69:      	movzbl	0x12(%rdx,%rax,8), %r8d
      6f:      	shll	$0x10, %r8d
      73:      	orq	%rdi, %r8
      76:      	movl	%r8d, %r9d
      79:      	shrl	$0x3, %r9d
      7d:      	movl	$0x0, %edi
      82:      	andl	$0xfffff, %r9d          # imm = 0xFFFFF
      89:      	je	0xac <bcc_runqlat_log2_histogram_bucket_xdp+0xac>
      8b:      	incq	%r9
      8e:      	xorl	%edi, %edi
      90:      	movl	%edi, %r10d
      93:      	leal	0x1(%r10), %edi
      97:      	cmpl	$0x3d, %r10d
      9b:      	ja	0xac <bcc_runqlat_log2_histogram_bucket_xdp+0xac>
      9d:      	movq	%r9, %r10
      a0:      	shrq	%r10
      a3:      	cmpq	$0x3, %r9
      a7:      	movq	%r10, %r9
      aa:      	ja	0x90 <bcc_runqlat_log2_histogram_bucket_xdp+0x90>
      ac:      	movzbl	0x13(%rdx,%rax,8), %r9d
      b2:      	shll	$0x18, %r9d
      b6:      	orq	%r8, %r9
      b9:      	movzbl	0x14(%rdx,%rax,8), %r8d
      bf:      	shlq	$0x20, %r8
      c3:      	movzbl	0x15(%rdx,%rax,8), %r10d
      c9:      	shlq	$0x28, %r10
      cd:      	orq	%r8, %r10
      d0:      	orq	%r9, %r10
      d3:      	movzbl	0x16(%rdx,%rax,8), %r8d
      d9:      	shlq	$0x30, %r8
      dd:      	movzbl	0x17(%rdx,%rax,8), %r9d
      e3:      	shlq	$0x38, %r9
      e7:      	orq	%r8, %r9
      ea:      	orq	%r10, %r9
      ed:      	cmpl	$0x19, %edi
      f0:      	movl	$0x19, %r10d
      f6:      	cmovbl	%edi, %r10d
      fa:      	leal	0x1(%r10), %r11d
      fe:      	leaq	0x1(%rax), %r8
     102:      	imulq	%r8, %r11
     106:      	addq	%r11, %rsi
     109:      	movl	%r10d, %r11d
     10c:      	andb	$0x7, %r11b
     110:      	leal	0x1(%r11), %ebx
     114:      	shlxq	%rbx, %r9, %rbx
     119:      	notb	%r11b
     11c:      	shrxq	%r11, %r9, %r11
     121:      	orq	%rbx, %r11
     124:      	xorq	%rsi, %r11
     127:      	cmpl	$0x19, %edi
     12a:      	jb	0x40 <bcc_runqlat_log2_histogram_bucket_xdp+0x40>
     130:      	shrq	$0x20, %r9
     134:      	addq	%r9, %r11
     137:      	movq	%r11, %rsi
     13a:      	movq	%r8, %rax
     13d:      	cmpq	$0x80, %r8
     144:      	jne	0x64 <bcc_runqlat_log2_histogram_bucket_xdp+0x64>
     14a:      	movq	%rsi, (%rcx)
     14d:      	movl	$0x2, %eax
     152:      	popq	%rbx
     153:      	retq
