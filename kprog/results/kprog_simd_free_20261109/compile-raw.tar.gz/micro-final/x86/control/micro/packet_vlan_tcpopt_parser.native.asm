
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/packet_vlan_tcpopt_parser.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <packet_vlan_tcpopt_parser_xdp>:
       0:      	movq	(%rdi), %rdx
       3:      	movq	0x8(%rdi), %r10
       7:      	xorl	%eax, %eax
       9:      	cmpq	%r10, %rdx
       c:      	ja	0x2aa <packet_vlan_tcpopt_parser_xdp+0x2aa>
      12:      	leaq	0x8(%rdx), %rcx
      16:      	cmpq	%r10, %rcx
      19:      	ja	0x2aa <packet_vlan_tcpopt_parser_xdp+0x2aa>
      1f:      	leaq	0x16(%rdx), %r9
      23:      	cmpq	%r10, %r9
      26:      	ja	0x2aa <packet_vlan_tcpopt_parser_xdp+0x2aa>
      2c:      	pushq	%rbp
      2d:      	pushq	%r15
      2f:      	pushq	%r14
      31:      	pushq	%rbx
      32:      	movbew	0x14(%rdx), %ax
      38:      	movzwl	%ax, %ecx
      3b:      	xorl	%eax, %eax
      3d:      	cmpl	$0x800, %ecx            # imm = 0x800
      43:      	je	0xdd <packet_vlan_tcpopt_parser_xdp+0xdd>
      49:      	cmpl	$0x88a8, %ecx           # imm = 0x88A8
      4f:      	je	0x5d <packet_vlan_tcpopt_parser_xdp+0x5d>
      51:      	cmpl	$0x8100, %ecx           # imm = 0x8100
      57:      	jne	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
      5d:      	leaq	0x1a(%rdx), %r9
      61:      	cmpq	%r10, %r9
      64:      	ja	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
      6a:      	movbew	0x16(%rdx), %si
      70:      	movbew	0x18(%rdx), %cx
      76:      	movzwl	%cx, %ecx
      79:      	cmpl	$0x800, %ecx            # imm = 0x800
      7f:      	je	0x292 <packet_vlan_tcpopt_parser_xdp+0x292>
      85:      	cmpl	$0x88a8, %ecx           # imm = 0x88A8
      8b:      	je	0x99 <packet_vlan_tcpopt_parser_xdp+0x99>
      8d:      	cmpl	$0x8100, %ecx           # imm = 0x8100
      93:      	jne	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
      99:      	leaq	0x1e(%rdx), %rcx
      9d:      	cmpq	%r10, %rcx
      a0:      	ja	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
      a6:      	movbew	0x1c(%rdx), %cx
      ac:      	movzwl	%cx, %ecx
      af:      	cmpl	$0x800, %ecx            # imm = 0x800
      b5:      	jne	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
      bb:      	leaq	0x32(%rdx), %rcx
      bf:      	cmpq	%r10, %rcx
      c2:      	ja	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
      c8:      	leaq	0x1e(%rdx), %r9
      cc:      	movbew	0x1a(%rdx), %cx
      d2:      	movzwl	%cx, %r8d
      d6:      	movl	$0x2, %ecx
      db:      	jmp	0xf1 <packet_vlan_tcpopt_parser_xdp+0xf1>
      dd:      	xorl	%esi, %esi
      df:      	xorl	%ecx, %ecx
      e1:      	leaq	0x14(%r9), %rdi
      e5:      	cmpq	%r10, %rdi
      e8:      	ja	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
      ee:      	xorl	%r8d, %r8d
      f1:      	movzbl	(%r9), %edi
      f5:      	movl	%edi, %r11d
      f8:      	andb	$-0x10, %r11b
      fc:      	cmpb	$0x40, %r11b
     100:      	jne	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     106:      	andl	$0xf, %edi
     109:      	cmpb	$0x5, %dil
     10d:      	jb	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     113:      	leaq	(%r9,%rdi,4), %rbx
     117:      	cmpq	%r10, %rbx
     11a:      	ja	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     120:      	cmpb	$0x6, 0x9(%r9)
     125:      	jne	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     12b:      	leaq	0x14(%rbx), %r14
     12f:      	cmpq	%r10, %r14
     132:      	ja	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     138:      	movzbl	0xc(%rbx), %r11d
     13d:      	cmpq	$0x50, %r11
     141:      	jb	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     147:      	shrl	$0x2, %r11d
     14b:      	andl	$-0x4, %r11d
     14f:      	leaq	(%rbx,%r11), %r15
     153:      	cmpq	%r10, %r15
     156:      	ja	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     15c:      	leaq	0x20(%rbx), %r15
     160:      	cmpq	%r10, %r15
     163:      	ja	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     169:      	cmpb	$0x20, %r11b
     16d:      	jb	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     173:      	cmpb	$0x2, (%r14)
     177:      	jne	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     17d:      	cmpb	$0x4, 0x15(%rbx)
     181:      	jb	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     187:      	cmpb	$0x1, 0x18(%rbx)
     18b:      	jne	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     191:      	cmpb	$0x3, 0x19(%rbx)
     195:      	jne	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     19b:      	cmpb	$0x3, 0x1a(%rbx)
     19f:      	jb	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     1a5:      	cmpb	$0x4, 0x1c(%rbx)
     1a9:      	jne	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     1af:      	cmpb	$0x2, 0x1d(%rbx)
     1b3:      	jb	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     1b9:      	cmpb	$0x1, 0x1e(%rbx)
     1bd:      	jne	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     1c3:      	movbew	0x2(%r9), %ax
     1ca:      	shlq	$0x2, %rdi
     1ce:      	movbel	0xc(%r9), %r10d
     1d4:      	movbew	(%rbx), %bp
     1d9:      	movzwl	%ax, %eax
     1dc:      	movzwl	%bp, %r14d
     1e0:      	addq	%rax, %r14
     1e3:      	movbew	0x2(%rbx), %ax
     1e9:      	movbel	0x10(%r9), %r9d
     1ef:      	movzwl	%ax, %eax
     1f2:      	addq	%r14, %rax
     1f5:      	xorq	%r10, %rax
     1f8:      	addq	%r9, %rax
     1fb:      	movzbl	0x16(%rbx), %r9d
     200:      	movl	%r9d, %r10d
     203:      	shll	$0x8, %r10d
     207:      	movzbl	0x17(%rbx), %r14d
     20c:      	orl	%r14d, %r10d
     20f:      	addq	$0x2, %r10
     213:      	shll	$0x10, %r9d
     217:      	xorq	%r10, %r9
     21a:      	shll	$0x18, %r14d
     21e:      	addq	%r14, %r9
     221:      	addq	$0x30100, %r9           # imm = 0x30100
     228:      	movzbl	0x1b(%rbx), %r10d
     22d:      	movq	%r10, %r14
     230:      	shlq	$0x20, %r14
     234:      	shll	$0x10, %r10d
     238:      	xorq	%r14, %r10
     23b:      	xorq	%r9, %r10
     23e:      	movzbl	0x1f(%rbx), %ebx
     242:      	shlq	$0x28, %rbx
     246:      	orq	%r10, %rbx
     249:      	movabsq	$0x144000000, %r9       # imm = 0x144000000
     253:      	addq	%rbx, %r9
     256:      	shll	$0x10, %esi
     259:      	orq	%r8, %rsi
     25c:      	xorq	%rax, %rsi
     25f:      	movq	%rcx, %rax
     262:      	shlq	$0x28, %rax
     266:      	shll	$0x8, %edi
     269:      	orq	%rax, %rdi
     26c:      	orq	%r11, %rdi
     26f:      	movabsq	$0x600000000, %rax      # imm = 0x600000000
     279:      	addq	%rdi, %rax
     27c:      	addq	%rsi, %rax
     27f:      	addl	$0x5, %ecx
     282:      	rolq	%cl, %r9
     285:      	xorq	%rax, %r9
     288:      	movq	%r9, (%rdx)
     28b:      	movl	$0x2, %eax
     290:      	jmp	0x2a4 <packet_vlan_tcpopt_parser_xdp+0x2a4>
     292:      	movl	$0x1, %ecx
     297:      	leaq	0x14(%r9), %rdi
     29b:      	cmpq	%r10, %rdi
     29e:      	jbe	0xee <packet_vlan_tcpopt_parser_xdp+0xee>
     2a4:      	popq	%rbx
     2a5:      	popq	%r14
     2a7:      	popq	%r15
     2a9:      	popq	%rbp
     2aa:      	retq
