
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/tracee_syscall_name_table_lookup.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <tracee_syscall_name_table_lookup_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rsi
       7:      	movq	%rcx, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rsi, %rdx
       f:      	jbe	0x12 <tracee_syscall_name_table_lookup_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rdx), %rdi
      16:      	cmpq	%rsi, %rdi
      19:      	ja	0x11 <tracee_syscall_name_table_lookup_xdp+0x11>
      1b:      	leaq	0x10c(%rdx), %r8
      22:      	cmpq	%rsi, %r8
      25:      	ja	0x11 <tracee_syscall_name_table_lookup_xdp+0x11>
      27:      	cmpl	$0x40, (%rdi)
      2a:      	jne	0x11 <tracee_syscall_name_table_lookup_xdp+0x11>
      2c:      	pushq	%rbp
      2d:      	pushq	%r15
      2f:      	pushq	%r14
      31:      	pushq	%r13
      33:      	pushq	%r12
      35:      	pushq	%rbx
      36:      	movabsq	$0x6a09e667f3bcc909, %rdi # imm = 0x6A09E667F3BCC909
      40:      	movabsq	$0x65736f6c63, %r13     # imm = 0x65736F6C63
      4a:      	xorl	%r9d, %r9d
      4d:      	leaq	0xfa0614(%r13), %r8
      54:      	movabsq	$0x74616e65706f, %r14   # imm = 0x74616E65706F
      5e:      	movabsq	$0x74616b6e696c6e75, %r10 # imm = 0x74616B6E696C6E75
      68:      	movabsq	$0x74613274617473, %r11 # imm = 0x74613274617473
      72:      	movabsq	$0x647466656e676973, %rbx # imm = 0x647466656E676973
      7c:      	nopl	(%rax)
      80:      	movzbl	0xc(%rdx,%r9,4), %r15d
      86:      	movzbl	0xd(%rdx,%r9,4), %eax
      8c:      	shll	$0x8, %eax
      8f:      	orl	%r15d, %eax
      92:      	movzwl	0xe(%rdx,%r9,4), %r12d
      98:      	shll	$0x10, %r12d
      9c:      	orl	%eax, %r12d
      9f:      	cmpl	$0x4f, %r12d
      a3:      	jg	0xe0 <tracee_syscall_name_table_lookup_xdp+0xe0>
      a5:      	cmpl	$0x26, %r12d
      a9:      	jg	0x130 <tracee_syscall_name_table_lookup_xdp+0x130>
      af:      	cmpl	$0x2, %r12d
      b3:      	jg	0x1ac <tracee_syscall_name_table_lookup_xdp+0x1ac>
      b9:      	testl	%r12d, %r12d
      bc:      	je	0x2a6 <tracee_syscall_name_table_lookup_xdp+0x2a6>
      c2:      	cmpl	$0x1, %r12d
      c6:      	je	0x263 <tracee_syscall_name_table_lookup_xdp+0x263>
      cc:      	cmpl	$0x2, %r12d
      d0:      	jne	0x31d <tracee_syscall_name_table_lookup_xdp+0x31d>
      d6:      	movl	$0x6e65706f, %eax       # imm = 0x6E65706F
      db:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
      e0:      	cmpl	$0x100, %r12d           # imm = 0x100
      e7:      	jg	0x170 <tracee_syscall_name_table_lookup_xdp+0x170>
      ed:      	cmpl	$0x9d, %r12d
      f4:      	jg	0x1d7 <tracee_syscall_name_table_lookup_xdp+0x1d7>
      fa:      	cmpl	$0x50, %r12d
      fe:      	je	0x2ad <tracee_syscall_name_table_lookup_xdp+0x2ad>
     104:      	cmpl	$0x57, %r12d
     108:      	je	0x268 <tracee_syscall_name_table_lookup_xdp+0x268>
     10e:      	cmpl	$0x59, %r12d
     112:      	jne	0x31d <tracee_syscall_name_table_lookup_xdp+0x31d>
     118:      	movabsq	$0x6b6e696c55, %rax     # imm = 0x6B6E696C55
     122:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     127:      	nopw	(%rax,%rax)
     130:      	cmpl	$0x3a, %r12d
     134:      	jg	0x20d <tracee_syscall_name_table_lookup_xdp+0x20d>
     13a:      	cmpl	$0x27, %r12d
     13e:      	je	0x2b4 <tracee_syscall_name_table_lookup_xdp+0x2b4>
     144:      	cmpl	$0x38, %r12d
     148:      	je	0x274 <tracee_syscall_name_table_lookup_xdp+0x274>
     14e:      	cmpl	$0x39, %r12d
     152:      	jne	0x31d <tracee_syscall_name_table_lookup_xdp+0x31d>
     158:      	movl	$0x6b726f66, %eax       # imm = 0x6B726F66
     15d:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     162:      	nopw	%cs:(%rax,%rax)
     170:      	cmpl	$0x122, %r12d           # imm = 0x122
     177:      	jg	0x236 <tracee_syscall_name_table_lookup_xdp+0x236>
     17d:      	cmpl	$0x101, %r12d           # imm = 0x101
     184:      	je	0x2c0 <tracee_syscall_name_table_lookup_xdp+0x2c0>
     18a:      	cmpl	$0x107, %r12d           # imm = 0x107
     191:      	je	0x280 <tracee_syscall_name_table_lookup_xdp+0x280>
     197:      	cmpl	$0x119, %r12d           # imm = 0x119
     19e:      	jne	0x31d <tracee_syscall_name_table_lookup_xdp+0x31d>
     1a4:      	movq	%r11, %rax
     1a7:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     1ac:      	movq	%r13, %rax
     1af:      	cmpl	$0x3, %r12d
     1b3:      	je	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     1b9:      	cmpl	$0x9, %r12d
     1bd:      	je	0x285 <tracee_syscall_name_table_lookup_xdp+0x285>
     1c3:      	cmpl	$0xc, %r12d
     1c7:      	jne	0x31d <tracee_syscall_name_table_lookup_xdp+0x31d>
     1cd:      	movl	$0x6b72626b, %eax       # imm = 0x6B72626B
     1d2:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     1d7:      	cmpl	$0x9e, %r12d
     1de:      	je	0x2c5 <tracee_syscall_name_table_lookup_xdp+0x2c5>
     1e4:      	cmpl	$0xca, %r12d
     1eb:      	je	0x28c <tracee_syscall_name_table_lookup_xdp+0x28c>
     1f1:      	cmpl	$0xd9, %r12d
     1f8:      	jne	0x31d <tracee_syscall_name_table_lookup_xdp+0x31d>
     1fe:      	movabsq	$0x646461746567, %rax   # imm = 0x646461746567
     208:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     20d:      	cmpl	$0x3b, %r12d
     211:      	je	0x2d1 <tracee_syscall_name_table_lookup_xdp+0x2d1>
     217:      	cmpl	$0x3c, %r12d
     21b:      	je	0x298 <tracee_syscall_name_table_lookup_xdp+0x298>
     21d:      	cmpl	$0x3d, %r12d
     221:      	jne	0x31d <tracee_syscall_name_table_lookup_xdp+0x31d>
     227:      	movabsq	$0x347469617755, %rax   # imm = 0x347469617755
     231:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     236:      	cmpl	$0x123, %r12d           # imm = 0x123
     23d:      	je	0x2dd <tracee_syscall_name_table_lookup_xdp+0x2dd>
     243:      	cmpl	$0x141, %r12d           # imm = 0x141
     24a:      	je	0x29f <tracee_syscall_name_table_lookup_xdp+0x29f>
     24c:      	cmpl	$0x14c, %r12d           # imm = 0x14C
     253:      	jne	0x31d <tracee_syscall_name_table_lookup_xdp+0x31d>
     259:      	movl	$0x78746173, %eax       # imm = 0x78746173
     25e:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     263:      	movq	%r8, %rax
     266:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     268:      	movabsq	$0x6b6e696c6e75, %rax   # imm = 0x6B6E696C6E75
     272:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     274:      	movabsq	$0x656e6f6c6355, %rax   # imm = 0x656E6F6C6355
     27e:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     280:      	movq	%r10, %rax
     283:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     285:      	movl	$0x70616d6d, %eax       # imm = 0x70616D6D
     28a:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     28c:      	movabsq	$0x786574756655, %rax   # imm = 0x786574756655
     296:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     298:      	movl	$0x74697865, %eax       # imm = 0x74697865
     29d:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     29f:      	movl	$0x706662, %eax         # imm = 0x706662
     2a4:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     2a6:      	movl	$0x72656164, %eax       # imm = 0x72656164
     2ab:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     2ad:      	movl	$0x69646863, %eax       # imm = 0x69646863
     2b2:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     2b4:      	movabsq	$0x6469707467, %rax     # imm = 0x6469707467
     2be:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     2c0:      	movq	%r14, %rax
     2c3:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     2c5:      	movabsq	$0x6c74635f68637261, %rax # imm = 0x6C74635F68637261
     2cf:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     2d1:      	movabsq	$0x657663657865, %rax   # imm = 0x657663657865
     2db:      	jmp	0x2e0 <tracee_syscall_name_table_lookup_xdp+0x2e0>
     2dd:      	movq	%rbx, %rax
     2e0:      	movl	%r12d, %r12d
     2e3:      	xorq	%rax, %r12
     2e6:      	movl	%r9d, %esi
     2e9:      	andl	$0x7, %esi
     2ec:      	leal	0x1(%rsi), %ebp
     2ef:      	shlxq	%rbp, %r12, %rbp
     2f4:      	movl	%esi, %eax
     2f6:      	notb	%al
     2f8:      	shrxq	%rax, %r12, %rax
     2fd:      	orq	%rbp, %rax
     300:      	addq	%rdi, %rax
     303:      	shll	$0x3, %esi
     306:      	shlxq	%rsi, %r15, %rdi
     30b:      	xorq	%rax, %rdi
     30e:      	incq	%r9
     311:      	cmpq	$0x40, %r9
     315:      	jne	0x80 <tracee_syscall_name_table_lookup_xdp+0x80>
     31b:      	jmp	0x33e <tracee_syscall_name_table_lookup_xdp+0x33e>
     31d:      	movl	%r12d, %eax
     320:      	movabsq	$-0x61c8864e7a143579, %rsi # imm = 0x9E3779B185EBCA87
     32a:      	imulq	%rsi, %rax
     32e:      	xorq	%rax, %rdi
     331:      	incq	%r9
     334:      	cmpq	$0x40, %r9
     338:      	jne	0x80 <tracee_syscall_name_table_lookup_xdp+0x80>
     33e:      	movq	%rdi, (%rcx)
     341:      	movl	$0x2, %eax
     346:      	popq	%rbx
     347:      	popq	%r12
     349:      	popq	%r13
     34b:      	popq	%r14
     34d:      	popq	%r15
     34f:      	popq	%rbp
     350:      	retq
