
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/bpftrace_comm_key_fnv_hash.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <bpftrace_comm_key_fnv_hash_xdp>:
       0:      	movq	(%rdi), %r8
       3:      	movq	0x8(%rdi), %rcx
       7:      	movq	%r8, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rcx, %rdx
       f:      	jbe	0x12 <bpftrace_comm_key_fnv_hash_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rdx), %rsi
      16:      	cmpq	%rcx, %rsi
      19:      	ja	0x11 <bpftrace_comm_key_fnv_hash_xdp+0x11>
      1b:      	leaq	0x410(%rdx), %rsi
      22:      	cmpq	%rcx, %rsi
      25:      	ja	0x11 <bpftrace_comm_key_fnv_hash_xdp+0x11>
      27:      	cmpl	$0x20, 0x8(%rdx)
      2b:      	jne	0x11 <bpftrace_comm_key_fnv_hash_xdp+0x11>
      2d:      	cmpl	$0x20, 0xc(%rdx)
      31:      	jne	0x11 <bpftrace_comm_key_fnv_hash_xdp+0x11>
      33:      	pushq	%rbp
      34:      	pushq	%r15
      36:      	pushq	%r14
      38:      	pushq	%r13
      3a:      	pushq	%r12
      3c:      	pushq	%rbx
      3d:      	subq	$0x48, %rsp
      41:      	movq	%r8, 0x8(%rsp)
      46:      	movabsq	$0x100000001b3, %r14    # imm = 0x100000001B3
      50:      	addq	$0x2f, %rdx
      54:      	movabsq	$-0x6b2fb644ecceee15, %r8 # imm = 0x94D049BB133111EB
      5e:      	xorl	%esi, %esi
      60:      	jmp	0xbd <bpftrace_comm_key_fnv_hash_xdp+0xbd>
      62:      	nopw	%cs:(%rax,%rax)
      70:      	shll	$0x8, %ebp
      73:      	shll	$0x10, %ebx
      76:      	orl	%ebp, %ebx
      78:      	shll	$0x18, %r10d
      7c:      	orl	%ebx, %r10d
      7f:      	orl	%edi, %r10d
      82:      	movl	%esi, %ecx
      84:      	andb	$0x7, %cl
      87:      	leal	0x1(%rcx), %edi
      8a:      	shlxq	%rdi, %r9, %rdi
      8f:      	notb	%cl
      91:      	shrxq	%rcx, %r9, %rcx
      96:      	orq	%rdi, %rcx
      99:      	movq	%r8, %rdi
      9c:      	xorq	%rcx, %rdi
      9f:      	shlq	$0x38, %r11
      a3:      	movl	%r10d, %r8d
      a6:      	orq	%r11, %r8
      a9:      	addq	%rdi, %r8
      ac:      	incq	%rsi
      af:      	addq	$0x20, %rdx
      b3:      	cmpq	$0x20, %rsi
      b7:      	je	0x304 <bpftrace_comm_key_fnv_hash_xdp+0x304>
      bd:      	movq	%rsi, 0x40(%rsp)
      c2:      	movzbl	-0x1f(%rdx), %r15d
      c7:      	movzbl	-0x1e(%rdx), %r12d
      cc:      	movzbl	-0x1d(%rdx), %ecx
      d0:      	movzbl	-0x1c(%rdx), %edi
      d4:      	movzbl	-0x1b(%rdx), %ebp
      d8:      	movzbl	-0x1a(%rdx), %eax
      dc:      	movzbl	-0x19(%rdx), %esi
      e0:      	movq	%rsi, 0x38(%rsp)
      e5:      	movzbl	-0x18(%rdx), %esi
      e9:      	movq	%rsi, 0x30(%rsp)
      ee:      	movzbl	-0x17(%rdx), %r13d
      f3:      	movzbl	-0x16(%rdx), %esi
      f7:      	movzbl	-0x15(%rdx), %ebx
      fb:      	movzbl	-0x14(%rdx), %r10d
     100:      	movq	%r15, %r9
     103:      	movabsq	$-0x340d631b7bdddcdb, %r11 # imm = 0xCBF29CE484222325
     10d:      	xorq	%r11, %r9
     110:      	imulq	%r14, %r9
     114:      	movq	%r12, 0x10(%rsp)
     119:      	xorq	%r12, %r9
     11c:      	imulq	%r14, %r9
     120:      	movq	%rcx, 0x20(%rsp)
     125:      	xorq	%rcx, %r9
     128:      	imulq	%r14, %r9
     12c:      	movq	%rdi, 0x18(%rsp)
     131:      	xorq	%rdi, %r9
     134:      	imulq	%r14, %r9
     138:      	movq	%rbp, 0x28(%rsp)
     13d:      	xorq	%rbp, %r9
     140:      	movq	0x30(%rsp), %rdi
     145:      	movq	0x38(%rsp), %r11
     14a:      	movq	%rsi, %rbp
     14d:      	imulq	%r14, %r9
     151:      	xorq	%rax, %r9
     154:      	imulq	%r14, %r9
     158:      	movq	%r11, %rsi
     15b:      	xorq	%r11, %r9
     15e:      	imulq	%r14, %r9
     162:      	xorq	%rdi, %r9
     165:      	imulq	%r14, %r9
     169:      	movq	%r13, (%rsp)
     16d:      	xorq	%r13, %r9
     170:      	imulq	%r14, %r9
     174:      	xorq	%rbp, %r9
     177:      	imulq	%r14, %r9
     17b:      	xorq	%rbx, %r9
     17e:      	imulq	%r14, %r9
     182:      	movq	%r10, %r11
     185:      	xorq	%r9, %r11
     188:      	imulq	%r14, %r11
     18c:      	movzbl	-0xf(%rdx), %r9d
     191:      	xorq	%r11, %r9
     194:      	imulq	%r14, %r9
     198:      	movzbl	-0xe(%rdx), %r11d
     19d:      	xorq	%r9, %r11
     1a0:      	imulq	%r14, %r11
     1a4:      	movzbl	-0xd(%rdx), %r9d
     1a9:      	xorq	%r11, %r9
     1ac:      	imulq	%r14, %r9
     1b0:      	movzbl	-0xc(%rdx), %r11d
     1b5:      	xorq	%r9, %r11
     1b8:      	imulq	%r14, %r11
     1bc:      	movzbl	-0xb(%rdx), %r9d
     1c1:      	xorq	%r11, %r9
     1c4:      	imulq	%r14, %r9
     1c8:      	movzbl	-0xa(%rdx), %r11d
     1cd:      	xorq	%r9, %r11
     1d0:      	imulq	%r14, %r11
     1d4:      	movzbl	-0x9(%rdx), %r9d
     1d9:      	xorq	%r11, %r9
     1dc:      	imulq	%r14, %r9
     1e0:      	movzbl	-0x8(%rdx), %r11d
     1e5:      	xorq	%r9, %r11
     1e8:      	imulq	%r14, %r11
     1ec:      	movzbl	-0x7(%rdx), %r9d
     1f1:      	xorq	%r11, %r9
     1f4:      	imulq	%r14, %r9
     1f8:      	movzbl	-0x6(%rdx), %r11d
     1fd:      	xorq	%r9, %r11
     200:      	imulq	%r14, %r11
     204:      	movzbl	-0x5(%rdx), %r9d
     209:      	xorq	%r11, %r9
     20c:      	imulq	%r14, %r9
     210:      	movzbl	-0x4(%rdx), %r11d
     215:      	xorq	%r9, %r11
     218:      	imulq	%r14, %r11
     21c:      	movzbl	-0x3(%rdx), %r9d
     221:      	xorq	%r11, %r9
     224:      	imulq	%r14, %r9
     228:      	movzbl	-0x2(%rdx), %r11d
     22d:      	xorq	%r9, %r11
     230:      	imulq	%r14, %r11
     234:      	movzbl	-0x1(%rdx), %r13d
     239:      	xorq	%r11, %r13
     23c:      	imulq	%r14, %r13
     240:      	movzbl	(%rdx), %r9d
     244:      	xorq	%r13, %r9
     247:      	movzbl	-0x13(%rdx), %r11d
     24c:      	imulq	%r14, %r9
     250:      	testb	$0x1, %r11b
     254:      	jne	0x270 <bpftrace_comm_key_fnv_hash_xdp+0x270>
     256:      	movq	(%rsp), %rdi
     25a:      	testb	$0x2, %r11b
     25e:      	movq	0x40(%rsp), %rsi
     263:      	je	0x70 <bpftrace_comm_key_fnv_hash_xdp+0x70>
     269:      	jmp	0x2ea <bpftrace_comm_key_fnv_hash_xdp+0x2ea>
     26e:      	nop
     270:      	movq	%rax, %rcx
     273:      	movq	%rdi, %rax
     276:      	shll	$0x18, %eax
     279:      	shll	$0x10, %esi
     27c:      	movq	%rcx, %r13
     27f:      	shll	$0x8, %r13d
     283:      	movq	0x20(%rsp), %rcx
     288:      	shlq	$0x30, %rcx
     28c:      	movq	0x18(%rsp), %rdi
     291:      	shlq	$0x38, %rdi
     295:      	movq	0x10(%rsp), %r12
     29a:      	shlq	$0x28, %r12
     29e:      	shlq	$0x20, %r15
     2a2:      	orq	%r12, %r15
     2a5:      	orq	%rcx, %r15
     2a8:      	orq	%rdi, %r15
     2ab:      	orq	%r13, %r15
     2ae:      	orq	%rsi, %r15
     2b1:      	orq	%rax, %r15
     2b4:      	orq	0x28(%rsp), %r15
     2b9:      	movq	(%rsp), %r12
     2bd:      	movl	%r12d, %ecx
     2c0:      	andb	$0x7, %cl
     2c3:      	leal	0x1(%rcx), %edi
     2c6:      	shlxq	%rdi, %r15, %rdi
     2cb:      	notb	%cl
     2cd:      	shrxq	%rcx, %r15, %rcx
     2d2:      	orq	%rdi, %rcx
     2d5:      	xorq	%rcx, %r9
     2d8:      	movq	%r12, %rdi
     2db:      	testb	$0x2, %r11b
     2df:      	movq	0x40(%rsp), %rsi
     2e4:      	je	0x70 <bpftrace_comm_key_fnv_hash_xdp+0x70>
     2ea:      	movabsq	$-0x61c8864e7a143579, %rcx # imm = 0x9E3779B185EBCA87
     2f4:      	addq	%r9, %rcx
     2f7:      	cmpb	$0x70, -0xf(%rdx)
     2fb:      	cmoveq	%rcx, %r9
     2ff:      	jmp	0x70 <bpftrace_comm_key_fnv_hash_xdp+0x70>
     304:      	movq	0x8(%rsp), %rax
     309:      	movq	%r8, (%rax)
     30c:      	movl	$0x2, %eax
     311:      	addq	$0x48, %rsp
     315:      	popq	%rbx
     316:      	popq	%r12
     318:      	popq	%r13
     31a:      	popq	%r14
     31c:      	popq	%r15
     31e:      	popq	%rbp
     31f:      	retq
