
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/packet_checksum_fold.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <packet_checksum_fold_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rsi
       7:      	movq	%rcx, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rsi, %rdx
       f:      	jbe	0x12 <packet_checksum_fold_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rdx), %rdi
      16:      	cmpq	%rsi, %rdi
      19:      	ja	0x11 <packet_checksum_fold_xdp+0x11>
      1b:      	leaq	0x410(%rdx), %rdi
      22:      	cmpq	%rsi, %rdi
      25:      	ja	0x11 <packet_checksum_fold_xdp+0x11>
      27:      	cmpl	$0x20, 0x8(%rdx)
      2b:      	jne	0x11 <packet_checksum_fold_xdp+0x11>
      2d:      	cmpl	$0x200, 0xc(%rdx)       # imm = 0x200
      34:      	jne	0x11 <packet_checksum_fold_xdp+0x11>
      36:      	xorl	%eax, %eax
      38:      	xorl	%esi, %esi
      3a:      	nopw	(%rax,%rax)
      40:      	xorl	%edi, %edi
      42:      	xorl	%r8d, %r8d
      45:      	nopw	%cs:(%rax,%rax)
      50:      	movzwl	0x10(%rdx,%rdi,2), %r9d
      56:      	addl	%r8d, %r9d
      59:      	movzwl	%r9w, %r8d
      5d:      	shrl	$0x10, %r9d
      61:      	addl	%r8d, %r9d
      64:      	movzwl	0x12(%rdx,%rdi,2), %r8d
      6a:      	addl	%r9d, %r8d
      6d:      	movzwl	%r8w, %r9d
      71:      	shrl	$0x10, %r8d
      75:      	addl	%r9d, %r8d
      78:      	movzwl	0x14(%rdx,%rdi,2), %r9d
      7e:      	addl	%r8d, %r9d
      81:      	movzwl	%r9w, %r8d
      85:      	shrl	$0x10, %r9d
      89:      	addl	%r8d, %r9d
      8c:      	movzwl	0x16(%rdx,%rdi,2), %r8d
      92:      	addl	%r9d, %r8d
      95:      	movzwl	%r8w, %r9d
      99:      	shrl	$0x10, %r8d
      9d:      	addl	%r9d, %r8d
      a0:      	addq	$0x4, %rdi
      a4:      	cmpq	$0x200, %rdi            # imm = 0x200
      ab:      	jne	0x50 <packet_checksum_fold_xdp+0x50>
      ad:      	movl	%r8d, %edi
      b0:      	shrl	$0x10, %edi
      b3:      	addl	%r8d, %edi
      b6:      	notl	%edi
      b8:      	movzwl	%di, %edi
      bb:      	movl	%eax, %r8d
      be:      	shll	$0x4, %r8d
      c2:      	shlxq	%r8, %rdi, %rdi
      c7:      	xorq	%rdi, %rsi
      ca:      	incl	%eax
      cc:      	cmpl	$0x20, %eax
      cf:      	jne	0x40 <packet_checksum_fold_xdp+0x40>
      d5:      	movq	%rsi, (%rcx)
      d8:      	movl	$0x2, %eax
      dd:      	retq
