
/var/tmp/kprog-tmp/S14/micro-final/x86/control/micro/cilium_policy_guard_tree_filter.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <cilium_policy_guard_tree_filter_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rsi
       7:      	movq	%rcx, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rsi, %rdx
       f:      	jbe	0x12 <cilium_policy_guard_tree_filter_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rdx), %rdi
      16:      	cmpq	%rsi, %rdi
      19:      	ja	0x11 <cilium_policy_guard_tree_filter_xdp+0x11>
      1b:      	leaq	0x20c(%rdx), %r8
      22:      	cmpq	%rsi, %r8
      25:      	ja	0x11 <cilium_policy_guard_tree_filter_xdp+0x11>
      27:      	cmpl	$0x20, (%rdi)
      2a:      	jne	0x11 <cilium_policy_guard_tree_filter_xdp+0x11>
      2c:      	pushq	%rbx
      2d:      	addq	$0x1b, %rdx
      31:      	movabsq	$-0x18fc812e5f4bd725, %rdi # imm = 0xE7037ED1A0B428DB
      3b:      	xorl	%eax, %eax
      3d:      	jmp	0x81 <cilium_policy_guard_tree_filter_xdp+0x81>
      3f:      	shlq	$0x30, %r8
      43:      	nopw	%cs:(%rax,%rax)
      50:      	xorq	%r8, %rsi
      53:      	addq	%rdi, %rsi
      56:      	movl	%eax, %edi
      58:      	andb	$0x7, %dil
      5c:      	leal	0x1(%rdi), %r8d
      60:      	shlxq	%r8, %rsi, %rbx
      65:      	notb	%dil
      68:      	shrxq	%rdi, %rsi, %rdi
      6d:      	orq	%rbx, %rdi
      70:      	incq	%rax
      73:      	addq	$0x10, %rdx
      77:      	cmpq	$0x20, %rax
      7b:      	je	0x13d <cilium_policy_guard_tree_filter_xdp+0x13d>
      81:      	movzbl	-0xf(%rdx), %r8d
      86:      	movq	-0x7(%rdx), %rsi
      8a:      	cmpq	$0x21, %r8
      8e:      	jb	0x50 <cilium_policy_guard_tree_filter_xdp+0x50>
      90:      	movzbl	-0xe(%rdx), %r9d
      95:      	testb	$0x1, %r9b
      99:      	je	0x101 <cilium_policy_guard_tree_filter_xdp+0x101>
      9b:      	movzbl	-0xd(%rdx), %r9d
      a0:      	testb	%r9b, %r9b
      a3:      	js	0xf7 <cilium_policy_guard_tree_filter_xdp+0xf7>
      a5:      	movzbl	-0xc(%rdx), %r9d
      aa:      	movl	%r9d, %r10d
      ad:      	xorl	%eax, %r10d
      b0:      	cmpb	$0x11, %r10b
      b4:      	jb	0xfd <cilium_policy_guard_tree_filter_xdp+0xfd>
      b6:      	movzbl	-0xb(%rdx), %r9d
      bb:      	addb	%r9b, %r8b
      be:      	cmpb	$-0x41, %r8b
      c2:      	ja	0x10c <cilium_policy_guard_tree_filter_xdp+0x10c>
      c4:      	movzbl	-0xa(%rdx), %r8d
      c9:      	movl	%r8d, %r9d
      cc:      	andb	$0x18, %r9b
      d0:      	cmpb	$0x10, %r9b
      d4:      	jne	0x118 <cilium_policy_guard_tree_filter_xdp+0x118>
      d6:      	movzbl	-0x9(%rdx), %r9d
      db:      	cmpl	$0xaa, %r9d
      e2:      	jne	0x121 <cilium_policy_guard_tree_filter_xdp+0x121>
      e4:      	xorq	%rsi, %r8
      e7:      	shldq	$0x7, %rsi, %r8
      ec:      	addq	%rdi, %r8
      ef:      	movq	%r8, %rsi
      f2:      	jmp	0x56 <cilium_policy_guard_tree_filter_xdp+0x56>
      f7:      	shll	$0x8, %r9d
      fb:      	jmp	0x110 <cilium_policy_guard_tree_filter_xdp+0x110>
      fd:      	shll	$0x10, %r9d
     101:      	addq	%r9, %rsi
     104:      	xorq	%rdi, %rsi
     107:      	jmp	0x56 <cilium_policy_guard_tree_filter_xdp+0x56>
     10c:      	shll	$0x18, %r9d
     110:      	xorq	%r9, %rsi
     113:      	jmp	0x53 <cilium_policy_guard_tree_filter_xdp+0x53>
     118:      	shlq	$0x20, %r8
     11c:      	addq	%r8, %rsi
     11f:      	jmp	0x104 <cilium_policy_guard_tree_filter_xdp+0x104>
     121:      	movzbl	-0x8(%rdx), %r8d
     126:      	movl	%r8d, %r10d
     129:      	andb	$0x3, %r10b
     12d:      	cmpb	$0x1, %r10b
     131:      	je	0x3f <cilium_policy_guard_tree_filter_xdp+0x3f>
     137:      	shlq	$0x28, %r9
     13b:      	jmp	0x101 <cilium_policy_guard_tree_filter_xdp+0x101>
     13d:      	movb	%dil, (%rcx)
     140:      	movb	%bh, 0x1(%rcx)
     143:      	movl	%ebx, %eax
     145:      	shrl	$0x10, %eax
     148:      	movb	%al, 0x2(%rcx)
     14b:      	movl	%ebx, %eax
     14d:      	shrl	$0x18, %eax
     150:      	movb	%al, 0x3(%rcx)
     153:      	movq	%rbx, %rax
     156:      	shrq	$0x20, %rax
     15a:      	movb	%al, 0x4(%rcx)
     15d:      	movq	%rbx, %rax
     160:      	shrq	$0x28, %rax
     164:      	movb	%al, 0x5(%rcx)
     167:      	movq	%rbx, %rax
     16a:      	shrq	$0x30, %rax
     16e:      	movb	%al, 0x6(%rcx)
     171:      	shrq	$0x38, %rbx
     175:      	movb	%bl, 0x7(%rcx)
     178:      	movl	$0x2, %eax
     17d:      	popq	%rbx
     17e:      	retq
