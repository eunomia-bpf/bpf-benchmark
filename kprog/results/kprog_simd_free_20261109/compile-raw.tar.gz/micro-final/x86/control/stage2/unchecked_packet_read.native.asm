
/var/tmp/kprog-tmp/S14/micro-final/x86/control/stage2/unchecked_packet_read.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <unchecked_packet_read>:
       0:      	movq	(%rdi), %rax
       3:      	movzbl	0x40(%rax), %eax
       7:      	retq
