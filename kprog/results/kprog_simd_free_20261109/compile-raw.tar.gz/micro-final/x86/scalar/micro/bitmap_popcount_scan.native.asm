
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/bitmap_popcount_scan.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <bitmap_popcount_scan_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rsi
       7:      	movq	%rcx, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rsi, %rdx
       f:      	jbe	0x12 <bitmap_popcount_scan_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rdx), %rdi
      16:      	cmpq	%rsi, %rdi
      19:      	ja	0x11 <bitmap_popcount_scan_xdp+0x11>
      1b:      	leaq	0x810(%rdx), %r8
      22:      	cmpq	%rsi, %r8
      25:      	ja	0x11 <bitmap_popcount_scan_xdp+0x11>
      27:      	cmpl	$0x100, (%rdi)          # imm = 0x100
      2d:      	jne	0x11 <bitmap_popcount_scan_xdp+0x11>
      2f:      	movl	0xc(%rdx), %esi
      32:      	xorl	%eax, %eax
      34:      	nopw	%cs:(%rax,%rax)
      40:      	movq	0x10(%rdx,%rax,8), %rdi
      45:      	movq	0x18(%rdx,%rax,8), %r8
      4a:      	movl	%eax, %r9d
      4d:      	andb	$0x6, %r9b
      51:      	shrxq	%r9, %rdi, %r9
      56:      	xorq	%rsi, %rdi
      59:      	popcntq	%rdi, %rdi
      5e:      	addq	%rsi, %rdi
      61:      	xorq	%rdi, %r9
      64:      	leal	0x1(%rax), %esi
      67:      	andb	$0x7, %sil
      6b:      	shrxq	%rsi, %r8, %rsi
      70:      	xorq	%r9, %r8
      73:      	xorl	%edi, %edi
      75:      	popcntq	%r8, %rdi
      7a:      	addq	%r9, %rdi
      7d:      	xorq	%rdi, %rsi
      80:      	addq	$0x2, %rax
      84:      	cmpq	$0x100, %rax            # imm = 0x100
      8a:      	jne	0x40 <bitmap_popcount_scan_xdp+0x40>
      8c:      	movq	%rsi, (%rcx)
      8f:      	movl	$0x2, %eax
      94:      	retq
