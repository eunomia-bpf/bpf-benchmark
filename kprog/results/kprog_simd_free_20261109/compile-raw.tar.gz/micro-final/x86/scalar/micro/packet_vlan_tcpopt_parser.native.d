/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/packet_vlan_tcpopt_parser.native.so: \
  packet_vlan_tcpopt_parser.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/kernel_offsets.h:
