
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/cilium_ct_nat_tuple_rewrite.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <cilium_ct_nat_tuple_rewrite_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rsi
       7:      	movq	%rcx, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rsi, %rdx
       f:      	jbe	0x12 <cilium_ct_nat_tuple_rewrite_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rdx), %rdi
      16:      	cmpq	%rsi, %rdi
      19:      	ja	0x11 <cilium_ct_nat_tuple_rewrite_xdp+0x11>
      1b:      	leaq	0x410(%rdx), %rdi
      22:      	cmpq	%rsi, %rdi
      25:      	ja	0x11 <cilium_ct_nat_tuple_rewrite_xdp+0x11>
      27:      	cmpl	$0x20, 0x8(%rdx)
      2b:      	jne	0x11 <cilium_ct_nat_tuple_rewrite_xdp+0x11>
      2d:      	cmpl	$0x20, 0xc(%rdx)
      31:      	jne	0x11 <cilium_ct_nat_tuple_rewrite_xdp+0x11>
      33:      	pushq	%rbp
      34:      	pushq	%r15
      36:      	pushq	%r14
      38:      	pushq	%r12
      3a:      	pushq	%rbx
      3b:      	addq	$0x2f, %rdx
      3f:      	movabsq	$-0x7143950f6377391d, %rax # imm = 0x8EBC6AF09C88C6E3
      49:      	xorl	%esi, %esi
      4b:      	jmp	0xd0 <cilium_ct_nat_tuple_rewrite_xdp+0xd0>
      50:      	movl	%ebp, %r12d
      53:      	movl	%r15d, %ebp
      56:      	rorxl	$0x15, %ebp, %r15d
      5c:      	shll	$0x10, %r14d
      60:      	xorl	%r15d, %r14d
      63:      	movzwl	%r12w, %r15d
      67:      	shll	$0x18, %r10d
      6b:      	orl	%r10d, %r9d
      6e:      	xorl	%r15d, %r9d
      71:      	xorl	%r14d, %r9d
      74:      	xorl	%ebx, %r9d
      77:      	shll	$0x1d, %r11d
      7b:      	sarl	$0x1f, %r11d
      7f:      	shll	$0x8, %edi
      82:      	xorl	%r8d, %edi
      85:      	andl	%r11d, %edi
      88:      	addl	%r9d, %edi
      8b:      	shlq	$0x20, %rdi
      8f:      	movl	%r8d, %r8d
      92:      	addq	%r8, %rax
      95:      	addq	%rdi, %rax
      98:      	shlq	$0x20, %rbx
      9c:      	movl	%ebp, %edi
      9e:      	orq	%rbx, %rdi
      a1:      	movl	%esi, %r8d
      a4:      	andl	$0x7, %r8d
      a8:      	leal	0x1(%r8), %r9d
      ac:      	shlxq	%r9, %rdi, %r9
      b1:      	notb	%r8b
      b4:      	shrxq	%r8, %rdi, %rdi
      b9:      	orq	%r9, %rdi
      bc:      	xorq	%rdi, %rax
      bf:      	incq	%rsi
      c2:      	addq	$0x20, %rdx
      c6:      	cmpq	$0x20, %rsi
      ca:      	je	0x15f <cilium_ct_nat_tuple_rewrite_xdp+0x15f>
      d0:      	movzbl	-0x13(%rdx), %r10d
      d5:      	movzwl	-0x7(%rdx), %edi
      d9:      	movzwl	-0x5(%rdx), %r9d
      de:      	movl	-0x3(%rdx), %r8d
      e2:      	cmpl	$0x6, %r10d
      e6:      	je	0xee <cilium_ct_nat_tuple_rewrite_xdp+0xee>
      e8:      	cmpl	$0x11, %r10d
      ec:      	jne	0x150 <cilium_ct_nat_tuple_rewrite_xdp+0x150>
      ee:      	leaq	-0xb(%rdx), %rbx
      f2:      	leaq	-0xf(%rdx), %r14
      f6:      	movzbl	-0x11(%rdx), %r11d
      fb:      	leaq	-0x1b(%rdx), %r12
      ff:      	leaq	-0x1f(%rdx), %r15
     103:      	movl	%r11d, %ebp
     106:      	andl	$0x1, %ebp
     109:      	cmovnel	%edi, %ebp
     10c:      	cmovneq	%r14, %r15
     110:      	xorw	-0x17(%rdx), %bp
     114:      	movl	(%r15), %r15d
     117:      	movl	%r11d, %r14d
     11a:      	andl	$0x2, %r14d
     11e:      	cmovnel	%edi, %r14d
     122:      	cmovneq	%rbx, %r12
     126:      	xorw	-0x15(%rdx), %r14w
     12b:      	movl	(%r12), %ebx
     12f:      	testb	$0x1, -0x12(%rdx)
     133:      	jne	0x50 <cilium_ct_nat_tuple_rewrite_xdp+0x50>
     139:      	movl	%r14d, %r12d
     13c:      	movl	%ebp, %r14d
     13f:      	movl	%ebx, %ebp
     141:      	movl	%r15d, %ebx
     144:      	jmp	0x56 <cilium_ct_nat_tuple_rewrite_xdp+0x56>
     149:      	nopl	(%rax)
     150:      	shlq	$0x38, %r10
     154:      	movl	%r8d, %edi
     157:      	orq	%r10, %rdi
     15a:      	jmp	0xbc <cilium_ct_nat_tuple_rewrite_xdp+0xbc>
     15f:      	movq	%rax, (%rcx)
     162:      	movl	$0x2, %eax
     167:      	popq	%rbx
     168:      	popq	%r12
     16a:      	popq	%r14
     16c:      	popq	%r15
     16e:      	popq	%rbp
     16f:      	retq
