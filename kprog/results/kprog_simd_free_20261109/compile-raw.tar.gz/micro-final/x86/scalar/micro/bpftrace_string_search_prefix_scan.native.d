/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/bpftrace_string_search_prefix_scan.native.so: \
  bpftrace_string_search_prefix_scan.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/kernel_offsets.h:
