
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/flow_record_field_scan.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <flow_record_field_scan_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rsi
       7:      	movq	%rcx, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rsi, %rdx
       f:      	jbe	0x12 <flow_record_field_scan_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rdx), %rdi
      16:      	cmpq	%rsi, %rdi
      19:      	ja	0x11 <flow_record_field_scan_xdp+0x11>
      1b:      	leaq	0x410(%rdx), %r8
      22:      	cmpq	%rsi, %r8
      25:      	ja	0x11 <flow_record_field_scan_xdp+0x11>
      27:      	cmpl	$0x20, (%rdi)
      2a:      	jne	0x11 <flow_record_field_scan_xdp+0x11>
      2c:      	cmpl	$0x20, 0xc(%rdx)
      30:      	jne	0x11 <flow_record_field_scan_xdp+0x11>
      32:      	pushq	%r14
      34:      	pushq	%rbx
      35:      	movabsq	$-0x61c8864680b583eb, %r8 # imm = 0x9E3779B97F4A7C15
      3f:      	xorl	%eax, %eax
      41:      	xorl	%esi, %esi
      43:      	jmp	0x96 <flow_record_field_scan_xdp+0x96>
      45:      	nopw	%cs:(%rax,%rax)
      50:      	movl	%esi, %r8d
      53:      	andb	$0x7, %r8b
      57:      	shrxq	%r8, %r10, %r8
      5c:      	xorq	%r8, %r9
      5f:      	addq	%r11, %r9
      62:      	movl	%eax, %r8d
      65:      	andb	$0x18, %r8b
      69:      	shlxq	%r8, %rdi, %r8
      6e:      	xorq	%r9, %r8
      71:      	andb	$0x7, %dil
      75:      	leal	0x1(%rdi), %r9d
      79:      	shlxq	%r9, %r8, %rbx
      7e:      	notb	%dil
      81:      	shrxq	%rdi, %r8, %r8
      86:      	orq	%rbx, %r8
      89:      	incq	%rsi
      8c:      	addq	$0x8, %rax
      90:      	cmpq	$0x20, %rsi
      94:      	je	0xe8 <flow_record_field_scan_xdp+0xe8>
      96:      	movq	0x20(%rdx,%rax,4), %r10
      9b:      	movq	0x18(%rdx,%rax,4), %rbx
      a0:      	addq	%r10, %rbx
      a3:      	movl	0x28(%rdx,%rax,4), %edi
      a7:      	shlq	$0x20, %rdi
      ab:      	movl	0x2c(%rdx,%rax,4), %r9d
      b0:      	orq	%rdi, %r9
      b3:      	movl	0x10(%rdx,%rax,4), %edi
      b7:      	movq	%rdi, %r11
      ba:      	shlq	$0x10, %r11
      be:      	movzwl	0x14(%rdx,%rax,4), %r14d
      c4:      	orq	%r14, %r11
      c7:      	xorq	%rbx, %r11
      ca:      	addq	%r8, %r11
      cd:      	testb	$0x1, %r14b
      d1:      	je	0x50 <flow_record_field_scan_xdp+0x50>
      d7:      	movzwl	0x16(%rdx,%rax,4), %r8d
      dd:      	addq	%r8, %r9
      e0:      	xorq	%r11, %r9
      e3:      	jmp	0x62 <flow_record_field_scan_xdp+0x62>
      e8:      	movb	%r8b, (%rcx)
      eb:      	movb	%bh, 0x1(%rcx)
      ee:      	movl	%ebx, %eax
      f0:      	shrl	$0x10, %eax
      f3:      	movb	%al, 0x2(%rcx)
      f6:      	movl	%ebx, %eax
      f8:      	shrl	$0x18, %eax
      fb:      	movb	%al, 0x3(%rcx)
      fe:      	movq	%rbx, %rax
     101:      	shrq	$0x20, %rax
     105:      	movb	%al, 0x4(%rcx)
     108:      	movq	%rbx, %rax
     10b:      	shrq	$0x28, %rax
     10f:      	movb	%al, 0x5(%rcx)
     112:      	movq	%rbx, %rax
     115:      	shrq	$0x30, %rax
     119:      	movb	%al, 0x6(%rcx)
     11c:      	shrq	$0x38, %rbx
     120:      	movb	%bl, 0x7(%rcx)
     123:      	movl	$0x2, %eax
     128:      	popq	%rbx
     129:      	popq	%r14
     12b:      	retq
