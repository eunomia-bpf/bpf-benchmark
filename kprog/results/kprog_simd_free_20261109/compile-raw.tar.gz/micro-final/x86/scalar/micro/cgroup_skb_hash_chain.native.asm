
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/cgroup_skb_hash_chain.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <cgroup_skb_hash_chain_prog>:
       0:      	movq	0x50(%rdi), %rsi
       4:      	movq	0xd0(%rdi), %rax
       b:      	cmpq	%rsi, %rax
       e:      	jbe	0x22 <cgroup_skb_hash_chain_prog+0x22>
      10:      	movl	$0xffffffff, 0x30(%rdi) # imm = 0xFFFFFFFF
      17:      	xorl	%eax, %eax
      19:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
      1e:      	movl	%ecx, 0x34(%rdi)
      21:      	retq
      22:      	leaq	0x8(%rax), %rcx
      26:      	cmpq	%rsi, %rcx
      29:      	ja	0x10 <cgroup_skb_hash_chain_prog+0x10>
      2b:      	leaq	0x50(%rax), %rdx
      2f:      	cmpq	%rsi, %rdx
      32:      	ja	0x10 <cgroup_skb_hash_chain_prog+0x10>
      34:      	movq	%rcx, %rsi
      37:      	movq	%rdx, %r8
      3a:      	cmpq	%r8, %rsi
      3d:      	ja	0x10 <cgroup_skb_hash_chain_prog+0x10>
      3f:      	addq	$0x8, %rsi
      43:      	cmpq	%r8, %rsi
      46:      	ja	0x10 <cgroup_skb_hash_chain_prog+0x10>
      48:      	cmpl	$0x10, 0x8(%rax)
      4c:      	jne	0x10 <cgroup_skb_hash_chain_prog+0x10>
      4e:      	cmpl	$0x8, 0xc(%rax)
      52:      	jne	0x10 <cgroup_skb_hash_chain_prog+0x10>
      54:      	leaq	0x8(%rcx), %rsi
      58:      	cmpq	%rdx, %rsi
      5b:      	ja	0x10 <cgroup_skb_hash_chain_prog+0x10>
      5d:      	addq	$0x48, %rcx
      61:      	cmpq	%rdx, %rcx
      64:      	ja	0x10 <cgroup_skb_hash_chain_prog+0x10>
      66:      	pushq	%rbp
      67:      	pushq	%r15
      69:      	pushq	%r14
      6b:      	pushq	%r13
      6d:      	pushq	%r12
      6f:      	pushq	%rbx
      70:      	movabsq	$-0x61c8864680b583eb, %r13 # imm = 0x9E3779B97F4A7C15
      7a:      	movabsq	$0x100000001b3, %rsi    # imm = 0x100000001B3
      84:      	movq	0x10(%rax), %r8
      88:      	movq	0x18(%rax), %r9
      8c:      	movq	0x20(%rax), %r10
      90:      	movq	0x28(%rax), %r11
      94:      	movq	0x30(%rax), %rbx
      98:      	movq	0x38(%rax), %r14
      9c:      	movq	0x40(%rax), %r15
      a0:      	movq	0x48(%rax), %r12
      a4:      	movabsq	$-0x340d631b7bdddcdb, %rcx # imm = 0xCBF29CE484222325
      ae:      	movl	$0x3e, %eax
      b3:      	nopw	%cs:(%rax,%rax)
      c0:      	movq	%r13, %rdx
      c3:      	movabsq	$-0x2ecbdabc217d106b, %rbp # imm = 0xD1342543DE82EF95
      cd:      	xorq	%rbp, %rdx
      d0:      	addq	%r8, %rdx
      d3:      	xorq	%rcx, %rdx
      d6:      	leal	-0x37(%rax), %ecx
      d9:      	rolq	%cl, %rdx
      dc:      	imulq	%rsi, %rdx
      e0:      	movq	%r13, %rcx
      e3:      	movabsq	$-0x5d97b57842fa20d6, %rbp # imm = 0xA2684A87BD05DF2A
      ed:      	xorq	%rbp, %rcx
      f0:      	addq	%r9, %rcx
      f3:      	xorq	%rdx, %rcx
      f6:      	shrq	$0x1d, %rdx
      fa:      	xorq	%rcx, %rdx
      fd:      	leal	-0x2c(%rax), %ecx
     100:      	rolq	%cl, %rdx
     103:      	imulq	%rsi, %rdx
     107:      	movq	%r13, %rcx
     10a:      	movabsq	$0x739c6fcb9b88cebf, %rbp # imm = 0x739C6FCB9B88CEBF
     114:      	xorq	%rbp, %rcx
     117:      	addq	%r10, %rcx
     11a:      	xorq	%rdx, %rcx
     11d:      	shrq	$0x1d, %rdx
     121:      	xorq	%rcx, %rdx
     124:      	leal	-0x21(%rax), %ecx
     127:      	rolq	%cl, %rdx
     12a:      	imulq	%rsi, %rdx
     12e:      	movq	%r13, %rcx
     131:      	movabsq	$0x44d0950f7a0bbe54, %rbp # imm = 0x44D0950F7A0BBE54
     13b:      	xorq	%rbp, %rcx
     13e:      	addq	%r11, %rcx
     141:      	xorq	%rdx, %rcx
     144:      	shrq	$0x1d, %rdx
     148:      	xorq	%rcx, %rdx
     14b:      	leal	-0x16(%rax), %ecx
     14e:      	rolq	%cl, %rdx
     151:      	imulq	%rsi, %rdx
     155:      	movq	%r13, %rcx
     158:      	movabsq	$0x1604ba53588eade9, %rbp # imm = 0x1604BA53588EADE9
     162:      	xorq	%rbp, %rcx
     165:      	addq	%rbx, %rcx
     168:      	xorq	%rdx, %rcx
     16b:      	shrq	$0x1d, %rdx
     16f:      	xorq	%rcx, %rdx
     172:      	leal	-0xb(%rax), %ecx
     175:      	rolq	%cl, %rdx
     178:      	imulq	%rsi, %rdx
     17c:      	movq	%r13, %rcx
     17f:      	movabsq	$-0x18c72068c8ee6282, %rbp # imm = 0xE738DF9737119D7E
     189:      	xorq	%rbp, %rcx
     18c:      	addq	%r14, %rcx
     18f:      	xorq	%rdx, %rcx
     192:      	shrq	$0x1d, %rdx
     196:      	xorq	%rcx, %rdx
     199:      	movl	%eax, %ecx
     19b:      	rolq	%cl, %rdx
     19e:      	imulq	%rsi, %rdx
     1a2:      	movq	%r13, %rcx
     1a5:      	movabsq	$-0x4792fb24ea6b72ed, %rbp # imm = 0xB86D04DB15948D13
     1af:      	xorq	%rbp, %rcx
     1b2:      	addq	%r15, %rcx
     1b5:      	xorq	%rdx, %rcx
     1b8:      	shrq	$0x1d, %rdx
     1bc:      	xorq	%rcx, %rdx
     1bf:      	leal	-0x35(%rax), %ecx
     1c2:      	rolq	%cl, %rdx
     1c5:      	imulq	%rsi, %rdx
     1c9:      	movq	%r13, %rcx
     1cc:      	movabsq	$-0x765ed5e10be88358, %rbp # imm = 0x89A12A1EF4177CA8
     1d6:      	xorq	%rbp, %rcx
     1d9:      	addq	%r12, %rcx
     1dc:      	xorq	%rdx, %rcx
     1df:      	shrq	$0x1d, %rdx
     1e3:      	xorq	%rcx, %rdx
     1e6:      	leal	-0x2a(%rax), %ecx
     1e9:      	rolq	%cl, %rdx
     1ec:      	imulq	%rsi, %rdx
     1f0:      	movq	%rdx, %rcx
     1f3:      	shrq	$0x1d, %rcx
     1f7:      	xorq	%rdx, %rcx
     1fa:      	addq	$0x5, %rax
     1fe:      	movabsq	$-0x61c8864680b583eb, %rdx # imm = 0x9E3779B97F4A7C15
     208:      	addq	%rdx, %r13
     20b:      	cmpq	$0x8e, %rax
     211:      	jne	0xc0 <cgroup_skb_hash_chain_prog+0xc0>
     217:      	movl	%ecx, 0x30(%rdi)
     21a:      	shrq	$0x20, %rcx
     21e:      	movl	$0x1, %eax
     223:      	popq	%rbx
     224:      	popq	%r12
     226:      	popq	%r13
     228:      	popq	%r14
     22a:      	popq	%r15
     22c:      	popq	%rbp
     22d:      	movl	%ecx, 0x34(%rdi)
     230:      	retq
