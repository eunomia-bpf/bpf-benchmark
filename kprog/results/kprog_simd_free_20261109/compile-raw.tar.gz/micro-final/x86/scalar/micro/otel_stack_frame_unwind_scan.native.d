/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/otel_stack_frame_unwind_scan.native.so: \
  otel_stack_frame_unwind_scan.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/kernel_offsets.h:
