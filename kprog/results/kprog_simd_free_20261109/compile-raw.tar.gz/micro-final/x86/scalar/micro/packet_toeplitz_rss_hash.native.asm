
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/packet_toeplitz_rss_hash.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <packet_toeplitz_rss_hash_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rsi
       7:      	movq	%rcx, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rsi, %rdx
       f:      	jbe	0x12 <packet_toeplitz_rss_hash_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rdx), %rdi
      16:      	cmpq	%rsi, %rdi
      19:      	ja	0x11 <packet_toeplitz_rss_hash_xdp+0x11>
      1b:      	leaq	0x3e(%rdx), %rdi
      1f:      	cmpq	%rsi, %rdi
      22:      	ja	0x11 <packet_toeplitz_rss_hash_xdp+0x11>
      24:      	movbew	0x14(%rdx), %si
      2a:      	movzwl	%si, %esi
      2d:      	cmpl	$0x800, %esi            # imm = 0x800
      33:      	jne	0x11 <packet_toeplitz_rss_hash_xdp+0x11>
      35:      	movzbl	0x16(%rdx), %esi
      39:      	andb	$0xf, %sil
      3d:      	cmpb	$0x5, %sil
      41:      	jne	0x11 <packet_toeplitz_rss_hash_xdp+0x11>
      43:      	cmpb	$0x6, 0x1f(%rdx)
      47:      	jne	0x11 <packet_toeplitz_rss_hash_xdp+0x11>
      49:      	pushq	%rbx
      4a:      	leaq	0x1f(%rdx), %rsi
      4e:      	movq	%rdx, %rdi
      51:      	addq	$0x22, %rdi
      55:      	xorl	%eax, %eax
      57:      	xorl	%r8d, %r8d
      5a:      	jmp	0x93 <packet_toeplitz_rss_hash_xdp+0x93>
      5c:      	movl	$0xc2, %ebx
      61:      	nopw	%cs:(%rax,%rax)
      70:      	shlxl	%r9d, %r11d, %r10d
      75:      	movb	$0x8, %r11b
      78:      	subb	%r9b, %r11b
      7b:      	shrxl	%r11d, %ebx, %r11d
      80:      	orl	%r10d, %r11d
      83:      	xorl	%r11d, %eax
      86:      	incl	%r8d
      89:      	cmpl	$0x68, %r8d
      8d:      	je	0x2b8 <packet_toeplitz_rss_hash_xdp+0x2b8>
      93:      	movl	%r8d, %r10d
      96:      	shrl	$0x3, %r10d
      9a:      	cmpl	$0x1f, %r8d
      9e:      	jbe	0xc0 <packet_toeplitz_rss_hash_xdp+0xc0>
      a0:      	cmpl	$0x3f, %r8d
      a4:      	jbe	0xc0 <packet_toeplitz_rss_hash_xdp+0xc0>
      a6:      	cmpl	$0x4f, %r8d
      aa:      	jbe	0xc0 <packet_toeplitz_rss_hash_xdp+0xc0>
      ac:      	movq	%rsi, %r9
      af:      	cmpl	$0x5f, %r8d
      b3:      	ja	0xc6 <packet_toeplitz_rss_hash_xdp+0xc6>
      b5:      	nopw	%cs:(%rax,%rax)
      c0:      	movl	%r10d, %r9d
      c3:      	addq	%rdi, %r9
      c6:      	movzbl	(%r9), %r11d
      ca:      	movl	%r8d, %r9d
      cd:      	andl	$0x7, %r9d
      d1:      	shlxl	%r9d, %r11d, %r11d
      d6:      	testb	%r11b, %r11b
      d9:      	jns	0x86 <packet_toeplitz_rss_hash_xdp+0x86>
      db:      	cmpl	$0x5, %r10d
      df:      	jle	0x110 <packet_toeplitz_rss_hash_xdp+0x110>
      e1:      	cmpl	$0x8, %r10d
      e5:      	jle	0x135 <packet_toeplitz_rss_hash_xdp+0x135>
      e7:      	cmpl	$0xa, %r10d
      eb:      	jg	0x16d <packet_toeplitz_rss_hash_xdp+0x16d>
      f1:      	cmpl	$0x9, %r10d
      f5:      	jne	0x1b4 <packet_toeplitz_rss_hash_xdp+0x1b4>
      fb:      	movl	$0x43, %ebx
     100:      	movl	$0x67253d00, %r11d      # imm = 0x67253D00
     106:      	jmp	0x1f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
     10b:      	nopl	(%rax,%rax)
     110:      	cmpl	$0x2, %r10d
     114:      	jg	0x151 <packet_toeplitz_rss_hash_xdp+0x151>
     116:      	testl	%r10d, %r10d
     119:      	je	0x18d <packet_toeplitz_rss_hash_xdp+0x18d>
     11b:      	cmpl	$0x1, %r10d
     11f:      	jne	0x1ce <packet_toeplitz_rss_hash_xdp+0x1ce>
     125:      	movl	$0x25, %ebx
     12a:      	movl	$0x5a56da00, %r11d      # imm = 0x5A56DA00
     130:      	jmp	0x1f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
     135:      	cmpl	$0x6, %r10d
     139:      	je	0x180 <packet_toeplitz_rss_hash_xdp+0x180>
     13b:      	cmpl	$0x7, %r10d
     13f:      	jne	0x1a7 <packet_toeplitz_rss_hash_xdp+0x1a7>
     141:      	movl	$0x25, %ebx
     146:      	movl	$0xc2416700, %r11d      # imm = 0xC2416700
     14c:      	jmp	0x1f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
     151:      	cmpl	$0x3, %r10d
     155:      	je	0x19a <packet_toeplitz_rss_hash_xdp+0x19a>
     157:      	cmpl	$0x4, %r10d
     15b:      	jne	0x1db <packet_toeplitz_rss_hash_xdp+0x1db>
     15d:      	movl	$0xc2, %ebx
     162:      	movl	$0x255b0e00, %r11d      # imm = 0x255B0E00
     168:      	jmp	0x1f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
     16d:      	cmpl	$0xb, %r10d
     171:      	jne	0x1c1 <packet_toeplitz_rss_hash_xdp+0x1c1>
     173:      	movl	$0x8f, %ebx
     178:      	movl	$0x3d43a300, %r11d      # imm = 0x3D43A300
     17e:      	jmp	0x1f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
     180:      	movl	$0x67, %ebx
     185:      	movl	$0xec24100, %r11d       # imm = 0xEC24100
     18b:      	jmp	0x1f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
     18d:      	movl	$0xda, %ebx
     192:      	movl	$0x6d5a5600, %r11d      # imm = 0x6D5A5600
     198:      	jmp	0x1f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
     19a:      	movl	$0xe, %ebx
     19f:      	movl	$0xda255b00, %r11d      # imm = 0xDA255B00
     1a5:      	jmp	0x1f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
     1a7:      	movl	$0x3d, %ebx
     1ac:      	movl	$0x41672500, %r11d      # imm = 0x41672500
     1b2:      	jmp	0x1f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
     1b4:      	movl	$0xa3, %ebx
     1b9:      	movl	$0x253d4300, %r11d      # imm = 0x253D4300
     1bf:      	jmp	0x1f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
     1c1:      	movl	$0xb0, %ebx
     1c6:      	movl	$0x43a38f00, %r11d      # imm = 0x43A38F00
     1cc:      	jmp	0x1f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
     1ce:      	movl	$0x5b, %ebx
     1d3:      	movl	$0x56da2500, %r11d      # imm = 0x56DA2500
     1d9:      	jmp	0x1f0 <packet_toeplitz_rss_hash_xdp+0x1f0>
     1db:      	movl	$0x41, %ebx
     1e0:      	movl	$0x5b0ec200, %r11d      # imm = 0x5B0EC200
     1e6:      	nopw	%cs:(%rax,%rax)
     1f0:      	orl	%ebx, %r11d
     1f3:      	testl	%r9d, %r9d
     1f6:      	je	0x83 <packet_toeplitz_rss_hash_xdp+0x83>
     1fc:      	movl	$0x25, %ebx
     201:      	cmpl	$0x5, %r10d
     205:      	jle	0x223 <packet_toeplitz_rss_hash_xdp+0x223>
     207:      	cmpl	$0x8, %r10d
     20b:      	jle	0x242 <packet_toeplitz_rss_hash_xdp+0x242>
     20d:      	cmpl	$0xa, %r10d
     211:      	jg	0x276 <packet_toeplitz_rss_hash_xdp+0x276>
     213:      	cmpl	$0x9, %r10d
     217:      	jne	0x290 <packet_toeplitz_rss_hash_xdp+0x290>
     219:      	movl	$0xa3, %ebx
     21e:      	jmp	0x70 <packet_toeplitz_rss_hash_xdp+0x70>
     223:      	cmpl	$0x2, %r10d
     227:      	jg	0x25c <packet_toeplitz_rss_hash_xdp+0x25c>
     229:      	testl	%r10d, %r10d
     22c:      	je	0x70 <packet_toeplitz_rss_hash_xdp+0x70>
     232:      	cmpl	$0x1, %r10d
     236:      	jne	0x2a4 <packet_toeplitz_rss_hash_xdp+0x2a4>
     238:      	movl	$0x5b, %ebx
     23d:      	jmp	0x70 <packet_toeplitz_rss_hash_xdp+0x70>
     242:      	cmpl	$0x6, %r10d
     246:      	je	0x70 <packet_toeplitz_rss_hash_xdp+0x70>
     24c:      	cmpl	$0x7, %r10d
     250:      	jne	0x286 <packet_toeplitz_rss_hash_xdp+0x286>
     252:      	movl	$0x3d, %ebx
     257:      	jmp	0x70 <packet_toeplitz_rss_hash_xdp+0x70>
     25c:      	cmpl	$0x3, %r10d
     260:      	je	0x5c <packet_toeplitz_rss_hash_xdp+0x5c>
     266:      	cmpl	$0x4, %r10d
     26a:      	jne	0x2ae <packet_toeplitz_rss_hash_xdp+0x2ae>
     26c:      	movl	$0x41, %ebx
     271:      	jmp	0x70 <packet_toeplitz_rss_hash_xdp+0x70>
     276:      	cmpl	$0xb, %r10d
     27a:      	jne	0x29a <packet_toeplitz_rss_hash_xdp+0x29a>
     27c:      	movl	$0xb0, %ebx
     281:      	jmp	0x70 <packet_toeplitz_rss_hash_xdp+0x70>
     286:      	movl	$0x43, %ebx
     28b:      	jmp	0x70 <packet_toeplitz_rss_hash_xdp+0x70>
     290:      	movl	$0x8f, %ebx
     295:      	jmp	0x70 <packet_toeplitz_rss_hash_xdp+0x70>
     29a:      	movl	$0xd0, %ebx
     29f:      	jmp	0x70 <packet_toeplitz_rss_hash_xdp+0x70>
     2a4:      	movl	$0xe, %ebx
     2a9:      	jmp	0x70 <packet_toeplitz_rss_hash_xdp+0x70>
     2ae:      	movl	$0x67, %ebx
     2b3:      	jmp	0x70 <packet_toeplitz_rss_hash_xdp+0x70>
     2b8:      	movl	0x26(%rdx), %esi
     2bb:      	movzbl	0x2a(%rdx), %edi
     2bf:      	movzbl	0x2b(%rdx), %r8d
     2c4:      	movzbl	0x2c(%rdx), %r9d
     2c9:      	movzbl	0x2d(%rdx), %r10d
     2ce:      	movq	%rax, %r11
     2d1:      	shlq	$0x20, %r11
     2d5:      	xorl	0x22(%rdx), %esi
     2d8:      	bswapl	%esi
     2da:      	movl	%esi, %edx
     2dc:      	xorl	%eax, %edx
     2de:      	orq	%r11, %rdx
     2e1:      	shlq	$0x38, %rdi
     2e5:      	shlq	$0x30, %r8
     2e9:      	orq	%rdi, %r8
     2ec:      	shlq	$0x28, %r9
     2f0:      	orq	%r8, %r9
     2f3:      	shlq	$0x20, %r10
     2f7:      	orq	%r9, %rsi
     2fa:      	orq	%r10, %rsi
     2fd:      	andl	$0x7, %eax
     300:      	leal	0x1(%rax), %edi
     303:      	shlxq	%rdi, %rsi, %rdi
     308:      	notb	%al
     30a:      	shrxq	%rax, %rsi, %rax
     30f:      	orq	%rdi, %rax
     312:      	xorq	%rdx, %rax
     315:      	movq	%rax, (%rcx)
     318:      	movl	$0x2, %eax
     31d:      	popq	%rbx
     31e:      	retq
