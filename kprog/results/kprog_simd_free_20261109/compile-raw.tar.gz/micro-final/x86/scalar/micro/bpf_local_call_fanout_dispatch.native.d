/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/bpf_local_call_fanout_dispatch.native.so: \
  bpf_local_call_fanout_dispatch.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/kernel_offsets.h:
