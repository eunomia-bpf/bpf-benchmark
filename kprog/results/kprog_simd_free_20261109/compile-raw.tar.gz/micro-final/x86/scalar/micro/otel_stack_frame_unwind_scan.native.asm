
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/otel_stack_frame_unwind_scan.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <otel_stack_frame_unwind_scan_xdp>:
       0:      	movq	(%rdi), %rdx
       3:      	movq	0x8(%rdi), %rcx
       7:      	movq	%rdx, %rsi
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rcx, %rsi
       f:      	jbe	0x12 <otel_stack_frame_unwind_scan_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rsi), %rdi
      16:      	cmpq	%rcx, %rdi
      19:      	ja	0x11 <otel_stack_frame_unwind_scan_xdp+0x11>
      1b:      	leaq	0x250(%rsi), %rdi
      22:      	cmpq	%rcx, %rdi
      25:      	ja	0x11 <otel_stack_frame_unwind_scan_xdp+0x11>
      27:      	cmpl	$0x18, 0x8(%rsi)
      2b:      	jne	0x11 <otel_stack_frame_unwind_scan_xdp+0x11>
      2d:      	cmpl	$0x18, 0xc(%rsi)
      31:      	jne	0x11 <otel_stack_frame_unwind_scan_xdp+0x11>
      33:      	pushq	%rbp
      34:      	pushq	%r15
      36:      	pushq	%r14
      38:      	pushq	%r12
      3a:      	pushq	%rbx
      3b:      	addq	$0x27, %rsi
      3f:      	movabsq	$0x100000000, %rax      # imm = 0x100000000
      49:      	movabsq	$0x589965cc75374cc3, %r9 # imm = 0x589965CC75374CC3
      53:      	xorl	%edi, %edi
      55:      	movl	$0x8, %r8d
      5b:      	jmp	0x7b <otel_stack_frame_unwind_scan_xdp+0x7b>
      5d:      	nopl	(%rax)
      60:      	shlq	$0x30, %rcx
      64:      	orq	%rbx, %rcx
      67:      	xorq	%rcx, %r9
      6a:      	incq	%rdi
      6d:      	addq	$0x18, %rsi
      71:      	cmpq	$0x18, %rdi
      75:      	je	0x183 <otel_stack_frame_unwind_scan_xdp+0x183>
      7b:      	movq	-0x17(%rsi), %rbx
      7f:      	movl	-0xf(%rsi), %ebp
      82:      	movl	-0xb(%rsi), %r14d
      86:      	movzwl	-0x7(%rsi), %r11d
      8b:      	movzwl	-0x5(%rsi), %ecx
      8f:      	movl	-0x3(%rsi), %r10d
      93:      	cmpl	$0x1, %ecx
      96:      	jg	0xc0 <otel_stack_frame_unwind_scan_xdp+0xc0>
      98:      	testl	%ecx, %ecx
      9a:      	je	0xda <otel_stack_frame_unwind_scan_xdp+0xda>
      9c:      	cmpl	$0x1, %ecx
      9f:      	jne	0x60 <otel_stack_frame_unwind_scan_xdp+0x60>
      a1:      	movl	$0x35, %r15d
      a7:      	cmpl	$0x1000, %ebp           # imm = 0x1000
      ad:      	jbe	0xff <otel_stack_frame_unwind_scan_xdp+0xff>
      af:      	jmp	0x60 <otel_stack_frame_unwind_scan_xdp+0x60>
      b1:      	nopw	%cs:(%rax,%rax)
      c0:      	cmpl	$0x2, %ecx
      c3:      	je	0xed <otel_stack_frame_unwind_scan_xdp+0xed>
      c5:      	cmpl	$0x3, %ecx
      c8:      	jne	0x60 <otel_stack_frame_unwind_scan_xdp+0x60>
      ca:      	movl	$0x89, %r15d
      d0:      	cmpl	$0x1000, %ebp           # imm = 0x1000
      d6:      	jbe	0xff <otel_stack_frame_unwind_scan_xdp+0xff>
      d8:      	jmp	0x60 <otel_stack_frame_unwind_scan_xdp+0x60>
      da:      	movl	$0x21, %r15d
      e0:      	cmpl	$0x1000, %ebp           # imm = 0x1000
      e6:      	jbe	0xff <otel_stack_frame_unwind_scan_xdp+0xff>
      e8:      	jmp	0x60 <otel_stack_frame_unwind_scan_xdp+0x60>
      ed:      	movl	$0x55, %r15d
      f3:      	cmpl	$0x1000, %ebp           # imm = 0x1000
      f9:      	ja	0x60 <otel_stack_frame_unwind_scan_xdp+0x60>
      ff:      	cmpl	$0x2001, %r14d          # imm = 0x2001
     106:      	jae	0x60 <otel_stack_frame_unwind_scan_xdp+0x60>
     10c:      	testb	$0x1, %r11b
     110:      	movl	%r14d, %r12d
     113:      	cmovel	%r8d, %r12d
     117:      	addl	%ebp, %r12d
     11a:      	addq	%r12, %rax
     11d:      	movq	%r10, %r12
     120:      	shlq	$0x20, %r12
     124:      	orq	%r12, %r15
     127:      	xorq	%r15, %rbx
     12a:      	xorq	%rax, %rbx
     12d:      	testb	$0x2, %r11b
     131:      	je	0x138 <otel_stack_frame_unwind_scan_xdp+0x138>
     133:      	incb	%cl
     135:      	rolq	%cl, %rbx
     138:      	movl	%r14d, %ecx
     13b:      	shlq	$0x18, %rcx
     13f:      	movl	%ebp, %r14d
     142:      	xorq	%rcx, %r14
     145:      	testb	$0x4, %r11b
     149:      	movl	$0x0, %ecx
     14e:      	cmovneq	%r14, %rcx
     152:      	addq	%rbx, %rcx
     155:      	movl	%edi, %ebx
     157:      	andb	$0x7, %bl
     15a:      	leal	0x1(%rbx), %r14d
     15e:      	shlxq	%r14, %rcx, %r14
     163:      	notb	%bl
     165:      	shrxq	%rbx, %rcx, %rcx
     16a:      	orq	%r14, %rcx
     16d:      	addq	%r9, %rcx
     170:      	movzwl	%r11w, %r9d
     174:      	shlq	$0x28, %r9
     178:      	orq	%r9, %r10
     17b:      	movq	%r10, %r9
     17e:      	jmp	0x67 <otel_stack_frame_unwind_scan_xdp+0x67>
     183:      	movq	%r9, (%rdx)
     186:      	movl	$0x2, %eax
     18b:      	popq	%rbx
     18c:      	popq	%r12
     18e:      	popq	%r14
     190:      	popq	%r15
     192:      	popq	%rbp
     193:      	retq
