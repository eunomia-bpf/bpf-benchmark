/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/packet_record_bounds_window.native.so: \
  packet_record_bounds_window.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/kernel_offsets.h:
