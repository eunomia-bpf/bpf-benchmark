
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/bpftrace_string_search_prefix_scan.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <bpftrace_string_search_prefix_scan_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rsi
       7:      	movq	%rcx, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rsi, %rdx
       f:      	ja	0x1ca <bpftrace_string_search_prefix_scan_xdp+0x1ca>
      15:      	leaq	0x8(%rdx), %rdi
      19:      	cmpq	%rsi, %rdi
      1c:      	ja	0x1ca <bpftrace_string_search_prefix_scan_xdp+0x1ca>
      22:      	leaq	0x78(%rdx), %rdi
      26:      	cmpq	%rsi, %rdi
      29:      	ja	0x1ca <bpftrace_string_search_prefix_scan_xdp+0x1ca>
      2f:      	pushq	%rbp
      30:      	pushq	%rbx
      31:      	movl	0x8(%rdx), %r8d
      35:      	movzbl	0x70(%rdx), %esi
      39:      	xorl	%eax, %eax
      3b:      	movl	$0x0, %r9d
      41:      	testb	%sil, %sil
      44:      	je	0xa8 <bpftrace_string_search_prefix_scan_xdp+0xa8>
      46:      	cmpb	$0x0, 0x71(%rdx)
      4a:      	je	0x7a <bpftrace_string_search_prefix_scan_xdp+0x7a>
      4c:      	cmpb	$0x0, 0x72(%rdx)
      50:      	je	0x82 <bpftrace_string_search_prefix_scan_xdp+0x82>
      52:      	cmpb	$0x0, 0x73(%rdx)
      56:      	je	0x8a <bpftrace_string_search_prefix_scan_xdp+0x8a>
      58:      	cmpb	$0x0, 0x74(%rdx)
      5c:      	je	0x92 <bpftrace_string_search_prefix_scan_xdp+0x92>
      5e:      	cmpb	$0x0, 0x75(%rdx)
      62:      	je	0x9a <bpftrace_string_search_prefix_scan_xdp+0x9a>
      64:      	cmpb	$0x0, 0x76(%rdx)
      68:      	je	0xa2 <bpftrace_string_search_prefix_scan_xdp+0xa2>
      6a:      	cmpb	$0x1, 0x77(%rdx)
      6e:      	movl	$0x8, %r9d
      74:      	sbbl	$0x0, %r9d
      78:      	jmp	0xa8 <bpftrace_string_search_prefix_scan_xdp+0xa8>
      7a:      	movl	$0x1, %r9d
      80:      	jmp	0xa8 <bpftrace_string_search_prefix_scan_xdp+0xa8>
      82:      	movl	$0x2, %r9d
      88:      	jmp	0xa8 <bpftrace_string_search_prefix_scan_xdp+0xa8>
      8a:      	movl	$0x3, %r9d
      90:      	jmp	0xa8 <bpftrace_string_search_prefix_scan_xdp+0xa8>
      92:      	movl	$0x4, %r9d
      98:      	jmp	0xa8 <bpftrace_string_search_prefix_scan_xdp+0xa8>
      9a:      	movl	$0x5, %r9d
      a0:      	jmp	0xa8 <bpftrace_string_search_prefix_scan_xdp+0xa8>
      a2:      	movl	$0x6, %r9d
      a8:      	cmpl	$0x60, %r8d
      ac:      	ja	0x1c8 <bpftrace_string_search_prefix_scan_xdp+0x1c8>
      b2:      	movl	0xc(%rdx), %edi
      b5:      	cmpl	%r9d, %edi
      b8:      	jne	0x1c8 <bpftrace_string_search_prefix_scan_xdp+0x1c8>
      be:      	testb	%sil, %sil
      c1:      	je	0x1c8 <bpftrace_string_search_prefix_scan_xdp+0x1c8>
      c7:      	movabsq	$0x4f82338baed89116, %rax # imm = 0x4F82338BAED89116
      d1:      	movl	%r8d, %r10d
      d4:      	leal	0x3(%rdi), %r11d
      d8:      	movabsq	$-0x2e4ab5cd2e6d12fd, %r8 # imm = 0xD1B54A32D192ED03
      e2:      	addq	%r11, %r8
      e5:      	xorl	%r9d, %r9d
      e8:      	jmp	0x108 <bpftrace_string_search_prefix_scan_xdp+0x108>
      ea:      	nopw	(%rax,%rax)
      f0:      	testb	%bl, %bl
      f2:      	je	0x1a7 <bpftrace_string_search_prefix_scan_xdp+0x1a7>
      f8:      	incq	%r9
      fb:      	addq	%r11, %r8
      fe:      	cmpq	$0x59, %r9
     102:      	je	0x1c0 <bpftrace_string_search_prefix_scan_xdp+0x1c0>
     108:      	leaq	(%rdi,%r9), %rbx
     10c:      	cmpq	%r10, %rbx
     10f:      	ja	0xf8 <bpftrace_string_search_prefix_scan_xdp+0xf8>
     111:      	testq	%rdi, %rdi
     114:      	je	0x1a7 <bpftrace_string_search_prefix_scan_xdp+0x1a7>
     11a:      	movzbl	0x10(%rdx,%r9), %ebx
     120:      	xorb	%sil, %bl
     123:      	cmpl	$0x2, %edi
     126:      	jb	0xf0 <bpftrace_string_search_prefix_scan_xdp+0xf0>
     128:      	movzbl	0x71(%rdx), %ebp
     12c:      	xorb	0x11(%rdx,%r9), %bpl
     131:      	orb	%bpl, %bl
     134:      	cmpl	$0x3, %edi
     137:      	jb	0xf0 <bpftrace_string_search_prefix_scan_xdp+0xf0>
     139:      	movzbl	0x72(%rdx), %ebp
     13d:      	xorb	0x12(%rdx,%r9), %bpl
     142:      	orb	%bpl, %bl
     145:      	cmpl	$0x4, %edi
     148:      	jb	0xf0 <bpftrace_string_search_prefix_scan_xdp+0xf0>
     14a:      	movzbl	0x73(%rdx), %ebp
     14e:      	xorb	0x13(%rdx,%r9), %bpl
     153:      	orb	%bpl, %bl
     156:      	cmpl	$0x5, %edi
     159:      	jb	0xf0 <bpftrace_string_search_prefix_scan_xdp+0xf0>
     15b:      	movzbl	0x74(%rdx), %ebp
     15f:      	xorb	0x14(%rdx,%r9), %bpl
     164:      	orb	%bpl, %bl
     167:      	cmpl	$0x6, %edi
     16a:      	jb	0xf0 <bpftrace_string_search_prefix_scan_xdp+0xf0>
     16c:      	movzbl	0x75(%rdx), %ebp
     170:      	xorb	0x15(%rdx,%r9), %bpl
     175:      	orb	%bpl, %bl
     178:      	cmpl	$0x7, %edi
     17b:      	jb	0xf0 <bpftrace_string_search_prefix_scan_xdp+0xf0>
     181:      	movzbl	0x76(%rdx), %ebp
     185:      	xorb	0x16(%rdx,%r9), %bpl
     18a:      	orb	%bpl, %bl
     18d:      	cmpl	$0x8, %edi
     190:      	jb	0xf0 <bpftrace_string_search_prefix_scan_xdp+0xf0>
     196:      	movzbl	0x77(%rdx), %ebp
     19a:      	xorb	0x17(%rdx,%r9), %bpl
     19f:      	orb	%bpl, %bl
     1a2:      	jmp	0xf0 <bpftrace_string_search_prefix_scan_xdp+0xf0>
     1a7:      	cmpq	$0x60, %r9
     1ab:      	je	0x1c0 <bpftrace_string_search_prefix_scan_xdp+0x1c0>
     1ad:      	shlq	$0x20, %rdi
     1b1:      	addq	%r9, %rdi
     1b4:      	rorxq	$0x3d, %rdi, %rax
     1ba:      	xorq	%rax, %r8
     1bd:      	movq	%r8, %rax
     1c0:      	movq	%rax, (%rcx)
     1c3:      	movl	$0x2, %eax
     1c8:      	popq	%rbx
     1c9:      	popq	%rbp
     1ca:      	retq
