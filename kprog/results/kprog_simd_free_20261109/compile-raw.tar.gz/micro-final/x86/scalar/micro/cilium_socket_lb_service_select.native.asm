
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/cilium_socket_lb_service_select.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <cilium_socket_lb_service_select_xdp>:
       0:      	movq	(%rdi), %r8
       3:      	movq	0x8(%rdi), %rcx
       7:      	movq	%r8, %rdi
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rcx, %rdi
       f:      	jbe	0x12 <cilium_socket_lb_service_select_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rdi), %rdx
      16:      	cmpq	%rcx, %rdx
      19:      	ja	0x11 <cilium_socket_lb_service_select_xdp+0x11>
      1b:      	leaq	0x610(%rdi), %rdx
      22:      	cmpq	%rcx, %rdx
      25:      	ja	0x11 <cilium_socket_lb_service_select_xdp+0x11>
      27:      	cmpl	$0x40, 0x8(%rdi)
      2b:      	jne	0x11 <cilium_socket_lb_service_select_xdp+0x11>
      2d:      	cmpl	$0x18, 0xc(%rdi)
      31:      	jne	0x11 <cilium_socket_lb_service_select_xdp+0x11>
      33:      	pushq	%rbp
      34:      	pushq	%r15
      36:      	pushq	%r14
      38:      	pushq	%r12
      3a:      	pushq	%rbx
      3b:      	addq	$0x27, %rdi
      3f:      	movabsq	$0x243f6a8885a308d3, %r9 # imm = 0x243F6A8885A308D3
      49:      	xorl	%r10d, %r10d
      4c:      	jmp	0x6e <cilium_socket_lb_service_select_xdp+0x6e>
      4e:      	nop
      50:      	shlq	$0x20, %r11
      54:      	movzwl	%bx, %eax
      57:      	orq	%r11, %rax
      5a:      	xorq	%rax, %r9
      5d:      	incq	%r10
      60:      	addq	$0x18, %rdi
      64:      	cmpq	$0x40, %r10
      68:      	je	0x158 <cilium_socket_lb_service_select_xdp+0x158>
      6e:      	movl	-0x13(%rdi), %eax
      71:      	movzbl	-0xb(%rdi), %r11d
      76:      	cmpq	$0x11, %r11
      7a:      	setne	%cl
      7d:      	cmpq	$0x6, %r11
      81:      	setne	%dl
      84:      	movzwl	-0xd(%rdi), %ebx
      88:      	movzbl	-0xa(%rdi), %r15d
      8d:      	testb	$0x2, %r15b
      91:      	movl	$0x0, %ebp
      96:      	cmovel	%eax, %ebp
      99:      	testb	%cl, %dl
      9b:      	jne	0x50 <cilium_socket_lb_service_select_xdp+0x50>
      9d:      	movzwl	-0x9(%rdi), %r12d
      a2:      	testw	%r12w, %r12w
      a6:      	je	0x50 <cilium_socket_lb_service_select_xdp+0x50>
      a8:      	movzwl	-0xf(%rdi), %ecx
      ac:      	movl	%ecx, %edx
      ae:      	shll	$0x10, %edx
      b1:      	xorl	-0x17(%rdi), %edx
      b4:      	movl	-0x3(%rdi), %r14d
      b8:      	xorl	%ebx, %edx
      ba:      	xorl	-0x7(%rdi), %edx
      bd:      	movswl	%bx, %esi
      c0:      	cmpl	$0x752f, %esi           # imm = 0x752F
      c6:      	jg	0xf0 <cilium_socket_lb_service_select_xdp+0xf0>
      c8:      	movl	%r15d, %esi
      cb:      	andl	$0x2, %esi
      ce:      	jne	0xf0 <cilium_socket_lb_service_select_xdp+0xf0>
      d0:      	movl	%eax, %eax
      d2:      	shlq	$0x10, %rax
      d6:      	movzwl	%cx, %ecx
      d9:      	orq	%rax, %rcx
      dc:      	addq	%rcx, %r9
      df:      	incq	%r10
      e2:      	addq	$0x18, %rdi
      e6:      	cmpq	$0x40, %r10
      ea:      	jne	0x6e <cilium_socket_lb_service_select_xdp+0x6e>
      ec:      	jmp	0x158 <cilium_socket_lb_service_select_xdp+0x158>
      ee:      	nop
      f0:      	xorl	%ebp, %edx
      f2:      	leal	(%r14,%r15), %esi
      f6:      	addl	%edx, %esi
      f8:      	movl	%r11d, %ecx
      fb:      	andl	$0x7, %ecx
      fe:      	incl	%ecx
     100:      	roll	%cl, %esi
     102:      	xorl	%edx, %esi
     104:      	movl	%esi, %eax
     106:      	xorl	%edx, %edx
     108:      	divl	%r12d
     10b:      	incl	%edx
     10d:      	shll	$0x1d, %r15d
     111:      	sarl	$0x1f, %r15d
     115:      	incl	%r14d
     118:      	andl	%r15d, %r14d
     11b:      	xorl	%edx, %r14d
     11e:      	movl	%ebp, %eax
     120:      	shlq	$0x10, %rax
     124:      	movzwl	%bx, %ecx
     127:      	shlq	$0x20, %rcx
     12b:      	xorq	%rax, %rcx
     12e:      	addq	%r11, %r9
     131:      	addq	%rcx, %r9
     134:      	shlq	$0x30, %r14
     138:      	orq	%r14, %rsi
     13b:      	movl	%r10d, %eax
     13e:      	andl	$0x7, %eax
     141:      	leal	0x1(%rax), %ecx
     144:      	shlxq	%rcx, %rsi, %rcx
     149:      	notb	%al
     14b:      	shrxq	%rax, %rsi, %rax
     150:      	orq	%rcx, %rax
     153:      	jmp	0x5a <cilium_socket_lb_service_select_xdp+0x5a>
     158:      	movq	%r9, (%r8)
     15b:      	movl	$0x2, %eax
     160:      	popq	%rbx
     161:      	popq	%r12
     163:      	popq	%r14
     165:      	popq	%r15
     167:      	popq	%rbp
     168:      	retq
