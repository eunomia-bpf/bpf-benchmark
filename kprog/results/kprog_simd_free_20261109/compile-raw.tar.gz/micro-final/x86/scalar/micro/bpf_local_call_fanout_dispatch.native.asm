
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/bpf_local_call_fanout_dispatch.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <bpf_local_call_fanout_dispatch_xdp>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x18, %rsp
       e:      	movq	(%rdi), %rsi
      11:      	movq	0x8(%rdi), %rcx
      15:      	movq	%rsi, %r15
      18:      	xorl	%eax, %eax
      1a:      	cmpq	%rcx, %r15
      1d:      	jbe	0x2e <bpf_local_call_fanout_dispatch_xdp+0x2e>
      1f:      	addq	$0x18, %rsp
      23:      	popq	%rbx
      24:      	popq	%r12
      26:      	popq	%r13
      28:      	popq	%r14
      2a:      	popq	%r15
      2c:      	popq	%rbp
      2d:      	retq
      2e:      	leaq	0x8(%r15), %rdx
      32:      	movq	%rdx, 0x8(%rsp)
      37:      	cmpq	%rcx, %rdx
      3a:      	ja	0x1f <bpf_local_call_fanout_dispatch_xdp+0x1f>
      3c:      	leaq	0x190(%r15), %rdx
      43:      	cmpq	%rcx, %rdx
      46:      	ja	0x1f <bpf_local_call_fanout_dispatch_xdp+0x1f>
      48:      	cmpl	$0x10, 0x8(%r15)
      4d:      	jne	0x1f <bpf_local_call_fanout_dispatch_xdp+0x1f>
      4f:      	cmpl	$0x18, 0xc(%r15)
      54:      	jne	0x1f <bpf_local_call_fanout_dispatch_xdp+0x1f>
      56:      	movq	%rsi, 0x10(%rsp)
      5b:      	movabsq	$0x243f6a8885a308d3, %rdi # imm = 0x243F6A8885A308D3
      65:      	xorl	%r12d, %r12d
      68:      	movl	$0x17, %r13d
      6e:      	xorl	%r14d, %r14d
      71:      	jmp	0xb4 <bpf_local_call_fanout_dispatch_xdp+0xb4>
      73:      	nopw	%cs:(%rax,%rax)
      80:      	movq	0x8(%rsp), %rsi
      85:      	movl	%ebp, %ecx
      87:      	callq	0x170 <local_call_pressure>
      8c:      	movl	%r14d, %ecx
      8f:      	andb	$0x38, %cl
      92:      	shlxq	%rcx, %rbx, %rcx
      97:      	movl	%ebp, %edi
      99:      	addq	%rcx, %rdi
      9c:      	xorq	%rax, %rdi
      9f:      	addq	$0x8, %r14
      a3:      	addl	$0x10, %r12d
      a7:      	addq	$0x18, %r13
      ab:      	cmpq	$0x80, %r14
      b2:      	je	0x111 <bpf_local_call_fanout_dispatch_xdp+0x111>
      b4:      	movzbl	-0x7(%r15,%r13), %ebx
      ba:      	andl	$0x3, %ebx
      bd:      	movl	-0x3(%r15,%r13), %ebp
      c2:      	xorl	%r12d, %ebp
      c5:      	leaq	-0xf(%r13), %rdx
      c9:      	cmpq	$0x2, %rbx
      cd:      	je	0xf0 <bpf_local_call_fanout_dispatch_xdp+0xf0>
      cf:      	cmpl	$0x1, %ebx
      d2:      	je	0x80 <bpf_local_call_fanout_dispatch_xdp+0x80>
      d4:      	testl	%ebx, %ebx
      d6:      	jne	0x100 <bpf_local_call_fanout_dispatch_xdp+0x100>
      d8:      	movq	0x8(%rsp), %rsi
      dd:      	movl	%ebp, %ecx
      df:      	callq	0x130 <local_call_linear>
      e4:      	jmp	0x8c <bpf_local_call_fanout_dispatch_xdp+0x8c>
      e6:      	nopw	%cs:(%rax,%rax)
      f0:      	movq	0x8(%rsp), %rsi
      f5:      	movl	%ebp, %ecx
      f7:      	callq	0x1c0 <local_call_crossload>
      fc:      	jmp	0x8c <bpf_local_call_fanout_dispatch_xdp+0x8c>
      fe:      	nop
     100:      	movq	0x8(%rsp), %rsi
     105:      	movl	%ebp, %ecx
     107:      	callq	0x240 <local_call_bytes>
     10c:      	jmp	0x8c <bpf_local_call_fanout_dispatch_xdp+0x8c>
     111:      	movq	0x10(%rsp), %rax
     116:      	movq	%rdi, (%rax)
     119:      	movl	$0x2, %eax
     11e:      	jmp	0x1f <bpf_local_call_fanout_dispatch_xdp+0x1f>
     123:      	nopw	%cs:(%rax,%rax)

0000000000000130 <local_call_linear>:
     130:      	movl	%edx, %edx
     132:      	movq	0x8(%rdx,%rsi), %rax
     137:      	leaq	(%rax,%rax,2), %r8
     13b:      	movl	%ecx, %r9d
     13e:      	addq	%r9, %rdi
     141:      	addq	%rdi, %r8
     144:      	addq	0x10(%rdx,%rsi), %r8
     149:      	shlq	$0xb, %r9
     14d:      	addq	%r8, %r9
     150:      	andl	$0x7, %ecx
     153:      	leal	0x1(%rcx), %edx
     156:      	shlxq	%rdx, %r9, %rdx
     15b:      	notb	%cl
     15d:      	shrxq	%rcx, %r9, %rcx
     162:      	orq	%rdx, %rcx
     165:      	xorq	%r8, %rcx
     168:      	shrq	$0x3, %rax
     16c:      	addq	%rcx, %rax
     16f:      	retq

0000000000000170 <local_call_pressure>:
     170:      	movl	%edx, %eax
     172:      	movq	0x8(%rax,%rsi), %rdx
     177:      	movq	0x10(%rax,%rsi), %rsi
     17c:      	xorq	%rdx, %rdi
     17f:      	movl	%ecx, %eax
     181:      	shlq	$0x11, %rax
     185:      	addq	%rsi, %rax
     188:      	leaq	(,%rdi,8), %rcx
     190:      	shrq	$0x2, %rsi
     194:      	xorq	%rcx, %rsi
     197:      	xorq	%rax, %rdx
     19a:      	rorxq	$0x3b, %rdx, %rcx
     1a0:      	leaq	(%rsi,%rdi), %rdx
     1a4:      	rorxq	$0x35, %rdx, %rdx
     1aa:      	addq	%rcx, %rdx
     1ad:      	xorq	%rax, %rdi
     1b0:      	shrq	$0x7, %rax
     1b4:      	xorq	%rdx, %rax
     1b7:      	addq	%rsi, %rax
     1ba:      	xorq	%rdi, %rax
     1bd:      	retq
     1be:      	nop

00000000000001c0 <local_call_crossload>:
     1c0:      	movl	%edx, %r11d
     1c3:      	movzbl	(%rsi,%r11), %eax
     1c8:      	leaq	0x4(%r11), %r8
     1cc:      	movzbl	0x4(%rsi,%r11), %edx
     1d2:      	movslq	%r8d, %r10
     1d5:      	movzbl	0x1(%rsi,%r10), %r9d
     1db:      	movzbl	0x2(%rsi,%r10), %r8d
     1e1:      	addq	0x8(%rsi,%r11), %rdi
     1e6:      	movzbl	0x3(%rsi,%r10), %r10d
     1ec:      	movq	0x10(%rsi,%r11), %rsi
     1f1:      	xorq	%rdi, %rsi
     1f4:      	andb	$0x7, %al
     1f6:      	leal	0x1(%rax), %r11d
     1fa:      	shlxq	%r11, %rsi, %r11
     1ff:      	movl	%ecx, %ecx
     201:      	shlxq	%rax, %rcx, %rcx
     206:      	notb	%al
     208:      	shrxq	%rax, %rsi, %rax
     20d:      	orq	%r11, %rax
     210:      	shlq	$0x21, %r10
     214:      	shlq	$0x19, %r8
     218:      	shll	$0x11, %r9d
     21c:      	shll	$0x9, %edx
     21f:      	orl	%r9d, %edx
     222:      	orq	%r8, %rdx
     225:      	orq	%r10, %rdx
     228:      	xorq	%rdi, %rdx
     22b:      	xorq	%rax, %rdx
     22e:      	addq	%rdx, %rcx
     231:      	shrq	$0x5, %rax
     235:      	xorq	%rcx, %rax
     238:      	addq	%rdi, %rax
     23b:      	retq
     23c:      	nopl	(%rax)

0000000000000240 <local_call_bytes>:
     240:      	movl	%ecx, %eax
     242:      	movl	%edx, %ecx
     244:      	movzbl	(%rsi,%rcx), %edx
     248:      	movabsq	$-0x6b2fb644ecceee15, %r8 # imm = 0x94D049BB133111EB
     252:      	xorq	%rdi, %r8
     255:      	xorq	%rdx, %r8
     258:      	addq	%rax, %r8
     25b:      	rorxq	$0x3f, %r8, %rdx
     261:      	movzbl	0x1(%rsi,%rcx), %edi
     266:      	shll	$0x8, %edi
     269:      	xorq	%rdx, %rdi
     26c:      	leaq	(%rax,%rdi), %rdx
     270:      	incq	%rdx
     273:      	rorxq	$0x3e, %rdx, %rdx
     279:      	movzbl	0x2(%rsi,%rcx), %edi
     27e:      	shll	$0x10, %edi
     281:      	xorq	%rdx, %rdi
     284:      	leaq	(%rax,%rdi), %rdx
     288:      	addq	$0x2, %rdx
     28c:      	rorxq	$0x3d, %rdx, %rdx
     292:      	movzbl	0x3(%rsi,%rcx), %edi
     297:      	shll	$0x18, %edi
     29a:      	xorq	%rdx, %rdi
     29d:      	leaq	(%rax,%rdi), %rdx
     2a1:      	addq	$0x3, %rdx
     2a5:      	rorxq	$0x3c, %rdx, %rdx
     2ab:      	movzbl	0x4(%rsi,%rcx), %edi
     2b0:      	shlq	$0x20, %rdi
     2b4:      	xorq	%rdx, %rdi
     2b7:      	leaq	(%rax,%rdi), %rdx
     2bb:      	addq	$0x4, %rdx
     2bf:      	rorxq	$0x3b, %rdx, %rdx
     2c5:      	movzbl	0x5(%rsi,%rcx), %edi
     2ca:      	shlq	$0x28, %rdi
     2ce:      	xorq	%rdx, %rdi
     2d1:      	leaq	(%rax,%rdi), %rdx
     2d5:      	addq	$0x5, %rdx
     2d9:      	rorxq	$0x3a, %rdx, %rdx
     2df:      	movzbl	0x6(%rsi,%rcx), %edi
     2e4:      	shlq	$0x30, %rdi
     2e8:      	xorq	%rdx, %rdi
     2eb:      	leaq	(%rax,%rdi), %rdx
     2ef:      	addq	$0x6, %rdx
     2f3:      	rorxq	$0x39, %rdx, %rdx
     2f9:      	movzbl	0x7(%rsi,%rcx), %edi
     2fe:      	shlq	$0x38, %rdi
     302:      	xorq	%rdx, %rdi
     305:      	addq	%rdi, %rax
     308:      	addq	$0x7, %rax
     30c:      	rorxq	$0x38, %rax, %rax
     312:      	addq	0x8(%rsi,%rcx), %rax
     317:      	xorq	0x10(%rsi,%rcx), %rax
     31c:      	retq
