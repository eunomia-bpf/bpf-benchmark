
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/payload_prefix_memcmp_scan.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <payload_prefix_memcmp_scan_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rsi
       7:      	movq	%rcx, %rdx
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rsi, %rdx
       f:      	jbe	0x12 <payload_prefix_memcmp_scan_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rdx), %rdi
      16:      	cmpq	%rsi, %rdi
      19:      	ja	0x11 <payload_prefix_memcmp_scan_xdp+0x11>
      1b:      	leaq	0xcc(%rdx), %r8
      22:      	cmpq	%rsi, %r8
      25:      	ja	0x11 <payload_prefix_memcmp_scan_xdp+0x11>
      27:      	cmpl	$0x3, (%rdi)
      2a:      	jne	0x11 <payload_prefix_memcmp_scan_xdp+0x11>
      2c:      	movl	$0x57, %r8d
      32:      	movl	$0xc, %r9d
      38:      	xorl	%eax, %eax
      3a:      	nopw	(%rax,%rax)
      40:      	movzbl	0xc(%rdx,%rax), %esi
      45:      	leal	-0x57(%r8), %r10d
      49:      	leal	-0xc(%r9), %edi
      4d:      	xorl	%r10d, %edi
      50:      	xorl	$0xa5, %edi
      56:      	addl	$0x11, %edi
      59:      	cmpb	%dil, %sil
      5c:      	jne	0xd9 <payload_prefix_memcmp_scan_xdp+0xd9>
      5e:      	movzbl	0xd(%rdx,%rax), %esi
      63:      	leal	-0x3a(%r8), %r10d
      67:      	leal	-0x8(%r9), %edi
      6b:      	xorl	%r10d, %edi
      6e:      	xorl	$0xa5, %edi
      74:      	addl	$0x11, %edi
      77:      	cmpb	%dil, %sil
      7a:      	jne	0xde <payload_prefix_memcmp_scan_xdp+0xde>
      7c:      	movzbl	0xe(%rdx,%rax), %esi
      81:      	leal	-0x1d(%r8), %r10d
      85:      	leal	-0x4(%r9), %edi
      89:      	xorl	%r10d, %edi
      8c:      	xorl	$0xa5, %edi
      92:      	addl	$0x11, %edi
      95:      	cmpb	%dil, %sil
      98:      	jne	0xe4 <payload_prefix_memcmp_scan_xdp+0xe4>
      9a:      	movzbl	0xf(%rdx,%rax), %esi
      9f:      	movl	%r9d, %edi
      a2:      	xorl	%r8d, %edi
      a5:      	xorl	$0xa5, %edi
      ab:      	addl	$0x11, %edi
      ae:      	addq	$0x4, %rax
      b2:      	cmpb	%dil, %sil
      b5:      	jne	0xe8 <payload_prefix_memcmp_scan_xdp+0xe8>
      b7:      	addl	$0x74, %r8d
      bb:      	addl	$0x10, %r9d
      bf:      	cmpq	$0x40, %rax
      c3:      	jne	0x40 <payload_prefix_memcmp_scan_xdp+0x40>
      c9:      	movzbl	0x4b(%rdx), %esi
      cd:      	movabsq	$-0xbc1602173094ae4, %rax # imm = 0xF43E9FDE8CF6B51C
      d7:      	jmp	0x106 <payload_prefix_memcmp_scan_xdp+0x106>
      d9:      	incq	%rax
      dc:      	jmp	0xe8 <payload_prefix_memcmp_scan_xdp+0xe8>
      de:      	addq	$0x2, %rax
      e2:      	jmp	0xe8 <payload_prefix_memcmp_scan_xdp+0xe8>
      e4:      	addq	$0x3, %rax
      e8:      	movl	%eax, %eax
      ea:      	leaq	(%rax,%rax,4), %rax
      ee:      	movabsq	$0x6a09e667f3bcc909, %r8 # imm = 0x6A09E667F3BCC909
      f8:      	addq	%rax, %r8
      fb:      	movzbl	%sil, %esi
      ff:      	xorq	%r8, %rsi
     102:      	movzbl	%dil, %eax
     106:      	addq	%rsi, %rax
     109:      	rorxq	$0x3b, %rax, %rax
     10f:      	movl	$0x57, %r9d
     115:      	movl	$0xc, %r10d
     11b:      	xorl	%esi, %esi
     11d:      	nopl	(%rax)
     120:      	movzbl	0x4c(%rdx,%rsi), %edi
     125:      	leal	-0x57(%r9), %r11d
     129:      	leal	-0xc(%r10), %r8d
     12d:      	xorl	%r11d, %r8d
     130:      	xorl	$0xa5, %r8d
     137:      	addl	$0x11, %r8d
     13b:      	cmpb	%r8b, %dil
     13e:      	jne	0x1d1 <payload_prefix_memcmp_scan_xdp+0x1d1>
     144:      	movzbl	0x4d(%rdx,%rsi), %edi
     149:      	leal	-0x3a(%r9), %r11d
     14d:      	leal	-0x8(%r10), %r8d
     151:      	xorl	%r11d, %r8d
     154:      	xorl	$0xa5, %r8d
     15b:      	addl	$0x11, %r8d
     15f:      	cmpb	%r8b, %dil
     162:      	jne	0x1d6 <payload_prefix_memcmp_scan_xdp+0x1d6>
     164:      	movzbl	0x4e(%rdx,%rsi), %edi
     169:      	leal	-0x1d(%r9), %r11d
     16d:      	leal	-0x4(%r10), %r8d
     171:      	xorl	%r11d, %r8d
     174:      	xorl	$0xa5, %r8d
     17b:      	addl	$0x11, %r8d
     17f:      	cmpb	%r8b, %dil
     182:      	jne	0x1dc <payload_prefix_memcmp_scan_xdp+0x1dc>
     184:      	movzbl	0x4f(%rdx,%rsi), %edi
     189:      	movl	%r10d, %r8d
     18c:      	xorl	%r9d, %r8d
     18f:      	xorl	$0xa5, %r8d
     196:      	addl	$0x11, %r8d
     19a:      	addq	$0x4, %rsi
     19e:      	cmpb	%r8b, %dil
     1a1:      	jne	0x1e0 <payload_prefix_memcmp_scan_xdp+0x1e0>
     1a3:      	addl	$0x74, %r9d
     1a7:      	addl	$0x10, %r10d
     1ab:      	cmpq	$0x40, %rsi
     1af:      	jne	0x120 <payload_prefix_memcmp_scan_xdp+0x120>
     1b5:      	movabsq	$-0x61c8864680b583ea, %rsi # imm = 0x9E3779B97F4A7C16
     1bf:      	xorq	%rsi, %rax
     1c2:      	movzbl	0x8b(%rdx), %esi
     1c9:      	shll	$0x8, %esi
     1cc:      	addq	%rax, %rsi
     1cf:      	jmp	0x1fb <payload_prefix_memcmp_scan_xdp+0x1fb>
     1d1:      	incq	%rsi
     1d4:      	jmp	0x1e0 <payload_prefix_memcmp_scan_xdp+0x1e0>
     1d6:      	addq	$0x2, %rsi
     1da:      	jmp	0x1e0 <payload_prefix_memcmp_scan_xdp+0x1e0>
     1dc:      	addq	$0x3, %rsi
     1e0:      	movl	%esi, %esi
     1e2:      	leaq	(%rsi,%rsi,2), %rsi
     1e6:      	leaq	(%rax,%rsi,2), %rax
     1ea:      	movzbl	%dil, %edi
     1ee:      	shll	$0x8, %edi
     1f1:      	xorq	%rax, %rdi
     1f4:      	movzbl	%r8b, %esi
     1f8:      	addq	%rdi, %rsi
     1fb:      	rorxq	$0x3a, %rsi, %rax
     201:      	movl	$0x57, %r9d
     207:      	movl	$0xc, %r10d
     20d:      	xorl	%esi, %esi
     20f:      	nop
     210:      	movzbl	0x8c(%rdx,%rsi), %edi
     218:      	leal	-0x57(%r9), %r11d
     21c:      	leal	-0xc(%r10), %r8d
     220:      	xorl	%r11d, %r8d
     223:      	xorl	$0xa5, %r8d
     22a:      	addl	$0x11, %r8d
     22e:      	cmpb	%r8b, %dil
     231:      	jne	0x2e2 <payload_prefix_memcmp_scan_xdp+0x2e2>
     237:      	movzbl	0x8d(%rdx,%rsi), %edi
     23f:      	leal	-0x3a(%r9), %r11d
     243:      	leal	-0x8(%r10), %r8d
     247:      	xorl	%r11d, %r8d
     24a:      	xorl	$0xa5, %r8d
     251:      	addl	$0x11, %r8d
     255:      	cmpb	%r8b, %dil
     258:      	jne	0x2e7 <payload_prefix_memcmp_scan_xdp+0x2e7>
     25e:      	movzbl	0x8e(%rdx,%rsi), %edi
     266:      	leal	-0x1d(%r9), %r11d
     26a:      	leal	-0x4(%r10), %r8d
     26e:      	xorl	%r11d, %r8d
     271:      	xorl	$0xa5, %r8d
     278:      	addl	$0x11, %r8d
     27c:      	cmpb	%r8b, %dil
     27f:      	jne	0x2ed <payload_prefix_memcmp_scan_xdp+0x2ed>
     281:      	movzbl	0x8f(%rdx,%rsi), %edi
     289:      	movl	%r10d, %r8d
     28c:      	xorl	%r9d, %r8d
     28f:      	xorl	$0xa5, %r8d
     296:      	addl	$0x11, %r8d
     29a:      	addq	$0x4, %rsi
     29e:      	cmpb	%r8b, %dil
     2a1:      	jne	0x2f1 <payload_prefix_memcmp_scan_xdp+0x2f1>
     2a3:      	addl	$0x74, %r9d
     2a7:      	addl	$0x10, %r10d
     2ab:      	cmpq	$0x40, %rsi
     2af:      	jne	0x210 <payload_prefix_memcmp_scan_xdp+0x210>
     2b5:      	movabsq	$-0x61c8864680b583ea, %rsi # imm = 0x9E3779B97F4A7C16
     2bf:      	orq	$0x1, %rsi
     2c3:      	xorq	%rsi, %rax
     2c6:      	movzbl	0xcb(%rdx), %edx
     2cd:      	shll	$0x10, %edx
     2d0:      	addq	%rax, %rdx
     2d3:      	rorxq	$0x39, %rdx, %rax
     2d9:      	movq	%rax, (%rcx)
     2dc:      	movl	$0x2, %eax
     2e1:      	retq
     2e2:      	incq	%rsi
     2e5:      	jmp	0x2f1 <payload_prefix_memcmp_scan_xdp+0x2f1>
     2e7:      	addq	$0x2, %rsi
     2eb:      	jmp	0x2f1 <payload_prefix_memcmp_scan_xdp+0x2f1>
     2ed:      	addq	$0x3, %rsi
     2f1:      	movl	%esi, %edx
     2f3:      	leaq	(,%rdx,8), %rsi
     2fb:      	subq	%rdx, %rsi
     2fe:      	addq	%rsi, %rax
     301:      	movzbl	%dil, %esi
     305:      	shll	$0x10, %esi
     308:      	xorq	%rax, %rsi
     30b:      	movzbl	%r8b, %edx
     30f:      	addq	%rsi, %rdx
     312:      	rorxq	$0x39, %rdx, %rax
     318:      	movq	%rax, (%rcx)
     31b:      	movl	$0x2, %eax
     320:      	retq
