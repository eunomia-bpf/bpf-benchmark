
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/tc_packet_checksum_fold.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <tc_packet_checksum_fold_prog>:
       0:      	movq	0x50(%rdi), %rsi
       4:      	movq	0xd0(%rdi), %rax
       b:      	cmpq	%rsi, %rax
       e:      	jbe	0x25 <tc_packet_checksum_fold_prog+0x25>
      10:      	movl	$0xffffffff, 0x30(%rdi) # imm = 0xFFFFFFFF
      17:      	movl	$0x2, %eax
      1c:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
      21:      	movl	%ecx, 0x34(%rdi)
      24:      	retq
      25:      	leaq	0x8(%rax), %rcx
      29:      	cmpq	%rsi, %rcx
      2c:      	ja	0x10 <tc_packet_checksum_fold_prog+0x10>
      2e:      	leaq	0x410(%rax), %rdx
      35:      	cmpq	%rsi, %rdx
      38:      	ja	0x10 <tc_packet_checksum_fold_prog+0x10>
      3a:      	movq	%rcx, %rsi
      3d:      	movq	%rdx, %r8
      40:      	cmpq	%r8, %rsi
      43:      	ja	0x10 <tc_packet_checksum_fold_prog+0x10>
      45:      	addq	$0x8, %rsi
      49:      	cmpq	%r8, %rsi
      4c:      	ja	0x10 <tc_packet_checksum_fold_prog+0x10>
      4e:      	cmpl	$0x20, 0x8(%rax)
      52:      	jne	0x10 <tc_packet_checksum_fold_prog+0x10>
      54:      	cmpl	$0x200, 0xc(%rax)       # imm = 0x200
      5b:      	jne	0x10 <tc_packet_checksum_fold_prog+0x10>
      5d:      	leaq	0x8(%rcx), %rsi
      61:      	cmpq	%rdx, %rsi
      64:      	ja	0x10 <tc_packet_checksum_fold_prog+0x10>
      66:      	addq	$0x408, %rcx            # imm = 0x408
      6d:      	cmpq	%rdx, %rcx
      70:      	ja	0x10 <tc_packet_checksum_fold_prog+0x10>
      72:      	xorl	%edx, %edx
      74:      	xorl	%ecx, %ecx
      76:      	nopw	%cs:(%rax,%rax)
      80:      	xorl	%esi, %esi
      82:      	xorl	%r8d, %r8d
      85:      	nopw	%cs:(%rax,%rax)
      90:      	movzwl	0x10(%rax,%rsi,2), %r9d
      96:      	addl	%r8d, %r9d
      99:      	movzwl	%r9w, %r8d
      9d:      	shrl	$0x10, %r9d
      a1:      	addl	%r8d, %r9d
      a4:      	movzwl	0x12(%rax,%rsi,2), %r8d
      aa:      	addl	%r9d, %r8d
      ad:      	movzwl	%r8w, %r9d
      b1:      	shrl	$0x10, %r8d
      b5:      	addl	%r9d, %r8d
      b8:      	movzwl	0x14(%rax,%rsi,2), %r9d
      be:      	addl	%r8d, %r9d
      c1:      	movzwl	%r9w, %r8d
      c5:      	shrl	$0x10, %r9d
      c9:      	addl	%r8d, %r9d
      cc:      	movzwl	0x16(%rax,%rsi,2), %r8d
      d2:      	addl	%r9d, %r8d
      d5:      	movzwl	%r8w, %r9d
      d9:      	shrl	$0x10, %r8d
      dd:      	addl	%r9d, %r8d
      e0:      	addq	$0x4, %rsi
      e4:      	cmpq	$0x200, %rsi            # imm = 0x200
      eb:      	jne	0x90 <tc_packet_checksum_fold_prog+0x90>
      ed:      	movl	%r8d, %esi
      f0:      	shrl	$0x10, %esi
      f3:      	addl	%r8d, %esi
      f6:      	notl	%esi
      f8:      	movzwl	%si, %esi
      fb:      	movl	%edx, %r8d
      fe:      	shll	$0x4, %r8d
     102:      	shlxq	%r8, %rsi, %rsi
     107:      	xorq	%rsi, %rcx
     10a:      	incl	%edx
     10c:      	cmpl	$0x20, %edx
     10f:      	jne	0x80 <tc_packet_checksum_fold_prog+0x80>
     115:      	movl	%ecx, 0x30(%rdi)
     118:      	shrq	$0x20, %rcx
     11c:      	xorl	%eax, %eax
     11e:      	movl	%ecx, 0x34(%rdi)
     121:      	retq
