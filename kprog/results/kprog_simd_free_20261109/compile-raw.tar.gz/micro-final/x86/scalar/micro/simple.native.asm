
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/simple.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <simple_xdp>:
       0:      	movq	(%rdi), %rcx
       3:      	movq	0x8(%rdi), %rdx
       7:      	movq	%rcx, %rsi
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rdx, %rsi
       f:      	ja	0x3c <simple_xdp+0x3c>
      11:      	leaq	0x8(%rsi), %rdi
      15:      	cmpq	%rdx, %rdi
      18:      	ja	0x3c <simple_xdp+0x3c>
      1a:      	addq	$0x48, %rsi
      1e:      	cmpq	%rdx, %rsi
      21:      	ja	0x3c <simple_xdp+0x3c>
      23:      	movw	$0x614e, (%rcx)         # imm = 0x614E
      28:      	movb	$-0x44, 0x2(%rcx)
      2c:      	movl	$0x0, 0x3(%rcx)
      33:      	movb	$0x0, 0x7(%rcx)
      37:      	movl	$0x2, %eax
      3c:      	retq
