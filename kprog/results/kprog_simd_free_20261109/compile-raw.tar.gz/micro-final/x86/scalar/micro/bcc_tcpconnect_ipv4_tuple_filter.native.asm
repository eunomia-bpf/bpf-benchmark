
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/micro/bcc_tcpconnect_ipv4_tuple_filter.native.so:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <bcc_tcpconnect_ipv4_tuple_filter_xdp>:
       0:      	movq	(%rdi), %rdx
       3:      	movq	0x8(%rdi), %rcx
       7:      	movq	%rdx, %rsi
       a:      	xorl	%eax, %eax
       c:      	cmpq	%rcx, %rsi
       f:      	jbe	0x12 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x12>
      11:      	retq
      12:      	leaq	0x8(%rsi), %rdi
      16:      	cmpq	%rcx, %rdi
      19:      	ja	0x11 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x11>
      1b:      	leaq	0x310(%rsi), %rdi
      22:      	cmpq	%rcx, %rdi
      25:      	ja	0x11 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x11>
      27:      	cmpl	$0x20, 0x8(%rsi)
      2b:      	jne	0x11 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x11>
      2d:      	cmpl	$0x18, 0xc(%rsi)
      31:      	jne	0x11 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x11>
      33:      	pushq	%rbp
      34:      	pushq	%r15
      36:      	pushq	%r14
      38:      	pushq	%rbx
      39:      	addq	$0x27, %rsi
      3d:      	movabsq	$-0x5f89e29b87429bd1, %rdi # imm = 0xA0761D6478BD642F
      47:      	xorl	%eax, %eax
      49:      	jmp	0x6e <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x6e>
      4b:      	nopl	(%rax,%rax)
      50:      	shlq	$0x30, %r9
      54:      	movl	%r11d, %ecx
      57:      	orq	%r9, %rcx
      5a:      	xorq	%rcx, %rdi
      5d:      	incq	%rax
      60:      	addq	$0x18, %rsi
      64:      	cmpq	$0x20, %rax
      68:      	je	0x1cf <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x1cf>
      6e:      	movzwl	-0x5(%rsi), %ecx
      72:      	cmpl	$0x1f8f, %ecx           # imm = 0x1F8F
      78:      	jg	0xa0 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0xa0>
      7a:      	cmpl	$0x50, %ecx
      7d:      	je	0xf2 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0xf2>
      7f:      	cmpl	$0x1bb, %ecx            # imm = 0x1BB
      85:      	jne	0xc7 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0xc7>
      87:      	movl	$0x2, %r8d
      8d:      	movl	-0x17(%rsi), %r11d
      91:      	movzbl	-0x3(%rsi), %r9d
      96:      	cmpl	$0x2, %r9d
      9a:      	jne	0x50 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x50>
      9c:      	jmp	0x110 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x110>
      9e:      	nop
      a0:      	cmpl	$0x1f90, %ecx           # imm = 0x1F90
      a6:      	je	0xb0 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0xb0>
      a8:      	cmpl	$0x20fb, %ecx           # imm = 0x20FB
      ae:      	jne	0xc7 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0xc7>
      b0:      	movl	$0x3, %r8d
      b6:      	movl	-0x17(%rsi), %r11d
      ba:      	movzbl	-0x3(%rsi), %r9d
      bf:      	cmpl	$0x2, %r9d
      c3:      	jne	0x50 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x50>
      c5:      	jmp	0x110 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x110>
      c7:      	movswl	%cx, %r9d
      cb:      	xorl	%r8d, %r8d
      ce:      	cmpl	$0x7530, %r9d           # imm = 0x7530
      d5:      	setge	%r8b
      d9:      	shll	$0x2, %r8d
      dd:      	movl	-0x17(%rsi), %r11d
      e1:      	movzbl	-0x3(%rsi), %r9d
      e6:      	cmpl	$0x2, %r9d
      ea:      	jne	0x50 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x50>
      f0:      	jmp	0x110 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x110>
      f2:      	movl	$0x1, %r8d
      f8:      	movl	-0x17(%rsi), %r11d
      fc:      	movzbl	-0x3(%rsi), %r9d
     101:      	cmpl	$0x2, %r9d
     105:      	jne	0x50 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x50>
     10b:      	nopl	(%rax,%rax)
     110:      	movl	-0x13(%rsi), %r9d
     114:      	movzbl	-0x2(%rsi), %ebx
     118:      	testb	$0x1, %bl
     11b:      	je	0x1c0 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x1c0>
     121:      	testl	%r8d, %r8d
     124:      	je	0x1c0 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x1c0>
     12a:      	movzbl	-0x7(%rsi), %ebp
     12e:      	movzbl	-0x6(%rsi), %r14d
     133:      	rorxl	$0x19, -0xb(%rsi), %r15d
     13a:      	movzwl	-0x1(%rsi), %r10d
     13f:      	xorl	-0xf(%rsi), %r15d
     143:      	shll	$0x18, %r14d
     147:      	shll	$0x10, %ebp
     14a:      	orl	%r14d, %ebp
     14d:      	movzwl	%cx, %ecx
     150:      	xorl	%ebp, %ecx
     152:      	xorl	%r15d, %ecx
     155:      	movl	%ebx, %ebp
     157:      	shll	$0x1e, %ebp
     15a:      	sarl	$0x1f, %ebp
     15d:      	leal	(%r9,%r11), %r14d
     161:      	andl	%ebp, %r14d
     164:      	xorl	%r10d, %r14d
     167:      	xorl	%ecx, %r14d
     16a:      	leal	0x3(%r8), %ecx
     16e:      	movl	%r14d, %r15d
     171:      	roll	%cl, %r15d
     174:      	testb	$0x4, %bl
     177:      	cmovel	%r14d, %r15d
     17b:      	shlq	$0x20, %r15
     17f:      	movl	%r11d, %ecx
     182:      	orq	%r15, %rcx
     185:      	movl	%eax, %r11d
     188:      	andb	$0x7, %r11b
     18c:      	leal	0x1(%r11), %ebx
     190:      	shlxq	%rbx, %rcx, %rbx
     195:      	notb	%r11b
     198:      	shrxq	%r11, %rcx, %rcx
     19d:      	orq	%rbx, %rcx
     1a0:      	xorq	%rdi, %rcx
     1a3:      	shlq	$0x38, %r8
     1a7:      	shll	$0x10, %r10d
     1ab:      	orq	%r8, %r10
     1ae:      	movl	%r9d, %edi
     1b1:      	xorq	%r10, %rdi
     1b4:      	addq	%rcx, %rdi
     1b7:      	jmp	0x5d <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x5d>
     1bc:      	nopl	(%rax)
     1c0:      	shlq	$0x20, %r9
     1c4:      	orq	%rcx, %r9
     1c7:      	addq	%r9, %rdi
     1ca:      	jmp	0x5d <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x5d>
     1cf:      	movq	%rdi, (%rdx)
     1d2:      	movl	$0x2, %eax
     1d7:      	popq	%rbx
     1d8:      	popq	%r14
     1da:      	popq	%r15
     1dc:      	popq	%rbp
     1dd:      	retq
