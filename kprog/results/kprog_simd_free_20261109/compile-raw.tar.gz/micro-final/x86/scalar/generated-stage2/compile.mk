.PHONY: all
all: /var/tmp/kprog-tmp/S14/micro-final/x86/scalar/generated-stage2/unchecked_packet_read.bpf.o
/var/tmp/kprog-tmp/S14/micro-final/x86/scalar/generated-stage2/unchecked_packet_read.bpf.o: /var/tmp/kprog-tmp/S14/micro-final/x86/scalar/generated-stage2/unchecked_packet_read.bpf.c
	clang-18 -g -O3 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -I/workspaces/repository/vendor/libbpf/include/uapi -I/workspaces/repository/vendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c $< -o $@
