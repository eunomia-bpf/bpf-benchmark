include /var/tmp/kprog-tmp/S14/native-micro.mk
NATIVE_CFLAGS := $(filter-out -shared,$(NATIVE_CFLAGS)) -c 
