/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/tracee_http_method_prefix_detect.native.so: \
  tracee_http_method_prefix_detect.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h:
