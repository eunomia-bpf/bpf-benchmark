/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/katran_lb_consistent_hash_select.native.so: \
  katran_lb_consistent_hash_select.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h:
