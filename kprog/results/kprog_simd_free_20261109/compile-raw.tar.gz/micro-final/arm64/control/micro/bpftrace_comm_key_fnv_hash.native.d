/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/bpftrace_comm_key_fnv_hash.native.so: \
  bpftrace_comm_key_fnv_hash.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h:
