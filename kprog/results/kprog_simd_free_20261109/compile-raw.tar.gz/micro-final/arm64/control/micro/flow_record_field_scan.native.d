/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/flow_record_field_scan.native.so: \
  flow_record_field_scan.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h:
