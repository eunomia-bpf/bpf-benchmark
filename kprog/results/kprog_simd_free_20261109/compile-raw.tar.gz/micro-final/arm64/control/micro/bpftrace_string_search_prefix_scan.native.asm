
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/bpftrace_string_search_prefix_scan.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <bpftrace_string_search_prefix_scan_xdp>:
       0:      	ldp	x8, x10, [x0]
       4:      	mov	x9, x8
       8:      	cmp	x9, x10
       c:      	b.hi	0xb8 <bpftrace_string_search_prefix_scan_xdp+0xb8>
      10:      	add	x11, x9, #0x8
      14:      	add	x12, x9, #0x78
      18:      	cmp	x11, x10
      1c:      	ccmp	x12, x10, #0x2, ls
      20:      	b.hi	0xb8 <bpftrace_string_search_prefix_scan_xdp+0xb8>
      24:      	ldp	w11, w10, [x9, #0x8]
      28:      	ldrb	w12, [x9, #0x70]
      2c:      	cbz	w12, 0x74 <bpftrace_string_search_prefix_scan_xdp+0x74>
      30:      	ldrb	w13, [x9, #0x71]
      34:      	cbz	w13, 0x7c <bpftrace_string_search_prefix_scan_xdp+0x7c>
      38:      	ldrb	w13, [x9, #0x72]
      3c:      	cbz	w13, 0x84 <bpftrace_string_search_prefix_scan_xdp+0x84>
      40:      	ldrb	w13, [x9, #0x73]
      44:      	cbz	w13, 0x8c <bpftrace_string_search_prefix_scan_xdp+0x8c>
      48:      	ldrb	w13, [x9, #0x74]
      4c:      	cbz	w13, 0x94 <bpftrace_string_search_prefix_scan_xdp+0x94>
      50:      	ldrb	w13, [x9, #0x75]
      54:      	cbz	w13, 0x9c <bpftrace_string_search_prefix_scan_xdp+0x9c>
      58:      	ldrb	w13, [x9, #0x76]
      5c:      	cbz	w13, 0xa4 <bpftrace_string_search_prefix_scan_xdp+0xa4>
      60:      	ldrb	w13, [x9, #0x77]
      64:      	cmp	w13, #0x0
      68:      	mov	w13, #0x7               // =7
      6c:      	cinc	w13, w13, ne
      70:      	b	0xa8 <bpftrace_string_search_prefix_scan_xdp+0xa8>
      74:      	mov	w13, wzr
      78:      	b	0xa8 <bpftrace_string_search_prefix_scan_xdp+0xa8>
      7c:      	mov	w13, #0x1               // =1
      80:      	b	0xa8 <bpftrace_string_search_prefix_scan_xdp+0xa8>
      84:      	mov	w13, #0x2               // =2
      88:      	b	0xa8 <bpftrace_string_search_prefix_scan_xdp+0xa8>
      8c:      	mov	w13, #0x3               // =3
      90:      	b	0xa8 <bpftrace_string_search_prefix_scan_xdp+0xa8>
      94:      	mov	w13, #0x4               // =4
      98:      	b	0xa8 <bpftrace_string_search_prefix_scan_xdp+0xa8>
      9c:      	mov	w13, #0x5               // =5
      a0:      	b	0xa8 <bpftrace_string_search_prefix_scan_xdp+0xa8>
      a4:      	mov	w13, #0x6               // =6
      a8:      	cmp	w11, #0x60
      ac:      	ccmp	w10, w13, #0x0, ls
      b0:      	ccmp	w12, #0x0, #0x4, eq
      b4:      	b.ne	0xc0 <bpftrace_string_search_prefix_scan_xdp+0xc0>
      b8:      	mov	w0, wzr
      bc:      	ret
      c0:      	mov	x15, #0xed03            // =60675
      c4:      	mov	x13, #0x9116            // =37142
      c8:      	add	w17, w10, #0x3
      cc:      	mov	x14, xzr
      d0:      	add	x16, x9, #0x10
      d4:      	movk	x15, #0xd192, lsl #16
      d8:      	movk	x13, #0xaed8, lsl #16
      dc:      	movk	x15, #0x4a32, lsl #32
      e0:      	movk	x13, #0x338b, lsl #32
      e4:      	movk	x15, #0xd1b5, lsl #48
      e8:      	movk	x13, #0x4f82, lsl #48
      ec:      	add	x15, x17, x15
      f0:      	b	0x114 <bpftrace_string_search_prefix_scan_xdp+0x114>
      f4:      	nop
      f8:      	nop
      fc:      	nop
     100:      	cbz	w18, 0x1e8 <bpftrace_string_search_prefix_scan_xdp+0x1e8>
     104:      	add	x14, x14, #0x1
     108:      	add	x15, x15, x17
     10c:      	cmp	x14, #0x59
     110:      	b.eq	0x1f8 <bpftrace_string_search_prefix_scan_xdp+0x1f8>
     114:      	add	x18, x10, x14
     118:      	cmp	x18, x11
     11c:      	b.hi	0x104 <bpftrace_string_search_prefix_scan_xdp+0x104>
     120:      	cbz	w10, 0x1e8 <bpftrace_string_search_prefix_scan_xdp+0x1e8>
     124:      	ldrb	w18, [x16, x14]
     128:      	cmp	w10, #0x2
     12c:      	eor	w18, w12, w18
     130:      	b.lo	0x100 <bpftrace_string_search_prefix_scan_xdp+0x100>
     134:      	add	x0, x16, x14
     138:      	ldrb	w2, [x9, #0x71]
     13c:      	cmp	w10, #0x3
     140:      	ldrb	w1, [x0, #0x1]
     144:      	eor	w1, w2, w1
     148:      	orr	w18, w18, w1
     14c:      	b.lo	0x100 <bpftrace_string_search_prefix_scan_xdp+0x100>
     150:      	ldrb	w0, [x0, #0x2]
     154:      	ldrb	w1, [x9, #0x72]
     158:      	cmp	w10, #0x4
     15c:      	eor	w0, w1, w0
     160:      	orr	w18, w18, w0
     164:      	b.lo	0x100 <bpftrace_string_search_prefix_scan_xdp+0x100>
     168:      	add	x0, x16, x14
     16c:      	ldrb	w2, [x9, #0x73]
     170:      	cmp	w10, #0x5
     174:      	ldrb	w1, [x0, #0x3]
     178:      	eor	w1, w2, w1
     17c:      	orr	w18, w18, w1
     180:      	b.lo	0x100 <bpftrace_string_search_prefix_scan_xdp+0x100>
     184:      	ldrb	w0, [x0, #0x4]
     188:      	ldrb	w1, [x9, #0x74]
     18c:      	cmp	w10, #0x6
     190:      	eor	w0, w1, w0
     194:      	orr	w18, w18, w0
     198:      	b.lo	0x100 <bpftrace_string_search_prefix_scan_xdp+0x100>
     19c:      	add	x0, x16, x14
     1a0:      	ldrb	w2, [x9, #0x75]
     1a4:      	cmp	w10, #0x7
     1a8:      	ldrb	w1, [x0, #0x5]
     1ac:      	eor	w1, w2, w1
     1b0:      	orr	w18, w18, w1
     1b4:      	b.lo	0x100 <bpftrace_string_search_prefix_scan_xdp+0x100>
     1b8:      	ldrb	w0, [x0, #0x6]
     1bc:      	ldrb	w1, [x9, #0x76]
     1c0:      	cmp	w10, #0x8
     1c4:      	eor	w0, w1, w0
     1c8:      	orr	w18, w18, w0
     1cc:      	b.lo	0x100 <bpftrace_string_search_prefix_scan_xdp+0x100>
     1d0:      	add	x0, x16, x14
     1d4:      	ldrb	w1, [x9, #0x77]
     1d8:      	ldrb	w0, [x0, #0x7]
     1dc:      	eor	w0, w1, w0
     1e0:      	orr	w18, w18, w0
     1e4:      	b	0x100 <bpftrace_string_search_prefix_scan_xdp+0x100>
     1e8:      	cmp	x14, #0x60
     1ec:      	b.eq	0x1f8 <bpftrace_string_search_prefix_scan_xdp+0x1f8>
     1f0:      	add	x9, x14, x10, lsl #32
     1f4:      	eor	x13, x15, x9, ror #61
     1f8:      	mov	w0, #0x2                // =2
     1fc:      	str	x13, [x8]
     200:      	ret
