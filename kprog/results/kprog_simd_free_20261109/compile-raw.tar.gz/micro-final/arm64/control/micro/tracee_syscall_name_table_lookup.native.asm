
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/tracee_syscall_name_table_lookup.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <tracee_syscall_name_table_lookup_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x11, x8
       8:      	cmp	x11, x9
       c:      	b.hi	0x138 <tracee_syscall_name_table_lookup_xdp+0x138>
      10:      	add	x10, x11, #0x8
      14:      	add	x12, x11, #0x10c
      18:      	cmp	x10, x9
      1c:      	ccmp	x12, x9, #0x2, ls
      20:      	b.hi	0x138 <tracee_syscall_name_table_lookup_xdp+0x138>
      24:      	ldr	w9, [x10]
      28:      	cmp	w9, #0x40
      2c:      	b.ne	0x138 <tracee_syscall_name_table_lookup_xdp+0x138>
      30:      	str	x25, [sp, #-0x40]!
      34:      	stp	x24, x23, [sp, #0x10]
      38:      	stp	x22, x21, [sp, #0x20]
      3c:      	stp	x20, x19, [sp, #0x30]
      40:      	mov	x12, #0xc909            // =51465
      44:      	mov	x0, #0xca87             // =51847
      48:      	mov	x3, #0x7261             // =29281
      4c:      	mov	x7, #0x6e75             // =28277
      50:      	mov	x19, #0x7473            // =29811
      54:      	mov	x20, #0x6973            // =26995
      58:      	mov	x13, #0x7277            // =29303
      5c:      	mov	x14, #0x6c63            // =27747
      60:      	movk	x12, #0xf3bc, lsl #16
      64:      	mov	x15, #0x7467            // =29799
      68:      	mov	x16, #0x6355            // =25429
      6c:      	mov	x17, #0x7865            // =30821
      70:      	mov	x18, #0x7755            // =30549
      74:      	movk	x0, #0x85eb, lsl #16
      78:      	mov	x1, #0x6e75             // =28277
      7c:      	mov	x2, #0x6c55             // =27733
      80:      	movk	x3, #0x6863, lsl #16
      84:      	mov	x4, #0x6655             // =26197
      88:      	mov	x5, #0x6567             // =25959
      8c:      	mov	x6, #0x706f             // =28783
      90:      	movk	x7, #0x696c, lsl #16
      94:      	movk	x19, #0x7461, lsl #16
      98:      	movk	x20, #0x6e67, lsl #16
      9c:      	mov	w10, #0x626b            // =25195
      a0:      	movk	x12, #0xe667, lsl #32
      a4:      	movk	x13, #0x7469, lsl #16
      a8:      	movk	x14, #0x736f, lsl #16
      ac:      	movk	x15, #0x6970, lsl #16
      b0:      	movk	x16, #0x6f6c, lsl #16
      b4:      	movk	x17, #0x6365, lsl #16
      b8:      	movk	x18, #0x6961, lsl #16
      bc:      	movk	x0, #0x79b1, lsl #32
      c0:      	movk	x1, #0x696c, lsl #16
      c4:      	movk	x2, #0x6e69, lsl #16
      c8:      	movk	x3, #0x635f, lsl #32
      cc:      	movk	x4, #0x7475, lsl #16
      d0:      	movk	x5, #0x6174, lsl #16
      d4:      	movk	x6, #0x6e65, lsl #16
      d8:      	movk	x7, #0x6b6e, lsl #32
      dc:      	movk	x19, #0x6132, lsl #32
      e0:      	movk	x20, #0x6665, lsl #32
      e4:      	mov	x9, xzr
      e8:      	movk	w10, #0x6b72, lsl #16
      ec:      	add	x11, x11, #0xf
      f0:      	movk	x12, #0x6a09, lsl #48
      f4:      	movk	x13, #0x65, lsl #32
      f8:      	movk	x14, #0x65, lsl #32
      fc:      	movk	x15, #0x64, lsl #32
     100:      	movk	x16, #0x656e, lsl #32
     104:      	movk	x17, #0x6576, lsl #32
     108:      	movk	x18, #0x3474, lsl #32
     10c:      	movk	x0, #0x9e37, lsl #48
     110:      	movk	x1, #0x6b6e, lsl #32
     114:      	movk	x2, #0x6b, lsl #32
     118:      	movk	x3, #0x6c74, lsl #48
     11c:      	movk	x4, #0x7865, lsl #32
     120:      	movk	x5, #0x6464, lsl #32
     124:      	movk	x6, #0x7461, lsl #32
     128:      	movk	x7, #0x7461, lsl #48
     12c:      	movk	x19, #0x74, lsl #48
     130:      	movk	x20, #0x6474, lsl #48
     134:      	b	0x184 <tracee_syscall_name_table_lookup_xdp+0x184>
     138:      	mov	w0, wzr
     13c:      	ret
     140:      	mov	w23, #0x6662            // =26210
     144:      	movk	w23, #0x70, lsl #16
     148:      	eor	x22, x23, x22
     14c:      	and	w23, w9, #0x7
     150:      	add	w24, w23, #0x1
     154:      	eor	w25, w23, #0x3f
     158:      	lsl	x24, x22, x24
     15c:      	lsr	x22, x22, x25
     160:      	orr	x22, x24, x22
     164:      	add	x12, x22, x12
     168:      	lsl	w22, w23, #3
     16c:      	lsl	x21, x21, x22
     170:      	eor	x12, x12, x21
     174:      	add	x9, x9, #0x1
     178:      	add	x11, x11, #0x4
     17c:      	cmp	x9, #0x40
     180:      	b.eq	0x398 <tracee_syscall_name_table_lookup_xdp+0x398>
     184:      	ldurb	w21, [x11, #-0x3]
     188:      	ldurb	w22, [x11, #-0x2]
     18c:      	orr	w22, w21, w22, lsl #8
     190:      	ldurb	w23, [x11, #-0x1]
     194:      	ldrb	w24, [x11]
     198:      	orr	w22, w22, w23, lsl #16
     19c:      	orr	w22, w22, w24, lsl #24
     1a0:      	cmp	w22, #0x4f
     1a4:      	b.gt	0x1e0 <tracee_syscall_name_table_lookup_xdp+0x1e0>
     1a8:      	cmp	w22, #0x26
     1ac:      	b.gt	0x220 <tracee_syscall_name_table_lookup_xdp+0x220>
     1b0:      	cmp	w22, #0x2
     1b4:      	b.gt	0x270 <tracee_syscall_name_table_lookup_xdp+0x270>
     1b8:      	cbz	w22, 0x338 <tracee_syscall_name_table_lookup_xdp+0x338>
     1bc:      	cmp	w22, #0x1
     1c0:      	b.eq	0x2f8 <tracee_syscall_name_table_lookup_xdp+0x2f8>
     1c4:      	cmp	w22, #0x2
     1c8:      	b.ne	0x380 <tracee_syscall_name_table_lookup_xdp+0x380>
     1cc:      	mov	w23, #0x706f            // =28783
     1d0:      	movk	w23, #0x6e65, lsl #16
     1d4:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     1d8:      	nop
     1dc:      	nop
     1e0:      	cmp	w22, #0x100
     1e4:      	b.gt	0x248 <tracee_syscall_name_table_lookup_xdp+0x248>
     1e8:      	cmp	w22, #0x9d
     1ec:      	b.gt	0x294 <tracee_syscall_name_table_lookup_xdp+0x294>
     1f0:      	cmp	w22, #0x50
     1f4:      	b.eq	0x344 <tracee_syscall_name_table_lookup_xdp+0x344>
     1f8:      	cmp	w22, #0x57
     1fc:      	b.eq	0x300 <tracee_syscall_name_table_lookup_xdp+0x300>
     200:      	cmp	w22, #0x59
     204:      	b.ne	0x380 <tracee_syscall_name_table_lookup_xdp+0x380>
     208:      	mov	x23, x2
     20c:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     210:      	nop
     214:      	nop
     218:      	nop
     21c:      	nop
     220:      	cmp	w22, #0x3a
     224:      	b.gt	0x2b4 <tracee_syscall_name_table_lookup_xdp+0x2b4>
     228:      	cmp	w22, #0x27
     22c:      	b.eq	0x350 <tracee_syscall_name_table_lookup_xdp+0x350>
     230:      	cmp	w22, #0x38
     234:      	b.eq	0x308 <tracee_syscall_name_table_lookup_xdp+0x308>
     238:      	cmp	w22, #0x39
     23c:      	b.ne	0x380 <tracee_syscall_name_table_lookup_xdp+0x380>
     240:      	add	x23, x10, #0xcfb
     244:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     248:      	cmp	w22, #0x122
     24c:      	b.gt	0x2d4 <tracee_syscall_name_table_lookup_xdp+0x2d4>
     250:      	cmp	w22, #0x101
     254:      	b.eq	0x358 <tracee_syscall_name_table_lookup_xdp+0x358>
     258:      	cmp	w22, #0x107
     25c:      	b.eq	0x310 <tracee_syscall_name_table_lookup_xdp+0x310>
     260:      	cmp	w22, #0x119
     264:      	b.ne	0x380 <tracee_syscall_name_table_lookup_xdp+0x380>
     268:      	mov	x23, x19
     26c:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     270:      	cmp	w22, #0x3
     274:      	b.eq	0x360 <tracee_syscall_name_table_lookup_xdp+0x360>
     278:      	cmp	w22, #0x9
     27c:      	b.eq	0x318 <tracee_syscall_name_table_lookup_xdp+0x318>
     280:      	mov	w23, #0x626b            // =25195
     284:      	cmp	w22, #0xc
     288:      	movk	w23, #0x6b72, lsl #16
     28c:      	b.eq	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     290:      	b	0x380 <tracee_syscall_name_table_lookup_xdp+0x380>
     294:      	cmp	w22, #0x9e
     298:      	b.eq	0x368 <tracee_syscall_name_table_lookup_xdp+0x368>
     29c:      	cmp	w22, #0xca
     2a0:      	b.eq	0x324 <tracee_syscall_name_table_lookup_xdp+0x324>
     2a4:      	cmp	w22, #0xd9
     2a8:      	b.ne	0x380 <tracee_syscall_name_table_lookup_xdp+0x380>
     2ac:      	mov	x23, x5
     2b0:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     2b4:      	cmp	w22, #0x3b
     2b8:      	b.eq	0x370 <tracee_syscall_name_table_lookup_xdp+0x370>
     2bc:      	cmp	w22, #0x3c
     2c0:      	b.eq	0x32c <tracee_syscall_name_table_lookup_xdp+0x32c>
     2c4:      	cmp	w22, #0x3d
     2c8:      	b.ne	0x380 <tracee_syscall_name_table_lookup_xdp+0x380>
     2cc:      	mov	x23, x18
     2d0:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     2d4:      	cmp	w22, #0x123
     2d8:      	b.eq	0x378 <tracee_syscall_name_table_lookup_xdp+0x378>
     2dc:      	cmp	w22, #0x141
     2e0:      	b.eq	0x140 <tracee_syscall_name_table_lookup_xdp+0x140>
     2e4:      	cmp	w22, #0x14c
     2e8:      	b.ne	0x380 <tracee_syscall_name_table_lookup_xdp+0x380>
     2ec:      	mov	w23, #0x6173            // =24947
     2f0:      	movk	w23, #0x7874, lsl #16
     2f4:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     2f8:      	mov	x23, x13
     2fc:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     300:      	mov	x23, x1
     304:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     308:      	mov	x23, x16
     30c:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     310:      	mov	x23, x7
     314:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     318:      	mov	w23, #0x6d6d            // =28013
     31c:      	movk	w23, #0x7061, lsl #16
     320:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     324:      	mov	x23, x4
     328:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     32c:      	mov	w23, #0x7865            // =30821
     330:      	movk	w23, #0x7469, lsl #16
     334:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     338:      	mov	w23, #0x6164            // =24932
     33c:      	movk	w23, #0x7265, lsl #16
     340:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     344:      	mov	w23, #0x6863            // =26723
     348:      	movk	w23, #0x6964, lsl #16
     34c:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     350:      	mov	x23, x15
     354:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     358:      	mov	x23, x6
     35c:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     360:      	mov	x23, x14
     364:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     368:      	mov	x23, x3
     36c:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     370:      	mov	x23, x17
     374:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     378:      	mov	x23, x20
     37c:      	b	0x148 <tracee_syscall_name_table_lookup_xdp+0x148>
     380:      	mul	x21, x22, x0
     384:      	eor	x12, x21, x12
     388:      	add	x9, x9, #0x1
     38c:      	add	x11, x11, #0x4
     390:      	cmp	x9, #0x40
     394:      	b.ne	0x184 <tracee_syscall_name_table_lookup_xdp+0x184>
     398:      	ldp	x20, x19, [sp, #0x30]
     39c:      	mov	w0, #0x2                // =2
     3a0:      	str	x12, [x8]
     3a4:      	ldp	x22, x21, [sp, #0x20]
     3a8:      	ldp	x24, x23, [sp, #0x10]
     3ac:      	ldr	x25, [sp], #0x40
     3b0:      	ret
