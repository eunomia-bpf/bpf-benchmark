
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/siphash_rotate64_mixer.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <siphash_rotate64_mixer_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x15, x8
       8:      	cmp	x15, x9
       c:      	b.hi	0x24 <siphash_rotate64_mixer_xdp+0x24>
      10:      	add	x10, x15, #0x8
      14:      	add	x11, x15, #0x48
      18:      	cmp	x10, x9
      1c:      	ccmp	x11, x9, #0x2, ls
      20:      	b.ls	0x2c <siphash_rotate64_mixer_xdp+0x2c>
      24:      	mov	w0, wzr
      28:      	ret
      2c:      	ldp	x14, x13, [x15, #0x18]
      30:      	mov	x17, #0x6573            // =25971
      34:      	mov	x18, #0x7261            // =29281
      38:      	mov	x1, #0xead0             // =60112
      3c:      	mov	x0, #0xdfc6             // =57286
      40:      	ldp	x12, x11, [x15, #0x28]
      44:      	movk	x17, #0x7974, lsl #16
      48:      	movk	x18, #0x6e65, lsl #16
      4c:      	movk	x1, #0xc19f, lsl #16
      50:      	ldp	x10, x9, [x15, #0x38]
      54:      	movk	x0, #0xd7de, lsl #16
      58:      	movk	x17, #0x6462, lsl #32
      5c:      	movk	x18, #0x6765, lsl #32
      60:      	ldp	x15, x16, [x15, #0x8]
      64:      	movk	x1, #0x596f, lsl #32
      68:      	movk	x0, #0xd4e2, lsl #32
      6c:      	movk	x17, #0x7465, lsl #48
      70:      	movk	x18, #0x6c79, lsl #48
      74:      	movk	x1, #0xa60c, lsl #48
      78:      	movk	x0, #0xded7, lsl #48
      7c:      	eor	x17, x15, x17
      80:      	add	x18, x17, x18
      84:      	eor	x18, x18, x17, ror #48
      88:      	add	x17, x17, x1
      8c:      	mov	x1, #0x7325             // =29477
      90:      	movk	x1, #0xf0de, lsl #16
      94:      	add	x0, x18, x0
      98:      	movk	x1, #0xa674, lsl #32
      9c:      	eor	x18, x0, x18, ror #43
      a0:      	movk	x1, #0xe414, lsl #48
      a4:      	eor	x1, x17, x1
      a8:      	ror	x17, x17, #0x20
      ac:      	add	x0, x0, x1
      b0:      	add	x17, x18, x17
      b4:      	eor	x1, x0, x1, ror #51
      b8:      	ror	x0, x0, #0x20
      bc:      	eor	x18, x17, x18, ror #48
      c0:      	add	x0, x18, x0
      c4:      	add	x17, x17, x1
      c8:      	eor	x18, x0, x18, ror #43
      cc:      	eor	x1, x17, x1, ror #47
      d0:      	ror	x17, x17, #0x20
      d4:      	eor	x15, x0, x15
      d8:      	eor	x18, x18, x16
      dc:      	add	x15, x15, x1
      e0:      	add	x17, x18, x17
      e4:      	eor	x0, x15, x1, ror #51
      e8:      	ror	x15, x15, #0x20
      ec:      	eor	x18, x17, x18, ror #48
      f0:      	add	x17, x17, x0
      f4:      	add	x15, x18, x15
      f8:      	eor	x0, x17, x0, ror #47
      fc:      	ror	x17, x17, #0x20
     100:      	eor	x18, x15, x18, ror #43
     104:      	add	x15, x15, x0
     108:      	add	x17, x18, x17
     10c:      	eor	x0, x15, x0, ror #51
     110:      	ror	x15, x15, #0x20
     114:      	eor	x18, x17, x18, ror #48
     118:      	add	x17, x17, x0
     11c:      	add	x15, x18, x15
     120:      	eor	x0, x17, x0, ror #47
     124:      	ror	x17, x17, #0x20
     128:      	eor	x18, x15, x18, ror #43
     12c:      	eor	x15, x15, x16
     130:      	eor	x16, x18, x14
     134:      	add	x15, x15, x0
     138:      	add	x17, x16, x17
     13c:      	eor	x18, x15, x0, ror #51
     140:      	ror	x15, x15, #0x20
     144:      	mov	w0, #0x2                // =2
     148:      	eor	x16, x17, x16, ror #48
     14c:      	add	x17, x17, x18
     150:      	add	x15, x16, x15
     154:      	eor	x18, x17, x18, ror #47
     158:      	ror	x17, x17, #0x20
     15c:      	eor	x16, x15, x16, ror #43
     160:      	add	x15, x15, x18
     164:      	add	x17, x16, x17
     168:      	eor	x18, x15, x18, ror #51
     16c:      	ror	x15, x15, #0x20
     170:      	eor	x16, x17, x16, ror #48
     174:      	add	x17, x17, x18
     178:      	add	x15, x16, x15
     17c:      	eor	x18, x17, x18, ror #47
     180:      	ror	x17, x17, #0x20
     184:      	eor	x16, x15, x16, ror #43
     188:      	eor	x14, x15, x14
     18c:      	eor	x15, x16, x13
     190:      	add	x14, x14, x18
     194:      	add	x17, x15, x17
     198:      	eor	x16, x14, x18, ror #51
     19c:      	ror	x14, x14, #0x20
     1a0:      	eor	x15, x17, x15, ror #48
     1a4:      	add	x17, x17, x16
     1a8:      	add	x14, x15, x14
     1ac:      	eor	x16, x17, x16, ror #47
     1b0:      	ror	x17, x17, #0x20
     1b4:      	eor	x15, x14, x15, ror #43
     1b8:      	add	x14, x14, x16
     1bc:      	add	x17, x15, x17
     1c0:      	eor	x16, x14, x16, ror #51
     1c4:      	ror	x14, x14, #0x20
     1c8:      	eor	x15, x17, x15, ror #48
     1cc:      	add	x17, x17, x16
     1d0:      	add	x14, x15, x14
     1d4:      	eor	x16, x17, x16, ror #47
     1d8:      	ror	x17, x17, #0x20
     1dc:      	eor	x15, x14, x15, ror #43
     1e0:      	eor	x13, x14, x13
     1e4:      	eor	x14, x15, x12
     1e8:      	add	x13, x13, x16
     1ec:      	eor	x15, x13, x16, ror #51
     1f0:      	add	x16, x14, x17
     1f4:      	ror	x13, x13, #0x20
     1f8:      	eor	x14, x16, x14, ror #48
     1fc:      	add	x16, x16, x15
     200:      	add	x13, x14, x13
     204:      	eor	x15, x16, x15, ror #47
     208:      	ror	x16, x16, #0x20
     20c:      	eor	x14, x13, x14, ror #43
     210:      	add	x13, x13, x15
     214:      	add	x16, x14, x16
     218:      	eor	x15, x13, x15, ror #51
     21c:      	ror	x13, x13, #0x20
     220:      	eor	x14, x16, x14, ror #48
     224:      	add	x16, x16, x15
     228:      	add	x13, x14, x13
     22c:      	eor	x15, x16, x15, ror #47
     230:      	ror	x16, x16, #0x20
     234:      	eor	x14, x13, x14, ror #43
     238:      	eor	x12, x13, x12
     23c:      	eor	x13, x14, x11
     240:      	add	x12, x12, x15
     244:      	eor	x14, x12, x15, ror #51
     248:      	add	x15, x13, x16
     24c:      	ror	x12, x12, #0x20
     250:      	eor	x13, x15, x13, ror #48
     254:      	add	x15, x15, x14
     258:      	add	x12, x13, x12
     25c:      	eor	x14, x15, x14, ror #47
     260:      	ror	x15, x15, #0x20
     264:      	eor	x13, x12, x13, ror #43
     268:      	add	x12, x12, x14
     26c:      	add	x15, x13, x15
     270:      	eor	x14, x12, x14, ror #51
     274:      	ror	x12, x12, #0x20
     278:      	eor	x13, x15, x13, ror #48
     27c:      	add	x15, x15, x14
     280:      	add	x12, x13, x12
     284:      	eor	x14, x15, x14, ror #47
     288:      	ror	x15, x15, #0x20
     28c:      	eor	x13, x12, x13, ror #43
     290:      	eor	x11, x12, x11
     294:      	eor	x12, x13, x10
     298:      	add	x11, x11, x14
     29c:      	eor	x13, x11, x14, ror #51
     2a0:      	add	x14, x12, x15
     2a4:      	ror	x11, x11, #0x20
     2a8:      	eor	x12, x14, x12, ror #48
     2ac:      	add	x14, x14, x13
     2b0:      	add	x11, x12, x11
     2b4:      	eor	x13, x14, x13, ror #47
     2b8:      	ror	x14, x14, #0x20
     2bc:      	eor	x12, x11, x12, ror #43
     2c0:      	add	x11, x11, x13
     2c4:      	add	x14, x12, x14
     2c8:      	eor	x13, x11, x13, ror #51
     2cc:      	ror	x11, x11, #0x20
     2d0:      	eor	x12, x14, x12, ror #48
     2d4:      	add	x14, x14, x13
     2d8:      	add	x11, x12, x11
     2dc:      	eor	x13, x14, x13, ror #47
     2e0:      	ror	x14, x14, #0x20
     2e4:      	eor	x12, x11, x12, ror #43
     2e8:      	eor	x10, x11, x10
     2ec:      	eor	x11, x12, x9
     2f0:      	add	x10, x10, x13
     2f4:      	eor	x12, x10, x13, ror #51
     2f8:      	add	x13, x11, x14
     2fc:      	ror	x10, x10, #0x20
     300:      	eor	x11, x13, x11, ror #48
     304:      	add	x13, x13, x12
     308:      	add	x10, x11, x10
     30c:      	eor	x12, x13, x12, ror #47
     310:      	ror	x13, x13, #0x20
     314:      	eor	x11, x10, x11, ror #43
     318:      	add	x10, x10, x12
     31c:      	eor	x12, x10, x12, ror #51
     320:      	add	x13, x11, x13
     324:      	ror	x10, x10, #0x20
     328:      	eor	x11, x13, x11, ror #48
     32c:      	add	x13, x13, x12
     330:      	add	x10, x11, x10
     334:      	eor	x12, x13, x12, ror #47
     338:      	ror	x13, x13, #0x20
     33c:      	eor	x11, x10, x11, ror #43
     340:      	eor	x9, x10, x9
     344:      	eor	x10, x13, #0xff
     348:      	add	x9, x9, x12
     34c:      	add	x10, x10, x11
     350:      	eor	x12, x9, x12, ror #51
     354:      	ror	x9, x9, #0x20
     358:      	eor	x11, x10, x11, ror #48
     35c:      	add	x9, x9, x11
     360:      	add	x10, x12, x10
     364:      	eor	x11, x9, x11, ror #43
     368:      	eor	x12, x10, x12, ror #47
     36c:      	ror	x10, x10, #0x20
     370:      	add	x9, x12, x9
     374:      	add	x10, x10, x11
     378:      	eor	x12, x9, x12, ror #51
     37c:      	ror	x9, x9, #0x20
     380:      	eor	x11, x10, x11, ror #48
     384:      	add	x9, x9, x11
     388:      	add	x10, x12, x10
     38c:      	eor	x11, x9, x11, ror #43
     390:      	eor	x12, x10, x12, ror #47
     394:      	ror	x10, x10, #0x20
     398:      	add	x9, x12, x9
     39c:      	add	x10, x10, x11
     3a0:      	eor	x12, x9, x12, ror #51
     3a4:      	ror	x9, x9, #0x20
     3a8:      	eor	x11, x10, x11, ror #48
     3ac:      	add	x9, x9, x11
     3b0:      	add	x10, x12, x10
     3b4:      	eor	x11, x9, x11, ror #43
     3b8:      	eor	x12, x10, x12, ror #47
     3bc:      	ror	x10, x10, #0x20
     3c0:      	add	x10, x10, x11
     3c4:      	add	x9, x12, x9
     3c8:      	eor	x11, x10, x11, ror #48
     3cc:      	eor	x9, x9, x12, ror #51
     3d0:      	ror	x11, x11, #0x2b
     3d4:      	add	x10, x9, x10
     3d8:      	eor	x9, x11, x9, ror #47
     3dc:      	eor	x9, x9, x10, ror #32
     3e0:      	eor	x9, x9, x10
     3e4:      	str	x9, [x8]
     3e8:      	ret
