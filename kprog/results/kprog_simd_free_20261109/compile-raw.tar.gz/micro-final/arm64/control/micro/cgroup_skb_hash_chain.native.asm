
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/cgroup_skb_hash_chain.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <cgroup_skb_hash_chain_prog>:
       0:      	ldr	x7, [x0, #0xd0]
       4:      	ldr	x10, [x0, #0x50]
       8:      	cmp	x7, x10
       c:      	add	x8, x7, #0x8
      10:      	add	x9, x7, #0x50
      14:      	ccmp	x8, x10, #0x2, ls
      18:      	ccmp	x9, x10, #0x2, ls
      1c:      	b.ls	0x34 <cgroup_skb_hash_chain_prog+0x34>
      20:      	mov	w9, #-0x1               // =-1
      24:      	mov	w8, wzr
      28:      	stp	w9, w9, [x0, #0x30]
      2c:      	mov	w0, w8
      30:      	ret
      34:      	mov	x10, x8
      38:      	mov	x11, x9
      3c:      	add	x12, x10, #0x8
      40:      	cmp	x10, x11
      44:      	ccmp	x12, x11, #0x2, ls
      48:      	b.hi	0x20 <cgroup_skb_hash_chain_prog+0x20>
      4c:      	ldp	w10, w11, [x7, #0x8]
      50:      	cmp	w10, #0x10
      54:      	ccmp	w11, #0x8, #0x0, eq
      58:      	b.ne	0x20 <cgroup_skb_hash_chain_prog+0x20>
      5c:      	add	x10, x8, #0x8
      60:      	cmp	x10, x9
      64:      	b.hi	0x20 <cgroup_skb_hash_chain_prog+0x20>
      68:      	add	x8, x8, #0x48
      6c:      	cmp	x8, x9
      70:      	b.hi	0x20 <cgroup_skb_hash_chain_prog+0x20>
      74:      	str	x29, [sp, #-0x60]!
      78:      	stp	x28, x27, [sp, #0x10]
      7c:      	stp	x26, x25, [sp, #0x20]
      80:      	stp	x24, x23, [sp, #0x30]
      84:      	stp	x22, x21, [sp, #0x40]
      88:      	stp	x20, x19, [sp, #0x50]
      8c:      	mov	x8, #0x7c15             // =31765
      90:      	ldp	x10, x11, [x7, #0x10]
      94:      	mov	x28, #0x2325            // =8997
      98:      	mov	x13, #0xef95            // =61333
      9c:      	mov	x17, #0xdf2a            // =57130
      a0:      	ldp	x14, x15, [x7, #0x20]
      a4:      	movk	x8, #0x7f4a, lsl #16
      a8:      	mov	x3, #0xcebf             // =52927
      ac:      	mov	x5, #0xbe54             // =48724
      b0:      	ldp	x1, x2, [x7, #0x30]
      b4:      	mov	x20, #0xade9            // =44521
      b8:      	mov	x22, #0x9d7e            // =40318
      bc:      	mov	x23, #0x8d13            // =36115
      c0:      	ldp	x6, x7, [x7, #0x40]
      c4:      	mov	x25, #0x7ca8            // =31912
      c8:      	movk	x8, #0x79b9, lsl #32
      cc:      	movk	x28, #0x8422, lsl #16
      d0:      	movk	x13, #0xde82, lsl #16
      d4:      	movk	x17, #0xbd05, lsl #16
      d8:      	movk	x3, #0x9b88, lsl #16
      dc:      	movk	x5, #0x7a0b, lsl #16
      e0:      	movk	x20, #0x588e, lsl #16
      e4:      	movk	x22, #0x3711, lsl #16
      e8:      	movk	x23, #0x1594, lsl #16
      ec:      	movk	x25, #0xf417, lsl #16
      f0:      	movk	x8, #0x9e37, lsl #48
      f4:      	mov	x9, #0x1b3              // =435
      f8:      	movk	x28, #0x9ce4, lsl #32
      fc:      	movk	x13, #0x2543, lsl #32
     100:      	movk	x17, #0x4a87, lsl #32
     104:      	movk	x3, #0x6fcb, lsl #32
     108:      	movk	x5, #0x950f, lsl #32
     10c:      	movk	x20, #0xba53, lsl #32
     110:      	movk	x22, #0xdf97, lsl #32
     114:      	movk	x23, #0x4db, lsl #32
     118:      	movk	x25, #0x2a1e, lsl #32
     11c:      	movk	x9, #0x100, lsl #32
     120:      	movk	x28, #0xcbf2, lsl #48
     124:      	mov	w12, #0x3e              // =62
     128:      	movk	x13, #0xd134, lsl #48
     12c:      	mov	w16, #0x37              // =55
     130:      	movk	x17, #0xa268, lsl #48
     134:      	mov	w18, #0x2c              // =44
     138:      	movk	x3, #0x739c, lsl #48
     13c:      	mov	w4, #0x21               // =33
     140:      	movk	x5, #0x44d0, lsl #48
     144:      	mov	w19, #0x16              // =22
     148:      	movk	x20, #0x1604, lsl #48
     14c:      	mov	w21, #0xb               // =11
     150:      	movk	x22, #0xe738, lsl #48
     154:      	movk	x23, #0xb86d, lsl #48
     158:      	mov	w24, #0x35              // =53
     15c:      	movk	x25, #0x89a1, lsl #48
     160:      	mov	w26, #0x2a              // =42
     164:      	mov	x27, x8
     168:      	eor	x29, x27, x13
     16c:      	add	x29, x10, x29
     170:      	eor	x28, x29, x28
     174:      	sub	w29, w16, w12
     178:      	ror	x28, x28, x29
     17c:      	eor	x29, x27, x17
     180:      	mul	x28, x28, x9
     184:      	add	x29, x11, x29
     188:      	eor	x29, x29, x28, lsr #29
     18c:      	eor	x28, x29, x28
     190:      	sub	w29, w18, w12
     194:      	ror	x28, x28, x29
     198:      	eor	x29, x27, x3
     19c:      	mul	x28, x28, x9
     1a0:      	add	x29, x14, x29
     1a4:      	eor	x29, x29, x28, lsr #29
     1a8:      	eor	x28, x29, x28
     1ac:      	sub	w29, w4, w12
     1b0:      	ror	x28, x28, x29
     1b4:      	eor	x29, x27, x5
     1b8:      	mul	x28, x28, x9
     1bc:      	add	x29, x15, x29
     1c0:      	eor	x29, x29, x28, lsr #29
     1c4:      	eor	x28, x29, x28
     1c8:      	sub	w29, w19, w12
     1cc:      	ror	x28, x28, x29
     1d0:      	eor	x29, x27, x20
     1d4:      	mul	x28, x28, x9
     1d8:      	add	x29, x1, x29
     1dc:      	eor	x29, x29, x28, lsr #29
     1e0:      	eor	x28, x29, x28
     1e4:      	sub	w29, w21, w12
     1e8:      	ror	x28, x28, x29
     1ec:      	eor	x29, x27, x22
     1f0:      	mul	x28, x28, x9
     1f4:      	add	x29, x2, x29
     1f8:      	eor	x29, x29, x28, lsr #29
     1fc:      	eor	x28, x29, x28
     200:      	neg	w29, w12
     204:      	ror	x28, x28, x29
     208:      	eor	x29, x27, x23
     20c:      	mul	x28, x28, x9
     210:      	add	x29, x6, x29
     214:      	eor	x29, x29, x28, lsr #29
     218:      	eor	x28, x29, x28
     21c:      	sub	w29, w24, w12
     220:      	ror	x28, x28, x29
     224:      	eor	x29, x27, x25
     228:      	add	x27, x27, x8
     22c:      	mul	x28, x28, x9
     230:      	add	x29, x7, x29
     234:      	eor	x29, x29, x28, lsr #29
     238:      	eor	x28, x29, x28
     23c:      	sub	w29, w26, w12
     240:      	add	x12, x12, #0x5
     244:      	ror	x28, x28, x29
     248:      	cmp	x12, #0x8e
     24c:      	mul	x28, x28, x9
     250:      	eor	x28, x28, x28, lsr #29
     254:      	b.ne	0x168 <cgroup_skb_hash_chain_prog+0x168>
     258:      	str	w28, [x0, #0x30]
     25c:      	lsr	x9, x28, #32
     260:      	ldp	x20, x19, [sp, #0x50]
     264:      	mov	w8, #0x1                // =1
     268:      	ldp	x22, x21, [sp, #0x40]
     26c:      	ldp	x24, x23, [sp, #0x30]
     270:      	ldp	x26, x25, [sp, #0x20]
     274:      	ldp	x28, x27, [sp, #0x10]
     278:      	ldr	x29, [sp], #0x60
     27c:      	str	w9, [x0, #0x34]
     280:      	mov	w0, w8
     284:      	ret
