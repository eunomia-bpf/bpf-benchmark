
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/cilium_ct_nat_tuple_rewrite.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <cilium_ct_nat_tuple_rewrite_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x10, x8
       8:      	cmp	x10, x9
       c:      	b.ls	0x18 <cilium_ct_nat_tuple_rewrite_xdp+0x18>
      10:      	mov	w0, wzr
      14:      	ret
      18:      	add	x11, x10, #0x8
      1c:      	add	x12, x10, #0x410
      20:      	mov	w0, wzr
      24:      	cmp	x11, x9
      28:      	ccmp	x12, x9, #0x2, ls
      2c:      	b.hi	0x168 <cilium_ct_nat_tuple_rewrite_xdp+0x168>
      30:      	ldr	w9, [x10, #0x8]
      34:      	cmp	w9, #0x20
      38:      	b.ne	0x168 <cilium_ct_nat_tuple_rewrite_xdp+0x168>
      3c:      	ldr	w9, [x10, #0xc]
      40:      	cmp	w9, #0x20
      44:      	b.ne	0x168 <cilium_ct_nat_tuple_rewrite_xdp+0x168>
      48:      	mov	x11, #0xc6e3            // =50915
      4c:      	mov	x9, xzr
      50:      	add	x10, x10, #0x17
      54:      	movk	x11, #0x9c88, lsl #16
      58:      	movk	x11, #0x6af0, lsl #32
      5c:      	movk	x11, #0x8ebc, lsl #48
      60:      	b	0x134 <cilium_ct_nat_tuple_rewrite_xdp+0x134>
      64:      	ldrb	w18, [x10, #0x7]
      68:      	ldurh	w14, [x10, #0x11]
      6c:      	add	x17, x10, #0x9
      70:      	sub	x4, x10, #0x7
      74:      	add	x16, x10, #0xd
      78:      	sub	x3, x10, #0x3
      7c:      	ldrb	w0, [x10, #0x6]
      80:      	add	x11, x11, w12, uxtw
      84:      	ldurh	w1, [x10, #0x3]
      88:      	tst	w18, #0x1
      8c:      	ldurh	w2, [x10, #0x1]
      90:      	ldurh	w15, [x10, #0x13]
      94:      	sbfx	w5, w18, #0, #1
      98:      	orr	w13, w15, w13, lsl #24
      9c:      	lsl	w15, w18, #29
      a0:      	csel	x17, x4, x17, eq
      a4:      	tst	w18, #0x2
      a8:      	lsl	w4, w18, #30
      ac:      	and	w5, w5, w14
      b0:      	csel	x16, x3, x16, eq
      b4:      	ldr	w17, [x17]
      b8:      	and	w4, w14, w4, asr #31
      bc:      	eor	w2, w2, w5
      c0:      	tst	w0, #0x1
      c4:      	and	w14, w14, #0xffff
      c8:      	ldr	w16, [x16]
      cc:      	eor	w1, w1, w4
      d0:      	eor	w14, w12, w14, lsl #8
      d4:      	csel	w0, w1, w2, eq
      d8:      	csel	w1, w2, w1, eq
      dc:      	and	w14, w14, w15, asr #31
      e0:      	csel	w2, w16, w17, eq
      e4:      	csel	w16, w17, w16, eq
      e8:      	and	w17, w0, #0xffff
      ec:      	eor	w13, w13, w17
      f0:      	orr	x12, x2, x16, lsl #32
      f4:      	eor	w13, w13, w1, lsl #16
      f8:      	eor	w13, w13, w2, ror #21
      fc:      	eor	w13, w13, w16
     100:      	add	w13, w13, w14
     104:      	add	x11, x11, x13, lsl #32
     108:      	and	w13, w9, #0x7
     10c:      	add	w14, w13, #0x1
     110:      	eor	w13, w13, #0x3f
     114:      	lsl	x14, x12, x14
     118:      	lsr	x12, x12, x13
     11c:      	orr	x12, x14, x12
     120:      	eor	x11, x11, x12
     124:      	add	x9, x9, #0x1
     128:      	add	x10, x10, #0x20
     12c:      	cmp	x9, #0x20
     130:      	b.eq	0x160 <cilium_ct_nat_tuple_rewrite_xdp+0x160>
     134:      	ldrb	w13, [x10, #0x5]
     138:      	ldur	w12, [x10, #0x15]
     13c:      	cmp	w13, #0x6
     140:      	ccmp	w13, #0x11, #0x4, ne
     144:      	b.eq	0x64 <cilium_ct_nat_tuple_rewrite_xdp+0x64>
     148:      	orr	x12, x12, x13, lsl #56
     14c:      	eor	x11, x12, x11
     150:      	add	x9, x9, #0x1
     154:      	add	x10, x10, #0x20
     158:      	cmp	x9, #0x20
     15c:      	b.ne	0x134 <cilium_ct_nat_tuple_rewrite_xdp+0x134>
     160:      	mov	w0, #0x2                // =2
     164:      	str	x11, [x8]
     168:      	ret
