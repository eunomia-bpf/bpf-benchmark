
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/tracee_http_method_prefix_detect.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <tracee_http_method_prefix_detect_xdp>:
       0:      	ldp	x8, x10, [x0]
       4:      	mov	x9, x8
       8:      	cmp	x9, x10
       c:      	b.hi	0x34 <tracee_http_method_prefix_detect_xdp+0x34>
      10:      	add	x11, x9, #0x8
      14:      	add	x12, x9, #0x90
      18:      	cmp	x11, x10
      1c:      	ccmp	x12, x10, #0x2, ls
      20:      	b.hi	0x34 <tracee_http_method_prefix_detect_xdp+0x34>
      24:      	ldp	w10, w11, [x9, #0x8]
      28:      	cmp	w10, #0x8
      2c:      	ccmp	w11, #0x10, #0x0, eq
      30:      	b.eq	0x3c <tracee_http_method_prefix_detect_xdp+0x3c>
      34:      	mov	w0, wzr
      38:      	ret
      3c:      	add	x10, x9, #0x16
      40:      	mov	x9, #0x642f             // =25647
      44:      	mov	w11, #0x1               // =1
      48:      	movk	x9, #0x78bd, lsl #16
      4c:      	movk	x9, #0x1d64, lsl #32
      50:      	movk	x9, #0xa076, lsl #48
      54:      	nop
      58:      	nop
      5c:      	nop
      60:      	ldurb	w12, [x10, #-0x6]
      64:      	ldurb	w13, [x10, #-0x5]
      68:      	cmp	w12, #0x47
      6c:      	b.gt	0xc0 <tracee_http_method_prefix_detect_xdp+0xc0>
      70:      	cmp	w12, #0x44
      74:      	b.eq	0x118 <tracee_http_method_prefix_detect_xdp+0x118>
      78:      	cmp	w12, #0x47
      7c:      	b.ne	0x240 <tracee_http_method_prefix_detect_xdp+0x240>
      80:      	cmp	w13, #0x45
      84:      	b.ne	0x240 <tracee_http_method_prefix_detect_xdp+0x240>
      88:      	ldurb	w13, [x10, #-0x4]
      8c:      	cmp	w13, #0x54
      90:      	b.ne	0x1b8 <tracee_http_method_prefix_detect_xdp+0x1b8>
      94:      	ldurb	w14, [x10, #-0x3]
      98:      	mov	w13, #0x45              // =69
      9c:      	cmp	w14, #0x20
      a0:      	b.ne	0x224 <tracee_http_method_prefix_detect_xdp+0x224>
      a4:      	mov	w14, #0x20              // =32
      a8:      	mov	w15, #0x54              // =84
      ac:      	mov	w16, #0x1               // =1
      b0:      	b	0x24c <tracee_http_method_prefix_detect_xdp+0x24c>
      b4:      	nop
      b8:      	nop
      bc:      	nop
      c0:      	cmp	w12, #0x48
      c4:      	b.eq	0x170 <tracee_http_method_prefix_detect_xdp+0x170>
      c8:      	cmp	w12, #0x50
      cc:      	b.ne	0x240 <tracee_http_method_prefix_detect_xdp+0x240>
      d0:      	cmp	w13, #0x55
      d4:      	b.eq	0x1c0 <tracee_http_method_prefix_detect_xdp+0x1c0>
      d8:      	cmp	w13, #0x4f
      dc:      	b.ne	0x240 <tracee_http_method_prefix_detect_xdp+0x240>
      e0:      	ldurb	w13, [x10, #-0x4]
      e4:      	cmp	w13, #0x53
      e8:      	b.ne	0x228 <tracee_http_method_prefix_detect_xdp+0x228>
      ec:      	ldurb	w13, [x10, #-0x3]
      f0:      	cmp	w13, #0x54
      f4:      	b.ne	0x228 <tracee_http_method_prefix_detect_xdp+0x228>
      f8:      	ldurb	w14, [x10, #-0x2]
      fc:      	mov	w13, #0x4f              // =79
     100:      	cmp	w14, #0x20
     104:      	b.ne	0x224 <tracee_http_method_prefix_detect_xdp+0x224>
     108:      	mov	w14, #0x54              // =84
     10c:      	mov	w15, #0x53              // =83
     110:      	mov	w16, #0x2               // =2
     114:      	b	0x24c <tracee_http_method_prefix_detect_xdp+0x24c>
     118:      	cmp	w13, #0x45
     11c:      	b.ne	0x240 <tracee_http_method_prefix_detect_xdp+0x240>
     120:      	ldurb	w13, [x10, #-0x4]
     124:      	cmp	w13, #0x4c
     128:      	b.ne	0x1b8 <tracee_http_method_prefix_detect_xdp+0x1b8>
     12c:      	ldurb	w13, [x10, #-0x3]
     130:      	cmp	w13, #0x45
     134:      	b.ne	0x1b8 <tracee_http_method_prefix_detect_xdp+0x1b8>
     138:      	ldurb	w13, [x10, #-0x2]
     13c:      	cmp	w13, #0x54
     140:      	b.ne	0x1b8 <tracee_http_method_prefix_detect_xdp+0x1b8>
     144:      	ldurb	w13, [x10, #-0x1]
     148:      	cmp	w13, #0x45
     14c:      	b.ne	0x1b8 <tracee_http_method_prefix_detect_xdp+0x1b8>
     150:      	ldrb	w14, [x10]
     154:      	mov	w13, #0x45              // =69
     158:      	cmp	w14, #0x20
     15c:      	b.ne	0x224 <tracee_http_method_prefix_detect_xdp+0x224>
     160:      	mov	w14, #0x45              // =69
     164:      	mov	w15, #0x4c              // =76
     168:      	mov	w16, #0x4               // =4
     16c:      	b	0x24c <tracee_http_method_prefix_detect_xdp+0x24c>
     170:      	cmp	w13, #0x54
     174:      	b.eq	0x1ec <tracee_http_method_prefix_detect_xdp+0x1ec>
     178:      	cmp	w13, #0x45
     17c:      	b.ne	0x240 <tracee_http_method_prefix_detect_xdp+0x240>
     180:      	ldurb	w13, [x10, #-0x4]
     184:      	cmp	w13, #0x41
     188:      	b.ne	0x1b8 <tracee_http_method_prefix_detect_xdp+0x1b8>
     18c:      	ldurb	w13, [x10, #-0x3]
     190:      	cmp	w13, #0x44
     194:      	b.ne	0x1b8 <tracee_http_method_prefix_detect_xdp+0x1b8>
     198:      	ldurb	w14, [x10, #-0x2]
     19c:      	mov	w13, #0x45              // =69
     1a0:      	cmp	w14, #0x20
     1a4:      	b.ne	0x224 <tracee_http_method_prefix_detect_xdp+0x224>
     1a8:      	mov	w14, #0x44              // =68
     1ac:      	mov	w15, #0x41              // =65
     1b0:      	mov	w16, #0x5               // =5
     1b4:      	b	0x24c <tracee_http_method_prefix_detect_xdp+0x24c>
     1b8:      	mov	w13, #0x45              // =69
     1bc:      	b	0x240 <tracee_http_method_prefix_detect_xdp+0x240>
     1c0:      	ldurb	w13, [x10, #-0x4]
     1c4:      	cmp	w13, #0x54
     1c8:      	b.ne	0x238 <tracee_http_method_prefix_detect_xdp+0x238>
     1cc:      	ldurb	w14, [x10, #-0x3]
     1d0:      	mov	w13, #0x55              // =85
     1d4:      	cmp	w14, #0x20
     1d8:      	b.ne	0x224 <tracee_http_method_prefix_detect_xdp+0x224>
     1dc:      	mov	w14, #0x20              // =32
     1e0:      	mov	w15, #0x54              // =84
     1e4:      	mov	w16, #0x3               // =3
     1e8:      	b	0x24c <tracee_http_method_prefix_detect_xdp+0x24c>
     1ec:      	ldurb	w13, [x10, #-0x4]
     1f0:      	cmp	w13, #0x54
     1f4:      	b.ne	0x230 <tracee_http_method_prefix_detect_xdp+0x230>
     1f8:      	ldurb	w13, [x10, #-0x3]
     1fc:      	cmp	w13, #0x50
     200:      	b.ne	0x230 <tracee_http_method_prefix_detect_xdp+0x230>
     204:      	ldurb	w14, [x10, #-0x2]
     208:      	mov	w13, #0x54              // =84
     20c:      	cmp	w14, #0x2f
     210:      	b.ne	0x240 <tracee_http_method_prefix_detect_xdp+0x240>
     214:      	mov	w14, #0x50              // =80
     218:      	mov	w15, #0x54              // =84
     21c:      	mov	w16, #0x6               // =6
     220:      	b	0x24c <tracee_http_method_prefix_detect_xdp+0x24c>
     224:      	b	0x240 <tracee_http_method_prefix_detect_xdp+0x240>
     228:      	mov	w13, #0x4f              // =79
     22c:      	b	0x240 <tracee_http_method_prefix_detect_xdp+0x240>
     230:      	mov	w13, #0x54              // =84
     234:      	b	0x240 <tracee_http_method_prefix_detect_xdp+0x240>
     238:      	mov	w13, #0x55              // =85
     23c:      	nop
     240:      	ldurb	w15, [x10, #-0x4]
     244:      	ldurb	w14, [x10, #-0x3]
     248:      	mov	x16, xzr
     24c:      	mov	w17, w13
     250:      	add	x13, x11, #0xa
     254:      	add	x10, x10, #0x10
     258:      	madd	x13, x13, x16, x13
     25c:      	add	x13, x9, x13
     260:      	lsl	x9, x12, #8
     264:      	orr	x9, x9, x17, lsl #16
     268:      	orr	x9, x9, x15, lsl #24
     26c:      	orr	x9, x9, x14, lsl #32
     270:      	orr	x9, x9, x16
     274:      	lsl	x9, x9, x11
     278:      	add	x11, x11, #0x1
     27c:      	eor	x9, x9, x13
     280:      	cmp	x11, #0x9
     284:      	b.ne	0x60 <tracee_http_method_prefix_detect_xdp+0x60>
     288:      	lsr	x10, x9, #8
     28c:      	mov	w0, #0x2                // =2
     290:      	strb	w13, [x8]
     294:      	strb	w10, [x8, #0x1]
     298:      	lsr	x10, x9, #16
     29c:      	strb	w10, [x8, #0x2]
     2a0:      	lsr	x10, x9, #24
     2a4:      	strb	w10, [x8, #0x3]
     2a8:      	lsr	x10, x9, #32
     2ac:      	strb	w10, [x8, #0x4]
     2b0:      	lsr	x10, x9, #40
     2b4:      	strb	w10, [x8, #0x5]
     2b8:      	lsr	x10, x9, #48
     2bc:      	lsr	x9, x9, #56
     2c0:      	strb	w10, [x8, #0x6]
     2c4:      	strb	w9, [x8, #0x7]
     2c8:      	ret
