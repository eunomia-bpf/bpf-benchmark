
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/cilium_policy_guard_tree_filter.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <cilium_policy_guard_tree_filter_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x10, x8
       8:      	cmp	x10, x9
       c:      	b.hi	0x13c <cilium_policy_guard_tree_filter_xdp+0x13c>
      10:      	add	x11, x10, #0x8
      14:      	add	x12, x10, #0x20c
      18:      	cmp	x11, x9
      1c:      	ccmp	x12, x9, #0x2, ls
      20:      	b.hi	0x13c <cilium_policy_guard_tree_filter_xdp+0x13c>
      24:      	ldr	w9, [x11]
      28:      	cmp	w9, #0x20
      2c:      	b.ne	0x13c <cilium_policy_guard_tree_filter_xdp+0x13c>
      30:      	mov	x11, #0x28db            // =10459
      34:      	mov	x9, xzr
      38:      	add	x10, x10, #0xd
      3c:      	movk	x11, #0xa0b4, lsl #16
      40:      	movk	x11, #0x7ed1, lsl #32
      44:      	movk	x11, #0xe703, lsl #48
      48:      	b	0x7c <cilium_policy_guard_tree_filter_xdp+0x7c>
      4c:      	eor	x12, x12, x13
      50:      	add	x11, x12, x11
      54:      	and	w13, w9, #0x7
      58:      	add	x9, x9, #0x1
      5c:      	add	x10, x10, #0x10
      60:      	add	w12, w13, #0x1
      64:      	eor	w13, w13, #0x3f
      68:      	cmp	x9, #0x20
      6c:      	lsl	x12, x11, x12
      70:      	lsr	x11, x11, x13
      74:      	orr	x11, x12, x11
      78:      	b.eq	0x144 <cilium_policy_guard_tree_filter_xdp+0x144>
      7c:      	ldurb	w13, [x10, #-0x1]
      80:      	ldur	x12, [x10, #0x7]
      84:      	cmp	x13, #0x21
      88:      	b.lo	0x4c <cilium_policy_guard_tree_filter_xdp+0x4c>
      8c:      	ldrb	w14, [x10]
      90:      	tbnz	w14, #0x0, 0xa0 <cilium_policy_guard_tree_filter_xdp+0xa0>
      94:      	add	x12, x12, x14
      98:      	b	0x104 <cilium_policy_guard_tree_filter_xdp+0x104>
      9c:      	nop
      a0:      	ldrb	w14, [x10, #0x1]
      a4:      	tbnz	w14, #0x7, 0xf8 <cilium_policy_guard_tree_filter_xdp+0xf8>
      a8:      	ldrb	w14, [x10, #0x2]
      ac:      	and	w15, w9, #0xff
      b0:      	eor	w15, w14, w15
      b4:      	cmp	w15, #0x11
      b8:      	b.lo	0x100 <cilium_policy_guard_tree_filter_xdp+0x100>
      bc:      	ldrb	w14, [x10, #0x3]
      c0:      	add	w13, w14, w13
      c4:      	and	w13, w13, #0xff
      c8:      	cmp	w13, #0xbf
      cc:      	b.hi	0x10c <cilium_policy_guard_tree_filter_xdp+0x10c>
      d0:      	ldrb	w13, [x10, #0x4]
      d4:      	and	w14, w13, #0x18
      d8:      	cmp	w14, #0x10
      dc:      	b.ne	0x114 <cilium_policy_guard_tree_filter_xdp+0x114>
      e0:      	ldrb	w14, [x10, #0x5]
      e4:      	cmp	w14, #0xaa
      e8:      	b.ne	0x11c <cilium_policy_guard_tree_filter_xdp+0x11c>
      ec:      	eor	x13, x12, x13
      f0:      	extr	x12, x13, x12, #0x39
      f4:      	b	0x50 <cilium_policy_guard_tree_filter_xdp+0x50>
      f8:      	eor	x12, x12, x14, lsl #8
      fc:      	b	0x50 <cilium_policy_guard_tree_filter_xdp+0x50>
     100:      	add	x12, x12, x14, lsl #16
     104:      	eor	x11, x12, x11
     108:      	b	0x54 <cilium_policy_guard_tree_filter_xdp+0x54>
     10c:      	eor	x12, x12, x14, lsl #24
     110:      	b	0x50 <cilium_policy_guard_tree_filter_xdp+0x50>
     114:      	add	x12, x12, x13, lsl #32
     118:      	b	0x104 <cilium_policy_guard_tree_filter_xdp+0x104>
     11c:      	ldrb	w13, [x10, #0x6]
     120:      	and	w15, w13, #0x3
     124:      	cmp	w15, #0x1
     128:      	b.ne	0x134 <cilium_policy_guard_tree_filter_xdp+0x134>
     12c:      	eor	x12, x12, x13, lsl #48
     130:      	b	0x50 <cilium_policy_guard_tree_filter_xdp+0x50>
     134:      	add	x12, x12, x14, lsl #40
     138:      	b	0x104 <cilium_policy_guard_tree_filter_xdp+0x104>
     13c:      	mov	w0, wzr
     140:      	ret
     144:      	lsr	x9, x12, #8
     148:      	mov	w0, #0x2                // =2
     14c:      	strb	w11, [x8]
     150:      	strb	w9, [x8, #0x1]
     154:      	lsr	x9, x12, #16
     158:      	strb	w9, [x8, #0x2]
     15c:      	lsr	x9, x12, #24
     160:      	strb	w9, [x8, #0x3]
     164:      	lsr	x9, x12, #32
     168:      	strb	w9, [x8, #0x4]
     16c:      	lsr	x9, x12, #40
     170:      	strb	w9, [x8, #0x5]
     174:      	lsr	x9, x12, #48
     178:      	strb	w9, [x8, #0x6]
     17c:      	lsr	x9, x12, #56
     180:      	strb	w9, [x8, #0x7]
     184:      	ret
