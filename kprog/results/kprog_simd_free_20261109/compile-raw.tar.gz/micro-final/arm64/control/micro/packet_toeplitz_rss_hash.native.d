/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/packet_toeplitz_rss_hash.native.so: \
  packet_toeplitz_rss_hash.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h:
