/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/cilium_policy_guard_tree_filter.native.so: \
  cilium_policy_guard_tree_filter.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h:
