/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/cilium_ct_nat_tuple_rewrite.native.so: \
  cilium_ct_nat_tuple_rewrite.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h:
