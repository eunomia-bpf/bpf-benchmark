
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/bcc_runqlat_log2_histogram_bucket.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <bcc_runqlat_log2_histogram_bucket_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x18, x8
       8:      	cmp	x18, x9
       c:      	b.hi	0x120 <bcc_runqlat_log2_histogram_bucket_xdp+0x120>
      10:      	add	x10, x18, #0x8
      14:      	add	x11, x18, #0x410
      18:      	cmp	x10, x9
      1c:      	ccmp	x11, x9, #0x2, ls
      20:      	b.hi	0x120 <bcc_runqlat_log2_histogram_bucket_xdp+0x120>
      24:      	ldr	w9, [x10]
      28:      	cmp	w9, #0x80
      2c:      	b.ne	0x120 <bcc_runqlat_log2_histogram_bucket_xdp+0x120>
      30:      	ldr	w16, [x18, #0xc]
      34:      	mov	x9, xzr
      38:      	add	x10, x18, #0x10
      3c:      	add	x11, x18, #0x11
      40:      	add	x12, x18, #0x12
      44:      	add	x13, x18, #0x13
      48:      	add	x14, x18, #0x14
      4c:      	add	x15, x18, #0x15
      50:      	add	x17, x18, #0x16
      54:      	add	x18, x18, #0x17
      58:      	mov	w0, #0x19               // =25
      5c:      	b	0xdc <bcc_runqlat_log2_histogram_bucket_xdp+0xdc>
      60:      	ldrb	w4, [x13, x1]
      64:      	ldrb	w5, [x15, x1]
      68:      	cmp	w2, #0x19
      6c:      	add	x9, x9, #0x1
      70:      	csel	w2, w2, w0, lo
      74:      	ldrb	w6, [x18, x1]
      78:      	orr	x3, x3, x4, lsl #24
      7c:      	ldrb	w4, [x14, x1]
      80:      	lsl	x5, x5, #40
      84:      	lsl	x6, x6, #56
      88:      	orr	x4, x5, x4, lsl #32
      8c:      	ldrb	w5, [x17, x1]
      90:      	and	x1, x1, #0x38
      94:      	lsl	x1, x2, x1
      98:      	orr	x5, x6, x5, lsl #48
      9c:      	orr	x4, x5, x4
      a0:      	orr	x3, x4, x3
      a4:      	add	w4, w2, #0x1
      a8:      	madd	x16, x9, x4, x16
      ac:      	and	w4, w2, #0x7
      b0:      	add	w5, w4, #0x1
      b4:      	eor	w4, w4, #0x3f
      b8:      	lsl	x5, x3, x5
      bc:      	lsr	x4, x3, x4
      c0:      	orr	x4, x5, x4
      c4:      	eor	x16, x4, x16
      c8:      	eor	x1, x16, x1
      cc:      	add	x16, x16, x3, lsr #32
      d0:      	csel	x16, x1, x16, lo
      d4:      	cmp	x9, #0x80
      d8:      	b.eq	0x128 <bcc_runqlat_log2_histogram_bucket_xdp+0x128>
      dc:      	lsl	x1, x9, #3
      e0:      	ldrb	w2, [x10, x1]
      e4:      	ldrb	w3, [x11, x1]
      e8:      	orr	x2, x2, x3, lsl #8
      ec:      	ldrb	w3, [x12, x1]
      f0:      	orr	x3, x2, x3, lsl #16
      f4:      	mov	w2, wzr
      f8:      	ubfx	x4, x3, #3, #20
      fc:      	cbz	x4, 0x60 <bcc_runqlat_log2_histogram_bucket_xdp+0x60>
     100:      	add	x4, x4, #0x1
     104:      	cmp	w2, #0x3d
     108:      	add	w2, w2, #0x1
     10c:      	b.hi	0x60 <bcc_runqlat_log2_histogram_bucket_xdp+0x60>
     110:      	cmp	x4, #0x3
     114:      	lsr	x4, x4, #1
     118:      	b.hi	0x104 <bcc_runqlat_log2_histogram_bucket_xdp+0x104>
     11c:      	b	0x60 <bcc_runqlat_log2_histogram_bucket_xdp+0x60>
     120:      	mov	w0, wzr
     124:      	ret
     128:      	mov	w0, #0x2                // =2
     12c:      	str	x16, [x8]
     130:      	ret
