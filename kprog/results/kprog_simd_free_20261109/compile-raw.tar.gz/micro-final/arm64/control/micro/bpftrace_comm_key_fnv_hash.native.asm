
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/bpftrace_comm_key_fnv_hash.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <bpftrace_comm_key_fnv_hash_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x11, x8
       8:      	cmp	x11, x9
       c:      	b.ls	0x18 <bpftrace_comm_key_fnv_hash_xdp+0x18>
      10:      	mov	w0, wzr
      14:      	ret
      18:      	add	x10, x11, #0x8
      1c:      	add	x12, x11, #0x410
      20:      	mov	w0, wzr
      24:      	cmp	x10, x9
      28:      	ccmp	x12, x9, #0x2, ls
      2c:      	b.hi	0x2a8 <bpftrace_comm_key_fnv_hash_xdp+0x2a8>
      30:      	ldr	w9, [x11, #0x8]
      34:      	cmp	w9, #0x20
      38:      	b.ne	0x2a8 <bpftrace_comm_key_fnv_hash_xdp+0x2a8>
      3c:      	ldr	w9, [x11, #0xc]
      40:      	cmp	w9, #0x20
      44:      	b.ne	0x2a8 <bpftrace_comm_key_fnv_hash_xdp+0x2a8>
      48:      	str	x21, [sp, #-0x20]!
      4c:      	stp	x20, x19, [sp, #0x10]
      50:      	mov	x12, #0x11eb            // =4587
      54:      	mov	x13, #0x2325            // =8997
      58:      	mov	x14, #0xca87            // =51847
      5c:      	mov	x10, #0x1b3             // =435
      60:      	mov	x9, xzr
      64:      	add	x11, x11, #0x17
      68:      	movk	x12, #0x1331, lsl #16
      6c:      	movk	x13, #0x8422, lsl #16
      70:      	movk	x14, #0x85eb, lsl #16
      74:      	movk	x10, #0x100, lsl #32
      78:      	movk	x12, #0x49bb, lsl #32
      7c:      	movk	x13, #0x9ce4, lsl #32
      80:      	movk	x14, #0x79b1, lsl #32
      84:      	movk	x12, #0x94d0, lsl #48
      88:      	movk	x13, #0xcbf2, lsl #48
      8c:      	movk	x14, #0x9e37, lsl #48
      90:      	b	0xe4 <bpftrace_comm_key_fnv_hash_xdp+0xe4>
      94:      	nop
      98:      	nop
      9c:      	nop
      a0:      	lsl	w18, w18, #16
      a4:      	add	x11, x11, #0x20
      a8:      	orr	w17, w18, w17, lsl #8
      ac:      	orr	w17, w17, w0, lsl #24
      b0:      	orr	w16, w17, w16
      b4:      	and	w17, w9, #0x7
      b8:      	add	x9, x9, #0x1
      bc:      	add	w18, w17, #0x1
      c0:      	eor	w17, w17, #0x3f
      c4:      	orr	x15, x16, x15, lsl #56
      c8:      	cmp	x9, #0x20
      cc:      	lsl	x18, x1, x18
      d0:      	lsr	x17, x1, x17
      d4:      	orr	x17, x18, x17
      d8:      	eor	x12, x17, x12
      dc:      	add	x12, x12, x15
      e0:      	b.eq	0x298 <bpftrace_comm_key_fnv_hash_xdp+0x298>
      e4:      	ldurb	w1, [x11, #-0x7]
      e8:      	ldurb	w2, [x11, #-0x6]
      ec:      	eor	x20, x1, x13
      f0:      	ldurb	w4, [x11, #-0x5]
      f4:      	ldurb	w5, [x11, #-0x4]
      f8:      	ldurb	w3, [x11, #-0x3]
      fc:      	ldurb	w6, [x11, #-0x2]
     100:      	ldurb	w7, [x11, #-0x1]
     104:      	ldrb	w19, [x11]
     108:      	ldrb	w16, [x11, #0x1]
     10c:      	ldrb	w17, [x11, #0x2]
     110:      	lsl	x1, x1, #32
     114:      	mul	x20, x20, x10
     118:      	ldrb	w18, [x11, #0x3]
     11c:      	ldrb	w0, [x11, #0x4]
     120:      	and	x21, x0, #0xff
     124:      	orr	x1, x1, x2, lsl #40
     128:      	orr	x1, x1, x4, lsl #48
     12c:      	ldrb	w15, [x11, #0x5]
     130:      	tst	w15, #0x1
     134:      	orr	x1, x1, x5, lsl #56
     138:      	orr	x1, x1, x6, lsl #8
     13c:      	eor	x20, x20, x2
     140:      	orr	x1, x1, x7, lsl #16
     144:      	and	x2, x16, #0x7
     148:      	mul	x20, x20, x10
     14c:      	orr	x1, x1, x19, lsl #24
     150:      	orr	x1, x1, x3
     154:      	eor	x20, x20, x4
     158:      	mul	x20, x20, x10
     15c:      	eor	x20, x20, x5
     160:      	mul	x20, x20, x10
     164:      	eor	x20, x20, x3
     168:      	add	x3, x2, #0x1
     16c:      	eor	w2, w2, #0x3f
     170:      	mul	x20, x20, x10
     174:      	lsl	x3, x1, x3
     178:      	lsr	x1, x1, x2
     17c:      	orr	x1, x3, x1
     180:      	eor	x20, x20, x6
     184:      	mul	x20, x20, x10
     188:      	eor	x20, x20, x7
     18c:      	mul	x20, x20, x10
     190:      	eor	x20, x20, x19
     194:      	mul	x20, x20, x10
     198:      	eor	x20, x20, x16
     19c:      	mul	x20, x20, x10
     1a0:      	eor	x20, x20, x17
     1a4:      	mul	x20, x20, x10
     1a8:      	eor	x20, x20, x18
     1ac:      	mul	x20, x20, x10
     1b0:      	eor	x20, x20, x21
     1b4:      	ldrb	w21, [x11, #0x9]
     1b8:      	mul	x20, x20, x10
     1bc:      	eor	x20, x20, x21
     1c0:      	ldrb	w21, [x11, #0xa]
     1c4:      	mul	x20, x20, x10
     1c8:      	eor	x20, x20, x21
     1cc:      	ldrb	w21, [x11, #0xb]
     1d0:      	mul	x20, x20, x10
     1d4:      	eor	x20, x20, x21
     1d8:      	ldrb	w21, [x11, #0xc]
     1dc:      	mul	x20, x20, x10
     1e0:      	eor	x20, x20, x21
     1e4:      	ldrb	w21, [x11, #0xd]
     1e8:      	mul	x20, x20, x10
     1ec:      	eor	x20, x20, x21
     1f0:      	ldrb	w21, [x11, #0xe]
     1f4:      	mul	x20, x20, x10
     1f8:      	eor	x20, x20, x21
     1fc:      	ldrb	w21, [x11, #0xf]
     200:      	mul	x20, x20, x10
     204:      	eor	x20, x20, x21
     208:      	ldrb	w21, [x11, #0x10]
     20c:      	mul	x20, x20, x10
     210:      	eor	x20, x20, x21
     214:      	ldrb	w21, [x11, #0x11]
     218:      	mul	x20, x20, x10
     21c:      	eor	x20, x20, x21
     220:      	ldrb	w21, [x11, #0x12]
     224:      	mul	x20, x20, x10
     228:      	eor	x20, x20, x21
     22c:      	ldrb	w21, [x11, #0x13]
     230:      	mul	x20, x20, x10
     234:      	eor	x20, x20, x21
     238:      	ldrb	w21, [x11, #0x14]
     23c:      	mul	x20, x20, x10
     240:      	eor	x20, x20, x21
     244:      	ldrb	w21, [x11, #0x15]
     248:      	mul	x20, x20, x10
     24c:      	eor	x20, x20, x21
     250:      	ldrb	w21, [x11, #0x16]
     254:      	mul	x20, x20, x10
     258:      	eor	x20, x20, x21
     25c:      	ldrb	w21, [x11, #0x17]
     260:      	mul	x20, x20, x10
     264:      	eor	x20, x20, x21
     268:      	ldrb	w21, [x11, #0x18]
     26c:      	mul	x20, x20, x10
     270:      	eor	x20, x20, x21
     274:      	mul	x20, x20, x10
     278:      	eor	x1, x20, x1
     27c:      	csel	x1, x20, x1, eq
     280:      	tbz	w15, #0x1, 0xa0 <bpftrace_comm_key_fnv_hash_xdp+0xa0>
     284:      	ldrb	w2, [x11, #0x9]
     288:      	add	x3, x1, x14
     28c:      	cmp	w2, #0x70
     290:      	csel	x1, x3, x1, eq
     294:      	b	0xa0 <bpftrace_comm_key_fnv_hash_xdp+0xa0>
     298:      	ldp	x20, x19, [sp, #0x10]
     29c:      	mov	w0, #0x2                // =2
     2a0:      	str	x12, [x8]
     2a4:      	ldr	x21, [sp], #0x20
     2a8:      	ret
