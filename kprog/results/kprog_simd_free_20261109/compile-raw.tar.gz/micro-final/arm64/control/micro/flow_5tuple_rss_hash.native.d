/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/flow_5tuple_rss_hash.native.so: \
  flow_5tuple_rss_hash.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h:
