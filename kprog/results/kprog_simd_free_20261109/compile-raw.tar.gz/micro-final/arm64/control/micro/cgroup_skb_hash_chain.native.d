/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/cgroup_skb_hash_chain.native.so: \
  cgroup_skb_hash_chain.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h:
