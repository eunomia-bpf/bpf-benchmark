
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/katran_lb_consistent_hash_select.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <katran_lb_consistent_hash_select_xdp>:
       0:      	ldp	x8, x10, [x0]
       4:      	cmp	x8, x10
       8:      	b.hi	0x24 <katran_lb_consistent_hash_select_xdp+0x24>
       c:      	add	x12, x8, #0x8
      10:      	cmp	x12, x10
      14:      	b.hi	0x24 <katran_lb_consistent_hash_select_xdp+0x24>
      18:      	add	x11, x8, #0x16
      1c:      	cmp	x11, x10
      20:      	b.ls	0x2c <katran_lb_consistent_hash_select_xdp+0x2c>
      24:      	mov	w0, wzr
      28:      	ret
      2c:      	ldrh	w13, [x8, #0x14]
      30:      	mov	x9, #0x7c15             // =31765
      34:      	mov	w14, #0xdd86            // =56710
      38:      	sub	x12, x10, x12
      3c:      	movk	x9, #0x7f4a, lsl #16
      40:      	movk	x9, #0x79b9, lsl #32
      44:      	movk	x9, #0x9e37, lsl #48
      48:      	cmp	w13, w14
      4c:      	b.eq	0x2a0 <katran_lb_consistent_hash_select_xdp+0x2a0>
      50:      	cmp	w13, #0x8
      54:      	b.ne	0x2f8 <katran_lb_consistent_hash_select_xdp+0x2f8>
      58:      	add	x13, x8, #0x2a
      5c:      	cmp	x13, x10
      60:      	b.hi	0x328 <katran_lb_consistent_hash_select_xdp+0x328>
      64:      	ldrb	w11, [x11]
      68:      	and	w11, w11, #0xf
      6c:      	cmp	w11, #0x5
      70:      	b.ne	0x328 <katran_lb_consistent_hash_select_xdp+0x328>
      74:      	ldrb	w11, [x8, #0x1c]
      78:      	ldrb	w13, [x8, #0x1d]
      7c:      	and	w11, w11, #0x3f
      80:      	orr	w11, w11, w13, lsl #8
      84:      	cbnz	w11, 0x328 <katran_lb_consistent_hash_select_xdp+0x328>
      88:      	ldrb	w11, [x8, #0x1f]
      8c:      	cmp	w11, #0x1
      90:      	b.eq	0x310 <katran_lb_consistent_hash_select_xdp+0x310>
      94:      	cmp	w11, #0x11
      98:      	b.eq	0x61c <katran_lb_consistent_hash_select_xdp+0x61c>
      9c:      	cmp	w11, #0x6
      a0:      	b.ne	0x310 <katran_lb_consistent_hash_select_xdp+0x310>
      a4:      	add	x11, x8, #0x3e
      a8:      	cmp	x11, x10
      ac:      	b.hi	0x328 <katran_lb_consistent_hash_select_xdp+0x328>
      b0:      	ldur	w11, [x8, #0x26]
      b4:      	mov	w13, #0x640a            // =25610
      b8:      	mov	w10, #0x2               // =2
      bc:      	movk	w13, #0x101, lsl #16
      c0:      	cmp	w11, w13
      c4:      	b.ne	0x314 <katran_lb_consistent_hash_select_xdp+0x314>
      c8:      	ldrh	w11, [x8, #0x2c]
      cc:      	mov	w13, #0x901f            // =36895
      d0:      	cmp	w11, w13
      d4:      	mov	w13, #0x2               // =2
      d8:      	b.ne	0x330 <katran_lb_consistent_hash_select_xdp+0x330>
      dc:      	cmp	x12, #0x5ea
      e0:      	b.gt	0x328 <katran_lb_consistent_hash_select_xdp+0x328>
      e4:      	ldrb	w14, [x8, #0x24]
      e8:      	ldrh	w16, [x8, #0x22]
      ec:      	mov	w17, #0xc0f7            // =49399
      f0:      	mov	w1, #0x70cc0000         // =1892417536
      f4:      	mov	w18, #0xc0f7            // =49399
      f8:      	movk	w17, #0x70cc, lsl #16
      fc:      	ldrb	w15, [x8, #0x25]
     100:      	movk	w18, #0xe0ad, lsl #16
     104:      	ldrh	w10, [x8, #0x18]
     108:      	lsl	w12, w14, #16
     10c:      	bfi	w16, w14, #16, #8
     110:      	ldrh	w14, [x8, #0x2a]
     114:      	lsl	w13, w15, #24
     118:      	ldrb	w11, [x8, #0x17]
     11c:      	rev16	w10, w10
     120:      	orr	w12, w13, w12
     124:      	add	w13, w10, #0x14
     128:      	bfi	w16, w15, #24, #8
     12c:      	mov	w15, #-0x6fe10000       // =-1877016576
     130:      	rev	w13, w13
     134:      	lsr	w13, w13, #16
     138:      	add	w17, w14, w17
     13c:      	orr	w15, w14, w15
     140:      	rev	w14, w14
     144:      	add	x11, x11, x13
     148:      	mov	w13, #0xdf3b            // =57147
     14c:      	extr	w1, w17, w1, #0x12
     150:      	eor	w0, w17, w18
     154:      	add	w18, w16, w18
     158:      	add	x16, x9, w16, uxtw
     15c:      	eor	w12, w14, w12
     160:      	lsr	w14, w12, #16
     164:      	add	x13, x14, x13
     168:      	sub	w0, w0, w1
     16c:      	add	x11, x11, x13
     170:      	eor	w18, w0, w18
     174:      	ror	w1, w0, #0x15
     178:      	lsr	x13, x11, #16
     17c:      	cmp	x11, #0x10, lsl #12     // =0x10000
     180:      	sub	w18, w18, w1
     184:      	add	x13, x13, w11, uxth
     188:      	eor	w17, w18, w17
     18c:      	ror	w1, w18, #0x7
     190:      	sub	w17, w17, w1
     194:      	csel	x11, x11, x13, lo
     198:      	eor	w0, w17, w0
     19c:      	ror	w1, w17, #0x10
     1a0:      	lsr	x13, x11, #16
     1a4:      	cmp	x11, #0x10, lsl #12     // =0x10000
     1a8:      	sub	w0, w0, w1
     1ac:      	add	x13, x13, w11, uxth
     1b0:      	eor	w18, w0, w18
     1b4:      	ror	w1, w0, #0x1c
     1b8:      	sub	w18, w18, w1
     1bc:      	csel	x11, x11, x13, lo
     1c0:      	eor	w17, w18, w17
     1c4:      	ror	w18, w18, #0x12
     1c8:      	lsr	x13, x11, #16
     1cc:      	cmp	x11, #0x10, lsl #12     // =0x10000
     1d0:      	sub	w17, w17, w18
     1d4:      	add	x13, x13, w11, uxth
     1d8:      	eor	w18, w17, w0
     1dc:      	ror	w17, w17, #0x8
     1e0:      	mov	w0, #0x640a             // =25610
     1e4:      	sub	w17, w18, w17
     1e8:      	mov	w18, #-0xffff           // =-65535
     1ec:      	movk	w0, #0x101, lsl #16
     1f0:      	csel	x11, x11, x13, lo
     1f4:      	umull	x18, w17, w18
     1f8:      	add	w13, w11, w11, lsr #16
     1fc:      	cmp	x11, #0x10, lsl #12     // =0x10000
     200:      	lsr	x18, x18, #48
     204:      	csel	w11, w11, w13, lo
     208:      	orr	w18, w18, w18, lsl #16
     20c:      	lsl	w11, w11, #16
     210:      	sub	w17, w17, w18
     214:      	add	x18, x9, x16, lsl #6
     218:      	add	x18, x18, x16, lsr #2
     21c:      	add	x18, x18, x0
     220:      	eor	x16, x18, x16
     224:      	add	x18, x9, x16, lsl #6
     228:      	add	x18, x18, x16, lsr #2
     22c:      	add	x15, x18, x15
     230:      	eor	x15, x15, x16
     234:      	add	x16, x9, x15, lsl #6
     238:      	add	x16, x16, x15, lsr #2
     23c:      	add	x16, x16, x17
     240:      	eor	x15, x16, x15
     244:      	add	x16, x9, x15, lsl #6
     248:      	add	x16, x16, x15, lsr #2
     24c:      	add	x16, x16, #0x1
     250:      	eor	x15, x16, x15
     254:      	add	x16, x9, x15, lsl #6
     258:      	add	x16, x16, x15, lsr #2
     25c:      	eor	x15, x16, x15
     260:      	add	x16, x10, x9
     264:      	add	x16, x16, x15, lsl #6
     268:      	add	x16, x16, x15, lsr #2
     26c:      	eor	x14, x16, x15
     270:      	mov	w15, #0x10ac            // =4268
     274:      	orr	w12, w12, w15
     278:      	mov	w15, #0xc80a            // =51210
     27c:      	movk	w15, #0x200, lsl #16
     280:      	orr	x12, x15, x12, lsl #32
     284:      	eor	x10, x12, x10
     288:      	mov	x12, #0xb               // =11
     28c:      	movk	x12, #0xffff, lsl #16
     290:      	movk	x12, #0x200, lsl #32
     294:      	eor	x10, x10, x12
     298:      	eor	x10, x10, x11
     29c:      	b	0x5f4 <katran_lb_consistent_hash_select_xdp+0x5f4>
     2a0:      	add	x11, x8, #0x3e
     2a4:      	cmp	x11, x10
     2a8:      	b.hi	0x328 <katran_lb_consistent_hash_select_xdp+0x328>
     2ac:      	ldrb	w13, [x8, #0x1c]
     2b0:      	cmp	w13, #0x2c
     2b4:      	b.eq	0x328 <katran_lb_consistent_hash_select_xdp+0x328>
     2b8:      	cmp	w13, #0x3a
     2bc:      	b.eq	0x310 <katran_lb_consistent_hash_select_xdp+0x310>
     2c0:      	ldrb	w17, [x8, #0x16]
     2c4:      	ldrb	w0, [x8, #0x17]
     2c8:      	cmp	w13, #0x11
     2cc:      	ldrh	w18, [x8, #0x1a]
     2d0:      	ldur	w11, [x8, #0x1e]
     2d4:      	ldur	w16, [x8, #0x22]
     2d8:      	ldur	w14, [x8, #0x26]
     2dc:      	ldur	w15, [x8, #0x2a]
     2e0:      	ldur	w1, [x8, #0x2e]
     2e4:      	b.eq	0x31c <katran_lb_consistent_hash_select_xdp+0x31c>
     2e8:      	cmp	w13, #0x6
     2ec:      	b.ne	0x310 <katran_lb_consistent_hash_select_xdp+0x310>
     2f0:      	add	x2, x8, #0x52
     2f4:      	b	0x320 <katran_lb_consistent_hash_select_xdp+0x320>
     2f8:      	add	x10, x12, x9
     2fc:      	add	x11, x9, x10, lsl #6
     300:      	add	x11, x11, x10, lsr #2
     304:      	add	x11, x11, #0x2
     308:      	eor	x10, x11, x10
     30c:      	b	0x314 <katran_lb_consistent_hash_select_xdp+0x314>
     310:      	mov	w10, #0x2               // =2
     314:      	mov	w13, #0x2               // =2
     318:      	b	0x330 <katran_lb_consistent_hash_select_xdp+0x330>
     31c:      	add	x2, x8, #0x46
     320:      	cmp	x2, x10
     324:      	b.ls	0x34c <katran_lb_consistent_hash_select_xdp+0x34c>
     328:      	mov	w10, #0x1               // =1
     32c:      	mov	w13, #0x1               // =1
     330:      	add	x9, x9, x10, lsl #6
     334:      	mov	w0, #0x2                // =2
     338:      	add	x9, x9, x10, lsr #2
     33c:      	add	x9, x9, x13
     340:      	eor	x9, x9, x10
     344:      	str	x9, [x8]
     348:      	ret
     34c:      	mov	w10, #0x2               // =2
     350:      	cmp	w13, #0x6
     354:      	b.ne	0x314 <katran_lb_consistent_hash_select_xdp+0x314>
     358:      	mov	w13, #0x640a            // =25610
     35c:      	movk	w13, #0x101, lsl #16
     360:      	cmp	w1, w13
     364:      	b.ne	0x314 <katran_lb_consistent_hash_select_xdp+0x314>
     368:      	ldrh	w13, [x8, #0x40]
     36c:      	mov	w1, #0x901f             // =36895
     370:      	cmp	w13, w1
     374:      	mov	w13, #0x2               // =2
     378:      	b.ne	0x330 <katran_lb_consistent_hash_select_xdp+0x330>
     37c:      	cmp	x12, #0x5ea
     380:      	b.gt	0x328 <katran_lb_consistent_hash_select_xdp+0x328>
     384:      	mov	w13, #0xc0ff            // =49407
     388:      	lsl	w10, w0, #24
     38c:      	and	w0, w15, #0xff0000
     390:      	and	w1, w15, #0xff00
     394:      	movk	w13, #0xdead, lsl #16
     398:      	extr	w12, w17, w10, #0x1c
     39c:      	rev16	w10, w18
     3a0:      	and	w17, w15, #0xff000000
     3a4:      	and	w15, w15, #0xff
     3a8:      	add	w18, w14, w13
     3ac:      	sub	w14, w11, w14
     3b0:      	add	w16, w16, w13
     3b4:      	ldrh	w13, [x8, #0x3e]
     3b8:      	add	w17, w17, w0
     3bc:      	eor	w14, w14, w18, ror #28
     3c0:      	add	w17, w17, w1
     3c4:      	sub	w2, w16, w14
     3c8:      	add	w16, w18, w16
     3cc:      	add	w15, w17, w15
     3d0:      	eor	w2, w2, w14, ror #26
     3d4:      	add	w14, w14, w16
     3d8:      	sub	w16, w16, w2
     3dc:      	add	w18, w2, w14
     3e0:      	eor	w16, w16, w2, ror #24
     3e4:      	sub	w14, w14, w16
     3e8:      	eor	w14, w14, w16, ror #16
     3ec:      	add	w16, w16, w18
     3f0:      	sub	w2, w18, w14
     3f4:      	eor	w2, w2, w14, ror #13
     3f8:      	add	w14, w14, w16
     3fc:      	sub	w16, w16, w2
     400:      	add	w18, w2, w14
     404:      	add	w14, w15, w14
     408:      	eor	w16, w16, w2, ror #28
     40c:      	eor	w15, w16, w18
     410:      	ror	w16, w18, #0x12
     414:      	sub	w15, w15, w16
     418:      	eor	w14, w14, w15
     41c:      	ror	w16, w15, #0x15
     420:      	sub	w14, w14, w16
     424:      	eor	w16, w14, w18
     428:      	ror	w17, w14, #0x7
     42c:      	mov	w18, #0x70cc0000        // =1892417536
     430:      	sub	w16, w16, w17
     434:      	eor	w15, w16, w15
     438:      	ror	w17, w16, #0x10
     43c:      	sub	w15, w15, w17
     440:      	eor	w14, w15, w14
     444:      	ror	w17, w15, #0x1c
     448:      	sub	w14, w14, w17
     44c:      	mov	w17, #0xc0f7            // =49399
     450:      	eor	w16, w14, w16
     454:      	ror	w14, w14, #0x12
     458:      	movk	w17, #0x70cc, lsl #16
     45c:      	sub	w14, w16, w14
     460:      	add	w17, w13, w17
     464:      	ror	w16, w14, #0x8
     468:      	eor	w14, w14, w15
     46c:      	extr	w18, w17, w18, #0x12
     470:      	mov	w15, #-0x6fe10000       // =-1877016576
     474:      	sub	w14, w14, w16
     478:      	mov	w16, #0xc0f7            // =49399
     47c:      	orr	w15, w13, w15
     480:      	rev	w13, w13
     484:      	movk	w16, #0xe0ad, lsl #16
     488:      	add	x15, x15, x9
     48c:      	add	w14, w14, w16
     490:      	eor	w16, w17, w16
     494:      	sub	w16, w16, w18
     498:      	eor	w14, w14, w16
     49c:      	ror	w18, w16, #0x15
     4a0:      	sub	w14, w14, w18
     4a4:      	eor	w17, w14, w17
     4a8:      	ror	w18, w14, #0x7
     4ac:      	sub	w17, w17, w18
     4b0:      	eor	w16, w17, w16
     4b4:      	ror	w18, w17, #0x10
     4b8:      	sub	w16, w16, w18
     4bc:      	eor	w14, w16, w14
     4c0:      	ror	w18, w16, #0x1c
     4c4:      	sub	w14, w14, w18
     4c8:      	mov	x18, #0xe01f            // =57375
     4cc:      	eor	w17, w14, w17
     4d0:      	ror	w14, w14, #0x12
     4d4:      	movk	x18, #0x804b, lsl #16
     4d8:      	sub	w14, w17, w14
     4dc:      	movk	x18, #0x79b9, lsl #32
     4e0:      	eor	w16, w14, w16
     4e4:      	ror	w14, w14, #0x8
     4e8:      	movk	x18, #0x9e37, lsl #48
     4ec:      	sub	w14, w16, w14
     4f0:      	mov	w16, #-0xffff           // =-65535
     4f4:      	umull	x16, w14, w16
     4f8:      	lsr	x16, x16, #48
     4fc:      	orr	w16, w16, w16, lsl #16
     500:      	sub	w14, w14, w16
     504:      	add	x16, x11, x9
     508:      	and	w11, w11, #0xffff0000
     50c:      	lsl	x17, x16, #6
     510:      	eor	w11, w13, w11
     514:      	add	w13, w10, #0x14
     518:      	add	x17, x17, x16, lsr #2
     51c:      	rev	w13, w13
     520:      	lsr	w13, w13, #16
     524:      	add	x17, x17, x18
     528:      	add	x12, x13, w12, uxtb
     52c:      	mov	w13, #0xdf3b            // =57147
     530:      	eor	x16, x17, x16
     534:      	add	x15, x15, x16, lsl #6
     538:      	add	x15, x15, x16, lsr #2
     53c:      	eor	x15, x15, x16
     540:      	add	x16, x9, x15, lsl #6
     544:      	add	x16, x16, x15, lsr #2
     548:      	add	x14, x16, x14
     54c:      	lsr	w16, w11, #16
     550:      	eor	x14, x14, x15
     554:      	add	x13, x16, x13
     558:      	add	x15, x9, x14, lsl #6
     55c:      	add	x12, x12, x13
     560:      	lsr	x13, x12, #16
     564:      	cmp	x12, #0x10, lsl #12     // =0x10000
     568:      	add	x15, x15, x14, lsr #2
     56c:      	add	x13, x13, w12, uxth
     570:      	add	x15, x15, #0x1
     574:      	csel	x12, x12, x13, lo
     578:      	eor	x14, x15, x14
     57c:      	lsr	x13, x12, #16
     580:      	cmp	x12, #0x10, lsl #12     // =0x10000
     584:      	add	x15, x9, x14, lsl #6
     588:      	add	x13, x13, w12, uxth
     58c:      	add	x15, x15, x14, lsr #2
     590:      	csel	x12, x12, x13, lo
     594:      	lsr	x13, x12, #16
     598:      	cmp	x12, #0x10, lsl #12     // =0x10000
     59c:      	eor	x14, x15, x14
     5a0:      	add	x15, x10, x9
     5a4:      	add	x13, x13, w12, uxth
     5a8:      	add	x15, x15, x14, lsl #6
     5ac:      	csel	x12, x12, x13, lo
     5b0:      	add	x15, x15, x14, lsr #2
     5b4:      	add	w13, w12, w12, lsr #16
     5b8:      	cmp	x12, #0x10, lsl #12     // =0x10000
     5bc:      	eor	x14, x15, x14
     5c0:      	mov	w15, #0x10ac            // =4268
     5c4:      	csel	w12, w12, w13, lo
     5c8:      	orr	w11, w11, w15
     5cc:      	mov	w15, #0xc80a            // =51210
     5d0:      	lsl	w12, w12, #16
     5d4:      	movk	w15, #0x200, lsl #16
     5d8:      	orr	x11, x15, x11, lsl #32
     5dc:      	eor	x10, x11, x10
     5e0:      	mov	x11, #0xb               // =11
     5e4:      	movk	x11, #0xffff, lsl #16
     5e8:      	movk	x11, #0x200, lsl #32
     5ec:      	eor	x10, x10, x11
     5f0:      	eor	x10, x10, x12
     5f4:      	add	x11, x9, x14, lsl #6
     5f8:      	mov	w13, #0x3               // =3
     5fc:      	add	x11, x11, x14, lsr #2
     600:      	add	x10, x11, x10
     604:      	eor	x10, x10, x14
     608:      	add	x11, x9, x10, lsl #6
     60c:      	add	x11, x11, x10, lsr #2
     610:      	add	x11, x11, #0x3
     614:      	eor	x10, x11, x10
     618:      	b	0x330 <katran_lb_consistent_hash_select_xdp+0x330>
     61c:      	add	x11, x8, #0x32
     620:      	cmp	x11, x10
     624:      	mov	w10, #0x1               // =1
     628:      	cinc	x10, x10, ls
     62c:      	mov	x13, x10
     630:      	b	0x330 <katran_lb_consistent_hash_select_xdp+0x330>
