
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/packet_record_bounds_window.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <packet_record_bounds_window_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x10, x8
       8:      	cmp	x10, x9
       c:      	b.ls	0x18 <packet_record_bounds_window_xdp+0x18>
      10:      	mov	w0, wzr
      14:      	ret
      18:      	add	x11, x10, #0x8
      1c:      	add	x12, x10, #0x310
      20:      	cmp	x11, x9
      24:      	ccmp	x12, x9, #0x2, ls
      28:      	b.ls	0x34 <packet_record_bounds_window_xdp+0x34>
      2c:      	mov	w0, wzr
      30:      	ret
      34:      	ldp	w9, w11, [x10, #0x8]
      38:      	cmp	w9, #0x20
      3c:      	ccmp	w11, #0x18, #0x0, eq
      40:      	b.eq	0x4c <packet_record_bounds_window_xdp+0x4c>
      44:      	mov	w0, wzr
      48:      	ret
      4c:      	mov	x12, #0xfd93            // =64915
      50:      	mov	x9, xzr
      54:      	add	x10, x10, #0x14
      58:      	mov	w11, #0x300             // =768
      5c:      	movk	x12, #0x6659, lsl #16
      60:      	movk	x12, #0xfeb8, lsl #32
      64:      	movk	x12, #0xd6e8, lsl #48
      68:      	b	0x80 <packet_record_bounds_window_xdp+0x80>
      6c:      	add	x9, x9, #0x8
      70:      	sub	x11, x11, #0x18
      74:      	add	x10, x10, #0x18
      78:      	cmp	x9, #0x100
      7c:      	b.eq	0x10c <packet_record_bounds_window_xdp+0x10c>
      80:      	ldurb	w13, [x10, #-0x4]
      84:      	mov	w14, #0x18              // =24
      88:      	bfxil	x14, x13, #0, #2
      8c:      	cmp	x11, x14
      90:      	b.lo	0x6c <packet_record_bounds_window_xdp+0x6c>
      94:      	ldp	w15, w16, [x10]
      98:      	ldrh	w0, [x10, #0x10]
      9c:      	and	x13, x13, #0x3
      a0:      	add	x12, x15, x12
      a4:      	ldp	w17, w18, [x10, #0x8]
      a8:      	ldurb	w14, [x10, #-0x3]
      ac:      	add	x15, x16, x0
      b0:      	orr	x16, x17, x16, lsl #32
      b4:      	orr	x17, x18, x17, lsl #32
      b8:      	tst	w14, #0x1
      bc:      	add	x12, x12, x15
      c0:      	ldrh	w15, [x10, #0x12]
      c4:      	add	x16, x12, x16
      c8:      	eor	x12, x12, x17
      cc:      	csel	x17, x18, x18, eq
      d0:      	csel	x12, x16, x12, eq
      d4:      	and	w16, w14, #0x7
      d8:      	ubfiz	x14, x14, #2, #3
      dc:      	lsl	x14, x17, x14
      e0:      	eor	w13, w16, w13
      e4:      	eor	x12, x12, x14
      e8:      	and	x14, x9, #0x18
      ec:      	lsl	x14, x15, x14
      f0:      	add	x12, x12, x14
      f4:      	add	w14, w13, #0x1
      f8:      	eor	w13, w13, #0x3f
      fc:      	lsl	x14, x12, x14
     100:      	lsr	x12, x12, x13
     104:      	orr	x12, x14, x12
     108:      	b	0x6c <packet_record_bounds_window_xdp+0x6c>
     10c:      	mov	w0, #0x2                // =2
     110:      	str	x12, [x8]
     114:      	ret
