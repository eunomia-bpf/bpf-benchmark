
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/trace_event_type_switch_dispatch.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <trace_event_type_switch_dispatch_xdp>:
       0:      	ldp	x8, x10, [x0]
       4:      	mov	x9, x8
       8:      	cmp	x9, x10
       c:      	b.hi	0x3c <trace_event_type_switch_dispatch_xdp+0x3c>
      10:      	add	x11, x9, #0x8
      14:      	add	x12, x9, #0x20c
      18:      	cmp	x11, x10
      1c:      	ccmp	x12, x10, #0x2, ls
      20:      	b.hi	0x3c <trace_event_type_switch_dispatch_xdp+0x3c>
      24:      	ldr	w10, [x11]
      28:      	cmp	w10, #0x80
      2c:      	b.ne	0x3c <trace_event_type_switch_dispatch_xdp+0x3c>
      30:      	mov	x11, xzr
      34:      	mov	x12, xzr
      38:      	b	0x58 <trace_event_type_switch_dispatch_xdp+0x58>
      3c:      	mov	w0, wzr
      40:      	ret
      44:      	mov	w12, #0xc               // =12
      48:      	add	x11, x11, #0x4
      4c:      	eor	x12, x12, x10
      50:      	cmp	x11, #0x200
      54:      	b.eq	0x574 <trace_event_type_switch_dispatch_xdp+0x574>
      58:      	mov	x10, x12
      5c:      	add	x12, x9, x11
      60:      	ldr	w12, [x12, #0xc]
      64:      	cmp	w12, #0x1f
      68:      	b.gt	0xa0 <trace_event_type_switch_dispatch_xdp+0xa0>
      6c:      	cmp	w12, #0xf
      70:      	b.gt	0xe0 <trace_event_type_switch_dispatch_xdp+0xe0>
      74:      	cmp	w12, #0x7
      78:      	b.gt	0x150 <trace_event_type_switch_dispatch_xdp+0x150>
      7c:      	cmp	w12, #0x3
      80:      	b.gt	0x1f0 <trace_event_type_switch_dispatch_xdp+0x1f0>
      84:      	cmp	w12, #0x1
      88:      	b.gt	0x2f0 <trace_event_type_switch_dispatch_xdp+0x2f0>
      8c:      	cbz	w12, 0x470 <trace_event_type_switch_dispatch_xdp+0x470>
      90:      	cmp	w12, #0x1
      94:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
      98:      	mov	w12, #0x2b              // =43
      9c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
      a0:      	cmp	w12, #0x2f
      a4:      	b.gt	0x120 <trace_event_type_switch_dispatch_xdp+0x120>
      a8:      	cmp	w12, #0x27
      ac:      	b.gt	0x178 <trace_event_type_switch_dispatch_xdp+0x178>
      b0:      	cmp	w12, #0x23
      b4:      	b.gt	0x210 <trace_event_type_switch_dispatch_xdp+0x210>
      b8:      	cmp	w12, #0x21
      bc:      	b.gt	0x308 <trace_event_type_switch_dispatch_xdp+0x308>
      c0:      	cmp	w12, #0x20
      c4:      	b.eq	0x478 <trace_event_type_switch_dispatch_xdp+0x478>
      c8:      	cmp	w12, #0x21
      cc:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
      d0:      	mov	w12, #0x27              // =39
      d4:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
      d8:      	nop
      dc:      	nop
      e0:      	cmp	w12, #0x17
      e4:      	b.gt	0x1a0 <trace_event_type_switch_dispatch_xdp+0x1a0>
      e8:      	cmp	w12, #0x13
      ec:      	b.gt	0x230 <trace_event_type_switch_dispatch_xdp+0x230>
      f0:      	cmp	w12, #0x11
      f4:      	b.gt	0x320 <trace_event_type_switch_dispatch_xdp+0x320>
      f8:      	cmp	w12, #0x10
      fc:      	b.eq	0x480 <trace_event_type_switch_dispatch_xdp+0x480>
     100:      	cmp	w12, #0x11
     104:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     108:      	mov	w12, #0x3e              // =62
     10c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     110:      	nop
     114:      	nop
     118:      	nop
     11c:      	nop
     120:      	cmp	w12, #0x37
     124:      	b.gt	0x1c8 <trace_event_type_switch_dispatch_xdp+0x1c8>
     128:      	cmp	w12, #0x33
     12c:      	b.gt	0x250 <trace_event_type_switch_dispatch_xdp+0x250>
     130:      	cmp	w12, #0x31
     134:      	b.gt	0x338 <trace_event_type_switch_dispatch_xdp+0x338>
     138:      	cmp	w12, #0x30
     13c:      	b.eq	0x488 <trace_event_type_switch_dispatch_xdp+0x488>
     140:      	cmp	w12, #0x31
     144:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     148:      	mov	x12, xzr
     14c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     150:      	cmp	w12, #0xb
     154:      	b.gt	0x270 <trace_event_type_switch_dispatch_xdp+0x270>
     158:      	cmp	w12, #0x9
     15c:      	b.gt	0x350 <trace_event_type_switch_dispatch_xdp+0x350>
     160:      	cmp	w12, #0x8
     164:      	b.eq	0x490 <trace_event_type_switch_dispatch_xdp+0x490>
     168:      	cmp	w12, #0x9
     16c:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     170:      	mov	w12, #0x3f              // =63
     174:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     178:      	cmp	w12, #0x2b
     17c:      	b.gt	0x290 <trace_event_type_switch_dispatch_xdp+0x290>
     180:      	cmp	w12, #0x29
     184:      	b.gt	0x368 <trace_event_type_switch_dispatch_xdp+0x368>
     188:      	cmp	w12, #0x28
     18c:      	b.eq	0x498 <trace_event_type_switch_dispatch_xdp+0x498>
     190:      	cmp	w12, #0x29
     194:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     198:      	mov	w12, #0x32              // =50
     19c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     1a0:      	cmp	w12, #0x1b
     1a4:      	b.gt	0x2b0 <trace_event_type_switch_dispatch_xdp+0x2b0>
     1a8:      	cmp	w12, #0x19
     1ac:      	b.gt	0x380 <trace_event_type_switch_dispatch_xdp+0x380>
     1b0:      	cmp	w12, #0x18
     1b4:      	b.eq	0x4a0 <trace_event_type_switch_dispatch_xdp+0x4a0>
     1b8:      	cmp	w12, #0x19
     1bc:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     1c0:      	mov	w12, #0x1a              // =26
     1c4:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     1c8:      	cmp	w12, #0x3b
     1cc:      	b.gt	0x2d0 <trace_event_type_switch_dispatch_xdp+0x2d0>
     1d0:      	cmp	w12, #0x39
     1d4:      	b.gt	0x398 <trace_event_type_switch_dispatch_xdp+0x398>
     1d8:      	cmp	w12, #0x38
     1dc:      	b.eq	0x4a8 <trace_event_type_switch_dispatch_xdp+0x4a8>
     1e0:      	cmp	w12, #0x39
     1e4:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     1e8:      	mov	w12, #0x36              // =54
     1ec:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     1f0:      	cmp	w12, #0x5
     1f4:      	b.gt	0x3b0 <trace_event_type_switch_dispatch_xdp+0x3b0>
     1f8:      	cmp	w12, #0x4
     1fc:      	b.eq	0x4b0 <trace_event_type_switch_dispatch_xdp+0x4b0>
     200:      	cmp	w12, #0x5
     204:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     208:      	mov	w12, #0x3d              // =61
     20c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     210:      	cmp	w12, #0x25
     214:      	b.gt	0x3c8 <trace_event_type_switch_dispatch_xdp+0x3c8>
     218:      	cmp	w12, #0x24
     21c:      	b.eq	0x4b8 <trace_event_type_switch_dispatch_xdp+0x4b8>
     220:      	cmp	w12, #0x25
     224:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     228:      	mov	w12, #0x4               // =4
     22c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     230:      	cmp	w12, #0x15
     234:      	b.gt	0x3e0 <trace_event_type_switch_dispatch_xdp+0x3e0>
     238:      	cmp	w12, #0x14
     23c:      	b.eq	0x4c0 <trace_event_type_switch_dispatch_xdp+0x4c0>
     240:      	cmp	w12, #0x15
     244:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     248:      	mov	w12, #0x15              // =21
     24c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     250:      	cmp	w12, #0x35
     254:      	b.gt	0x3f8 <trace_event_type_switch_dispatch_xdp+0x3f8>
     258:      	cmp	w12, #0x34
     25c:      	b.eq	0x4c8 <trace_event_type_switch_dispatch_xdp+0x4c8>
     260:      	cmp	w12, #0x35
     264:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     268:      	mov	w12, #0x14              // =20
     26c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     270:      	cmp	w12, #0xd
     274:      	b.gt	0x410 <trace_event_type_switch_dispatch_xdp+0x410>
     278:      	cmp	w12, #0xc
     27c:      	b.eq	0x4d0 <trace_event_type_switch_dispatch_xdp+0x4d0>
     280:      	cmp	w12, #0xd
     284:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     288:      	mov	w12, #0x2a              // =42
     28c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     290:      	cmp	w12, #0x2d
     294:      	b.gt	0x428 <trace_event_type_switch_dispatch_xdp+0x428>
     298:      	cmp	w12, #0x2c
     29c:      	b.eq	0x4d8 <trace_event_type_switch_dispatch_xdp+0x4d8>
     2a0:      	cmp	w12, #0x2d
     2a4:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     2a8:      	mov	w12, #0x2c              // =44
     2ac:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     2b0:      	cmp	w12, #0x1d
     2b4:      	b.gt	0x440 <trace_event_type_switch_dispatch_xdp+0x440>
     2b8:      	cmp	w12, #0x1c
     2bc:      	b.eq	0x4e0 <trace_event_type_switch_dispatch_xdp+0x4e0>
     2c0:      	cmp	w12, #0x1d
     2c4:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     2c8:      	mov	w12, #0x1f              // =31
     2cc:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     2d0:      	cmp	w12, #0x3d
     2d4:      	b.gt	0x458 <trace_event_type_switch_dispatch_xdp+0x458>
     2d8:      	cmp	w12, #0x3c
     2dc:      	b.eq	0x4e8 <trace_event_type_switch_dispatch_xdp+0x4e8>
     2e0:      	cmp	w12, #0x3d
     2e4:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     2e8:      	mov	w12, #0x5               // =5
     2ec:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     2f0:      	cmp	w12, #0x2
     2f4:      	b.eq	0x4f0 <trace_event_type_switch_dispatch_xdp+0x4f0>
     2f8:      	cmp	w12, #0x3
     2fc:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     300:      	mov	w12, #0x1c              // =28
     304:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     308:      	cmp	w12, #0x22
     30c:      	b.eq	0x4f8 <trace_event_type_switch_dispatch_xdp+0x4f8>
     310:      	cmp	w12, #0x23
     314:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     318:      	mov	w12, #0x1b              // =27
     31c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     320:      	cmp	w12, #0x12
     324:      	b.eq	0x500 <trace_event_type_switch_dispatch_xdp+0x500>
     328:      	cmp	w12, #0x13
     32c:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     330:      	mov	w12, #0x6               // =6
     334:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     338:      	cmp	w12, #0x32
     33c:      	b.eq	0x508 <trace_event_type_switch_dispatch_xdp+0x508>
     340:      	cmp	w12, #0x33
     344:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     348:      	mov	w12, #0x3               // =3
     34c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     350:      	cmp	w12, #0xa
     354:      	b.eq	0x510 <trace_event_type_switch_dispatch_xdp+0x510>
     358:      	cmp	w12, #0xb
     35c:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     360:      	mov	w12, #0x24              // =36
     364:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     368:      	cmp	w12, #0x2a
     36c:      	b.eq	0x518 <trace_event_type_switch_dispatch_xdp+0x518>
     370:      	cmp	w12, #0x2b
     374:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     378:      	mov	w12, #0x23              // =35
     37c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     380:      	cmp	w12, #0x1a
     384:      	b.eq	0x520 <trace_event_type_switch_dispatch_xdp+0x520>
     388:      	cmp	w12, #0x1b
     38c:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     390:      	mov	w12, #0x29              // =41
     394:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     398:      	cmp	w12, #0x3a
     39c:      	b.eq	0x528 <trace_event_type_switch_dispatch_xdp+0x528>
     3a0:      	cmp	w12, #0x3b
     3a4:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     3a8:      	mov	w12, #0x10              // =16
     3ac:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     3b0:      	cmp	w12, #0x6
     3b4:      	b.eq	0x530 <trace_event_type_switch_dispatch_xdp+0x530>
     3b8:      	cmp	w12, #0x7
     3bc:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     3c0:      	mov	w12, #0x3a              // =58
     3c4:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     3c8:      	cmp	w12, #0x26
     3cc:      	b.eq	0x538 <trace_event_type_switch_dispatch_xdp+0x538>
     3d0:      	cmp	w12, #0x27
     3d4:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     3d8:      	mov	w12, #0x30              // =48
     3dc:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     3e0:      	cmp	w12, #0x16
     3e4:      	b.eq	0x540 <trace_event_type_switch_dispatch_xdp+0x540>
     3e8:      	cmp	w12, #0x17
     3ec:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     3f0:      	mov	w12, #0x28              // =40
     3f4:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     3f8:      	cmp	w12, #0x36
     3fc:      	b.eq	0x548 <trace_event_type_switch_dispatch_xdp+0x548>
     400:      	cmp	w12, #0x37
     404:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     408:      	mov	w12, #0x12              // =18
     40c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     410:      	cmp	w12, #0xe
     414:      	b.eq	0x550 <trace_event_type_switch_dispatch_xdp+0x550>
     418:      	cmp	w12, #0xf
     41c:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     420:      	mov	w12, #0x2e              // =46
     424:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     428:      	cmp	w12, #0x2e
     42c:      	b.eq	0x558 <trace_event_type_switch_dispatch_xdp+0x558>
     430:      	cmp	w12, #0x2f
     434:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     438:      	mov	w12, #0x3b              // =59
     43c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     440:      	cmp	w12, #0x1e
     444:      	b.eq	0x560 <trace_event_type_switch_dispatch_xdp+0x560>
     448:      	cmp	w12, #0x1f
     44c:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     450:      	mov	w12, #0x34              // =52
     454:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     458:      	cmp	w12, #0x3e
     45c:      	b.eq	0x44 <trace_event_type_switch_dispatch_xdp+0x44>
     460:      	cmp	w12, #0x3f
     464:      	b.ne	0x568 <trace_event_type_switch_dispatch_xdp+0x568>
     468:      	mov	w12, #0x37              // =55
     46c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     470:      	mov	w12, #0x38              // =56
     474:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     478:      	mov	w12, #0x19              // =25
     47c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     480:      	mov	w12, #0x22              // =34
     484:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     488:      	mov	w12, #0x2d              // =45
     48c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     490:      	mov	w12, #0x2               // =2
     494:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     498:      	mov	w12, #0x20              // =32
     49c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     4a0:      	mov	w12, #0x26              // =38
     4a4:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     4a8:      	mov	w12, #0x1               // =1
     4ac:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     4b0:      	mov	w12, #0xe               // =14
     4b4:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     4b8:      	mov	w12, #0x35              // =53
     4bc:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     4c0:      	mov	w12, #0x1d              // =29
     4c4:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     4c8:      	mov	w12, #0xd               // =13
     4cc:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     4d0:      	mov	w12, #0x13              // =19
     4d4:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     4d8:      	mov	w12, #0x8               // =8
     4dc:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     4e0:      	mov	w12, #0x21              // =33
     4e4:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     4e8:      	mov	w12, #0x3c              // =60
     4ec:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     4f0:      	mov	w12, #0x39              // =57
     4f4:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     4f8:      	mov	w12, #0xb               // =11
     4fc:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     500:      	mov	w12, #0x2f              // =47
     504:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     508:      	mov	w12, #0x9               // =9
     50c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     510:      	mov	w12, #0x31              // =49
     514:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     518:      	mov	w12, #0x7               // =7
     51c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     520:      	mov	w12, #0x11              // =17
     524:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     528:      	mov	w12, #0x16              // =22
     52c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     530:      	mov	w12, #0xa               // =10
     534:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     538:      	mov	w12, #0x18              // =24
     53c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     540:      	mov	w12, #0xf               // =15
     544:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     548:      	mov	w12, #0x1e              // =30
     54c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     550:      	mov	w12, #0x25              // =37
     554:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     558:      	mov	w12, #0x33              // =51
     55c:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     560:      	mov	w12, #0x17              // =23
     564:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     568:      	mov	w12, #0xbf52            // =48978
     56c:      	movk	w12, #0x1, lsl #16
     570:      	b	0x48 <trace_event_type_switch_dispatch_xdp+0x48>
     574:      	lsr	x9, x12, #8
     578:      	lsr	x11, x12, #16
     57c:      	mov	w0, #0x2                // =2
     580:      	strb	w12, [x8]
     584:      	strb	w9, [x8, #0x1]
     588:      	lsr	x9, x10, #24
     58c:      	strb	w11, [x8, #0x2]
     590:      	lsr	x11, x10, #32
     594:      	strb	w9, [x8, #0x3]
     598:      	lsr	x9, x10, #40
     59c:      	strb	w11, [x8, #0x4]
     5a0:      	strb	w9, [x8, #0x5]
     5a4:      	lsr	x9, x10, #48
     5a8:      	strb	w9, [x8, #0x6]
     5ac:      	lsr	x9, x10, #56
     5b0:      	strb	w9, [x8, #0x7]
     5b4:      	ret
