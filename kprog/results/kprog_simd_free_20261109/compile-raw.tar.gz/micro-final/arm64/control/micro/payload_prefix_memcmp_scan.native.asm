
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/payload_prefix_memcmp_scan.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <payload_prefix_memcmp_scan_xdp>:
       0:      	ldp	x8, x10, [x0]
       4:      	mov	x9, x8
       8:      	cmp	x9, x10
       c:      	b.hi	0xa4 <payload_prefix_memcmp_scan_xdp+0xa4>
      10:      	add	x11, x9, #0x8
      14:      	add	x12, x9, #0xcc
      18:      	cmp	x11, x10
      1c:      	ccmp	x12, x10, #0x2, ls
      20:      	b.hi	0xa4 <payload_prefix_memcmp_scan_xdp+0xa4>
      24:      	ldr	w10, [x11]
      28:      	cmp	w10, #0x3
      2c:      	b.ne	0xa4 <payload_prefix_memcmp_scan_xdp+0xa4>
      30:      	mov	x13, #0xc90e            // =51470
      34:      	mov	w10, wzr
      38:      	mov	x11, xzr
      3c:      	add	x12, x9, #0xc
      40:      	mov	w14, #0xa5              // =165
      44:      	movk	x13, #0xf3bc, lsl #16
      48:      	movk	x13, #0xe667, lsl #32
      4c:      	movk	x13, #0x6a09, lsl #48
      50:      	nop
      54:      	nop
      58:      	nop
      5c:      	nop
      60:      	ldrb	w15, [x12], #0x1
      64:      	eor	w16, w11, w10
      68:      	eor	w16, w16, w14
      6c:      	add	w16, w16, #0x11
      70:      	cmp	w15, w16, uxtb
      74:      	b.ne	0xac <payload_prefix_memcmp_scan_xdp+0xac>
      78:      	add	x11, x11, #0x4
      7c:      	add	w10, w10, #0x1d
      80:      	add	x13, x13, #0x5
      84:      	cmp	x11, #0x100
      88:      	b.ne	0x60 <payload_prefix_memcmp_scan_xdp+0x60>
      8c:      	ldrb	w10, [x9, #0x4b]
      90:      	mov	x11, #0xb51c            // =46364
      94:      	movk	x11, #0x8cf6, lsl #16
      98:      	movk	x11, #0x9fde, lsl #32
      9c:      	movk	x11, #0xf43e, lsl #48
      a0:      	b	0xb4 <payload_prefix_memcmp_scan_xdp+0xb4>
      a4:      	mov	w0, wzr
      a8:      	ret
      ac:      	eor	x10, x13, x15
      b0:      	and	w11, w16, #0xff
      b4:      	add	x10, x10, x11
      b8:      	mov	w11, wzr
      bc:      	mov	x12, xzr
      c0:      	add	x13, x9, #0x4c
      c4:      	mov	x14, #-0x6              // =-6
      c8:      	mov	w15, #0xa5              // =165
      cc:      	ror	x10, x10, #0x3b
      d0:      	nop
      d4:      	nop
      d8:      	nop
      dc:      	nop
      e0:      	ldrb	w16, [x13], #0x1
      e4:      	eor	w17, w12, w11
      e8:      	eor	w17, w17, w15
      ec:      	add	w17, w17, #0x11
      f0:      	cmp	w16, w17, uxtb
      f4:      	b.ne	0x12c <payload_prefix_memcmp_scan_xdp+0x12c>
      f8:      	add	x12, x12, #0x4
      fc:      	sub	x14, x14, #0x6
     100:      	add	w11, w11, #0x1d
     104:      	cmp	x12, #0x100
     108:      	b.ne	0xe0 <payload_prefix_memcmp_scan_xdp+0xe0>
     10c:      	mov	x11, #0x7c16            // =31766
     110:      	movk	x11, #0x7f4a, lsl #16
     114:      	movk	x11, #0x79b9, lsl #32
     118:      	movk	x11, #0x9e37, lsl #48
     11c:      	eor	x10, x10, x11
     120:      	ldrb	w11, [x9, #0x8b]
     124:      	add	x10, x10, x11, lsl #8
     128:      	b	0x13c <payload_prefix_memcmp_scan_xdp+0x13c>
     12c:      	sub	x10, x10, x14
     130:      	and	w11, w17, #0xff
     134:      	eor	x10, x10, x16, lsl #8
     138:      	add	x10, x10, x11
     13c:      	mov	w11, wzr
     140:      	mov	x12, xzr
     144:      	ror	x10, x10, #0x3a
     148:      	add	x13, x9, #0x8c
     14c:      	mov	x14, #-0x7              // =-7
     150:      	mov	w15, #0xa5              // =165
     154:      	nop
     158:      	nop
     15c:      	nop
     160:      	ldrb	w16, [x13], #0x1
     164:      	eor	w17, w12, w11
     168:      	eor	w17, w17, w15
     16c:      	add	w17, w17, #0x11
     170:      	cmp	w16, w17, uxtb
     174:      	b.ne	0x1bc <payload_prefix_memcmp_scan_xdp+0x1bc>
     178:      	add	x12, x12, #0x4
     17c:      	sub	x14, x14, #0x7
     180:      	add	w11, w11, #0x1d
     184:      	cmp	x12, #0x100
     188:      	b.ne	0x160 <payload_prefix_memcmp_scan_xdp+0x160>
     18c:      	mov	x11, #0x7c16            // =31766
     190:      	ldrb	w9, [x9, #0xcb]
     194:      	movk	x11, #0x7f4a, lsl #16
     198:      	movk	x11, #0x79b9, lsl #32
     19c:      	movk	x11, #0x9e37, lsl #48
     1a0:      	orr	x11, x11, #0x1
     1a4:      	eor	x10, x10, x11
     1a8:      	add	x9, x10, x9, lsl #16
     1ac:      	ror	x9, x9, #0x39
     1b0:      	mov	w0, #0x2                // =2
     1b4:      	str	x9, [x8]
     1b8:      	ret
     1bc:      	sub	x9, x10, x14
     1c0:      	and	w10, w17, #0xff
     1c4:      	eor	x9, x9, x16, lsl #16
     1c8:      	add	x9, x9, x10
     1cc:      	ror	x9, x9, #0x39
     1d0:      	mov	w0, #0x2                // =2
     1d4:      	str	x9, [x8]
     1d8:      	ret
