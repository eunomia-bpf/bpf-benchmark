/var/tmp/kprog-tmp/S14/micro-final/arm64/control/stage2/unchecked_packet_read.native.o: \
  unchecked_packet_read.bpf.c include/native_helpers.h \
  include/../../../micro/programs/common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h
include/native_helpers.h:
include/../../../micro/programs/common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/micro/kernel_offsets.h:
