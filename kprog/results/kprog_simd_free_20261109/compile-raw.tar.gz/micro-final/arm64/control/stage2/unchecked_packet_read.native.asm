
/var/tmp/kprog-tmp/S14/micro-final/arm64/control/stage2/unchecked_packet_read.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <unchecked_packet_read>:
       0:      	ldr	x8, [x0]
       4:      	ldrb	w0, [x8, #0x40]
       8:      	ret
