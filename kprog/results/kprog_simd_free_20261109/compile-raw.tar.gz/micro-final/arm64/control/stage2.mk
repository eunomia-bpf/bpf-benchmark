include /var/tmp/kprog-tmp/S14/native-stage2.mk
NATIVE_CFLAGS := $(filter-out -shared,$(NATIVE_CFLAGS)) -c 
