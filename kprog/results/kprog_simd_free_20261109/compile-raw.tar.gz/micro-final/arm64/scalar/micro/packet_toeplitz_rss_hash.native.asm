
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/packet_toeplitz_rss_hash.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <packet_toeplitz_rss_hash_xdp>:
       0:      	ldp	x8, x10, [x0]
       4:      	mov	x9, x8
       8:      	cmp	x9, x10
       c:      	b.hi	0x68 <packet_toeplitz_rss_hash_xdp+0x68>
      10:      	add	x11, x9, #0x8
      14:      	add	x12, x9, #0x3e
      18:      	cmp	x11, x10
      1c:      	ccmp	x12, x10, #0x2, ls
      20:      	b.hi	0x68 <packet_toeplitz_rss_hash_xdp+0x68>
      24:      	ldrh	w10, [x9, #0x14]
      28:      	rev16	w10, w10
      2c:      	cmp	w10, #0x800
      30:      	b.ne	0x68 <packet_toeplitz_rss_hash_xdp+0x68>
      34:      	ldrb	w10, [x9, #0x16]
      38:      	and	w10, w10, #0xf
      3c:      	cmp	w10, #0x5
      40:      	b.ne	0x68 <packet_toeplitz_rss_hash_xdp+0x68>
      44:      	mov	x11, x9
      48:      	ldrb	w10, [x11, #0x1f]!
      4c:      	cmp	w10, #0x6
      50:      	b.ne	0x68 <packet_toeplitz_rss_hash_xdp+0x68>
      54:      	mov	w10, wzr
      58:      	mov	w12, wzr
      5c:      	add	x13, x9, #0x22
      60:      	mov	w14, #0x8               // =8
      64:      	b	0xa0 <packet_toeplitz_rss_hash_xdp+0xa0>
      68:      	mov	w0, wzr
      6c:      	ret
      70:      	mov	w18, #0xc2              // =194
      74:      	nop
      78:      	nop
      7c:      	nop
      80:      	lsl	w16, w17, w15
      84:      	sub	w15, w14, w15
      88:      	lsr	w15, w18, w15
      8c:      	orr	w17, w15, w16
      90:      	eor	w10, w17, w10
      94:      	add	w12, w12, #0x1
      98:      	cmp	w12, #0x68
      9c:      	b.eq	0x2bc <packet_toeplitz_rss_hash_xdp+0x2bc>
      a0:      	lsr	w16, w12, #3
      a4:      	cmp	w12, #0x1f
      a8:      	b.ls	0xc8 <packet_toeplitz_rss_hash_xdp+0xc8>
      ac:      	cmp	w12, #0x3f
      b0:      	b.ls	0xc8 <packet_toeplitz_rss_hash_xdp+0xc8>
      b4:      	cmp	w12, #0x4f
      b8:      	b.ls	0xc8 <packet_toeplitz_rss_hash_xdp+0xc8>
      bc:      	cmp	w12, #0x5f
      c0:      	mov	x15, x11
      c4:      	b.hi	0xcc <packet_toeplitz_rss_hash_xdp+0xcc>
      c8:      	add	x15, x13, w16, uxtw
      cc:      	ldrb	w17, [x15]
      d0:      	and	w15, w12, #0x7
      d4:      	lsl	w17, w17, w15
      d8:      	tbz	w17, #0x7, 0x94 <packet_toeplitz_rss_hash_xdp+0x94>
      dc:      	cmp	w16, #0x5
      e0:      	b.le	0x10c <packet_toeplitz_rss_hash_xdp+0x10c>
      e4:      	cmp	w16, #0x8
      e8:      	b.le	0x130 <packet_toeplitz_rss_hash_xdp+0x130>
      ec:      	cmp	w16, #0xa
      f0:      	b.gt	0x170 <packet_toeplitz_rss_hash_xdp+0x170>
      f4:      	cmp	w16, #0x9
      f8:      	b.ne	0x1c8 <packet_toeplitz_rss_hash_xdp+0x1c8>
      fc:      	mov	w18, #0x3d00            // =15616
     100:      	mov	w17, #0x43              // =67
     104:      	movk	w18, #0x6725, lsl #16
     108:      	b	0x204 <packet_toeplitz_rss_hash_xdp+0x204>
     10c:      	cmp	w16, #0x2
     110:      	b.gt	0x150 <packet_toeplitz_rss_hash_xdp+0x150>
     114:      	cbz	w16, 0x198 <packet_toeplitz_rss_hash_xdp+0x198>
     118:      	cmp	w16, #0x1
     11c:      	b.ne	0x1e8 <packet_toeplitz_rss_hash_xdp+0x1e8>
     120:      	mov	w18, #0xda00            // =55808
     124:      	mov	w17, #0x25              // =37
     128:      	movk	w18, #0x5a56, lsl #16
     12c:      	b	0x204 <packet_toeplitz_rss_hash_xdp+0x204>
     130:      	cmp	w16, #0x6
     134:      	b.eq	0x188 <packet_toeplitz_rss_hash_xdp+0x188>
     138:      	cmp	w16, #0x7
     13c:      	b.ne	0x1b8 <packet_toeplitz_rss_hash_xdp+0x1b8>
     140:      	mov	w18, #0x6700            // =26368
     144:      	mov	w17, #0x25              // =37
     148:      	movk	w18, #0xc241, lsl #16
     14c:      	b	0x204 <packet_toeplitz_rss_hash_xdp+0x204>
     150:      	cmp	w16, #0x3
     154:      	b.eq	0x1a8 <packet_toeplitz_rss_hash_xdp+0x1a8>
     158:      	cmp	w16, #0x4
     15c:      	b.ne	0x1f8 <packet_toeplitz_rss_hash_xdp+0x1f8>
     160:      	mov	w18, #0xe00             // =3584
     164:      	mov	w17, #0xc2              // =194
     168:      	movk	w18, #0x255b, lsl #16
     16c:      	b	0x204 <packet_toeplitz_rss_hash_xdp+0x204>
     170:      	cmp	w16, #0xb
     174:      	b.ne	0x1d8 <packet_toeplitz_rss_hash_xdp+0x1d8>
     178:      	mov	w18, #0xa300            // =41728
     17c:      	mov	w17, #0x8f              // =143
     180:      	movk	w18, #0x3d43, lsl #16
     184:      	b	0x204 <packet_toeplitz_rss_hash_xdp+0x204>
     188:      	mov	w18, #0x4100            // =16640
     18c:      	mov	w17, #0x67              // =103
     190:      	movk	w18, #0xec2, lsl #16
     194:      	b	0x204 <packet_toeplitz_rss_hash_xdp+0x204>
     198:      	mov	w18, #0x5600            // =22016
     19c:      	mov	w17, #0xda              // =218
     1a0:      	movk	w18, #0x6d5a, lsl #16
     1a4:      	b	0x204 <packet_toeplitz_rss_hash_xdp+0x204>
     1a8:      	mov	w18, #0x5b00            // =23296
     1ac:      	mov	w17, #0xe               // =14
     1b0:      	movk	w18, #0xda25, lsl #16
     1b4:      	b	0x204 <packet_toeplitz_rss_hash_xdp+0x204>
     1b8:      	mov	w18, #0x2500            // =9472
     1bc:      	mov	w17, #0x3d              // =61
     1c0:      	movk	w18, #0x4167, lsl #16
     1c4:      	b	0x204 <packet_toeplitz_rss_hash_xdp+0x204>
     1c8:      	mov	w18, #0x4300            // =17152
     1cc:      	mov	w17, #0xa3              // =163
     1d0:      	movk	w18, #0x253d, lsl #16
     1d4:      	b	0x204 <packet_toeplitz_rss_hash_xdp+0x204>
     1d8:      	mov	w18, #0x8f00            // =36608
     1dc:      	mov	w17, #0xb0              // =176
     1e0:      	movk	w18, #0x43a3, lsl #16
     1e4:      	b	0x204 <packet_toeplitz_rss_hash_xdp+0x204>
     1e8:      	mov	w18, #0x2500            // =9472
     1ec:      	mov	w17, #0x5b              // =91
     1f0:      	movk	w18, #0x56da, lsl #16
     1f4:      	b	0x204 <packet_toeplitz_rss_hash_xdp+0x204>
     1f8:      	mov	w18, #0xc200            // =49664
     1fc:      	mov	w17, #0x41              // =65
     200:      	movk	w18, #0x5b0e, lsl #16
     204:      	orr	w17, w17, w18
     208:      	cbz	w15, 0x90 <packet_toeplitz_rss_hash_xdp+0x90>
     20c:      	mov	w18, #0x25              // =37
     210:      	cmp	w16, #0x5
     214:      	b.le	0x238 <packet_toeplitz_rss_hash_xdp+0x238>
     218:      	cmp	w16, #0x8
     21c:      	b.le	0x254 <packet_toeplitz_rss_hash_xdp+0x254>
     220:      	cmp	w16, #0xa
     224:      	b.gt	0x284 <packet_toeplitz_rss_hash_xdp+0x284>
     228:      	cmp	w16, #0x9
     22c:      	b.ne	0x29c <packet_toeplitz_rss_hash_xdp+0x29c>
     230:      	mov	w18, #0xa3              // =163
     234:      	b	0x80 <packet_toeplitz_rss_hash_xdp+0x80>
     238:      	cmp	w16, #0x2
     23c:      	b.gt	0x26c <packet_toeplitz_rss_hash_xdp+0x26c>
     240:      	cbz	w16, 0x80 <packet_toeplitz_rss_hash_xdp+0x80>
     244:      	cmp	w16, #0x1
     248:      	b.ne	0x2ac <packet_toeplitz_rss_hash_xdp+0x2ac>
     24c:      	mov	w18, #0x5b              // =91
     250:      	b	0x80 <packet_toeplitz_rss_hash_xdp+0x80>
     254:      	cmp	w16, #0x6
     258:      	b.eq	0x80 <packet_toeplitz_rss_hash_xdp+0x80>
     25c:      	cmp	w16, #0x7
     260:      	b.ne	0x294 <packet_toeplitz_rss_hash_xdp+0x294>
     264:      	mov	w18, #0x3d              // =61
     268:      	b	0x80 <packet_toeplitz_rss_hash_xdp+0x80>
     26c:      	cmp	w16, #0x3
     270:      	b.eq	0x70 <packet_toeplitz_rss_hash_xdp+0x70>
     274:      	cmp	w16, #0x4
     278:      	b.ne	0x2b4 <packet_toeplitz_rss_hash_xdp+0x2b4>
     27c:      	mov	w18, #0x41              // =65
     280:      	b	0x80 <packet_toeplitz_rss_hash_xdp+0x80>
     284:      	cmp	w16, #0xb
     288:      	b.ne	0x2a4 <packet_toeplitz_rss_hash_xdp+0x2a4>
     28c:      	mov	w18, #0xb0              // =176
     290:      	b	0x80 <packet_toeplitz_rss_hash_xdp+0x80>
     294:      	mov	w18, #0x43              // =67
     298:      	b	0x80 <packet_toeplitz_rss_hash_xdp+0x80>
     29c:      	mov	w18, #0x8f              // =143
     2a0:      	b	0x80 <packet_toeplitz_rss_hash_xdp+0x80>
     2a4:      	mov	w18, #0xd0              // =208
     2a8:      	b	0x80 <packet_toeplitz_rss_hash_xdp+0x80>
     2ac:      	mov	w18, #0xe               // =14
     2b0:      	b	0x80 <packet_toeplitz_rss_hash_xdp+0x80>
     2b4:      	mov	w18, #0x67              // =103
     2b8:      	b	0x80 <packet_toeplitz_rss_hash_xdp+0x80>
     2bc:      	ldur	w11, [x9, #0x22]
     2c0:      	ldur	w12, [x9, #0x26]
     2c4:      	mov	w0, #0x2                // =2
     2c8:      	eor	w11, w12, w11
     2cc:      	ldrb	w13, [x9, #0x2a]
     2d0:      	ldrb	w14, [x9, #0x2b]
     2d4:      	ldrb	w15, [x9, #0x2c]
     2d8:      	ldrb	w9, [x9, #0x2d]
     2dc:      	lsl	x13, x13, #56
     2e0:      	rev	w11, w11
     2e4:      	orr	x13, x13, x14, lsl #48
     2e8:      	eor	w12, w11, w10
     2ec:      	orr	x13, x13, x15, lsl #40
     2f0:      	orr	x12, x12, x10, lsl #32
     2f4:      	orr	x11, x13, x11
     2f8:      	and	w10, w10, #0x7
     2fc:      	orr	x9, x11, x9, lsl #32
     300:      	add	w11, w10, #0x1
     304:      	eor	w10, w10, #0x3f
     308:      	lsl	x11, x9, x11
     30c:      	lsr	x9, x9, x10
     310:      	orr	x9, x11, x9
     314:      	eor	x9, x9, x12
     318:      	str	x9, [x8]
     31c:      	ret
