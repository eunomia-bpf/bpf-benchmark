/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/cilium_policy_guard_tree_filter.native.so: \
  cilium_policy_guard_tree_filter.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h:
