/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/simple_packet.native.so: \
  simple_packet.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h:
