/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/cilium_socket_lb_service_select.native.so: \
  cilium_socket_lb_service_select.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h:
