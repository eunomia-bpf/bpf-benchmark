/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/cgroup_skb_hash_chain.native.so: \
  cgroup_skb_hash_chain.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h:
