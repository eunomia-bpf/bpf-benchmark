
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/bpf_local_call_fanout_dispatch.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <bpf_local_call_fanout_dispatch_xdp>:
       0:      	str	x30, [sp, #-0x50]!
       4:      	stp	x26, x25, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	ldp	x21, x9, [x0]
      18:      	mov	x8, x21
      1c:      	cmp	x8, x9
      20:      	b.hi	0x48 <bpf_local_call_fanout_dispatch_xdp+0x48>
      24:      	add	x19, x8, #0x8
      28:      	add	x10, x8, #0x190
      2c:      	cmp	x19, x9
      30:      	ccmp	x10, x9, #0x2, ls
      34:      	b.hi	0x48 <bpf_local_call_fanout_dispatch_xdp+0x48>
      38:      	ldp	w9, w10, [x8, #0x8]
      3c:      	cmp	w9, #0x10
      40:      	ccmp	w10, #0x18, #0x0, eq
      44:      	b.eq	0x64 <bpf_local_call_fanout_dispatch_xdp+0x64>
      48:      	mov	w0, wzr
      4c:      	ldp	x20, x19, [sp, #0x40]
      50:      	ldp	x22, x21, [sp, #0x30]
      54:      	ldp	x24, x23, [sp, #0x20]
      58:      	ldp	x26, x25, [sp, #0x10]
      5c:      	ldr	x30, [sp], #0x50
      60:      	ret
      64:      	mov	x0, #0x8d3              // =2259
      68:      	mov	x22, xzr
      6c:      	mov	w23, wzr
      70:      	mov	x24, xzr
      74:      	add	x25, x8, #0x10
      78:      	movk	x0, #0x85a3, lsl #16
      7c:      	movk	x0, #0x6a88, lsl #32
      80:      	movk	x0, #0x243f, lsl #48
      84:      	b	0xb0 <bpf_local_call_fanout_dispatch_xdp+0xb0>
      88:      	bl	0x180 <local_call_pressure>
      8c:      	and	x8, x24, #0x38
      90:      	add	x24, x24, #0x8
      94:      	add	w23, w23, #0x10
      98:      	add	x22, x22, #0x18
      9c:      	lsl	x8, x26, x8
      a0:      	cmp	x24, #0x80
      a4:      	add	x8, x8, w20, uxtw
      a8:      	eor	x0, x0, x8
      ac:      	b.eq	0x108 <bpf_local_call_fanout_dispatch_xdp+0x108>
      b0:      	add	x8, x25, x22
      b4:      	mov	x1, x19
      b8:      	add	x2, x22, #0x8
      bc:      	ldrb	w9, [x8]
      c0:      	ldr	w8, [x8, #0x4]
      c4:      	and	x26, x9, #0x3
      c8:      	eor	w20, w8, w23
      cc:      	mov	w3, w20
      d0:      	cmp	w26, #0x2
      d4:      	b.eq	0xec <bpf_local_call_fanout_dispatch_xdp+0xec>
      d8:      	cmp	w26, #0x1
      dc:      	b.eq	0x88 <bpf_local_call_fanout_dispatch_xdp+0x88>
      e0:      	cbnz	w26, 0x100 <bpf_local_call_fanout_dispatch_xdp+0x100>
      e4:      	bl	0x130 <local_call_linear>
      e8:      	b	0x8c <bpf_local_call_fanout_dispatch_xdp+0x8c>
      ec:      	bl	0x1d0 <local_call_crossload>
      f0:      	b	0x8c <bpf_local_call_fanout_dispatch_xdp+0x8c>
      f4:      	nop
      f8:      	nop
      fc:      	nop
     100:      	bl	0x250 <local_call_bytes>
     104:      	b	0x8c <bpf_local_call_fanout_dispatch_xdp+0x8c>
     108:      	str	x0, [x21]
     10c:      	mov	w0, #0x2                // =2
     110:      	ldp	x20, x19, [sp, #0x40]
     114:      	ldp	x22, x21, [sp, #0x30]
     118:      	ldp	x24, x23, [sp, #0x20]
     11c:      	ldp	x26, x25, [sp, #0x10]
     120:      	ldr	x30, [sp], #0x50
     124:      	ret
     128:      	nop
     12c:      	nop

0000000000000130 <local_call_linear>:
     130:      	add	x8, x1, w2, uxtw
     134:      	mov	w11, w3
     138:      	add	x12, x11, x0
     13c:      	ldp	x8, x9, [x8, #0x8]
     140:      	add	x10, x8, x8, lsl #1
     144:      	add	x9, x12, x9
     148:      	add	x9, x9, x10
     14c:      	add	x10, x9, x11, lsl #11
     150:      	and	w11, w3, #0x7
     154:      	add	w12, w11, #0x1
     158:      	eor	w11, w11, #0x3f
     15c:      	lsl	x12, x10, x12
     160:      	lsr	x10, x10, x11
     164:      	orr	x10, x12, x10
     168:      	eor	x9, x10, x9
     16c:      	add	x0, x9, x8, lsr #3
     170:      	ret
     174:      	nop
     178:      	nop
     17c:      	nop

0000000000000180 <local_call_pressure>:
     180:      	add	x8, x1, w2, uxtw
     184:      	mov	w11, w3
     188:      	ldp	x8, x9, [x8, #0x8]
     18c:      	eor	x10, x8, x0
     190:      	add	x11, x9, x11, lsl #17
     194:      	lsr	x9, x9, #2
     198:      	eor	x9, x9, x10, lsl #3
     19c:      	eor	x8, x11, x8
     1a0:      	add	x12, x9, x10
     1a4:      	ror	x8, x8, #0x3b
     1a8:      	ror	x12, x12, #0x35
     1ac:      	add	x8, x12, x8
     1b0:      	eor	x8, x8, x11, lsr #7
     1b4:      	add	x8, x8, x9
     1b8:      	eor	x9, x10, x11
     1bc:      	eor	x0, x9, x8
     1c0:      	ret
     1c4:      	nop
     1c8:      	nop
     1cc:      	nop

00000000000001d0 <local_call_crossload>:
     1d0:      	mov	w8, w2
     1d4:      	add	x9, x1, x8
     1d8:      	add	x8, x8, #0x4
     1dc:      	ldrb	w10, [x9]
     1e0:      	ldrb	w11, [x1, x8]
     1e4:      	add	x8, x1, w8, sxtw
     1e8:      	ldp	x9, x14, [x9, #0x8]
     1ec:      	ldrb	w12, [x8, #0x1]
     1f0:      	ldrb	w13, [x8, #0x2]
     1f4:      	ldrb	w8, [x8, #0x3]
     1f8:      	add	x9, x9, x0
     1fc:      	and	x10, x10, #0x7
     200:      	lsl	x11, x11, #9
     204:      	eor	x14, x14, x9
     208:      	add	x15, x10, #0x1
     20c:      	eor	w16, w10, #0x3f
     210:      	lsl	x15, x14, x15
     214:      	lsr	x14, x14, x16
     218:      	orr	x11, x11, x12, lsl #17
     21c:      	orr	x14, x15, x14
     220:      	orr	x11, x11, x13, lsl #25
     224:      	orr	x8, x11, x8, lsl #33
     228:      	eor	x11, x9, x14
     22c:      	eor	x8, x11, x8
     230:      	mov	w11, w3
     234:      	lsl	x10, x11, x10
     238:      	add	x8, x8, x10
     23c:      	eor	x8, x8, x14, lsr #5
     240:      	add	x0, x8, x9
     244:      	ret
     248:      	nop
     24c:      	nop

0000000000000250 <local_call_bytes>:
     250:      	add	x9, x1, w2, uxtw
     254:      	mov	x11, #0x11eb            // =4587
     258:      	mov	w8, w3
     25c:      	movk	x11, #0x1331, lsl #16
     260:      	ldrb	w10, [x9]
     264:      	movk	x11, #0x49bb, lsl #32
     268:      	movk	x11, #0x94d0, lsl #48
     26c:      	eor	x11, x0, x11
     270:      	eor	x10, x10, x11
     274:      	ldrb	w11, [x9, #0x1]
     278:      	add	x10, x10, x8
     27c:      	lsl	x11, x11, #8
     280:      	eor	x10, x11, x10, ror #63
     284:      	ldrb	w11, [x9, #0x2]
     288:      	add	x10, x8, x10
     28c:      	add	x10, x10, #0x1
     290:      	lsl	x11, x11, #16
     294:      	eor	x10, x11, x10, ror #62
     298:      	ldrb	w11, [x9, #0x3]
     29c:      	add	x10, x8, x10
     2a0:      	add	x10, x10, #0x2
     2a4:      	lsl	x11, x11, #24
     2a8:      	eor	x10, x11, x10, ror #61
     2ac:      	ldrb	w11, [x9, #0x4]
     2b0:      	add	x10, x8, x10
     2b4:      	add	x10, x10, #0x3
     2b8:      	lsl	x11, x11, #32
     2bc:      	eor	x10, x11, x10, ror #60
     2c0:      	ldrb	w11, [x9, #0x5]
     2c4:      	add	x10, x8, x10
     2c8:      	add	x10, x10, #0x4
     2cc:      	lsl	x11, x11, #40
     2d0:      	eor	x10, x11, x10, ror #59
     2d4:      	ldrb	w11, [x9, #0x6]
     2d8:      	add	x10, x8, x10
     2dc:      	add	x10, x10, #0x5
     2e0:      	lsl	x11, x11, #48
     2e4:      	eor	x10, x11, x10, ror #58
     2e8:      	ldrb	w11, [x9, #0x7]
     2ec:      	add	x10, x8, x10
     2f0:      	add	x10, x10, #0x6
     2f4:      	lsl	x11, x11, #56
     2f8:      	eor	x10, x11, x10, ror #57
     2fc:      	add	x8, x8, x10
     300:      	ldp	x9, x10, [x9, #0x8]
     304:      	add	x8, x8, #0x7
     308:      	ror	x8, x8, #0x38
     30c:      	add	x8, x9, x8
     310:      	eor	x0, x10, x8
     314:      	ret
