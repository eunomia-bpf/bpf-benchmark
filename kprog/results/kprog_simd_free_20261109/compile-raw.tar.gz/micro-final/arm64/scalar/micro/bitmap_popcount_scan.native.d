/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/bitmap_popcount_scan.native.so: \
  bitmap_popcount_scan.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h:
