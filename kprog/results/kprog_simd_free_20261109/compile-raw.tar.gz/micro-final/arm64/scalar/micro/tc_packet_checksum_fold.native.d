/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/tc_packet_checksum_fold.native.so: \
  tc_packet_checksum_fold.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h:
