/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/bcc_tcpconnect_ipv4_tuple_filter.native.so: \
  bcc_tcpconnect_ipv4_tuple_filter.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h:
