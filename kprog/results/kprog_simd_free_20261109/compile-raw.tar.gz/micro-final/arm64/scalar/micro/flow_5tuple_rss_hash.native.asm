
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/flow_5tuple_rss_hash.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <flow_5tuple_rss_hash_xdp>:
       0:      	ldp	x8, x11, [x0]
       4:      	add	x9, x8, #0x8
       8:      	cmp	x8, x11
       c:      	ccmp	x9, x11, #0x2, ls
      10:      	b.hi	0x84 <flow_5tuple_rss_hash_xdp+0x84>
      14:      	add	x9, x8, #0x16
      18:      	cmp	x9, x11
      1c:      	b.hi	0x84 <flow_5tuple_rss_hash_xdp+0x84>
      20:      	ldrh	w10, [x8, #0x14]
      24:      	add	x12, x8, #0x2a
      28:      	rev16	w10, w10
      2c:      	cmp	w10, #0x800
      30:      	ccmp	x12, x11, #0x2, eq
      34:      	b.hi	0x84 <flow_5tuple_rss_hash_xdp+0x84>
      38:      	ldrb	w12, [x9]
      3c:      	and	x10, x12, #0xf
      40:      	and	w12, w12, #0xf0
      44:      	cmp	w12, #0x40
      48:      	ccmp	w10, #0x5, #0x0, eq
      4c:      	b.lo	0x84 <flow_5tuple_rss_hash_xdp+0x84>
      50:      	add	x12, x9, x10, lsl #2
      54:      	cmp	x12, x11
      58:      	b.hi	0x84 <flow_5tuple_rss_hash_xdp+0x84>
      5c:      	ldrb	w10, [x8, #0x1f]
      60:      	ldrb	w9, [x8, #0x18]
      64:      	cmp	w10, #0x11
      68:      	ldrb	w13, [x8, #0x19]
      6c:      	b.eq	0x78 <flow_5tuple_rss_hash_xdp+0x78>
      70:      	cmp	w10, #0x6
      74:      	b.ne	0x84 <flow_5tuple_rss_hash_xdp+0x84>
      78:      	add	x14, x12, #0x4
      7c:      	cmp	x14, x11
      80:      	b.ls	0x8c <flow_5tuple_rss_hash_xdp+0x8c>
      84:      	mov	w0, wzr
      88:      	ret
      8c:      	ldrh	w14, [x12]
      90:      	ldrh	w11, [x12, #0x2]
      94:      	mov	w17, #0x5678            // =22136
      98:      	orr	w13, w13, w9, lsl #8
      9c:      	mov	w0, #0xbeef             // =48879
      a0:      	mov	w1, #0x79b9             // =31161
      a4:      	ldur	w15, [x8, #0x22]
      a8:      	movk	w17, #0x1234, lsl #16
      ac:      	ldur	w16, [x8, #0x26]
      b0:      	movk	w0, #0xdead, lsl #16
      b4:      	movk	w1, #0x9e37, lsl #16
      b8:      	strb	w9, [x8, #0x3]
      bc:      	add	w17, w10, w17
      c0:      	rev	w12, w14
      c4:      	rev	w14, w11
      c8:      	rev	w15, w15
      cc:      	rev	w16, w16
      d0:      	rev16	w9, w11
      d4:      	lsr	w12, w12, #16
      d8:      	add	w18, w13, w15
      dc:      	eor	w15, w15, w16
      e0:      	extr	w14, w12, w14, #0x10
      e4:      	ror	w15, w15, #0x19
      e8:      	add	w17, w17, w14
      ec:      	sub	w18, w18, w17
      f0:      	add	w18, w18, w0
      f4:      	add	w0, w16, w1
      f8:      	eor	w18, w18, w17, ror #28
      fc:      	add	w17, w17, w0
     100:      	sub	w1, w0, w18
     104:      	eor	w0, w1, w18, ror #26
     108:      	sub	w1, w17, w0
     10c:      	add	w17, w18, w17
     110:      	eor	w18, w1, w0, ror #24
     114:      	sub	w1, w17, w18
     118:      	add	w17, w0, w17
     11c:      	eor	w0, w1, w18, ror #16
     120:      	sub	w1, w17, w0
     124:      	add	w17, w18, w17
     128:      	eor	w18, w1, w0, ror #13
     12c:      	add	w0, w0, w17
     130:      	orr	w1, w13, w10, lsl #24
     134:      	bfi	x10, x12, #8, #16
     138:      	sub	w17, w17, w18
     13c:      	add	w14, w0, w14
     140:      	add	w15, w0, w15
     144:      	mov	w0, #0x2                // =2
     148:      	eor	w17, w17, w18, ror #28
     14c:      	add	w14, w14, w18
     150:      	eor	x9, x10, x9
     154:      	ubfiz	x10, x12, #8, #32
     158:      	add	w16, w17, w1
     15c:      	ror	w17, w14, #0x12
     160:      	eor	w10, w10, w13, lsl #16
     164:      	strb	w9, [x8]
     168:      	lsr	x9, x9, #8
     16c:      	eor	w16, w16, w14
     170:      	lsr	w10, w10, #16
     174:      	strb	w9, [x8, #0x1]
     178:      	sub	w16, w16, w17
     17c:      	strb	w10, [x8, #0x2]
     180:      	eor	w15, w16, w15
     184:      	ror	w17, w16, #0x15
     188:      	sub	w15, w15, w17
     18c:      	eor	w14, w15, w14
     190:      	ror	w17, w15, #0x7
     194:      	sub	w14, w14, w17
     198:      	eor	w16, w14, w16
     19c:      	ror	w17, w14, #0x10
     1a0:      	sub	w16, w16, w17
     1a4:      	eor	w15, w16, w15
     1a8:      	ror	w17, w16, #0x1c
     1ac:      	sub	w15, w15, w17
     1b0:      	eor	w14, w15, w14
     1b4:      	ror	w15, w15, #0x12
     1b8:      	sub	w14, w14, w15
     1bc:      	eor	w11, w14, w16
     1c0:      	ror	w12, w14, #0x8
     1c4:      	sub	w9, w11, w12
     1c8:      	lsr	x10, x9, #8
     1cc:      	strb	w9, [x8, #0x4]
     1d0:      	strb	w10, [x8, #0x5]
     1d4:      	lsr	x10, x9, #16
     1d8:      	lsr	x9, x9, #24
     1dc:      	strb	w10, [x8, #0x6]
     1e0:      	strb	w9, [x8, #0x7]
     1e4:      	ret
