
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/tetragon_process_event_arg_filter.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <tetragon_process_event_arg_filter_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x10, x8
       8:      	cmp	x10, x9
       c:      	b.ls	0x18 <tetragon_process_event_arg_filter_xdp+0x18>
      10:      	mov	w0, wzr
      14:      	ret
      18:      	add	x11, x10, #0x8
      1c:      	add	x12, x10, #0x410
      20:      	mov	w0, wzr
      24:      	cmp	x11, x9
      28:      	ccmp	x12, x9, #0x2, ls
      2c:      	b.hi	0x2e4 <tetragon_process_event_arg_filter_xdp+0x2e4>
      30:      	ldr	w9, [x10, #0x8]
      34:      	cmp	w9, #0x20
      38:      	b.ne	0x2e4 <tetragon_process_event_arg_filter_xdp+0x2e4>
      3c:      	ldr	w9, [x10, #0xc]
      40:      	cmp	w9, #0x20
      44:      	b.ne	0x2e4 <tetragon_process_event_arg_filter_xdp+0x2e4>
      48:      	stp	x28, x27, [sp, #-0x50]!
      4c:      	stp	x26, x25, [sp, #0x10]
      50:      	stp	x24, x23, [sp, #0x20]
      54:      	stp	x22, x21, [sp, #0x30]
      58:      	stp	x20, x19, [sp, #0x40]
      5c:      	add	x11, x10, #0x17
      60:      	mov	x10, #0x28db            // =10459
      64:      	mov	x15, #0x7970            // =31088
      68:      	mov	w12, #0x6162            // =24930
      6c:      	mov	w14, #0x7563            // =30051
      70:      	mov	x9, xzr
      74:      	mov	w13, #0x24              // =36
      78:      	mov	w16, #0x6873            // =26739
      7c:      	movk	x10, #0xa0b4, lsl #16
      80:      	movk	x15, #0x6874, lsl #16
      84:      	movk	w12, #0x6873, lsl #16
      88:      	movk	w14, #0x6c72, lsl #16
      8c:      	mov	w17, #0x59              // =89
      90:      	movk	x10, #0x7ed1, lsl #32
      94:      	movk	x15, #0x6e6f, lsl #32
      98:      	movk	x10, #0xe703, lsl #48
      9c:      	b	0xb8 <tetragon_process_event_arg_filter_xdp+0xb8>
      a0:      	orr	x18, x24, x0, lsl #32
      a4:      	eor	x10, x18, x10
      a8:      	add	x9, x9, #0x1
      ac:      	add	x11, x11, #0x20
      b0:      	cmp	x9, #0x20
      b4:      	b.eq	0x2c8 <tetragon_process_event_arg_filter_xdp+0x2c8>
      b8:      	ldrb	w18, [x11, #0x5]
      bc:      	ldrb	w0, [x11, #0x6]
      c0:      	orr	w0, w18, w0, lsl #8
      c4:      	cmp	w0, #0x4
      c8:      	b.gt	0xe4 <tetragon_process_event_arg_filter_xdp+0xe4>
      cc:      	cmp	w0, #0x1
      d0:      	b.eq	0x108 <tetragon_process_event_arg_filter_xdp+0x108>
      d4:      	cmp	w0, #0x2
      d8:      	b.ne	0xfc <tetragon_process_event_arg_filter_xdp+0xfc>
      dc:      	mov	w1, #0x23               // =35
      e0:      	b	0x120 <tetragon_process_event_arg_filter_xdp+0x120>
      e4:      	cmp	w0, #0x5
      e8:      	b.eq	0x110 <tetragon_process_event_arg_filter_xdp+0x110>
      ec:      	cmp	w0, #0x9
      f0:      	b.ne	0xfc <tetragon_process_event_arg_filter_xdp+0xfc>
      f4:      	mov	w1, #0x41               // =65
      f8:      	b	0x120 <tetragon_process_event_arg_filter_xdp+0x120>
      fc:      	cmp	w0, #0xd
     100:      	csel	w1, w17, wzr, eq
     104:      	b	0x120 <tetragon_process_event_arg_filter_xdp+0x120>
     108:      	mov	w1, #0x11               // =17
     10c:      	b	0x120 <tetragon_process_event_arg_filter_xdp+0x120>
     110:      	mov	w1, #0x37               // =55
     114:      	nop
     118:      	nop
     11c:      	nop
     120:      	ldurh	w2, [x11, #0x11]
     124:      	ldrb	w3, [x11, #0x13]
     128:      	orr	x3, x2, x3, lsl #16
     12c:      	ldrb	w2, [x11, #0x14]
     130:      	ldrb	w5, [x11, #0x16]
     134:      	lsl	x5, x5, #40
     138:      	orr	x4, x3, x2, lsl #24
     13c:      	ldrb	w2, [x11, #0x15]
     140:      	cmp	w4, w12
     144:      	orr	x2, x5, x2, lsl #32
     148:      	orr	x2, x2, x4
     14c:      	b.eq	0x168 <tetragon_process_event_arg_filter_xdp+0x168>
     150:      	cmp	w4, w14
     154:      	b.ne	0x180 <tetragon_process_event_arg_filter_xdp+0x180>
     158:      	mov	w22, #0x2               // =2
     15c:      	ldur	w24, [x11, #-0x7]
     160:      	cbnz	w1, 0x1ac <tetragon_process_event_arg_filter_xdp+0x1ac>
     164:      	b	0xa0 <tetragon_process_event_arg_filter_xdp+0xa0>
     168:      	mov	w22, #0x1               // =1
     16c:      	ldur	w24, [x11, #-0x7]
     170:      	cbnz	w1, 0x1ac <tetragon_process_event_arg_filter_xdp+0x1ac>
     174:      	b	0xa0 <tetragon_process_event_arg_filter_xdp+0xa0>
     178:      	nop
     17c:      	nop
     180:      	cmp	x2, x15
     184:      	b.ne	0x198 <tetragon_process_event_arg_filter_xdp+0x198>
     188:      	mov	w22, #0x3               // =3
     18c:      	ldur	w24, [x11, #-0x7]
     190:      	cbnz	w1, 0x1ac <tetragon_process_event_arg_filter_xdp+0x1ac>
     194:      	b	0xa0 <tetragon_process_event_arg_filter_xdp+0xa0>
     198:      	cmp	x3, x16
     19c:      	cset	w3, eq
     1a0:      	lsl	w22, w3, #2
     1a4:      	ldur	w24, [x11, #-0x7]
     1a8:      	cbz	w1, 0xa0 <tetragon_process_event_arg_filter_xdp+0xa0>
     1ac:      	ldrb	w26, [x11, #0x1]
     1b0:      	ldurh	w0, [x11, #0x7]
     1b4:      	cmp	w26, #0x42
     1b8:      	ldrb	w4, [x11, #0x9]
     1bc:      	ldrb	w5, [x11, #0xa]
     1c0:      	ldrb	w6, [x11, #0xb]
     1c4:      	ldrb	w23, [x11, #0xc]
     1c8:      	ldrb	w7, [x11, #0xd]
     1cc:      	ldrb	w21, [x11, #0xe]
     1d0:      	ldrb	w19, [x11, #0xf]
     1d4:      	ldrb	w20, [x11, #0x10]
     1d8:      	ldrb	w25, [x11, #0x17]
     1dc:      	ldrb	w27, [x11, #0x18]
     1e0:      	ldur	w3, [x11, #-0x3]
     1e4:      	b.eq	0x224 <tetragon_process_event_arg_filter_xdp+0x224>
     1e8:      	and	x28, x5, x13
     1ec:      	cbnz	x28, 0x224 <tetragon_process_event_arg_filter_xdp+0x224>
     1f0:      	ldrb	w18, [x11, #0x2]
     1f4:      	ldrb	w0, [x11, #0x3]
     1f8:      	orr	x18, x26, x18, lsl #8
     1fc:      	ldrb	w1, [x11, #0x4]
     200:      	orr	x18, x18, x0, lsl #16
     204:      	orr	x18, x18, x1, lsl #24
     208:      	eor	x18, x18, x3, lsl #16
     20c:      	add	x10, x18, x10
     210:      	add	x9, x9, #0x1
     214:      	add	x11, x11, #0x20
     218:      	cmp	x9, #0x20
     21c:      	b.ne	0xb8 <tetragon_process_event_arg_filter_xdp+0xb8>
     220:      	b	0x2c8 <tetragon_process_event_arg_filter_xdp+0x2c8>
     224:      	lsl	x1, x1, #48
     228:      	orr	x1, x1, x22, lsl #40
     22c:      	orr	x1, x1, x0, lsl #24
     230:      	orr	x1, x1, x24
     234:      	tbz	w0, #0x1, 0x264 <tetragon_process_event_arg_filter_xdp+0x264>
     238:      	cbz	w22, 0x264 <tetragon_process_event_arg_filter_xdp+0x264>
     23c:      	lsl	x22, x27, #56
     240:      	and	x18, x18, #0x7
     244:      	orr	x22, x22, x25, lsl #48
     248:      	orr	x2, x22, x2
     24c:      	add	x22, x18, #0x1
     250:      	eor	w18, w18, #0x3f
     254:      	lsl	x22, x2, x22
     258:      	lsr	x18, x2, x18
     25c:      	orr	x18, x22, x18
     260:      	eor	x1, x1, x18
     264:      	lsl	x18, x23, #24
     268:      	lsl	x2, x21, #40
     26c:      	lsl	x20, x20, #56
     270:      	orr	x4, x4, x5, lsl #8
     274:      	tst	w0, #0x4
     278:      	and	w0, w9, #0x7
     27c:      	orr	x18, x18, x6, lsl #16
     280:      	orr	x2, x2, x7, lsl #32
     284:      	orr	x18, x18, x4
     288:      	orr	x4, x20, x19, lsl #48
     28c:      	orr	x2, x4, x2
     290:      	orr	x18, x2, x18
     294:      	eor	x18, x18, x3
     298:      	csel	x18, xzr, x18, eq
     29c:      	add	x18, x1, x18
     2a0:      	add	w1, w0, #0x1
     2a4:      	eor	w0, w0, #0x3f
     2a8:      	lsl	x1, x18, x1
     2ac:      	lsr	x18, x18, x0
     2b0:      	orr	x18, x1, x18
     2b4:      	eor	x10, x18, x10
     2b8:      	add	x9, x9, #0x1
     2bc:      	add	x11, x11, #0x20
     2c0:      	cmp	x9, #0x20
     2c4:      	b.ne	0xb8 <tetragon_process_event_arg_filter_xdp+0xb8>
     2c8:      	ldp	x20, x19, [sp, #0x40]
     2cc:      	mov	w0, #0x2                // =2
     2d0:      	str	x10, [x8]
     2d4:      	ldp	x22, x21, [sp, #0x30]
     2d8:      	ldp	x24, x23, [sp, #0x20]
     2dc:      	ldp	x26, x25, [sp, #0x10]
     2e0:      	ldp	x28, x27, [sp], #0x50
     2e4:      	ret
