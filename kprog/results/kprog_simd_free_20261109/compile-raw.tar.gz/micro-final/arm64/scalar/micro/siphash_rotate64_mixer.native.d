/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/siphash_rotate64_mixer.native.so: \
  siphash_rotate64_mixer.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h:
