
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/sorted_rule_binary_search.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <sorted_rule_binary_search_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x0, x8
       8:      	cmp	x0, x9
       c:      	b.ls	0x18 <sorted_rule_binary_search_xdp+0x18>
      10:      	mov	w0, wzr
      14:      	ret
      18:      	add	x10, x0, #0x8
      1c:      	add	x11, x0, #0x190
      20:      	cmp	x10, x9
      24:      	ccmp	x11, x9, #0x2, ls
      28:      	b.ls	0x34 <sorted_rule_binary_search_xdp+0x34>
      2c:      	mov	w0, wzr
      30:      	ret
      34:      	ldp	w9, w10, [x0, #0x8]
      38:      	cmp	w9, #0x20
      3c:      	ccmp	w10, #0x10, #0x0, eq
      40:      	b.eq	0x4c <sorted_rule_binary_search_xdp+0x4c>
      44:      	mov	w0, wzr
      48:      	ret
      4c:      	mov	x9, xzr
      50:      	mov	x10, xzr
      54:      	add	x11, x0, #0x110
      58:      	add	x12, x0, #0x111
      5c:      	add	x13, x0, #0x112
      60:      	add	x14, x0, #0x113
      64:      	add	x15, x0, #0x114
      68:      	add	x16, x0, #0x115
      6c:      	add	x17, x0, #0x116
      70:      	add	x18, x0, #0x117
      74:      	add	x0, x0, #0x17
      78:      	nop
      7c:      	nop
      80:      	lsl	x4, x9, #3
      84:      	mov	x2, xzr
      88:      	mov	x1, xzr
      8c:      	ldrb	w5, [x11, x4]
      90:      	ldrb	w6, [x12, x4]
      94:      	mov	w3, wzr
      98:      	orr	x5, x5, x6, lsl #8
      9c:      	ldrb	w6, [x13, x4]
      a0:      	orr	x5, x5, x6, lsl #16
      a4:      	ldrb	w6, [x14, x4]
      a8:      	orr	x5, x5, x6, lsl #24
      ac:      	ldrb	w6, [x15, x4]
      b0:      	orr	x5, x5, x6, lsl #32
      b4:      	ldrb	w6, [x16, x4]
      b8:      	orr	x5, x5, x6, lsl #40
      bc:      	ldrb	w6, [x17, x4]
      c0:      	ldrb	w4, [x18, x4]
      c4:      	orr	x5, x5, x6, lsl #48
      c8:      	orr	x4, x5, x4, lsl #56
      cc:      	mov	x5, x0
      d0:      	nop
      d4:      	nop
      d8:      	nop
      dc:      	nop
      e0:      	ldur	x6, [x5, #-0x7]
      e4:      	add	x5, x5, #0x8
      e8:      	cmp	x6, x4
      ec:      	cset	w6, eq
      f0:      	csel	x7, x2, x1, eq
      f4:      	tst	w3, #0x1
      f8:      	add	x2, x2, #0x1
      fc:      	orr	w6, w3, w6
     100:      	csel	x1, x1, x7, ne
     104:      	cmp	x2, #0x20
     108:      	mov	w3, w6
     10c:      	b.ne	0xe0 <sorted_rule_binary_search_xdp+0xe0>
     110:      	add	x2, x4, #0x20
     114:      	add	x1, x1, x10
     118:      	tst	w6, #0x1
     11c:      	add	x9, x9, #0x1
     120:      	eor	x10, x2, x10
     124:      	csel	x10, x1, x10, ne
     128:      	cmp	x9, #0x10
     12c:      	b.ne	0x80 <sorted_rule_binary_search_xdp+0x80>
     130:      	mov	w0, #0x2                // =2
     134:      	str	x10, [x8]
     138:      	ret
