
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/packed_header_bitfield_decode.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <packed_header_bitfield_decode_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x10, x8
       8:      	cmp	x10, x9
       c:      	b.ls	0x18 <packed_header_bitfield_decode_xdp+0x18>
      10:      	mov	w0, wzr
      14:      	ret
      18:      	add	x11, x10, #0x8
      1c:      	add	x12, x10, #0x210
      20:      	cmp	x11, x9
      24:      	ccmp	x12, x9, #0x2, ls
      28:      	b.ls	0x34 <packed_header_bitfield_decode_xdp+0x34>
      2c:      	mov	w0, wzr
      30:      	ret
      34:      	ldp	w9, w11, [x10, #0x8]
      38:      	cmp	w9, #0x20
      3c:      	ccmp	w11, #0x2, #0x0, eq
      40:      	b.eq	0x4c <packed_header_bitfield_decode_xdp+0x4c>
      44:      	mov	w0, wzr
      48:      	ret
      4c:      	str	x29, [sp, #-0x60]!
      50:      	stp	x28, x27, [sp, #0x10]
      54:      	stp	x26, x25, [sp, #0x20]
      58:      	stp	x24, x23, [sp, #0x30]
      5c:      	stp	x22, x21, [sp, #0x40]
      60:      	stp	x20, x19, [sp, #0x50]
      64:      	mov	x14, #0xc909            // =51465
      68:      	mov	x9, xzr
      6c:      	add	x10, x10, #0x1f
      70:      	mov	w11, #0xb               // =11
      74:      	mov	w12, #0xd               // =13
      78:      	mov	w13, #0x13              // =19
      7c:      	movk	x14, #0xf3bc, lsl #16
      80:      	movk	x14, #0xe667, lsl #32
      84:      	movk	x14, #0x6a09, lsl #48
      88:      	ldurb	w16, [x10, #-0xc]
      8c:      	ldurb	w0, [x10, #-0x5]
      90:      	lsl	x3, x16, #24
      94:      	ldurb	w16, [x10, #-0x8]
      98:      	ldurb	w5, [x10, #-0x4]
      9c:      	ldurb	w18, [x10, #-0x6]
      a0:      	ldurb	w20, [x10, #-0x2]
      a4:      	ldurb	w25, [x10, #-0xd]
      a8:      	ldurb	w19, [x10, #-0x3]
      ac:      	ldrb	w22, [x10]
      b0:      	lsl	x6, x0, #16
      b4:      	lsl	x7, x5, #24
      b8:      	ldurb	w23, [x10, #-0x1]
      bc:      	lsl	x21, x20, #40
      c0:      	lsl	x22, x22, #56
      c4:      	mov	x5, x7
      c8:      	ldurb	w17, [x10, #-0xa]
      cc:      	orr	w6, w7, w6
      d0:      	bfi	x7, x0, #16, #8
      d4:      	orr	x3, x3, x25, lsl #16
      d8:      	ldurb	w25, [x10, #-0xb]
      dc:      	orr	x21, x21, x19, lsl #32
      e0:      	orr	x22, x22, x23, lsl #48
      e4:      	lsl	x2, x17, #40
      e8:      	lsl	x17, x18, #8
      ec:      	bfi	x5, x19, #32, #8
      f0:      	ldurb	w15, [x10, #-0xf]
      f4:      	ldurb	w23, [x10, #-0xe]
      f8:      	lsr	x28, x3, #22
      fc:      	lsl	x4, x16, #56
     100:      	ldurb	w16, [x10, #-0x7]
     104:      	orr	x2, x2, x25, lsl #32
     108:      	ldurb	w25, [x10, #-0x9]
     10c:      	orr	x24, x15, x23, lsl #8
     110:      	ubfx	x23, x23, #1, #5
     114:      	add	x10, x10, #0x10
     118:      	orr	x26, x3, x24
     11c:      	ubfx	x24, x24, #6, #5
     120:      	orr	x2, x2, x26
     124:      	ubfx	x26, x26, #11, #11
     128:      	mov	x1, x16
     12c:      	ubfx	x3, x2, #30, #14
     130:      	bfi	x1, x18, #8, #8
     134:      	orr	x4, x4, x25, lsl #48
     138:      	and	x25, x15, #0x3f
     13c:      	and	x15, x15, #0x7
     140:      	orr	x4, x4, x2
     144:      	add	x24, x25, x24
     148:      	orr	x7, x7, x1
     14c:      	ubfx	x29, x4, #44, #10
     150:      	lsr	x2, x4, #54
     154:      	and	x4, x16, #0xf
     158:      	ubfx	x1, x1, #4, #8
     15c:      	add	x24, x24, x26
     160:      	orr	x7, x21, x7
     164:      	ubfx	x21, x21, #38, #7
     168:      	add	x24, x2, x24
     16c:      	add	x25, x3, x29
     170:      	orr	x27, x22, x7
     174:      	bfi	x22, x20, #40, #8
     178:      	ubfx	x7, x7, #24, #16
     17c:      	lsr	x20, x27, #40
     180:      	orr	x19, x5, x22
     184:      	bfi	x19, x0, #16, #8
     188:      	orr	w0, w17, w6
     18c:      	add	x6, x23, x23, lsl #4
     190:      	ubfx	x0, x0, #12, #12
     194:      	bfi	x19, x18, #8, #8
     198:      	add	x0, x0, x21
     19c:      	add	x18, x19, x16
     1a0:      	orr	w16, w17, w16
     1a4:      	add	x17, x9, x23
     1a8:      	add	x9, x9, #0x1
     1ac:      	add	x18, x4, x18, lsr #40
     1b0:      	add	x4, x3, x3, lsl #2
     1b4:      	lsr	w16, w16, #4
     1b8:      	cmp	x9, #0x20
     1bc:      	add	x18, x18, x5, lsr #24
     1c0:      	add	x5, x20, x20, lsl #3
     1c4:      	add	x18, x18, x0
     1c8:      	add	x0, x26, x26, lsl #1
     1cc:      	eor	x0, x0, x4
     1d0:      	lsl	x4, x1, #3
     1d4:      	add	x16, x18, w16, uxtb
     1d8:      	add	x18, x24, w28, uxtb
     1dc:      	sub	x1, x4, x1
     1e0:      	umull	x4, w7, w12
     1e4:      	umull	x7, w21, w13
     1e8:      	eor	x0, x0, x1
     1ec:      	umull	x1, w2, w11
     1f0:      	add	x16, x17, x16
     1f4:      	add	x18, x18, x25
     1f8:      	eor	x4, x5, x4
     1fc:      	eor	x1, x6, x1
     200:      	eor	x1, x1, x4
     204:      	eor	x17, x1, x7
     208:      	add	x1, x15, #0x1
     20c:      	eor	w15, w15, #0x3f
     210:      	lsl	x1, x16, x1
     214:      	lsr	x15, x16, x15
     218:      	eor	w16, w20, w2
     21c:      	orr	x15, x1, x15
     220:      	and	w16, w16, #0xf
     224:      	eor	x15, x15, x18
     228:      	add	x14, x15, x14
     22c:      	add	x15, x17, x0
     230:      	eor	x14, x14, x15
     234:      	add	x15, x23, x3
     238:      	add	x15, x20, x15
     23c:      	add	x14, x15, x14
     240:      	add	w15, w16, #0x1
     244:      	eor	w16, w16, #0x3f
     248:      	lsl	x15, x14, x15
     24c:      	lsr	x14, x14, x16
     250:      	orr	x14, x15, x14
     254:      	b.ne	0x88 <packed_header_bitfield_decode_xdp+0x88>
     258:      	lsr	x9, x14, #8
     25c:      	ldp	x20, x19, [sp, #0x50]
     260:      	mov	w0, #0x2                // =2
     264:      	strb	w14, [x8]
     268:      	strb	w9, [x8, #0x1]
     26c:      	lsr	x9, x15, #16
     270:      	strb	w9, [x8, #0x2]
     274:      	lsr	x9, x15, #24
     278:      	ldp	x22, x21, [sp, #0x40]
     27c:      	strb	w9, [x8, #0x3]
     280:      	lsr	x9, x15, #32
     284:      	strb	w9, [x8, #0x4]
     288:      	lsr	x9, x15, #40
     28c:      	ldp	x24, x23, [sp, #0x30]
     290:      	strb	w9, [x8, #0x5]
     294:      	lsr	x9, x15, #48
     298:      	strb	w9, [x8, #0x6]
     29c:      	ldp	x26, x25, [sp, #0x20]
     2a0:      	lsr	x9, x15, #56
     2a4:      	strb	w9, [x8, #0x7]
     2a8:      	ldp	x28, x27, [sp, #0x10]
     2ac:      	ldr	x29, [sp], #0x60
     2b0:      	ret
