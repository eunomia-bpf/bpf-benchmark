/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/trace_event_type_switch_dispatch.native.so: \
  trace_event_type_switch_dispatch.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h:
