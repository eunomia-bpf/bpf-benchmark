
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/cilium_socket_lb_service_select.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <cilium_socket_lb_service_select_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x10, x8
       8:      	cmp	x10, x9
       c:      	b.ls	0x18 <cilium_socket_lb_service_select_xdp+0x18>
      10:      	mov	w0, wzr
      14:      	ret
      18:      	add	x11, x10, #0x8
      1c:      	add	x12, x10, #0x610
      20:      	cmp	x11, x9
      24:      	ccmp	x12, x9, #0x2, ls
      28:      	b.ls	0x34 <cilium_socket_lb_service_select_xdp+0x34>
      2c:      	mov	w0, wzr
      30:      	ret
      34:      	ldp	w9, w11, [x10, #0x8]
      38:      	cmp	w9, #0x40
      3c:      	ccmp	w11, #0x18, #0x0, eq
      40:      	b.eq	0x4c <cilium_socket_lb_service_select_xdp+0x4c>
      44:      	mov	w0, wzr
      48:      	ret
      4c:      	mov	x12, #0x8d3             // =2259
      50:      	mov	x9, xzr
      54:      	add	x10, x10, #0x13
      58:      	mov	w11, #0x752f            // =29999
      5c:      	movk	x12, #0x85a3, lsl #16
      60:      	movk	x12, #0x6a88, lsl #32
      64:      	movk	x12, #0x243f, lsl #48
      68:      	b	0x84 <cilium_socket_lb_service_select_xdp+0x84>
      6c:      	orr	x13, x14, x13, lsl #32
      70:      	eor	x12, x13, x12
      74:      	add	x9, x9, #0x1
      78:      	add	x10, x10, #0x18
      7c:      	cmp	x9, #0x40
      80:      	b.eq	0x16c <cilium_socket_lb_service_select_xdp+0x16c>
      84:      	ldrb	w16, [x10, #0xa]
      88:      	ldur	w18, [x10, #0x1]
      8c:      	tst	w16, #0x2
      90:      	ldrb	w13, [x10, #0x9]
      94:      	ldurh	w17, [x10, #0xb]
      98:      	ldurh	w14, [x10, #0x7]
      9c:      	csel	w15, w18, wzr, eq
      a0:      	cmp	w13, #0x11
      a4:      	ccmp	w13, #0x6, #0x4, ne
      a8:      	ccmp	w17, #0x0, #0x4, eq
      ac:      	b.eq	0x6c <cilium_socket_lb_service_select_xdp+0x6c>
      b0:      	ldur	w2, [x10, #-0x3]
      b4:      	ldurh	w1, [x10, #0x5]
      b8:      	cmp	w11, w14, sxth
      bc:      	ldur	w3, [x10, #0xd]
      c0:      	ldur	w0, [x10, #0x11]
      c4:      	b.lt	0xe8 <cilium_socket_lb_service_select_xdp+0xe8>
      c8:      	tbnz	w16, #0x1, 0xe8 <cilium_socket_lb_service_select_xdp+0xe8>
      cc:      	orr	x13, x1, x18, lsl #16
      d0:      	add	x12, x13, x12
      d4:      	add	x9, x9, #0x1
      d8:      	add	x10, x10, #0x18
      dc:      	cmp	x9, #0x40
      e0:      	b.ne	0x84 <cilium_socket_lb_service_select_xdp+0x84>
      e4:      	b	0x16c <cilium_socket_lb_service_select_xdp+0x16c>
      e8:      	eor	w18, w2, w1, lsl #16
      ec:      	eor	w1, w14, w3
      f0:      	mvn	w2, w13
      f4:      	add	x12, x12, x13
      f8:      	eor	w18, w18, w1
      fc:      	add	w1, w0, w16
     100:      	orr	w2, w2, #0x18
     104:      	lsl	w16, w16, #29
     108:      	add	w0, w0, #0x1
     10c:      	eor	w18, w18, w15
     110:      	ubfiz	x15, x15, #16, #32
     114:      	and	w16, w0, w16, asr #31
     118:      	add	w1, w1, w18
     11c:      	eor	x14, x15, x14, lsl #32
     120:      	ror	w1, w1, w2
     124:      	add	x12, x12, x14
     128:      	and	w14, w9, #0x7
     12c:      	eor	w18, w1, w18
     130:      	add	w15, w14, #0x1
     134:      	eor	w14, w14, #0x3f
     138:      	udiv	w1, w18, w17
     13c:      	msub	w17, w1, w17, w18
     140:      	add	w17, w17, #0x1
     144:      	eor	w16, w17, w16
     148:      	orr	x13, x18, x16, lsl #48
     14c:      	lsl	x15, x13, x15
     150:      	lsr	x13, x13, x14
     154:      	orr	x13, x15, x13
     158:      	eor	x12, x13, x12
     15c:      	add	x9, x9, #0x1
     160:      	add	x10, x10, #0x18
     164:      	cmp	x9, #0x40
     168:      	b.ne	0x84 <cilium_socket_lb_service_select_xdp+0x84>
     16c:      	mov	w0, #0x2                // =2
     170:      	str	x12, [x8]
     174:      	ret
