
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/simple.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <simple_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x10, x8
       8:      	cmp	x10, x9
       c:      	b.hi	0x24 <simple_xdp+0x24>
      10:      	add	x11, x10, #0x8
      14:      	add	x10, x10, #0x48
      18:      	cmp	x11, x9
      1c:      	ccmp	x10, x9, #0x2, ls
      20:      	b.ls	0x2c <simple_xdp+0x2c>
      24:      	mov	w0, wzr
      28:      	ret
      2c:      	mov	w9, #0x614e             // =24910
      30:      	mov	w0, #0x2                // =2
      34:      	stur	wzr, [x8, #0x3]
      38:      	strb	wzr, [x8, #0x7]
      3c:      	strh	w9, [x8]
      40:      	mov	w9, #0xbc               // =188
      44:      	strb	w9, [x8, #0x2]
      48:      	ret
