
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/bitmap_popcount_scan.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <bitmap_popcount_scan_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x11, x8
       8:      	cmp	x11, x9
       c:      	b.hi	0x9c <bitmap_popcount_scan_xdp+0x9c>
      10:      	add	x10, x11, #0x8
      14:      	add	x12, x11, #0x810
      18:      	cmp	x10, x9
      1c:      	ccmp	x12, x9, #0x2, ls
      20:      	b.hi	0x9c <bitmap_popcount_scan_xdp+0x9c>
      24:      	ldr	w9, [x10]
      28:      	cmp	w9, #0x100
      2c:      	b.ne	0x9c <bitmap_popcount_scan_xdp+0x9c>
      30:      	ldr	w10, [x11, #0xc]
      34:      	mov	x9, xzr
      38:      	add	x11, x11, #0x17
      3c:      	mov	x12, #0x101010101010101 // =72340172838076673
      40:      	ldur	x13, [x11, #-0x7]
      44:      	add	x11, x11, #0x8
      48:      	eor	x14, x13, x10
      4c:      	lsr	x15, x14, #1
      50:      	and	x15, x15, #0x5555555555555555
      54:      	sub	x14, x14, x15
      58:      	and	x15, x14, #0x3333333333333333
      5c:      	lsr	x14, x14, #2
      60:      	and	x14, x14, #0x3333333333333333
      64:      	add	x14, x15, x14
      68:      	add	x14, x14, x14, lsr #4
      6c:      	and	x14, x14, #0xf0f0f0f0f0f0f0f
      70:      	mul	x14, x14, x12
      74:      	add	x10, x10, x14, lsr #56
      78:      	and	x14, x9, #0x7
      7c:      	add	x9, x9, #0x1
      80:      	lsr	x13, x13, x14
      84:      	cmp	x9, #0x100
      88:      	eor	x10, x10, x13
      8c:      	b.ne	0x40 <bitmap_popcount_scan_xdp+0x40>
      90:      	mov	w0, #0x2                // =2
      94:      	str	x10, [x8]
      98:      	ret
      9c:      	mov	w0, wzr
      a0:      	ret
