
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/simple_packet.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <simple_packet_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x10, x8
       8:      	add	x11, x10, #0x8
       c:      	cmp	x10, x9
      10:      	ccmp	x11, x9, #0x2, ls
      14:      	b.ls	0x20 <simple_packet_xdp+0x20>
      18:      	mov	w0, wzr
      1c:      	ret
      20:      	mov	w9, #0x614e             // =24910
      24:      	mov	w0, #0x2                // =2
      28:      	stur	wzr, [x8, #0x3]
      2c:      	strb	wzr, [x8, #0x7]
      30:      	strh	w9, [x8]
      34:      	mov	w9, #0xbc               // =188
      38:      	strb	w9, [x8, #0x2]
      3c:      	ret
