
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/packet_checksum_fold.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <packet_checksum_fold_xdp>:
       0:      	ldp	x8, x10, [x0]
       4:      	mov	x9, x8
       8:      	cmp	x9, x10
       c:      	b.ls	0x18 <packet_checksum_fold_xdp+0x18>
      10:      	mov	w0, wzr
      14:      	ret
      18:      	add	x11, x9, #0x8
      1c:      	add	x12, x9, #0x410
      20:      	mov	w0, wzr
      24:      	cmp	x11, x10
      28:      	ccmp	x12, x10, #0x2, ls
      2c:      	b.hi	0xc0 <packet_checksum_fold_xdp+0xc0>
      30:      	ldr	w10, [x9, #0x8]
      34:      	cmp	w10, #0x20
      38:      	b.ne	0xc0 <packet_checksum_fold_xdp+0xc0>
      3c:      	ldr	w10, [x9, #0xc]
      40:      	cmp	w10, #0x200
      44:      	b.ne	0xc0 <packet_checksum_fold_xdp+0xc0>
      48:      	mov	w11, wzr
      4c:      	mov	x10, xzr
      50:      	mov	w12, #0xffff            // =65535
      54:      	nop
      58:      	nop
      5c:      	nop
      60:      	mov	x13, xzr
      64:      	mov	w14, wzr
      68:      	add	x15, x9, x13
      6c:      	add	x13, x13, #0x4
      70:      	ldrh	w16, [x15, #0x10]
      74:      	ldrh	w15, [x15, #0x12]
      78:      	cmp	x13, #0x400
      7c:      	add	w14, w16, w14
      80:      	lsr	w16, w14, #16
      84:      	add	w14, w16, w14, uxth
      88:      	add	w14, w15, w14
      8c:      	lsr	w15, w14, #16
      90:      	add	w14, w15, w14, uxth
      94:      	b.ne	0x68 <packet_checksum_fold_xdp+0x68>
      98:      	add	w13, w14, w14, lsr #16
      9c:      	ubfiz	w14, w11, #4, #2
      a0:      	add	w11, w11, #0x1
      a4:      	cmp	w11, #0x20
      a8:      	bic	w13, w12, w13
      ac:      	lsl	x13, x13, x14
      b0:      	eor	x10, x13, x10
      b4:      	b.ne	0x60 <packet_checksum_fold_xdp+0x60>
      b8:      	mov	w0, #0x2                // =2
      bc:      	str	x10, [x8]
      c0:      	ret
