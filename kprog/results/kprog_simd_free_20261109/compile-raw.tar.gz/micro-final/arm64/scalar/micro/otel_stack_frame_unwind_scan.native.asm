
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/otel_stack_frame_unwind_scan.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <otel_stack_frame_unwind_scan_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x10, x8
       8:      	cmp	x10, x9
       c:      	b.ls	0x18 <otel_stack_frame_unwind_scan_xdp+0x18>
      10:      	mov	w0, wzr
      14:      	ret
      18:      	add	x11, x10, #0x8
      1c:      	add	x12, x10, #0x250
      20:      	cmp	x11, x9
      24:      	ccmp	x12, x9, #0x2, ls
      28:      	b.ls	0x34 <otel_stack_frame_unwind_scan_xdp+0x34>
      2c:      	mov	w0, wzr
      30:      	ret
      34:      	ldp	w9, w11, [x10, #0x8]
      38:      	cmp	w9, #0x18
      3c:      	ccmp	w11, #0x18, #0x0, eq
      40:      	b.eq	0x4c <otel_stack_frame_unwind_scan_xdp+0x4c>
      44:      	mov	w0, wzr
      48:      	ret
      4c:      	mov	x12, #0x4cc3            // =19651
      50:      	mov	x9, xzr
      54:      	add	x10, x10, #0x13
      58:      	mov	x11, #0x100000000       // =4294967296
      5c:      	mov	w13, #0x8               // =8
      60:      	movk	x12, #0x7537, lsl #16
      64:      	movk	x12, #0x65cc, lsl #32
      68:      	movk	x12, #0x5899, lsl #48
      6c:      	b	0x98 <otel_stack_frame_unwind_scan_xdp+0x98>
      70:      	nop
      74:      	nop
      78:      	nop
      7c:      	nop
      80:      	orr	x16, x18, x0, lsl #48
      84:      	add	x9, x9, #0x1
      88:      	add	x10, x10, #0x18
      8c:      	eor	x12, x16, x12
      90:      	cmp	x9, #0x18
      94:      	b.eq	0x194 <otel_stack_frame_unwind_scan_xdp+0x194>
      98:      	ldurh	w0, [x10, #0xf]
      9c:      	ldur	x18, [x10, #-0x3]
      a0:      	cmp	w0, #0x1
      a4:      	ldur	w16, [x10, #0x5]
      a8:      	ldur	w17, [x10, #0x9]
      ac:      	ldurh	w14, [x10, #0xd]
      b0:      	ldur	w15, [x10, #0x11]
      b4:      	b.gt	0xe0 <otel_stack_frame_unwind_scan_xdp+0xe0>
      b8:      	cbz	w0, 0x100 <otel_stack_frame_unwind_scan_xdp+0x100>
      bc:      	cmp	w0, #0x1
      c0:      	b.ne	0x80 <otel_stack_frame_unwind_scan_xdp+0x80>
      c4:      	mov	w1, #0x35               // =53
      c8:      	cmp	w16, #0x1, lsl #12      // =0x1000
      cc:      	b.ls	0x11c <otel_stack_frame_unwind_scan_xdp+0x11c>
      d0:      	b	0x80 <otel_stack_frame_unwind_scan_xdp+0x80>
      d4:      	nop
      d8:      	nop
      dc:      	nop
      e0:      	cmp	w0, #0x2
      e4:      	b.eq	0x110 <otel_stack_frame_unwind_scan_xdp+0x110>
      e8:      	cmp	w0, #0x3
      ec:      	b.ne	0x80 <otel_stack_frame_unwind_scan_xdp+0x80>
      f0:      	mov	w1, #0x89               // =137
      f4:      	cmp	w16, #0x1, lsl #12      // =0x1000
      f8:      	b.ls	0x11c <otel_stack_frame_unwind_scan_xdp+0x11c>
      fc:      	b	0x80 <otel_stack_frame_unwind_scan_xdp+0x80>
     100:      	mov	w1, #0x21               // =33
     104:      	cmp	w16, #0x1, lsl #12      // =0x1000
     108:      	b.ls	0x11c <otel_stack_frame_unwind_scan_xdp+0x11c>
     10c:      	b	0x80 <otel_stack_frame_unwind_scan_xdp+0x80>
     110:      	mov	w1, #0x55               // =85
     114:      	cmp	w16, #0x1, lsl #12      // =0x1000
     118:      	b.hi	0x80 <otel_stack_frame_unwind_scan_xdp+0x80>
     11c:      	cmp	w17, #0x2, lsl #12      // =0x2000
     120:      	b.hi	0x80 <otel_stack_frame_unwind_scan_xdp+0x80>
     124:      	tst	w14, #0x1
     128:      	orr	x1, x1, x15, lsl #32
     12c:      	mvn	w0, w0
     130:      	csel	w2, w13, w17, eq
     134:      	eor	x18, x18, x1
     138:      	tst	w14, #0x2
     13c:      	add	w2, w2, w16
     140:      	eor	x16, x16, x17, lsl #24
     144:      	and	w17, w9, #0x7
     148:      	add	x11, x11, x2
     14c:      	eor	x18, x18, x11
     150:      	ror	x0, x18, x0
     154:      	csel	x18, x18, x0, eq
     158:      	tst	w14, #0x4
     15c:      	csel	x16, xzr, x16, eq
     160:      	add	x16, x18, x16
     164:      	add	w18, w17, #0x1
     168:      	eor	w17, w17, #0x3f
     16c:      	lsl	x18, x16, x18
     170:      	lsr	x16, x16, x17
     174:      	orr	x16, x18, x16
     178:      	add	x16, x16, x12
     17c:      	orr	x12, x15, x14, lsl #40
     180:      	add	x9, x9, #0x1
     184:      	add	x10, x10, #0x18
     188:      	eor	x12, x16, x12
     18c:      	cmp	x9, #0x18
     190:      	b.ne	0x98 <otel_stack_frame_unwind_scan_xdp+0x98>
     194:      	mov	w0, #0x2                // =2
     198:      	str	x12, [x8]
     19c:      	ret
