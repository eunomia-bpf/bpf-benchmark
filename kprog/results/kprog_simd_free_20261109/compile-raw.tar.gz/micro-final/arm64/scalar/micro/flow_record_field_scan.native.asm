
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/flow_record_field_scan.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <flow_record_field_scan_xdp>:
       0:      	ldp	x8, x10, [x0]
       4:      	mov	x9, x8
       8:      	cmp	x9, x10
       c:      	b.hi	0xe4 <flow_record_field_scan_xdp+0xe4>
      10:      	add	x11, x9, #0x8
      14:      	add	x12, x9, #0x410
      18:      	cmp	x11, x10
      1c:      	ccmp	x12, x10, #0x2, ls
      20:      	b.hi	0xe4 <flow_record_field_scan_xdp+0xe4>
      24:      	ldr	w10, [x11]
      28:      	cmp	w10, #0x20
      2c:      	b.ne	0xe4 <flow_record_field_scan_xdp+0xe4>
      30:      	ldr	w10, [x9, #0xc]
      34:      	cmp	w10, #0x20
      38:      	b.ne	0xe4 <flow_record_field_scan_xdp+0xe4>
      3c:      	mov	x13, #0x7c15            // =31765
      40:      	mov	x10, xzr
      44:      	mov	x11, xzr
      48:      	mov	x12, xzr
      4c:      	movk	x13, #0x7f4a, lsl #16
      50:      	movk	x13, #0x79b9, lsl #32
      54:      	movk	x13, #0x9e37, lsl #48
      58:      	b	0xa8 <flow_record_field_scan_xdp+0xa8>
      5c:      	nop
      60:      	and	x15, x12, #0x7
      64:      	lsr	x15, x16, x15
      68:      	eor	x15, x17, x15
      6c:      	add	x13, x13, x15
      70:      	and	x15, x11, #0x18
      74:      	add	x10, x10, #0x20
      78:      	add	x12, x12, #0x1
      7c:      	add	x11, x11, #0x8
      80:      	lsl	x15, x14, x15
      84:      	cmp	x10, #0x400
      88:      	eor	x13, x13, x15
      8c:      	and	w15, w14, #0x7
      90:      	add	w14, w15, #0x1
      94:      	eor	w15, w15, #0x3f
      98:      	lsl	x14, x13, x14
      9c:      	lsr	x13, x13, x15
      a0:      	orr	x13, x14, x13
      a4:      	b.eq	0xec <flow_record_field_scan_xdp+0xec>
      a8:      	add	x15, x9, x10
      ac:      	ldp	x14, x16, [x15, #0x18]
      b0:      	ldrh	w0, [x15, #0x14]
      b4:      	add	x18, x16, x14
      b8:      	ldp	w14, w17, [x15, #0x28]
      bc:      	orr	x17, x17, x14, lsl #32
      c0:      	ldr	w14, [x15, #0x10]
      c4:      	orr	x1, x0, x14, lsl #16
      c8:      	eor	x18, x1, x18
      cc:      	add	x13, x18, x13
      d0:      	tbz	w0, #0x0, 0x60 <flow_record_field_scan_xdp+0x60>
      d4:      	ldrh	w15, [x15, #0x16]
      d8:      	add	x15, x17, x15
      dc:      	eor	x13, x15, x13
      e0:      	b	0x70 <flow_record_field_scan_xdp+0x70>
      e4:      	mov	w0, wzr
      e8:      	ret
      ec:      	lsr	x9, x14, #8
      f0:      	mov	w0, #0x2                // =2
      f4:      	strb	w13, [x8]
      f8:      	strb	w9, [x8, #0x1]
      fc:      	lsr	x9, x14, #16
     100:      	strb	w9, [x8, #0x2]
     104:      	lsr	x9, x14, #24
     108:      	strb	w9, [x8, #0x3]
     10c:      	lsr	x9, x14, #32
     110:      	strb	w9, [x8, #0x4]
     114:      	lsr	x9, x14, #40
     118:      	strb	w9, [x8, #0x5]
     11c:      	lsr	x9, x14, #48
     120:      	strb	w9, [x8, #0x6]
     124:      	lsr	x9, x14, #56
     128:      	strb	w9, [x8, #0x7]
     12c:      	ret
