/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/sorted_rule_binary_search.native.so: \
  sorted_rule_binary_search.bpf.c common.h \
  /var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h
common.h:
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/kernel_offsets.h:
