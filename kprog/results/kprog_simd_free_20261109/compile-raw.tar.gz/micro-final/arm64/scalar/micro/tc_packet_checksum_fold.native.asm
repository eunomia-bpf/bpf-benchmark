
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/tc_packet_checksum_fold.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <tc_packet_checksum_fold_prog>:
       0:      	ldr	x8, [x0, #0xd0]
       4:      	ldr	x11, [x0, #0x50]
       8:      	cmp	x8, x11
       c:      	add	x9, x8, #0x8
      10:      	add	x10, x8, #0x410
      14:      	ccmp	x9, x11, #0x2, ls
      18:      	ccmp	x10, x11, #0x2, ls
      1c:      	b.ls	0x34 <tc_packet_checksum_fold_prog+0x34>
      20:      	mov	w9, #-0x1               // =-1
      24:      	mov	w8, #0x2                // =2
      28:      	stp	w9, w9, [x0, #0x30]
      2c:      	mov	w0, w8
      30:      	ret
      34:      	mov	x11, x9
      38:      	mov	x12, x10
      3c:      	add	x13, x11, #0x8
      40:      	cmp	x11, x12
      44:      	ccmp	x13, x12, #0x2, ls
      48:      	b.hi	0x20 <tc_packet_checksum_fold_prog+0x20>
      4c:      	ldr	w11, [x8, #0x8]
      50:      	cmp	w11, #0x20
      54:      	b.ne	0x20 <tc_packet_checksum_fold_prog+0x20>
      58:      	ldr	w11, [x8, #0xc]
      5c:      	cmp	w11, #0x200
      60:      	b.ne	0x20 <tc_packet_checksum_fold_prog+0x20>
      64:      	add	x11, x9, #0x8
      68:      	cmp	x11, x10
      6c:      	b.hi	0x20 <tc_packet_checksum_fold_prog+0x20>
      70:      	add	x9, x9, #0x408
      74:      	cmp	x9, x10
      78:      	b.hi	0x20 <tc_packet_checksum_fold_prog+0x20>
      7c:      	mov	w10, wzr
      80:      	mov	x9, xzr
      84:      	mov	w11, #0xffff            // =65535
      88:      	mov	x12, xzr
      8c:      	mov	w13, wzr
      90:      	nop
      94:      	nop
      98:      	nop
      9c:      	nop
      a0:      	add	x14, x8, x12
      a4:      	add	x12, x12, #0x4
      a8:      	ldrh	w15, [x14, #0x10]
      ac:      	ldrh	w14, [x14, #0x12]
      b0:      	cmp	x12, #0x400
      b4:      	add	w13, w15, w13
      b8:      	lsr	w15, w13, #16
      bc:      	add	w13, w15, w13, uxth
      c0:      	add	w13, w14, w13
      c4:      	lsr	w14, w13, #16
      c8:      	add	w13, w14, w13, uxth
      cc:      	b.ne	0xa0 <tc_packet_checksum_fold_prog+0xa0>
      d0:      	add	w12, w13, w13, lsr #16
      d4:      	ubfiz	w13, w10, #4, #2
      d8:      	add	w10, w10, #0x1
      dc:      	cmp	w10, #0x20
      e0:      	bic	w12, w11, w12
      e4:      	lsl	x12, x12, x13
      e8:      	eor	x9, x12, x9
      ec:      	b.ne	0x88 <tc_packet_checksum_fold_prog+0x88>
      f0:      	mov	w8, wzr
      f4:      	str	w9, [x0, #0x30]
      f8:      	lsr	x9, x9, #32
      fc:      	str	w9, [x0, #0x34]
     100:      	mov	w0, w8
     104:      	ret
