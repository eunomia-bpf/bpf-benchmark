
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/packet_vlan_tcpopt_parser.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <packet_vlan_tcpopt_parser_xdp>:
       0:      	ldp	x8, x12, [x0]
       4:      	add	x9, x8, #0x8
       8:      	cmp	x8, x12
       c:      	ccmp	x9, x12, #0x2, ls
      10:      	b.hi	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
      14:      	add	x11, x8, #0x16
      18:      	cmp	x11, x12
      1c:      	b.ls	0x28 <packet_vlan_tcpopt_parser_xdp+0x28>
      20:      	mov	w0, wzr
      24:      	ret
      28:      	ldrh	w9, [x8, #0x14]
      2c:      	rev16	w9, w9
      30:      	cmp	w9, #0x800
      34:      	b.eq	0xd0 <packet_vlan_tcpopt_parser_xdp+0xd0>
      38:      	mov	w10, #0x88a8            // =34984
      3c:      	mov	w0, wzr
      40:      	cmp	w9, w10
      44:      	mov	w10, #0x8100            // =33024
      48:      	ccmp	w9, w10, #0x4, ne
      4c:      	b.ne	0x24 <packet_vlan_tcpopt_parser_xdp+0x24>
      50:      	add	x11, x8, #0x1a
      54:      	cmp	x11, x12
      58:      	b.hi	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
      5c:      	ldrh	w9, [x8, #0x16]
      60:      	ldrh	w10, [x8, #0x18]
      64:      	rev	w9, w9
      68:      	rev16	w10, w10
      6c:      	lsr	w9, w9, #16
      70:      	cmp	w10, #0x800
      74:      	b.eq	0x27c <packet_vlan_tcpopt_parser_xdp+0x27c>
      78:      	mov	w11, #0x88a8            // =34984
      7c:      	cmp	w10, w11
      80:      	b.eq	0x90 <packet_vlan_tcpopt_parser_xdp+0x90>
      84:      	mov	w11, #0x8100            // =33024
      88:      	cmp	w10, w11
      8c:      	b.ne	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
      90:      	add	x10, x8, #0x1e
      94:      	cmp	x10, x12
      98:      	b.hi	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
      9c:      	ldrh	w10, [x8, #0x1c]
      a0:      	mov	w0, wzr
      a4:      	rev16	w10, w10
      a8:      	cmp	w10, #0x800
      ac:      	b.ne	0x24 <packet_vlan_tcpopt_parser_xdp+0x24>
      b0:      	add	x10, x8, #0x32
      b4:      	cmp	x10, x12
      b8:      	b.hi	0x24 <packet_vlan_tcpopt_parser_xdp+0x24>
      bc:      	ldrh	w10, [x8, #0x1a]
      c0:      	add	x11, x8, #0x1e
      c4:      	rev16	w13, w10
      c8:      	mov	w10, #0x2               // =2
      cc:      	b	0xe8 <packet_vlan_tcpopt_parser_xdp+0xe8>
      d0:      	mov	w9, wzr
      d4:      	mov	w10, wzr
      d8:      	add	x13, x11, #0x14
      dc:      	cmp	x13, x12
      e0:      	b.hi	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
      e4:      	mov	x13, xzr
      e8:      	ldrb	w14, [x11]
      ec:      	mov	w0, wzr
      f0:      	and	w15, w14, #0xf0
      f4:      	cmp	w15, #0x40
      f8:      	b.ne	0x24 <packet_vlan_tcpopt_parser_xdp+0x24>
      fc:      	and	x16, x14, #0xf
     100:      	cmp	w16, #0x5
     104:      	b.lo	0x24 <packet_vlan_tcpopt_parser_xdp+0x24>
     108:      	add	x14, x11, x16, lsl #2
     10c:      	cmp	x14, x12
     110:      	b.hi	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
     114:      	ldrb	w15, [x11, #0x9]
     118:      	cmp	w15, #0x6
     11c:      	b.ne	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
     120:      	add	x17, x14, #0x14
     124:      	cmp	x17, x12
     128:      	b.hi	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
     12c:      	ldrb	w15, [x14, #0xc]
     130:      	cmp	w15, #0x50
     134:      	b.lo	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
     138:      	lsr	x15, x15, #2
     13c:      	and	x15, x15, #0x3c
     140:      	add	x18, x14, x15
     144:      	cmp	x18, x12
     148:      	b.hi	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
     14c:      	add	x18, x14, #0x20
     150:      	mov	w0, wzr
     154:      	cmp	x18, x12
     158:      	b.hi	0x24 <packet_vlan_tcpopt_parser_xdp+0x24>
     15c:      	cmp	w15, #0x20
     160:      	b.lo	0x24 <packet_vlan_tcpopt_parser_xdp+0x24>
     164:      	ldrb	w12, [x17]
     168:      	cmp	w12, #0x2
     16c:      	b.ne	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
     170:      	ldrb	w12, [x14, #0x15]
     174:      	cmp	w12, #0x4
     178:      	b.lo	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
     17c:      	ldrb	w12, [x14, #0x18]
     180:      	cmp	w12, #0x1
     184:      	b.ne	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
     188:      	ldrb	w12, [x14, #0x19]
     18c:      	cmp	w12, #0x3
     190:      	b.ne	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
     194:      	ldrb	w12, [x14, #0x1a]
     198:      	cmp	w12, #0x3
     19c:      	b.lo	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
     1a0:      	ldrb	w12, [x14, #0x1c]
     1a4:      	cmp	w12, #0x4
     1a8:      	b.ne	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
     1ac:      	ldrb	w12, [x14, #0x1d]
     1b0:      	cmp	w12, #0x2
     1b4:      	b.lo	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
     1b8:      	ldrb	w12, [x14, #0x1e]
     1bc:      	cmp	w12, #0x1
     1c0:      	b.ne	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
     1c4:      	ldrb	w1, [x14, #0x16]
     1c8:      	ldrb	w2, [x14, #0x17]
     1cc:      	lsl	x12, x16, #2
     1d0:      	mov	w9, w9
     1d4:      	orr	x9, x13, x9, lsl #16
     1d8:      	ldrh	w16, [x11, #0x2]
     1dc:      	ldrh	w18, [x14]
     1e0:      	orr	x3, x2, x1, lsl #8
     1e4:      	ldrh	w0, [x14, #0x2]
     1e8:      	ldp	w17, w11, [x11, #0xc]
     1ec:      	lsl	x2, x2, #24
     1f0:      	rev16	w16, w16
     1f4:      	rev16	w18, w18
     1f8:      	rev16	w0, w0
     1fc:      	rev	w17, w17
     200:      	rev	w11, w11
     204:      	add	x3, x3, #0x2
     208:      	add	x16, x18, x16
     20c:      	eor	x1, x3, x1, lsl #16
     210:      	add	x16, x16, x0
     214:      	mov	w0, #0x2                // =2
     218:      	add	x1, x1, x2
     21c:      	ldrb	w2, [x14, #0x1b]
     220:      	ldrb	w14, [x14, #0x1f]
     224:      	eor	x16, x16, x17
     228:      	add	x1, x1, #0x30, lsl #12  // =0x30000
     22c:      	add	x11, x16, x11
     230:      	add	x1, x1, #0x100
     234:      	eor	x9, x11, x9
     238:      	lsl	x11, x12, #8
     23c:      	mov	x12, #0x600000000       // =25769803776
     240:      	orr	x11, x11, x10, lsl #40
     244:      	eor	w10, w10, #0xfffffffb
     248:      	eor	x1, x1, x2, lsl #32
     24c:      	orr	x11, x11, x15
     250:      	eor	x1, x1, x2, lsl #16
     254:      	add	x11, x11, x12
     258:      	orr	x14, x1, x14, lsl #40
     25c:      	mov	x1, #0x44000000         // =1140850688
     260:      	add	x9, x9, x11
     264:      	movk	x1, #0x1, lsl #32
     268:      	add	x14, x14, x1
     26c:      	ror	x10, x14, x10
     270:      	eor	x9, x10, x9
     274:      	str	x9, [x8]
     278:      	ret
     27c:      	mov	w10, #0x1               // =1
     280:      	add	x13, x11, #0x14
     284:      	cmp	x13, x12
     288:      	b.hi	0x20 <packet_vlan_tcpopt_parser_xdp+0x20>
     28c:      	b	0xe4 <packet_vlan_tcpopt_parser_xdp+0xe4>
