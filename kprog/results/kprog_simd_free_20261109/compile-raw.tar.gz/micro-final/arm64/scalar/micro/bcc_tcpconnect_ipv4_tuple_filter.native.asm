
/var/tmp/kprog-tmp/S14/micro-final/arm64/scalar/micro/bcc_tcpconnect_ipv4_tuple_filter.native.so:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <bcc_tcpconnect_ipv4_tuple_filter_xdp>:
       0:      	ldp	x8, x9, [x0]
       4:      	mov	x10, x8
       8:      	cmp	x10, x9
       c:      	b.ls	0x18 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x18>
      10:      	mov	w0, wzr
      14:      	ret
      18:      	add	x11, x10, #0x8
      1c:      	add	x12, x10, #0x310
      20:      	cmp	x11, x9
      24:      	ccmp	x12, x9, #0x2, ls
      28:      	b.ls	0x34 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x34>
      2c:      	mov	w0, wzr
      30:      	ret
      34:      	ldp	w9, w11, [x10, #0x8]
      38:      	cmp	w9, #0x20
      3c:      	ccmp	w11, #0x18, #0x0, eq
      40:      	b.eq	0x4c <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x4c>
      44:      	mov	w0, wzr
      48:      	ret
      4c:      	mov	x12, #0x642f            // =25647
      50:      	mov	x9, xzr
      54:      	add	x10, x10, #0x13
      58:      	mov	w11, #0x1f8f            // =8079
      5c:      	mov	w13, #-0x3              // =-3
      60:      	mov	w14, #0x752f            // =29999
      64:      	mov	w15, #0x1f90            // =8080
      68:      	mov	w16, #0x20fb            // =8443
      6c:      	movk	x12, #0x78bd, lsl #16
      70:      	movk	x12, #0x1d64, lsl #32
      74:      	movk	x12, #0xa076, lsl #48
      78:      	b	0x98 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x98>
      7c:      	nop
      80:      	orr	x17, x2, x1, lsl #48
      84:      	eor	x12, x17, x12
      88:      	add	x9, x9, #0x1
      8c:      	add	x10, x10, #0x18
      90:      	cmp	x9, #0x20
      94:      	b.eq	0x1ec <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x1ec>
      98:      	ldurh	w0, [x10, #0xf]
      9c:      	sxth	w18, w0
      a0:      	cmp	w0, w11
      a4:      	b.gt	0xe0 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0xe0>
      a8:      	cmp	w0, #0x50
      ac:      	b.eq	0x128 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x128>
      b0:      	cmp	w0, #0x1bb
      b4:      	b.ne	0x108 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x108>
      b8:      	mov	w17, #0x2               // =2
      bc:      	ldrb	w1, [x10, #0x11]
      c0:      	ldur	w2, [x10, #-0x3]
      c4:      	cmp	w1, #0x2
      c8:      	b.ne	0x80 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x80>
      cc:      	b	0x140 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x140>
      d0:      	nop
      d4:      	nop
      d8:      	nop
      dc:      	nop
      e0:      	cmp	w0, w15
      e4:      	b.eq	0xf0 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0xf0>
      e8:      	cmp	w0, w16
      ec:      	b.ne	0x108 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x108>
      f0:      	mov	w17, #0x3               // =3
      f4:      	ldrb	w1, [x10, #0x11]
      f8:      	ldur	w2, [x10, #-0x3]
      fc:      	cmp	w1, #0x2
     100:      	b.ne	0x80 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x80>
     104:      	b	0x140 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x140>
     108:      	cmp	w18, w14
     10c:      	cset	w17, gt
     110:      	lsl	w17, w17, #2
     114:      	ldrb	w1, [x10, #0x11]
     118:      	ldur	w2, [x10, #-0x3]
     11c:      	cmp	w1, #0x2
     120:      	b.ne	0x80 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x80>
     124:      	b	0x140 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x140>
     128:      	mov	w17, #0x1               // =1
     12c:      	ldrb	w1, [x10, #0x11]
     130:      	ldur	w2, [x10, #-0x3]
     134:      	cmp	w1, #0x2
     138:      	b.ne	0x80 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x80>
     13c:      	nop
     140:      	ldur	w1, [x10, #0x1]
     144:      	ldrb	w3, [x10, #0x12]
     148:      	tbz	w3, #0x0, 0x1e0 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x1e0>
     14c:      	cbz	w17, 0x1e0 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x1e0>
     150:      	ldur	w0, [x10, #0x5]
     154:      	ldur	w4, [x10, #0x9]
     158:      	and	w18, w18, #0xffff
     15c:      	tst	w3, #0x4
     160:      	eor	w0, w0, w4, ror #25
     164:      	ldrb	w5, [x10, #0xd]
     168:      	ldrb	w6, [x10, #0xe]
     16c:      	lsl	w4, w5, #16
     170:      	ldurh	w7, [x10, #0x13]
     174:      	add	w5, w1, w2
     178:      	orr	w4, w4, w6, lsl #24
     17c:      	eor	w0, w0, w4
     180:      	lsl	w4, w3, #30
     184:      	and	w4, w5, w4, asr #31
     188:      	eor	w18, w18, w4
     18c:      	eor	w18, w0, w18
     190:      	sub	w0, w13, w17
     194:      	eor	w18, w18, w7
     198:      	ror	w0, w18, w0
     19c:      	csel	w18, w18, w0, eq
     1a0:      	and	w0, w9, #0x7
     1a4:      	orr	x18, x2, x18, lsl #32
     1a8:      	add	w2, w0, #0x1
     1ac:      	eor	w0, w0, #0x3f
     1b0:      	lsl	x2, x18, x2
     1b4:      	lsr	x18, x18, x0
     1b8:      	orr	x18, x2, x18
     1bc:      	eor	x12, x18, x12
     1c0:      	ubfiz	x18, x7, #16, #32
     1c4:      	orr	x17, x18, x17, lsl #56
     1c8:      	eor	x17, x17, x1
     1cc:      	add	x12, x12, x17
     1d0:      	b	0x88 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x88>
     1d4:      	nop
     1d8:      	nop
     1dc:      	nop
     1e0:      	orr	x17, x0, x1, lsl #32
     1e4:      	add	x12, x17, x12
     1e8:      	b	0x88 <bcc_tcpconnect_ipv4_tuple_filter_xdp+0x88>
     1ec:      	mov	w0, #0x2                // =2
     1f0:      	str	x12, [x8]
     1f4:      	ret
