#!/bin/bash
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S14 PYTHONDONTWRITEBYTECODE=1
cd /workspaces/repository
for arch in x86 arm64; do
 sys='-I/usr/include -I/usr/include/x86_64-linux-gnu'
 if [ "$arch" = arm64 ]; then sys='-I/usr/aarch64-linux-gnu/include -I/workspaces/repository/.cache/aarch64-sysroot/usr/include -I/workspaces/repository/.cache/aarch64-sysroot/usr/include/aarch64-linux-gnu'; fi
 taskset -c 8-23 make -C vendor/bpf -f /var/tmp/kprog-tmp/S14/corpus.mk -j4 -k scalar-corpus-objects ARCH="$arch" BUILD=/var/tmp/kprog-tmp/S14/corpus NATIVE_LINK=/workspaces/repository/kprog/x86/native_lab/native_link/target/release/native-link NATIVE_SYS_INCLUDE_FLAGS="$sys" > /var/tmp/kprog-tmp/S14/corpus-$arch.log 2>&1
 echo $? > /var/tmp/kprog-tmp/S14/corpus-$arch.exit
done
