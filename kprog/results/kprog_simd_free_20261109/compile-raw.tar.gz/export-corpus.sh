#!/bin/bash
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S14 PYTHONDONTWRITEBYTECODE=1
cd /workspaces/repository
taskset -c 8-23 python3 /var/tmp/kprog-tmp/S14/export-corpus.py > /var/tmp/kprog-tmp/S14/export-corpus.log 2>&1
echo $? > /var/tmp/kprog-tmp/S14/export-corpus.exit
