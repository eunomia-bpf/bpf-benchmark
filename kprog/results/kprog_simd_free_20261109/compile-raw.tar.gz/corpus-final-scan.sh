#!/bin/bash
export TMPDIR=/var/tmp/kprog-tmp/S14 PYTHONDONTWRITEBYTECODE=1
cd /workspaces/repository
taskset -c 8-23 python3 /var/tmp/kprog-tmp/S14/corpus-final-scan.py > /var/tmp/kprog-tmp/S14/corpus-final-scan.log 2>&1
echo $? > /var/tmp/kprog-tmp/S14/corpus-final-scan.exit
