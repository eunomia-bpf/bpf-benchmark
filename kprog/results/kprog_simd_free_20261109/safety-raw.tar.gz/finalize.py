from pathlib import Path
import collections,hashlib,json,os,re,select,shutil,subprocess,sys,tarfile,time,traceback
O=Path('/var/tmp/kprog-tmp/S14');R=Path('/workspaces/repository');D=R/'kprog/results/kprog_simd_free_20261109';C=Path('/workspaces/.agent-state/kprog-lanes/COORDINATION.md')
def notice(text):
 with C.open('a') as f:f.write('\nS14 '+text+'\n')
def run(args):return subprocess.run(args,cwd=R,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
def outcomes(epoch,arch):
 root=O/'safety'/epoch/arch
 for p in [root/'run/outcomes.json',*sorted(root.glob('transport/*/outcomes.json'))]:
  if p.exists():return json.loads(p.read_text())
 for p in sorted(root.glob('trusted-arm64-service-result/run-*.tar.gz'),reverse=True):
  with tarfile.open(p) as tar:
   hits=[m for m in tar.getmembers() if m.isfile() and m.name.rsplit('/',1)[-1]=='outcomes.json']
   if hits:return json.loads(tar.extractfile(min(hits,key=lambda m:len(m.name))).read())
 return []
def summarize():
 sets={};counts={};findings={};deltas=[];issues=[]
 for epoch in ['control','scalar']:
  for arch in ['x86','arm64']:
   key=epoch+'/'+arch;rows=outcomes(epoch,arch);sets[key]={x['name']:x for x in rows}
   p=O/'safety'/epoch/arch/'cases.json';expected=json.loads(p.read_text()) if p.exists() else []
   if len(rows)!=len(expected) or not expected:issues.append(key+' completed '+str(len(rows))+'/'+str(len(expected)))
   counts[key]=dict(collections.Counter(x['stage'] for x in rows));findings[key]=[x['name'] for x in rows if x['stage']=='accepted_finding']
   for row in rows:
    if row['unsafe_native_executed'] or (row['negative'] and len(row['command'])!=3):issues.append(key+' execution route '+row['name'])
    if not row['negative'] and row['stage']!='valid_executed':issues.append(key+' positive '+row['name']+' '+row['stage'])
 for arch in ['x86','arm64']:
  before=sets['control/'+arch];after=sets['scalar/'+arch]
  if set(before)!=set(after):issues.append(arch+' paired case set awaits completion')
  for name in before.keys()&after.keys():
   a,b=before[name],after[name]
   if a['stage']!=b['stage']:
    intended=b['stage']=='specialization_rejected' and bool(re.search(r'unsupported (?:register: [qdsbhv]\d|(?:arm64 instruction|mnemonic): (?:fmov|cnt|uaddlv|movaps|movups))',b.get('message','')+' '+str(b.get('request',{}))))
    deltas.append(dict(arch=arch,name=name,control=a['stage'],scalar=b['stage'],scalar_handler_domain=intended))
    if not intended:issues.append(arch+' paired stage '+name)
 return dict(counts=counts,accepted_findings=findings,deltas=deltas,issues=issues,negative_native_executions=0)
def wait_git(args, label):
 while True:
  p=run(args)
  with (O/'final-publication.log').open('a') as f:f.write(label+'\n'+p.stdout+'\n')
  if p.returncode==0:return p.stdout
  notice('publication retry '+label+': command receipt retained in final-publication.log; current owned paths and shared writers remain in place.')
  time.sleep(30)
def main():
 if len(sys.argv)>1 and sys.argv[1]=='--summarize':print(json.dumps(summarize(),indent=2));return
 if len(sys.argv)>2 and sys.argv[1]=='--wait-pid':
  try:fd=os.pidfd_open(int(sys.argv[2]))
  except ProcessLookupError:pass
  else:select.select([fd],[],[]);os.close(fd)
 result=summarize();(O/'safety-summary.json').write_text(json.dumps(result,indent=2)+'\n')
 if result['issues']:
  notice('ATTENTION: completed serial safety receipts require review: '+json.dumps(result['issues'])+'. All actual counts and stages retained in /var/tmp/kprog-tmp/S14/safety-summary.json; lane continues at this recorded dependency.');return
 # Export every safety receipt plus source/command hashes; large kernel/runtime inputs use their captured hashes.
 package=O/'safety-publish';package.mkdir()
 shutil.copytree(O/'safety',package/'safety')
 for name in ['safety.py','safety.sh','safety.log','safety-source-pins.json','safety-summary.json','finalize.py']:
  shutil.copy2(O/name,package/name)
 manifest=[]
 for p in sorted(package.rglob('*')):
  if p.is_file():manifest.append(dict(path=str(p.relative_to(package)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 archive=O/'safety-raw.tar.gz'
 with tarfile.open(archive,'w:gz') as tar:
  for row in manifest:tar.add(package/row['path'],arcname=row['path'],recursive=False)
 with tarfile.open(archive) as tar:
  for row in manifest:
   data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 shutil.copy2(archive,D/archive.name)
 meta=dict(archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),entries=manifest)
 (D/'safety-raw-manifest.json').write_text(json.dumps(meta,indent=2)+'\n');(D/'safety-summary.json').write_text(json.dumps(result,indent=2)+'\n')
 p=D/'README.md';text=p.read_text();text=text.replace('S14, 2026-11-09. Implementation and compile evidence are published; the paired\nsafety replay remains active under `/var/tmp/kprog-tmp/S14/safety.sh`.','S14, 2026-11-09. The scalar native scope, compile evidence and paired safety\nreplay are complete and published. The lane retires its private outputs after\nGit archive and remote-ancestry readback.')
 start=text.index('The paired safety recipe captures');end=text.index('\nThe initial corpus invocation',start)
 section='The paired safety recipe captures common model/service/kernel/bridge inputs and\nuses one 2 GiB guest at a time on CPUs 20-23. Complete observed stage counts:\n\n| Epoch/ISA | Observed stages |\n| --- | --- |\n'
 for key,count in result['counts'].items():section+='| '+key+' | '+', '.join(k+'='+str(v) for k,v in count.items())+' |\n'
 section+='\nEvery positive control executes with its expected result. Negative native\nexecutions: 0. Integer-case stages remain paired. SIMD/FP generation-domain\nchanges: '+json.dumps(result['deltas'],sort_keys=True)+'.\n\nLoad-only accepted findings remain recorded by epoch/ISA: '+json.dumps(result['accepted_findings'],sort_keys=True)+'. These preserved model findings retain their C/A/S7 owners.\n`safety-raw.tar.gz` retains all source-pinned inputs, requests, generated B,\nstock verifier logs and actual outcomes. V retains universal compiled-B and\nphysical-composition ownership.\n'
 p.write_text(text[:start]+section+text[end:])
 assert run(['git','branch','--show-current']).stdout.strip()=='master'
 status=run(['git','status','--short','--branch','-uno']);(O/'final-status.log').write_text(status.stdout)
 paths=[str((D/name).relative_to(R)) for name in ['README.md','safety-summary.json','safety-raw-manifest.json','safety-raw.tar.gz']]
 check=run(['git','diff','--check','--',*paths]);assert check.returncode==0,check.stdout
 wait_git(['git','add','-f','--',*paths],'stage owned safety receipts')
 wait_git(['git','commit','--only',*paths,'-m','Record paired scalar native safety outcomes'],'commit owned safety receipts')
 commit=run(['git','rev-parse','HEAD']).stdout.strip();wait_git(['git','push','origin','master'],'push master')
 for sha in ['dba3416ac','4f40432f1','6cb21f656','dcd1af7cb',commit]:assert run(['git','merge-base','--is-ancestor',sha,'origin/master']).returncode==0
 for name in ['compile-raw','safety-raw']:
  m=json.loads((D/(name+'-manifest.json')).read_text());b=subprocess.check_output(['git','show',commit+':'+str((D/(name+'.tar.gz')).relative_to(R))],cwd=R);assert hashlib.sha256(b).hexdigest()==m['archive_sha256']
 # Every producer and guest has exited before private-output retirement.
 assert O.resolve()==Path('/var/tmp/kprog-tmp/S14') and O.is_dir()
 counts=json.dumps(result['counts'],sort_keys=True);deltas=json.dumps(result['deltas'],sort_keys=True)
 digest=meta['archive_sha256'];n=len(manifest)
 shutil.rmtree(O)
 notice('FINAL 2026-11-09 published-clean: SIMD-free native scope complete. Published commits dba3416ac,4f40432f1,6cb21f656,dcd1af7cb,'+commit+' are remote-master ancestors. Native60pairs executable changes0; B60/60; rebuilt corpus198 and existing638path operands0; specializer7generation failures; Cilium13tests. Complete paired counts '+counts+'; domain deltas '+deltas+'. Every positive control retains its expected execution; negative native executions0. Preserved load-only findings retain C/A/S7 ownership; universal compiled-B/physical composition remains V-owned. Safety archive '+str(n)+'members SHA256 '+digest+' and compile archive independently verified from Git. Own producers/guests0 and /var/tmp/kprog-tmp/S14 retired; recovered generated headers and vmlinux receipts published. The finite Windows completion bridge creates the empty local STOP and exits.')
try:main()
except Exception:
 message=traceback.format_exc()
 if O.exists():(O/'finalize-error.log').write_text(message)
 notice('ATTENTION: final publication dependency recorded in /var/tmp/kprog-tmp/S14/finalize-error.log; existing owned results and shared writers remain preserved. '+message.splitlines()[-1])
 raise
