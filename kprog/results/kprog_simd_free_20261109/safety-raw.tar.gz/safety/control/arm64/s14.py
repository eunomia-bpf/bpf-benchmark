from pathlib import Path
import sys,importlib.util,json,os,subprocess,types
R=Path('/workspaces/repository');O=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('s14base',O/'_base_check.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
ARCH='arm64'
m.ARCH=ARCH;m.OUT=O;m.BUILD=R/('kprog/formal/build/fidelity-trusted'+('-arm64' if ARCH=='arm64' else ''))
if ARCH=='arm64':
 m.loader_build=lambda:R/'kprog/libnativeloader/build-arm64-typed-tail-v1'
 positives={'valid_control':'mov w0,#2; ret','valid_copy_restore':'mov x1,sp; mov sp,x1; mov w0,#2; ret','valid_alias_load':'sub sp,sp,#16; mov x1,#37; str x1,[sp]; mov x2,sp; ldr x3,[x2]; add sp,sp,#16; cmp x3,#37; b.ne 1f; mov w0,#2; ret; 1: mov w0,#0; ret','valid_spill_restore':'sub sp,sp,#32; add x1,sp,#16; str x1,[sp]; ldr x1,[sp]; mov sp,x1; add sp,sp,#16; mov w0,#2; ret'}
 m.cases=lambda:[dict(name=n,assembly=a,negative=False) for n,a in positives.items()]+[dict(name=n,assembly=a,negative=True) for n,a in m.fixtures.FIXTURES[ARCH].items()]
if sys.argv[1]=='build':m.build()
elif sys.argv[1]=='guest':
 live=Path(sys.argv[2]);selected=json.loads((O/'cases.json').read_text());(live/'cases.json').write_text(json.dumps(selected));m.cases=lambda:selected;m.OUT=live
 if ARCH=='arm64':os.environ['KPROG_TRUSTED_COMPILE_STATE']=str(O/'compile-broker')
 try:m.check()
 finally:
  p=live/'outcomes.json';rows=json.loads(p.read_text()) if p.exists() else []
  (live/'guest.json').write_text(json.dumps(dict(cases=len(rows),expected=len(selected),counts=dict(__import__('collections').Counter(x['stage'] for x in rows)),negative_executions=0),indent=2)+'\n')
elif sys.argv[1]=='host':
 spec=importlib.util.spec_from_file_location('s14transport',R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
 real_popen=subprocess.Popen
 def launch(argv,**kw):
  argv[:]=[x+',multidevs=remap' if x.startswith('local,id=repo,') else x for x in argv]
  argv[2]='20-23'
  return real_popen(argv,**kw)
 t.subprocess=types.SimpleNamespace(Popen=launch,PIPE=subprocess.PIPE,STDOUT=subprocess.STDOUT)
 t.HERE=O;t.__file__=__file__;t.NATIVE_LINK=m.native_link();t.LOADER=m.loader_build();t.host()
