from pathlib import Path
import hashlib,json,re,subprocess
O=Path('/var/tmp/kprog-tmp/S14')
reg=re.compile(r'(?<![A-Za-z0-9_])(?:[xyz]mm\d+|mm[0-7]|st(?:\([0-7]\))?|[vqdsbh](?:[12]?\d|3[01])(?:\.[0-9]*[bhsd])?|fpcr|fpsr|fpmr)(?![A-Za-z0-9_])',re.I)
state={'emms','vzeroupper','vzeroall','ldmxcsr','stmxcsr','xsave','xsave64','xsavec','xsavec64','xsaveopt','xsaveopt64','xsaves','xsaves64','xrstor','xrstor64','xrstors','xrstors64'}
def inspect(text):
 hits=[]
 for line in text.splitlines():
  m=re.match(r'^\s*[0-9a-f]+:\s+(\S+)\s*(.*)$',line)
  if not m:continue
  mnemonic,operands=m.groups();operands=operands.split('//',1)[0].split(' # ',1)[0]
  if mnemonic.startswith('f') or mnemonic in state or reg.search(operands):hits.append(line)
 return hits
paths=sorted((O/'micro-final').glob('*/*/*/*.native.asm'))+sorted((O/'export/corpus').rglob('*.native.asm'))
rows=[dict(path=str(p.relative_to(O)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),fp_instruction_hits=inspect(p.read_text())) for p in paths]
assert len(rows)==318,len(rows)
assert all(not x['fp_instruction_hits'] for x in rows),[x for x in rows if x['fp_instruction_hits']]
controls=[]
for p in sorted((O/'rejection').glob('*/*/input.o')):
 text=subprocess.check_output(['llvm-objdump-18','-d','--no-show-raw-insn',str(p)],text=True);hits=inspect(text);assert hits,str(p)
 controls.append(dict(path=str(p.relative_to(O)),detected=hits))
assert len(controls)==7
(O/'safety/fp-audit.json').write_text(json.dumps(dict(native_objects=len(rows),fp_state_instruction_hits=0,positive_detection_controls=controls,objects=rows),indent=2)+'\n')
print('native FP state audit: PASS',len(rows),'objects, 0 hits; 7 actual rejection-ELF detection controls')
