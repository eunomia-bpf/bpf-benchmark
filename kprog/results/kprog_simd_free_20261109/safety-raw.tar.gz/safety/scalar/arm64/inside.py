from pathlib import Path
import os,subprocess,sys
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S14/safety/scalar/arm64')
os.unshare(os.CLONE_NEWNS);subprocess.run(['mount','--make-rprivate','/'],check=True)
def bind(a,b):subprocess.run(['mount','--bind',str(a),str(b)],check=True)
arch='arm64';epoch='scalar'
canon=R/'kprog/results/kprog_fidelity_20261107/negative'/('x86-trusted-sp' if arch=='x86' else 'arm64-trusted-sp')
bind(O,canon);bind(O/'build',R/('kprog/formal/build/fidelity-trusted'+('-arm64' if arch=='arm64' else '')))
if epoch=='control':bind(Path('/var/tmp/kprog-tmp/S14/baseline')/f'kprog/{arch}/micro-prog/generate_micro_sim_proofs.py',R/f'kprog/{arch}/micro-prog/generate_micro_sim_proofs.py')
subprocess.run(['python3',str(canon/'s14.py'),'build'],check=True)
if arch=='x86':
 (canon/'run').mkdir()
 cmd='cd /workspaces/repository && (mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug) && insmod /workspaces/repository/kprog/tv/build-x86/bpf_x86_native_lab.ko && PATH=/usr/lib/llvm-18/bin:$PATH PYTHONDONTWRITEBYTECODE=1 python3 '+str(canon/'s14.py')+' guest '+str(canon/'run')
 rc=subprocess.run(['taskset','-c','20-23','vng','--run',str(R/'kprog/tv/build-kernel-x86/arch/x86/boot/bzImage'),'--cwd',str(R),'--rwdir',str(R),'--overlay-rwdir','/tmp','--disable-monitor','--cpus','2','--memory','2G','--append','loglevel=4 panic=30 oops=panic','--exec',cmd]).returncode
else:
 bind(O/'transport',R/'kprog/arm64/build/trusted-transport')
 broker_dir=canon/'compile-broker';broker_dir.mkdir()
 with (O/'compile-broker.log').open('w') as log:
  broker=subprocess.Popen(['python3',str(R/'kprog/trusted_compile.py'),'serve','--scope',str(R),'--state',str(broker_dir),'--arm64-sysroot',str(R/'kprog/arm64/build/app-runtime-v35/root')],stdout=log,stderr=subprocess.STDOUT)
  try:rc=subprocess.run(['python3',str(canon/'s14.py'),'host']).returncode
  finally:(broker_dir/'STOP').touch();broker.wait()
(O/'inside.exit').write_text(str(rc)+'\n');raise SystemExit(rc)
