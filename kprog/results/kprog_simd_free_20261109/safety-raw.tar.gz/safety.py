from pathlib import Path
import collections,hashlib,importlib.util,json,os,shutil,subprocess,sys,types
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S14')
os.unshare(os.CLONE_NEWNS);subprocess.run(['mount','--make-rprivate','/'],check=True)
def bind(src,dst):subprocess.run(['mount','--bind',str(src),str(dst)],check=True)
spec=importlib.util.spec_from_file_location('s14tcb',R/'kprog/fidelity/tcb.py');tcb=importlib.util.module_from_spec(spec);spec.loader.exec_module(tcb)
paths=set()
for arch in ['x86','arm64']:
 paths|=tcb.includes(R/f'kprog/{arch}/{arch}_sim_local_bpf.h')|tcb.imports(R/f'kprog/{arch}/micro-prog/generate_micro_sim_proofs.py')
 paths|={R/f'kprog/{arch}/trusted_specializer.py'}
paths|={R/x for x in ['kprog/trusted_service.py','kprog/trusted_generation.py','kprog/trusted_compile.py','kprog/fidelity/negative.py','kprog/fidelity/bound_probe.cpp','kprog/fidelity/negative_companion.bpf.c','kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp/check.py','kprog/x86/native_lab/native_link/target/release/native-link','kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link','kprog/tv/build-kernel-x86/arch/x86/boot/bzImage','kprog/tv/build-x86/bpf_x86_native_lab.ko']}
# Use the established paired protected-read kernel and current ARM bridge.
for src,dst in [('kprog/arm64/build/native-load-recovery/recovery/Image','vendor/build/arm64/linux/arch/arm64/boot/Image'),('kprog/arm64/build/native-load-recovery/recovery/bpf_arm64_native_lab.ko','kinsn/module/arm64/build-native-resources/bpf_arm64_native_lab.ko')]:
 paths.add(R/src)
for root in ['kprog/libnativeloader/build','kprog/libnativeloader/build-arm64-typed-tail-v1']:
 for name in ['trusted-native-loader','trusted-service-client','trusted-native.o','libnative_loader.a']:
  p=R/root/name
  if p.exists():paths.add(p)
for name in ['trusted-native-loader','trusted-service-client','libnative_loader.a']:
 paths.add(R/'runner/build-arm64-llvmbpf/native_loader'/name)
pins={}
for p in sorted(paths):
 d=O/'safety-source'/p.relative_to(R);d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d);pins[str(p.relative_to(R))]=hashlib.sha256(d.read_bytes()).hexdigest();bind(d,p)
(O/'safety-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
for src,dst in [('kprog/arm64/build/native-load-recovery/recovery/Image','vendor/build/arm64/linux/arch/arm64/boot/Image'),('kprog/arm64/build/native-load-recovery/recovery/bpf_arm64_native_lab.ko','kinsn/module/arm64/build-native-resources/bpf_arm64_native_lab.ko')]:bind(R/src,R/dst)
for name in ['trusted-native-loader','trusted-service-client','libnative_loader.a']:
 bind(R/'runner/build-arm64-llvmbpf/native_loader'/name,R/'kprog/libnativeloader/build-arm64-typed-tail-v1'/name)
# Each namespace child receives one epoch and uses the ordinary registered service.
wrapper='''from pathlib import Path
import sys,importlib.util,json,os,subprocess,types
R=Path('/workspaces/repository');O=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('s14base',O/'_base_check.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
ARCH=ARCH_VALUE
m.ARCH=ARCH;m.OUT=O;m.BUILD=R/('kprog/formal/build/fidelity-trusted'+('-arm64' if ARCH=='arm64' else ''))
if ARCH=='arm64':
 m.loader_build=lambda:R/'kprog/libnativeloader/build-arm64-typed-tail-v1'
 positives={'valid_control':'mov w0,#2; ret','valid_copy_restore':'mov x1,sp; mov sp,x1; mov w0,#2; ret','valid_alias_load':'sub sp,sp,#16; mov x1,#37; str x1,[sp]; mov x2,sp; ldr x3,[x2]; add sp,sp,#16; cmp x3,#37; b.ne 1f; mov w0,#2; ret; 1: mov w0,#0; ret','valid_spill_restore':'sub sp,sp,#32; add x1,sp,#16; str x1,[sp]; ldr x1,[sp]; mov sp,x1; add sp,sp,#16; mov w0,#2; ret'}
 m.cases=lambda:[dict(name=n,assembly=a,negative=False) for n,a in positives.items()]+[dict(name=n,assembly=a,negative=True) for n,a in m.fixtures.FIXTURES[ARCH].items()]
if sys.argv[1]=='build':m.build()
elif sys.argv[1]=='guest':
 live=Path(sys.argv[2]);selected=json.loads((O/'cases.json').read_text());(live/'cases.json').write_text(json.dumps(selected));m.cases=lambda:selected;m.OUT=live
 if ARCH=='arm64':os.environ['KPROG_TRUSTED_COMPILE_STATE']=str(O/'compile-broker')
 try:m.check()
 finally:
  p=live/'outcomes.json';rows=json.loads(p.read_text()) if p.exists() else []
  (live/'guest.json').write_text(json.dumps(dict(cases=len(rows),expected=len(selected),counts=dict(__import__('collections').Counter(x['stage'] for x in rows)),negative_executions=0),indent=2)+'\\n')
elif sys.argv[1]=='host':
 spec=importlib.util.spec_from_file_location('s14transport',R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
 real_popen=subprocess.Popen
 def launch(argv,**kw):
  argv[:]=[x+',multidevs=remap' if x.startswith('local,id=repo,') else x for x in argv]
  argv[2]='20-23'
  return real_popen(argv,**kw)
 t.subprocess=types.SimpleNamespace(Popen=launch,PIPE=subprocess.PIPE,STDOUT=subprocess.STDOUT)
 t.HERE=O;t.__file__=__file__;t.NATIVE_LINK=m.native_link();t.LOADER=m.loader_build();t.host()
'''
base=(R/'kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp/check.py').read_bytes()
for epoch in ['control','scalar']:
 for arch in ['x86','arm64']:
  out=O/'safety'/epoch/arch;out.mkdir(parents=True,exist_ok=True)
  (out/'_base_check.py').write_bytes(base);(out/'s14.py').write_text(wrapper.replace('ARCH_VALUE',repr(arch)))
  (out/'build').mkdir();(out/'transport').mkdir()
  # The child restores its parent's mount view automatically at exit.
  job=out/'inside.py'
  job.write_text('''from pathlib import Path
import os,subprocess,sys
R=Path('/workspaces/repository');O=Path(OUT_VALUE)
os.unshare(os.CLONE_NEWNS);subprocess.run(['mount','--make-rprivate','/'],check=True)
def bind(a,b):subprocess.run(['mount','--bind',str(a),str(b)],check=True)
arch=ARCH_VALUE;epoch=EPOCH_VALUE
canon=R/'kprog/results/kprog_fidelity_20261107/negative'/('x86-trusted-sp' if arch=='x86' else 'arm64-trusted-sp')
bind(O,canon);bind(O/'build',R/('kprog/formal/build/fidelity-trusted'+('-arm64' if arch=='arm64' else '')))
if epoch=='control':bind(Path('/var/tmp/kprog-tmp/S14/baseline')/f'kprog/{arch}/micro-prog/generate_micro_sim_proofs.py',R/f'kprog/{arch}/micro-prog/generate_micro_sim_proofs.py')
subprocess.run(['python3',str(canon/'s14.py'),'build'],check=True)
if arch=='x86':
 (canon/'run').mkdir()
 cmd='cd /workspaces/repository && (mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug) && insmod /workspaces/repository/kprog/tv/build-x86/bpf_x86_native_lab.ko && PATH=/usr/lib/llvm-18/bin:$PATH PYTHONDONTWRITEBYTECODE=1 python3 '+str(canon/'s14.py')+' guest '+str(canon/'run')
 rc=subprocess.run(['taskset','-c','20-23','vng','--run',str(R/'kprog/tv/build-kernel-x86/arch/x86/boot/bzImage'),'--cwd',str(R),'--rwdir',str(R),'--overlay-rwdir','/tmp','--disable-monitor','--cpus','2','--memory','2G','--append','loglevel=4 panic=30 oops=panic','--exec',cmd]).returncode
else:
 bind(O/'transport',R/'kprog/arm64/build/trusted-transport')
 broker_dir=canon/'compile-broker';broker_dir.mkdir()
 with (O/'compile-broker.log').open('w') as log:
  broker=subprocess.Popen(['python3',str(R/'kprog/trusted_compile.py'),'serve','--scope',str(R),'--state',str(broker_dir),'--arm64-sysroot',str(R/'kprog/arm64/build/app-runtime-v35/root')],stdout=log,stderr=subprocess.STDOUT)
  try:rc=subprocess.run(['python3',str(canon/'s14.py'),'host']).returncode
  finally:(broker_dir/'STOP').touch();broker.wait()
(O/'inside.exit').write_text(str(rc)+'\\n');raise SystemExit(rc)
'''.replace('OUT_VALUE',repr(str(out))).replace('ARCH_VALUE',repr(arch)).replace('EPOCH_VALUE',repr(epoch)))
  print('SAFETY',epoch,arch,'START',flush=True)
  with (out/'console.log').open('w') as log: rc=subprocess.run(['python3',str(job)],stdout=log,stderr=subprocess.STDOUT).returncode
  print('SAFETY',epoch,arch,'RETURN',rc,flush=True)
print('paired safety jobs complete',flush=True)
