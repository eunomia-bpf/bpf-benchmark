import BPF
namespace KProgTV.Compiled
def input_block : Array KProgFormal.Reference.Byte := #[0xb7, 0x90, 0x01, 0x00, 0x02, 0x00, 0x00, 0x00, 0xbf, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb7, 0x90, 0x02, 0x00, 0x02, 0x00, 0x00, 0x00, 0xbf, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0f, 0x23, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb7, 0x90, 0x01, 0x00, 0x02, 0x00, 0x00, 0x00, 0x0f, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb7, 0x90, 0x04, 0x00, 0x02, 0x00, 0x00, 0x00, 0x0f, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xbf, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x95, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
@[simp] theorem input_block_decode_0 : BPF.decode input_block 0 = .ok ⟨183, 0, 9, 1, 2⟩ := by rfl
@[simp] theorem input_block_decode_1 : BPF.decode input_block 1 = .ok ⟨191, 2, 0, 0, 0⟩ := by rfl
@[simp] theorem input_block_decode_2 : BPF.decode input_block 2 = .ok ⟨183, 0, 9, 2, 2⟩ := by rfl
@[simp] theorem input_block_decode_3 : BPF.decode input_block 3 = .ok ⟨191, 3, 0, 0, 0⟩ := by rfl
@[simp] theorem input_block_decode_4 : BPF.decode input_block 4 = .ok ⟨15, 3, 2, 0, 0⟩ := by rfl
@[simp] theorem input_block_decode_5 : BPF.decode input_block 5 = .ok ⟨183, 0, 9, 1, 2⟩ := by rfl
@[simp] theorem input_block_decode_6 : BPF.decode input_block 6 = .ok ⟨15, 3, 0, 0, 0⟩ := by rfl
@[simp] theorem input_block_decode_7 : BPF.decode input_block 7 = .ok ⟨183, 0, 9, 4, 2⟩ := by rfl
@[simp] theorem input_block_decode_8 : BPF.decode input_block 8 = .ok ⟨15, 3, 0, 0, 0⟩ := by rfl
@[simp] theorem input_block_decode_9 : BPF.decode input_block 9 = .ok ⟨191, 0, 3, 0, 0⟩ := by rfl
@[simp] theorem input_block_decode_10 : BPF.decode input_block 10 = .ok ⟨149, 0, 0, 0, 0⟩ := by rfl
@[simp] theorem imm_0 : (BitVec.ofNat 32 0).signExtend 64 = BitVec.ofNat 64 0 := by decide
@[simp] theorem imm_2 : (BitVec.ofNat 32 2).signExtend 64 = BitVec.ofNat 64 2 := by decide
@[simp] theorem off_0 : (BitVec.ofNat 16 0).toInt = (0 : Int) := by decide
@[simp] theorem off_1 : (BitVec.ofNat 16 1).toInt = (1 : Int) := by decide
@[simp] theorem off_2 : (BitVec.ofNat 16 2).toInt = (2 : Int) := by decide
@[simp] theorem off_4 : (BitVec.ofNat 16 4).toInt = (4 : Int) := by decide
end KProgTV.Compiled
