#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

extern __u8 __source_map_base_0[] __ksym;
static const char __x86_source_map_metadata[] SEC(".native_lab.source_maps") = "{\"version\":1,\"objects\":[{\"native_symbol\":\"__native_source_map_0\",\"source_insn\":0,\"proof_symbol\":\"__source_map_base_0\"}]}";

SEC("socket")
int bcc_map_value_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)(__source_map_base_0 + 16ULL)));
x86_l_7:
	/* 0x7: mov    QWORD PTR [rax],0x2a */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 42ULL);
x86_l_e:
	/* 0xe: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_10:
	/* 0x10: jmp    15 <bpf_main+0x15> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_15:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
