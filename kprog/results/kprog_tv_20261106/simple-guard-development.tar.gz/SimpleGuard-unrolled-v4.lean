import ARM64Path
import BPFPath
import SimpleCompiled
import Std.Tactic.BVDecide

set_option maxRecDepth 4096
set_option maxHeartbeats 300000

namespace KProgTV.SimpleGuardCertificate
open KProgFormal.Reference KProgTV.SimpleCompiled

@[simp] theorem native_size : native.size = 84 := rfl

-- The actual native opcodes, not a second decoder or assumed CFG.
theorem decode4 : AArch64.decode (native.extract 4 8) =
    .ok (.moveRegister .w64 (.general 10) (.general 8)) := rfl
theorem decode8 : AArch64.decode (native.extract 8 12) =
    .ok (.arithmeticRegister .w64 true true .zero (.general 10) 9 0 ⟨0, by decide⟩) := rfl
theorem decode12 : AArch64.decode (native.extract 12 16) =
    .ok (.branchConditional 8 24) := rfl
theorem decode16 : AArch64.decode (native.extract 16 20) =
    .ok (.arithmeticImmediate .w64 false false (.general 11) (.general 10) 8) := rfl
theorem decode20 : AArch64.decode (native.extract 20 24) =
    .ok (.arithmeticImmediate .w64 false false (.general 10) (.general 10) 72) := rfl
theorem decode24 : AArch64.decode (native.extract 24 28) =
    .ok (.arithmeticRegister .w64 true true .zero (.general 11) 9 0 ⟨0, by decide⟩) := rfl
theorem decode28 : AArch64.decode (native.extract 28 32) =
    .ok (.compare .w64 10 (.register 9) 9 2) := rfl
theorem decode32 : AArch64.decode (native.extract 32 36) =
    .ok (.branchConditional 9 12) := rfl

set_option pp.maxSteps 3000

theorem cmp_hi (left right flags : Word) :
    AArch64.condition (AArch64.arithmeticFlags .w64 true left right flags) 8 = (left > right) := by
  simp only [AArch64.condition, AArch64.arithmeticFlags, AArch64.Width.bits]
  bv_decide

theorem cmp_ls (left right flags : Word) :
    AArch64.condition (AArch64.arithmeticFlags .w64 true left right flags) 9 = (left ≤ right) := by
  simp only [AArch64.condition, AArch64.arithmeticFlags, AArch64.Width.bits]
  bv_decide

theorem fallback_rejects (flags : Word) :
    AArch64.condition (AArch64.compareFallback flags (2#4)) 9 = false := by
  simp only [AArch64.condition, AArch64.compareFallback]
  bv_decide

def before (n : AArch64.State) (pointer limit : Word) : AArch64.State :=
  { n with
    gpr := fun r => if r.val = 8 then pointer else if r.val = 9 then limit else n.gpr r
    pc := 4 }

def nativePositions (pointer limit : Word) : List Nat :=
  if pointer > limit then [4,8,12] else [4,8,12,16,20,24,28,32]

def admitted (pointer limit : Word) : Bool :=
  pointer ≤ limit && pointer + (8#64) ≤ limit && pointer + (72#64) ≤ limit

def nativeObserved (n : AArch64.State) (pointer limit : Word) :=
  (ARM64Path.evaluate 0 native (nativePositions pointer limit) (before n pointer limit)).map
    fun result => (result.state.pc, result.state.memory, result.events, result.fault)

theorem native_guards (n : AArch64.State) (pointer limit : Word) :
    nativeObserved n pointer limit =
      .ok (if admitted pointer limit then 44 else 36, n.memory, [], none) := by
  by_cases h0 : pointer > limit <;>
    simp +decide [nativeObserved, nativePositions, admitted,
      ARM64Path.evaluate, ARM64Path.step, decode4, decode8, decode12,
      decode16, decode20, decode24, decode28, decode32,
      before, AArch64.step, AArch64.moveRegStep, AArch64.readData, AArch64.writeData,
      AArch64.writeReg, AArch64.readReg, AArch64.narrow, AArch64.Width.bits,
      AArch64.arithmeticRegisterStep, AArch64.arithmeticImmediateStep,
      AArch64.shiftValue, AArch64.arithmeticShift,
      AArch64.compareStep, AArch64.compareOperand, AArch64.branchStep,
      cmp_hi, cmp_ls, fallback_rejects, h0,
      Fin.ofNat', Fin.instOfNat, Except.bind, Except.map, Except.pure,
      Bind.bind, Pure.pure, Except.instMonad]
  all_goals trace_state

end KProgTV.SimpleGuardCertificate
#print axioms KProgTV.SimpleGuardCertificate.native_guards
