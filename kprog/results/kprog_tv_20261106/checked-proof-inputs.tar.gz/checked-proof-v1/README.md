Checked-proof capture v1, 2026-11-06. Native module only; use the matching
T context-v2-exclusive-choice kernel/runtime pair. Earlier immutable handoffs
are unchanged. Both architectures pass their complete binding regression.

insmod bpf_<arch>_native_lab.ko capture_checked=1
Read /sys/kernel/debug/bpf_<arch>_native_lab/checked_proof immediately after
EACH successful bound load and before the next upload. CAP_SYS_ADMIN required.
Binary format: native_lab_checked_wire.h. Snapshot includes exact expanded
virtual proof, all proof regions/payloads, binding96/source identity, resolved
map IDs/shapes/pointers and helper IDs/functions. One latest snapshot, no queue.
A blob/proof/relocation/binding mutation invalidates new opens; an existing FD
retains an immutable copy. A failed load is not verifier acceptance evidence.
Default capture_checked=0. Capture errors with capture enabled propagate.
