#include "native_rodata_binding.hpp"
#include <cstdio>
int main() {
    const auto layout = parse_native_readonly_layout(
        R"({"version":1,"objects":[{"native_symbol":"\u0061","offset":0,"size":16}]})", 16);
    const ProofReadonlyBinding proof{".rodata.native.0", "proof", "?", 16};
    try {
        resolve_readonly_extent(proof, layout, 16);
        std::puts("UNSAFE_ACCEPT: Unicode a bound to distinct question-mark symbol");
        return 1;
    } catch (const std::runtime_error &error) {
        if (std::string(error.what()).find("absent") == std::string::npos) throw;
        std::puts("Unicode a / question-mark mismatch: REJECTED");
        return 0;
    }
}
