/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_LOAD_TAG_H
#define KPROG_FORMAL_GENERATED_ARM64_LOAD_TAG_H
/*
 * The routing decision of the ordinary AArch64 load: whether the destination is
 * written by the tag-copy register write (which attaches the memory-read
 * provenance tag) or by the tag-dropping width-narrowed scalar write. The tag is
 * preserved only at doubleword width and only when it is not the bare scalar tag.
 * An opcode outside the family reaches the caller-supplied unsupported arm.
 */
#include "arm64_width.h"
_Static_assert(ARM64_OP_LOAD == 31U, "arm64 load-tag code drift");
/*
 * The numeric case label 31U tracks the ARM64_OP_LOAD value defined in
 * kprog/arm64/arm64_sim.h. OP is the opcode, TAG the memory-read provenance
 * tag, WIDTH the access width code; OP, TAG and WIDTH are each read once. The
 * result is 1 when the destination must be written through
 * ARM64_SIM_L_WRITE_REG_PTR_TAG (attaching TAG) and 0 when it must be written
 * through ARM64_SIM_L_WRITE_REG_WIDTH (dropping TAG).
 */
#define KPROG_ARM64_LOAD_TAG_PRESERVE_INTO(OUTPUT, OP, TAG, WIDTH, UNSUPPORTED)          \
	do { \
		__u64 __kprog_a64_lt_op = (OP); \
		__u64 __kprog_a64_lt_tag = (TAG); \
		__u64 __kprog_a64_lt_width = (WIDTH); \
		__u64 __kprog_a64_lt_preserve = 0; \
\
		switch (__kprog_a64_lt_op) { \
		case 31U:                            \
			__kprog_a64_lt_preserve = \
				__kprog_a64_lt_width == ARM64_WIDTH_64 && \
				__kprog_a64_lt_tag != ARM64_SIM_TAG_SCALAR; \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		(OUTPUT) = __kprog_a64_lt_preserve; \
	} while (0)
#define KPROG_ARM64_LOAD_TAG_PRESERVE(OP, TAG, WIDTH, UNSUPPORTED) \
    ({ __u64 __kprog_memory_helper_result; \
       KPROG_ARM64_LOAD_TAG_PRESERVE_INTO(__kprog_memory_helper_result, (OP), (TAG), (WIDTH), UNSUPPORTED); \
       __kprog_memory_helper_result; })
#endif
