/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_PAIR_LOAD_TAG_H
#define KPROG_FORMAL_GENERATED_ARM64_PAIR_LOAD_TAG_H
/*
 * The routing decision of the AArch64 pair load: the outer pair gate
 * (`width == 64 && (tagLo != SCALAR || tagHi != SCALAR)`) guarding two per-slot
 * tag-class decisions. The result is a two-bit mask: bit 0 selects the tag-copy
 * register write for the low slot (attaching TAG_LO), bit 1 for the high slot
 * (attaching TAG_HI); a clear bit selects the tag-dropping width-narrowed scalar
 * write.
 * An opcode outside the family reaches the caller-supplied unsupported arm.
 */
#include "arm64_width.h"
_Static_assert(ARM64_OP_LDP == 33U, "arm64 pair-load-tag code drift");
/*
 * The numeric case label 33U tracks the ARM64_OP_LDP value defined in
 * kprog/arm64/arm64_sim.h. OP is the opcode, TAG_LO/TAG_HI the memory-read
 * provenance tags of the low and high slots, WIDTH the access width code; OP,
 * TAG_LO, TAG_HI and WIDTH are each read once. The handler then writes the low
 * slot to DST through KPROG_ARM64_PAIR_LOAD_TAG_ROUTE_LOW(mask) and the high slot
 * to SRC through KPROG_ARM64_PAIR_LOAD_TAG_ROUTE_HIGH(mask).
 */
#define KPROG_ARM64_PAIR_LOAD_TAG_ROUTE_INTO(OUTPUT, OP, TAG_LO, TAG_HI, WIDTH, UNSUPPORTED)\
	do { \
		__u64 __kprog_a64_plt_op = (OP); \
		__u64 __kprog_a64_plt_lo = (TAG_LO); \
		__u64 __kprog_a64_plt_hi = (TAG_HI); \
		__u64 __kprog_a64_plt_width = (WIDTH); \
		__u64 __kprog_a64_plt_mask = 0; \
\
		switch (__kprog_a64_plt_op) { \
		case 33U:                            \
			if (__kprog_a64_plt_width == ARM64_WIDTH_64 && \
			    (__kprog_a64_plt_lo != ARM64_SIM_TAG_SCALAR || \
			     __kprog_a64_plt_hi != ARM64_SIM_TAG_SCALAR)) { \
				if (__kprog_a64_plt_lo != ARM64_SIM_TAG_SCALAR)\
					__kprog_a64_plt_mask |= 1U; \
				if (__kprog_a64_plt_hi != ARM64_SIM_TAG_SCALAR)\
					__kprog_a64_plt_mask |= 2U; \
			} \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		(OUTPUT) = __kprog_a64_plt_mask; \
	} while (0)
#define KPROG_ARM64_PAIR_LOAD_TAG_ROUTE(OP, TAG_LO, TAG_HI, WIDTH, UNSUPPORTED) \
    ({ __u64 __kprog_pair_mask; \
       KPROG_ARM64_PAIR_LOAD_TAG_ROUTE_INTO(__kprog_pair_mask, (OP), (TAG_LO), (TAG_HI), (WIDTH), UNSUPPORTED); \
       __kprog_pair_mask; })

/*
 * The two slot route bits of the mask produced by
 * KPROG_ARM64_PAIR_LOAD_TAG_ROUTE: the low slot (bit 0) and the high slot
 * (bit 1). Each is read once.
 */
#define KPROG_ARM64_PAIR_LOAD_TAG_ROUTE_LOW(MASK) (((MASK) & 1U) != 0U)
#define KPROG_ARM64_PAIR_LOAD_TAG_ROUTE_HIGH(MASK) (((MASK) & 2U) != 0U)
#endif
