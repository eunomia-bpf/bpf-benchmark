/* Canonical simulator C; edit directly. Historical origin: generate_arm64_ccmp_decode_spec.py from arm64_ccmp_decode_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_CCMP_DECODE_H
#define KPROG_FORMAL_GENERATED_ARM64_CCMP_DECODE_H

/*
 * The two CCMP fields of the shared packed AUX word, as plain masked shifts
 * so both are usable from a `_Static_assert`: lane 0
 * (bits 0 to 7) is the condition byte whose low four
 * bits select `ARM64_COND_*`, lane 8
 * (bits 8 to 15) is the fallback NZCV immediate. The
 * lane offsets are re-read from `arm64_aux_spec.json` and the condition
 * count from `arm64_cond_spec.json`, so neither can drift from the kernels
 * they cite.
 */
#define KPROG_ARM64_CCMP_CONDITION_COUNT 15U
#define KPROG_ARM64_CCMP_COND(AUX) ((__u8)(((AUX) >> 0) & 0xffU))
#define KPROG_ARM64_CCMP_NZCV(AUX) ((__u8)(((AUX) >> 8) & 0xffU))

/* A packed CCMP operand roundtrips: packing a `0`-shifted byte and
 * a `8`-shifted byte and decoding both lanes back re-derives them
 * exactly, at every byte value including the `ARM64_REG_NONE` sentinel, so
 * the condition byte cannot lean into the NZCV byte or vice versa. */
_Static_assert(KPROG_ARM64_CCMP_NZCV(ARM64_AUX_CCMP(
	KPROG_ARM64_CCMP_COND(ARM64_AUX_CCMP(0x55U, 0x96U)), 0xa7U)) == 0xa7U,
	       "AArch64 CCMP decode NZCV packer roundtrip drift");
_Static_assert(KPROG_ARM64_CCMP_COND(ARM64_AUX_CCMP(
	KPROG_ARM64_CCMP_COND(ARM64_AUX_CCMP(0x55U, 0x96U)), 0xa7U))
	== 0x55U,
	       "AArch64 CCMP decode condition packer roundtrip drift");

#endif
