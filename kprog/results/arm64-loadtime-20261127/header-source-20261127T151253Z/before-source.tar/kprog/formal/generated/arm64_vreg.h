/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_VREG_H
#define KPROG_FORMAL_GENERATED_ARM64_VREG_H
/*
 * AArch64 vector-register-file half mapping. The 128-bit vector register is
 * split into two independent 64-bit state fields: the low half `__a64_v0`
 * at slot offset 0 and the high half `__a64_v0_hi` at slot offset 8. A `.D0`
 * transfer touches the low half only; a `.Q0` transfer touches the low half and
 * then the high half. The memory offset and the pre/post base adjustment stay in
 * their own proved contracts; this contract fixes which state field each half
 * maps into and in which order the halves are touched.
 */
_Static_assert(ARM64_OP_LOAD_D0 == 0x28U, "arm64 vreg loadD0 opcode drift");
_Static_assert(ARM64_OP_LOAD_Q0 == 0x2aU, "arm64 vreg loadQ0 opcode drift");
_Static_assert(ARM64_OP_STORE_D0 == 0x29U, "arm64 vreg storeD0 opcode drift");
_Static_assert(ARM64_OP_STORE_Q0 == 0x2bU, "arm64 vreg storeQ0 opcode drift");
#define KPROG_ARM64_VREG_HANDLED(OP)                                        \
	((OP) == ARM64_OP_LOAD_D0) ||                                  \
	((OP) == ARM64_OP_LOAD_Q0) ||                                  \
	((OP) == ARM64_OP_STORE_D0) ||                                 \
	((OP) == ARM64_OP_STORE_Q0)
_Static_assert(KPROG_ARM64_VREG_HANDLED(ARM64_OP_LOAD_D0), "arm64 vreg coverage drift");
_Static_assert(KPROG_ARM64_VREG_HANDLED(ARM64_OP_LOAD_Q0), "arm64 vreg coverage drift");
_Static_assert(KPROG_ARM64_VREG_HANDLED(ARM64_OP_STORE_D0), "arm64 vreg coverage drift");
_Static_assert(KPROG_ARM64_VREG_HANDLED(ARM64_OP_STORE_Q0), "arm64 vreg coverage drift");
/* The low and high half slot offsets, distinct 64-bit state fields. */
#define KPROG_ARM64_VREG_LOW_OFFSET 0U
#define KPROG_ARM64_VREG_HIGH_OFFSET 8U
_Static_assert(KPROG_ARM64_VREG_LOW_OFFSET != KPROG_ARM64_VREG_HIGH_OFFSET,
	       "arm64 vreg half offsets alias");
/* The two half selectors and the two access-direction codes. */
#define KPROG_ARM64_VREG_HALF_LOW 0U
#define KPROG_ARM64_VREG_HALF_HIGH 1U
#define KPROG_ARM64_VREG_ACCESS_LOAD 0U
#define KPROG_ARM64_VREG_ACCESS_STORE 1U
/* The slot offset of a half: low half at offset 0, high half at offset 8. */
#define KPROG_ARM64_VREG_HALF_OFFSET(HALF)                                  \
	((HALF) == KPROG_ARM64_VREG_HALF_HIGH ? KPROG_ARM64_VREG_HIGH_OFFSET \
					      : KPROG_ARM64_VREG_LOW_OFFSET)
/*
 * Access direction of each opcode: 0 loads into the vector register file, 1
 * stores from it.
 */
#define KPROG_ARM64_VREG_OP_LOAD_D0_ACCESS KPROG_ARM64_VREG_ACCESS_LOAD
#define KPROG_ARM64_VREG_OP_LOAD_Q0_ACCESS KPROG_ARM64_VREG_ACCESS_LOAD
#define KPROG_ARM64_VREG_OP_STORE_D0_ACCESS KPROG_ARM64_VREG_ACCESS_STORE
#define KPROG_ARM64_VREG_OP_STORE_Q0_ACCESS KPROG_ARM64_VREG_ACCESS_STORE
/*
 * Half count of each opcode: 1 touches the low half only (`.D0`), 2 touches the
 * low half then the high half (`.Q0`).
 */
#define KPROG_ARM64_VREG_OP_LOAD_D0_HALVES 1U
#define KPROG_ARM64_VREG_OP_LOAD_Q0_HALVES 2U
#define KPROG_ARM64_VREG_OP_STORE_D0_HALVES 1U
#define KPROG_ARM64_VREG_OP_STORE_Q0_HALVES 2U
/*
 * The arm index of each opcode in the four-way `OP == LOAD_D0 / LOAD_Q0 /
 * STORE_D0 / STORE_Q0` chain, decoded from the opcode code so the chain order is
 * a checked fact.
 */
#define KPROG_ARM64_VREG_OP_LOAD_D0_INDEX 0U
#define KPROG_ARM64_VREG_OP_LOAD_Q0_INDEX 1U
#define KPROG_ARM64_VREG_OP_STORE_D0_INDEX 2U
#define KPROG_ARM64_VREG_OP_STORE_Q0_INDEX 3U
#define KPROG_ARM64_VREG_INDEX_INTO(OUTPUT, OP) \
    do { \
        __u32 __kprog_a64_vreg_idx; \
        if ((OP) == ARM64_OP_LOAD_D0) \
            __kprog_a64_vreg_idx = 0U; \
        else if ((OP) == ARM64_OP_LOAD_Q0) \
            __kprog_a64_vreg_idx = 1U; \
        else if ((OP) == ARM64_OP_STORE_D0) \
            __kprog_a64_vreg_idx = 2U; \
        else \
            __kprog_a64_vreg_idx = 3U; \
        (OUTPUT) = __kprog_a64_vreg_idx; \
    } while (0)
#define KPROG_ARM64_VREG_INDEX(OP) \
    ({ __u32 __kprog_transfer_index; \
       KPROG_ARM64_VREG_INDEX_INTO(__kprog_transfer_index, (OP)); \
       __kprog_transfer_index; })

/*
 * The half plan of each opcode: `SELECT(N)` yields the half index touched at
 * plan position `N`, low half first. A `.D0` opcode ignores `N`.
 */
#define KPROG_ARM64_VREG_OP_LOAD_D0_SELECT(N) KPROG_ARM64_VREG_HALF_LOW
#define KPROG_ARM64_VREG_OP_LOAD_Q0_SELECT(N) ((N) == 0U ? KPROG_ARM64_VREG_HALF_LOW : KPROG_ARM64_VREG_HALF_HIGH)
#define KPROG_ARM64_VREG_OP_STORE_D0_SELECT(N) KPROG_ARM64_VREG_HALF_LOW
#define KPROG_ARM64_VREG_OP_STORE_Q0_SELECT(N) ((N) == 0U ? KPROG_ARM64_VREG_HALF_LOW : KPROG_ARM64_VREG_HALF_HIGH)
#endif
