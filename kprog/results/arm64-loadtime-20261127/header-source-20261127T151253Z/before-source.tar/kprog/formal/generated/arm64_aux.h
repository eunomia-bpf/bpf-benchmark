/* Canonical simulator C; edit directly. Historical origin: generate_arm64_aux_spec.py from arm64_aux_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_AUX_H
#define KPROG_FORMAL_GENERATED_ARM64_AUX_H
/*
 * Packed AArch64 simulator AUX word, four bytes little-endian, one shared
 * layout interpreted per opcode:
 *   bits  0-7  ALU opcode / memory index register (0xff == no
 *              index, ARM64_REG_NONE) / bitfield kind
 *   bits  8-15 source modifier / bitfield LSB / CCMP NZCV
 *   bits 16-23 shift amount / bitfield width / MOVK column
 *   bits 24-31 memory flags (ARM64_MEM_PRE / ARM64_MEM_POST)
 * Every argument is masked to its byte, so lane bytes never bleed into one
 * another; the decoders extract the same bytes back.
 */
#define KPROG_ARM64_AUX(B0, B1, B2, B3) \
	(((__u32)(B0) & 0xffU) | \
	 (((__u32)(B1) & 0xffU) << 8) | \
	 (((__u32)(B2) & 0xffU) << 16) | \
	 (((__u32)(B3) & 0xffU) << 24))
#define KPROG_ARM64_AUX_B0(AUX) ((__u8)((AUX) & 0xffU))
#define KPROG_ARM64_AUX_B1(AUX) ((__u8)(((AUX) >> 8) & 0xffU))
#define KPROG_ARM64_AUX_B2(AUX) ((__u8)(((AUX) >> 16) & 0xffU))
#define KPROG_ARM64_AUX_B3(AUX) ((__u8)(((AUX) >> 24) & 0xffU))
#define KPROG_ARM64_AUX_REG_NONE 0xffU
#endif
