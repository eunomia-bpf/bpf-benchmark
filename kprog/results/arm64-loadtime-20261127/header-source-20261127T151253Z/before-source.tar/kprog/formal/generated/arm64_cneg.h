/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_CNEG_H
#define KPROG_FORMAL_GENERATED_ARM64_CNEG_H
/*
 * The one arm is the AArch64 condition-gated negation (CNEG): on a taken
 * condition the source is negated, otherwise it passes through unchanged. The
 * result is masked to the destination width, exactly the narrowing the caller's
 * register write performs. The negation is inlined, so this header calls no
 * hand-written helper. An opcode outside the family reaches the caller-supplied
 * unsupported arm.
 */
#include "arm64_width.h"
_Static_assert(ARM64_OP_CNEG == 65U, "arm64 cneg code drift");
#define KPROG_ARM64_CNEG_HANDLED(OP)                                        \
	(((OP) == ARM64_OP_CNEG))
_Static_assert(KPROG_ARM64_CNEG_HANDLED(ARM64_OP_CNEG), "arm64 cneg coverage drift");
/*
 * The numeric case label 65U tracks the ARM64_OP_CNEG value defined in
 * kprog/arm64/arm64_sim.h. OP is the opcode, VALUE the source register
 * contents, TAKEN the already evaluated condition result and WIDTH the
 * destination width code. VALUE and TAKEN are each evaluated exactly once and
 * no arm writes NZCV. The result is the width-narrowed raw 64-bit value the
 * caller writes back.
 */
#define KPROG_ARM64_CNEG_VALUE_INTO(OUTPUT, OP, VALUE, TAKEN, WIDTH, UNSUPPORTED) \
	do { \
		__u64 __kprog_a64_cneg_op = (OP); \
		__u64 __kprog_a64_cneg_value = (VALUE); \
		int __kprog_a64_cneg_taken = (TAKEN) ? 1 : 0; \
		__u64 __kprog_a64_cneg_width = (WIDTH); \
		__u64 __kprog_a64_cneg_wmask = KPROG_ARM64_WIDTH_MASK(__kprog_a64_cneg_width); \
		__u64 __kprog_a64_cneg_result = 0; \
 \
		switch (__kprog_a64_cneg_op) { \
		case 65U:                           \
			__kprog_a64_cneg_result = (__kprog_a64_cneg_taken ? (__u64)(0ULL - __kprog_a64_cneg_value) : __kprog_a64_cneg_value) & __kprog_a64_cneg_wmask; \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		(OUTPUT) = __kprog_a64_cneg_result; \
	} while (0)

#define KPROG_ARM64_CNEG_VALUE(OP, VALUE, TAKEN, WIDTH, UNSUPPORTED) \
	({ __u64 __kprog_a64_cneg_result_out; \
	   KPROG_ARM64_CNEG_VALUE_INTO(__kprog_a64_cneg_result_out, OP, VALUE, TAKEN, WIDTH, UNSUPPORTED); \
	   __kprog_a64_cneg_result_out; })
#endif
