/* Canonical simulator C; edit directly. Historical origin: generate_arm64_dq_mem_extra_spec.py from arm64_dq_mem_extra_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_DQ_MEM_EXTRA_H
#define KPROG_FORMAL_GENERATED_ARM64_DQ_MEM_EXTRA_H
/*
 * AArch64 vector lane extra-offset contract: the vector memory step
 * `ARM64_SIM_L_DQ_MEM_STEP` moves the SIMD register's halves to or from memory
 * one lane at a time, and each moved lane's byte offset is selected from a
 * closed pair of facts: whether the lane is the first plan position and whether
 * the transfer has a high lane at all. The first-lane offset is zero, the
 * high-lane offset is one 64-bit lane stride above the low lane for the second
 * position of a `.Q0` transfer, and the single-lane offset is zero for the
 * second fact of a one-position transfer. `KProgFormal/Arm64DqMemExtraShape.lean`
 * proves the generated `extraOffsetOf` equal to an independent 3-way statement
 * and ties the high-lane offset to the DQ lane stride
 * (`KPROG_ARM64_DQ_MEM_HIGH_LANE_STRIDE` / `GeneratedArm64DqMem.transfer`) and
 * the half plan (`GeneratedArm64Vreg.plan` / `halfOffset`). The two facts are a
 * closed pair, so the 3-way selection is total. This header uses only literal
 * inputs, so it is included after the `ARM64_DQ_MEM` lane stride defines and
 * before the `ARM64_WIDTH_*` decodes and the `ARM64_SIM_TAG_*` tag names in the
 * simulator header.
 */
/* The number of per-lane extra offsets the step selects between. */
#define KPROG_ARM64_DQ_MEM_EXTRA_COUNT 3U
/* The per-lane extra offset of each outcome. */
#define KPROG_ARM64_DQ_MEM_EXTRA_FIRST_LANE_BYTES 0U
#define KPROG_ARM64_DQ_MEM_EXTRA_HIGH_LANE_BYTES 1U
#define KPROG_ARM64_DQ_MEM_EXTRA_SINGLE_LANE_BYTES 2U
/* The byte offset of each outcome. */
#define KPROG_ARM64_DQ_MEM_EXTRA_FIRST_LANE_BYTES_OFFSET 0U
#define KPROG_ARM64_DQ_MEM_EXTRA_HIGH_LANE_BYTES_OFFSET 8U
#define KPROG_ARM64_DQ_MEM_EXTRA_SINGLE_LANE_BYTES_OFFSET 0U
/*
 * The per-lane extra offset a vector memory step selects: the first-lane offset
 * exactly when the lane is the first plan position, the high-lane offset at
 * every later position of a transfer that has a high lane, and the single-lane
 * offset when the transfer has only one position. Both inputs are evaluated
 * once and no NZCV is written.
 */
#define KPROG_ARM64_DQ_MEM_EXTRA(IS_FIRST_LANE, HAS_HIGH_LANE)             \
	((__s64)(((IS_FIRST_LANE))                       \
		 ? KPROG_ARM64_DQ_MEM_EXTRA_FIRST_LANE_BYTES_OFFSET                    \
		 : (((HAS_HIGH_LANE))                    \
		 ? KPROG_ARM64_DQ_MEM_EXTRA_HIGH_LANE_BYTES_OFFSET                     \
		 : KPROG_ARM64_DQ_MEM_EXTRA_SINGLE_LANE_BYTES_OFFSET)))
_Static_assert(KPROG_ARM64_DQ_MEM_EXTRA_COUNT == 3U,
	       "arm64 dq mem extra count drift");
_Static_assert(KPROG_ARM64_DQ_MEM_EXTRA_FIRST_LANE_BYTES != KPROG_ARM64_DQ_MEM_EXTRA_HIGH_LANE_BYTES,
	       "arm64 dq mem extra codes must be distinct");
_Static_assert(KPROG_ARM64_DQ_MEM_EXTRA_FIRST_LANE_BYTES != KPROG_ARM64_DQ_MEM_EXTRA_SINGLE_LANE_BYTES,
	       "arm64 dq mem extra codes must be distinct");
_Static_assert(KPROG_ARM64_DQ_MEM_EXTRA_HIGH_LANE_BYTES != KPROG_ARM64_DQ_MEM_EXTRA_SINGLE_LANE_BYTES,
	       "arm64 dq mem extra codes must be distinct");
_Static_assert(KPROG_ARM64_DQ_MEM_EXTRA_FIRST_LANE_BYTES == 0U && KPROG_ARM64_DQ_MEM_EXTRA_HIGH_LANE_BYTES == 1U && KPROG_ARM64_DQ_MEM_EXTRA_SINGLE_LANE_BYTES == 2U,
	       "arm64 dq mem extra code drift");
/* The offset of the high lane is the DQ lane stride; the first and
 * single-position offsets are the base offset. */
_Static_assert(KPROG_ARM64_DQ_MEM_EXTRA_HIGH_LANE_BYTES_OFFSET == KPROG_ARM64_DQ_MEM_HIGH_LANE_STRIDE,
	       "arm64 dq mem extra high lane offset drift");
_Static_assert(KPROG_ARM64_DQ_MEM_EXTRA_FIRST_LANE_BYTES_OFFSET == 0U && KPROG_ARM64_DQ_MEM_EXTRA_SINGLE_LANE_BYTES_OFFSET == 0U,
	       "arm64 dq mem extra base offset drift");
/* The selector must name each offset at its own fact pair. */
_Static_assert(KPROG_ARM64_DQ_MEM_EXTRA(1, 1) == KPROG_ARM64_DQ_MEM_EXTRA_FIRST_LANE_BYTES_OFFSET,
	       "arm64 dq mem extra first lane selection drift");
_Static_assert(KPROG_ARM64_DQ_MEM_EXTRA(1, 0) == KPROG_ARM64_DQ_MEM_EXTRA_FIRST_LANE_BYTES_OFFSET,
	       "arm64 dq mem extra first lane single selection drift");
_Static_assert(KPROG_ARM64_DQ_MEM_EXTRA(0, 1) == KPROG_ARM64_DQ_MEM_EXTRA_HIGH_LANE_BYTES_OFFSET,
	       "arm64 dq mem extra high lane selection drift");
_Static_assert(KPROG_ARM64_DQ_MEM_EXTRA(0, 0) == KPROG_ARM64_DQ_MEM_EXTRA_SINGLE_LANE_BYTES_OFFSET,
	       "arm64 dq mem extra single lane selection drift");
#endif
