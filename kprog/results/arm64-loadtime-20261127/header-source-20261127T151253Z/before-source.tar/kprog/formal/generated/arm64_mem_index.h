/* Canonical simulator C; edit directly. Historical origin: generate_arm64_mem_index_spec.py from arm64_mem_index_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_MEM_INDEX_H
#define KPROG_FORMAL_GENERATED_ARM64_MEM_INDEX_H
/*
 * AArch64 memory-index presence: the `AUX` index lane names an index register,
 * or the sentinel byte (`0xff`, `ARM64_REG_NONE`) when the addressing mode
 * carries none. `KProgFormal/Arm64MemIndex.lean` proves the presence test equals
 * an independent `decide (indexByte != 0xff)`.
 */
/* The two index arms. */
#define KPROG_ARM64_MEM_INDEX_ARM_PRESENT 0U
#define KPROG_ARM64_MEM_INDEX_ARM_ABSENT 1U
/* The all-ones byte that means "no index register". */
#define KPROG_ARM64_MEM_INDEX_SENTINEL 0xffU
/*
 * INDEX_BYTE is the `AUX` word's index lane (lane 0, the ALU opcode byte). It
 * is evaluated once; the result is 1 exactly when the byte names an index
 * register. No flags written.
 */
#define KPROG_ARM64_MEM_INDEX_PRESENT(INDEX_BYTE)                           \
	((__u8)(((INDEX_BYTE) != KPROG_ARM64_MEM_INDEX_SENTINEL) ? 1 : 0))
/*
 * The arm INDEX_BYTE selects: the present arm when it names an index register,
 * the absent arm at the sentinel. Evaluated once; no flags written.
 */
#define KPROG_ARM64_MEM_INDEX_ARM(INDEX_BYTE)                               \
	((__u8)(((INDEX_BYTE) != KPROG_ARM64_MEM_INDEX_SENTINEL)             \
		 ? KPROG_ARM64_MEM_INDEX_ARM_PRESENT                       \
		 : KPROG_ARM64_MEM_INDEX_ARM_ABSENT))
#endif
