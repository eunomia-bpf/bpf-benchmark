/* Canonical simulator C; edit directly. Historical origin: generate_arm64_stack_read_tag_source_spec.py from arm64_stack_read_tag_source_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_STACK_READ_TAG_SOURCE_H
#define KPROG_FORMAL_GENERATED_ARM64_STACK_READ_TAG_SOURCE_H
/*
 * AArch64 stack slot-tag read source contract: the stack tag read helper
 * `ARM64_SIM_L_STACK_READ_TAG` returns the tag of a stack slot read, and its
 * source is selected from a closed pair of facts: whether the read width is 64
 * bits and whether the stack slot is 8-aligned. The stack-tag-array source
 * (a 64-bit read at a qword-aligned slot) reads the slot's word in the
 * per-slot tag array; the scalar default source (every other fact pair)
 * returns the scalar marker with the byte image read untagged.
 * `KProgFormal/Arm64StackReadTagSourceShape.lean` proves the generated
 * `sourceOf` equal to an independent 2-way statement and ties the
 * stack-tag-array source to the read-side `KPROG_ARM64_STACK_TAG` slot-tag
 * predicate and to the 0137 write helper's word-and-tag action on the same
 * fact pair. The two facts are a closed pair, so the 2-way selection is total.
 * This header uses only literal inputs, so it is included before the
 * `ARM64_WIDTH_*` decodes and the `ARM64_SIM_TAG_*` tag names in the
 * simulator header.
 */
/* The number of tag sources the helper selects between. */
#define KPROG_ARM64_STACK_READ_TAG_SOURCE_COUNT 2U
#define KPROG_ARM64_STACK_READ_TAG_SOURCE_STACK_TAG_ARRAY 0U
#define KPROG_ARM64_STACK_READ_TAG_SOURCE_SCALAR_DEFAULT 1U
/*
 * The tag source a stack tag read selects: the stack-tag-array source exactly
 * when the read is 64-bit and the slot is 8-aligned, the scalar default
 * otherwise. Both inputs are evaluated once and no NZCV is written.
 */
#define KPROG_ARM64_STACK_READ_TAG_SOURCE(IS_W64, IS_ALIGNED)           \
	((__u8)(((IS_W64) && (IS_ALIGNED))                        \
		 ? KPROG_ARM64_STACK_READ_TAG_SOURCE_STACK_TAG_ARRAY                              \
		 : KPROG_ARM64_STACK_READ_TAG_SOURCE_SCALAR_DEFAULT))
_Static_assert(KPROG_ARM64_STACK_READ_TAG_SOURCE_COUNT == 2U,
	       "arm64 stack read tag source count drift");
_Static_assert(KPROG_ARM64_STACK_READ_TAG_SOURCE_STACK_TAG_ARRAY != KPROG_ARM64_STACK_READ_TAG_SOURCE_SCALAR_DEFAULT,
	       "arm64 stack read tag source codes must be distinct");
_Static_assert(KPROG_ARM64_STACK_READ_TAG_SOURCE_STACK_TAG_ARRAY == 0U && KPROG_ARM64_STACK_READ_TAG_SOURCE_SCALAR_DEFAULT == 1U,
	       "arm64 stack read tag source code drift");
/* The selector must name each source at its own fact pair. */
_Static_assert(KPROG_ARM64_STACK_READ_TAG_SOURCE(1, 1) == KPROG_ARM64_STACK_READ_TAG_SOURCE_STACK_TAG_ARRAY,
	       "arm64 stack read tag source w64 aligned selection drift");
_Static_assert(KPROG_ARM64_STACK_READ_TAG_SOURCE(1, 0) == KPROG_ARM64_STACK_READ_TAG_SOURCE_SCALAR_DEFAULT,
	       "arm64 stack read tag source w64 unaligned selection drift");
_Static_assert(KPROG_ARM64_STACK_READ_TAG_SOURCE(0, 1) == KPROG_ARM64_STACK_READ_TAG_SOURCE_SCALAR_DEFAULT,
	       "arm64 stack read tag source aligned scalar selection drift");
_Static_assert(KPROG_ARM64_STACK_READ_TAG_SOURCE(0, 0) == KPROG_ARM64_STACK_READ_TAG_SOURCE_SCALAR_DEFAULT,
	       "arm64 stack read tag source unaligned scalar selection drift");
#endif
