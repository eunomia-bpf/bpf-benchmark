/* Canonical simulator C. Edit directly; export the Lean AST with clightgen. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_BRANCH_H
#define KPROG_FORMAL_GENERATED_ARM64_BRANCH_H
/*
 * The four arms are the AArch64 compare-and-branch predicates CBZ/CBNZ (whole
 * value against zero) and TBZ/TBNZ (one bit against zero/one). The kind set is
 * closed, so the macro is total and takes no unsupported arm.
 */
#define KPROG_ARM64_BRANCH_CBZ 0U
#define KPROG_ARM64_BRANCH_CBNZ 1U
#define KPROG_ARM64_BRANCH_TBZ 2U
#define KPROG_ARM64_BRANCH_TBNZ 3U
_Static_assert(KPROG_ARM64_BRANCH_CBZ == 0U, "arm64 branch code drift");
_Static_assert(KPROG_ARM64_BRANCH_CBNZ == 1U, "arm64 branch code drift");
_Static_assert(KPROG_ARM64_BRANCH_TBZ == 2U, "arm64 branch code drift");
_Static_assert(KPROG_ARM64_BRANCH_TBNZ == 3U, "arm64 branch code drift");
#define KPROG_ARM64_BRANCH_HANDLED(KIND)                                    \
	(((KIND) == KPROG_ARM64_BRANCH_CBZ) || \
	((KIND) == KPROG_ARM64_BRANCH_CBNZ) || \
	((KIND) == KPROG_ARM64_BRANCH_TBZ) || \
	((KIND) == KPROG_ARM64_BRANCH_TBNZ))
_Static_assert(KPROG_ARM64_BRANCH_HANDLED(KPROG_ARM64_BRANCH_CBZ), "arm64 branch coverage drift");
_Static_assert(KPROG_ARM64_BRANCH_HANDLED(KPROG_ARM64_BRANCH_CBNZ), "arm64 branch coverage drift");
_Static_assert(KPROG_ARM64_BRANCH_HANDLED(KPROG_ARM64_BRANCH_TBZ), "arm64 branch coverage drift");
_Static_assert(KPROG_ARM64_BRANCH_HANDLED(KPROG_ARM64_BRANCH_TBNZ), "arm64 branch coverage drift");
/*
 * The numeric case labels 0U..3U are the contiguous predicate kinds above. This
 * header intentionally does not include arm64_sim.h, so it stays usable
 * standalone. KIND, VALUE and BIT are each evaluated exactly once. BIT is masked
 * to the 64-bit register domain, matching the architecture. The result is a C
 * int (1 = branch taken).
 */
#define KPROG_ARM64_BRANCH_TEST_DECL(NAME, KIND, VALUE, BIT)                           \
		__u64 __kprog_a64_br_kind = (KIND); \
		__u64 __kprog_a64_br_value = (VALUE); \
		__u64 __kprog_a64_br_bit = (BIT) & 63ULL; \
		int NAME = 0; \
 \
		switch (__kprog_a64_br_kind) { \
		case 0U:                           \
			NAME = (__kprog_a64_br_value == 0); \
			break; \
		case 1U:                           \
			NAME = (__kprog_a64_br_value != 0); \
			break; \
		case 2U:                           \
			NAME = (((__kprog_a64_br_value >> __kprog_a64_br_bit) & 1ULL) == 0); \
			break; \
		case 3U:                           \
			NAME = (((__kprog_a64_br_value >> __kprog_a64_br_bit) & 1ULL) != 0); \
			break; \
		}
#define KPROG_ARM64_BRANCH_TEST_INTO(OUTPUT, KIND, VALUE, BIT) \
    do { KPROG_ARM64_BRANCH_TEST_DECL(__kprog_a64_br_taken, KIND, VALUE, BIT); \
         (OUTPUT)=__kprog_a64_br_taken; } while (0)
#define KPROG_ARM64_BRANCH_TEST(KIND, VALUE, BIT) \
    ({ KPROG_ARM64_BRANCH_TEST_DECL(__kprog_a64_br_taken, KIND, VALUE, BIT); \
       __kprog_a64_br_taken; })
#endif
