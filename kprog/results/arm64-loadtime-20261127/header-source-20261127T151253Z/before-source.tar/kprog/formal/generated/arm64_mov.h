/* Canonical simulator C. Edit directly; export the Lean AST with clightgen. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_MOV_H
#define KPROG_FORMAL_GENERATED_ARM64_MOV_H
/*
 * The routing decision shared by the two AArch64 move opcodes: whether the
 * destination is written by the tag-copy register write (which carries the
 * source register's provenance) or by a width-narrowed scalar write (which drops
 * it). Only the register-source move at doubleword width preserves provenance.
 * An opcode outside the family reaches the caller-supplied unsupported arm.
 */
#include "arm64_width.h"
_Static_assert(ARM64_OP_MOV_IMM == 1U, "arm64 mov code drift");
_Static_assert(ARM64_OP_MOV_REG == 2U, "arm64 mov code drift");
#define KPROG_ARM64_MOV_HANDLED(OP)                                         \
	(((OP) == ARM64_OP_MOV_IMM) || \
	((OP) == ARM64_OP_MOV_REG))
_Static_assert(KPROG_ARM64_MOV_HANDLED(ARM64_OP_MOV_IMM), "arm64 mov coverage drift");
_Static_assert(KPROG_ARM64_MOV_HANDLED(ARM64_OP_MOV_REG), "arm64 mov coverage drift");
/*
 * The numeric case labels 1U and 2U track the ARM64_OP_MOV_IMM and
 * ARM64_OP_MOV_REG values defined in kprog/arm64/arm64_sim.h. OP is the
 * opcode and WIDTH the access width code; OP and WIDTH are each read once. The
 * result is 1 when the destination must be written through
 * ARM64_SIM_L_WRITE_REG_PTR_TAG (copying ARM64_SIM_L_REG_TAG(SRC)) and 0 when it
 * must be written through ARM64_SIM_L_WRITE_REG_WIDTH (dropping the tag).
 */
#define KPROG_ARM64_MOV_PTR_TAG_PATH_DECL(NAME, OP, WIDTH, UNSUPPORTED) \
		__u64 __kprog_a64_mov_op = (OP); \
		__u64 __kprog_a64_mov_width = (WIDTH); \
		__u64 NAME = 0; \
 \
		switch (__kprog_a64_mov_op) { \
		case 1U: \
			break; \
		case 2U: \
			NAME = (__kprog_a64_mov_width == ARM64_WIDTH_64); \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		}
#define KPROG_ARM64_MOV_PTR_TAG_PATH_INTO(OUTPUT, OP, WIDTH, UNSUPPORTED) \
    do { KPROG_ARM64_MOV_PTR_TAG_PATH_DECL(__kprog_a64_mov_path, OP, WIDTH, UNSUPPORTED); \
         (OUTPUT)=__kprog_a64_mov_path; } while (0)
#define KPROG_ARM64_MOV_PTR_TAG_PATH(OP, WIDTH, UNSUPPORTED) \
    ({ KPROG_ARM64_MOV_PTR_TAG_PATH_DECL(__kprog_a64_mov_path, OP, WIDTH, UNSUPPORTED); \
       __kprog_a64_mov_path; })
#endif
