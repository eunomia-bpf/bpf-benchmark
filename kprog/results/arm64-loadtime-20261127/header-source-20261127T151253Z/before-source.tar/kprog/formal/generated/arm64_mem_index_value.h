/* Canonical simulator C; edit directly. Historical origin: generate_arm64_mem_index_value_spec.py from arm64_mem_index_value_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_MEM_INDEX_VALUE_H
#define KPROG_FORMAL_GENERATED_ARM64_MEM_INDEX_VALUE_H
/*
 * AArch64 memory index-value source contract: the memory address offset
 * (`ARM64_SIM_L_MEM_BASE_OFF`) adds the source-modified index register value
 * to the immediate exactly when the addressing mode carries an index register,
 * and its source is selected from the single closed fact: whether the
 * addressing mode carries an index register. The source-modified index
 * register value source (an addressing mode that names an index register) is
 * the index register's value after the addressing mode's source modifier and
 * shift; the zero source (the sentinel index operand) is a literal zero, so
 * the offset carries no index contribution. `KProgFormal/
 * Arm64MemIndexValueShape.lean` proves the generated `sourceOf` equal to an
 * independent 2-way statement and ties the register source to the 0102
 * presence fact (`GeneratedArm64MemIndex.present`) and the zero source to the
 * offset the value feeds (`GeneratedArm64MemOffset.value`). The fact is
 * closed, so the 2-way selection is total. This header uses only literal
 * inputs, so it is included before the `ARM64_SIM_L_MEM_BASE_OFF` body.
 */
/* The number of index-value sources the offset selects between. */
#define KPROG_ARM64_MEM_INDEX_VALUE_COUNT 2U
#define KPROG_ARM64_MEM_INDEX_VALUE_REGISTER 0U
#define KPROG_ARM64_MEM_INDEX_VALUE_ZERO 1U
/*
 * The index-value source a memory address offset selects: the source-modified
 * index register value exactly when the addressing mode carries an index
 * register, a literal zero otherwise. The input is evaluated once and no NZCV
 * is written.
 */
#define KPROG_ARM64_MEM_INDEX_VALUE(HAS_INDEX)                  \
	((__u8)(((HAS_INDEX)) ? KPROG_ARM64_MEM_INDEX_VALUE_REGISTER : KPROG_ARM64_MEM_INDEX_VALUE_ZERO))
_Static_assert(KPROG_ARM64_MEM_INDEX_VALUE_COUNT == 2U,
	       "arm64 mem index value count drift");
_Static_assert(KPROG_ARM64_MEM_INDEX_VALUE_REGISTER != KPROG_ARM64_MEM_INDEX_VALUE_ZERO,
	       "arm64 mem index value codes must be distinct");
_Static_assert(KPROG_ARM64_MEM_INDEX_VALUE_REGISTER == 0U && KPROG_ARM64_MEM_INDEX_VALUE_ZERO == 1U,
	       "arm64 mem index value code drift");
/* The selector must name each source at its own fact. */
_Static_assert(KPROG_ARM64_MEM_INDEX_VALUE(1) == KPROG_ARM64_MEM_INDEX_VALUE_REGISTER,
	       "arm64 mem index value register selection drift");
_Static_assert(KPROG_ARM64_MEM_INDEX_VALUE(0) == KPROG_ARM64_MEM_INDEX_VALUE_ZERO,
	       "arm64 mem index value zero selection drift");
#endif
