/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_CSEL_H
#define KPROG_FORMAL_GENERATED_ARM64_CSEL_H
/*
 * The eight arms are the AArch64 conditional-select family (CSEL/CINC/CSET/
 * CSETM/CINV/CSINV/CSINC/CSNEG). Each selects one of the two candidate values
 * on the already evaluated condition result. Every opcode of the family has
 * exactly one arm; an opcode outside the family reaches the caller-supplied
 * unsupported arm. The family reads flags but writes none.
 */
_Static_assert(ARM64_OP_CSEL == 28U, "arm64 conditional-select code drift");
_Static_assert(ARM64_OP_CINC == 29U, "arm64 conditional-select code drift");
_Static_assert(ARM64_OP_CSET == 30U, "arm64 conditional-select code drift");
_Static_assert(ARM64_OP_CINV == 52U, "arm64 conditional-select code drift");
_Static_assert(ARM64_OP_CSINV == 61U, "arm64 conditional-select code drift");
_Static_assert(ARM64_OP_CSINC == 62U, "arm64 conditional-select code drift");
_Static_assert(ARM64_OP_CSETM == 68U, "arm64 conditional-select code drift");
_Static_assert(ARM64_OP_CSNEG == 69U, "arm64 conditional-select code drift");
#define KPROG_ARM64_CSEL_HANDLED(OP)                                        \
	(((OP) == ARM64_OP_CSEL) || \
	((OP) == ARM64_OP_CINC) || \
	((OP) == ARM64_OP_CSET) || \
	((OP) == ARM64_OP_CINV) || \
	((OP) == ARM64_OP_CSINV) || \
	((OP) == ARM64_OP_CSINC) || \
	((OP) == ARM64_OP_CSETM) || \
	((OP) == ARM64_OP_CSNEG))
_Static_assert(KPROG_ARM64_CSEL_HANDLED(ARM64_OP_CSEL), "arm64 conditional-select coverage drift");
_Static_assert(KPROG_ARM64_CSEL_HANDLED(ARM64_OP_CINC), "arm64 conditional-select coverage drift");
_Static_assert(KPROG_ARM64_CSEL_HANDLED(ARM64_OP_CSET), "arm64 conditional-select coverage drift");
_Static_assert(KPROG_ARM64_CSEL_HANDLED(ARM64_OP_CINV), "arm64 conditional-select coverage drift");
_Static_assert(KPROG_ARM64_CSEL_HANDLED(ARM64_OP_CSINV), "arm64 conditional-select coverage drift");
_Static_assert(KPROG_ARM64_CSEL_HANDLED(ARM64_OP_CSINC), "arm64 conditional-select coverage drift");
_Static_assert(KPROG_ARM64_CSEL_HANDLED(ARM64_OP_CSETM), "arm64 conditional-select coverage drift");
_Static_assert(KPROG_ARM64_CSEL_HANDLED(ARM64_OP_CSNEG), "arm64 conditional-select coverage drift");
/*
 * The numeric case labels 28U, 29U, 30U, 52U, 61U, 62U, 68U and 69U track the
 * ARM64_OP_CSEL/CINC/CSET/CINV/CSINV/CSINC/CSETM/CSNEG values defined in
 * kprog/arm64/arm64_sim.h; the family is not contiguous. This header
 * intentionally does not include arm64_sim.h, so it stays usable standalone;
 * load() re-checks the codes against arm64_sim.h and exits 1 if they drift.
 * SRC, SRC2 and TAKEN are each evaluated exactly once and no arm writes NZCV.
 * The result is the raw 64-bit value; the caller applies the destination width.
 */
#define KPROG_ARM64_CSEL_VALUE_INTO(OUTPUT, OP, SRC, SRC2, TAKEN, UNSUPPORTED) \
	do { \
		__u64 __kprog_a64_csel_op = (OP); \
		__u64 __kprog_a64_csel_src = (SRC); \
		__u64 __kprog_a64_csel_src2 = (SRC2); \
		int __kprog_a64_csel_taken = (TAKEN) ? 1 : 0; \
		__u64 __kprog_a64_csel_result = 0; \
 \
		switch (__kprog_a64_csel_op) { \
		case 28U:                           \
			__kprog_a64_csel_result = __kprog_a64_csel_taken \
				? __kprog_a64_csel_src \
				: __kprog_a64_csel_src2; \
			break; \
		case 29U:                           \
			__kprog_a64_csel_result = __kprog_a64_csel_taken \
				? __kprog_a64_csel_src + 1 \
				: __kprog_a64_csel_src; \
			break; \
		case 30U:                           \
			__kprog_a64_csel_result = __kprog_a64_csel_taken \
				? 1 \
				: 0; \
			break; \
		case 52U:                           \
			__kprog_a64_csel_result = __kprog_a64_csel_taken \
				? ~__kprog_a64_csel_src \
				: __kprog_a64_csel_src; \
			break; \
		case 61U:                           \
			__kprog_a64_csel_result = __kprog_a64_csel_taken \
				? __kprog_a64_csel_src \
				: ~__kprog_a64_csel_src2; \
			break; \
		case 62U:                           \
			__kprog_a64_csel_result = __kprog_a64_csel_taken \
				? __kprog_a64_csel_src \
				: __kprog_a64_csel_src2 + 1; \
			break; \
		case 68U:                           \
			__kprog_a64_csel_result = __kprog_a64_csel_taken \
				? ~0ULL \
				: 0; \
			break; \
		case 69U:                           \
			__kprog_a64_csel_result = __kprog_a64_csel_taken \
				? __kprog_a64_csel_src \
				: -__kprog_a64_csel_src2; \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		(OUTPUT) = __kprog_a64_csel_result; \
	} while (0)

#define KPROG_ARM64_CSEL_VALUE(OP, SRC, SRC2, TAKEN, UNSUPPORTED) \
	({ __u64 __kprog_a64_csel_result_out; \
	   KPROG_ARM64_CSEL_VALUE_INTO(__kprog_a64_csel_result_out, OP, SRC, SRC2, TAKEN, UNSUPPORTED); \
	   __kprog_a64_csel_result_out; })
#endif
