/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_IMM_OPERAND_H
#define KPROG_FORMAL_GENERATED_ARM64_IMM_OPERAND_H
/*
 * The operand-source selection shared by the two AArch64 handler arms that pick
 * between the decoded immediate and a register expression (the move and the
 * shift arm): the `_IMM` member of each pair selects the decoded immediate,
 * every other (register) opcode selects the caller-supplied register
 * expression. The register expression is the caller's, because the move reads
 * the source register while the shift reads the second source. A code outside
 * the two `_IMM` labels is not a selection and returns the register expression.
 */
_Static_assert(ARM64_OP_MOV_IMM == 1U, "arm64 imm operand code drift");
_Static_assert(ARM64_OP_MOV_REG == 2U, "arm64 imm operand code drift");
_Static_assert(ARM64_OP_SHIFT_IMM == 8U, "arm64 imm operand code drift");
_Static_assert(ARM64_OP_SHIFT_REG == 9U, "arm64 imm operand code drift");
/*
 * OP is the arm opcode, IMM the decoded immediate and REG the register-form
 * operand. OP, IMM and REG are each evaluated exactly once, so a register
 * expression with a side effect still runs at most once. The result is IMM
 * exactly when OP is one of the two immediate case labels, and REG otherwise.
 */
#define KPROG_ARM64_IMM_RHS_INTO(OUTPUT, OP, IMM, REG) \
	do { \
		__u64 __kprog_a64_io_operand = (REG); \
 \
		switch (OP) { \
		case 1U: \
			__kprog_a64_io_operand = (IMM); \
			break; \
		case 8U: \
			__kprog_a64_io_operand = (IMM); \
			break; \
		default: \
			break; \
		} \
		(OUTPUT) = __kprog_a64_io_operand; \
	} while (0)

#define KPROG_ARM64_IMM_RHS(OP, IMM, REG) \
	({ __u64 __kprog_a64_io_operand_out; \
	   KPROG_ARM64_IMM_RHS_INTO(__kprog_a64_io_operand_out, OP, IMM, REG); \
	   __kprog_a64_io_operand_out; })
#endif
