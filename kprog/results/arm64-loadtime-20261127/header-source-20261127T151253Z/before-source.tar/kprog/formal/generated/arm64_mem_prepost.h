/* Canonical simulator C; edit directly. Historical origin: generate_arm64_mem_prepost_spec.py from arm64_mem_prepost_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_MEM_PREPOST_H
#define KPROG_FORMAL_GENERATED_ARM64_MEM_PREPOST_H
/*
 * AArch64 pre/post-indexed address writeback. The packed memory-flag byte of an
 * `ARM64_AUX_MEM` operand is its top byte. A pre-indexed access (MEM_PRE) applies
 * the immediate before the access, a post-indexed access (MEM_POST) applies it
 * after, and an offset access contributes the immediate in the address offset.
 * MEM_PRE and MEM_POST are independent bits: MEM_PRE | MEM_POST set applies the
 * same immediate twice. Each macro reads the flag byte once; no NZCV is written.
 */
#define KPROG_ARM64_MEM_PRE_BIT 1U
#define KPROG_ARM64_MEM_POST_BIT 2U
#define KPROG_ARM64_MEM_FLAGS_SHIFT 24U
#define KPROG_ARM64_MEM_FLAGS_MASK 255U
_Static_assert(KPROG_ARM64_MEM_PRE_BIT == 1U,
	       "arm64 pre-bit drift");
_Static_assert(KPROG_ARM64_MEM_POST_BIT == 2U,
	       "arm64 post-bit drift");
/*
 * The flag byte of an `AUX` operand: the top byte, matching MEM_FLAGS.
 */
#define KPROG_ARM64_MEM_PREPOST_FLAGS(AUX)                             \
	((__u32)(((AUX) >> KPROG_ARM64_MEM_FLAGS_SHIFT) &                     \
		KPROG_ARM64_MEM_FLAGS_MASK))
/*
 * Whether the address offset suppresses the immediate: true for a pre- or
 * post-indexed access, which applies the immediate as its own writeback.
 */
#define KPROG_ARM64_MEM_PREPOST_SUPPRESS(AUX)                          \
	((KPROG_ARM64_MEM_PREPOST_FLAGS(AUX) & KPROG_ARM64_MEM_PRE_BIT) ||    \
	 (KPROG_ARM64_MEM_PREPOST_FLAGS(AUX) & KPROG_ARM64_MEM_POST_BIT))
/*
 * The immediate the pre-indexed writeback applies (or zero if absent) and the
 * one the post-indexed writeback applies (or zero if absent).
 */
#define KPROG_ARM64_MEM_PREPOST_PRE_DELTA(AUX, IMM)                    \
	((KPROG_ARM64_MEM_PREPOST_FLAGS(AUX) & KPROG_ARM64_MEM_PRE_BIT)       \
		 ? (IMM) : 0)
#define KPROG_ARM64_MEM_PREPOST_POST_DELTA(AUX, IMM)                   \
	((KPROG_ARM64_MEM_PREPOST_FLAGS(AUX) & KPROG_ARM64_MEM_POST_BIT)      \
		 ? (IMM) : 0)
#endif
