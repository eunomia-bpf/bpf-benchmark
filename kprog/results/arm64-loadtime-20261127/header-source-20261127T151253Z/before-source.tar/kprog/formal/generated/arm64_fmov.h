/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_FMOV_H
#define KPROG_FORMAL_GENERATED_ARM64_FMOV_H
/*
 * The four arms are the AArch64 FMOV directions between a general-purpose
 * register and the vector register `v0`. Every ARM64_FMOV_* code has exactly one
 * arm; a code outside the four reaches the caller-supplied unsupported arm.
 */
_Static_assert(ARM64_FMOV_D_FROM_X == 0U, "arm64 fmov code drift");
_Static_assert(ARM64_FMOV_X_FROM_D == 1U, "arm64 fmov code drift");
_Static_assert(ARM64_FMOV_S_FROM_W == 2U, "arm64 fmov code drift");
_Static_assert(ARM64_FMOV_W_FROM_S == 3U, "arm64 fmov code drift");
#define KPROG_ARM64_FMOV_HANDLED(DIR)                                       \
	(((DIR) == ARM64_FMOV_D_FROM_X) || \
	((DIR) == ARM64_FMOV_X_FROM_D) || \
	((DIR) == ARM64_FMOV_S_FROM_W) || \
	((DIR) == ARM64_FMOV_W_FROM_S))
_Static_assert(KPROG_ARM64_FMOV_HANDLED(ARM64_FMOV_D_FROM_X), "arm64 fmov coverage drift");
_Static_assert(KPROG_ARM64_FMOV_HANDLED(ARM64_FMOV_X_FROM_D), "arm64 fmov coverage drift");
_Static_assert(KPROG_ARM64_FMOV_HANDLED(ARM64_FMOV_S_FROM_W), "arm64 fmov coverage drift");
_Static_assert(KPROG_ARM64_FMOV_HANDLED(ARM64_FMOV_W_FROM_S), "arm64 fmov coverage drift");
/*
 * DIR is one of the four ARM64_FMOV_* codes; V0 is the current vector-register
 * value and SRC the general-purpose source register (read at the destination
 * width). V0 and SRC are each evaluated exactly once and no NZCV is written.
 * The result is either the new `v0` or the value to write into the destination
 * register, depending on the direction; the caller applies the width.
 */
#define KPROG_ARM64_FMOV_VALUE_INTO(OUTPUT, DIR, V0, SRC, UNSUPPORTED) \
	do { \
		__u64 __kprog_a64_fmov_dir = (DIR); \
		__u64 __kprog_a64_fmov_v0 = (V0); \
		__u64 __kprog_a64_fmov_src = (SRC); \
		__u64 __kprog_a64_fmov_result = 0; \
 \
		switch (__kprog_a64_fmov_dir) { \
		case 0U:                           \
			__kprog_a64_fmov_result = __kprog_a64_fmov_src; \
			break; \
		case 1U:                           \
			__kprog_a64_fmov_result = __kprog_a64_fmov_v0; \
			break; \
		case 2U:                           \
			__kprog_a64_fmov_result = __kprog_a64_fmov_src; \
			break; \
		case 3U:                           \
			__kprog_a64_fmov_result = __kprog_a64_fmov_v0; \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		(OUTPUT) = __kprog_a64_fmov_result; \
	} while (0)

#define KPROG_ARM64_FMOV_VALUE(DIR, V0, SRC, UNSUPPORTED) \
	({ __u64 __kprog_a64_fmov_result_out; \
	   KPROG_ARM64_FMOV_VALUE_INTO(__kprog_a64_fmov_result_out, DIR, V0, SRC, UNSUPPORTED); \
	   __kprog_a64_fmov_result_out; })
#endif
