/* Canonical simulator C; edit directly. Historical origin: generate_arm64_dispatch_singleton_spec.py from arm64_dispatch_singleton_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_DISPATCH_SINGLETON_H
#define KPROG_FORMAL_GENERATED_ARM64_DISPATCH_SINGLETON_H
/*
 * The sixteen AArch64 opcodes the `ARM64_SIM_L_EXEC` chain gates individually,
 * outside the immediate/register dispatch families: NOP, MOVK, BITFIELD,
 * CMN_IMM, CMN_REG, TST_BIC_REG, BICS_REG, LOAD, STORE, LDP, STP, LOAD_D0,
 * STORE_D0, LOAD_Q0, STORE_Q0 and FMOV. Each names its ARM64_OP_* opcode and
 * exposes a one-member membership macro, so a dispatch gate is the generated
 * contract rather than a hand-rolled raw comparison. A code outside every
 * singleton reaches the caller's unsupported arm.
 * This header is included after `arm64_sim.h`, so the opcode-number drift
 * checks bind the hand-written ARM64_OP_* decode to the generated singleton
 * set.
 */
_Static_assert(ARM64_OP_NOP == 0U, "arm64 dispatch singleton code drift");
_Static_assert(ARM64_OP_MOVK == 5U, "arm64 dispatch singleton code drift");
_Static_assert(ARM64_OP_BITFIELD == 18U, "arm64 dispatch singleton code drift");
_Static_assert(ARM64_OP_CMN_IMM == 51U, "arm64 dispatch singleton code drift");
_Static_assert(ARM64_OP_CMN_REG == 58U, "arm64 dispatch singleton code drift");
_Static_assert(ARM64_OP_TST_BIC_REG == 44U, "arm64 dispatch singleton code drift");
_Static_assert(ARM64_OP_BICS_REG == 67U, "arm64 dispatch singleton code drift");
_Static_assert(ARM64_OP_LOAD == 31U, "arm64 dispatch singleton code drift");
_Static_assert(ARM64_OP_STORE == 32U, "arm64 dispatch singleton code drift");
_Static_assert(ARM64_OP_LDP == 33U, "arm64 dispatch singleton code drift");
_Static_assert(ARM64_OP_STP == 34U, "arm64 dispatch singleton code drift");
_Static_assert(ARM64_OP_LOAD_D0 == 40U, "arm64 dispatch singleton code drift");
_Static_assert(ARM64_OP_STORE_D0 == 41U, "arm64 dispatch singleton code drift");
_Static_assert(ARM64_OP_LOAD_Q0 == 42U, "arm64 dispatch singleton code drift");
_Static_assert(ARM64_OP_STORE_Q0 == 43U, "arm64 dispatch singleton code drift");
_Static_assert(ARM64_OP_FMOV == 35U, "arm64 dispatch singleton code drift");
/* Each singleton's opcode, tested by the dispatcher. */
#define KPROG_ARM64_DISP_NOP_HANDLED(OP)                            \
	((OP) == ARM64_OP_NOP)
#define KPROG_ARM64_DISP_MOVK_HANDLED(OP)                           \
	((OP) == ARM64_OP_MOVK)
#define KPROG_ARM64_DISP_BITFIELD_HANDLED(OP)                       \
	((OP) == ARM64_OP_BITFIELD)
#define KPROG_ARM64_DISP_CMN_IMM_HANDLED(OP)                        \
	((OP) == ARM64_OP_CMN_IMM)
#define KPROG_ARM64_DISP_CMN_REG_HANDLED(OP)                        \
	((OP) == ARM64_OP_CMN_REG)
#define KPROG_ARM64_DISP_TST_BIC_REG_HANDLED(OP)                    \
	((OP) == ARM64_OP_TST_BIC_REG)
#define KPROG_ARM64_DISP_BICS_REG_HANDLED(OP)                       \
	((OP) == ARM64_OP_BICS_REG)
#define KPROG_ARM64_DISP_LOAD_HANDLED(OP)                           \
	((OP) == ARM64_OP_LOAD)
#define KPROG_ARM64_DISP_STORE_HANDLED(OP)                          \
	((OP) == ARM64_OP_STORE)
#define KPROG_ARM64_DISP_LDP_HANDLED(OP)                            \
	((OP) == ARM64_OP_LDP)
#define KPROG_ARM64_DISP_STP_HANDLED(OP)                            \
	((OP) == ARM64_OP_STP)
#define KPROG_ARM64_DISP_LOAD_D0_HANDLED(OP)                        \
	((OP) == ARM64_OP_LOAD_D0)
#define KPROG_ARM64_DISP_STORE_D0_HANDLED(OP)                       \
	((OP) == ARM64_OP_STORE_D0)
#define KPROG_ARM64_DISP_LOAD_Q0_HANDLED(OP)                        \
	((OP) == ARM64_OP_LOAD_Q0)
#define KPROG_ARM64_DISP_STORE_Q0_HANDLED(OP)                       \
	((OP) == ARM64_OP_STORE_Q0)
#define KPROG_ARM64_DISP_FMOV_HANDLED(OP)                           \
	((OP) == ARM64_OP_FMOV)
/* Every singleton must be named by its generated membership macro. */
_Static_assert(KPROG_ARM64_DISP_NOP_HANDLED(ARM64_OP_NOP), "arm64 dispatch singleton coverage drift");
_Static_assert(KPROG_ARM64_DISP_MOVK_HANDLED(ARM64_OP_MOVK), "arm64 dispatch singleton coverage drift");
_Static_assert(KPROG_ARM64_DISP_BITFIELD_HANDLED(ARM64_OP_BITFIELD), "arm64 dispatch singleton coverage drift");
_Static_assert(KPROG_ARM64_DISP_CMN_IMM_HANDLED(ARM64_OP_CMN_IMM), "arm64 dispatch singleton coverage drift");
_Static_assert(KPROG_ARM64_DISP_CMN_REG_HANDLED(ARM64_OP_CMN_REG), "arm64 dispatch singleton coverage drift");
_Static_assert(KPROG_ARM64_DISP_TST_BIC_REG_HANDLED(ARM64_OP_TST_BIC_REG), "arm64 dispatch singleton coverage drift");
_Static_assert(KPROG_ARM64_DISP_BICS_REG_HANDLED(ARM64_OP_BICS_REG), "arm64 dispatch singleton coverage drift");
_Static_assert(KPROG_ARM64_DISP_LOAD_HANDLED(ARM64_OP_LOAD), "arm64 dispatch singleton coverage drift");
_Static_assert(KPROG_ARM64_DISP_STORE_HANDLED(ARM64_OP_STORE), "arm64 dispatch singleton coverage drift");
_Static_assert(KPROG_ARM64_DISP_LDP_HANDLED(ARM64_OP_LDP), "arm64 dispatch singleton coverage drift");
_Static_assert(KPROG_ARM64_DISP_STP_HANDLED(ARM64_OP_STP), "arm64 dispatch singleton coverage drift");
_Static_assert(KPROG_ARM64_DISP_LOAD_D0_HANDLED(ARM64_OP_LOAD_D0), "arm64 dispatch singleton coverage drift");
_Static_assert(KPROG_ARM64_DISP_STORE_D0_HANDLED(ARM64_OP_STORE_D0), "arm64 dispatch singleton coverage drift");
_Static_assert(KPROG_ARM64_DISP_LOAD_Q0_HANDLED(ARM64_OP_LOAD_Q0), "arm64 dispatch singleton coverage drift");
_Static_assert(KPROG_ARM64_DISP_STORE_Q0_HANDLED(ARM64_OP_STORE_Q0), "arm64 dispatch singleton coverage drift");
_Static_assert(KPROG_ARM64_DISP_FMOV_HANDLED(ARM64_OP_FMOV), "arm64 dispatch singleton coverage drift");
#endif
