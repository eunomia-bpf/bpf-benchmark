/* Canonical simulator C; edit directly. Historical origin: generate_arm64_stack_write_lanes_spec.py from arm64_stack_write_lanes_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_STACK_WRITE_LANES_H
#define KPROG_FORMAL_GENERATED_ARM64_STACK_WRITE_LANES_H
/*
 * AArch64 stack byte-ladder per-lane activation contract: the stack write
 * helper `ARM64_SIM_L_STACK_WRITE_TAG` narrows a resolved access to the byte
 * arena `b[]` through a little-endian byte ladder. The width set is closed (the
 * four ARM64_WIDTH_* codes) and the activation is monotone: an access of `n`
 * bytes writes exactly the lanes `0..n-1`, so the width's active-lane mask has
 * its low `n` bits set (`1`, `3`, `15`, `255`). This is the counterpart of the
 * read-side body selection (`KPROG_ARM64_STACK_ARM`) and of the memory-side
 * ladder (`KPROG_ARM64_STORE_BYTES`).
 * `KProgFormal/Arm64StackWriteLanesShape.lean` proves the generated activation
 * equal to an independent construction from the literals, tied to the
 * `Arm64ByteLane` extraction, the `Arm64Width` codes and the store-bytes
 * contract.
 * This header is included after the `ARM64_WIDTH_*` decodes and the
 * `arm64_byte_lane.h` extraction, so the drift checks bind the hand-written
 * width codes to the generated activation table.
 */
/* The eight byte lanes of a 64-bit stack slot, in lane order. */
#define KPROG_ARM64_STACK_WRITE_LANE0 0U
#define KPROG_ARM64_STACK_WRITE_LANE1 1U
#define KPROG_ARM64_STACK_WRITE_LANE2 2U
#define KPROG_ARM64_STACK_WRITE_LANE3 3U
#define KPROG_ARM64_STACK_WRITE_LANE4 4U
#define KPROG_ARM64_STACK_WRITE_LANE5 5U
#define KPROG_ARM64_STACK_WRITE_LANE6 6U
#define KPROG_ARM64_STACK_WRITE_LANE7 7U
/* The number of byte lanes the helper can write. */
#define KPROG_ARM64_STACK_WRITE_LANE_SLOTS 8U
/* The width's active-lane mask: bit `k` set exactly when lane `k` is written. */
#define KPROG_ARM64_STACK_WRITE_MASK(WIDTH)                                 \
	((WIDTH) == ARM64_WIDTH_8 ? 0x01U : \
	((WIDTH) == ARM64_WIDTH_16 ? 0x03U : \
	((WIDTH) == ARM64_WIDTH_32 ? 0x0fU : \
	 0xffU)))
/* The number of byte lanes the width writes: the mask's set-bit count. */
#define KPROG_ARM64_STACK_WRITE_LANE_COUNT(WIDTH)                           \
	((WIDTH) == ARM64_WIDTH_8 ? 1U :                                  \
	 ((WIDTH) == ARM64_WIDTH_16 ? 2U :                                 \
	  ((WIDTH) == ARM64_WIDTH_32 ? 4U : 8U)))
/*
 * Whether a stack access of WIDTH writes LANE: bit LANE of the width's
 * active-lane mask. WIDTH must be a side-effect-free expression (the mask
 * compares it against each width code); LANE is read once and no NZCV is
 * written.
 */
#define KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(WIDTH, LANE)                    	((__u8)((KPROG_ARM64_STACK_WRITE_MASK(WIDTH) >> (LANE)) & 1U))
_Static_assert(ARM64_WIDTH_8 == 1U, "arm64 stack write lanes width code drift");
_Static_assert(ARM64_WIDTH_16 == 2U, "arm64 stack write lanes width code drift");
_Static_assert(ARM64_WIDTH_32 == 4U, "arm64 stack write lanes width code drift");
_Static_assert(ARM64_WIDTH_64 == 8U, "arm64 stack write lanes width code drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_SLOTS == 8U,
	       "arm64 stack write lanes slot count drift");
/* The mask must name each width's active-lane set and its size. */
_Static_assert(KPROG_ARM64_STACK_WRITE_MASK(ARM64_WIDTH_8) == 0x01U,
	       "arm64 stack write lanes mask drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_COUNT(ARM64_WIDTH_8) == 1U,
	       "arm64 stack write lanes count drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_MASK(ARM64_WIDTH_16) == 0x03U,
	       "arm64 stack write lanes mask drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_COUNT(ARM64_WIDTH_16) == 2U,
	       "arm64 stack write lanes count drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_MASK(ARM64_WIDTH_32) == 0x0fU,
	       "arm64 stack write lanes mask drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_COUNT(ARM64_WIDTH_32) == 4U,
	       "arm64 stack write lanes count drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_MASK(ARM64_WIDTH_64) == 0xffU,
	       "arm64 stack write lanes mask drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_COUNT(ARM64_WIDTH_64) == 8U,
	       "arm64 stack write lanes count drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_8, 0) == 1U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_8, 1) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_8, 2) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_8, 3) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_8, 4) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_8, 5) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_8, 6) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_8, 7) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_16, 0) == 1U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_16, 1) == 1U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_16, 2) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_16, 3) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_16, 4) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_16, 5) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_16, 6) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_16, 7) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_32, 0) == 1U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_32, 1) == 1U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_32, 2) == 1U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_32, 3) == 1U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_32, 4) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_32, 5) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_32, 6) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_32, 7) == 0U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_64, 0) == 1U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_64, 1) == 1U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_64, 2) == 1U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_64, 3) == 1U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_64, 4) == 1U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_64, 5) == 1U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_64, 6) == 1U,
	       "arm64 stack write lanes activation drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_LANE_ACTIVE(ARM64_WIDTH_64, 7) == 1U,
	       "arm64 stack write lanes activation drift");
#endif
