/* Canonical simulator C; edit directly. Historical origin: generate_arm64_width_spec.py from arm64_width_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_WIDTH_H
#define KPROG_FORMAL_GENERATED_ARM64_WIDTH_H
_Static_assert(ARM64_WIDTH_8 == 1U, "arm64 width code drift");
_Static_assert(ARM64_WIDTH_16 == 2U, "arm64 width code drift");
_Static_assert(ARM64_WIDTH_32 == 4U, "arm64 width code drift");
_Static_assert(ARM64_WIDTH_64 == 8U, "arm64 width code drift");
#define KPROG_ARM64_WIDTH_MASK(WIDTH)                                       \
	((WIDTH) == ARM64_WIDTH_8 ? 0xffULL : \
	((WIDTH) == ARM64_WIDTH_16 ? 0xffffULL : \
	((WIDTH) == ARM64_WIDTH_32 ? 0xffffffffULL : \
	 0xffffffffffffffffULL)))
#define KPROG_ARM64_WIDTH_SIGN_MASK(WIDTH)                                  \
	((WIDTH) == ARM64_WIDTH_8 ? 0x80ULL : \
	((WIDTH) == ARM64_WIDTH_16 ? 0x8000ULL : \
	((WIDTH) == ARM64_WIDTH_32 ? 0x80000000ULL : \
	 0x8000000000000000ULL)))
#define KPROG_ARM64_WIDTH_BITS(WIDTH)                                       \
	((WIDTH) == ARM64_WIDTH_8 ? 8U : \
	((WIDTH) == ARM64_WIDTH_16 ? 16U : \
	((WIDTH) == ARM64_WIDTH_32 ? 32U : \
	 64U)))
#define KPROG_ARM64_APPLY_WIDTH(VALUE, WIDTH) ((VALUE) & KPROG_ARM64_WIDTH_MASK(WIDTH))
/* The decoded width code that means "absent": a body that leaves its width
 * field empty falls back to the default code. */
#define KPROG_ARM64_WIDTH_ABSENT_CODE 0U
#define KPROG_ARM64_WIDTH_EFFECTIVE_DEFAULT ARM64_WIDTH_64
/* Resolve a decoded width code to the code a body operates at: the absent code
 * (0) falls back to the 64-bit default, every other code is used as
 * decoded. The operand is evaluated as the body evaluates it. */
#define KPROG_ARM64_WIDTH_EFFECTIVE(CODE)                                   \
	((CODE) != KPROG_ARM64_WIDTH_ABSENT_CODE ? (CODE) :                     \
	 KPROG_ARM64_WIDTH_EFFECTIVE_DEFAULT)
#endif
