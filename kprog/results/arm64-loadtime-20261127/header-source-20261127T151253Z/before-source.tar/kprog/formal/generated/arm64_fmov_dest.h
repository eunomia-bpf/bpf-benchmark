/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_FMOV_DEST_H
#define KPROG_FORMAL_GENERATED_ARM64_FMOV_DEST_H
/*
 * The destination-routing decision of the AArch64 FMOV: whether the moved value
 * is written to the vector register `v0` or to the general-purpose destination
 * register through the width-narrowed register write. A direction code outside
 * the four reaches the caller-supplied unsupported arm.
 */
_Static_assert(ARM64_OP_FMOV == 35U, "arm64 fmov-dest opcode drift");
_Static_assert(ARM64_FMOV_D_FROM_X == 0U, "arm64 fmov-dest code drift");
_Static_assert(ARM64_FMOV_X_FROM_D == 1U, "arm64 fmov-dest code drift");
_Static_assert(ARM64_FMOV_S_FROM_W == 2U, "arm64 fmov-dest code drift");
_Static_assert(ARM64_FMOV_W_FROM_S == 3U, "arm64 fmov-dest code drift");
/*
 * DIR is one of the four ARM64_FMOV_* direction codes; DIR is read once. The
 * result is 1 when the handler must assign the result to `v0` and 0 when it must
 * write the general-purpose destination through the width-narrowed register
 * write.
 */
#define KPROG_ARM64_FMOV_DEST_VECTOR_INTO(OUTPUT, DIR, UNSUPPORTED) \
	do { \
		__u64 __kprog_a64_fmd_dir = (DIR); \
		__u64 __kprog_a64_fmd_v0 = 0; \
 \
		switch (__kprog_a64_fmd_dir) { \
		case 0U: \
			__kprog_a64_fmd_v0 = 1U; \
			break; \
		case 1U: \
			__kprog_a64_fmd_v0 = 0U; \
			break; \
		case 2U: \
			__kprog_a64_fmd_v0 = 1U; \
			break; \
		case 3U: \
			__kprog_a64_fmd_v0 = 0U; \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		(OUTPUT) = __kprog_a64_fmd_v0; \
	} while (0)

#define KPROG_ARM64_FMOV_DEST_VECTOR(DIR, UNSUPPORTED) \
	({ __u64 __kprog_a64_fmd_v0_out; \
	   KPROG_ARM64_FMOV_DEST_VECTOR_INTO(__kprog_a64_fmd_v0_out, DIR, UNSUPPORTED); \
	   __kprog_a64_fmd_v0_out; })
#endif
