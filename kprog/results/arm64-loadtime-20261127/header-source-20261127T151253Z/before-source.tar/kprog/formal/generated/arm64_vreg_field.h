/* Canonical simulator C; edit directly. Historical origin: generate_arm64_vreg_field_spec.py from arm64_vreg_field_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_VREG_FIELD_H
#define KPROG_FORMAL_GENERATED_ARM64_VREG_FIELD_H
/*
 * AArch64 vector-register half state-field contract: the vector memory step
 * (`ARM64_SIM_L_DQ_MEM_STEP`) moves the SIMD register's halves one at a time,
 * and each moved half lands in one of the two 64-bit state fields the vector
 * register file is split into. The field is selected from the single closed
 * fact: whether the half the plan names at this position is the high half,
 * whose slot offset is the high half's offset (`KPROG_ARM64_VREG_HIGH_OFFSET`,
 * the offset `KPROG_ARM64_VREG_HALF_OFFSET` yields for the high half). The low
 * field is the low half `__a64_v0` at slot offset 0; the high field is the
 * high half `__a64_v0_hi` at slot offset 8. `KProgFormal/
 * Arm64VregFieldShape.lean` proves the generated `fieldOf` equal to an
 * independent 2-way statement and ties the choice to the vector-register
 * contract (`GeneratedArm64Vreg.halfOffset` / `plan`) that fixes which state
 * field each half maps into and in which order the halves are touched. The
 * fact is closed, so the 2-way selection is total. This header uses only
 * literal inputs, but it cross-pins its field choice to the half offsets, so
 * it is included after `generated/arm64_vreg.h`.
 */
/* The number of state fields a moved half selects between. */
#define KPROG_ARM64_VREG_FIELD_COUNT 2U
#define KPROG_ARM64_VREG_LOW_FIELD 0U
#define KPROG_ARM64_VREG_HIGH_FIELD 1U
/*
 * The vector-register state field a moved half lands in: the high half's field
 * exactly when the moved half's slot offset is the high half's offset, the low
 * half's field otherwise. The input is evaluated once and no NZCV is written.
 */
#define KPROG_ARM64_VREG_FIELD(IS_HIGH_FIELD)                  \
	((__u8)(((IS_HIGH_FIELD)) ? KPROG_ARM64_VREG_HIGH_FIELD : KPROG_ARM64_VREG_LOW_FIELD))
_Static_assert(KPROG_ARM64_VREG_FIELD_COUNT == 2U,
	       "arm64 vreg field count drift");
_Static_assert(KPROG_ARM64_VREG_LOW_FIELD != KPROG_ARM64_VREG_HIGH_FIELD,
	       "arm64 vreg field codes must be distinct");
_Static_assert(KPROG_ARM64_VREG_LOW_FIELD == 0U && KPROG_ARM64_VREG_HIGH_FIELD == 1U,
	       "arm64 vreg field code drift");
/* The selector's fact is the moved half's slot offset being the high half's
 * offset, so the two vector half offsets must name the two state fields. */
_Static_assert(KPROG_ARM64_VREG_FIELD(KPROG_ARM64_VREG_HIGH_OFFSET ==
	       KPROG_ARM64_VREG_HIGH_OFFSET) == KPROG_ARM64_VREG_HIGH_FIELD,
	       "arm64 vreg field high half selection drift");
_Static_assert(KPROG_ARM64_VREG_FIELD(KPROG_ARM64_VREG_LOW_OFFSET ==
	       KPROG_ARM64_VREG_HIGH_OFFSET) == KPROG_ARM64_VREG_LOW_FIELD,
	       "arm64 vreg field low half selection drift");
/* The selector must name each state field at its own fact. */
_Static_assert(KPROG_ARM64_VREG_FIELD(1) == KPROG_ARM64_VREG_HIGH_FIELD,
	       "arm64 vreg field high selection drift");
_Static_assert(KPROG_ARM64_VREG_FIELD(0) == KPROG_ARM64_VREG_LOW_FIELD,
	       "arm64 vreg field low selection drift");
#endif
