/* Canonical simulator C; edit directly. Historical origin: generate_arm64_mem_base_src_spec.py from arm64_mem_base_src_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_MEM_BASE_SRC_H
#define KPROG_FORMAL_GENERATED_ARM64_MEM_BASE_SRC_H
/*
 * AArch64 memory base-address source contract: the scalar memory helpers
 * `ARM64_SIM_L_MEM_READ`, `ARM64_SIM_L_MEM_READ_TAG` and
 * `ARM64_SIM_L_MEM_WRITE` each compute the base address of a stack-arena
 * access, and its source is selected from the single closed fact: whether the
 * base register is the stack pointer. The stack pointer register source (a
 * base of `ARM64_SP`) is the simulator's stack pointer `__a64_sp` itself; the
 * general-purpose register arena base source (every other base) is the base
 * register's raw pointer value, the value the simulator indexes the arena
 * with. `KProgFormal/Arm64MemBaseSrcShape.lean` proves the generated
 * `sourceOf` equal to an independent 2-way statement and ties the
 * stack-pointer source to the 0123 store body selection
 * (`KPROG_ARM64_MEM_WRITE_ARM`) and the load dispatch stack split
 * (`KPROG_ARM64_MEM_READ_SRC`). The fact is closed, so the 2-way selection is
 * total. This header uses only literal inputs, so it is included before the
 * `ARM64_SIM_TAG_*` tag names in the simulator header.
 */
/* The number of base-address sources the helper selects between. */
#define KPROG_ARM64_MEM_BASE_SRC_COUNT 2U
#define KPROG_ARM64_MEM_BASE_SRC_SP_REGISTER 0U
#define KPROG_ARM64_MEM_BASE_SRC_GPR_BASE 1U
/*
 * The base-address source a memory helper selects: the stack pointer register
 * source exactly when the base register is the stack pointer, the base
 * register's own arena pointer otherwise. The input is evaluated once and no
 * NZCV is written.
 */
#define KPROG_ARM64_MEM_BASE_SRC(BASE_IS_SP)                  \
	((__u8)(((BASE_IS_SP)) ? KPROG_ARM64_MEM_BASE_SRC_SP_REGISTER : KPROG_ARM64_MEM_BASE_SRC_GPR_BASE))
_Static_assert(KPROG_ARM64_MEM_BASE_SRC_COUNT == 2U,
	       "arm64 mem base src count drift");
_Static_assert(KPROG_ARM64_MEM_BASE_SRC_SP_REGISTER != KPROG_ARM64_MEM_BASE_SRC_GPR_BASE,
	       "arm64 mem base src codes must be distinct");
_Static_assert(KPROG_ARM64_MEM_BASE_SRC_SP_REGISTER == 0U && KPROG_ARM64_MEM_BASE_SRC_GPR_BASE == 1U,
	       "arm64 mem base src code drift");
/* The selector must name each source at its own fact. */
_Static_assert(KPROG_ARM64_MEM_BASE_SRC(1) == KPROG_ARM64_MEM_BASE_SRC_SP_REGISTER,
	       "arm64 mem base src stack pointer selection drift");
_Static_assert(KPROG_ARM64_MEM_BASE_SRC(0) == KPROG_ARM64_MEM_BASE_SRC_GPR_BASE,
	       "arm64 mem base src gpr base selection drift");
#endif
