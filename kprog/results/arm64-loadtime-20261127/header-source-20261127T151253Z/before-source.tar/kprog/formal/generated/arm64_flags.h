/* Canonical simulator C; edit directly. Historical origin: generate_arm64_flags_spec.py from arm64_flags_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_FLAGS_H
#define KPROG_FORMAL_GENERATED_ARM64_FLAGS_H
#define KPROG_ARM64_SET_ADD_FLAGS(C_N, C_Z, C_C, C_V, LHS, RHS, WIDTH)   \
	do {                                                                \
		__u64 __kprog_a64_add_mask = KPROG_ARM64_WIDTH_MASK(WIDTH);  \
		__u64 __kprog_a64_add_sign = KPROG_ARM64_WIDTH_SIGN_MASK(WIDTH);\
		__u64 __kprog_a64_add_lhs = (LHS) & __kprog_a64_add_mask;    \
		__u64 __kprog_a64_add_rhs = (RHS) & __kprog_a64_add_mask;    \
		__u64 __kprog_a64_add_res =                              \
			(__kprog_a64_add_lhs + __kprog_a64_add_rhs) &       \
			__kprog_a64_add_mask;                                \
		(C_Z) = __kprog_a64_add_res == 0;                            \
		(C_N) = (__kprog_a64_add_res & __kprog_a64_add_sign) != 0;   \
		(C_C) = __kprog_a64_add_lhs >                                  \
			__kprog_a64_add_mask - __kprog_a64_add_rhs;          \
		(C_V) = (~(__kprog_a64_add_lhs ^ __kprog_a64_add_rhs) &      \
			 (__kprog_a64_add_lhs ^ __kprog_a64_add_res) &       \
			 __kprog_a64_add_sign) != 0;                         \
	} while (0)
#define KPROG_ARM64_SET_SUB_FLAGS(C_N, C_Z, C_C, C_V, LHS, RHS, WIDTH)   \
	do {                                                                \
		__u64 __kprog_a64_sub_mask = KPROG_ARM64_WIDTH_MASK(WIDTH);  \
		__u64 __kprog_a64_sub_sign = KPROG_ARM64_WIDTH_SIGN_MASK(WIDTH);\
		__u64 __kprog_a64_sub_lhs = (LHS) & __kprog_a64_sub_mask;    \
		__u64 __kprog_a64_sub_rhs = (RHS) & __kprog_a64_sub_mask;    \
		__u64 __kprog_a64_sub_res =                              \
			(__kprog_a64_sub_lhs - __kprog_a64_sub_rhs) &       \
			__kprog_a64_sub_mask;                                \
		(C_Z) = __kprog_a64_sub_lhs == __kprog_a64_sub_rhs;          \
		(C_N) = (__kprog_a64_sub_res & __kprog_a64_sub_sign) != 0;   \
		(C_C) = __kprog_a64_sub_lhs >= __kprog_a64_sub_rhs;          \
		(C_V) = ((__kprog_a64_sub_lhs ^ __kprog_a64_sub_rhs) &       \
			 (__kprog_a64_sub_lhs ^ __kprog_a64_sub_res) &       \
			 __kprog_a64_sub_sign) != 0;                         \
	} while (0)
#define KPROG_ARM64_SET_LOGIC_FLAGS(C_N, C_Z, C_C, C_V, VALUE, WIDTH)    \
	do {                                                                \
		__u64 __kprog_a64_log_value =                            \
			(VALUE) & KPROG_ARM64_WIDTH_MASK(WIDTH);             \
		__u64 __kprog_a64_log_sign =                             \
			KPROG_ARM64_WIDTH_SIGN_MASK(WIDTH);                  \
		(C_Z) = __kprog_a64_log_value == 0;                          \
		(C_N) = (__kprog_a64_log_value & __kprog_a64_log_sign) != 0; \
		(C_C) = 0;                                                   \
		(C_V) = 0;                                                   \
	} while (0)
#endif
