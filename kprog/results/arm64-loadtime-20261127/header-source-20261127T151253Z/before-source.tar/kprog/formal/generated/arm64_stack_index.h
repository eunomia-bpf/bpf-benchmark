/* Canonical simulator C; edit directly. Historical origin: generate_arm64_stack_index_spec.py from arm64_stack_index_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_STACK_INDEX_H
#define KPROG_FORMAL_GENERATED_ARM64_STACK_INDEX_H
#define KPROG_ARM64_STACK_INDEX(OFF, BIAS)                                  \
	((__u64)(BIAS) + (__u64)(OFF))
#define KPROG_ARM64_STACK_PTR_INDEX(OFF, BIAS)                              \
	((__s64)((__u64)(BIAS) + (__u64)(OFF)))
#endif
