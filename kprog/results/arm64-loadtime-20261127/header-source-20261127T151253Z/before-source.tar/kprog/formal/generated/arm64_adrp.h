/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_ADRP_H
#define KPROG_FORMAL_GENERATED_ARM64_ADRP_H
/*
 * The two arms are the AArch64 ADRP relocation kinds: the GOT form tags the
 * page-address write as a relocation address and the RODATA form as a
 * read-only-data address. The selected tag is returned to the caller, which
 * performs the register write; the immediate page address itself stays outside
 * this contract. An opcode outside the family reaches the caller-supplied
 * unsupported arm.
 */
_Static_assert(ARM64_OP_ADRP_GOT == 38U, "arm64 adrp code drift");
_Static_assert(ARM64_OP_ADRP_RODATA == 39U, "arm64 adrp code drift");
_Static_assert(ARM64_SIM_TAG_RELOC_ADDR == 7U, "arm64 adrp tag drift");
_Static_assert(ARM64_SIM_TAG_RODATA_ADDR == 8U, "arm64 adrp tag drift");
#define KPROG_ARM64_ADRP_HANDLED(OP)                                        \
	(((OP) == ARM64_OP_ADRP_GOT) || \
	((OP) == ARM64_OP_ADRP_RODATA))
_Static_assert(KPROG_ARM64_ADRP_HANDLED(ARM64_OP_ADRP_GOT), "arm64 adrp coverage drift");
_Static_assert(KPROG_ARM64_ADRP_HANDLED(ARM64_OP_ADRP_RODATA), "arm64 adrp coverage drift");
/*
 * The numeric case labels 38U and 39U track the ARM64_OP_ADRP_GOT and
 * ARM64_OP_ADRP_RODATA values defined in kprog/arm64/arm64_sim.h. OP is
 * the opcode; it is read once and no arm writes NZCV. The result is the
 * ARM64_SIM_TAG_* provenance tag the surrounding register write attaches.
 */
#define KPROG_ARM64_ADRP_TAG_INTO(OUTPUT, OP, UNSUPPORTED) \
	do { \
		__u8 __kprog_a64_adrp_op = (OP); \
		__u8 __kprog_a64_adrp_tag = 0; \
 \
		switch (__kprog_a64_adrp_op) { \
		case 38U:                           \
			__kprog_a64_adrp_tag = ARM64_SIM_TAG_RELOC_ADDR; \
			break; \
		case 39U:                           \
			__kprog_a64_adrp_tag = ARM64_SIM_TAG_RODATA_ADDR; \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		(OUTPUT) = __kprog_a64_adrp_tag; \
	} while (0)

#define KPROG_ARM64_ADRP_TAG(OP, UNSUPPORTED) \
	({ __u8 __kprog_a64_adrp_tag_out; \
	   KPROG_ARM64_ADRP_TAG_INTO(__kprog_a64_adrp_tag_out, OP, UNSUPPORTED); \
	   __kprog_a64_adrp_tag_out; })
#endif
