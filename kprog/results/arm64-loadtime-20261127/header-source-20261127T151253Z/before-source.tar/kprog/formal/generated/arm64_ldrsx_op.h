/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_LDRSX_OP_H
#define KPROG_FORMAL_GENERATED_ARM64_LDRSX_OP_H
/*
 * The sign-extending opcode each load-sign-extend arm derives from its load
 * opcode before handing the loaded value to the shared extract/reverse/extend
 * contract: SXTB for LDRSB, SXTW for LDRSW, SXTH for LDRSH. The sign position
 * follows the load width (bit 7, bit 31, bit 15 respectively). An opcode
 * outside the family reaches the caller-supplied unsupported arm.
 */
_Static_assert(ARM64_OP_LDRSB == 54U, "arm64 ldrsx op load code drift");
_Static_assert(ARM64_OP_SXTB == 60U, "arm64 ldrsx op sign code drift");
_Static_assert(ARM64_OP_LDRSW == 57U, "arm64 ldrsx op load code drift");
_Static_assert(ARM64_OP_SXTW == 47U, "arm64 ldrsx op sign code drift");
_Static_assert(ARM64_OP_LDRSH == 63U, "arm64 ldrsx op load code drift");
_Static_assert(ARM64_OP_SXTH == 21U, "arm64 ldrsx op sign code drift");
/*
 * The numeric case labels 54U, 57U, and 63U track the ARM64_OP_LDRSB,
 * ARM64_OP_LDRSW, and ARM64_OP_LDRSH values defined in
 * kprog/arm64/arm64_sim.h. OP is the load opcode, read once. The result is the
 * ARM64_OP_SX* opcode the extract/reverse/extend contract sign-extends with.
 */
#define KPROG_ARM64_LDRSX_SXOP_INTO(OUTPUT, OP, UNSUPPORTED)                             \
	do { \
		__u64 __kprog_a64_ldrsx_sxop = (OP); \
		__u64 __kprog_a64_ldrsx_sx = 0; \
 \
		switch (__kprog_a64_ldrsx_sxop) { \
		case 54U:                           \
			__kprog_a64_ldrsx_sx = ARM64_OP_SXTB; \
			break; \
		case 57U:                           \
			__kprog_a64_ldrsx_sx = ARM64_OP_SXTW; \
			break; \
		case 63U:                           \
			__kprog_a64_ldrsx_sx = ARM64_OP_SXTH; \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		(OUTPUT) = __kprog_a64_ldrsx_sx; \
	} while (0)
#define KPROG_ARM64_LDRSX_SXOP(OP, UNSUPPORTED) \
    ({ __u64 __kprog_memory_helper_result; \
       KPROG_ARM64_LDRSX_SXOP_INTO(__kprog_memory_helper_result, (OP), UNSUPPORTED); \
       __kprog_memory_helper_result; })
#endif
