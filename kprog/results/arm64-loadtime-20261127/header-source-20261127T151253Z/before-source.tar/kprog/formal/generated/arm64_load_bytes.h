/* Canonical simulator C; edit directly. Historical origin: generate_arm64_load_bytes_spec.py from arm64_load_bytes_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_LOAD_BYTES_H
#define KPROG_FORMAL_GENERATED_ARM64_LOAD_BYTES_H
/*
 * AArch64 little-endian load value: assemble the width's bytes from memory into
 * their own lanes, zeroing every higher lane. The width set is closed (the four
 * ARM64_WIDTH_* codes) and every case is handled, so there is no unsupported
 * arm.
 */
_Static_assert(ARM64_WIDTH_8 == 1U, "arm64 load-bytes width code drift");
_Static_assert(ARM64_WIDTH_16 == 2U, "arm64 load-bytes width code drift");
_Static_assert(ARM64_WIDTH_32 == 4U, "arm64 load-bytes width code drift");
_Static_assert(ARM64_WIDTH_64 == 8U, "arm64 load-bytes width code drift");
#if defined(__bpf__) || defined(__BPF__)
#define KPROG_ARM64_LOAD_ACCESS(BITS, ADDR, OUT) \
	__asm__ __volatile__("%0 = *(u" #BITS " *)(%1 + 0)" : "=r"(OUT) : "r"(ADDR) : "memory")
#define KPROG_ARM64_LOAD_ACCESS_OFFSET(BITS, BASE, OFFSET, OUT) \
	do { \
		if (__builtin_constant_p(OFFSET) && (OFFSET) >= -32768 && (OFFSET) <= 32767) { \
			if ((OFFSET) < 0) \
				__asm__ __volatile__("%0 = *(u" #BITS " *)(%1 - %2)" : "=r"(OUT) : "r"(BASE), "i"(-(OFFSET)) : "memory"); \
			else \
				__asm__ __volatile__("%0 = *(u" #BITS " *)(%1 + %2)" : "=r"(OUT) : "r"(BASE), "i"(OFFSET) : "memory"); \
		} else \
			KPROG_ARM64_LOAD_ACCESS(BITS, (const __u8 *)(BASE) + (OFFSET), OUT); \
	} while (0)
#elif defined(__COMPCERT__)
#include "../c/Platform.h"
#define KPROG_ARM64_LOAD_ACCESS(BITS, ADDR, OUT) \
    KPROG_C_UNALIGNED_LOAD_INTO((OUT), __u##BITS, (ADDR), 0)
#define KPROG_ARM64_LOAD_ACCESS_OFFSET(BITS, BASE, OFFSET, OUT) \
    KPROG_C_UNALIGNED_LOAD_INTO((OUT), __u##BITS, (BASE), (OFFSET))
#else
typedef __u8 kprog_arm64_load_u8_unaligned __attribute__((aligned(1),may_alias));
typedef __u16 kprog_arm64_load_u16_unaligned __attribute__((aligned(1),may_alias));
typedef __u32 kprog_arm64_load_u32_unaligned __attribute__((aligned(1),may_alias));
typedef __u64 kprog_arm64_load_u64_unaligned __attribute__((aligned(1),may_alias));
#define KPROG_ARM64_LOAD_ACCESS(BITS, ADDR, OUT) \
	((OUT) = *(volatile const kprog_arm64_load_u##BITS##_unaligned *)(ADDR))
#define KPROG_ARM64_LOAD_ACCESS_OFFSET(BITS, BASE, OFFSET, OUT) \
	KPROG_ARM64_LOAD_ACCESS(BITS, (const __u8 *)(BASE) + (OFFSET), OUT)
#endif
/*
 * ADDR + OFFSET is the source address; WIDTH is one of the four ARM64_WIDTH_*
 * codes. One access reads exactly that width; no NZCV is written. The
 * result is the raw 64-bit value; the caller applies the destination width to
 * the *value* separately for the sign-extending loads.
 */
#define KPROG_ARM64_LOAD_BYTES_OFFSET_INTO(OUTPUT, ADDR, OFFSET, WIDTH)                                 \
	do { \
		volatile const __u8 *__kprog_a64_lb_addr = \
			(volatile const __u8 *)(ADDR); \
		__u8 __kprog_a64_lb_width = (WIDTH); \
		__u64 __kprog_a64_lb_value; \
		if (__kprog_a64_lb_width == ARM64_WIDTH_64) \
			KPROG_ARM64_LOAD_ACCESS_OFFSET(64, __kprog_a64_lb_addr, (OFFSET), __kprog_a64_lb_value); \
		else if (__kprog_a64_lb_width >= ARM64_WIDTH_32) \
			KPROG_ARM64_LOAD_ACCESS_OFFSET(32, __kprog_a64_lb_addr, (OFFSET), __kprog_a64_lb_value); \
		else if (__kprog_a64_lb_width >= ARM64_WIDTH_16) \
			KPROG_ARM64_LOAD_ACCESS_OFFSET(16, __kprog_a64_lb_addr, (OFFSET), __kprog_a64_lb_value); \
		else \
			KPROG_ARM64_LOAD_ACCESS_OFFSET(8, __kprog_a64_lb_addr, (OFFSET), __kprog_a64_lb_value); \
		(OUTPUT) = __kprog_a64_lb_value; \
	} while (0)
#define KPROG_ARM64_LOAD_BYTES_OFFSET(ADDR, OFFSET, WIDTH) \
    ({ __u64 __kprog_a64_loaded; \
       KPROG_ARM64_LOAD_BYTES_OFFSET_INTO(__kprog_a64_loaded, (ADDR), (OFFSET), (WIDTH)); \
       __kprog_a64_loaded; })
/* Keep constant displacements inside the BPF memory instruction: some context
 * types forbid pointer arithmetic even for a fixed, valid field offset.
 * Variable or out-of-encoding-range offsets use ordinary address arithmetic.
 * Both forms read exactly WIDTH bytes at ADDR + OFFSET. */
#define KPROG_ARM64_LOAD_BYTES(ADDR, WIDTH) \
	KPROG_ARM64_LOAD_BYTES_OFFSET((ADDR), 0, (WIDTH))
#endif
