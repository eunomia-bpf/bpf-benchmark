/* Canonical simulator C; edit directly. Historical origin: generate_arm64_write_arm_spec.py from arm64_write_arm_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_WRITE_ARM_H
#define KPROG_FORMAL_GENERATED_ARM64_WRITE_ARM_H
/*
 * AArch64 write-register width body-selection contract: the writeback body
 * `ARM64_SIM_L_WRITE_REG_WIDTH` first masks its value to the access width
 * (`KPROG_ARM64_APPLY_WIDTH`, owned by `generated/arm64_width.h`) and then
 * selects the writeback body from a single closed fact: whether the access
 * width code is the 32-bit code 4. The narrow cell store writes
 * `(__u32)__a64_l_next`; the full cell store writes `__a64_l_next`.
 * Because the value is
 * masked to the width before the choice, the two bodies are observationally
 * equal for every width the simulator reaches, so only a wrong selector code
 * or a swapped body assignment is observable.
 * `KProgFormal/Arm64WriteArmShape.lean` proves the generated `armOf` equal to
 * an independent 2-way statement, tied to the `Arm64Width` 32-bit code
 * (`arm64WidthCodeSpec .w32`) the pre-truncation step masks with. The `SP`
 * branch and the destination-presence guard stay outside the selector: they
 * are the destination-identity contract, not the width body choice.
 * This header binds the hand-written 32-bit code to the generated table, so it
 * is included after the `ARM64_WIDTH_*` decodes.
 */
/* The 32-bit width code the narrow body is selected at. */
#define KPROG_ARM64_WRITE_ARM_W32 4U
/* The number of writeback bodies the helper selects between. */
#define KPROG_ARM64_WRITE_ARM_COUNT 2U
#define KPROG_ARM64_WRITE_ARM_FULL 0U
#define KPROG_ARM64_WRITE_ARM_NARROW 1U
/*
 * The writeback body an access width selects: the full-value body exactly when
 * the width code is not the 32-bit code, the 32-bit truncating body otherwise.
 * The input is evaluated once and no NZCV is written.
 */
#define KPROG_ARM64_WRITE_ARM(IS_W32)                                        \
	((__u8)(((IS_W32)) ? KPROG_ARM64_WRITE_ARM_NARROW : KPROG_ARM64_WRITE_ARM_FULL))
_Static_assert(KPROG_ARM64_WRITE_ARM_W32 == 4U,
	       "arm64 write arm 32-bit width code drift");
_Static_assert(ARM64_WIDTH_32 == KPROG_ARM64_WRITE_ARM_W32,
	       "arm64 write arm 32-bit width code drift");
_Static_assert(KPROG_ARM64_WRITE_ARM_COUNT == 2U,
	       "arm64 write arm count drift");
_Static_assert(KPROG_ARM64_WRITE_ARM_FULL != KPROG_ARM64_WRITE_ARM_NARROW,
	       "arm64 write arm codes must be distinct");
_Static_assert(KPROG_ARM64_WRITE_ARM_FULL == 0U &&
	       KPROG_ARM64_WRITE_ARM_NARROW == 1U,
	       "arm64 write arm code drift");
/* The selector must name each body at its own width fact. */
_Static_assert(KPROG_ARM64_WRITE_ARM(ARM64_WIDTH_32 == ARM64_WIDTH_32) == KPROG_ARM64_WRITE_ARM_NARROW,
	       "arm64 write arm narrow selection drift");
_Static_assert(KPROG_ARM64_WRITE_ARM(ARM64_WIDTH_8 == ARM64_WIDTH_32) == KPROG_ARM64_WRITE_ARM_FULL,
	       "arm64 write arm 8-bit selection drift");
_Static_assert(KPROG_ARM64_WRITE_ARM(ARM64_WIDTH_16 == ARM64_WIDTH_32) == KPROG_ARM64_WRITE_ARM_FULL,
	       "arm64 write arm 16-bit selection drift");
_Static_assert(KPROG_ARM64_WRITE_ARM(ARM64_WIDTH_64 == ARM64_WIDTH_32) == KPROG_ARM64_WRITE_ARM_FULL,
	       "arm64 write arm 64-bit selection drift");
#endif
