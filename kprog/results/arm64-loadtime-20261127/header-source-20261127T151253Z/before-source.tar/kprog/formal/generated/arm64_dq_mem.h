/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_DQ_MEM_H
#define KPROG_FORMAL_GENERATED_ARM64_DQ_MEM_H
/*
 * AArch64 vector `.D0` / `.Q0` memory-transfer contract. The four bodies move
 * the SIMD low lane (`.D0`) or both 64-bit lanes (`.Q0`) to or from memory. The
 * address offset (MEM_BASE_OFF) and the pre/post base adjustment (MEM_PRE /
 * MEM_POST) stay in the macros with their own proved contracts; this contract
 * fixes which lanes each opcode transfers and in which order. Every lane is a
 * full 64-bit scalar access.
 */
_Static_assert(ARM64_OP_LOAD_D0 == 0x28U, "arm64 D0/Q0 loadD0 opcode drift");
_Static_assert(ARM64_OP_LOAD_Q0 == 0x2aU, "arm64 D0/Q0 loadQ0 opcode drift");
_Static_assert(ARM64_OP_STORE_D0 == 0x29U, "arm64 D0/Q0 storeD0 opcode drift");
_Static_assert(ARM64_OP_STORE_Q0 == 0x2bU, "arm64 D0/Q0 storeQ0 opcode drift");
/*
 * The lane stride: every transferred lane is a 64-bit access, and the high lane
 * of a `.Q0` transfer follows the low lane by one lane stride.
 */
#define KPROG_ARM64_DQ_MEM_LANE_STRIDE ARM64_WIDTH_64
#define KPROG_ARM64_DQ_MEM_HIGH_LANE_STRIDE 8
_Static_assert(KPROG_ARM64_DQ_MEM_LANE_STRIDE == 8U,
	       "arm64 D0/Q0 lane stride drift");
/*
 * Access direction of each opcode: 0 loads into the SIMD register, 1 stores
 * from it.
 */
#define KPROG_ARM64_DQ_MEM_ACCESS_LOAD 0U
#define KPROG_ARM64_DQ_MEM_ACCESS_STORE 1U
#define KPROG_ARM64_DQ_MEM_OP_LOAD_D0_ACCESS KPROG_ARM64_DQ_MEM_ACCESS_LOAD
#define KPROG_ARM64_DQ_MEM_OP_LOAD_Q0_ACCESS KPROG_ARM64_DQ_MEM_ACCESS_LOAD
#define KPROG_ARM64_DQ_MEM_OP_STORE_D0_ACCESS KPROG_ARM64_DQ_MEM_ACCESS_STORE
#define KPROG_ARM64_DQ_MEM_OP_STORE_Q0_ACCESS KPROG_ARM64_DQ_MEM_ACCESS_STORE
/*
 * Lane count of each opcode: 1 moves the low lane only (`.D0`), 2 moves the low
 * lane then the high lane (`.Q0`).
 */
#define KPROG_ARM64_DQ_MEM_OP_LOAD_D0_LANES 1U
#define KPROG_ARM64_DQ_MEM_OP_LOAD_Q0_LANES 2U
#define KPROG_ARM64_DQ_MEM_OP_STORE_D0_LANES 1U
#define KPROG_ARM64_DQ_MEM_OP_STORE_Q0_LANES 2U
/* The scalar load zeroes the upper vector half after its one lane read. */
#define KPROG_ARM64_DQ_MEM_CLEAR_HIGH(OP) (((OP) == ARM64_OP_LOAD_D0))
/*
 * The arm index of each opcode in the four-way `OP == LOAD_D0 / LOAD_Q0 /
 * STORE_D0 / STORE_Q0` chain, decoded from the opcode code so the chain order is
 * a checked fact.
 */
#define KPROG_ARM64_DQ_MEM_OP_LOAD_D0_INDEX 0U
#define KPROG_ARM64_DQ_MEM_OP_LOAD_Q0_INDEX 1U
#define KPROG_ARM64_DQ_MEM_OP_STORE_D0_INDEX 2U
#define KPROG_ARM64_DQ_MEM_OP_STORE_Q0_INDEX 3U
#define KPROG_ARM64_DQ_MEM_INDEX_INTO(OUTPUT, OP) \
    do { \
        __u32 __kprog_a64_dq_idx; \
        if ((OP) == ARM64_OP_LOAD_D0) \
            __kprog_a64_dq_idx = 0U; \
        else if ((OP) == ARM64_OP_LOAD_Q0) \
            __kprog_a64_dq_idx = 1U; \
        else if ((OP) == ARM64_OP_STORE_D0) \
            __kprog_a64_dq_idx = 2U; \
        else \
            __kprog_a64_dq_idx = 3U; \
        (OUTPUT) = __kprog_a64_dq_idx; \
    } while (0)
#define KPROG_ARM64_DQ_MEM_INDEX(OP) \
    ({ __u32 __kprog_transfer_index; \
       KPROG_ARM64_DQ_MEM_INDEX_INTO(__kprog_transfer_index, (OP)); \
       __kprog_transfer_index; })

#endif
