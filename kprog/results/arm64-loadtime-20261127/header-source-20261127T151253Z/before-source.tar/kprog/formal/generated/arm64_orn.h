/* Canonical simulator C. Edit directly; export the Lean AST with clightgen. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_ORN_H
#define KPROG_FORMAL_GENERATED_ARM64_ORN_H
/*
 * The one arm is the AArch64 complemented logical OR (ORN): the OR of the first
 * source with the bitwise complement of the already source-modified second
 * source. The result is masked to the destination width, exactly the narrowing
 * the caller's register write performs. The complement is inlined, so this
 * header calls no hand-written helper. An opcode outside the family reaches the
 * caller-supplied unsupported arm.
 */
#include "arm64_width.h"
_Static_assert(ARM64_OP_ORN_REG == 53U, "arm64 orn code drift");
#define KPROG_ARM64_ORN_HANDLED(OP)                                         \
	(((OP) == ARM64_OP_ORN_REG))
_Static_assert(KPROG_ARM64_ORN_HANDLED(ARM64_OP_ORN_REG), "arm64 orn coverage drift");
/*
 * The numeric case label 53U tracks the ARM64_OP_ORN_REG value defined in
 * kprog/arm64/arm64_sim.h. OP is the opcode, LHS the first source register
 * contents, RHS the second source register contents (the caller has applied any
 * source modifier), and WIDTH the destination width code. LHS and RHS are each
 * evaluated exactly once and no arm writes NZCV. The result is the
 * width-narrowed raw 64-bit value the caller writes back.
 */
#define KPROG_ARM64_ORN_VALUE_DECL(NAME, OP, LHS, RHS, WIDTH, UNSUPPORTED) \
		__u64 __kprog_a64_orn_op = (OP); \
		__u64 __kprog_a64_orn_lhs = (LHS); \
		__u64 __kprog_a64_orn_rhs = (RHS); \
		__u64 __kprog_a64_orn_width = (WIDTH); \
		__u64 __kprog_a64_orn_wmask = KPROG_ARM64_WIDTH_MASK(__kprog_a64_orn_width); \
		__u64 NAME = 0; \
 \
		switch (__kprog_a64_orn_op) { \
		case 53U: \
			NAME = (__kprog_a64_orn_lhs | ~__kprog_a64_orn_rhs) & __kprog_a64_orn_wmask; \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		}
#define KPROG_ARM64_ORN_VALUE_INTO(OUTPUT, OP, LHS, RHS, WIDTH, UNSUPPORTED) \
    do { KPROG_ARM64_ORN_VALUE_DECL(__kprog_a64_orn_result, OP, LHS, RHS, WIDTH, UNSUPPORTED); \
         (OUTPUT)=__kprog_a64_orn_result; } while (0)
#define KPROG_ARM64_ORN_VALUE(OP, LHS, RHS, WIDTH, UNSUPPORTED) \
    ({ KPROG_ARM64_ORN_VALUE_DECL(__kprog_a64_orn_result, OP, LHS, RHS, WIDTH, UNSUPPORTED); \
       __kprog_a64_orn_result; })
#endif
