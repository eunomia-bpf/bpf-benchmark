/* Canonical simulator C; edit directly. Historical origin: generate_arm64_stack_arena_spec.py from arm64_stack_arena_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_STACK_ARENA_H
#define KPROG_FORMAL_GENERATED_ARM64_STACK_ARENA_H
#define KPROG_ARM64_STACK_WORD_INDEX(INDEX) ((__u64)(INDEX) >> 3)
#define KPROG_ARM64_STACK_WORD_ALIGNED(INDEX) \
	((((__u32)(INDEX) & 7U) == 0U) ? 1 : 0)
#define KPROG_ARM64_STACK_WORDS(CAPACITY) \
	(((__u32)(CAPACITY) + 7U) / 8U)
#define KPROG_ARM64_STACK_TAG_SLOTS(CAPACITY) \
	(((__u32)(CAPACITY) + 7U) / 8U)
/*
 * An access of BYTES bytes at INDEX fits an arena of CAPACITY bytes when the
 * first index past its window is at most CAPACITY. A caller that reaches the
 * arena without this guard over-runs the final BYTES - 1 bytes.
 */
#define KPROG_ARM64_STACK_WINDOW_END(INDEX, BYTES) \
	(((__u64)(__u32)(INDEX)) + ((__u64)(__u32)(BYTES)))
#define KPROG_ARM64_STACK_WINDOW_FITS(INDEX, BYTES, CAPACITY) \
	((KPROG_ARM64_STACK_WINDOW_END((INDEX), (BYTES)) <= (__u64)(__u32)(CAPACITY)) ? 1 : 0)
/*
 * A tag access addresses one slot of `KPROG_ARM64_STACK_TAG_SLOTS(CAPACITY)`
 * entries. A slot at or past the count -- which a byte index at or past
 * CAPACITY reaches -- is outside the tag array.
 */
#define KPROG_ARM64_STACK_TAG_SLOT_FITS(INDEX, SLOTS) \
	((KPROG_ARM64_STACK_WORD_INDEX(INDEX) < (__u32)(SLOTS)) ? 1 : 0)
/*
 * An arena pointer is well defined up to and including the one-past-end index,
 * the C `INDEX <= CAPACITY`. A pointer past that is not an arena address. The comparison widens the index
to a signed 64-bit value and then reads it unsigned, so a negative index
becomes a huge value and fails the same single test -- no branch that the
compiler could fold away for one call site's type.
 */
#define KPROG_ARM64_STACK_POINTER_FITS(INDEX, CAPACITY) \
	(((__u64)(__s64)(INDEX)) <= ((__u64)(__s64)(__u32)(CAPACITY)) ? 1 : 0)
#endif
