/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_SHIFT_H
#define KPROG_FORMAL_GENERATED_ARM64_SHIFT_H
/*
 * The four arms are the AArch64 shift family (LSL/LSR/ASR/ROR) applied by the
 * shift handler. Every ARM64_SHIFT_* code has exactly one arm, so the macro is
 * total over SHIFT and no unsupported arm is needed; a code outside the table
 * still reaches the caller-supplied unsupported arm.
 *
 * The rotations are inlined, so this header calls no hand-written helper. It
 * includes the shared width contract for ARM64_WIDTH_32 and
 * KPROG_ARM64_WIDTH_MASK so it is usable standalone.
 */
#include "arm64_width.h"
_Static_assert(ARM64_SHIFT_LSL == 0U, "arm64 shift code drift");
_Static_assert(ARM64_SHIFT_LSR == 1U, "arm64 shift code drift");
_Static_assert(ARM64_SHIFT_ASR == 2U, "arm64 shift code drift");
_Static_assert(ARM64_SHIFT_ROR == 3U, "arm64 shift code drift");
#define KPROG_ARM64_SHIFT_HANDLED(SHIFT)                                    \
	(((SHIFT) == ARM64_SHIFT_LSL) || \
	((SHIFT) == ARM64_SHIFT_LSR) || \
	((SHIFT) == ARM64_SHIFT_ASR) || \
	((SHIFT) == ARM64_SHIFT_ROR))
_Static_assert(KPROG_ARM64_SHIFT_HANDLED(ARM64_SHIFT_LSL), "arm64 shift coverage drift");
_Static_assert(KPROG_ARM64_SHIFT_HANDLED(ARM64_SHIFT_LSR), "arm64 shift coverage drift");
_Static_assert(KPROG_ARM64_SHIFT_HANDLED(ARM64_SHIFT_ASR), "arm64 shift coverage drift");
_Static_assert(KPROG_ARM64_SHIFT_HANDLED(ARM64_SHIFT_ROR), "arm64 shift coverage drift");
/*
 * The numeric case labels 0U..3U track the ARM64_SHIFT_LSL/LSR/ASR/ROR values
 * defined in kprog/arm64/arm64_sim.h. SHIFT is the shift kind, VALUE the
 * source operand, AMOUNT the raw shift amount and WIDTH the destination width
 * code. VALUE and AMOUNT are each evaluated exactly once and no arm writes NZCV.
 * The result is the raw 64-bit value; the caller applies the destination width.
 */
#define KPROG_ARM64_SHIFT_VALUE_INTO(OUTPUT, SHIFT, VALUE, AMOUNT, WIDTH, UNSUPPORTED) \
	do { \
		__u64 __kprog_a64_shift_op = (SHIFT); \
		__u64 __kprog_a64_shift_value = (VALUE); \
		__u64 __kprog_a64_shift_amount = (AMOUNT); \
		__u64 __kprog_a64_shift_width = (WIDTH); \
		int __kprog_a64_shift_32 = __kprog_a64_shift_width == ARM64_WIDTH_32; \
		__u64 __kprog_a64_shift_wmask = KPROG_ARM64_WIDTH_MASK(__kprog_a64_shift_width); \
		__u64 __kprog_a64_shift_k = __kprog_a64_shift_amount & (__kprog_a64_shift_width == ARM64_WIDTH_32 ? 31ULL : 63ULL); \
		__u64 __kprog_a64_shift_result = 0; \
 \
		switch (__kprog_a64_shift_op) { \
		case 0U:                           \
			__kprog_a64_shift_result = \
				(__kprog_a64_shift_value << __kprog_a64_shift_k) & \
				__kprog_a64_shift_wmask; \
			break; \
		case 1U:                           \
			__kprog_a64_shift_result = \
				(__kprog_a64_shift_value & __kprog_a64_shift_wmask) >> \
				__kprog_a64_shift_k; \
			break; \
		case 2U:                           \
			__kprog_a64_shift_result = __kprog_a64_shift_32 \
				? (__u64)((__s32)__kprog_a64_shift_value >> __kprog_a64_shift_k) \
				: (__u64)((__s64)__kprog_a64_shift_value >> __kprog_a64_shift_k); \
			break; \
		case 3U:                           \
			if (__kprog_a64_shift_32) { \
				__u32 __kprog_a64_shift_w32 = (__u32)__kprog_a64_shift_value; \
 \
				__kprog_a64_shift_result = __kprog_a64_shift_k \
					? (__u64)((__kprog_a64_shift_w32 >> __kprog_a64_shift_k) | \
						  (__kprog_a64_shift_w32 << (32U - __kprog_a64_shift_k))) \
					: (__u64)__kprog_a64_shift_w32; \
			} else { \
				__kprog_a64_shift_result = __kprog_a64_shift_k \
					? (__kprog_a64_shift_value >> __kprog_a64_shift_k) | \
					  (__kprog_a64_shift_value << (64U - __kprog_a64_shift_k)) \
					: __kprog_a64_shift_value; \
			} \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		(OUTPUT) = __kprog_a64_shift_result; \
	} while (0)

#define KPROG_ARM64_SHIFT_VALUE(SHIFT, VALUE, AMOUNT, WIDTH, UNSUPPORTED) \
	({ __u64 __kprog_a64_shift_result_out; \
	   KPROG_ARM64_SHIFT_VALUE_INTO(__kprog_a64_shift_result_out, SHIFT, VALUE, AMOUNT, WIDTH, UNSUPPORTED); \
	   __kprog_a64_shift_result_out; })
#endif
