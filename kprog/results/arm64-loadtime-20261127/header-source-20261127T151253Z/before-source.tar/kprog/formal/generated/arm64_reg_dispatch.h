/* Canonical simulator C; edit directly. Historical origin: generate_arm64_reg_dispatch_spec.py from arm64_reg_dispatch_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_REG_DISPATCH_H
#define KPROG_FORMAL_GENERATED_ARM64_REG_DISPATCH_H
/*
 * AArch64 register-number -> dispatch-cell binding: the 31 general-purpose
 * registers are the register numbers `0 .. 30`, in `x0 .. x30` order, so
 * the `ARM64_SIM_L_FOR_EACH_GPR` dispatch cell index equals the register
 * number. The zero register (`31`, `ARM64_XZR`), the stack pointer (`32`,
 * `ARM64_SP`) and the no-register sentinel (`0xff`, `ARM64_REG_NONE`) are not
 * dispatch cells.
 * `KProgFormal/Arm64RegDispatch.lean` proves the generated `cellNumbers` /
 * `cellNames` tables equal an independent `List.finRange` construction and that
 * `cellOf` maps exactly the general-purpose register numbers to a cell.
 * This header is included after the `ARM64_X0 .. ARM64_X30` decodes, so the
 * number drift checks bind the hand-written decode to the generated table.
 */
/* The number of GPR dispatch cells. */
#define KPROG_ARM64_GPR_COUNT 31U
/*
 * The dispatch cell index a decoded register number names. The
 * `ARM64_SIM_L_FOR_EACH_GPR` order makes the cell index equal the register
 * number; evaluated once. Callers must have already excluded the non-GPR
 * numbers (the zero register, the stack pointer and the sentinel).
 */
#define KPROG_ARM64_GPR_CELL(REG) ((__u8)((REG)))
/* The hand-written register decode must equal the generated cell table. */
_Static_assert(ARM64_X0 == 0U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X1 == 1U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X2 == 2U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X3 == 3U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X4 == 4U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X5 == 5U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X6 == 6U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X7 == 7U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X8 == 8U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X9 == 9U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X10 == 10U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X11 == 11U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X12 == 12U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X13 == 13U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X14 == 14U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X15 == 15U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X16 == 16U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X17 == 17U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X18 == 18U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X19 == 19U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X20 == 20U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X21 == 21U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X22 == 22U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X23 == 23U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X24 == 24U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X25 == 25U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X26 == 26U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X27 == 27U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X28 == 28U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X29 == 29U, "arm64 gpr dispatch number drift");
_Static_assert(ARM64_X30 == 30U, "arm64 gpr dispatch number drift");
_Static_assert(KPROG_ARM64_GPR_COUNT == 31U,
	       "arm64 gpr dispatch count drift");
#endif
