/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_EXTREV_H
#define KPROG_FORMAL_GENERATED_ARM64_EXTREV_H
/*
 * The six arms are EXTR (extract of a rotated register pair), REV/REV16 (byte
 * reversal over the whole width and within each 16-bit unit) and
 * SXTB/SXTH/SXTW (sign extension of the low 8/16/32 bits). Every opcode of the
 * family has exactly one arm; an opcode outside the family reaches the
 * caller-supplied unsupported arm. All six write no NZCV.
 */
_Static_assert(ARM64_OP_EXTR == 17U, "arm64 extract code drift");
_Static_assert(ARM64_OP_REV == 19U, "arm64 extract code drift");
_Static_assert(ARM64_OP_REV16 == 20U, "arm64 extract code drift");
_Static_assert(ARM64_OP_SXTH == 21U, "arm64 extract code drift");
_Static_assert(ARM64_OP_SXTW == 47U, "arm64 extract code drift");
_Static_assert(ARM64_OP_SXTB == 60U, "arm64 extract code drift");
#define KPROG_ARM64_EXTREV_HANDLED(OP)                                      \
	(((OP) == ARM64_OP_EXTR) || \
	((OP) == ARM64_OP_REV) || \
	((OP) == ARM64_OP_REV16) || \
	((OP) == ARM64_OP_SXTH) || \
	((OP) == ARM64_OP_SXTW) || \
	((OP) == ARM64_OP_SXTB))
_Static_assert(KPROG_ARM64_EXTREV_HANDLED(ARM64_OP_EXTR), "arm64 extract coverage drift");
_Static_assert(KPROG_ARM64_EXTREV_HANDLED(ARM64_OP_REV), "arm64 extract coverage drift");
_Static_assert(KPROG_ARM64_EXTREV_HANDLED(ARM64_OP_REV16), "arm64 extract coverage drift");
_Static_assert(KPROG_ARM64_EXTREV_HANDLED(ARM64_OP_SXTH), "arm64 extract coverage drift");
_Static_assert(KPROG_ARM64_EXTREV_HANDLED(ARM64_OP_SXTW), "arm64 extract coverage drift");
_Static_assert(KPROG_ARM64_EXTREV_HANDLED(ARM64_OP_SXTB), "arm64 extract coverage drift");
/*
 * The numeric case labels 17U, 19U, 20U, 21U, 47U and 60U track the
 * ARM64_OP_EXTR/REV/REV16/SXTH/SXTW/SXTB values defined in
 * kprog/arm64/arm64_sim.h; the family is not contiguous. This header
 * intentionally does not include arm64_sim.h, so it stays usable standalone;
 * load() re-checks the codes against arm64_sim.h and exits 1 if they drift.
 * SRC, SRC2 and SHIFT are each evaluated exactly once, and no arm writes NZCV.
 * The result is the raw 64-bit value; the caller applies the destination width
 * afterwards, which is also the architectural narrowing of EXTR. WIDTH is a
 * width code and must be one of ARM64_WIDTH_8/16/32/64.
 */
#define KPROG_ARM64_EXTREV_VALUE_INTO(OUTPUT, OP, SRC, SRC2, SHIFT, WIDTH, UNSUPPORTED) \
	do { \
		__u64 __kprog_a64_ext_op = (OP); \
		__u64 __kprog_a64_ext_src = (SRC); \
		__u64 __kprog_a64_ext_src2 = (SRC2); \
		__u64 __kprog_a64_ext_shift = (SHIFT); \
		__u64 __kprog_a64_ext_width = (WIDTH); \
		__u64 __kprog_a64_ext_bits = \
			KPROG_ARM64_WIDTH_BITS(__kprog_a64_ext_width); \
		__u64 __kprog_a64_ext_result = 0; \
 \
		switch (__kprog_a64_ext_op) { \
		case 17U:                           \
			__kprog_a64_ext_shift = \
				__kprog_a64_ext_shift & (__kprog_a64_ext_bits - 1); \
			__kprog_a64_ext_result = \
				(__kprog_a64_ext_src2 >> __kprog_a64_ext_shift) | \
				(__kprog_a64_ext_shift \
					? __kprog_a64_ext_src \
					  << (__kprog_a64_ext_bits - __kprog_a64_ext_shift) \
					: 0); \
			break; \
		case 19U:                           \
			if (__kprog_a64_ext_width == ARM64_WIDTH_32) { \
				__u32 __kprog_a64_ext_w32 = (__u32)__kprog_a64_ext_src; \
 \
				__kprog_a64_ext_result = \
					((__u64)(__kprog_a64_ext_w32 & 0xffU) << 24) | \
					((__u64)((__kprog_a64_ext_w32 >> 8) & 0xffU) << 16) | \
					((__u64)((__kprog_a64_ext_w32 >> 16) & 0xffU) << 8) | \
					((__u64)((__kprog_a64_ext_w32 >> 24) & 0xffU)); \
			} else { \
				__kprog_a64_ext_result = \
					((__kprog_a64_ext_src & 0xffULL) << 56) | \
					(((__kprog_a64_ext_src >> 8) & 0xffULL) << 48) | \
					(((__kprog_a64_ext_src >> 16) & 0xffULL) << 40) | \
					(((__kprog_a64_ext_src >> 24) & 0xffULL) << 32) | \
					(((__kprog_a64_ext_src >> 32) & 0xffULL) << 24) | \
					(((__kprog_a64_ext_src >> 40) & 0xffULL) << 16) | \
					(((__kprog_a64_ext_src >> 48) & 0xffULL) << 8) | \
					(((__kprog_a64_ext_src >> 56) & 0xffULL)); \
			} \
			break; \
		case 20U:                           \
			if (__kprog_a64_ext_width == ARM64_WIDTH_32) { \
				__kprog_a64_ext_result = \
					((__kprog_a64_ext_src & 0x00ff00ffULL) << 8) | \
					((__kprog_a64_ext_src & 0xff00ff00ULL) >> 8); \
			} else { \
				__kprog_a64_ext_result = \
					((__kprog_a64_ext_src \
					  & 0x00ff00ff00ff00ffULL) << 8) | \
					((__kprog_a64_ext_src \
					  & 0xff00ff00ff00ff00ULL) >> 8); \
			} \
			break; \
		case 21U:                           \
			__kprog_a64_ext_result = \
				(((__kprog_a64_ext_src & 0xffffULL) \
				  ^ 0x8000ULL) - 0x8000ULL); \
			break; \
		case 47U:                           \
			__kprog_a64_ext_result = \
				(((__kprog_a64_ext_src & 0xffffffffULL) \
				  ^ 0x80000000ULL) - 0x80000000ULL); \
			break; \
		case 60U:                           \
			__kprog_a64_ext_result = \
				(((__kprog_a64_ext_src & 0xffULL) \
				  ^ 0x80ULL) - 0x80ULL); \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		(OUTPUT) = __kprog_a64_ext_result; \
	} while (0)

#define KPROG_ARM64_EXTREV_VALUE(OP, SRC, SRC2, SHIFT, WIDTH, UNSUPPORTED) \
	({ __u64 __kprog_a64_ext_result_out; \
	   KPROG_ARM64_EXTREV_VALUE_INTO(__kprog_a64_ext_result_out, OP, SRC, SRC2, SHIFT, WIDTH, UNSUPPORTED); \
	   __kprog_a64_ext_result_out; })
#endif
