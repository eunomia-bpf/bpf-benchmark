/* Canonical simulator C; edit directly. Historical origin: generate_arm64_reg_presence_spec.py from arm64_reg_presence_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_REG_PRESENCE_H
#define KPROG_FORMAL_GENERATED_ARM64_REG_PRESENCE_H
/*
 * AArch64 write-register destination presence: a decoded register number is a
 * destination a write lands in unless it is the zero register (`31`,
 * `ARM64_XZR`) or the no-register sentinel (`0xff`, `ARM64_REG_NONE`).
 * `KProgFormal/Arm64RegPresence.lean` proves the presence test equals an
 * independent `decide (reg != 31 && reg != 0xff)`.
 */
/* The destination classes. */
#define KPROG_ARM64_REG_CLASS_GPR 0U
#define KPROG_ARM64_REG_CLASS_ZERO 1U
#define KPROG_ARM64_REG_CLASS_NONE 2U
/* The zero register and the no-register sentinel. */
#define KPROG_ARM64_REG_XZR 0x1fU
#define KPROG_ARM64_REG_NONE 0xffU
/*
 * REG is a decoded AArch64 register number. It is evaluated once; the result is
 * 1 exactly when a write to REG lands in a destination (a GPR), 0 for the zero
 * register and the no-register sentinel. No flags written.
 */
#define KPROG_ARM64_REG_WRITABLE(REG)                                       \
	((__u8)(((REG) != KPROG_ARM64_REG_XZR && (REG) != KPROG_ARM64_REG_NONE) \
		 ? 1 : 0))
/*
 * The class REG names: a GPR, the zero register or the no-register sentinel.
 * Evaluated once; no flags written.
 */
#define KPROG_ARM64_REG_CLASS(REG)                                          \
	((__u8)(((REG) == KPROG_ARM64_REG_XZR) ? KPROG_ARM64_REG_CLASS_ZERO \
		 : ((REG) == KPROG_ARM64_REG_NONE) ? KPROG_ARM64_REG_CLASS_NONE \
		 : KPROG_ARM64_REG_CLASS_GPR))
#endif
