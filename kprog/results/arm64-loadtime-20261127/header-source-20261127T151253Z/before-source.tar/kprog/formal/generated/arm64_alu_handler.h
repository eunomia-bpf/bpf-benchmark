/* Canonical simulator C; edit directly. Historical origin: generate_arm64_alu_handler_spec.py from arm64_alu_handler_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_ALU_HANDLER_H
#define KPROG_FORMAL_GENERATED_ARM64_ALU_HANDLER_H

#define KPROG_ARM64_ALU_USE_POINTER(WIDTH, OP, DST_IS_SP, SRC_IS_SCALAR) \
	((WIDTH) == ARM64_WIDTH_64 && (OP) == ARM64_ALU_ADD &&             \
	 !(DST_IS_SP) && !(SRC_IS_SCALAR))

#define KPROG_ARM64_ALU_USE_STACK_SUB(WIDTH, OP, DST_IS_SP, SRC_IS_STACK) \
	((WIDTH) == ARM64_WIDTH_64 && (OP) == ARM64_ALU_SUB && \
	 !(DST_IS_SP) && (SRC_IS_STACK))

#endif
