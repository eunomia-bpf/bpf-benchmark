/* Canonical simulator C; edit directly. Historical origin: generate_arm64_mem_write_arm_spec.py from arm64_mem_write_arm_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_MEM_WRITE_ARM_H
#define KPROG_FORMAL_GENERATED_ARM64_MEM_WRITE_ARM_H
/*
 * AArch64 store body-selection contract: the store helper
 * `ARM64_SIM_L_MEM_WRITE` writes a resolved access to one of two destinations,
 * selected from a closed pair of facts: whether the base register is the stack
 * pointer, and whether the base's resolved tag names a stack slot. When either
 * holds the access goes through the stack arena write helper
 * `ARM64_SIM_L_STACK_WRITE_TAG`; every other base goes through the plain
 * little-endian byte store `ARM64_SIM_L_STORE_ADDR` (the generated
 * `arm64_store_bytes.h` contract). This is the *same* predicate the load
 * dispatch `KPROG_ARM64_MEM_READ_SRC` (the generated `arm64_mem_dispatch.h`
 * contract) selects its stack source on; `KProgFormal/Arm64MemWriteArmShape.lean`
 * proves the generated `armOf` equal to an independent construction from the
 * facts and ties it to the load path's space/source table.
 * This header is included after the `ARM64_SIM_TAG_*` decodes, so the drift
 * checks bind the hand-written stack-tag name to the generated selection.
 */
/* The number of destinations the helper selects between. */
#define KPROG_ARM64_MEM_WRITE_ARM_COUNT 2U
#define KPROG_ARM64_MEM_WRITE_ARM_STACK 0U
#define KPROG_ARM64_MEM_WRITE_ARM_MEMORY 1U
/*
 * The destination a store selects: the stack arena body exactly when the base
 * register is the stack pointer or its tag names a stack slot, the plain byte
 * store otherwise. Both inputs are evaluated once.
 */
#define KPROG_ARM64_MEM_WRITE_ARM(BASE_IS_SP, TAG)                          \
	((__u8)(((BASE_IS_SP) || (TAG) == ARM64_SIM_TAG_STACK)              \
		 ? KPROG_ARM64_MEM_WRITE_ARM_STACK                       \
		 : KPROG_ARM64_MEM_WRITE_ARM_MEMORY))
_Static_assert(KPROG_ARM64_MEM_WRITE_ARM_COUNT == 2U,
	       "arm64 mem write arm count drift");
_Static_assert(KPROG_ARM64_MEM_WRITE_ARM_STACK != KPROG_ARM64_MEM_WRITE_ARM_MEMORY,
	       "arm64 mem write arm codes must be distinct");
_Static_assert(KPROG_ARM64_MEM_WRITE_ARM_STACK == 0U && KPROG_ARM64_MEM_WRITE_ARM_MEMORY == 1U,
	       "arm64 mem write arm code drift");
/* The selector must name each destination at its own fact pair. */
_Static_assert(KPROG_ARM64_MEM_WRITE_ARM(1, ARM64_SIM_TAG_SCALAR) == KPROG_ARM64_MEM_WRITE_ARM_STACK,
	       "arm64 mem write arm sp selection drift");
_Static_assert(KPROG_ARM64_MEM_WRITE_ARM(0, ARM64_SIM_TAG_STACK) == KPROG_ARM64_MEM_WRITE_ARM_STACK,
	       "arm64 mem write arm stack-tag selection drift");
_Static_assert(KPROG_ARM64_MEM_WRITE_ARM(1, ARM64_SIM_TAG_STACK) == KPROG_ARM64_MEM_WRITE_ARM_STACK,
	       "arm64 mem write arm sp tagged selection drift");
_Static_assert(KPROG_ARM64_MEM_WRITE_ARM(0, ARM64_SIM_TAG_SCALAR) == KPROG_ARM64_MEM_WRITE_ARM_MEMORY,
	       "arm64 mem write arm memory selection drift");
#endif
