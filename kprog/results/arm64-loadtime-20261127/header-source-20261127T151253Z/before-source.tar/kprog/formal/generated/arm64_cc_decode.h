/* Canonical simulator C; edit directly. Historical origin: generate_arm64_cc_decode_spec.py from arm64_cc_decode_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_CC_DECODE_H
#define KPROG_FORMAL_GENERATED_ARM64_CC_DECODE_H
/*
 * The AArch64 artifact encoder's textual condition mnemonics. Every mnemonic
 * selects an `ARM64_COND_*` code, whose numeric values are pinned by the
 * shared condition contract. There are 18 mnemonics for 15
 * predicates: `hs`/`lo` select `cs`/`cc`, and `nv` selects always-true `al`.
 */
_Static_assert(ARM64_COND_EQ == 0U, "AArch64 cc decode condition code drift");
_Static_assert(ARM64_COND_NE == 1U, "AArch64 cc decode condition code drift");
_Static_assert(ARM64_COND_CS == 2U, "AArch64 cc decode condition code drift");
_Static_assert(ARM64_COND_CC == 3U, "AArch64 cc decode condition code drift");
_Static_assert(ARM64_COND_MI == 4U, "AArch64 cc decode condition code drift");
_Static_assert(ARM64_COND_PL == 5U, "AArch64 cc decode condition code drift");
_Static_assert(ARM64_COND_VS == 6U, "AArch64 cc decode condition code drift");
_Static_assert(ARM64_COND_VC == 7U, "AArch64 cc decode condition code drift");
_Static_assert(ARM64_COND_HI == 8U, "AArch64 cc decode condition code drift");
_Static_assert(ARM64_COND_LS == 9U, "AArch64 cc decode condition code drift");
_Static_assert(ARM64_COND_GE == 10U, "AArch64 cc decode condition code drift");
_Static_assert(ARM64_COND_LT == 11U, "AArch64 cc decode condition code drift");
_Static_assert(ARM64_COND_GT == 12U, "AArch64 cc decode condition code drift");
_Static_assert(ARM64_COND_LE == 13U, "AArch64 cc decode condition code drift");
_Static_assert(ARM64_COND_AL == 14U, "AArch64 cc decode condition code drift");
#define KPROG_ARM64_CC_DECODE_MNEMONIC_COUNT 18U
#define KPROG_ARM64_CC_DECODE_CONDITION_COUNT 15U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_EQ 0U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_NE 1U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_CS 2U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_HS 3U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_CC 4U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_LO 5U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_MI 6U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_PL 7U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_VS 8U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_VC 9U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_HI 10U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_LS 11U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_GE 12U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_LT 13U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_GT 14U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_LE 15U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_AL 16U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_NV 17U
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_EQ "eq"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_NE "ne"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_CS "cs"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_HS "hs"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_CC "cc"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_LO "lo"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_MI "mi"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_PL "pl"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_VS "vs"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_VC "vc"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_HI "hi"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_LS "ls"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_GE "ge"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_LT "lt"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_GT "gt"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_LE "le"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_AL "al"
#define KPROG_ARM64_CC_DECODE_MNEMONIC_TEXT_NV "nv"
/*
 * The `ARM64_COND_*` code a mnemonic selects. The input is evaluated once. A
 * mnemonic code outside the table reaches the 0 default; the table is total
 * over its own mnemonic codes.
 */
#define KPROG_ARM64_CC_DECODE_COND(MNEMONIC)                                \
	((MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_EQ ? ARM64_COND_EQ : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_NE ? ARM64_COND_NE : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_CS ? ARM64_COND_CS : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_HS ? ARM64_COND_CS : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_CC ? ARM64_COND_CC : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_LO ? ARM64_COND_CC : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_MI ? ARM64_COND_MI : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_PL ? ARM64_COND_PL : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_VS ? ARM64_COND_VS : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_VC ? ARM64_COND_VC : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_HI ? ARM64_COND_HI : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_LS ? ARM64_COND_LS : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_GE ? ARM64_COND_GE : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_LT ? ARM64_COND_LT : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_GT ? ARM64_COND_GT : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_LE ? ARM64_COND_LE : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_AL ? ARM64_COND_AL : \
	 (MNEMONIC) == KPROG_ARM64_CC_DECODE_MNEMONIC_NV ? ARM64_COND_AL : \
	 0)
_Static_assert(KPROG_ARM64_CC_DECODE_MNEMONIC_COUNT == 18U,
	       "AArch64 cc decode mnemonic count drift");
_Static_assert(KPROG_ARM64_CC_DECODE_CONDITION_COUNT ==
	       15U,
	       "AArch64 cc decode condition count drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_EQ) == ARM64_COND_EQ, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_NE) == ARM64_COND_NE, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_CS) == ARM64_COND_CS, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_HS) == ARM64_COND_CS, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_CC) == ARM64_COND_CC, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_LO) == ARM64_COND_CC, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_MI) == ARM64_COND_MI, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_PL) == ARM64_COND_PL, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_VS) == ARM64_COND_VS, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_VC) == ARM64_COND_VC, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_HI) == ARM64_COND_HI, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_LS) == ARM64_COND_LS, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_GE) == ARM64_COND_GE, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_LT) == ARM64_COND_LT, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_GT) == ARM64_COND_GT, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_LE) == ARM64_COND_LE, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_AL) == ARM64_COND_AL, "AArch64 cc decode mnemonic selection drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_NV) == ARM64_COND_AL, "AArch64 cc decode mnemonic selection drift");
/* The selector is total: a mnemonic code past the table reaches the default. */
_Static_assert(KPROG_ARM64_CC_DECODE_COND(
	KPROG_ARM64_CC_DECODE_MNEMONIC_COUNT) == 0,
	       "AArch64 cc decode absent mnemonic must reach the default arm");
/* The aliases name the same condition as their canonical spelling. */
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_HS) == ARM64_COND_CS, "AArch64 cc decode alias drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_LO) == ARM64_COND_CC, "AArch64 cc decode alias drift");
_Static_assert(KPROG_ARM64_CC_DECODE_COND(KPROG_ARM64_CC_DECODE_MNEMONIC_NV) == ARM64_COND_AL, "AArch64 cc decode alias drift");
#endif
