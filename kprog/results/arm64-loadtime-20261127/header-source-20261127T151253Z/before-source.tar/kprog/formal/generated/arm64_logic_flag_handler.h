/* Canonical simulator C; edit directly. Historical origin: generate_arm64_logic_flag_handler_spec.py from arm64_logic_flag_handler_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_LOGIC_FLAG_HANDLER_H
#define KPROG_FORMAL_GENERATED_ARM64_LOGIC_FLAG_HANDLER_H

#define KPROG_ARM64_LOGIC_FAMILY_AND 2U
#define KPROG_ARM64_LOGIC_FAMILY_BIC 3U

#define KPROG_ARM64_EXEC_LOGIC_FLAGS(FAMILY, RESULT, C_N, C_Z, C_C, C_V, LHS, RHS, WIDTH, UNSUPPORTED) \
	do { \
		switch (FAMILY) { \
		case KPROG_ARM64_LOGIC_FAMILY_AND: \
			(RESULT) = KPROG_ALU64_RESULT(ARM64_ALU_AND, (LHS), (RHS), UNSUPPORTED); \
			break; \
		case KPROG_ARM64_LOGIC_FAMILY_BIC: \
			(RESULT) = KPROG_ALU64_RESULT(ARM64_ALU_BIC, (LHS), (RHS), UNSUPPORTED); \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		KPROG_ARM64_SET_LOGIC_FLAGS((C_N), (C_Z), (C_C), (C_V), (RESULT), (WIDTH)); \
	} while (0)

#endif
