/* Canonical simulator C; edit directly. Historical origin: generate_arm64_ccmp_handler_spec.py from arm64_ccmp_handler_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_CCMP_HANDLER_H
#define KPROG_FORMAL_GENERATED_ARM64_CCMP_HANDLER_H

#define KPROG_ARM64_EXEC_CCMP(COND, FALLBACK, C_N, C_Z, C_C, C_V, LHS, RHS, WIDTH, UNSUPPORTED) \
	do { \
		if (KPROG_ARM64_EVAL_COND((COND), (C_N), (C_Z), (C_C), (C_V), UNSUPPORTED)) { \
			KPROG_ARM64_SET_SUB_FLAGS((C_N), (C_Z), (C_C), (C_V), (LHS), (RHS), (WIDTH)); \
		} else { \
			__u8 __kprog_a64_ccmp_fallback = (FALLBACK); \
			(C_N) = (__kprog_a64_ccmp_fallback >> 3) & 1U; \
			(C_Z) = (__kprog_a64_ccmp_fallback >> 2) & 1U; \
			(C_C) = (__kprog_a64_ccmp_fallback >> 1) & 1U; \
			(C_V) = (__kprog_a64_ccmp_fallback >> 0) & 1U; \
		} \
	} while (0)

#endif
