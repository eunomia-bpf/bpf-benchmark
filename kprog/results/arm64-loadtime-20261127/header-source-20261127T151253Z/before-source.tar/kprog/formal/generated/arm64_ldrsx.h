/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_LDRSX_H
#define KPROG_FORMAL_GENERATED_ARM64_LDRSX_H
/*
 * The load width each sign-extending load opcode reads before sign-extending the
 * value into the destination: a byte for LDRSB, a halfword for LDRSH, a word for
 * LDRSW. This is the *load* width, fixed by the opcode and independent of the
 * destination access width, so a mislabeled load reads the wrong number of bytes.
 * An opcode outside the family reaches the caller-supplied unsupported arm.
 */
#include "arm64_width.h"
_Static_assert(ARM64_OP_LDRSB == 54U, "arm64 ldrsx code drift");
_Static_assert(ARM64_OP_LDRSW == 57U, "arm64 ldrsx code drift");
_Static_assert(ARM64_OP_LDRSH == 63U, "arm64 ldrsx code drift");
#define KPROG_ARM64_LDRSX_HANDLED(OP)                                       \
	(((OP) == ARM64_OP_LDRSB) || \
	((OP) == ARM64_OP_LDRSW) || \
	((OP) == ARM64_OP_LDRSH))
_Static_assert(KPROG_ARM64_LDRSX_HANDLED(ARM64_OP_LDRSB), "arm64 ldrsx coverage drift");
_Static_assert(KPROG_ARM64_LDRSX_HANDLED(ARM64_OP_LDRSW), "arm64 ldrsx coverage drift");
_Static_assert(KPROG_ARM64_LDRSX_HANDLED(ARM64_OP_LDRSH), "arm64 ldrsx coverage drift");
/*
 * The numeric case labels 54U, 57U, and 63U track the ARM64_OP_LDRSB,
 * ARM64_OP_LDRSW, and ARM64_OP_LDRSH values defined in
 * kprog/arm64/arm64_sim.h. OP is the opcode; OP is read once. The result is
 * the ARM64_WIDTH_* code of the value the load must read, which the handler then
 * sign-extends into the destination.
 */
#define KPROG_ARM64_LDRSX_LOAD_WIDTH_INTO(OUTPUT, OP, UNSUPPORTED)                       \
	do { \
		__u64 __kprog_a64_ldrsx_op = (OP); \
		__u64 __kprog_a64_ldrsx_width = 0; \
 \
		switch (__kprog_a64_ldrsx_op) { \
		case 54U:                           \
			__kprog_a64_ldrsx_width = ARM64_WIDTH_8; \
			break; \
		case 57U:                           \
			__kprog_a64_ldrsx_width = ARM64_WIDTH_32; \
			break; \
		case 63U:                           \
			__kprog_a64_ldrsx_width = ARM64_WIDTH_16; \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		(OUTPUT) = __kprog_a64_ldrsx_width; \
	} while (0)
#define KPROG_ARM64_LDRSX_LOAD_WIDTH(OP, UNSUPPORTED) \
    ({ __u64 __kprog_memory_helper_result; \
       KPROG_ARM64_LDRSX_LOAD_WIDTH_INTO(__kprog_memory_helper_result, (OP), UNSUPPORTED); \
       __kprog_memory_helper_result; })
#endif
