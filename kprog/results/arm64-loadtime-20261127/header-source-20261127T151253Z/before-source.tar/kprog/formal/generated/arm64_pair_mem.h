/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_PAIR_MEM_H
#define KPROG_FORMAL_GENERATED_ARM64_PAIR_MEM_H
/*
 * AArch64 `LDP` / `STP` pair-move contract. `LDP` moves two 64-bit slots into a
 * register pair (low slot into DST, high slot into SRC); `STP` moves a register
 * pair out to the same two slots (low from SRC, high from SRC2). The address
 * offset (MEM_BASE_OFF) and the pre/post base adjustment (MEM_PRE / MEM_POST)
 * stay in the macros with their own proved contracts, and the LDP tag-pair
 * probe is a separate MEM_READ_TAG composition; this contract fixes which two
 * slots each opcode transfers and in which order. Every slot is a full 64-bit
 * access.
 */
_Static_assert(ARM64_OP_LDP == 0x21U, "arm64 LDP/STP ldp opcode drift");
_Static_assert(ARM64_OP_STP == 0x22U, "arm64 LDP/STP stp opcode drift");
/*
 * The slot stride: every transferred slot is a 64-bit access, and the high slot
 * of a pair move follows the low slot by one slot stride.
 */
#define KPROG_ARM64_PAIR_MEM_SLOT_STRIDE ARM64_WIDTH_64
#define KPROG_ARM64_PAIR_MEM_HIGH_SLOT_STRIDE 8
_Static_assert(KPROG_ARM64_PAIR_MEM_SLOT_STRIDE == 8U,
	       "arm64 LDP/STP slot stride drift");
/*
 * The number of slots a pair move transfers: exactly two, the low slot then the
 * high slot.
 */
#define KPROG_ARM64_PAIR_MEM_SLOT_COUNT 2U
/*
 * Access direction of each opcode: 0 loads a register pair from memory, 1
 * stores a register pair to memory.
 */
#define KPROG_ARM64_PAIR_MEM_ACCESS_LOAD 0U
#define KPROG_ARM64_PAIR_MEM_ACCESS_STORE 1U
#define KPROG_ARM64_PAIR_MEM_OP_LDP_ACCESS KPROG_ARM64_PAIR_MEM_ACCESS_LOAD
#define KPROG_ARM64_PAIR_MEM_OP_STP_ACCESS KPROG_ARM64_PAIR_MEM_ACCESS_STORE
/*
 * The arm index of each opcode in the two-way `OP == LDP / STP` chain, decoded
 * from the opcode code so the chain order is a checked fact.
 */
#define KPROG_ARM64_PAIR_MEM_OP_LDP_INDEX 0U
#define KPROG_ARM64_PAIR_MEM_OP_STP_INDEX 1U
#define KPROG_ARM64_PAIR_MEM_INDEX_INTO(OUTPUT, OP) \
    do { \
        __u32 __kprog_a64_pair_idx; \
        if ((OP) == ARM64_OP_LDP) \
            __kprog_a64_pair_idx = 0U; \
        else \
            __kprog_a64_pair_idx = 1U; \
        (OUTPUT) = __kprog_a64_pair_idx; \
    } while (0)
#define KPROG_ARM64_PAIR_MEM_INDEX(OP) \
    ({ __u32 __kprog_transfer_index; \
       KPROG_ARM64_PAIR_MEM_INDEX_INTO(__kprog_transfer_index, (OP)); \
       __kprog_transfer_index; })

#endif
