/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_UNARY_H
#define KPROG_FORMAL_GENERATED_ARM64_UNARY_H
/*
 * The two arms are the AArch64 unary values the simulator applies to a source
 * register: MVN (bitwise complement) and NEG (two's-complement negation). Each
 * result is masked to the destination width, exactly the narrowing the caller's
 * register write performs. The complement/negation are inlined, so this header
 * calls no hand-written helper. An opcode outside the two reaches the
 * caller-supplied unsupported arm.
 */
#include "arm64_width.h"
_Static_assert(ARM64_OP_MVN == 15U, "arm64 unary code drift");
_Static_assert(ARM64_OP_NEG == 16U, "arm64 unary code drift");
#define KPROG_ARM64_UNARY_HANDLED(OP)                                       \
	(((OP) == ARM64_OP_MVN) || \
	((OP) == ARM64_OP_NEG))
_Static_assert(KPROG_ARM64_UNARY_HANDLED(ARM64_OP_MVN), "arm64 unary coverage drift");
_Static_assert(KPROG_ARM64_UNARY_HANDLED(ARM64_OP_NEG), "arm64 unary coverage drift");
/*
 * The numeric case labels 15U and 16U track the ARM64_OP_MVN/NEG values
 * defined in kprog/arm64/arm64_sim.h. OP is the opcode, VALUE the source
 * register contents and WIDTH the destination width code. VALUE is evaluated
 * exactly once and no arm writes NZCV. The result is the width-narrowed raw
 * 64-bit value the caller writes back.
 */
#define KPROG_ARM64_UNARY_VALUE_INTO(OUTPUT, OP, VALUE, WIDTH, UNSUPPORTED) \
	do { \
		__u64 __kprog_a64_un_op = (OP); \
		__u64 __kprog_a64_un_value = (VALUE); \
		__u64 __kprog_a64_un_width = (WIDTH); \
		__u64 __kprog_a64_un_wmask = KPROG_ARM64_WIDTH_MASK(__kprog_a64_un_width); \
		__u64 __kprog_a64_un_result = 0; \
 \
		switch (__kprog_a64_un_op) { \
		case 15U:                           \
			__kprog_a64_un_result = ~__kprog_a64_un_value & __kprog_a64_un_wmask; \
			break; \
		case 16U:                           \
			__kprog_a64_un_result = (__u64)(0ULL - __kprog_a64_un_value) & __kprog_a64_un_wmask; \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		(OUTPUT) = __kprog_a64_un_result; \
	} while (0)

#define KPROG_ARM64_UNARY_VALUE(OP, VALUE, WIDTH, UNSUPPORTED) \
	({ __u64 __kprog_a64_un_result_out; \
	   KPROG_ARM64_UNARY_VALUE_INTO(__kprog_a64_un_result_out, OP, VALUE, WIDTH, UNSUPPORTED); \
	   __kprog_a64_un_result_out; })
#endif
