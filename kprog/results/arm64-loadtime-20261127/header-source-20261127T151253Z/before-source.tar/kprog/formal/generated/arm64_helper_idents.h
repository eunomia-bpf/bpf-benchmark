/* Canonical simulator C; edit directly. Historical origin: generate_arm64_helper_idents_spec.py from arm64_helper_idents_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_HELPER_IDENTS_H
#define KPROG_FORMAL_GENERATED_ARM64_HELPER_IDENTS_H
/*
 * The AArch64 artifact encoder's BPF helper-ident table: the 95 kernel
 * ids the AArch64 simulator recognizes, in id-sorted order.
 * KPROG_ARM64_HELPER_ROW maps a kernel id to its 1-based position in that
 * order, 0 outside. Each name invokes its actual Linux helper ID.
 */
#define KPROG_ARM64_HELPER_IDENTS_COUNT 95U
/*
 * The 1-based position of a kernel id in the id-sorted table. The input is
 * evaluated once; an id outside the table reaches the 0 default.
 */
#define KPROG_ARM64_HELPER_ROW(KERNEL_ID)                                           \
	((KERNEL_ID) == 1 ? 1U : \
	 (KERNEL_ID) == 2 ? 2U : \
	 (KERNEL_ID) == 3 ? 3U : \
	 (KERNEL_ID) == 4 ? 4U : \
	 (KERNEL_ID) == 5 ? 5U : \
	 (KERNEL_ID) == 6 ? 6U : \
	 (KERNEL_ID) == 7 ? 7U : \
	 (KERNEL_ID) == 8 ? 8U : \
	 (KERNEL_ID) == 9 ? 9U : \
	 (KERNEL_ID) == 10 ? 10U : \
	 (KERNEL_ID) == 11 ? 11U : \
	 (KERNEL_ID) == 12 ? 12U : \
	 (KERNEL_ID) == 13 ? 13U : \
	 (KERNEL_ID) == 14 ? 14U : \
	 (KERNEL_ID) == 15 ? 15U : \
	 (KERNEL_ID) == 16 ? 16U : \
	 (KERNEL_ID) == 20 ? 17U : \
	 (KERNEL_ID) == 21 ? 18U : \
	 (KERNEL_ID) == 23 ? 19U : \
	 (KERNEL_ID) == 25 ? 20U : \
	 (KERNEL_ID) == 26 ? 21U : \
	 (KERNEL_ID) == 27 ? 22U : \
	 (KERNEL_ID) == 28 ? 23U : \
	 (KERNEL_ID) == 31 ? 24U : \
	 (KERNEL_ID) == 32 ? 25U : \
	 (KERNEL_ID) == 33 ? 26U : \
	 (KERNEL_ID) == 35 ? 27U : \
	 (KERNEL_ID) == 36 ? 28U : \
	 (KERNEL_ID) == 37 ? 29U : \
	 (KERNEL_ID) == 38 ? 30U : \
	 (KERNEL_ID) == 39 ? 31U : \
	 (KERNEL_ID) == 43 ? 32U : \
	 (KERNEL_ID) == 44 ? 33U : \
	 (KERNEL_ID) == 45 ? 34U : \
	 (KERNEL_ID) == 46 ? 35U : \
	 (KERNEL_ID) == 50 ? 36U : \
	 (KERNEL_ID) == 54 ? 37U : \
	 (KERNEL_ID) == 58 ? 38U : \
	 (KERNEL_ID) == 65 ? 39U : \
	 (KERNEL_ID) == 67 ? 40U : \
	 (KERNEL_ID) == 68 ? 41U : \
	 (KERNEL_ID) == 69 ? 42U : \
	 (KERNEL_ID) == 80 ? 43U : \
	 (KERNEL_ID) == 85 ? 44U : \
	 (KERNEL_ID) == 86 ? 45U : \
	 (KERNEL_ID) == 87 ? 46U : \
	 (KERNEL_ID) == 88 ? 47U : \
	 (KERNEL_ID) == 95 ? 48U : \
	 (KERNEL_ID) == 99 ? 49U : \
	 (KERNEL_ID) == 105 ? 50U : \
	 (KERNEL_ID) == 109 ? 51U : \
	 (KERNEL_ID) == 112 ? 52U : \
	 (KERNEL_ID) == 113 ? 53U : \
	 (KERNEL_ID) == 114 ? 54U : \
	 (KERNEL_ID) == 115 ? 55U : \
	 (KERNEL_ID) == 118 ? 56U : \
	 (KERNEL_ID) == 122 ? 57U : \
	 (KERNEL_ID) == 124 ? 58U : \
	 (KERNEL_ID) == 125 ? 59U : \
	 (KERNEL_ID) == 127 ? 60U : \
	 (KERNEL_ID) == 130 ? 61U : \
	 (KERNEL_ID) == 131 ? 62U : \
	 (KERNEL_ID) == 132 ? 63U : \
	 (KERNEL_ID) == 133 ? 64U : \
	 (KERNEL_ID) == 148 ? 65U : \
	 (KERNEL_ID) == 152 ? 66U : \
	 (KERNEL_ID) == 154 ? 67U : \
	 (KERNEL_ID) == 155 ? 68U : \
	 (KERNEL_ID) == 158 ? 69U : \
	 (KERNEL_ID) == 160 ? 70U : \
	 (KERNEL_ID) == 161 ? 71U : \
	 (KERNEL_ID) == 163 ? 72U : \
	 (KERNEL_ID) == 173 ? 73U : \
	 (KERNEL_ID) == 174 ? 74U : \
	 (KERNEL_ID) == 175 ? 75U : \
	 (KERNEL_ID) == 181 ? 76U : \
	 (KERNEL_ID) == 182 ? 77U : \
	 (KERNEL_ID) == 183 ? 78U : \
	 (KERNEL_ID) == 184 ? 79U : \
	 (KERNEL_ID) == 185 ? 80U : \
	 (KERNEL_ID) == 186 ? 81U : \
	 (KERNEL_ID) == 188 ? 82U : \
	 (KERNEL_ID) == 189 ? 83U : \
	 (KERNEL_ID) == 190 ? 84U : \
	 (KERNEL_ID) == 191 ? 85U : \
	 (KERNEL_ID) == 193 ? 86U : \
	 (KERNEL_ID) == 194 ? 87U : \
	 (KERNEL_ID) == 195 ? 88U : \
	 (KERNEL_ID) == 197 ? 89U : \
	 (KERNEL_ID) == 198 ? 90U : \
	 (KERNEL_ID) == 199 ? 91U : \
	 (KERNEL_ID) == 200 ? 92U : \
	 (KERNEL_ID) == 201 ? 93U : \
	 (KERNEL_ID) == 202 ? 94U : \
	 (KERNEL_ID) == 203 ? 95U : \
	 0)
_Static_assert(KPROG_ARM64_HELPER_IDENTS_COUNT == 95U,
	       "AArch64 helper idents count drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(1) == 1U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(2) == 2U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(3) == 3U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(4) == 4U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(5) == 5U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(6) == 6U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(7) == 7U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(8) == 8U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(9) == 9U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(10) == 10U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(11) == 11U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(12) == 12U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(13) == 13U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(14) == 14U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(15) == 15U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(16) == 16U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(20) == 17U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(21) == 18U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(23) == 19U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(25) == 20U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(26) == 21U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(27) == 22U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(28) == 23U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(31) == 24U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(32) == 25U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(33) == 26U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(35) == 27U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(36) == 28U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(37) == 29U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(38) == 30U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(39) == 31U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(43) == 32U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(44) == 33U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(45) == 34U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(46) == 35U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(50) == 36U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(54) == 37U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(58) == 38U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(65) == 39U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(67) == 40U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(68) == 41U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(69) == 42U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(80) == 43U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(85) == 44U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(86) == 45U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(87) == 46U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(88) == 47U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(95) == 48U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(99) == 49U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(105) == 50U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(109) == 51U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(112) == 52U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(113) == 53U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(114) == 54U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(115) == 55U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(118) == 56U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(122) == 57U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(124) == 58U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(125) == 59U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(127) == 60U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(130) == 61U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(131) == 62U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(132) == 63U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(133) == 64U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(148) == 65U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(152) == 66U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(154) == 67U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(155) == 68U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(158) == 69U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(160) == 70U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(161) == 71U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(163) == 72U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(173) == 73U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(174) == 74U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(175) == 75U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(181) == 76U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(182) == 77U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(183) == 78U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(184) == 79U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(185) == 80U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(186) == 81U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(188) == 82U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(189) == 83U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(190) == 84U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(191) == 85U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(193) == 86U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(194) == 87U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(195) == 88U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(197) == 89U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(198) == 90U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(199) == 91U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(200) == 92U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(201) == 93U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(202) == 94U, "AArch64 helper idents row selection drift");
_Static_assert(KPROG_ARM64_HELPER_ROW(203) == 95U, "AArch64 helper idents row selection drift");
/* The selector is total: a kernel id past the table reaches the default. */
_Static_assert(KPROG_ARM64_HELPER_ROW(0x100) == 0U,
	       "AArch64 helper idents out-of-range id must reach the default arm");
#endif
