/* Canonical simulator C; edit directly. Historical origin: generate_arm64_helper_arg_ptr_spec.py from arm64_helper_arg_ptr_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_HELPER_ARG_PTR_H
#define KPROG_FORMAL_GENERATED_ARM64_HELPER_ARG_PTR_H
/*
 * AArch64 BPF helper-argument pointer contract: the BPF helper-argument
 * pointer helper `ARM64_SIM_L_HELPER_ARG_PTR` resolves the pointer a BPF
 * helper call receives in a register argument, and its source is selected
 * from the single closed fact: whether the register's provenance tag is the
 * stack tag. The stack arena pointer source (a stack-tagged register)
 * resolves to the arena byte at the register pointer's biased arena index;
 * the raw pointer source (every other tag) passes the register's raw pointer
 * value through unchanged. `KProgFormal/Arm64HelperArgPtrShape.lean` proves
 * the generated `sourceOf` equal to an independent 2-way statement and ties
 * the stack arena pointer source to the `KPROG_ARM64_STACK_INDEX` biased
 * pointer index. The fact is closed, so the 2-way selection is total. This
 * header uses only literal inputs, so it is included before the
 * `ARM64_SIM_TAG_*` tag names in the simulator header.
 */
/* The number of pointer sources the helper selects between. */
#define KPROG_ARM64_HELPER_ARG_PTR_BODY_COUNT 2U
#define KPROG_ARM64_HELPER_ARG_PTR_BODY_STACK_ARENA_PTR 0U
#define KPROG_ARM64_HELPER_ARG_PTR_BODY_RAW_PTR 1U
/*
 * The pointer source a BPF helper-argument register selects: the stack arena
 * pointer source exactly when the register's provenance tag is the stack tag,
 * the raw pointer otherwise. The input is evaluated once and no NZCV is
 * written.
 */
#define KPROG_ARM64_HELPER_ARG_PTR_BODY(IS_STACK_TAGGED)                  \
	((__u8)(((IS_STACK_TAGGED)) ? KPROG_ARM64_HELPER_ARG_PTR_BODY_STACK_ARENA_PTR : KPROG_ARM64_HELPER_ARG_PTR_BODY_RAW_PTR))
_Static_assert(KPROG_ARM64_HELPER_ARG_PTR_BODY_COUNT == 2U,
	       "arm64 helper arg pointer body count drift");
_Static_assert(KPROG_ARM64_HELPER_ARG_PTR_BODY_STACK_ARENA_PTR != KPROG_ARM64_HELPER_ARG_PTR_BODY_RAW_PTR,
	       "arm64 helper arg pointer codes must be distinct");
_Static_assert(KPROG_ARM64_HELPER_ARG_PTR_BODY_STACK_ARENA_PTR == 0U && KPROG_ARM64_HELPER_ARG_PTR_BODY_RAW_PTR == 1U,
	       "arm64 helper arg pointer code drift");
/* The selector must name each source at its own fact. */
_Static_assert(KPROG_ARM64_HELPER_ARG_PTR_BODY(1) == KPROG_ARM64_HELPER_ARG_PTR_BODY_STACK_ARENA_PTR,
	       "arm64 helper arg pointer stack tagged selection drift");
_Static_assert(KPROG_ARM64_HELPER_ARG_PTR_BODY(0) == KPROG_ARM64_HELPER_ARG_PTR_BODY_RAW_PTR,
	       "arm64 helper arg pointer not stack tagged selection drift");
#endif
