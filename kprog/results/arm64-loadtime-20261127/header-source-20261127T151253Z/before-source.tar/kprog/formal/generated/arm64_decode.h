/* Canonical simulator C; edit directly. Historical origin: generate_arm64_decode_spec.py from arm64_decode_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_DECODE_H
#define KPROG_FORMAL_GENERATED_ARM64_DECODE_H
#define ARM64_ALU_ADD 0U
#define ARM64_ALU_SUB 1U
#define ARM64_ALU_AND 2U
#define ARM64_ALU_BIC 3U
#define ARM64_ALU_EOR 4U
#define ARM64_ALU_ORR 5U

#define ARM64_SHIFT_LSL 0U
#define ARM64_SHIFT_LSR 1U
#define ARM64_SHIFT_ASR 2U
#define ARM64_SHIFT_ROR 3U

#define ARM64_MOD_NONE 0U
#define ARM64_MOD_LSL 1U
#define ARM64_MOD_LSR 2U
#define ARM64_MOD_ASR 3U
#define ARM64_MOD_ROR 4U
#define ARM64_MOD_UXTW 5U
#define ARM64_MOD_SXTW 6U
#define ARM64_MOD_UXTH 7U
#define ARM64_MOD_SXTH 8U
#define ARM64_MOD_UXTB 9U
#define ARM64_MOD_SXTB 10U

#define ARM64_BITFIELD_UBFX 0U
#define ARM64_BITFIELD_SBFX 1U
#define ARM64_BITFIELD_UBFIZ 2U
#define ARM64_BITFIELD_BFXIL 3U
#define ARM64_BITFIELD_BFI 4U
#endif
