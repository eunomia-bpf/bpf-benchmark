/* Canonical simulator C; edit directly. Historical origin: generate_arm64_branch_emit_spec.py from arm64_branch_emit_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_BRANCH_EMIT_H
#define KPROG_FORMAL_GENERATED_ARM64_BRANCH_EMIT_H
/*
 * AArch64 branch-emission shape: the generator emits a backward edge
 * (target <= current) as an inverted conditional jump to a local fall-through
 * label followed by an unconditional jump, and a forward edge as a plain
 * conditional jump with a fall-through. Both select the same next PC, which
 * KProgFormal/Arm64BranchEmit.lean proves equals the architectural branchPc.
 */
#define KPROG_ARM64_BRANCH_BACKWARD(CURRENT, TARGET)                        \
	((__u8)(((TARGET) <= (CURRENT)) ? 1 : 0))
#endif
