/* Canonical simulator C. Edit directly; export the Lean AST with clightgen. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_CSEL_PTR_H
#define KPROG_FORMAL_GENERATED_ARM64_CSEL_PTR_H
/*
 * The pointer-path decision shared by the eight AArch64 conditional-select
 * opcodes: whether the destination is written by the tag-copy register write
 * (which carries the selected source register's provenance) or by a
 * width-narrowed scalar write (which drops it). Only the plain CSEL at
 * doubleword width preserves provenance. An opcode outside the family reaches
 * the caller-supplied unsupported arm.
 */
#include "arm64_width.h"
_Static_assert(ARM64_OP_CSEL == 28U, "arm64 csel-ptr code drift");
_Static_assert(ARM64_OP_CINC == 29U, "arm64 csel-ptr code drift");
_Static_assert(ARM64_OP_CSET == 30U, "arm64 csel-ptr code drift");
_Static_assert(ARM64_OP_CINV == 52U, "arm64 csel-ptr code drift");
_Static_assert(ARM64_OP_CSINV == 61U, "arm64 csel-ptr code drift");
_Static_assert(ARM64_OP_CSINC == 62U, "arm64 csel-ptr code drift");
_Static_assert(ARM64_OP_CSETM == 68U, "arm64 csel-ptr code drift");
_Static_assert(ARM64_OP_CSNEG == 69U, "arm64 csel-ptr code drift");
/*
 * OP is one of the eight ARM64_OP_CS* codes and WIDTH the access width code; OP
 * and WIDTH are each read once. The result is 1 when the destination must be
 * written through ARM64_SIM_L_WRITE_REG_PTR_TAG (copying the selected source
 * register's tag) and 0 when it must be written through
 * ARM64_SIM_L_WRITE_REG_WIDTH (dropping the tag).
 */
#define KPROG_ARM64_CSEL_PTR_TAG_PATH_DECL(NAME, OP, WIDTH, UNSUPPORTED) \
		__u64 __kprog_a64_cp_op = (OP); \
		__u64 __kprog_a64_cp_width = (WIDTH); \
		__u64 NAME = 0; \
 \
		switch (__kprog_a64_cp_op) { \
		case 28U: \
			NAME = (__kprog_a64_cp_width == ARM64_WIDTH_64); \
			break; \
		case 29U: \
			NAME = 0; \
			break; \
		case 30U: \
			NAME = 0; \
			break; \
		case 52U: \
			NAME = 0; \
			break; \
		case 61U: \
			NAME = 0; \
			break; \
		case 62U: \
			NAME = 0; \
			break; \
		case 68U: \
			NAME = 0; \
			break; \
		case 69U: \
			NAME = 0; \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		}
#define KPROG_ARM64_CSEL_PTR_TAG_PATH_INTO(OUTPUT, OP, WIDTH, UNSUPPORTED) \
    do { KPROG_ARM64_CSEL_PTR_TAG_PATH_DECL(__kprog_a64_cp_path, OP, WIDTH, UNSUPPORTED); \
         (OUTPUT)=__kprog_a64_cp_path; } while (0)
#define KPROG_ARM64_CSEL_PTR_TAG_PATH(OP, WIDTH, UNSUPPORTED) \
    ({ KPROG_ARM64_CSEL_PTR_TAG_PATH_DECL(__kprog_a64_cp_path, OP, WIDTH, UNSUPPORTED); \
       __kprog_a64_cp_path; })
#endif
