/* Canonical simulator C; edit directly. Historical origin: generate_arm64_stack_write_tag_action_spec.py from arm64_stack_write_tag_action_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_STACK_WRITE_TAG_ACTION_H
#define KPROG_FORMAL_GENERATED_ARM64_STACK_WRITE_TAG_ACTION_H
/*
 * AArch64 stack slot-tag write action contract: the stack write helper
 * `ARM64_SIM_L_STACK_WRITE_TAG` writes a resolved access into the stack arena's
 * byte window and the per-slot tag array, and its action is selected from a
 * closed pair of facts: whether the access width is 64 bits and whether the
 * stack slot is 8-aligned. The word-and-tag action (64-bit at a qword-aligned
 * slot) writes the qword and stores the write's slot tag; the clear-and-write-
 * bytes action (an aligned sub-qword access) clears the slot tag to the scalar
 * marker and writes the width's active byte lanes; the plain byte-ladder write
 * (any unaligned access) writes the width's active byte lanes with the slot tag
 * untouched. `KProgFormal/Arm64StackWriteTagActionShape.lean` proves the
 * generated `actionOf` equal to an independent 3-way statement and ties the
 * word/tag arm to the read-side `KPROG_ARM64_STACK_TAG` slot-tag predicate and
 * the byte arms to the `KPROG_ARM64_STACK_WRITE_LANE_ACTIVE` ladder. The two
 * facts are a closed pair, so the 3-way selection is total.
 * This header uses only literal inputs, so it is included before the
 * `ARM64_WIDTH_*` decodes and the `ARM64_SIM_TAG_*` tag names in the
 * simulator header.
 */
/* The number of slot-tag actions the helper selects between. */
#define KPROG_ARM64_STACK_WRITE_TAG_ACTION_COUNT 3U
#define KPROG_ARM64_STACK_WRITE_TAG_ACTION_WRITE_WORD_AND_TAG 0U
#define KPROG_ARM64_STACK_WRITE_TAG_ACTION_CLEAR_TAG_AND_WRITE_BYTES 1U
#define KPROG_ARM64_STACK_WRITE_TAG_ACTION_WRITE_BYTES_NO_TAG 2U
/*
 * The slot-tag action a stack write selects: the word-and-tag action exactly
 * when the width is 64-bit and the slot is 8-aligned, the clear-and-write-bytes
 * action at every aligned sub-qword access, and the plain byte-ladder write
 * otherwise. Both inputs are evaluated once and no NZCV is written.
 */
#define KPROG_ARM64_STACK_WRITE_TAG_ACTION(IS_W64, IS_ALIGNED)            \
	((__u8)(((IS_W64) && (IS_ALIGNED))                        \
		 ? KPROG_ARM64_STACK_WRITE_TAG_ACTION_WRITE_WORD_AND_TAG                              \
		 : (((IS_ALIGNED))                               \
		 ? KPROG_ARM64_STACK_WRITE_TAG_ACTION_CLEAR_TAG_AND_WRITE_BYTES                              \
		 : KPROG_ARM64_STACK_WRITE_TAG_ACTION_WRITE_BYTES_NO_TAG)))
_Static_assert(KPROG_ARM64_STACK_WRITE_TAG_ACTION_COUNT == 3U,
	       "arm64 stack write tag action count drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_TAG_ACTION_WRITE_WORD_AND_TAG != KPROG_ARM64_STACK_WRITE_TAG_ACTION_CLEAR_TAG_AND_WRITE_BYTES,
	       "arm64 stack write tag action codes must be distinct");
_Static_assert(KPROG_ARM64_STACK_WRITE_TAG_ACTION_WRITE_WORD_AND_TAG != KPROG_ARM64_STACK_WRITE_TAG_ACTION_WRITE_BYTES_NO_TAG,
	       "arm64 stack write tag action codes must be distinct");
_Static_assert(KPROG_ARM64_STACK_WRITE_TAG_ACTION_CLEAR_TAG_AND_WRITE_BYTES != KPROG_ARM64_STACK_WRITE_TAG_ACTION_WRITE_BYTES_NO_TAG,
	       "arm64 stack write tag action codes must be distinct");
_Static_assert(KPROG_ARM64_STACK_WRITE_TAG_ACTION_WRITE_WORD_AND_TAG == 0U && KPROG_ARM64_STACK_WRITE_TAG_ACTION_CLEAR_TAG_AND_WRITE_BYTES == 1U && KPROG_ARM64_STACK_WRITE_TAG_ACTION_WRITE_BYTES_NO_TAG == 2U,
	       "arm64 stack write tag action code drift");
/* The selector must name each action at its own fact pair. */
_Static_assert(KPROG_ARM64_STACK_WRITE_TAG_ACTION(1, 1) == KPROG_ARM64_STACK_WRITE_TAG_ACTION_WRITE_WORD_AND_TAG,
	       "arm64 stack write tag action w64 aligned selection drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_TAG_ACTION(1, 0) == KPROG_ARM64_STACK_WRITE_TAG_ACTION_WRITE_BYTES_NO_TAG,
	       "arm64 stack write tag action w64 unaligned selection drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_TAG_ACTION(0, 1) == KPROG_ARM64_STACK_WRITE_TAG_ACTION_CLEAR_TAG_AND_WRITE_BYTES,
	       "arm64 stack write tag action aligned scalar selection drift");
_Static_assert(KPROG_ARM64_STACK_WRITE_TAG_ACTION(0, 0) == KPROG_ARM64_STACK_WRITE_TAG_ACTION_WRITE_BYTES_NO_TAG,
	       "arm64 stack write tag action unaligned scalar selection drift");
#endif
