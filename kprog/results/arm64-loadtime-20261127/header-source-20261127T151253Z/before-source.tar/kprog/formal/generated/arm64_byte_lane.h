/* Canonical simulator C; edit directly. Historical origin: generate_arm64_byte_lane_spec.py from arm64_byte_lane_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_BYTE_LANE_H
#define KPROG_FORMAL_GENERATED_ARM64_BYTE_LANE_H
/*
 * AArch64 byte-lane extraction: the byte a lane takes from a 64-bit word. This
 * is the inverse of the generated little-endian load ladder: the ladder
 * reassembles exactly these lanes, which KProgFormal/Arm64ByteLane.lean proves.
 * The eight lanes are the closed set the stack byte scatter uses; a lane outside
 * 0..7 reaches the caller-supplied unsupported arm.
 */
/*
 * LANE is the byte lane 0..7 and VALUE the 64-bit source word. VALUE is
 * evaluated exactly once and no NZCV is written. The result is a __u8 byte.
 */
#define KPROG_ARM64_BYTE_AT_INTO(OUTPUT, LANE, VALUE, UNSUPPORTED)                       \
	do { \
		__u64 __kprog_a64_bl_lane = (LANE); \
		__u64 __kprog_a64_bl_value = (VALUE); \
		__u64 __kprog_a64_bl_shift = 0; \
 \
		switch (__kprog_a64_bl_lane) { \
		case 0U:                           \
			__kprog_a64_bl_shift = 0; \
			break; \
		case 1U:                           \
			__kprog_a64_bl_shift = 8; \
			break; \
		case 2U:                           \
			__kprog_a64_bl_shift = 16; \
			break; \
		case 3U:                           \
			__kprog_a64_bl_shift = 24; \
			break; \
		case 4U:                           \
			__kprog_a64_bl_shift = 32; \
			break; \
		case 5U:                           \
			__kprog_a64_bl_shift = 40; \
			break; \
		case 6U:                           \
			__kprog_a64_bl_shift = 48; \
			break; \
		case 7U:                           \
			__kprog_a64_bl_shift = 56; \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		(OUTPUT) = (__u8)(__kprog_a64_bl_value >> __kprog_a64_bl_shift); \
	} while (0)
#define KPROG_ARM64_BYTE_AT(LANE, VALUE, UNSUPPORTED) \
    ({ __u8 __kprog_a64_byte_result; \
       KPROG_ARM64_BYTE_AT_INTO(__kprog_a64_byte_result, (LANE), (VALUE), UNSUPPORTED); \
       __kprog_a64_byte_result; })
#endif
