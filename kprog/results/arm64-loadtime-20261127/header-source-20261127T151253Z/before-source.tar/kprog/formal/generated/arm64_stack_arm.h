/* Canonical simulator C; edit directly. Historical origin: generate_arm64_stack_arm_spec.py from arm64_stack_arm_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_STACK_ARM_H
#define KPROG_FORMAL_GENERATED_ARM64_STACK_ARM_H
/*
 * AArch64 stack word-path/byte-ladder body-selection contract: the stack
 * helper `ARM64_SIM_L_STACK_READ` selects between two bodies from a closed pair
 * of facts: whether the resolved access width is the full 8 (64-bit)
 * code, and whether the resolved stack index is qword-aligned. Only when both
 * hold does the helper touch the word arena `q[INDEX >> 3]`, covering exactly
 * the byte window; every other width and every unaligned index goes through the
 * little-endian byte ladder over `b[]`. `KProgFormal/Arm64StackArmShape.lean`
 * proves the generated `armOf` equal to an independent construction from the
 * width and alignment facts, tied to the `Arm64Width` 64-bit code and the
 * `Arm64StackArena` alignment guard.
 * This header is included after the `ARM64_WIDTH_*` decodes and the
 * `arm64_stack_arena.h` guard, so the drift checks bind the hand-written 64-bit
 * code to the generated table.
 */
/* The full 64-bit width code the word body is selected at. */
#define KPROG_ARM64_STACK_ARM_WIDTH64 8U
/* The number of bodies the helper selects between. */
#define KPROG_ARM64_STACK_ARM_COUNT 2U
#define KPROG_ARM64_STACK_ARM_WORD 1U
#define KPROG_ARM64_STACK_ARM_BYTE 0U
/*
 * The body a 64-bit test and an alignment test select: the word-arena body
 * exactly when the access is 64-bit and the resolved index is qword-aligned,
 * the byte-ladder body otherwise. Both inputs are evaluated once.
 */
#define KPROG_ARM64_STACK_ARM(IS_W64, IS_ALIGNED)                           \
	((__u8)(((IS_W64) && (IS_ALIGNED)) ? 1 : 0))
_Static_assert(KPROG_ARM64_STACK_ARM_WIDTH64 == 8U,
	       "arm64 stack arm 64-bit width code drift");
_Static_assert(ARM64_WIDTH_64 == KPROG_ARM64_STACK_ARM_WIDTH64,
	       "arm64 stack arm 64-bit width code drift");
_Static_assert(KPROG_ARM64_STACK_ARM_COUNT == 2U,
	       "arm64 stack arm count drift");
_Static_assert(KPROG_ARM64_STACK_ARM_WORD != KPROG_ARM64_STACK_ARM_BYTE,
	       "arm64 stack arm codes must be distinct");
_Static_assert(KPROG_ARM64_STACK_ARM_WORD == 1U && KPROG_ARM64_STACK_ARM_BYTE == 0U,
	       "arm64 stack arm code drift");
/* The selector must name each body at its own width/alignment pair. */
_Static_assert(KPROG_ARM64_STACK_ARM(1, 1) == KPROG_ARM64_STACK_ARM_WORD,
	       "arm64 stack arm word selection drift");
_Static_assert(KPROG_ARM64_STACK_ARM(1, 0) == KPROG_ARM64_STACK_ARM_BYTE,
	       "arm64 stack arm unaligned selection drift");
_Static_assert(KPROG_ARM64_STACK_ARM(0, 1) == KPROG_ARM64_STACK_ARM_BYTE,
	       "arm64 stack arm narrow selection drift");
_Static_assert(KPROG_ARM64_STACK_ARM(0, 0) == KPROG_ARM64_STACK_ARM_BYTE,
	       "arm64 stack arm narrow unaligned selection drift");
#endif
