/* Canonical simulator C; edit directly. Historical origin: generate_arm64_flag_handler_spec.py from arm64_flag_handler_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_FLAG_HANDLER_H
#define KPROG_FORMAL_GENERATED_ARM64_FLAG_HANDLER_H

#define KPROG_ARM64_ARITH_FAMILY_ADD 0U
#define KPROG_ARM64_ARITH_FAMILY_SUB 1U

#define KPROG_ARM64_EXEC_ARITH_WRITEBACK(FAMILY, RESULT, C_N, C_Z, C_C, C_V, LHS, RHS, WIDTH, UNSUPPORTED) \
	do { \
		switch (FAMILY) { \
		case KPROG_ARM64_ARITH_FAMILY_ADD: \
			(RESULT) = KPROG_ALU64_RESULT(ARM64_ALU_ADD, (LHS), (RHS), UNSUPPORTED); \
			KPROG_ARM64_SET_ADD_FLAGS((C_N), (C_Z), (C_C), (C_V), (LHS), (RHS), (WIDTH)); \
			break; \
		case KPROG_ARM64_ARITH_FAMILY_SUB: \
			(RESULT) = KPROG_ALU64_RESULT(ARM64_ALU_SUB, (LHS), (RHS), UNSUPPORTED); \
			KPROG_ARM64_SET_SUB_FLAGS((C_N), (C_Z), (C_C), (C_V), (LHS), (RHS), (WIDTH)); \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
	} while (0)

#define KPROG_ARM64_EXEC_ARITH_COMPARE(FAMILY, C_N, C_Z, C_C, C_V, LHS, RHS, WIDTH, UNSUPPORTED) \
	do { \
		switch (FAMILY) { \
		case KPROG_ARM64_ARITH_FAMILY_ADD: \
			KPROG_ARM64_SET_ADD_FLAGS((C_N), (C_Z), (C_C), (C_V), (LHS), (RHS), (WIDTH)); \
			break; \
		case KPROG_ARM64_ARITH_FAMILY_SUB: \
			KPROG_ARM64_SET_SUB_FLAGS((C_N), (C_Z), (C_C), (C_V), (LHS), (RHS), (WIDTH)); \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
	} while (0)

#endif
