/* Canonical simulator C; edit directly. Historical origin: generate_arm64_stack_tag_spec.py from arm64_stack_tag_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_STACK_TAG_H
#define KPROG_FORMAL_GENERATED_ARM64_STACK_TAG_H
/*
 * AArch64 stack slot-tag selection. Only a 64-bit access at a qword-aligned
 * stack slot carries the slot's stored tag; every other access is scalar. The
 * two conditions are a closed pair, so the predicate is total.
 */
/*
 * IS_W64 is true when the access width is 64 bits; IS_ALIGNED is true when the
 * stack slot index is 8-aligned. Both inputs are evaluated once and no NZCV is
 * written. The result is 1 when the slot tag applies, 0 otherwise.
 */
#define KPROG_ARM64_STACK_TAG(IS_W64, IS_ALIGNED)                           \
	((__u8)(((IS_W64) && (IS_ALIGNED)) ? 1 : 0))
#endif
