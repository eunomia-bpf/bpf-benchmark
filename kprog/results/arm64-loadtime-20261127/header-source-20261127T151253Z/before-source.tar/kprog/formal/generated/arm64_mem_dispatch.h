/* Canonical simulator C; edit directly. Historical origin: generate_arm64_mem_dispatch_spec.py from arm64_mem_dispatch_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_MEM_DISPATCH_H
#define KPROG_FORMAL_GENERATED_ARM64_MEM_DISPATCH_H
/*
 * AArch64 memory access-dispatch classification. The four memory spaces and the
 * two width cases are a closed table, so each predicate is total and has no
 * unsupported arm. `KPROG_ARM64_MEM_SRC_*` names the value source the read path
 * must use; `KPROG_ARM64_MEM_TAG_*` names the result-tag source (the ABI tag
 * itself is still computed by KPROG_ABI_LOAD_TAG).
 */
#define KPROG_ARM64_MEM_SRC_STACK 0U
#define KPROG_ARM64_MEM_SRC_ABI_PTR_LOAD 1U
#define KPROG_ARM64_MEM_SRC_RELOC_PTR 2U
#define KPROG_ARM64_MEM_SRC_NORMAL_LOAD 3U
#define KPROG_ARM64_MEM_TAG_STACK 0U
#define KPROG_ARM64_MEM_TAG_ABI 1U
#define KPROG_ARM64_MEM_TAG_MAP_PTR 2U
#define KPROG_ARM64_MEM_TAG_SCALAR 3U
/*
 * BASE_IS_SP is true for the stack pointer; TAG is the base register's memory
 * tag; WIDTH is the ARM64_WIDTH_* access code. Each predicate evaluates its
 * inputs and writes no NZCV.
 */
#define KPROG_ARM64_MEM_READ_SRC_INTO(OUTPUT, BASE_IS_SP, TAG, WIDTH)                    \
	do {                                                                 \
		__u8 __kprog_a64_md_src;                                      \
		if ((BASE_IS_SP) || (TAG) == ARM64_SIM_TAG_STACK)              \
			__kprog_a64_md_src = KPROG_ARM64_MEM_SRC_STACK;            \
		else if ((TAG) == ARM64_SIM_TAG_ABI &&                    \
			 (WIDTH) == ARM64_WIDTH_64)                             \
			__kprog_a64_md_src = KPROG_ARM64_MEM_SRC_ABI_PTR_LOAD;              \
		else if ((TAG) == ARM64_SIM_TAG_RELOC_ADDR &&                    \
			 (WIDTH) == ARM64_WIDTH_64)                             \
			__kprog_a64_md_src = KPROG_ARM64_MEM_SRC_RELOC_PTR;              \
		else                                                        \
			__kprog_a64_md_src = KPROG_ARM64_MEM_SRC_NORMAL_LOAD;       \
		(OUTPUT) = __kprog_a64_md_src;                                         \
	} while (0)
#define KPROG_ARM64_MEM_READ_SRC(BASE_IS_SP, TAG, WIDTH) \
    ({ __u8 __kprog_address_result; \
       KPROG_ARM64_MEM_READ_SRC_INTO(__kprog_address_result, (BASE_IS_SP), (TAG), (WIDTH)); \
       __kprog_address_result; })
#define KPROG_ARM64_MEM_READ_TAG_INTO(OUTPUT, BASE_IS_SP, TAG, WIDTH)                    \
	do {                                                                 \
		__u8 __kprog_a64_md_tag;                                      \
		if ((BASE_IS_SP) || (TAG) == ARM64_SIM_TAG_STACK)              \
			__kprog_a64_md_tag = KPROG_ARM64_MEM_TAG_STACK;            \
		else if ((TAG) == ARM64_SIM_TAG_ABI &&                    \
			 (WIDTH) == ARM64_WIDTH_64)                             \
			__kprog_a64_md_tag = KPROG_ARM64_MEM_TAG_ABI;              \
		else if ((TAG) == ARM64_SIM_TAG_RELOC_ADDR &&                    \
			 (WIDTH) == ARM64_WIDTH_64)                             \
			__kprog_a64_md_tag = KPROG_ARM64_MEM_TAG_MAP_PTR;              \
		else                                                        \
			__kprog_a64_md_tag = KPROG_ARM64_MEM_TAG_SCALAR;          \
		(OUTPUT) = __kprog_a64_md_tag;                                         \
	} while (0)
#define KPROG_ARM64_MEM_READ_TAG(BASE_IS_SP, TAG, WIDTH) \
    ({ __u8 __kprog_address_result; \
       KPROG_ARM64_MEM_READ_TAG_INTO(__kprog_address_result, (BASE_IS_SP), (TAG), (WIDTH)); \
       __kprog_address_result; })
#endif
