/* Canonical simulator C; edit directly. Historical origin: generate_arm64_dispatch_family_spec.py from arm64_dispatch_family_spec.json. */
#ifndef KPROG_FORMAL_GENERATED_ARM64_DISPATCH_FAMILY_H
#define KPROG_FORMAL_GENERATED_ARM64_DISPATCH_FAMILY_H
/*
 * The eight AArch64 dispatch families, including ALU immediate aliases, of the `ARM64_SIM_L_EXEC` opcode chain
 * that select an immediate and a register opcode through one arm: ALU, SHIFT,
 * SUBS, ADDS, CMP, TST, ANDS and CCMP. Each family names its member opcode set
 * and exposes it as a plain-expression membership macro, so the dispatcher's
 * family gate is the generated contract rather than a hand-rolled `||` of raw
 * ARM64_OP_* comparisons. A code outside every family reaches the caller's
 * unsupported arm.
 * This header is included after `arm64_sim.h`, so the opcode-number drift
 * checks bind the hand-written ARM64_OP_* decode to the generated member sets.
 */
_Static_assert(ARM64_OP_ADD_IMM == 3U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_SUB_IMM == 4U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_ALU_IMM == 6U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_ALU_REG == 7U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_SHIFT_IMM == 8U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_SHIFT_REG == 9U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_SUBS_IMM == 48U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_SUBS_REG == 50U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_ADDS_IMM == 49U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_ADDS_REG == 66U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_CMP_IMM == 22U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_CMP_REG == 23U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_TST_IMM == 24U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_TST_REG == 25U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_ANDS_REG == 45U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_ANDS_IMM == 55U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_CCMP_IMM == 26U, "arm64 dispatch family code drift");
_Static_assert(ARM64_OP_CCMP_REG == 27U, "arm64 dispatch family code drift");
/* Each family's member opcode set, tested by the dispatcher. */
#define KPROG_ARM64_ALU_HANDLED(OP)                                 \
	(((OP) == ARM64_OP_ADD_IMM) || \
	((OP) == ARM64_OP_SUB_IMM) || \
	((OP) == ARM64_OP_ALU_IMM) || \
	((OP) == ARM64_OP_ALU_REG))
#define KPROG_ARM64_SHIFT_OP_HANDLED(OP)                            \
	(((OP) == ARM64_OP_SHIFT_IMM) || \
	((OP) == ARM64_OP_SHIFT_REG))
#define KPROG_ARM64_SUBS_HANDLED(OP)                                \
	(((OP) == ARM64_OP_SUBS_IMM) || \
	((OP) == ARM64_OP_SUBS_REG))
#define KPROG_ARM64_ADDS_HANDLED(OP)                                \
	(((OP) == ARM64_OP_ADDS_IMM) || \
	((OP) == ARM64_OP_ADDS_REG))
#define KPROG_ARM64_CMP_HANDLED(OP)                                 \
	(((OP) == ARM64_OP_CMP_IMM) || \
	((OP) == ARM64_OP_CMP_REG))
#define KPROG_ARM64_TST_HANDLED(OP)                                 \
	(((OP) == ARM64_OP_TST_IMM) || \
	((OP) == ARM64_OP_TST_REG))
#define KPROG_ARM64_ANDS_HANDLED(OP)                                \
	(((OP) == ARM64_OP_ANDS_REG) || \
	((OP) == ARM64_OP_ANDS_IMM))
#define KPROG_ARM64_CCMP_HANDLED(OP)                                \
	(((OP) == ARM64_OP_CCMP_IMM) || \
	((OP) == ARM64_OP_CCMP_REG))
/* Every family member must be named by its generated membership macro. */
_Static_assert(KPROG_ARM64_ALU_HANDLED(ARM64_OP_ADD_IMM), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_ALU_HANDLED(ARM64_OP_SUB_IMM), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_ALU_HANDLED(ARM64_OP_ALU_IMM), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_ALU_HANDLED(ARM64_OP_ALU_REG), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_SHIFT_OP_HANDLED(ARM64_OP_SHIFT_IMM), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_SHIFT_OP_HANDLED(ARM64_OP_SHIFT_REG), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_SUBS_HANDLED(ARM64_OP_SUBS_IMM), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_SUBS_HANDLED(ARM64_OP_SUBS_REG), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_ADDS_HANDLED(ARM64_OP_ADDS_IMM), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_ADDS_HANDLED(ARM64_OP_ADDS_REG), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_CMP_HANDLED(ARM64_OP_CMP_IMM), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_CMP_HANDLED(ARM64_OP_CMP_REG), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_TST_HANDLED(ARM64_OP_TST_IMM), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_TST_HANDLED(ARM64_OP_TST_REG), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_ANDS_HANDLED(ARM64_OP_ANDS_REG), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_ANDS_HANDLED(ARM64_OP_ANDS_IMM), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_CCMP_HANDLED(ARM64_OP_CCMP_IMM), "arm64 dispatch family coverage drift");
_Static_assert(KPROG_ARM64_CCMP_HANDLED(ARM64_OP_CCMP_REG), "arm64 dispatch family coverage drift");
#endif
