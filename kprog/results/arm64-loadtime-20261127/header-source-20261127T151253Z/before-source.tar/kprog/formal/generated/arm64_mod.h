/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_MOD_H
#define KPROG_FORMAL_GENERATED_ARM64_MOD_H
/*
 * The handler is total: every modifier code of the AArch64 modifier table has
 * exactly one arm, including the ARM64_MOD_NONE identity arm, so there is no
 * unsupported arm and no default case.
 */
_Static_assert(ARM64_MOD_NONE == 0U, "arm64 modifier code drift");
_Static_assert(ARM64_MOD_LSL == 1U, "arm64 modifier code drift");
_Static_assert(ARM64_MOD_LSR == 2U, "arm64 modifier code drift");
_Static_assert(ARM64_MOD_ASR == 3U, "arm64 modifier code drift");
_Static_assert(ARM64_MOD_ROR == 4U, "arm64 modifier code drift");
_Static_assert(ARM64_MOD_UXTW == 5U, "arm64 modifier code drift");
_Static_assert(ARM64_MOD_SXTW == 6U, "arm64 modifier code drift");
_Static_assert(ARM64_MOD_UXTH == 7U, "arm64 modifier code drift");
_Static_assert(ARM64_MOD_SXTH == 8U, "arm64 modifier code drift");
_Static_assert(ARM64_MOD_UXTB == 9U, "arm64 modifier code drift");
_Static_assert(ARM64_MOD_SXTB == 10U, "arm64 modifier code drift");
#define KPROG_ARM64_MOD_HANDLED(MOD)                                        \
	(((MOD) == ARM64_MOD_NONE) || \
	((MOD) == ARM64_MOD_LSL) || \
	((MOD) == ARM64_MOD_LSR) || \
	((MOD) == ARM64_MOD_ASR) || \
	((MOD) == ARM64_MOD_ROR) || \
	((MOD) == ARM64_MOD_UXTW) || \
	((MOD) == ARM64_MOD_SXTW) || \
	((MOD) == ARM64_MOD_UXTH) || \
	((MOD) == ARM64_MOD_SXTH) || \
	((MOD) == ARM64_MOD_UXTB) || \
	((MOD) == ARM64_MOD_SXTB))
_Static_assert(KPROG_ARM64_MOD_HANDLED(ARM64_MOD_NONE), "arm64 modifier coverage drift");
_Static_assert(KPROG_ARM64_MOD_HANDLED(ARM64_MOD_LSL), "arm64 modifier coverage drift");
_Static_assert(KPROG_ARM64_MOD_HANDLED(ARM64_MOD_LSR), "arm64 modifier coverage drift");
_Static_assert(KPROG_ARM64_MOD_HANDLED(ARM64_MOD_ASR), "arm64 modifier coverage drift");
_Static_assert(KPROG_ARM64_MOD_HANDLED(ARM64_MOD_ROR), "arm64 modifier coverage drift");
_Static_assert(KPROG_ARM64_MOD_HANDLED(ARM64_MOD_UXTW), "arm64 modifier coverage drift");
_Static_assert(KPROG_ARM64_MOD_HANDLED(ARM64_MOD_SXTW), "arm64 modifier coverage drift");
_Static_assert(KPROG_ARM64_MOD_HANDLED(ARM64_MOD_UXTH), "arm64 modifier coverage drift");
_Static_assert(KPROG_ARM64_MOD_HANDLED(ARM64_MOD_SXTH), "arm64 modifier coverage drift");
_Static_assert(KPROG_ARM64_MOD_HANDLED(ARM64_MOD_UXTB), "arm64 modifier coverage drift");
_Static_assert(KPROG_ARM64_MOD_HANDLED(ARM64_MOD_SXTB), "arm64 modifier coverage drift");
/*
 * The numeric case labels 0U..10U track the ARM64_MOD_* values defined in
 * generated/arm64_decode.h. This header intentionally does not include
 * arm64_decode.h, so it stays usable standalone; load() re-checks the codes
 * against arm64_decode_spec.json and exits 1 if they drift. The extend arms
 * apply SHIFT unmasked like the hardware, so a SHIFT of 64 or more is outside
 * the modelled domain.
 */
#define KPROG_ARM64_MOD_VALUE_INTO(OUTPUT, MOD, VALUE, SHIFT, WIDTH) \
	do { \
		__u64 __kprog_a64_mod_value = (VALUE); \
		__u8 __kprog_a64_mod = (MOD); \
		__u8 __kprog_a64_mod_shift = (SHIFT); \
		__u8 __kprog_a64_mod_amount = \
			(__u8)(__kprog_a64_mod_shift & \
			      ((WIDTH) == ARM64_WIDTH_32 ? 31U : 63U)); \
 \
		switch (__kprog_a64_mod) { \
		case 0U:                           \
			break; \
		case 1U:                           \
			__kprog_a64_mod_value = ((__kprog_a64_mod_value << __kprog_a64_mod_amount) & KPROG_ARM64_WIDTH_MASK(WIDTH)); \
			break; \
		case 2U:                           \
			__kprog_a64_mod_value = ((__kprog_a64_mod_value & KPROG_ARM64_WIDTH_MASK(WIDTH)) >> __kprog_a64_mod_amount); \
			break; \
		case 3U:                           \
			if ((WIDTH) == ARM64_WIDTH_32) \
				__kprog_a64_mod_value = (__u64)((__s32)__kprog_a64_mod_value >> \
					__kprog_a64_mod_amount); \
			else \
				__kprog_a64_mod_value = (__u64)((__s64)__kprog_a64_mod_value >> \
					__kprog_a64_mod_amount); \
			break; \
		case 4U:                           \
			if ((WIDTH) == ARM64_WIDTH_32) { \
				__u32 __kprog_a64_mod_w32 = (__u32)__kprog_a64_mod_value; \
 \
				__kprog_a64_mod_value = __kprog_a64_mod_amount \
					? (__u64)((__kprog_a64_mod_w32 >> __kprog_a64_mod_amount) | \
						  (__kprog_a64_mod_w32 << (32U - __kprog_a64_mod_amount))) \
					: (__u64)__kprog_a64_mod_w32; \
			} else if (__kprog_a64_mod_amount) { \
				__kprog_a64_mod_value = \
					(__kprog_a64_mod_value >> __kprog_a64_mod_amount) | \
					(__kprog_a64_mod_value << (64U - __kprog_a64_mod_amount)); \
			} \
			break; \
		case 5U:                           \
			__kprog_a64_mod_value = (((__u64)(__u32)__kprog_a64_mod_value) << __kprog_a64_mod_shift); \
			break; \
		case 6U:                           \
			__kprog_a64_mod_value = (((__u64)(__s64)(__s32)__kprog_a64_mod_value) << __kprog_a64_mod_shift); \
			break; \
		case 7U:                           \
			__kprog_a64_mod_value = (((__u64)(__u16)__kprog_a64_mod_value) << __kprog_a64_mod_shift); \
			break; \
		case 8U:                           \
			__kprog_a64_mod_value = (((__u64)(__s64)(__s16)__kprog_a64_mod_value) << __kprog_a64_mod_shift); \
			break; \
		case 9U:                           \
			__kprog_a64_mod_value = (((__u64)(__u8)__kprog_a64_mod_value) << __kprog_a64_mod_shift); \
			break; \
		case 10U:                           \
			__kprog_a64_mod_value = (((__u64)(__s64)(__s8)__kprog_a64_mod_value) << __kprog_a64_mod_shift); \
			break; \
		} \
		(OUTPUT) = __kprog_a64_mod_value; \
	} while (0)

#define KPROG_ARM64_MOD_VALUE(MOD, VALUE, SHIFT, WIDTH) \
	({ __u64 __kprog_a64_mod_value_out; \
	   KPROG_ARM64_MOD_VALUE_INTO(__kprog_a64_mod_value_out, MOD, VALUE, SHIFT, WIDTH); \
	   __kprog_a64_mod_value_out; })
#endif
