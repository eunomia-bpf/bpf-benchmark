/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_BITFIELD_H
#define KPROG_FORMAL_GENERATED_ARM64_BITFIELD_H
/*
 * The five bitfield arms are UBFX (extract), SBFX (signed extract), UBFIZ
 * (insert in zeros), BFXIL (extract and insert at low end) and BFI (insert).
 * Every bitfield code of the AArch64 bitfield table has exactly one arm; a code
 * outside the table reaches the caller-supplied unsupported arm.
 */
_Static_assert(ARM64_BITFIELD_UBFX == 0U, "arm64 bitfield code drift");
_Static_assert(ARM64_BITFIELD_SBFX == 1U, "arm64 bitfield code drift");
_Static_assert(ARM64_BITFIELD_UBFIZ == 2U, "arm64 bitfield code drift");
_Static_assert(ARM64_BITFIELD_BFXIL == 3U, "arm64 bitfield code drift");
_Static_assert(ARM64_BITFIELD_BFI == 4U, "arm64 bitfield code drift");
#define KPROG_ARM64_BITFIELD_HANDLED(KIND)                                  \
	(((KIND) == ARM64_BITFIELD_UBFX) || \
	((KIND) == ARM64_BITFIELD_SBFX) || \
	((KIND) == ARM64_BITFIELD_UBFIZ) || \
	((KIND) == ARM64_BITFIELD_BFXIL) || \
	((KIND) == ARM64_BITFIELD_BFI))
_Static_assert(KPROG_ARM64_BITFIELD_HANDLED(ARM64_BITFIELD_UBFX), "arm64 bitfield coverage drift");
_Static_assert(KPROG_ARM64_BITFIELD_HANDLED(ARM64_BITFIELD_SBFX), "arm64 bitfield coverage drift");
_Static_assert(KPROG_ARM64_BITFIELD_HANDLED(ARM64_BITFIELD_UBFIZ), "arm64 bitfield coverage drift");
_Static_assert(KPROG_ARM64_BITFIELD_HANDLED(ARM64_BITFIELD_BFXIL), "arm64 bitfield coverage drift");
_Static_assert(KPROG_ARM64_BITFIELD_HANDLED(ARM64_BITFIELD_BFI), "arm64 bitfield coverage drift");
/*
 * The numeric case labels 0U..4U track the ARM64_BITFIELD_* values defined in
 * generated/arm64_decode.h. This header intentionally does not include
 * arm64_decode.h, so it stays usable standalone; load() re-checks the codes
 * against arm64_decode_spec.json and exits 1 if they drift. SRC and DST are
 * each evaluated exactly once. The result is the raw 64-bit field value; the
 * caller applies the operand width afterwards.
 */
#define KPROG_ARM64_BITFIELD_VALUE_INTO(OUTPUT, KIND, SRC, DST, LSB, BITS, UNSUPPORTED) \
	do { \
		__u64 __kprog_a64_bf_src = (SRC); \
		__u64 __kprog_a64_bf_dst = (DST); \
		__u8 __kprog_a64_bf_kind = (KIND); \
		__u8 __kprog_a64_bf_lsb = (LSB); \
		__u8 __kprog_a64_bf_bits = (BITS); \
		__u64 __kprog_a64_bf_mask = \
			__kprog_a64_bf_bits == 0 ? 0 \
			: (__kprog_a64_bf_bits >= 64 ? 0xffffffffffffffffULL \
			   : (1ULL << __kprog_a64_bf_bits) - 1ULL); \
		__u64 __kprog_a64_bf_src_r = \
			__kprog_a64_bf_lsb >= 64 ? 0 \
			: __kprog_a64_bf_src >> __kprog_a64_bf_lsb; \
		__u64 __kprog_a64_bf_src_l = \
			__kprog_a64_bf_lsb >= 64 ? 0 \
			: __kprog_a64_bf_src << __kprog_a64_bf_lsb; \
		__u64 __kprog_a64_bf_field = \
			__kprog_a64_bf_lsb >= 64 ? 0 \
			: __kprog_a64_bf_mask << __kprog_a64_bf_lsb; \
		__u64 __kprog_a64_bf_sign = \
			__kprog_a64_bf_bits == 0 ? 0 \
			: 1ULL << (__kprog_a64_bf_bits >= 64 ? 63U \
				     : __kprog_a64_bf_bits - 1U); \
		__u64 __kprog_a64_bf_result = 0; \
 \
		switch (__kprog_a64_bf_kind) { \
		case 0U:                           \
			__kprog_a64_bf_result = __kprog_a64_bf_src_r & __kprog_a64_bf_mask; \
			break; \
		case 1U:                           \
			__kprog_a64_bf_result = __kprog_a64_bf_bits == 0 ? 0 : ((__kprog_a64_bf_src_r & __kprog_a64_bf_mask) ^ __kprog_a64_bf_sign) - __kprog_a64_bf_sign; \
			break; \
		case 2U:                           \
			__kprog_a64_bf_result = __kprog_a64_bf_src_l & __kprog_a64_bf_field; \
			break; \
		case 3U:                           \
			__kprog_a64_bf_result = (__kprog_a64_bf_dst & ~__kprog_a64_bf_mask) | (__kprog_a64_bf_src_r & __kprog_a64_bf_mask); \
			break; \
		case 4U:                           \
			__kprog_a64_bf_result = (__kprog_a64_bf_dst & ~__kprog_a64_bf_field) | (__kprog_a64_bf_src_l & __kprog_a64_bf_field); \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		(OUTPUT) = __kprog_a64_bf_result; \
	} while (0)

#define KPROG_ARM64_BITFIELD_VALUE(KIND, SRC, DST, LSB, BITS, UNSUPPORTED) \
	({ __u64 __kprog_a64_bf_result_out; \
	   KPROG_ARM64_BITFIELD_VALUE_INTO(__kprog_a64_bf_result_out, KIND, SRC, DST, LSB, BITS, UNSUPPORTED); \
	   __kprog_a64_bf_result_out; })
#endif
