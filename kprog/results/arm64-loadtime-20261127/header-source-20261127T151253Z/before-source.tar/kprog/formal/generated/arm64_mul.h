/* Canonical simulator C; edited directly (formal/README.md, M4). */
#ifndef KPROG_FORMAL_GENERATED_ARM64_MUL_H
#define KPROG_FORMAL_GENERATED_ARM64_MUL_H
/*
 * The eight multiply-family arms are MADD/MSUB (multiply-add and
 * multiply-subtract), MUL, UMULL/UMADDL (unsigned 32x32 widening long
 * multiply, with and without accumulator), SMADDL (signed 32x32 widening
 * multiply-add), UDIV (with the architectural divide-by-zero result of zero)
 * and UMULH (the high word of the full 64x64 product). Every opcode of the
 * family has exactly one arm; an opcode outside the family reaches the
 * caller-supplied unsupported arm.
 */
_Static_assert(ARM64_OP_MADD == 10U, "arm64 multiply code drift");
_Static_assert(ARM64_OP_MSUB == 11U, "arm64 multiply code drift");
_Static_assert(ARM64_OP_MUL == 12U, "arm64 multiply code drift");
_Static_assert(ARM64_OP_UMULL == 13U, "arm64 multiply code drift");
_Static_assert(ARM64_OP_UDIV == 14U, "arm64 multiply code drift");
_Static_assert(ARM64_OP_UMULH == 46U, "arm64 multiply code drift");
_Static_assert(ARM64_OP_UMADDL == 59U, "arm64 multiply code drift");
_Static_assert(ARM64_OP_SMADDL == 64U, "arm64 multiply code drift");
#define KPROG_ARM64_MUL_HANDLED(OP)                                         \
	(((OP) == ARM64_OP_MADD) || \
	((OP) == ARM64_OP_MSUB) || \
	((OP) == ARM64_OP_MUL) || \
	((OP) == ARM64_OP_UMULL) || \
	((OP) == ARM64_OP_UDIV) || \
	((OP) == ARM64_OP_UMULH) || \
	((OP) == ARM64_OP_UMADDL) || \
	((OP) == ARM64_OP_SMADDL))
_Static_assert(KPROG_ARM64_MUL_HANDLED(ARM64_OP_MADD), "arm64 multiply coverage drift");
_Static_assert(KPROG_ARM64_MUL_HANDLED(ARM64_OP_MSUB), "arm64 multiply coverage drift");
_Static_assert(KPROG_ARM64_MUL_HANDLED(ARM64_OP_MUL), "arm64 multiply coverage drift");
_Static_assert(KPROG_ARM64_MUL_HANDLED(ARM64_OP_UMULL), "arm64 multiply coverage drift");
_Static_assert(KPROG_ARM64_MUL_HANDLED(ARM64_OP_UDIV), "arm64 multiply coverage drift");
_Static_assert(KPROG_ARM64_MUL_HANDLED(ARM64_OP_UMULH), "arm64 multiply coverage drift");
_Static_assert(KPROG_ARM64_MUL_HANDLED(ARM64_OP_UMADDL), "arm64 multiply coverage drift");
_Static_assert(KPROG_ARM64_MUL_HANDLED(ARM64_OP_SMADDL), "arm64 multiply coverage drift");
/*
 * The numeric case labels 10U, 11U, 12U, 13U, 14U, 46U, 59U and 64U track the
 * ARM64_OP_MADD/MSUB/MUL/UMULL/UDIV/UMULH/UMADDL/SMADDL values defined in
 * kprog/arm64/arm64_sim.h; the family is not contiguous. This header
 * intentionally does not include arm64_sim.h, so it stays usable standalone;
 * load() re-checks the codes against arm64_sim.h and exits 1 if they drift.
 * LHS, RHS and ADDEND are each evaluated exactly once, and no arm writes NZCV.
 * The result is the raw 64-bit value; the caller applies the destination width
 * afterwards.
 */
#define KPROG_ARM64_MUL_VALUE_INTO(OUTPUT, OP, LHS, RHS, ADDEND, UNSUPPORTED) \
	do { \
		__u64 __kprog_a64_mul_op = (OP); \
		__u64 __kprog_a64_mul_lhs = (LHS); \
		__u64 __kprog_a64_mul_rhs = (RHS); \
		__u64 __kprog_a64_mul_addend = (ADDEND); \
		__u64 __kprog_a64_mul_result = 0; \
 \
		switch (__kprog_a64_mul_op) { \
		case 10U:                           \
			__kprog_a64_mul_result = __kprog_a64_mul_lhs * __kprog_a64_mul_rhs + __kprog_a64_mul_addend; \
			break; \
		case 11U:                           \
			__kprog_a64_mul_result = __kprog_a64_mul_addend - __kprog_a64_mul_lhs * __kprog_a64_mul_rhs; \
			break; \
		case 12U:                           \
			__kprog_a64_mul_result = __kprog_a64_mul_lhs * __kprog_a64_mul_rhs; \
			break; \
		case 13U:                           \
			__kprog_a64_mul_result = (__u64)(__u32)__kprog_a64_mul_lhs * (__u64)(__u32)__kprog_a64_mul_rhs; \
			break; \
		case 14U:                           \
			__kprog_a64_mul_result = __kprog_a64_mul_rhs ? __kprog_a64_mul_lhs / __kprog_a64_mul_rhs : 0; \
			break; \
		case 46U:                           \
			{ \
				__u64 __kprog_a64_mul_lo = \
					(__u64)(__u32)__kprog_a64_mul_lhs * \
					(__u64)(__u32)__kprog_a64_mul_rhs; \
				__u64 __kprog_a64_mul_mid1 = \
					(__kprog_a64_mul_lhs >> 32) * \
					(__u64)(__u32)__kprog_a64_mul_rhs; \
				__u64 __kprog_a64_mul_mid2 = \
					(__u64)(__u32)__kprog_a64_mul_lhs * \
					(__kprog_a64_mul_rhs >> 32); \
				__u64 __kprog_a64_mul_hi = \
					(__kprog_a64_mul_lhs >> 32) * \
					(__kprog_a64_mul_rhs >> 32); \
				__u64 __kprog_a64_mul_carry = \
					((__kprog_a64_mul_lo >> 32) + \
					 (__u64)(__u32)__kprog_a64_mul_mid1 + \
					 (__u64)(__u32)__kprog_a64_mul_mid2) >> 32; \
 \
				__kprog_a64_mul_result = \
					__kprog_a64_mul_hi + (__kprog_a64_mul_mid1 >> 32) + \
					(__kprog_a64_mul_mid2 >> 32) + __kprog_a64_mul_carry; \
			} \
			break; \
		case 59U:                           \
			__kprog_a64_mul_result = (__u64)(__u32)__kprog_a64_mul_lhs * (__u64)(__u32)__kprog_a64_mul_rhs + __kprog_a64_mul_addend; \
			break; \
		case 64U:                           \
			__kprog_a64_mul_result = (__u64)((__s64)(__s32)__kprog_a64_mul_lhs * (__s64)(__s32)__kprog_a64_mul_rhs) + __kprog_a64_mul_addend; \
			break; \
		default: \
			UNSUPPORTED; \
			break; \
		} \
		(OUTPUT) = __kprog_a64_mul_result; \
	} while (0)

#define KPROG_ARM64_MUL_VALUE(OP, LHS, RHS, ADDEND, UNSUPPORTED) \
	({ __u64 __kprog_a64_mul_result_out; \
	   KPROG_ARM64_MUL_VALUE_INTO(__kprog_a64_mul_result_out, OP, LHS, RHS, ADDEND, UNSUPPORTED); \
	   __kprog_a64_mul_result_out; })
#endif
