
/var/tmp/kprog-tmp/perf/dynamic-array-c/native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <selected>:
       0: 8b 07                        	movl	(%rdi), %eax
       2: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x9 <selected+0x9>
		0000000000000005:  R_X86_64_REX_GOTPCRELX	counts-0x4
       9: 3b 41 44                     	cmpl	0x44(%rcx), %eax
       c: 73 1a                        	jae	0x28 <selected+0x28>
       e: 8b 91 20 01 00 00            	movl	0x120(%rcx), %edx
      14: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
      1a: 48 0f af c2                  	imulq	%rdx, %rax
      1e: 48 01 c8                     	addq	%rcx, %rax
      21: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
      27: c3                           	retq
      28: 31 c0                        	xorl	%eax, %eax
      2a: c3                           	retq
      2b: 0f 1f 44 00 00               	nopl	(%rax,%rax)

0000000000000030 <selected_alias>:
      30: 8b 07                        	movl	(%rdi), %eax
      32: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x39 <selected_alias+0x9>
		0000000000000035:  R_X86_64_REX_GOTPCRELX	same-0x4
      39: 3b 41 44                     	cmpl	0x44(%rcx), %eax
      3c: 73 1a                        	jae	0x58 <selected_alias+0x28>
      3e: 8b 91 20 01 00 00            	movl	0x120(%rcx), %edx
      44: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
      4a: 48 0f af c2                  	imulq	%rdx, %rax
      4e: 48 01 c8                     	addq	%rcx, %rax
      51: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
      57: c3                           	retq
      58: 31 c0                        	xorl	%eax, %eax
      5a: c3                           	retq
      5b: 0f 1f 44 00 00               	nopl	(%rax,%rax)

0000000000000060 <unselected>:
      60: 48 89 fe                     	movq	%rdi, %rsi
      63: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x6a <unselected+0xa>
		0000000000000066:  R_X86_64_REX_GOTPCRELX	other-0x4
      6a: e9 00 00 00 00               	jmp	0x6f <unselected+0xf>
		000000000000006b:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
      6f: 90                           	nop

0000000000000070 <dynamic>:
      70: e9 00 00 00 00               	jmp	0x75 <dynamic+0x5>
		0000000000000071:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
      75: 66 66 2e 0f 1f 84 00 00 00 00 00     	nopw	%cs:(%rax,%rax)

0000000000000080 <__kprog_array_lookup>:
      80: 8b 06                        	movl	(%rsi), %eax
      82: 3b 47 44                     	cmpl	0x44(%rdi), %eax
      85: 73 1a                        	jae	0xa1 <__kprog_array_lookup+0x21>
      87: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
      8d: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
      93: 48 0f af c1                  	imulq	%rcx, %rax
      97: 48 01 f8                     	addq	%rdi, %rax
      9a: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
      a0: c3                           	retq
      a1: 31 c0                        	xorl	%eax, %eax
      a3: c3                           	retq
