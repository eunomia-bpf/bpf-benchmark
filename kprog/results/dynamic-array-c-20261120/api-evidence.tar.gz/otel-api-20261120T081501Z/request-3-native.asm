
/var/tmp/kprog-tmp/perf/helper-sharing/3/checked-simulator.native.o:	file format elf64-x86-64

Disassembly of section perf_event:

0000000000000000 <trusted_x86_x86_sim_xdp>:
       0: 55                           	pushq	%rbp
       1: 41 57                        	pushq	%r15
       3: 41 56                        	pushq	%r14
       5: 41 55                        	pushq	%r13
       7: 41 54                        	pushq	%r12
       9: 53                           	pushq	%rbx
       a: 48 81 ec 08 02 00 00         	subq	$0x208, %rsp            # imm = 0x208
      11: c7 84 24 b8 00 00 00 00 00 00 00     	movl	$0x0, 0xb8(%rsp)
      1c: 48 c7 84 24 50 01 00 00 00 00 00 00  	movq	$0x0, 0x150(%rsp)
      28: 48 c7 84 24 58 01 00 00 00 00 00 00  	movq	$0x0, 0x158(%rsp)
      34: 48 c7 84 24 60 01 00 00 00 00 00 00  	movq	$0x0, 0x160(%rsp)
      40: 48 c7 84 24 68 01 00 00 00 00 00 00  	movq	$0x0, 0x168(%rsp)
      4c: 48 c7 84 24 70 01 00 00 00 00 00 00  	movq	$0x0, 0x170(%rsp)
      58: 48 c7 84 24 78 01 00 00 00 00 00 00  	movq	$0x0, 0x178(%rsp)
      64: 4c 8b 2d 00 00 00 00         	movq	(%rip), %r13            # 0x6b <trusted_x86_x86_sim_xdp+0x6b>
		0000000000000067:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
      6b: 41 83 7d 44 00               	cmpl	$0x0, 0x44(%r13)
      70: 0f 84 39 2c 00 00            	je	0x2caf <trusted_x86_x86_sim_xdp+0x2caf>
      76: 49 89 ff                     	movq	%rdi, %r15
      79: 49 8b bd 30 01 00 00         	movq	0x130(%r13), %rdi
      80: e8 00 00 00 00               	callq	0x85 <trusted_x86_x86_sim_xdp+0x85>
		0000000000000081:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
      85: 48 85 c0                     	testq	%rax, %rax
      88: 0f 84 21 2c 00 00            	je	0x2caf <trusted_x86_x86_sim_xdp+0x2caf>
      8e: 48 89 c3                     	movq	%rax, %rbx
      91: c7 84 24 b8 00 00 00 05 00 00 00     	movl	$0x5, 0xb8(%rsp)
      9c: 4c 8b 25 00 00 00 00         	movq	(%rip), %r12            # 0xa3 <trusted_x86_x86_sim_xdp+0xa3>
		000000000000009f:  R_X86_64_REX_GOTPCRELX	metrics-0x4
      a3: 41 83 7c 24 44 06            	cmpl	$0x6, 0x44(%r12)
      a9: 72 2b                        	jb	0xd6 <trusted_x86_x86_sim_xdp+0xd6>
      ab: b8 05 00 00 00               	movl	$0x5, %eax
      b0: 41 23 84 24 24 01 00 00      	andl	0x124(%r12), %eax
      b8: 49 8b bc c4 30 01 00 00      	movq	0x130(%r12,%rax,8), %rdi
      c0: e8 00 00 00 00               	callq	0xc5 <trusted_x86_x86_sim_xdp+0xc5>
		00000000000000c1:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
      c5: 48 85 c0                     	testq	%rax, %rax
      c8: 74 0c                        	je	0xd6 <trusted_x86_x86_sim_xdp+0xd6>
      ca: 48 89 c1                     	movq	%rax, %rcx
      cd: 48 8b 09                     	movq	(%rcx), %rcx
      d0: 48 ff c1                     	incq	%rcx
      d3: 48 89 08                     	movq	%rcx, (%rax)
      d6: 48 89 d8                     	movq	%rbx, %rax
      d9: 8b 88 c0 02 00 00            	movl	0x2c0(%rax), %ecx
      df: 83 f9 7f                     	cmpl	$0x7f, %ecx
      e2: 72 50                        	jb	0x134 <trusted_x86_x86_sim_xdp+0x134>
      e4: c7 84 24 b8 00 00 00 02 00 00 00     	movl	$0x2, 0xb8(%rsp)
      ef: bd 02 00 00 00               	movl	$0x2, %ebp
      f4: 41 83 7c 24 44 03            	cmpl	$0x3, 0x44(%r12)
      fa: 0f 82 b7 0b 00 00            	jb	0xcb7 <trusted_x86_x86_sim_xdp+0xcb7>
     100: 41 8b 84 24 24 01 00 00      	movl	0x124(%r12), %eax
     108: 21 e8                        	andl	%ebp, %eax
     10a: 49 8b bc c4 30 01 00 00      	movq	0x130(%r12,%rax,8), %rdi
     112: e8 00 00 00 00               	callq	0x117 <trusted_x86_x86_sim_xdp+0x117>
		0000000000000113:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     117: 48 85 c0                     	testq	%rax, %rax
     11a: 0f 84 97 0b 00 00            	je	0xcb7 <trusted_x86_x86_sim_xdp+0xcb7>
     120: 48 89 c1                     	movq	%rax, %rcx
     123: 48 8b 09                     	movq	(%rcx), %rcx
     126: 48 ff c1                     	incq	%rcx
     129: 48 89 08                     	movq	%rcx, (%rax)
     12c: 45 31 e4                     	xorl	%r12d, %r12d
     12f: e9 b4 2a 00 00               	jmp	0x2be8 <trusted_x86_x86_sim_xdp+0x2be8>
     134: 48 89 d8                     	movq	%rbx, %rax
     137: 0f b6 80 30 0f 00 00         	movzbl	0xf30(%rax), %eax
     13e: 48 89 da                     	movq	%rbx, %rdx
     141: 48 8b 92 10 0f 00 00         	movq	0xf10(%rdx), %rdx
     148: 48 89 de                     	movq	%rbx, %rsi
     14b: 48 8b b6 18 0f 00 00         	movq	0xf18(%rsi), %rsi
     152: 8d 79 01                     	leal	0x1(%rcx), %edi
     155: 4c 8d a3 c0 02 00 00         	leaq	0x2c0(%rbx), %r12
     15c: 4d 89 e0                     	movq	%r12, %r8
     15f: 41 89 38                     	movl	%edi, (%r8)
     162: c1 e1 03                     	shll	$0x3, %ecx
     165: 8d 0c 49                     	leal	(%rcx,%rcx,2), %ecx
     168: 48 8d 3c 0b                  	leaq	(%rbx,%rcx), %rdi
     16c: 48 81 c7 d0 02 00 00         	addq	$0x2d0, %rdi            # imm = 0x2D0
     173: 48 89 17                     	movq	%rdx, (%rdi)
     176: 48 8d 94 0b d8 02 00 00      	leaq	0x2d8(%rbx,%rcx), %rdx
     17e: 48 89 32                     	movq	%rsi, (%rdx)
     181: 48 8d 94 0b e0 02 00 00      	leaq	0x2e0(%rbx,%rcx), %rdx
     189: c6 02 03                     	movb	$0x3, (%rdx)
     18c: 48 8d 94 0b e1 02 00 00      	leaq	0x2e1(%rbx,%rcx), %rdx
     194: 88 02                        	movb	%al, (%rdx)
     196: 48 8d 84 0b e2 02 00 00      	leaq	0x2e2(%rbx,%rcx), %rax
     19e: c7 00 00 00 00 00            	movl	$0x0, (%rax)
     1a4: 48 8d 84 0b e6 02 00 00      	leaq	0x2e6(%rbx,%rcx), %rax
     1ac: 66 c7 00 00 00               	movw	$0x0, (%rax)
     1b1: c7 44 24 60 00 00 00 00      	movl	$0x0, 0x60(%rsp)
     1b9: 48 89 d8                     	movq	%rbx, %rax
     1bc: 48 8b 80 10 0f 00 00         	movq	0xf10(%rax), %rax
     1c3: 48 89 84 24 b0 00 00 00      	movq	%rax, 0xb0(%rsp)
     1cb: 48 89 44 24 68               	movq	%rax, 0x68(%rsp)
     1d0: 48 89 d8                     	movq	%rbx, %rax
     1d3: 48 c7 c1 00 00 ff ff         	movq	$-0x10000, %rcx         # imm = 0xFFFF0000
     1da: 48 23 88 18 0f 00 00         	andq	0xf18(%rax), %rcx
     1e1: 48 89 4c 24 70               	movq	%rcx, 0x70(%rsp)
     1e6: 48 8d 6c 24 68               	leaq	0x68(%rsp), %rbp
     1eb: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1f2 <trusted_x86_x86_sim_xdp+0x1f2>
		00000000000001ee:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
     1f2: 48 3b 0d 00 00 00 00         	cmpq	(%rip), %rcx            # 0x1f9 <trusted_x86_x86_sim_xdp+0x1f9>
		00000000000001f5:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
     1f9: 0f 94 c0                     	sete	%al
     1fc: 48 3b 0d 00 00 00 00         	cmpq	(%rip), %rcx            # 0x203 <trusted_x86_x86_sim_xdp+0x203>
		00000000000001ff:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     203: 41 0f 94 c6                  	sete	%r14b
     207: 41 08 c6                     	orb	%al, %r14b
     20a: 41 80 fe 01                  	cmpb	$0x1, %r14b
     20e: 75 1e                        	jne	0x22e <trusted_x86_x86_sim_xdp+0x22e>
     210: 8b 44 24 68                  	movl	0x68(%rsp), %eax
     214: 3b 41 44                     	cmpl	0x44(%rcx), %eax
     217: 73 28                        	jae	0x241 <trusted_x86_x86_sim_xdp+0x241>
     219: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
     21f: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
     227: e8 00 00 00 00               	callq	0x22c <trusted_x86_x86_sim_xdp+0x22c>
		0000000000000228:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     22c: eb 37                        	jmp	0x265 <trusted_x86_x86_sim_xdp+0x265>
     22e: 48 89 ef                     	movq	%rbp, %rdi
     231: 48 3b 0d 00 00 00 00         	cmpq	(%rip), %rcx            # 0x238 <trusted_x86_x86_sim_xdp+0x238>
		0000000000000234:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
     238: 75 16                        	jne	0x250 <trusted_x86_x86_sim_xdp+0x250>
     23a: e8 00 00 00 00               	callq	0x23f <trusted_x86_x86_sim_xdp+0x23f>
		000000000000023b:  R_X86_64_PLT32	.text+0x7c
     23f: eb 24                        	jmp	0x265 <trusted_x86_x86_sim_xdp+0x265>
     241: ba 08 00 00 00               	movl	$0x8, %edx
     246: b9 a0 0f 00 00               	movl	$0xfa0, %ecx            # imm = 0xFA0
     24b: e9 8a 29 00 00               	jmp	0x2bda <trusted_x86_x86_sim_xdp+0x2bda>
     250: 48 3b 0d 00 00 00 00         	cmpq	(%rip), %rcx            # 0x257 <trusted_x86_x86_sim_xdp+0x257>
		0000000000000253:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
     257: 75 07                        	jne	0x260 <trusted_x86_x86_sim_xdp+0x260>
     259: e8 00 00 00 00               	callq	0x25e <trusted_x86_x86_sim_xdp+0x25e>
		000000000000025a:  R_X86_64_PLT32	.text+0x12c
     25e: eb 05                        	jmp	0x265 <trusted_x86_x86_sim_xdp+0x265>
     260: e8 00 00 00 00               	callq	0x265 <trusted_x86_x86_sim_xdp+0x265>
		0000000000000261:  R_X86_64_PLT32	.text+0x1dc
     265: ba 08 00 00 00               	movl	$0x8, %edx
     26a: b9 a0 0f 00 00               	movl	$0xfa0, %ecx            # imm = 0xFA0
     26f: 48 85 c0                     	testq	%rax, %rax
     272: 0f 84 62 29 00 00            	je	0x2bda <trusted_x86_x86_sim_xdp+0x2bda>
     278: 48 89 c1                     	movq	%rax, %rcx
     27b: 0f b7 49 06                  	movzwl	0x6(%rcx), %ecx
     27f: 0f b7 c9                     	movzwl	%cx, %ecx
     282: 83 c1 f8                     	addl	$-0x8, %ecx
     285: f7 c1 f0 ff 00 00            	testl	$0xfff0, %ecx           # imm = 0xFFF0
     28b: 74 0f                        	je	0x29c <trusted_x86_x86_sim_xdp+0x29c>
     28d: b9 a1 0f 00 00               	movl	$0xfa1, %ecx            # imm = 0xFA1
     292: ba 33 00 00 00               	movl	$0x33, %edx
     297: e9 3e 29 00 00               	jmp	0x2bda <trusted_x86_x86_sim_xdp+0x2bda>
     29c: 83 e1 0f                     	andl	$0xf, %ecx
     29f: 48 8d 15 00 00 00 00         	leaq	(%rip), %rdx            # 0x2a6 <trusted_x86_x86_sim_xdp+0x2a6>
		00000000000002a2:  R_X86_64_PC32	.data.rel.ro-0x4
     2a6: 48 8b 3c ca                  	movq	(%rdx,%rcx,8), %rdi
     2aa: 48 8d b4 24 b0 00 00 00      	leaq	0xb0(%rsp), %rsi
     2b2: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     2b6: 75 34                        	jne	0x2ec <trusted_x86_x86_sim_xdp+0x2ec>
     2b8: 8b 8c 24 b0 00 00 00         	movl	0xb0(%rsp), %ecx
     2bf: 3b 4f 44                     	cmpl	0x44(%rdi), %ecx
     2c2: 0f 83 08 29 00 00            	jae	0x2bd0 <trusted_x86_x86_sim_xdp+0x2bd0>
     2c8: 4c 89 a4 24 c0 01 00 00      	movq	%r12, 0x1c0(%rsp)
     2d0: 8b 97 20 01 00 00            	movl	0x120(%rdi), %edx
     2d6: 23 8f 24 01 00 00            	andl	0x124(%rdi), %ecx
     2dc: 48 0f af ca                  	imulq	%rdx, %rcx
     2e0: 48 01 cf                     	addq	%rcx, %rdi
     2e3: 48 81 c7 30 01 00 00         	addq	$0x130, %rdi            # imm = 0x130
     2ea: eb 21                        	jmp	0x30d <trusted_x86_x86_sim_xdp+0x30d>
     2ec: 4c 89 a4 24 c0 01 00 00      	movq	%r12, 0x1c0(%rsp)
     2f4: 48 8b 4f 20                  	movq	0x20(%rdi), %rcx
     2f8: 49 89 c4                     	movq	%rax, %r12
     2fb: ff 51 60                     	callq	*0x60(%rcx)
     2fe: 48 89 c7                     	movq	%rax, %rdi
     301: 4c 89 e0                     	movq	%r12, %rax
     304: 48 85 ff                     	testq	%rdi, %rdi
     307: 0f 84 c3 28 00 00            	je	0x2bd0 <trusted_x86_x86_sim_xdp+0x2bd0>
     30d: 4c 89 bc 24 80 00 00 00      	movq	%r15, 0x80(%rsp)
     315: 48 89 c1                     	movq	%rax, %rcx
     318: 44 8b 21                     	movl	(%rcx), %r12d
     31b: 44 89 64 24 64               	movl	%r12d, 0x64(%rsp)
     320: 48 89 d9                     	movq	%rbx, %rcx
     323: 48 8b 89 18 0f 00 00         	movq	0xf18(%rcx), %rcx
     32a: 48 89 4c 24 58               	movq	%rcx, 0x58(%rsp)
     32f: 48 89 c1                     	movq	%rax, %rcx
     332: 44 0f b7 79 04               	movzwl	0x4(%rcx), %r15d
     337: 45 85 ff                     	testl	%r15d, %r15d
     33a: 74 49                        	je	0x385 <trusted_x86_x86_sim_xdp+0x385>
     33c: 45 01 e7                     	addl	%r12d, %r15d
     33f: 43 8d 0c 27                  	leal	(%r15,%r12), %ecx
     343: d1 e9                        	shrl	%ecx
     345: 89 4c 24 3c                  	movl	%ecx, 0x3c(%rsp)
     349: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     34e: 48 89 7c 24 50               	movq	%rdi, 0x50(%rsp)
     353: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     357: 75 39                        	jne	0x392 <trusted_x86_x86_sim_xdp+0x392>
     359: 8b 0e                        	movl	(%rsi), %ecx
     35b: 3b 4f 44                     	cmpl	0x44(%rdi), %ecx
     35e: 0f 83 ee 44 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     364: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
     369: 8b 87 20 01 00 00            	movl	0x120(%rdi), %eax
     36f: 23 8f 24 01 00 00            	andl	0x124(%rdi), %ecx
     375: 48 0f af c8                  	imulq	%rax, %rcx
     379: 48 8d 04 0f                  	leaq	(%rdi,%rcx), %rax
     37d: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     383: eb 22                        	jmp	0x3a7 <trusted_x86_x86_sim_xdp+0x3a7>
     385: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
     38a: 45 89 e7                     	movl	%r12d, %r15d
     38d: e9 56 07 00 00               	jmp	0xae8 <trusted_x86_x86_sim_xdp+0xae8>
     392: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
     397: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     39b: ff 50 60                     	callq	*0x60(%rax)
     39e: 48 85 c0                     	testq	%rax, %rax
     3a1: 0f 84 ab 44 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     3a7: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     3ab: 8d 69 01                     	leal	0x1(%rcx), %ebp
     3ae: 0f b7 54 24 58               	movzwl	0x58(%rsp), %edx
     3b3: 0f b7 00                     	movzwl	(%rax), %eax
     3b6: 48 39 c2                     	cmpq	%rax, %rdx
     3b9: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     3bd: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     3c1: 44 39 fd                     	cmpl	%r15d, %ebp
     3c4: 0f 83 0b 07 00 00            	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     3ca: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     3ce: d1 e8                        	shrl	%eax
     3d0: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
     3d4: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     3d9: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     3dd: 75 2b                        	jne	0x40a <trusted_x86_x86_sim_xdp+0x40a>
     3df: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
     3e4: 8b 00                        	movl	(%rax), %eax
     3e6: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     3e9: 0f 83 63 44 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     3ef: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     3f5: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     3fb: 48 0f af c1                  	imulq	%rcx, %rax
     3ff: 48 01 f8                     	addq	%rdi, %rax
     402: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     408: eb 15                        	jmp	0x41f <trusted_x86_x86_sim_xdp+0x41f>
     40a: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     40e: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     413: ff 50 60                     	callq	*0x60(%rax)
     416: 48 85 c0                     	testq	%rax, %rax
     419: 0f 84 33 44 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     41f: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     423: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
     427: 0f b7 54 24 58               	movzwl	0x58(%rsp), %edx
     42c: 0f b7 00                     	movzwl	(%rax), %eax
     42f: 48 39 c2                     	cmpq	%rax, %rdx
     432: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
     436: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     43a: 45 39 fc                     	cmpl	%r15d, %r12d
     43d: 0f 83 92 06 00 00            	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     443: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
     447: d1 e8                        	shrl	%eax
     449: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
     44d: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     452: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     456: 75 2b                        	jne	0x483 <trusted_x86_x86_sim_xdp+0x483>
     458: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
     45d: 8b 00                        	movl	(%rax), %eax
     45f: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     462: 0f 83 ea 43 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     468: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     46e: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     474: 48 0f af c1                  	imulq	%rcx, %rax
     478: 48 01 f8                     	addq	%rdi, %rax
     47b: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     481: eb 15                        	jmp	0x498 <trusted_x86_x86_sim_xdp+0x498>
     483: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     487: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     48c: ff 50 60                     	callq	*0x60(%rax)
     48f: 48 85 c0                     	testq	%rax, %rax
     492: 0f 84 ba 43 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     498: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     49c: 8d 69 01                     	leal	0x1(%rcx), %ebp
     49f: 0f b7 54 24 58               	movzwl	0x58(%rsp), %edx
     4a4: 0f b7 00                     	movzwl	(%rax), %eax
     4a7: 48 39 c2                     	cmpq	%rax, %rdx
     4aa: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     4ae: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     4b2: 44 39 fd                     	cmpl	%r15d, %ebp
     4b5: 0f 83 1a 06 00 00            	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     4bb: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     4bf: d1 e8                        	shrl	%eax
     4c1: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
     4c5: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     4ca: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     4ce: 75 2b                        	jne	0x4fb <trusted_x86_x86_sim_xdp+0x4fb>
     4d0: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
     4d5: 8b 00                        	movl	(%rax), %eax
     4d7: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     4da: 0f 83 72 43 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     4e0: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     4e6: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     4ec: 48 0f af c1                  	imulq	%rcx, %rax
     4f0: 48 01 f8                     	addq	%rdi, %rax
     4f3: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     4f9: eb 15                        	jmp	0x510 <trusted_x86_x86_sim_xdp+0x510>
     4fb: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     4ff: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     504: ff 50 60                     	callq	*0x60(%rax)
     507: 48 85 c0                     	testq	%rax, %rax
     50a: 0f 84 42 43 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     510: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     514: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
     518: 0f b7 54 24 58               	movzwl	0x58(%rsp), %edx
     51d: 0f b7 00                     	movzwl	(%rax), %eax
     520: 48 39 c2                     	cmpq	%rax, %rdx
     523: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
     527: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     52b: 45 39 fc                     	cmpl	%r15d, %r12d
     52e: 0f 83 a1 05 00 00            	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     534: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
     538: d1 e8                        	shrl	%eax
     53a: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
     53e: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     543: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     547: 75 2b                        	jne	0x574 <trusted_x86_x86_sim_xdp+0x574>
     549: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
     54e: 8b 00                        	movl	(%rax), %eax
     550: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     553: 0f 83 f9 42 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     559: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     55f: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     565: 48 0f af c1                  	imulq	%rcx, %rax
     569: 48 01 f8                     	addq	%rdi, %rax
     56c: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     572: eb 15                        	jmp	0x589 <trusted_x86_x86_sim_xdp+0x589>
     574: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     578: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     57d: ff 50 60                     	callq	*0x60(%rax)
     580: 48 85 c0                     	testq	%rax, %rax
     583: 0f 84 c9 42 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     589: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     58d: 8d 69 01                     	leal	0x1(%rcx), %ebp
     590: 0f b7 54 24 58               	movzwl	0x58(%rsp), %edx
     595: 0f b7 00                     	movzwl	(%rax), %eax
     598: 48 39 c2                     	cmpq	%rax, %rdx
     59b: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     59f: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     5a3: 44 39 fd                     	cmpl	%r15d, %ebp
     5a6: 0f 83 29 05 00 00            	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     5ac: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     5b0: d1 e8                        	shrl	%eax
     5b2: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
     5b6: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     5bb: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     5bf: 75 2b                        	jne	0x5ec <trusted_x86_x86_sim_xdp+0x5ec>
     5c1: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
     5c6: 8b 00                        	movl	(%rax), %eax
     5c8: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     5cb: 0f 83 81 42 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     5d1: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     5d7: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     5dd: 48 0f af c1                  	imulq	%rcx, %rax
     5e1: 48 01 f8                     	addq	%rdi, %rax
     5e4: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     5ea: eb 15                        	jmp	0x601 <trusted_x86_x86_sim_xdp+0x601>
     5ec: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     5f0: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     5f5: ff 50 60                     	callq	*0x60(%rax)
     5f8: 48 85 c0                     	testq	%rax, %rax
     5fb: 0f 84 51 42 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     601: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     605: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
     609: 0f b7 54 24 58               	movzwl	0x58(%rsp), %edx
     60e: 0f b7 00                     	movzwl	(%rax), %eax
     611: 48 39 c2                     	cmpq	%rax, %rdx
     614: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
     618: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     61c: 45 39 fc                     	cmpl	%r15d, %r12d
     61f: 0f 83 b0 04 00 00            	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     625: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
     629: d1 e8                        	shrl	%eax
     62b: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
     62f: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     634: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     638: 75 2b                        	jne	0x665 <trusted_x86_x86_sim_xdp+0x665>
     63a: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
     63f: 8b 00                        	movl	(%rax), %eax
     641: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     644: 0f 83 08 42 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     64a: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     650: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     656: 48 0f af c1                  	imulq	%rcx, %rax
     65a: 48 01 f8                     	addq	%rdi, %rax
     65d: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     663: eb 15                        	jmp	0x67a <trusted_x86_x86_sim_xdp+0x67a>
     665: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     669: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     66e: ff 50 60                     	callq	*0x60(%rax)
     671: 48 85 c0                     	testq	%rax, %rax
     674: 0f 84 d8 41 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     67a: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     67e: 8d 69 01                     	leal	0x1(%rcx), %ebp
     681: 0f b7 54 24 58               	movzwl	0x58(%rsp), %edx
     686: 0f b7 00                     	movzwl	(%rax), %eax
     689: 48 39 c2                     	cmpq	%rax, %rdx
     68c: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     690: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     694: 44 39 fd                     	cmpl	%r15d, %ebp
     697: 0f 83 38 04 00 00            	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     69d: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     6a1: d1 e8                        	shrl	%eax
     6a3: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
     6a7: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     6ac: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     6b0: 75 2b                        	jne	0x6dd <trusted_x86_x86_sim_xdp+0x6dd>
     6b2: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
     6b7: 8b 00                        	movl	(%rax), %eax
     6b9: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     6bc: 0f 83 90 41 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     6c2: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     6c8: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     6ce: 48 0f af c1                  	imulq	%rcx, %rax
     6d2: 48 01 f8                     	addq	%rdi, %rax
     6d5: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     6db: eb 15                        	jmp	0x6f2 <trusted_x86_x86_sim_xdp+0x6f2>
     6dd: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     6e1: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     6e6: ff 50 60                     	callq	*0x60(%rax)
     6e9: 48 85 c0                     	testq	%rax, %rax
     6ec: 0f 84 60 41 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     6f2: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     6f6: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
     6fa: 0f b7 54 24 58               	movzwl	0x58(%rsp), %edx
     6ff: 0f b7 00                     	movzwl	(%rax), %eax
     702: 48 39 c2                     	cmpq	%rax, %rdx
     705: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
     709: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     70d: 45 39 fc                     	cmpl	%r15d, %r12d
     710: 0f 83 bf 03 00 00            	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     716: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
     71a: d1 e8                        	shrl	%eax
     71c: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
     720: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     725: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     729: 75 2b                        	jne	0x756 <trusted_x86_x86_sim_xdp+0x756>
     72b: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
     730: 8b 00                        	movl	(%rax), %eax
     732: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     735: 0f 83 17 41 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     73b: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     741: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     747: 48 0f af c1                  	imulq	%rcx, %rax
     74b: 48 01 f8                     	addq	%rdi, %rax
     74e: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     754: eb 15                        	jmp	0x76b <trusted_x86_x86_sim_xdp+0x76b>
     756: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     75a: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     75f: ff 50 60                     	callq	*0x60(%rax)
     762: 48 85 c0                     	testq	%rax, %rax
     765: 0f 84 e7 40 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     76b: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     76f: 8d 69 01                     	leal	0x1(%rcx), %ebp
     772: 0f b7 54 24 58               	movzwl	0x58(%rsp), %edx
     777: 0f b7 00                     	movzwl	(%rax), %eax
     77a: 48 39 c2                     	cmpq	%rax, %rdx
     77d: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     781: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     785: 44 39 fd                     	cmpl	%r15d, %ebp
     788: 0f 83 47 03 00 00            	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     78e: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     792: d1 e8                        	shrl	%eax
     794: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
     798: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     79d: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     7a1: 75 2b                        	jne	0x7ce <trusted_x86_x86_sim_xdp+0x7ce>
     7a3: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
     7a8: 8b 00                        	movl	(%rax), %eax
     7aa: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     7ad: 0f 83 9f 40 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     7b3: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     7b9: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     7bf: 48 0f af c1                  	imulq	%rcx, %rax
     7c3: 48 01 f8                     	addq	%rdi, %rax
     7c6: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     7cc: eb 15                        	jmp	0x7e3 <trusted_x86_x86_sim_xdp+0x7e3>
     7ce: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     7d2: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     7d7: ff 50 60                     	callq	*0x60(%rax)
     7da: 48 85 c0                     	testq	%rax, %rax
     7dd: 0f 84 6f 40 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     7e3: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     7e7: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
     7eb: 0f b7 54 24 58               	movzwl	0x58(%rsp), %edx
     7f0: 0f b7 00                     	movzwl	(%rax), %eax
     7f3: 48 39 c2                     	cmpq	%rax, %rdx
     7f6: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
     7fa: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     7fe: 45 39 fc                     	cmpl	%r15d, %r12d
     801: 0f 83 ce 02 00 00            	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     807: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
     80b: d1 e8                        	shrl	%eax
     80d: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
     811: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     816: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     81a: 75 2b                        	jne	0x847 <trusted_x86_x86_sim_xdp+0x847>
     81c: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
     821: 8b 00                        	movl	(%rax), %eax
     823: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     826: 0f 83 26 40 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     82c: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     832: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     838: 48 0f af c1                  	imulq	%rcx, %rax
     83c: 48 01 f8                     	addq	%rdi, %rax
     83f: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     845: eb 15                        	jmp	0x85c <trusted_x86_x86_sim_xdp+0x85c>
     847: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     84b: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     850: ff 50 60                     	callq	*0x60(%rax)
     853: 48 85 c0                     	testq	%rax, %rax
     856: 0f 84 f6 3f 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     85c: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     860: 8d 69 01                     	leal	0x1(%rcx), %ebp
     863: 0f b7 54 24 58               	movzwl	0x58(%rsp), %edx
     868: 0f b7 00                     	movzwl	(%rax), %eax
     86b: 48 39 c2                     	cmpq	%rax, %rdx
     86e: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     872: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     876: 44 39 fd                     	cmpl	%r15d, %ebp
     879: 0f 83 56 02 00 00            	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     87f: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     883: d1 e8                        	shrl	%eax
     885: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
     889: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     88e: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     892: 75 2b                        	jne	0x8bf <trusted_x86_x86_sim_xdp+0x8bf>
     894: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
     899: 8b 00                        	movl	(%rax), %eax
     89b: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     89e: 0f 83 ae 3f 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     8a4: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     8aa: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     8b0: 48 0f af c1                  	imulq	%rcx, %rax
     8b4: 48 01 f8                     	addq	%rdi, %rax
     8b7: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     8bd: eb 15                        	jmp	0x8d4 <trusted_x86_x86_sim_xdp+0x8d4>
     8bf: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     8c3: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     8c8: ff 50 60                     	callq	*0x60(%rax)
     8cb: 48 85 c0                     	testq	%rax, %rax
     8ce: 0f 84 7e 3f 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     8d4: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     8d8: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
     8dc: 0f b7 54 24 58               	movzwl	0x58(%rsp), %edx
     8e1: 0f b7 00                     	movzwl	(%rax), %eax
     8e4: 48 39 c2                     	cmpq	%rax, %rdx
     8e7: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
     8eb: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     8ef: 45 39 fc                     	cmpl	%r15d, %r12d
     8f2: 0f 83 dd 01 00 00            	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     8f8: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
     8fc: d1 e8                        	shrl	%eax
     8fe: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
     902: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     907: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     90b: 75 2b                        	jne	0x938 <trusted_x86_x86_sim_xdp+0x938>
     90d: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
     912: 8b 00                        	movl	(%rax), %eax
     914: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     917: 0f 83 35 3f 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     91d: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     923: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     929: 48 0f af c1                  	imulq	%rcx, %rax
     92d: 48 01 f8                     	addq	%rdi, %rax
     930: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     936: eb 15                        	jmp	0x94d <trusted_x86_x86_sim_xdp+0x94d>
     938: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     93c: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     941: ff 50 60                     	callq	*0x60(%rax)
     944: 48 85 c0                     	testq	%rax, %rax
     947: 0f 84 05 3f 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     94d: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     951: 8d 69 01                     	leal	0x1(%rcx), %ebp
     954: 0f b7 54 24 58               	movzwl	0x58(%rsp), %edx
     959: 0f b7 00                     	movzwl	(%rax), %eax
     95c: 48 39 c2                     	cmpq	%rax, %rdx
     95f: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     963: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     967: 44 39 fd                     	cmpl	%r15d, %ebp
     96a: 0f 83 65 01 00 00            	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     970: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     974: d1 e8                        	shrl	%eax
     976: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
     97a: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     97f: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     983: 75 2b                        	jne	0x9b0 <trusted_x86_x86_sim_xdp+0x9b0>
     985: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
     98a: 8b 00                        	movl	(%rax), %eax
     98c: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     98f: 0f 83 bd 3e 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     995: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     99b: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     9a1: 48 0f af c1                  	imulq	%rcx, %rax
     9a5: 48 01 f8                     	addq	%rdi, %rax
     9a8: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     9ae: eb 15                        	jmp	0x9c5 <trusted_x86_x86_sim_xdp+0x9c5>
     9b0: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     9b4: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     9b9: ff 50 60                     	callq	*0x60(%rax)
     9bc: 48 85 c0                     	testq	%rax, %rax
     9bf: 0f 84 8d 3e 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     9c5: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     9c9: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
     9cd: 0f b7 54 24 58               	movzwl	0x58(%rsp), %edx
     9d2: 0f b7 00                     	movzwl	(%rax), %eax
     9d5: 48 39 c2                     	cmpq	%rax, %rdx
     9d8: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
     9dc: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     9e0: 45 39 fc                     	cmpl	%r15d, %r12d
     9e3: 0f 83 ec 00 00 00            	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     9e9: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
     9ed: d1 e8                        	shrl	%eax
     9ef: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
     9f3: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     9f8: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     9fc: 75 2b                        	jne	0xa29 <trusted_x86_x86_sim_xdp+0xa29>
     9fe: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
     a03: 8b 00                        	movl	(%rax), %eax
     a05: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     a08: 0f 83 44 3e 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     a0e: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     a14: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     a1a: 48 0f af c1                  	imulq	%rcx, %rax
     a1e: 48 01 f8                     	addq	%rdi, %rax
     a21: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     a27: eb 15                        	jmp	0xa3e <trusted_x86_x86_sim_xdp+0xa3e>
     a29: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     a2d: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     a32: ff 50 60                     	callq	*0x60(%rax)
     a35: 48 85 c0                     	testq	%rax, %rax
     a38: 0f 84 14 3e 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     a3e: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     a42: 8d 69 01                     	leal	0x1(%rcx), %ebp
     a45: 0f b7 54 24 58               	movzwl	0x58(%rsp), %edx
     a4a: 0f b7 00                     	movzwl	(%rax), %eax
     a4d: 48 39 c2                     	cmpq	%rax, %rdx
     a50: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     a54: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     a58: 44 39 fd                     	cmpl	%r15d, %ebp
     a5b: 73 78                        	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     a5d: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     a61: d1 e8                        	shrl	%eax
     a63: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
     a67: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     a6c: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     a70: 75 2b                        	jne	0xa9d <trusted_x86_x86_sim_xdp+0xa9d>
     a72: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
     a77: 8b 00                        	movl	(%rax), %eax
     a79: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     a7c: 0f 83 d0 3d 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     a82: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     a88: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     a8e: 48 0f af c1                  	imulq	%rcx, %rax
     a92: 48 01 f8                     	addq	%rdi, %rax
     a95: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     a9b: eb 15                        	jmp	0xab2 <trusted_x86_x86_sim_xdp+0xab2>
     a9d: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     aa1: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
     aa6: ff 50 60                     	callq	*0x60(%rax)
     aa9: 48 85 c0                     	testq	%rax, %rax
     aac: 0f 84 a0 3d 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     ab2: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
     ab6: 8d 51 01                     	leal	0x1(%rcx), %edx
     ab9: 0f b7 74 24 58               	movzwl	0x58(%rsp), %esi
     abe: 0f b7 00                     	movzwl	(%rax), %eax
     ac1: 48 39 c6                     	cmpq	%rax, %rsi
     ac4: 0f 42 d5                     	cmovbl	%ebp, %edx
     ac7: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     acb: 44 39 fa                     	cmpl	%r15d, %edx
     ace: 73 05                        	jae	0xad5 <trusted_x86_x86_sim_xdp+0xad5>
     ad0: e9 7d 3d 00 00               	jmp	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     ad5: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
     ada: 45 85 ff                     	testl	%r15d, %r15d
     add: 48 8d 6c 24 68               	leaq	0x68(%rsp), %rbp
     ae2: 0f 84 6a 3d 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
     ae8: 41 ff cf                     	decl	%r15d
     aeb: 48 8d 74 24 64               	leaq	0x64(%rsp), %rsi
     af0: 44 89 7c 24 64               	movl	%r15d, 0x64(%rsp)
     af5: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     af9: 75 28                        	jne	0xb23 <trusted_x86_x86_sim_xdp+0xb23>
     afb: 8b 44 24 64                  	movl	0x64(%rsp), %eax
     aff: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     b02: 0f 83 3a 3e 00 00            	jae	0x4942 <trusted_x86_x86_sim_xdp+0x4942>
     b08: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     b0e: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     b14: 48 0f af c1                  	imulq	%rcx, %rax
     b18: 48 01 f8                     	addq	%rdi, %rax
     b1b: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     b21: eb 10                        	jmp	0xb33 <trusted_x86_x86_sim_xdp+0xb33>
     b23: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     b27: ff 50 60                     	callq	*0x60(%rax)
     b2a: 48 85 c0                     	testq	%rax, %rax
     b2d: 0f 84 0f 3e 00 00            	je	0x4942 <trusted_x86_x86_sim_xdp+0x4942>
     b33: 0f b7 4c 24 58               	movzwl	0x58(%rsp), %ecx
     b38: 48 89 c2                     	movq	%rax, %rdx
     b3b: 0f b7 12                     	movzwl	(%rdx), %edx
     b3e: 29 d1                        	subl	%edx, %ecx
     b40: 8b 54 24 64                  	movl	0x64(%rsp), %edx
     b44: 48 8b 74 24 08               	movq	0x8(%rsp), %rsi
     b49: 8b 36                        	movl	(%rsi), %esi
     b4b: 44 8d b9 00 00 01 00         	leal	0x10000(%rcx), %r15d
     b52: 39 d6                        	cmpl	%edx, %esi
     b54: 44 0f 46 f9                  	cmovbel	%ecx, %r15d
     b58: 0f b7 40 02                  	movzwl	0x2(%rax), %eax
     b5c: 89 44 24 60                  	movl	%eax, 0x60(%rsp)
     b60: c7 44 24 08 a5 0f 00 00      	movl	$0xfa5, 0x8(%rsp)       # imm = 0xFA5
     b68: c7 44 24 04 0d 00 00 00      	movl	$0xd, 0x4(%rsp)
     b70: 3d 00 80 00 00               	cmpl	$0x8000, %eax           # imm = 0x8000
     b75: 0f 84 d7 3d 00 00            	je	0x4952 <trusted_x86_x86_sim_xdp+0x4952>
     b7b: 3d 01 80 00 00               	cmpl	$0x8001, %eax           # imm = 0x8001
     b80: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0xb87 <trusted_x86_x86_sim_xdp+0xb87>
		0000000000000b83:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     b87: 75 3b                        	jne	0xbc4 <trusted_x86_x86_sim_xdp+0xbc4>
     b89: c7 44 24 3c 07 00 00 00      	movl	$0x7, 0x3c(%rsp)
     b91: 83 79 44 08                  	cmpl	$0x8, 0x44(%rcx)
     b95: 72 29                        	jb	0xbc0 <trusted_x86_x86_sim_xdp+0xbc0>
     b97: b8 07 00 00 00               	movl	$0x7, %eax
     b9c: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
     ba2: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
     baa: e8 00 00 00 00               	callq	0xbaf <trusted_x86_x86_sim_xdp+0xbaf>
		0000000000000bab:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     baf: 48 85 c0                     	testq	%rax, %rax
     bb2: 74 0c                        	je	0xbc0 <trusted_x86_x86_sim_xdp+0xbc0>
     bb4: 48 89 c1                     	movq	%rax, %rcx
     bb7: 48 8b 09                     	movq	(%rcx), %rcx
     bba: 48 ff c1                     	incq	%rcx
     bbd: 48 89 08                     	movq	%rcx, (%rax)
     bc0: 8b 44 24 60                  	movl	0x60(%rsp), %eax
     bc4: 4c 8d a4 24 b8 00 00 00      	leaq	0xb8(%rsp), %r12
     bcc: 48 8d 8b d0 0e 00 00         	leaq	0xed0(%rbx), %rcx
     bd3: 48 89 8c 24 80 01 00 00      	movq	%rcx, 0x180(%rsp)
     bdb: 48 8d 8b e0 0e 00 00         	leaq	0xee0(%rbx), %rcx
     be2: 48 89 4c 24 58               	movq	%rcx, 0x58(%rsp)
     be7: 48 8d 93 d8 0e 00 00         	leaq	0xed8(%rbx), %rdx
     bee: 48 8d b3 e8 0e 00 00         	leaq	0xee8(%rbx), %rsi
     bf5: 48 89 b4 24 a8 01 00 00      	movq	%rsi, 0x1a8(%rsp)
     bfd: 4c 8d 9b f0 0e 00 00         	leaq	0xef0(%rbx), %r11
     c04: 48 8d b3 f8 0e 00 00         	leaq	0xef8(%rbx), %rsi
     c0b: 4c 8d 93 08 0f 00 00         	leaq	0xf08(%rbx), %r10
     c12: 66 85 c0                     	testw	%ax, %ax
     c15: 78 6b                        	js	0xc82 <trusted_x86_x86_sim_xdp+0xc82>
     c17: 48 89 b4 24 98 00 00 00      	movq	%rsi, 0x98(%rsp)
     c1f: 4c 89 9c 24 a0 00 00 00      	movq	%r11, 0xa0(%rsp)
     c27: 48 89 94 24 88 00 00 00      	movq	%rdx, 0x88(%rsp)
     c2f: 4c 89 54 24 50               	movq	%r10, 0x50(%rsp)
     c34: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0xc3b <trusted_x86_x86_sim_xdp+0xc3b>
		0000000000000c37:  R_X86_64_REX_GOTPCRELX	unwind_info_array-0x4
     c3b: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0xc42 <trusted_x86_x86_sim_xdp+0xc42>
		0000000000000c3e:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     c42: 48 89 94 24 88 01 00 00      	movq	%rdx, 0x188(%rsp)
     c4a: 48 89 8c 24 98 01 00 00      	movq	%rcx, 0x198(%rsp)
     c52: 48 89 74 24 30               	movq	%rsi, 0x30(%rsp)
     c57: 74 66                        	je	0xcbf <trusted_x86_x86_sim_xdp+0xcbf>
     c59: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0xc60 <trusted_x86_x86_sim_xdp+0xc60>
		0000000000000c5c:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
     c60: 74 5d                        	je	0xcbf <trusted_x86_x86_sim_xdp+0xcbf>
     c62: 48 8d 7c 24 60               	leaq	0x60(%rsp), %rdi
     c67: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0xc6e <trusted_x86_x86_sim_xdp+0xc6e>
		0000000000000c6a:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
     c6e: 75 7c                        	jne	0xcec <trusted_x86_x86_sim_xdp+0xcec>
     c70: 4c 89 5c 24 20               	movq	%r11, 0x20(%rsp)
     c75: 4d 89 d4                     	movq	%r10, %r12
     c78: e8 00 00 00 00               	callq	0xc7d <trusted_x86_x86_sim_xdp+0xc7d>
		0000000000000c79:  R_X86_64_PLT32	.text+0x7c
     c7d: e9 aa 02 00 00               	jmp	0xf2c <trusted_x86_x86_sim_xdp+0xf2c>
     c82: 48 89 ef                     	movq	%rbp, %rdi
     c85: 25 ff 7f ff ff               	andl	$0xffff7fff, %eax       # imm = 0xFFFF7FFF
     c8a: ff c8                        	decl	%eax
     c8c: 4c 8b bc 24 80 00 00 00      	movq	0x80(%rsp), %r15
     c94: 31 ed                        	xorl	%ebp, %ebp
     c96: 83 f8 03                     	cmpl	$0x3, %eax
     c99: 0f 87 27 3d 00 00            	ja	0x49c6 <trusted_x86_x86_sim_xdp+0x49c6>
     c9f: 48 89 8c 24 98 01 00 00      	movq	%rcx, 0x198(%rsp)
     ca7: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0xcae <trusted_x86_x86_sim_xdp+0xcae>
		0000000000000caa:  R_X86_64_PC32	.rodata-0x4
     cae: 48 63 04 81                  	movslq	(%rcx,%rax,4), %rax
     cb2: 48 01 c8                     	addq	%rcx, %rax
     cb5: ff e0                        	jmpq	*%rax
     cb7: 45 31 e4                     	xorl	%r12d, %r12d
     cba: e9 29 1f 00 00               	jmp	0x2be8 <trusted_x86_x86_sim_xdp+0x2be8>
     cbf: 8b 4c 24 60                  	movl	0x60(%rsp), %ecx
     cc3: 3b 48 44                     	cmpl	0x44(%rax), %ecx
     cc6: 0f 83 47 3f 00 00            	jae	0x4c13 <trusted_x86_x86_sim_xdp+0x4c13>
     ccc: 4c 89 5c 24 20               	movq	%r11, 0x20(%rsp)
     cd1: 4d 89 d4                     	movq	%r10, %r12
     cd4: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
     cda: 48 8b bc c8 30 01 00 00      	movq	0x130(%rax,%rcx,8), %rdi
     ce2: e8 00 00 00 00               	callq	0xce7 <trusted_x86_x86_sim_xdp+0xce7>
		0000000000000ce3:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     ce7: e9 40 02 00 00               	jmp	0xf2c <trusted_x86_x86_sim_xdp+0xf2c>
     cec: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0xcf3 <trusted_x86_x86_sim_xdp+0xcf3>
		0000000000000cef:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
     cf3: 0f 85 19 02 00 00            	jne	0xf12 <trusted_x86_x86_sim_xdp+0xf12>
     cf9: 4c 89 5c 24 20               	movq	%r11, 0x20(%rsp)
     cfe: 4d 89 d4                     	movq	%r10, %r12
     d01: e8 00 00 00 00               	callq	0xd06 <trusted_x86_x86_sim_xdp+0xd06>
		0000000000000d02:  R_X86_64_PLT32	.text+0x12c
     d06: e9 21 02 00 00               	jmp	0xf2c <trusted_x86_x86_sim_xdp+0xf2c>
     d0b: 48 89 74 24 30               	movq	%rsi, 0x30(%rsp)
     d10: 48 89 b4 24 98 00 00 00      	movq	%rsi, 0x98(%rsp)
     d18: 4c 89 5c 24 20               	movq	%r11, 0x20(%rsp)
     d1d: 4c 89 9c 24 a0 00 00 00      	movq	%r11, 0xa0(%rsp)
     d25: 4c 89 54 24 28               	movq	%r10, 0x28(%rsp)
     d2a: 4c 89 54 24 50               	movq	%r10, 0x50(%rsp)
     d2f: 48 89 94 24 88 00 00 00      	movq	%rdx, 0x88(%rsp)
     d37: 48 89 d5                     	movq	%rdx, %rbp
     d3a: 48 89 d0                     	movq	%rdx, %rax
     d3d: 48 8b 30                     	movq	(%rax), %rsi
     d40: 48 83 c6 28                  	addq	$0x28, %rsi
     d44: ba 90 00 00 00               	movl	$0x90, %edx
     d49: 4c 89 e7                     	movq	%r12, %rdi
     d4c: e8 00 00 00 00               	callq	0xd51 <trusted_x86_x86_sim_xdp+0xd51>
		0000000000000d4d:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     d51: 49 89 c7                     	movq	%rax, %r15
     d54: 45 85 ff                     	testl	%r15d, %r15d
     d57: 79 0f                        	jns	0xd68 <trusted_x86_x86_sim_xdp+0xd68>
     d59: ba 90 00 00 00               	movl	$0x90, %edx
     d5e: 4c 89 e7                     	movq	%r12, %rdi
     d61: 31 f6                        	xorl	%esi, %esi
     d63: e8 00 00 00 00               	callq	0xd68 <trusted_x86_x86_sim_xdp+0xd68>
		0000000000000d64:  R_X86_64_PLT32	memset-0x4
     d68: 45 85 ff                     	testl	%r15d, %r15d
     d6b: 48 8b 54 24 28               	movq	0x28(%rsp), %rdx
     d70: 48 8b 74 24 30               	movq	0x30(%rsp), %rsi
     d75: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
     d7a: 0f 85 95 04 00 00            	jne	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
     d80: 48 8b 84 24 20 01 00 00      	movq	0x120(%rsp), %rax
     d88: 4c 8b a4 24 a8 01 00 00      	movq	0x1a8(%rsp), %r12
     d90: 4c 89 e1                     	movq	%r12, %rcx
     d93: 48 89 01                     	movq	%rax, (%rcx)
     d96: 48 8b 84 24 c0 00 00 00      	movq	0xc0(%rsp), %rax
     d9e: 48 89 f9                     	movq	%rdi, %rcx
     da1: 48 89 01                     	movq	%rax, (%rcx)
     da4: 48 8b 84 24 d0 00 00 00      	movq	0xd0(%rsp), %rax
     dac: 48 89 f1                     	movq	%rsi, %rcx
     daf: 48 89 01                     	movq	%rax, (%rcx)
     db2: 48 8b 84 24 e0 00 00 00      	movq	0xe0(%rsp), %rax
     dba: 48 8d 8b 00 0f 00 00         	leaq	0xf00(%rbx), %rcx
     dc1: 48 89 01                     	movq	%rax, (%rcx)
     dc4: 48 8b 84 24 f0 00 00 00      	movq	0xf0(%rsp), %rax
     dcc: 48 89 d1                     	movq	%rdx, %rcx
     dcf: 48 89 01                     	movq	%rax, (%rcx)
     dd2: 48 8b 84 24 08 01 00 00      	movq	0x108(%rsp), %rax
     dda: 48 8b 8c 24 98 01 00 00      	movq	0x198(%rsp), %rcx
     de2: 48 89 01                     	movq	%rax, (%rcx)
     de5: 48 8b 84 24 30 01 00 00      	movq	0x130(%rsp), %rax
     ded: 48 89 ea                     	movq	%rbp, %rdx
     df0: 48 89 e9                     	movq	%rbp, %rcx
     df3: 48 89 01                     	movq	%rax, (%rcx)
     df6: 48 8b 84 24 38 01 00 00      	movq	0x138(%rsp), %rax
     dfe: 48 8b ac 24 80 01 00 00      	movq	0x180(%rsp), %rbp
     e06: 48 89 e9                     	movq	%rbp, %rcx
     e09: 48 89 01                     	movq	%rax, (%rcx)
     e0c: 48 8d 83 30 0f 00 00         	leaq	0xf30(%rbx), %rax
     e13: 31 c9                        	xorl	%ecx, %ecx
     e15: e9 5d 04 00 00               	jmp	0x1277 <trusted_x86_x86_sim_xdp+0x1277>
     e1a: 48 89 74 24 30               	movq	%rsi, 0x30(%rsp)
     e1f: 48 89 b4 24 98 00 00 00      	movq	%rsi, 0x98(%rsp)
     e27: 4c 89 5c 24 20               	movq	%r11, 0x20(%rsp)
     e2c: 4c 89 9c 24 a0 00 00 00      	movq	%r11, 0xa0(%rsp)
     e34: 49 89 d4                     	movq	%rdx, %r12
     e37: 48 89 94 24 88 00 00 00      	movq	%rdx, 0x88(%rsp)
     e3f: 4c 89 54 24 28               	movq	%r10, 0x28(%rsp)
     e44: 4c 89 54 24 50               	movq	%r10, 0x50(%rsp)
     e49: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
     e4e: 48 8b 30                     	movq	(%rax), %rsi
     e51: ba 10 00 00 00               	movl	$0x10, %edx
     e56: 49 89 ff                     	movq	%rdi, %r15
     e59: e8 00 00 00 00               	callq	0xe5e <trusted_x86_x86_sim_xdp+0xe5e>
		0000000000000e5a:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     e5e: 85 c0                        	testl	%eax, %eax
     e60: 79 0f                        	jns	0xe71 <trusted_x86_x86_sim_xdp+0xe71>
     e62: 49 c7 47 08 00 00 00 00      	movq	$0x0, 0x8(%r15)
     e6a: 49 c7 07 00 00 00 00         	movq	$0x0, (%r15)
     e71: 85 c0                        	testl	%eax, %eax
     e73: 0f 85 9c 03 00 00            	jne	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
     e79: 48 89 d8                     	movq	%rbx, %rax
     e7c: 48 8b 80 e0 0e 00 00         	movq	0xee0(%rax), %rax
     e83: 48 83 c0 10                  	addq	$0x10, %rax
     e87: 4c 89 e2                     	movq	%r12, %rdx
     e8a: 4c 89 e1                     	movq	%r12, %rcx
     e8d: 48 89 01                     	movq	%rax, (%rcx)
     e90: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
     e95: 48 8b 8c 24 98 01 00 00      	movq	0x198(%rsp), %rcx
     e9d: 48 89 01                     	movq	%rax, (%rcx)
     ea0: 4c 8b 7c 24 70               	movq	0x70(%rsp), %r15
     ea5: 48 8b ac 24 80 01 00 00      	movq	0x180(%rsp), %rbp
     ead: 48 89 e8                     	movq	%rbp, %rax
     eb0: 4c 8b a4 24 a8 01 00 00      	movq	0x1a8(%rsp), %r12
     eb8: e9 ae 03 00 00               	jmp	0x126b <trusted_x86_x86_sim_xdp+0x126b>
     ebd: 48 89 b4 24 98 00 00 00      	movq	%rsi, 0x98(%rsp)
     ec5: 4c 89 9c 24 a0 00 00 00      	movq	%r11, 0xa0(%rsp)
     ecd: 4c 89 54 24 50               	movq	%r10, 0x50(%rsp)
     ed2: 48 89 94 24 88 00 00 00      	movq	%rdx, 0x88(%rsp)
     eda: 48 89 94 24 88 01 00 00      	movq	%rdx, 0x188(%rsp)
     ee2: 48 89 d0                     	movq	%rdx, %rax
     ee5: 48 8b 00                     	movq	(%rax), %rax
     ee8: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
     ef0: 8b 09                        	movl	(%rcx), %ecx
     ef2: 83 e1 0f                     	andl	$0xf, %ecx
     ef5: 31 d2                        	xorl	%edx, %edx
     ef7: 83 f9 0b                     	cmpl	$0xb, %ecx
     efa: 0f 93 c2                     	setae	%dl
     efd: 4c 8d 3c d0                  	leaq	(%rax,%rdx,8), %r15
     f01: 49 83 c7 08                  	addq	$0x8, %r15
     f05: 4c 8b a4 24 a8 01 00 00      	movq	0x1a8(%rsp), %r12
     f0d: e9 be 02 00 00               	jmp	0x11d0 <trusted_x86_x86_sim_xdp+0x11d0>
     f12: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0xf19 <trusted_x86_x86_sim_xdp+0xf19>
		0000000000000f15:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
     f19: 0f 85 c9 00 00 00            	jne	0xfe8 <trusted_x86_x86_sim_xdp+0xfe8>
     f1f: 4c 89 5c 24 20               	movq	%r11, 0x20(%rsp)
     f24: 4d 89 d4                     	movq	%r10, %r12
     f27: e8 00 00 00 00               	callq	0xf2c <trusted_x86_x86_sim_xdp+0xf2c>
		0000000000000f28:  R_X86_64_PLT32	.text+0x1dc
     f2c: 48 85 c0                     	testq	%rax, %rax
     f2f: 4d 89 e2                     	movq	%r12, %r10
     f32: 4c 8b 5c 24 20               	movq	0x20(%rsp), %r11
     f37: 0f 84 d6 3c 00 00            	je	0x4c13 <trusted_x86_x86_sim_xdp+0x4c13>
     f3d: 48 8b 8c 24 a8 01 00 00      	movq	0x1a8(%rsp), %rcx
     f45: 48 89 8c 24 90 00 00 00      	movq	%rcx, 0x90(%rsp)
     f4d: 48 89 c1                     	movq	%rax, %rcx
     f50: 44 8b 61 04                  	movl	0x4(%rcx), %r12d
     f54: 48 89 c1                     	movq	%rax, %rcx
     f57: 0f b6 51 02                  	movzbl	0x2(%rcx), %edx
     f5b: 85 d2                        	testl	%edx, %edx
     f5d: 74 30                        	je	0xf8f <trusted_x86_x86_sim_xdp+0xf8f>
     f5f: 89 d6                        	movl	%edx, %esi
     f61: 83 e6 7f                     	andl	$0x7f, %esi
     f64: 49 c1 e7 20                  	shlq	$0x20, %r15
     f68: 48 c1 e6 20                  	shlq	$0x20, %rsi
     f6c: 48 8b 4c 24 50               	movq	0x50(%rsp), %rcx
     f71: 48 89 8c 24 90 01 00 00      	movq	%rcx, 0x190(%rsp)
     f79: 49 39 f7                     	cmpq	%rsi, %r15
     f7c: 7c 1e                        	jl	0xf9c <trusted_x86_x86_sim_xdp+0xf9c>
     f7e: f7 d2                        	notl	%edx
     f80: c1 ea 03                     	shrl	$0x3, %edx
     f83: 83 e2 10                     	andl	$0x10, %edx
     f86: 41 01 d4                     	addl	%edx, %r12d
     f89: 41 83 c4 f8                  	addl	$-0x8, %r12d
     f8d: eb 0d                        	jmp	0xf9c <trusted_x86_x86_sim_xdp+0xf9c>
     f8f: 48 8b 4c 24 50               	movq	0x50(%rsp), %rcx
     f94: 48 89 8c 24 90 01 00 00      	movq	%rcx, 0x190(%rsp)
     f9c: 48 8b 4c 24 58               	movq	0x58(%rsp), %rcx
     fa1: 48 89 c2                     	movq	%rax, %rdx
     fa4: 0f b6 12                     	movzbl	(%rdx), %edx
     fa7: 44 89 e6                     	movl	%r12d, %esi
     faa: 83 e6 f8                     	andl	$-0x8, %esi
     fad: 84 d2                        	testb	%dl, %dl
     faf: 41 0f 49 f4                  	cmovnsl	%r12d, %esi
     fb3: 89 d7                        	movl	%edx, %edi
     fb5: 83 e7 7f                     	andl	$0x7f, %edi
     fb8: 44 8d 47 ff                  	leal	-0x1(%rdi), %r8d
     fbc: 41 83 f8 04                  	cmpl	$0x4, %r8d
     fc0: 48 89 8c 24 a0 01 00 00      	movq	%rcx, 0x1a0(%rsp)
     fc8: 77 67                        	ja	0x1031 <trusted_x86_x86_sim_xdp+0x1031>
     fca: 40 0f b6 ff                  	movzbl	%dil, %edi
     fce: 45 31 ff                     	xorl	%r15d, %r15d
     fd1: ff cf                        	decl	%edi
     fd3: 4c 8d 05 00 00 00 00         	leaq	(%rip), %r8             # 0xfda <trusted_x86_x86_sim_xdp+0xfda>
		0000000000000fd6:  R_X86_64_PC32	.rodata+0xc
     fda: 4d 63 0c b8                  	movslq	(%r8,%rdi,4), %r9
     fde: 4d 01 c1                     	addq	%r8, %r9
     fe1: 41 ff e1                     	jmpq	*%r9
     fe4: 31 ff                        	xorl	%edi, %edi
     fe6: eb 59                        	jmp	0x1041 <trusted_x86_x86_sim_xdp+0x1041>
     fe8: 8b 4c 24 60                  	movl	0x60(%rsp), %ecx
     fec: 3b 48 44                     	cmpl	0x44(%rax), %ecx
     fef: 0f 83 1e 3c 00 00            	jae	0x4c13 <trusted_x86_x86_sim_xdp+0x4c13>
     ff5: 8b 90 20 01 00 00            	movl	0x120(%rax), %edx
     ffb: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    1001: 48 0f af ca                  	imulq	%rdx, %rcx
    1005: 48 01 c8                     	addq	%rcx, %rax
    1008: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    100e: e9 2a ff ff ff               	jmp	0xf3d <trusted_x86_x86_sim_xdp+0xf3d>
    1013: 44 89 e2                     	movl	%r12d, %edx
    1016: 83 e2 0f                     	andl	$0xf, %edx
    1019: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0x1020 <trusted_x86_x86_sim_xdp+0x1020>
		000000000000101c:  R_X86_64_PC32	.rodata+0x20
    1020: 48 63 3c 96                  	movslq	(%rsi,%rdx,4), %rdi
    1024: 48 01 f7                     	addq	%rsi, %rdi
    1027: 48 8b 94 24 90 01 00 00      	movq	0x190(%rsp), %rdx
    102f: ff e7                        	jmpq	*%rdi
    1031: 45 31 ff                     	xorl	%r15d, %r15d
    1034: eb 7c                        	jmp	0x10b2 <trusted_x86_x86_sim_xdp+0x10b2>
    1036: 48 8b 8c 24 88 00 00 00      	movq	0x88(%rsp), %rcx
    103e: 48 8b 39                     	movq	(%rcx), %rdi
    1041: 4c 63 fe                     	movslq	%esi, %r15
    1044: 49 01 ff                     	addq	%rdi, %r15
    1047: 84 d2                        	testb	%dl, %dl
    1049: 79 67                        	jns	0x10b2 <trusted_x86_x86_sim_xdp+0x10b2>
    104b: 4c 89 5c 24 20               	movq	%r11, 0x20(%rsp)
    1050: 4c 89 54 24 28               	movq	%r10, 0x28(%rsp)
    1055: 48 89 ef                     	movq	%rbp, %rdi
    1058: 48 89 84 24 b0 01 00 00      	movq	%rax, 0x1b0(%rsp)
    1060: ba 08 00 00 00               	movl	$0x8, %edx
    1065: 4c 89 fe                     	movq	%r15, %rsi
    1068: e8 00 00 00 00               	callq	0x106d <trusted_x86_x86_sim_xdp+0x106d>
		0000000000001069:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    106d: 85 c0                        	testl	%eax, %eax
    106f: 79 09                        	jns	0x107a <trusted_x86_x86_sim_xdp+0x107a>
    1071: 48 c7 44 24 68 00 00 00 00   	movq	$0x0, 0x68(%rsp)
    107a: 85 c0                        	testl	%eax, %eax
    107c: 74 05                        	je	0x1083 <trusted_x86_x86_sim_xdp+0x1083>
    107e: 45 31 ff                     	xorl	%r15d, %r15d
    1081: eb 10                        	jmp	0x1093 <trusted_x86_x86_sim_xdp+0x1093>
    1083: 41 c1 e4 03                  	shll	$0x3, %r12d
    1087: 41 83 e4 38                  	andl	$0x38, %r12d
    108b: 4c 03 64 24 68               	addq	0x68(%rsp), %r12
    1090: 4d 89 e7                     	movq	%r12, %r15
    1093: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
    1098: 48 89 84 24 90 01 00 00      	movq	%rax, 0x190(%rsp)
    10a0: 48 8b 84 24 b0 01 00 00      	movq	0x1b0(%rsp), %rax
    10a8: 4c 8b 54 24 28               	movq	0x28(%rsp), %r10
    10ad: 4c 8b 5c 24 20               	movq	0x20(%rsp), %r11
    10b2: 48 89 c2                     	movq	%rax, %rdx
    10b5: 0f b6 52 01                  	movzbl	0x1(%rdx), %edx
    10b9: 48 89 c6                     	movq	%rax, %rsi
    10bc: 44 8b 66 08                  	movl	0x8(%rsi), %r12d
    10c0: 44 89 e6                     	movl	%r12d, %esi
    10c3: 83 e6 f8                     	andl	$-0x8, %esi
    10c6: 84 d2                        	testb	%dl, %dl
    10c8: 41 0f 49 f4                  	cmovnsl	%r12d, %esi
    10cc: 89 d7                        	movl	%edx, %edi
    10ce: 83 e7 7f                     	andl	$0x7f, %edi
    10d1: 44 8d 47 ff                  	leal	-0x1(%rdi), %r8d
    10d5: 41 83 f8 04                  	cmpl	$0x4, %r8d
    10d9: 0f 87 ce 00 00 00            	ja	0x11ad <trusted_x86_x86_sim_xdp+0x11ad>
    10df: 40 0f b6 ff                  	movzbl	%dil, %edi
    10e3: ff cf                        	decl	%edi
    10e5: 4c 8d 05 00 00 00 00         	leaq	(%rip), %r8             # 0x10ec <trusted_x86_x86_sim_xdp+0x10ec>
		00000000000010e8:  R_X86_64_PC32	.rodata+0x60
    10ec: 4d 63 0c b8                  	movslq	(%r8,%rdi,4), %r9
    10f0: 4d 01 c1                     	addq	%r8, %r9
    10f3: 48 8b bc 24 a0 01 00 00      	movq	0x1a0(%rsp), %rdi
    10fb: 4d 89 f8                     	movq	%r15, %r8
    10fe: 41 ff e1                     	jmpq	*%r9
    1101: 48 8b bc 24 88 00 00 00      	movq	0x88(%rsp), %rdi
    1109: 4c 8b 07                     	movq	(%rdi), %r8
    110c: 4c 89 5c 24 20               	movq	%r11, 0x20(%rsp)
    1111: 4c 89 54 24 28               	movq	%r10, 0x28(%rsp)
    1116: 48 89 ef                     	movq	%rbp, %rdi
    1119: 48 89 c5                     	movq	%rax, %rbp
    111c: 48 63 f6                     	movslq	%esi, %rsi
    111f: 4c 01 c6                     	addq	%r8, %rsi
    1122: 84 d2                        	testb	%dl, %dl
    1124: 78 43                        	js	0x1169 <trusted_x86_x86_sim_xdp+0x1169>
    1126: 4c 8b a4 24 90 00 00 00      	movq	0x90(%rsp), %r12
    112e: 48 85 f6                     	testq	%rsi, %rsi
    1131: 0f 84 e3 01 00 00            	je	0x131a <trusted_x86_x86_sim_xdp+0x131a>
    1137: ba 08 00 00 00               	movl	$0x8, %edx
    113c: 48 8b ac 24 a0 01 00 00      	movq	0x1a0(%rsp), %rbp
    1144: 48 89 ef                     	movq	%rbp, %rdi
    1147: e8 00 00 00 00               	callq	0x114c <trusted_x86_x86_sim_xdp+0x114c>
		0000000000001148:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    114c: 85 c0                        	testl	%eax, %eax
    114e: 79 08                        	jns	0x1158 <trusted_x86_x86_sim_xdp+0x1158>
    1150: 48 c7 45 00 00 00 00 00      	movq	$0x0, (%rbp)
    1158: 4c 8b 54 24 28               	movq	0x28(%rsp), %r10
    115d: 48 8b 74 24 30               	movq	0x30(%rsp), %rsi
    1162: 4c 8b 5c 24 20               	movq	0x20(%rsp), %r11
    1167: eb 67                        	jmp	0x11d0 <trusted_x86_x86_sim_xdp+0x11d0>
    1169: ba 08 00 00 00               	movl	$0x8, %edx
    116e: e8 00 00 00 00               	callq	0x1173 <trusted_x86_x86_sim_xdp+0x1173>
		000000000000116f:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1173: 85 c0                        	testl	%eax, %eax
    1175: 79 09                        	jns	0x1180 <trusted_x86_x86_sim_xdp+0x1180>
    1177: 48 c7 44 24 68 00 00 00 00   	movq	$0x0, 0x68(%rsp)
    1180: 85 c0                        	testl	%eax, %eax
    1182: 0f 84 23 02 00 00            	je	0x13ab <trusted_x86_x86_sim_xdp+0x13ab>
    1188: 48 89 e8                     	movq	%rbp, %rax
    118b: 4c 8b 54 24 28               	movq	0x28(%rsp), %r10
    1190: 4c 8b 5c 24 20               	movq	0x20(%rsp), %r11
    1195: eb 16                        	jmp	0x11ad <trusted_x86_x86_sim_xdp+0x11ad>
    1197: 44 89 e2                     	movl	%r12d, %edx
    119a: 83 e2 0f                     	andl	$0xf, %edx
    119d: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0x11a4 <trusted_x86_x86_sim_xdp+0x11a4>
		00000000000011a0:  R_X86_64_PC32	.rodata+0x74
    11a4: 48 63 14 96                  	movslq	(%rsi,%rdx,4), %rdx
    11a8: 48 01 f2                     	addq	%rsi, %rdx
    11ab: ff e2                        	jmpq	*%rdx
    11ad: 4c 8b a4 24 90 00 00 00      	movq	0x90(%rsp), %r12
    11b5: 0f b6 00                     	movzbl	(%rax), %eax
    11b8: 3c 03                        	cmpb	$0x3, %al
    11ba: 48 8b 74 24 30               	movq	0x30(%rsp), %rsi
    11bf: 48 8b 84 24 a0 01 00 00      	movq	0x1a0(%rsp), %rax
    11c7: 75 07                        	jne	0x11d0 <trusted_x86_x86_sim_xdp+0x11d0>
    11c9: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    11d0: 4d 85 ff                     	testq	%r15, %r15
    11d3: 74 40                        	je	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
    11d5: 4c 89 5c 24 20               	movq	%r11, 0x20(%rsp)
    11da: 48 89 74 24 30               	movq	%rsi, 0x30(%rsp)
    11df: 4c 89 54 24 28               	movq	%r10, 0x28(%rsp)
    11e4: 49 8d 77 f8                  	leaq	-0x8(%r15), %rsi
    11e8: ba 08 00 00 00               	movl	$0x8, %edx
    11ed: 48 8b ac 24 80 01 00 00      	movq	0x180(%rsp), %rbp
    11f5: 48 89 ef                     	movq	%rbp, %rdi
    11f8: e8 00 00 00 00               	callq	0x11fd <trusted_x86_x86_sim_xdp+0x11fd>
		00000000000011f9:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    11fd: 85 c0                        	testl	%eax, %eax
    11ff: 79 08                        	jns	0x1209 <trusted_x86_x86_sim_xdp+0x1209>
    1201: 48 c7 45 00 00 00 00 00      	movq	$0x0, (%rbp)
    1209: 85 c0                        	testl	%eax, %eax
    120b: 48 8b 94 24 88 01 00 00      	movq	0x188(%rsp), %rdx
    1213: 74 53                        	je	0x1268 <trusted_x86_x86_sim_xdp+0x1268>
    1215: c7 44 24 68 0e 00 00 00      	movl	$0xe, 0x68(%rsp)
    121d: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1224 <trusted_x86_x86_sim_xdp+0x1224>
		0000000000001220:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    1224: 83 79 44 0f                  	cmpl	$0xf, 0x44(%rcx)
    1228: 72 29                        	jb	0x1253 <trusted_x86_x86_sim_xdp+0x1253>
    122a: b8 0e 00 00 00               	movl	$0xe, %eax
    122f: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    1235: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    123d: e8 00 00 00 00               	callq	0x1242 <trusted_x86_x86_sim_xdp+0x1242>
		000000000000123e:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    1242: 48 85 c0                     	testq	%rax, %rax
    1245: 74 0c                        	je	0x1253 <trusted_x86_x86_sim_xdp+0x1253>
    1247: 48 89 c1                     	movq	%rax, %rcx
    124a: 48 8b 09                     	movq	(%rcx), %rcx
    124d: 48 ff c1                     	incq	%rcx
    1250: 48 89 08                     	movq	%rcx, (%rax)
    1253: 4c 8b bc 24 80 00 00 00      	movq	0x80(%rsp), %r15
    125b: bd a7 0f 00 00               	movl	$0xfa7, %ebp            # imm = 0xFA7
    1260: 45 31 e4                     	xorl	%r12d, %r12d
    1263: e9 80 19 00 00               	jmp	0x2be8 <trusted_x86_x86_sim_xdp+0x2be8>
    1268: 48 89 d0                     	movq	%rdx, %rax
    126b: 4c 89 38                     	movq	%r15, (%rax)
    126e: 48 8d 83 30 0f 00 00         	leaq	0xf30(%rbx), %rax
    1275: b1 01                        	movb	$0x1, %cl
    1277: 88 08                        	movb	%cl, (%rax)
    1279: 4c 89 a4 24 90 00 00 00      	movq	%r12, 0x90(%rsp)
    1281: c7 44 24 68 06 00 00 00      	movl	$0x6, 0x68(%rsp)
    1289: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1290 <trusted_x86_x86_sim_xdp+0x1290>
		000000000000128c:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    1290: 83 79 44 07                  	cmpl	$0x7, 0x44(%rcx)
    1294: 72 2f                        	jb	0x12c5 <trusted_x86_x86_sim_xdp+0x12c5>
    1296: b8 06 00 00 00               	movl	$0x6, %eax
    129b: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    12a1: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    12a9: 49 89 d7                     	movq	%rdx, %r15
    12ac: e8 00 00 00 00               	callq	0x12b1 <trusted_x86_x86_sim_xdp+0x12b1>
		00000000000012ad:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    12b1: 4c 89 fa                     	movq	%r15, %rdx
    12b4: 48 85 c0                     	testq	%rax, %rax
    12b7: 74 0c                        	je	0x12c5 <trusted_x86_x86_sim_xdp+0x12c5>
    12b9: 48 89 c1                     	movq	%rax, %rcx
    12bc: 48 8b 09                     	movq	(%rcx), %rcx
    12bf: 48 ff c1                     	incq	%rcx
    12c2: 48 89 08                     	movq	%rcx, (%rax)
    12c5: 48 8b 6d 00                  	movq	(%rbp), %rbp
    12c9: 48 85 ed                     	testq	%rbp, %rbp
    12cc: 0f 84 ab 3c 00 00            	je	0x4f7d <trusted_x86_x86_sim_xdp+0x4f7d>
    12d2: 48 89 e8                     	movq	%rbp, %rax
    12d5: 48 c1 e8 38                  	shrq	$0x38, %rax
    12d9: 74 17                        	je	0x12f2 <trusted_x86_x86_sim_xdp+0x12f2>
    12db: 48 8d 83 28 0f 00 00         	leaq	0xf28(%rbx), %rax
    12e2: c7 00 0b 00 00 00            	movl	$0xb, (%rax)
    12e8: bd ab 0f 00 00               	movl	$0xfab, %ebp            # imm = 0xFAB
    12ed: e9 9d 3c 00 00               	jmp	0x4f8f <trusted_x86_x86_sim_xdp+0x4f8f>
    12f2: 48 89 94 24 88 01 00 00      	movq	%rdx, 0x188(%rsp)
    12fa: 48 81 fd ff 0f 00 00         	cmpq	$0xfff, %rbp            # imm = 0xFFF
    1301: 77 29                        	ja	0x132c <trusted_x86_x86_sim_xdp+0x132c>
    1303: 48 8d 83 28 0f 00 00         	leaq	0xf28(%rbx), %rax
    130a: c7 00 31 00 00 00            	movl	$0x31, (%rax)
    1310: bd ae 0f 00 00               	movl	$0xfae, %ebp            # imm = 0xFAE
    1315: e9 75 3c 00 00               	jmp	0x4f8f <trusted_x86_x86_sim_xdp+0x4f8f>
    131a: 48 89 e8                     	movq	%rbp, %rax
    131d: 4c 8b 54 24 28               	movq	0x28(%rsp), %r10
    1322: 4c 8b 5c 24 20               	movq	0x20(%rsp), %r11
    1327: e9 89 fe ff ff               	jmp	0x11b5 <trusted_x86_x86_sim_xdp+0x11b5>
    132c: 48 89 d8                     	movq	%rbx, %rax
    132f: 8b 00                        	movl	(%rax), %eax
    1331: c7 84 24 b8 00 00 00 60 00 00 00     	movl	$0x60, 0xb8(%rsp)
    133c: 0f 38 f1 84 24 bc 00 00 00   	movbel	%eax, 0xbc(%rsp)
    1345: 48 0f 38 f1 ac 24 c0 00 00 00	movbeq	%rbp, 0xc0(%rsp)
    134f: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1356 <trusted_x86_x86_sim_xdp+0x1356>
		0000000000001352:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1356: 48 3b 0d 00 00 00 00         	cmpq	(%rip), %rcx            # 0x135d <trusted_x86_x86_sim_xdp+0x135d>
		0000000000001359:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
    135d: 0f 94 c0                     	sete	%al
    1360: 48 3b 0d 00 00 00 00         	cmpq	(%rip), %rcx            # 0x1367 <trusted_x86_x86_sim_xdp+0x1367>
		0000000000001363:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    1367: 0f 94 c1                     	sete	%cl
    136a: 08 c1                        	orb	%al, %cl
    136c: 88 8c 24 a0 01 00 00         	movb	%cl, 0x1a0(%rsp)
    1373: 80 f9 01                     	cmpb	$0x1, %cl
    1376: 75 48                        	jne	0x13c0 <trusted_x86_x86_sim_xdp+0x13c0>
    1378: 8b 84 24 b8 00 00 00         	movl	0xb8(%rsp), %eax
    137f: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1386 <trusted_x86_x86_sim_xdp+0x1386>
		0000000000001382:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1386: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    1389: 0f 83 a6 3c 00 00            	jae	0x5035 <trusted_x86_x86_sim_xdp+0x5035>
    138f: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1396 <trusted_x86_x86_sim_xdp+0x1396>
		0000000000001392:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1396: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    139c: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    13a4: e8 00 00 00 00               	callq	0x13a9 <trusted_x86_x86_sim_xdp+0x13a9>
		00000000000013a5:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    13a9: eb 22                        	jmp	0x13cd <trusted_x86_x86_sim_xdp+0x13cd>
    13ab: 41 c1 e4 03                  	shll	$0x3, %r12d
    13af: 41 83 e4 38                  	andl	$0x38, %r12d
    13b3: 4c 03 64 24 68               	addq	0x68(%rsp), %r12
    13b8: 4c 89 e6                     	movq	%r12, %rsi
    13bb: e9 66 fd ff ff               	jmp	0x1126 <trusted_x86_x86_sim_xdp+0x1126>
    13c0: 48 8d bc 24 b8 00 00 00      	leaq	0xb8(%rsp), %rdi
    13c8: e8 00 00 00 00               	callq	0x13cd <trusted_x86_x86_sim_xdp+0x13cd>
		00000000000013c9:  R_X86_64_PLT32	.text+0x7c
    13cd: 48 85 c0                     	testq	%rax, %rax
    13d0: 0f 84 5f 3c 00 00            	je	0x5035 <trusted_x86_x86_sim_xdp+0x5035>
    13d6: 48 ba ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    13e0: 48 89 c1                     	movq	%rax, %rcx
    13e3: 4c 8b 61 08                  	movq	0x8(%rcx), %r12
    13e7: 4c 89 e1                     	movq	%r12, %rcx
    13ea: 48 21 d1                     	andq	%rdx, %rcx
    13ed: 48 8d 93 20 0f 00 00         	leaq	0xf20(%rbx), %rdx
    13f4: 48 89 94 24 90 01 00 00      	movq	%rdx, 0x190(%rsp)
    13fc: 48 89 0a                     	movq	%rcx, (%rdx)
    13ff: 49 c1 ec 38                  	shrq	$0x38, %r12
    1403: 48 8b 00                     	movq	(%rax), %rax
    1406: 48 8d 93 10 0f 00 00         	leaq	0xf10(%rbx), %rdx
    140d: 48 89 94 24 c8 01 00 00      	movq	%rdx, 0x1c8(%rsp)
    1415: 48 89 02                     	movq	%rax, (%rdx)
    1418: 48 29 cd                     	subq	%rcx, %rbp
    141b: 48 8d 8b 18 0f 00 00         	leaq	0xf18(%rbx), %rcx
    1422: 48 89 8c 24 b0 01 00 00      	movq	%rcx, 0x1b0(%rsp)
    142a: 48 89 29                     	movq	%rbp, (%rcx)
    142d: 49 83 fc 01                  	cmpq	$0x1, %r12
    1431: 0f 85 86 01 00 00            	jne	0x15bd <trusted_x86_x86_sim_xdp+0x15bd>
    1437: 48 89 84 24 b8 00 00 00      	movq	%rax, 0xb8(%rsp)
    143f: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x1446 <trusted_x86_x86_sim_xdp+0x1446>
		0000000000001442:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    1446: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x144d <trusted_x86_x86_sim_xdp+0x144d>
		0000000000001449:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    144d: 74 28                        	je	0x1477 <trusted_x86_x86_sim_xdp+0x1477>
    144f: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x1456 <trusted_x86_x86_sim_xdp+0x1456>
		0000000000001452:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
    1456: 74 1f                        	je	0x1477 <trusted_x86_x86_sim_xdp+0x1477>
    1458: 48 8d bc 24 b8 00 00 00      	leaq	0xb8(%rsp), %rdi
    1460: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x1467 <trusted_x86_x86_sim_xdp+0x1467>
		0000000000001463:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1467: 0f 85 be 00 00 00            	jne	0x152b <trusted_x86_x86_sim_xdp+0x152b>
    146d: e8 00 00 00 00               	callq	0x1472 <trusted_x86_x86_sim_xdp+0x1472>
		000000000000146e:  R_X86_64_PLT32	.text+0x7c
    1472: e9 b9 00 00 00               	jmp	0x1530 <trusted_x86_x86_sim_xdp+0x1530>
    1477: 8b 8c 24 b8 00 00 00         	movl	0xb8(%rsp), %ecx
    147e: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    1481: 0f 83 42 01 00 00            	jae	0x15c9 <trusted_x86_x86_sim_xdp+0x15c9>
    1487: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    148d: 48 8b bc c8 30 01 00 00      	movq	0x130(%rax,%rcx,8), %rdi
    1495: e8 00 00 00 00               	callq	0x149a <trusted_x86_x86_sim_xdp+0x149a>
		0000000000001496:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    149a: e9 91 00 00 00               	jmp	0x1530 <trusted_x86_x86_sim_xdp+0x1530>
    149f: 48 8b 94 24 a0 00 00 00      	movq	0xa0(%rsp), %rdx
    14a7: eb 26                        	jmp	0x14cf <trusted_x86_x86_sim_xdp+0x14cf>
    14a9: 48 8b 8c 24 a0 00 00 00      	movq	0xa0(%rsp), %rcx
    14b1: eb 40                        	jmp	0x14f3 <trusted_x86_x86_sim_xdp+0x14f3>
    14b3: 48 8b 94 24 98 00 00 00      	movq	0x98(%rsp), %rdx
    14bb: eb 12                        	jmp	0x14cf <trusted_x86_x86_sim_xdp+0x14cf>
    14bd: 48 8b 8c 24 98 00 00 00      	movq	0x98(%rsp), %rcx
    14c5: eb 2c                        	jmp	0x14f3 <trusted_x86_x86_sim_xdp+0x14f3>
    14c7: 48 8b 94 24 90 00 00 00      	movq	0x90(%rsp), %rdx
    14cf: 44 89 e6                     	movl	%r12d, %esi
    14d2: 81 e6 00 00 00 80            	andl	$0x80000000, %esi       # imm = 0x80000000
    14d8: 41 c1 ec 04                  	shrl	$0x4, %r12d
    14dc: 42 8d 34 e6                  	leal	(%rsi,%r12,8), %esi
    14e0: 4c 63 fe                     	movslq	%esi, %r15
    14e3: 4c 03 3a                     	addq	(%rdx), %r15
    14e6: e9 c7 fb ff ff               	jmp	0x10b2 <trusted_x86_x86_sim_xdp+0x10b2>
    14eb: 48 8b 8c 24 90 00 00 00      	movq	0x90(%rsp), %rcx
    14f3: 48 89 8c 24 90 01 00 00      	movq	%rcx, 0x190(%rsp)
    14fb: 4c 89 5c 24 20               	movq	%r11, 0x20(%rsp)
    1500: 4c 89 54 24 28               	movq	%r10, 0x28(%rsp)
    1505: 48 89 c5                     	movq	%rax, %rbp
    1508: 44 89 e0                     	movl	%r12d, %eax
    150b: 25 00 00 00 80               	andl	$0x80000000, %eax       # imm = 0x80000000
    1510: 41 c1 ec 04                  	shrl	$0x4, %r12d
    1514: 42 8d 04 e0                  	leal	(%rax,%r12,8), %eax
    1518: 48 63 f0                     	movslq	%eax, %rsi
    151b: 48 8b 84 24 90 01 00 00      	movq	0x190(%rsp), %rax
    1523: 48 03 30                     	addq	(%rax), %rsi
    1526: e9 fb fb ff ff               	jmp	0x1126 <trusted_x86_x86_sim_xdp+0x1126>
    152b: e8 00 00 00 00               	callq	0x1530 <trusted_x86_x86_sim_xdp+0x1530>
		000000000000152c:  R_X86_64_PLT32	.text+0x12c
    1530: 49 89 c7                     	movq	%rax, %r15
    1533: 48 85 c0                     	testq	%rax, %rax
    1536: 0f 84 8d 00 00 00            	je	0x15c9 <trusted_x86_x86_sim_xdp+0x15c9>
    153c: 4c 89 f8                     	movq	%r15, %rax
    153f: 48 8b 00                     	movq	(%rax), %rax
    1542: 48 39 e8                     	cmpq	%rbp, %rax
    1545: 77 0c                        	ja	0x1553 <trusted_x86_x86_sim_xdp+0x1553>
    1547: 4c 89 f8                     	movq	%r15, %rax
    154a: 48 8b 40 08                  	movq	0x8(%rax), %rax
    154e: 48 39 e8                     	cmpq	%rbp, %rax
    1551: 73 18                        	jae	0x156b <trusted_x86_x86_sim_xdp+0x156b>
    1553: 4c 89 f8                     	movq	%r15, %rax
    1556: 48 8b 40 10                  	movq	0x10(%rax), %rax
    155a: 48 39 e8                     	cmpq	%rbp, %rax
    155d: 77 6a                        	ja	0x15c9 <trusted_x86_x86_sim_xdp+0x15c9>
    155f: 4c 89 f8                     	movq	%r15, %rax
    1562: 48 8b 40 18                  	movq	0x18(%rax), %rax
    1566: 48 39 e8                     	cmpq	%rbp, %rax
    1569: 72 5e                        	jb	0x15c9 <trusted_x86_x86_sim_xdp+0x15c9>
    156b: 48 89 d8                     	movq	%rbx, %rax
    156e: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
    1574: 4c 89 f9                     	movq	%r15, %rcx
    1577: 8b 49 20                     	movl	0x20(%rcx), %ecx
    157a: 0f a3 c8                     	btl	%ecx, %eax
    157d: 72 4a                        	jb	0x15c9 <trusted_x86_x86_sim_xdp+0x15c9>
    157f: c7 44 24 68 00 00 00 00      	movl	$0x0, 0x68(%rsp)
    1587: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x158e <trusted_x86_x86_sim_xdp+0x158e>
		000000000000158a:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    158e: 83 78 44 00                  	cmpl	$0x0, 0x44(%rax)
    1592: 74 24                        	je	0x15b8 <trusted_x86_x86_sim_xdp+0x15b8>
    1594: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x159b <trusted_x86_x86_sim_xdp+0x159b>
		0000000000001597:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    159b: 48 8b b8 30 01 00 00         	movq	0x130(%rax), %rdi
    15a2: e8 00 00 00 00               	callq	0x15a7 <trusted_x86_x86_sim_xdp+0x15a7>
		00000000000015a3:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    15a7: 48 85 c0                     	testq	%rax, %rax
    15aa: 74 0c                        	je	0x15b8 <trusted_x86_x86_sim_xdp+0x15b8>
    15ac: 48 89 c1                     	movq	%rax, %rcx
    15af: 48 8b 09                     	movq	(%rcx), %rcx
    15b2: 48 ff c1                     	incq	%rcx
    15b5: 48 89 08                     	movq	%rcx, (%rax)
    15b8: 45 0f b7 67 20               	movzwl	0x20(%r15), %r12d
    15bd: 31 ed                        	xorl	%ebp, %ebp
    15bf: 41 83 fc 01                  	cmpl	$0x1, %r12d
    15c3: 0f 85 c9 39 00 00            	jne	0x4f92 <trusted_x86_x86_sim_xdp+0x4f92>
    15c9: 48 8b 84 24 80 01 00 00      	movq	0x180(%rsp), %rax
    15d1: 48 89 84 24 a8 00 00 00      	movq	%rax, 0xa8(%rsp)
    15d9: c7 84 24 b8 00 00 00 05 00 00 00     	movl	$0x5, 0xb8(%rsp)
    15e4: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x15eb <trusted_x86_x86_sim_xdp+0x15eb>
		00000000000015e7:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    15eb: 83 78 44 06                  	cmpl	$0x6, 0x44(%rax)
    15ef: 72 30                        	jb	0x1621 <trusted_x86_x86_sim_xdp+0x1621>
    15f1: b8 05 00 00 00               	movl	$0x5, %eax
    15f6: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x15fd <trusted_x86_x86_sim_xdp+0x15fd>
		00000000000015f9:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    15fd: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    1603: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    160b: e8 00 00 00 00               	callq	0x1610 <trusted_x86_x86_sim_xdp+0x1610>
		000000000000160c:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    1610: 48 85 c0                     	testq	%rax, %rax
    1613: 74 0c                        	je	0x1621 <trusted_x86_x86_sim_xdp+0x1621>
    1615: 48 89 c1                     	movq	%rax, %rcx
    1618: 48 8b 09                     	movq	(%rcx), %rcx
    161b: 48 ff c1                     	incq	%rcx
    161e: 48 89 08                     	movq	%rcx, (%rax)
    1621: 48 89 d8                     	movq	%rbx, %rax
    1624: 8b 88 c0 02 00 00            	movl	0x2c0(%rax), %ecx
    162a: 83 f9 7e                     	cmpl	$0x7e, %ecx
    162d: 0f 87 c0 14 00 00            	ja	0x2af3 <trusted_x86_x86_sim_xdp+0x2af3>
    1633: 4c 8d a3 d0 02 00 00         	leaq	0x2d0(%rbx), %r12
    163a: 4c 8d bb d8 02 00 00         	leaq	0x2d8(%rbx), %r15
    1641: 4c 8d 9b e0 02 00 00         	leaq	0x2e0(%rbx), %r11
    1648: 4c 8d 93 e1 02 00 00         	leaq	0x2e1(%rbx), %r10
    164f: 4c 8d 8b e2 02 00 00         	leaq	0x2e2(%rbx), %r9
    1656: 48 89 d8                     	movq	%rbx, %rax
    1659: 0f b6 80 30 0f 00 00         	movzbl	0xf30(%rax), %eax
    1660: 48 89 da                     	movq	%rbx, %rdx
    1663: 48 8b 92 10 0f 00 00         	movq	0xf10(%rdx), %rdx
    166a: 48 89 de                     	movq	%rbx, %rsi
    166d: 48 8b b6 18 0f 00 00         	movq	0xf18(%rsi), %rsi
    1674: 8d 79 01                     	leal	0x1(%rcx), %edi
    1677: 4c 8b 84 24 c0 01 00 00      	movq	0x1c0(%rsp), %r8
    167f: 41 89 38                     	movl	%edi, (%r8)
    1682: c1 e1 03                     	shll	$0x3, %ecx
    1685: 8d 0c 49                     	leal	(%rcx,%rcx,2), %ecx
    1688: 4c 89 a4 24 e0 01 00 00      	movq	%r12, 0x1e0(%rsp)
    1690: 49 8d 3c 0c                  	leaq	(%r12,%rcx), %rdi
    1694: 48 89 17                     	movq	%rdx, (%rdi)
    1697: 4c 89 bc 24 e8 01 00 00      	movq	%r15, 0x1e8(%rsp)
    169f: 49 8d 14 0f                  	leaq	(%r15,%rcx), %rdx
    16a3: 48 89 32                     	movq	%rsi, (%rdx)
    16a6: 4c 89 9c 24 f0 01 00 00      	movq	%r11, 0x1f0(%rsp)
    16ae: 49 8d 14 0b                  	leaq	(%r11,%rcx), %rdx
    16b2: c6 02 03                     	movb	$0x3, (%rdx)
    16b5: 4c 89 94 24 f8 01 00 00      	movq	%r10, 0x1f8(%rsp)
    16bd: 49 8d 14 0a                  	leaq	(%r10,%rcx), %rdx
    16c1: 88 02                        	movb	%al, (%rdx)
    16c3: 48 8d 93 e6 02 00 00         	leaq	0x2e6(%rbx), %rdx
    16ca: 4c 89 8c 24 00 02 00 00      	movq	%r9, 0x200(%rsp)
    16d2: 49 8d 04 09                  	leaq	(%r9,%rcx), %rax
    16d6: c7 00 00 00 00 00            	movl	$0x0, (%rax)
    16dc: 48 89 94 24 d8 01 00 00      	movq	%rdx, 0x1d8(%rsp)
    16e4: 48 01 d1                     	addq	%rdx, %rcx
    16e7: 66 c7 01 00 00               	movw	$0x0, (%rcx)
    16ec: c7 44 24 60 00 00 00 00      	movl	$0x0, 0x60(%rsp)
    16f4: 48 89 d8                     	movq	%rbx, %rax
    16f7: 48 8b 80 10 0f 00 00         	movq	0xf10(%rax), %rax
    16fe: 48 89 84 24 b0 00 00 00      	movq	%rax, 0xb0(%rsp)
    1706: 48 89 44 24 68               	movq	%rax, 0x68(%rsp)
    170b: 48 89 d8                     	movq	%rbx, %rax
    170e: 48 c7 c1 00 00 ff ff         	movq	$-0x10000, %rcx         # imm = 0xFFFF0000
    1715: 48 23 88 18 0f 00 00         	andq	0xf18(%rax), %rcx
    171c: 48 89 4c 24 70               	movq	%rcx, 0x70(%rsp)
    1721: 45 84 f6                     	testb	%r14b, %r14b
    1724: 74 30                        	je	0x1756 <trusted_x86_x86_sim_xdp+0x1756>
    1726: 8b 44 24 68                  	movl	0x68(%rsp), %eax
    172a: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1731 <trusted_x86_x86_sim_xdp+0x1731>
		000000000000172d:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    1731: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    1734: 0f 83 71 14 00 00            	jae	0x2bab <trusted_x86_x86_sim_xdp+0x2bab>
    173a: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1741 <trusted_x86_x86_sim_xdp+0x1741>
		000000000000173d:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    1741: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    1747: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    174f: e8 00 00 00 00               	callq	0x1754 <trusted_x86_x86_sim_xdp+0x1754>
		0000000000001750:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    1754: eb 3d                        	jmp	0x1793 <trusted_x86_x86_sim_xdp+0x1793>
    1756: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x175d <trusted_x86_x86_sim_xdp+0x175d>
		0000000000001759:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    175d: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x1764 <trusted_x86_x86_sim_xdp+0x1764>
		0000000000001760:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1764: 75 0c                        	jne	0x1772 <trusted_x86_x86_sim_xdp+0x1772>
    1766: 48 8d 7c 24 68               	leaq	0x68(%rsp), %rdi
    176b: e8 00 00 00 00               	callq	0x1770 <trusted_x86_x86_sim_xdp+0x1770>
		000000000000176c:  R_X86_64_PLT32	.text+0x7c
    1770: eb 21                        	jmp	0x1793 <trusted_x86_x86_sim_xdp+0x1793>
    1772: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x1779 <trusted_x86_x86_sim_xdp+0x1779>
		0000000000001775:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    1779: 48 8d 7c 24 68               	leaq	0x68(%rsp), %rdi
    177e: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x1785 <trusted_x86_x86_sim_xdp+0x1785>
		0000000000001781:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    1785: 75 07                        	jne	0x178e <trusted_x86_x86_sim_xdp+0x178e>
    1787: e8 00 00 00 00               	callq	0x178c <trusted_x86_x86_sim_xdp+0x178c>
		0000000000001788:  R_X86_64_PLT32	.text+0x12c
    178c: eb 05                        	jmp	0x1793 <trusted_x86_x86_sim_xdp+0x1793>
    178e: e8 00 00 00 00               	callq	0x1793 <trusted_x86_x86_sim_xdp+0x1793>
		000000000000178f:  R_X86_64_PLT32	.text+0x1dc
    1793: 49 89 c7                     	movq	%rax, %r15
    1796: 48 85 c0                     	testq	%rax, %rax
    1799: 0f 84 0c 14 00 00            	je	0x2bab <trusted_x86_x86_sim_xdp+0x2bab>
    179f: 4c 89 f8                     	movq	%r15, %rax
    17a2: 0f b7 40 06                  	movzwl	0x6(%rax), %eax
    17a6: 0f b7 c0                     	movzwl	%ax, %eax
    17a9: 83 c0 f8                     	addl	$-0x8, %eax
    17ac: a9 f0 ff 00 00               	testl	$0xfff0, %eax           # imm = 0xFFF0
    17b1: 74 0d                        	je	0x17c0 <trusted_x86_x86_sim_xdp+0x17c0>
    17b3: 4c 8b bc 24 80 00 00 00      	movq	0x80(%rsp), %r15
    17bb: e9 cd ea ff ff               	jmp	0x28d <trusted_x86_x86_sim_xdp+0x28d>
    17c0: 83 e0 0f                     	andl	$0xf, %eax
    17c3: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x17ca <trusted_x86_x86_sim_xdp+0x17ca>
		00000000000017c6:  R_X86_64_PC32	.data.rel.ro-0x4
    17ca: 48 8b 3c c1                  	movq	(%rcx,%rax,8), %rdi
    17ce: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    17d2: 75 30                        	jne	0x1804 <trusted_x86_x86_sim_xdp+0x1804>
    17d4: 8b 84 24 b0 00 00 00         	movl	0xb0(%rsp), %eax
    17db: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    17de: 0f 83 db 13 00 00            	jae	0x2bbf <trusted_x86_x86_sim_xdp+0x2bbf>
    17e4: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    17ea: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    17f0: 48 0f af c1                  	imulq	%rcx, %rax
    17f4: 48 01 f8                     	addq	%rdi, %rax
    17f7: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    17fd: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    1802: eb 1d                        	jmp	0x1821 <trusted_x86_x86_sim_xdp+0x1821>
    1804: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    1808: 48 8d b4 24 b0 00 00 00      	leaq	0xb0(%rsp), %rsi
    1810: ff 50 60                     	callq	*0x60(%rax)
    1813: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    1818: 48 85 c0                     	testq	%rax, %rax
    181b: 0f 84 a7 13 00 00            	je	0x2bc8 <trusted_x86_x86_sim_xdp+0x2bc8>
    1821: 4c 89 f9                     	movq	%r15, %rcx
    1824: 4c 89 f8                     	movq	%r15, %rax
    1827: 44 8b 20                     	movl	(%rax), %r12d
    182a: 44 89 64 24 64               	movl	%r12d, 0x64(%rsp)
    182f: 48 89 d8                     	movq	%rbx, %rax
    1832: 48 8b 80 18 0f 00 00         	movq	0xf18(%rax), %rax
    1839: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    183e: 4c 89 f8                     	movq	%r15, %rax
    1841: 0f b7 48 04                  	movzwl	0x4(%rax), %ecx
    1845: 85 c9                        	testl	%ecx, %ecx
    1847: 0f 84 8b 08 00 00            	je	0x20d8 <trusted_x86_x86_sim_xdp+0x20d8>
    184d: 48 89 c8                     	movq	%rcx, %rax
    1850: 44 01 e0                     	addl	%r12d, %eax
    1853: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    1858: 44 01 e0                     	addl	%r12d, %eax
    185b: d1 e8                        	shrl	%eax
    185d: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    1861: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    1866: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    186a: 75 2b                        	jne	0x1897 <trusted_x86_x86_sim_xdp+0x1897>
    186c: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    1871: 8b 00                        	movl	(%rax), %eax
    1873: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    1876: 0f 83 d6 2f 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    187c: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    1882: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    1888: 48 0f af c1                  	imulq	%rcx, %rax
    188c: 48 01 f8                     	addq	%rdi, %rax
    188f: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    1895: eb 15                        	jmp	0x18ac <trusted_x86_x86_sim_xdp+0x18ac>
    1897: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    189b: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    18a0: ff 50 60                     	callq	*0x60(%rax)
    18a3: 48 85 c0                     	testq	%rax, %rax
    18a6: 0f 84 a6 2f 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    18ac: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    18b0: 8d 69 01                     	leal	0x1(%rcx), %ebp
    18b3: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    18b8: 0f b7 00                     	movzwl	(%rax), %eax
    18bb: 48 39 c2                     	cmpq	%rax, %rdx
    18be: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    18c2: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    18c7: 0f 42 d1                     	cmovbl	%ecx, %edx
    18ca: 48 89 d0                     	movq	%rdx, %rax
    18cd: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    18d2: 39 d5                        	cmpl	%edx, %ebp
    18d4: 0f 83 ee 07 00 00            	jae	0x20c8 <trusted_x86_x86_sim_xdp+0x20c8>
    18da: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    18df: 01 e8                        	addl	%ebp, %eax
    18e1: d1 e8                        	shrl	%eax
    18e3: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    18e7: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    18ec: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    18f0: 75 2b                        	jne	0x191d <trusted_x86_x86_sim_xdp+0x191d>
    18f2: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    18f7: 8b 00                        	movl	(%rax), %eax
    18f9: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    18fc: 0f 83 50 2f 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1902: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    1908: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    190e: 48 0f af c1                  	imulq	%rcx, %rax
    1912: 48 01 f8                     	addq	%rdi, %rax
    1915: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    191b: eb 15                        	jmp	0x1932 <trusted_x86_x86_sim_xdp+0x1932>
    191d: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    1921: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    1926: ff 50 60                     	callq	*0x60(%rax)
    1929: 48 85 c0                     	testq	%rax, %rax
    192c: 0f 84 20 2f 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1932: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    1936: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    193a: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    193f: 0f b7 00                     	movzwl	(%rax), %eax
    1942: 48 39 c2                     	cmpq	%rax, %rdx
    1945: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    1949: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    194e: 0f 42 d1                     	cmovbl	%ecx, %edx
    1951: 48 89 d0                     	movq	%rdx, %rax
    1954: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1959: 41 39 d4                     	cmpl	%edx, %r12d
    195c: 0f 83 66 07 00 00            	jae	0x20c8 <trusted_x86_x86_sim_xdp+0x20c8>
    1962: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1967: 44 01 e0                     	addl	%r12d, %eax
    196a: d1 e8                        	shrl	%eax
    196c: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    1970: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    1975: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    1979: 75 2b                        	jne	0x19a6 <trusted_x86_x86_sim_xdp+0x19a6>
    197b: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    1980: 8b 00                        	movl	(%rax), %eax
    1982: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    1985: 0f 83 c7 2e 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    198b: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    1991: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    1997: 48 0f af c1                  	imulq	%rcx, %rax
    199b: 48 01 f8                     	addq	%rdi, %rax
    199e: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    19a4: eb 15                        	jmp	0x19bb <trusted_x86_x86_sim_xdp+0x19bb>
    19a6: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    19aa: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    19af: ff 50 60                     	callq	*0x60(%rax)
    19b2: 48 85 c0                     	testq	%rax, %rax
    19b5: 0f 84 97 2e 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    19bb: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    19bf: 8d 69 01                     	leal	0x1(%rcx), %ebp
    19c2: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    19c7: 0f b7 00                     	movzwl	(%rax), %eax
    19ca: 48 39 c2                     	cmpq	%rax, %rdx
    19cd: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    19d1: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    19d6: 0f 42 d1                     	cmovbl	%ecx, %edx
    19d9: 48 89 d0                     	movq	%rdx, %rax
    19dc: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    19e1: 39 d5                        	cmpl	%edx, %ebp
    19e3: 0f 83 df 06 00 00            	jae	0x20c8 <trusted_x86_x86_sim_xdp+0x20c8>
    19e9: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    19ee: 01 e8                        	addl	%ebp, %eax
    19f0: d1 e8                        	shrl	%eax
    19f2: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    19f6: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    19fb: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    19ff: 75 2b                        	jne	0x1a2c <trusted_x86_x86_sim_xdp+0x1a2c>
    1a01: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    1a06: 8b 00                        	movl	(%rax), %eax
    1a08: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    1a0b: 0f 83 41 2e 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1a11: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    1a17: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    1a1d: 48 0f af c1                  	imulq	%rcx, %rax
    1a21: 48 01 f8                     	addq	%rdi, %rax
    1a24: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    1a2a: eb 15                        	jmp	0x1a41 <trusted_x86_x86_sim_xdp+0x1a41>
    1a2c: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    1a30: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    1a35: ff 50 60                     	callq	*0x60(%rax)
    1a38: 48 85 c0                     	testq	%rax, %rax
    1a3b: 0f 84 11 2e 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1a41: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    1a45: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    1a49: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    1a4e: 0f b7 00                     	movzwl	(%rax), %eax
    1a51: 48 39 c2                     	cmpq	%rax, %rdx
    1a54: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    1a58: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1a5d: 0f 42 d1                     	cmovbl	%ecx, %edx
    1a60: 48 89 d0                     	movq	%rdx, %rax
    1a63: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1a68: 41 39 d4                     	cmpl	%edx, %r12d
    1a6b: 0f 83 57 06 00 00            	jae	0x20c8 <trusted_x86_x86_sim_xdp+0x20c8>
    1a71: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1a76: 44 01 e0                     	addl	%r12d, %eax
    1a79: d1 e8                        	shrl	%eax
    1a7b: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    1a7f: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    1a84: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    1a88: 75 2b                        	jne	0x1ab5 <trusted_x86_x86_sim_xdp+0x1ab5>
    1a8a: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    1a8f: 8b 00                        	movl	(%rax), %eax
    1a91: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    1a94: 0f 83 b8 2d 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1a9a: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    1aa0: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    1aa6: 48 0f af c1                  	imulq	%rcx, %rax
    1aaa: 48 01 f8                     	addq	%rdi, %rax
    1aad: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    1ab3: eb 15                        	jmp	0x1aca <trusted_x86_x86_sim_xdp+0x1aca>
    1ab5: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    1ab9: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    1abe: ff 50 60                     	callq	*0x60(%rax)
    1ac1: 48 85 c0                     	testq	%rax, %rax
    1ac4: 0f 84 88 2d 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1aca: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    1ace: 8d 69 01                     	leal	0x1(%rcx), %ebp
    1ad1: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    1ad6: 0f b7 00                     	movzwl	(%rax), %eax
    1ad9: 48 39 c2                     	cmpq	%rax, %rdx
    1adc: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    1ae0: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1ae5: 0f 42 d1                     	cmovbl	%ecx, %edx
    1ae8: 48 89 d0                     	movq	%rdx, %rax
    1aeb: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1af0: 39 d5                        	cmpl	%edx, %ebp
    1af2: 0f 83 d0 05 00 00            	jae	0x20c8 <trusted_x86_x86_sim_xdp+0x20c8>
    1af8: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1afd: 01 e8                        	addl	%ebp, %eax
    1aff: d1 e8                        	shrl	%eax
    1b01: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    1b05: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    1b0a: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    1b0e: 75 2b                        	jne	0x1b3b <trusted_x86_x86_sim_xdp+0x1b3b>
    1b10: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    1b15: 8b 00                        	movl	(%rax), %eax
    1b17: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    1b1a: 0f 83 32 2d 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1b20: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    1b26: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    1b2c: 48 0f af c1                  	imulq	%rcx, %rax
    1b30: 48 01 f8                     	addq	%rdi, %rax
    1b33: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    1b39: eb 15                        	jmp	0x1b50 <trusted_x86_x86_sim_xdp+0x1b50>
    1b3b: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    1b3f: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    1b44: ff 50 60                     	callq	*0x60(%rax)
    1b47: 48 85 c0                     	testq	%rax, %rax
    1b4a: 0f 84 02 2d 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1b50: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    1b54: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    1b58: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    1b5d: 0f b7 00                     	movzwl	(%rax), %eax
    1b60: 48 39 c2                     	cmpq	%rax, %rdx
    1b63: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    1b67: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1b6c: 0f 42 d1                     	cmovbl	%ecx, %edx
    1b6f: 48 89 d0                     	movq	%rdx, %rax
    1b72: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1b77: 41 39 d4                     	cmpl	%edx, %r12d
    1b7a: 0f 83 48 05 00 00            	jae	0x20c8 <trusted_x86_x86_sim_xdp+0x20c8>
    1b80: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1b85: 44 01 e0                     	addl	%r12d, %eax
    1b88: d1 e8                        	shrl	%eax
    1b8a: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    1b8e: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    1b93: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    1b97: 75 2b                        	jne	0x1bc4 <trusted_x86_x86_sim_xdp+0x1bc4>
    1b99: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    1b9e: 8b 00                        	movl	(%rax), %eax
    1ba0: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    1ba3: 0f 83 a9 2c 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1ba9: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    1baf: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    1bb5: 48 0f af c1                  	imulq	%rcx, %rax
    1bb9: 48 01 f8                     	addq	%rdi, %rax
    1bbc: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    1bc2: eb 15                        	jmp	0x1bd9 <trusted_x86_x86_sim_xdp+0x1bd9>
    1bc4: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    1bc8: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    1bcd: ff 50 60                     	callq	*0x60(%rax)
    1bd0: 48 85 c0                     	testq	%rax, %rax
    1bd3: 0f 84 79 2c 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1bd9: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    1bdd: 8d 69 01                     	leal	0x1(%rcx), %ebp
    1be0: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    1be5: 0f b7 00                     	movzwl	(%rax), %eax
    1be8: 48 39 c2                     	cmpq	%rax, %rdx
    1beb: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    1bef: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1bf4: 0f 42 d1                     	cmovbl	%ecx, %edx
    1bf7: 48 89 d0                     	movq	%rdx, %rax
    1bfa: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1bff: 39 d5                        	cmpl	%edx, %ebp
    1c01: 0f 83 c1 04 00 00            	jae	0x20c8 <trusted_x86_x86_sim_xdp+0x20c8>
    1c07: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1c0c: 01 e8                        	addl	%ebp, %eax
    1c0e: d1 e8                        	shrl	%eax
    1c10: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    1c14: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    1c19: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    1c1d: 75 2b                        	jne	0x1c4a <trusted_x86_x86_sim_xdp+0x1c4a>
    1c1f: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    1c24: 8b 00                        	movl	(%rax), %eax
    1c26: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    1c29: 0f 83 23 2c 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1c2f: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    1c35: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    1c3b: 48 0f af c1                  	imulq	%rcx, %rax
    1c3f: 48 01 f8                     	addq	%rdi, %rax
    1c42: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    1c48: eb 15                        	jmp	0x1c5f <trusted_x86_x86_sim_xdp+0x1c5f>
    1c4a: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    1c4e: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    1c53: ff 50 60                     	callq	*0x60(%rax)
    1c56: 48 85 c0                     	testq	%rax, %rax
    1c59: 0f 84 f3 2b 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1c5f: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    1c63: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    1c67: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    1c6c: 0f b7 00                     	movzwl	(%rax), %eax
    1c6f: 48 39 c2                     	cmpq	%rax, %rdx
    1c72: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    1c76: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1c7b: 0f 42 d1                     	cmovbl	%ecx, %edx
    1c7e: 48 89 d0                     	movq	%rdx, %rax
    1c81: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1c86: 41 39 d4                     	cmpl	%edx, %r12d
    1c89: 0f 83 39 04 00 00            	jae	0x20c8 <trusted_x86_x86_sim_xdp+0x20c8>
    1c8f: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1c94: 44 01 e0                     	addl	%r12d, %eax
    1c97: d1 e8                        	shrl	%eax
    1c99: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    1c9d: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    1ca2: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    1ca6: 75 2b                        	jne	0x1cd3 <trusted_x86_x86_sim_xdp+0x1cd3>
    1ca8: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    1cad: 8b 00                        	movl	(%rax), %eax
    1caf: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    1cb2: 0f 83 9a 2b 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1cb8: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    1cbe: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    1cc4: 48 0f af c1                  	imulq	%rcx, %rax
    1cc8: 48 01 f8                     	addq	%rdi, %rax
    1ccb: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    1cd1: eb 15                        	jmp	0x1ce8 <trusted_x86_x86_sim_xdp+0x1ce8>
    1cd3: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    1cd7: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    1cdc: ff 50 60                     	callq	*0x60(%rax)
    1cdf: 48 85 c0                     	testq	%rax, %rax
    1ce2: 0f 84 6a 2b 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1ce8: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    1cec: 8d 69 01                     	leal	0x1(%rcx), %ebp
    1cef: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    1cf4: 0f b7 00                     	movzwl	(%rax), %eax
    1cf7: 48 39 c2                     	cmpq	%rax, %rdx
    1cfa: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    1cfe: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1d03: 0f 42 d1                     	cmovbl	%ecx, %edx
    1d06: 48 89 d0                     	movq	%rdx, %rax
    1d09: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1d0e: 39 d5                        	cmpl	%edx, %ebp
    1d10: 0f 83 b2 03 00 00            	jae	0x20c8 <trusted_x86_x86_sim_xdp+0x20c8>
    1d16: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1d1b: 01 e8                        	addl	%ebp, %eax
    1d1d: d1 e8                        	shrl	%eax
    1d1f: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    1d23: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    1d28: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    1d2c: 75 2b                        	jne	0x1d59 <trusted_x86_x86_sim_xdp+0x1d59>
    1d2e: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    1d33: 8b 00                        	movl	(%rax), %eax
    1d35: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    1d38: 0f 83 14 2b 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1d3e: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    1d44: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    1d4a: 48 0f af c1                  	imulq	%rcx, %rax
    1d4e: 48 01 f8                     	addq	%rdi, %rax
    1d51: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    1d57: eb 15                        	jmp	0x1d6e <trusted_x86_x86_sim_xdp+0x1d6e>
    1d59: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    1d5d: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    1d62: ff 50 60                     	callq	*0x60(%rax)
    1d65: 48 85 c0                     	testq	%rax, %rax
    1d68: 0f 84 e4 2a 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1d6e: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    1d72: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    1d76: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    1d7b: 0f b7 00                     	movzwl	(%rax), %eax
    1d7e: 48 39 c2                     	cmpq	%rax, %rdx
    1d81: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    1d85: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1d8a: 0f 42 d1                     	cmovbl	%ecx, %edx
    1d8d: 48 89 d0                     	movq	%rdx, %rax
    1d90: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1d95: 41 39 d4                     	cmpl	%edx, %r12d
    1d98: 0f 83 2a 03 00 00            	jae	0x20c8 <trusted_x86_x86_sim_xdp+0x20c8>
    1d9e: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1da3: 44 01 e0                     	addl	%r12d, %eax
    1da6: d1 e8                        	shrl	%eax
    1da8: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    1dac: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    1db1: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    1db5: 75 2b                        	jne	0x1de2 <trusted_x86_x86_sim_xdp+0x1de2>
    1db7: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    1dbc: 8b 00                        	movl	(%rax), %eax
    1dbe: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    1dc1: 0f 83 8b 2a 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1dc7: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    1dcd: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    1dd3: 48 0f af c1                  	imulq	%rcx, %rax
    1dd7: 48 01 f8                     	addq	%rdi, %rax
    1dda: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    1de0: eb 15                        	jmp	0x1df7 <trusted_x86_x86_sim_xdp+0x1df7>
    1de2: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    1de6: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    1deb: ff 50 60                     	callq	*0x60(%rax)
    1dee: 48 85 c0                     	testq	%rax, %rax
    1df1: 0f 84 5b 2a 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1df7: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    1dfb: 8d 69 01                     	leal	0x1(%rcx), %ebp
    1dfe: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    1e03: 0f b7 00                     	movzwl	(%rax), %eax
    1e06: 48 39 c2                     	cmpq	%rax, %rdx
    1e09: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    1e0d: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1e12: 0f 42 d1                     	cmovbl	%ecx, %edx
    1e15: 48 89 d0                     	movq	%rdx, %rax
    1e18: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1e1d: 39 d5                        	cmpl	%edx, %ebp
    1e1f: 0f 83 a3 02 00 00            	jae	0x20c8 <trusted_x86_x86_sim_xdp+0x20c8>
    1e25: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1e2a: 01 e8                        	addl	%ebp, %eax
    1e2c: d1 e8                        	shrl	%eax
    1e2e: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    1e32: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    1e37: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    1e3b: 75 2b                        	jne	0x1e68 <trusted_x86_x86_sim_xdp+0x1e68>
    1e3d: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    1e42: 8b 00                        	movl	(%rax), %eax
    1e44: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    1e47: 0f 83 05 2a 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1e4d: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    1e53: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    1e59: 48 0f af c1                  	imulq	%rcx, %rax
    1e5d: 48 01 f8                     	addq	%rdi, %rax
    1e60: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    1e66: eb 15                        	jmp	0x1e7d <trusted_x86_x86_sim_xdp+0x1e7d>
    1e68: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    1e6c: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    1e71: ff 50 60                     	callq	*0x60(%rax)
    1e74: 48 85 c0                     	testq	%rax, %rax
    1e77: 0f 84 d5 29 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1e7d: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    1e81: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    1e85: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    1e8a: 0f b7 00                     	movzwl	(%rax), %eax
    1e8d: 48 39 c2                     	cmpq	%rax, %rdx
    1e90: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    1e94: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1e99: 0f 42 d1                     	cmovbl	%ecx, %edx
    1e9c: 48 89 d0                     	movq	%rdx, %rax
    1e9f: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1ea4: 41 39 d4                     	cmpl	%edx, %r12d
    1ea7: 0f 83 1b 02 00 00            	jae	0x20c8 <trusted_x86_x86_sim_xdp+0x20c8>
    1ead: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1eb2: 44 01 e0                     	addl	%r12d, %eax
    1eb5: d1 e8                        	shrl	%eax
    1eb7: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    1ebb: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    1ec0: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    1ec4: 75 2b                        	jne	0x1ef1 <trusted_x86_x86_sim_xdp+0x1ef1>
    1ec6: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    1ecb: 8b 00                        	movl	(%rax), %eax
    1ecd: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    1ed0: 0f 83 7c 29 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1ed6: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    1edc: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    1ee2: 48 0f af c1                  	imulq	%rcx, %rax
    1ee6: 48 01 f8                     	addq	%rdi, %rax
    1ee9: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    1eef: eb 15                        	jmp	0x1f06 <trusted_x86_x86_sim_xdp+0x1f06>
    1ef1: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    1ef5: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    1efa: ff 50 60                     	callq	*0x60(%rax)
    1efd: 48 85 c0                     	testq	%rax, %rax
    1f00: 0f 84 4c 29 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1f06: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    1f0a: 8d 69 01                     	leal	0x1(%rcx), %ebp
    1f0d: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    1f12: 0f b7 00                     	movzwl	(%rax), %eax
    1f15: 48 39 c2                     	cmpq	%rax, %rdx
    1f18: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    1f1c: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1f21: 0f 42 d1                     	cmovbl	%ecx, %edx
    1f24: 48 89 d0                     	movq	%rdx, %rax
    1f27: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1f2c: 39 d5                        	cmpl	%edx, %ebp
    1f2e: 0f 83 94 01 00 00            	jae	0x20c8 <trusted_x86_x86_sim_xdp+0x20c8>
    1f34: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1f39: 01 e8                        	addl	%ebp, %eax
    1f3b: d1 e8                        	shrl	%eax
    1f3d: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    1f41: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    1f46: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    1f4a: 75 2b                        	jne	0x1f77 <trusted_x86_x86_sim_xdp+0x1f77>
    1f4c: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    1f51: 8b 00                        	movl	(%rax), %eax
    1f53: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    1f56: 0f 83 f6 28 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1f5c: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    1f62: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    1f68: 48 0f af c1                  	imulq	%rcx, %rax
    1f6c: 48 01 f8                     	addq	%rdi, %rax
    1f6f: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    1f75: eb 15                        	jmp	0x1f8c <trusted_x86_x86_sim_xdp+0x1f8c>
    1f77: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    1f7b: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    1f80: ff 50 60                     	callq	*0x60(%rax)
    1f83: 48 85 c0                     	testq	%rax, %rax
    1f86: 0f 84 c6 28 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1f8c: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    1f90: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    1f94: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    1f99: 0f b7 00                     	movzwl	(%rax), %eax
    1f9c: 48 39 c2                     	cmpq	%rax, %rdx
    1f9f: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    1fa3: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1fa8: 0f 42 d1                     	cmovbl	%ecx, %edx
    1fab: 48 89 d0                     	movq	%rdx, %rax
    1fae: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1fb3: 41 39 d4                     	cmpl	%edx, %r12d
    1fb6: 0f 83 0c 01 00 00            	jae	0x20c8 <trusted_x86_x86_sim_xdp+0x20c8>
    1fbc: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1fc1: 44 01 e0                     	addl	%r12d, %eax
    1fc4: d1 e8                        	shrl	%eax
    1fc6: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    1fca: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    1fcf: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    1fd3: 75 2b                        	jne	0x2000 <trusted_x86_x86_sim_xdp+0x2000>
    1fd5: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    1fda: 8b 00                        	movl	(%rax), %eax
    1fdc: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    1fdf: 0f 83 6d 28 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    1fe5: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    1feb: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    1ff1: 48 0f af c1                  	imulq	%rcx, %rax
    1ff5: 48 01 f8                     	addq	%rdi, %rax
    1ff8: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    1ffe: eb 15                        	jmp	0x2015 <trusted_x86_x86_sim_xdp+0x2015>
    2000: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    2004: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    2009: ff 50 60                     	callq	*0x60(%rax)
    200c: 48 85 c0                     	testq	%rax, %rax
    200f: 0f 84 3d 28 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    2015: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    2019: 8d 69 01                     	leal	0x1(%rcx), %ebp
    201c: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    2021: 0f b7 00                     	movzwl	(%rax), %eax
    2024: 48 39 c2                     	cmpq	%rax, %rdx
    2027: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    202b: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    2030: 0f 42 d1                     	cmovbl	%ecx, %edx
    2033: 48 89 d0                     	movq	%rdx, %rax
    2036: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    203b: 39 d5                        	cmpl	%edx, %ebp
    203d: 0f 83 85 00 00 00            	jae	0x20c8 <trusted_x86_x86_sim_xdp+0x20c8>
    2043: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    2048: 01 e8                        	addl	%ebp, %eax
    204a: d1 e8                        	shrl	%eax
    204c: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    2050: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    2055: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    2059: 75 2b                        	jne	0x2086 <trusted_x86_x86_sim_xdp+0x2086>
    205b: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    2060: 8b 00                        	movl	(%rax), %eax
    2062: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    2065: 0f 83 e7 27 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    206b: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    2071: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    2077: 48 0f af c1                  	imulq	%rcx, %rax
    207b: 48 01 f8                     	addq	%rdi, %rax
    207e: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    2084: eb 15                        	jmp	0x209b <trusted_x86_x86_sim_xdp+0x209b>
    2086: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    208a: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    208f: ff 50 60                     	callq	*0x60(%rax)
    2092: 48 85 c0                     	testq	%rax, %rax
    2095: 0f 84 b7 27 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    209b: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    209f: 8d 51 01                     	leal	0x1(%rcx), %edx
    20a2: 0f b7 74 24 40               	movzwl	0x40(%rsp), %esi
    20a7: 0f b7 00                     	movzwl	(%rax), %eax
    20aa: 48 39 c6                     	cmpq	%rax, %rsi
    20ad: 0f 42 d5                     	cmovbl	%ebp, %edx
    20b0: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
    20b5: 0f 42 f1                     	cmovbl	%ecx, %esi
    20b8: 48 89 f0                     	movq	%rsi, %rax
    20bb: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
    20c0: 39 f2                        	cmpl	%esi, %edx
    20c2: 0f 82 8a 27 00 00            	jb	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    20c8: 83 7c 24 10 00               	cmpl	$0x0, 0x10(%rsp)
    20cd: 0f 84 7f 27 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    20d3: 4c 8b 64 24 10               	movq	0x10(%rsp), %r12
    20d8: 41 ff cc                     	decl	%r12d
    20db: 44 89 64 24 64               	movl	%r12d, 0x64(%rsp)
    20e0: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    20e5: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    20e9: 75 28                        	jne	0x2113 <trusted_x86_x86_sim_xdp+0x2113>
    20eb: 8b 44 24 64                  	movl	0x64(%rsp), %eax
    20ef: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    20f2: 0f 83 4a 28 00 00            	jae	0x4942 <trusted_x86_x86_sim_xdp+0x4942>
    20f8: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    20fe: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    2104: 48 0f af c1                  	imulq	%rcx, %rax
    2108: 48 01 f8                     	addq	%rdi, %rax
    210b: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    2111: eb 15                        	jmp	0x2128 <trusted_x86_x86_sim_xdp+0x2128>
    2113: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    2117: 48 8d 74 24 64               	leaq	0x64(%rsp), %rsi
    211c: ff 50 60                     	callq	*0x60(%rax)
    211f: 48 85 c0                     	testq	%rax, %rax
    2122: 0f 84 1a 28 00 00            	je	0x4942 <trusted_x86_x86_sim_xdp+0x4942>
    2128: 0f b7 4c 24 40               	movzwl	0x40(%rsp), %ecx
    212d: 48 89 c2                     	movq	%rax, %rdx
    2130: 0f b7 12                     	movzwl	(%rdx), %edx
    2133: 29 d1                        	subl	%edx, %ecx
    2135: 8b 54 24 64                  	movl	0x64(%rsp), %edx
    2139: 41 8b 37                     	movl	(%r15), %esi
    213c: 44 8d a1 00 00 01 00         	leal	0x10000(%rcx), %r12d
    2143: 39 d6                        	cmpl	%edx, %esi
    2145: 44 0f 46 e1                  	cmovbel	%ecx, %r12d
    2149: 0f b7 40 02                  	movzwl	0x2(%rax), %eax
    214d: 89 44 24 60                  	movl	%eax, 0x60(%rsp)
    2151: 3d 00 80 00 00               	cmpl	$0x8000, %eax           # imm = 0x8000
    2156: 0f 84 f6 27 00 00            	je	0x4952 <trusted_x86_x86_sim_xdp+0x4952>
    215c: 3d 01 80 00 00               	cmpl	$0x8001, %eax           # imm = 0x8001
    2161: 75 49                        	jne	0x21ac <trusted_x86_x86_sim_xdp+0x21ac>
    2163: c7 44 24 3c 07 00 00 00      	movl	$0x7, 0x3c(%rsp)
    216b: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x2172 <trusted_x86_x86_sim_xdp+0x2172>
		000000000000216e:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2172: 83 78 44 08                  	cmpl	$0x8, 0x44(%rax)
    2176: 72 30                        	jb	0x21a8 <trusted_x86_x86_sim_xdp+0x21a8>
    2178: b8 07 00 00 00               	movl	$0x7, %eax
    217d: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2184 <trusted_x86_x86_sim_xdp+0x2184>
		0000000000002180:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2184: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    218a: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    2192: e8 00 00 00 00               	callq	0x2197 <trusted_x86_x86_sim_xdp+0x2197>
		0000000000002193:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    2197: 48 85 c0                     	testq	%rax, %rax
    219a: 74 0c                        	je	0x21a8 <trusted_x86_x86_sim_xdp+0x21a8>
    219c: 48 89 c1                     	movq	%rax, %rcx
    219f: 48 8b 09                     	movq	(%rcx), %rcx
    21a2: 48 ff c1                     	incq	%rcx
    21a5: 48 89 08                     	movq	%rcx, (%rax)
    21a8: 8b 44 24 60                  	movl	0x60(%rsp), %eax
    21ac: 48 8d 4c 24 58               	leaq	0x58(%rsp), %rcx
    21b1: 48 89 8c 24 d0 01 00 00      	movq	%rcx, 0x1d0(%rsp)
    21b9: 48 8d 8c 24 90 00 00 00      	leaq	0x90(%rsp), %rcx
    21c1: 48 89 8c 24 b8 01 00 00      	movq	%rcx, 0x1b8(%rsp)
    21c9: 66 85 c0                     	testw	%ax, %ax
    21cc: 78 31                        	js	0x21ff <trusted_x86_x86_sim_xdp+0x21ff>
    21ce: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x21d5 <trusted_x86_x86_sim_xdp+0x21d5>
		00000000000021d1:  R_X86_64_REX_GOTPCRELX	unwind_info_array-0x4
    21d5: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x21dc <trusted_x86_x86_sim_xdp+0x21dc>
		00000000000021d8:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    21dc: 74 53                        	je	0x2231 <trusted_x86_x86_sim_xdp+0x2231>
    21de: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x21e5 <trusted_x86_x86_sim_xdp+0x21e5>
		00000000000021e1:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
    21e5: 74 4a                        	je	0x2231 <trusted_x86_x86_sim_xdp+0x2231>
    21e7: 48 8d 7c 24 60               	leaq	0x60(%rsp), %rdi
    21ec: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x21f3 <trusted_x86_x86_sim_xdp+0x21f3>
		00000000000021ef:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    21f3: 75 61                        	jne	0x2256 <trusted_x86_x86_sim_xdp+0x2256>
    21f5: e8 00 00 00 00               	callq	0x21fa <trusted_x86_x86_sim_xdp+0x21fa>
		00000000000021f6:  R_X86_64_PLT32	.text+0x7c
    21fa: e9 41 02 00 00               	jmp	0x2440 <trusted_x86_x86_sim_xdp+0x2440>
    21ff: 25 ff 7f ff ff               	andl	$0xffff7fff, %eax       # imm = 0xFFFF7FFF
    2204: ff c8                        	decl	%eax
    2206: 83 f8 03                     	cmpl	$0x3, %eax
    2209: 0f 87 af 27 00 00            	ja	0x49be <trusted_x86_x86_sim_xdp+0x49be>
    220f: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x2216 <trusted_x86_x86_sim_xdp+0x2216>
		0000000000002212:  R_X86_64_PC32	.rodata+0xb4
    2216: 48 63 04 81                  	movslq	(%rcx,%rax,4), %rax
    221a: 48 01 c8                     	addq	%rcx, %rax
    221d: ff e0                        	jmpq	*%rax
    221f: 4c 8b bc 24 80 00 00 00      	movq	0x80(%rsp), %r15
    2227: 45 31 e4                     	xorl	%r12d, %r12d
    222a: 31 ed                        	xorl	%ebp, %ebp
    222c: e9 b7 09 00 00               	jmp	0x2be8 <trusted_x86_x86_sim_xdp+0x2be8>
    2231: 8b 4c 24 60                  	movl	0x60(%rsp), %ecx
    2235: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    2238: 0f 83 d5 29 00 00            	jae	0x4c13 <trusted_x86_x86_sim_xdp+0x4c13>
    223e: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    2244: 48 8b bc c8 30 01 00 00      	movq	0x130(%rax,%rcx,8), %rdi
    224c: e8 00 00 00 00               	callq	0x2251 <trusted_x86_x86_sim_xdp+0x2251>
		000000000000224d:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    2251: e9 ea 01 00 00               	jmp	0x2440 <trusted_x86_x86_sim_xdp+0x2440>
    2256: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x225d <trusted_x86_x86_sim_xdp+0x225d>
		0000000000002259:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    225d: 0f 85 cb 01 00 00            	jne	0x242e <trusted_x86_x86_sim_xdp+0x242e>
    2263: e8 00 00 00 00               	callq	0x2268 <trusted_x86_x86_sim_xdp+0x2268>
		0000000000002264:  R_X86_64_PLT32	.text+0x12c
    2268: e9 d3 01 00 00               	jmp	0x2440 <trusted_x86_x86_sim_xdp+0x2440>
    226d: 48 8b 84 24 88 00 00 00      	movq	0x88(%rsp), %rax
    2275: 48 8b 8c 24 a8 00 00 00      	movq	0xa8(%rsp), %rcx
    227d: 48 8b 00                     	movq	(%rax), %rax
    2280: 8b 09                        	movl	(%rcx), %ecx
    2282: 83 e1 0f                     	andl	$0xf, %ecx
    2285: 31 d2                        	xorl	%edx, %edx
    2287: 83 f9 0b                     	cmpl	$0xb, %ecx
    228a: 0f 93 c2                     	setae	%dl
    228d: 48 8d 04 d0                  	leaq	(%rax,%rdx,8), %rax
    2291: 48 83 c0 08                  	addq	$0x8, %rax
    2295: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    229a: e9 c4 03 00 00               	jmp	0x2663 <trusted_x86_x86_sim_xdp+0x2663>
    229f: 48 8b 84 24 88 00 00 00      	movq	0x88(%rsp), %rax
    22a7: 48 8b 30                     	movq	(%rax), %rsi
    22aa: 48 83 c6 28                  	addq	$0x28, %rsi
    22ae: ba 90 00 00 00               	movl	$0x90, %edx
    22b3: 48 8d bc 24 b8 00 00 00      	leaq	0xb8(%rsp), %rdi
    22bb: e8 00 00 00 00               	callq	0x22c0 <trusted_x86_x86_sim_xdp+0x22c0>
		00000000000022bc:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    22c0: 49 89 c7                     	movq	%rax, %r15
    22c3: 45 85 ff                     	testl	%r15d, %r15d
    22c6: 79 14                        	jns	0x22dc <trusted_x86_x86_sim_xdp+0x22dc>
    22c8: ba 90 00 00 00               	movl	$0x90, %edx
    22cd: 48 8d bc 24 b8 00 00 00      	leaq	0xb8(%rsp), %rdi
    22d5: 31 f6                        	xorl	%esi, %esi
    22d7: e8 00 00 00 00               	callq	0x22dc <trusted_x86_x86_sim_xdp+0x22dc>
		00000000000022d8:  R_X86_64_PLT32	memset-0x4
    22dc: 45 85 ff                     	testl	%r15d, %r15d
    22df: 48 8b 54 24 28               	movq	0x28(%rsp), %rdx
    22e4: 48 8b 74 24 30               	movq	0x30(%rsp), %rsi
    22e9: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
    22ee: 0f 85 21 ef ff ff            	jne	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
    22f4: 48 8b 84 24 20 01 00 00      	movq	0x120(%rsp), %rax
    22fc: 48 8b 8c 24 a8 01 00 00      	movq	0x1a8(%rsp), %rcx
    2304: 48 89 01                     	movq	%rax, (%rcx)
    2307: 48 8b 84 24 c0 00 00 00      	movq	0xc0(%rsp), %rax
    230f: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
    2314: 48 89 f9                     	movq	%rdi, %rcx
    2317: 48 89 01                     	movq	%rax, (%rcx)
    231a: 48 8b 84 24 d0 00 00 00      	movq	0xd0(%rsp), %rax
    2322: 48 89 74 24 30               	movq	%rsi, 0x30(%rsp)
    2327: 48 89 f1                     	movq	%rsi, %rcx
    232a: 48 89 01                     	movq	%rax, (%rcx)
    232d: 48 8b 84 24 e0 00 00 00      	movq	0xe0(%rsp), %rax
    2335: 48 8d 8b 00 0f 00 00         	leaq	0xf00(%rbx), %rcx
    233c: 48 89 01                     	movq	%rax, (%rcx)
    233f: 48 8b 84 24 f0 00 00 00      	movq	0xf0(%rsp), %rax
    2347: 48 89 54 24 28               	movq	%rdx, 0x28(%rsp)
    234c: 48 89 d1                     	movq	%rdx, %rcx
    234f: 48 89 01                     	movq	%rax, (%rcx)
    2352: 48 8b 84 24 08 01 00 00      	movq	0x108(%rsp), %rax
    235a: 48 8b 8c 24 98 01 00 00      	movq	0x198(%rsp), %rcx
    2362: 48 89 01                     	movq	%rax, (%rcx)
    2365: 48 8b 84 24 30 01 00 00      	movq	0x130(%rsp), %rax
    236d: 48 8b 8c 24 88 01 00 00      	movq	0x188(%rsp), %rcx
    2375: 48 89 01                     	movq	%rax, (%rcx)
    2378: 48 8b 84 24 38 01 00 00      	movq	0x138(%rsp), %rax
    2380: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
    2388: 48 89 01                     	movq	%rax, (%rcx)
    238b: 48 8d 83 30 0f 00 00         	leaq	0xf30(%rbx), %rax
    2392: 31 c9                        	xorl	%ecx, %ecx
    2394: e9 3e 03 00 00               	jmp	0x26d7 <trusted_x86_x86_sim_xdp+0x26d7>
    2399: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    239e: 48 8b 30                     	movq	(%rax), %rsi
    23a1: ba 10 00 00 00               	movl	$0x10, %edx
    23a6: 48 8d 7c 24 68               	leaq	0x68(%rsp), %rdi
    23ab: e8 00 00 00 00               	callq	0x23b0 <trusted_x86_x86_sim_xdp+0x23b0>
		00000000000023ac:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    23b0: 85 c0                        	testl	%eax, %eax
    23b2: 79 14                        	jns	0x23c8 <trusted_x86_x86_sim_xdp+0x23c8>
    23b4: 48 8d 4c 24 68               	leaq	0x68(%rsp), %rcx
    23b9: 48 c7 41 08 00 00 00 00      	movq	$0x0, 0x8(%rcx)
    23c1: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
    23c8: 85 c0                        	testl	%eax, %eax
    23ca: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    23cf: 48 8b 4c 24 30               	movq	0x30(%rsp), %rcx
    23d4: 48 8b 54 24 20               	movq	0x20(%rsp), %rdx
    23d9: 0f 85 36 ee ff ff            	jne	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
    23df: 48 89 54 24 20               	movq	%rdx, 0x20(%rsp)
    23e4: 48 89 4c 24 30               	movq	%rcx, 0x30(%rsp)
    23e9: 48 89 44 24 28               	movq	%rax, 0x28(%rsp)
    23ee: 48 89 d8                     	movq	%rbx, %rax
    23f1: 48 8b 80 e0 0e 00 00         	movq	0xee0(%rax), %rax
    23f8: 48 83 c0 10                  	addq	$0x10, %rax
    23fc: 48 8b 8c 24 88 01 00 00      	movq	0x188(%rsp), %rcx
    2404: 48 89 01                     	movq	%rax, (%rcx)
    2407: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
    240c: 48 8b 8c 24 98 01 00 00      	movq	0x198(%rsp), %rcx
    2414: 48 89 01                     	movq	%rax, (%rcx)
    2417: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
    241c: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    2421: 48 8b 84 24 80 01 00 00      	movq	0x180(%rsp), %rax
    2429: e9 98 02 00 00               	jmp	0x26c6 <trusted_x86_x86_sim_xdp+0x26c6>
    242e: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x2435 <trusted_x86_x86_sim_xdp+0x2435>
		0000000000002431:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    2435: 0f 85 9b 00 00 00            	jne	0x24d6 <trusted_x86_x86_sim_xdp+0x24d6>
    243b: e8 00 00 00 00               	callq	0x2440 <trusted_x86_x86_sim_xdp+0x2440>
		000000000000243c:  R_X86_64_PLT32	.text+0x1dc
    2440: 49 89 c7                     	movq	%rax, %r15
    2443: 48 85 c0                     	testq	%rax, %rax
    2446: 48 8b 74 24 28               	movq	0x28(%rsp), %rsi
    244b: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
    2450: 0f 84 bd 27 00 00            	je	0x4c13 <trusted_x86_x86_sim_xdp+0x4c13>
    2456: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
    245b: 48 89 74 24 28               	movq	%rsi, 0x28(%rsp)
    2460: 4c 89 f8                     	movq	%r15, %rax
    2463: 8b 68 04                     	movl	0x4(%rax), %ebp
    2466: 4c 89 f8                     	movq	%r15, %rax
    2469: 0f b6 40 02                  	movzbl	0x2(%rax), %eax
    246d: 85 c0                        	testl	%eax, %eax
    246f: 74 1f                        	je	0x2490 <trusted_x86_x86_sim_xdp+0x2490>
    2471: 89 c1                        	movl	%eax, %ecx
    2473: 83 e1 7f                     	andl	$0x7f, %ecx
    2476: 49 c1 e4 20                  	shlq	$0x20, %r12
    247a: 48 c1 e1 20                  	shlq	$0x20, %rcx
    247e: 49 39 cc                     	cmpq	%rcx, %r12
    2481: 7c 0d                        	jl	0x2490 <trusted_x86_x86_sim_xdp+0x2490>
    2483: f7 d0                        	notl	%eax
    2485: c1 e8 03                     	shrl	$0x3, %eax
    2488: 83 e0 10                     	andl	$0x10, %eax
    248b: 01 c5                        	addl	%eax, %ebp
    248d: 83 c5 f8                     	addl	$-0x8, %ebp
    2490: 4c 89 f8                     	movq	%r15, %rax
    2493: 0f b6 00                     	movzbl	(%rax), %eax
    2496: 89 e9                        	movl	%ebp, %ecx
    2498: 83 e1 f8                     	andl	$-0x8, %ecx
    249b: 84 c0                        	testb	%al, %al
    249d: 0f 49 cd                     	cmovnsl	%ebp, %ecx
    24a0: 89 c2                        	movl	%eax, %edx
    24a2: 83 e2 7f                     	andl	$0x7f, %edx
    24a5: 8d 72 ff                     	leal	-0x1(%rdx), %esi
    24a8: 83 fe 04                     	cmpl	$0x4, %esi
    24ab: 0f 87 c1 00 00 00            	ja	0x2572 <trusted_x86_x86_sim_xdp+0x2572>
    24b1: 0f b6 d2                     	movzbl	%dl, %edx
    24b4: 31 f6                        	xorl	%esi, %esi
    24b6: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
    24bb: ff ca                        	decl	%edx
    24bd: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0x24c4 <trusted_x86_x86_sim_xdp+0x24c4>
		00000000000024c0:  R_X86_64_PC32	.rodata+0xc4
    24c4: 48 63 3c 96                  	movslq	(%rsi,%rdx,4), %rdi
    24c8: 48 01 f7                     	addq	%rsi, %rdi
    24cb: 48 8d 54 24 58               	leaq	0x58(%rsp), %rdx
    24d0: ff e7                        	jmpq	*%rdi
    24d2: 31 d2                        	xorl	%edx, %edx
    24d4: eb 45                        	jmp	0x251b <trusted_x86_x86_sim_xdp+0x251b>
    24d6: 8b 4c 24 60                  	movl	0x60(%rsp), %ecx
    24da: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    24dd: 48 8b 74 24 28               	movq	0x28(%rsp), %rsi
    24e2: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
    24e7: 0f 83 26 27 00 00            	jae	0x4c13 <trusted_x86_x86_sim_xdp+0x4c13>
    24ed: 8b 90 20 01 00 00            	movl	0x120(%rax), %edx
    24f3: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    24f9: 48 0f af ca                  	imulq	%rdx, %rcx
    24fd: 4c 8d 3c 08                  	leaq	(%rax,%rcx), %r15
    2501: 49 81 c7 30 01 00 00         	addq	$0x130, %r15            # imm = 0x130
    2508: e9 49 ff ff ff               	jmp	0x2456 <trusted_x86_x86_sim_xdp+0x2456>
    250d: 48 8d 94 24 88 00 00 00      	leaq	0x88(%rsp), %rdx
    2515: 48 8b 12                     	movq	(%rdx), %rdx
    2518: 48 8b 12                     	movq	(%rdx), %rdx
    251b: 48 63 c9                     	movslq	%ecx, %rcx
    251e: 48 01 d1                     	addq	%rdx, %rcx
    2521: 48 89 4c 24 10               	movq	%rcx, 0x10(%rsp)
    2526: 84 c0                        	testb	%al, %al
    2528: 79 4f                        	jns	0x2579 <trusted_x86_x86_sim_xdp+0x2579>
    252a: ba 08 00 00 00               	movl	$0x8, %edx
    252f: 48 8d 7c 24 68               	leaq	0x68(%rsp), %rdi
    2534: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
    2539: e8 00 00 00 00               	callq	0x253e <trusted_x86_x86_sim_xdp+0x253e>
		000000000000253a:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    253e: 85 c0                        	testl	%eax, %eax
    2540: 79 09                        	jns	0x254b <trusted_x86_x86_sim_xdp+0x254b>
    2542: 48 c7 44 24 68 00 00 00 00   	movq	$0x0, 0x68(%rsp)
    254b: 85 c0                        	testl	%eax, %eax
    254d: 0f 84 67 02 00 00            	je	0x27ba <trusted_x86_x86_sim_xdp+0x27ba>
    2553: eb 1d                        	jmp	0x2572 <trusted_x86_x86_sim_xdp+0x2572>
    2555: 89 e8                        	movl	%ebp, %eax
    2557: 83 e0 0f                     	andl	$0xf, %eax
    255a: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x2561 <trusted_x86_x86_sim_xdp+0x2561>
		000000000000255d:  R_X86_64_PC32	.rodata+0xd8
    2561: 48 63 14 81                  	movslq	(%rcx,%rax,4), %rdx
    2565: 48 01 ca                     	addq	%rcx, %rdx
    2568: 48 8d 84 24 90 00 00 00      	leaq	0x90(%rsp), %rax
    2570: ff e2                        	jmpq	*%rdx
    2572: 31 c0                        	xorl	%eax, %eax
    2574: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    2579: 4c 89 f8                     	movq	%r15, %rax
    257c: 0f b6 40 01                  	movzbl	0x1(%rax), %eax
    2580: 4c 89 f9                     	movq	%r15, %rcx
    2583: 44 8b 61 08                  	movl	0x8(%rcx), %r12d
    2587: 44 89 e1                     	movl	%r12d, %ecx
    258a: 83 e1 f8                     	andl	$-0x8, %ecx
    258d: 84 c0                        	testb	%al, %al
    258f: 41 0f 49 cc                  	cmovnsl	%r12d, %ecx
    2593: 89 c2                        	movl	%eax, %edx
    2595: 83 e2 7f                     	andl	$0x7f, %edx
    2598: 8d 72 ff                     	leal	-0x1(%rdx), %esi
    259b: 83 fe 04                     	cmpl	$0x4, %esi
    259e: 0f 87 ab 00 00 00            	ja	0x264f <trusted_x86_x86_sim_xdp+0x264f>
    25a4: 0f b6 d2                     	movzbl	%dl, %edx
    25a7: ff ca                        	decl	%edx
    25a9: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0x25b0 <trusted_x86_x86_sim_xdp+0x25b0>
		00000000000025ac:  R_X86_64_PC32	.rodata+0x118
    25b0: 48 63 3c 96                  	movslq	(%rsi,%rdx,4), %rdi
    25b4: 48 01 f7                     	addq	%rsi, %rdi
    25b7: 48 8d 74 24 58               	leaq	0x58(%rsp), %rsi
    25bc: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    25c1: ff e7                        	jmpq	*%rdi
    25c3: 48 8d b4 24 88 00 00 00      	leaq	0x88(%rsp), %rsi
    25cb: 48 8b 16                     	movq	(%rsi), %rdx
    25ce: 48 8b 12                     	movq	(%rdx), %rdx
    25d1: 48 63 f1                     	movslq	%ecx, %rsi
    25d4: 48 01 d6                     	addq	%rdx, %rsi
    25d7: 84 c0                        	testb	%al, %al
    25d9: 78 24                        	js	0x25ff <trusted_x86_x86_sim_xdp+0x25ff>
    25db: 48 85 f6                     	testq	%rsi, %rsi
    25de: 74 6f                        	je	0x264f <trusted_x86_x86_sim_xdp+0x264f>
    25e0: 4c 8b 7c 24 58               	movq	0x58(%rsp), %r15
    25e5: ba 08 00 00 00               	movl	$0x8, %edx
    25ea: 4c 89 ff                     	movq	%r15, %rdi
    25ed: e8 00 00 00 00               	callq	0x25f2 <trusted_x86_x86_sim_xdp+0x25f2>
		00000000000025ee:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    25f2: 85 c0                        	testl	%eax, %eax
    25f4: 79 6d                        	jns	0x2663 <trusted_x86_x86_sim_xdp+0x2663>
    25f6: 49 c7 07 00 00 00 00         	movq	$0x0, (%r15)
    25fd: eb 64                        	jmp	0x2663 <trusted_x86_x86_sim_xdp+0x2663>
    25ff: ba 08 00 00 00               	movl	$0x8, %edx
    2604: 48 8d 7c 24 68               	leaq	0x68(%rsp), %rdi
    2609: e8 00 00 00 00               	callq	0x260e <trusted_x86_x86_sim_xdp+0x260e>
		000000000000260a:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    260e: 85 c0                        	testl	%eax, %eax
    2610: 79 09                        	jns	0x261b <trusted_x86_x86_sim_xdp+0x261b>
    2612: 48 c7 44 24 68 00 00 00 00   	movq	$0x0, 0x68(%rsp)
    261b: 85 c0                        	testl	%eax, %eax
    261d: 75 30                        	jne	0x264f <trusted_x86_x86_sim_xdp+0x264f>
    261f: 41 c1 e4 03                  	shll	$0x3, %r12d
    2623: 41 83 e4 38                  	andl	$0x38, %r12d
    2627: 4c 03 64 24 68               	addq	0x68(%rsp), %r12
    262c: 4c 89 e6                     	movq	%r12, %rsi
    262f: eb aa                        	jmp	0x25db <trusted_x86_x86_sim_xdp+0x25db>
    2631: 44 89 e0                     	movl	%r12d, %eax
    2634: 83 e0 0f                     	andl	$0xf, %eax
    2637: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x263e <trusted_x86_x86_sim_xdp+0x263e>
		000000000000263a:  R_X86_64_PC32	.rodata+0x12c
    263e: 48 63 14 81                  	movslq	(%rcx,%rax,4), %rdx
    2642: 48 01 ca                     	addq	%rcx, %rdx
    2645: 48 8d 84 24 90 00 00 00      	leaq	0x90(%rsp), %rax
    264d: ff e2                        	jmpq	*%rdx
    264f: 41 0f b6 07                  	movzbl	(%r15), %eax
    2653: 3c 03                        	cmpb	$0x3, %al
    2655: 75 0c                        	jne	0x2663 <trusted_x86_x86_sim_xdp+0x2663>
    2657: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    265c: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    2663: 48 83 7c 24 10 00            	cmpq	$0x0, 0x10(%rsp)
    2669: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    266e: 48 8b 4c 24 30               	movq	0x30(%rsp), %rcx
    2673: 48 8b 54 24 20               	movq	0x20(%rsp), %rdx
    2678: 0f 84 97 eb ff ff            	je	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
    267e: 48 89 54 24 20               	movq	%rdx, 0x20(%rsp)
    2683: 48 89 4c 24 30               	movq	%rcx, 0x30(%rsp)
    2688: 48 89 44 24 28               	movq	%rax, 0x28(%rsp)
    268d: 4c 8b bc 24 a8 00 00 00      	movq	0xa8(%rsp), %r15
    2695: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    269a: 48 8d 70 f8                  	leaq	-0x8(%rax), %rsi
    269e: ba 08 00 00 00               	movl	$0x8, %edx
    26a3: 4c 89 ff                     	movq	%r15, %rdi
    26a6: e8 00 00 00 00               	callq	0x26ab <trusted_x86_x86_sim_xdp+0x26ab>
		00000000000026a7:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    26ab: 85 c0                        	testl	%eax, %eax
    26ad: 79 07                        	jns	0x26b6 <trusted_x86_x86_sim_xdp+0x26b6>
    26af: 49 c7 07 00 00 00 00         	movq	$0x0, (%r15)
    26b6: 85 c0                        	testl	%eax, %eax
    26b8: 0f 85 57 eb ff ff            	jne	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
    26be: 48 8b 84 24 88 01 00 00      	movq	0x188(%rsp), %rax
    26c6: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
    26cb: 48 89 08                     	movq	%rcx, (%rax)
    26ce: 48 8d 83 30 0f 00 00         	leaq	0xf30(%rbx), %rax
    26d5: b1 01                        	movb	$0x1, %cl
    26d7: 88 08                        	movb	%cl, (%rax)
    26d9: c7 44 24 68 06 00 00 00      	movl	$0x6, 0x68(%rsp)
    26e1: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x26e8 <trusted_x86_x86_sim_xdp+0x26e8>
		00000000000026e4:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    26e8: 83 78 44 07                  	cmpl	$0x7, 0x44(%rax)
    26ec: 72 30                        	jb	0x271e <trusted_x86_x86_sim_xdp+0x271e>
    26ee: b8 06 00 00 00               	movl	$0x6, %eax
    26f3: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x26fa <trusted_x86_x86_sim_xdp+0x26fa>
		00000000000026f6:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    26fa: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    2700: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    2708: e8 00 00 00 00               	callq	0x270d <trusted_x86_x86_sim_xdp+0x270d>
		0000000000002709:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    270d: 48 85 c0                     	testq	%rax, %rax
    2710: 74 0c                        	je	0x271e <trusted_x86_x86_sim_xdp+0x271e>
    2712: 48 89 c1                     	movq	%rax, %rcx
    2715: 48 8b 09                     	movq	(%rcx), %rcx
    2718: 48 ff c1                     	incq	%rcx
    271b: 48 89 08                     	movq	%rcx, (%rax)
    271e: 48 8b 84 24 a8 00 00 00      	movq	0xa8(%rsp), %rax
    2726: 48 8b 28                     	movq	(%rax), %rbp
    2729: 48 85 ed                     	testq	%rbp, %rbp
    272c: 0f 84 4b 28 00 00            	je	0x4f7d <trusted_x86_x86_sim_xdp+0x4f7d>
    2732: 48 b8 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    273c: 48 ff c0                     	incq	%rax
    273f: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    2744: 48 39 c5                     	cmpq	%rax, %rbp
    2747: 0f 83 8e eb ff ff            	jae	0x12db <trusted_x86_x86_sim_xdp+0x12db>
    274d: 48 81 fd 00 10 00 00         	cmpq	$0x1000, %rbp           # imm = 0x1000
    2754: 0f 82 a9 eb ff ff            	jb	0x1303 <trusted_x86_x86_sim_xdp+0x1303>
    275a: 48 89 d8                     	movq	%rbx, %rax
    275d: 8b 00                        	movl	(%rax), %eax
    275f: c7 84 24 b8 00 00 00 60 00 00 00     	movl	$0x60, 0xb8(%rsp)
    276a: 0f 38 f1 84 24 bc 00 00 00   	movbel	%eax, 0xbc(%rsp)
    2773: 48 0f 38 f1 ac 24 c0 00 00 00	movbeq	%rbp, 0xc0(%rsp)
    277d: 80 bc 24 a0 01 00 00 00      	cmpb	$0x0, 0x1a0(%rsp)
    2785: 74 48                        	je	0x27cf <trusted_x86_x86_sim_xdp+0x27cf>
    2787: 8b 84 24 b8 00 00 00         	movl	0xb8(%rsp), %eax
    278e: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2795 <trusted_x86_x86_sim_xdp+0x2795>
		0000000000002791:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2795: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    2798: 0f 83 97 28 00 00            	jae	0x5035 <trusted_x86_x86_sim_xdp+0x5035>
    279e: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x27a5 <trusted_x86_x86_sim_xdp+0x27a5>
		00000000000027a1:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    27a5: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    27ab: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    27b3: e8 00 00 00 00               	callq	0x27b8 <trusted_x86_x86_sim_xdp+0x27b8>
		00000000000027b4:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    27b8: eb 22                        	jmp	0x27dc <trusted_x86_x86_sim_xdp+0x27dc>
    27ba: c1 e5 03                     	shll	$0x3, %ebp
    27bd: 83 e5 38                     	andl	$0x38, %ebp
    27c0: 48 03 6c 24 68               	addq	0x68(%rsp), %rbp
    27c5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
    27ca: e9 aa fd ff ff               	jmp	0x2579 <trusted_x86_x86_sim_xdp+0x2579>
    27cf: 48 8d bc 24 b8 00 00 00      	leaq	0xb8(%rsp), %rdi
    27d7: e8 00 00 00 00               	callq	0x27dc <trusted_x86_x86_sim_xdp+0x27dc>
		00000000000027d8:  R_X86_64_PLT32	.text+0x7c
    27dc: 48 85 c0                     	testq	%rax, %rax
    27df: 0f 84 50 28 00 00            	je	0x5035 <trusted_x86_x86_sim_xdp+0x5035>
    27e5: 48 89 c1                     	movq	%rax, %rcx
    27e8: 4c 8b 61 08                  	movq	0x8(%rcx), %r12
    27ec: 4c 89 e1                     	movq	%r12, %rcx
    27ef: 48 ba ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    27f9: 48 21 d1                     	andq	%rdx, %rcx
    27fc: 48 8b 94 24 90 01 00 00      	movq	0x190(%rsp), %rdx
    2804: 48 89 0a                     	movq	%rcx, (%rdx)
    2807: 48 8b 00                     	movq	(%rax), %rax
    280a: 48 8b 94 24 c8 01 00 00      	movq	0x1c8(%rsp), %rdx
    2812: 48 89 02                     	movq	%rax, (%rdx)
    2815: 49 c1 ec 38                  	shrq	$0x38, %r12
    2819: 48 29 cd                     	subq	%rcx, %rbp
    281c: 48 8b 8c 24 b0 01 00 00      	movq	0x1b0(%rsp), %rcx
    2824: 48 89 29                     	movq	%rbp, (%rcx)
    2827: 49 83 fc 01                  	cmpq	$0x1, %r12
    282b: 0f 85 69 01 00 00            	jne	0x299a <trusted_x86_x86_sim_xdp+0x299a>
    2831: 48 89 84 24 b8 00 00 00      	movq	%rax, 0xb8(%rsp)
    2839: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x2840 <trusted_x86_x86_sim_xdp+0x2840>
		000000000000283c:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    2840: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x2847 <trusted_x86_x86_sim_xdp+0x2847>
		0000000000002843:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2847: 74 28                        	je	0x2871 <trusted_x86_x86_sim_xdp+0x2871>
    2849: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x2850 <trusted_x86_x86_sim_xdp+0x2850>
		000000000000284c:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
    2850: 74 1f                        	je	0x2871 <trusted_x86_x86_sim_xdp+0x2871>
    2852: 48 8d bc 24 b8 00 00 00      	leaq	0xb8(%rsp), %rdi
    285a: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x2861 <trusted_x86_x86_sim_xdp+0x2861>
		000000000000285d:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2861: 0f 85 a1 00 00 00            	jne	0x2908 <trusted_x86_x86_sim_xdp+0x2908>
    2867: e8 00 00 00 00               	callq	0x286c <trusted_x86_x86_sim_xdp+0x286c>
		0000000000002868:  R_X86_64_PLT32	.text+0x7c
    286c: e9 9c 00 00 00               	jmp	0x290d <trusted_x86_x86_sim_xdp+0x290d>
    2871: 8b 8c 24 b8 00 00 00         	movl	0xb8(%rsp), %ecx
    2878: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    287b: 0f 83 25 01 00 00            	jae	0x29a6 <trusted_x86_x86_sim_xdp+0x29a6>
    2881: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    2887: 48 8b bc c8 30 01 00 00      	movq	0x130(%rax,%rcx,8), %rdi
    288f: e8 00 00 00 00               	callq	0x2894 <trusted_x86_x86_sim_xdp+0x2894>
		0000000000002890:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    2894: eb 77                        	jmp	0x290d <trusted_x86_x86_sim_xdp+0x290d>
    2896: 48 8d 84 24 a0 00 00 00      	leaq	0xa0(%rsp), %rax
    289e: eb 0f                        	jmp	0x28af <trusted_x86_x86_sim_xdp+0x28af>
    28a0: 48 8d 84 24 98 00 00 00      	leaq	0x98(%rsp), %rax
    28a8: eb 05                        	jmp	0x28af <trusted_x86_x86_sim_xdp+0x28af>
    28aa: 48 8d 44 24 50               	leaq	0x50(%rsp), %rax
    28af: 48 8b 00                     	movq	(%rax), %rax
    28b2: 89 e9                        	movl	%ebp, %ecx
    28b4: 81 e1 00 00 00 80            	andl	$0x80000000, %ecx       # imm = 0x80000000
    28ba: c1 ed 04                     	shrl	$0x4, %ebp
    28bd: 8d 0c e9                     	leal	(%rcx,%rbp,8), %ecx
    28c0: 48 63 c9                     	movslq	%ecx, %rcx
    28c3: 48 03 08                     	addq	(%rax), %rcx
    28c6: 48 89 4c 24 10               	movq	%rcx, 0x10(%rsp)
    28cb: e9 a9 fc ff ff               	jmp	0x2579 <trusted_x86_x86_sim_xdp+0x2579>
    28d0: 48 8d 84 24 a0 00 00 00      	leaq	0xa0(%rsp), %rax
    28d8: eb 0f                        	jmp	0x28e9 <trusted_x86_x86_sim_xdp+0x28e9>
    28da: 48 8d 84 24 98 00 00 00      	leaq	0x98(%rsp), %rax
    28e2: eb 05                        	jmp	0x28e9 <trusted_x86_x86_sim_xdp+0x28e9>
    28e4: 48 8d 44 24 50               	leaq	0x50(%rsp), %rax
    28e9: 48 8b 00                     	movq	(%rax), %rax
    28ec: 44 89 e1                     	movl	%r12d, %ecx
    28ef: 81 e1 00 00 00 80            	andl	$0x80000000, %ecx       # imm = 0x80000000
    28f5: 41 c1 ec 04                  	shrl	$0x4, %r12d
    28f9: 42 8d 0c e1                  	leal	(%rcx,%r12,8), %ecx
    28fd: 48 63 f1                     	movslq	%ecx, %rsi
    2900: 48 03 30                     	addq	(%rax), %rsi
    2903: e9 d3 fc ff ff               	jmp	0x25db <trusted_x86_x86_sim_xdp+0x25db>
    2908: e8 00 00 00 00               	callq	0x290d <trusted_x86_x86_sim_xdp+0x290d>
		0000000000002909:  R_X86_64_PLT32	.text+0x12c
    290d: 49 89 c7                     	movq	%rax, %r15
    2910: 48 85 c0                     	testq	%rax, %rax
    2913: 0f 84 8d 00 00 00            	je	0x29a6 <trusted_x86_x86_sim_xdp+0x29a6>
    2919: 4c 89 f8                     	movq	%r15, %rax
    291c: 48 8b 00                     	movq	(%rax), %rax
    291f: 48 39 e8                     	cmpq	%rbp, %rax
    2922: 77 0c                        	ja	0x2930 <trusted_x86_x86_sim_xdp+0x2930>
    2924: 4c 89 f8                     	movq	%r15, %rax
    2927: 48 8b 40 08                  	movq	0x8(%rax), %rax
    292b: 48 39 e8                     	cmpq	%rbp, %rax
    292e: 73 18                        	jae	0x2948 <trusted_x86_x86_sim_xdp+0x2948>
    2930: 4c 89 f8                     	movq	%r15, %rax
    2933: 48 8b 40 10                  	movq	0x10(%rax), %rax
    2937: 48 39 e8                     	cmpq	%rbp, %rax
    293a: 77 6a                        	ja	0x29a6 <trusted_x86_x86_sim_xdp+0x29a6>
    293c: 4c 89 f8                     	movq	%r15, %rax
    293f: 48 8b 40 18                  	movq	0x18(%rax), %rax
    2943: 48 39 e8                     	cmpq	%rbp, %rax
    2946: 72 5e                        	jb	0x29a6 <trusted_x86_x86_sim_xdp+0x29a6>
    2948: 48 89 d8                     	movq	%rbx, %rax
    294b: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
    2951: 4c 89 f9                     	movq	%r15, %rcx
    2954: 8b 49 20                     	movl	0x20(%rcx), %ecx
    2957: 0f a3 c8                     	btl	%ecx, %eax
    295a: 72 4a                        	jb	0x29a6 <trusted_x86_x86_sim_xdp+0x29a6>
    295c: c7 44 24 68 00 00 00 00      	movl	$0x0, 0x68(%rsp)
    2964: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x296b <trusted_x86_x86_sim_xdp+0x296b>
		0000000000002967:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    296b: 83 78 44 00                  	cmpl	$0x0, 0x44(%rax)
    296f: 74 24                        	je	0x2995 <trusted_x86_x86_sim_xdp+0x2995>
    2971: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x2978 <trusted_x86_x86_sim_xdp+0x2978>
		0000000000002974:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2978: 48 8b b8 30 01 00 00         	movq	0x130(%rax), %rdi
    297f: e8 00 00 00 00               	callq	0x2984 <trusted_x86_x86_sim_xdp+0x2984>
		0000000000002980:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    2984: 48 85 c0                     	testq	%rax, %rax
    2987: 74 0c                        	je	0x2995 <trusted_x86_x86_sim_xdp+0x2995>
    2989: 48 89 c1                     	movq	%rax, %rcx
    298c: 48 8b 09                     	movq	(%rcx), %rcx
    298f: 48 ff c1                     	incq	%rcx
    2992: 48 89 08                     	movq	%rcx, (%rax)
    2995: 45 0f b7 67 20               	movzwl	0x20(%r15), %r12d
    299a: 31 ed                        	xorl	%ebp, %ebp
    299c: 41 83 fc 01                  	cmpl	$0x1, %r12d
    29a0: 0f 85 ec 25 00 00            	jne	0x4f92 <trusted_x86_x86_sim_xdp+0x4f92>
    29a6: c7 84 24 b8 00 00 00 05 00 00 00     	movl	$0x5, 0xb8(%rsp)
    29b1: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x29b8 <trusted_x86_x86_sim_xdp+0x29b8>
		00000000000029b4:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    29b8: 83 78 44 06                  	cmpl	$0x6, 0x44(%rax)
    29bc: 72 30                        	jb	0x29ee <trusted_x86_x86_sim_xdp+0x29ee>
    29be: b8 05 00 00 00               	movl	$0x5, %eax
    29c3: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x29ca <trusted_x86_x86_sim_xdp+0x29ca>
		00000000000029c6:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    29ca: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    29d0: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    29d8: e8 00 00 00 00               	callq	0x29dd <trusted_x86_x86_sim_xdp+0x29dd>
		00000000000029d9:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    29dd: 48 85 c0                     	testq	%rax, %rax
    29e0: 74 0c                        	je	0x29ee <trusted_x86_x86_sim_xdp+0x29ee>
    29e2: 48 89 c1                     	movq	%rax, %rcx
    29e5: 48 8b 09                     	movq	(%rcx), %rcx
    29e8: 48 ff c1                     	incq	%rcx
    29eb: 48 89 08                     	movq	%rcx, (%rax)
    29ee: 48 89 d8                     	movq	%rbx, %rax
    29f1: 8b 88 c0 02 00 00            	movl	0x2c0(%rax), %ecx
    29f7: 83 f9 7e                     	cmpl	$0x7e, %ecx
    29fa: 0f 87 f3 00 00 00            	ja	0x2af3 <trusted_x86_x86_sim_xdp+0x2af3>
    2a00: 48 89 d8                     	movq	%rbx, %rax
    2a03: 0f b6 80 30 0f 00 00         	movzbl	0xf30(%rax), %eax
    2a0a: 48 89 da                     	movq	%rbx, %rdx
    2a0d: 48 8b 92 10 0f 00 00         	movq	0xf10(%rdx), %rdx
    2a14: 48 89 de                     	movq	%rbx, %rsi
    2a17: 48 8b b6 18 0f 00 00         	movq	0xf18(%rsi), %rsi
    2a1e: 8d 79 01                     	leal	0x1(%rcx), %edi
    2a21: 4c 8b 84 24 c0 01 00 00      	movq	0x1c0(%rsp), %r8
    2a29: 41 89 38                     	movl	%edi, (%r8)
    2a2c: c1 e1 03                     	shll	$0x3, %ecx
    2a2f: 8d 0c 49                     	leal	(%rcx,%rcx,2), %ecx
    2a32: 48 8b bc 24 e0 01 00 00      	movq	0x1e0(%rsp), %rdi
    2a3a: 48 01 cf                     	addq	%rcx, %rdi
    2a3d: 48 89 17                     	movq	%rdx, (%rdi)
    2a40: 48 8b 94 24 e8 01 00 00      	movq	0x1e8(%rsp), %rdx
    2a48: 48 8d 14 0a                  	leaq	(%rdx,%rcx), %rdx
    2a4c: 48 89 32                     	movq	%rsi, (%rdx)
    2a4f: 48 8b 94 24 f0 01 00 00      	movq	0x1f0(%rsp), %rdx
    2a57: 48 8d 14 0a                  	leaq	(%rdx,%rcx), %rdx
    2a5b: c6 02 03                     	movb	$0x3, (%rdx)
    2a5e: 48 8b 94 24 f8 01 00 00      	movq	0x1f8(%rsp), %rdx
    2a66: 48 01 ca                     	addq	%rcx, %rdx
    2a69: 88 02                        	movb	%al, (%rdx)
    2a6b: 48 8b 84 24 00 02 00 00      	movq	0x200(%rsp), %rax
    2a73: 48 01 c8                     	addq	%rcx, %rax
    2a76: c7 00 00 00 00 00            	movl	$0x0, (%rax)
    2a7c: 48 03 8c 24 d8 01 00 00      	addq	0x1d8(%rsp), %rcx
    2a84: 66 c7 01 00 00               	movw	$0x0, (%rcx)
    2a89: c7 44 24 60 00 00 00 00      	movl	$0x0, 0x60(%rsp)
    2a91: 48 89 d8                     	movq	%rbx, %rax
    2a94: 48 8b 80 10 0f 00 00         	movq	0xf10(%rax), %rax
    2a9b: 48 89 84 24 b0 00 00 00      	movq	%rax, 0xb0(%rsp)
    2aa3: 48 89 44 24 68               	movq	%rax, 0x68(%rsp)
    2aa8: 48 89 d8                     	movq	%rbx, %rax
    2aab: 48 c7 c1 00 00 ff ff         	movq	$-0x10000, %rcx         # imm = 0xFFFF0000
    2ab2: 48 23 88 18 0f 00 00         	andq	0xf18(%rax), %rcx
    2ab9: 48 89 4c 24 70               	movq	%rcx, 0x70(%rsp)
    2abe: 45 84 f6                     	testb	%r14b, %r14b
    2ac1: 74 44                        	je	0x2b07 <trusted_x86_x86_sim_xdp+0x2b07>
    2ac3: 8b 44 24 68                  	movl	0x68(%rsp), %eax
    2ac7: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2ace <trusted_x86_x86_sim_xdp+0x2ace>
		0000000000002aca:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    2ace: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    2ad1: 0f 83 d4 00 00 00            	jae	0x2bab <trusted_x86_x86_sim_xdp+0x2bab>
    2ad7: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2ade <trusted_x86_x86_sim_xdp+0x2ade>
		0000000000002ada:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    2ade: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    2ae4: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    2aec: e8 00 00 00 00               	callq	0x2af1 <trusted_x86_x86_sim_xdp+0x2af1>
		0000000000002aed:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    2af1: eb 51                        	jmp	0x2b44 <trusted_x86_x86_sim_xdp+0x2b44>
    2af3: 4c 8b bc 24 80 00 00 00      	movq	0x80(%rsp), %r15
    2afb: 4c 8b 25 00 00 00 00         	movq	(%rip), %r12            # 0x2b02 <trusted_x86_x86_sim_xdp+0x2b02>
		0000000000002afe:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2b02: e9 dd d5 ff ff               	jmp	0xe4 <trusted_x86_x86_sim_xdp+0xe4>
    2b07: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x2b0e <trusted_x86_x86_sim_xdp+0x2b0e>
		0000000000002b0a:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    2b0e: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x2b15 <trusted_x86_x86_sim_xdp+0x2b15>
		0000000000002b11:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2b15: 75 0c                        	jne	0x2b23 <trusted_x86_x86_sim_xdp+0x2b23>
    2b17: 48 8d 7c 24 68               	leaq	0x68(%rsp), %rdi
    2b1c: e8 00 00 00 00               	callq	0x2b21 <trusted_x86_x86_sim_xdp+0x2b21>
		0000000000002b1d:  R_X86_64_PLT32	.text+0x7c
    2b21: eb 21                        	jmp	0x2b44 <trusted_x86_x86_sim_xdp+0x2b44>
    2b23: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x2b2a <trusted_x86_x86_sim_xdp+0x2b2a>
		0000000000002b26:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    2b2a: 48 8d 7c 24 68               	leaq	0x68(%rsp), %rdi
    2b2f: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x2b36 <trusted_x86_x86_sim_xdp+0x2b36>
		0000000000002b32:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    2b36: 75 07                        	jne	0x2b3f <trusted_x86_x86_sim_xdp+0x2b3f>
    2b38: e8 00 00 00 00               	callq	0x2b3d <trusted_x86_x86_sim_xdp+0x2b3d>
		0000000000002b39:  R_X86_64_PLT32	.text+0x12c
    2b3d: eb 05                        	jmp	0x2b44 <trusted_x86_x86_sim_xdp+0x2b44>
    2b3f: e8 00 00 00 00               	callq	0x2b44 <trusted_x86_x86_sim_xdp+0x2b44>
		0000000000002b40:  R_X86_64_PLT32	.text+0x1dc
    2b44: 49 89 c7                     	movq	%rax, %r15
    2b47: 48 85 c0                     	testq	%rax, %rax
    2b4a: 74 5f                        	je	0x2bab <trusted_x86_x86_sim_xdp+0x2bab>
    2b4c: 4c 89 f8                     	movq	%r15, %rax
    2b4f: 0f b7 40 06                  	movzwl	0x6(%rax), %eax
    2b53: 0f b7 c0                     	movzwl	%ax, %eax
    2b56: 83 c0 f8                     	addl	$-0x8, %eax
    2b59: a9 f0 ff 00 00               	testl	$0xfff0, %eax           # imm = 0xFFF0
    2b5e: 0f 85 4f ec ff ff            	jne	0x17b3 <trusted_x86_x86_sim_xdp+0x17b3>
    2b64: 83 e0 0f                     	andl	$0xf, %eax
    2b67: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x2b6e <trusted_x86_x86_sim_xdp+0x2b6e>
		0000000000002b6a:  R_X86_64_PC32	.data.rel.ro-0x4
    2b6e: 48 8b 3c c1                  	movq	(%rcx,%rax,8), %rdi
    2b72: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    2b76: 0f 85 4a 01 00 00            	jne	0x2cc6 <trusted_x86_x86_sim_xdp+0x2cc6>
    2b7c: 8b 84 24 b0 00 00 00         	movl	0xb0(%rsp), %eax
    2b83: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    2b86: 73 37                        	jae	0x2bbf <trusted_x86_x86_sim_xdp+0x2bbf>
    2b88: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    2b8e: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    2b94: 48 0f af c1                  	imulq	%rcx, %rax
    2b98: 48 01 f8                     	addq	%rdi, %rax
    2b9b: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    2ba1: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    2ba6: e9 38 01 00 00               	jmp	0x2ce3 <trusted_x86_x86_sim_xdp+0x2ce3>
    2bab: 4c 8b bc 24 80 00 00 00      	movq	0x80(%rsp), %r15
    2bb3: b9 a0 0f 00 00               	movl	$0xfa0, %ecx            # imm = 0xFA0
    2bb8: ba 08 00 00 00               	movl	$0x8, %edx
    2bbd: eb 1b                        	jmp	0x2bda <trusted_x86_x86_sim_xdp+0x2bda>
    2bbf: 48 c7 44 24 48 00 00 00 00   	movq	$0x0, 0x48(%rsp)
    2bc8: 4c 8b bc 24 80 00 00 00      	movq	0x80(%rsp), %r15
    2bd0: ba 32 00 00 00               	movl	$0x32, %edx
    2bd5: b9 a2 0f 00 00               	movl	$0xfa2, %ecx            # imm = 0xFA2
    2bda: 48 8d 83 28 0f 00 00         	leaq	0xf28(%rbx), %rax
    2be1: 89 10                        	movl	%edx, (%rax)
    2be3: 45 31 e4                     	xorl	%r12d, %r12d
    2be6: 89 cd                        	movl	%ecx, %ebp
    2be8: 48 81 c3 2c 0f 00 00         	addq	$0xf2c, %rbx            # imm = 0xF2C
    2bef: 89 2b                        	movl	%ebp, (%rbx)
    2bf1: c7 84 24 b8 00 00 00 00 00 00 00     	movl	$0x0, 0xb8(%rsp)
    2bfc: 31 db                        	xorl	%ebx, %ebx
    2bfe: 41 83 7d 44 00               	cmpl	$0x0, 0x44(%r13)
    2c03: 0f 84 95 00 00 00            	je	0x2c9e <trusted_x86_x86_sim_xdp+0x2c9e>
    2c09: 49 8b bd 30 01 00 00         	movq	0x130(%r13), %rdi
    2c10: e8 00 00 00 00               	callq	0x2c15 <trusted_x86_x86_sim_xdp+0x2c15>
		0000000000002c11:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    2c15: 48 85 c0                     	testq	%rax, %rax
    2c18: 0f 84 80 00 00 00            	je	0x2c9e <trusted_x86_x86_sim_xdp+0x2c9e>
    2c1e: 48 89 c1                     	movq	%rax, %rcx
    2c21: 0f b6 89 84 13 00 00         	movzbl	0x1384(%rcx), %ecx
    2c28: 80 f9 1d                     	cmpb	$0x1d, %cl
    2c2b: 72 64                        	jb	0x2c91 <trusted_x86_x86_sim_xdp+0x2c91>
    2c2d: 48 8d 88 2c 0f 00 00         	leaq	0xf2c(%rax), %rcx
    2c34: c7 01 05 00 00 00            	movl	$0x5, (%rcx)
    2c3a: c7 84 24 b8 00 00 00 44 00 00 00     	movl	$0x44, 0xb8(%rsp)
    2c45: 48 8b 15 00 00 00 00         	movq	(%rip), %rdx            # 0x2c4c <trusted_x86_x86_sim_xdp+0x2c4c>
		0000000000002c48:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2c4c: 83 7a 44 45                  	cmpl	$0x45, 0x44(%rdx)
    2c50: 72 32                        	jb	0x2c84 <trusted_x86_x86_sim_xdp+0x2c84>
    2c52: b9 44 00 00 00               	movl	$0x44, %ecx
    2c57: 23 8a 24 01 00 00            	andl	0x124(%rdx), %ecx
    2c5d: 48 8b bc ca 30 01 00 00      	movq	0x130(%rdx,%rcx,8), %rdi
    2c65: 48 89 c3                     	movq	%rax, %rbx
    2c68: e8 00 00 00 00               	callq	0x2c6d <trusted_x86_x86_sim_xdp+0x2c6d>
		0000000000002c69:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    2c6d: 48 89 c1                     	movq	%rax, %rcx
    2c70: 48 89 d8                     	movq	%rbx, %rax
    2c73: 48 85 c9                     	testq	%rcx, %rcx
    2c76: 74 0c                        	je	0x2c84 <trusted_x86_x86_sim_xdp+0x2c84>
    2c78: 48 89 ca                     	movq	%rcx, %rdx
    2c7b: 48 8b 12                     	movq	(%rdx), %rdx
    2c7e: 48 ff c2                     	incq	%rdx
    2c81: 48 89 11                     	movq	%rdx, (%rcx)
    2c84: 48 89 c1                     	movq	%rax, %rcx
    2c87: 0f b6 89 84 13 00 00         	movzbl	0x1384(%rcx), %ecx
    2c8e: 45 31 e4                     	xorl	%r12d, %r12d
    2c91: fe c1                        	incb	%cl
    2c93: 48 05 84 13 00 00            	addq	$0x1384, %rax           # imm = 0x1384
    2c99: 88 08                        	movb	%cl, (%rax)
    2c9b: 44 89 e3                     	movl	%r12d, %ebx
    2c9e: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x2ca5 <trusted_x86_x86_sim_xdp+0x2ca5>
		0000000000002ca1:  R_X86_64_REX_GOTPCRELX	perf_progs-0x4
    2ca5: 4c 89 ff                     	movq	%r15, %rdi
    2ca8: 89 da                        	movl	%ebx, %edx
    2caa: e8 00 00 00 00               	callq	0x2caf <trusted_x86_x86_sim_xdp+0x2caf>
		0000000000002cab:  R_X86_64_PLT32	bpf_tail_call-0x4
    2caf: b8 ff ff ff ff               	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
    2cb4: 48 81 c4 08 02 00 00         	addq	$0x208, %rsp            # imm = 0x208
    2cbb: 5b                           	popq	%rbx
    2cbc: 41 5c                        	popq	%r12
    2cbe: 41 5d                        	popq	%r13
    2cc0: 41 5e                        	popq	%r14
    2cc2: 41 5f                        	popq	%r15
    2cc4: 5d                           	popq	%rbp
    2cc5: c3                           	retq
    2cc6: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    2cca: 48 8d b4 24 b0 00 00 00      	leaq	0xb0(%rsp), %rsi
    2cd2: ff 50 60                     	callq	*0x60(%rax)
    2cd5: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    2cda: 48 85 c0                     	testq	%rax, %rax
    2cdd: 0f 84 e5 fe ff ff            	je	0x2bc8 <trusted_x86_x86_sim_xdp+0x2bc8>
    2ce3: 4c 89 f9                     	movq	%r15, %rcx
    2ce6: 4c 89 f8                     	movq	%r15, %rax
    2ce9: 44 8b 20                     	movl	(%rax), %r12d
    2cec: 44 89 64 24 64               	movl	%r12d, 0x64(%rsp)
    2cf1: 48 89 d8                     	movq	%rbx, %rax
    2cf4: 48 8b 80 18 0f 00 00         	movq	0xf18(%rax), %rax
    2cfb: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    2d00: 4c 89 f8                     	movq	%r15, %rax
    2d03: 0f b7 48 04                  	movzwl	0x4(%rax), %ecx
    2d07: 85 c9                        	testl	%ecx, %ecx
    2d09: 0f 84 8b 08 00 00            	je	0x359a <trusted_x86_x86_sim_xdp+0x359a>
    2d0f: 48 89 c8                     	movq	%rcx, %rax
    2d12: 44 01 e0                     	addl	%r12d, %eax
    2d15: 48 89 44 24 18               	movq	%rax, 0x18(%rsp)
    2d1a: 44 01 e0                     	addl	%r12d, %eax
    2d1d: d1 e8                        	shrl	%eax
    2d1f: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    2d23: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    2d28: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    2d2c: 75 2b                        	jne	0x2d59 <trusted_x86_x86_sim_xdp+0x2d59>
    2d2e: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    2d33: 8b 00                        	movl	(%rax), %eax
    2d35: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    2d38: 0f 83 14 1b 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    2d3e: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    2d44: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    2d4a: 48 0f af c1                  	imulq	%rcx, %rax
    2d4e: 48 01 f8                     	addq	%rdi, %rax
    2d51: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    2d57: eb 15                        	jmp	0x2d6e <trusted_x86_x86_sim_xdp+0x2d6e>
    2d59: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    2d5d: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    2d62: ff 50 60                     	callq	*0x60(%rax)
    2d65: 48 85 c0                     	testq	%rax, %rax
    2d68: 0f 84 e4 1a 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    2d6e: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    2d72: 8d 69 01                     	leal	0x1(%rcx), %ebp
    2d75: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    2d7a: 0f b7 00                     	movzwl	(%rax), %eax
    2d7d: 48 39 c2                     	cmpq	%rax, %rdx
    2d80: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    2d84: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    2d89: 0f 42 d1                     	cmovbl	%ecx, %edx
    2d8c: 48 89 d0                     	movq	%rdx, %rax
    2d8f: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    2d94: 39 d5                        	cmpl	%edx, %ebp
    2d96: 0f 83 ee 07 00 00            	jae	0x358a <trusted_x86_x86_sim_xdp+0x358a>
    2d9c: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    2da1: 01 e8                        	addl	%ebp, %eax
    2da3: d1 e8                        	shrl	%eax
    2da5: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    2da9: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    2dae: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    2db2: 75 2b                        	jne	0x2ddf <trusted_x86_x86_sim_xdp+0x2ddf>
    2db4: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    2db9: 8b 00                        	movl	(%rax), %eax
    2dbb: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    2dbe: 0f 83 8e 1a 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    2dc4: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    2dca: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    2dd0: 48 0f af c1                  	imulq	%rcx, %rax
    2dd4: 48 01 f8                     	addq	%rdi, %rax
    2dd7: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    2ddd: eb 15                        	jmp	0x2df4 <trusted_x86_x86_sim_xdp+0x2df4>
    2ddf: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    2de3: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    2de8: ff 50 60                     	callq	*0x60(%rax)
    2deb: 48 85 c0                     	testq	%rax, %rax
    2dee: 0f 84 5e 1a 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    2df4: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    2df8: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    2dfc: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    2e01: 0f b7 00                     	movzwl	(%rax), %eax
    2e04: 48 39 c2                     	cmpq	%rax, %rdx
    2e07: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    2e0b: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    2e10: 0f 42 d1                     	cmovbl	%ecx, %edx
    2e13: 48 89 d0                     	movq	%rdx, %rax
    2e16: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    2e1b: 41 39 d4                     	cmpl	%edx, %r12d
    2e1e: 0f 83 66 07 00 00            	jae	0x358a <trusted_x86_x86_sim_xdp+0x358a>
    2e24: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    2e29: 44 01 e0                     	addl	%r12d, %eax
    2e2c: d1 e8                        	shrl	%eax
    2e2e: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    2e32: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    2e37: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    2e3b: 75 2b                        	jne	0x2e68 <trusted_x86_x86_sim_xdp+0x2e68>
    2e3d: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    2e42: 8b 00                        	movl	(%rax), %eax
    2e44: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    2e47: 0f 83 05 1a 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    2e4d: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    2e53: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    2e59: 48 0f af c1                  	imulq	%rcx, %rax
    2e5d: 48 01 f8                     	addq	%rdi, %rax
    2e60: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    2e66: eb 15                        	jmp	0x2e7d <trusted_x86_x86_sim_xdp+0x2e7d>
    2e68: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    2e6c: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    2e71: ff 50 60                     	callq	*0x60(%rax)
    2e74: 48 85 c0                     	testq	%rax, %rax
    2e77: 0f 84 d5 19 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    2e7d: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    2e81: 8d 69 01                     	leal	0x1(%rcx), %ebp
    2e84: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    2e89: 0f b7 00                     	movzwl	(%rax), %eax
    2e8c: 48 39 c2                     	cmpq	%rax, %rdx
    2e8f: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    2e93: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    2e98: 0f 42 d1                     	cmovbl	%ecx, %edx
    2e9b: 48 89 d0                     	movq	%rdx, %rax
    2e9e: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    2ea3: 39 d5                        	cmpl	%edx, %ebp
    2ea5: 0f 83 df 06 00 00            	jae	0x358a <trusted_x86_x86_sim_xdp+0x358a>
    2eab: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    2eb0: 01 e8                        	addl	%ebp, %eax
    2eb2: d1 e8                        	shrl	%eax
    2eb4: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    2eb8: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    2ebd: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    2ec1: 75 2b                        	jne	0x2eee <trusted_x86_x86_sim_xdp+0x2eee>
    2ec3: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    2ec8: 8b 00                        	movl	(%rax), %eax
    2eca: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    2ecd: 0f 83 7f 19 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    2ed3: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    2ed9: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    2edf: 48 0f af c1                  	imulq	%rcx, %rax
    2ee3: 48 01 f8                     	addq	%rdi, %rax
    2ee6: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    2eec: eb 15                        	jmp	0x2f03 <trusted_x86_x86_sim_xdp+0x2f03>
    2eee: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    2ef2: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    2ef7: ff 50 60                     	callq	*0x60(%rax)
    2efa: 48 85 c0                     	testq	%rax, %rax
    2efd: 0f 84 4f 19 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    2f03: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    2f07: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    2f0b: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    2f10: 0f b7 00                     	movzwl	(%rax), %eax
    2f13: 48 39 c2                     	cmpq	%rax, %rdx
    2f16: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    2f1a: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    2f1f: 0f 42 d1                     	cmovbl	%ecx, %edx
    2f22: 48 89 d0                     	movq	%rdx, %rax
    2f25: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    2f2a: 41 39 d4                     	cmpl	%edx, %r12d
    2f2d: 0f 83 57 06 00 00            	jae	0x358a <trusted_x86_x86_sim_xdp+0x358a>
    2f33: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    2f38: 44 01 e0                     	addl	%r12d, %eax
    2f3b: d1 e8                        	shrl	%eax
    2f3d: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    2f41: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    2f46: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    2f4a: 75 2b                        	jne	0x2f77 <trusted_x86_x86_sim_xdp+0x2f77>
    2f4c: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    2f51: 8b 00                        	movl	(%rax), %eax
    2f53: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    2f56: 0f 83 f6 18 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    2f5c: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    2f62: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    2f68: 48 0f af c1                  	imulq	%rcx, %rax
    2f6c: 48 01 f8                     	addq	%rdi, %rax
    2f6f: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    2f75: eb 15                        	jmp	0x2f8c <trusted_x86_x86_sim_xdp+0x2f8c>
    2f77: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    2f7b: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    2f80: ff 50 60                     	callq	*0x60(%rax)
    2f83: 48 85 c0                     	testq	%rax, %rax
    2f86: 0f 84 c6 18 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    2f8c: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    2f90: 8d 69 01                     	leal	0x1(%rcx), %ebp
    2f93: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    2f98: 0f b7 00                     	movzwl	(%rax), %eax
    2f9b: 48 39 c2                     	cmpq	%rax, %rdx
    2f9e: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    2fa2: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    2fa7: 0f 42 d1                     	cmovbl	%ecx, %edx
    2faa: 48 89 d0                     	movq	%rdx, %rax
    2fad: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    2fb2: 39 d5                        	cmpl	%edx, %ebp
    2fb4: 0f 83 d0 05 00 00            	jae	0x358a <trusted_x86_x86_sim_xdp+0x358a>
    2fba: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    2fbf: 01 e8                        	addl	%ebp, %eax
    2fc1: d1 e8                        	shrl	%eax
    2fc3: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    2fc7: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    2fcc: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    2fd0: 75 2b                        	jne	0x2ffd <trusted_x86_x86_sim_xdp+0x2ffd>
    2fd2: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    2fd7: 8b 00                        	movl	(%rax), %eax
    2fd9: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    2fdc: 0f 83 70 18 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    2fe2: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    2fe8: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    2fee: 48 0f af c1                  	imulq	%rcx, %rax
    2ff2: 48 01 f8                     	addq	%rdi, %rax
    2ff5: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    2ffb: eb 15                        	jmp	0x3012 <trusted_x86_x86_sim_xdp+0x3012>
    2ffd: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    3001: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    3006: ff 50 60                     	callq	*0x60(%rax)
    3009: 48 85 c0                     	testq	%rax, %rax
    300c: 0f 84 40 18 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    3012: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    3016: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    301a: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    301f: 0f b7 00                     	movzwl	(%rax), %eax
    3022: 48 39 c2                     	cmpq	%rax, %rdx
    3025: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    3029: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    302e: 0f 42 d1                     	cmovbl	%ecx, %edx
    3031: 48 89 d0                     	movq	%rdx, %rax
    3034: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    3039: 41 39 d4                     	cmpl	%edx, %r12d
    303c: 0f 83 48 05 00 00            	jae	0x358a <trusted_x86_x86_sim_xdp+0x358a>
    3042: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    3047: 44 01 e0                     	addl	%r12d, %eax
    304a: d1 e8                        	shrl	%eax
    304c: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    3050: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    3055: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    3059: 75 2b                        	jne	0x3086 <trusted_x86_x86_sim_xdp+0x3086>
    305b: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    3060: 8b 00                        	movl	(%rax), %eax
    3062: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    3065: 0f 83 e7 17 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    306b: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    3071: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    3077: 48 0f af c1                  	imulq	%rcx, %rax
    307b: 48 01 f8                     	addq	%rdi, %rax
    307e: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    3084: eb 15                        	jmp	0x309b <trusted_x86_x86_sim_xdp+0x309b>
    3086: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    308a: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    308f: ff 50 60                     	callq	*0x60(%rax)
    3092: 48 85 c0                     	testq	%rax, %rax
    3095: 0f 84 b7 17 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    309b: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    309f: 8d 69 01                     	leal	0x1(%rcx), %ebp
    30a2: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    30a7: 0f b7 00                     	movzwl	(%rax), %eax
    30aa: 48 39 c2                     	cmpq	%rax, %rdx
    30ad: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    30b1: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    30b6: 0f 42 d1                     	cmovbl	%ecx, %edx
    30b9: 48 89 d0                     	movq	%rdx, %rax
    30bc: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    30c1: 39 d5                        	cmpl	%edx, %ebp
    30c3: 0f 83 c1 04 00 00            	jae	0x358a <trusted_x86_x86_sim_xdp+0x358a>
    30c9: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    30ce: 01 e8                        	addl	%ebp, %eax
    30d0: d1 e8                        	shrl	%eax
    30d2: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    30d6: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    30db: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    30df: 75 2b                        	jne	0x310c <trusted_x86_x86_sim_xdp+0x310c>
    30e1: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    30e6: 8b 00                        	movl	(%rax), %eax
    30e8: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    30eb: 0f 83 61 17 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    30f1: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    30f7: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    30fd: 48 0f af c1                  	imulq	%rcx, %rax
    3101: 48 01 f8                     	addq	%rdi, %rax
    3104: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    310a: eb 15                        	jmp	0x3121 <trusted_x86_x86_sim_xdp+0x3121>
    310c: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    3110: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    3115: ff 50 60                     	callq	*0x60(%rax)
    3118: 48 85 c0                     	testq	%rax, %rax
    311b: 0f 84 31 17 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    3121: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    3125: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    3129: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    312e: 0f b7 00                     	movzwl	(%rax), %eax
    3131: 48 39 c2                     	cmpq	%rax, %rdx
    3134: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    3138: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    313d: 0f 42 d1                     	cmovbl	%ecx, %edx
    3140: 48 89 d0                     	movq	%rdx, %rax
    3143: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    3148: 41 39 d4                     	cmpl	%edx, %r12d
    314b: 0f 83 39 04 00 00            	jae	0x358a <trusted_x86_x86_sim_xdp+0x358a>
    3151: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    3156: 44 01 e0                     	addl	%r12d, %eax
    3159: d1 e8                        	shrl	%eax
    315b: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    315f: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    3164: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    3168: 75 2b                        	jne	0x3195 <trusted_x86_x86_sim_xdp+0x3195>
    316a: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    316f: 8b 00                        	movl	(%rax), %eax
    3171: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    3174: 0f 83 d8 16 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    317a: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    3180: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    3186: 48 0f af c1                  	imulq	%rcx, %rax
    318a: 48 01 f8                     	addq	%rdi, %rax
    318d: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    3193: eb 15                        	jmp	0x31aa <trusted_x86_x86_sim_xdp+0x31aa>
    3195: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    3199: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    319e: ff 50 60                     	callq	*0x60(%rax)
    31a1: 48 85 c0                     	testq	%rax, %rax
    31a4: 0f 84 a8 16 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    31aa: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    31ae: 8d 69 01                     	leal	0x1(%rcx), %ebp
    31b1: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    31b6: 0f b7 00                     	movzwl	(%rax), %eax
    31b9: 48 39 c2                     	cmpq	%rax, %rdx
    31bc: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    31c0: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    31c5: 0f 42 d1                     	cmovbl	%ecx, %edx
    31c8: 48 89 d0                     	movq	%rdx, %rax
    31cb: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    31d0: 39 d5                        	cmpl	%edx, %ebp
    31d2: 0f 83 b2 03 00 00            	jae	0x358a <trusted_x86_x86_sim_xdp+0x358a>
    31d8: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    31dd: 01 e8                        	addl	%ebp, %eax
    31df: d1 e8                        	shrl	%eax
    31e1: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    31e5: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    31ea: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    31ee: 75 2b                        	jne	0x321b <trusted_x86_x86_sim_xdp+0x321b>
    31f0: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    31f5: 8b 00                        	movl	(%rax), %eax
    31f7: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    31fa: 0f 83 52 16 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    3200: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    3206: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    320c: 48 0f af c1                  	imulq	%rcx, %rax
    3210: 48 01 f8                     	addq	%rdi, %rax
    3213: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    3219: eb 15                        	jmp	0x3230 <trusted_x86_x86_sim_xdp+0x3230>
    321b: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    321f: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    3224: ff 50 60                     	callq	*0x60(%rax)
    3227: 48 85 c0                     	testq	%rax, %rax
    322a: 0f 84 22 16 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    3230: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    3234: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    3238: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    323d: 0f b7 00                     	movzwl	(%rax), %eax
    3240: 48 39 c2                     	cmpq	%rax, %rdx
    3243: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    3247: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    324c: 0f 42 d1                     	cmovbl	%ecx, %edx
    324f: 48 89 d0                     	movq	%rdx, %rax
    3252: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    3257: 41 39 d4                     	cmpl	%edx, %r12d
    325a: 0f 83 2a 03 00 00            	jae	0x358a <trusted_x86_x86_sim_xdp+0x358a>
    3260: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    3265: 44 01 e0                     	addl	%r12d, %eax
    3268: d1 e8                        	shrl	%eax
    326a: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    326e: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    3273: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    3277: 75 2b                        	jne	0x32a4 <trusted_x86_x86_sim_xdp+0x32a4>
    3279: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    327e: 8b 00                        	movl	(%rax), %eax
    3280: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    3283: 0f 83 c9 15 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    3289: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    328f: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    3295: 48 0f af c1                  	imulq	%rcx, %rax
    3299: 48 01 f8                     	addq	%rdi, %rax
    329c: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    32a2: eb 15                        	jmp	0x32b9 <trusted_x86_x86_sim_xdp+0x32b9>
    32a4: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    32a8: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    32ad: ff 50 60                     	callq	*0x60(%rax)
    32b0: 48 85 c0                     	testq	%rax, %rax
    32b3: 0f 84 99 15 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    32b9: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    32bd: 8d 69 01                     	leal	0x1(%rcx), %ebp
    32c0: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    32c5: 0f b7 00                     	movzwl	(%rax), %eax
    32c8: 48 39 c2                     	cmpq	%rax, %rdx
    32cb: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    32cf: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    32d4: 0f 42 d1                     	cmovbl	%ecx, %edx
    32d7: 48 89 d0                     	movq	%rdx, %rax
    32da: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    32df: 39 d5                        	cmpl	%edx, %ebp
    32e1: 0f 83 a3 02 00 00            	jae	0x358a <trusted_x86_x86_sim_xdp+0x358a>
    32e7: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    32ec: 01 e8                        	addl	%ebp, %eax
    32ee: d1 e8                        	shrl	%eax
    32f0: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    32f4: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    32f9: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    32fd: 75 2b                        	jne	0x332a <trusted_x86_x86_sim_xdp+0x332a>
    32ff: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    3304: 8b 00                        	movl	(%rax), %eax
    3306: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    3309: 0f 83 43 15 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    330f: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    3315: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    331b: 48 0f af c1                  	imulq	%rcx, %rax
    331f: 48 01 f8                     	addq	%rdi, %rax
    3322: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    3328: eb 15                        	jmp	0x333f <trusted_x86_x86_sim_xdp+0x333f>
    332a: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    332e: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    3333: ff 50 60                     	callq	*0x60(%rax)
    3336: 48 85 c0                     	testq	%rax, %rax
    3339: 0f 84 13 15 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    333f: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    3343: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    3347: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    334c: 0f b7 00                     	movzwl	(%rax), %eax
    334f: 48 39 c2                     	cmpq	%rax, %rdx
    3352: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    3356: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    335b: 0f 42 d1                     	cmovbl	%ecx, %edx
    335e: 48 89 d0                     	movq	%rdx, %rax
    3361: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    3366: 41 39 d4                     	cmpl	%edx, %r12d
    3369: 0f 83 1b 02 00 00            	jae	0x358a <trusted_x86_x86_sim_xdp+0x358a>
    336f: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    3374: 44 01 e0                     	addl	%r12d, %eax
    3377: d1 e8                        	shrl	%eax
    3379: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    337d: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    3382: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    3386: 75 2b                        	jne	0x33b3 <trusted_x86_x86_sim_xdp+0x33b3>
    3388: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    338d: 8b 00                        	movl	(%rax), %eax
    338f: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    3392: 0f 83 ba 14 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    3398: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    339e: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    33a4: 48 0f af c1                  	imulq	%rcx, %rax
    33a8: 48 01 f8                     	addq	%rdi, %rax
    33ab: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    33b1: eb 15                        	jmp	0x33c8 <trusted_x86_x86_sim_xdp+0x33c8>
    33b3: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    33b7: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    33bc: ff 50 60                     	callq	*0x60(%rax)
    33bf: 48 85 c0                     	testq	%rax, %rax
    33c2: 0f 84 8a 14 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    33c8: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    33cc: 8d 69 01                     	leal	0x1(%rcx), %ebp
    33cf: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    33d4: 0f b7 00                     	movzwl	(%rax), %eax
    33d7: 48 39 c2                     	cmpq	%rax, %rdx
    33da: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    33de: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    33e3: 0f 42 d1                     	cmovbl	%ecx, %edx
    33e6: 48 89 d0                     	movq	%rdx, %rax
    33e9: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    33ee: 39 d5                        	cmpl	%edx, %ebp
    33f0: 0f 83 94 01 00 00            	jae	0x358a <trusted_x86_x86_sim_xdp+0x358a>
    33f6: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    33fb: 01 e8                        	addl	%ebp, %eax
    33fd: d1 e8                        	shrl	%eax
    33ff: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    3403: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    3408: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    340c: 75 2b                        	jne	0x3439 <trusted_x86_x86_sim_xdp+0x3439>
    340e: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    3413: 8b 00                        	movl	(%rax), %eax
    3415: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    3418: 0f 83 34 14 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    341e: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    3424: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    342a: 48 0f af c1                  	imulq	%rcx, %rax
    342e: 48 01 f8                     	addq	%rdi, %rax
    3431: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    3437: eb 15                        	jmp	0x344e <trusted_x86_x86_sim_xdp+0x344e>
    3439: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    343d: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    3442: ff 50 60                     	callq	*0x60(%rax)
    3445: 48 85 c0                     	testq	%rax, %rax
    3448: 0f 84 04 14 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    344e: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    3452: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    3456: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    345b: 0f b7 00                     	movzwl	(%rax), %eax
    345e: 48 39 c2                     	cmpq	%rax, %rdx
    3461: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    3465: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    346a: 0f 42 d1                     	cmovbl	%ecx, %edx
    346d: 48 89 d0                     	movq	%rdx, %rax
    3470: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    3475: 41 39 d4                     	cmpl	%edx, %r12d
    3478: 0f 83 0c 01 00 00            	jae	0x358a <trusted_x86_x86_sim_xdp+0x358a>
    347e: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    3483: 44 01 e0                     	addl	%r12d, %eax
    3486: d1 e8                        	shrl	%eax
    3488: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    348c: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    3491: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    3495: 75 2b                        	jne	0x34c2 <trusted_x86_x86_sim_xdp+0x34c2>
    3497: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    349c: 8b 00                        	movl	(%rax), %eax
    349e: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    34a1: 0f 83 ab 13 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    34a7: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    34ad: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    34b3: 48 0f af c1                  	imulq	%rcx, %rax
    34b7: 48 01 f8                     	addq	%rdi, %rax
    34ba: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    34c0: eb 15                        	jmp	0x34d7 <trusted_x86_x86_sim_xdp+0x34d7>
    34c2: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    34c6: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    34cb: ff 50 60                     	callq	*0x60(%rax)
    34ce: 48 85 c0                     	testq	%rax, %rax
    34d1: 0f 84 7b 13 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    34d7: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    34db: 8d 69 01                     	leal	0x1(%rcx), %ebp
    34de: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    34e3: 0f b7 00                     	movzwl	(%rax), %eax
    34e6: 48 39 c2                     	cmpq	%rax, %rdx
    34e9: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    34ed: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    34f2: 0f 42 d1                     	cmovbl	%ecx, %edx
    34f5: 48 89 d0                     	movq	%rdx, %rax
    34f8: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    34fd: 39 d5                        	cmpl	%edx, %ebp
    34ff: 0f 83 85 00 00 00            	jae	0x358a <trusted_x86_x86_sim_xdp+0x358a>
    3505: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    350a: 01 e8                        	addl	%ebp, %eax
    350c: d1 e8                        	shrl	%eax
    350e: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    3512: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    3517: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    351b: 75 2b                        	jne	0x3548 <trusted_x86_x86_sim_xdp+0x3548>
    351d: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    3522: 8b 00                        	movl	(%rax), %eax
    3524: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    3527: 0f 83 25 13 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    352d: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    3533: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    3539: 48 0f af c1                  	imulq	%rcx, %rax
    353d: 48 01 f8                     	addq	%rdi, %rax
    3540: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    3546: eb 15                        	jmp	0x355d <trusted_x86_x86_sim_xdp+0x355d>
    3548: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    354c: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    3551: ff 50 60                     	callq	*0x60(%rax)
    3554: 48 85 c0                     	testq	%rax, %rax
    3557: 0f 84 f5 12 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    355d: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    3561: 8d 51 01                     	leal	0x1(%rcx), %edx
    3564: 0f b7 74 24 40               	movzwl	0x40(%rsp), %esi
    3569: 0f b7 00                     	movzwl	(%rax), %eax
    356c: 48 39 c6                     	cmpq	%rax, %rsi
    356f: 0f 42 d5                     	cmovbl	%ebp, %edx
    3572: 48 8b 74 24 18               	movq	0x18(%rsp), %rsi
    3577: 0f 42 f1                     	cmovbl	%ecx, %esi
    357a: 48 89 f0                     	movq	%rsi, %rax
    357d: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
    3582: 39 f2                        	cmpl	%esi, %edx
    3584: 0f 82 c8 12 00 00            	jb	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    358a: 83 7c 24 18 00               	cmpl	$0x0, 0x18(%rsp)
    358f: 0f 84 bd 12 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    3595: 4c 8b 64 24 18               	movq	0x18(%rsp), %r12
    359a: 41 ff cc                     	decl	%r12d
    359d: 44 89 64 24 64               	movl	%r12d, 0x64(%rsp)
    35a2: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    35a7: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    35ab: 75 28                        	jne	0x35d5 <trusted_x86_x86_sim_xdp+0x35d5>
    35ad: 8b 44 24 64                  	movl	0x64(%rsp), %eax
    35b1: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    35b4: 0f 83 88 13 00 00            	jae	0x4942 <trusted_x86_x86_sim_xdp+0x4942>
    35ba: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    35c0: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    35c6: 48 0f af c1                  	imulq	%rcx, %rax
    35ca: 48 01 f8                     	addq	%rdi, %rax
    35cd: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    35d3: eb 15                        	jmp	0x35ea <trusted_x86_x86_sim_xdp+0x35ea>
    35d5: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    35d9: 48 8d 74 24 64               	leaq	0x64(%rsp), %rsi
    35de: ff 50 60                     	callq	*0x60(%rax)
    35e1: 48 85 c0                     	testq	%rax, %rax
    35e4: 0f 84 58 13 00 00            	je	0x4942 <trusted_x86_x86_sim_xdp+0x4942>
    35ea: 0f b7 4c 24 40               	movzwl	0x40(%rsp), %ecx
    35ef: 48 89 c2                     	movq	%rax, %rdx
    35f2: 0f b7 12                     	movzwl	(%rdx), %edx
    35f5: 29 d1                        	subl	%edx, %ecx
    35f7: 8b 54 24 64                  	movl	0x64(%rsp), %edx
    35fb: 41 8b 37                     	movl	(%r15), %esi
    35fe: 44 8d a1 00 00 01 00         	leal	0x10000(%rcx), %r12d
    3605: 39 d6                        	cmpl	%edx, %esi
    3607: 44 0f 46 e1                  	cmovbel	%ecx, %r12d
    360b: 0f b7 40 02                  	movzwl	0x2(%rax), %eax
    360f: 89 44 24 60                  	movl	%eax, 0x60(%rsp)
    3613: 3d 00 80 00 00               	cmpl	$0x8000, %eax           # imm = 0x8000
    3618: 0f 84 34 13 00 00            	je	0x4952 <trusted_x86_x86_sim_xdp+0x4952>
    361e: 3d 01 80 00 00               	cmpl	$0x8001, %eax           # imm = 0x8001
    3623: 75 49                        	jne	0x366e <trusted_x86_x86_sim_xdp+0x366e>
    3625: c7 44 24 3c 07 00 00 00      	movl	$0x7, 0x3c(%rsp)
    362d: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x3634 <trusted_x86_x86_sim_xdp+0x3634>
		0000000000003630:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3634: 83 78 44 08                  	cmpl	$0x8, 0x44(%rax)
    3638: 72 30                        	jb	0x366a <trusted_x86_x86_sim_xdp+0x366a>
    363a: b8 07 00 00 00               	movl	$0x7, %eax
    363f: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3646 <trusted_x86_x86_sim_xdp+0x3646>
		0000000000003642:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3646: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    364c: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    3654: e8 00 00 00 00               	callq	0x3659 <trusted_x86_x86_sim_xdp+0x3659>
		0000000000003655:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3659: 48 85 c0                     	testq	%rax, %rax
    365c: 74 0c                        	je	0x366a <trusted_x86_x86_sim_xdp+0x366a>
    365e: 48 89 c1                     	movq	%rax, %rcx
    3661: 48 8b 09                     	movq	(%rcx), %rcx
    3664: 48 ff c1                     	incq	%rcx
    3667: 48 89 08                     	movq	%rcx, (%rax)
    366a: 8b 44 24 60                  	movl	0x60(%rsp), %eax
    366e: 66 85 c0                     	testw	%ax, %ax
    3671: 78 35                        	js	0x36a8 <trusted_x86_x86_sim_xdp+0x36a8>
    3673: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x367a <trusted_x86_x86_sim_xdp+0x367a>
		0000000000003676:  R_X86_64_REX_GOTPCRELX	unwind_info_array-0x4
    367a: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x3681 <trusted_x86_x86_sim_xdp+0x3681>
		000000000000367d:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3681: 74 77                        	je	0x36fa <trusted_x86_x86_sim_xdp+0x36fa>
    3683: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x368a <trusted_x86_x86_sim_xdp+0x368a>
		0000000000003686:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
    368a: 74 6e                        	je	0x36fa <trusted_x86_x86_sim_xdp+0x36fa>
    368c: 48 8d 7c 24 60               	leaq	0x60(%rsp), %rdi
    3691: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x3698 <trusted_x86_x86_sim_xdp+0x3698>
		0000000000003694:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3698: 0f 85 81 00 00 00            	jne	0x371f <trusted_x86_x86_sim_xdp+0x371f>
    369e: e8 00 00 00 00               	callq	0x36a3 <trusted_x86_x86_sim_xdp+0x36a3>
		000000000000369f:  R_X86_64_PLT32	.text+0x7c
    36a3: e9 2f 02 00 00               	jmp	0x38d7 <trusted_x86_x86_sim_xdp+0x38d7>
    36a8: 25 ff 7f ff ff               	andl	$0xffff7fff, %eax       # imm = 0xFFFF7FFF
    36ad: ff c8                        	decl	%eax
    36af: 83 f8 03                     	cmpl	$0x3, %eax
    36b2: 0f 87 06 13 00 00            	ja	0x49be <trusted_x86_x86_sim_xdp+0x49be>
    36b8: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x36bf <trusted_x86_x86_sim_xdp+0x36bf>
		00000000000036bb:  R_X86_64_PC32	.rodata+0x16c
    36bf: 48 63 04 81                  	movslq	(%rcx,%rax,4), %rax
    36c3: 48 01 c8                     	addq	%rcx, %rax
    36c6: ff e0                        	jmpq	*%rax
    36c8: 48 8b 84 24 88 00 00 00      	movq	0x88(%rsp), %rax
    36d0: 48 8b 8c 24 a8 00 00 00      	movq	0xa8(%rsp), %rcx
    36d8: 48 8b 00                     	movq	(%rax), %rax
    36db: 8b 09                        	movl	(%rcx), %ecx
    36dd: 83 e1 0f                     	andl	$0xf, %ecx
    36e0: 31 d2                        	xorl	%edx, %edx
    36e2: 83 f9 0b                     	cmpl	$0xb, %ecx
    36e5: 0f 93 c2                     	setae	%dl
    36e8: 48 8d 04 d0                  	leaq	(%rax,%rdx,8), %rax
    36ec: 48 83 c0 08                  	addq	$0x8, %rax
    36f0: 48 89 44 24 18               	movq	%rax, 0x18(%rsp)
    36f5: e9 00 04 00 00               	jmp	0x3afa <trusted_x86_x86_sim_xdp+0x3afa>
    36fa: 8b 4c 24 60                  	movl	0x60(%rsp), %ecx
    36fe: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    3701: 0f 83 0c 15 00 00            	jae	0x4c13 <trusted_x86_x86_sim_xdp+0x4c13>
    3707: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    370d: 48 8b bc c8 30 01 00 00      	movq	0x130(%rax,%rcx,8), %rdi
    3715: e8 00 00 00 00               	callq	0x371a <trusted_x86_x86_sim_xdp+0x371a>
		0000000000003716:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    371a: e9 b8 01 00 00               	jmp	0x38d7 <trusted_x86_x86_sim_xdp+0x38d7>
    371f: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x3726 <trusted_x86_x86_sim_xdp+0x3726>
		0000000000003722:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    3726: 0f 85 99 01 00 00            	jne	0x38c5 <trusted_x86_x86_sim_xdp+0x38c5>
    372c: e8 00 00 00 00               	callq	0x3731 <trusted_x86_x86_sim_xdp+0x3731>
		000000000000372d:  R_X86_64_PLT32	.text+0x12c
    3731: e9 a1 01 00 00               	jmp	0x38d7 <trusted_x86_x86_sim_xdp+0x38d7>
    3736: 48 8b 84 24 88 00 00 00      	movq	0x88(%rsp), %rax
    373e: 48 8b 30                     	movq	(%rax), %rsi
    3741: 48 83 c6 28                  	addq	$0x28, %rsi
    3745: ba 90 00 00 00               	movl	$0x90, %edx
    374a: 48 8d bc 24 b8 00 00 00      	leaq	0xb8(%rsp), %rdi
    3752: e8 00 00 00 00               	callq	0x3757 <trusted_x86_x86_sim_xdp+0x3757>
		0000000000003753:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3757: 49 89 c7                     	movq	%rax, %r15
    375a: 45 85 ff                     	testl	%r15d, %r15d
    375d: 79 14                        	jns	0x3773 <trusted_x86_x86_sim_xdp+0x3773>
    375f: ba 90 00 00 00               	movl	$0x90, %edx
    3764: 48 8d bc 24 b8 00 00 00      	leaq	0xb8(%rsp), %rdi
    376c: 31 f6                        	xorl	%esi, %esi
    376e: e8 00 00 00 00               	callq	0x3773 <trusted_x86_x86_sim_xdp+0x3773>
		000000000000376f:  R_X86_64_PLT32	memset-0x4
    3773: 45 85 ff                     	testl	%r15d, %r15d
    3776: 48 8b 54 24 28               	movq	0x28(%rsp), %rdx
    377b: 48 8b 74 24 30               	movq	0x30(%rsp), %rsi
    3780: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
    3785: 0f 85 8a da ff ff            	jne	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
    378b: 48 8b 84 24 20 01 00 00      	movq	0x120(%rsp), %rax
    3793: 48 8b 8c 24 a8 01 00 00      	movq	0x1a8(%rsp), %rcx
    379b: 48 89 01                     	movq	%rax, (%rcx)
    379e: 48 8b 84 24 c0 00 00 00      	movq	0xc0(%rsp), %rax
    37a6: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
    37ab: 48 89 f9                     	movq	%rdi, %rcx
    37ae: 48 89 01                     	movq	%rax, (%rcx)
    37b1: 48 8b 84 24 d0 00 00 00      	movq	0xd0(%rsp), %rax
    37b9: 48 89 74 24 30               	movq	%rsi, 0x30(%rsp)
    37be: 48 89 f1                     	movq	%rsi, %rcx
    37c1: 48 89 01                     	movq	%rax, (%rcx)
    37c4: 48 8b 84 24 e0 00 00 00      	movq	0xe0(%rsp), %rax
    37cc: 48 8d 8b 00 0f 00 00         	leaq	0xf00(%rbx), %rcx
    37d3: 48 89 01                     	movq	%rax, (%rcx)
    37d6: 48 8b 84 24 f0 00 00 00      	movq	0xf0(%rsp), %rax
    37de: 48 89 54 24 28               	movq	%rdx, 0x28(%rsp)
    37e3: 48 89 d1                     	movq	%rdx, %rcx
    37e6: 48 89 01                     	movq	%rax, (%rcx)
    37e9: 48 8b 84 24 08 01 00 00      	movq	0x108(%rsp), %rax
    37f1: 48 8b 8c 24 98 01 00 00      	movq	0x198(%rsp), %rcx
    37f9: 48 89 01                     	movq	%rax, (%rcx)
    37fc: 48 8b 84 24 30 01 00 00      	movq	0x130(%rsp), %rax
    3804: 48 8b 8c 24 88 01 00 00      	movq	0x188(%rsp), %rcx
    380c: 48 89 01                     	movq	%rax, (%rcx)
    380f: 48 8b 84 24 38 01 00 00      	movq	0x138(%rsp), %rax
    3817: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
    381f: 48 89 01                     	movq	%rax, (%rcx)
    3822: 48 8d 83 30 0f 00 00         	leaq	0xf30(%rbx), %rax
    3829: 31 c9                        	xorl	%ecx, %ecx
    382b: e9 3e 03 00 00               	jmp	0x3b6e <trusted_x86_x86_sim_xdp+0x3b6e>
    3830: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    3835: 48 8b 30                     	movq	(%rax), %rsi
    3838: ba 10 00 00 00               	movl	$0x10, %edx
    383d: 48 8d 7c 24 68               	leaq	0x68(%rsp), %rdi
    3842: e8 00 00 00 00               	callq	0x3847 <trusted_x86_x86_sim_xdp+0x3847>
		0000000000003843:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3847: 85 c0                        	testl	%eax, %eax
    3849: 79 14                        	jns	0x385f <trusted_x86_x86_sim_xdp+0x385f>
    384b: 48 8d 4c 24 68               	leaq	0x68(%rsp), %rcx
    3850: 48 c7 41 08 00 00 00 00      	movq	$0x0, 0x8(%rcx)
    3858: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
    385f: 85 c0                        	testl	%eax, %eax
    3861: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    3866: 48 8b 4c 24 30               	movq	0x30(%rsp), %rcx
    386b: 48 8b 54 24 20               	movq	0x20(%rsp), %rdx
    3870: 0f 85 9f d9 ff ff            	jne	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
    3876: 48 89 54 24 20               	movq	%rdx, 0x20(%rsp)
    387b: 48 89 4c 24 30               	movq	%rcx, 0x30(%rsp)
    3880: 48 89 44 24 28               	movq	%rax, 0x28(%rsp)
    3885: 48 89 d8                     	movq	%rbx, %rax
    3888: 48 8b 80 e0 0e 00 00         	movq	0xee0(%rax), %rax
    388f: 48 83 c0 10                  	addq	$0x10, %rax
    3893: 48 8b 8c 24 88 01 00 00      	movq	0x188(%rsp), %rcx
    389b: 48 89 01                     	movq	%rax, (%rcx)
    389e: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
    38a3: 48 8b 8c 24 98 01 00 00      	movq	0x198(%rsp), %rcx
    38ab: 48 89 01                     	movq	%rax, (%rcx)
    38ae: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
    38b3: 48 89 44 24 18               	movq	%rax, 0x18(%rsp)
    38b8: 48 8b 84 24 80 01 00 00      	movq	0x180(%rsp), %rax
    38c0: e9 98 02 00 00               	jmp	0x3b5d <trusted_x86_x86_sim_xdp+0x3b5d>
    38c5: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x38cc <trusted_x86_x86_sim_xdp+0x38cc>
		00000000000038c8:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    38cc: 0f 85 9b 00 00 00            	jne	0x396d <trusted_x86_x86_sim_xdp+0x396d>
    38d2: e8 00 00 00 00               	callq	0x38d7 <trusted_x86_x86_sim_xdp+0x38d7>
		00000000000038d3:  R_X86_64_PLT32	.text+0x1dc
    38d7: 49 89 c7                     	movq	%rax, %r15
    38da: 48 85 c0                     	testq	%rax, %rax
    38dd: 48 8b 74 24 28               	movq	0x28(%rsp), %rsi
    38e2: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
    38e7: 0f 84 26 13 00 00            	je	0x4c13 <trusted_x86_x86_sim_xdp+0x4c13>
    38ed: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
    38f2: 48 89 74 24 28               	movq	%rsi, 0x28(%rsp)
    38f7: 4c 89 f8                     	movq	%r15, %rax
    38fa: 8b 68 04                     	movl	0x4(%rax), %ebp
    38fd: 4c 89 f8                     	movq	%r15, %rax
    3900: 0f b6 40 02                  	movzbl	0x2(%rax), %eax
    3904: 85 c0                        	testl	%eax, %eax
    3906: 74 1f                        	je	0x3927 <trusted_x86_x86_sim_xdp+0x3927>
    3908: 89 c1                        	movl	%eax, %ecx
    390a: 83 e1 7f                     	andl	$0x7f, %ecx
    390d: 49 c1 e4 20                  	shlq	$0x20, %r12
    3911: 48 c1 e1 20                  	shlq	$0x20, %rcx
    3915: 49 39 cc                     	cmpq	%rcx, %r12
    3918: 7c 0d                        	jl	0x3927 <trusted_x86_x86_sim_xdp+0x3927>
    391a: f7 d0                        	notl	%eax
    391c: c1 e8 03                     	shrl	$0x3, %eax
    391f: 83 e0 10                     	andl	$0x10, %eax
    3922: 01 c5                        	addl	%eax, %ebp
    3924: 83 c5 f8                     	addl	$-0x8, %ebp
    3927: 4c 89 f8                     	movq	%r15, %rax
    392a: 0f b6 00                     	movzbl	(%rax), %eax
    392d: 89 e9                        	movl	%ebp, %ecx
    392f: 83 e1 f8                     	andl	$-0x8, %ecx
    3932: 84 c0                        	testb	%al, %al
    3934: 0f 49 cd                     	cmovnsl	%ebp, %ecx
    3937: 89 c2                        	movl	%eax, %edx
    3939: 83 e2 7f                     	andl	$0x7f, %edx
    393c: 8d 72 ff                     	leal	-0x1(%rdx), %esi
    393f: 83 fe 04                     	cmpl	$0x4, %esi
    3942: 0f 87 c1 00 00 00            	ja	0x3a09 <trusted_x86_x86_sim_xdp+0x3a09>
    3948: 0f b6 d2                     	movzbl	%dl, %edx
    394b: 31 f6                        	xorl	%esi, %esi
    394d: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
    3952: ff ca                        	decl	%edx
    3954: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0x395b <trusted_x86_x86_sim_xdp+0x395b>
		0000000000003957:  R_X86_64_PC32	.rodata+0x17c
    395b: 48 63 3c 96                  	movslq	(%rsi,%rdx,4), %rdi
    395f: 48 01 f7                     	addq	%rsi, %rdi
    3962: 48 8d 54 24 58               	leaq	0x58(%rsp), %rdx
    3967: ff e7                        	jmpq	*%rdi
    3969: 31 d2                        	xorl	%edx, %edx
    396b: eb 45                        	jmp	0x39b2 <trusted_x86_x86_sim_xdp+0x39b2>
    396d: 8b 4c 24 60                  	movl	0x60(%rsp), %ecx
    3971: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    3974: 48 8b 74 24 28               	movq	0x28(%rsp), %rsi
    3979: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
    397e: 0f 83 8f 12 00 00            	jae	0x4c13 <trusted_x86_x86_sim_xdp+0x4c13>
    3984: 8b 90 20 01 00 00            	movl	0x120(%rax), %edx
    398a: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    3990: 48 0f af ca                  	imulq	%rdx, %rcx
    3994: 4c 8d 3c 08                  	leaq	(%rax,%rcx), %r15
    3998: 49 81 c7 30 01 00 00         	addq	$0x130, %r15            # imm = 0x130
    399f: e9 49 ff ff ff               	jmp	0x38ed <trusted_x86_x86_sim_xdp+0x38ed>
    39a4: 48 8d 94 24 88 00 00 00      	leaq	0x88(%rsp), %rdx
    39ac: 48 8b 12                     	movq	(%rdx), %rdx
    39af: 48 8b 12                     	movq	(%rdx), %rdx
    39b2: 48 63 c9                     	movslq	%ecx, %rcx
    39b5: 48 01 d1                     	addq	%rdx, %rcx
    39b8: 48 89 4c 24 18               	movq	%rcx, 0x18(%rsp)
    39bd: 84 c0                        	testb	%al, %al
    39bf: 79 4f                        	jns	0x3a10 <trusted_x86_x86_sim_xdp+0x3a10>
    39c1: ba 08 00 00 00               	movl	$0x8, %edx
    39c6: 48 8d 7c 24 68               	leaq	0x68(%rsp), %rdi
    39cb: 48 8b 74 24 18               	movq	0x18(%rsp), %rsi
    39d0: e8 00 00 00 00               	callq	0x39d5 <trusted_x86_x86_sim_xdp+0x39d5>
		00000000000039d1:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    39d5: 85 c0                        	testl	%eax, %eax
    39d7: 79 09                        	jns	0x39e2 <trusted_x86_x86_sim_xdp+0x39e2>
    39d9: 48 c7 44 24 68 00 00 00 00   	movq	$0x0, 0x68(%rsp)
    39e2: 85 c0                        	testl	%eax, %eax
    39e4: 0f 84 57 02 00 00            	je	0x3c41 <trusted_x86_x86_sim_xdp+0x3c41>
    39ea: eb 1d                        	jmp	0x3a09 <trusted_x86_x86_sim_xdp+0x3a09>
    39ec: 89 e8                        	movl	%ebp, %eax
    39ee: 83 e0 0f                     	andl	$0xf, %eax
    39f1: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x39f8 <trusted_x86_x86_sim_xdp+0x39f8>
		00000000000039f4:  R_X86_64_PC32	.rodata+0x190
    39f8: 48 63 14 81                  	movslq	(%rcx,%rax,4), %rdx
    39fc: 48 01 ca                     	addq	%rcx, %rdx
    39ff: 48 8d 84 24 90 00 00 00      	leaq	0x90(%rsp), %rax
    3a07: ff e2                        	jmpq	*%rdx
    3a09: 31 c0                        	xorl	%eax, %eax
    3a0b: 48 89 44 24 18               	movq	%rax, 0x18(%rsp)
    3a10: 4c 89 f8                     	movq	%r15, %rax
    3a13: 0f b6 40 01                  	movzbl	0x1(%rax), %eax
    3a17: 4c 89 f9                     	movq	%r15, %rcx
    3a1a: 44 8b 61 08                  	movl	0x8(%rcx), %r12d
    3a1e: 44 89 e1                     	movl	%r12d, %ecx
    3a21: 83 e1 f8                     	andl	$-0x8, %ecx
    3a24: 84 c0                        	testb	%al, %al
    3a26: 41 0f 49 cc                  	cmovnsl	%r12d, %ecx
    3a2a: 89 c2                        	movl	%eax, %edx
    3a2c: 83 e2 7f                     	andl	$0x7f, %edx
    3a2f: 8d 72 ff                     	leal	-0x1(%rdx), %esi
    3a32: 83 fe 04                     	cmpl	$0x4, %esi
    3a35: 0f 87 ab 00 00 00            	ja	0x3ae6 <trusted_x86_x86_sim_xdp+0x3ae6>
    3a3b: 0f b6 d2                     	movzbl	%dl, %edx
    3a3e: ff ca                        	decl	%edx
    3a40: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0x3a47 <trusted_x86_x86_sim_xdp+0x3a47>
		0000000000003a43:  R_X86_64_PC32	.rodata+0x1d0
    3a47: 48 63 3c 96                  	movslq	(%rsi,%rdx,4), %rdi
    3a4b: 48 01 f7                     	addq	%rsi, %rdi
    3a4e: 48 8d 74 24 58               	leaq	0x58(%rsp), %rsi
    3a53: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    3a58: ff e7                        	jmpq	*%rdi
    3a5a: 48 8d b4 24 88 00 00 00      	leaq	0x88(%rsp), %rsi
    3a62: 48 8b 16                     	movq	(%rsi), %rdx
    3a65: 48 8b 12                     	movq	(%rdx), %rdx
    3a68: 48 63 f1                     	movslq	%ecx, %rsi
    3a6b: 48 01 d6                     	addq	%rdx, %rsi
    3a6e: 84 c0                        	testb	%al, %al
    3a70: 78 24                        	js	0x3a96 <trusted_x86_x86_sim_xdp+0x3a96>
    3a72: 48 85 f6                     	testq	%rsi, %rsi
    3a75: 74 6f                        	je	0x3ae6 <trusted_x86_x86_sim_xdp+0x3ae6>
    3a77: 4c 8b 7c 24 58               	movq	0x58(%rsp), %r15
    3a7c: ba 08 00 00 00               	movl	$0x8, %edx
    3a81: 4c 89 ff                     	movq	%r15, %rdi
    3a84: e8 00 00 00 00               	callq	0x3a89 <trusted_x86_x86_sim_xdp+0x3a89>
		0000000000003a85:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3a89: 85 c0                        	testl	%eax, %eax
    3a8b: 79 6d                        	jns	0x3afa <trusted_x86_x86_sim_xdp+0x3afa>
    3a8d: 49 c7 07 00 00 00 00         	movq	$0x0, (%r15)
    3a94: eb 64                        	jmp	0x3afa <trusted_x86_x86_sim_xdp+0x3afa>
    3a96: ba 08 00 00 00               	movl	$0x8, %edx
    3a9b: 48 8d 7c 24 68               	leaq	0x68(%rsp), %rdi
    3aa0: e8 00 00 00 00               	callq	0x3aa5 <trusted_x86_x86_sim_xdp+0x3aa5>
		0000000000003aa1:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3aa5: 85 c0                        	testl	%eax, %eax
    3aa7: 79 09                        	jns	0x3ab2 <trusted_x86_x86_sim_xdp+0x3ab2>
    3aa9: 48 c7 44 24 68 00 00 00 00   	movq	$0x0, 0x68(%rsp)
    3ab2: 85 c0                        	testl	%eax, %eax
    3ab4: 75 30                        	jne	0x3ae6 <trusted_x86_x86_sim_xdp+0x3ae6>
    3ab6: 41 c1 e4 03                  	shll	$0x3, %r12d
    3aba: 41 83 e4 38                  	andl	$0x38, %r12d
    3abe: 4c 03 64 24 68               	addq	0x68(%rsp), %r12
    3ac3: 4c 89 e6                     	movq	%r12, %rsi
    3ac6: eb aa                        	jmp	0x3a72 <trusted_x86_x86_sim_xdp+0x3a72>
    3ac8: 44 89 e0                     	movl	%r12d, %eax
    3acb: 83 e0 0f                     	andl	$0xf, %eax
    3ace: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x3ad5 <trusted_x86_x86_sim_xdp+0x3ad5>
		0000000000003ad1:  R_X86_64_PC32	.rodata+0x1e4
    3ad5: 48 63 14 81                  	movslq	(%rcx,%rax,4), %rdx
    3ad9: 48 01 ca                     	addq	%rcx, %rdx
    3adc: 48 8d 84 24 90 00 00 00      	leaq	0x90(%rsp), %rax
    3ae4: ff e2                        	jmpq	*%rdx
    3ae6: 41 0f b6 07                  	movzbl	(%r15), %eax
    3aea: 3c 03                        	cmpb	$0x3, %al
    3aec: 75 0c                        	jne	0x3afa <trusted_x86_x86_sim_xdp+0x3afa>
    3aee: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    3af3: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    3afa: 48 83 7c 24 18 00            	cmpq	$0x0, 0x18(%rsp)
    3b00: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    3b05: 48 8b 4c 24 30               	movq	0x30(%rsp), %rcx
    3b0a: 48 8b 54 24 20               	movq	0x20(%rsp), %rdx
    3b0f: 0f 84 00 d7 ff ff            	je	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
    3b15: 48 89 54 24 20               	movq	%rdx, 0x20(%rsp)
    3b1a: 48 89 4c 24 30               	movq	%rcx, 0x30(%rsp)
    3b1f: 48 89 44 24 28               	movq	%rax, 0x28(%rsp)
    3b24: 4c 8b bc 24 a8 00 00 00      	movq	0xa8(%rsp), %r15
    3b2c: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    3b31: 48 8d 70 f8                  	leaq	-0x8(%rax), %rsi
    3b35: ba 08 00 00 00               	movl	$0x8, %edx
    3b3a: 4c 89 ff                     	movq	%r15, %rdi
    3b3d: e8 00 00 00 00               	callq	0x3b42 <trusted_x86_x86_sim_xdp+0x3b42>
		0000000000003b3e:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3b42: 85 c0                        	testl	%eax, %eax
    3b44: 79 07                        	jns	0x3b4d <trusted_x86_x86_sim_xdp+0x3b4d>
    3b46: 49 c7 07 00 00 00 00         	movq	$0x0, (%r15)
    3b4d: 85 c0                        	testl	%eax, %eax
    3b4f: 0f 85 c0 d6 ff ff            	jne	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
    3b55: 48 8b 84 24 88 01 00 00      	movq	0x188(%rsp), %rax
    3b5d: 48 8b 4c 24 18               	movq	0x18(%rsp), %rcx
    3b62: 48 89 08                     	movq	%rcx, (%rax)
    3b65: 48 8d 83 30 0f 00 00         	leaq	0xf30(%rbx), %rax
    3b6c: b1 01                        	movb	$0x1, %cl
    3b6e: 88 08                        	movb	%cl, (%rax)
    3b70: c7 44 24 68 06 00 00 00      	movl	$0x6, 0x68(%rsp)
    3b78: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x3b7f <trusted_x86_x86_sim_xdp+0x3b7f>
		0000000000003b7b:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3b7f: 83 78 44 07                  	cmpl	$0x7, 0x44(%rax)
    3b83: 72 30                        	jb	0x3bb5 <trusted_x86_x86_sim_xdp+0x3bb5>
    3b85: b8 06 00 00 00               	movl	$0x6, %eax
    3b8a: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3b91 <trusted_x86_x86_sim_xdp+0x3b91>
		0000000000003b8d:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3b91: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    3b97: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    3b9f: e8 00 00 00 00               	callq	0x3ba4 <trusted_x86_x86_sim_xdp+0x3ba4>
		0000000000003ba0:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3ba4: 48 85 c0                     	testq	%rax, %rax
    3ba7: 74 0c                        	je	0x3bb5 <trusted_x86_x86_sim_xdp+0x3bb5>
    3ba9: 48 89 c1                     	movq	%rax, %rcx
    3bac: 48 8b 09                     	movq	(%rcx), %rcx
    3baf: 48 ff c1                     	incq	%rcx
    3bb2: 48 89 08                     	movq	%rcx, (%rax)
    3bb5: 48 8b 84 24 a8 00 00 00      	movq	0xa8(%rsp), %rax
    3bbd: 48 8b 28                     	movq	(%rax), %rbp
    3bc0: 48 85 ed                     	testq	%rbp, %rbp
    3bc3: 0f 84 b4 13 00 00            	je	0x4f7d <trusted_x86_x86_sim_xdp+0x4f7d>
    3bc9: 48 3b 6c 24 10               	cmpq	0x10(%rsp), %rbp
    3bce: 0f 83 07 d7 ff ff            	jae	0x12db <trusted_x86_x86_sim_xdp+0x12db>
    3bd4: 48 81 fd 00 10 00 00         	cmpq	$0x1000, %rbp           # imm = 0x1000
    3bdb: 0f 82 22 d7 ff ff            	jb	0x1303 <trusted_x86_x86_sim_xdp+0x1303>
    3be1: 48 89 d8                     	movq	%rbx, %rax
    3be4: 8b 00                        	movl	(%rax), %eax
    3be6: c7 84 24 b8 00 00 00 60 00 00 00     	movl	$0x60, 0xb8(%rsp)
    3bf1: 0f 38 f1 84 24 bc 00 00 00   	movbel	%eax, 0xbc(%rsp)
    3bfa: 48 0f 38 f1 ac 24 c0 00 00 00	movbeq	%rbp, 0xc0(%rsp)
    3c04: 80 bc 24 a0 01 00 00 00      	cmpb	$0x0, 0x1a0(%rsp)
    3c0c: 74 48                        	je	0x3c56 <trusted_x86_x86_sim_xdp+0x3c56>
    3c0e: 8b 84 24 b8 00 00 00         	movl	0xb8(%rsp), %eax
    3c15: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3c1c <trusted_x86_x86_sim_xdp+0x3c1c>
		0000000000003c18:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3c1c: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    3c1f: 0f 83 10 14 00 00            	jae	0x5035 <trusted_x86_x86_sim_xdp+0x5035>
    3c25: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3c2c <trusted_x86_x86_sim_xdp+0x3c2c>
		0000000000003c28:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3c2c: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    3c32: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    3c3a: e8 00 00 00 00               	callq	0x3c3f <trusted_x86_x86_sim_xdp+0x3c3f>
		0000000000003c3b:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3c3f: eb 22                        	jmp	0x3c63 <trusted_x86_x86_sim_xdp+0x3c63>
    3c41: c1 e5 03                     	shll	$0x3, %ebp
    3c44: 83 e5 38                     	andl	$0x38, %ebp
    3c47: 48 03 6c 24 68               	addq	0x68(%rsp), %rbp
    3c4c: 48 89 6c 24 18               	movq	%rbp, 0x18(%rsp)
    3c51: e9 ba fd ff ff               	jmp	0x3a10 <trusted_x86_x86_sim_xdp+0x3a10>
    3c56: 48 8d bc 24 b8 00 00 00      	leaq	0xb8(%rsp), %rdi
    3c5e: e8 00 00 00 00               	callq	0x3c63 <trusted_x86_x86_sim_xdp+0x3c63>
		0000000000003c5f:  R_X86_64_PLT32	.text+0x7c
    3c63: 48 85 c0                     	testq	%rax, %rax
    3c66: 0f 84 c9 13 00 00            	je	0x5035 <trusted_x86_x86_sim_xdp+0x5035>
    3c6c: 48 89 c1                     	movq	%rax, %rcx
    3c6f: 4c 8b 61 08                  	movq	0x8(%rcx), %r12
    3c73: 4c 89 e1                     	movq	%r12, %rcx
    3c76: 48 ba ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    3c80: 48 21 d1                     	andq	%rdx, %rcx
    3c83: 48 8b 94 24 90 01 00 00      	movq	0x190(%rsp), %rdx
    3c8b: 48 89 0a                     	movq	%rcx, (%rdx)
    3c8e: 48 8b 00                     	movq	(%rax), %rax
    3c91: 48 8b 94 24 c8 01 00 00      	movq	0x1c8(%rsp), %rdx
    3c99: 48 89 02                     	movq	%rax, (%rdx)
    3c9c: 49 c1 ec 38                  	shrq	$0x38, %r12
    3ca0: 48 29 cd                     	subq	%rcx, %rbp
    3ca3: 48 8b 8c 24 b0 01 00 00      	movq	0x1b0(%rsp), %rcx
    3cab: 48 89 29                     	movq	%rbp, (%rcx)
    3cae: 49 83 fc 01                  	cmpq	$0x1, %r12
    3cb2: 0f 85 69 01 00 00            	jne	0x3e21 <trusted_x86_x86_sim_xdp+0x3e21>
    3cb8: 48 89 84 24 b8 00 00 00      	movq	%rax, 0xb8(%rsp)
    3cc0: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x3cc7 <trusted_x86_x86_sim_xdp+0x3cc7>
		0000000000003cc3:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    3cc7: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x3cce <trusted_x86_x86_sim_xdp+0x3cce>
		0000000000003cca:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3cce: 74 28                        	je	0x3cf8 <trusted_x86_x86_sim_xdp+0x3cf8>
    3cd0: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x3cd7 <trusted_x86_x86_sim_xdp+0x3cd7>
		0000000000003cd3:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
    3cd7: 74 1f                        	je	0x3cf8 <trusted_x86_x86_sim_xdp+0x3cf8>
    3cd9: 48 8d bc 24 b8 00 00 00      	leaq	0xb8(%rsp), %rdi
    3ce1: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x3ce8 <trusted_x86_x86_sim_xdp+0x3ce8>
		0000000000003ce4:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3ce8: 0f 85 a1 00 00 00            	jne	0x3d8f <trusted_x86_x86_sim_xdp+0x3d8f>
    3cee: e8 00 00 00 00               	callq	0x3cf3 <trusted_x86_x86_sim_xdp+0x3cf3>
		0000000000003cef:  R_X86_64_PLT32	.text+0x7c
    3cf3: e9 9c 00 00 00               	jmp	0x3d94 <trusted_x86_x86_sim_xdp+0x3d94>
    3cf8: 8b 8c 24 b8 00 00 00         	movl	0xb8(%rsp), %ecx
    3cff: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    3d02: 0f 83 25 01 00 00            	jae	0x3e2d <trusted_x86_x86_sim_xdp+0x3e2d>
    3d08: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    3d0e: 48 8b bc c8 30 01 00 00      	movq	0x130(%rax,%rcx,8), %rdi
    3d16: e8 00 00 00 00               	callq	0x3d1b <trusted_x86_x86_sim_xdp+0x3d1b>
		0000000000003d17:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3d1b: eb 77                        	jmp	0x3d94 <trusted_x86_x86_sim_xdp+0x3d94>
    3d1d: 48 8d 84 24 a0 00 00 00      	leaq	0xa0(%rsp), %rax
    3d25: eb 0f                        	jmp	0x3d36 <trusted_x86_x86_sim_xdp+0x3d36>
    3d27: 48 8d 84 24 98 00 00 00      	leaq	0x98(%rsp), %rax
    3d2f: eb 05                        	jmp	0x3d36 <trusted_x86_x86_sim_xdp+0x3d36>
    3d31: 48 8d 44 24 50               	leaq	0x50(%rsp), %rax
    3d36: 48 8b 00                     	movq	(%rax), %rax
    3d39: 89 e9                        	movl	%ebp, %ecx
    3d3b: 81 e1 00 00 00 80            	andl	$0x80000000, %ecx       # imm = 0x80000000
    3d41: c1 ed 04                     	shrl	$0x4, %ebp
    3d44: 8d 0c e9                     	leal	(%rcx,%rbp,8), %ecx
    3d47: 48 63 c9                     	movslq	%ecx, %rcx
    3d4a: 48 03 08                     	addq	(%rax), %rcx
    3d4d: 48 89 4c 24 18               	movq	%rcx, 0x18(%rsp)
    3d52: e9 b9 fc ff ff               	jmp	0x3a10 <trusted_x86_x86_sim_xdp+0x3a10>
    3d57: 48 8d 84 24 a0 00 00 00      	leaq	0xa0(%rsp), %rax
    3d5f: eb 0f                        	jmp	0x3d70 <trusted_x86_x86_sim_xdp+0x3d70>
    3d61: 48 8d 84 24 98 00 00 00      	leaq	0x98(%rsp), %rax
    3d69: eb 05                        	jmp	0x3d70 <trusted_x86_x86_sim_xdp+0x3d70>
    3d6b: 48 8d 44 24 50               	leaq	0x50(%rsp), %rax
    3d70: 48 8b 00                     	movq	(%rax), %rax
    3d73: 44 89 e1                     	movl	%r12d, %ecx
    3d76: 81 e1 00 00 00 80            	andl	$0x80000000, %ecx       # imm = 0x80000000
    3d7c: 41 c1 ec 04                  	shrl	$0x4, %r12d
    3d80: 42 8d 0c e1                  	leal	(%rcx,%r12,8), %ecx
    3d84: 48 63 f1                     	movslq	%ecx, %rsi
    3d87: 48 03 30                     	addq	(%rax), %rsi
    3d8a: e9 e3 fc ff ff               	jmp	0x3a72 <trusted_x86_x86_sim_xdp+0x3a72>
    3d8f: e8 00 00 00 00               	callq	0x3d94 <trusted_x86_x86_sim_xdp+0x3d94>
		0000000000003d90:  R_X86_64_PLT32	.text+0x12c
    3d94: 49 89 c7                     	movq	%rax, %r15
    3d97: 48 85 c0                     	testq	%rax, %rax
    3d9a: 0f 84 8d 00 00 00            	je	0x3e2d <trusted_x86_x86_sim_xdp+0x3e2d>
    3da0: 4c 89 f8                     	movq	%r15, %rax
    3da3: 48 8b 00                     	movq	(%rax), %rax
    3da6: 48 39 e8                     	cmpq	%rbp, %rax
    3da9: 77 0c                        	ja	0x3db7 <trusted_x86_x86_sim_xdp+0x3db7>
    3dab: 4c 89 f8                     	movq	%r15, %rax
    3dae: 48 8b 40 08                  	movq	0x8(%rax), %rax
    3db2: 48 39 e8                     	cmpq	%rbp, %rax
    3db5: 73 18                        	jae	0x3dcf <trusted_x86_x86_sim_xdp+0x3dcf>
    3db7: 4c 89 f8                     	movq	%r15, %rax
    3dba: 48 8b 40 10                  	movq	0x10(%rax), %rax
    3dbe: 48 39 e8                     	cmpq	%rbp, %rax
    3dc1: 77 6a                        	ja	0x3e2d <trusted_x86_x86_sim_xdp+0x3e2d>
    3dc3: 4c 89 f8                     	movq	%r15, %rax
    3dc6: 48 8b 40 18                  	movq	0x18(%rax), %rax
    3dca: 48 39 e8                     	cmpq	%rbp, %rax
    3dcd: 72 5e                        	jb	0x3e2d <trusted_x86_x86_sim_xdp+0x3e2d>
    3dcf: 48 89 d8                     	movq	%rbx, %rax
    3dd2: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
    3dd8: 4c 89 f9                     	movq	%r15, %rcx
    3ddb: 8b 49 20                     	movl	0x20(%rcx), %ecx
    3dde: 0f a3 c8                     	btl	%ecx, %eax
    3de1: 72 4a                        	jb	0x3e2d <trusted_x86_x86_sim_xdp+0x3e2d>
    3de3: c7 44 24 68 00 00 00 00      	movl	$0x0, 0x68(%rsp)
    3deb: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x3df2 <trusted_x86_x86_sim_xdp+0x3df2>
		0000000000003dee:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3df2: 83 78 44 00                  	cmpl	$0x0, 0x44(%rax)
    3df6: 74 24                        	je	0x3e1c <trusted_x86_x86_sim_xdp+0x3e1c>
    3df8: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x3dff <trusted_x86_x86_sim_xdp+0x3dff>
		0000000000003dfb:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3dff: 48 8b b8 30 01 00 00         	movq	0x130(%rax), %rdi
    3e06: e8 00 00 00 00               	callq	0x3e0b <trusted_x86_x86_sim_xdp+0x3e0b>
		0000000000003e07:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3e0b: 48 85 c0                     	testq	%rax, %rax
    3e0e: 74 0c                        	je	0x3e1c <trusted_x86_x86_sim_xdp+0x3e1c>
    3e10: 48 89 c1                     	movq	%rax, %rcx
    3e13: 48 8b 09                     	movq	(%rcx), %rcx
    3e16: 48 ff c1                     	incq	%rcx
    3e19: 48 89 08                     	movq	%rcx, (%rax)
    3e1c: 45 0f b7 67 20               	movzwl	0x20(%r15), %r12d
    3e21: 31 ed                        	xorl	%ebp, %ebp
    3e23: 41 83 fc 01                  	cmpl	$0x1, %r12d
    3e27: 0f 85 65 11 00 00            	jne	0x4f92 <trusted_x86_x86_sim_xdp+0x4f92>
    3e2d: c7 84 24 b8 00 00 00 05 00 00 00     	movl	$0x5, 0xb8(%rsp)
    3e38: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x3e3f <trusted_x86_x86_sim_xdp+0x3e3f>
		0000000000003e3b:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3e3f: 83 78 44 06                  	cmpl	$0x6, 0x44(%rax)
    3e43: 72 30                        	jb	0x3e75 <trusted_x86_x86_sim_xdp+0x3e75>
    3e45: b8 05 00 00 00               	movl	$0x5, %eax
    3e4a: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3e51 <trusted_x86_x86_sim_xdp+0x3e51>
		0000000000003e4d:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3e51: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    3e57: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    3e5f: e8 00 00 00 00               	callq	0x3e64 <trusted_x86_x86_sim_xdp+0x3e64>
		0000000000003e60:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3e64: 48 85 c0                     	testq	%rax, %rax
    3e67: 74 0c                        	je	0x3e75 <trusted_x86_x86_sim_xdp+0x3e75>
    3e69: 48 89 c1                     	movq	%rax, %rcx
    3e6c: 48 8b 09                     	movq	(%rcx), %rcx
    3e6f: 48 ff c1                     	incq	%rcx
    3e72: 48 89 08                     	movq	%rcx, (%rax)
    3e75: 48 89 d8                     	movq	%rbx, %rax
    3e78: 8b 88 c0 02 00 00            	movl	0x2c0(%rax), %ecx
    3e7e: 4c 8b bc 24 80 00 00 00      	movq	0x80(%rsp), %r15
    3e86: 83 f9 7e                     	cmpl	$0x7e, %ecx
    3e89: 4c 8b 25 00 00 00 00         	movq	(%rip), %r12            # 0x3e90 <trusted_x86_x86_sim_xdp+0x3e90>
		0000000000003e8c:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3e90: 0f 87 4e c2 ff ff            	ja	0xe4 <trusted_x86_x86_sim_xdp+0xe4>
    3e96: 48 89 d8                     	movq	%rbx, %rax
    3e99: 0f b6 80 30 0f 00 00         	movzbl	0xf30(%rax), %eax
    3ea0: 48 89 da                     	movq	%rbx, %rdx
    3ea3: 48 8b 92 10 0f 00 00         	movq	0xf10(%rdx), %rdx
    3eaa: 48 89 de                     	movq	%rbx, %rsi
    3ead: 48 8b b6 18 0f 00 00         	movq	0xf18(%rsi), %rsi
    3eb4: 8d 79 01                     	leal	0x1(%rcx), %edi
    3eb7: 4c 8b 84 24 c0 01 00 00      	movq	0x1c0(%rsp), %r8
    3ebf: 41 89 38                     	movl	%edi, (%r8)
    3ec2: c1 e1 03                     	shll	$0x3, %ecx
    3ec5: 8d 0c 49                     	leal	(%rcx,%rcx,2), %ecx
    3ec8: 48 8b bc 24 e0 01 00 00      	movq	0x1e0(%rsp), %rdi
    3ed0: 48 01 cf                     	addq	%rcx, %rdi
    3ed3: 48 89 17                     	movq	%rdx, (%rdi)
    3ed6: 48 8b 94 24 e8 01 00 00      	movq	0x1e8(%rsp), %rdx
    3ede: 48 01 ca                     	addq	%rcx, %rdx
    3ee1: 48 89 32                     	movq	%rsi, (%rdx)
    3ee4: 48 8b 94 24 f0 01 00 00      	movq	0x1f0(%rsp), %rdx
    3eec: 48 01 ca                     	addq	%rcx, %rdx
    3eef: c6 02 03                     	movb	$0x3, (%rdx)
    3ef2: 48 8b 94 24 f8 01 00 00      	movq	0x1f8(%rsp), %rdx
    3efa: 48 01 ca                     	addq	%rcx, %rdx
    3efd: 88 02                        	movb	%al, (%rdx)
    3eff: 48 8b 84 24 00 02 00 00      	movq	0x200(%rsp), %rax
    3f07: 48 01 c8                     	addq	%rcx, %rax
    3f0a: c7 00 00 00 00 00            	movl	$0x0, (%rax)
    3f10: 48 8b 84 24 d8 01 00 00      	movq	0x1d8(%rsp), %rax
    3f18: 48 01 c8                     	addq	%rcx, %rax
    3f1b: 66 c7 00 00 00               	movw	$0x0, (%rax)
    3f20: c7 44 24 60 00 00 00 00      	movl	$0x0, 0x60(%rsp)
    3f28: 48 89 d8                     	movq	%rbx, %rax
    3f2b: 48 8b 80 10 0f 00 00         	movq	0xf10(%rax), %rax
    3f32: 48 89 84 24 b0 00 00 00      	movq	%rax, 0xb0(%rsp)
    3f3a: 48 89 44 24 68               	movq	%rax, 0x68(%rsp)
    3f3f: 48 89 d8                     	movq	%rbx, %rax
    3f42: 48 c7 c1 00 00 ff ff         	movq	$-0x10000, %rcx         # imm = 0xFFFF0000
    3f49: 48 23 88 18 0f 00 00         	andq	0xf18(%rax), %rcx
    3f50: 48 89 4c 24 70               	movq	%rcx, 0x70(%rsp)
    3f55: 45 84 f6                     	testb	%r14b, %r14b
    3f58: 74 30                        	je	0x3f8a <trusted_x86_x86_sim_xdp+0x3f8a>
    3f5a: 8b 44 24 68                  	movl	0x68(%rsp), %eax
    3f5e: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3f65 <trusted_x86_x86_sim_xdp+0x3f65>
		0000000000003f61:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    3f65: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    3f68: 0f 83 45 ec ff ff            	jae	0x2bb3 <trusted_x86_x86_sim_xdp+0x2bb3>
    3f6e: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3f75 <trusted_x86_x86_sim_xdp+0x3f75>
		0000000000003f71:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    3f75: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    3f7b: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    3f83: e8 00 00 00 00               	callq	0x3f88 <trusted_x86_x86_sim_xdp+0x3f88>
		0000000000003f84:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3f88: eb 3d                        	jmp	0x3fc7 <trusted_x86_x86_sim_xdp+0x3fc7>
    3f8a: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x3f91 <trusted_x86_x86_sim_xdp+0x3f91>
		0000000000003f8d:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    3f91: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x3f98 <trusted_x86_x86_sim_xdp+0x3f98>
		0000000000003f94:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3f98: 75 0c                        	jne	0x3fa6 <trusted_x86_x86_sim_xdp+0x3fa6>
    3f9a: 48 8d 7c 24 68               	leaq	0x68(%rsp), %rdi
    3f9f: e8 00 00 00 00               	callq	0x3fa4 <trusted_x86_x86_sim_xdp+0x3fa4>
		0000000000003fa0:  R_X86_64_PLT32	.text+0x7c
    3fa4: eb 21                        	jmp	0x3fc7 <trusted_x86_x86_sim_xdp+0x3fc7>
    3fa6: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x3fad <trusted_x86_x86_sim_xdp+0x3fad>
		0000000000003fa9:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    3fad: 48 8d 7c 24 68               	leaq	0x68(%rsp), %rdi
    3fb2: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x3fb9 <trusted_x86_x86_sim_xdp+0x3fb9>
		0000000000003fb5:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    3fb9: 75 07                        	jne	0x3fc2 <trusted_x86_x86_sim_xdp+0x3fc2>
    3fbb: e8 00 00 00 00               	callq	0x3fc0 <trusted_x86_x86_sim_xdp+0x3fc0>
		0000000000003fbc:  R_X86_64_PLT32	.text+0x12c
    3fc0: eb 05                        	jmp	0x3fc7 <trusted_x86_x86_sim_xdp+0x3fc7>
    3fc2: e8 00 00 00 00               	callq	0x3fc7 <trusted_x86_x86_sim_xdp+0x3fc7>
		0000000000003fc3:  R_X86_64_PLT32	.text+0x1dc
    3fc7: 49 89 c6                     	movq	%rax, %r14
    3fca: 48 85 c0                     	testq	%rax, %rax
    3fcd: 0f 84 e0 eb ff ff            	je	0x2bb3 <trusted_x86_x86_sim_xdp+0x2bb3>
    3fd3: 4c 89 f0                     	movq	%r14, %rax
    3fd6: 0f b7 40 06                  	movzwl	0x6(%rax), %eax
    3fda: 0f b7 c0                     	movzwl	%ax, %eax
    3fdd: 83 c0 f8                     	addl	$-0x8, %eax
    3fe0: b9 a1 0f 00 00               	movl	$0xfa1, %ecx            # imm = 0xFA1
    3fe5: ba 33 00 00 00               	movl	$0x33, %edx
    3fea: a9 f0 ff 00 00               	testl	$0xfff0, %eax           # imm = 0xFFF0
    3fef: 0f 85 e5 eb ff ff            	jne	0x2bda <trusted_x86_x86_sim_xdp+0x2bda>
    3ff5: 83 e0 0f                     	andl	$0xf, %eax
    3ff8: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x3fff <trusted_x86_x86_sim_xdp+0x3fff>
		0000000000003ffb:  R_X86_64_PC32	.data.rel.ro-0x4
    3fff: 48 8b 3c c1                  	movq	(%rcx,%rax,8), %rdi
    4003: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    4007: 75 30                        	jne	0x4039 <trusted_x86_x86_sim_xdp+0x4039>
    4009: 8b 84 24 b0 00 00 00         	movl	0xb0(%rsp), %eax
    4010: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    4013: 0f 83 ae 00 00 00            	jae	0x40c7 <trusted_x86_x86_sim_xdp+0x40c7>
    4019: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    401f: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    4025: 48 0f af c1                  	imulq	%rcx, %rax
    4029: 48 01 f8                     	addq	%rdi, %rax
    402c: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    4032: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    4037: eb 1d                        	jmp	0x4056 <trusted_x86_x86_sim_xdp+0x4056>
    4039: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    403d: 48 8d b4 24 b0 00 00 00      	leaq	0xb0(%rsp), %rsi
    4045: ff 50 60                     	callq	*0x60(%rax)
    4048: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    404d: 48 85 c0                     	testq	%rax, %rax
    4050: 0f 84 7a eb ff ff            	je	0x2bd0 <trusted_x86_x86_sim_xdp+0x2bd0>
    4056: 4c 89 f1                     	movq	%r14, %rcx
    4059: 4c 89 f0                     	movq	%r14, %rax
    405c: 44 8b 20                     	movl	(%rax), %r12d
    405f: 44 89 64 24 64               	movl	%r12d, 0x64(%rsp)
    4064: 48 89 d8                     	movq	%rbx, %rax
    4067: 48 8b 80 18 0f 00 00         	movq	0xf18(%rax), %rax
    406e: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    4073: 4c 89 f0                     	movq	%r14, %rax
    4076: 44 0f b7 78 04               	movzwl	0x4(%rax), %r15d
    407b: 45 85 ff                     	testl	%r15d, %r15d
    407e: 0f 84 93 07 00 00            	je	0x4817 <trusted_x86_x86_sim_xdp+0x4817>
    4084: 45 01 e7                     	addl	%r12d, %r15d
    4087: 43 8d 04 27                  	leal	(%r15,%r12), %eax
    408b: d1 e8                        	shrl	%eax
    408d: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    4091: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    4096: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    409a: 75 39                        	jne	0x40d5 <trusted_x86_x86_sim_xdp+0x40d5>
    409c: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    40a1: 8b 00                        	movl	(%rax), %eax
    40a3: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    40a6: 0f 83 a6 07 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    40ac: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    40b2: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    40b8: 48 0f af c1                  	imulq	%rcx, %rax
    40bc: 48 01 f8                     	addq	%rdi, %rax
    40bf: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    40c5: eb 23                        	jmp	0x40ea <trusted_x86_x86_sim_xdp+0x40ea>
    40c7: 48 c7 44 24 48 00 00 00 00   	movq	$0x0, 0x48(%rsp)
    40d0: e9 fb ea ff ff               	jmp	0x2bd0 <trusted_x86_x86_sim_xdp+0x2bd0>
    40d5: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    40d9: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    40de: ff 50 60                     	callq	*0x60(%rax)
    40e1: 48 85 c0                     	testq	%rax, %rax
    40e4: 0f 84 68 07 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    40ea: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    40ee: 8d 69 01                     	leal	0x1(%rcx), %ebp
    40f1: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    40f6: 0f b7 00                     	movzwl	(%rax), %eax
    40f9: 48 39 c2                     	cmpq	%rax, %rdx
    40fc: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    4100: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    4104: 44 39 fd                     	cmpl	%r15d, %ebp
    4107: 0f 83 02 07 00 00            	jae	0x480f <trusted_x86_x86_sim_xdp+0x480f>
    410d: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
    4111: d1 e8                        	shrl	%eax
    4113: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    4117: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    411c: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    4120: 75 2b                        	jne	0x414d <trusted_x86_x86_sim_xdp+0x414d>
    4122: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    4127: 8b 00                        	movl	(%rax), %eax
    4129: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    412c: 0f 83 20 07 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4132: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    4138: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    413e: 48 0f af c1                  	imulq	%rcx, %rax
    4142: 48 01 f8                     	addq	%rdi, %rax
    4145: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    414b: eb 15                        	jmp	0x4162 <trusted_x86_x86_sim_xdp+0x4162>
    414d: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    4151: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    4156: ff 50 60                     	callq	*0x60(%rax)
    4159: 48 85 c0                     	testq	%rax, %rax
    415c: 0f 84 f0 06 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4162: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    4166: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    416a: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    416f: 0f b7 00                     	movzwl	(%rax), %eax
    4172: 48 39 c2                     	cmpq	%rax, %rdx
    4175: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    4179: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    417d: 45 39 fc                     	cmpl	%r15d, %r12d
    4180: 0f 83 89 06 00 00            	jae	0x480f <trusted_x86_x86_sim_xdp+0x480f>
    4186: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
    418a: d1 e8                        	shrl	%eax
    418c: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    4190: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    4195: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    4199: 75 2b                        	jne	0x41c6 <trusted_x86_x86_sim_xdp+0x41c6>
    419b: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    41a0: 8b 00                        	movl	(%rax), %eax
    41a2: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    41a5: 0f 83 a7 06 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    41ab: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    41b1: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    41b7: 48 0f af c1                  	imulq	%rcx, %rax
    41bb: 48 01 f8                     	addq	%rdi, %rax
    41be: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    41c4: eb 15                        	jmp	0x41db <trusted_x86_x86_sim_xdp+0x41db>
    41c6: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    41ca: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    41cf: ff 50 60                     	callq	*0x60(%rax)
    41d2: 48 85 c0                     	testq	%rax, %rax
    41d5: 0f 84 77 06 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    41db: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    41df: 8d 69 01                     	leal	0x1(%rcx), %ebp
    41e2: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    41e7: 0f b7 00                     	movzwl	(%rax), %eax
    41ea: 48 39 c2                     	cmpq	%rax, %rdx
    41ed: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    41f1: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    41f5: 44 39 fd                     	cmpl	%r15d, %ebp
    41f8: 0f 83 11 06 00 00            	jae	0x480f <trusted_x86_x86_sim_xdp+0x480f>
    41fe: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
    4202: d1 e8                        	shrl	%eax
    4204: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    4208: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    420d: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    4211: 75 2b                        	jne	0x423e <trusted_x86_x86_sim_xdp+0x423e>
    4213: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    4218: 8b 00                        	movl	(%rax), %eax
    421a: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    421d: 0f 83 2f 06 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4223: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    4229: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    422f: 48 0f af c1                  	imulq	%rcx, %rax
    4233: 48 01 f8                     	addq	%rdi, %rax
    4236: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    423c: eb 15                        	jmp	0x4253 <trusted_x86_x86_sim_xdp+0x4253>
    423e: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    4242: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    4247: ff 50 60                     	callq	*0x60(%rax)
    424a: 48 85 c0                     	testq	%rax, %rax
    424d: 0f 84 ff 05 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4253: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    4257: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    425b: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    4260: 0f b7 00                     	movzwl	(%rax), %eax
    4263: 48 39 c2                     	cmpq	%rax, %rdx
    4266: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    426a: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    426e: 45 39 fc                     	cmpl	%r15d, %r12d
    4271: 0f 83 98 05 00 00            	jae	0x480f <trusted_x86_x86_sim_xdp+0x480f>
    4277: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
    427b: d1 e8                        	shrl	%eax
    427d: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    4281: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    4286: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    428a: 75 2b                        	jne	0x42b7 <trusted_x86_x86_sim_xdp+0x42b7>
    428c: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    4291: 8b 00                        	movl	(%rax), %eax
    4293: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    4296: 0f 83 b6 05 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    429c: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    42a2: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    42a8: 48 0f af c1                  	imulq	%rcx, %rax
    42ac: 48 01 f8                     	addq	%rdi, %rax
    42af: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    42b5: eb 15                        	jmp	0x42cc <trusted_x86_x86_sim_xdp+0x42cc>
    42b7: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    42bb: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    42c0: ff 50 60                     	callq	*0x60(%rax)
    42c3: 48 85 c0                     	testq	%rax, %rax
    42c6: 0f 84 86 05 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    42cc: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    42d0: 8d 69 01                     	leal	0x1(%rcx), %ebp
    42d3: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    42d8: 0f b7 00                     	movzwl	(%rax), %eax
    42db: 48 39 c2                     	cmpq	%rax, %rdx
    42de: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    42e2: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    42e6: 44 39 fd                     	cmpl	%r15d, %ebp
    42e9: 0f 83 20 05 00 00            	jae	0x480f <trusted_x86_x86_sim_xdp+0x480f>
    42ef: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
    42f3: d1 e8                        	shrl	%eax
    42f5: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    42f9: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    42fe: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    4302: 75 2b                        	jne	0x432f <trusted_x86_x86_sim_xdp+0x432f>
    4304: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    4309: 8b 00                        	movl	(%rax), %eax
    430b: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    430e: 0f 83 3e 05 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4314: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    431a: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    4320: 48 0f af c1                  	imulq	%rcx, %rax
    4324: 48 01 f8                     	addq	%rdi, %rax
    4327: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    432d: eb 15                        	jmp	0x4344 <trusted_x86_x86_sim_xdp+0x4344>
    432f: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    4333: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    4338: ff 50 60                     	callq	*0x60(%rax)
    433b: 48 85 c0                     	testq	%rax, %rax
    433e: 0f 84 0e 05 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4344: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    4348: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    434c: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    4351: 0f b7 00                     	movzwl	(%rax), %eax
    4354: 48 39 c2                     	cmpq	%rax, %rdx
    4357: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    435b: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    435f: 45 39 fc                     	cmpl	%r15d, %r12d
    4362: 0f 83 a7 04 00 00            	jae	0x480f <trusted_x86_x86_sim_xdp+0x480f>
    4368: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
    436c: d1 e8                        	shrl	%eax
    436e: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    4372: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    4377: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    437b: 75 2b                        	jne	0x43a8 <trusted_x86_x86_sim_xdp+0x43a8>
    437d: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    4382: 8b 00                        	movl	(%rax), %eax
    4384: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    4387: 0f 83 c5 04 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    438d: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    4393: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    4399: 48 0f af c1                  	imulq	%rcx, %rax
    439d: 48 01 f8                     	addq	%rdi, %rax
    43a0: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    43a6: eb 15                        	jmp	0x43bd <trusted_x86_x86_sim_xdp+0x43bd>
    43a8: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    43ac: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    43b1: ff 50 60                     	callq	*0x60(%rax)
    43b4: 48 85 c0                     	testq	%rax, %rax
    43b7: 0f 84 95 04 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    43bd: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    43c1: 8d 69 01                     	leal	0x1(%rcx), %ebp
    43c4: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    43c9: 0f b7 00                     	movzwl	(%rax), %eax
    43cc: 48 39 c2                     	cmpq	%rax, %rdx
    43cf: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    43d3: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    43d7: 44 39 fd                     	cmpl	%r15d, %ebp
    43da: 0f 83 2f 04 00 00            	jae	0x480f <trusted_x86_x86_sim_xdp+0x480f>
    43e0: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
    43e4: d1 e8                        	shrl	%eax
    43e6: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    43ea: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    43ef: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    43f3: 75 2b                        	jne	0x4420 <trusted_x86_x86_sim_xdp+0x4420>
    43f5: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    43fa: 8b 00                        	movl	(%rax), %eax
    43fc: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    43ff: 0f 83 4d 04 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4405: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    440b: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    4411: 48 0f af c1                  	imulq	%rcx, %rax
    4415: 48 01 f8                     	addq	%rdi, %rax
    4418: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    441e: eb 15                        	jmp	0x4435 <trusted_x86_x86_sim_xdp+0x4435>
    4420: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    4424: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    4429: ff 50 60                     	callq	*0x60(%rax)
    442c: 48 85 c0                     	testq	%rax, %rax
    442f: 0f 84 1d 04 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4435: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    4439: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    443d: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    4442: 0f b7 00                     	movzwl	(%rax), %eax
    4445: 48 39 c2                     	cmpq	%rax, %rdx
    4448: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    444c: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    4450: 45 39 fc                     	cmpl	%r15d, %r12d
    4453: 0f 83 b6 03 00 00            	jae	0x480f <trusted_x86_x86_sim_xdp+0x480f>
    4459: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
    445d: d1 e8                        	shrl	%eax
    445f: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    4463: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    4468: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    446c: 75 2b                        	jne	0x4499 <trusted_x86_x86_sim_xdp+0x4499>
    446e: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    4473: 8b 00                        	movl	(%rax), %eax
    4475: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    4478: 0f 83 d4 03 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    447e: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    4484: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    448a: 48 0f af c1                  	imulq	%rcx, %rax
    448e: 48 01 f8                     	addq	%rdi, %rax
    4491: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    4497: eb 15                        	jmp	0x44ae <trusted_x86_x86_sim_xdp+0x44ae>
    4499: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    449d: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    44a2: ff 50 60                     	callq	*0x60(%rax)
    44a5: 48 85 c0                     	testq	%rax, %rax
    44a8: 0f 84 a4 03 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    44ae: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    44b2: 8d 69 01                     	leal	0x1(%rcx), %ebp
    44b5: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    44ba: 0f b7 00                     	movzwl	(%rax), %eax
    44bd: 48 39 c2                     	cmpq	%rax, %rdx
    44c0: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    44c4: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    44c8: 44 39 fd                     	cmpl	%r15d, %ebp
    44cb: 0f 83 3e 03 00 00            	jae	0x480f <trusted_x86_x86_sim_xdp+0x480f>
    44d1: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
    44d5: d1 e8                        	shrl	%eax
    44d7: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    44db: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    44e0: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    44e4: 75 2b                        	jne	0x4511 <trusted_x86_x86_sim_xdp+0x4511>
    44e6: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    44eb: 8b 00                        	movl	(%rax), %eax
    44ed: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    44f0: 0f 83 5c 03 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    44f6: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    44fc: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    4502: 48 0f af c1                  	imulq	%rcx, %rax
    4506: 48 01 f8                     	addq	%rdi, %rax
    4509: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    450f: eb 15                        	jmp	0x4526 <trusted_x86_x86_sim_xdp+0x4526>
    4511: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    4515: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    451a: ff 50 60                     	callq	*0x60(%rax)
    451d: 48 85 c0                     	testq	%rax, %rax
    4520: 0f 84 2c 03 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4526: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    452a: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    452e: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    4533: 0f b7 00                     	movzwl	(%rax), %eax
    4536: 48 39 c2                     	cmpq	%rax, %rdx
    4539: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    453d: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    4541: 45 39 fc                     	cmpl	%r15d, %r12d
    4544: 0f 83 c5 02 00 00            	jae	0x480f <trusted_x86_x86_sim_xdp+0x480f>
    454a: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
    454e: d1 e8                        	shrl	%eax
    4550: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    4554: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    4559: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    455d: 75 2b                        	jne	0x458a <trusted_x86_x86_sim_xdp+0x458a>
    455f: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    4564: 8b 00                        	movl	(%rax), %eax
    4566: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    4569: 0f 83 e3 02 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    456f: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    4575: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    457b: 48 0f af c1                  	imulq	%rcx, %rax
    457f: 48 01 f8                     	addq	%rdi, %rax
    4582: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    4588: eb 15                        	jmp	0x459f <trusted_x86_x86_sim_xdp+0x459f>
    458a: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    458e: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    4593: ff 50 60                     	callq	*0x60(%rax)
    4596: 48 85 c0                     	testq	%rax, %rax
    4599: 0f 84 b3 02 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    459f: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    45a3: 8d 69 01                     	leal	0x1(%rcx), %ebp
    45a6: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    45ab: 0f b7 00                     	movzwl	(%rax), %eax
    45ae: 48 39 c2                     	cmpq	%rax, %rdx
    45b1: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    45b5: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    45b9: 44 39 fd                     	cmpl	%r15d, %ebp
    45bc: 0f 83 4d 02 00 00            	jae	0x480f <trusted_x86_x86_sim_xdp+0x480f>
    45c2: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
    45c6: d1 e8                        	shrl	%eax
    45c8: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    45cc: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    45d1: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    45d5: 75 2b                        	jne	0x4602 <trusted_x86_x86_sim_xdp+0x4602>
    45d7: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    45dc: 8b 00                        	movl	(%rax), %eax
    45de: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    45e1: 0f 83 6b 02 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    45e7: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    45ed: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    45f3: 48 0f af c1                  	imulq	%rcx, %rax
    45f7: 48 01 f8                     	addq	%rdi, %rax
    45fa: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    4600: eb 15                        	jmp	0x4617 <trusted_x86_x86_sim_xdp+0x4617>
    4602: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    4606: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    460b: ff 50 60                     	callq	*0x60(%rax)
    460e: 48 85 c0                     	testq	%rax, %rax
    4611: 0f 84 3b 02 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4617: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    461b: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    461f: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    4624: 0f b7 00                     	movzwl	(%rax), %eax
    4627: 48 39 c2                     	cmpq	%rax, %rdx
    462a: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    462e: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    4632: 45 39 fc                     	cmpl	%r15d, %r12d
    4635: 0f 83 d4 01 00 00            	jae	0x480f <trusted_x86_x86_sim_xdp+0x480f>
    463b: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
    463f: d1 e8                        	shrl	%eax
    4641: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    4645: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    464a: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    464e: 75 2b                        	jne	0x467b <trusted_x86_x86_sim_xdp+0x467b>
    4650: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    4655: 8b 00                        	movl	(%rax), %eax
    4657: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    465a: 0f 83 f2 01 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4660: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    4666: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    466c: 48 0f af c1                  	imulq	%rcx, %rax
    4670: 48 01 f8                     	addq	%rdi, %rax
    4673: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    4679: eb 15                        	jmp	0x4690 <trusted_x86_x86_sim_xdp+0x4690>
    467b: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    467f: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    4684: ff 50 60                     	callq	*0x60(%rax)
    4687: 48 85 c0                     	testq	%rax, %rax
    468a: 0f 84 c2 01 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4690: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    4694: 8d 69 01                     	leal	0x1(%rcx), %ebp
    4697: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    469c: 0f b7 00                     	movzwl	(%rax), %eax
    469f: 48 39 c2                     	cmpq	%rax, %rdx
    46a2: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    46a6: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    46aa: 44 39 fd                     	cmpl	%r15d, %ebp
    46ad: 0f 83 5c 01 00 00            	jae	0x480f <trusted_x86_x86_sim_xdp+0x480f>
    46b3: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
    46b7: d1 e8                        	shrl	%eax
    46b9: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    46bd: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    46c2: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    46c6: 75 2b                        	jne	0x46f3 <trusted_x86_x86_sim_xdp+0x46f3>
    46c8: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    46cd: 8b 00                        	movl	(%rax), %eax
    46cf: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    46d2: 0f 83 7a 01 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    46d8: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    46de: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    46e4: 48 0f af c1                  	imulq	%rcx, %rax
    46e8: 48 01 f8                     	addq	%rdi, %rax
    46eb: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    46f1: eb 15                        	jmp	0x4708 <trusted_x86_x86_sim_xdp+0x4708>
    46f3: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    46f7: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    46fc: ff 50 60                     	callq	*0x60(%rax)
    46ff: 48 85 c0                     	testq	%rax, %rax
    4702: 0f 84 4a 01 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4708: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    470c: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    4710: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    4715: 0f b7 00                     	movzwl	(%rax), %eax
    4718: 48 39 c2                     	cmpq	%rax, %rdx
    471b: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    471f: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    4723: 45 39 fc                     	cmpl	%r15d, %r12d
    4726: 0f 83 e3 00 00 00            	jae	0x480f <trusted_x86_x86_sim_xdp+0x480f>
    472c: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
    4730: d1 e8                        	shrl	%eax
    4732: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    4736: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    473b: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    473f: 75 2b                        	jne	0x476c <trusted_x86_x86_sim_xdp+0x476c>
    4741: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    4746: 8b 00                        	movl	(%rax), %eax
    4748: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    474b: 0f 83 01 01 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4751: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    4757: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    475d: 48 0f af c1                  	imulq	%rcx, %rax
    4761: 48 01 f8                     	addq	%rdi, %rax
    4764: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    476a: eb 15                        	jmp	0x4781 <trusted_x86_x86_sim_xdp+0x4781>
    476c: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    4770: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    4775: ff 50 60                     	callq	*0x60(%rax)
    4778: 48 85 c0                     	testq	%rax, %rax
    477b: 0f 84 d1 00 00 00            	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4781: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    4785: 8d 69 01                     	leal	0x1(%rcx), %ebp
    4788: 0f b7 54 24 40               	movzwl	0x40(%rsp), %edx
    478d: 0f b7 00                     	movzwl	(%rax), %eax
    4790: 48 39 c2                     	cmpq	%rax, %rdx
    4793: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    4797: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    479b: 44 39 fd                     	cmpl	%r15d, %ebp
    479e: 73 6f                        	jae	0x480f <trusted_x86_x86_sim_xdp+0x480f>
    47a0: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
    47a4: d1 e8                        	shrl	%eax
    47a6: 89 44 24 3c                  	movl	%eax, 0x3c(%rsp)
    47aa: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    47af: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    47b3: 75 2b                        	jne	0x47e0 <trusted_x86_x86_sim_xdp+0x47e0>
    47b5: 48 8d 44 24 3c               	leaq	0x3c(%rsp), %rax
    47ba: 8b 00                        	movl	(%rax), %eax
    47bc: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    47bf: 0f 83 8d 00 00 00            	jae	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    47c5: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    47cb: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    47d1: 48 0f af c1                  	imulq	%rcx, %rax
    47d5: 48 01 f8                     	addq	%rdi, %rax
    47d8: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    47de: eb 11                        	jmp	0x47f1 <trusted_x86_x86_sim_xdp+0x47f1>
    47e0: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    47e4: 48 8d 74 24 3c               	leaq	0x3c(%rsp), %rsi
    47e9: ff 50 60                     	callq	*0x60(%rax)
    47ec: 48 85 c0                     	testq	%rax, %rax
    47ef: 74 61                        	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    47f1: 8b 4c 24 3c                  	movl	0x3c(%rsp), %ecx
    47f5: 8d 51 01                     	leal	0x1(%rcx), %edx
    47f8: 0f b7 74 24 40               	movzwl	0x40(%rsp), %esi
    47fd: 0f b7 00                     	movzwl	(%rax), %eax
    4800: 48 39 c6                     	cmpq	%rax, %rsi
    4803: 0f 42 d5                     	cmovbl	%ebp, %edx
    4806: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
    480a: 44 39 fa                     	cmpl	%r15d, %edx
    480d: 72 43                        	jb	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    480f: 45 85 ff                     	testl	%r15d, %r15d
    4812: 74 3e                        	je	0x4852 <trusted_x86_x86_sim_xdp+0x4852>
    4814: 45 89 fc                     	movl	%r15d, %r12d
    4817: 41 ff cc                     	decl	%r12d
    481a: 44 89 64 24 64               	movl	%r12d, 0x64(%rsp)
    481f: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
    4824: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
    4828: 75 3d                        	jne	0x4867 <trusted_x86_x86_sim_xdp+0x4867>
    482a: 8b 44 24 64                  	movl	0x64(%rsp), %eax
    482e: 3b 47 44                     	cmpl	0x44(%rdi), %eax
    4831: 0f 83 0b 01 00 00            	jae	0x4942 <trusted_x86_x86_sim_xdp+0x4942>
    4837: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
    483d: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
    4843: 48 0f af c1                  	imulq	%rcx, %rax
    4847: 48 01 f8                     	addq	%rdi, %rax
    484a: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
    4850: eb 2a                        	jmp	0x487c <trusted_x86_x86_sim_xdp+0x487c>
    4852: c7 44 24 08 a3 0f 00 00      	movl	$0xfa3, 0x8(%rsp)       # imm = 0xFA3
    485a: c7 44 24 04 09 00 00 00      	movl	$0x9, 0x4(%rsp)
    4862: e9 eb 00 00 00               	jmp	0x4952 <trusted_x86_x86_sim_xdp+0x4952>
    4867: 48 8b 47 20                  	movq	0x20(%rdi), %rax
    486b: 48 8d 74 24 64               	leaq	0x64(%rsp), %rsi
    4870: ff 50 60                     	callq	*0x60(%rax)
    4873: 48 85 c0                     	testq	%rax, %rax
    4876: 0f 84 c6 00 00 00            	je	0x4942 <trusted_x86_x86_sim_xdp+0x4942>
    487c: 0f b7 4c 24 40               	movzwl	0x40(%rsp), %ecx
    4881: 48 89 c2                     	movq	%rax, %rdx
    4884: 0f b7 12                     	movzwl	(%rdx), %edx
    4887: 29 d1                        	subl	%edx, %ecx
    4889: 8b 54 24 64                  	movl	0x64(%rsp), %edx
    488d: 44 8d a1 00 00 01 00         	leal	0x10000(%rcx), %r12d
    4894: 41 8b 36                     	movl	(%r14), %esi
    4897: 39 d6                        	cmpl	%edx, %esi
    4899: 44 0f 46 e1                  	cmovbel	%ecx, %r12d
    489d: 0f b7 40 02                  	movzwl	0x2(%rax), %eax
    48a1: 89 44 24 60                  	movl	%eax, 0x60(%rsp)
    48a5: 3d 00 80 00 00               	cmpl	$0x8000, %eax           # imm = 0x8000
    48aa: 0f 84 a2 00 00 00            	je	0x4952 <trusted_x86_x86_sim_xdp+0x4952>
    48b0: 3d 01 80 00 00               	cmpl	$0x8001, %eax           # imm = 0x8001
    48b5: 75 49                        	jne	0x4900 <trusted_x86_x86_sim_xdp+0x4900>
    48b7: c7 44 24 3c 07 00 00 00      	movl	$0x7, 0x3c(%rsp)
    48bf: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x48c6 <trusted_x86_x86_sim_xdp+0x48c6>
		00000000000048c2:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    48c6: 83 78 44 08                  	cmpl	$0x8, 0x44(%rax)
    48ca: 72 30                        	jb	0x48fc <trusted_x86_x86_sim_xdp+0x48fc>
    48cc: b8 07 00 00 00               	movl	$0x7, %eax
    48d1: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x48d8 <trusted_x86_x86_sim_xdp+0x48d8>
		00000000000048d4:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    48d8: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    48de: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    48e6: e8 00 00 00 00               	callq	0x48eb <trusted_x86_x86_sim_xdp+0x48eb>
		00000000000048e7:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    48eb: 48 85 c0                     	testq	%rax, %rax
    48ee: 74 0c                        	je	0x48fc <trusted_x86_x86_sim_xdp+0x48fc>
    48f0: 48 89 c1                     	movq	%rax, %rcx
    48f3: 48 8b 09                     	movq	(%rcx), %rcx
    48f6: 48 ff c1                     	incq	%rcx
    48f9: 48 89 08                     	movq	%rcx, (%rax)
    48fc: 8b 44 24 60                  	movl	0x60(%rsp), %eax
    4900: 66 85 c0                     	testw	%ax, %ax
    4903: 78 70                        	js	0x4975 <trusted_x86_x86_sim_xdp+0x4975>
    4905: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x490c <trusted_x86_x86_sim_xdp+0x490c>
		0000000000004908:  R_X86_64_REX_GOTPCRELX	unwind_info_array-0x4
    490c: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x4913 <trusted_x86_x86_sim_xdp+0x4913>
		000000000000490f:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    4913: 0f 84 ba 00 00 00            	je	0x49d3 <trusted_x86_x86_sim_xdp+0x49d3>
    4919: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x4920 <trusted_x86_x86_sim_xdp+0x4920>
		000000000000491c:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
    4920: 0f 84 ad 00 00 00            	je	0x49d3 <trusted_x86_x86_sim_xdp+0x49d3>
    4926: 48 8d 7c 24 60               	leaq	0x60(%rsp), %rdi
    492b: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x4932 <trusted_x86_x86_sim_xdp+0x4932>
		000000000000492e:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    4932: 0f 85 c0 00 00 00            	jne	0x49f8 <trusted_x86_x86_sim_xdp+0x49f8>
    4938: e8 00 00 00 00               	callq	0x493d <trusted_x86_x86_sim_xdp+0x493d>
		0000000000004939:  R_X86_64_PLT32	.text+0x7c
    493d: e9 2f 02 00 00               	jmp	0x4b71 <trusted_x86_x86_sim_xdp+0x4b71>
    4942: c7 44 24 08 a4 0f 00 00      	movl	$0xfa4, 0x8(%rsp)       # imm = 0xFA4
    494a: c7 44 24 04 0a 00 00 00      	movl	$0xa, 0x4(%rsp)
    4952: 48 8d 83 28 0f 00 00         	leaq	0xf28(%rbx), %rax
    4959: 8b 4c 24 04                  	movl	0x4(%rsp), %ecx
    495d: 89 08                        	movl	%ecx, (%rax)
    495f: 4c 8b bc 24 80 00 00 00      	movq	0x80(%rsp), %r15
    4967: 45 31 e4                     	xorl	%r12d, %r12d
    496a: 8b 44 24 08                  	movl	0x8(%rsp), %eax
    496e: 89 c5                        	movl	%eax, %ebp
    4970: e9 73 e2 ff ff               	jmp	0x2be8 <trusted_x86_x86_sim_xdp+0x2be8>
    4975: 25 ff 7f ff ff               	andl	$0xffff7fff, %eax       # imm = 0xFFFF7FFF
    497a: ff c8                        	decl	%eax
    497c: 83 f8 03                     	cmpl	$0x3, %eax
    497f: 77 3d                        	ja	0x49be <trusted_x86_x86_sim_xdp+0x49be>
    4981: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x4988 <trusted_x86_x86_sim_xdp+0x4988>
		0000000000004984:  R_X86_64_PC32	.rodata+0x224
    4988: 48 63 04 81                  	movslq	(%rcx,%rax,4), %rax
    498c: 48 01 c8                     	addq	%rcx, %rax
    498f: ff e0                        	jmpq	*%rax
    4991: 48 8b 84 24 88 00 00 00      	movq	0x88(%rsp), %rax
    4999: 48 8b 8c 24 a8 00 00 00      	movq	0xa8(%rsp), %rcx
    49a1: 48 8b 00                     	movq	(%rax), %rax
    49a4: 8b 09                        	movl	(%rcx), %ecx
    49a6: 83 e1 0f                     	andl	$0xf, %ecx
    49a9: 31 d2                        	xorl	%edx, %edx
    49ab: 83 f9 0b                     	cmpl	$0xb, %ecx
    49ae: 0f 93 c2                     	setae	%dl
    49b1: 4c 8d 24 d0                  	leaq	(%rax,%rdx,8), %r12
    49b5: 49 83 c4 08                  	addq	$0x8, %r12
    49b9: e9 96 04 00 00               	jmp	0x4e54 <trusted_x86_x86_sim_xdp+0x4e54>
    49be: 4c 8b bc 24 80 00 00 00      	movq	0x80(%rsp), %r15
    49c6: bd 01 00 00 00               	movl	$0x1, %ebp
    49cb: 45 31 e4                     	xorl	%r12d, %r12d
    49ce: e9 15 e2 ff ff               	jmp	0x2be8 <trusted_x86_x86_sim_xdp+0x2be8>
    49d3: 8b 4c 24 60                  	movl	0x60(%rsp), %ecx
    49d7: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    49da: 0f 83 33 02 00 00            	jae	0x4c13 <trusted_x86_x86_sim_xdp+0x4c13>
    49e0: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    49e6: 48 8b bc c8 30 01 00 00      	movq	0x130(%rax,%rcx,8), %rdi
    49ee: e8 00 00 00 00               	callq	0x49f3 <trusted_x86_x86_sim_xdp+0x49f3>
		00000000000049ef:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    49f3: e9 79 01 00 00               	jmp	0x4b71 <trusted_x86_x86_sim_xdp+0x4b71>
    49f8: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x49ff <trusted_x86_x86_sim_xdp+0x49ff>
		00000000000049fb:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    49ff: 0f 85 5e 01 00 00            	jne	0x4b63 <trusted_x86_x86_sim_xdp+0x4b63>
    4a05: e8 00 00 00 00               	callq	0x4a0a <trusted_x86_x86_sim_xdp+0x4a0a>
		0000000000004a06:  R_X86_64_PLT32	.text+0x12c
    4a0a: e9 62 01 00 00               	jmp	0x4b71 <trusted_x86_x86_sim_xdp+0x4b71>
    4a0f: 48 8b 84 24 88 00 00 00      	movq	0x88(%rsp), %rax
    4a17: 48 8b 30                     	movq	(%rax), %rsi
    4a1a: 48 83 c6 28                  	addq	$0x28, %rsi
    4a1e: ba 90 00 00 00               	movl	$0x90, %edx
    4a23: 48 8d bc 24 b8 00 00 00      	leaq	0xb8(%rsp), %rdi
    4a2b: e8 00 00 00 00               	callq	0x4a30 <trusted_x86_x86_sim_xdp+0x4a30>
		0000000000004a2c:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    4a30: 49 89 c6                     	movq	%rax, %r14
    4a33: 45 85 f6                     	testl	%r14d, %r14d
    4a36: 79 14                        	jns	0x4a4c <trusted_x86_x86_sim_xdp+0x4a4c>
    4a38: ba 90 00 00 00               	movl	$0x90, %edx
    4a3d: 48 8d bc 24 b8 00 00 00      	leaq	0xb8(%rsp), %rdi
    4a45: 31 f6                        	xorl	%esi, %esi
    4a47: e8 00 00 00 00               	callq	0x4a4c <trusted_x86_x86_sim_xdp+0x4a4c>
		0000000000004a48:  R_X86_64_PLT32	memset-0x4
    4a4c: 45 85 f6                     	testl	%r14d, %r14d
    4a4f: 48 8b 54 24 28               	movq	0x28(%rsp), %rdx
    4a54: 48 8b 4c 24 30               	movq	0x30(%rsp), %rcx
    4a59: 48 8b 74 24 20               	movq	0x20(%rsp), %rsi
    4a5e: 0f 85 b1 c7 ff ff            	jne	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
    4a64: 48 8b 84 24 20 01 00 00      	movq	0x120(%rsp), %rax
    4a6c: 48 8b bc 24 a8 01 00 00      	movq	0x1a8(%rsp), %rdi
    4a74: 48 89 07                     	movq	%rax, (%rdi)
    4a77: 48 8b 84 24 c0 00 00 00      	movq	0xc0(%rsp), %rax
    4a7f: 48 89 06                     	movq	%rax, (%rsi)
    4a82: 48 8b 84 24 d0 00 00 00      	movq	0xd0(%rsp), %rax
    4a8a: 48 89 01                     	movq	%rax, (%rcx)
    4a8d: 48 8b 84 24 e0 00 00 00      	movq	0xe0(%rsp), %rax
    4a95: 48 8d 8b 00 0f 00 00         	leaq	0xf00(%rbx), %rcx
    4a9c: 48 89 01                     	movq	%rax, (%rcx)
    4a9f: 48 8b 84 24 f0 00 00 00      	movq	0xf0(%rsp), %rax
    4aa7: 48 89 02                     	movq	%rax, (%rdx)
    4aaa: 48 8b 84 24 08 01 00 00      	movq	0x108(%rsp), %rax
    4ab2: 48 8b 8c 24 98 01 00 00      	movq	0x198(%rsp), %rcx
    4aba: 48 89 01                     	movq	%rax, (%rcx)
    4abd: 48 8b 84 24 30 01 00 00      	movq	0x130(%rsp), %rax
    4ac5: 48 8b 8c 24 88 01 00 00      	movq	0x188(%rsp), %rcx
    4acd: 48 89 01                     	movq	%rax, (%rcx)
    4ad0: 48 8b 84 24 38 01 00 00      	movq	0x138(%rsp), %rax
    4ad8: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
    4ae0: 48 89 01                     	movq	%rax, (%rcx)
    4ae3: 48 8d 83 30 0f 00 00         	leaq	0xf30(%rbx), %rax
    4aea: 31 c9                        	xorl	%ecx, %ecx
    4aec: e9 bd 03 00 00               	jmp	0x4eae <trusted_x86_x86_sim_xdp+0x4eae>
    4af1: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    4af6: 48 8b 30                     	movq	(%rax), %rsi
    4af9: ba 10 00 00 00               	movl	$0x10, %edx
    4afe: 48 8d 7c 24 68               	leaq	0x68(%rsp), %rdi
    4b03: e8 00 00 00 00               	callq	0x4b08 <trusted_x86_x86_sim_xdp+0x4b08>
		0000000000004b04:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    4b08: 85 c0                        	testl	%eax, %eax
    4b0a: 79 14                        	jns	0x4b20 <trusted_x86_x86_sim_xdp+0x4b20>
    4b0c: 48 8d 4c 24 68               	leaq	0x68(%rsp), %rcx
    4b11: 48 c7 41 08 00 00 00 00      	movq	$0x0, 0x8(%rcx)
    4b19: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
    4b20: 85 c0                        	testl	%eax, %eax
    4b22: 0f 85 ed c6 ff ff            	jne	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
    4b28: 48 89 d8                     	movq	%rbx, %rax
    4b2b: 48 8b 80 e0 0e 00 00         	movq	0xee0(%rax), %rax
    4b32: 48 83 c0 10                  	addq	$0x10, %rax
    4b36: 48 8b 8c 24 88 01 00 00      	movq	0x188(%rsp), %rcx
    4b3e: 48 89 01                     	movq	%rax, (%rcx)
    4b41: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
    4b46: 48 8b 8c 24 98 01 00 00      	movq	0x198(%rsp), %rcx
    4b4e: 48 89 01                     	movq	%rax, (%rcx)
    4b51: 4c 8b 64 24 70               	movq	0x70(%rsp), %r12
    4b56: 48 8b 84 24 80 01 00 00      	movq	0x180(%rsp), %rax
    4b5e: e9 2f 03 00 00               	jmp	0x4e92 <trusted_x86_x86_sim_xdp+0x4e92>
    4b63: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x4b6a <trusted_x86_x86_sim_xdp+0x4b6a>
		0000000000004b66:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    4b6a: 75 12                        	jne	0x4b7e <trusted_x86_x86_sim_xdp+0x4b7e>
    4b6c: e8 00 00 00 00               	callq	0x4b71 <trusted_x86_x86_sim_xdp+0x4b71>
		0000000000004b6d:  R_X86_64_PLT32	.text+0x1dc
    4b71: 49 89 c7                     	movq	%rax, %r15
    4b74: 48 85 c0                     	testq	%rax, %rax
    4b77: 75 2d                        	jne	0x4ba6 <trusted_x86_x86_sim_xdp+0x4ba6>
    4b79: e9 95 00 00 00               	jmp	0x4c13 <trusted_x86_x86_sim_xdp+0x4c13>
    4b7e: 8b 4c 24 60                  	movl	0x60(%rsp), %ecx
    4b82: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    4b85: 0f 83 88 00 00 00            	jae	0x4c13 <trusted_x86_x86_sim_xdp+0x4c13>
    4b8b: 8b 90 20 01 00 00            	movl	0x120(%rax), %edx
    4b91: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    4b97: 48 0f af ca                  	imulq	%rdx, %rcx
    4b9b: 4c 8d 3c 08                  	leaq	(%rax,%rcx), %r15
    4b9f: 49 81 c7 30 01 00 00         	addq	$0x130, %r15            # imm = 0x130
    4ba6: 4c 89 f8                     	movq	%r15, %rax
    4ba9: 8b 68 04                     	movl	0x4(%rax), %ebp
    4bac: 4c 89 f8                     	movq	%r15, %rax
    4baf: 0f b6 40 02                  	movzbl	0x2(%rax), %eax
    4bb3: 85 c0                        	testl	%eax, %eax
    4bb5: 74 1f                        	je	0x4bd6 <trusted_x86_x86_sim_xdp+0x4bd6>
    4bb7: 89 c1                        	movl	%eax, %ecx
    4bb9: 83 e1 7f                     	andl	$0x7f, %ecx
    4bbc: 49 c1 e4 20                  	shlq	$0x20, %r12
    4bc0: 48 c1 e1 20                  	shlq	$0x20, %rcx
    4bc4: 49 39 cc                     	cmpq	%rcx, %r12
    4bc7: 7c 0d                        	jl	0x4bd6 <trusted_x86_x86_sim_xdp+0x4bd6>
    4bc9: f7 d0                        	notl	%eax
    4bcb: c1 e8 03                     	shrl	$0x3, %eax
    4bce: 83 e0 10                     	andl	$0x10, %eax
    4bd1: 01 c5                        	addl	%eax, %ebp
    4bd3: 83 c5 f8                     	addl	$-0x8, %ebp
    4bd6: 4c 89 f8                     	movq	%r15, %rax
    4bd9: 0f b6 00                     	movzbl	(%rax), %eax
    4bdc: 89 e9                        	movl	%ebp, %ecx
    4bde: 83 e1 f8                     	andl	$-0x8, %ecx
    4be1: 84 c0                        	testb	%al, %al
    4be3: 0f 49 cd                     	cmovnsl	%ebp, %ecx
    4be6: 89 c2                        	movl	%eax, %edx
    4be8: 83 e2 7f                     	andl	$0x7f, %edx
    4beb: 8d 72 ff                     	leal	-0x1(%rdx), %esi
    4bee: 83 fe 04                     	cmpl	$0x4, %esi
    4bf1: 0f 87 d8 00 00 00            	ja	0x4ccf <trusted_x86_x86_sim_xdp+0x4ccf>
    4bf7: 0f b6 d2                     	movzbl	%dl, %edx
    4bfa: 45 31 e4                     	xorl	%r12d, %r12d
    4bfd: ff ca                        	decl	%edx
    4bff: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0x4c06 <trusted_x86_x86_sim_xdp+0x4c06>
		0000000000004c02:  R_X86_64_PC32	.rodata+0x234
    4c06: 48 63 14 96                  	movslq	(%rsi,%rdx,4), %rdx
    4c0a: 48 01 f2                     	addq	%rsi, %rdx
    4c0d: ff e2                        	jmpq	*%rdx
    4c0f: 31 d2                        	xorl	%edx, %edx
    4c11: eb 71                        	jmp	0x4c84 <trusted_x86_x86_sim_xdp+0x4c84>
    4c13: c7 44 24 68 55 00 00 00      	movl	$0x55, 0x68(%rsp)
    4c1b: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x4c22 <trusted_x86_x86_sim_xdp+0x4c22>
		0000000000004c1e:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    4c22: 83 79 44 56                  	cmpl	$0x56, 0x44(%rcx)
    4c26: 72 29                        	jb	0x4c51 <trusted_x86_x86_sim_xdp+0x4c51>
    4c28: b8 55 00 00 00               	movl	$0x55, %eax
    4c2d: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    4c33: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    4c3b: e8 00 00 00 00               	callq	0x4c40 <trusted_x86_x86_sim_xdp+0x4c40>
		0000000000004c3c:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    4c40: 48 85 c0                     	testq	%rax, %rax
    4c43: 74 0c                        	je	0x4c51 <trusted_x86_x86_sim_xdp+0x4c51>
    4c45: 48 89 c1                     	movq	%rax, %rcx
    4c48: 48 8b 09                     	movq	(%rcx), %rcx
    4c4b: 48 ff c1                     	incq	%rcx
    4c4e: 48 89 08                     	movq	%rcx, (%rax)
    4c51: 4c 8b bc 24 80 00 00 00      	movq	0x80(%rsp), %r15
    4c59: bd af 0f 00 00               	movl	$0xfaf, %ebp            # imm = 0xFAF
    4c5e: 45 31 e4                     	xorl	%r12d, %r12d
    4c61: e9 82 df ff ff               	jmp	0x2be8 <trusted_x86_x86_sim_xdp+0x2be8>
    4c66: 48 8d 94 24 88 00 00 00      	leaq	0x88(%rsp), %rdx
    4c6e: 48 89 94 24 d0 01 00 00      	movq	%rdx, 0x1d0(%rsp)
    4c76: 48 8b 94 24 d0 01 00 00      	movq	0x1d0(%rsp), %rdx
    4c7e: 48 8b 12                     	movq	(%rdx), %rdx
    4c81: 48 8b 12                     	movq	(%rdx), %rdx
    4c84: 4c 63 e1                     	movslq	%ecx, %r12
    4c87: 49 01 d4                     	addq	%rdx, %r12
    4c8a: 84 c0                        	testb	%al, %al
    4c8c: 0f 89 92 00 00 00            	jns	0x4d24 <trusted_x86_x86_sim_xdp+0x4d24>
    4c92: ba 08 00 00 00               	movl	$0x8, %edx
    4c97: 48 8d 7c 24 68               	leaq	0x68(%rsp), %rdi
    4c9c: 4c 89 e6                     	movq	%r12, %rsi
    4c9f: e8 00 00 00 00               	callq	0x4ca4 <trusted_x86_x86_sim_xdp+0x4ca4>
		0000000000004ca0:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    4ca4: 85 c0                        	testl	%eax, %eax
    4ca6: 79 09                        	jns	0x4cb1 <trusted_x86_x86_sim_xdp+0x4cb1>
    4ca8: 48 c7 44 24 68 00 00 00 00   	movq	$0x0, 0x68(%rsp)
    4cb1: 85 c0                        	testl	%eax, %eax
    4cb3: 74 1f                        	je	0x4cd4 <trusted_x86_x86_sim_xdp+0x4cd4>
    4cb5: 45 31 e4                     	xorl	%r12d, %r12d
    4cb8: eb 6a                        	jmp	0x4d24 <trusted_x86_x86_sim_xdp+0x4d24>
    4cba: 89 e8                        	movl	%ebp, %eax
    4cbc: 83 e0 0f                     	andl	$0xf, %eax
    4cbf: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x4cc6 <trusted_x86_x86_sim_xdp+0x4cc6>
		0000000000004cc2:  R_X86_64_PC32	.rodata+0x248
    4cc6: 48 63 04 81                  	movslq	(%rcx,%rax,4), %rax
    4cca: 48 01 c8                     	addq	%rcx, %rax
    4ccd: ff e0                        	jmpq	*%rax
    4ccf: 45 31 e4                     	xorl	%r12d, %r12d
    4cd2: eb 50                        	jmp	0x4d24 <trusted_x86_x86_sim_xdp+0x4d24>
    4cd4: c1 e5 03                     	shll	$0x3, %ebp
    4cd7: 83 e5 38                     	andl	$0x38, %ebp
    4cda: 48 03 6c 24 68               	addq	0x68(%rsp), %rbp
    4cdf: 49 89 ec                     	movq	%rbp, %r12
    4ce2: eb 40                        	jmp	0x4d24 <trusted_x86_x86_sim_xdp+0x4d24>
    4ce4: 48 8d 84 24 a0 00 00 00      	leaq	0xa0(%rsp), %rax
    4cec: eb 0f                        	jmp	0x4cfd <trusted_x86_x86_sim_xdp+0x4cfd>
    4cee: 48 8d 84 24 98 00 00 00      	leaq	0x98(%rsp), %rax
    4cf6: eb 05                        	jmp	0x4cfd <trusted_x86_x86_sim_xdp+0x4cfd>
    4cf8: 48 8d 44 24 50               	leaq	0x50(%rsp), %rax
    4cfd: 48 89 84 24 b8 01 00 00      	movq	%rax, 0x1b8(%rsp)
    4d05: 48 8b 84 24 b8 01 00 00      	movq	0x1b8(%rsp), %rax
    4d0d: 48 8b 00                     	movq	(%rax), %rax
    4d10: 89 e9                        	movl	%ebp, %ecx
    4d12: 81 e1 00 00 00 80            	andl	$0x80000000, %ecx       # imm = 0x80000000
    4d18: c1 ed 04                     	shrl	$0x4, %ebp
    4d1b: 8d 0c e9                     	leal	(%rcx,%rbp,8), %ecx
    4d1e: 4c 63 e1                     	movslq	%ecx, %r12
    4d21: 4c 03 20                     	addq	(%rax), %r12
    4d24: 4c 89 f8                     	movq	%r15, %rax
    4d27: 0f b6 40 01                  	movzbl	0x1(%rax), %eax
    4d2b: 4c 89 f9                     	movq	%r15, %rcx
    4d2e: 44 8b 71 08                  	movl	0x8(%rcx), %r14d
    4d32: 44 89 f1                     	movl	%r14d, %ecx
    4d35: 83 e1 f8                     	andl	$-0x8, %ecx
    4d38: 84 c0                        	testb	%al, %al
    4d3a: 41 0f 49 ce                  	cmovnsl	%r14d, %ecx
    4d3e: 89 c2                        	movl	%eax, %edx
    4d40: 83 e2 7f                     	andl	$0x7f, %edx
    4d43: 8d 72 ff                     	leal	-0x1(%rdx), %esi
    4d46: 83 fe 04                     	cmpl	$0x4, %esi
    4d49: 0f 87 f1 00 00 00            	ja	0x4e40 <trusted_x86_x86_sim_xdp+0x4e40>
    4d4f: 0f b6 d2                     	movzbl	%dl, %edx
    4d52: ff ca                        	decl	%edx
    4d54: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0x4d5b <trusted_x86_x86_sim_xdp+0x4d5b>
		0000000000004d57:  R_X86_64_PC32	.rodata+0x288
    4d5b: 48 63 3c 96                  	movslq	(%rsi,%rdx,4), %rdi
    4d5f: 48 01 f7                     	addq	%rsi, %rdi
    4d62: 4c 89 e2                     	movq	%r12, %rdx
    4d65: ff e7                        	jmpq	*%rdi
    4d67: 48 8b 94 24 88 00 00 00      	movq	0x88(%rsp), %rdx
    4d6f: eb 0d                        	jmp	0x4d7e <trusted_x86_x86_sim_xdp+0x4d7e>
    4d71: 48 8b 54 24 58               	movq	0x58(%rsp), %rdx
    4d76: 48 89 94 24 88 00 00 00      	movq	%rdx, 0x88(%rsp)
    4d7e: 48 8b 12                     	movq	(%rdx), %rdx
    4d81: 48 63 f1                     	movslq	%ecx, %rsi
    4d84: 48 01 d6                     	addq	%rdx, %rsi
    4d87: 84 c0                        	testb	%al, %al
    4d89: 0f 89 8d 00 00 00            	jns	0x4e1c <trusted_x86_x86_sim_xdp+0x4e1c>
    4d8f: ba 08 00 00 00               	movl	$0x8, %edx
    4d94: 48 8d 7c 24 68               	leaq	0x68(%rsp), %rdi
    4d99: e8 00 00 00 00               	callq	0x4d9e <trusted_x86_x86_sim_xdp+0x4d9e>
		0000000000004d9a:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    4d9e: 85 c0                        	testl	%eax, %eax
    4da0: 79 09                        	jns	0x4dab <trusted_x86_x86_sim_xdp+0x4dab>
    4da2: 48 c7 44 24 68 00 00 00 00   	movq	$0x0, 0x68(%rsp)
    4dab: 85 c0                        	testl	%eax, %eax
    4dad: 0f 85 8d 00 00 00            	jne	0x4e40 <trusted_x86_x86_sim_xdp+0x4e40>
    4db3: 41 c1 e6 03                  	shll	$0x3, %r14d
    4db7: 41 83 e6 38                  	andl	$0x38, %r14d
    4dbb: 4c 03 74 24 68               	addq	0x68(%rsp), %r14
    4dc0: 4c 89 f6                     	movq	%r14, %rsi
    4dc3: eb 57                        	jmp	0x4e1c <trusted_x86_x86_sim_xdp+0x4e1c>
    4dc5: 44 89 f0                     	movl	%r14d, %eax
    4dc8: 83 e0 0f                     	andl	$0xf, %eax
    4dcb: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x4dd2 <trusted_x86_x86_sim_xdp+0x4dd2>
		0000000000004dce:  R_X86_64_PC32	.rodata+0x29c
    4dd2: 48 63 04 81                  	movslq	(%rcx,%rax,4), %rax
    4dd6: 48 01 c8                     	addq	%rcx, %rax
    4dd9: ff e0                        	jmpq	*%rax
    4ddb: 48 8b 84 24 90 00 00 00      	movq	0x90(%rsp), %rax
    4de3: eb 20                        	jmp	0x4e05 <trusted_x86_x86_sim_xdp+0x4e05>
    4de5: b8 0d 00 00 00               	movl	$0xd, %eax
    4dea: eb 0c                        	jmp	0x4df8 <trusted_x86_x86_sim_xdp+0x4df8>
    4dec: b8 0c 00 00 00               	movl	$0xc, %eax
    4df1: eb 05                        	jmp	0x4df8 <trusted_x86_x86_sim_xdp+0x4df8>
    4df3: b8 03 00 00 00               	movl	$0x3, %eax
    4df8: 48 8b 44 c4 38               	movq	0x38(%rsp,%rax,8), %rax
    4dfd: 48 89 84 24 90 00 00 00      	movq	%rax, 0x90(%rsp)
    4e05: 44 89 f1                     	movl	%r14d, %ecx
    4e08: 81 e1 00 00 00 80            	andl	$0x80000000, %ecx       # imm = 0x80000000
    4e0e: 41 c1 ee 04                  	shrl	$0x4, %r14d
    4e12: 42 8d 0c f1                  	leal	(%rcx,%r14,8), %ecx
    4e16: 48 63 f1                     	movslq	%ecx, %rsi
    4e19: 48 03 30                     	addq	(%rax), %rsi
    4e1c: 48 85 f6                     	testq	%rsi, %rsi
    4e1f: 74 1f                        	je	0x4e40 <trusted_x86_x86_sim_xdp+0x4e40>
    4e21: 4c 8b 74 24 58               	movq	0x58(%rsp), %r14
    4e26: ba 08 00 00 00               	movl	$0x8, %edx
    4e2b: 4c 89 f7                     	movq	%r14, %rdi
    4e2e: e8 00 00 00 00               	callq	0x4e33 <trusted_x86_x86_sim_xdp+0x4e33>
		0000000000004e2f:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    4e33: 85 c0                        	testl	%eax, %eax
    4e35: 79 1d                        	jns	0x4e54 <trusted_x86_x86_sim_xdp+0x4e54>
    4e37: 49 c7 06 00 00 00 00         	movq	$0x0, (%r14)
    4e3e: eb 14                        	jmp	0x4e54 <trusted_x86_x86_sim_xdp+0x4e54>
    4e40: 41 0f b6 07                  	movzbl	(%r15), %eax
    4e44: 3c 03                        	cmpb	$0x3, %al
    4e46: 75 0c                        	jne	0x4e54 <trusted_x86_x86_sim_xdp+0x4e54>
    4e48: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    4e4d: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    4e54: 4d 85 e4                     	testq	%r12, %r12
    4e57: 0f 84 b8 c3 ff ff            	je	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
    4e5d: 4c 8b b4 24 a8 00 00 00      	movq	0xa8(%rsp), %r14
    4e65: 49 8d 74 24 f8               	leaq	-0x8(%r12), %rsi
    4e6a: ba 08 00 00 00               	movl	$0x8, %edx
    4e6f: 4c 89 f7                     	movq	%r14, %rdi
    4e72: e8 00 00 00 00               	callq	0x4e77 <trusted_x86_x86_sim_xdp+0x4e77>
		0000000000004e73:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    4e77: 85 c0                        	testl	%eax, %eax
    4e79: 79 07                        	jns	0x4e82 <trusted_x86_x86_sim_xdp+0x4e82>
    4e7b: 49 c7 06 00 00 00 00         	movq	$0x0, (%r14)
    4e82: 85 c0                        	testl	%eax, %eax
    4e84: 0f 85 8b c3 ff ff            	jne	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
    4e8a: 48 8b 84 24 88 01 00 00      	movq	0x188(%rsp), %rax
    4e92: 48 89 84 24 80 01 00 00      	movq	%rax, 0x180(%rsp)
    4e9a: 48 8b 84 24 80 01 00 00      	movq	0x180(%rsp), %rax
    4ea2: 4c 89 20                     	movq	%r12, (%rax)
    4ea5: 48 8d 83 30 0f 00 00         	leaq	0xf30(%rbx), %rax
    4eac: b1 01                        	movb	$0x1, %cl
    4eae: 88 08                        	movb	%cl, (%rax)
    4eb0: c7 44 24 68 06 00 00 00      	movl	$0x6, 0x68(%rsp)
    4eb8: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x4ebf <trusted_x86_x86_sim_xdp+0x4ebf>
		0000000000004ebb:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    4ebf: 83 78 44 07                  	cmpl	$0x7, 0x44(%rax)
    4ec3: 72 30                        	jb	0x4ef5 <trusted_x86_x86_sim_xdp+0x4ef5>
    4ec5: b8 06 00 00 00               	movl	$0x6, %eax
    4eca: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x4ed1 <trusted_x86_x86_sim_xdp+0x4ed1>
		0000000000004ecd:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    4ed1: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    4ed7: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    4edf: e8 00 00 00 00               	callq	0x4ee4 <trusted_x86_x86_sim_xdp+0x4ee4>
		0000000000004ee0:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    4ee4: 48 85 c0                     	testq	%rax, %rax
    4ee7: 74 0c                        	je	0x4ef5 <trusted_x86_x86_sim_xdp+0x4ef5>
    4ee9: 48 89 c1                     	movq	%rax, %rcx
    4eec: 48 8b 09                     	movq	(%rcx), %rcx
    4eef: 48 ff c1                     	incq	%rcx
    4ef2: 48 89 08                     	movq	%rcx, (%rax)
    4ef5: 48 8b 84 24 a8 00 00 00      	movq	0xa8(%rsp), %rax
    4efd: 4c 8b 38                     	movq	(%rax), %r15
    4f00: 4d 85 ff                     	testq	%r15, %r15
    4f03: 74 78                        	je	0x4f7d <trusted_x86_x86_sim_xdp+0x4f7d>
    4f05: 4c 3b 7c 24 10               	cmpq	0x10(%rsp), %r15
    4f0a: 0f 83 cb c3 ff ff            	jae	0x12db <trusted_x86_x86_sim_xdp+0x12db>
    4f10: 49 81 ff 00 10 00 00         	cmpq	$0x1000, %r15           # imm = 0x1000
    4f17: 0f 82 e6 c3 ff ff            	jb	0x1303 <trusted_x86_x86_sim_xdp+0x1303>
    4f1d: 48 89 d8                     	movq	%rbx, %rax
    4f20: 8b 00                        	movl	(%rax), %eax
    4f22: c7 84 24 b8 00 00 00 60 00 00 00     	movl	$0x60, 0xb8(%rsp)
    4f2d: 0f 38 f1 84 24 bc 00 00 00   	movbel	%eax, 0xbc(%rsp)
    4f36: 4c 0f 38 f1 bc 24 c0 00 00 00	movbeq	%r15, 0xc0(%rsp)
    4f40: 80 bc 24 a0 01 00 00 00      	cmpb	$0x0, 0x1a0(%rsp)
    4f48: 74 55                        	je	0x4f9f <trusted_x86_x86_sim_xdp+0x4f9f>
    4f4a: 8b 84 24 b8 00 00 00         	movl	0xb8(%rsp), %eax
    4f51: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x4f58 <trusted_x86_x86_sim_xdp+0x4f58>
		0000000000004f54:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    4f58: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    4f5b: 0f 83 d4 00 00 00            	jae	0x5035 <trusted_x86_x86_sim_xdp+0x5035>
    4f61: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x4f68 <trusted_x86_x86_sim_xdp+0x4f68>
		0000000000004f64:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    4f68: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    4f6e: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    4f76: e8 00 00 00 00               	callq	0x4f7b <trusted_x86_x86_sim_xdp+0x4f7b>
		0000000000004f77:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    4f7b: eb 2f                        	jmp	0x4fac <trusted_x86_x86_sim_xdp+0x4fac>
    4f7d: 48 8d 83 28 0f 00 00         	leaq	0xf28(%rbx), %rax
    4f84: c7 00 01 00 00 00            	movl	$0x1, (%rax)
    4f8a: bd ad 0f 00 00               	movl	$0xfad, %ebp            # imm = 0xFAD
    4f8f: 45 31 e4                     	xorl	%r12d, %r12d
    4f92: 4c 8b bc 24 80 00 00 00      	movq	0x80(%rsp), %r15
    4f9a: e9 49 dc ff ff               	jmp	0x2be8 <trusted_x86_x86_sim_xdp+0x2be8>
    4f9f: 48 8d bc 24 b8 00 00 00      	leaq	0xb8(%rsp), %rdi
    4fa7: e8 00 00 00 00               	callq	0x4fac <trusted_x86_x86_sim_xdp+0x4fac>
		0000000000004fa8:  R_X86_64_PLT32	.text+0x7c
    4fac: 48 85 c0                     	testq	%rax, %rax
    4faf: 0f 84 80 00 00 00            	je	0x5035 <trusted_x86_x86_sim_xdp+0x5035>
    4fb5: 48 89 c1                     	movq	%rax, %rcx
    4fb8: 4c 8b 61 08                  	movq	0x8(%rcx), %r12
    4fbc: 48 b9 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    4fc6: 4c 21 e1                     	andq	%r12, %rcx
    4fc9: 48 8b 94 24 90 01 00 00      	movq	0x190(%rsp), %rdx
    4fd1: 48 89 0a                     	movq	%rcx, (%rdx)
    4fd4: 48 8b 00                     	movq	(%rax), %rax
    4fd7: 48 8b 94 24 c8 01 00 00      	movq	0x1c8(%rsp), %rdx
    4fdf: 48 89 02                     	movq	%rax, (%rdx)
    4fe2: 49 c1 ec 38                  	shrq	$0x38, %r12
    4fe6: 49 29 cf                     	subq	%rcx, %r15
    4fe9: 48 8b 8c 24 b0 01 00 00      	movq	0x1b0(%rsp), %rcx
    4ff1: 4c 89 39                     	movq	%r15, (%rcx)
    4ff4: 31 ed                        	xorl	%ebp, %ebp
    4ff6: 49 83 fc 01                  	cmpq	$0x1, %r12
    4ffa: 75 96                        	jne	0x4f92 <trusted_x86_x86_sim_xdp+0x4f92>
    4ffc: 48 89 84 24 b8 00 00 00      	movq	%rax, 0xb8(%rsp)
    5004: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x500b <trusted_x86_x86_sim_xdp+0x500b>
		0000000000005007:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    500b: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x5012 <trusted_x86_x86_sim_xdp+0x5012>
		000000000000500e:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    5012: 74 38                        	je	0x504c <trusted_x86_x86_sim_xdp+0x504c>
    5014: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x501b <trusted_x86_x86_sim_xdp+0x501b>
		0000000000005017:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
    501b: 74 2f                        	je	0x504c <trusted_x86_x86_sim_xdp+0x504c>
    501d: 48 8d bc 24 b8 00 00 00      	leaq	0xb8(%rsp), %rdi
    5025: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x502c <trusted_x86_x86_sim_xdp+0x502c>
		0000000000005028:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    502c: 75 49                        	jne	0x5077 <trusted_x86_x86_sim_xdp+0x5077>
    502e: e8 00 00 00 00               	callq	0x5033 <trusted_x86_x86_sim_xdp+0x5033>
		000000000000502f:  R_X86_64_PLT32	.text+0x7c
    5033: eb 47                        	jmp	0x507c <trusted_x86_x86_sim_xdp+0x507c>
    5035: 48 8d 83 28 0f 00 00         	leaq	0xf28(%rbx), %rax
    503c: c7 00 0c 00 00 00            	movl	$0xc, (%rax)
    5042: bd ac 0f 00 00               	movl	$0xfac, %ebp            # imm = 0xFAC
    5047: e9 43 ff ff ff               	jmp	0x4f8f <trusted_x86_x86_sim_xdp+0x4f8f>
    504c: 8b 8c 24 b8 00 00 00         	movl	0xb8(%rsp), %ecx
    5053: 41 bc 01 00 00 00            	movl	$0x1, %r12d
    5059: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    505c: 0f 83 30 ff ff ff            	jae	0x4f92 <trusted_x86_x86_sim_xdp+0x4f92>
    5062: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    5068: 48 8b bc c8 30 01 00 00      	movq	0x130(%rax,%rcx,8), %rdi
    5070: e8 00 00 00 00               	callq	0x5075 <trusted_x86_x86_sim_xdp+0x5075>
		0000000000005071:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    5075: eb 05                        	jmp	0x507c <trusted_x86_x86_sim_xdp+0x507c>
    5077: e8 00 00 00 00               	callq	0x507c <trusted_x86_x86_sim_xdp+0x507c>
		0000000000005078:  R_X86_64_PLT32	.text+0x12c
    507c: 49 89 c6                     	movq	%rax, %r14
    507f: 41 bc 01 00 00 00            	movl	$0x1, %r12d
    5085: 48 85 c0                     	testq	%rax, %rax
    5088: 0f 84 04 ff ff ff            	je	0x4f92 <trusted_x86_x86_sim_xdp+0x4f92>
    508e: 4c 89 f0                     	movq	%r14, %rax
    5091: 48 8b 00                     	movq	(%rax), %rax
    5094: 4c 39 f8                     	cmpq	%r15, %rax
    5097: 77 0c                        	ja	0x50a5 <trusted_x86_x86_sim_xdp+0x50a5>
    5099: 4c 89 f0                     	movq	%r14, %rax
    509c: 48 8b 40 08                  	movq	0x8(%rax), %rax
    50a0: 4c 39 f8                     	cmpq	%r15, %rax
    50a3: 73 20                        	jae	0x50c5 <trusted_x86_x86_sim_xdp+0x50c5>
    50a5: 4c 89 f0                     	movq	%r14, %rax
    50a8: 48 8b 40 10                  	movq	0x10(%rax), %rax
    50ac: 4c 39 f8                     	cmpq	%r15, %rax
    50af: 0f 87 dd fe ff ff            	ja	0x4f92 <trusted_x86_x86_sim_xdp+0x4f92>
    50b5: 4c 89 f0                     	movq	%r14, %rax
    50b8: 48 8b 40 18                  	movq	0x18(%rax), %rax
    50bc: 4c 39 f8                     	cmpq	%r15, %rax
    50bf: 0f 82 cd fe ff ff            	jb	0x4f92 <trusted_x86_x86_sim_xdp+0x4f92>
    50c5: 48 89 d8                     	movq	%rbx, %rax
    50c8: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
    50ce: 4c 89 f1                     	movq	%r14, %rcx
    50d1: 8b 49 20                     	movl	0x20(%rcx), %ecx
    50d4: 0f a3 c8                     	btl	%ecx, %eax
    50d7: 0f 82 b5 fe ff ff            	jb	0x4f92 <trusted_x86_x86_sim_xdp+0x4f92>
    50dd: c7 44 24 68 00 00 00 00      	movl	$0x0, 0x68(%rsp)
    50e5: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x50ec <trusted_x86_x86_sim_xdp+0x50ec>
		00000000000050e8:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    50ec: 83 78 44 00                  	cmpl	$0x0, 0x44(%rax)
    50f0: 74 24                        	je	0x5116 <trusted_x86_x86_sim_xdp+0x5116>
    50f2: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x50f9 <trusted_x86_x86_sim_xdp+0x50f9>
		00000000000050f5:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    50f9: 48 8b b8 30 01 00 00         	movq	0x130(%rax), %rdi
    5100: e8 00 00 00 00               	callq	0x5105 <trusted_x86_x86_sim_xdp+0x5105>
		0000000000005101:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    5105: 48 85 c0                     	testq	%rax, %rax
    5108: 74 0c                        	je	0x5116 <trusted_x86_x86_sim_xdp+0x5116>
    510a: 48 89 c1                     	movq	%rax, %rcx
    510d: 48 8b 09                     	movq	(%rcx), %rcx
    5110: 48 ff c1                     	incq	%rcx
    5113: 48 89 08                     	movq	%rcx, (%rax)
    5116: 45 0f b7 66 20               	movzwl	0x20(%r14), %r12d
    511b: 4c 8b bc 24 80 00 00 00      	movq	0x80(%rsp), %r15
    5123: e9 c0 da ff ff               	jmp	0x2be8 <trusted_x86_x86_sim_xdp+0x2be8>
