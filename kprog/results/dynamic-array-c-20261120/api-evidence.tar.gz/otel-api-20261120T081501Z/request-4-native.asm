
/var/tmp/kprog-tmp/perf/helper-sharing/4/checked-simulator.native.o:	file format elf64-x86-64

Disassembly of section perf_event:

0000000000000000 <trusted_x86_x86_sim_xdp>:
       0: 55                           	pushq	%rbp
       1: 41 57                        	pushq	%r15
       3: 41 56                        	pushq	%r14
       5: 41 55                        	pushq	%r13
       7: 41 54                        	pushq	%r12
       9: 53                           	pushq	%rbx
       a: 48 81 ec c8 01 00 00         	subq	$0x1c8, %rsp            # imm = 0x1C8
      11: c7 44 24 58 00 00 00 00      	movl	$0x0, 0x58(%rsp)
      19: 48 c7 84 24 20 01 00 00 00 00 00 00  	movq	$0x0, 0x120(%rsp)
      25: 48 c7 84 24 28 01 00 00 00 00 00 00  	movq	$0x0, 0x128(%rsp)
      31: 48 c7 84 24 30 01 00 00 00 00 00 00  	movq	$0x0, 0x130(%rsp)
      3d: 48 c7 84 24 38 01 00 00 00 00 00 00  	movq	$0x0, 0x138(%rsp)
      49: 48 c7 84 24 40 01 00 00 00 00 00 00  	movq	$0x0, 0x140(%rsp)
      55: 48 c7 84 24 48 01 00 00 00 00 00 00  	movq	$0x0, 0x148(%rsp)
      61: 4c 8b 3d 00 00 00 00         	movq	(%rip), %r15            # 0x68 <trusted_x86_x86_sim_xdp+0x68>
		0000000000000064:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
      68: b8 ff ff ff ff               	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      6d: 41 83 7f 44 00               	cmpl	$0x0, 0x44(%r15)
      72: 0f 84 61 02 00 00            	je	0x2d9 <trusted_x86_x86_sim_xdp+0x2d9>
      78: 49 89 fe                     	movq	%rdi, %r14
      7b: 49 8b bf 30 01 00 00         	movq	0x130(%r15), %rdi
      82: e8 00 00 00 00               	callq	0x87 <trusted_x86_x86_sim_xdp+0x87>
		0000000000000083:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
      87: 48 85 c0                     	testq	%rax, %rax
      8a: 0f 84 44 02 00 00            	je	0x2d4 <trusted_x86_x86_sim_xdp+0x2d4>
      90: 48 89 c3                     	movq	%rax, %rbx
      93: 8b 00                        	movl	(%rax), %eax
      95: 89 84 24 1c 01 00 00         	movl	%eax, 0x11c(%rsp)
      9c: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0xa3 <trusted_x86_x86_sim_xdp+0xa3>
		000000000000009f:  R_X86_64_REX_GOTPCRELX	hotspot_procs-0x4
      a3: 48 3b 0d 00 00 00 00         	cmpq	(%rip), %rcx            # 0xaa <trusted_x86_x86_sim_xdp+0xaa>
		00000000000000a6:  R_X86_64_REX_GOTPCRELX	metrics-0x4
      aa: 74 32                        	je	0xde <trusted_x86_x86_sim_xdp+0xde>
      ac: 48 3b 0d 00 00 00 00         	cmpq	(%rip), %rcx            # 0xb3 <trusted_x86_x86_sim_xdp+0xb3>
		00000000000000af:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
      b3: 74 29                        	je	0xde <trusted_x86_x86_sim_xdp+0xde>
      b5: 48 8d bc 24 1c 01 00 00      	leaq	0x11c(%rsp), %rdi
      bd: 48 3b 0d 00 00 00 00         	cmpq	(%rip), %rcx            # 0xc4 <trusted_x86_x86_sim_xdp+0xc4>
		00000000000000c0:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
      c4: 0f 85 21 02 00 00            	jne	0x2eb <trusted_x86_x86_sim_xdp+0x2eb>
      ca: e8 00 00 00 00               	callq	0xcf <trusted_x86_x86_sim_xdp+0xcf>
		00000000000000cb:  R_X86_64_PLT32	.text+0x7c
      cf: 49 89 c4                     	movq	%rax, %r12
      d2: 48 85 c0                     	testq	%rax, %rax
      d5: 75 34                        	jne	0x10b <trusted_x86_x86_sim_xdp+0x10b>
      d7: 31 c0                        	xorl	%eax, %eax
      d9: e9 fb 01 00 00               	jmp	0x2d9 <trusted_x86_x86_sim_xdp+0x2d9>
      de: 8b 94 24 1c 01 00 00         	movl	0x11c(%rsp), %edx
      e5: 31 c0                        	xorl	%eax, %eax
      e7: 3b 51 44                     	cmpl	0x44(%rcx), %edx
      ea: 0f 83 e9 01 00 00            	jae	0x2d9 <trusted_x86_x86_sim_xdp+0x2d9>
      f0: 23 91 24 01 00 00            	andl	0x124(%rcx), %edx
      f6: 48 8b bc d1 30 01 00 00      	movq	0x130(%rcx,%rdx,8), %rdi
      fe: e8 00 00 00 00               	callq	0x103 <trusted_x86_x86_sim_xdp+0x103>
		00000000000000ff:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     103: 49 89 c4                     	movq	%rax, %r12
     106: 48 85 c0                     	testq	%rax, %rax
     109: 74 cc                        	je	0xd7 <trusted_x86_x86_sim_xdp+0xd7>
     10b: 4c 89 b4 24 08 01 00 00      	movq	%r14, 0x108(%rsp)
     113: c7 44 24 58 29 00 00 00      	movl	$0x29, 0x58(%rsp)
     11b: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x122 <trusted_x86_x86_sim_xdp+0x122>
		000000000000011e:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     122: 83 79 44 2a                  	cmpl	$0x2a, 0x44(%rcx)
     126: 72 29                        	jb	0x151 <trusted_x86_x86_sim_xdp+0x151>
     128: b8 29 00 00 00               	movl	$0x29, %eax
     12d: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
     133: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
     13b: e8 00 00 00 00               	callq	0x140 <trusted_x86_x86_sim_xdp+0x140>
		000000000000013c:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     140: 48 85 c0                     	testq	%rax, %rax
     143: 74 0c                        	je	0x151 <trusted_x86_x86_sim_xdp+0x151>
     145: 48 89 c1                     	movq	%rax, %rcx
     148: 48 8b 09                     	movq	(%rcx), %rcx
     14b: 48 ff c1                     	incq	%rcx
     14e: 48 89 08                     	movq	%rcx, (%rax)
     151: 48 89 d8                     	movq	%rbx, %rax
     154: 4c 8b b0 d0 0e 00 00         	movq	0xed0(%rax), %r14
     15b: 48 89 d8                     	movq	%rbx, %rax
     15e: 48 8b a8 d8 0e 00 00         	movq	0xed8(%rax), %rbp
     165: 48 89 d8                     	movq	%rbx, %rax
     168: 48 8b 80 e0 0e 00 00         	movq	0xee0(%rax), %rax
     16f: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
     174: 4c 89 64 24 10               	movq	%r12, 0x10(%rsp)
     179: 41 0f b6 44 24 20            	movzbl	0x20(%r12), %eax
     17f: 48 89 d9                     	movq	%rbx, %rcx
     182: c4 62 fb f7 a9 18 0f 00 00   	shrxq	%rax, 0xf18(%rcx), %r13
     18b: 48 89 d8                     	movq	%rbx, %rax
     18e: b1 38                        	movb	$0x38, %cl
     190: c4 62 f0 f5 a0 10 0f 00 00   	bzhiq	%rcx, 0xf10(%rax), %r12
     199: 4b 8d 34 2c                  	leaq	(%r12,%r13), %rsi
     19d: ba 01 00 00 00               	movl	$0x1, %edx
     1a2: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     1a7: e8 00 00 00 00               	callq	0x1ac <trusted_x86_x86_sim_xdp+0x1ac>
		00000000000001a8:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     1ac: 85 c0                        	testl	%eax, %eax
     1ae: 79 05                        	jns	0x1b5 <trusted_x86_x86_sim_xdp+0x1b5>
     1b0: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
     1b5: 85 c0                        	testl	%eax, %eax
     1b7: 0f 84 51 01 00 00            	je	0x30e <trusted_x86_x86_sim_xdp+0x30e>
     1bd: 48 c7 84 24 c8 00 00 00 00 00 00 00  	movq	$0x0, 0xc8(%rsp)
     1c9: c7 44 24 58 2b 00 00 00      	movl	$0x2b, 0x58(%rsp)
     1d1: bd e8 03 00 00               	movl	$0x3e8, %ebp            # imm = 0x3E8
     1d6: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1dd <trusted_x86_x86_sim_xdp+0x1dd>
		00000000000001d9:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     1dd: 83 79 44 2c                  	cmpl	$0x2c, 0x44(%rcx)
     1e1: 72 29                        	jb	0x20c <trusted_x86_x86_sim_xdp+0x20c>
     1e3: b8 2b 00 00 00               	movl	$0x2b, %eax
     1e8: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
     1ee: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
     1f6: e8 00 00 00 00               	callq	0x1fb <trusted_x86_x86_sim_xdp+0x1fb>
		00000000000001f7:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     1fb: 48 85 c0                     	testq	%rax, %rax
     1fe: 74 0c                        	je	0x20c <trusted_x86_x86_sim_xdp+0x20c>
     200: 48 89 c1                     	movq	%rax, %rcx
     203: 48 8b 09                     	movq	(%rcx), %rcx
     206: 48 ff c1                     	incq	%rcx
     209: 48 89 08                     	movq	%rcx, (%rax)
     20c: 45 31 ed                     	xorl	%r13d, %r13d
     20f: 4c 8b b4 24 08 01 00 00      	movq	0x108(%rsp), %r14
     217: 48 81 c3 2c 0f 00 00         	addq	$0xf2c, %rbx            # imm = 0xF2C
     21e: 89 2b                        	movl	%ebp, (%rbx)
     220: c7 44 24 58 00 00 00 00      	movl	$0x0, 0x58(%rsp)
     228: 31 db                        	xorl	%ebx, %ebx
     22a: 41 83 7f 44 00               	cmpl	$0x0, 0x44(%r15)
     22f: 0f 84 8e 00 00 00            	je	0x2c3 <trusted_x86_x86_sim_xdp+0x2c3>
     235: 49 8b bf 30 01 00 00         	movq	0x130(%r15), %rdi
     23c: e8 00 00 00 00               	callq	0x241 <trusted_x86_x86_sim_xdp+0x241>
		000000000000023d:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     241: 48 85 c0                     	testq	%rax, %rax
     244: 74 7d                        	je	0x2c3 <trusted_x86_x86_sim_xdp+0x2c3>
     246: 48 89 c1                     	movq	%rax, %rcx
     249: 0f b6 89 84 13 00 00         	movzbl	0x1384(%rcx), %ecx
     250: 80 f9 1d                     	cmpb	$0x1d, %cl
     253: 72 61                        	jb	0x2b6 <trusted_x86_x86_sim_xdp+0x2b6>
     255: 48 8d 88 2c 0f 00 00         	leaq	0xf2c(%rax), %rcx
     25c: c7 01 05 00 00 00            	movl	$0x5, (%rcx)
     262: c7 44 24 58 44 00 00 00      	movl	$0x44, 0x58(%rsp)
     26a: 48 8b 15 00 00 00 00         	movq	(%rip), %rdx            # 0x271 <trusted_x86_x86_sim_xdp+0x271>
		000000000000026d:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     271: 83 7a 44 45                  	cmpl	$0x45, 0x44(%rdx)
     275: 72 32                        	jb	0x2a9 <trusted_x86_x86_sim_xdp+0x2a9>
     277: b9 44 00 00 00               	movl	$0x44, %ecx
     27c: 23 8a 24 01 00 00            	andl	0x124(%rdx), %ecx
     282: 48 8b bc ca 30 01 00 00      	movq	0x130(%rdx,%rcx,8), %rdi
     28a: 48 89 c3                     	movq	%rax, %rbx
     28d: e8 00 00 00 00               	callq	0x292 <trusted_x86_x86_sim_xdp+0x292>
		000000000000028e:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     292: 48 89 c1                     	movq	%rax, %rcx
     295: 48 89 d8                     	movq	%rbx, %rax
     298: 48 85 c9                     	testq	%rcx, %rcx
     29b: 74 0c                        	je	0x2a9 <trusted_x86_x86_sim_xdp+0x2a9>
     29d: 48 89 ca                     	movq	%rcx, %rdx
     2a0: 48 8b 12                     	movq	(%rdx), %rdx
     2a3: 48 ff c2                     	incq	%rdx
     2a6: 48 89 11                     	movq	%rdx, (%rcx)
     2a9: 48 89 c1                     	movq	%rax, %rcx
     2ac: 0f b6 89 84 13 00 00         	movzbl	0x1384(%rcx), %ecx
     2b3: 45 31 ed                     	xorl	%r13d, %r13d
     2b6: fe c1                        	incb	%cl
     2b8: 48 05 84 13 00 00            	addq	$0x1384, %rax           # imm = 0x1384
     2be: 88 08                        	movb	%cl, (%rax)
     2c0: 44 89 eb                     	movl	%r13d, %ebx
     2c3: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x2ca <trusted_x86_x86_sim_xdp+0x2ca>
		00000000000002c6:  R_X86_64_REX_GOTPCRELX	perf_progs-0x4
     2ca: 4c 89 f7                     	movq	%r14, %rdi
     2cd: 89 da                        	movl	%ebx, %edx
     2cf: e8 00 00 00 00               	callq	0x2d4 <trusted_x86_x86_sim_xdp+0x2d4>
		00000000000002d0:  R_X86_64_PLT32	bpf_tail_call-0x4
     2d4: b8 ff ff ff ff               	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     2d9: 48 81 c4 c8 01 00 00         	addq	$0x1c8, %rsp            # imm = 0x1C8
     2e0: 5b                           	popq	%rbx
     2e1: 41 5c                        	popq	%r12
     2e3: 41 5d                        	popq	%r13
     2e5: 41 5e                        	popq	%r14
     2e7: 41 5f                        	popq	%r15
     2e9: 5d                           	popq	%rbp
     2ea: c3                           	retq
     2eb: 48 3b 0d 00 00 00 00         	cmpq	(%rip), %rcx            # 0x2f2 <trusted_x86_x86_sim_xdp+0x2f2>
		00000000000002ee:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
     2f2: 0f 85 a5 02 00 00            	jne	0x59d <trusted_x86_x86_sim_xdp+0x59d>
     2f8: e8 00 00 00 00               	callq	0x2fd <trusted_x86_x86_sim_xdp+0x2fd>
		00000000000002f9:  R_X86_64_PLT32	.text+0x12c
     2fd: 49 89 c4                     	movq	%rax, %r12
     300: 48 85 c0                     	testq	%rax, %rax
     303: 0f 85 02 fe ff ff            	jne	0x10b <trusted_x86_x86_sim_xdp+0x10b>
     309: e9 c9 fd ff ff               	jmp	0xd7 <trusted_x86_x86_sim_xdp+0xd7>
     30e: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
     313: 8d 48 01                     	leal	0x1(%rax), %ecx
     316: f6 c1 fe                     	testb	$-0x2, %cl
     319: 0f 84 94 02 00 00            	je	0x5b3 <trusted_x86_x86_sim_xdp+0x5b3>
     31f: 89 c0                        	movl	%eax, %eax
     321: 49 29 c5                     	subq	%rax, %r13
     324: 4b 8d 34 2c                  	leaq	(%r12,%r13), %rsi
     328: ba 01 00 00 00               	movl	$0x1, %edx
     32d: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     332: e8 00 00 00 00               	callq	0x337 <trusted_x86_x86_sim_xdp+0x337>
		0000000000000333:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     337: 85 c0                        	testl	%eax, %eax
     339: 79 05                        	jns	0x340 <trusted_x86_x86_sim_xdp+0x340>
     33b: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
     340: 85 c0                        	testl	%eax, %eax
     342: 0f 85 75 fe ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
     348: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
     34d: 8d 48 01                     	leal	0x1(%rax), %ecx
     350: f6 c1 fe                     	testb	$-0x2, %cl
     353: 0f 84 5a 02 00 00            	je	0x5b3 <trusted_x86_x86_sim_xdp+0x5b3>
     359: 89 c0                        	movl	%eax, %eax
     35b: 49 29 c5                     	subq	%rax, %r13
     35e: 4b 8d 34 2c                  	leaq	(%r12,%r13), %rsi
     362: ba 01 00 00 00               	movl	$0x1, %edx
     367: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     36c: e8 00 00 00 00               	callq	0x371 <trusted_x86_x86_sim_xdp+0x371>
		000000000000036d:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     371: 85 c0                        	testl	%eax, %eax
     373: 79 05                        	jns	0x37a <trusted_x86_x86_sim_xdp+0x37a>
     375: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
     37a: 85 c0                        	testl	%eax, %eax
     37c: 0f 85 3b fe ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
     382: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
     387: 8d 48 01                     	leal	0x1(%rax), %ecx
     38a: f6 c1 fe                     	testb	$-0x2, %cl
     38d: 0f 84 20 02 00 00            	je	0x5b3 <trusted_x86_x86_sim_xdp+0x5b3>
     393: 89 c0                        	movl	%eax, %eax
     395: 49 29 c5                     	subq	%rax, %r13
     398: 4b 8d 34 2c                  	leaq	(%r12,%r13), %rsi
     39c: ba 01 00 00 00               	movl	$0x1, %edx
     3a1: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     3a6: e8 00 00 00 00               	callq	0x3ab <trusted_x86_x86_sim_xdp+0x3ab>
		00000000000003a7:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     3ab: 85 c0                        	testl	%eax, %eax
     3ad: 79 05                        	jns	0x3b4 <trusted_x86_x86_sim_xdp+0x3b4>
     3af: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
     3b4: 85 c0                        	testl	%eax, %eax
     3b6: 0f 85 01 fe ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
     3bc: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
     3c1: 8d 48 01                     	leal	0x1(%rax), %ecx
     3c4: f6 c1 fe                     	testb	$-0x2, %cl
     3c7: 0f 84 e6 01 00 00            	je	0x5b3 <trusted_x86_x86_sim_xdp+0x5b3>
     3cd: 89 c0                        	movl	%eax, %eax
     3cf: 49 29 c5                     	subq	%rax, %r13
     3d2: 4b 8d 34 2c                  	leaq	(%r12,%r13), %rsi
     3d6: ba 01 00 00 00               	movl	$0x1, %edx
     3db: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     3e0: e8 00 00 00 00               	callq	0x3e5 <trusted_x86_x86_sim_xdp+0x3e5>
		00000000000003e1:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     3e5: 85 c0                        	testl	%eax, %eax
     3e7: 79 05                        	jns	0x3ee <trusted_x86_x86_sim_xdp+0x3ee>
     3e9: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
     3ee: 85 c0                        	testl	%eax, %eax
     3f0: 0f 85 c7 fd ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
     3f6: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
     3fb: 8d 48 01                     	leal	0x1(%rax), %ecx
     3fe: f6 c1 fe                     	testb	$-0x2, %cl
     401: 0f 84 ac 01 00 00            	je	0x5b3 <trusted_x86_x86_sim_xdp+0x5b3>
     407: 89 c0                        	movl	%eax, %eax
     409: 49 29 c5                     	subq	%rax, %r13
     40c: 4b 8d 34 2c                  	leaq	(%r12,%r13), %rsi
     410: ba 01 00 00 00               	movl	$0x1, %edx
     415: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     41a: e8 00 00 00 00               	callq	0x41f <trusted_x86_x86_sim_xdp+0x41f>
		000000000000041b:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     41f: 85 c0                        	testl	%eax, %eax
     421: 79 05                        	jns	0x428 <trusted_x86_x86_sim_xdp+0x428>
     423: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
     428: 85 c0                        	testl	%eax, %eax
     42a: 0f 85 8d fd ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
     430: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
     435: 8d 48 01                     	leal	0x1(%rax), %ecx
     438: f6 c1 fe                     	testb	$-0x2, %cl
     43b: 0f 84 72 01 00 00            	je	0x5b3 <trusted_x86_x86_sim_xdp+0x5b3>
     441: 89 c0                        	movl	%eax, %eax
     443: 49 29 c5                     	subq	%rax, %r13
     446: 4b 8d 34 2c                  	leaq	(%r12,%r13), %rsi
     44a: ba 01 00 00 00               	movl	$0x1, %edx
     44f: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     454: e8 00 00 00 00               	callq	0x459 <trusted_x86_x86_sim_xdp+0x459>
		0000000000000455:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     459: 85 c0                        	testl	%eax, %eax
     45b: 79 05                        	jns	0x462 <trusted_x86_x86_sim_xdp+0x462>
     45d: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
     462: 85 c0                        	testl	%eax, %eax
     464: 0f 85 53 fd ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
     46a: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
     46f: 8d 48 01                     	leal	0x1(%rax), %ecx
     472: f6 c1 fe                     	testb	$-0x2, %cl
     475: 0f 84 38 01 00 00            	je	0x5b3 <trusted_x86_x86_sim_xdp+0x5b3>
     47b: 89 c0                        	movl	%eax, %eax
     47d: 49 29 c5                     	subq	%rax, %r13
     480: 4b 8d 34 2c                  	leaq	(%r12,%r13), %rsi
     484: ba 01 00 00 00               	movl	$0x1, %edx
     489: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     48e: e8 00 00 00 00               	callq	0x493 <trusted_x86_x86_sim_xdp+0x493>
		000000000000048f:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     493: 85 c0                        	testl	%eax, %eax
     495: 79 05                        	jns	0x49c <trusted_x86_x86_sim_xdp+0x49c>
     497: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
     49c: 85 c0                        	testl	%eax, %eax
     49e: 0f 85 19 fd ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
     4a4: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
     4a9: 8d 48 01                     	leal	0x1(%rax), %ecx
     4ac: f6 c1 fe                     	testb	$-0x2, %cl
     4af: 0f 84 fe 00 00 00            	je	0x5b3 <trusted_x86_x86_sim_xdp+0x5b3>
     4b5: 89 c0                        	movl	%eax, %eax
     4b7: 49 29 c5                     	subq	%rax, %r13
     4ba: 4b 8d 34 2c                  	leaq	(%r12,%r13), %rsi
     4be: ba 01 00 00 00               	movl	$0x1, %edx
     4c3: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     4c8: e8 00 00 00 00               	callq	0x4cd <trusted_x86_x86_sim_xdp+0x4cd>
		00000000000004c9:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     4cd: 85 c0                        	testl	%eax, %eax
     4cf: 79 05                        	jns	0x4d6 <trusted_x86_x86_sim_xdp+0x4d6>
     4d1: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
     4d6: 85 c0                        	testl	%eax, %eax
     4d8: 0f 85 df fc ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
     4de: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
     4e3: 8d 48 01                     	leal	0x1(%rax), %ecx
     4e6: f6 c1 fe                     	testb	$-0x2, %cl
     4e9: 0f 84 c4 00 00 00            	je	0x5b3 <trusted_x86_x86_sim_xdp+0x5b3>
     4ef: 89 c0                        	movl	%eax, %eax
     4f1: 49 29 c5                     	subq	%rax, %r13
     4f4: 4b 8d 34 2c                  	leaq	(%r12,%r13), %rsi
     4f8: ba 01 00 00 00               	movl	$0x1, %edx
     4fd: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     502: e8 00 00 00 00               	callq	0x507 <trusted_x86_x86_sim_xdp+0x507>
		0000000000000503:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     507: 85 c0                        	testl	%eax, %eax
     509: 79 05                        	jns	0x510 <trusted_x86_x86_sim_xdp+0x510>
     50b: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
     510: 85 c0                        	testl	%eax, %eax
     512: 0f 85 a5 fc ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
     518: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
     51d: 8d 48 01                     	leal	0x1(%rax), %ecx
     520: f6 c1 fe                     	testb	$-0x2, %cl
     523: 0f 84 8a 00 00 00            	je	0x5b3 <trusted_x86_x86_sim_xdp+0x5b3>
     529: 89 c0                        	movl	%eax, %eax
     52b: 49 29 c5                     	subq	%rax, %r13
     52e: 4b 8d 34 2c                  	leaq	(%r12,%r13), %rsi
     532: ba 01 00 00 00               	movl	$0x1, %edx
     537: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     53c: e8 00 00 00 00               	callq	0x541 <trusted_x86_x86_sim_xdp+0x541>
		000000000000053d:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     541: 85 c0                        	testl	%eax, %eax
     543: 79 05                        	jns	0x54a <trusted_x86_x86_sim_xdp+0x54a>
     545: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
     54a: 85 c0                        	testl	%eax, %eax
     54c: 0f 85 6b fc ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
     552: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
     557: 8d 48 01                     	leal	0x1(%rax), %ecx
     55a: f6 c1 fe                     	testb	$-0x2, %cl
     55d: 74 54                        	je	0x5b3 <trusted_x86_x86_sim_xdp+0x5b3>
     55f: 89 c0                        	movl	%eax, %eax
     561: 49 29 c5                     	subq	%rax, %r13
     564: 4d 01 ec                     	addq	%r13, %r12
     567: ba 01 00 00 00               	movl	$0x1, %edx
     56c: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     571: 4c 89 e6                     	movq	%r12, %rsi
     574: e8 00 00 00 00               	callq	0x579 <trusted_x86_x86_sim_xdp+0x579>
		0000000000000575:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     579: 85 c0                        	testl	%eax, %eax
     57b: 79 05                        	jns	0x582 <trusted_x86_x86_sim_xdp+0x582>
     57d: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
     582: 85 c0                        	testl	%eax, %eax
     584: 0f 85 33 fc ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
     58a: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
     58f: 8d 48 01                     	leal	0x1(%rax), %ecx
     592: f6 c1 fe                     	testb	$-0x2, %cl
     595: 0f 85 22 fc ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
     59b: eb 16                        	jmp	0x5b3 <trusted_x86_x86_sim_xdp+0x5b3>
     59d: e8 00 00 00 00               	callq	0x5a2 <trusted_x86_x86_sim_xdp+0x5a2>
		000000000000059e:  R_X86_64_PLT32	.text+0x1dc
     5a2: 49 89 c4                     	movq	%rax, %r12
     5a5: 48 85 c0                     	testq	%rax, %rax
     5a8: 0f 85 5d fb ff ff            	jne	0x10b <trusted_x86_x86_sim_xdp+0x10b>
     5ae: e9 24 fb ff ff               	jmp	0xd7 <trusted_x86_x86_sim_xdp+0xd7>
     5b3: 85 c0                        	testl	%eax, %eax
     5b5: 0f 85 02 fc ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
     5bb: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
     5c0: 48 89 c8                     	movq	%rcx, %rax
     5c3: 0f b6 40 20                  	movzbl	0x20(%rax), %eax
     5c7: c4 c2 f9 f7 c5               	shlxq	%rax, %r13, %rax
     5cc: 48 89 ca                     	movq	%rcx, %rdx
     5cf: 48 89 d9                     	movq	%rbx, %rcx
     5d2: 48 03 81 20 0f 00 00         	addq	0xf20(%rcx), %rax
     5d9: 48 89 d1                     	movq	%rdx, %rcx
     5dc: 0f b6 71 1b                  	movzbl	0x1b(%rcx), %esi
     5e0: 48 01 c6                     	addq	%rax, %rsi
     5e3: 48 89 b4 24 c8 00 00 00      	movq	%rsi, 0xc8(%rsp)
     5eb: 0f 84 d8 fb ff ff            	je	0x1c9 <trusted_x86_x86_sim_xdp+0x1c9>
     5f1: 4c 8d a3 80 0f 00 00         	leaq	0xf80(%rbx), %r12
     5f8: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
     5fd: 4c 89 e7                     	movq	%r12, %rdi
     600: e8 00 00 00 00               	callq	0x605 <trusted_x86_x86_sim_xdp+0x605>
		0000000000000601:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     605: 49 89 c5                     	movq	%rax, %r13
     608: 45 85 ed                     	testl	%r13d, %r13d
     60b: 79 0f                        	jns	0x61c <trusted_x86_x86_sim_xdp+0x61c>
     60d: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
     612: 4c 89 e7                     	movq	%r12, %rdi
     615: 31 f6                        	xorl	%esi, %esi
     617: e8 00 00 00 00               	callq	0x61c <trusted_x86_x86_sim_xdp+0x61c>
		0000000000000618:  R_X86_64_PLT32	memset-0x4
     61c: 45 85 ed                     	testl	%r13d, %r13d
     61f: 74 4d                        	je	0x66e <trusted_x86_x86_sim_xdp+0x66e>
     621: c7 44 24 58 2c 00 00 00      	movl	$0x2c, 0x58(%rsp)
     629: bd eb 03 00 00               	movl	$0x3eb, %ebp            # imm = 0x3EB
     62e: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x635 <trusted_x86_x86_sim_xdp+0x635>
		0000000000000631:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     635: 83 79 44 2d                  	cmpl	$0x2d, 0x44(%rcx)
     639: 0f 82 cd fb ff ff            	jb	0x20c <trusted_x86_x86_sim_xdp+0x20c>
     63f: b8 2c 00 00 00               	movl	$0x2c, %eax
     644: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
     64a: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
     652: e8 00 00 00 00               	callq	0x657 <trusted_x86_x86_sim_xdp+0x657>
		0000000000000653:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     657: 48 85 c0                     	testq	%rax, %rax
     65a: 0f 84 ac fb ff ff            	je	0x20c <trusted_x86_x86_sim_xdp+0x20c>
     660: 48 89 c1                     	movq	%rax, %rcx
     663: 48 8b 09                     	movq	(%rcx), %rcx
     666: 48 ff c1                     	incq	%rcx
     669: e9 9b fb ff ff               	jmp	0x209 <trusted_x86_x86_sim_xdp+0x209>
     66e: 4c 8b 6c 24 10               	movq	0x10(%rsp), %r13
     673: 4c 89 e8                     	movq	%r13, %rax
     676: 0f b7 40 10                  	movzwl	0x10(%rax), %eax
     67a: 0f b7 c0                     	movzwl	%ax, %eax
     67d: 3d f8 01 00 00               	cmpl	$0x1f8, %eax            # imm = 0x1F8
     682: 0f 87 56 33 00 00            	ja	0x39de <trusted_x86_x86_sim_xdp+0x39de>
     688: 4c 89 e9                     	movq	%r13, %rcx
     68b: 0f b7 49 12                  	movzwl	0x12(%rcx), %ecx
     68f: 0f b7 c9                     	movzwl	%cx, %ecx
     692: 81 f9 fc 01 00 00            	cmpl	$0x1fc, %ecx            # imm = 0x1FC
     698: 0f 87 40 33 00 00            	ja	0x39de <trusted_x86_x86_sim_xdp+0x39de>
     69e: 4c 89 ea                     	movq	%r13, %rdx
     6a1: 0f b7 52 14                  	movzwl	0x14(%rdx), %edx
     6a5: 0f b7 d2                     	movzwl	%dx, %edx
     6a8: 81 fa f8 01 00 00            	cmpl	$0x1f8, %edx            # imm = 0x1F8
     6ae: 0f 87 2a 33 00 00            	ja	0x39de <trusted_x86_x86_sim_xdp+0x39de>
     6b4: 4c 89 ee                     	movq	%r13, %rsi
     6b7: 0f b6 76 17                  	movzbl	0x17(%rsi), %esi
     6bb: 40 0f b6 f6                  	movzbl	%sil, %esi
     6bf: 4c 01 e6                     	addq	%r12, %rsi
     6c2: 48 8b 36                     	movq	(%rsi), %rsi
     6c5: 48 89 b4 24 d0 00 00 00      	movq	%rsi, 0xd0(%rsp)
     6cd: 4c 89 ee                     	movq	%r13, %rsi
     6d0: 0f b6 76 18                  	movzbl	0x18(%rsi), %esi
     6d4: 40 0f b6 f6                  	movzbl	%sil, %esi
     6d8: 4c 01 e6                     	addq	%r12, %rsi
     6db: 48 8b 36                     	movq	(%rsi), %rsi
     6de: 48 89 b4 24 d8 00 00 00      	movq	%rsi, 0xd8(%rsp)
     6e6: 4c 89 ee                     	movq	%r13, %rsi
     6e9: 0f b6 76 1a                  	movzbl	0x1a(%rsi), %esi
     6ed: 40 0f b6 f6                  	movzbl	%sil, %esi
     6f1: 4c 01 e6                     	addq	%r12, %rsi
     6f4: 8b 36                        	movl	(%rsi), %esi
     6f6: c1 e6 03                     	shll	$0x3, %esi
     6f9: 89 b4 24 f0 00 00 00         	movl	%esi, 0xf0(%rsp)
     700: 4c 89 ee                     	movq	%r13, %rsi
     703: 0f b6 76 19                  	movzbl	0x19(%rsi), %esi
     707: 40 0f b6 f6                  	movzbl	%sil, %esi
     70b: 4c 01 e6                     	addq	%r12, %rsi
     70e: 0f b7 36                     	movzwl	(%rsi), %esi
     711: 66 89 b4 24 f8 00 00 00      	movw	%si, 0xf8(%rsp)
     719: 4c 01 e1                     	addq	%r12, %rcx
     71c: 8b 09                        	movl	(%rcx), %ecx
     71e: 89 8c 24 f4 00 00 00         	movl	%ecx, 0xf4(%rsp)
     725: 4c 01 e2                     	addq	%r12, %rdx
     728: 8b 0a                        	movl	(%rdx), %ecx
     72a: 89 8c 24 ec 00 00 00         	movl	%ecx, 0xec(%rsp)
     731: 48 8d bc 24 e8 00 00 00      	leaq	0xe8(%rsp), %rdi
     739: 4c 01 e0                     	addq	%r12, %rax
     73c: 48 8b 00                     	movq	(%rax), %rax
     73f: 48 89 84 24 e0 00 00 00      	movq	%rax, 0xe0(%rsp)
     747: 4c 89 e8                     	movq	%r13, %rax
     74a: 0f b6 40 16                  	movzbl	0x16(%rax), %eax
     74e: 0f b6 c0                     	movzbl	%al, %eax
     751: 4c 01 e0                     	addq	%r12, %rax
     754: 48 8b 30                     	movq	(%rax), %rsi
     757: ba 04 00 00 00               	movl	$0x4, %edx
     75c: e8 00 00 00 00               	callq	0x761 <trusted_x86_x86_sim_xdp+0x761>
		000000000000075d:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     761: 85 c0                        	testl	%eax, %eax
     763: 79 0b                        	jns	0x770 <trusted_x86_x86_sim_xdp+0x770>
     765: c7 84 24 e8 00 00 00 00 00 00 00     	movl	$0x0, 0xe8(%rsp)
     770: 85 c0                        	testl	%eax, %eax
     772: 0f 85 a9 fe ff ff            	jne	0x621 <trusted_x86_x86_sim_xdp+0x621>
     778: 4c 89 e8                     	movq	%r13, %rax
     77b: 0f b6 50 21                  	movzbl	0x21(%rax), %edx
     77f: 48 8b 84 24 c8 00 00 00      	movq	0xc8(%rsp), %rax
     787: 48 8b 8c 24 d0 00 00 00      	movq	0xd0(%rsp), %rcx
     78f: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
     794: 84 d2                        	testb	%dl, %dl
     796: 74 1f                        	je	0x7b7 <trusted_x86_x86_sim_xdp+0x7b7>
     798: 89 c9                        	movl	%ecx, %ecx
     79a: 48 01 c1                     	addq	%rax, %rcx
     79d: 48 89 8c 24 d0 00 00 00      	movq	%rcx, 0xd0(%rsp)
     7a5: 8b b4 24 d8 00 00 00         	movl	0xd8(%rsp), %esi
     7ac: 48 01 c6                     	addq	%rax, %rsi
     7af: 48 89 b4 24 d8 00 00 00      	movq	%rsi, 0xd8(%rsp)
     7b7: 4c 8b 6c 24 20               	movq	0x20(%rsp), %r13
     7bc: 8b 84 24 e8 00 00 00         	movl	0xe8(%rsp), %eax
     7c3: 44 89 f6                     	movl	%r14d, %esi
     7c6: 29 ce                        	subl	%ecx, %esi
     7c8: 48 89 b4 24 c0 00 00 00      	movq	%rsi, 0xc0(%rsp)
     7d0: 3d 6d 61 74 69               	cmpl	$0x6974616d, %eax       # imm = 0x6974616D
     7d5: 7f 18                        	jg	0x7ef <trusted_x86_x86_sim_xdp+0x7ef>
     7d7: 3d 76 74 61 62               	cmpl	$0x62617476, %eax       # imm = 0x62617476
     7dc: 0f 85 e9 00 00 00            	jne	0x8cb <trusted_x86_x86_sim_xdp+0x8cb>
     7e2: c7 44 24 38 01 00 00 00      	movl	$0x1, 0x38(%rsp)
     7ea: e9 d2 00 00 00               	jmp	0x8c1 <trusted_x86_x86_sim_xdp+0x8c1>
     7ef: 3d 6e 6d 65 74               	cmpl	$0x74656d6e, %eax       # imm = 0x74656D6E
     7f4: 74 0b                        	je	0x801 <trusted_x86_x86_sim_xdp+0x801>
     7f6: 3d 6e 61 74 69               	cmpl	$0x6974616e, %eax       # imm = 0x6974616E
     7fb: 0f 85 9f 01 00 00            	jne	0x9a0 <trusted_x86_x86_sim_xdp+0x9a0>
     801: 48 8b 84 24 e0 00 00 00      	movq	0xe0(%rsp), %rax
     809: 89 c6                        	movl	%eax, %esi
     80b: 48 03 74 24 48               	addq	0x48(%rsp), %rsi
     810: 48 89 df                     	movq	%rbx, %rdi
     813: 44 0f b6 af 30 0f 00 00      	movzbl	0xf30(%rdi), %r13d
     81b: 84 d2                        	testb	%dl, %dl
     81d: 8b 94 24 f4 00 00 00         	movl	0xf4(%rsp), %edx
     824: 48 89 54 24 40               	movq	%rdx, 0x40(%rsp)
     829: 48 0f 44 f0                  	cmoveq	%rax, %rsi
     82d: 49 39 f6                     	cmpq	%rsi, %r14
     830: 75 54                        	jne	0x886 <trusted_x86_x86_sim_xdp+0x886>
     832: 8b b4 24 ec 00 00 00         	movl	0xec(%rsp), %esi
     839: 48 01 ee                     	addq	%rbp, %rsi
     83c: ba 08 00 00 00               	movl	$0x8, %edx
     841: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     846: e8 00 00 00 00               	callq	0x84b <trusted_x86_x86_sim_xdp+0x84b>
		0000000000000847:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     84b: 85 c0                        	testl	%eax, %eax
     84d: 79 09                        	jns	0x858 <trusted_x86_x86_sim_xdp+0x858>
     84f: 48 c7 44 24 58 00 00 00 00   	movq	$0x0, 0x58(%rsp)
     858: 48 8b 8c 24 d0 00 00 00      	movq	0xd0(%rsp), %rcx
     860: 85 c0                        	testl	%eax, %eax
     862: 75 22                        	jne	0x886 <trusted_x86_x86_sim_xdp+0x886>
     864: 48 8b 74 24 58               	movq	0x58(%rsp), %rsi
     869: 48 39 ce                     	cmpq	%rcx, %rsi
     86c: 72 18                        	jb	0x886 <trusted_x86_x86_sim_xdp+0x886>
     86e: 48 3b b4 24 d8 00 00 00      	cmpq	0xd8(%rsp), %rsi
     876: 73 0e                        	jae	0x886 <trusted_x86_x86_sim_xdp+0x886>
     878: 89 f0                        	movl	%esi, %eax
     87a: 29 c8                        	subl	%ecx, %eax
     87c: 48 89 84 24 c0 00 00 00      	movq	%rax, 0xc0(%rsp)
     884: eb 03                        	jmp	0x889 <trusted_x86_x86_sim_xdp+0x889>
     886: 4c 89 f6                     	movq	%r14, %rsi
     889: 0f b7 94 24 f8 00 00 00      	movzwl	0xf8(%rsp), %edx
     891: 48 01 ca                     	addq	%rcx, %rdx
     894: 48 39 f2                     	cmpq	%rsi, %rdx
     897: 0f 86 24 01 00 00            	jbe	0x9c1 <trusted_x86_x86_sim_xdp+0x9c1>
     89d: 48 83 c2 fc                  	addq	$-0x4, %rdx
     8a1: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
     8a7: 83 c9 03                     	orl	$0x3, %ecx
     8aa: 89 4c 24 38                  	movl	%ecx, 0x38(%rsp)
     8ae: 4c 8b 6c 24 20               	movq	0x20(%rsp), %r13
     8b3: 48 8b 44 24 40               	movq	0x40(%rsp), %rax
     8b8: 48 39 f2                     	cmpq	%rsi, %rdx
     8bb: 0f 86 73 01 00 00            	jbe	0xa34 <trusted_x86_x86_sim_xdp+0xa34>
     8c1: b9 08 00 00 00               	movl	$0x8, %ecx
     8c6: e9 6e 01 00 00               	jmp	0xa39 <trusted_x86_x86_sim_xdp+0xa39>
     8cb: 3d 49 6e 74 65               	cmpl	$0x65746e49, %eax       # imm = 0x65746E49
     8d0: 0f 85 ca 00 00 00            	jne	0x9a0 <trusted_x86_x86_sim_xdp+0x9a0>
     8d6: 49 39 ed                     	cmpq	%rbp, %r13
     8d9: 0f 82 ee 06 00 00            	jb	0xfcd <trusted_x86_x86_sim_xdp+0xfcd>
     8df: 48 81 c5 00 10 00 00         	addq	$0x1000, %rbp           # imm = 0x1000
     8e6: 49 39 ed                     	cmpq	%rbp, %r13
     8e9: 0f 83 de 06 00 00            	jae	0xfcd <trusted_x86_x86_sim_xdp+0xfcd>
     8ef: 48 8b 74 24 20               	movq	0x20(%rsp), %rsi
     8f4: 48 83 c6 b0                  	addq	$-0x50, %rsi
     8f8: ba 60 00 00 00               	movl	$0x60, %edx
     8fd: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     902: e8 00 00 00 00               	callq	0x907 <trusted_x86_x86_sim_xdp+0x907>
		0000000000000903:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     907: 85 c0                        	testl	%eax, %eax
     909: 79 64                        	jns	0x96f <trusted_x86_x86_sim_xdp+0x96f>
     90b: 48 8d 4c 24 58               	leaq	0x58(%rsp), %rcx
     910: 48 c7 41 58 00 00 00 00      	movq	$0x0, 0x58(%rcx)
     918: 48 c7 41 50 00 00 00 00      	movq	$0x0, 0x50(%rcx)
     920: 48 c7 41 48 00 00 00 00      	movq	$0x0, 0x48(%rcx)
     928: 48 c7 41 40 00 00 00 00      	movq	$0x0, 0x40(%rcx)
     930: 48 c7 41 38 00 00 00 00      	movq	$0x0, 0x38(%rcx)
     938: 48 c7 41 30 00 00 00 00      	movq	$0x0, 0x30(%rcx)
     940: 48 c7 41 28 00 00 00 00      	movq	$0x0, 0x28(%rcx)
     948: 48 c7 41 20 00 00 00 00      	movq	$0x0, 0x20(%rcx)
     950: 48 c7 41 18 00 00 00 00      	movq	$0x0, 0x18(%rcx)
     958: 48 c7 41 10 00 00 00 00      	movq	$0x0, 0x10(%rcx)
     960: 48 c7 41 08 00 00 00 00      	movq	$0x0, 0x8(%rcx)
     968: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
     96f: 85 c0                        	testl	%eax, %eax
     971: 0f 85 56 06 00 00            	jne	0xfcd <trusted_x86_x86_sim_xdp+0xfcd>
     977: 48 89 d8                     	movq	%rbx, %rax
     97a: 83 b8 c0 02 00 00 00         	cmpl	$0x0, 0x2c0(%rax)
     981: 0f 84 df 05 00 00            	je	0xf66 <trusted_x86_x86_sim_xdp+0xf66>
     987: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
     98c: 80 78 1f 00                  	cmpb	$0x0, 0x1f(%rax)
     990: 0f 84 dc 05 00 00            	je	0xf72 <trusted_x86_x86_sim_xdp+0xf72>
     996: 4c 8b 6c 24 68               	movq	0x68(%rsp), %r13
     99b: e9 d7 05 00 00               	jmp	0xf77 <trusted_x86_x86_sim_xdp+0xf77>
     9a0: 8b 8c 24 f0 00 00 00         	movl	0xf0(%rsp), %ecx
     9a7: c7 44 24 38 00 00 00 00      	movl	$0x0, 0x38(%rsp)
     9af: 85 c9                        	testl	%ecx, %ecx
     9b1: 0f 85 89 00 00 00            	jne	0xa40 <trusted_x86_x86_sim_xdp+0xa40>
     9b7: b9 10 00 00 00               	movl	$0x10, %ecx
     9bc: 4c 89 ed                     	movq	%r13, %rbp
     9bf: eb 78                        	jmp	0xa39 <trusted_x86_x86_sim_xdp+0xa39>
     9c1: 45 84 ed                     	testb	%r13b, %r13b
     9c4: 75 34                        	jne	0x9fa <trusted_x86_x86_sim_xdp+0x9fa>
     9c6: 48 ff ce                     	decq	%rsi
     9c9: ba 0e 00 00 00               	movl	$0xe, %edx
     9ce: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     9d3: e8 00 00 00 00               	callq	0x9d8 <trusted_x86_x86_sim_xdp+0x9d8>
		00000000000009d4:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     9d8: 85 c0                        	testl	%eax, %eax
     9da: 79 14                        	jns	0x9f0 <trusted_x86_x86_sim_xdp+0x9f0>
     9dc: 48 8d 4c 24 58               	leaq	0x58(%rsp), %rcx
     9e1: 48 c7 41 06 00 00 00 00      	movq	$0x0, 0x6(%rcx)
     9e9: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
     9f0: 85 c0                        	testl	%eax, %eax
     9f2: 0f 84 8f 03 00 00            	je	0xd87 <trusted_x86_x86_sim_xdp+0xd87>
     9f8: 31 c9                        	xorl	%ecx, %ecx
     9fa: 8b b4 24 f0 00 00 00         	movl	0xf0(%rsp), %esi
     a01: 48 01 ee                     	addq	%rbp, %rsi
     a04: 4c 8b 6c 24 20               	movq	0x20(%rsp), %r13
     a09: 49 39 ed                     	cmpq	%rbp, %r13
     a0c: 0f 82 df 00 00 00            	jb	0xaf1 <trusted_x86_x86_sim_xdp+0xaf1>
     a12: 48 8d 46 30                  	leaq	0x30(%rsi), %rax
     a16: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
     a1c: 83 c9 03                     	orl	$0x3, %ecx
     a1f: 89 4c 24 38                  	movl	%ecx, 0x38(%rsp)
     a23: 49 39 c5                     	cmpq	%rax, %r13
     a26: 0f 83 c5 00 00 00            	jae	0xaf1 <trusted_x86_x86_sim_xdp+0xaf1>
     a2c: 4c 89 ed                     	movq	%r13, %rbp
     a2f: 48 8b 44 24 40               	movq	0x40(%rsp), %rax
     a34: b9 10 00 00 00               	movl	$0x10, %ecx
     a39: 89 8c 24 f0 00 00 00         	movl	%ecx, 0xf0(%rsp)
     a40: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
     a45: 41 89 ce                     	movl	%ecx, %r14d
     a48: 49 01 ee                     	addq	%rbp, %r14
     a4b: 49 8d 76 f0                  	leaq	-0x10(%r14), %rsi
     a4f: ba 10 00 00 00               	movl	$0x10, %edx
     a54: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     a59: e8 00 00 00 00               	callq	0xa5e <trusted_x86_x86_sim_xdp+0xa5e>
		0000000000000a5a:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     a5e: 85 c0                        	testl	%eax, %eax
     a60: 79 14                        	jns	0xa76 <trusted_x86_x86_sim_xdp+0xa76>
     a62: 48 8d 44 24 58               	leaq	0x58(%rsp), %rax
     a67: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
     a6f: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
     a76: 83 bc 24 f0 00 00 00 10      	cmpl	$0x10, 0xf0(%rsp)
     a7e: 72 05                        	jb	0xa85 <trusted_x86_x86_sim_xdp+0xa85>
     a80: 4c 8b 6c 24 58               	movq	0x58(%rsp), %r13
     a85: 48 8b 6c 24 60               	movq	0x60(%rsp), %rbp
     a8a: 8b 4c 24 40                  	movl	0x40(%rsp), %ecx
     a8e: 48 89 d8                     	movq	%rbx, %rax
     a91: 8b 80 c0 02 00 00            	movl	0x2c0(%rax), %eax
     a97: 83 f8 7f                     	cmpl	$0x7f, %eax
     a9a: 0f 82 00 06 00 00            	jb	0x10a0 <trusted_x86_x86_sim_xdp+0x10a0>
     aa0: c7 44 24 58 02 00 00 00      	movl	$0x2, 0x58(%rsp)
     aa8: bd 02 00 00 00               	movl	$0x2, %ebp
     aad: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0xab4 <trusted_x86_x86_sim_xdp+0xab4>
		0000000000000ab0:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     ab4: 83 78 44 03                  	cmpl	$0x3, 0x44(%rax)
     ab8: 0f 82 4e f7 ff ff            	jb	0x20c <trusted_x86_x86_sim_xdp+0x20c>
     abe: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0xac5 <trusted_x86_x86_sim_xdp+0xac5>
		0000000000000ac1:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     ac5: 8b 81 24 01 00 00            	movl	0x124(%rcx), %eax
     acb: 21 e8                        	andl	%ebp, %eax
     acd: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
     ad5: e8 00 00 00 00               	callq	0xada <trusted_x86_x86_sim_xdp+0xada>
		0000000000000ad6:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     ada: 48 85 c0                     	testq	%rax, %rax
     add: 0f 84 29 f7 ff ff            	je	0x20c <trusted_x86_x86_sim_xdp+0x20c>
     ae3: 48 89 c1                     	movq	%rax, %rcx
     ae6: 48 8b 09                     	movq	(%rcx), %rcx
     ae9: 48 ff c1                     	incq	%rcx
     aec: e9 18 f7 ff ff               	jmp	0x209 <trusted_x86_x86_sim_xdp+0x209>
     af1: 48 89 74 24 38               	movq	%rsi, 0x38(%rsp)
     af6: 48 83 c6 f8                  	addq	$-0x8, %rsi
     afa: ba 30 00 00 00               	movl	$0x30, %edx
     aff: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     b04: e8 00 00 00 00               	callq	0xb09 <trusted_x86_x86_sim_xdp+0xb09>
		0000000000000b05:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     b09: 85 c0                        	testl	%eax, %eax
     b0b: 79 34                        	jns	0xb41 <trusted_x86_x86_sim_xdp+0xb41>
     b0d: 48 8d 44 24 58               	leaq	0x58(%rsp), %rax
     b12: 48 c7 40 28 00 00 00 00      	movq	$0x0, 0x28(%rax)
     b1a: 48 c7 40 20 00 00 00 00      	movq	$0x0, 0x20(%rax)
     b22: 48 c7 40 18 00 00 00 00      	movq	$0x0, 0x18(%rax)
     b2a: 48 c7 40 10 00 00 00 00      	movq	$0x0, 0x10(%rax)
     b32: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
     b3a: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
     b41: 49 be 00 00 00 00 00 00 00 ff	movabsq	$-0x100000000000000, %r14 # imm = 0xFF00000000000000
     b4b: 48 89 d8                     	movq	%rbx, %rax
     b4e: 8b 00                        	movl	(%rax), %eax
     b50: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
     b58: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
     b5e: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
     b63: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
     b6a: 4c 8b 2d 00 00 00 00         	movq	(%rip), %r13            # 0xb71 <trusted_x86_x86_sim_xdp+0xb71>
		0000000000000b6d:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
     b71: 4c 3b 2d 00 00 00 00         	cmpq	(%rip), %r13            # 0xb78 <trusted_x86_x86_sim_xdp+0xb78>
		0000000000000b74:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
     b78: 0f 94 c0                     	sete	%al
     b7b: 4c 3b 2d 00 00 00 00         	cmpq	(%rip), %r13            # 0xb82 <trusted_x86_x86_sim_xdp+0xb82>
		0000000000000b7e:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     b82: 40 0f 94 c5                  	sete	%bpl
     b86: 40 08 c5                     	orb	%al, %bpl
     b89: 40 80 fd 01                  	cmpb	$0x1, %bpl
     b8d: 75 20                        	jne	0xbaf <trusted_x86_x86_sim_xdp+0xbaf>
     b8f: 8b 44 24 28                  	movl	0x28(%rsp), %eax
     b93: 41 3b 45 44                  	cmpl	0x44(%r13), %eax
     b97: 73 45                        	jae	0xbde <trusted_x86_x86_sim_xdp+0xbde>
     b99: 41 23 85 24 01 00 00         	andl	0x124(%r13), %eax
     ba0: 49 8b bc c5 30 01 00 00      	movq	0x130(%r13,%rax,8), %rdi
     ba8: e8 00 00 00 00               	callq	0xbad <trusted_x86_x86_sim_xdp+0xbad>
		0000000000000ba9:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     bad: eb 0a                        	jmp	0xbb9 <trusted_x86_x86_sim_xdp+0xbb9>
     baf: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
     bb4: e8 00 00 00 00               	callq	0xbb9 <trusted_x86_x86_sim_xdp+0xbb9>
		0000000000000bb5:  R_X86_64_PLT32	.text+0x7c
     bb9: 48 85 c0                     	testq	%rax, %rax
     bbc: 74 20                        	je	0xbde <trusted_x86_x86_sim_xdp+0xbde>
     bbe: 48 8b 40 08                  	movq	0x8(%rax), %rax
     bc2: 4c 21 f0                     	andq	%r14, %rax
     bc5: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
     bcf: 48 39 c8                     	cmpq	%rcx, %rax
     bd2: 75 0a                        	jne	0xbde <trusted_x86_x86_sim_xdp+0xbde>
     bd4: 4c 8b 74 24 38               	movq	0x38(%rsp), %r14
     bd9: e9 73 02 00 00               	jmp	0xe51 <trusted_x86_x86_sim_xdp+0xe51>
     bde: 48 89 d8                     	movq	%rbx, %rax
     be1: 8b 00                        	movl	(%rax), %eax
     be3: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
     beb: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
     bf1: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
     bf6: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
     bfd: 40 84 ed                     	testb	%bpl, %bpl
     c00: 74 20                        	je	0xc22 <trusted_x86_x86_sim_xdp+0xc22>
     c02: 8b 44 24 28                  	movl	0x28(%rsp), %eax
     c06: 41 3b 45 44                  	cmpl	0x44(%r13), %eax
     c0a: 73 49                        	jae	0xc55 <trusted_x86_x86_sim_xdp+0xc55>
     c0c: 41 23 85 24 01 00 00         	andl	0x124(%r13), %eax
     c13: 49 8b bc c5 30 01 00 00      	movq	0x130(%r13,%rax,8), %rdi
     c1b: e8 00 00 00 00               	callq	0xc20 <trusted_x86_x86_sim_xdp+0xc20>
		0000000000000c1c:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     c20: eb 0a                        	jmp	0xc2c <trusted_x86_x86_sim_xdp+0xc2c>
     c22: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
     c27: e8 00 00 00 00               	callq	0xc2c <trusted_x86_x86_sim_xdp+0xc2c>
		0000000000000c28:  R_X86_64_PLT32	.text+0x7c
     c2c: 48 85 c0                     	testq	%rax, %rax
     c2f: 74 24                        	je	0xc55 <trusted_x86_x86_sim_xdp+0xc55>
     c31: 48 8b 40 08                  	movq	0x8(%rax), %rax
     c35: 4c 21 f0                     	andq	%r14, %rax
     c38: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
     c42: 48 39 c8                     	cmpq	%rcx, %rax
     c45: 75 0e                        	jne	0xc55 <trusted_x86_x86_sim_xdp+0xc55>
     c47: 4c 8b 74 24 38               	movq	0x38(%rsp), %r14
     c4c: 49 83 c6 08                  	addq	$0x8, %r14
     c50: e9 fc 01 00 00               	jmp	0xe51 <trusted_x86_x86_sim_xdp+0xe51>
     c55: 48 89 d8                     	movq	%rbx, %rax
     c58: 8b 00                        	movl	(%rax), %eax
     c5a: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
     c62: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
     c68: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
     c6d: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
     c74: 40 84 ed                     	testb	%bpl, %bpl
     c77: 74 20                        	je	0xc99 <trusted_x86_x86_sim_xdp+0xc99>
     c79: 8b 44 24 28                  	movl	0x28(%rsp), %eax
     c7d: 41 3b 45 44                  	cmpl	0x44(%r13), %eax
     c81: 73 49                        	jae	0xccc <trusted_x86_x86_sim_xdp+0xccc>
     c83: 41 23 85 24 01 00 00         	andl	0x124(%r13), %eax
     c8a: 49 8b bc c5 30 01 00 00      	movq	0x130(%r13,%rax,8), %rdi
     c92: e8 00 00 00 00               	callq	0xc97 <trusted_x86_x86_sim_xdp+0xc97>
		0000000000000c93:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     c97: eb 0a                        	jmp	0xca3 <trusted_x86_x86_sim_xdp+0xca3>
     c99: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
     c9e: e8 00 00 00 00               	callq	0xca3 <trusted_x86_x86_sim_xdp+0xca3>
		0000000000000c9f:  R_X86_64_PLT32	.text+0x7c
     ca3: 48 85 c0                     	testq	%rax, %rax
     ca6: 74 24                        	je	0xccc <trusted_x86_x86_sim_xdp+0xccc>
     ca8: 48 8b 40 08                  	movq	0x8(%rax), %rax
     cac: 4c 21 f0                     	andq	%r14, %rax
     caf: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
     cb9: 48 39 c8                     	cmpq	%rcx, %rax
     cbc: 75 0e                        	jne	0xccc <trusted_x86_x86_sim_xdp+0xccc>
     cbe: 4c 8b 74 24 38               	movq	0x38(%rsp), %r14
     cc3: 49 83 c6 10                  	addq	$0x10, %r14
     cc7: e9 85 01 00 00               	jmp	0xe51 <trusted_x86_x86_sim_xdp+0xe51>
     ccc: 48 89 d8                     	movq	%rbx, %rax
     ccf: 8b 00                        	movl	(%rax), %eax
     cd1: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
     cd9: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
     cdf: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
     ce4: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
     ceb: 40 84 ed                     	testb	%bpl, %bpl
     cee: 74 20                        	je	0xd10 <trusted_x86_x86_sim_xdp+0xd10>
     cf0: 8b 44 24 28                  	movl	0x28(%rsp), %eax
     cf4: 41 3b 45 44                  	cmpl	0x44(%r13), %eax
     cf8: 73 49                        	jae	0xd43 <trusted_x86_x86_sim_xdp+0xd43>
     cfa: 41 23 85 24 01 00 00         	andl	0x124(%r13), %eax
     d01: 49 8b bc c5 30 01 00 00      	movq	0x130(%r13,%rax,8), %rdi
     d09: e8 00 00 00 00               	callq	0xd0e <trusted_x86_x86_sim_xdp+0xd0e>
		0000000000000d0a:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     d0e: eb 0a                        	jmp	0xd1a <trusted_x86_x86_sim_xdp+0xd1a>
     d10: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
     d15: e8 00 00 00 00               	callq	0xd1a <trusted_x86_x86_sim_xdp+0xd1a>
		0000000000000d16:  R_X86_64_PLT32	.text+0x7c
     d1a: 48 85 c0                     	testq	%rax, %rax
     d1d: 74 24                        	je	0xd43 <trusted_x86_x86_sim_xdp+0xd43>
     d1f: 48 8b 40 08                  	movq	0x8(%rax), %rax
     d23: 4c 21 f0                     	andq	%r14, %rax
     d26: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
     d30: 48 39 c8                     	cmpq	%rcx, %rax
     d33: 75 0e                        	jne	0xd43 <trusted_x86_x86_sim_xdp+0xd43>
     d35: 4c 8b 74 24 38               	movq	0x38(%rsp), %r14
     d3a: 49 83 c6 18                  	addq	$0x18, %r14
     d3e: e9 0e 01 00 00               	jmp	0xe51 <trusted_x86_x86_sim_xdp+0xe51>
     d43: 48 89 d8                     	movq	%rbx, %rax
     d46: 8b 00                        	movl	(%rax), %eax
     d48: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
     d50: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
     d56: 48 8b 44 24 78               	movq	0x78(%rsp), %rax
     d5b: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
     d62: 40 84 ed                     	testb	%bpl, %bpl
     d65: 74 48                        	je	0xdaf <trusted_x86_x86_sim_xdp+0xdaf>
     d67: 8b 44 24 28                  	movl	0x28(%rsp), %eax
     d6b: 41 3b 45 44                  	cmpl	0x44(%r13), %eax
     d6f: 73 6e                        	jae	0xddf <trusted_x86_x86_sim_xdp+0xddf>
     d71: 41 23 85 24 01 00 00         	andl	0x124(%r13), %eax
     d78: 49 8b bc c5 30 01 00 00      	movq	0x130(%r13,%rax,8), %rdi
     d80: e8 00 00 00 00               	callq	0xd85 <trusted_x86_x86_sim_xdp+0xd85>
		0000000000000d81:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     d85: eb 32                        	jmp	0xdb9 <trusted_x86_x86_sim_xdp+0xdb9>
     d87: 0f b6 74 24 59               	movzbl	0x59(%rsp), %esi
     d8c: 81 fe c3 00 00 00            	cmpl	$0xc3, %esi
     d92: 0f 85 22 01 00 00            	jne	0xeba <trusted_x86_x86_sim_xdp+0xeba>
     d98: c7 44 24 38 03 00 00 00      	movl	$0x3, 0x38(%rsp)
     da0: 4c 8b 6c 24 20               	movq	0x20(%rsp), %r13
     da5: 48 8b 44 24 40               	movq	0x40(%rsp), %rax
     daa: e9 12 fb ff ff               	jmp	0x8c1 <trusted_x86_x86_sim_xdp+0x8c1>
     daf: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
     db4: e8 00 00 00 00               	callq	0xdb9 <trusted_x86_x86_sim_xdp+0xdb9>
		0000000000000db5:  R_X86_64_PLT32	.text+0x7c
     db9: 48 85 c0                     	testq	%rax, %rax
     dbc: 74 21                        	je	0xddf <trusted_x86_x86_sim_xdp+0xddf>
     dbe: 48 8b 40 08                  	movq	0x8(%rax), %rax
     dc2: 4c 21 f0                     	andq	%r14, %rax
     dc5: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
     dcf: 48 39 c8                     	cmpq	%rcx, %rax
     dd2: 75 0b                        	jne	0xddf <trusted_x86_x86_sim_xdp+0xddf>
     dd4: 4c 8b 74 24 38               	movq	0x38(%rsp), %r14
     dd9: 49 83 c6 20                  	addq	$0x20, %r14
     ddd: eb 72                        	jmp	0xe51 <trusted_x86_x86_sim_xdp+0xe51>
     ddf: 48 89 d8                     	movq	%rbx, %rax
     de2: 8b 00                        	movl	(%rax), %eax
     de4: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
     dec: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
     df2: 48 8b 84 24 80 00 00 00      	movq	0x80(%rsp), %rax
     dfa: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
     e01: 40 84 ed                     	testb	%bpl, %bpl
     e04: 74 20                        	je	0xe26 <trusted_x86_x86_sim_xdp+0xe26>
     e06: 8b 44 24 28                  	movl	0x28(%rsp), %eax
     e0a: 41 3b 45 44                  	cmpl	0x44(%r13), %eax
     e0e: 73 53                        	jae	0xe63 <trusted_x86_x86_sim_xdp+0xe63>
     e10: 41 23 85 24 01 00 00         	andl	0x124(%r13), %eax
     e17: 49 8b bc c5 30 01 00 00      	movq	0x130(%r13,%rax,8), %rdi
     e1f: e8 00 00 00 00               	callq	0xe24 <trusted_x86_x86_sim_xdp+0xe24>
		0000000000000e20:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     e24: eb 0a                        	jmp	0xe30 <trusted_x86_x86_sim_xdp+0xe30>
     e26: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
     e2b: e8 00 00 00 00               	callq	0xe30 <trusted_x86_x86_sim_xdp+0xe30>
		0000000000000e2c:  R_X86_64_PLT32	.text+0x7c
     e30: 48 85 c0                     	testq	%rax, %rax
     e33: 74 2e                        	je	0xe63 <trusted_x86_x86_sim_xdp+0xe63>
     e35: 4c 23 70 08                  	andq	0x8(%rax), %r14
     e39: 48 b8 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rax # imm = 0x200000000000000
     e43: 49 39 c6                     	cmpq	%rax, %r14
     e46: 75 1b                        	jne	0xe63 <trusted_x86_x86_sim_xdp+0xe63>
     e48: 4c 8b 74 24 38               	movq	0x38(%rsp), %r14
     e4d: 49 83 c6 28                  	addq	$0x28, %r14
     e51: c7 44 24 38 03 00 00 00      	movl	$0x3, 0x38(%rsp)
     e59: 4c 8b 6c 24 20               	movq	0x20(%rsp), %r13
     e5e: e9 e8 fb ff ff               	jmp	0xa4b <trusted_x86_x86_sim_xdp+0xa4b>
     e63: c7 44 24 28 2e 00 00 00      	movl	$0x2e, 0x28(%rsp)
     e6b: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0xe72 <trusted_x86_x86_sim_xdp+0xe72>
		0000000000000e6e:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     e72: 83 78 44 2f                  	cmpl	$0x2f, 0x44(%rax)
     e76: 72 30                        	jb	0xea8 <trusted_x86_x86_sim_xdp+0xea8>
     e78: b8 2e 00 00 00               	movl	$0x2e, %eax
     e7d: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0xe84 <trusted_x86_x86_sim_xdp+0xe84>
		0000000000000e80:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     e84: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
     e8a: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
     e92: e8 00 00 00 00               	callq	0xe97 <trusted_x86_x86_sim_xdp+0xe97>
		0000000000000e93:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
     e97: 48 85 c0                     	testq	%rax, %rax
     e9a: 74 0c                        	je	0xea8 <trusted_x86_x86_sim_xdp+0xea8>
     e9c: 48 89 c1                     	movq	%rax, %rcx
     e9f: 48 8b 09                     	movq	(%rcx), %rcx
     ea2: 48 ff c1                     	incq	%rcx
     ea5: 48 89 08                     	movq	%rcx, (%rax)
     ea8: c7 44 24 38 03 00 00 00      	movl	$0x3, 0x38(%rsp)
     eb0: bd ea 03 00 00               	movl	$0x3ea, %ebp            # imm = 0x3EA
     eb5: e9 52 f3 ff ff               	jmp	0x20c <trusted_x86_x86_sim_xdp+0x20c>
     eba: 0f b6 54 24 5a               	movzbl	0x5a(%rsp), %edx
     ebf: 0f b6 4c 24 5b               	movzbl	0x5b(%rsp), %ecx
     ec4: 0f b6 44 24 5c               	movzbl	0x5c(%rsp), %eax
     ec9: 0f b6 7c 24 5f               	movzbl	0x5f(%rsp), %edi
     ece: 80 fa c3                     	cmpb	$-0x3d, %dl
     ed1: 74 4b                        	je	0xf1e <trusted_x86_x86_sim_xdp+0xf1e>
     ed3: 80 f9 c3                     	cmpb	$-0x3d, %cl
     ed6: 74 46                        	je	0xf1e <trusted_x86_x86_sim_xdp+0xf1e>
     ed8: 3c c3                        	cmpb	$-0x3d, %al
     eda: 74 42                        	je	0xf1e <trusted_x86_x86_sim_xdp+0xf1e>
     edc: 80 7c 24 5d c3               	cmpb	$-0x3d, 0x5d(%rsp)
     ee1: 74 3b                        	je	0xf1e <trusted_x86_x86_sim_xdp+0xf1e>
     ee3: 80 7c 24 5e c3               	cmpb	$-0x3d, 0x5e(%rsp)
     ee8: 74 34                        	je	0xf1e <trusted_x86_x86_sim_xdp+0xf1e>
     eea: 40 80 ff c3                  	cmpb	$-0x3d, %dil
     eee: 74 2e                        	je	0xf1e <trusted_x86_x86_sim_xdp+0xf1e>
     ef0: 80 7c 24 60 c3               	cmpb	$-0x3d, 0x60(%rsp)
     ef5: 74 27                        	je	0xf1e <trusted_x86_x86_sim_xdp+0xf1e>
     ef7: 80 7c 24 61 c3               	cmpb	$-0x3d, 0x61(%rsp)
     efc: 74 20                        	je	0xf1e <trusted_x86_x86_sim_xdp+0xf1e>
     efe: 80 7c 24 62 c3               	cmpb	$-0x3d, 0x62(%rsp)
     f03: 74 19                        	je	0xf1e <trusted_x86_x86_sim_xdp+0xf1e>
     f05: 80 7c 24 63 c3               	cmpb	$-0x3d, 0x63(%rsp)
     f0a: 74 12                        	je	0xf1e <trusted_x86_x86_sim_xdp+0xf1e>
     f0c: 80 7c 24 64 c3               	cmpb	$-0x3d, 0x64(%rsp)
     f11: 74 0b                        	je	0xf1e <trusted_x86_x86_sim_xdp+0xf1e>
     f13: 80 7c 24 65 c3               	cmpb	$-0x3d, 0x65(%rsp)
     f18: 0f 85 da fa ff ff            	jne	0x9f8 <trusted_x86_x86_sim_xdp+0x9f8>
     f1e: 83 fe 5d                     	cmpl	$0x5d, %esi
     f21: 75 12                        	jne	0xf35 <trusted_x86_x86_sim_xdp+0xf35>
     f23: c7 44 24 38 03 00 00 00      	movl	$0x3, 0x38(%rsp)
     f2b: 4c 8b 6c 24 20               	movq	0x20(%rsp), %r13
     f30: e9 fa fa ff ff               	jmp	0xa2f <trusted_x86_x86_sim_xdp+0xa2f>
     f35: 83 fe 0f                     	cmpl	$0xf, %esi
     f38: 0f 84 40 08 00 00            	je	0x177e <trusted_x86_x86_sim_xdp+0x177e>
     f3e: 83 fe 41                     	cmpl	$0x41, %esi
     f41: 0f 85 46 08 00 00            	jne	0x178d <trusted_x86_x86_sim_xdp+0x178d>
     f47: 80 fa 85                     	cmpb	$-0x7b, %dl
     f4a: 0f 85 3d 08 00 00            	jne	0x178d <trusted_x86_x86_sim_xdp+0x178d>
     f50: 80 f9 02                     	cmpb	$0x2, %cl
     f53: 0f 85 34 08 00 00            	jne	0x178d <trusted_x86_x86_sim_xdp+0x178d>
     f59: 3c c3                        	cmpb	$-0x3d, %al
     f5b: 0f 84 37 fe ff ff            	je	0xd98 <trusted_x86_x86_sim_xdp+0xd98>
     f61: e9 27 08 00 00               	jmp	0x178d <trusted_x86_x86_sim_xdp+0x178d>
     f66: 48 89 d8                     	movq	%rbx, %rax
     f69: 4c 8b a8 00 0f 00 00         	movq	0xf00(%rax), %r13
     f70: eb 05                        	jmp	0xf77 <trusted_x86_x86_sim_xdp+0xf77>
     f72: 4c 8b 6c 24 70               	movq	0x70(%rsp), %r13
     f77: 48 8b 84 24 90 00 00 00      	movq	0x90(%rsp), %rax
     f7f: 4c 8b b4 24 a0 00 00 00      	movq	0xa0(%rsp), %r14
     f87: 48 8b 8c 24 a8 00 00 00      	movq	0xa8(%rsp), %rcx
     f8f: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
     f94: 48 8b ac 24 b0 00 00 00      	movq	0xb0(%rsp), %rbp
     f9c: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
     fa1: 0f b6 71 1c                  	movzbl	0x1c(%rcx), %esi
     fa5: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
     faa: 48 01 c6                     	addq	%rax, %rsi
     fad: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
     fb2: ba 08 00 00 00               	movl	$0x8, %edx
     fb7: e8 00 00 00 00               	callq	0xfbc <trusted_x86_x86_sim_xdp+0xfbc>
		0000000000000fb8:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     fbc: 85 c0                        	testl	%eax, %eax
     fbe: 79 09                        	jns	0xfc9 <trusted_x86_x86_sim_xdp+0xfc9>
     fc0: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
     fc9: 85 c0                        	testl	%eax, %eax
     fcb: 74 63                        	je	0x1030 <trusted_x86_x86_sim_xdp+0x1030>
     fcd: c7 84 24 04 01 00 00 2d 00 00 00     	movl	$0x2d, 0x104(%rsp)
     fd8: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0xfdf <trusted_x86_x86_sim_xdp+0xfdf>
		0000000000000fdb:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     fdf: 83 78 44 2e                  	cmpl	$0x2e, 0x44(%rax)
     fe3: 72 30                        	jb	0x1015 <trusted_x86_x86_sim_xdp+0x1015>
     fe5: b8 2d 00 00 00               	movl	$0x2d, %eax
     fea: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0xff1 <trusted_x86_x86_sim_xdp+0xff1>
		0000000000000fed:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     ff1: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
     ff7: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
     fff: e8 00 00 00 00               	callq	0x1004 <trusted_x86_x86_sim_xdp+0x1004>
		0000000000001000:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    1004: 48 85 c0                     	testq	%rax, %rax
    1007: 74 0c                        	je	0x1015 <trusted_x86_x86_sim_xdp+0x1015>
    1009: 48 89 c1                     	movq	%rax, %rcx
    100c: 48 8b 09                     	movq	(%rcx), %rcx
    100f: 48 ff c1                     	incq	%rcx
    1012: 48 89 08                     	movq	%rcx, (%rax)
    1015: 48 c7 44 24 40 49 6e 74 65   	movq	$0x65746e49, 0x40(%rsp) # imm = 0x65746E49
    101e: c7 44 24 38 02 6e 74 65      	movl	$0x65746e02, 0x38(%rsp) # imm = 0x65746E02
    1026: bd e9 03 00 00               	movl	$0x3e9, %ebp            # imm = 0x3E9
    102b: e9 dc f1 ff ff               	jmp	0x20c <trusted_x86_x86_sim_xdp+0x20c>
    1030: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    1035: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
    103a: 0f b6 49 1d                  	movzbl	0x1d(%rcx), %ecx
    103e: 48 01 c1                     	addq	%rax, %rcx
    1041: 31 d2                        	xorl	%edx, %edx
    1043: 49 39 cd                     	cmpq	%rcx, %r13
    1046: 48 0f 43 d1                  	cmovaeq	%rcx, %rdx
    104a: 49 29 d5                     	subq	%rdx, %r13
    104d: 49 81 fd ff ff 00 00         	cmpq	$0xffff, %r13           # imm = 0xFFFF
    1054: b9 ff ff 00 00               	movl	$0xffff, %ecx           # imm = 0xFFFF
    1059: 49 0f 42 cd                  	cmovbq	%r13, %rcx
    105d: 48 89 8c 24 c0 00 00 00      	movq	%rcx, 0xc0(%rsp)
    1065: 48 c1 e8 03                  	shrq	$0x3, %rax
    1069: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    106e: 81 e2 00 ff ff ff            	andl	$0xffffff00, %edx       # imm = 0xFFFFFF00
    1074: 83 ca 02                     	orl	$0x2, %edx
    1077: 89 54 24 38                  	movl	%edx, 0x38(%rsp)
    107b: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
    1080: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    1085: 4c 8b 6c 24 20               	movq	0x20(%rsp), %r13
    108a: 8b 4c 24 40                  	movl	0x40(%rsp), %ecx
    108e: 48 89 d8                     	movq	%rbx, %rax
    1091: 8b 80 c0 02 00 00            	movl	0x2c0(%rax), %eax
    1097: 83 f8 7e                     	cmpl	$0x7e, %eax
    109a: 0f 87 00 fa ff ff            	ja	0xaa0 <trusted_x86_x86_sim_xdp+0xaa0>
    10a0: 48 89 da                     	movq	%rbx, %rdx
    10a3: 0f b6 92 30 0f 00 00         	movzbl	0xf30(%rdx), %edx
    10aa: 8b 74 24 38                  	movl	0x38(%rsp), %esi
    10ae: 48 c1 e6 3c                  	shlq	$0x3c, %rsi
    10b2: 48 8b bc 24 c0 00 00 00      	movq	0xc0(%rsp), %rdi
    10ba: 48 c1 e7 20                  	shlq	$0x20, %rdi
    10be: 48 09 cf                     	orq	%rcx, %rdi
    10c1: 8d 48 01                     	leal	0x1(%rax), %ecx
    10c4: 4c 8d 83 c0 02 00 00         	leaq	0x2c0(%rbx), %r8
    10cb: 4c 89 84 24 70 01 00 00      	movq	%r8, 0x170(%rsp)
    10d3: 41 89 08                     	movl	%ecx, (%r8)
    10d6: 48 09 f7                     	orq	%rsi, %rdi
    10d9: 48 8b 4c 24 48               	movq	0x48(%rsp), %rcx
    10de: c1 e0 03                     	shll	$0x3, %eax
    10e1: 8d 04 40                     	leal	(%rax,%rax,2), %eax
    10e4: 48 8d 34 03                  	leaq	(%rbx,%rax), %rsi
    10e8: 48 81 c6 d0 02 00 00         	addq	$0x2d0, %rsi            # imm = 0x2D0
    10ef: 48 89 0e                     	movq	%rcx, (%rsi)
    10f2: 48 8d 8c 03 d8 02 00 00      	leaq	0x2d8(%rbx,%rax), %rcx
    10fa: 48 89 39                     	movq	%rdi, (%rcx)
    10fd: 48 8d 8c 03 e0 02 00 00      	leaq	0x2e0(%rbx,%rax), %rcx
    1105: c6 01 05                     	movb	$0x5, (%rcx)
    1108: 48 8d 8c 03 e1 02 00 00      	leaq	0x2e1(%rbx,%rax), %rcx
    1110: 88 11                        	movb	%dl, (%rcx)
    1112: 48 8d 8c 03 e2 02 00 00      	leaq	0x2e2(%rbx,%rax), %rcx
    111a: c7 01 00 00 00 00            	movl	$0x0, (%rcx)
    1120: 48 8d 84 03 e6 02 00 00      	leaq	0x2e6(%rbx,%rax), %rax
    1128: 66 c7 00 00 00               	movw	$0x0, (%rax)
    112d: 48 8d 83 d0 0e 00 00         	leaq	0xed0(%rbx), %rax
    1134: 48 89 84 24 90 01 00 00      	movq	%rax, 0x190(%rsp)
    113c: 48 89 28                     	movq	%rbp, (%rax)
    113f: 48 8d 83 d8 0e 00 00         	leaq	0xed8(%rbx), %rax
    1146: 48 89 84 24 88 01 00 00      	movq	%rax, 0x188(%rsp)
    114e: 4c 89 30                     	movq	%r14, (%rax)
    1151: 48 8d 83 e0 0e 00 00         	leaq	0xee0(%rbx), %rax
    1158: 48 89 84 24 80 01 00 00      	movq	%rax, 0x180(%rsp)
    1160: 4c 89 28                     	movq	%r13, (%rax)
    1163: 48 8d 83 30 0f 00 00         	leaq	0xf30(%rbx), %rax
    116a: 48 89 84 24 78 01 00 00      	movq	%rax, 0x178(%rsp)
    1172: c6 00 01                     	movb	$0x1, (%rax)
    1175: c7 44 24 58 2a 00 00 00      	movl	$0x2a, 0x58(%rsp)
    117d: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x1184 <trusted_x86_x86_sim_xdp+0x1184>
		0000000000001180:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    1184: 83 78 44 2b                  	cmpl	$0x2b, 0x44(%rax)
    1188: 72 30                        	jb	0x11ba <trusted_x86_x86_sim_xdp+0x11ba>
    118a: b8 2a 00 00 00               	movl	$0x2a, %eax
    118f: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1196 <trusted_x86_x86_sim_xdp+0x1196>
		0000000000001192:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    1196: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    119c: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    11a4: e8 00 00 00 00               	callq	0x11a9 <trusted_x86_x86_sim_xdp+0x11a9>
		00000000000011a5:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    11a9: 48 85 c0                     	testq	%rax, %rax
    11ac: 74 0c                        	je	0x11ba <trusted_x86_x86_sim_xdp+0x11ba>
    11ae: 48 89 c1                     	movq	%rax, %rcx
    11b1: 48 8b 09                     	movq	(%rcx), %rcx
    11b4: 48 ff c1                     	incq	%rcx
    11b7: 48 89 08                     	movq	%rcx, (%rax)
    11ba: 48 89 d8                     	movq	%rbx, %rax
    11bd: 4c 8b b0 d0 0e 00 00         	movq	0xed0(%rax), %r14
    11c4: 4d 85 f6                     	testq	%r14, %r14
    11c7: 0f 84 5e 31 00 00            	je	0x432b <trusted_x86_x86_sim_xdp+0x432b>
    11cd: 48 b8 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    11d7: 49 39 c6                     	cmpq	%rax, %r14
    11da: 76 17                        	jbe	0x11f3 <trusted_x86_x86_sim_xdp+0x11f3>
    11dc: 48 8d 83 28 0f 00 00         	leaq	0xf28(%rbx), %rax
    11e3: c7 00 0b 00 00 00            	movl	$0xb, (%rax)
    11e9: bd ab 0f 00 00               	movl	$0xfab, %ebp            # imm = 0xFAB
    11ee: e9 19 f0 ff ff               	jmp	0x20c <trusted_x86_x86_sim_xdp+0x20c>
    11f3: 49 81 fe ff 0f 00 00         	cmpq	$0xfff, %r14            # imm = 0xFFF
    11fa: 77 17                        	ja	0x1213 <trusted_x86_x86_sim_xdp+0x1213>
    11fc: 48 8d 83 28 0f 00 00         	leaq	0xf28(%rbx), %rax
    1203: c7 00 31 00 00 00            	movl	$0x31, (%rax)
    1209: bd ae 0f 00 00               	movl	$0xfae, %ebp            # imm = 0xFAE
    120e: e9 f9 ef ff ff               	jmp	0x20c <trusted_x86_x86_sim_xdp+0x20c>
    1213: 48 89 d8                     	movq	%rbx, %rax
    1216: 8b 00                        	movl	(%rax), %eax
    1218: c7 44 24 58 60 00 00 00      	movl	$0x60, 0x58(%rsp)
    1220: 0f 38 f1 44 24 5c            	movbel	%eax, 0x5c(%rsp)
    1226: 4c 0f 38 f1 74 24 60         	movbeq	%r14, 0x60(%rsp)
    122d: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1234 <trusted_x86_x86_sim_xdp+0x1234>
		0000000000001230:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1234: 48 3b 0d 00 00 00 00         	cmpq	(%rip), %rcx            # 0x123b <trusted_x86_x86_sim_xdp+0x123b>
		0000000000001237:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
    123b: 0f 94 c0                     	sete	%al
    123e: 48 3b 0d 00 00 00 00         	cmpq	(%rip), %rcx            # 0x1245 <trusted_x86_x86_sim_xdp+0x1245>
		0000000000001241:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    1245: 0f 94 c1                     	sete	%cl
    1248: 08 c1                        	orb	%al, %cl
    124a: 88 4c 24 0f                  	movb	%cl, 0xf(%rsp)
    124e: 80 f9 01                     	cmpb	$0x1, %cl
    1251: 75 30                        	jne	0x1283 <trusted_x86_x86_sim_xdp+0x1283>
    1253: 8b 44 24 58                  	movl	0x58(%rsp), %eax
    1257: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x125e <trusted_x86_x86_sim_xdp+0x125e>
		000000000000125a:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    125e: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    1261: 0f 83 bf 31 00 00            	jae	0x4426 <trusted_x86_x86_sim_xdp+0x4426>
    1267: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x126e <trusted_x86_x86_sim_xdp+0x126e>
		000000000000126a:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    126e: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    1274: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    127c: e8 00 00 00 00               	callq	0x1281 <trusted_x86_x86_sim_xdp+0x1281>
		000000000000127d:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    1281: eb 0a                        	jmp	0x128d <trusted_x86_x86_sim_xdp+0x128d>
    1283: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    1288: e8 00 00 00 00               	callq	0x128d <trusted_x86_x86_sim_xdp+0x128d>
		0000000000001289:  R_X86_64_PLT32	.text+0x7c
    128d: 48 85 c0                     	testq	%rax, %rax
    1290: 0f 84 90 31 00 00            	je	0x4426 <trusted_x86_x86_sim_xdp+0x4426>
    1296: 48 89 c1                     	movq	%rax, %rcx
    1299: 4c 8b 69 08                  	movq	0x8(%rcx), %r13
    129d: 4c 89 e9                     	movq	%r13, %rcx
    12a0: 48 ba ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    12aa: 48 21 d1                     	andq	%rdx, %rcx
    12ad: 48 8d 93 20 0f 00 00         	leaq	0xf20(%rbx), %rdx
    12b4: 48 89 94 24 68 01 00 00      	movq	%rdx, 0x168(%rsp)
    12bc: 48 89 0a                     	movq	%rcx, (%rdx)
    12bf: 49 c1 ed 38                  	shrq	$0x38, %r13
    12c3: 48 8b 00                     	movq	(%rax), %rax
    12c6: 48 8d 93 10 0f 00 00         	leaq	0xf10(%rbx), %rdx
    12cd: 48 89 94 24 60 01 00 00      	movq	%rdx, 0x160(%rsp)
    12d5: 48 89 02                     	movq	%rax, (%rdx)
    12d8: 49 29 ce                     	subq	%rcx, %r14
    12db: 48 8d 8b 18 0f 00 00         	leaq	0xf18(%rbx), %rcx
    12e2: 48 89 8c 24 58 01 00 00      	movq	%rcx, 0x158(%rsp)
    12ea: 4c 89 31                     	movq	%r14, (%rcx)
    12ed: 49 83 fd 01                  	cmpq	$0x1, %r13
    12f1: 0f 85 2a 01 00 00            	jne	0x1421 <trusted_x86_x86_sim_xdp+0x1421>
    12f7: 48 89 44 24 58               	movq	%rax, 0x58(%rsp)
    12fc: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x1303 <trusted_x86_x86_sim_xdp+0x1303>
		00000000000012ff:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    1303: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x130a <trusted_x86_x86_sim_xdp+0x130a>
		0000000000001306:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    130a: 74 1e                        	je	0x132a <trusted_x86_x86_sim_xdp+0x132a>
    130c: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x1313 <trusted_x86_x86_sim_xdp+0x1313>
		000000000000130f:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
    1313: 74 15                        	je	0x132a <trusted_x86_x86_sim_xdp+0x132a>
    1315: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    131a: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x1321 <trusted_x86_x86_sim_xdp+0x1321>
		000000000000131d:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1321: 75 29                        	jne	0x134c <trusted_x86_x86_sim_xdp+0x134c>
    1323: e8 00 00 00 00               	callq	0x1328 <trusted_x86_x86_sim_xdp+0x1328>
		0000000000001324:  R_X86_64_PLT32	.text+0x7c
    1328: eb 27                        	jmp	0x1351 <trusted_x86_x86_sim_xdp+0x1351>
    132a: 8b 4c 24 58                  	movl	0x58(%rsp), %ecx
    132e: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    1331: 0f 83 8d 1f 00 00            	jae	0x32c4 <trusted_x86_x86_sim_xdp+0x32c4>
    1337: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    133d: 48 8b bc c8 30 01 00 00      	movq	0x130(%rax,%rcx,8), %rdi
    1345: e8 00 00 00 00               	callq	0x134a <trusted_x86_x86_sim_xdp+0x134a>
		0000000000001346:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    134a: eb 05                        	jmp	0x1351 <trusted_x86_x86_sim_xdp+0x1351>
    134c: e8 00 00 00 00               	callq	0x1351 <trusted_x86_x86_sim_xdp+0x1351>
		000000000000134d:  R_X86_64_PLT32	.text+0x12c
    1351: 48 89 84 24 50 01 00 00      	movq	%rax, 0x150(%rsp)
    1359: 31 ed                        	xorl	%ebp, %ebp
    135b: 41 bd 01 00 00 00            	movl	$0x1, %r13d
    1361: 48 83 bc 24 50 01 00 00 00   	cmpq	$0x0, 0x150(%rsp)
    136a: 0f 84 9f ee ff ff            	je	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    1370: 48 8b 84 24 50 01 00 00      	movq	0x150(%rsp), %rax
    1378: 48 8b 00                     	movq	(%rax), %rax
    137b: 4c 39 f0                     	cmpq	%r14, %rax
    137e: 77 11                        	ja	0x1391 <trusted_x86_x86_sim_xdp+0x1391>
    1380: 48 8b 84 24 50 01 00 00      	movq	0x150(%rsp), %rax
    1388: 48 8b 40 08                  	movq	0x8(%rax), %rax
    138c: 4c 39 f0                     	cmpq	%r14, %rax
    138f: 73 2a                        	jae	0x13bb <trusted_x86_x86_sim_xdp+0x13bb>
    1391: 48 8b 84 24 50 01 00 00      	movq	0x150(%rsp), %rax
    1399: 48 8b 40 10                  	movq	0x10(%rax), %rax
    139d: 4c 39 f0                     	cmpq	%r14, %rax
    13a0: 0f 87 69 ee ff ff            	ja	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    13a6: 48 8b 84 24 50 01 00 00      	movq	0x150(%rsp), %rax
    13ae: 48 8b 40 18                  	movq	0x18(%rax), %rax
    13b2: 4c 39 f0                     	cmpq	%r14, %rax
    13b5: 0f 82 54 ee ff ff            	jb	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    13bb: 48 89 d8                     	movq	%rbx, %rax
    13be: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
    13c4: 48 8b 8c 24 50 01 00 00      	movq	0x150(%rsp), %rcx
    13cc: 8b 49 20                     	movl	0x20(%rcx), %ecx
    13cf: 0f a3 c8                     	btl	%ecx, %eax
    13d2: 0f 82 37 ee ff ff            	jb	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    13d8: c7 84 24 c8 00 00 00 00 00 00 00     	movl	$0x0, 0xc8(%rsp)
    13e3: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x13ea <trusted_x86_x86_sim_xdp+0x13ea>
		00000000000013e6:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    13ea: 83 78 44 00                  	cmpl	$0x0, 0x44(%rax)
    13ee: 74 24                        	je	0x1414 <trusted_x86_x86_sim_xdp+0x1414>
    13f0: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x13f7 <trusted_x86_x86_sim_xdp+0x13f7>
		00000000000013f3:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    13f7: 48 8b b8 30 01 00 00         	movq	0x130(%rax), %rdi
    13fe: e8 00 00 00 00               	callq	0x1403 <trusted_x86_x86_sim_xdp+0x1403>
		00000000000013ff:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    1403: 48 85 c0                     	testq	%rax, %rax
    1406: 74 0c                        	je	0x1414 <trusted_x86_x86_sim_xdp+0x1414>
    1408: 48 89 c1                     	movq	%rax, %rcx
    140b: 48 8b 09                     	movq	(%rcx), %rcx
    140e: 48 ff c1                     	incq	%rcx
    1411: 48 89 08                     	movq	%rcx, (%rax)
    1414: 48 8b 84 24 50 01 00 00      	movq	0x150(%rsp), %rax
    141c: 44 0f b7 68 20               	movzwl	0x20(%rax), %r13d
    1421: 31 ed                        	xorl	%ebp, %ebp
    1423: 41 83 fd 02                  	cmpl	$0x2, %r13d
    1427: 0f 85 e2 ed ff ff            	jne	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    142d: c7 44 24 58 29 00 00 00      	movl	$0x29, 0x58(%rsp)
    1435: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x143c <trusted_x86_x86_sim_xdp+0x143c>
		0000000000001438:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    143c: 83 78 44 2a                  	cmpl	$0x2a, 0x44(%rax)
    1440: 72 30                        	jb	0x1472 <trusted_x86_x86_sim_xdp+0x1472>
    1442: b8 29 00 00 00               	movl	$0x29, %eax
    1447: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x144e <trusted_x86_x86_sim_xdp+0x144e>
		000000000000144a:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    144e: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    1454: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    145c: e8 00 00 00 00               	callq	0x1461 <trusted_x86_x86_sim_xdp+0x1461>
		000000000000145d:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    1461: 48 85 c0                     	testq	%rax, %rax
    1464: 74 0c                        	je	0x1472 <trusted_x86_x86_sim_xdp+0x1472>
    1466: 48 89 c1                     	movq	%rax, %rcx
    1469: 48 8b 09                     	movq	(%rcx), %rcx
    146c: 48 ff c1                     	incq	%rcx
    146f: 48 89 08                     	movq	%rcx, (%rax)
    1472: 48 89 d8                     	movq	%rbx, %rax
    1475: 48 8b 80 d0 0e 00 00         	movq	0xed0(%rax), %rax
    147c: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    1481: 48 89 d8                     	movq	%rbx, %rax
    1484: 48 8b 80 d8 0e 00 00         	movq	0xed8(%rax), %rax
    148b: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
    1490: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1495: 0f b6 40 20                  	movzbl	0x20(%rax), %eax
    1499: 48 89 d9                     	movq	%rbx, %rcx
    149c: 48 8b 89 e0 0e 00 00         	movq	0xee0(%rcx), %rcx
    14a3: 48 89 4c 24 48               	movq	%rcx, 0x48(%rsp)
    14a8: 48 89 d9                     	movq	%rbx, %rcx
    14ab: c4 62 fb f7 b1 18 0f 00 00   	shrxq	%rax, 0xf18(%rcx), %r14
    14b4: 48 89 d8                     	movq	%rbx, %rax
    14b7: 48 8b a8 10 0f 00 00         	movq	0xf10(%rax), %rbp
    14be: 48 b8 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    14c8: 48 21 c5                     	andq	%rax, %rbp
    14cb: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    14cf: ba 01 00 00 00               	movl	$0x1, %edx
    14d4: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    14d9: e8 00 00 00 00               	callq	0x14de <trusted_x86_x86_sim_xdp+0x14de>
		00000000000014da:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    14de: 85 c0                        	testl	%eax, %eax
    14e0: 79 05                        	jns	0x14e7 <trusted_x86_x86_sim_xdp+0x14e7>
    14e2: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    14e7: 85 c0                        	testl	%eax, %eax
    14e9: 0f 85 ce ec ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    14ef: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    14f4: 8d 48 01                     	leal	0x1(%rax), %ecx
    14f7: f6 c1 fe                     	testb	$-0x2, %cl
    14fa: 0f 84 ac 02 00 00            	je	0x17ac <trusted_x86_x86_sim_xdp+0x17ac>
    1500: 89 c0                        	movl	%eax, %eax
    1502: 49 29 c6                     	subq	%rax, %r14
    1505: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    1509: ba 01 00 00 00               	movl	$0x1, %edx
    150e: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    1513: e8 00 00 00 00               	callq	0x1518 <trusted_x86_x86_sim_xdp+0x1518>
		0000000000001514:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1518: 85 c0                        	testl	%eax, %eax
    151a: 79 05                        	jns	0x1521 <trusted_x86_x86_sim_xdp+0x1521>
    151c: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    1521: 85 c0                        	testl	%eax, %eax
    1523: 0f 85 94 ec ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    1529: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    152e: 8d 48 01                     	leal	0x1(%rax), %ecx
    1531: f6 c1 fe                     	testb	$-0x2, %cl
    1534: 0f 84 72 02 00 00            	je	0x17ac <trusted_x86_x86_sim_xdp+0x17ac>
    153a: 89 c0                        	movl	%eax, %eax
    153c: 49 29 c6                     	subq	%rax, %r14
    153f: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    1543: ba 01 00 00 00               	movl	$0x1, %edx
    1548: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    154d: e8 00 00 00 00               	callq	0x1552 <trusted_x86_x86_sim_xdp+0x1552>
		000000000000154e:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1552: 85 c0                        	testl	%eax, %eax
    1554: 79 05                        	jns	0x155b <trusted_x86_x86_sim_xdp+0x155b>
    1556: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    155b: 85 c0                        	testl	%eax, %eax
    155d: 0f 85 5a ec ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    1563: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    1568: 8d 48 01                     	leal	0x1(%rax), %ecx
    156b: f6 c1 fe                     	testb	$-0x2, %cl
    156e: 0f 84 38 02 00 00            	je	0x17ac <trusted_x86_x86_sim_xdp+0x17ac>
    1574: 89 c0                        	movl	%eax, %eax
    1576: 49 29 c6                     	subq	%rax, %r14
    1579: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    157d: ba 01 00 00 00               	movl	$0x1, %edx
    1582: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    1587: e8 00 00 00 00               	callq	0x158c <trusted_x86_x86_sim_xdp+0x158c>
		0000000000001588:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    158c: 85 c0                        	testl	%eax, %eax
    158e: 79 05                        	jns	0x1595 <trusted_x86_x86_sim_xdp+0x1595>
    1590: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    1595: 85 c0                        	testl	%eax, %eax
    1597: 0f 85 20 ec ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    159d: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    15a2: 8d 48 01                     	leal	0x1(%rax), %ecx
    15a5: f6 c1 fe                     	testb	$-0x2, %cl
    15a8: 0f 84 fe 01 00 00            	je	0x17ac <trusted_x86_x86_sim_xdp+0x17ac>
    15ae: 89 c0                        	movl	%eax, %eax
    15b0: 49 29 c6                     	subq	%rax, %r14
    15b3: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    15b7: ba 01 00 00 00               	movl	$0x1, %edx
    15bc: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    15c1: e8 00 00 00 00               	callq	0x15c6 <trusted_x86_x86_sim_xdp+0x15c6>
		00000000000015c2:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    15c6: 85 c0                        	testl	%eax, %eax
    15c8: 79 05                        	jns	0x15cf <trusted_x86_x86_sim_xdp+0x15cf>
    15ca: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    15cf: 85 c0                        	testl	%eax, %eax
    15d1: 0f 85 e6 eb ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    15d7: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    15dc: 8d 48 01                     	leal	0x1(%rax), %ecx
    15df: f6 c1 fe                     	testb	$-0x2, %cl
    15e2: 0f 84 c4 01 00 00            	je	0x17ac <trusted_x86_x86_sim_xdp+0x17ac>
    15e8: 89 c0                        	movl	%eax, %eax
    15ea: 49 29 c6                     	subq	%rax, %r14
    15ed: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    15f1: ba 01 00 00 00               	movl	$0x1, %edx
    15f6: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    15fb: e8 00 00 00 00               	callq	0x1600 <trusted_x86_x86_sim_xdp+0x1600>
		00000000000015fc:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1600: 85 c0                        	testl	%eax, %eax
    1602: 79 05                        	jns	0x1609 <trusted_x86_x86_sim_xdp+0x1609>
    1604: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    1609: 85 c0                        	testl	%eax, %eax
    160b: 0f 85 ac eb ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    1611: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    1616: 8d 48 01                     	leal	0x1(%rax), %ecx
    1619: f6 c1 fe                     	testb	$-0x2, %cl
    161c: 0f 84 8a 01 00 00            	je	0x17ac <trusted_x86_x86_sim_xdp+0x17ac>
    1622: 89 c0                        	movl	%eax, %eax
    1624: 49 29 c6                     	subq	%rax, %r14
    1627: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    162b: ba 01 00 00 00               	movl	$0x1, %edx
    1630: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    1635: e8 00 00 00 00               	callq	0x163a <trusted_x86_x86_sim_xdp+0x163a>
		0000000000001636:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    163a: 85 c0                        	testl	%eax, %eax
    163c: 79 05                        	jns	0x1643 <trusted_x86_x86_sim_xdp+0x1643>
    163e: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    1643: 85 c0                        	testl	%eax, %eax
    1645: 0f 85 72 eb ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    164b: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    1650: 8d 48 01                     	leal	0x1(%rax), %ecx
    1653: f6 c1 fe                     	testb	$-0x2, %cl
    1656: 0f 84 50 01 00 00            	je	0x17ac <trusted_x86_x86_sim_xdp+0x17ac>
    165c: 89 c0                        	movl	%eax, %eax
    165e: 49 29 c6                     	subq	%rax, %r14
    1661: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    1665: ba 01 00 00 00               	movl	$0x1, %edx
    166a: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    166f: e8 00 00 00 00               	callq	0x1674 <trusted_x86_x86_sim_xdp+0x1674>
		0000000000001670:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1674: 85 c0                        	testl	%eax, %eax
    1676: 79 05                        	jns	0x167d <trusted_x86_x86_sim_xdp+0x167d>
    1678: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    167d: 85 c0                        	testl	%eax, %eax
    167f: 0f 85 38 eb ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    1685: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    168a: 8d 48 01                     	leal	0x1(%rax), %ecx
    168d: f6 c1 fe                     	testb	$-0x2, %cl
    1690: 0f 84 16 01 00 00            	je	0x17ac <trusted_x86_x86_sim_xdp+0x17ac>
    1696: 89 c0                        	movl	%eax, %eax
    1698: 49 29 c6                     	subq	%rax, %r14
    169b: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    169f: ba 01 00 00 00               	movl	$0x1, %edx
    16a4: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    16a9: e8 00 00 00 00               	callq	0x16ae <trusted_x86_x86_sim_xdp+0x16ae>
		00000000000016aa:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    16ae: 85 c0                        	testl	%eax, %eax
    16b0: 79 05                        	jns	0x16b7 <trusted_x86_x86_sim_xdp+0x16b7>
    16b2: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    16b7: 85 c0                        	testl	%eax, %eax
    16b9: 0f 85 fe ea ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    16bf: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    16c4: 8d 48 01                     	leal	0x1(%rax), %ecx
    16c7: f6 c1 fe                     	testb	$-0x2, %cl
    16ca: 0f 84 dc 00 00 00            	je	0x17ac <trusted_x86_x86_sim_xdp+0x17ac>
    16d0: 89 c0                        	movl	%eax, %eax
    16d2: 49 29 c6                     	subq	%rax, %r14
    16d5: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    16d9: ba 01 00 00 00               	movl	$0x1, %edx
    16de: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    16e3: e8 00 00 00 00               	callq	0x16e8 <trusted_x86_x86_sim_xdp+0x16e8>
		00000000000016e4:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    16e8: 85 c0                        	testl	%eax, %eax
    16ea: 79 05                        	jns	0x16f1 <trusted_x86_x86_sim_xdp+0x16f1>
    16ec: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    16f1: 85 c0                        	testl	%eax, %eax
    16f3: 0f 85 c4 ea ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    16f9: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    16fe: 8d 48 01                     	leal	0x1(%rax), %ecx
    1701: f6 c1 fe                     	testb	$-0x2, %cl
    1704: 0f 84 a2 00 00 00            	je	0x17ac <trusted_x86_x86_sim_xdp+0x17ac>
    170a: 89 c0                        	movl	%eax, %eax
    170c: 49 29 c6                     	subq	%rax, %r14
    170f: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    1713: ba 01 00 00 00               	movl	$0x1, %edx
    1718: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    171d: e8 00 00 00 00               	callq	0x1722 <trusted_x86_x86_sim_xdp+0x1722>
		000000000000171e:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1722: 85 c0                        	testl	%eax, %eax
    1724: 79 05                        	jns	0x172b <trusted_x86_x86_sim_xdp+0x172b>
    1726: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    172b: 85 c0                        	testl	%eax, %eax
    172d: 0f 85 8a ea ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    1733: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    1738: 8d 48 01                     	leal	0x1(%rax), %ecx
    173b: f6 c1 fe                     	testb	$-0x2, %cl
    173e: 74 6c                        	je	0x17ac <trusted_x86_x86_sim_xdp+0x17ac>
    1740: 89 c0                        	movl	%eax, %eax
    1742: 49 29 c6                     	subq	%rax, %r14
    1745: 4c 01 f5                     	addq	%r14, %rbp
    1748: ba 01 00 00 00               	movl	$0x1, %edx
    174d: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    1752: 48 89 ee                     	movq	%rbp, %rsi
    1755: e8 00 00 00 00               	callq	0x175a <trusted_x86_x86_sim_xdp+0x175a>
		0000000000001756:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    175a: 85 c0                        	testl	%eax, %eax
    175c: 79 05                        	jns	0x1763 <trusted_x86_x86_sim_xdp+0x1763>
    175e: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    1763: 85 c0                        	testl	%eax, %eax
    1765: 0f 85 52 ea ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    176b: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    1770: 8d 48 01                     	leal	0x1(%rax), %ecx
    1773: f6 c1 fe                     	testb	$-0x2, %cl
    1776: 0f 85 41 ea ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    177c: eb 2e                        	jmp	0x17ac <trusted_x86_x86_sim_xdp+0x17ac>
    177e: 80 fa 85                     	cmpb	$-0x7b, %dl
    1781: 75 0a                        	jne	0x178d <trusted_x86_x86_sim_xdp+0x178d>
    1783: 40 80 ff c3                  	cmpb	$-0x3d, %dil
    1787: 0f 84 0b f6 ff ff            	je	0xd98 <trusted_x86_x86_sim_xdp+0xd98>
    178d: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    1792: 3c 5d                        	cmpb	$0x5d, %al
    1794: 0f 84 fe f5 ff ff            	je	0xd98 <trusted_x86_x86_sim_xdp+0xd98>
    179a: 3c c9                        	cmpb	$-0x37, %al
    179c: 0f 84 f6 f5 ff ff            	je	0xd98 <trusted_x86_x86_sim_xdp+0xd98>
    17a2: b9 01 00 00 00               	movl	$0x1, %ecx
    17a7: e9 4e f2 ff ff               	jmp	0x9fa <trusted_x86_x86_sim_xdp+0x9fa>
    17ac: 85 c0                        	testl	%eax, %eax
    17ae: 0f 85 09 ea ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    17b4: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    17b9: 48 89 d0                     	movq	%rdx, %rax
    17bc: 0f b6 40 20                  	movzbl	0x20(%rax), %eax
    17c0: c4 c2 f9 f7 c6               	shlxq	%rax, %r14, %rax
    17c5: 48 89 d9                     	movq	%rbx, %rcx
    17c8: 48 03 81 20 0f 00 00         	addq	0xf20(%rcx), %rax
    17cf: 48 89 d1                     	movq	%rdx, %rcx
    17d2: 0f b6 71 1b                  	movzbl	0x1b(%rcx), %esi
    17d6: 48 01 c6                     	addq	%rax, %rsi
    17d9: 48 89 b4 24 c8 00 00 00      	movq	%rsi, 0xc8(%rsp)
    17e1: 0f 84 e2 e9 ff ff            	je	0x1c9 <trusted_x86_x86_sim_xdp+0x1c9>
    17e7: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
    17ec: 4c 89 e7                     	movq	%r12, %rdi
    17ef: e8 00 00 00 00               	callq	0x17f4 <trusted_x86_x86_sim_xdp+0x17f4>
		00000000000017f0:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    17f4: 48 89 c5                     	movq	%rax, %rbp
    17f7: 85 ed                        	testl	%ebp, %ebp
    17f9: 79 0f                        	jns	0x180a <trusted_x86_x86_sim_xdp+0x180a>
    17fb: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
    1800: 4c 89 e7                     	movq	%r12, %rdi
    1803: 31 f6                        	xorl	%esi, %esi
    1805: e8 00 00 00 00               	callq	0x180a <trusted_x86_x86_sim_xdp+0x180a>
		0000000000001806:  R_X86_64_PLT32	memset-0x4
    180a: 85 ed                        	testl	%ebp, %ebp
    180c: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1811: 0f 85 0a ee ff ff            	jne	0x621 <trusted_x86_x86_sim_xdp+0x621>
    1817: 0f b7 40 10                  	movzwl	0x10(%rax), %eax
    181b: 0f b7 c0                     	movzwl	%ax, %eax
    181e: 3d f8 01 00 00               	cmpl	$0x1f8, %eax            # imm = 0x1F8
    1823: 0f 87 b5 21 00 00            	ja	0x39de <trusted_x86_x86_sim_xdp+0x39de>
    1829: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
    182e: 0f b7 49 12                  	movzwl	0x12(%rcx), %ecx
    1832: 0f b7 c9                     	movzwl	%cx, %ecx
    1835: 81 f9 fc 01 00 00            	cmpl	$0x1fc, %ecx            # imm = 0x1FC
    183b: 0f 87 9d 21 00 00            	ja	0x39de <trusted_x86_x86_sim_xdp+0x39de>
    1841: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1846: 0f b7 52 14                  	movzwl	0x14(%rdx), %edx
    184a: 0f b7 d2                     	movzwl	%dx, %edx
    184d: 81 fa f8 01 00 00            	cmpl	$0x1f8, %edx            # imm = 0x1F8
    1853: 0f 87 85 21 00 00            	ja	0x39de <trusted_x86_x86_sim_xdp+0x39de>
    1859: 48 8b 7c 24 10               	movq	0x10(%rsp), %rdi
    185e: 48 89 fe                     	movq	%rdi, %rsi
    1861: 0f b6 76 17                  	movzbl	0x17(%rsi), %esi
    1865: 40 0f b6 f6                  	movzbl	%sil, %esi
    1869: 4c 01 e6                     	addq	%r12, %rsi
    186c: 48 8b 36                     	movq	(%rsi), %rsi
    186f: 48 89 b4 24 d0 00 00 00      	movq	%rsi, 0xd0(%rsp)
    1877: 48 89 fe                     	movq	%rdi, %rsi
    187a: 0f b6 76 18                  	movzbl	0x18(%rsi), %esi
    187e: 40 0f b6 f6                  	movzbl	%sil, %esi
    1882: 4c 01 e6                     	addq	%r12, %rsi
    1885: 48 8b 36                     	movq	(%rsi), %rsi
    1888: 48 89 b4 24 d8 00 00 00      	movq	%rsi, 0xd8(%rsp)
    1890: 48 89 fe                     	movq	%rdi, %rsi
    1893: 0f b6 76 1a                  	movzbl	0x1a(%rsi), %esi
    1897: 40 0f b6 f6                  	movzbl	%sil, %esi
    189b: 4c 01 e6                     	addq	%r12, %rsi
    189e: 8b 36                        	movl	(%rsi), %esi
    18a0: c1 e6 03                     	shll	$0x3, %esi
    18a3: 89 b4 24 f0 00 00 00         	movl	%esi, 0xf0(%rsp)
    18aa: 48 89 fe                     	movq	%rdi, %rsi
    18ad: 0f b6 76 19                  	movzbl	0x19(%rsi), %esi
    18b1: 40 0f b6 f6                  	movzbl	%sil, %esi
    18b5: 4c 01 e6                     	addq	%r12, %rsi
    18b8: 0f b7 36                     	movzwl	(%rsi), %esi
    18bb: 66 89 b4 24 f8 00 00 00      	movw	%si, 0xf8(%rsp)
    18c3: 4c 01 e1                     	addq	%r12, %rcx
    18c6: 8b 09                        	movl	(%rcx), %ecx
    18c8: 89 8c 24 f4 00 00 00         	movl	%ecx, 0xf4(%rsp)
    18cf: 4c 01 e2                     	addq	%r12, %rdx
    18d2: 8b 0a                        	movl	(%rdx), %ecx
    18d4: 89 8c 24 ec 00 00 00         	movl	%ecx, 0xec(%rsp)
    18db: 4c 01 e0                     	addq	%r12, %rax
    18de: 48 8b 00                     	movq	(%rax), %rax
    18e1: 48 89 84 24 e0 00 00 00      	movq	%rax, 0xe0(%rsp)
    18e9: 48 89 f8                     	movq	%rdi, %rax
    18ec: 0f b6 40 16                  	movzbl	0x16(%rax), %eax
    18f0: 0f b6 c0                     	movzbl	%al, %eax
    18f3: 4c 01 e0                     	addq	%r12, %rax
    18f6: 48 8b 30                     	movq	(%rax), %rsi
    18f9: ba 04 00 00 00               	movl	$0x4, %edx
    18fe: 48 8d bc 24 e8 00 00 00      	leaq	0xe8(%rsp), %rdi
    1906: e8 00 00 00 00               	callq	0x190b <trusted_x86_x86_sim_xdp+0x190b>
		0000000000001907:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    190b: 85 c0                        	testl	%eax, %eax
    190d: 79 0b                        	jns	0x191a <trusted_x86_x86_sim_xdp+0x191a>
    190f: c7 84 24 e8 00 00 00 00 00 00 00     	movl	$0x0, 0xe8(%rsp)
    191a: 85 c0                        	testl	%eax, %eax
    191c: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1921: 0f 85 fa ec ff ff            	jne	0x621 <trusted_x86_x86_sim_xdp+0x621>
    1927: 0f b6 40 21                  	movzbl	0x21(%rax), %eax
    192b: 4c 8b b4 24 c8 00 00 00      	movq	0xc8(%rsp), %r14
    1933: 48 8b 8c 24 d0 00 00 00      	movq	0xd0(%rsp), %rcx
    193b: 84 c0                        	testb	%al, %al
    193d: 74 1f                        	je	0x195e <trusted_x86_x86_sim_xdp+0x195e>
    193f: 89 c9                        	movl	%ecx, %ecx
    1941: 4c 01 f1                     	addq	%r14, %rcx
    1944: 48 89 8c 24 d0 00 00 00      	movq	%rcx, 0xd0(%rsp)
    194c: 8b 94 24 d8 00 00 00         	movl	0xd8(%rsp), %edx
    1953: 4c 01 f2                     	addq	%r14, %rdx
    1956: 48 89 94 24 d8 00 00 00      	movq	%rdx, 0xd8(%rsp)
    195e: 8b ac 24 e8 00 00 00         	movl	0xe8(%rsp), %ebp
    1965: 48 8b 54 24 40               	movq	0x40(%rsp), %rdx
    196a: 89 d6                        	movl	%edx, %esi
    196c: 29 ce                        	subl	%ecx, %esi
    196e: 48 89 b4 24 c0 00 00 00      	movq	%rsi, 0xc0(%rsp)
    1976: 81 fd 6d 61 74 69            	cmpl	$0x6974616d, %ebp       # imm = 0x6974616D
    197c: 7f 19                        	jg	0x1997 <trusted_x86_x86_sim_xdp+0x1997>
    197e: 81 fd 76 74 61 62            	cmpl	$0x62617476, %ebp       # imm = 0x62617476
    1984: 0f 85 e5 00 00 00            	jne	0x1a6f <trusted_x86_x86_sim_xdp+0x1a6f>
    198a: c7 44 24 38 01 00 00 00      	movl	$0x1, 0x38(%rsp)
    1992: e9 c3 00 00 00               	jmp	0x1a5a <trusted_x86_x86_sim_xdp+0x1a5a>
    1997: 81 fd 6e 61 74 69            	cmpl	$0x6974616e, %ebp       # imm = 0x6974616E
    199d: 74 11                        	je	0x19b0 <trusted_x86_x86_sim_xdp+0x19b0>
    199f: 81 fd 6e 6d 65 74            	cmpl	$0x74656d6e, %ebp       # imm = 0x74656D6E
    19a5: 0f 85 a6 01 00 00            	jne	0x1b51 <trusted_x86_x86_sim_xdp+0x1b51>
    19ab: 48 8b 54 24 40               	movq	0x40(%rsp), %rdx
    19b0: 48 8b b4 24 e0 00 00 00      	movq	0xe0(%rsp), %rsi
    19b8: 89 f7                        	movl	%esi, %edi
    19ba: 4c 01 f7                     	addq	%r14, %rdi
    19bd: 84 c0                        	testb	%al, %al
    19bf: 8b ac 24 f4 00 00 00         	movl	0xf4(%rsp), %ebp
    19c6: 48 0f 44 fe                  	cmoveq	%rsi, %rdi
    19ca: 48 39 fa                     	cmpq	%rdi, %rdx
    19cd: 75 59                        	jne	0x1a28 <trusted_x86_x86_sim_xdp+0x1a28>
    19cf: 8b b4 24 ec 00 00 00         	movl	0xec(%rsp), %esi
    19d6: 48 03 74 24 20               	addq	0x20(%rsp), %rsi
    19db: ba 08 00 00 00               	movl	$0x8, %edx
    19e0: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    19e5: e8 00 00 00 00               	callq	0x19ea <trusted_x86_x86_sim_xdp+0x19ea>
		00000000000019e6:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    19ea: 85 c0                        	testl	%eax, %eax
    19ec: 79 09                        	jns	0x19f7 <trusted_x86_x86_sim_xdp+0x19f7>
    19ee: 48 c7 44 24 58 00 00 00 00   	movq	$0x0, 0x58(%rsp)
    19f7: 48 8b 8c 24 d0 00 00 00      	movq	0xd0(%rsp), %rcx
    19ff: 85 c0                        	testl	%eax, %eax
    1a01: 75 25                        	jne	0x1a28 <trusted_x86_x86_sim_xdp+0x1a28>
    1a03: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    1a08: 48 39 c8                     	cmpq	%rcx, %rax
    1a0b: 72 1b                        	jb	0x1a28 <trusted_x86_x86_sim_xdp+0x1a28>
    1a0d: 48 3b 84 24 d8 00 00 00      	cmpq	0xd8(%rsp), %rax
    1a15: 73 11                        	jae	0x1a28 <trusted_x86_x86_sim_xdp+0x1a28>
    1a17: 89 c2                        	movl	%eax, %edx
    1a19: 29 ca                        	subl	%ecx, %edx
    1a1b: 48 89 94 24 c0 00 00 00      	movq	%rdx, 0xc0(%rsp)
    1a23: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    1a28: 0f b7 84 24 f8 00 00 00      	movzwl	0xf8(%rsp), %eax
    1a30: 48 01 c8                     	addq	%rcx, %rax
    1a33: 48 39 44 24 40               	cmpq	%rax, 0x40(%rsp)
    1a38: 0f 83 2d 01 00 00            	jae	0x1b6b <trusted_x86_x86_sim_xdp+0x1b6b>
    1a3e: 48 83 c0 fc                  	addq	$-0x4, %rax
    1a42: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    1a48: 83 c9 03                     	orl	$0x3, %ecx
    1a4b: 89 4c 24 38                  	movl	%ecx, 0x38(%rsp)
    1a4f: 48 39 44 24 40               	cmpq	%rax, 0x40(%rsp)
    1a54: 0f 83 5c 01 00 00            	jae	0x1bb6 <trusted_x86_x86_sim_xdp+0x1bb6>
    1a5a: c7 84 24 f0 00 00 00 08 00 00 00     	movl	$0x8, 0xf0(%rsp)
    1a65: b8 08 00 00 00               	movl	$0x8, %eax
    1a6a: e9 61 01 00 00               	jmp	0x1bd0 <trusted_x86_x86_sim_xdp+0x1bd0>
    1a6f: 81 fd 49 6e 74 65            	cmpl	$0x65746e49, %ebp       # imm = 0x65746E49
    1a75: 0f 85 d6 00 00 00            	jne	0x1b51 <trusted_x86_x86_sim_xdp+0x1b51>
    1a7b: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    1a80: 48 3b 44 24 20               	cmpq	0x20(%rsp), %rax
    1a85: 0f 82 e9 0c 00 00            	jb	0x2774 <trusted_x86_x86_sim_xdp+0x2774>
    1a8b: b8 00 10 00 00               	movl	$0x1000, %eax           # imm = 0x1000
    1a90: 48 03 44 24 20               	addq	0x20(%rsp), %rax
    1a95: 48 39 44 24 48               	cmpq	%rax, 0x48(%rsp)
    1a9a: 0f 83 d4 0c 00 00            	jae	0x2774 <trusted_x86_x86_sim_xdp+0x2774>
    1aa0: 48 8b 74 24 48               	movq	0x48(%rsp), %rsi
    1aa5: 48 83 c6 b0                  	addq	$-0x50, %rsi
    1aa9: ba 60 00 00 00               	movl	$0x60, %edx
    1aae: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    1ab3: e8 00 00 00 00               	callq	0x1ab8 <trusted_x86_x86_sim_xdp+0x1ab8>
		0000000000001ab4:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1ab8: 85 c0                        	testl	%eax, %eax
    1aba: 79 64                        	jns	0x1b20 <trusted_x86_x86_sim_xdp+0x1b20>
    1abc: 48 8d 4c 24 58               	leaq	0x58(%rsp), %rcx
    1ac1: 48 c7 41 58 00 00 00 00      	movq	$0x0, 0x58(%rcx)
    1ac9: 48 c7 41 50 00 00 00 00      	movq	$0x0, 0x50(%rcx)
    1ad1: 48 c7 41 48 00 00 00 00      	movq	$0x0, 0x48(%rcx)
    1ad9: 48 c7 41 40 00 00 00 00      	movq	$0x0, 0x40(%rcx)
    1ae1: 48 c7 41 38 00 00 00 00      	movq	$0x0, 0x38(%rcx)
    1ae9: 48 c7 41 30 00 00 00 00      	movq	$0x0, 0x30(%rcx)
    1af1: 48 c7 41 28 00 00 00 00      	movq	$0x0, 0x28(%rcx)
    1af9: 48 c7 41 20 00 00 00 00      	movq	$0x0, 0x20(%rcx)
    1b01: 48 c7 41 18 00 00 00 00      	movq	$0x0, 0x18(%rcx)
    1b09: 48 c7 41 10 00 00 00 00      	movq	$0x0, 0x10(%rcx)
    1b11: 48 c7 41 08 00 00 00 00      	movq	$0x0, 0x8(%rcx)
    1b19: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
    1b20: 85 c0                        	testl	%eax, %eax
    1b22: 0f 85 4c 0c 00 00            	jne	0x2774 <trusted_x86_x86_sim_xdp+0x2774>
    1b28: 48 89 d8                     	movq	%rbx, %rax
    1b2b: 83 b8 c0 02 00 00 00         	cmpl	$0x0, 0x2c0(%rax)
    1b32: 0f 84 a2 07 00 00            	je	0x22da <trusted_x86_x86_sim_xdp+0x22da>
    1b38: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1b3d: 80 78 1f 00                  	cmpb	$0x0, 0x1f(%rax)
    1b41: 0f 84 c0 0b 00 00            	je	0x2707 <trusted_x86_x86_sim_xdp+0x2707>
    1b47: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
    1b4c: e9 bb 0b 00 00               	jmp	0x270c <trusted_x86_x86_sim_xdp+0x270c>
    1b51: 8b 84 24 f0 00 00 00         	movl	0xf0(%rsp), %eax
    1b58: c7 44 24 38 00 00 00 00      	movl	$0x0, 0x38(%rsp)
    1b60: 85 c0                        	testl	%eax, %eax
    1b62: 75 6c                        	jne	0x1bd0 <trusted_x86_x86_sim_xdp+0x1bd0>
    1b64: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    1b69: eb 50                        	jmp	0x1bbb <trusted_x86_x86_sim_xdp+0x1bbb>
    1b6b: 8b 84 24 f0 00 00 00         	movl	0xf0(%rsp), %eax
    1b72: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
    1b77: 48 8b 54 24 48               	movq	0x48(%rsp), %rdx
    1b7c: 48 8d 34 01                  	leaq	(%rcx,%rax), %rsi
    1b80: 48 83 c6 30                  	addq	$0x30, %rsi
    1b84: 48 89 74 24 50               	movq	%rsi, 0x50(%rsp)
    1b89: 48 39 ca                     	cmpq	%rcx, %rdx
    1b8c: 0f 82 7f 02 00 00            	jb	0x1e11 <trusted_x86_x86_sim_xdp+0x1e11>
    1b92: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    1b98: 83 c9 03                     	orl	$0x3, %ecx
    1b9b: 89 4c 24 38                  	movl	%ecx, 0x38(%rsp)
    1b9f: 48 8b 4c 24 48               	movq	0x48(%rsp), %rcx
    1ba4: 48 3b 4c 24 50               	cmpq	0x50(%rsp), %rcx
    1ba9: 0f 83 5d 02 00 00            	jae	0x1e0c <trusted_x86_x86_sim_xdp+0x1e0c>
    1baf: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    1bb4: eb 05                        	jmp	0x1bbb <trusted_x86_x86_sim_xdp+0x1bbb>
    1bb6: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    1bbb: c7 84 24 f0 00 00 00 10 00 00 00     	movl	$0x10, 0xf0(%rsp)
    1bc6: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
    1bcb: b8 10 00 00 00               	movl	$0x10, %eax
    1bd0: 89 c6                        	movl	%eax, %esi
    1bd2: 48 03 74 24 20               	addq	0x20(%rsp), %rsi
    1bd7: 48 89 74 24 20               	movq	%rsi, 0x20(%rsp)
    1bdc: 48 83 c6 f0                  	addq	$-0x10, %rsi
    1be0: ba 10 00 00 00               	movl	$0x10, %edx
    1be5: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    1bea: e8 00 00 00 00               	callq	0x1bef <trusted_x86_x86_sim_xdp+0x1bef>
		0000000000001beb:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1bef: 85 c0                        	testl	%eax, %eax
    1bf1: 79 14                        	jns	0x1c07 <trusted_x86_x86_sim_xdp+0x1c07>
    1bf3: 48 8d 44 24 58               	leaq	0x58(%rsp), %rax
    1bf8: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
    1c00: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    1c07: 83 bc 24 f0 00 00 00 10      	cmpl	$0x10, 0xf0(%rsp)
    1c0f: 72 0a                        	jb	0x1c1b <trusted_x86_x86_sim_xdp+0x1c1b>
    1c11: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    1c16: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    1c1b: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
    1c20: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    1c25: 48 89 d8                     	movq	%rbx, %rax
    1c28: 8b 88 c0 02 00 00            	movl	0x2c0(%rax), %ecx
    1c2e: 83 f9 7e                     	cmpl	$0x7e, %ecx
    1c31: 0f 87 69 ee ff ff            	ja	0xaa0 <trusted_x86_x86_sim_xdp+0xaa0>
    1c37: 48 89 d8                     	movq	%rbx, %rax
    1c3a: 0f b6 80 30 0f 00 00         	movzbl	0xf30(%rax), %eax
    1c41: 8b 54 24 38                  	movl	0x38(%rsp), %edx
    1c45: 48 8b b4 24 c0 00 00 00      	movq	0xc0(%rsp), %rsi
    1c4d: 8d 79 01                     	leal	0x1(%rcx), %edi
    1c50: 4c 8b 84 24 70 01 00 00      	movq	0x170(%rsp), %r8
    1c58: 41 89 38                     	movl	%edi, (%r8)
    1c5b: 48 8d bb d0 02 00 00         	leaq	0x2d0(%rbx), %rdi
    1c62: c1 e1 03                     	shll	$0x3, %ecx
    1c65: 8d 0c 49                     	leal	(%rcx,%rcx,2), %ecx
    1c68: 48 89 bc 24 b8 01 00 00      	movq	%rdi, 0x1b8(%rsp)
    1c70: 48 01 cf                     	addq	%rcx, %rdi
    1c73: 4c 89 37                     	movq	%r14, (%rdi)
    1c76: 4c 8d 8b d8 02 00 00         	leaq	0x2d8(%rbx), %r9
    1c7d: 4c 8d 83 e0 02 00 00         	leaq	0x2e0(%rbx), %r8
    1c84: 48 c1 e6 20                  	shlq	$0x20, %rsi
    1c88: 89 ef                        	movl	%ebp, %edi
    1c8a: 48 09 f7                     	orq	%rsi, %rdi
    1c8d: 48 8d b3 e1 02 00 00         	leaq	0x2e1(%rbx), %rsi
    1c94: 48 c1 e2 3c                  	shlq	$0x3c, %rdx
    1c98: 48 09 d7                     	orq	%rdx, %rdi
    1c9b: 4c 89 8c 24 b0 01 00 00      	movq	%r9, 0x1b0(%rsp)
    1ca3: 49 8d 14 09                  	leaq	(%r9,%rcx), %rdx
    1ca7: 48 89 3a                     	movq	%rdi, (%rdx)
    1caa: 4c 89 84 24 c0 01 00 00      	movq	%r8, 0x1c0(%rsp)
    1cb2: 49 8d 14 08                  	leaq	(%r8,%rcx), %rdx
    1cb6: c6 02 05                     	movb	$0x5, (%rdx)
    1cb9: 48 89 b4 24 50 01 00 00      	movq	%rsi, 0x150(%rsp)
    1cc1: 48 8d 14 0e                  	leaq	(%rsi,%rcx), %rdx
    1cc5: 88 02                        	movb	%al, (%rdx)
    1cc7: 48 8d 83 e2 02 00 00         	leaq	0x2e2(%rbx), %rax
    1cce: 48 8d 93 e6 02 00 00         	leaq	0x2e6(%rbx), %rdx
    1cd5: 48 89 84 24 a0 01 00 00      	movq	%rax, 0x1a0(%rsp)
    1cdd: 48 01 c8                     	addq	%rcx, %rax
    1ce0: c7 00 00 00 00 00            	movl	$0x0, (%rax)
    1ce6: 48 89 94 24 a8 01 00 00      	movq	%rdx, 0x1a8(%rsp)
    1cee: 48 01 d1                     	addq	%rdx, %rcx
    1cf1: 66 c7 01 00 00               	movw	$0x0, (%rcx)
    1cf6: 48 8b 44 24 40               	movq	0x40(%rsp), %rax
    1cfb: 48 8b 8c 24 90 01 00 00      	movq	0x190(%rsp), %rcx
    1d03: 48 89 01                     	movq	%rax, (%rcx)
    1d06: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    1d0b: 48 8b 8c 24 88 01 00 00      	movq	0x188(%rsp), %rcx
    1d13: 48 89 01                     	movq	%rax, (%rcx)
    1d16: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    1d1b: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
    1d23: 48 89 01                     	movq	%rax, (%rcx)
    1d26: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
    1d2e: c6 00 01                     	movb	$0x1, (%rax)
    1d31: c7 44 24 58 2a 00 00 00      	movl	$0x2a, 0x58(%rsp)
    1d39: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x1d40 <trusted_x86_x86_sim_xdp+0x1d40>
		0000000000001d3c:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    1d40: 83 78 44 2b                  	cmpl	$0x2b, 0x44(%rax)
    1d44: 72 30                        	jb	0x1d76 <trusted_x86_x86_sim_xdp+0x1d76>
    1d46: b8 2a 00 00 00               	movl	$0x2a, %eax
    1d4b: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1d52 <trusted_x86_x86_sim_xdp+0x1d52>
		0000000000001d4e:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    1d52: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    1d58: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    1d60: e8 00 00 00 00               	callq	0x1d65 <trusted_x86_x86_sim_xdp+0x1d65>
		0000000000001d61:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    1d65: 48 85 c0                     	testq	%rax, %rax
    1d68: 74 0c                        	je	0x1d76 <trusted_x86_x86_sim_xdp+0x1d76>
    1d6a: 48 89 c1                     	movq	%rax, %rcx
    1d6d: 48 8b 09                     	movq	(%rcx), %rcx
    1d70: 48 ff c1                     	incq	%rcx
    1d73: 48 89 08                     	movq	%rcx, (%rax)
    1d76: 48 89 d8                     	movq	%rbx, %rax
    1d79: 4c 8b b0 d0 0e 00 00         	movq	0xed0(%rax), %r14
    1d80: 4d 85 f6                     	testq	%r14, %r14
    1d83: 0f 84 a2 25 00 00            	je	0x432b <trusted_x86_x86_sim_xdp+0x432b>
    1d89: 48 b8 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    1d93: 48 ff c0                     	incq	%rax
    1d96: 48 89 84 24 98 01 00 00      	movq	%rax, 0x198(%rsp)
    1d9e: 49 39 c6                     	cmpq	%rax, %r14
    1da1: 0f 83 35 f4 ff ff            	jae	0x11dc <trusted_x86_x86_sim_xdp+0x11dc>
    1da7: 49 81 fe 00 10 00 00         	cmpq	$0x1000, %r14           # imm = 0x1000
    1dae: 0f 82 48 f4 ff ff            	jb	0x11fc <trusted_x86_x86_sim_xdp+0x11fc>
    1db4: 48 89 d8                     	movq	%rbx, %rax
    1db7: 8b 00                        	movl	(%rax), %eax
    1db9: c7 44 24 58 60 00 00 00      	movl	$0x60, 0x58(%rsp)
    1dc1: 0f 38 f1 44 24 5c            	movbel	%eax, 0x5c(%rsp)
    1dc7: 4c 0f 38 f1 74 24 60         	movbeq	%r14, 0x60(%rsp)
    1dce: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    1dd3: 0f 84 82 02 00 00            	je	0x205b <trusted_x86_x86_sim_xdp+0x205b>
    1dd9: 8b 44 24 58                  	movl	0x58(%rsp), %eax
    1ddd: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1de4 <trusted_x86_x86_sim_xdp+0x1de4>
		0000000000001de0:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1de4: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    1de7: 0f 83 39 26 00 00            	jae	0x4426 <trusted_x86_x86_sim_xdp+0x4426>
    1ded: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1df4 <trusted_x86_x86_sim_xdp+0x1df4>
		0000000000001df0:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1df4: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    1dfa: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    1e02: e8 00 00 00 00               	callq	0x1e07 <trusted_x86_x86_sim_xdp+0x1e07>
		0000000000001e03:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    1e07: e9 59 02 00 00               	jmp	0x2065 <trusted_x86_x86_sim_xdp+0x2065>
    1e0c: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
    1e11: 48 8d 14 01                  	leaq	(%rcx,%rax), %rdx
    1e15: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
    1e1a: 48 8d 34 01                  	leaq	(%rcx,%rax), %rsi
    1e1e: 48 83 c6 f8                  	addq	$-0x8, %rsi
    1e22: ba 30 00 00 00               	movl	$0x30, %edx
    1e27: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    1e2c: e8 00 00 00 00               	callq	0x1e31 <trusted_x86_x86_sim_xdp+0x1e31>
		0000000000001e2d:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1e31: 85 c0                        	testl	%eax, %eax
    1e33: 79 34                        	jns	0x1e69 <trusted_x86_x86_sim_xdp+0x1e69>
    1e35: 48 8d 44 24 58               	leaq	0x58(%rsp), %rax
    1e3a: 48 c7 40 28 00 00 00 00      	movq	$0x0, 0x28(%rax)
    1e42: 48 c7 40 20 00 00 00 00      	movq	$0x0, 0x20(%rax)
    1e4a: 48 c7 40 18 00 00 00 00      	movq	$0x0, 0x18(%rax)
    1e52: 48 c7 40 10 00 00 00 00      	movq	$0x0, 0x10(%rax)
    1e5a: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
    1e62: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    1e69: 49 bd 00 00 00 00 00 00 00 ff	movabsq	$-0x100000000000000, %r13 # imm = 0xFF00000000000000
    1e73: 48 89 d8                     	movq	%rbx, %rax
    1e76: 8b 00                        	movl	(%rax), %eax
    1e78: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    1e80: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    1e86: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    1e8b: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    1e92: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    1e97: 74 2c                        	je	0x1ec5 <trusted_x86_x86_sim_xdp+0x1ec5>
    1e99: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    1e9d: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1ea4 <trusted_x86_x86_sim_xdp+0x1ea4>
		0000000000001ea0:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1ea4: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    1ea7: 73 4b                        	jae	0x1ef4 <trusted_x86_x86_sim_xdp+0x1ef4>
    1ea9: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1eb0 <trusted_x86_x86_sim_xdp+0x1eb0>
		0000000000001eac:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1eb0: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    1eb6: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    1ebe: e8 00 00 00 00               	callq	0x1ec3 <trusted_x86_x86_sim_xdp+0x1ec3>
		0000000000001ebf:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    1ec3: eb 0a                        	jmp	0x1ecf <trusted_x86_x86_sim_xdp+0x1ecf>
    1ec5: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    1eca: e8 00 00 00 00               	callq	0x1ecf <trusted_x86_x86_sim_xdp+0x1ecf>
		0000000000001ecb:  R_X86_64_PLT32	.text+0x7c
    1ecf: 48 85 c0                     	testq	%rax, %rax
    1ed2: 74 20                        	je	0x1ef4 <trusted_x86_x86_sim_xdp+0x1ef4>
    1ed4: 48 8b 40 08                  	movq	0x8(%rax), %rax
    1ed8: 4c 21 e8                     	andq	%r13, %rax
    1edb: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    1ee5: 48 39 c8                     	cmpq	%rcx, %rax
    1ee8: 75 0a                        	jne	0x1ef4 <trusted_x86_x86_sim_xdp+0x1ef4>
    1eea: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    1eef: e9 40 03 00 00               	jmp	0x2234 <trusted_x86_x86_sim_xdp+0x2234>
    1ef4: 48 89 d8                     	movq	%rbx, %rax
    1ef7: 8b 00                        	movl	(%rax), %eax
    1ef9: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    1f01: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    1f07: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
    1f0c: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    1f13: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    1f18: 74 2c                        	je	0x1f46 <trusted_x86_x86_sim_xdp+0x1f46>
    1f1a: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    1f1e: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1f25 <trusted_x86_x86_sim_xdp+0x1f25>
		0000000000001f21:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1f25: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    1f28: 73 4f                        	jae	0x1f79 <trusted_x86_x86_sim_xdp+0x1f79>
    1f2a: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1f31 <trusted_x86_x86_sim_xdp+0x1f31>
		0000000000001f2d:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1f31: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    1f37: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    1f3f: e8 00 00 00 00               	callq	0x1f44 <trusted_x86_x86_sim_xdp+0x1f44>
		0000000000001f40:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    1f44: eb 0a                        	jmp	0x1f50 <trusted_x86_x86_sim_xdp+0x1f50>
    1f46: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    1f4b: e8 00 00 00 00               	callq	0x1f50 <trusted_x86_x86_sim_xdp+0x1f50>
		0000000000001f4c:  R_X86_64_PLT32	.text+0x7c
    1f50: 48 85 c0                     	testq	%rax, %rax
    1f53: 74 24                        	je	0x1f79 <trusted_x86_x86_sim_xdp+0x1f79>
    1f55: 48 8b 40 08                  	movq	0x8(%rax), %rax
    1f59: 4c 21 e8                     	andq	%r13, %rax
    1f5c: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    1f66: 48 39 c8                     	cmpq	%rcx, %rax
    1f69: 75 0e                        	jne	0x1f79 <trusted_x86_x86_sim_xdp+0x1f79>
    1f6b: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    1f70: 48 83 c0 08                  	addq	$0x8, %rax
    1f74: e9 bb 02 00 00               	jmp	0x2234 <trusted_x86_x86_sim_xdp+0x2234>
    1f79: 48 89 d8                     	movq	%rbx, %rax
    1f7c: 8b 00                        	movl	(%rax), %eax
    1f7e: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    1f86: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    1f8c: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
    1f91: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    1f98: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    1f9d: 74 2c                        	je	0x1fcb <trusted_x86_x86_sim_xdp+0x1fcb>
    1f9f: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    1fa3: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1faa <trusted_x86_x86_sim_xdp+0x1faa>
		0000000000001fa6:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1faa: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    1fad: 73 4f                        	jae	0x1ffe <trusted_x86_x86_sim_xdp+0x1ffe>
    1faf: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x1fb6 <trusted_x86_x86_sim_xdp+0x1fb6>
		0000000000001fb2:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1fb6: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    1fbc: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    1fc4: e8 00 00 00 00               	callq	0x1fc9 <trusted_x86_x86_sim_xdp+0x1fc9>
		0000000000001fc5:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    1fc9: eb 0a                        	jmp	0x1fd5 <trusted_x86_x86_sim_xdp+0x1fd5>
    1fcb: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    1fd0: e8 00 00 00 00               	callq	0x1fd5 <trusted_x86_x86_sim_xdp+0x1fd5>
		0000000000001fd1:  R_X86_64_PLT32	.text+0x7c
    1fd5: 48 85 c0                     	testq	%rax, %rax
    1fd8: 74 24                        	je	0x1ffe <trusted_x86_x86_sim_xdp+0x1ffe>
    1fda: 48 8b 40 08                  	movq	0x8(%rax), %rax
    1fde: 4c 21 e8                     	andq	%r13, %rax
    1fe1: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    1feb: 48 39 c8                     	cmpq	%rcx, %rax
    1fee: 75 0e                        	jne	0x1ffe <trusted_x86_x86_sim_xdp+0x1ffe>
    1ff0: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    1ff5: 48 83 c0 10                  	addq	$0x10, %rax
    1ff9: e9 36 02 00 00               	jmp	0x2234 <trusted_x86_x86_sim_xdp+0x2234>
    1ffe: 48 89 d8                     	movq	%rbx, %rax
    2001: 8b 00                        	movl	(%rax), %eax
    2003: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    200b: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    2011: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
    2016: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    201d: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    2022: 0f 84 d4 00 00 00            	je	0x20fc <trusted_x86_x86_sim_xdp+0x20fc>
    2028: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    202c: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2033 <trusted_x86_x86_sim_xdp+0x2033>
		000000000000202f:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2033: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    2036: 0f 83 f3 00 00 00            	jae	0x212f <trusted_x86_x86_sim_xdp+0x212f>
    203c: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2043 <trusted_x86_x86_sim_xdp+0x2043>
		000000000000203f:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2043: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    2049: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    2051: e8 00 00 00 00               	callq	0x2056 <trusted_x86_x86_sim_xdp+0x2056>
		0000000000002052:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    2056: e9 ab 00 00 00               	jmp	0x2106 <trusted_x86_x86_sim_xdp+0x2106>
    205b: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    2060: e8 00 00 00 00               	callq	0x2065 <trusted_x86_x86_sim_xdp+0x2065>
		0000000000002061:  R_X86_64_PLT32	.text+0x7c
    2065: 48 85 c0                     	testq	%rax, %rax
    2068: 0f 84 b8 23 00 00            	je	0x4426 <trusted_x86_x86_sim_xdp+0x4426>
    206e: 48 89 c1                     	movq	%rax, %rcx
    2071: 4c 8b 69 08                  	movq	0x8(%rcx), %r13
    2075: 4c 89 e9                     	movq	%r13, %rcx
    2078: 48 ba ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    2082: 48 21 d1                     	andq	%rdx, %rcx
    2085: 48 8b 94 24 68 01 00 00      	movq	0x168(%rsp), %rdx
    208d: 48 89 0a                     	movq	%rcx, (%rdx)
    2090: 48 8b 00                     	movq	(%rax), %rax
    2093: 48 8b 94 24 60 01 00 00      	movq	0x160(%rsp), %rdx
    209b: 48 89 02                     	movq	%rax, (%rdx)
    209e: 49 c1 ed 38                  	shrq	$0x38, %r13
    20a2: 49 29 ce                     	subq	%rcx, %r14
    20a5: 48 8b 8c 24 58 01 00 00      	movq	0x158(%rsp), %rcx
    20ad: 4c 89 31                     	movq	%r14, (%rcx)
    20b0: 49 83 fd 01                  	cmpq	$0x1, %r13
    20b4: 0f 85 e9 02 00 00            	jne	0x23a3 <trusted_x86_x86_sim_xdp+0x23a3>
    20ba: 48 89 44 24 58               	movq	%rax, 0x58(%rsp)
    20bf: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x20c6 <trusted_x86_x86_sim_xdp+0x20c6>
		00000000000020c2:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    20c6: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x20cd <trusted_x86_x86_sim_xdp+0x20cd>
		00000000000020c9:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    20cd: 0f 84 e5 01 00 00            	je	0x22b8 <trusted_x86_x86_sim_xdp+0x22b8>
    20d3: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x20da <trusted_x86_x86_sim_xdp+0x20da>
		00000000000020d6:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
    20da: 0f 84 d8 01 00 00            	je	0x22b8 <trusted_x86_x86_sim_xdp+0x22b8>
    20e0: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    20e5: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x20ec <trusted_x86_x86_sim_xdp+0x20ec>
		00000000000020e8:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    20ec: 0f 85 f7 01 00 00            	jne	0x22e9 <trusted_x86_x86_sim_xdp+0x22e9>
    20f2: e8 00 00 00 00               	callq	0x20f7 <trusted_x86_x86_sim_xdp+0x20f7>
		00000000000020f3:  R_X86_64_PLT32	.text+0x7c
    20f7: e9 f2 01 00 00               	jmp	0x22ee <trusted_x86_x86_sim_xdp+0x22ee>
    20fc: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    2101: e8 00 00 00 00               	callq	0x2106 <trusted_x86_x86_sim_xdp+0x2106>
		0000000000002102:  R_X86_64_PLT32	.text+0x7c
    2106: 48 85 c0                     	testq	%rax, %rax
    2109: 74 24                        	je	0x212f <trusted_x86_x86_sim_xdp+0x212f>
    210b: 48 8b 40 08                  	movq	0x8(%rax), %rax
    210f: 4c 21 e8                     	andq	%r13, %rax
    2112: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    211c: 48 39 c8                     	cmpq	%rcx, %rax
    211f: 75 0e                        	jne	0x212f <trusted_x86_x86_sim_xdp+0x212f>
    2121: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    2126: 48 83 c0 18                  	addq	$0x18, %rax
    212a: e9 05 01 00 00               	jmp	0x2234 <trusted_x86_x86_sim_xdp+0x2234>
    212f: 48 89 d8                     	movq	%rbx, %rax
    2132: 8b 00                        	movl	(%rax), %eax
    2134: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    213c: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    2142: 48 8b 44 24 78               	movq	0x78(%rsp), %rax
    2147: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    214e: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    2153: 74 2c                        	je	0x2181 <trusted_x86_x86_sim_xdp+0x2181>
    2155: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    2159: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2160 <trusted_x86_x86_sim_xdp+0x2160>
		000000000000215c:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2160: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    2163: 73 4f                        	jae	0x21b4 <trusted_x86_x86_sim_xdp+0x21b4>
    2165: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x216c <trusted_x86_x86_sim_xdp+0x216c>
		0000000000002168:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    216c: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    2172: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    217a: e8 00 00 00 00               	callq	0x217f <trusted_x86_x86_sim_xdp+0x217f>
		000000000000217b:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    217f: eb 0a                        	jmp	0x218b <trusted_x86_x86_sim_xdp+0x218b>
    2181: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    2186: e8 00 00 00 00               	callq	0x218b <trusted_x86_x86_sim_xdp+0x218b>
		0000000000002187:  R_X86_64_PLT32	.text+0x7c
    218b: 48 85 c0                     	testq	%rax, %rax
    218e: 74 24                        	je	0x21b4 <trusted_x86_x86_sim_xdp+0x21b4>
    2190: 48 8b 40 08                  	movq	0x8(%rax), %rax
    2194: 4c 21 e8                     	andq	%r13, %rax
    2197: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    21a1: 48 39 c8                     	cmpq	%rcx, %rax
    21a4: 75 0e                        	jne	0x21b4 <trusted_x86_x86_sim_xdp+0x21b4>
    21a6: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    21ab: 48 83 c0 20                  	addq	$0x20, %rax
    21af: e9 80 00 00 00               	jmp	0x2234 <trusted_x86_x86_sim_xdp+0x2234>
    21b4: 48 89 d8                     	movq	%rbx, %rax
    21b7: 8b 00                        	movl	(%rax), %eax
    21b9: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    21c1: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    21c7: 48 8b 84 24 80 00 00 00      	movq	0x80(%rsp), %rax
    21cf: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    21d6: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    21db: 74 2c                        	je	0x2209 <trusted_x86_x86_sim_xdp+0x2209>
    21dd: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    21e1: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x21e8 <trusted_x86_x86_sim_xdp+0x21e8>
		00000000000021e4:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    21e8: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    21eb: 73 6a                        	jae	0x2257 <trusted_x86_x86_sim_xdp+0x2257>
    21ed: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x21f4 <trusted_x86_x86_sim_xdp+0x21f4>
		00000000000021f0:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    21f4: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    21fa: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    2202: e8 00 00 00 00               	callq	0x2207 <trusted_x86_x86_sim_xdp+0x2207>
		0000000000002203:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    2207: eb 0a                        	jmp	0x2213 <trusted_x86_x86_sim_xdp+0x2213>
    2209: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    220e: e8 00 00 00 00               	callq	0x2213 <trusted_x86_x86_sim_xdp+0x2213>
		000000000000220f:  R_X86_64_PLT32	.text+0x7c
    2213: 48 85 c0                     	testq	%rax, %rax
    2216: 74 3f                        	je	0x2257 <trusted_x86_x86_sim_xdp+0x2257>
    2218: 4c 23 68 08                  	andq	0x8(%rax), %r13
    221c: 48 b8 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rax # imm = 0x200000000000000
    2226: 49 39 c5                     	cmpq	%rax, %r13
    2229: 75 2c                        	jne	0x2257 <trusted_x86_x86_sim_xdp+0x2257>
    222b: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    2230: 48 83 c0 28                  	addq	$0x28, %rax
    2234: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
    2239: 89 c1                        	movl	%eax, %ecx
    223b: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    2241: 83 c9 03                     	orl	$0x3, %ecx
    2244: 89 4c 24 38                  	movl	%ecx, 0x38(%rsp)
    2248: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
    224d: 48 8b 74 24 20               	movq	0x20(%rsp), %rsi
    2252: e9 85 f9 ff ff               	jmp	0x1bdc <trusted_x86_x86_sim_xdp+0x1bdc>
    2257: c7 44 24 28 2e 00 00 00      	movl	$0x2e, 0x28(%rsp)
    225f: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x2266 <trusted_x86_x86_sim_xdp+0x2266>
		0000000000002262:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2266: 83 78 44 2f                  	cmpl	$0x2f, 0x44(%rax)
    226a: 72 30                        	jb	0x229c <trusted_x86_x86_sim_xdp+0x229c>
    226c: b8 2e 00 00 00               	movl	$0x2e, %eax
    2271: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2278 <trusted_x86_x86_sim_xdp+0x2278>
		0000000000002274:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2278: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    227e: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    2286: e8 00 00 00 00               	callq	0x228b <trusted_x86_x86_sim_xdp+0x228b>
		0000000000002287:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    228b: 48 85 c0                     	testq	%rax, %rax
    228e: 74 0c                        	je	0x229c <trusted_x86_x86_sim_xdp+0x229c>
    2290: 48 89 c1                     	movq	%rax, %rcx
    2293: 48 8b 09                     	movq	(%rcx), %rcx
    2296: 48 ff c1                     	incq	%rcx
    2299: 48 89 08                     	movq	%rcx, (%rax)
    229c: c7 44 24 38 03 00 00 00      	movl	$0x3, 0x38(%rsp)
    22a4: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
    22a9: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
    22ae: bd ea 03 00 00               	movl	$0x3ea, %ebp            # imm = 0x3EA
    22b3: e9 54 df ff ff               	jmp	0x20c <trusted_x86_x86_sim_xdp+0x20c>
    22b8: 8b 4c 24 58                  	movl	0x58(%rsp), %ecx
    22bc: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    22bf: 0f 83 f6 0f 00 00            	jae	0x32bb <trusted_x86_x86_sim_xdp+0x32bb>
    22c5: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    22cb: 48 8b bc c8 30 01 00 00      	movq	0x130(%rax,%rcx,8), %rdi
    22d3: e8 00 00 00 00               	callq	0x22d8 <trusted_x86_x86_sim_xdp+0x22d8>
		00000000000022d4:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    22d8: eb 14                        	jmp	0x22ee <trusted_x86_x86_sim_xdp+0x22ee>
    22da: 48 89 d8                     	movq	%rbx, %rax
    22dd: 48 8b 80 00 0f 00 00         	movq	0xf00(%rax), %rax
    22e4: e9 23 04 00 00               	jmp	0x270c <trusted_x86_x86_sim_xdp+0x270c>
    22e9: e8 00 00 00 00               	callq	0x22ee <trusted_x86_x86_sim_xdp+0x22ee>
		00000000000022ea:  R_X86_64_PLT32	.text+0x12c
    22ee: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
    22f3: 31 ed                        	xorl	%ebp, %ebp
    22f5: 41 bd 01 00 00 00            	movl	$0x1, %r13d
    22fb: 48 85 c0                     	testq	%rax, %rax
    22fe: 0f 84 0b df ff ff            	je	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    2304: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    2309: 48 8b 00                     	movq	(%rax), %rax
    230c: 4c 39 f0                     	cmpq	%r14, %rax
    230f: 77 0e                        	ja	0x231f <trusted_x86_x86_sim_xdp+0x231f>
    2311: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    2316: 48 8b 40 08                  	movq	0x8(%rax), %rax
    231a: 4c 39 f0                     	cmpq	%r14, %rax
    231d: 73 24                        	jae	0x2343 <trusted_x86_x86_sim_xdp+0x2343>
    231f: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    2324: 48 8b 40 10                  	movq	0x10(%rax), %rax
    2328: 4c 39 f0                     	cmpq	%r14, %rax
    232b: 0f 87 de de ff ff            	ja	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    2331: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    2336: 48 8b 40 18                  	movq	0x18(%rax), %rax
    233a: 4c 39 f0                     	cmpq	%r14, %rax
    233d: 0f 82 cc de ff ff            	jb	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    2343: 48 89 d8                     	movq	%rbx, %rax
    2346: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
    234c: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
    2351: 8b 49 20                     	movl	0x20(%rcx), %ecx
    2354: 0f a3 c8                     	btl	%ecx, %eax
    2357: 0f 82 b2 de ff ff            	jb	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    235d: c7 84 24 c8 00 00 00 00 00 00 00     	movl	$0x0, 0xc8(%rsp)
    2368: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x236f <trusted_x86_x86_sim_xdp+0x236f>
		000000000000236b:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    236f: 83 78 44 00                  	cmpl	$0x0, 0x44(%rax)
    2373: 74 24                        	je	0x2399 <trusted_x86_x86_sim_xdp+0x2399>
    2375: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x237c <trusted_x86_x86_sim_xdp+0x237c>
		0000000000002378:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    237c: 48 8b b8 30 01 00 00         	movq	0x130(%rax), %rdi
    2383: e8 00 00 00 00               	callq	0x2388 <trusted_x86_x86_sim_xdp+0x2388>
		0000000000002384:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    2388: 48 85 c0                     	testq	%rax, %rax
    238b: 74 0c                        	je	0x2399 <trusted_x86_x86_sim_xdp+0x2399>
    238d: 48 89 c1                     	movq	%rax, %rcx
    2390: 48 8b 09                     	movq	(%rcx), %rcx
    2393: 48 ff c1                     	incq	%rcx
    2396: 48 89 08                     	movq	%rcx, (%rax)
    2399: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    239e: 44 0f b7 68 20               	movzwl	0x20(%rax), %r13d
    23a3: 31 ed                        	xorl	%ebp, %ebp
    23a5: 41 83 fd 02                  	cmpl	$0x2, %r13d
    23a9: 0f 85 60 de ff ff            	jne	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    23af: c7 44 24 58 29 00 00 00      	movl	$0x29, 0x58(%rsp)
    23b7: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x23be <trusted_x86_x86_sim_xdp+0x23be>
		00000000000023ba:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    23be: 83 78 44 2a                  	cmpl	$0x2a, 0x44(%rax)
    23c2: 72 30                        	jb	0x23f4 <trusted_x86_x86_sim_xdp+0x23f4>
    23c4: b8 29 00 00 00               	movl	$0x29, %eax
    23c9: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x23d0 <trusted_x86_x86_sim_xdp+0x23d0>
		00000000000023cc:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    23d0: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    23d6: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    23de: e8 00 00 00 00               	callq	0x23e3 <trusted_x86_x86_sim_xdp+0x23e3>
		00000000000023df:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    23e3: 48 85 c0                     	testq	%rax, %rax
    23e6: 74 0c                        	je	0x23f4 <trusted_x86_x86_sim_xdp+0x23f4>
    23e8: 48 89 c1                     	movq	%rax, %rcx
    23eb: 48 8b 09                     	movq	(%rcx), %rcx
    23ee: 48 ff c1                     	incq	%rcx
    23f1: 48 89 08                     	movq	%rcx, (%rax)
    23f4: 48 89 d8                     	movq	%rbx, %rax
    23f7: 48 8b 80 d0 0e 00 00         	movq	0xed0(%rax), %rax
    23fe: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    2403: 48 89 d8                     	movq	%rbx, %rax
    2406: 48 8b 80 d8 0e 00 00         	movq	0xed8(%rax), %rax
    240d: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
    2412: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    2417: 0f b6 40 20                  	movzbl	0x20(%rax), %eax
    241b: 48 89 d9                     	movq	%rbx, %rcx
    241e: 48 8b 89 e0 0e 00 00         	movq	0xee0(%rcx), %rcx
    2425: 48 89 4c 24 48               	movq	%rcx, 0x48(%rsp)
    242a: 48 89 d9                     	movq	%rbx, %rcx
    242d: c4 62 fb f7 a9 18 0f 00 00   	shrxq	%rax, 0xf18(%rcx), %r13
    2436: 48 89 d8                     	movq	%rbx, %rax
    2439: 4c 8b b0 10 0f 00 00         	movq	0xf10(%rax), %r14
    2440: 48 b8 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    244a: 49 21 c6                     	andq	%rax, %r14
    244d: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    2451: ba 01 00 00 00               	movl	$0x1, %edx
    2456: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    245b: e8 00 00 00 00               	callq	0x2460 <trusted_x86_x86_sim_xdp+0x2460>
		000000000000245c:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2460: 85 c0                        	testl	%eax, %eax
    2462: 79 05                        	jns	0x2469 <trusted_x86_x86_sim_xdp+0x2469>
    2464: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    2469: 85 c0                        	testl	%eax, %eax
    246b: 0f 85 4c dd ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    2471: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    2476: 8d 48 01                     	leal	0x1(%rax), %ecx
    2479: f6 c1 fe                     	testb	$-0x2, %cl
    247c: 0f 84 a1 03 00 00            	je	0x2823 <trusted_x86_x86_sim_xdp+0x2823>
    2482: 89 c0                        	movl	%eax, %eax
    2484: 49 29 c5                     	subq	%rax, %r13
    2487: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    248b: ba 01 00 00 00               	movl	$0x1, %edx
    2490: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    2495: e8 00 00 00 00               	callq	0x249a <trusted_x86_x86_sim_xdp+0x249a>
		0000000000002496:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    249a: 85 c0                        	testl	%eax, %eax
    249c: 79 05                        	jns	0x24a3 <trusted_x86_x86_sim_xdp+0x24a3>
    249e: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    24a3: 85 c0                        	testl	%eax, %eax
    24a5: 0f 85 12 dd ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    24ab: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    24b0: 8d 48 01                     	leal	0x1(%rax), %ecx
    24b3: f6 c1 fe                     	testb	$-0x2, %cl
    24b6: 0f 84 67 03 00 00            	je	0x2823 <trusted_x86_x86_sim_xdp+0x2823>
    24bc: 89 c0                        	movl	%eax, %eax
    24be: 49 29 c5                     	subq	%rax, %r13
    24c1: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    24c5: ba 01 00 00 00               	movl	$0x1, %edx
    24ca: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    24cf: e8 00 00 00 00               	callq	0x24d4 <trusted_x86_x86_sim_xdp+0x24d4>
		00000000000024d0:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    24d4: 85 c0                        	testl	%eax, %eax
    24d6: 79 05                        	jns	0x24dd <trusted_x86_x86_sim_xdp+0x24dd>
    24d8: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    24dd: 85 c0                        	testl	%eax, %eax
    24df: 0f 85 d8 dc ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    24e5: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    24ea: 8d 48 01                     	leal	0x1(%rax), %ecx
    24ed: f6 c1 fe                     	testb	$-0x2, %cl
    24f0: 0f 84 2d 03 00 00            	je	0x2823 <trusted_x86_x86_sim_xdp+0x2823>
    24f6: 89 c0                        	movl	%eax, %eax
    24f8: 49 29 c5                     	subq	%rax, %r13
    24fb: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    24ff: ba 01 00 00 00               	movl	$0x1, %edx
    2504: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    2509: e8 00 00 00 00               	callq	0x250e <trusted_x86_x86_sim_xdp+0x250e>
		000000000000250a:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    250e: 85 c0                        	testl	%eax, %eax
    2510: 79 05                        	jns	0x2517 <trusted_x86_x86_sim_xdp+0x2517>
    2512: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    2517: 85 c0                        	testl	%eax, %eax
    2519: 0f 85 9e dc ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    251f: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    2524: 8d 48 01                     	leal	0x1(%rax), %ecx
    2527: f6 c1 fe                     	testb	$-0x2, %cl
    252a: 0f 84 f3 02 00 00            	je	0x2823 <trusted_x86_x86_sim_xdp+0x2823>
    2530: 89 c0                        	movl	%eax, %eax
    2532: 49 29 c5                     	subq	%rax, %r13
    2535: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    2539: ba 01 00 00 00               	movl	$0x1, %edx
    253e: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    2543: e8 00 00 00 00               	callq	0x2548 <trusted_x86_x86_sim_xdp+0x2548>
		0000000000002544:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2548: 85 c0                        	testl	%eax, %eax
    254a: 79 05                        	jns	0x2551 <trusted_x86_x86_sim_xdp+0x2551>
    254c: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    2551: 85 c0                        	testl	%eax, %eax
    2553: 0f 85 64 dc ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    2559: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    255e: 8d 48 01                     	leal	0x1(%rax), %ecx
    2561: f6 c1 fe                     	testb	$-0x2, %cl
    2564: 0f 84 b9 02 00 00            	je	0x2823 <trusted_x86_x86_sim_xdp+0x2823>
    256a: 89 c0                        	movl	%eax, %eax
    256c: 49 29 c5                     	subq	%rax, %r13
    256f: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    2573: ba 01 00 00 00               	movl	$0x1, %edx
    2578: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    257d: e8 00 00 00 00               	callq	0x2582 <trusted_x86_x86_sim_xdp+0x2582>
		000000000000257e:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2582: 85 c0                        	testl	%eax, %eax
    2584: 79 05                        	jns	0x258b <trusted_x86_x86_sim_xdp+0x258b>
    2586: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    258b: 85 c0                        	testl	%eax, %eax
    258d: 0f 85 2a dc ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    2593: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    2598: 8d 48 01                     	leal	0x1(%rax), %ecx
    259b: f6 c1 fe                     	testb	$-0x2, %cl
    259e: 0f 84 7f 02 00 00            	je	0x2823 <trusted_x86_x86_sim_xdp+0x2823>
    25a4: 89 c0                        	movl	%eax, %eax
    25a6: 49 29 c5                     	subq	%rax, %r13
    25a9: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    25ad: ba 01 00 00 00               	movl	$0x1, %edx
    25b2: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    25b7: e8 00 00 00 00               	callq	0x25bc <trusted_x86_x86_sim_xdp+0x25bc>
		00000000000025b8:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    25bc: 85 c0                        	testl	%eax, %eax
    25be: 79 05                        	jns	0x25c5 <trusted_x86_x86_sim_xdp+0x25c5>
    25c0: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    25c5: 85 c0                        	testl	%eax, %eax
    25c7: 0f 85 f0 db ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    25cd: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    25d2: 8d 48 01                     	leal	0x1(%rax), %ecx
    25d5: f6 c1 fe                     	testb	$-0x2, %cl
    25d8: 0f 84 45 02 00 00            	je	0x2823 <trusted_x86_x86_sim_xdp+0x2823>
    25de: 89 c0                        	movl	%eax, %eax
    25e0: 49 29 c5                     	subq	%rax, %r13
    25e3: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    25e7: ba 01 00 00 00               	movl	$0x1, %edx
    25ec: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    25f1: e8 00 00 00 00               	callq	0x25f6 <trusted_x86_x86_sim_xdp+0x25f6>
		00000000000025f2:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    25f6: 85 c0                        	testl	%eax, %eax
    25f8: 79 05                        	jns	0x25ff <trusted_x86_x86_sim_xdp+0x25ff>
    25fa: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    25ff: 85 c0                        	testl	%eax, %eax
    2601: 0f 85 b6 db ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    2607: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    260c: 8d 48 01                     	leal	0x1(%rax), %ecx
    260f: f6 c1 fe                     	testb	$-0x2, %cl
    2612: 0f 84 0b 02 00 00            	je	0x2823 <trusted_x86_x86_sim_xdp+0x2823>
    2618: 89 c0                        	movl	%eax, %eax
    261a: 49 29 c5                     	subq	%rax, %r13
    261d: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    2621: ba 01 00 00 00               	movl	$0x1, %edx
    2626: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    262b: e8 00 00 00 00               	callq	0x2630 <trusted_x86_x86_sim_xdp+0x2630>
		000000000000262c:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2630: 85 c0                        	testl	%eax, %eax
    2632: 79 05                        	jns	0x2639 <trusted_x86_x86_sim_xdp+0x2639>
    2634: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    2639: 85 c0                        	testl	%eax, %eax
    263b: 0f 85 7c db ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    2641: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    2646: 8d 48 01                     	leal	0x1(%rax), %ecx
    2649: f6 c1 fe                     	testb	$-0x2, %cl
    264c: 0f 84 d1 01 00 00            	je	0x2823 <trusted_x86_x86_sim_xdp+0x2823>
    2652: 89 c0                        	movl	%eax, %eax
    2654: 49 29 c5                     	subq	%rax, %r13
    2657: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    265b: ba 01 00 00 00               	movl	$0x1, %edx
    2660: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    2665: e8 00 00 00 00               	callq	0x266a <trusted_x86_x86_sim_xdp+0x266a>
		0000000000002666:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    266a: 85 c0                        	testl	%eax, %eax
    266c: 79 05                        	jns	0x2673 <trusted_x86_x86_sim_xdp+0x2673>
    266e: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    2673: 85 c0                        	testl	%eax, %eax
    2675: 0f 85 42 db ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    267b: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    2680: 8d 48 01                     	leal	0x1(%rax), %ecx
    2683: f6 c1 fe                     	testb	$-0x2, %cl
    2686: 0f 84 97 01 00 00            	je	0x2823 <trusted_x86_x86_sim_xdp+0x2823>
    268c: 89 c0                        	movl	%eax, %eax
    268e: 49 29 c5                     	subq	%rax, %r13
    2691: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    2695: ba 01 00 00 00               	movl	$0x1, %edx
    269a: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    269f: e8 00 00 00 00               	callq	0x26a4 <trusted_x86_x86_sim_xdp+0x26a4>
		00000000000026a0:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    26a4: 85 c0                        	testl	%eax, %eax
    26a6: 79 05                        	jns	0x26ad <trusted_x86_x86_sim_xdp+0x26ad>
    26a8: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    26ad: 85 c0                        	testl	%eax, %eax
    26af: 0f 85 08 db ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    26b5: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    26ba: 8d 48 01                     	leal	0x1(%rax), %ecx
    26bd: f6 c1 fe                     	testb	$-0x2, %cl
    26c0: 0f 84 5d 01 00 00            	je	0x2823 <trusted_x86_x86_sim_xdp+0x2823>
    26c6: 89 c0                        	movl	%eax, %eax
    26c8: 49 29 c5                     	subq	%rax, %r13
    26cb: 4d 01 ee                     	addq	%r13, %r14
    26ce: ba 01 00 00 00               	movl	$0x1, %edx
    26d3: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    26d8: 4c 89 f6                     	movq	%r14, %rsi
    26db: e8 00 00 00 00               	callq	0x26e0 <trusted_x86_x86_sim_xdp+0x26e0>
		00000000000026dc:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    26e0: 85 c0                        	testl	%eax, %eax
    26e2: 79 05                        	jns	0x26e9 <trusted_x86_x86_sim_xdp+0x26e9>
    26e4: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    26e9: 85 c0                        	testl	%eax, %eax
    26eb: 0f 85 cc da ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    26f1: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    26f6: 8d 48 01                     	leal	0x1(%rax), %ecx
    26f9: f6 c1 fe                     	testb	$-0x2, %cl
    26fc: 0f 85 bb da ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    2702: e9 1c 01 00 00               	jmp	0x2823 <trusted_x86_x86_sim_xdp+0x2823>
    2707: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
    270c: 48 89 84 24 10 01 00 00      	movq	%rax, 0x110(%rsp)
    2714: 48 8b 84 24 90 00 00 00      	movq	0x90(%rsp), %rax
    271c: 48 8b 8c 24 a0 00 00 00      	movq	0xa0(%rsp), %rcx
    2724: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
    2729: 48 8b 8c 24 a8 00 00 00      	movq	0xa8(%rsp), %rcx
    2731: 48 89 4c 24 48               	movq	%rcx, 0x48(%rsp)
    2736: 48 8b 8c 24 b0 00 00 00      	movq	0xb0(%rsp), %rcx
    273e: 48 89 4c 24 40               	movq	%rcx, 0x40(%rsp)
    2743: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
    2748: 0f b6 71 1c                  	movzbl	0x1c(%rcx), %esi
    274c: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
    2751: 48 01 c6                     	addq	%rax, %rsi
    2754: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    2759: ba 08 00 00 00               	movl	$0x8, %edx
    275e: e8 00 00 00 00               	callq	0x2763 <trusted_x86_x86_sim_xdp+0x2763>
		000000000000275f:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2763: 85 c0                        	testl	%eax, %eax
    2765: 79 09                        	jns	0x2770 <trusted_x86_x86_sim_xdp+0x2770>
    2767: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
    2770: 85 c0                        	testl	%eax, %eax
    2772: 74 57                        	je	0x27cb <trusted_x86_x86_sim_xdp+0x27cb>
    2774: c7 84 24 04 01 00 00 2d 00 00 00     	movl	$0x2d, 0x104(%rsp)
    277f: bd e9 03 00 00               	movl	$0x3e9, %ebp            # imm = 0x3E9
    2784: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x278b <trusted_x86_x86_sim_xdp+0x278b>
		0000000000002787:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    278b: 83 78 44 2e                  	cmpl	$0x2e, 0x44(%rax)
    278f: 0f 82 77 da ff ff            	jb	0x20c <trusted_x86_x86_sim_xdp+0x20c>
    2795: b8 2d 00 00 00               	movl	$0x2d, %eax
    279a: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x27a1 <trusted_x86_x86_sim_xdp+0x27a1>
		000000000000279d:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    27a1: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    27a7: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    27af: e8 00 00 00 00               	callq	0x27b4 <trusted_x86_x86_sim_xdp+0x27b4>
		00000000000027b0:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    27b4: 48 85 c0                     	testq	%rax, %rax
    27b7: 0f 84 4f da ff ff            	je	0x20c <trusted_x86_x86_sim_xdp+0x20c>
    27bd: 48 89 c1                     	movq	%rax, %rcx
    27c0: 48 8b 09                     	movq	(%rcx), %rcx
    27c3: 48 ff c1                     	incq	%rcx
    27c6: e9 3e da ff ff               	jmp	0x209 <trusted_x86_x86_sim_xdp+0x209>
    27cb: 48 8b 6c 24 28               	movq	0x28(%rsp), %rbp
    27d0: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    27d5: 0f b6 40 1d                  	movzbl	0x1d(%rax), %eax
    27d9: 48 01 e8                     	addq	%rbp, %rax
    27dc: 4c 8b 74 24 50               	movq	0x50(%rsp), %r14
    27e1: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
    27e9: 31 d2                        	xorl	%edx, %edx
    27eb: 48 39 c1                     	cmpq	%rax, %rcx
    27ee: 48 0f 43 d0                  	cmovaeq	%rax, %rdx
    27f2: 48 29 d1                     	subq	%rdx, %rcx
    27f5: 48 81 f9 ff ff 00 00         	cmpq	$0xffff, %rcx           # imm = 0xFFFF
    27fc: b8 ff ff 00 00               	movl	$0xffff, %eax           # imm = 0xFFFF
    2801: 48 0f 42 c1                  	cmovbq	%rcx, %rax
    2805: 48 89 84 24 c0 00 00 00      	movq	%rax, 0xc0(%rsp)
    280d: 48 c1 ed 03                  	shrq	$0x3, %rbp
    2811: 81 e2 00 ff ff ff            	andl	$0xffffff00, %edx       # imm = 0xFFFFFF00
    2817: 83 ca 02                     	orl	$0x2, %edx
    281a: 89 54 24 38                  	movl	%edx, 0x38(%rsp)
    281e: e9 02 f4 ff ff               	jmp	0x1c25 <trusted_x86_x86_sim_xdp+0x1c25>
    2823: 85 c0                        	testl	%eax, %eax
    2825: 0f 85 92 d9 ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    282b: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
    2830: 48 89 c8                     	movq	%rcx, %rax
    2833: 0f b6 40 20                  	movzbl	0x20(%rax), %eax
    2837: c4 c2 f9 f7 c5               	shlxq	%rax, %r13, %rax
    283c: 48 89 ca                     	movq	%rcx, %rdx
    283f: 48 89 d9                     	movq	%rbx, %rcx
    2842: 48 03 81 20 0f 00 00         	addq	0xf20(%rcx), %rax
    2849: 48 89 d1                     	movq	%rdx, %rcx
    284c: 0f b6 71 1b                  	movzbl	0x1b(%rcx), %esi
    2850: 48 01 c6                     	addq	%rax, %rsi
    2853: 48 89 b4 24 c8 00 00 00      	movq	%rsi, 0xc8(%rsp)
    285b: 0f 84 68 d9 ff ff            	je	0x1c9 <trusted_x86_x86_sim_xdp+0x1c9>
    2861: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
    2866: 4c 89 e7                     	movq	%r12, %rdi
    2869: e8 00 00 00 00               	callq	0x286e <trusted_x86_x86_sim_xdp+0x286e>
		000000000000286a:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    286e: 49 89 c6                     	movq	%rax, %r14
    2871: 45 85 f6                     	testl	%r14d, %r14d
    2874: 79 0f                        	jns	0x2885 <trusted_x86_x86_sim_xdp+0x2885>
    2876: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
    287b: 4c 89 e7                     	movq	%r12, %rdi
    287e: 31 f6                        	xorl	%esi, %esi
    2880: e8 00 00 00 00               	callq	0x2885 <trusted_x86_x86_sim_xdp+0x2885>
		0000000000002881:  R_X86_64_PLT32	memset-0x4
    2885: 45 85 f6                     	testl	%r14d, %r14d
    2888: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    288d: 0f 85 8e dd ff ff            	jne	0x621 <trusted_x86_x86_sim_xdp+0x621>
    2893: 0f b7 40 10                  	movzwl	0x10(%rax), %eax
    2897: 0f b7 c0                     	movzwl	%ax, %eax
    289a: 3d f8 01 00 00               	cmpl	$0x1f8, %eax            # imm = 0x1F8
    289f: 0f 87 39 11 00 00            	ja	0x39de <trusted_x86_x86_sim_xdp+0x39de>
    28a5: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
    28aa: 0f b7 49 12                  	movzwl	0x12(%rcx), %ecx
    28ae: 0f b7 c9                     	movzwl	%cx, %ecx
    28b1: 81 f9 fc 01 00 00            	cmpl	$0x1fc, %ecx            # imm = 0x1FC
    28b7: 0f 87 21 11 00 00            	ja	0x39de <trusted_x86_x86_sim_xdp+0x39de>
    28bd: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    28c2: 0f b7 52 14                  	movzwl	0x14(%rdx), %edx
    28c6: 0f b7 d2                     	movzwl	%dx, %edx
    28c9: 81 fa f8 01 00 00            	cmpl	$0x1f8, %edx            # imm = 0x1F8
    28cf: 0f 87 09 11 00 00            	ja	0x39de <trusted_x86_x86_sim_xdp+0x39de>
    28d5: 48 8b 7c 24 10               	movq	0x10(%rsp), %rdi
    28da: 48 89 fe                     	movq	%rdi, %rsi
    28dd: 0f b6 76 17                  	movzbl	0x17(%rsi), %esi
    28e1: 40 0f b6 f6                  	movzbl	%sil, %esi
    28e5: 4c 01 e6                     	addq	%r12, %rsi
    28e8: 48 8b 36                     	movq	(%rsi), %rsi
    28eb: 48 89 b4 24 d0 00 00 00      	movq	%rsi, 0xd0(%rsp)
    28f3: 48 89 fe                     	movq	%rdi, %rsi
    28f6: 0f b6 76 18                  	movzbl	0x18(%rsi), %esi
    28fa: 40 0f b6 f6                  	movzbl	%sil, %esi
    28fe: 4c 01 e6                     	addq	%r12, %rsi
    2901: 48 8b 36                     	movq	(%rsi), %rsi
    2904: 48 89 b4 24 d8 00 00 00      	movq	%rsi, 0xd8(%rsp)
    290c: 48 89 fe                     	movq	%rdi, %rsi
    290f: 0f b6 76 1a                  	movzbl	0x1a(%rsi), %esi
    2913: 40 0f b6 f6                  	movzbl	%sil, %esi
    2917: 4c 01 e6                     	addq	%r12, %rsi
    291a: 8b 36                        	movl	(%rsi), %esi
    291c: c1 e6 03                     	shll	$0x3, %esi
    291f: 89 b4 24 f0 00 00 00         	movl	%esi, 0xf0(%rsp)
    2926: 48 89 fe                     	movq	%rdi, %rsi
    2929: 0f b6 76 19                  	movzbl	0x19(%rsi), %esi
    292d: 40 0f b6 f6                  	movzbl	%sil, %esi
    2931: 4c 01 e6                     	addq	%r12, %rsi
    2934: 0f b7 36                     	movzwl	(%rsi), %esi
    2937: 66 89 b4 24 f8 00 00 00      	movw	%si, 0xf8(%rsp)
    293f: 4c 01 e1                     	addq	%r12, %rcx
    2942: 8b 09                        	movl	(%rcx), %ecx
    2944: 89 8c 24 f4 00 00 00         	movl	%ecx, 0xf4(%rsp)
    294b: 4c 01 e2                     	addq	%r12, %rdx
    294e: 8b 0a                        	movl	(%rdx), %ecx
    2950: 89 8c 24 ec 00 00 00         	movl	%ecx, 0xec(%rsp)
    2957: 4c 01 e0                     	addq	%r12, %rax
    295a: 48 8b 00                     	movq	(%rax), %rax
    295d: 48 89 84 24 e0 00 00 00      	movq	%rax, 0xe0(%rsp)
    2965: 48 89 f8                     	movq	%rdi, %rax
    2968: 0f b6 40 16                  	movzbl	0x16(%rax), %eax
    296c: 0f b6 c0                     	movzbl	%al, %eax
    296f: 4c 01 e0                     	addq	%r12, %rax
    2972: 48 8b 30                     	movq	(%rax), %rsi
    2975: ba 04 00 00 00               	movl	$0x4, %edx
    297a: 48 8d bc 24 e8 00 00 00      	leaq	0xe8(%rsp), %rdi
    2982: e8 00 00 00 00               	callq	0x2987 <trusted_x86_x86_sim_xdp+0x2987>
		0000000000002983:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2987: 85 c0                        	testl	%eax, %eax
    2989: 79 0b                        	jns	0x2996 <trusted_x86_x86_sim_xdp+0x2996>
    298b: c7 84 24 e8 00 00 00 00 00 00 00     	movl	$0x0, 0xe8(%rsp)
    2996: 85 c0                        	testl	%eax, %eax
    2998: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    299d: 0f 85 7e dc ff ff            	jne	0x621 <trusted_x86_x86_sim_xdp+0x621>
    29a3: 0f b6 40 21                  	movzbl	0x21(%rax), %eax
    29a7: 4c 8b b4 24 c8 00 00 00      	movq	0xc8(%rsp), %r14
    29af: 48 8b 8c 24 d0 00 00 00      	movq	0xd0(%rsp), %rcx
    29b7: 84 c0                        	testb	%al, %al
    29b9: 74 1f                        	je	0x29da <trusted_x86_x86_sim_xdp+0x29da>
    29bb: 89 c9                        	movl	%ecx, %ecx
    29bd: 4c 01 f1                     	addq	%r14, %rcx
    29c0: 48 89 8c 24 d0 00 00 00      	movq	%rcx, 0xd0(%rsp)
    29c8: 8b 94 24 d8 00 00 00         	movl	0xd8(%rsp), %edx
    29cf: 4c 01 f2                     	addq	%r14, %rdx
    29d2: 48 89 94 24 d8 00 00 00      	movq	%rdx, 0xd8(%rsp)
    29da: 8b ac 24 e8 00 00 00         	movl	0xe8(%rsp), %ebp
    29e1: 48 8b 54 24 40               	movq	0x40(%rsp), %rdx
    29e6: 89 d6                        	movl	%edx, %esi
    29e8: 29 ce                        	subl	%ecx, %esi
    29ea: 48 89 b4 24 c0 00 00 00      	movq	%rsi, 0xc0(%rsp)
    29f2: 81 fd 6d 61 74 69            	cmpl	$0x6974616d, %ebp       # imm = 0x6974616D
    29f8: 7f 19                        	jg	0x2a13 <trusted_x86_x86_sim_xdp+0x2a13>
    29fa: 81 fd 76 74 61 62            	cmpl	$0x62617476, %ebp       # imm = 0x62617476
    2a00: 0f 85 e5 00 00 00            	jne	0x2aeb <trusted_x86_x86_sim_xdp+0x2aeb>
    2a06: c7 44 24 38 01 00 00 00      	movl	$0x1, 0x38(%rsp)
    2a0e: e9 c3 00 00 00               	jmp	0x2ad6 <trusted_x86_x86_sim_xdp+0x2ad6>
    2a13: 81 fd 6e 61 74 69            	cmpl	$0x6974616e, %ebp       # imm = 0x6974616E
    2a19: 74 11                        	je	0x2a2c <trusted_x86_x86_sim_xdp+0x2a2c>
    2a1b: 81 fd 6e 6d 65 74            	cmpl	$0x74656d6e, %ebp       # imm = 0x74656D6E
    2a21: 0f 85 a6 01 00 00            	jne	0x2bcd <trusted_x86_x86_sim_xdp+0x2bcd>
    2a27: 48 8b 54 24 40               	movq	0x40(%rsp), %rdx
    2a2c: 48 8b b4 24 e0 00 00 00      	movq	0xe0(%rsp), %rsi
    2a34: 89 f7                        	movl	%esi, %edi
    2a36: 4c 01 f7                     	addq	%r14, %rdi
    2a39: 84 c0                        	testb	%al, %al
    2a3b: 8b ac 24 f4 00 00 00         	movl	0xf4(%rsp), %ebp
    2a42: 48 0f 44 fe                  	cmoveq	%rsi, %rdi
    2a46: 48 39 fa                     	cmpq	%rdi, %rdx
    2a49: 75 59                        	jne	0x2aa4 <trusted_x86_x86_sim_xdp+0x2aa4>
    2a4b: 8b b4 24 ec 00 00 00         	movl	0xec(%rsp), %esi
    2a52: 48 03 74 24 20               	addq	0x20(%rsp), %rsi
    2a57: ba 08 00 00 00               	movl	$0x8, %edx
    2a5c: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    2a61: e8 00 00 00 00               	callq	0x2a66 <trusted_x86_x86_sim_xdp+0x2a66>
		0000000000002a62:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2a66: 85 c0                        	testl	%eax, %eax
    2a68: 79 09                        	jns	0x2a73 <trusted_x86_x86_sim_xdp+0x2a73>
    2a6a: 48 c7 44 24 58 00 00 00 00   	movq	$0x0, 0x58(%rsp)
    2a73: 48 8b 8c 24 d0 00 00 00      	movq	0xd0(%rsp), %rcx
    2a7b: 85 c0                        	testl	%eax, %eax
    2a7d: 75 25                        	jne	0x2aa4 <trusted_x86_x86_sim_xdp+0x2aa4>
    2a7f: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    2a84: 48 39 c8                     	cmpq	%rcx, %rax
    2a87: 72 1b                        	jb	0x2aa4 <trusted_x86_x86_sim_xdp+0x2aa4>
    2a89: 48 3b 84 24 d8 00 00 00      	cmpq	0xd8(%rsp), %rax
    2a91: 73 11                        	jae	0x2aa4 <trusted_x86_x86_sim_xdp+0x2aa4>
    2a93: 89 c2                        	movl	%eax, %edx
    2a95: 29 ca                        	subl	%ecx, %edx
    2a97: 48 89 94 24 c0 00 00 00      	movq	%rdx, 0xc0(%rsp)
    2a9f: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    2aa4: 0f b7 84 24 f8 00 00 00      	movzwl	0xf8(%rsp), %eax
    2aac: 48 01 c8                     	addq	%rcx, %rax
    2aaf: 48 39 44 24 40               	cmpq	%rax, 0x40(%rsp)
    2ab4: 0f 83 2d 01 00 00            	jae	0x2be7 <trusted_x86_x86_sim_xdp+0x2be7>
    2aba: 48 83 c0 fc                  	addq	$-0x4, %rax
    2abe: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    2ac4: 83 c9 03                     	orl	$0x3, %ecx
    2ac7: 89 4c 24 38                  	movl	%ecx, 0x38(%rsp)
    2acb: 48 39 44 24 40               	cmpq	%rax, 0x40(%rsp)
    2ad0: 0f 83 5c 01 00 00            	jae	0x2c32 <trusted_x86_x86_sim_xdp+0x2c32>
    2ad6: c7 84 24 f0 00 00 00 08 00 00 00     	movl	$0x8, 0xf0(%rsp)
    2ae1: b8 08 00 00 00               	movl	$0x8, %eax
    2ae6: e9 61 01 00 00               	jmp	0x2c4c <trusted_x86_x86_sim_xdp+0x2c4c>
    2aeb: 81 fd 49 6e 74 65            	cmpl	$0x65746e49, %ebp       # imm = 0x65746E49
    2af1: 0f 85 d6 00 00 00            	jne	0x2bcd <trusted_x86_x86_sim_xdp+0x2bcd>
    2af7: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    2afc: 48 3b 44 24 20               	cmpq	0x20(%rsp), %rax
    2b01: 0f 82 3f 07 00 00            	jb	0x3246 <trusted_x86_x86_sim_xdp+0x3246>
    2b07: b8 00 10 00 00               	movl	$0x1000, %eax           # imm = 0x1000
    2b0c: 48 03 44 24 20               	addq	0x20(%rsp), %rax
    2b11: 48 39 44 24 48               	cmpq	%rax, 0x48(%rsp)
    2b16: 0f 83 2a 07 00 00            	jae	0x3246 <trusted_x86_x86_sim_xdp+0x3246>
    2b1c: 48 8b 74 24 48               	movq	0x48(%rsp), %rsi
    2b21: 48 83 c6 b0                  	addq	$-0x50, %rsi
    2b25: ba 60 00 00 00               	movl	$0x60, %edx
    2b2a: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    2b2f: e8 00 00 00 00               	callq	0x2b34 <trusted_x86_x86_sim_xdp+0x2b34>
		0000000000002b30:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2b34: 85 c0                        	testl	%eax, %eax
    2b36: 79 64                        	jns	0x2b9c <trusted_x86_x86_sim_xdp+0x2b9c>
    2b38: 48 8d 4c 24 58               	leaq	0x58(%rsp), %rcx
    2b3d: 48 c7 41 58 00 00 00 00      	movq	$0x0, 0x58(%rcx)
    2b45: 48 c7 41 50 00 00 00 00      	movq	$0x0, 0x50(%rcx)
    2b4d: 48 c7 41 48 00 00 00 00      	movq	$0x0, 0x48(%rcx)
    2b55: 48 c7 41 40 00 00 00 00      	movq	$0x0, 0x40(%rcx)
    2b5d: 48 c7 41 38 00 00 00 00      	movq	$0x0, 0x38(%rcx)
    2b65: 48 c7 41 30 00 00 00 00      	movq	$0x0, 0x30(%rcx)
    2b6d: 48 c7 41 28 00 00 00 00      	movq	$0x0, 0x28(%rcx)
    2b75: 48 c7 41 20 00 00 00 00      	movq	$0x0, 0x20(%rcx)
    2b7d: 48 c7 41 18 00 00 00 00      	movq	$0x0, 0x18(%rcx)
    2b85: 48 c7 41 10 00 00 00 00      	movq	$0x0, 0x10(%rcx)
    2b8d: 48 c7 41 08 00 00 00 00      	movq	$0x0, 0x8(%rcx)
    2b95: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
    2b9c: 85 c0                        	testl	%eax, %eax
    2b9e: 0f 85 a2 06 00 00            	jne	0x3246 <trusted_x86_x86_sim_xdp+0x3246>
    2ba4: 48 89 d8                     	movq	%rbx, %rax
    2ba7: 83 b8 c0 02 00 00 00         	cmpl	$0x0, 0x2c0(%rax)
    2bae: 0f 84 15 06 00 00            	je	0x31c9 <trusted_x86_x86_sim_xdp+0x31c9>
    2bb4: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    2bb9: 80 78 1f 00                  	cmpb	$0x0, 0x1f(%rax)
    2bbd: 0f 84 12 06 00 00            	je	0x31d5 <trusted_x86_x86_sim_xdp+0x31d5>
    2bc3: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
    2bc8: e9 0d 06 00 00               	jmp	0x31da <trusted_x86_x86_sim_xdp+0x31da>
    2bcd: 8b 84 24 f0 00 00 00         	movl	0xf0(%rsp), %eax
    2bd4: c7 44 24 38 00 00 00 00      	movl	$0x0, 0x38(%rsp)
    2bdc: 85 c0                        	testl	%eax, %eax
    2bde: 75 6c                        	jne	0x2c4c <trusted_x86_x86_sim_xdp+0x2c4c>
    2be0: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    2be5: eb 50                        	jmp	0x2c37 <trusted_x86_x86_sim_xdp+0x2c37>
    2be7: 8b 84 24 f0 00 00 00         	movl	0xf0(%rsp), %eax
    2bee: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
    2bf3: 48 8b 54 24 48               	movq	0x48(%rsp), %rdx
    2bf8: 48 8d 34 01                  	leaq	(%rcx,%rax), %rsi
    2bfc: 48 83 c6 30                  	addq	$0x30, %rsi
    2c00: 48 89 74 24 50               	movq	%rsi, 0x50(%rsp)
    2c05: 48 39 ca                     	cmpq	%rcx, %rdx
    2c08: 0f 82 40 02 00 00            	jb	0x2e4e <trusted_x86_x86_sim_xdp+0x2e4e>
    2c0e: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    2c14: 83 c9 03                     	orl	$0x3, %ecx
    2c17: 89 4c 24 38                  	movl	%ecx, 0x38(%rsp)
    2c1b: 48 8b 4c 24 48               	movq	0x48(%rsp), %rcx
    2c20: 48 3b 4c 24 50               	cmpq	0x50(%rsp), %rcx
    2c25: 0f 83 1e 02 00 00            	jae	0x2e49 <trusted_x86_x86_sim_xdp+0x2e49>
    2c2b: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    2c30: eb 05                        	jmp	0x2c37 <trusted_x86_x86_sim_xdp+0x2c37>
    2c32: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    2c37: c7 84 24 f0 00 00 00 10 00 00 00     	movl	$0x10, 0xf0(%rsp)
    2c42: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
    2c47: b8 10 00 00 00               	movl	$0x10, %eax
    2c4c: 89 c6                        	movl	%eax, %esi
    2c4e: 48 03 74 24 20               	addq	0x20(%rsp), %rsi
    2c53: 48 89 74 24 20               	movq	%rsi, 0x20(%rsp)
    2c58: 48 83 c6 f0                  	addq	$-0x10, %rsi
    2c5c: ba 10 00 00 00               	movl	$0x10, %edx
    2c61: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    2c66: e8 00 00 00 00               	callq	0x2c6b <trusted_x86_x86_sim_xdp+0x2c6b>
		0000000000002c67:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2c6b: 85 c0                        	testl	%eax, %eax
    2c6d: 79 14                        	jns	0x2c83 <trusted_x86_x86_sim_xdp+0x2c83>
    2c6f: 48 8d 44 24 58               	leaq	0x58(%rsp), %rax
    2c74: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
    2c7c: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    2c83: 83 bc 24 f0 00 00 00 10      	cmpl	$0x10, 0xf0(%rsp)
    2c8b: 72 0a                        	jb	0x2c97 <trusted_x86_x86_sim_xdp+0x2c97>
    2c8d: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    2c92: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    2c97: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
    2c9c: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    2ca1: 48 89 d8                     	movq	%rbx, %rax
    2ca4: 8b 88 c0 02 00 00            	movl	0x2c0(%rax), %ecx
    2caa: 83 f9 7e                     	cmpl	$0x7e, %ecx
    2cad: 0f 87 ed dd ff ff            	ja	0xaa0 <trusted_x86_x86_sim_xdp+0xaa0>
    2cb3: 48 89 d8                     	movq	%rbx, %rax
    2cb6: 0f b6 80 30 0f 00 00         	movzbl	0xf30(%rax), %eax
    2cbd: 8b 54 24 38                  	movl	0x38(%rsp), %edx
    2cc1: 48 8b b4 24 c0 00 00 00      	movq	0xc0(%rsp), %rsi
    2cc9: 8d 79 01                     	leal	0x1(%rcx), %edi
    2ccc: 4c 8b 84 24 70 01 00 00      	movq	0x170(%rsp), %r8
    2cd4: 41 89 38                     	movl	%edi, (%r8)
    2cd7: c1 e1 03                     	shll	$0x3, %ecx
    2cda: 8d 0c 49                     	leal	(%rcx,%rcx,2), %ecx
    2cdd: 48 8b bc 24 b8 01 00 00      	movq	0x1b8(%rsp), %rdi
    2ce5: 48 01 cf                     	addq	%rcx, %rdi
    2ce8: 4c 89 37                     	movq	%r14, (%rdi)
    2ceb: 48 c1 e6 20                  	shlq	$0x20, %rsi
    2cef: 89 ef                        	movl	%ebp, %edi
    2cf1: 48 09 f7                     	orq	%rsi, %rdi
    2cf4: 48 c1 e2 3c                  	shlq	$0x3c, %rdx
    2cf8: 48 09 d7                     	orq	%rdx, %rdi
    2cfb: 48 8b 94 24 b0 01 00 00      	movq	0x1b0(%rsp), %rdx
    2d03: 48 01 ca                     	addq	%rcx, %rdx
    2d06: 48 89 3a                     	movq	%rdi, (%rdx)
    2d09: 48 8b 94 24 c0 01 00 00      	movq	0x1c0(%rsp), %rdx
    2d11: 48 8d 14 0a                  	leaq	(%rdx,%rcx), %rdx
    2d15: c6 02 05                     	movb	$0x5, (%rdx)
    2d18: 48 8b 94 24 50 01 00 00      	movq	0x150(%rsp), %rdx
    2d20: 48 01 ca                     	addq	%rcx, %rdx
    2d23: 88 02                        	movb	%al, (%rdx)
    2d25: 48 8b 84 24 a0 01 00 00      	movq	0x1a0(%rsp), %rax
    2d2d: 48 01 c8                     	addq	%rcx, %rax
    2d30: c7 00 00 00 00 00            	movl	$0x0, (%rax)
    2d36: 48 03 8c 24 a8 01 00 00      	addq	0x1a8(%rsp), %rcx
    2d3e: 66 c7 01 00 00               	movw	$0x0, (%rcx)
    2d43: 48 8b 44 24 40               	movq	0x40(%rsp), %rax
    2d48: 48 8b 8c 24 90 01 00 00      	movq	0x190(%rsp), %rcx
    2d50: 48 89 01                     	movq	%rax, (%rcx)
    2d53: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    2d58: 48 8b 8c 24 88 01 00 00      	movq	0x188(%rsp), %rcx
    2d60: 48 89 01                     	movq	%rax, (%rcx)
    2d63: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    2d68: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
    2d70: 48 89 01                     	movq	%rax, (%rcx)
    2d73: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
    2d7b: c6 00 01                     	movb	$0x1, (%rax)
    2d7e: c7 44 24 58 2a 00 00 00      	movl	$0x2a, 0x58(%rsp)
    2d86: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x2d8d <trusted_x86_x86_sim_xdp+0x2d8d>
		0000000000002d89:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2d8d: 83 78 44 2b                  	cmpl	$0x2b, 0x44(%rax)
    2d91: 72 30                        	jb	0x2dc3 <trusted_x86_x86_sim_xdp+0x2dc3>
    2d93: b8 2a 00 00 00               	movl	$0x2a, %eax
    2d98: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2d9f <trusted_x86_x86_sim_xdp+0x2d9f>
		0000000000002d9b:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2d9f: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    2da5: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    2dad: e8 00 00 00 00               	callq	0x2db2 <trusted_x86_x86_sim_xdp+0x2db2>
		0000000000002dae:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    2db2: 48 85 c0                     	testq	%rax, %rax
    2db5: 74 0c                        	je	0x2dc3 <trusted_x86_x86_sim_xdp+0x2dc3>
    2db7: 48 89 c1                     	movq	%rax, %rcx
    2dba: 48 8b 09                     	movq	(%rcx), %rcx
    2dbd: 48 ff c1                     	incq	%rcx
    2dc0: 48 89 08                     	movq	%rcx, (%rax)
    2dc3: 48 89 d8                     	movq	%rbx, %rax
    2dc6: 4c 8b b0 d0 0e 00 00         	movq	0xed0(%rax), %r14
    2dcd: 4d 85 f6                     	testq	%r14, %r14
    2dd0: 0f 84 55 15 00 00            	je	0x432b <trusted_x86_x86_sim_xdp+0x432b>
    2dd6: 4c 3b b4 24 98 01 00 00      	cmpq	0x198(%rsp), %r14
    2dde: 0f 83 f8 e3 ff ff            	jae	0x11dc <trusted_x86_x86_sim_xdp+0x11dc>
    2de4: 49 81 fe 00 10 00 00         	cmpq	$0x1000, %r14           # imm = 0x1000
    2deb: 0f 82 0b e4 ff ff            	jb	0x11fc <trusted_x86_x86_sim_xdp+0x11fc>
    2df1: 48 89 d8                     	movq	%rbx, %rax
    2df4: 8b 00                        	movl	(%rax), %eax
    2df6: c7 44 24 58 60 00 00 00      	movl	$0x60, 0x58(%rsp)
    2dfe: 0f 38 f1 44 24 5c            	movbel	%eax, 0x5c(%rsp)
    2e04: 4c 0f 38 f1 74 24 60         	movbeq	%r14, 0x60(%rsp)
    2e0b: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    2e10: 0f 84 82 02 00 00            	je	0x3098 <trusted_x86_x86_sim_xdp+0x3098>
    2e16: 8b 44 24 58                  	movl	0x58(%rsp), %eax
    2e1a: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2e21 <trusted_x86_x86_sim_xdp+0x2e21>
		0000000000002e1d:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2e21: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    2e24: 0f 83 fc 15 00 00            	jae	0x4426 <trusted_x86_x86_sim_xdp+0x4426>
    2e2a: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2e31 <trusted_x86_x86_sim_xdp+0x2e31>
		0000000000002e2d:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2e31: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    2e37: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    2e3f: e8 00 00 00 00               	callq	0x2e44 <trusted_x86_x86_sim_xdp+0x2e44>
		0000000000002e40:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    2e44: e9 59 02 00 00               	jmp	0x30a2 <trusted_x86_x86_sim_xdp+0x30a2>
    2e49: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
    2e4e: 48 8d 14 01                  	leaq	(%rcx,%rax), %rdx
    2e52: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
    2e57: 48 8d 34 01                  	leaq	(%rcx,%rax), %rsi
    2e5b: 48 83 c6 f8                  	addq	$-0x8, %rsi
    2e5f: ba 30 00 00 00               	movl	$0x30, %edx
    2e64: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    2e69: e8 00 00 00 00               	callq	0x2e6e <trusted_x86_x86_sim_xdp+0x2e6e>
		0000000000002e6a:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2e6e: 85 c0                        	testl	%eax, %eax
    2e70: 79 34                        	jns	0x2ea6 <trusted_x86_x86_sim_xdp+0x2ea6>
    2e72: 48 8d 44 24 58               	leaq	0x58(%rsp), %rax
    2e77: 48 c7 40 28 00 00 00 00      	movq	$0x0, 0x28(%rax)
    2e7f: 48 c7 40 20 00 00 00 00      	movq	$0x0, 0x20(%rax)
    2e87: 48 c7 40 18 00 00 00 00      	movq	$0x0, 0x18(%rax)
    2e8f: 48 c7 40 10 00 00 00 00      	movq	$0x0, 0x10(%rax)
    2e97: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
    2e9f: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    2ea6: 49 bd 00 00 00 00 00 00 00 ff	movabsq	$-0x100000000000000, %r13 # imm = 0xFF00000000000000
    2eb0: 48 89 d8                     	movq	%rbx, %rax
    2eb3: 8b 00                        	movl	(%rax), %eax
    2eb5: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    2ebd: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    2ec3: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    2ec8: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    2ecf: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    2ed4: 74 2c                        	je	0x2f02 <trusted_x86_x86_sim_xdp+0x2f02>
    2ed6: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    2eda: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2ee1 <trusted_x86_x86_sim_xdp+0x2ee1>
		0000000000002edd:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2ee1: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    2ee4: 73 4b                        	jae	0x2f31 <trusted_x86_x86_sim_xdp+0x2f31>
    2ee6: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2eed <trusted_x86_x86_sim_xdp+0x2eed>
		0000000000002ee9:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2eed: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    2ef3: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    2efb: e8 00 00 00 00               	callq	0x2f00 <trusted_x86_x86_sim_xdp+0x2f00>
		0000000000002efc:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    2f00: eb 0a                        	jmp	0x2f0c <trusted_x86_x86_sim_xdp+0x2f0c>
    2f02: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    2f07: e8 00 00 00 00               	callq	0x2f0c <trusted_x86_x86_sim_xdp+0x2f0c>
		0000000000002f08:  R_X86_64_PLT32	.text+0x7c
    2f0c: 48 85 c0                     	testq	%rax, %rax
    2f0f: 74 20                        	je	0x2f31 <trusted_x86_x86_sim_xdp+0x2f31>
    2f11: 48 8b 40 08                  	movq	0x8(%rax), %rax
    2f15: 4c 21 e8                     	andq	%r13, %rax
    2f18: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    2f22: 48 39 c8                     	cmpq	%rcx, %rax
    2f25: 75 0a                        	jne	0x2f31 <trusted_x86_x86_sim_xdp+0x2f31>
    2f27: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    2f2c: e9 e5 0a 00 00               	jmp	0x3a16 <trusted_x86_x86_sim_xdp+0x3a16>
    2f31: 48 89 d8                     	movq	%rbx, %rax
    2f34: 8b 00                        	movl	(%rax), %eax
    2f36: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    2f3e: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    2f44: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
    2f49: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    2f50: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    2f55: 74 2c                        	je	0x2f83 <trusted_x86_x86_sim_xdp+0x2f83>
    2f57: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    2f5b: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2f62 <trusted_x86_x86_sim_xdp+0x2f62>
		0000000000002f5e:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2f62: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    2f65: 73 4f                        	jae	0x2fb6 <trusted_x86_x86_sim_xdp+0x2fb6>
    2f67: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2f6e <trusted_x86_x86_sim_xdp+0x2f6e>
		0000000000002f6a:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2f6e: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    2f74: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    2f7c: e8 00 00 00 00               	callq	0x2f81 <trusted_x86_x86_sim_xdp+0x2f81>
		0000000000002f7d:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    2f81: eb 0a                        	jmp	0x2f8d <trusted_x86_x86_sim_xdp+0x2f8d>
    2f83: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    2f88: e8 00 00 00 00               	callq	0x2f8d <trusted_x86_x86_sim_xdp+0x2f8d>
		0000000000002f89:  R_X86_64_PLT32	.text+0x7c
    2f8d: 48 85 c0                     	testq	%rax, %rax
    2f90: 74 24                        	je	0x2fb6 <trusted_x86_x86_sim_xdp+0x2fb6>
    2f92: 48 8b 40 08                  	movq	0x8(%rax), %rax
    2f96: 4c 21 e8                     	andq	%r13, %rax
    2f99: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    2fa3: 48 39 c8                     	cmpq	%rcx, %rax
    2fa6: 75 0e                        	jne	0x2fb6 <trusted_x86_x86_sim_xdp+0x2fb6>
    2fa8: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    2fad: 48 83 c0 08                  	addq	$0x8, %rax
    2fb1: e9 60 0a 00 00               	jmp	0x3a16 <trusted_x86_x86_sim_xdp+0x3a16>
    2fb6: 48 89 d8                     	movq	%rbx, %rax
    2fb9: 8b 00                        	movl	(%rax), %eax
    2fbb: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    2fc3: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    2fc9: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
    2fce: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    2fd5: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    2fda: 74 2c                        	je	0x3008 <trusted_x86_x86_sim_xdp+0x3008>
    2fdc: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    2fe0: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2fe7 <trusted_x86_x86_sim_xdp+0x2fe7>
		0000000000002fe3:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2fe7: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    2fea: 73 4f                        	jae	0x303b <trusted_x86_x86_sim_xdp+0x303b>
    2fec: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x2ff3 <trusted_x86_x86_sim_xdp+0x2ff3>
		0000000000002fef:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2ff3: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    2ff9: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    3001: e8 00 00 00 00               	callq	0x3006 <trusted_x86_x86_sim_xdp+0x3006>
		0000000000003002:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3006: eb 0a                        	jmp	0x3012 <trusted_x86_x86_sim_xdp+0x3012>
    3008: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    300d: e8 00 00 00 00               	callq	0x3012 <trusted_x86_x86_sim_xdp+0x3012>
		000000000000300e:  R_X86_64_PLT32	.text+0x7c
    3012: 48 85 c0                     	testq	%rax, %rax
    3015: 74 24                        	je	0x303b <trusted_x86_x86_sim_xdp+0x303b>
    3017: 48 8b 40 08                  	movq	0x8(%rax), %rax
    301b: 4c 21 e8                     	andq	%r13, %rax
    301e: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    3028: 48 39 c8                     	cmpq	%rcx, %rax
    302b: 75 0e                        	jne	0x303b <trusted_x86_x86_sim_xdp+0x303b>
    302d: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    3032: 48 83 c0 10                  	addq	$0x10, %rax
    3036: e9 db 09 00 00               	jmp	0x3a16 <trusted_x86_x86_sim_xdp+0x3a16>
    303b: 48 89 d8                     	movq	%rbx, %rax
    303e: 8b 00                        	movl	(%rax), %eax
    3040: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    3048: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    304e: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
    3053: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    305a: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    305f: 0f 84 d4 00 00 00            	je	0x3139 <trusted_x86_x86_sim_xdp+0x3139>
    3065: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    3069: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3070 <trusted_x86_x86_sim_xdp+0x3070>
		000000000000306c:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3070: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    3073: 0f 83 f3 00 00 00            	jae	0x316c <trusted_x86_x86_sim_xdp+0x316c>
    3079: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3080 <trusted_x86_x86_sim_xdp+0x3080>
		000000000000307c:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3080: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    3086: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    308e: e8 00 00 00 00               	callq	0x3093 <trusted_x86_x86_sim_xdp+0x3093>
		000000000000308f:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3093: e9 ab 00 00 00               	jmp	0x3143 <trusted_x86_x86_sim_xdp+0x3143>
    3098: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    309d: e8 00 00 00 00               	callq	0x30a2 <trusted_x86_x86_sim_xdp+0x30a2>
		000000000000309e:  R_X86_64_PLT32	.text+0x7c
    30a2: 48 85 c0                     	testq	%rax, %rax
    30a5: 0f 84 7b 13 00 00            	je	0x4426 <trusted_x86_x86_sim_xdp+0x4426>
    30ab: 48 89 c1                     	movq	%rax, %rcx
    30ae: 4c 8b 69 08                  	movq	0x8(%rcx), %r13
    30b2: 4c 89 e9                     	movq	%r13, %rcx
    30b5: 48 ba ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    30bf: 48 21 d1                     	andq	%rdx, %rcx
    30c2: 48 8b 94 24 68 01 00 00      	movq	0x168(%rsp), %rdx
    30ca: 48 89 0a                     	movq	%rcx, (%rdx)
    30cd: 48 8b 00                     	movq	(%rax), %rax
    30d0: 48 8b 94 24 60 01 00 00      	movq	0x160(%rsp), %rdx
    30d8: 48 89 02                     	movq	%rax, (%rdx)
    30db: 49 c1 ed 38                  	shrq	$0x38, %r13
    30df: 49 29 ce                     	subq	%rcx, %r14
    30e2: 48 8b 8c 24 58 01 00 00      	movq	0x158(%rsp), %rcx
    30ea: 4c 89 31                     	movq	%r14, (%rcx)
    30ed: 49 83 fd 01                  	cmpq	$0x1, %r13
    30f1: 0f 85 94 02 00 00            	jne	0x338b <trusted_x86_x86_sim_xdp+0x338b>
    30f7: 48 89 44 24 58               	movq	%rax, 0x58(%rsp)
    30fc: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x3103 <trusted_x86_x86_sim_xdp+0x3103>
		00000000000030ff:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    3103: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x310a <trusted_x86_x86_sim_xdp+0x310a>
		0000000000003106:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    310a: 0f 84 8d 01 00 00            	je	0x329d <trusted_x86_x86_sim_xdp+0x329d>
    3110: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x3117 <trusted_x86_x86_sim_xdp+0x3117>
		0000000000003113:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
    3117: 0f 84 80 01 00 00            	je	0x329d <trusted_x86_x86_sim_xdp+0x329d>
    311d: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    3122: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x3129 <trusted_x86_x86_sim_xdp+0x3129>
		0000000000003125:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3129: 0f 85 a2 01 00 00            	jne	0x32d1 <trusted_x86_x86_sim_xdp+0x32d1>
    312f: e8 00 00 00 00               	callq	0x3134 <trusted_x86_x86_sim_xdp+0x3134>
		0000000000003130:  R_X86_64_PLT32	.text+0x7c
    3134: e9 9d 01 00 00               	jmp	0x32d6 <trusted_x86_x86_sim_xdp+0x32d6>
    3139: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    313e: e8 00 00 00 00               	callq	0x3143 <trusted_x86_x86_sim_xdp+0x3143>
		000000000000313f:  R_X86_64_PLT32	.text+0x7c
    3143: 48 85 c0                     	testq	%rax, %rax
    3146: 74 24                        	je	0x316c <trusted_x86_x86_sim_xdp+0x316c>
    3148: 48 8b 40 08                  	movq	0x8(%rax), %rax
    314c: 4c 21 e8                     	andq	%r13, %rax
    314f: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    3159: 48 39 c8                     	cmpq	%rcx, %rax
    315c: 75 0e                        	jne	0x316c <trusted_x86_x86_sim_xdp+0x316c>
    315e: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    3163: 48 83 c0 18                  	addq	$0x18, %rax
    3167: e9 aa 08 00 00               	jmp	0x3a16 <trusted_x86_x86_sim_xdp+0x3a16>
    316c: 48 89 d8                     	movq	%rbx, %rax
    316f: 8b 00                        	movl	(%rax), %eax
    3171: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    3179: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    317f: 48 8b 44 24 78               	movq	0x78(%rsp), %rax
    3184: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    318b: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    3190: 0f 84 59 05 00 00            	je	0x36ef <trusted_x86_x86_sim_xdp+0x36ef>
    3196: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    319a: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x31a1 <trusted_x86_x86_sim_xdp+0x31a1>
		000000000000319d:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    31a1: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    31a4: 0f 83 78 05 00 00            	jae	0x3722 <trusted_x86_x86_sim_xdp+0x3722>
    31aa: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x31b1 <trusted_x86_x86_sim_xdp+0x31b1>
		00000000000031ad:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    31b1: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    31b7: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    31bf: e8 00 00 00 00               	callq	0x31c4 <trusted_x86_x86_sim_xdp+0x31c4>
		00000000000031c0:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    31c4: e9 30 05 00 00               	jmp	0x36f9 <trusted_x86_x86_sim_xdp+0x36f9>
    31c9: 48 89 d8                     	movq	%rbx, %rax
    31cc: 48 8b 80 00 0f 00 00         	movq	0xf00(%rax), %rax
    31d3: eb 05                        	jmp	0x31da <trusted_x86_x86_sim_xdp+0x31da>
    31d5: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
    31da: 48 89 84 24 10 01 00 00      	movq	%rax, 0x110(%rsp)
    31e2: 48 8b 84 24 90 00 00 00      	movq	0x90(%rsp), %rax
    31ea: 48 8b 8c 24 a0 00 00 00      	movq	0xa0(%rsp), %rcx
    31f2: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
    31f7: 48 8b 8c 24 a8 00 00 00      	movq	0xa8(%rsp), %rcx
    31ff: 48 89 4c 24 48               	movq	%rcx, 0x48(%rsp)
    3204: 48 8b 8c 24 b0 00 00 00      	movq	0xb0(%rsp), %rcx
    320c: 48 89 4c 24 40               	movq	%rcx, 0x40(%rsp)
    3211: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
    3216: 0f b6 71 1c                  	movzbl	0x1c(%rcx), %esi
    321a: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
    321f: 48 01 c6                     	addq	%rax, %rsi
    3222: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    3227: ba 08 00 00 00               	movl	$0x8, %edx
    322c: e8 00 00 00 00               	callq	0x3231 <trusted_x86_x86_sim_xdp+0x3231>
		000000000000322d:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3231: 85 c0                        	testl	%eax, %eax
    3233: 79 09                        	jns	0x323e <trusted_x86_x86_sim_xdp+0x323e>
    3235: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
    323e: 85 c0                        	testl	%eax, %eax
    3240: 0f 84 3c 05 00 00            	je	0x3782 <trusted_x86_x86_sim_xdp+0x3782>
    3246: c7 84 24 04 01 00 00 2d 00 00 00     	movl	$0x2d, 0x104(%rsp)
    3251: bd e9 03 00 00               	movl	$0x3e9, %ebp            # imm = 0x3E9
    3256: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x325d <trusted_x86_x86_sim_xdp+0x325d>
		0000000000003259:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    325d: 83 78 44 2e                  	cmpl	$0x2e, 0x44(%rax)
    3261: 0f 82 a5 cf ff ff            	jb	0x20c <trusted_x86_x86_sim_xdp+0x20c>
    3267: b8 2d 00 00 00               	movl	$0x2d, %eax
    326c: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3273 <trusted_x86_x86_sim_xdp+0x3273>
		000000000000326f:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3273: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    3279: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    3281: e8 00 00 00 00               	callq	0x3286 <trusted_x86_x86_sim_xdp+0x3286>
		0000000000003282:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3286: 48 85 c0                     	testq	%rax, %rax
    3289: 0f 84 7d cf ff ff            	je	0x20c <trusted_x86_x86_sim_xdp+0x20c>
    328f: 48 89 c1                     	movq	%rax, %rcx
    3292: 48 8b 09                     	movq	(%rcx), %rcx
    3295: 48 ff c1                     	incq	%rcx
    3298: e9 6c cf ff ff               	jmp	0x209 <trusted_x86_x86_sim_xdp+0x209>
    329d: 8b 4c 24 58                  	movl	0x58(%rsp), %ecx
    32a1: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    32a4: 73 15                        	jae	0x32bb <trusted_x86_x86_sim_xdp+0x32bb>
    32a6: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    32ac: 48 8b bc c8 30 01 00 00      	movq	0x130(%rax,%rcx,8), %rdi
    32b4: e8 00 00 00 00               	callq	0x32b9 <trusted_x86_x86_sim_xdp+0x32b9>
		00000000000032b5:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    32b9: eb 1b                        	jmp	0x32d6 <trusted_x86_x86_sim_xdp+0x32d6>
    32bb: 48 c7 44 24 20 00 00 00 00   	movq	$0x0, 0x20(%rsp)
    32c4: 31 ed                        	xorl	%ebp, %ebp
    32c6: 41 bd 01 00 00 00            	movl	$0x1, %r13d
    32cc: e9 3e cf ff ff               	jmp	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    32d1: e8 00 00 00 00               	callq	0x32d6 <trusted_x86_x86_sim_xdp+0x32d6>
		00000000000032d2:  R_X86_64_PLT32	.text+0x12c
    32d6: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
    32db: 31 ed                        	xorl	%ebp, %ebp
    32dd: 41 bd 01 00 00 00            	movl	$0x1, %r13d
    32e3: 48 85 c0                     	testq	%rax, %rax
    32e6: 0f 84 23 cf ff ff            	je	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    32ec: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    32f1: 48 8b 00                     	movq	(%rax), %rax
    32f4: 4c 39 f0                     	cmpq	%r14, %rax
    32f7: 77 0e                        	ja	0x3307 <trusted_x86_x86_sim_xdp+0x3307>
    32f9: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    32fe: 48 8b 40 08                  	movq	0x8(%rax), %rax
    3302: 4c 39 f0                     	cmpq	%r14, %rax
    3305: 73 24                        	jae	0x332b <trusted_x86_x86_sim_xdp+0x332b>
    3307: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    330c: 48 8b 40 10                  	movq	0x10(%rax), %rax
    3310: 4c 39 f0                     	cmpq	%r14, %rax
    3313: 0f 87 f6 ce ff ff            	ja	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    3319: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    331e: 48 8b 40 18                  	movq	0x18(%rax), %rax
    3322: 4c 39 f0                     	cmpq	%r14, %rax
    3325: 0f 82 e4 ce ff ff            	jb	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    332b: 48 89 d8                     	movq	%rbx, %rax
    332e: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
    3334: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
    3339: 8b 49 20                     	movl	0x20(%rcx), %ecx
    333c: 0f a3 c8                     	btl	%ecx, %eax
    333f: 0f 82 ca ce ff ff            	jb	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    3345: c7 84 24 c8 00 00 00 00 00 00 00     	movl	$0x0, 0xc8(%rsp)
    3350: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x3357 <trusted_x86_x86_sim_xdp+0x3357>
		0000000000003353:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3357: 83 78 44 00                  	cmpl	$0x0, 0x44(%rax)
    335b: 74 24                        	je	0x3381 <trusted_x86_x86_sim_xdp+0x3381>
    335d: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x3364 <trusted_x86_x86_sim_xdp+0x3364>
		0000000000003360:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3364: 48 8b b8 30 01 00 00         	movq	0x130(%rax), %rdi
    336b: e8 00 00 00 00               	callq	0x3370 <trusted_x86_x86_sim_xdp+0x3370>
		000000000000336c:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3370: 48 85 c0                     	testq	%rax, %rax
    3373: 74 0c                        	je	0x3381 <trusted_x86_x86_sim_xdp+0x3381>
    3375: 48 89 c1                     	movq	%rax, %rcx
    3378: 48 8b 09                     	movq	(%rcx), %rcx
    337b: 48 ff c1                     	incq	%rcx
    337e: 48 89 08                     	movq	%rcx, (%rax)
    3381: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    3386: 44 0f b7 68 20               	movzwl	0x20(%rax), %r13d
    338b: 31 ed                        	xorl	%ebp, %ebp
    338d: 41 83 fd 02                  	cmpl	$0x2, %r13d
    3391: 0f 85 78 ce ff ff            	jne	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    3397: c7 44 24 58 29 00 00 00      	movl	$0x29, 0x58(%rsp)
    339f: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x33a6 <trusted_x86_x86_sim_xdp+0x33a6>
		00000000000033a2:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    33a6: 83 78 44 2a                  	cmpl	$0x2a, 0x44(%rax)
    33aa: 72 30                        	jb	0x33dc <trusted_x86_x86_sim_xdp+0x33dc>
    33ac: b8 29 00 00 00               	movl	$0x29, %eax
    33b1: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x33b8 <trusted_x86_x86_sim_xdp+0x33b8>
		00000000000033b4:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    33b8: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    33be: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    33c6: e8 00 00 00 00               	callq	0x33cb <trusted_x86_x86_sim_xdp+0x33cb>
		00000000000033c7:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    33cb: 48 85 c0                     	testq	%rax, %rax
    33ce: 74 0c                        	je	0x33dc <trusted_x86_x86_sim_xdp+0x33dc>
    33d0: 48 89 c1                     	movq	%rax, %rcx
    33d3: 48 8b 09                     	movq	(%rcx), %rcx
    33d6: 48 ff c1                     	incq	%rcx
    33d9: 48 89 08                     	movq	%rcx, (%rax)
    33dc: 48 89 d8                     	movq	%rbx, %rax
    33df: 48 8b 80 d0 0e 00 00         	movq	0xed0(%rax), %rax
    33e6: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    33eb: 48 89 d8                     	movq	%rbx, %rax
    33ee: 48 8b 80 d8 0e 00 00         	movq	0xed8(%rax), %rax
    33f5: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
    33fa: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    33ff: 0f b6 40 20                  	movzbl	0x20(%rax), %eax
    3403: 48 89 d9                     	movq	%rbx, %rcx
    3406: 48 8b 89 e0 0e 00 00         	movq	0xee0(%rcx), %rcx
    340d: 48 89 4c 24 40               	movq	%rcx, 0x40(%rsp)
    3412: 48 89 d9                     	movq	%rbx, %rcx
    3415: c4 62 fb f7 a9 18 0f 00 00   	shrxq	%rax, 0xf18(%rcx), %r13
    341e: 48 89 d8                     	movq	%rbx, %rax
    3421: 4c 8b b0 10 0f 00 00         	movq	0xf10(%rax), %r14
    3428: 48 b8 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    3432: 49 21 c6                     	andq	%rax, %r14
    3435: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    3439: ba 01 00 00 00               	movl	$0x1, %edx
    343e: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    3443: e8 00 00 00 00               	callq	0x3448 <trusted_x86_x86_sim_xdp+0x3448>
		0000000000003444:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3448: 85 c0                        	testl	%eax, %eax
    344a: 79 05                        	jns	0x3451 <trusted_x86_x86_sim_xdp+0x3451>
    344c: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    3451: 85 c0                        	testl	%eax, %eax
    3453: 0f 85 64 cd ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    3459: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    345e: 8d 48 01                     	leal	0x1(%rax), %ecx
    3461: f6 c1 fe                     	testb	$-0x2, %cl
    3464: 0f 84 70 03 00 00            	je	0x37da <trusted_x86_x86_sim_xdp+0x37da>
    346a: 89 c0                        	movl	%eax, %eax
    346c: 49 29 c5                     	subq	%rax, %r13
    346f: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    3473: ba 01 00 00 00               	movl	$0x1, %edx
    3478: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    347d: e8 00 00 00 00               	callq	0x3482 <trusted_x86_x86_sim_xdp+0x3482>
		000000000000347e:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3482: 85 c0                        	testl	%eax, %eax
    3484: 79 05                        	jns	0x348b <trusted_x86_x86_sim_xdp+0x348b>
    3486: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    348b: 85 c0                        	testl	%eax, %eax
    348d: 0f 85 2a cd ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    3493: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    3498: 8d 48 01                     	leal	0x1(%rax), %ecx
    349b: f6 c1 fe                     	testb	$-0x2, %cl
    349e: 0f 84 36 03 00 00            	je	0x37da <trusted_x86_x86_sim_xdp+0x37da>
    34a4: 89 c0                        	movl	%eax, %eax
    34a6: 49 29 c5                     	subq	%rax, %r13
    34a9: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    34ad: ba 01 00 00 00               	movl	$0x1, %edx
    34b2: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    34b7: e8 00 00 00 00               	callq	0x34bc <trusted_x86_x86_sim_xdp+0x34bc>
		00000000000034b8:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    34bc: 85 c0                        	testl	%eax, %eax
    34be: 79 05                        	jns	0x34c5 <trusted_x86_x86_sim_xdp+0x34c5>
    34c0: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    34c5: 85 c0                        	testl	%eax, %eax
    34c7: 0f 85 f0 cc ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    34cd: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    34d2: 8d 48 01                     	leal	0x1(%rax), %ecx
    34d5: f6 c1 fe                     	testb	$-0x2, %cl
    34d8: 0f 84 fc 02 00 00            	je	0x37da <trusted_x86_x86_sim_xdp+0x37da>
    34de: 89 c0                        	movl	%eax, %eax
    34e0: 49 29 c5                     	subq	%rax, %r13
    34e3: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    34e7: ba 01 00 00 00               	movl	$0x1, %edx
    34ec: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    34f1: e8 00 00 00 00               	callq	0x34f6 <trusted_x86_x86_sim_xdp+0x34f6>
		00000000000034f2:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    34f6: 85 c0                        	testl	%eax, %eax
    34f8: 79 05                        	jns	0x34ff <trusted_x86_x86_sim_xdp+0x34ff>
    34fa: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    34ff: 85 c0                        	testl	%eax, %eax
    3501: 0f 85 b6 cc ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    3507: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    350c: 8d 48 01                     	leal	0x1(%rax), %ecx
    350f: f6 c1 fe                     	testb	$-0x2, %cl
    3512: 0f 84 c2 02 00 00            	je	0x37da <trusted_x86_x86_sim_xdp+0x37da>
    3518: 89 c0                        	movl	%eax, %eax
    351a: 49 29 c5                     	subq	%rax, %r13
    351d: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    3521: ba 01 00 00 00               	movl	$0x1, %edx
    3526: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    352b: e8 00 00 00 00               	callq	0x3530 <trusted_x86_x86_sim_xdp+0x3530>
		000000000000352c:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3530: 85 c0                        	testl	%eax, %eax
    3532: 79 05                        	jns	0x3539 <trusted_x86_x86_sim_xdp+0x3539>
    3534: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    3539: 85 c0                        	testl	%eax, %eax
    353b: 0f 85 7c cc ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    3541: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    3546: 8d 48 01                     	leal	0x1(%rax), %ecx
    3549: f6 c1 fe                     	testb	$-0x2, %cl
    354c: 0f 84 88 02 00 00            	je	0x37da <trusted_x86_x86_sim_xdp+0x37da>
    3552: 89 c0                        	movl	%eax, %eax
    3554: 49 29 c5                     	subq	%rax, %r13
    3557: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    355b: ba 01 00 00 00               	movl	$0x1, %edx
    3560: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    3565: e8 00 00 00 00               	callq	0x356a <trusted_x86_x86_sim_xdp+0x356a>
		0000000000003566:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    356a: 85 c0                        	testl	%eax, %eax
    356c: 79 05                        	jns	0x3573 <trusted_x86_x86_sim_xdp+0x3573>
    356e: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    3573: 85 c0                        	testl	%eax, %eax
    3575: 0f 85 42 cc ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    357b: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    3580: 8d 48 01                     	leal	0x1(%rax), %ecx
    3583: f6 c1 fe                     	testb	$-0x2, %cl
    3586: 0f 84 4e 02 00 00            	je	0x37da <trusted_x86_x86_sim_xdp+0x37da>
    358c: 89 c0                        	movl	%eax, %eax
    358e: 49 29 c5                     	subq	%rax, %r13
    3591: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    3595: ba 01 00 00 00               	movl	$0x1, %edx
    359a: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    359f: e8 00 00 00 00               	callq	0x35a4 <trusted_x86_x86_sim_xdp+0x35a4>
		00000000000035a0:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    35a4: 85 c0                        	testl	%eax, %eax
    35a6: 79 05                        	jns	0x35ad <trusted_x86_x86_sim_xdp+0x35ad>
    35a8: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    35ad: 85 c0                        	testl	%eax, %eax
    35af: 0f 85 08 cc ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    35b5: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    35ba: 8d 48 01                     	leal	0x1(%rax), %ecx
    35bd: f6 c1 fe                     	testb	$-0x2, %cl
    35c0: 0f 84 14 02 00 00            	je	0x37da <trusted_x86_x86_sim_xdp+0x37da>
    35c6: 89 c0                        	movl	%eax, %eax
    35c8: 49 29 c5                     	subq	%rax, %r13
    35cb: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    35cf: ba 01 00 00 00               	movl	$0x1, %edx
    35d4: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    35d9: e8 00 00 00 00               	callq	0x35de <trusted_x86_x86_sim_xdp+0x35de>
		00000000000035da:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    35de: 85 c0                        	testl	%eax, %eax
    35e0: 79 05                        	jns	0x35e7 <trusted_x86_x86_sim_xdp+0x35e7>
    35e2: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    35e7: 85 c0                        	testl	%eax, %eax
    35e9: 0f 85 ce cb ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    35ef: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    35f4: 8d 48 01                     	leal	0x1(%rax), %ecx
    35f7: f6 c1 fe                     	testb	$-0x2, %cl
    35fa: 0f 84 da 01 00 00            	je	0x37da <trusted_x86_x86_sim_xdp+0x37da>
    3600: 89 c0                        	movl	%eax, %eax
    3602: 49 29 c5                     	subq	%rax, %r13
    3605: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    3609: ba 01 00 00 00               	movl	$0x1, %edx
    360e: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    3613: e8 00 00 00 00               	callq	0x3618 <trusted_x86_x86_sim_xdp+0x3618>
		0000000000003614:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3618: 85 c0                        	testl	%eax, %eax
    361a: 79 05                        	jns	0x3621 <trusted_x86_x86_sim_xdp+0x3621>
    361c: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    3621: 85 c0                        	testl	%eax, %eax
    3623: 0f 85 94 cb ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    3629: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    362e: 8d 48 01                     	leal	0x1(%rax), %ecx
    3631: f6 c1 fe                     	testb	$-0x2, %cl
    3634: 0f 84 a0 01 00 00            	je	0x37da <trusted_x86_x86_sim_xdp+0x37da>
    363a: 89 c0                        	movl	%eax, %eax
    363c: 49 29 c5                     	subq	%rax, %r13
    363f: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    3643: ba 01 00 00 00               	movl	$0x1, %edx
    3648: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    364d: e8 00 00 00 00               	callq	0x3652 <trusted_x86_x86_sim_xdp+0x3652>
		000000000000364e:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3652: 85 c0                        	testl	%eax, %eax
    3654: 79 05                        	jns	0x365b <trusted_x86_x86_sim_xdp+0x365b>
    3656: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    365b: 85 c0                        	testl	%eax, %eax
    365d: 0f 85 5a cb ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    3663: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    3668: 8d 48 01                     	leal	0x1(%rax), %ecx
    366b: f6 c1 fe                     	testb	$-0x2, %cl
    366e: 0f 84 66 01 00 00            	je	0x37da <trusted_x86_x86_sim_xdp+0x37da>
    3674: 89 c0                        	movl	%eax, %eax
    3676: 49 29 c5                     	subq	%rax, %r13
    3679: 4b 8d 34 2e                  	leaq	(%r14,%r13), %rsi
    367d: ba 01 00 00 00               	movl	$0x1, %edx
    3682: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    3687: e8 00 00 00 00               	callq	0x368c <trusted_x86_x86_sim_xdp+0x368c>
		0000000000003688:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    368c: 85 c0                        	testl	%eax, %eax
    368e: 79 05                        	jns	0x3695 <trusted_x86_x86_sim_xdp+0x3695>
    3690: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    3695: 85 c0                        	testl	%eax, %eax
    3697: 0f 85 20 cb ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    369d: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    36a2: 8d 48 01                     	leal	0x1(%rax), %ecx
    36a5: f6 c1 fe                     	testb	$-0x2, %cl
    36a8: 0f 84 2c 01 00 00            	je	0x37da <trusted_x86_x86_sim_xdp+0x37da>
    36ae: 89 c0                        	movl	%eax, %eax
    36b0: 49 29 c5                     	subq	%rax, %r13
    36b3: 4d 01 ee                     	addq	%r13, %r14
    36b6: ba 01 00 00 00               	movl	$0x1, %edx
    36bb: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    36c0: 4c 89 f6                     	movq	%r14, %rsi
    36c3: e8 00 00 00 00               	callq	0x36c8 <trusted_x86_x86_sim_xdp+0x36c8>
		00000000000036c4:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    36c8: 85 c0                        	testl	%eax, %eax
    36ca: 79 05                        	jns	0x36d1 <trusted_x86_x86_sim_xdp+0x36d1>
    36cc: c6 44 24 58 00               	movb	$0x0, 0x58(%rsp)
    36d1: 85 c0                        	testl	%eax, %eax
    36d3: 0f 85 e4 ca ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    36d9: 0f b6 44 24 58               	movzbl	0x58(%rsp), %eax
    36de: 8d 48 01                     	leal	0x1(%rax), %ecx
    36e1: f6 c1 fe                     	testb	$-0x2, %cl
    36e4: 0f 85 d3 ca ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    36ea: e9 eb 00 00 00               	jmp	0x37da <trusted_x86_x86_sim_xdp+0x37da>
    36ef: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    36f4: e8 00 00 00 00               	callq	0x36f9 <trusted_x86_x86_sim_xdp+0x36f9>
		00000000000036f5:  R_X86_64_PLT32	.text+0x7c
    36f9: 48 85 c0                     	testq	%rax, %rax
    36fc: 74 24                        	je	0x3722 <trusted_x86_x86_sim_xdp+0x3722>
    36fe: 48 8b 40 08                  	movq	0x8(%rax), %rax
    3702: 4c 21 e8                     	andq	%r13, %rax
    3705: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    370f: 48 39 c8                     	cmpq	%rcx, %rax
    3712: 75 0e                        	jne	0x3722 <trusted_x86_x86_sim_xdp+0x3722>
    3714: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    3719: 48 83 c0 20                  	addq	$0x20, %rax
    371d: e9 f4 02 00 00               	jmp	0x3a16 <trusted_x86_x86_sim_xdp+0x3a16>
    3722: 48 89 d8                     	movq	%rbx, %rax
    3725: 8b 00                        	movl	(%rax), %eax
    3727: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    372f: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    3735: 48 8b 84 24 80 00 00 00      	movq	0x80(%rsp), %rax
    373d: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    3744: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    3749: 0f 84 9c 02 00 00            	je	0x39eb <trusted_x86_x86_sim_xdp+0x39eb>
    374f: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    3753: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x375a <trusted_x86_x86_sim_xdp+0x375a>
		0000000000003756:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    375a: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    375d: 0f 83 d6 02 00 00            	jae	0x3a39 <trusted_x86_x86_sim_xdp+0x3a39>
    3763: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x376a <trusted_x86_x86_sim_xdp+0x376a>
		0000000000003766:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    376a: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    3770: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    3778: e8 00 00 00 00               	callq	0x377d <trusted_x86_x86_sim_xdp+0x377d>
		0000000000003779:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    377d: e9 73 02 00 00               	jmp	0x39f5 <trusted_x86_x86_sim_xdp+0x39f5>
    3782: 48 8b 6c 24 28               	movq	0x28(%rsp), %rbp
    3787: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    378c: 0f b6 40 1d                  	movzbl	0x1d(%rax), %eax
    3790: 48 01 e8                     	addq	%rbp, %rax
    3793: 4c 8b 74 24 50               	movq	0x50(%rsp), %r14
    3798: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
    37a0: 31 d2                        	xorl	%edx, %edx
    37a2: 48 39 c1                     	cmpq	%rax, %rcx
    37a5: 48 0f 43 d0                  	cmovaeq	%rax, %rdx
    37a9: 48 29 d1                     	subq	%rdx, %rcx
    37ac: 48 81 f9 ff ff 00 00         	cmpq	$0xffff, %rcx           # imm = 0xFFFF
    37b3: b8 ff ff 00 00               	movl	$0xffff, %eax           # imm = 0xFFFF
    37b8: 48 0f 42 c1                  	cmovbq	%rcx, %rax
    37bc: 48 89 84 24 c0 00 00 00      	movq	%rax, 0xc0(%rsp)
    37c4: 48 c1 ed 03                  	shrq	$0x3, %rbp
    37c8: 81 e2 00 ff ff ff            	andl	$0xffffff00, %edx       # imm = 0xFFFFFF00
    37ce: 83 ca 02                     	orl	$0x2, %edx
    37d1: 89 54 24 38                  	movl	%edx, 0x38(%rsp)
    37d5: e9 c7 f4 ff ff               	jmp	0x2ca1 <trusted_x86_x86_sim_xdp+0x2ca1>
    37da: 85 c0                        	testl	%eax, %eax
    37dc: 0f 85 db c9 ff ff            	jne	0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
    37e2: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
    37e7: 48 89 c8                     	movq	%rcx, %rax
    37ea: 0f b6 40 20                  	movzbl	0x20(%rax), %eax
    37ee: c4 c2 f9 f7 c5               	shlxq	%rax, %r13, %rax
    37f3: 48 89 ca                     	movq	%rcx, %rdx
    37f6: 48 89 d9                     	movq	%rbx, %rcx
    37f9: 48 03 81 20 0f 00 00         	addq	0xf20(%rcx), %rax
    3800: 48 89 d1                     	movq	%rdx, %rcx
    3803: 0f b6 71 1b                  	movzbl	0x1b(%rcx), %esi
    3807: 48 01 c6                     	addq	%rax, %rsi
    380a: 48 89 b4 24 c8 00 00 00      	movq	%rsi, 0xc8(%rsp)
    3812: 0f 84 b1 c9 ff ff            	je	0x1c9 <trusted_x86_x86_sim_xdp+0x1c9>
    3818: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
    381d: 4c 89 e7                     	movq	%r12, %rdi
    3820: e8 00 00 00 00               	callq	0x3825 <trusted_x86_x86_sim_xdp+0x3825>
		0000000000003821:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3825: 49 89 c6                     	movq	%rax, %r14
    3828: 45 85 f6                     	testl	%r14d, %r14d
    382b: 79 0f                        	jns	0x383c <trusted_x86_x86_sim_xdp+0x383c>
    382d: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
    3832: 4c 89 e7                     	movq	%r12, %rdi
    3835: 31 f6                        	xorl	%esi, %esi
    3837: e8 00 00 00 00               	callq	0x383c <trusted_x86_x86_sim_xdp+0x383c>
		0000000000003838:  R_X86_64_PLT32	memset-0x4
    383c: 45 85 f6                     	testl	%r14d, %r14d
    383f: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    3844: 0f 85 d7 cd ff ff            	jne	0x621 <trusted_x86_x86_sim_xdp+0x621>
    384a: 0f b7 40 10                  	movzwl	0x10(%rax), %eax
    384e: 0f b7 c0                     	movzwl	%ax, %eax
    3851: 3d f8 01 00 00               	cmpl	$0x1f8, %eax            # imm = 0x1F8
    3856: 0f 87 82 01 00 00            	ja	0x39de <trusted_x86_x86_sim_xdp+0x39de>
    385c: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
    3861: 0f b7 49 12                  	movzwl	0x12(%rcx), %ecx
    3865: 0f b7 c9                     	movzwl	%cx, %ecx
    3868: 81 f9 fc 01 00 00            	cmpl	$0x1fc, %ecx            # imm = 0x1FC
    386e: 0f 87 6a 01 00 00            	ja	0x39de <trusted_x86_x86_sim_xdp+0x39de>
    3874: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    3879: 0f b7 52 14                  	movzwl	0x14(%rdx), %edx
    387d: 0f b7 d2                     	movzwl	%dx, %edx
    3880: 81 fa f8 01 00 00            	cmpl	$0x1f8, %edx            # imm = 0x1F8
    3886: 0f 87 52 01 00 00            	ja	0x39de <trusted_x86_x86_sim_xdp+0x39de>
    388c: 48 8b 7c 24 10               	movq	0x10(%rsp), %rdi
    3891: 48 89 fe                     	movq	%rdi, %rsi
    3894: 0f b6 76 17                  	movzbl	0x17(%rsi), %esi
    3898: 40 0f b6 f6                  	movzbl	%sil, %esi
    389c: 4c 01 e6                     	addq	%r12, %rsi
    389f: 48 8b 36                     	movq	(%rsi), %rsi
    38a2: 48 89 b4 24 d0 00 00 00      	movq	%rsi, 0xd0(%rsp)
    38aa: 48 89 fe                     	movq	%rdi, %rsi
    38ad: 0f b6 76 18                  	movzbl	0x18(%rsi), %esi
    38b1: 40 0f b6 f6                  	movzbl	%sil, %esi
    38b5: 4c 01 e6                     	addq	%r12, %rsi
    38b8: 48 8b 36                     	movq	(%rsi), %rsi
    38bb: 48 89 b4 24 d8 00 00 00      	movq	%rsi, 0xd8(%rsp)
    38c3: 48 89 fe                     	movq	%rdi, %rsi
    38c6: 0f b6 76 1a                  	movzbl	0x1a(%rsi), %esi
    38ca: 40 0f b6 f6                  	movzbl	%sil, %esi
    38ce: 4c 01 e6                     	addq	%r12, %rsi
    38d1: 8b 36                        	movl	(%rsi), %esi
    38d3: c1 e6 03                     	shll	$0x3, %esi
    38d6: 89 b4 24 f0 00 00 00         	movl	%esi, 0xf0(%rsp)
    38dd: 48 89 fe                     	movq	%rdi, %rsi
    38e0: 0f b6 76 19                  	movzbl	0x19(%rsi), %esi
    38e4: 40 0f b6 f6                  	movzbl	%sil, %esi
    38e8: 4c 01 e6                     	addq	%r12, %rsi
    38eb: 0f b7 36                     	movzwl	(%rsi), %esi
    38ee: 66 89 b4 24 f8 00 00 00      	movw	%si, 0xf8(%rsp)
    38f6: 4c 01 e1                     	addq	%r12, %rcx
    38f9: 8b 09                        	movl	(%rcx), %ecx
    38fb: 89 8c 24 f4 00 00 00         	movl	%ecx, 0xf4(%rsp)
    3902: 4c 01 e2                     	addq	%r12, %rdx
    3905: 8b 0a                        	movl	(%rdx), %ecx
    3907: 89 8c 24 ec 00 00 00         	movl	%ecx, 0xec(%rsp)
    390e: 4c 01 e0                     	addq	%r12, %rax
    3911: 48 8b 00                     	movq	(%rax), %rax
    3914: 48 89 84 24 e0 00 00 00      	movq	%rax, 0xe0(%rsp)
    391c: 48 89 f8                     	movq	%rdi, %rax
    391f: 0f b6 40 16                  	movzbl	0x16(%rax), %eax
    3923: 0f b6 c0                     	movzbl	%al, %eax
    3926: 4c 01 e0                     	addq	%r12, %rax
    3929: 48 8b 30                     	movq	(%rax), %rsi
    392c: ba 04 00 00 00               	movl	$0x4, %edx
    3931: 48 8d bc 24 e8 00 00 00      	leaq	0xe8(%rsp), %rdi
    3939: e8 00 00 00 00               	callq	0x393e <trusted_x86_x86_sim_xdp+0x393e>
		000000000000393a:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    393e: 85 c0                        	testl	%eax, %eax
    3940: 79 0b                        	jns	0x394d <trusted_x86_x86_sim_xdp+0x394d>
    3942: c7 84 24 e8 00 00 00 00 00 00 00     	movl	$0x0, 0xe8(%rsp)
    394d: 85 c0                        	testl	%eax, %eax
    394f: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    3954: 0f 85 c7 cc ff ff            	jne	0x621 <trusted_x86_x86_sim_xdp+0x621>
    395a: 0f b6 40 21                  	movzbl	0x21(%rax), %eax
    395e: 48 8b 94 24 c8 00 00 00      	movq	0xc8(%rsp), %rdx
    3966: 48 8b 8c 24 d0 00 00 00      	movq	0xd0(%rsp), %rcx
    396e: 48 89 94 24 c0 00 00 00      	movq	%rdx, 0xc0(%rsp)
    3976: 84 c0                        	testb	%al, %al
    3978: 74 27                        	je	0x39a1 <trusted_x86_x86_sim_xdp+0x39a1>
    397a: 89 c9                        	movl	%ecx, %ecx
    397c: 48 8b 94 24 c0 00 00 00      	movq	0xc0(%rsp), %rdx
    3984: 48 01 d1                     	addq	%rdx, %rcx
    3987: 48 89 8c 24 d0 00 00 00      	movq	%rcx, 0xd0(%rsp)
    398f: 8b b4 24 d8 00 00 00         	movl	0xd8(%rsp), %esi
    3996: 48 01 d6                     	addq	%rdx, %rsi
    3999: 48 89 b4 24 d8 00 00 00      	movq	%rsi, 0xd8(%rsp)
    39a1: 44 8b ac 24 e8 00 00 00      	movl	0xe8(%rsp), %r13d
    39a9: 48 8b 74 24 48               	movq	0x48(%rsp), %rsi
    39ae: 89 f7                        	movl	%esi, %edi
    39b0: 29 cf                        	subl	%ecx, %edi
    39b2: 48 89 7c 24 50               	movq	%rdi, 0x50(%rsp)
    39b7: 41 81 fd 6d 61 74 69         	cmpl	$0x6974616d, %r13d      # imm = 0x6974616D
    39be: 0f 8f c4 00 00 00            	jg	0x3a88 <trusted_x86_x86_sim_xdp+0x3a88>
    39c4: 41 81 fd 76 74 61 62         	cmpl	$0x62617476, %r13d      # imm = 0x62617476
    39cb: 0f 85 98 01 00 00            	jne	0x3b69 <trusted_x86_x86_sim_xdp+0x3b69>
    39d1: c7 44 24 38 01 00 00 00      	movl	$0x1, 0x38(%rsp)
    39d9: e9 76 01 00 00               	jmp	0x3b54 <trusted_x86_x86_sim_xdp+0x3b54>
    39de: 45 31 ed                     	xorl	%r13d, %r13d
    39e1: bd 01 00 00 00               	movl	$0x1, %ebp
    39e6: e9 24 c8 ff ff               	jmp	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    39eb: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    39f0: e8 00 00 00 00               	callq	0x39f5 <trusted_x86_x86_sim_xdp+0x39f5>
		00000000000039f1:  R_X86_64_PLT32	.text+0x7c
    39f5: 48 85 c0                     	testq	%rax, %rax
    39f8: 74 3f                        	je	0x3a39 <trusted_x86_x86_sim_xdp+0x3a39>
    39fa: 4c 23 68 08                  	andq	0x8(%rax), %r13
    39fe: 48 b8 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rax # imm = 0x200000000000000
    3a08: 49 39 c5                     	cmpq	%rax, %r13
    3a0b: 75 2c                        	jne	0x3a39 <trusted_x86_x86_sim_xdp+0x3a39>
    3a0d: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    3a12: 48 83 c0 28                  	addq	$0x28, %rax
    3a16: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
    3a1b: 89 c1                        	movl	%eax, %ecx
    3a1d: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    3a23: 83 c9 03                     	orl	$0x3, %ecx
    3a26: 89 4c 24 38                  	movl	%ecx, 0x38(%rsp)
    3a2a: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
    3a2f: 48 8b 74 24 20               	movq	0x20(%rsp), %rsi
    3a34: e9 1f f2 ff ff               	jmp	0x2c58 <trusted_x86_x86_sim_xdp+0x2c58>
    3a39: c7 44 24 28 2e 00 00 00      	movl	$0x2e, 0x28(%rsp)
    3a41: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x3a48 <trusted_x86_x86_sim_xdp+0x3a48>
		0000000000003a44:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3a48: 83 78 44 2f                  	cmpl	$0x2f, 0x44(%rax)
    3a4c: 0f 82 4a e8 ff ff            	jb	0x229c <trusted_x86_x86_sim_xdp+0x229c>
    3a52: b8 2e 00 00 00               	movl	$0x2e, %eax
    3a57: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3a5e <trusted_x86_x86_sim_xdp+0x3a5e>
		0000000000003a5a:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3a5e: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    3a64: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    3a6c: e8 00 00 00 00               	callq	0x3a71 <trusted_x86_x86_sim_xdp+0x3a71>
		0000000000003a6d:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3a71: 48 85 c0                     	testq	%rax, %rax
    3a74: 0f 84 22 e8 ff ff            	je	0x229c <trusted_x86_x86_sim_xdp+0x229c>
    3a7a: 48 89 c1                     	movq	%rax, %rcx
    3a7d: 48 8b 09                     	movq	(%rcx), %rcx
    3a80: 48 ff c1                     	incq	%rcx
    3a83: e9 11 e8 ff ff               	jmp	0x2299 <trusted_x86_x86_sim_xdp+0x2299>
    3a88: 41 81 fd 6e 61 74 69         	cmpl	$0x6974616e, %r13d      # imm = 0x6974616E
    3a8f: 74 1a                        	je	0x3aab <trusted_x86_x86_sim_xdp+0x3aab>
    3a91: 41 81 fd 6e 6d 65 74         	cmpl	$0x74656d6e, %r13d      # imm = 0x74656D6E
    3a98: 0f 85 bb 02 00 00            	jne	0x3d59 <trusted_x86_x86_sim_xdp+0x3d59>
    3a9e: 48 8b 74 24 48               	movq	0x48(%rsp), %rsi
    3aa3: 48 8b 94 24 c0 00 00 00      	movq	0xc0(%rsp), %rdx
    3aab: 48 8b bc 24 e0 00 00 00      	movq	0xe0(%rsp), %rdi
    3ab3: 41 89 f8                     	movl	%edi, %r8d
    3ab6: 49 01 d0                     	addq	%rdx, %r8
    3ab9: 84 c0                        	testb	%al, %al
    3abb: 44 8b ac 24 f4 00 00 00      	movl	0xf4(%rsp), %r13d
    3ac3: 4c 0f 44 c7                  	cmoveq	%rdi, %r8
    3ac7: 4c 39 c6                     	cmpq	%r8, %rsi
    3aca: 75 56                        	jne	0x3b22 <trusted_x86_x86_sim_xdp+0x3b22>
    3acc: 8b b4 24 ec 00 00 00         	movl	0xec(%rsp), %esi
    3ad3: 48 03 74 24 20               	addq	0x20(%rsp), %rsi
    3ad8: ba 08 00 00 00               	movl	$0x8, %edx
    3add: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    3ae2: e8 00 00 00 00               	callq	0x3ae7 <trusted_x86_x86_sim_xdp+0x3ae7>
		0000000000003ae3:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3ae7: 85 c0                        	testl	%eax, %eax
    3ae9: 79 09                        	jns	0x3af4 <trusted_x86_x86_sim_xdp+0x3af4>
    3aeb: 48 c7 44 24 58 00 00 00 00   	movq	$0x0, 0x58(%rsp)
    3af4: 48 8b 8c 24 d0 00 00 00      	movq	0xd0(%rsp), %rcx
    3afc: 85 c0                        	testl	%eax, %eax
    3afe: 75 22                        	jne	0x3b22 <trusted_x86_x86_sim_xdp+0x3b22>
    3b00: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    3b05: 48 39 c8                     	cmpq	%rcx, %rax
    3b08: 72 18                        	jb	0x3b22 <trusted_x86_x86_sim_xdp+0x3b22>
    3b0a: 48 3b 84 24 d8 00 00 00      	cmpq	0xd8(%rsp), %rax
    3b12: 73 0e                        	jae	0x3b22 <trusted_x86_x86_sim_xdp+0x3b22>
    3b14: 89 c2                        	movl	%eax, %edx
    3b16: 29 ca                        	subl	%ecx, %edx
    3b18: 48 89 54 24 50               	movq	%rdx, 0x50(%rsp)
    3b1d: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    3b22: 0f b7 84 24 f8 00 00 00      	movzwl	0xf8(%rsp), %eax
    3b2a: 48 01 c8                     	addq	%rcx, %rax
    3b2d: 48 39 44 24 48               	cmpq	%rax, 0x48(%rsp)
    3b32: 0f 83 14 01 00 00            	jae	0x3c4c <trusted_x86_x86_sim_xdp+0x3c4c>
    3b38: 48 83 c0 fc                  	addq	$-0x4, %rax
    3b3c: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    3b42: 83 c9 03                     	orl	$0x3, %ecx
    3b45: 89 4c 24 38                  	movl	%ecx, 0x38(%rsp)
    3b49: 48 39 44 24 48               	cmpq	%rax, 0x48(%rsp)
    3b4e: 0f 83 fe 01 00 00            	jae	0x3d52 <trusted_x86_x86_sim_xdp+0x3d52>
    3b54: c7 84 24 f0 00 00 00 08 00 00 00     	movl	$0x8, 0xf0(%rsp)
    3b5f: b8 08 00 00 00               	movl	$0x8, %eax
    3b64: e9 1d 02 00 00               	jmp	0x3d86 <trusted_x86_x86_sim_xdp+0x3d86>
    3b69: 41 81 fd 49 6e 74 65         	cmpl	$0x65746e49, %r13d      # imm = 0x65746E49
    3b70: 0f 85 e3 01 00 00            	jne	0x3d59 <trusted_x86_x86_sim_xdp+0x3d59>
    3b76: 48 8b 44 24 40               	movq	0x40(%rsp), %rax
    3b7b: 48 3b 44 24 20               	cmpq	0x20(%rsp), %rax
    3b80: 0f 82 81 02 00 00            	jb	0x3e07 <trusted_x86_x86_sim_xdp+0x3e07>
    3b86: b8 00 10 00 00               	movl	$0x1000, %eax           # imm = 0x1000
    3b8b: 48 03 44 24 20               	addq	0x20(%rsp), %rax
    3b90: 48 39 44 24 40               	cmpq	%rax, 0x40(%rsp)
    3b95: 0f 83 6c 02 00 00            	jae	0x3e07 <trusted_x86_x86_sim_xdp+0x3e07>
    3b9b: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
    3ba0: 48 83 c6 b0                  	addq	$-0x50, %rsi
    3ba4: ba 60 00 00 00               	movl	$0x60, %edx
    3ba9: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    3bae: e8 00 00 00 00               	callq	0x3bb3 <trusted_x86_x86_sim_xdp+0x3bb3>
		0000000000003baf:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3bb3: 85 c0                        	testl	%eax, %eax
    3bb5: 79 64                        	jns	0x3c1b <trusted_x86_x86_sim_xdp+0x3c1b>
    3bb7: 48 8d 4c 24 58               	leaq	0x58(%rsp), %rcx
    3bbc: 48 c7 41 58 00 00 00 00      	movq	$0x0, 0x58(%rcx)
    3bc4: 48 c7 41 50 00 00 00 00      	movq	$0x0, 0x50(%rcx)
    3bcc: 48 c7 41 48 00 00 00 00      	movq	$0x0, 0x48(%rcx)
    3bd4: 48 c7 41 40 00 00 00 00      	movq	$0x0, 0x40(%rcx)
    3bdc: 48 c7 41 38 00 00 00 00      	movq	$0x0, 0x38(%rcx)
    3be4: 48 c7 41 30 00 00 00 00      	movq	$0x0, 0x30(%rcx)
    3bec: 48 c7 41 28 00 00 00 00      	movq	$0x0, 0x28(%rcx)
    3bf4: 48 c7 41 20 00 00 00 00      	movq	$0x0, 0x20(%rcx)
    3bfc: 48 c7 41 18 00 00 00 00      	movq	$0x0, 0x18(%rcx)
    3c04: 48 c7 41 10 00 00 00 00      	movq	$0x0, 0x10(%rcx)
    3c0c: 48 c7 41 08 00 00 00 00      	movq	$0x0, 0x8(%rcx)
    3c14: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
    3c1b: 85 c0                        	testl	%eax, %eax
    3c1d: 0f 85 e4 01 00 00            	jne	0x3e07 <trusted_x86_x86_sim_xdp+0x3e07>
    3c23: 48 89 d8                     	movq	%rbx, %rax
    3c26: 83 b8 c0 02 00 00 00         	cmpl	$0x0, 0x2c0(%rax)
    3c2d: 0f 84 64 01 00 00            	je	0x3d97 <trusted_x86_x86_sim_xdp+0x3d97>
    3c33: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    3c38: 80 78 1f 00                  	cmpb	$0x0, 0x1f(%rax)
    3c3c: 0f 84 61 01 00 00            	je	0x3da3 <trusted_x86_x86_sim_xdp+0x3da3>
    3c42: 4c 8b 64 24 68               	movq	0x68(%rsp), %r12
    3c47: e9 5c 01 00 00               	jmp	0x3da8 <trusted_x86_x86_sim_xdp+0x3da8>
    3c4c: 44 8b b4 24 f0 00 00 00      	movl	0xf0(%rsp), %r14d
    3c54: 48 8b 6c 24 20               	movq	0x20(%rsp), %rbp
    3c59: 49 8d 04 2e                  	leaq	(%r14,%rbp), %rax
    3c5d: 48 83 c0 30                  	addq	$0x30, %rax
    3c61: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    3c66: 48 39 6c 24 40               	cmpq	%rbp, 0x40(%rsp)
    3c6b: 72 22                        	jb	0x3c8f <trusted_x86_x86_sim_xdp+0x3c8f>
    3c6d: 81 e5 00 ff ff ff            	andl	$0xffffff00, %ebp       # imm = 0xFFFFFF00
    3c73: 83 cd 03                     	orl	$0x3, %ebp
    3c76: 89 6c 24 38                  	movl	%ebp, 0x38(%rsp)
    3c7a: 48 8b 44 24 40               	movq	0x40(%rsp), %rax
    3c7f: 48 3b 44 24 10               	cmpq	0x10(%rsp), %rax
    3c84: 0f 82 e7 00 00 00            	jb	0x3d71 <trusted_x86_x86_sim_xdp+0x3d71>
    3c8a: 48 8b 6c 24 20               	movq	0x20(%rsp), %rbp
    3c8f: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    3c93: 48 83 c6 f8                  	addq	$-0x8, %rsi
    3c97: ba 30 00 00 00               	movl	$0x30, %edx
    3c9c: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    3ca1: e8 00 00 00 00               	callq	0x3ca6 <trusted_x86_x86_sim_xdp+0x3ca6>
		0000000000003ca2:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3ca6: 85 c0                        	testl	%eax, %eax
    3ca8: 79 34                        	jns	0x3cde <trusted_x86_x86_sim_xdp+0x3cde>
    3caa: 48 8d 44 24 58               	leaq	0x58(%rsp), %rax
    3caf: 48 c7 40 28 00 00 00 00      	movq	$0x0, 0x28(%rax)
    3cb7: 48 c7 40 20 00 00 00 00      	movq	$0x0, 0x20(%rax)
    3cbf: 48 c7 40 18 00 00 00 00      	movq	$0x0, 0x18(%rax)
    3cc7: 48 c7 40 10 00 00 00 00      	movq	$0x0, 0x10(%rax)
    3ccf: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
    3cd7: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    3cde: 4c 01 f5                     	addq	%r14, %rbp
    3ce1: 49 bc 00 00 00 00 00 00 00 ff	movabsq	$-0x100000000000000, %r12 # imm = 0xFF00000000000000
    3ceb: 49 be 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %r14 # imm = 0x200000000000000
    3cf5: 48 89 d8                     	movq	%rbx, %rax
    3cf8: 8b 00                        	movl	(%rax), %eax
    3cfa: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    3d02: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    3d08: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    3d0d: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    3d14: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    3d19: 0f 84 3f 01 00 00            	je	0x3e5e <trusted_x86_x86_sim_xdp+0x3e5e>
    3d1f: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    3d23: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3d2a <trusted_x86_x86_sim_xdp+0x3d2a>
		0000000000003d26:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3d2a: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    3d2d: 0f 83 4a 01 00 00            	jae	0x3e7d <trusted_x86_x86_sim_xdp+0x3e7d>
    3d33: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3d3a <trusted_x86_x86_sim_xdp+0x3d3a>
		0000000000003d36:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3d3a: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    3d40: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    3d48: e8 00 00 00 00               	callq	0x3d4d <trusted_x86_x86_sim_xdp+0x3d4d>
		0000000000003d49:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3d4d: e9 16 01 00 00               	jmp	0x3e68 <trusted_x86_x86_sim_xdp+0x3e68>
    3d52: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    3d57: eb 18                        	jmp	0x3d71 <trusted_x86_x86_sim_xdp+0x3d71>
    3d59: 8b 84 24 f0 00 00 00         	movl	0xf0(%rsp), %eax
    3d60: c7 44 24 38 00 00 00 00      	movl	$0x0, 0x38(%rsp)
    3d68: 85 c0                        	testl	%eax, %eax
    3d6a: 75 1a                        	jne	0x3d86 <trusted_x86_x86_sim_xdp+0x3d86>
    3d6c: 48 8b 44 24 40               	movq	0x40(%rsp), %rax
    3d71: c7 84 24 f0 00 00 00 10 00 00 00     	movl	$0x10, 0xf0(%rsp)
    3d7c: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
    3d81: b8 10 00 00 00               	movl	$0x10, %eax
    3d86: 89 c6                        	movl	%eax, %esi
    3d88: 48 03 74 24 20               	addq	0x20(%rsp), %rsi
    3d8d: 48 89 74 24 20               	movq	%rsi, 0x20(%rsp)
    3d92: e9 a2 03 00 00               	jmp	0x4139 <trusted_x86_x86_sim_xdp+0x4139>
    3d97: 48 89 d8                     	movq	%rbx, %rax
    3d9a: 4c 8b a0 00 0f 00 00         	movq	0xf00(%rax), %r12
    3da1: eb 05                        	jmp	0x3da8 <trusted_x86_x86_sim_xdp+0x3da8>
    3da3: 4c 8b 64 24 70               	movq	0x70(%rsp), %r12
    3da8: 4c 8b b4 24 90 00 00 00      	movq	0x90(%rsp), %r14
    3db0: 48 8b 84 24 a0 00 00 00      	movq	0xa0(%rsp), %rax
    3db8: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
    3dbd: 48 8b 84 24 a8 00 00 00      	movq	0xa8(%rsp), %rax
    3dc5: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    3dca: 48 8b 84 24 b0 00 00 00      	movq	0xb0(%rsp), %rax
    3dd2: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    3dd7: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    3ddc: 0f b6 70 1c                  	movzbl	0x1c(%rax), %esi
    3de0: 4c 01 f6                     	addq	%r14, %rsi
    3de3: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    3de8: ba 08 00 00 00               	movl	$0x8, %edx
    3ded: e8 00 00 00 00               	callq	0x3df2 <trusted_x86_x86_sim_xdp+0x3df2>
		0000000000003dee:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3df2: 85 c0                        	testl	%eax, %eax
    3df4: 79 09                        	jns	0x3dff <trusted_x86_x86_sim_xdp+0x3dff>
    3df6: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
    3dff: 85 c0                        	testl	%eax, %eax
    3e01: 0f 84 d0 00 00 00            	je	0x3ed7 <trusted_x86_x86_sim_xdp+0x3ed7>
    3e07: c7 84 24 04 01 00 00 2d 00 00 00     	movl	$0x2d, 0x104(%rsp)
    3e12: bd e9 03 00 00               	movl	$0x3e9, %ebp            # imm = 0x3E9
    3e17: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x3e1e <trusted_x86_x86_sim_xdp+0x3e1e>
		0000000000003e1a:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3e1e: 83 78 44 2e                  	cmpl	$0x2e, 0x44(%rax)
    3e22: 0f 82 e4 c3 ff ff            	jb	0x20c <trusted_x86_x86_sim_xdp+0x20c>
    3e28: b8 2d 00 00 00               	movl	$0x2d, %eax
    3e2d: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3e34 <trusted_x86_x86_sim_xdp+0x3e34>
		0000000000003e30:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3e34: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    3e3a: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    3e42: e8 00 00 00 00               	callq	0x3e47 <trusted_x86_x86_sim_xdp+0x3e47>
		0000000000003e43:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3e47: 48 85 c0                     	testq	%rax, %rax
    3e4a: 0f 84 bc c3 ff ff            	je	0x20c <trusted_x86_x86_sim_xdp+0x20c>
    3e50: 48 89 c1                     	movq	%rax, %rcx
    3e53: 48 8b 09                     	movq	(%rcx), %rcx
    3e56: 48 ff c1                     	incq	%rcx
    3e59: e9 ab c3 ff ff               	jmp	0x209 <trusted_x86_x86_sim_xdp+0x209>
    3e5e: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    3e63: e8 00 00 00 00               	callq	0x3e68 <trusted_x86_x86_sim_xdp+0x3e68>
		0000000000003e64:  R_X86_64_PLT32	.text+0x7c
    3e68: 48 85 c0                     	testq	%rax, %rax
    3e6b: 74 10                        	je	0x3e7d <trusted_x86_x86_sim_xdp+0x3e7d>
    3e6d: 48 8b 40 08                  	movq	0x8(%rax), %rax
    3e71: 4c 21 e0                     	andq	%r12, %rax
    3e74: 4c 39 f0                     	cmpq	%r14, %rax
    3e77: 0f 84 aa 02 00 00            	je	0x4127 <trusted_x86_x86_sim_xdp+0x4127>
    3e7d: 48 89 d8                     	movq	%rbx, %rax
    3e80: 8b 00                        	movl	(%rax), %eax
    3e82: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    3e8a: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    3e90: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
    3e95: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    3e9c: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    3ea1: 0f 84 80 00 00 00            	je	0x3f27 <trusted_x86_x86_sim_xdp+0x3f27>
    3ea7: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    3eab: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3eb2 <trusted_x86_x86_sim_xdp+0x3eb2>
		0000000000003eae:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3eb2: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    3eb5: 0f 83 90 00 00 00            	jae	0x3f4b <trusted_x86_x86_sim_xdp+0x3f4b>
    3ebb: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3ec2 <trusted_x86_x86_sim_xdp+0x3ec2>
		0000000000003ebe:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3ec2: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    3ec8: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    3ed0: e8 00 00 00 00               	callq	0x3ed5 <trusted_x86_x86_sim_xdp+0x3ed5>
		0000000000003ed1:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3ed5: eb 5a                        	jmp	0x3f31 <trusted_x86_x86_sim_xdp+0x3f31>
    3ed7: 4c 8b 6c 24 28               	movq	0x28(%rsp), %r13
    3edc: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    3ee1: 0f b6 40 1d                  	movzbl	0x1d(%rax), %eax
    3ee5: 4c 01 e8                     	addq	%r13, %rax
    3ee8: 31 c9                        	xorl	%ecx, %ecx
    3eea: 49 39 c4                     	cmpq	%rax, %r12
    3eed: 48 0f 43 c8                  	cmovaeq	%rax, %rcx
    3ef1: 49 29 cc                     	subq	%rcx, %r12
    3ef4: 49 81 fc ff ff 00 00         	cmpq	$0xffff, %r12           # imm = 0xFFFF
    3efb: b8 ff ff 00 00               	movl	$0xffff, %eax           # imm = 0xFFFF
    3f00: 49 0f 42 c4                  	cmovbq	%r12, %rax
    3f04: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
    3f09: 49 c1 ed 03                  	shrq	$0x3, %r13
    3f0d: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    3f13: 83 c9 02                     	orl	$0x2, %ecx
    3f16: 89 4c 24 38                  	movl	%ecx, 0x38(%rsp)
    3f1a: 4c 89 b4 24 c0 00 00 00      	movq	%r14, 0xc0(%rsp)
    3f22: e9 5b 02 00 00               	jmp	0x4182 <trusted_x86_x86_sim_xdp+0x4182>
    3f27: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    3f2c: e8 00 00 00 00               	callq	0x3f31 <trusted_x86_x86_sim_xdp+0x3f31>
		0000000000003f2d:  R_X86_64_PLT32	.text+0x7c
    3f31: 48 85 c0                     	testq	%rax, %rax
    3f34: 74 15                        	je	0x3f4b <trusted_x86_x86_sim_xdp+0x3f4b>
    3f36: 48 8b 40 08                  	movq	0x8(%rax), %rax
    3f3a: 4c 21 e0                     	andq	%r12, %rax
    3f3d: 4c 39 f0                     	cmpq	%r14, %rax
    3f40: 75 09                        	jne	0x3f4b <trusted_x86_x86_sim_xdp+0x3f4b>
    3f42: 48 83 c5 08                  	addq	$0x8, %rbp
    3f46: e9 dc 01 00 00               	jmp	0x4127 <trusted_x86_x86_sim_xdp+0x4127>
    3f4b: 48 89 d8                     	movq	%rbx, %rax
    3f4e: 8b 00                        	movl	(%rax), %eax
    3f50: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    3f58: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    3f5e: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
    3f63: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    3f6a: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    3f6f: 74 2c                        	je	0x3f9d <trusted_x86_x86_sim_xdp+0x3f9d>
    3f71: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    3f75: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3f7c <trusted_x86_x86_sim_xdp+0x3f7c>
		0000000000003f78:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3f7c: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    3f7f: 73 40                        	jae	0x3fc1 <trusted_x86_x86_sim_xdp+0x3fc1>
    3f81: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3f88 <trusted_x86_x86_sim_xdp+0x3f88>
		0000000000003f84:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3f88: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    3f8e: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    3f96: e8 00 00 00 00               	callq	0x3f9b <trusted_x86_x86_sim_xdp+0x3f9b>
		0000000000003f97:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    3f9b: eb 0a                        	jmp	0x3fa7 <trusted_x86_x86_sim_xdp+0x3fa7>
    3f9d: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    3fa2: e8 00 00 00 00               	callq	0x3fa7 <trusted_x86_x86_sim_xdp+0x3fa7>
		0000000000003fa3:  R_X86_64_PLT32	.text+0x7c
    3fa7: 48 85 c0                     	testq	%rax, %rax
    3faa: 74 15                        	je	0x3fc1 <trusted_x86_x86_sim_xdp+0x3fc1>
    3fac: 48 8b 40 08                  	movq	0x8(%rax), %rax
    3fb0: 4c 21 e0                     	andq	%r12, %rax
    3fb3: 4c 39 f0                     	cmpq	%r14, %rax
    3fb6: 75 09                        	jne	0x3fc1 <trusted_x86_x86_sim_xdp+0x3fc1>
    3fb8: 48 83 c5 10                  	addq	$0x10, %rbp
    3fbc: e9 66 01 00 00               	jmp	0x4127 <trusted_x86_x86_sim_xdp+0x4127>
    3fc1: 48 89 d8                     	movq	%rbx, %rax
    3fc4: 8b 00                        	movl	(%rax), %eax
    3fc6: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    3fce: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    3fd4: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
    3fd9: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    3fe0: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    3fe5: 74 2c                        	je	0x4013 <trusted_x86_x86_sim_xdp+0x4013>
    3fe7: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    3feb: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3ff2 <trusted_x86_x86_sim_xdp+0x3ff2>
		0000000000003fee:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3ff2: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    3ff5: 73 40                        	jae	0x4037 <trusted_x86_x86_sim_xdp+0x4037>
    3ff7: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x3ffe <trusted_x86_x86_sim_xdp+0x3ffe>
		0000000000003ffa:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3ffe: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    4004: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    400c: e8 00 00 00 00               	callq	0x4011 <trusted_x86_x86_sim_xdp+0x4011>
		000000000000400d:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    4011: eb 0a                        	jmp	0x401d <trusted_x86_x86_sim_xdp+0x401d>
    4013: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    4018: e8 00 00 00 00               	callq	0x401d <trusted_x86_x86_sim_xdp+0x401d>
		0000000000004019:  R_X86_64_PLT32	.text+0x7c
    401d: 48 85 c0                     	testq	%rax, %rax
    4020: 74 15                        	je	0x4037 <trusted_x86_x86_sim_xdp+0x4037>
    4022: 48 8b 40 08                  	movq	0x8(%rax), %rax
    4026: 4c 21 e0                     	andq	%r12, %rax
    4029: 4c 39 f0                     	cmpq	%r14, %rax
    402c: 75 09                        	jne	0x4037 <trusted_x86_x86_sim_xdp+0x4037>
    402e: 48 83 c5 18                  	addq	$0x18, %rbp
    4032: e9 f0 00 00 00               	jmp	0x4127 <trusted_x86_x86_sim_xdp+0x4127>
    4037: 48 89 d8                     	movq	%rbx, %rax
    403a: 8b 00                        	movl	(%rax), %eax
    403c: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    4044: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    404a: 48 8b 44 24 78               	movq	0x78(%rsp), %rax
    404f: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    4056: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    405b: 74 2c                        	je	0x4089 <trusted_x86_x86_sim_xdp+0x4089>
    405d: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    4061: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x4068 <trusted_x86_x86_sim_xdp+0x4068>
		0000000000004064:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    4068: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    406b: 73 3d                        	jae	0x40aa <trusted_x86_x86_sim_xdp+0x40aa>
    406d: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x4074 <trusted_x86_x86_sim_xdp+0x4074>
		0000000000004070:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    4074: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    407a: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    4082: e8 00 00 00 00               	callq	0x4087 <trusted_x86_x86_sim_xdp+0x4087>
		0000000000004083:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    4087: eb 0a                        	jmp	0x4093 <trusted_x86_x86_sim_xdp+0x4093>
    4089: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    408e: e8 00 00 00 00               	callq	0x4093 <trusted_x86_x86_sim_xdp+0x4093>
		000000000000408f:  R_X86_64_PLT32	.text+0x7c
    4093: 48 85 c0                     	testq	%rax, %rax
    4096: 74 12                        	je	0x40aa <trusted_x86_x86_sim_xdp+0x40aa>
    4098: 48 8b 40 08                  	movq	0x8(%rax), %rax
    409c: 4c 21 e0                     	andq	%r12, %rax
    409f: 4c 39 f0                     	cmpq	%r14, %rax
    40a2: 75 06                        	jne	0x40aa <trusted_x86_x86_sim_xdp+0x40aa>
    40a4: 48 83 c5 20                  	addq	$0x20, %rbp
    40a8: eb 7d                        	jmp	0x4127 <trusted_x86_x86_sim_xdp+0x4127>
    40aa: 48 89 d8                     	movq	%rbx, %rax
    40ad: 8b 00                        	movl	(%rax), %eax
    40af: c7 44 24 28 60 00 00 00      	movl	$0x60, 0x28(%rsp)
    40b7: 0f 38 f1 44 24 2c            	movbel	%eax, 0x2c(%rsp)
    40bd: 48 8b 84 24 80 00 00 00      	movq	0x80(%rsp), %rax
    40c5: 48 0f 38 f1 44 24 30         	movbeq	%rax, 0x30(%rsp)
    40cc: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    40d1: 74 30                        	je	0x4103 <trusted_x86_x86_sim_xdp+0x4103>
    40d3: 8b 44 24 28                  	movl	0x28(%rsp), %eax
    40d7: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x40de <trusted_x86_x86_sim_xdp+0x40de>
		00000000000040da:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    40de: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    40e1: 0f 83 5b 02 00 00            	jae	0x4342 <trusted_x86_x86_sim_xdp+0x4342>
    40e7: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x40ee <trusted_x86_x86_sim_xdp+0x40ee>
		00000000000040ea:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    40ee: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    40f4: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    40fc: e8 00 00 00 00               	callq	0x4101 <trusted_x86_x86_sim_xdp+0x4101>
		00000000000040fd:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    4101: eb 0a                        	jmp	0x410d <trusted_x86_x86_sim_xdp+0x410d>
    4103: 48 8d 7c 24 28               	leaq	0x28(%rsp), %rdi
    4108: e8 00 00 00 00               	callq	0x410d <trusted_x86_x86_sim_xdp+0x410d>
		0000000000004109:  R_X86_64_PLT32	.text+0x7c
    410d: 48 85 c0                     	testq	%rax, %rax
    4110: 0f 84 2c 02 00 00            	je	0x4342 <trusted_x86_x86_sim_xdp+0x4342>
    4116: 4c 23 60 08                  	andq	0x8(%rax), %r12
    411a: 4d 39 f4                     	cmpq	%r14, %r12
    411d: 0f 85 1f 02 00 00            	jne	0x4342 <trusted_x86_x86_sim_xdp+0x4342>
    4123: 48 83 c5 28                  	addq	$0x28, %rbp
    4127: c7 44 24 38 03 00 00 00      	movl	$0x3, 0x38(%rsp)
    412f: 48 89 6c 24 20               	movq	%rbp, 0x20(%rsp)
    4134: 48 8b 74 24 20               	movq	0x20(%rsp), %rsi
    4139: 48 83 c6 f0                  	addq	$-0x10, %rsi
    413d: ba 10 00 00 00               	movl	$0x10, %edx
    4142: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    4147: e8 00 00 00 00               	callq	0x414c <trusted_x86_x86_sim_xdp+0x414c>
		0000000000004148:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    414c: 85 c0                        	testl	%eax, %eax
    414e: 79 14                        	jns	0x4164 <trusted_x86_x86_sim_xdp+0x4164>
    4150: 48 8d 44 24 58               	leaq	0x58(%rsp), %rax
    4155: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
    415d: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    4164: 83 bc 24 f0 00 00 00 10      	cmpl	$0x10, 0xf0(%rsp)
    416c: 72 0a                        	jb	0x4178 <trusted_x86_x86_sim_xdp+0x4178>
    416e: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    4173: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    4178: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
    417d: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    4182: 48 89 d8                     	movq	%rbx, %rax
    4185: 8b 88 c0 02 00 00            	movl	0x2c0(%rax), %ecx
    418b: 83 f9 7e                     	cmpl	$0x7e, %ecx
    418e: 0f 87 0c c9 ff ff            	ja	0xaa0 <trusted_x86_x86_sim_xdp+0xaa0>
    4194: 48 89 d8                     	movq	%rbx, %rax
    4197: 0f b6 80 30 0f 00 00         	movzbl	0xf30(%rax), %eax
    419e: 8b 54 24 38                  	movl	0x38(%rsp), %edx
    41a2: 48 8b 74 24 50               	movq	0x50(%rsp), %rsi
    41a7: 4c 8b 84 24 70 01 00 00      	movq	0x170(%rsp), %r8
    41af: 8d 79 01                     	leal	0x1(%rcx), %edi
    41b2: 41 89 38                     	movl	%edi, (%r8)
    41b5: c1 e1 03                     	shll	$0x3, %ecx
    41b8: 8d 0c 49                     	leal	(%rcx,%rcx,2), %ecx
    41bb: 4c 8b 84 24 b8 01 00 00      	movq	0x1b8(%rsp), %r8
    41c3: 49 01 c8                     	addq	%rcx, %r8
    41c6: 48 8b bc 24 c0 00 00 00      	movq	0xc0(%rsp), %rdi
    41ce: 49 89 38                     	movq	%rdi, (%r8)
    41d1: 48 c1 e6 20                  	shlq	$0x20, %rsi
    41d5: 44 89 ef                     	movl	%r13d, %edi
    41d8: 48 09 f7                     	orq	%rsi, %rdi
    41db: 48 c1 e2 3c                  	shlq	$0x3c, %rdx
    41df: 48 09 d7                     	orq	%rdx, %rdi
    41e2: 48 8b 94 24 b0 01 00 00      	movq	0x1b0(%rsp), %rdx
    41ea: 48 01 ca                     	addq	%rcx, %rdx
    41ed: 48 89 3a                     	movq	%rdi, (%rdx)
    41f0: 48 8b 94 24 c0 01 00 00      	movq	0x1c0(%rsp), %rdx
    41f8: 48 01 ca                     	addq	%rcx, %rdx
    41fb: c6 02 05                     	movb	$0x5, (%rdx)
    41fe: 48 8b 94 24 50 01 00 00      	movq	0x150(%rsp), %rdx
    4206: 48 01 ca                     	addq	%rcx, %rdx
    4209: 88 02                        	movb	%al, (%rdx)
    420b: 48 8b 84 24 a0 01 00 00      	movq	0x1a0(%rsp), %rax
    4213: 48 01 c8                     	addq	%rcx, %rax
    4216: c7 00 00 00 00 00            	movl	$0x0, (%rax)
    421c: 48 8b 84 24 a8 01 00 00      	movq	0x1a8(%rsp), %rax
    4224: 48 01 c8                     	addq	%rcx, %rax
    4227: 66 c7 00 00 00               	movw	$0x0, (%rax)
    422c: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    4231: 48 8b 8c 24 90 01 00 00      	movq	0x190(%rsp), %rcx
    4239: 48 89 01                     	movq	%rax, (%rcx)
    423c: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
    4241: 48 8b 8c 24 88 01 00 00      	movq	0x188(%rsp), %rcx
    4249: 48 89 01                     	movq	%rax, (%rcx)
    424c: 48 8b 44 24 40               	movq	0x40(%rsp), %rax
    4251: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
    4259: 48 89 01                     	movq	%rax, (%rcx)
    425c: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
    4264: c6 00 01                     	movb	$0x1, (%rax)
    4267: c7 44 24 58 2a 00 00 00      	movl	$0x2a, 0x58(%rsp)
    426f: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x4276 <trusted_x86_x86_sim_xdp+0x4276>
		0000000000004272:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    4276: 83 78 44 2b                  	cmpl	$0x2b, 0x44(%rax)
    427a: 72 30                        	jb	0x42ac <trusted_x86_x86_sim_xdp+0x42ac>
    427c: b8 2a 00 00 00               	movl	$0x2a, %eax
    4281: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x4288 <trusted_x86_x86_sim_xdp+0x4288>
		0000000000004284:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    4288: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    428e: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    4296: e8 00 00 00 00               	callq	0x429b <trusted_x86_x86_sim_xdp+0x429b>
		0000000000004297:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    429b: 48 85 c0                     	testq	%rax, %rax
    429e: 74 0c                        	je	0x42ac <trusted_x86_x86_sim_xdp+0x42ac>
    42a0: 48 89 c1                     	movq	%rax, %rcx
    42a3: 48 8b 09                     	movq	(%rcx), %rcx
    42a6: 48 ff c1                     	incq	%rcx
    42a9: 48 89 08                     	movq	%rcx, (%rax)
    42ac: 48 89 d8                     	movq	%rbx, %rax
    42af: 4c 8b a0 d0 0e 00 00         	movq	0xed0(%rax), %r12
    42b6: 4d 85 e4                     	testq	%r12, %r12
    42b9: 74 70                        	je	0x432b <trusted_x86_x86_sim_xdp+0x432b>
    42bb: 4c 3b a4 24 98 01 00 00      	cmpq	0x198(%rsp), %r12
    42c3: 0f 83 13 cf ff ff            	jae	0x11dc <trusted_x86_x86_sim_xdp+0x11dc>
    42c9: 49 81 fc 00 10 00 00         	cmpq	$0x1000, %r12           # imm = 0x1000
    42d0: 0f 82 26 cf ff ff            	jb	0x11fc <trusted_x86_x86_sim_xdp+0x11fc>
    42d6: 48 89 d8                     	movq	%rbx, %rax
    42d9: 8b 00                        	movl	(%rax), %eax
    42db: c7 44 24 58 60 00 00 00      	movl	$0x60, 0x58(%rsp)
    42e3: 0f 38 f1 44 24 5c            	movbel	%eax, 0x5c(%rsp)
    42e9: 4c 0f 38 f1 64 24 60         	movbeq	%r12, 0x60(%rsp)
    42f0: 80 7c 24 0f 00               	cmpb	$0x0, 0xf(%rsp)
    42f5: 0f 84 9e 00 00 00            	je	0x4399 <trusted_x86_x86_sim_xdp+0x4399>
    42fb: 8b 44 24 58                  	movl	0x58(%rsp), %eax
    42ff: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x4306 <trusted_x86_x86_sim_xdp+0x4306>
		0000000000004302:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    4306: 3b 41 44                     	cmpl	0x44(%rcx), %eax
    4309: 0f 83 17 01 00 00            	jae	0x4426 <trusted_x86_x86_sim_xdp+0x4426>
    430f: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x4316 <trusted_x86_x86_sim_xdp+0x4316>
		0000000000004312:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    4316: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    431c: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    4324: e8 00 00 00 00               	callq	0x4329 <trusted_x86_x86_sim_xdp+0x4329>
		0000000000004325:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    4329: eb 78                        	jmp	0x43a3 <trusted_x86_x86_sim_xdp+0x43a3>
    432b: 48 8d 83 28 0f 00 00         	leaq	0xf28(%rbx), %rax
    4332: c7 00 01 00 00 00            	movl	$0x1, (%rax)
    4338: bd ad 0f 00 00               	movl	$0xfad, %ebp            # imm = 0xFAD
    433d: e9 ca be ff ff               	jmp	0x20c <trusted_x86_x86_sim_xdp+0x20c>
    4342: c7 44 24 28 2e 00 00 00      	movl	$0x2e, 0x28(%rsp)
    434a: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x4351 <trusted_x86_x86_sim_xdp+0x4351>
		000000000000434d:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    4351: 83 78 44 2f                  	cmpl	$0x2f, 0x44(%rax)
    4355: 72 30                        	jb	0x4387 <trusted_x86_x86_sim_xdp+0x4387>
    4357: b8 2e 00 00 00               	movl	$0x2e, %eax
    435c: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x4363 <trusted_x86_x86_sim_xdp+0x4363>
		000000000000435f:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    4363: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
    4369: 48 8b bc c1 30 01 00 00      	movq	0x130(%rcx,%rax,8), %rdi
    4371: e8 00 00 00 00               	callq	0x4376 <trusted_x86_x86_sim_xdp+0x4376>
		0000000000004372:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    4376: 48 85 c0                     	testq	%rax, %rax
    4379: 74 0c                        	je	0x4387 <trusted_x86_x86_sim_xdp+0x4387>
    437b: 48 89 c1                     	movq	%rax, %rcx
    437e: 48 8b 09                     	movq	(%rcx), %rcx
    4381: 48 ff c1                     	incq	%rcx
    4384: 48 89 08                     	movq	%rcx, (%rax)
    4387: c7 44 24 38 03 00 00 00      	movl	$0x3, 0x38(%rsp)
    438f: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    4394: e9 10 df ff ff               	jmp	0x22a9 <trusted_x86_x86_sim_xdp+0x22a9>
    4399: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    439e: e8 00 00 00 00               	callq	0x43a3 <trusted_x86_x86_sim_xdp+0x43a3>
		000000000000439f:  R_X86_64_PLT32	.text+0x7c
    43a3: 48 85 c0                     	testq	%rax, %rax
    43a6: 74 7e                        	je	0x4426 <trusted_x86_x86_sim_xdp+0x4426>
    43a8: 48 89 c1                     	movq	%rax, %rcx
    43ab: 4c 8b 69 08                  	movq	0x8(%rcx), %r13
    43af: 48 b9 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    43b9: 4c 21 e9                     	andq	%r13, %rcx
    43bc: 48 8b 94 24 68 01 00 00      	movq	0x168(%rsp), %rdx
    43c4: 48 89 0a                     	movq	%rcx, (%rdx)
    43c7: 49 c1 ed 38                  	shrq	$0x38, %r13
    43cb: 48 8b 00                     	movq	(%rax), %rax
    43ce: 48 8b 94 24 60 01 00 00      	movq	0x160(%rsp), %rdx
    43d6: 48 89 02                     	movq	%rax, (%rdx)
    43d9: 49 29 cc                     	subq	%rcx, %r12
    43dc: 48 8b 8c 24 58 01 00 00      	movq	0x158(%rsp), %rcx
    43e4: 4c 89 21                     	movq	%r12, (%rcx)
    43e7: 31 ed                        	xorl	%ebp, %ebp
    43e9: 49 83 fd 01                  	cmpq	$0x1, %r13
    43ed: 0f 85 1c be ff ff            	jne	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    43f3: 48 89 44 24 58               	movq	%rax, 0x58(%rsp)
    43f8: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x43ff <trusted_x86_x86_sim_xdp+0x43ff>
		00000000000043fb:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    43ff: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x4406 <trusted_x86_x86_sim_xdp+0x4406>
		0000000000004402:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    4406: 74 35                        	je	0x443d <trusted_x86_x86_sim_xdp+0x443d>
    4408: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x440f <trusted_x86_x86_sim_xdp+0x440f>
		000000000000440b:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
    440f: 74 2c                        	je	0x443d <trusted_x86_x86_sim_xdp+0x443d>
    4411: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    4416: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x441d <trusted_x86_x86_sim_xdp+0x441d>
		0000000000004419:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    441d: 75 46                        	jne	0x4465 <trusted_x86_x86_sim_xdp+0x4465>
    441f: e8 00 00 00 00               	callq	0x4424 <trusted_x86_x86_sim_xdp+0x4424>
		0000000000004420:  R_X86_64_PLT32	.text+0x7c
    4424: eb 44                        	jmp	0x446a <trusted_x86_x86_sim_xdp+0x446a>
    4426: 48 8d 83 28 0f 00 00         	leaq	0xf28(%rbx), %rax
    442d: c7 00 0c 00 00 00            	movl	$0xc, (%rax)
    4433: bd ac 0f 00 00               	movl	$0xfac, %ebp            # imm = 0xFAC
    4438: e9 cf bd ff ff               	jmp	0x20c <trusted_x86_x86_sim_xdp+0x20c>
    443d: 8b 4c 24 58                  	movl	0x58(%rsp), %ecx
    4441: 41 bd 01 00 00 00            	movl	$0x1, %r13d
    4447: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    444a: 0f 83 bf bd ff ff            	jae	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    4450: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    4456: 48 8b bc c8 30 01 00 00      	movq	0x130(%rax,%rcx,8), %rdi
    445e: e8 00 00 00 00               	callq	0x4463 <trusted_x86_x86_sim_xdp+0x4463>
		000000000000445f:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    4463: eb 05                        	jmp	0x446a <trusted_x86_x86_sim_xdp+0x446a>
    4465: e8 00 00 00 00               	callq	0x446a <trusted_x86_x86_sim_xdp+0x446a>
		0000000000004466:  R_X86_64_PLT32	.text+0x12c
    446a: 49 89 c6                     	movq	%rax, %r14
    446d: 41 bd 01 00 00 00            	movl	$0x1, %r13d
    4473: 48 85 c0                     	testq	%rax, %rax
    4476: 0f 84 93 bd ff ff            	je	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    447c: 4c 89 f0                     	movq	%r14, %rax
    447f: 48 8b 00                     	movq	(%rax), %rax
    4482: 4c 39 e0                     	cmpq	%r12, %rax
    4485: 77 0c                        	ja	0x4493 <trusted_x86_x86_sim_xdp+0x4493>
    4487: 4c 89 f0                     	movq	%r14, %rax
    448a: 48 8b 40 08                  	movq	0x8(%rax), %rax
    448e: 4c 39 e0                     	cmpq	%r12, %rax
    4491: 73 20                        	jae	0x44b3 <trusted_x86_x86_sim_xdp+0x44b3>
    4493: 4c 89 f0                     	movq	%r14, %rax
    4496: 48 8b 40 10                  	movq	0x10(%rax), %rax
    449a: 4c 39 e0                     	cmpq	%r12, %rax
    449d: 0f 87 6c bd ff ff            	ja	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    44a3: 4c 89 f0                     	movq	%r14, %rax
    44a6: 48 8b 40 18                  	movq	0x18(%rax), %rax
    44aa: 4c 39 e0                     	cmpq	%r12, %rax
    44ad: 0f 82 5c bd ff ff            	jb	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    44b3: 48 89 d8                     	movq	%rbx, %rax
    44b6: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
    44bc: 4c 89 f1                     	movq	%r14, %rcx
    44bf: 8b 49 20                     	movl	0x20(%rcx), %ecx
    44c2: 0f a3 c8                     	btl	%ecx, %eax
    44c5: 0f 82 44 bd ff ff            	jb	0x20f <trusted_x86_x86_sim_xdp+0x20f>
    44cb: c7 84 24 c8 00 00 00 00 00 00 00     	movl	$0x0, 0xc8(%rsp)
    44d6: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x44dd <trusted_x86_x86_sim_xdp+0x44dd>
		00000000000044d9:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    44dd: 83 78 44 00                  	cmpl	$0x0, 0x44(%rax)
    44e1: 74 24                        	je	0x4507 <trusted_x86_x86_sim_xdp+0x4507>
    44e3: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x44ea <trusted_x86_x86_sim_xdp+0x44ea>
		00000000000044e6:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    44ea: 48 8b b8 30 01 00 00         	movq	0x130(%rax), %rdi
    44f1: e8 00 00 00 00               	callq	0x44f6 <trusted_x86_x86_sim_xdp+0x44f6>
		00000000000044f2:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
    44f6: 48 85 c0                     	testq	%rax, %rax
    44f9: 74 0c                        	je	0x4507 <trusted_x86_x86_sim_xdp+0x4507>
    44fb: 48 89 c1                     	movq	%rax, %rcx
    44fe: 48 8b 09                     	movq	(%rcx), %rcx
    4501: 48 ff c1                     	incq	%rcx
    4504: 48 89 08                     	movq	%rcx, (%rax)
    4507: 45 0f b7 6e 20               	movzwl	0x20(%r14), %r13d
    450c: e9 fe bc ff ff               	jmp	0x20f <trusted_x86_x86_sim_xdp+0x20f>
