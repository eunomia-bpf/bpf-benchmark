
/var/tmp/kprog-tmp/perf/dynamic-array-c/native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <selected>:
       0: 8b 07                        	movl	(%rdi), %eax
       2: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x9 <selected+0x9>
		0000000000000005:  R_X86_64_REX_GOTPCRELX	counts-0x4
       9: 3b 41 44                     	cmpl	0x44(%rcx), %eax
       c: 73 1a                        	jae	0x28 <selected+0x28>
       e: 8b 91 20 01 00 00            	movl	0x120(%rcx), %edx
      14: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
      1a: 48 0f af c2                  	imulq	%rdx, %rax
      1e: 48 01 c8                     	addq	%rcx, %rax
      21: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
      27: c3                           	retq
      28: 31 c0                        	xorl	%eax, %eax
      2a: c3                           	retq
      2b: 0f 1f 44 00 00               	nopl	(%rax,%rax)

0000000000000030 <selected_alias>:
      30: 8b 07                        	movl	(%rdi), %eax
      32: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x39 <selected_alias+0x9>
		0000000000000035:  R_X86_64_REX_GOTPCRELX	same-0x4
      39: 3b 41 44                     	cmpl	0x44(%rcx), %eax
      3c: 73 1a                        	jae	0x58 <selected_alias+0x28>
      3e: 8b 91 20 01 00 00            	movl	0x120(%rcx), %edx
      44: 23 81 24 01 00 00            	andl	0x124(%rcx), %eax
      4a: 48 0f af c2                  	imulq	%rdx, %rax
      4e: 48 01 c8                     	addq	%rcx, %rax
      51: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
      57: c3                           	retq
      58: 31 c0                        	xorl	%eax, %eax
      5a: c3                           	retq
      5b: 0f 1f 44 00 00               	nopl	(%rax,%rax)

0000000000000060 <unselected>:
      60: 48 89 fe                     	movq	%rdi, %rsi
      63: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x6a <unselected+0xa>
		0000000000000066:  R_X86_64_REX_GOTPCRELX	other-0x4
      6a: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
      6e: 75 21                        	jne	0x91 <unselected+0x31>
      70: 8b 06                        	movl	(%rsi), %eax
      72: 3b 47 44                     	cmpl	0x44(%rdi), %eax
      75: 73 24                        	jae	0x9b <unselected+0x3b>
      77: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
      7d: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
      83: 48 0f af c1                  	imulq	%rcx, %rax
      87: 48 01 f8                     	addq	%rdi, %rax
      8a: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
      90: c3                           	retq
      91: 48 8b 47 20                  	movq	0x20(%rdi), %rax
      95: 48 8b 40 60                  	movq	0x60(%rax), %rax
      99: ff e0                        	jmpq	*%rax
      9b: 31 c0                        	xorl	%eax, %eax
      9d: c3                           	retq
      9e: 66 90                        	nop

00000000000000a0 <dynamic>:
      a0: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
      a4: 75 21                        	jne	0xc7 <dynamic+0x27>
      a6: 8b 06                        	movl	(%rsi), %eax
      a8: 3b 47 44                     	cmpl	0x44(%rdi), %eax
      ab: 73 24                        	jae	0xd1 <dynamic+0x31>
      ad: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
      b3: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
      b9: 48 0f af c1                  	imulq	%rcx, %rax
      bd: 48 01 f8                     	addq	%rdi, %rax
      c0: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
      c6: c3                           	retq
      c7: 48 8b 47 20                  	movq	0x20(%rdi), %rax
      cb: 48 8b 40 60                  	movq	0x60(%rax), %rax
      cf: ff e0                        	jmpq	*%rax
      d1: 31 c0                        	xorl	%eax, %eax
      d3: c3                           	retq
      d4: 66 66 66 2e 0f 1f 84 00 00 00 00 00  	nopw	%cs:(%rax,%rax)

00000000000000e0 <__kprog_array_lookup>:
      e0: 8b 06                        	movl	(%rsi), %eax
      e2: 3b 47 44                     	cmpl	0x44(%rdi), %eax
      e5: 73 1a                        	jae	0x101 <__kprog_array_lookup+0x21>
      e7: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
      ed: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
      f3: 48 0f af c1                  	imulq	%rcx, %rax
      f7: 48 01 f8                     	addq	%rdi, %rax
      fa: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     100: c3                           	retq
     101: 31 c0                        	xorl	%eax, %eax
     103: c3                           	retq
     104: 66 66 66 2e 0f 1f 84 00 00 00 00 00  	nopw	%cs:(%rax,%rax)

0000000000000110 <bpf_map_lookup_elem>:
     110: 83 7f 38 02                  	cmpl	$0x2, 0x38(%rdi)
     114: 75 21                        	jne	0x137 <bpf_map_lookup_elem+0x27>
     116: 8b 06                        	movl	(%rsi), %eax
     118: 3b 47 44                     	cmpl	0x44(%rdi), %eax
     11b: 73 24                        	jae	0x141 <bpf_map_lookup_elem+0x31>
     11d: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
     123: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
     129: 48 0f af c1                  	imulq	%rcx, %rax
     12d: 48 01 f8                     	addq	%rdi, %rax
     130: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     136: c3                           	retq
     137: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     13b: 48 8b 40 60                  	movq	0x60(%rax), %rax
     13f: ff e0                        	jmpq	*%rax
     141: 31 c0                        	xorl	%eax, %eax
     143: c3                           	retq
