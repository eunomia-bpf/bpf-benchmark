
/workspaces/kprog-raw/perf/current-entry-20261120/trusted_x86.proof.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_tracer_entry>:
       0: 55                           	pushq	%rbp
       1: 41 57                        	pushq	%r15
       3: 41 56                        	pushq	%r14
       5: 41 55                        	pushq	%r13
       7: 41 54                        	pushq	%r12
       9: 53                           	pushq	%rbx
       a: 48 81 ec c8 00 00 00         	subq	$0xc8, %rsp
      11: 48 89 fb                     	movq	%rdi, %rbx
      14: e8 00 00 00 00               	callq	0x19 <native_tracer_entry+0x19>
		0000000000000015:  R_X86_64_PLT32	bpf_get_current_pid_tgid-0x4
      19: 49 89 c7                     	movq	%rax, %r15
      1c: 49 89 c5                     	movq	%rax, %r13
      1f: 49 c1 ed 20                  	shrq	$0x20, %r13
      23: e8 00 00 00 00               	callq	0x28 <native_tracer_entry+0x28>
		0000000000000024:  R_X86_64_PLT32	bpf_ktime_get_ns-0x4
      28: 49 89 c4                     	movq	%rax, %r12
      2b: 4d 85 ed                     	testq	%r13, %r13
      2e: 0f 84 7c 01 00 00            	je	0x1b0 <native_tracer_entry+0x1b0>
      34: c7 44 24 20 00 00 00 00      	movl	$0x0, 0x20(%rsp)
      3c: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x43 <native_tracer_entry+0x43>
		000000000000003f:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
      43: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
      48: e8 00 00 00 00               	callq	0x4d <native_tracer_entry+0x4d>
		0000000000000049:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
      4d: bd ff ff ff ff               	movl	$0xffffffff, %ebp       # imm = 0xFFFFFFFF
      52: 48 85 c0                     	testq	%rax, %rax
      55: 0f 84 26 04 00 00            	je	0x481 <native_tracer_entry+0x481>
      5b: 49 89 c6                     	movq	%rax, %r14
      5e: 48 c7 80 00 0f 00 00 00 00 00 00     	movq	$0x0, 0xf00(%rax)
      69: c6 80 30 0f 00 00 00         	movb	$0x0, 0xf30(%rax)
      70: 48 c7 80 d0 0e 00 00 00 00 00 00     	movq	$0x0, 0xed0(%rax)
      7b: 48 c7 80 d8 0e 00 00 00 00 00 00     	movq	$0x0, 0xed8(%rax)
      86: 48 c7 80 e0 0e 00 00 00 00 00 00     	movq	$0x0, 0xee0(%rax)
      91: b8 ff ff ff ff               	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      96: 49 89 86 28 0f 00 00         	movq	%rax, 0xf28(%r14)
      9d: 41 c7 86 80 13 00 00 00 00 00 00     	movl	$0x0, 0x1380(%r14)
      a8: 66 41 c7 86 84 13 00 00 00 01	movw	$0x100, 0x1384(%r14)    # imm = 0x100
      b2: 49 c7 86 38 0f 00 00 00 00 00 00     	movq	$0x0, 0xf38(%r14)
      bd: 49 c7 86 40 0f 00 00 00 00 00 00     	movq	$0x0, 0xf40(%r14)
      c8: 49 c7 86 58 0f 00 00 00 00 00 00     	movq	$0x0, 0xf58(%r14)
      d3: 49 c7 86 60 0f 00 00 00 00 00 00     	movq	$0x0, 0xf60(%r14)
      de: 49 c7 86 68 0f 00 00 00 00 00 00     	movq	$0x0, 0xf68(%r14)
      e9: 49 c7 86 70 0f 00 00 00 00 00 00     	movq	$0x0, 0xf70(%r14)
      f4: 49 c7 86 78 0f 00 00 00 00 00 00     	movq	$0x0, 0xf78(%r14)
      ff: 49 89 86 bc 02 00 00         	movq	%rax, 0x2bc(%r14)
     106: 49 8d 7e 20                  	leaq	0x20(%r14), %rdi
     10a: ba 9c 02 00 00               	movl	$0x29c, %edx            # imm = 0x29C
     10f: 31 f6                        	xorl	%esi, %esi
     111: e8 04 08 00 00               	callq	0x91a <__native_link_local_memset_zero_668>
     116: 41 c7 86 c4 02 00 00 01 00 00 00     	movl	$0x1, 0x2c4(%r14)
     121: 45 89 2e                     	movl	%r13d, (%r14)
     124: 45 89 7e 04                  	movl	%r15d, 0x4(%r14)
     128: 4d 89 66 08                  	movq	%r12, 0x8(%r14)
     12c: 49 c7 86 c8 02 00 00 00 00 00 00     	movq	$0x0, 0x2c8(%r14)
     137: 49 8d 7e 10                  	leaq	0x10(%r14), %rdi
     13b: be 10 00 00 00               	movl	$0x10, %esi
     140: e8 00 00 00 00               	callq	0x145 <native_tracer_entry+0x145>
		0000000000000141:  R_X86_64_PLT32	bpf_get_current_comm-0x4
     145: 48 85 c0                     	testq	%rax, %rax
     148: 79 21                        	jns	0x16b <native_tracer_entry+0x16b>
     14a: c7 44 24 20 34 00 00 00      	movl	$0x34, 0x20(%rsp)
     152: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x159 <native_tracer_entry+0x159>
		0000000000000155:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     159: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     15e: e8 00 00 00 00               	callq	0x163 <native_tracer_entry+0x163>
		000000000000015f:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     163: 48 85 c0                     	testq	%rax, %rax
     166: 74 03                        	je	0x16b <native_tracer_entry+0x16b>
     168: 48 ff 00                     	incq	(%rax)
     16b: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x172 <native_tracer_entry+0x172>
		000000000000016e:  R_X86_64_REX_GOTPCRELX	kernel_stackmap-0x4
     172: ba 00 04 00 00               	movl	$0x400, %edx            # imm = 0x400
     177: 48 89 df                     	movq	%rbx, %rdi
     17a: e8 00 00 00 00               	callq	0x17f <native_tracer_entry+0x17f>
		000000000000017b:  R_X86_64_PLT32	bpf_get_stackid-0x4
     17f: 41 89 86 bc 02 00 00         	movl	%eax, 0x2bc(%r14)
     186: 48 8b 03                     	movq	(%rbx), %rax
     189: 48 83 b8 a0 00 00 00 2b      	cmpq	$0x2b, 0xa0(%rax)
     191: 0f 85 e6 01 00 00            	jne	0x37d <native_tracer_entry+0x37d>
     197: 48 83 b8 88 00 00 00 23      	cmpq	$0x23, 0x88(%rax)
     19f: 0f 85 f4 02 00 00            	jne	0x499 <native_tracer_entry+0x499>
     1a5: 41 bc b1 0f 00 00            	movl	$0xfb1, %r12d           # imm = 0xFB1
     1ab: e9 32 02 00 00               	jmp	0x3e2 <native_tracer_entry+0x3e2>
     1b0: c7 44 24 20 00 00 00 00      	movl	$0x0, 0x20(%rsp)
     1b8: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x1bf <native_tracer_entry+0x1bf>
		00000000000001bb:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
     1bf: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     1c4: e8 00 00 00 00               	callq	0x1c9 <native_tracer_entry+0x1c9>
		00000000000001c5:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     1c9: 48 85 c0                     	testq	%rax, %rax
     1cc: 0f 84 97 02 00 00            	je	0x469 <native_tracer_entry+0x469>
     1d2: 49 89 c6                     	movq	%rax, %r14
     1d5: 48 c7 80 00 0f 00 00 00 00 00 00     	movq	$0x0, 0xf00(%rax)
     1e0: c6 80 30 0f 00 00 00         	movb	$0x0, 0xf30(%rax)
     1e7: 48 c7 80 d0 0e 00 00 00 00 00 00     	movq	$0x0, 0xed0(%rax)
     1f2: 48 c7 80 d8 0e 00 00 00 00 00 00     	movq	$0x0, 0xed8(%rax)
     1fd: 48 c7 80 e0 0e 00 00 00 00 00 00     	movq	$0x0, 0xee0(%rax)
     208: b8 ff ff ff ff               	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     20d: 49 89 86 28 0f 00 00         	movq	%rax, 0xf28(%r14)
     214: 41 c7 86 80 13 00 00 00 00 00 00     	movl	$0x0, 0x1380(%r14)
     21f: 66 41 c7 86 84 13 00 00 00 01	movw	$0x100, 0x1384(%r14)    # imm = 0x100
     229: 49 c7 86 38 0f 00 00 00 00 00 00     	movq	$0x0, 0xf38(%r14)
     234: 49 c7 86 40 0f 00 00 00 00 00 00     	movq	$0x0, 0xf40(%r14)
     23f: 49 c7 86 58 0f 00 00 00 00 00 00     	movq	$0x0, 0xf58(%r14)
     24a: 49 c7 86 60 0f 00 00 00 00 00 00     	movq	$0x0, 0xf60(%r14)
     255: 49 c7 86 68 0f 00 00 00 00 00 00     	movq	$0x0, 0xf68(%r14)
     260: 49 c7 86 70 0f 00 00 00 00 00 00     	movq	$0x0, 0xf70(%r14)
     26b: 49 c7 86 78 0f 00 00 00 00 00 00     	movq	$0x0, 0xf78(%r14)
     276: 49 89 86 bc 02 00 00         	movq	%rax, 0x2bc(%r14)
     27d: 49 8d 7e 20                  	leaq	0x20(%r14), %rdi
     281: ba 9c 02 00 00               	movl	$0x29c, %edx            # imm = 0x29C
     286: 31 f6                        	xorl	%esi, %esi
     288: e8 8d 06 00 00               	callq	0x91a <__native_link_local_memset_zero_668>
     28d: 41 c7 86 c4 02 00 00 01 00 00 00     	movl	$0x1, 0x2c4(%r14)
     298: 41 c7 06 00 00 00 00         	movl	$0x0, (%r14)
     29f: 45 89 7e 04                  	movl	%r15d, 0x4(%r14)
     2a3: 4d 89 66 08                  	movq	%r12, 0x8(%r14)
     2a7: 49 c7 86 c8 02 00 00 00 00 00 00     	movq	$0x0, 0x2c8(%r14)
     2b2: 4c 89 f7                     	movq	%r14, %rdi
     2b5: 48 83 c7 10                  	addq	$0x10, %rdi
     2b9: be 10 00 00 00               	movl	$0x10, %esi
     2be: e8 00 00 00 00               	callq	0x2c3 <native_tracer_entry+0x2c3>
		00000000000002bf:  R_X86_64_PLT32	bpf_get_current_comm-0x4
     2c3: 48 85 c0                     	testq	%rax, %rax
     2c6: 79 21                        	jns	0x2e9 <native_tracer_entry+0x2e9>
     2c8: c7 44 24 20 34 00 00 00      	movl	$0x34, 0x20(%rsp)
     2d0: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x2d7 <native_tracer_entry+0x2d7>
		00000000000002d3:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     2d7: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     2dc: e8 00 00 00 00               	callq	0x2e1 <native_tracer_entry+0x2e1>
		00000000000002dd:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     2e1: 48 85 c0                     	testq	%rax, %rax
     2e4: 74 03                        	je	0x2e9 <native_tracer_entry+0x2e9>
     2e6: 48 ff 00                     	incq	(%rax)
     2e9: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x2f0 <native_tracer_entry+0x2f0>
		00000000000002ec:  R_X86_64_REX_GOTPCRELX	kernel_stackmap-0x4
     2f0: ba 00 04 00 00               	movl	$0x400, %edx            # imm = 0x400
     2f5: 48 89 df                     	movq	%rbx, %rdi
     2f8: e8 00 00 00 00               	callq	0x2fd <native_tracer_entry+0x2fd>
		00000000000002f9:  R_X86_64_PLT32	bpf_get_stackid-0x4
     2fd: 41 89 86 bc 02 00 00         	movl	%eax, 0x2bc(%r14)
     304: c7 44 24 20 00 00 00 00      	movl	$0x0, 0x20(%rsp)
     30c: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x313 <native_tracer_entry+0x313>
		000000000000030f:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
     313: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     318: e8 00 00 00 00               	callq	0x31d <native_tracer_entry+0x31d>
		0000000000000319:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     31d: 48 85 c0                     	testq	%rax, %rax
     320: 74 4d                        	je	0x36f <native_tracer_entry+0x36f>
     322: 0f b6 88 84 13 00 00         	movzbl	0x1384(%rax), %ecx
     329: 80 f9 1d                     	cmpb	$0x1d, %cl
     32c: 72 39                        	jb	0x367 <native_tracer_entry+0x367>
     32e: 49 89 c6                     	movq	%rax, %r14
     331: c7 80 2c 0f 00 00 05 00 00 00	movl	$0x5, 0xf2c(%rax)
     33b: c7 44 24 20 44 00 00 00      	movl	$0x44, 0x20(%rsp)
     343: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x34a <native_tracer_entry+0x34a>
		0000000000000346:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     34a: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     34f: e8 00 00 00 00               	callq	0x354 <native_tracer_entry+0x354>
		0000000000000350:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     354: 48 85 c0                     	testq	%rax, %rax
     357: 74 03                        	je	0x35c <native_tracer_entry+0x35c>
     359: 48 ff 00                     	incq	(%rax)
     35c: 4c 89 f0                     	movq	%r14, %rax
     35f: 41 0f b6 8e 84 13 00 00      	movzbl	0x1384(%r14), %ecx
     367: fe c1                        	incb	%cl
     369: 88 88 84 13 00 00            	movb	%cl, 0x1384(%rax)
     36f: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x376 <native_tracer_entry+0x376>
		0000000000000372:  R_X86_64_REX_GOTPCRELX	perf_progs-0x4
     376: 31 ed                        	xorl	%ebp, %ebp
     378: e9 fa 00 00 00               	jmp	0x477 <native_tracer_entry+0x477>
     37d: e8 00 00 00 00               	callq	0x382 <native_tracer_entry+0x382>
		000000000000037e:  R_X86_64_PLT32	bpf_get_current_task-0x4
     382: 48 8d 7c 24 20               	leaq	0x20(%rsp), %rdi
     387: be 08 00 00 00               	movl	$0x8, %esi
     38c: 48 89 c2                     	movq	%rax, %rdx
     38f: e8 00 00 00 00               	callq	0x394 <native_tracer_entry+0x394>
		0000000000000390:  R_X86_64_PLT32	bpf_probe_read_kernel-0x4
     394: 48 85 c0                     	testq	%rax, %rax
     397: 75 22                        	jne	0x3bb <native_tracer_entry+0x3bb>
     399: 48 8b 54 24 20               	movq	0x20(%rsp), %rdx
     39e: 48 85 d2                     	testq	%rdx, %rdx
     3a1: 74 18                        	je	0x3bb <native_tracer_entry+0x3bb>
     3a3: 48 8d 7c 24 20               	leaq	0x20(%rsp), %rdi
     3a8: be a8 00 00 00               	movl	$0xa8, %esi
     3ad: e8 00 00 00 00               	callq	0x3b2 <native_tracer_entry+0x3b2>
		00000000000003ae:  R_X86_64_PLT32	bpf_probe_read_kernel-0x4
     3b2: 48 85 c0                     	testq	%rax, %rax
     3b5: 0f 84 4f 02 00 00            	je	0x60a <native_tracer_entry+0x60a>
     3bb: c7 44 24 18 52 00 00 00      	movl	$0x52, 0x18(%rsp)
     3c3: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x3ca <native_tracer_entry+0x3ca>
		00000000000003c6:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     3ca: 48 8d 74 24 18               	leaq	0x18(%rsp), %rsi
     3cf: e8 00 00 00 00               	callq	0x3d4 <native_tracer_entry+0x3d4>
		00000000000003d0:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     3d4: 48 85 c0                     	testq	%rax, %rax
     3d7: 74 03                        	je	0x3dc <native_tracer_entry+0x3dc>
     3d9: 48 ff 00                     	incq	(%rax)
     3dc: 41 bc a9 0f 00 00            	movl	$0xfa9, %r12d           # imm = 0xFA9
     3e2: 45 31 ff                     	xorl	%r15d, %r15d
     3e5: 45 89 a6 2c 0f 00 00         	movl	%r12d, 0xf2c(%r14)
     3ec: c7 44 24 20 00 00 00 00      	movl	$0x0, 0x20(%rsp)
     3f4: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x3fb <native_tracer_entry+0x3fb>
		00000000000003f7:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
     3fb: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     400: e8 00 00 00 00               	callq	0x405 <native_tracer_entry+0x405>
		0000000000000401:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     405: 48 85 c0                     	testq	%rax, %rax
     408: 74 66                        	je	0x470 <native_tracer_entry+0x470>
     40a: 0f b6 88 84 13 00 00         	movzbl	0x1384(%rax), %ecx
     411: 80 f9 1d                     	cmpb	$0x1d, %cl
     414: 72 3c                        	jb	0x452 <native_tracer_entry+0x452>
     416: 49 89 c6                     	movq	%rax, %r14
     419: c7 80 2c 0f 00 00 05 00 00 00	movl	$0x5, 0xf2c(%rax)
     423: c7 44 24 20 44 00 00 00      	movl	$0x44, 0x20(%rsp)
     42b: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x432 <native_tracer_entry+0x432>
		000000000000042e:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     432: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     437: e8 00 00 00 00               	callq	0x43c <native_tracer_entry+0x43c>
		0000000000000438:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     43c: 48 85 c0                     	testq	%rax, %rax
     43f: 74 03                        	je	0x444 <native_tracer_entry+0x444>
     441: 48 ff 00                     	incq	(%rax)
     444: 4c 89 f0                     	movq	%r14, %rax
     447: 41 0f b6 8e 84 13 00 00      	movzbl	0x1384(%r14), %ecx
     44f: 45 31 ff                     	xorl	%r15d, %r15d
     452: fe c1                        	incb	%cl
     454: 88 88 84 13 00 00            	movb	%cl, 0x1384(%rax)
     45a: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x461 <native_tracer_entry+0x461>
		000000000000045d:  R_X86_64_REX_GOTPCRELX	perf_progs-0x4
     461: 48 89 df                     	movq	%rbx, %rdi
     464: 44 89 fa                     	movl	%r15d, %edx
     467: eb 13                        	jmp	0x47c <native_tracer_entry+0x47c>
     469: bd ff ff ff ff               	movl	$0xffffffff, %ebp       # imm = 0xFFFFFFFF
     46e: eb 11                        	jmp	0x481 <native_tracer_entry+0x481>
     470: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x477 <native_tracer_entry+0x477>
		0000000000000473:  R_X86_64_REX_GOTPCRELX	perf_progs-0x4
     477: 48 89 df                     	movq	%rbx, %rdi
     47a: 31 d2                        	xorl	%edx, %edx
     47c: e8 00 00 00 00               	callq	0x481 <native_tracer_entry+0x481>
		000000000000047d:  R_X86_64_PLT32	bpf_tail_call-0x4
     481: 89 e8                        	movl	%ebp, %eax
     483: 48 81 c4 c8 00 00 00         	addq	$0xc8, %rsp
     48a: 5b                           	popq	%rbx
     48b: 41 5c                        	popq	%r12
     48d: 41 5d                        	popq	%r13
     48f: 41 5e                        	popq	%r14
     491: 41 5f                        	popq	%r15
     493: 5d                           	popq	%rbp
     494: e9 b8 04 00 00               	jmp	0x951 <__native_link_local_memset_zero_668+0x37>
     499: 48 8b 80 80 00 00 00         	movq	0x80(%rax), %rax
     4a0: 49 89 86 d0 0e 00 00         	movq	%rax, 0xed0(%r14)
     4a7: 48 8b 03                     	movq	(%rbx), %rax
     4aa: 48 8b 80 98 00 00 00         	movq	0x98(%rax), %rax
     4b1: 49 89 86 d8 0e 00 00         	movq	%rax, 0xed8(%r14)
     4b8: 48 8b 03                     	movq	(%rbx), %rax
     4bb: 48 8b 40 20                  	movq	0x20(%rax), %rax
     4bf: 49 89 86 e0 0e 00 00         	movq	%rax, 0xee0(%r14)
     4c6: 48 8b 03                     	movq	(%rbx), %rax
     4c9: 48 8b 40 50                  	movq	0x50(%rax), %rax
     4cd: 49 89 86 e8 0e 00 00         	movq	%rax, 0xee8(%r14)
     4d4: 48 8b 03                     	movq	(%rbx), %rax
     4d7: 48 8b 40 40                  	movq	0x40(%rax), %rax
     4db: 49 89 86 f0 0e 00 00         	movq	%rax, 0xef0(%r14)
     4e2: 48 8b 03                     	movq	(%rbx), %rax
     4e5: 48 8b 40 30                  	movq	0x30(%rax), %rax
     4e9: 49 89 86 f8 0e 00 00         	movq	%rax, 0xef8(%r14)
     4f0: 48 8b 03                     	movq	(%rbx), %rax
     4f3: 48 8b 40 10                  	movq	0x10(%rax), %rax
     4f7: 49 89 86 00 0f 00 00         	movq	%rax, 0xf00(%r14)
     4fe: 48 8b 03                     	movq	(%rbx), %rax
     501: 48 8b 00                     	movq	(%rax), %rax
     504: 49 89 86 08 0f 00 00         	movq	%rax, 0xf08(%r14)
     50b: 41 c6 86 30 0f 00 00 00      	movb	$0x0, 0xf30(%r14)
     513: c7 44 24 20 60 00 00 00      	movl	$0x60, 0x20(%rsp)
     51b: 44 0f 38 f1 6c 24 24         	movbel	%r13d, 0x24(%rsp)
     522: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
     52b: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x532 <native_tracer_entry+0x532>
		000000000000052e:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
     532: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     537: e8 00 00 00 00               	callq	0x53c <native_tracer_entry+0x53c>
		0000000000000538:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     53c: 48 85 c0                     	testq	%rax, %rax
     53f: 74 38                        	je	0x579 <native_tracer_entry+0x579>
     541: 4c 89 f0                     	movq	%r14, %rax
     544: 48 05 d0 0e 00 00            	addq	$0xed0, %rax            # imm = 0xED0
     54a: 4c 8b 28                     	movq	(%rax), %r13
     54d: 4d 85 ed                     	testq	%r13, %r13
     550: 0f 84 4e 01 00 00            	je	0x6a4 <native_tracer_entry+0x6a4>
     556: 4c 89 e8                     	movq	%r13, %rax
     559: 48 c1 e8 38                  	shrq	$0x38, %rax
     55d: 0f 84 57 01 00 00            	je	0x6ba <native_tracer_entry+0x6ba>
     563: 41 c7 86 28 0f 00 00 0b 00 00 00     	movl	$0xb, 0xf28(%r14)
     56e: 41 bc ab 0f 00 00            	movl	$0xfab, %r12d           # imm = 0xFAB
     574: e9 69 fe ff ff               	jmp	0x3e2 <native_tracer_entry+0x3e2>
     579: 4c 89 7c 24 18               	movq	%r15, 0x18(%rsp)
     57e: 44 89 6c 24 10               	movl	%r13d, 0x10(%rsp)
     583: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x58a <native_tracer_entry+0x58a>
		0000000000000586:  R_X86_64_REX_GOTPCRELX	reported_pids-0x4
     58a: 48 8d 74 24 10               	leaq	0x10(%rsp), %rsi
     58f: e8 00 00 00 00               	callq	0x594 <native_tracer_entry+0x594>
		0000000000000590:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     594: 49 89 c6                     	movq	%rax, %r14
     597: e8 00 00 00 00               	callq	0x59c <native_tracer_entry+0x59c>
		0000000000000598:  R_X86_64_PLT32	bpf_ktime_get_ns-0x4
     59c: 4d 85 f6                     	testq	%r14, %r14
     59f: 0f 84 43 01 00 00            	je	0x6e8 <native_tracer_entry+0x6e8>
     5a5: 49 8b 16                     	movq	(%r14), %rdx
     5a8: 48 89 d1                     	movq	%rdx, %rcx
     5ab: 48 83 e1 e0                  	andq	$-0x20, %rcx
     5af: 48 89 c6                     	movq	%rax, %rsi
     5b2: 48 29 ce                     	subq	%rcx, %rsi
     5b5: 89 d1                        	movl	%edx, %ecx
     5b7: 80 e1 0f                     	andb	$0xf, %cl
     5ba: bf 00 e1 f5 05               	movl	$0x5f5e100, %edi        # imm = 0x5F5E100
     5bf: c4 e2 f1 f7 ff               	shlxq	%rcx, %rdi, %rdi
     5c4: 48 39 fe                     	cmpq	%rdi, %rsi
     5c7: 0f 82 72 01 00 00            	jb	0x73f <native_tracer_entry+0x73f>
     5cd: 89 d1                        	movl	%edx, %ecx
     5cf: 80 e1 10                     	andb	$0x10, %cl
     5d2: 41 b8 ff ff ff ff            	movl	$0xffffffff, %r8d       # imm = 0xFFFFFFFF
     5d8: 4c 01 c7                     	addq	%r8, %rdi
     5db: 48 81 c7 01 f2 05 2a         	addq	$0x2a05f201, %rdi       # imm = 0x2A05F201
     5e2: 48 39 fe                     	cmpq	%rdi, %rsi
     5e5: 0f 83 ff 00 00 00            	jae	0x6ea <native_tracer_entry+0x6ea>
     5eb: 83 e2 0f                     	andl	$0xf, %edx
     5ee: 31 f6                        	xorl	%esi, %esi
     5f0: 84 c9                        	testb	%cl, %cl
     5f2: 40 0f 94 c6                  	sete	%sil
     5f6: 8d 34 b5 04 00 00 00         	leal	0x4(,%rsi,4), %esi
     5fd: 39 f2                        	cmpl	%esi, %edx
     5ff: 80 d2 00                     	adcb	$0x0, %dl
     602: 0f b6 d2                     	movzbl	%dl, %edx
     605: e9 e2 00 00 00               	jmp	0x6ec <native_tracer_entry+0x6ec>
     60a: 48 83 bc 24 c0 00 00 00 2b   	cmpq	$0x2b, 0xc0(%rsp)
     613: 0f 85 c4 00 00 00            	jne	0x6dd <native_tracer_entry+0x6dd>
     619: 48 83 bc 24 a8 00 00 00 23   	cmpq	$0x23, 0xa8(%rsp)
     622: 0f 84 7d fb ff ff            	je	0x1a5 <native_tracer_entry+0x1a5>
     628: 48 8b 84 24 a0 00 00 00      	movq	0xa0(%rsp), %rax
     630: 49 89 86 d0 0e 00 00         	movq	%rax, 0xed0(%r14)
     637: 48 8b 84 24 b8 00 00 00      	movq	0xb8(%rsp), %rax
     63f: 49 89 86 d8 0e 00 00         	movq	%rax, 0xed8(%r14)
     646: 48 8b 44 24 40               	movq	0x40(%rsp), %rax
     64b: 49 89 86 e0 0e 00 00         	movq	%rax, 0xee0(%r14)
     652: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
     657: 49 89 86 e8 0e 00 00         	movq	%rax, 0xee8(%r14)
     65e: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
     663: 49 89 86 f0 0e 00 00         	movq	%rax, 0xef0(%r14)
     66a: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
     66f: 49 89 86 f8 0e 00 00         	movq	%rax, 0xef8(%r14)
     676: 48 8b 44 24 30               	movq	0x30(%rsp), %rax
     67b: 49 89 86 00 0f 00 00         	movq	%rax, 0xf00(%r14)
     682: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
     687: 49 89 86 08 0f 00 00         	movq	%rax, 0xf08(%r14)
     68e: 48 83 bc 24 98 00 00 00 ff   	cmpq	$-0x1, 0x98(%rsp)
     697: 41 0f 95 86 30 0f 00 00      	setne	0xf30(%r14)
     69f: e9 6f fe ff ff               	jmp	0x513 <native_tracer_entry+0x513>
     6a4: 41 c7 86 28 0f 00 00 01 00 00 00     	movl	$0x1, 0xf28(%r14)
     6af: 41 bc ad 0f 00 00            	movl	$0xfad, %r12d           # imm = 0xFAD
     6b5: e9 28 fd ff ff               	jmp	0x3e2 <native_tracer_entry+0x3e2>
     6ba: 49 81 fd ff 0f 00 00         	cmpq	$0xfff, %r13            # imm = 0xFFF
     6c1: 0f 87 7f 00 00 00            	ja	0x746 <native_tracer_entry+0x746>
     6c7: 41 c7 86 28 0f 00 00 31 00 00 00     	movl	$0x31, 0xf28(%r14)
     6d2: 41 bc ae 0f 00 00            	movl	$0xfae, %r12d           # imm = 0xFAE
     6d8: e9 05 fd ff ff               	jmp	0x3e2 <native_tracer_entry+0x3e2>
     6dd: 45 31 ff                     	xorl	%r15d, %r15d
     6e0: 45 31 e4                     	xorl	%r12d, %r12d
     6e3: e9 fd fc ff ff               	jmp	0x3e5 <native_tracer_entry+0x3e5>
     6e8: 31 c9                        	xorl	%ecx, %ecx
     6ea: 31 d2                        	xorl	%edx, %edx
     6ec: 48 83 e0 e0                  	andq	$-0x20, %rax
     6f0: 0f b6 c9                     	movzbl	%cl, %ecx
     6f3: 48 09 c1                     	orq	%rax, %rcx
     6f6: 48 09 d1                     	orq	%rdx, %rcx
     6f9: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
     6fe: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x705 <native_tracer_entry+0x705>
		0000000000000701:  R_X86_64_REX_GOTPCRELX	reported_pids-0x4
     705: 48 8d 74 24 10               	leaq	0x10(%rsp), %rsi
     70a: 48 8d 54 24 20               	leaq	0x20(%rsp), %rdx
     70f: 31 c9                        	xorl	%ecx, %ecx
     711: e8 00 00 00 00               	callq	0x716 <native_tracer_entry+0x716>
		0000000000000712:  R_X86_64_PLT32	bpf_map_update_elem-0x4
     716: 85 c0                        	testl	%eax, %eax
     718: 0f 84 1c 01 00 00            	je	0x83a <native_tracer_entry+0x83a>
     71e: c7 44 24 14 3d 00 00 00      	movl	$0x3d, 0x14(%rsp)
     726: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x72d <native_tracer_entry+0x72d>
		0000000000000729:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     72d: 48 8d 74 24 14               	leaq	0x14(%rsp), %rsi
     732: e8 00 00 00 00               	callq	0x737 <native_tracer_entry+0x737>
		0000000000000733:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     737: 48 85 c0                     	testq	%rax, %rax
     73a: 74 03                        	je	0x73f <native_tracer_entry+0x73f>
     73c: 48 ff 00                     	incq	(%rax)
     73f: 31 ed                        	xorl	%ebp, %ebp
     741: e9 3b fd ff ff               	jmp	0x481 <native_tracer_entry+0x481>
     746: 41 8b 06                     	movl	(%r14), %eax
     749: c7 44 24 20 60 00 00 00      	movl	$0x60, 0x20(%rsp)
     751: 0f 38 f1 44 24 24            	movbel	%eax, 0x24(%rsp)
     757: 4c 0f 38 f1 6c 24 28         	movbeq	%r13, 0x28(%rsp)
     75e: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x765 <native_tracer_entry+0x765>
		0000000000000761:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
     765: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     76a: e8 00 00 00 00               	callq	0x76f <native_tracer_entry+0x76f>
		000000000000076b:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     76f: 48 85 c0                     	testq	%rax, %rax
     772: 0f 84 f0 00 00 00            	je	0x868 <native_tracer_entry+0x868>
     778: 48 b9 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
     782: 4c 8b 78 08                  	movq	0x8(%rax), %r15
     786: 4c 21 f9                     	andq	%r15, %rcx
     789: 49 89 8e 20 0f 00 00         	movq	%rcx, 0xf20(%r14)
     790: 48 8b 00                     	movq	(%rax), %rax
     793: 49 89 86 10 0f 00 00         	movq	%rax, 0xf10(%r14)
     79a: 49 c1 ef 38                  	shrq	$0x38, %r15
     79e: 49 29 cd                     	subq	%rcx, %r13
     7a1: 4d 89 ae 18 0f 00 00         	movq	%r13, 0xf18(%r14)
     7a8: 45 31 e4                     	xorl	%r12d, %r12d
     7ab: 49 83 ff 01                  	cmpq	$0x1, %r15
     7af: 0f 85 30 fc ff ff            	jne	0x3e5 <native_tracer_entry+0x3e5>
     7b5: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
     7ba: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x7c1 <native_tracer_entry+0x7c1>
		00000000000007bd:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
     7c1: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     7c6: e8 00 00 00 00               	callq	0x7cb <native_tracer_entry+0x7cb>
		00000000000007c7:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     7cb: 41 bf 01 00 00 00            	movl	$0x1, %r15d
     7d1: 48 85 c0                     	testq	%rax, %rax
     7d4: 0f 84 0b fc ff ff            	je	0x3e5 <native_tracer_entry+0x3e5>
     7da: 4c 39 28                     	cmpq	%r13, (%rax)
     7dd: 77 06                        	ja	0x7e5 <native_tracer_entry+0x7e5>
     7df: 4c 39 68 08                  	cmpq	%r13, 0x8(%rax)
     7e3: 73 14                        	jae	0x7f9 <native_tracer_entry+0x7f9>
     7e5: 4c 39 68 10                  	cmpq	%r13, 0x10(%rax)
     7e9: 0f 87 f6 fb ff ff            	ja	0x3e5 <native_tracer_entry+0x3e5>
     7ef: 4c 39 68 18                  	cmpq	%r13, 0x18(%rax)
     7f3: 0f 82 ec fb ff ff            	jb	0x3e5 <native_tracer_entry+0x3e5>
     7f9: 41 8b 8e 80 13 00 00         	movl	0x1380(%r14), %ecx
     800: 8b 50 20                     	movl	0x20(%rax), %edx
     803: 0f a3 d1                     	btl	%edx, %ecx
     806: 0f 82 d9 fb ff ff            	jb	0x3e5 <native_tracer_entry+0x3e5>
     80c: 49 89 c7                     	movq	%rax, %r15
     80f: c7 44 24 18 00 00 00 00      	movl	$0x0, 0x18(%rsp)
     817: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x81e <native_tracer_entry+0x81e>
		000000000000081a:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     81e: 48 8d 74 24 18               	leaq	0x18(%rsp), %rsi
     823: e8 00 00 00 00               	callq	0x828 <native_tracer_entry+0x828>
		0000000000000824:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     828: 48 85 c0                     	testq	%rax, %rax
     82b: 74 03                        	je	0x830 <native_tracer_entry+0x830>
     82d: 48 ff 00                     	incq	(%rax)
     830: 45 0f b7 7f 20               	movzwl	0x20(%r15), %r15d
     835: e9 ab fb ff ff               	jmp	0x3e5 <native_tracer_entry+0x3e5>
     83a: c6 44 24 0f 01               	movb	$0x1, 0xf(%rsp)
     83f: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x846 <native_tracer_entry+0x846>
		0000000000000842:  R_X86_64_REX_GOTPCRELX	pid_events-0x4
     846: 48 8d 74 24 18               	leaq	0x18(%rsp), %rsi
     84b: 48 8d 54 24 0f               	leaq	0xf(%rsp), %rdx
     850: 31 c9                        	xorl	%ecx, %ecx
     852: e8 00 00 00 00               	callq	0x857 <native_tracer_entry+0x857>
		0000000000000853:  R_X86_64_PLT32	bpf_map_update_elem-0x4
     857: 85 c0                        	testl	%eax, %eax
     859: 74 23                        	je	0x87e <native_tracer_entry+0x87e>
     85b: c7 44 24 20 3e 00 00 00      	movl	$0x3e, 0x20(%rsp)
     863: e9 93 00 00 00               	jmp	0x8fb <native_tracer_entry+0x8fb>
     868: 41 c7 86 28 0f 00 00 0c 00 00 00     	movl	$0xc, 0xf28(%r14)
     873: 41 bc ac 0f 00 00            	movl	$0xfac, %r12d           # imm = 0xFAC
     879: e9 64 fb ff ff               	jmp	0x3e2 <native_tracer_entry+0x3e2>
     87e: c7 44 24 14 01 00 00 00      	movl	$0x1, 0x14(%rsp)
     886: c6 44 24 10 01               	movb	$0x1, 0x10(%rsp)
     88b: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x892 <native_tracer_entry+0x892>
		000000000000088e:  R_X86_64_REX_GOTPCRELX	inhibit_events-0x4
     892: 48 8d 74 24 14               	leaq	0x14(%rsp), %rsi
     897: 48 8d 54 24 10               	leaq	0x10(%rsp), %rdx
     89c: b9 01 00 00 00               	movl	$0x1, %ecx
     8a1: e8 00 00 00 00               	callq	0x8a6 <native_tracer_entry+0x8a6>
		00000000000008a2:  R_X86_64_PLT32	bpf_map_update_elem-0x4
     8a6: 48 85 c0                     	testq	%rax, %rax
     8a9: 78 48                        	js	0x8f3 <native_tracer_entry+0x8f3>
     8ab: c7 44 24 20 42 00 00 00      	movl	$0x42, 0x20(%rsp)
     8b3: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x8ba <native_tracer_entry+0x8ba>
		00000000000008b6:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     8ba: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     8bf: e8 00 00 00 00               	callq	0x8c4 <native_tracer_entry+0x8c4>
		00000000000008c0:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     8c4: 48 85 c0                     	testq	%rax, %rax
     8c7: 74 03                        	je	0x8cc <native_tracer_entry+0x8cc>
     8c9: 48 ff 00                     	incq	(%rax)
     8cc: c7 44 24 20 01 00 00 00      	movl	$0x1, 0x20(%rsp)
     8d4: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x8db <native_tracer_entry+0x8db>
		00000000000008d7:  R_X86_64_REX_GOTPCRELX	report_events-0x4
     8db: 48 8d 4c 24 20               	leaq	0x20(%rsp), %rcx
     8e0: ba ff ff ff ff               	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     8e5: 41 b8 04 00 00 00            	movl	$0x4, %r8d
     8eb: 48 89 df                     	movq	%rbx, %rdi
     8ee: e8 00 00 00 00               	callq	0x8f3 <native_tracer_entry+0x8f3>
		00000000000008ef:  R_X86_64_PLT32	bpf_perf_event_output-0x4
     8f3: c7 44 24 20 3f 00 00 00      	movl	$0x3f, 0x20(%rsp)
     8fb: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x902 <native_tracer_entry+0x902>
		00000000000008fe:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     902: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     907: e8 00 00 00 00               	callq	0x90c <native_tracer_entry+0x90c>
		0000000000000908:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     90c: 48 85 c0                     	testq	%rax, %rax
     90f: 0f 85 27 fe ff ff            	jne	0x73c <native_tracer_entry+0x73c>
     915: e9 25 fe ff ff               	jmp	0x73f <native_tracer_entry+0x73f>
