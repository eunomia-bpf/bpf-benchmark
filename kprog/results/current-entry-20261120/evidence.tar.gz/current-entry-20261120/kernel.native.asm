
/workspaces/kprog-raw/perf/current-entry-20261120/kernel.native.o:	file format elf64-x86-64

Disassembly of section perf_event/native_tracer_entry:

0000000000000000 <native_tracer_entry>:
       0: 55                           	pushq	%rbp
       1: 41 57                        	pushq	%r15
       3: 41 56                        	pushq	%r14
       5: 41 55                        	pushq	%r13
       7: 41 54                        	pushq	%r12
       9: 53                           	pushq	%rbx
       a: 48 81 ec c8 00 00 00         	subq	$0xc8, %rsp
      11: 48 89 fb                     	movq	%rdi, %rbx
      14: e8 00 00 00 00               	callq	0x19 <native_tracer_entry+0x19>
		0000000000000015:  R_X86_64_PLT32	bpf_get_current_pid_tgid-0x4
      19: 49 89 c7                     	movq	%rax, %r15
      1c: 49 89 c5                     	movq	%rax, %r13
      1f: 49 c1 ed 20                  	shrq	$0x20, %r13
      23: e8 00 00 00 00               	callq	0x28 <native_tracer_entry+0x28>
		0000000000000024:  R_X86_64_PLT32	bpf_ktime_get_ns-0x4
      28: 49 89 c4                     	movq	%rax, %r12
      2b: 4d 85 ed                     	testq	%r13, %r13
      2e: 0f 84 7c 01 00 00            	je	0x1b0 <native_tracer_entry+0x1b0>
      34: c7 44 24 20 00 00 00 00      	movl	$0x0, 0x20(%rsp)
      3c: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x43 <native_tracer_entry+0x43>
		000000000000003f:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
      43: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
      48: e8 00 00 00 00               	callq	0x4d <native_tracer_entry+0x4d>
		0000000000000049:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
      4d: bd ff ff ff ff               	movl	$0xffffffff, %ebp       # imm = 0xFFFFFFFF
      52: 48 85 c0                     	testq	%rax, %rax
      55: 0f 84 26 04 00 00            	je	0x481 <native_tracer_entry+0x481>
      5b: 49 89 c6                     	movq	%rax, %r14
      5e: 48 c7 80 00 0f 00 00 00 00 00 00     	movq	$0x0, 0xf00(%rax)
      69: c6 80 30 0f 00 00 00         	movb	$0x0, 0xf30(%rax)
      70: 48 c7 80 d0 0e 00 00 00 00 00 00     	movq	$0x0, 0xed0(%rax)
      7b: 48 c7 80 d8 0e 00 00 00 00 00 00     	movq	$0x0, 0xed8(%rax)
      86: 48 c7 80 e0 0e 00 00 00 00 00 00     	movq	$0x0, 0xee0(%rax)
      91: b8 ff ff ff ff               	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      96: 49 89 86 28 0f 00 00         	movq	%rax, 0xf28(%r14)
      9d: 41 c7 86 80 13 00 00 00 00 00 00     	movl	$0x0, 0x1380(%r14)
      a8: 66 41 c7 86 84 13 00 00 00 01	movw	$0x100, 0x1384(%r14)    # imm = 0x100
      b2: 49 c7 86 38 0f 00 00 00 00 00 00     	movq	$0x0, 0xf38(%r14)
      bd: 49 c7 86 40 0f 00 00 00 00 00 00     	movq	$0x0, 0xf40(%r14)
      c8: 49 c7 86 58 0f 00 00 00 00 00 00     	movq	$0x0, 0xf58(%r14)
      d3: 49 c7 86 60 0f 00 00 00 00 00 00     	movq	$0x0, 0xf60(%r14)
      de: 49 c7 86 68 0f 00 00 00 00 00 00     	movq	$0x0, 0xf68(%r14)
      e9: 49 c7 86 70 0f 00 00 00 00 00 00     	movq	$0x0, 0xf70(%r14)
      f4: 49 c7 86 78 0f 00 00 00 00 00 00     	movq	$0x0, 0xf78(%r14)
      ff: 49 89 86 bc 02 00 00         	movq	%rax, 0x2bc(%r14)
     106: 49 8d 7e 20                  	leaq	0x20(%r14), %rdi
     10a: ba 9c 02 00 00               	movl	$0x29c, %edx            # imm = 0x29C
     10f: 31 f6                        	xorl	%esi, %esi
     111: e8 00 00 00 00               	callq	0x116 <native_tracer_entry+0x116>
		0000000000000112:  R_X86_64_PLT32	memset-0x4
     116: 41 c7 86 c4 02 00 00 01 00 00 00     	movl	$0x1, 0x2c4(%r14)
     121: 45 89 2e                     	movl	%r13d, (%r14)
     124: 45 89 7e 04                  	movl	%r15d, 0x4(%r14)
     128: 4d 89 66 08                  	movq	%r12, 0x8(%r14)
     12c: 49 c7 86 c8 02 00 00 00 00 00 00     	movq	$0x0, 0x2c8(%r14)
     137: 49 8d 7e 10                  	leaq	0x10(%r14), %rdi
     13b: be 10 00 00 00               	movl	$0x10, %esi
     140: e8 00 00 00 00               	callq	0x145 <native_tracer_entry+0x145>
		0000000000000141:  R_X86_64_PLT32	bpf_get_current_comm-0x4
     145: 48 85 c0                     	testq	%rax, %rax
     148: 79 21                        	jns	0x16b <native_tracer_entry+0x16b>
     14a: c7 44 24 20 34 00 00 00      	movl	$0x34, 0x20(%rsp)
     152: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x159 <native_tracer_entry+0x159>
		0000000000000155:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     159: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     15e: e8 00 00 00 00               	callq	0x163 <native_tracer_entry+0x163>
		000000000000015f:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     163: 48 85 c0                     	testq	%rax, %rax
     166: 74 03                        	je	0x16b <native_tracer_entry+0x16b>
     168: 48 ff 00                     	incq	(%rax)
     16b: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x172 <native_tracer_entry+0x172>
		000000000000016e:  R_X86_64_REX_GOTPCRELX	kernel_stackmap-0x4
     172: ba 00 04 00 00               	movl	$0x400, %edx            # imm = 0x400
     177: 48 89 df                     	movq	%rbx, %rdi
     17a: e8 00 00 00 00               	callq	0x17f <native_tracer_entry+0x17f>
		000000000000017b:  R_X86_64_PLT32	bpf_get_stackid-0x4
     17f: 41 89 86 bc 02 00 00         	movl	%eax, 0x2bc(%r14)
     186: 48 8b 03                     	movq	(%rbx), %rax
     189: 48 83 b8 a0 00 00 00 2b      	cmpq	$0x2b, 0xa0(%rax)
     191: 0f 85 e6 01 00 00            	jne	0x37d <native_tracer_entry+0x37d>
     197: 48 83 b8 88 00 00 00 23      	cmpq	$0x23, 0x88(%rax)
     19f: 0f 85 f0 02 00 00            	jne	0x495 <native_tracer_entry+0x495>
     1a5: 41 bc b1 0f 00 00            	movl	$0xfb1, %r12d           # imm = 0xFB1
     1ab: e9 32 02 00 00               	jmp	0x3e2 <native_tracer_entry+0x3e2>
     1b0: c7 44 24 20 00 00 00 00      	movl	$0x0, 0x20(%rsp)
     1b8: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x1bf <native_tracer_entry+0x1bf>
		00000000000001bb:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
     1bf: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     1c4: e8 00 00 00 00               	callq	0x1c9 <native_tracer_entry+0x1c9>
		00000000000001c5:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     1c9: 48 85 c0                     	testq	%rax, %rax
     1cc: 0f 84 97 02 00 00            	je	0x469 <native_tracer_entry+0x469>
     1d2: 49 89 c6                     	movq	%rax, %r14
     1d5: 48 c7 80 00 0f 00 00 00 00 00 00     	movq	$0x0, 0xf00(%rax)
     1e0: c6 80 30 0f 00 00 00         	movb	$0x0, 0xf30(%rax)
     1e7: 48 c7 80 d0 0e 00 00 00 00 00 00     	movq	$0x0, 0xed0(%rax)
     1f2: 48 c7 80 d8 0e 00 00 00 00 00 00     	movq	$0x0, 0xed8(%rax)
     1fd: 48 c7 80 e0 0e 00 00 00 00 00 00     	movq	$0x0, 0xee0(%rax)
     208: b8 ff ff ff ff               	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     20d: 49 89 86 28 0f 00 00         	movq	%rax, 0xf28(%r14)
     214: 41 c7 86 80 13 00 00 00 00 00 00     	movl	$0x0, 0x1380(%r14)
     21f: 66 41 c7 86 84 13 00 00 00 01	movw	$0x100, 0x1384(%r14)    # imm = 0x100
     229: 49 c7 86 38 0f 00 00 00 00 00 00     	movq	$0x0, 0xf38(%r14)
     234: 49 c7 86 40 0f 00 00 00 00 00 00     	movq	$0x0, 0xf40(%r14)
     23f: 49 c7 86 58 0f 00 00 00 00 00 00     	movq	$0x0, 0xf58(%r14)
     24a: 49 c7 86 60 0f 00 00 00 00 00 00     	movq	$0x0, 0xf60(%r14)
     255: 49 c7 86 68 0f 00 00 00 00 00 00     	movq	$0x0, 0xf68(%r14)
     260: 49 c7 86 70 0f 00 00 00 00 00 00     	movq	$0x0, 0xf70(%r14)
     26b: 49 c7 86 78 0f 00 00 00 00 00 00     	movq	$0x0, 0xf78(%r14)
     276: 49 89 86 bc 02 00 00         	movq	%rax, 0x2bc(%r14)
     27d: 49 8d 7e 20                  	leaq	0x20(%r14), %rdi
     281: ba 9c 02 00 00               	movl	$0x29c, %edx            # imm = 0x29C
     286: 31 f6                        	xorl	%esi, %esi
     288: e8 00 00 00 00               	callq	0x28d <native_tracer_entry+0x28d>
		0000000000000289:  R_X86_64_PLT32	memset-0x4
     28d: 41 c7 86 c4 02 00 00 01 00 00 00     	movl	$0x1, 0x2c4(%r14)
     298: 41 c7 06 00 00 00 00         	movl	$0x0, (%r14)
     29f: 45 89 7e 04                  	movl	%r15d, 0x4(%r14)
     2a3: 4d 89 66 08                  	movq	%r12, 0x8(%r14)
     2a7: 49 c7 86 c8 02 00 00 00 00 00 00     	movq	$0x0, 0x2c8(%r14)
     2b2: 4c 89 f7                     	movq	%r14, %rdi
     2b5: 48 83 c7 10                  	addq	$0x10, %rdi
     2b9: be 10 00 00 00               	movl	$0x10, %esi
     2be: e8 00 00 00 00               	callq	0x2c3 <native_tracer_entry+0x2c3>
		00000000000002bf:  R_X86_64_PLT32	bpf_get_current_comm-0x4
     2c3: 48 85 c0                     	testq	%rax, %rax
     2c6: 79 21                        	jns	0x2e9 <native_tracer_entry+0x2e9>
     2c8: c7 44 24 20 34 00 00 00      	movl	$0x34, 0x20(%rsp)
     2d0: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x2d7 <native_tracer_entry+0x2d7>
		00000000000002d3:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     2d7: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     2dc: e8 00 00 00 00               	callq	0x2e1 <native_tracer_entry+0x2e1>
		00000000000002dd:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     2e1: 48 85 c0                     	testq	%rax, %rax
     2e4: 74 03                        	je	0x2e9 <native_tracer_entry+0x2e9>
     2e6: 48 ff 00                     	incq	(%rax)
     2e9: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x2f0 <native_tracer_entry+0x2f0>
		00000000000002ec:  R_X86_64_REX_GOTPCRELX	kernel_stackmap-0x4
     2f0: ba 00 04 00 00               	movl	$0x400, %edx            # imm = 0x400
     2f5: 48 89 df                     	movq	%rbx, %rdi
     2f8: e8 00 00 00 00               	callq	0x2fd <native_tracer_entry+0x2fd>
		00000000000002f9:  R_X86_64_PLT32	bpf_get_stackid-0x4
     2fd: 41 89 86 bc 02 00 00         	movl	%eax, 0x2bc(%r14)
     304: c7 44 24 20 00 00 00 00      	movl	$0x0, 0x20(%rsp)
     30c: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x313 <native_tracer_entry+0x313>
		000000000000030f:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
     313: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     318: e8 00 00 00 00               	callq	0x31d <native_tracer_entry+0x31d>
		0000000000000319:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     31d: 48 85 c0                     	testq	%rax, %rax
     320: 74 4d                        	je	0x36f <native_tracer_entry+0x36f>
     322: 0f b6 88 84 13 00 00         	movzbl	0x1384(%rax), %ecx
     329: 80 f9 1d                     	cmpb	$0x1d, %cl
     32c: 72 39                        	jb	0x367 <native_tracer_entry+0x367>
     32e: 49 89 c6                     	movq	%rax, %r14
     331: c7 80 2c 0f 00 00 05 00 00 00	movl	$0x5, 0xf2c(%rax)
     33b: c7 44 24 20 44 00 00 00      	movl	$0x44, 0x20(%rsp)
     343: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x34a <native_tracer_entry+0x34a>
		0000000000000346:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     34a: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     34f: e8 00 00 00 00               	callq	0x354 <native_tracer_entry+0x354>
		0000000000000350:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     354: 48 85 c0                     	testq	%rax, %rax
     357: 74 03                        	je	0x35c <native_tracer_entry+0x35c>
     359: 48 ff 00                     	incq	(%rax)
     35c: 4c 89 f0                     	movq	%r14, %rax
     35f: 41 0f b6 8e 84 13 00 00      	movzbl	0x1384(%r14), %ecx
     367: fe c1                        	incb	%cl
     369: 88 88 84 13 00 00            	movb	%cl, 0x1384(%rax)
     36f: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x376 <native_tracer_entry+0x376>
		0000000000000372:  R_X86_64_REX_GOTPCRELX	perf_progs-0x4
     376: 31 ed                        	xorl	%ebp, %ebp
     378: e9 fa 00 00 00               	jmp	0x477 <native_tracer_entry+0x477>
     37d: e8 00 00 00 00               	callq	0x382 <native_tracer_entry+0x382>
		000000000000037e:  R_X86_64_PLT32	bpf_get_current_task-0x4
     382: 48 8d 7c 24 20               	leaq	0x20(%rsp), %rdi
     387: be 08 00 00 00               	movl	$0x8, %esi
     38c: 48 89 c2                     	movq	%rax, %rdx
     38f: e8 00 00 00 00               	callq	0x394 <native_tracer_entry+0x394>
		0000000000000390:  R_X86_64_PLT32	bpf_probe_read_kernel-0x4
     394: 48 85 c0                     	testq	%rax, %rax
     397: 75 22                        	jne	0x3bb <native_tracer_entry+0x3bb>
     399: 48 8b 54 24 20               	movq	0x20(%rsp), %rdx
     39e: 48 85 d2                     	testq	%rdx, %rdx
     3a1: 74 18                        	je	0x3bb <native_tracer_entry+0x3bb>
     3a3: 48 8d 7c 24 20               	leaq	0x20(%rsp), %rdi
     3a8: be a8 00 00 00               	movl	$0xa8, %esi
     3ad: e8 00 00 00 00               	callq	0x3b2 <native_tracer_entry+0x3b2>
		00000000000003ae:  R_X86_64_PLT32	bpf_probe_read_kernel-0x4
     3b2: 48 85 c0                     	testq	%rax, %rax
     3b5: 0f 84 4b 02 00 00            	je	0x606 <native_tracer_entry+0x606>
     3bb: c7 44 24 18 52 00 00 00      	movl	$0x52, 0x18(%rsp)
     3c3: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x3ca <native_tracer_entry+0x3ca>
		00000000000003c6:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     3ca: 48 8d 74 24 18               	leaq	0x18(%rsp), %rsi
     3cf: e8 00 00 00 00               	callq	0x3d4 <native_tracer_entry+0x3d4>
		00000000000003d0:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     3d4: 48 85 c0                     	testq	%rax, %rax
     3d7: 74 03                        	je	0x3dc <native_tracer_entry+0x3dc>
     3d9: 48 ff 00                     	incq	(%rax)
     3dc: 41 bc a9 0f 00 00            	movl	$0xfa9, %r12d           # imm = 0xFA9
     3e2: 45 31 ff                     	xorl	%r15d, %r15d
     3e5: 45 89 a6 2c 0f 00 00         	movl	%r12d, 0xf2c(%r14)
     3ec: c7 44 24 20 00 00 00 00      	movl	$0x0, 0x20(%rsp)
     3f4: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x3fb <native_tracer_entry+0x3fb>
		00000000000003f7:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
     3fb: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     400: e8 00 00 00 00               	callq	0x405 <native_tracer_entry+0x405>
		0000000000000401:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     405: 48 85 c0                     	testq	%rax, %rax
     408: 74 66                        	je	0x470 <native_tracer_entry+0x470>
     40a: 0f b6 88 84 13 00 00         	movzbl	0x1384(%rax), %ecx
     411: 80 f9 1d                     	cmpb	$0x1d, %cl
     414: 72 3c                        	jb	0x452 <native_tracer_entry+0x452>
     416: 49 89 c6                     	movq	%rax, %r14
     419: c7 80 2c 0f 00 00 05 00 00 00	movl	$0x5, 0xf2c(%rax)
     423: c7 44 24 20 44 00 00 00      	movl	$0x44, 0x20(%rsp)
     42b: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x432 <native_tracer_entry+0x432>
		000000000000042e:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     432: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     437: e8 00 00 00 00               	callq	0x43c <native_tracer_entry+0x43c>
		0000000000000438:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     43c: 48 85 c0                     	testq	%rax, %rax
     43f: 74 03                        	je	0x444 <native_tracer_entry+0x444>
     441: 48 ff 00                     	incq	(%rax)
     444: 4c 89 f0                     	movq	%r14, %rax
     447: 41 0f b6 8e 84 13 00 00      	movzbl	0x1384(%r14), %ecx
     44f: 45 31 ff                     	xorl	%r15d, %r15d
     452: fe c1                        	incb	%cl
     454: 88 88 84 13 00 00            	movb	%cl, 0x1384(%rax)
     45a: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x461 <native_tracer_entry+0x461>
		000000000000045d:  R_X86_64_REX_GOTPCRELX	perf_progs-0x4
     461: 48 89 df                     	movq	%rbx, %rdi
     464: 44 89 fa                     	movl	%r15d, %edx
     467: eb 13                        	jmp	0x47c <native_tracer_entry+0x47c>
     469: bd ff ff ff ff               	movl	$0xffffffff, %ebp       # imm = 0xFFFFFFFF
     46e: eb 11                        	jmp	0x481 <native_tracer_entry+0x481>
     470: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x477 <native_tracer_entry+0x477>
		0000000000000473:  R_X86_64_REX_GOTPCRELX	perf_progs-0x4
     477: 48 89 df                     	movq	%rbx, %rdi
     47a: 31 d2                        	xorl	%edx, %edx
     47c: e8 00 00 00 00               	callq	0x481 <native_tracer_entry+0x481>
		000000000000047d:  R_X86_64_PLT32	bpf_tail_call-0x4
     481: 89 e8                        	movl	%ebp, %eax
     483: 48 81 c4 c8 00 00 00         	addq	$0xc8, %rsp
     48a: 5b                           	popq	%rbx
     48b: 41 5c                        	popq	%r12
     48d: 41 5d                        	popq	%r13
     48f: 41 5e                        	popq	%r14
     491: 41 5f                        	popq	%r15
     493: 5d                           	popq	%rbp
     494: c3                           	retq
     495: 48 8b 80 80 00 00 00         	movq	0x80(%rax), %rax
     49c: 49 89 86 d0 0e 00 00         	movq	%rax, 0xed0(%r14)
     4a3: 48 8b 03                     	movq	(%rbx), %rax
     4a6: 48 8b 80 98 00 00 00         	movq	0x98(%rax), %rax
     4ad: 49 89 86 d8 0e 00 00         	movq	%rax, 0xed8(%r14)
     4b4: 48 8b 03                     	movq	(%rbx), %rax
     4b7: 48 8b 40 20                  	movq	0x20(%rax), %rax
     4bb: 49 89 86 e0 0e 00 00         	movq	%rax, 0xee0(%r14)
     4c2: 48 8b 03                     	movq	(%rbx), %rax
     4c5: 48 8b 40 50                  	movq	0x50(%rax), %rax
     4c9: 49 89 86 e8 0e 00 00         	movq	%rax, 0xee8(%r14)
     4d0: 48 8b 03                     	movq	(%rbx), %rax
     4d3: 48 8b 40 40                  	movq	0x40(%rax), %rax
     4d7: 49 89 86 f0 0e 00 00         	movq	%rax, 0xef0(%r14)
     4de: 48 8b 03                     	movq	(%rbx), %rax
     4e1: 48 8b 40 30                  	movq	0x30(%rax), %rax
     4e5: 49 89 86 f8 0e 00 00         	movq	%rax, 0xef8(%r14)
     4ec: 48 8b 03                     	movq	(%rbx), %rax
     4ef: 48 8b 40 10                  	movq	0x10(%rax), %rax
     4f3: 49 89 86 00 0f 00 00         	movq	%rax, 0xf00(%r14)
     4fa: 48 8b 03                     	movq	(%rbx), %rax
     4fd: 48 8b 00                     	movq	(%rax), %rax
     500: 49 89 86 08 0f 00 00         	movq	%rax, 0xf08(%r14)
     507: 41 c6 86 30 0f 00 00 00      	movb	$0x0, 0xf30(%r14)
     50f: c7 44 24 20 60 00 00 00      	movl	$0x60, 0x20(%rsp)
     517: 44 0f 38 f1 6c 24 24         	movbel	%r13d, 0x24(%rsp)
     51e: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
     527: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x52e <native_tracer_entry+0x52e>
		000000000000052a:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
     52e: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     533: e8 00 00 00 00               	callq	0x538 <native_tracer_entry+0x538>
		0000000000000534:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     538: 48 85 c0                     	testq	%rax, %rax
     53b: 74 38                        	je	0x575 <native_tracer_entry+0x575>
     53d: 4c 89 f0                     	movq	%r14, %rax
     540: 48 05 d0 0e 00 00            	addq	$0xed0, %rax            # imm = 0xED0
     546: 4c 8b 28                     	movq	(%rax), %r13
     549: 4d 85 ed                     	testq	%r13, %r13
     54c: 0f 84 4e 01 00 00            	je	0x6a0 <native_tracer_entry+0x6a0>
     552: 4c 89 e8                     	movq	%r13, %rax
     555: 48 c1 e8 38                  	shrq	$0x38, %rax
     559: 0f 84 57 01 00 00            	je	0x6b6 <native_tracer_entry+0x6b6>
     55f: 41 c7 86 28 0f 00 00 0b 00 00 00     	movl	$0xb, 0xf28(%r14)
     56a: 41 bc ab 0f 00 00            	movl	$0xfab, %r12d           # imm = 0xFAB
     570: e9 6d fe ff ff               	jmp	0x3e2 <native_tracer_entry+0x3e2>
     575: 4c 89 7c 24 18               	movq	%r15, 0x18(%rsp)
     57a: 44 89 6c 24 10               	movl	%r13d, 0x10(%rsp)
     57f: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x586 <native_tracer_entry+0x586>
		0000000000000582:  R_X86_64_REX_GOTPCRELX	reported_pids-0x4
     586: 48 8d 74 24 10               	leaq	0x10(%rsp), %rsi
     58b: e8 00 00 00 00               	callq	0x590 <native_tracer_entry+0x590>
		000000000000058c:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     590: 49 89 c6                     	movq	%rax, %r14
     593: e8 00 00 00 00               	callq	0x598 <native_tracer_entry+0x598>
		0000000000000594:  R_X86_64_PLT32	bpf_ktime_get_ns-0x4
     598: 4d 85 f6                     	testq	%r14, %r14
     59b: 0f 84 3f 01 00 00            	je	0x6e0 <native_tracer_entry+0x6e0>
     5a1: 49 8b 16                     	movq	(%r14), %rdx
     5a4: 48 89 d1                     	movq	%rdx, %rcx
     5a7: 48 83 e1 e0                  	andq	$-0x20, %rcx
     5ab: 48 89 c6                     	movq	%rax, %rsi
     5ae: 48 29 ce                     	subq	%rcx, %rsi
     5b1: 89 d1                        	movl	%edx, %ecx
     5b3: 80 e1 0f                     	andb	$0xf, %cl
     5b6: bf 00 e1 f5 05               	movl	$0x5f5e100, %edi        # imm = 0x5F5E100
     5bb: c4 e2 f1 f7 ff               	shlxq	%rcx, %rdi, %rdi
     5c0: 48 39 fe                     	cmpq	%rdi, %rsi
     5c3: 0f 82 6e 01 00 00            	jb	0x737 <native_tracer_entry+0x737>
     5c9: 89 d1                        	movl	%edx, %ecx
     5cb: 80 e1 10                     	andb	$0x10, %cl
     5ce: 41 b8 ff ff ff ff            	movl	$0xffffffff, %r8d       # imm = 0xFFFFFFFF
     5d4: 4c 01 c7                     	addq	%r8, %rdi
     5d7: 48 81 c7 01 f2 05 2a         	addq	$0x2a05f201, %rdi       # imm = 0x2A05F201
     5de: 48 39 fe                     	cmpq	%rdi, %rsi
     5e1: 0f 83 fb 00 00 00            	jae	0x6e2 <native_tracer_entry+0x6e2>
     5e7: 83 e2 0f                     	andl	$0xf, %edx
     5ea: 31 f6                        	xorl	%esi, %esi
     5ec: 84 c9                        	testb	%cl, %cl
     5ee: 40 0f 94 c6                  	sete	%sil
     5f2: 8d 34 b5 04 00 00 00         	leal	0x4(,%rsi,4), %esi
     5f9: 39 f2                        	cmpl	%esi, %edx
     5fb: 80 d2 00                     	adcb	$0x0, %dl
     5fe: 0f b6 d2                     	movzbl	%dl, %edx
     601: e9 de 00 00 00               	jmp	0x6e4 <native_tracer_entry+0x6e4>
     606: 48 83 bc 24 c0 00 00 00 2b   	cmpq	$0x2b, 0xc0(%rsp)
     60f: 0f 85 c0 00 00 00            	jne	0x6d5 <native_tracer_entry+0x6d5>
     615: 48 83 bc 24 a8 00 00 00 23   	cmpq	$0x23, 0xa8(%rsp)
     61e: 0f 84 81 fb ff ff            	je	0x1a5 <native_tracer_entry+0x1a5>
     624: 48 8b 84 24 a0 00 00 00      	movq	0xa0(%rsp), %rax
     62c: 49 89 86 d0 0e 00 00         	movq	%rax, 0xed0(%r14)
     633: 48 8b 84 24 b8 00 00 00      	movq	0xb8(%rsp), %rax
     63b: 49 89 86 d8 0e 00 00         	movq	%rax, 0xed8(%r14)
     642: 48 8b 44 24 40               	movq	0x40(%rsp), %rax
     647: 49 89 86 e0 0e 00 00         	movq	%rax, 0xee0(%r14)
     64e: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
     653: 49 89 86 e8 0e 00 00         	movq	%rax, 0xee8(%r14)
     65a: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
     65f: 49 89 86 f0 0e 00 00         	movq	%rax, 0xef0(%r14)
     666: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
     66b: 49 89 86 f8 0e 00 00         	movq	%rax, 0xef8(%r14)
     672: 48 8b 44 24 30               	movq	0x30(%rsp), %rax
     677: 49 89 86 00 0f 00 00         	movq	%rax, 0xf00(%r14)
     67e: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
     683: 49 89 86 08 0f 00 00         	movq	%rax, 0xf08(%r14)
     68a: 48 83 bc 24 98 00 00 00 ff   	cmpq	$-0x1, 0x98(%rsp)
     693: 41 0f 95 86 30 0f 00 00      	setne	0xf30(%r14)
     69b: e9 6f fe ff ff               	jmp	0x50f <native_tracer_entry+0x50f>
     6a0: 41 c7 86 28 0f 00 00 01 00 00 00     	movl	$0x1, 0xf28(%r14)
     6ab: 41 bc ad 0f 00 00            	movl	$0xfad, %r12d           # imm = 0xFAD
     6b1: e9 2c fd ff ff               	jmp	0x3e2 <native_tracer_entry+0x3e2>
     6b6: 49 81 fd ff 0f 00 00         	cmpq	$0xfff, %r13            # imm = 0xFFF
     6bd: 77 7f                        	ja	0x73e <native_tracer_entry+0x73e>
     6bf: 41 c7 86 28 0f 00 00 31 00 00 00     	movl	$0x31, 0xf28(%r14)
     6ca: 41 bc ae 0f 00 00            	movl	$0xfae, %r12d           # imm = 0xFAE
     6d0: e9 0d fd ff ff               	jmp	0x3e2 <native_tracer_entry+0x3e2>
     6d5: 45 31 ff                     	xorl	%r15d, %r15d
     6d8: 45 31 e4                     	xorl	%r12d, %r12d
     6db: e9 05 fd ff ff               	jmp	0x3e5 <native_tracer_entry+0x3e5>
     6e0: 31 c9                        	xorl	%ecx, %ecx
     6e2: 31 d2                        	xorl	%edx, %edx
     6e4: 48 83 e0 e0                  	andq	$-0x20, %rax
     6e8: 0f b6 c9                     	movzbl	%cl, %ecx
     6eb: 48 09 c1                     	orq	%rax, %rcx
     6ee: 48 09 d1                     	orq	%rdx, %rcx
     6f1: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
     6f6: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x6fd <native_tracer_entry+0x6fd>
		00000000000006f9:  R_X86_64_REX_GOTPCRELX	reported_pids-0x4
     6fd: 48 8d 74 24 10               	leaq	0x10(%rsp), %rsi
     702: 48 8d 54 24 20               	leaq	0x20(%rsp), %rdx
     707: 31 c9                        	xorl	%ecx, %ecx
     709: e8 00 00 00 00               	callq	0x70e <native_tracer_entry+0x70e>
		000000000000070a:  R_X86_64_PLT32	bpf_map_update_elem-0x4
     70e: 85 c0                        	testl	%eax, %eax
     710: 0f 84 1c 01 00 00            	je	0x832 <native_tracer_entry+0x832>
     716: c7 44 24 14 3d 00 00 00      	movl	$0x3d, 0x14(%rsp)
     71e: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x725 <native_tracer_entry+0x725>
		0000000000000721:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     725: 48 8d 74 24 14               	leaq	0x14(%rsp), %rsi
     72a: e8 00 00 00 00               	callq	0x72f <native_tracer_entry+0x72f>
		000000000000072b:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     72f: 48 85 c0                     	testq	%rax, %rax
     732: 74 03                        	je	0x737 <native_tracer_entry+0x737>
     734: 48 ff 00                     	incq	(%rax)
     737: 31 ed                        	xorl	%ebp, %ebp
     739: e9 43 fd ff ff               	jmp	0x481 <native_tracer_entry+0x481>
     73e: 41 8b 06                     	movl	(%r14), %eax
     741: c7 44 24 20 60 00 00 00      	movl	$0x60, 0x20(%rsp)
     749: 0f 38 f1 44 24 24            	movbel	%eax, 0x24(%rsp)
     74f: 4c 0f 38 f1 6c 24 28         	movbeq	%r13, 0x28(%rsp)
     756: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x75d <native_tracer_entry+0x75d>
		0000000000000759:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
     75d: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     762: e8 00 00 00 00               	callq	0x767 <native_tracer_entry+0x767>
		0000000000000763:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     767: 48 85 c0                     	testq	%rax, %rax
     76a: 0f 84 f0 00 00 00            	je	0x860 <native_tracer_entry+0x860>
     770: 48 b9 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
     77a: 4c 8b 78 08                  	movq	0x8(%rax), %r15
     77e: 4c 21 f9                     	andq	%r15, %rcx
     781: 49 89 8e 20 0f 00 00         	movq	%rcx, 0xf20(%r14)
     788: 48 8b 00                     	movq	(%rax), %rax
     78b: 49 89 86 10 0f 00 00         	movq	%rax, 0xf10(%r14)
     792: 49 c1 ef 38                  	shrq	$0x38, %r15
     796: 49 29 cd                     	subq	%rcx, %r13
     799: 4d 89 ae 18 0f 00 00         	movq	%r13, 0xf18(%r14)
     7a0: 45 31 e4                     	xorl	%r12d, %r12d
     7a3: 49 83 ff 01                  	cmpq	$0x1, %r15
     7a7: 0f 85 38 fc ff ff            	jne	0x3e5 <native_tracer_entry+0x3e5>
     7ad: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
     7b2: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x7b9 <native_tracer_entry+0x7b9>
		00000000000007b5:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
     7b9: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     7be: e8 00 00 00 00               	callq	0x7c3 <native_tracer_entry+0x7c3>
		00000000000007bf:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     7c3: 41 bf 01 00 00 00            	movl	$0x1, %r15d
     7c9: 48 85 c0                     	testq	%rax, %rax
     7cc: 0f 84 13 fc ff ff            	je	0x3e5 <native_tracer_entry+0x3e5>
     7d2: 4c 39 28                     	cmpq	%r13, (%rax)
     7d5: 77 06                        	ja	0x7dd <native_tracer_entry+0x7dd>
     7d7: 4c 39 68 08                  	cmpq	%r13, 0x8(%rax)
     7db: 73 14                        	jae	0x7f1 <native_tracer_entry+0x7f1>
     7dd: 4c 39 68 10                  	cmpq	%r13, 0x10(%rax)
     7e1: 0f 87 fe fb ff ff            	ja	0x3e5 <native_tracer_entry+0x3e5>
     7e7: 4c 39 68 18                  	cmpq	%r13, 0x18(%rax)
     7eb: 0f 82 f4 fb ff ff            	jb	0x3e5 <native_tracer_entry+0x3e5>
     7f1: 41 8b 8e 80 13 00 00         	movl	0x1380(%r14), %ecx
     7f8: 8b 50 20                     	movl	0x20(%rax), %edx
     7fb: 0f a3 d1                     	btl	%edx, %ecx
     7fe: 0f 82 e1 fb ff ff            	jb	0x3e5 <native_tracer_entry+0x3e5>
     804: 49 89 c7                     	movq	%rax, %r15
     807: c7 44 24 18 00 00 00 00      	movl	$0x0, 0x18(%rsp)
     80f: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x816 <native_tracer_entry+0x816>
		0000000000000812:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     816: 48 8d 74 24 18               	leaq	0x18(%rsp), %rsi
     81b: e8 00 00 00 00               	callq	0x820 <native_tracer_entry+0x820>
		000000000000081c:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     820: 48 85 c0                     	testq	%rax, %rax
     823: 74 03                        	je	0x828 <native_tracer_entry+0x828>
     825: 48 ff 00                     	incq	(%rax)
     828: 45 0f b7 7f 20               	movzwl	0x20(%r15), %r15d
     82d: e9 b3 fb ff ff               	jmp	0x3e5 <native_tracer_entry+0x3e5>
     832: c6 44 24 0f 01               	movb	$0x1, 0xf(%rsp)
     837: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x83e <native_tracer_entry+0x83e>
		000000000000083a:  R_X86_64_REX_GOTPCRELX	pid_events-0x4
     83e: 48 8d 74 24 18               	leaq	0x18(%rsp), %rsi
     843: 48 8d 54 24 0f               	leaq	0xf(%rsp), %rdx
     848: 31 c9                        	xorl	%ecx, %ecx
     84a: e8 00 00 00 00               	callq	0x84f <native_tracer_entry+0x84f>
		000000000000084b:  R_X86_64_PLT32	bpf_map_update_elem-0x4
     84f: 85 c0                        	testl	%eax, %eax
     851: 74 23                        	je	0x876 <native_tracer_entry+0x876>
     853: c7 44 24 20 3e 00 00 00      	movl	$0x3e, 0x20(%rsp)
     85b: e9 93 00 00 00               	jmp	0x8f3 <native_tracer_entry+0x8f3>
     860: 41 c7 86 28 0f 00 00 0c 00 00 00     	movl	$0xc, 0xf28(%r14)
     86b: 41 bc ac 0f 00 00            	movl	$0xfac, %r12d           # imm = 0xFAC
     871: e9 6c fb ff ff               	jmp	0x3e2 <native_tracer_entry+0x3e2>
     876: c7 44 24 14 01 00 00 00      	movl	$0x1, 0x14(%rsp)
     87e: c6 44 24 10 01               	movb	$0x1, 0x10(%rsp)
     883: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x88a <native_tracer_entry+0x88a>
		0000000000000886:  R_X86_64_REX_GOTPCRELX	inhibit_events-0x4
     88a: 48 8d 74 24 14               	leaq	0x14(%rsp), %rsi
     88f: 48 8d 54 24 10               	leaq	0x10(%rsp), %rdx
     894: b9 01 00 00 00               	movl	$0x1, %ecx
     899: e8 00 00 00 00               	callq	0x89e <native_tracer_entry+0x89e>
		000000000000089a:  R_X86_64_PLT32	bpf_map_update_elem-0x4
     89e: 48 85 c0                     	testq	%rax, %rax
     8a1: 78 48                        	js	0x8eb <native_tracer_entry+0x8eb>
     8a3: c7 44 24 20 42 00 00 00      	movl	$0x42, 0x20(%rsp)
     8ab: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x8b2 <native_tracer_entry+0x8b2>
		00000000000008ae:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     8b2: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     8b7: e8 00 00 00 00               	callq	0x8bc <native_tracer_entry+0x8bc>
		00000000000008b8:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     8bc: 48 85 c0                     	testq	%rax, %rax
     8bf: 74 03                        	je	0x8c4 <native_tracer_entry+0x8c4>
     8c1: 48 ff 00                     	incq	(%rax)
     8c4: c7 44 24 20 01 00 00 00      	movl	$0x1, 0x20(%rsp)
     8cc: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x8d3 <native_tracer_entry+0x8d3>
		00000000000008cf:  R_X86_64_REX_GOTPCRELX	report_events-0x4
     8d3: 48 8d 4c 24 20               	leaq	0x20(%rsp), %rcx
     8d8: ba ff ff ff ff               	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     8dd: 41 b8 04 00 00 00            	movl	$0x4, %r8d
     8e3: 48 89 df                     	movq	%rbx, %rdi
     8e6: e8 00 00 00 00               	callq	0x8eb <native_tracer_entry+0x8eb>
		00000000000008e7:  R_X86_64_PLT32	bpf_perf_event_output-0x4
     8eb: c7 44 24 20 3f 00 00 00      	movl	$0x3f, 0x20(%rsp)
     8f3: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x8fa <native_tracer_entry+0x8fa>
		00000000000008f6:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     8fa: 48 8d 74 24 20               	leaq	0x20(%rsp), %rsi
     8ff: e8 00 00 00 00               	callq	0x904 <native_tracer_entry+0x904>
		0000000000000900:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     904: 48 85 c0                     	testq	%rax, %rax
     907: 0f 85 27 fe ff ff            	jne	0x734 <native_tracer_entry+0x734>
     90d: e9 25 fe ff ff               	jmp	0x737 <native_tracer_entry+0x737>
