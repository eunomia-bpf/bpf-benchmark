
/workspaces/kprog-raw/perf/current-entry-20261120/trusted_x86.bpf.o:	file format elf64-bpf
