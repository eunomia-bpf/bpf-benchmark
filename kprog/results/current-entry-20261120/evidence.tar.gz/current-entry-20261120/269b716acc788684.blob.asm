
/workspaces/kprog-raw/perf/current-entry-20261120/269b716acc788684.blob.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
  11:	48 89 fb             	mov    %rdi,%rbx
  14:	e8 00 00 00 00       	call   0x19
  19:	49 89 c7             	mov    %rax,%r15
  1c:	49 89 c5             	mov    %rax,%r13
  1f:	49 c1 ed 20          	shr    $0x20,%r13
  23:	e8 00 00 00 00       	call   0x28
  28:	49 89 c4             	mov    %rax,%r12
  2b:	4d 85 ed             	test   %r13,%r13
  2e:	0f 84 85 01 00 00    	je     0x1b9
  34:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
  3b:	00 
  3c:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
  43:	00 00 00 
  46:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
  4b:	e8 ac 09 00 00       	call   0x9fc
  50:	bd ff ff ff ff       	mov    $0xffffffff,%ebp
  55:	48 85 c0             	test   %rax,%rax
  58:	0f 84 92 04 00 00    	je     0x4f0
  5e:	49 89 c6             	mov    %rax,%r14
  61:	48 c7 80 00 0f 00 00 	movq   $0x0,0xf00(%rax)
  68:	00 00 00 00 
  6c:	c6 80 30 0f 00 00 00 	movb   $0x0,0xf30(%rax)
  73:	48 c7 80 d0 0e 00 00 	movq   $0x0,0xed0(%rax)
  7a:	00 00 00 00 
  7e:	48 c7 80 d8 0e 00 00 	movq   $0x0,0xed8(%rax)
  85:	00 00 00 00 
  89:	48 c7 80 e0 0e 00 00 	movq   $0x0,0xee0(%rax)
  90:	00 00 00 00 
  94:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  99:	49 89 86 28 0f 00 00 	mov    %rax,0xf28(%r14)
  a0:	41 c7 86 80 13 00 00 	movl   $0x0,0x1380(%r14)
  a7:	00 00 00 00 
  ab:	66 41 c7 86 84 13 00 	movw   $0x100,0x1384(%r14)
  b2:	00 00 01 
  b5:	49 c7 86 38 0f 00 00 	movq   $0x0,0xf38(%r14)
  bc:	00 00 00 00 
  c0:	49 c7 86 40 0f 00 00 	movq   $0x0,0xf40(%r14)
  c7:	00 00 00 00 
  cb:	49 c7 86 58 0f 00 00 	movq   $0x0,0xf58(%r14)
  d2:	00 00 00 00 
  d6:	49 c7 86 60 0f 00 00 	movq   $0x0,0xf60(%r14)
  dd:	00 00 00 00 
  e1:	49 c7 86 68 0f 00 00 	movq   $0x0,0xf68(%r14)
  e8:	00 00 00 00 
  ec:	49 c7 86 70 0f 00 00 	movq   $0x0,0xf70(%r14)
  f3:	00 00 00 00 
  f7:	49 c7 86 78 0f 00 00 	movq   $0x0,0xf78(%r14)
  fe:	00 00 00 00 
 102:	49 89 86 bc 02 00 00 	mov    %rax,0x2bc(%r14)
 109:	49 8d 7e 20          	lea    0x20(%r14),%rdi
 10d:	ba 9c 02 00 00       	mov    $0x29c,%edx
 112:	31 f6                	xor    %esi,%esi
 114:	e8 b0 08 00 00       	call   0x9c9
 119:	41 c7 86 c4 02 00 00 	movl   $0x1,0x2c4(%r14)
 120:	01 00 00 00 
 124:	45 89 2e             	mov    %r13d,(%r14)
 127:	45 89 7e 04          	mov    %r15d,0x4(%r14)
 12b:	4d 89 66 08          	mov    %r12,0x8(%r14)
 12f:	49 c7 86 c8 02 00 00 	movq   $0x0,0x2c8(%r14)
 136:	00 00 00 00 
 13a:	49 8d 7e 10          	lea    0x10(%r14),%rdi
 13e:	be 10 00 00 00       	mov    $0x10,%esi
 143:	e8 00 00 00 00       	call   0x148
 148:	48 85 c0             	test   %rax,%rax
 14b:	79 24                	jns    0x171
 14d:	c7 44 24 20 34 00 00 	movl   $0x34,0x20(%rsp)
 154:	00 
 155:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 15c:	00 00 00 
 15f:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
 164:	e8 b2 08 00 00       	call   0xa1b
 169:	48 85 c0             	test   %rax,%rax
 16c:	74 03                	je     0x171
 16e:	48 ff 00             	incq   (%rax)
 171:	48 be 00 00 00 00 00 	movabs $0x0,%rsi
 178:	00 00 00 
 17b:	ba 00 04 00 00       	mov    $0x400,%edx
 180:	48 89 df             	mov    %rbx,%rdi
 183:	e8 00 00 00 00       	call   0x188
 188:	41 89 86 bc 02 00 00 	mov    %eax,0x2bc(%r14)
 18f:	48 8b 03             	mov    (%rbx),%rax
 192:	48 83 b8 a0 00 00 00 	cmpq   $0x2b,0xa0(%rax)
 199:	2b 
 19a:	0f 85 f8 01 00 00    	jne    0x398
 1a0:	48 83 b8 88 00 00 00 	cmpq   $0x23,0x88(%rax)
 1a7:	23 
 1a8:	0f 85 5a 03 00 00    	jne    0x508
 1ae:	41 bc b1 0f 00 00    	mov    $0xfb1,%r12d
 1b4:	e9 47 02 00 00       	jmp    0x400
 1b9:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 1c0:	00 
 1c1:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 1c8:	00 00 00 
 1cb:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
 1d0:	e8 27 08 00 00       	call   0x9fc
 1d5:	48 85 c0             	test   %rax,%rax
 1d8:	0f 84 b2 02 00 00    	je     0x490
 1de:	49 89 c6             	mov    %rax,%r14
 1e1:	48 c7 80 00 0f 00 00 	movq   $0x0,0xf00(%rax)
 1e8:	00 00 00 00 
 1ec:	c6 80 30 0f 00 00 00 	movb   $0x0,0xf30(%rax)
 1f3:	48 c7 80 d0 0e 00 00 	movq   $0x0,0xed0(%rax)
 1fa:	00 00 00 00 
 1fe:	48 c7 80 d8 0e 00 00 	movq   $0x0,0xed8(%rax)
 205:	00 00 00 00 
 209:	48 c7 80 e0 0e 00 00 	movq   $0x0,0xee0(%rax)
 210:	00 00 00 00 
 214:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
 219:	49 89 86 28 0f 00 00 	mov    %rax,0xf28(%r14)
 220:	41 c7 86 80 13 00 00 	movl   $0x0,0x1380(%r14)
 227:	00 00 00 00 
 22b:	66 41 c7 86 84 13 00 	movw   $0x100,0x1384(%r14)
 232:	00 00 01 
 235:	49 c7 86 38 0f 00 00 	movq   $0x0,0xf38(%r14)
 23c:	00 00 00 00 
 240:	49 c7 86 40 0f 00 00 	movq   $0x0,0xf40(%r14)
 247:	00 00 00 00 
 24b:	49 c7 86 58 0f 00 00 	movq   $0x0,0xf58(%r14)
 252:	00 00 00 00 
 256:	49 c7 86 60 0f 00 00 	movq   $0x0,0xf60(%r14)
 25d:	00 00 00 00 
 261:	49 c7 86 68 0f 00 00 	movq   $0x0,0xf68(%r14)
 268:	00 00 00 00 
 26c:	49 c7 86 70 0f 00 00 	movq   $0x0,0xf70(%r14)
 273:	00 00 00 00 
 277:	49 c7 86 78 0f 00 00 	movq   $0x0,0xf78(%r14)
 27e:	00 00 00 00 
 282:	49 89 86 bc 02 00 00 	mov    %rax,0x2bc(%r14)
 289:	49 8d 7e 20          	lea    0x20(%r14),%rdi
 28d:	ba 9c 02 00 00       	mov    $0x29c,%edx
 292:	31 f6                	xor    %esi,%esi
 294:	e8 30 07 00 00       	call   0x9c9
 299:	41 c7 86 c4 02 00 00 	movl   $0x1,0x2c4(%r14)
 2a0:	01 00 00 00 
 2a4:	41 c7 06 00 00 00 00 	movl   $0x0,(%r14)
 2ab:	45 89 7e 04          	mov    %r15d,0x4(%r14)
 2af:	4d 89 66 08          	mov    %r12,0x8(%r14)
 2b3:	49 c7 86 c8 02 00 00 	movq   $0x0,0x2c8(%r14)
 2ba:	00 00 00 00 
 2be:	4c 89 f7             	mov    %r14,%rdi
 2c1:	48 83 c7 10          	add    $0x10,%rdi
 2c5:	be 10 00 00 00       	mov    $0x10,%esi
 2ca:	e8 00 00 00 00       	call   0x2cf
 2cf:	48 85 c0             	test   %rax,%rax
 2d2:	79 24                	jns    0x2f8
 2d4:	c7 44 24 20 34 00 00 	movl   $0x34,0x20(%rsp)
 2db:	00 
 2dc:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 2e3:	00 00 00 
 2e6:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
 2eb:	e8 2b 07 00 00       	call   0xa1b
 2f0:	48 85 c0             	test   %rax,%rax
 2f3:	74 03                	je     0x2f8
 2f5:	48 ff 00             	incq   (%rax)
 2f8:	48 be 00 00 00 00 00 	movabs $0x0,%rsi
 2ff:	00 00 00 
 302:	ba 00 04 00 00       	mov    $0x400,%edx
 307:	48 89 df             	mov    %rbx,%rdi
 30a:	e8 00 00 00 00       	call   0x30f
 30f:	41 89 86 bc 02 00 00 	mov    %eax,0x2bc(%r14)
 316:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 31d:	00 
 31e:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 325:	00 00 00 
 328:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
 32d:	e8 ca 06 00 00       	call   0x9fc
 332:	48 85 c0             	test   %rax,%rax
 335:	74 50                	je     0x387
 337:	0f b6 88 84 13 00 00 	movzbl 0x1384(%rax),%ecx
 33e:	80 f9 1d             	cmp    $0x1d,%cl
 341:	72 3c                	jb     0x37f
 343:	49 89 c6             	mov    %rax,%r14
 346:	c7 80 2c 0f 00 00 05 	movl   $0x5,0xf2c(%rax)
 34d:	00 00 00 
 350:	c7 44 24 20 44 00 00 	movl   $0x44,0x20(%rsp)
 357:	00 
 358:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 35f:	00 00 00 
 362:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
 367:	e8 af 06 00 00       	call   0xa1b
 36c:	48 85 c0             	test   %rax,%rax
 36f:	74 03                	je     0x374
 371:	48 ff 00             	incq   (%rax)
 374:	4c 89 f0             	mov    %r14,%rax
 377:	41 0f b6 8e 84 13 00 	movzbl 0x1384(%r14),%ecx
 37e:	00 
 37f:	fe c1                	inc    %cl
 381:	88 88 84 13 00 00    	mov    %cl,0x1384(%rax)
 387:	48 be 00 00 00 00 00 	movabs $0x0,%rsi
 38e:	00 00 00 
 391:	31 ed                	xor    %ebp,%ebp
 393:	e9 09 01 00 00       	jmp    0x4a1
 398:	e8 00 00 00 00       	call   0x39d
 39d:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
 3a2:	be 08 00 00 00       	mov    $0x8,%esi
 3a7:	48 89 c2             	mov    %rax,%rdx
 3aa:	e8 00 00 00 00       	call   0x3af
 3af:	48 85 c0             	test   %rax,%rax
 3b2:	75 22                	jne    0x3d6
 3b4:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 3b9:	48 85 d2             	test   %rdx,%rdx
 3bc:	74 18                	je     0x3d6
 3be:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
 3c3:	be a8 00 00 00       	mov    $0xa8,%esi
 3c8:	e8 00 00 00 00       	call   0x3cd
 3cd:	48 85 c0             	test   %rax,%rax
 3d0:	0f 84 bc 02 00 00    	je     0x692
 3d6:	c7 44 24 18 52 00 00 	movl   $0x52,0x18(%rsp)
 3dd:	00 
 3de:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 3e5:	00 00 00 
 3e8:	48 8d 74 24 18       	lea    0x18(%rsp),%rsi
 3ed:	e8 29 06 00 00       	call   0xa1b
 3f2:	48 85 c0             	test   %rax,%rax
 3f5:	74 03                	je     0x3fa
 3f7:	48 ff 00             	incq   (%rax)
 3fa:	41 bc a9 0f 00 00    	mov    $0xfa9,%r12d
 400:	45 31 ff             	xor    %r15d,%r15d
 403:	45 89 a6 2c 0f 00 00 	mov    %r12d,0xf2c(%r14)
 40a:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 411:	00 
 412:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 419:	00 00 00 
 41c:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
 421:	e8 d6 05 00 00       	call   0x9fc
 426:	48 85 c0             	test   %rax,%rax
 429:	74 6c                	je     0x497
 42b:	0f b6 88 84 13 00 00 	movzbl 0x1384(%rax),%ecx
 432:	80 f9 1d             	cmp    $0x1d,%cl
 435:	72 3f                	jb     0x476
 437:	49 89 c6             	mov    %rax,%r14
 43a:	c7 80 2c 0f 00 00 05 	movl   $0x5,0xf2c(%rax)
 441:	00 00 00 
 444:	c7 44 24 20 44 00 00 	movl   $0x44,0x20(%rsp)
 44b:	00 
 44c:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 453:	00 00 00 
 456:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
 45b:	e8 bb 05 00 00       	call   0xa1b
 460:	48 85 c0             	test   %rax,%rax
 463:	74 03                	je     0x468
 465:	48 ff 00             	incq   (%rax)
 468:	4c 89 f0             	mov    %r14,%rax
 46b:	41 0f b6 8e 84 13 00 	movzbl 0x1384(%r14),%ecx
 472:	00 
 473:	45 31 ff             	xor    %r15d,%r15d
 476:	fe c1                	inc    %cl
 478:	88 88 84 13 00 00    	mov    %cl,0x1384(%rax)
 47e:	48 be 00 00 00 00 00 	movabs $0x0,%rsi
 485:	00 00 00 
 488:	48 89 df             	mov    %rbx,%rdi
 48b:	44 89 fa             	mov    %r15d,%edx
 48e:	eb 16                	jmp    0x4a6
 490:	bd ff ff ff ff       	mov    $0xffffffff,%ebp
 495:	eb 59                	jmp    0x4f0
 497:	48 be 00 00 00 00 00 	movabs $0x0,%rsi
 49e:	00 00 00 
 4a1:	48 89 df             	mov    %rbx,%rdi
 4a4:	31 d2                	xor    %edx,%edx
 4a6:	89 d2                	mov    %edx,%edx
 4a8:	39 56 44             	cmp    %edx,0x44(%rsi)
 4ab:	76 43                	jbe    0x4f0
 4ad:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
 4b4:	00 
 4b5:	48 8b 80 f0 ff ff ff 	mov    -0x10(%rax),%rax
 4bc:	48 83 38 21          	cmpq   $0x21,(%rax)
 4c0:	73 2e                	jae    0x4f0
 4c2:	48 8b 8c d6 30 01 00 	mov    0x130(%rsi,%rdx,8),%rcx
 4c9:	00 
 4ca:	48 85 c9             	test   %rcx,%rcx
 4cd:	74 21                	je     0x4f0
 4cf:	48 83 00 01          	addq   $0x1,(%rax)
 4d3:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
 4da:	5b                   	pop    %rbx
 4db:	41 5c                	pop    %r12
 4dd:	41 5d                	pop    %r13
 4df:	41 5e                	pop    %r14
 4e1:	41 5f                	pop    %r15
 4e3:	5d                   	pop    %rbp
 4e4:	58                   	pop    %rax
 4e5:	58                   	pop    %rax
 4e6:	48 8b 49 48          	mov    0x48(%rcx),%rcx
 4ea:	48 83 c1 0c          	add    $0xc,%rcx
 4ee:	ff e1                	jmp    *%rcx
 4f0:	89 e8                	mov    %ebp,%eax
 4f2:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
 4f9:	5b                   	pop    %rbx
 4fa:	41 5c                	pop    %r12
 4fc:	41 5d                	pop    %r13
 4fe:	41 5e                	pop    %r14
 500:	41 5f                	pop    %r15
 502:	5d                   	pop    %rbp
 503:	e9 32 05 00 00       	jmp    0xa3a
 508:	48 8b 80 80 00 00 00 	mov    0x80(%rax),%rax
 50f:	49 89 86 d0 0e 00 00 	mov    %rax,0xed0(%r14)
 516:	48 8b 03             	mov    (%rbx),%rax
 519:	48 8b 80 98 00 00 00 	mov    0x98(%rax),%rax
 520:	49 89 86 d8 0e 00 00 	mov    %rax,0xed8(%r14)
 527:	48 8b 03             	mov    (%rbx),%rax
 52a:	48 8b 40 20          	mov    0x20(%rax),%rax
 52e:	49 89 86 e0 0e 00 00 	mov    %rax,0xee0(%r14)
 535:	48 8b 03             	mov    (%rbx),%rax
 538:	48 8b 40 50          	mov    0x50(%rax),%rax
 53c:	49 89 86 e8 0e 00 00 	mov    %rax,0xee8(%r14)
 543:	48 8b 03             	mov    (%rbx),%rax
 546:	48 8b 40 40          	mov    0x40(%rax),%rax
 54a:	49 89 86 f0 0e 00 00 	mov    %rax,0xef0(%r14)
 551:	48 8b 03             	mov    (%rbx),%rax
 554:	48 8b 40 30          	mov    0x30(%rax),%rax
 558:	49 89 86 f8 0e 00 00 	mov    %rax,0xef8(%r14)
 55f:	48 8b 03             	mov    (%rbx),%rax
 562:	48 8b 40 10          	mov    0x10(%rax),%rax
 566:	49 89 86 00 0f 00 00 	mov    %rax,0xf00(%r14)
 56d:	48 8b 03             	mov    (%rbx),%rax
 570:	48 8b 00             	mov    (%rax),%rax
 573:	49 89 86 08 0f 00 00 	mov    %rax,0xf08(%r14)
 57a:	41 c6 86 30 0f 00 00 	movb   $0x0,0xf30(%r14)
 581:	00 
 582:	c7 44 24 20 60 00 00 	movl   $0x60,0x20(%rsp)
 589:	00 
 58a:	44 0f 38 f1 6c 24 24 	movbe  %r13d,0x24(%rsp)
 591:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
 598:	00 00 
 59a:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 5a1:	00 00 00 
 5a4:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
 5a9:	e8 00 00 00 00       	call   0x5ae
 5ae:	48 85 c0             	test   %rax,%rax
 5b1:	74 38                	je     0x5eb
 5b3:	4c 89 f0             	mov    %r14,%rax
 5b6:	48 05 d0 0e 00 00    	add    $0xed0,%rax
 5bc:	4c 8b 28             	mov    (%rax),%r13
 5bf:	4d 85 ed             	test   %r13,%r13
 5c2:	0f 84 64 01 00 00    	je     0x72c
 5c8:	4c 89 e8             	mov    %r13,%rax
 5cb:	48 c1 e8 38          	shr    $0x38,%rax
 5cf:	0f 84 6d 01 00 00    	je     0x742
 5d5:	41 c7 86 28 0f 00 00 	movl   $0xb,0xf28(%r14)
 5dc:	0b 00 00 00 
 5e0:	41 bc ab 0f 00 00    	mov    $0xfab,%r12d
 5e6:	e9 15 fe ff ff       	jmp    0x400
 5eb:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
 5f0:	44 89 6c 24 10       	mov    %r13d,0x10(%rsp)
 5f5:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 5fc:	00 00 00 
 5ff:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
 604:	e8 00 00 00 00       	call   0x609
 609:	48 85 c0             	test   %rax,%rax
 60c:	74 0e                	je     0x61c
 60e:	80 78 23 00          	cmpb   $0x0,0x23(%rax)
 612:	75 04                	jne    0x618
 614:	c6 40 23 01          	movb   $0x1,0x23(%rax)
 618:	48 83 c0 38          	add    $0x38,%rax
 61c:	49 89 c6             	mov    %rax,%r14
 61f:	e8 00 00 00 00       	call   0x624
 624:	4d 85 f6             	test   %r14,%r14
 627:	0f 84 43 01 00 00    	je     0x770
 62d:	49 8b 16             	mov    (%r14),%rdx
 630:	48 89 d1             	mov    %rdx,%rcx
 633:	48 83 e1 e0          	and    $0xffffffffffffffe0,%rcx
 637:	48 89 c6             	mov    %rax,%rsi
 63a:	48 29 ce             	sub    %rcx,%rsi
 63d:	89 d1                	mov    %edx,%ecx
 63f:	80 e1 0f             	and    $0xf,%cl
 642:	bf 00 e1 f5 05       	mov    $0x5f5e100,%edi
 647:	c4 e2 f1 f7 ff       	shlx   %rcx,%rdi,%rdi
 64c:	48 39 fe             	cmp    %rdi,%rsi
 64f:	0f 82 78 01 00 00    	jb     0x7cd
 655:	89 d1                	mov    %edx,%ecx
 657:	80 e1 10             	and    $0x10,%cl
 65a:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
 660:	4c 01 c7             	add    %r8,%rdi
 663:	48 81 c7 01 f2 05 2a 	add    $0x2a05f201,%rdi
 66a:	48 39 fe             	cmp    %rdi,%rsi
 66d:	0f 83 ff 00 00 00    	jae    0x772
 673:	83 e2 0f             	and    $0xf,%edx
 676:	31 f6                	xor    %esi,%esi
 678:	84 c9                	test   %cl,%cl
 67a:	40 0f 94 c6          	sete   %sil
 67e:	8d 34 b5 04 00 00 00 	lea    0x4(,%rsi,4),%esi
 685:	39 f2                	cmp    %esi,%edx
 687:	80 d2 00             	adc    $0x0,%dl
 68a:	0f b6 d2             	movzbl %dl,%edx
 68d:	e9 e2 00 00 00       	jmp    0x774
 692:	48 83 bc 24 c0 00 00 	cmpq   $0x2b,0xc0(%rsp)
 699:	00 2b 
 69b:	0f 85 c4 00 00 00    	jne    0x765
 6a1:	48 83 bc 24 a8 00 00 	cmpq   $0x23,0xa8(%rsp)
 6a8:	00 23 
 6aa:	0f 84 fe fa ff ff    	je     0x1ae
 6b0:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
 6b7:	00 
 6b8:	49 89 86 d0 0e 00 00 	mov    %rax,0xed0(%r14)
 6bf:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 6c6:	00 
 6c7:	49 89 86 d8 0e 00 00 	mov    %rax,0xed8(%r14)
 6ce:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
 6d3:	49 89 86 e0 0e 00 00 	mov    %rax,0xee0(%r14)
 6da:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
 6df:	49 89 86 e8 0e 00 00 	mov    %rax,0xee8(%r14)
 6e6:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
 6eb:	49 89 86 f0 0e 00 00 	mov    %rax,0xef0(%r14)
 6f2:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
 6f7:	49 89 86 f8 0e 00 00 	mov    %rax,0xef8(%r14)
 6fe:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 703:	49 89 86 00 0f 00 00 	mov    %rax,0xf00(%r14)
 70a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 70f:	49 89 86 08 0f 00 00 	mov    %rax,0xf08(%r14)
 716:	48 83 bc 24 98 00 00 	cmpq   $0xffffffffffffffff,0x98(%rsp)
 71d:	00 ff 
 71f:	41 0f 95 86 30 0f 00 	setne  0xf30(%r14)
 726:	00 
 727:	e9 56 fe ff ff       	jmp    0x582
 72c:	41 c7 86 28 0f 00 00 	movl   $0x1,0xf28(%r14)
 733:	01 00 00 00 
 737:	41 bc ad 0f 00 00    	mov    $0xfad,%r12d
 73d:	e9 be fc ff ff       	jmp    0x400
 742:	49 81 fd ff 0f 00 00 	cmp    $0xfff,%r13
 749:	0f 87 85 00 00 00    	ja     0x7d4
 74f:	41 c7 86 28 0f 00 00 	movl   $0x31,0xf28(%r14)
 756:	31 00 00 00 
 75a:	41 bc ae 0f 00 00    	mov    $0xfae,%r12d
 760:	e9 9b fc ff ff       	jmp    0x400
 765:	45 31 ff             	xor    %r15d,%r15d
 768:	45 31 e4             	xor    %r12d,%r12d
 76b:	e9 93 fc ff ff       	jmp    0x403
 770:	31 c9                	xor    %ecx,%ecx
 772:	31 d2                	xor    %edx,%edx
 774:	48 83 e0 e0          	and    $0xffffffffffffffe0,%rax
 778:	0f b6 c9             	movzbl %cl,%ecx
 77b:	48 09 c1             	or     %rax,%rcx
 77e:	48 09 d1             	or     %rdx,%rcx
 781:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
 786:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 78d:	00 00 00 
 790:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
 795:	48 8d 54 24 20       	lea    0x20(%rsp),%rdx
 79a:	31 c9                	xor    %ecx,%ecx
 79c:	e8 00 00 00 00       	call   0x7a1
 7a1:	85 c0                	test   %eax,%eax
 7a3:	0f 84 31 01 00 00    	je     0x8da
 7a9:	c7 44 24 14 3d 00 00 	movl   $0x3d,0x14(%rsp)
 7b0:	00 
 7b1:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 7b8:	00 00 00 
 7bb:	48 8d 74 24 14       	lea    0x14(%rsp),%rsi
 7c0:	e8 56 02 00 00       	call   0xa1b
 7c5:	48 85 c0             	test   %rax,%rax
 7c8:	74 03                	je     0x7cd
 7ca:	48 ff 00             	incq   (%rax)
 7cd:	31 ed                	xor    %ebp,%ebp
 7cf:	e9 1c fd ff ff       	jmp    0x4f0
 7d4:	41 8b 06             	mov    (%r14),%eax
 7d7:	c7 44 24 20 60 00 00 	movl   $0x60,0x20(%rsp)
 7de:	00 
 7df:	0f 38 f1 44 24 24    	movbe  %eax,0x24(%rsp)
 7e5:	4c 0f 38 f1 6c 24 28 	movbe  %r13,0x28(%rsp)
 7ec:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 7f3:	00 00 00 
 7f6:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
 7fb:	e8 00 00 00 00       	call   0x800
 800:	48 85 c0             	test   %rax,%rax
 803:	0f 84 02 01 00 00    	je     0x90b
 809:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffffff,%rcx
 810:	ff ff 00 
 813:	4c 8b 78 08          	mov    0x8(%rax),%r15
 817:	4c 21 f9             	and    %r15,%rcx
 81a:	49 89 8e 20 0f 00 00 	mov    %rcx,0xf20(%r14)
 821:	48 8b 00             	mov    (%rax),%rax
 824:	49 89 86 10 0f 00 00 	mov    %rax,0xf10(%r14)
 82b:	49 c1 ef 38          	shr    $0x38,%r15
 82f:	49 29 cd             	sub    %rcx,%r13
 832:	4d 89 ae 18 0f 00 00 	mov    %r13,0xf18(%r14)
 839:	45 31 e4             	xor    %r12d,%r12d
 83c:	49 83 ff 01          	cmp    $0x1,%r15
 840:	0f 85 bd fb ff ff    	jne    0x403
 846:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 84b:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 852:	00 00 00 
 855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
 85a:	e8 00 00 00 00       	call   0x85f
 85f:	48 85 c0             	test   %rax,%rax
 862:	74 04                	je     0x868
 864:	48 83 c0 38          	add    $0x38,%rax
 868:	41 bf 01 00 00 00    	mov    $0x1,%r15d
 86e:	48 85 c0             	test   %rax,%rax
 871:	0f 84 8c fb ff ff    	je     0x403
 877:	4c 39 28             	cmp    %r13,(%rax)
 87a:	77 06                	ja     0x882
 87c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
 880:	73 14                	jae    0x896
 882:	4c 39 68 10          	cmp    %r13,0x10(%rax)
 886:	0f 87 77 fb ff ff    	ja     0x403
 88c:	4c 39 68 18          	cmp    %r13,0x18(%rax)
 890:	0f 82 6d fb ff ff    	jb     0x403
 896:	41 8b 8e 80 13 00 00 	mov    0x1380(%r14),%ecx
 89d:	8b 50 20             	mov    0x20(%rax),%edx
 8a0:	0f a3 d1             	bt     %edx,%ecx
 8a3:	0f 82 5a fb ff ff    	jb     0x403
 8a9:	49 89 c7             	mov    %rax,%r15
 8ac:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
 8b3:	00 
 8b4:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 8bb:	00 00 00 
 8be:	48 8d 74 24 18       	lea    0x18(%rsp),%rsi
 8c3:	e8 53 01 00 00       	call   0xa1b
 8c8:	48 85 c0             	test   %rax,%rax
 8cb:	74 03                	je     0x8d0
 8cd:	48 ff 00             	incq   (%rax)
 8d0:	45 0f b7 7f 20       	movzwl 0x20(%r15),%r15d
 8d5:	e9 29 fb ff ff       	jmp    0x403
 8da:	c6 44 24 0f 01       	movb   $0x1,0xf(%rsp)
 8df:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 8e6:	00 00 00 
 8e9:	48 8d 74 24 18       	lea    0x18(%rsp),%rsi
 8ee:	48 8d 54 24 0f       	lea    0xf(%rsp),%rdx
 8f3:	31 c9                	xor    %ecx,%ecx
 8f5:	e8 00 00 00 00       	call   0x8fa
 8fa:	85 c0                	test   %eax,%eax
 8fc:	74 23                	je     0x921
 8fe:	c7 44 24 20 3e 00 00 	movl   $0x3e,0x20(%rsp)
 905:	00 
 906:	e9 9c 00 00 00       	jmp    0x9a7
 90b:	41 c7 86 28 0f 00 00 	movl   $0xc,0xf28(%r14)
 912:	0c 00 00 00 
 916:	41 bc ac 0f 00 00    	mov    $0xfac,%r12d
 91c:	e9 df fa ff ff       	jmp    0x400
 921:	c7 44 24 14 01 00 00 	movl   $0x1,0x14(%rsp)
 928:	00 
 929:	c6 44 24 10 01       	movb   $0x1,0x10(%rsp)
 92e:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 935:	00 00 00 
 938:	48 8d 74 24 14       	lea    0x14(%rsp),%rsi
 93d:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 942:	b9 01 00 00 00       	mov    $0x1,%ecx
 947:	e8 00 00 00 00       	call   0x94c
 94c:	48 85 c0             	test   %rax,%rax
 94f:	78 4e                	js     0x99f
 951:	c7 44 24 20 42 00 00 	movl   $0x42,0x20(%rsp)
 958:	00 
 959:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 960:	00 00 00 
 963:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
 968:	e8 ae 00 00 00       	call   0xa1b
 96d:	48 85 c0             	test   %rax,%rax
 970:	74 03                	je     0x975
 972:	48 ff 00             	incq   (%rax)
 975:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
 97c:	00 
 97d:	48 be 00 00 00 00 00 	movabs $0x0,%rsi
 984:	00 00 00 
 987:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
 98c:	ba ff ff ff ff       	mov    $0xffffffff,%edx
 991:	41 b8 04 00 00 00    	mov    $0x4,%r8d
 997:	48 89 df             	mov    %rbx,%rdi
 99a:	e8 00 00 00 00       	call   0x99f
 99f:	c7 44 24 20 3f 00 00 	movl   $0x3f,0x20(%rsp)
 9a6:	00 
 9a7:	48 bf 00 00 00 00 00 	movabs $0x0,%rdi
 9ae:	00 00 00 
 9b1:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
 9b6:	e8 60 00 00 00       	call   0xa1b
 9bb:	48 85 c0             	test   %rax,%rax
 9be:	0f 85 06 fe ff ff    	jne    0x7ca
 9c4:	e9 04 fe ff ff       	jmp    0x7cd
 9c9:	48 89 f8             	mov    %rdi,%rax
 9cc:	45 31 c0             	xor    %r8d,%r8d
 9cf:	b9 14 00 00 00       	mov    $0x14,%ecx
 9d4:	4c 89 07             	mov    %r8,(%rdi)
 9d7:	4c 89 47 08          	mov    %r8,0x8(%rdi)
 9db:	4c 89 47 10          	mov    %r8,0x10(%rdi)
 9df:	4c 89 47 18          	mov    %r8,0x18(%rdi)
 9e3:	48 83 c7 20          	add    $0x20,%rdi
 9e7:	48 ff c9             	dec    %rcx
 9ea:	75 e8                	jne    0x9d4
 9ec:	4c 89 07             	mov    %r8,(%rdi)
 9ef:	4c 89 47 08          	mov    %r8,0x8(%rdi)
 9f3:	4c 89 47 10          	mov    %r8,0x10(%rdi)
 9f7:	44 89 47 18          	mov    %r8d,0x18(%rdi)
 9fb:	c3                   	ret
 9fc:	8b 06                	mov    (%rsi),%eax
 9fe:	83 f8 01             	cmp    $0x1,%eax
 a01:	73 15                	jae    0xa18
 a03:	48 8d 84 c7 30 01 00 	lea    0x130(%rdi,%rax,8),%rax
 a0a:	00 
 a0b:	48 8b 00             	mov    (%rax),%rax
 a0e:	65 48 03 04 25 28 00 	add    %gs:0xffffffff852b0028,%rax
 a15:	2b 85 
 a17:	c3                   	ret
 a18:	31 c0                	xor    %eax,%eax
 a1a:	c3                   	ret
 a1b:	8b 06                	mov    (%rsi),%eax
 a1d:	83 f8 63             	cmp    $0x63,%eax
 a20:	73 15                	jae    0xa37
 a22:	48 8d 84 c7 30 01 00 	lea    0x130(%rdi,%rax,8),%rax
 a29:	00 
 a2a:	48 8b 00             	mov    (%rax),%rax
 a2d:	65 48 03 04 25 28 00 	add    %gs:0xffffffff852b0028,%rax
 a34:	2b 85 
 a36:	c3                   	ret
 a37:	31 c0                	xor    %eax,%eax
 a39:	c3                   	ret
