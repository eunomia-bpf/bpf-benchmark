from pathlib import Path
from datetime import datetime,timezone
import hashlib,io,json,subprocess,sys,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A')
D=R/'kprog/arm64/build/trusted-transport/katran-current-context'
D.mkdir(exist_ok=False)
O=R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted-bcc-frame-result/trusted-arm64-katran-result'
prior=json.loads((O/'summary.json').read_text())
archive=O/prior['archive']
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(archive)==prior['archive_sha256']
with tarfile.open(archive) as t:
 with tarfile.open(fileobj=io.BytesIO(t.extractfile('run/requests/1.success.tar.gz').read())) as q:
  native=q.extractfile('request/kernel.native.o').read()
  metadata=json.loads(q.extractfile('request/generation.metadata.json').read())
  entry=q.extractfile('request/kernel.entry').read().decode().strip()
assert hashlib.sha256(native).hexdigest()=='8e9d78758740ab2c38e085dcaac933d740d5a387b41f4df55813cba6c097a01c'
link=R/'kprog/arm64/build/app-native-link/release/native-link'
assert link.is_file()
paths=['kprog/arm64/trusted_specializer.py','kprog/arm64/micro-prog/generate_micro_sim_proofs.py','kprog/arm64/micro-prog/arm64_abi.py','kprog/arm64/arm64_sim_local_bpf.h','kprog/arm64/arm64_sim.h','kprog/arm64/arm64_sim_direct.h','kprog/trusted_generation.py','kprog/helper_abi.py']
pins={p:h(R/p) for p in paths};pins[str(link.relative_to(R))]=h(link)
report=dict(utc=datetime.now(timezone.utc).isoformat(),scope='fresh canonical production generation/host compilation of exact kernel-captured Katran native request; no compact worker, verifier, QEMU or execution',source_archive_sha256=prior['archive_sha256'],native_sha256=hashlib.sha256(native).hexdigest(),entry=entry,pins=pins)
(D/'kernel.native.o').write_bytes(native);(D/'generation.metadata.json').write_text(json.dumps(metadata,indent=2)+chr(10))
(D/'inputs.json').write_text(json.dumps(report,indent=2)+chr(10))
sys.path.insert(0,str(R/'kprog/arm64'))
import trusted_specializer as worker
rc=0
try:
 result=worker.specialize(native,entry,metadata,D/'generated',link)
 report['artifacts']=result;report['generation_compile_returncode']=0
except Exception as error:
 rc=1;report['generation_compile_returncode']=1
 report['exception_type']=type(error).__name__;report['error']=str(error)
 (D/'exception.txt').write_text(traceback.format_exc())
finally:
 report['source_hashes_unchanged']=all(h(R/p)==v for p,v in pins.items())
 report['finished']=datetime.now(timezone.utc).isoformat()
 (D/'result.json').write_text(json.dumps(report,indent=2)+chr(10))
 print(json.dumps({k:report[k] for k in ['scope','generation_compile_returncode','source_hashes_unchanged','native_sha256']}),flush=True)
sys.exit(rc)
