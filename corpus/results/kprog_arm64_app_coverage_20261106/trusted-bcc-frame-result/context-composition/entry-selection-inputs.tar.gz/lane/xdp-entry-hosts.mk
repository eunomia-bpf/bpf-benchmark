include /workspaces/repository/kprog/formal/Makefile

a-xdp-entry-host-check:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_offset_host.c -o /workspaces/.agent-state/kprog-lanes/A/xdp-entry-hosts/test_arm64_mem_offset_host
	/workspaces/.agent-state/kprog-lanes/A/xdp-entry-hosts/test_arm64_mem_offset_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_prepost_host.c -o /workspaces/.agent-state/kprog-lanes/A/xdp-entry-hosts/test_arm64_mem_prepost_host
	/workspaces/.agent-state/kprog-lanes/A/xdp-entry-hosts/test_arm64_mem_prepost_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dq_mem_extra_route_host.c -o /workspaces/.agent-state/kprog-lanes/A/xdp-entry-hosts/test_arm64_dq_mem_extra_route_host
	/workspaces/.agent-state/kprog-lanes/A/xdp-entry-hosts/test_arm64_dq_mem_extra_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_vreg_field_route_host.c -o /workspaces/.agent-state/kprog-lanes/A/xdp-entry-hosts/test_arm64_vreg_field_route_host
	/workspaces/.agent-state/kprog-lanes/A/xdp-entry-hosts/test_arm64_vreg_field_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dq_mem_route_host.c -o /workspaces/.agent-state/kprog-lanes/A/xdp-entry-hosts/test_arm64_dq_mem_route_host
	/workspaces/.agent-state/kprog-lanes/A/xdp-entry-hosts/test_arm64_dq_mem_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_pair_mem_route_host.c -o /workspaces/.agent-state/kprog-lanes/A/xdp-entry-hosts/test_arm64_pair_mem_route_host
	/workspaces/.agent-state/kprog-lanes/A/xdp-entry-hosts/test_arm64_pair_mem_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_vreg_route_host.c -o /workspaces/.agent-state/kprog-lanes/A/xdp-entry-hosts/test_arm64_vreg_route_host
	/workspaces/.agent-state/kprog-lanes/A/xdp-entry-hosts/test_arm64_vreg_route_host
