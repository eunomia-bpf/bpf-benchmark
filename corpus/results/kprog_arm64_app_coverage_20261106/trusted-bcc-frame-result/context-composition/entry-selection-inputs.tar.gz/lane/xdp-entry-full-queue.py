from pathlib import Path
import os,subprocess,time
lane=Path('/workspaces/.agent-state/kprog-lanes/A')
while True:
 active=[]
 for line in subprocess.check_output(['ps','-eo','pid,comm'],text=True).splitlines()[1:]:
  fields=line.split()
  if len(fields)!=2 or fields[1] not in {'make','gmake'}:continue
  proc=Path('/proc')/fields[0]
  try:
   args=proc.joinpath('cmdline').read_bytes().split(b'\0');cwd=Path(os.readlink(proc/'cwd'))
  except FileNotFoundError:continue
  if b'check' in args and cwd.parts[-2:]==('kprog','formal'):active.append(fields[0])
 if not active:break
 (lane/'xdp-entry-full.state').write_text('queued '+(lane/'xdp-entry-base.txt').read_text().strip()+'; active FULL pids '+','.join(active)+'\n')
 time.sleep(30)
(lane/'xdp-entry-full.state').write_text('starting '+(lane/'xdp-entry-base.txt').read_text())
raise SystemExit(subprocess.call(['taskset','-c','12-15','python3',str(lane/'xdp-entry-full.py')]))
