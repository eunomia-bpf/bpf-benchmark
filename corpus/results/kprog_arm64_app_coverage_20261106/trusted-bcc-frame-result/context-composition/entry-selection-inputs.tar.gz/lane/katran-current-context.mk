check:
	taskset -c 16-19 python3 /workspaces/.agent-state/kprog-lanes/A/katran-current-context.py
