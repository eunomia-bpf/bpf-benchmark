from pathlib import Path
import hashlib, shutil, subprocess, traceback, json, gzip
lane=Path('/workspaces/.agent-state/kprog-lanes/A')
root=Path('/workspaces/repository')
sha=(lane/'xdp-entry-base.txt').read_text().strip()
out=lane/'source-check-xdp-entry'
assert not out.exists(),out
rc=1
try:
    tree=subprocess.check_output(['git','ls-tree','-rz','--full-tree',sha],cwd=root)
    chosen=[]
    for entry in tree.split(b'\0'):
        if not entry: continue
        meta,name=entry.split(b'\t',1)
        mode,kind,obj=meta.decode().split()
        n=name.decode(); path=Path(n); parts=path.parts
        needed=(parts[:2]==('kprog','formal') or parts[:3]==('kinsn','module','include') or n=='kprog/helper_abi.py' or parts[:3]==('kprog','test','include') or (len(parts)==3 and parts[0]=='kprog' and parts[1] in {'x86','arm64'} and path.suffix in {'.h','.py','.json'}) or (len(parts)==4 and parts[0]=='kprog' and parts[1] in {'x86','arm64'} and parts[2]=='micro-prog' and path.suffix=='.py') or parts[:4]==('kprog','x86','native_lab','native_link'))
        if not needed or kind!='blob' or any(p in {'build','target','results','.lake','__pycache__'} or p.startswith('build-') for p in parts): continue
        chosen.append((n,obj))
    objects=subprocess.run(['git','cat-file','--batch'],cwd=root,input=''.join(obj+'\n' for _,obj in chosen).encode(),stdout=subprocess.PIPE,check=True).stdout
    pos=0;manifest=[]
    for n,obj in chosen:
        end=objects.index(b'\n',pos); header=objects[pos:end].decode().split(); assert header[:2]==[obj,'blob']
        size=int(header[2]);data=objects[end+1:end+1+size];assert len(data)==size
        pos=end+size+2
        target=out/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
        manifest.append(hashlib.sha256(data).hexdigest()+'  '+n+'\n')
    assert pos==len(objects)
    overlay=lane/'xdp-entry-after.h'
    rel='kprog/arm64/arm64_sim_local_bpf.h'
    (out/rel).write_bytes(overlay.read_bytes())
    manifest=[line for line in manifest if not line.endswith('  '+rel+'\n')]
    manifest.append(hashlib.sha256(overlay.read_bytes()).hexdigest()+'  '+rel+'\n')

    (out/'vendor').mkdir(parents=True)
    for name in ('libbpf','linux-framework'): (out/'vendor'/name).symlink_to(root/'vendor'/name,target_is_directory=True)
    subprocess.run(['cp','-a','--reflink=auto',str(root/'kprog/formal/.lake'),str(out/'kprog/formal/.lake')],check=True)
    (out/'kprog/formal/build').mkdir(exist_ok=True)
    subprocess.run(['cp','-a','--reflink=auto',str(root/'kprog/formal/build/native-link'),str(out/'kprog/formal/build/native-link')],check=True)
    (lane/'xdp-entry-full.sources').write_text(''.join(manifest))
    (lane/'xdp-entry-full.head').write_text(sha+'\n')
    (lane/'xdp-entry-full.state').write_text('running '+sha+'\n')
    print('Frozen',len(chosen),'candidate files at',sha,flush=True)
    with (lane/'xdp-entry-full.log').open('w') as log:
        rc=subprocess.run(['taskset','-c','12-15','make','-C',str(out/'kprog/formal'),'check'],cwd=out,stdout=log,stderr=subprocess.STDOUT).returncode
except Exception:
    traceback.print_exc()
finally:
    trace=out/'kprog/formal/build/call-reference/cpu.jsonl'
    if trace.exists(): (lane/'xdp-entry-full.cpu.jsonl.gz').write_bytes(gzip.compress(trace.read_bytes()))
    if out.exists():
        assert out.resolve().parent==lane.resolve() and out.name=='source-check-xdp-entry'
        shutil.rmtree(out)
    (lane/'xdp-entry-full.exit').write_text(str(rc)+'\n')
    (lane/'xdp-entry-full.state').write_text('finished '+str(rc)+' '+sha+'\n')
    with (lane.parent/'COORDINATION.md').open('a') as f:
        f.write('\n- A entry-selection immutable FULL ended rc='+str(rc)+' at '+sha[:9]+'. Sole FULL slot RELEASED; temporary source/cache export deleted immediately, hashes/log/exit retained at V/xdp-entry-full.*. No ROOT/source/sharedindex writes.\n')
    print('Full finished',rc,'temporary export deleted',flush=True)
