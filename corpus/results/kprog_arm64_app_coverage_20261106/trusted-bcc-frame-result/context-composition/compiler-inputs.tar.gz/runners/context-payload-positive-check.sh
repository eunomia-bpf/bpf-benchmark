#!/bin/sh
cd /workspaces/repository || exit 1
make -f - check > /workspaces/.agent-state/kprog-lanes/A/context-payload-positive-check.log 2>&1 <<'MAKE'
.PHONY: check
check:
	taskset -c 16-19 python3 /workspaces/.agent-state/kprog-lanes/A/context-payload-positive-check.py
MAKE
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/context-payload-positive-check.exit
exit "$rc"
