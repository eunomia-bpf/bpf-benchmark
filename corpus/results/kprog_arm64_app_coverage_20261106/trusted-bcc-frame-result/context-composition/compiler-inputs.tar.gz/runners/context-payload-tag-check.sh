cd /workspaces/repository
make -f /workspaces/.agent-state/kprog-lanes/A/context-payload-tag-check.mk check >/workspaces/.agent-state/kprog-lanes/A/context-payload-tag-check.log 2>&1
echo $? >/workspaces/.agent-state/kprog-lanes/A/context-payload-tag-check.exit
