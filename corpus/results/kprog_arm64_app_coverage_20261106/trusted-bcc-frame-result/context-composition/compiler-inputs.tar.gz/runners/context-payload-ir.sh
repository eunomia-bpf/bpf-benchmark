cd /workspaces/repository
make -f /workspaces/.agent-state/kprog-lanes/A/context-payload-ir.mk check >/workspaces/.agent-state/kprog-lanes/A/context-payload-ir.log 2>&1
echo $? >/workspaces/.agent-state/kprog-lanes/A/context-payload-ir.exit
