cd /workspaces/repository
make -f /workspaces/.agent-state/kprog-lanes/A/context-payload-byte-tag.mk check >/workspaces/.agent-state/kprog-lanes/A/context-payload-byte-tag.log 2>&1
echo $? >/workspaces/.agent-state/kprog-lanes/A/context-payload-byte-tag.exit
