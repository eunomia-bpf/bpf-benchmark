check:
	taskset -c 20-23 python3 /workspaces/.agent-state/kprog-lanes/A/ghost-payload-candidate.py

hosts:
	taskset -c 20-23 python3 /workspaces/.agent-state/kprog-lanes/A/ghost-candidate-hosts.py
