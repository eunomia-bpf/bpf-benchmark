from pathlib import Path
import tarfile,tempfile,subprocess,re,json,hashlib
root=Path('/workspaces/repository'); r=root/'corpus/results/kprog_arm64_app_coverage_20261106'; a=Path('/workspaces/.agent-state/kprog-lanes/A')
h=root/'kprog/arm64/arm64_sim_local_bpf.h'
old=h.read_text(); needle='\t\t\t__a64_stack_payload[KPROG_ARM64_STACK_WORD_INDEX(__a64_stw_index)] = ARM64_SIM_L_UNMATERIALIZE(__a64_stw_value, (TAG));'
assert old.count(needle)==1
new=old.replace(needle, '\t\t\tif ((TAG) == ARM64_SIM_TAG_STACK || (TAG) == ARM64_SIM_TAG_RETURN) '+needle.lstrip())
summary=dict(input_header_sha256=hashlib.sha256(h.read_bytes()).hexdigest(),cases=[])
with tempfile.TemporaryDirectory(prefix='ghost-candidate-',dir=a) as tmp:
 d=Path(tmp); header=d/'arm64_sim_local_bpf.h'; header.write_text(new)
 for app,archive,source in [('tcplife','trusted-bcc-frame-result/compiler-inputs.tar.gz','generated/worker/trusted_arm64.bpf.c'),('katran','trusted-extern-result/compiler-inputs.tar.gz','katran/trusted_arm64.bpf.c')]:
  with tarfile.open(r/archive) as t:text=t.extractfile(source).read().decode()
  text=text.replace('#include "'+str(h)+'"','#include "'+str(header)+'"')
  # Relative header includes still resolve to the canonical header directory.
  c=d/(app+'.c'); c.write_text(text); obj=d/(app+'.o')
  command=['clang','-g','-O2','-mcpu=v4','-target','bpf','-mllvm','-bpf-stack-size=4096','-D__TARGET_ARCH_arm64','-I',str(h.parent),'-I',str(root/'vendor/libbpf/include/uapi'),'-I',str(root/'vendor/libbpf/src'),'-I','/usr/include/x86_64-linux-gnu','-c',str(c),'-o',str(obj)]
  p=subprocess.run(command,text=True,capture_output=True)
  (d/(app+'.compiler.log')).write_text(p.stdout+p.stderr); p.check_returncode()
  asm=subprocess.check_output(['llvm-objdump','-d',str(obj)],text=True); (d/(app+'.asm')).write_text(asm)
  values=[int(v,0) for v in re.findall(r'r10 - (0x[0-9a-f]+|[0-9]+)',asm)]
  summary['cases'].append(dict(app=app,max_fp_minus=max(values),command=command))
 with tarfile.open(a/'ghost-payload-candidate.tar.gz','w:gz') as t:
  for f in d.iterdir():t.add(f,arcname=f.name)
summary['header_unchanged']=hashlib.sha256(h.read_bytes()).hexdigest()==summary['input_header_sha256']; assert summary['header_unchanged']
(a/'ghost-payload-candidate.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
