from pathlib import Path
import subprocess,tempfile,json,hashlib,tarfile
r=Path('/workspaces/repository'); a=Path('/workspaces/.agent-state/kprog-lanes/A'); formal=r/'kprog/formal'
with tarfile.open(a/'ghost-payload-candidate.tar.gz') as t:header_bytes=t.extractfile('arm64_sim_local_bpf.h').read()
summary=[]
with tempfile.TemporaryDirectory(prefix='ghost-hosts-',dir=a) as tmp:
 d=Path(tmp); (d/'arm64_sim_local_bpf.h').write_bytes(header_bytes); candidate=d/'arm64_sim_local_bpf.h'
 for name in ['stack_arena','stack_arm','stack_read_tag_source','stack_write_lanes','stack_write_tag_action']:
  original=formal/('oracles/test_arm64_'+name+'_route_host.c'); source=d/(name+'.c'); text=original.read_text(); assert '#include "../arm64/arm64_sim_local_bpf.h"' in text
  source.write_text(text.replace('#include "../arm64/arm64_sim_local_bpf.h"','#include "'+str(candidate)+'"'))
  binary=d/name
  command=['cc','-include','oracles/arm64_entry_environment_host.h','-DKPROG_TEST_EXCLUSIVE_FAILURE=0','-include','oracles/arm64_exclusive_choice_host.h','-Wall','-Wextra','-O2','-I.','-I../arm64','-I../../kprog','-I../../vendor/libbpf/src','-Ioracles',str(source),'-o',str(binary)]
  build=subprocess.run(command,cwd=formal,text=True,capture_output=True); (d/(name+'.compile.log')).write_text(build.stdout+build.stderr); build.check_returncode()
  run=subprocess.run([binary],cwd=formal,text=True,capture_output=True); (d/(name+'.run.log')).write_text(run.stdout+run.stderr); run.check_returncode()
  summary.append(dict(case=name,compile=build.returncode,run=run.returncode,stdout=run.stdout))
 with tarfile.open(a/'ghost-candidate-hosts.tar.gz','w:gz') as t:
  for p in d.iterdir():
   if p.suffix in {'.c','.h','.log'}:t.add(p,arcname=p.name)
(a/'ghost-candidate-hosts.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
