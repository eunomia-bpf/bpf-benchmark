
/workspaces/repository/vendor/build/arm64/linux/vmlinux:	file format elf64-littleaarch64

Disassembly of section .text:

ffff800080c7b248 <xdp_convert_ctx_access>:
ffff800080c7b248: d503201f     	nop
ffff800080c7b24c: d503201f     	nop
ffff800080c7b250: 79c00420     	ldrsh	w0, [x1, #0x2]
ffff800080c7b254: 7100301f     	cmp	w0, #0xc
ffff800080c7b258: 54000b20     	b.eq	0xffff800080c7b3bc <xdp_convert_ctx_access+0x174>
ffff800080c7b25c: 540001cc     	b.gt	0xffff800080c7b294 <xdp_convert_ctx_access+0x4c>
ffff800080c7b260: 7100101f     	cmp	w0, #0x4
ffff800080c7b264: 540009a0     	b.eq	0xffff800080c7b398 <xdp_convert_ctx_access+0x150>
ffff800080c7b268: 7100201f     	cmp	w0, #0x8
ffff800080c7b26c: 54000840     	b.eq	0xffff800080c7b374 <xdp_convert_ctx_access+0x12c>
ffff800080c7b270: 35000540     	cbnz	w0, 0xffff800080c7b318 <xdp_convert_ctx_access+0xd0>
ffff800080c7b274: 39400420     	ldrb	w0, [x1, #0x1]
ffff800080c7b278: 52800f21     	mov	w1, #0x79       // =121
ffff800080c7b27c: 39000041     	strb	w1, [x2]
ffff800080c7b280: 39000440     	strb	w0, [x2, #0x1]
ffff800080c7b284: 52800020     	mov	w0, #0x1        // =1
ffff800080c7b288: 7900045f     	strh	wzr, [x2, #0x2]
ffff800080c7b28c: b900045f     	str	wzr, [x2, #0x4]
ffff800080c7b290: d65f03c0     	ret
ffff800080c7b294: 7100401f     	cmp	w0, #0x10
ffff800080c7b298: 54000440     	b.eq	0xffff800080c7b320 <xdp_convert_ctx_access+0xd8>
ffff800080c7b29c: 7100501f     	cmp	w0, #0x14
ffff800080c7b2a0: 540003c1     	b.ne	0xffff800080c7b318 <xdp_convert_ctx_access+0xd0>
ffff800080c7b2a4: 39400424     	ldrb	w4, [x1, #0x1]
ffff800080c7b2a8: 52800f20     	mov	w0, #0x79       // =121
ffff800080c7b2ac: 52800503     	mov	w3, #0x28       // =40
ffff800080c7b2b0: 39000040     	strb	w0, [x2]
ffff800080c7b2b4: 52800c26     	mov	w6, #0x61       // =97
ffff800080c7b2b8: 39000444     	strb	w4, [x2, #0x1]
ffff800080c7b2bc: 52801c05     	mov	w5, #0xe0       // =224
ffff800080c7b2c0: 79000443     	strh	w3, [x2, #0x2]
ffff800080c7b2c4: b900045f     	str	wzr, [x2, #0x4]
ffff800080c7b2c8: 39402443     	ldrb	w3, [x2, #0x9]
ffff800080c7b2cc: b9400024     	ldr	w4, [x1]
ffff800080c7b2d0: 39002040     	strb	w0, [x2, #0x8]
ffff800080c7b2d4: 7900145f     	strh	wzr, [x2, #0xa]
ffff800080c7b2d8: d3482c84     	ubfx	x4, x4, #8, #4
ffff800080c7b2dc: b9000c5f     	str	wzr, [x2, #0xc]
ffff800080c7b2e0: 39404440     	ldrb	w0, [x2, #0x11]
ffff800080c7b2e4: 33000c83     	bfxil	w3, w4, #0, #4
ffff800080c7b2e8: 331c0c83     	bfi	w3, w4, #4, #4
ffff800080c7b2ec: 39002443     	strb	w3, [x2, #0x9]
ffff800080c7b2f0: b9400021     	ldr	w1, [x1]
ffff800080c7b2f4: 39004046     	strb	w6, [x2, #0x10]
ffff800080c7b2f8: 79002445     	strh	w5, [x2, #0x12]
ffff800080c7b2fc: d3482c21     	ubfx	x1, x1, #8, #4
ffff800080c7b300: b900145f     	str	wzr, [x2, #0x14]
ffff800080c7b304: 33000c20     	bfxil	w0, w1, #0, #4
ffff800080c7b308: 331c0c20     	bfi	w0, w1, #4, #4
ffff800080c7b30c: 39004440     	strb	w0, [x2, #0x11]
ffff800080c7b310: 52800060     	mov	w0, #0x3        // =3
ffff800080c7b314: d65f03c0     	ret
ffff800080c7b318: 52800000     	mov	w0, #0x0        // =0
ffff800080c7b31c: d65f03c0     	ret
ffff800080c7b320: 39400423     	ldrb	w3, [x1, #0x1]
ffff800080c7b324: 52800f24     	mov	w4, #0x79       // =121
ffff800080c7b328: 52800400     	mov	w0, #0x20       // =32
ffff800080c7b32c: 39000044     	strb	w4, [x2]
ffff800080c7b330: 39000443     	strb	w3, [x2, #0x1]
ffff800080c7b334: 52800c26     	mov	w6, #0x61       // =97
ffff800080c7b338: 79000440     	strh	w0, [x2, #0x2]
ffff800080c7b33c: 52800105     	mov	w5, #0x8        // =8
ffff800080c7b340: b900045f     	str	wzr, [x2, #0x4]
ffff800080c7b344: 52800040     	mov	w0, #0x2        // =2
ffff800080c7b348: 39402443     	ldrb	w3, [x2, #0x9]
ffff800080c7b34c: b9400024     	ldr	w4, [x1]
ffff800080c7b350: 39002046     	strb	w6, [x2, #0x8]
ffff800080c7b354: 79001445     	strh	w5, [x2, #0xa]
ffff800080c7b358: d3482c84     	ubfx	x4, x4, #8, #4
ffff800080c7b35c: b9000c5f     	str	wzr, [x2, #0xc]
ffff800080c7b360: 33000c83     	bfxil	w3, w4, #0, #4
ffff800080c7b364: 2a0303e1     	mov	w1, w3
ffff800080c7b368: 331c0c81     	bfi	w1, w4, #4, #4
ffff800080c7b36c: 39002441     	strb	w1, [x2, #0x9]
ffff800080c7b370: d65f03c0     	ret
ffff800080c7b374: 39400421     	ldrb	w1, [x1, #0x1]
ffff800080c7b378: 52800200     	mov	w0, #0x10       // =16
ffff800080c7b37c: 52800f23     	mov	w3, #0x79       // =121
ffff800080c7b380: 39000043     	strb	w3, [x2]
ffff800080c7b384: 39000441     	strb	w1, [x2, #0x1]
ffff800080c7b388: 79000440     	strh	w0, [x2, #0x2]
ffff800080c7b38c: 52800020     	mov	w0, #0x1        // =1
ffff800080c7b390: b900045f     	str	wzr, [x2, #0x4]
ffff800080c7b394: 17ffffbf     	b	0xffff800080c7b290 <xdp_convert_ctx_access+0x48>
ffff800080c7b398: 39400421     	ldrb	w1, [x1, #0x1]
ffff800080c7b39c: 52800100     	mov	w0, #0x8        // =8
ffff800080c7b3a0: 52800f23     	mov	w3, #0x79       // =121
ffff800080c7b3a4: 39000043     	strb	w3, [x2]
ffff800080c7b3a8: 39000441     	strb	w1, [x2, #0x1]
ffff800080c7b3ac: 79000440     	strh	w0, [x2, #0x2]
ffff800080c7b3b0: 52800020     	mov	w0, #0x1        // =1
ffff800080c7b3b4: b900045f     	str	wzr, [x2, #0x4]
ffff800080c7b3b8: 17ffffb6     	b	0xffff800080c7b290 <xdp_convert_ctx_access+0x48>
ffff800080c7b3bc: 39400424     	ldrb	w4, [x1, #0x1]
ffff800080c7b3c0: 52800f20     	mov	w0, #0x79       // =121
ffff800080c7b3c4: 52800403     	mov	w3, #0x20       // =32
ffff800080c7b3c8: 17ffffba     	b	0xffff800080c7b2b0 <xdp_convert_ctx_access+0x68>
ffff800080c7b3cc: d503201f     	nop
ffff800080c7b3d0: d503201f     	nop
ffff800080c7b3d4: d503201f     	nop
