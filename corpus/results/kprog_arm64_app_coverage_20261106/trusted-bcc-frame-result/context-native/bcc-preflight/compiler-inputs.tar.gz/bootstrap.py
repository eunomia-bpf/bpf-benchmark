"""Use the existing BCC compiler-frame reproduction with the frozen context/compact worker."""
from pathlib import Path
import importlib.util
import sys
H=Path('/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106')
sys.path.insert(0,str(H))
import trusted_context_memory as context
sys.path.insert(0,str(context.ROOT/'kprog'))
import trusted_service
spec=importlib.util.spec_from_file_location('bcc_frame_preflight',H/'trusted_bcc_frame.py')
frame=importlib.util.module_from_spec(spec)
spec.loader.exec_module(frame)
frame.worker=context.candidate.adapter(trusted_service)
frame.HERE=Path(__file__).resolve().parent
if __name__=='__main__':
    frame.main()
