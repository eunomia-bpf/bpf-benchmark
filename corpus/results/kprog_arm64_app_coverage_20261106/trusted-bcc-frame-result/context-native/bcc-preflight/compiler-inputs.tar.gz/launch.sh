#!/bin/sh
cd /workspaces/repository
PYTHONDONTWRITEBYTECODE=1 taskset -c 20-23 make -f corpus/results/kprog_arm64_app_coverage_20261106/Makefile trusted-bcc-frame-check HERE=/workspaces/repository/kprog/arm64/build/trusted-transport/bcc-compact-preflight
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/bcc-compact-preflight.exit
exit "$rc"
