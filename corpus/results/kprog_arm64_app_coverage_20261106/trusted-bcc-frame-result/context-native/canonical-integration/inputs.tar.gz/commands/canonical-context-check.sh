#!/bin/sh
cd /workspaces/repository
PYTHONDONTWRITEBYTECODE=1 taskset -c 8-11 make -f corpus/results/kprog_arm64_app_coverage_20261106/Makefile trusted-bcc-frame-check HERE=/workspaces/repository/kprog/arm64/build/trusted-transport/canonical-context
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/canonical-context-check.exit
exit "$rc"
