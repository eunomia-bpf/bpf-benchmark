from pathlib import Path
import hashlib,io,json,subprocess,sys,tarfile,traceback
from elftools.elf.elffile import ELFFile
from elftools.elf.relocation import RelocationSection
ROOT=Path('/workspaces/repository'); OUT=ROOT/'kprog/arm64/build/trusted-transport/canonical-context'
sys.path.insert(0,str(ROOT/'kprog/arm64'))
import trusted_specializer as worker
result={'scope':'canonical source/preprocessing and compiled executable/relocation identity against actual frozen worker; no new kernel run', 'requests':[]}
def sha(data):return hashlib.sha256(data).hexdigest()
def nested(path):
 with tarfile.open(path) as outer:
  for m in outer.getmembers():
   if m.isfile() and m.name.endswith(('.success.tar.gz','.refused.tar.gz','.failure.tar.gz')):
    yield m.name,tarfile.open(fileobj=io.BytesIO(outer.extractfile(m).read()))
def contents(t):return {m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
def compiled(data):
 elf=ELFFile(io.BytesIO(data)); executable={s.name:sha(s.data()) for s in elf.iter_sections() if s['sh_flags']&4}
 relocations=[]
 for section in elf.iter_sections():
  if isinstance(section,RelocationSection) and elf.get_section(section['sh_info'])['sh_flags']&4:
   symbols=elf.get_section(section['sh_link'])
   for rel in section.iter_relocations():
    sym=symbols.get_symbol(rel['r_info_sym'])
    relocations.append([section.name,rel['r_offset'],rel['r_info_type'],sym.name,rel.entry.get('r_addend')])
 return dict(executable=executable,relocations=relocations)
def cpp(path):
 command=['clang','-E','-P','-mcpu=v4','-target','bpf','-D__TARGET_ARCH_arm64','-I',str(ROOT/'vendor/libbpf/include/uapi'),'-I',str(ROOT/'vendor/libbpf/src'),'-I','/usr/include/x86_64-linux-gnu',str(path)]
 r=subprocess.run(command,capture_output=True)
 if r.returncode:raise RuntimeError(r.stderr.decode())
 return r.stdout
base=ROOT/'corpus/results/kprog_arm64_app_coverage_20261106/trusted-bcc-frame-result/context-native'
for kind in ['service','katran']:
 archive=next((base/('trusted-arm64-'+kind+'-result')).glob('run-*.tar.gz'))
 for name,t in nested(archive):
  data=contents(t); t.close()
  proof=data.get('request/generated/trusted_arm64.proof.o')
  if proof is None:
   raise RuntimeError('no proof input for '+name)
  folder=OUT/'source-audit'/kind/Path(name).name.removesuffix('.tar.gz');folder.mkdir(parents=True,exist_ok=True)
  (folder/'trusted_arm64.proof.o').write_bytes(proof)
  metadata=json.loads(data['request/generation.metadata.json'])
  symbol=data['request/kernel.entry'].decode().strip('\x00\n ')
  rec={'kind':kind,'request':name,'entry':symbol,'proof_sha256':sha(proof)}
  try:
   functions,rodata=worker.gen.parse_native_linked_program(worker.gen.Bench('trusted_arm64',symbol,'raw'),folder)
   text=worker.gen.render_program('trusted_arm64',symbol,functions,{6:'xdp',3:'tc',8:'cgroup_skb'}.get(metadata['prog_type'],'raw'),rodata16=rodata,linked_exit=True,program_section=metadata['section'],trusted_map_bindings=[dict(native_symbol=m['name'],value_offset=m.get('value_offset')) for m in metadata['maps']])
   text=text.replace('#include "../arm64_sim_local_bpf.h"','#include '+json.dumps(str(ROOT/'kprog/arm64/arm64_sim_local_bpf.h')))
   (folder/'canonical.bpf.c').write_text(text)
   old=data.get('request/generated/trusted_arm64.bpf.c')
   if old is None:raise RuntimeError('canonical generated for formerly refused source')
   (folder/'frozen.bpf.c').write_bytes(old)
   before,after=cpp(folder/'frozen.bpf.c'),cpp(folder/'canonical.bpf.c')
   rec.update(generated=True,preprocessed_identical=before==after,frozen_preprocessed_sha256=sha(before),canonical_preprocessed_sha256=sha(after))
   if before!=after:
    (folder/'frozen.i').write_bytes(before);(folder/'canonical.i').write_bytes(after)
    raise RuntimeError('preprocessing differs '+name)
  except ValueError as e:
   if 'request/generated/trusted_arm64.bpf.c' in data:raise
   rec.update(generated=False,specialization_error=str(e),frozen_refused=True)
  result['requests'].append(rec)
  print(kind,name,rec.get('preprocessed_identical',rec.get('specialization_error')),flush=True)
# Same real tcplife native source and same compiler flags, different include/debug paths.
with tarfile.open(base/'bcc-preflight/compiler-inputs.tar.gz') as outer:
 member=next(m for m in outer.getmembers() if m.name.endswith('compiler-run.tar.gz'))
 with tarfile.open(fileobj=io.BytesIO(outer.extractfile(member).read())) as inner:
  oldobj=next(inner.extractfile(m).read() for m in inner.getmembers() if m.name.endswith('/trusted_arm64.bpf.o'))
with tarfile.open(OUT/'trusted-bcc-frame-result/compiler-inputs.tar.gz') as t:
 newobj=next(t.extractfile(m).read() for m in t.getmembers() if m.name.endswith('/trusted_arm64.bpf.o'))
a,b=compiled(oldobj),compiled(newobj)
result['tcplife']={'executable_and_relocations_identical':a==b,'frozen':a,'canonical':b,'canonical_frame_bytes':352}
assert a==b,result['tcplife']
assert len(result['requests'])==46,len(result['requests'])
result['ok']=True
result['source_pins']={str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p):sha(p.read_bytes()) for p in [ROOT/'kprog/arm64/arm64_sim_local_bpf.h',ROOT/'kprog/arm64/arm64_sim_direct.h',ROOT/'kprog/arm64/micro-prog/arm64_abi.py',ROOT/'kprog/arm64/micro-prog/generate_micro_sim_proofs.py',Path(__file__)]}
(OUT/'source-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS46 source/admission cases + tcplife executable/relocation identity',flush=True)
