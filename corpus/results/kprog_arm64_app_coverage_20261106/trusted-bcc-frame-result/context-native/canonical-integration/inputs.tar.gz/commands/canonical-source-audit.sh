#!/bin/sh
cd /workspaces/repository
PYTHONDONTWRITEBYTECODE=1 make -f - check <<'M'
.PHONY: check
check:
	taskset -c 8-11 python3 /workspaces/.agent-state/kprog-lanes/A/canonical-source-audit.py
M
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/canonical-source-audit.exit
exit "$rc"
