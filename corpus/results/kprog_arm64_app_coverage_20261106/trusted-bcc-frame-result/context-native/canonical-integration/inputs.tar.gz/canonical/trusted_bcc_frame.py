import importlib.util
from pathlib import Path
import sys
root=Path('/workspaces/repository')
path=root/'corpus/results/kprog_arm64_app_coverage_20261106/trusted_bcc_frame.py'
sys.path.insert(0,str(path.parent))
spec=importlib.util.spec_from_file_location('canonical_bcc_frame',path)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.HERE=Path(__file__).resolve().parent
module.main()
