"""Temporary safety bootstrap; reuse the exact worker and unchanged45 native cases."""
from pathlib import Path
import sys
import subprocess
HERE=Path('/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106')
sys.path.insert(0,str(HERE))
import trusted_context_memory as context

def guest(live):
    suite=context.load('context_parallel_safety',HERE/'trusted_payload_negative.py')
    suite.candidate=context.candidate
    suite.BUILD=context.D/'safety-inputs'
    original=subprocess.Popen
    def start(command,*args,**kwargs):
        if len(command)>1 and Path(command[1])==HERE/'trusted_payload_check.py':
            command=list(command)
            command[1]=str(HERE/'trusted_context_memory.py')
        return original(command,*args,**kwargs)
    subprocess.Popen=start
    suite.guest(Path(live))

if sys.argv[1:]==['host','safety']:
    transport=context.transport()
    transport.__file__=__file__
    transport.host('control')
elif len(sys.argv)==4 and sys.argv[1]=='guest' and sys.argv[3]=='control':
    guest(sys.argv[2])
else:
    raise SystemExit('usage: temporary context safety bootstrap host safety | guest LIVE control')
