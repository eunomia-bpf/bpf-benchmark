#!/bin/sh
cd /workspaces/repository
make -f corpus/results/kprog_arm64_app_coverage_20261106/Makefile trusted-context-memory-safety-run HERE=/workspaces/repository/kprog/arm64/build/trusted-transport/context-memory-read
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/context-memory-parallel-safety.exit
exit "$rc"
