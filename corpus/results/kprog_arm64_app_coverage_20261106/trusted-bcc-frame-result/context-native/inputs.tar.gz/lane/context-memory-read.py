from pathlib import Path
import difflib,hashlib,io,json,os,re,subprocess,tarfile
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A')
old=R/'kprog/arm64/build/trusted-transport/payload-candidate'
D=R/'kprog/arm64/build/trusted-transport/context-memory-read'
D.mkdir(exist_ok=False)
H=R/'kprog/arm64/arm64_sim_local_bpf.h'
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prefix=str(old/'includes')+'/'
def restore(m):
 assert m[1].startswith(prefix)
 return '#include "'+os.path.relpath(R/m[1][len(prefix):],H.parent)+'"'
compact=re.sub(r'^#include "([^"\n]+)"',restore,(old/'arm64_sim_local_bpf.h').read_text(),flags=re.M)
baseline=subprocess.check_output(['git','show','b2b6f28d9^:kprog/arm64/arm64_sim_local_bpf.h'],text=True)
patch='\n'.join(difflib.unified_diff(baseline.splitlines(),compact.splitlines(),fromfile='baseline',tofile='compact'))+'\n'
merged=D/'arm64_sim_local_bpf.h';merged.write_text(H.read_text())
subprocess.run(['patch','--batch',str(merged)],input=patch,text=True,check=True)
pins={}
def freeze(path):
 path=path.resolve();rel=path.relative_to(R);dest=D/'includes'/rel
 if str(rel) in pins:return dest
 pins[str(rel)]=hashfile(path);dest.parent.mkdir(parents=True,exist_ok=True)
 body=re.sub(r'^#include "([^"\n]+)"',lambda m:'#include '+json.dumps(str(freeze(path.parent/m[1]))),path.read_text(),flags=re.M)
 dest.write_text(body);return dest
text=re.sub(r'^#include "([^"\n]+)"',lambda m:'#include '+json.dumps(str(freeze(H.parent/m[1]))),merged.read_text(),flags=re.M)
text=text.replace('extern void arm64_sim_unmapped_xdp_read(void)'+chr(10)+'    __attribute__((error("unmapped native XDP context read")));'+chr(10),'')
needle='    else arm64_sim_unmapped_xdp_read(); '
assert text.count(needle)==1
text=text.replace(needle,'    else __a64_xdp_value = KPROG_ARM64_LOAD_BYTES_OFFSET(ARM64_SIM_L_READ_REG_PTR(BASE), (OFF), (WIDTH)); ')
merged.write_text(text)
O=R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted-bcc-frame-result/trusted-arm64-katran-result'
s=json.loads((O/'summary.json').read_text());archive=O/s['archive'];assert hashfile(archive)==s['archive_sha256']
with tarfile.open(archive) as outer:
 with tarfile.open(fileobj=io.BytesIO(outer.extractfile('run/requests/1.success.tar.gz').read())) as inner:
  source=inner.extractfile('request/generated/trusted_arm64.bpf.c').read().decode()
  native=inner.extractfile('request/kernel.native.o').read()
oldinclude='#include '+json.dumps(str(old/'arm64_sim_local_bpf.h'))
assert source.count(oldinclude)==1
source=source.replace(oldinclude,'#include '+json.dumps(str(merged)))
c=D/'katran.bpf.c';obj=D/'katran.bpf.o';c.write_text(source)
command=['clang','-g','-O2','-mcpu=v4','-target','bpf','-mllvm','-bpf-stack-size=4096','-D__TARGET_ARCH_arm64','-I',str(R/'vendor/libbpf/include/uapi'),'-I',str(R/'vendor/libbpf/src'),'-I','/usr/include/x86_64-linux-gnu','-c',str(c),'-o',str(obj)]
report=dict(scope='positive Katran host compilation only; production context-identity fix plus frozen compact ghost-payload header changes',production_header_sha256=hashfile(H),compact_header_sha256=hashfile(old/'arm64_sim_local_bpf.h'),merged_header_sha256=hashfile(merged),dependencies=pins,native_sha256=hashlib.sha256(native).hexdigest(),source_archive_sha256=s['archive_sha256'],command=command)
(D/'inputs.json').write_text(json.dumps(report,indent=2)+'\n')
done=subprocess.run(command,capture_output=True,text=True)
(D/'compiler.log').write_text(done.stdout+done.stderr);report['compile_returncode']=done.returncode
if done.returncode==0:
 dump=subprocess.check_output(['llvm-objdump','-d',str(obj)],text=True);(D/'katran.asm').write_text(dump)
 report['max_fp_minus']=max([0]+[int(x,0) for x in re.findall(r'r10 - (0x[0-9a-f]+|[0-9]+)',dump)])
 report['object_sha256']=hashfile(obj)
report['source_inputs_unchanged']=hashfile(H)==report['production_header_sha256'] and hashfile(old/'arm64_sim_local_bpf.h')==report['compact_header_sha256'] and all(hashfile(R/p)==v for p,v in pins.items())
(D/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k in ['scope','compile_returncode','max_fp_minus','source_inputs_unchanged']}),flush=True)
done.check_returncode()
