check:
	taskset -c 20-23 python3 /workspaces/.agent-state/kprog-lanes/A/context-memory-read.py
