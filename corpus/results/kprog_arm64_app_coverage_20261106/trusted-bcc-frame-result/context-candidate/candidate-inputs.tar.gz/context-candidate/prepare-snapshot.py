from pathlib import Path
import hashlib,json,re
R=Path('/workspaces/repository')
D=R/'kprog/arm64/build/trusted-transport/context-candidate'
D.mkdir(exist_ok=False)
source=R/'kprog/arm64/arm64_sim_local_bpf.h';text=source.read_text()
# Architectural X0 keeps real context identity, including scalarized aliases.
old='__a64_x0.ptr = &__a64_sim_abi;'
assert text.count(old)==2
text=text.replace(old,'__a64_x0.ptr = (void *)(CTX);',1)
anchor='#define ARM64_SIM_L_MEM_READ(BASE, INDEX, AUX, IMM, EXTRA, WIDTH)'
assert text.count(anchor)==1
macro=r'''/* Native XDP pointer fields are 64-bit; BPF ctx access uses typed fields.
 * Unknown native fields fail compilation instead of reading zero padding. */
extern void arm64_sim_unmapped_xdp_read(void)
    __attribute__((error("unmapped native XDP context read")));
#define ARM64_SIM_L_XDP_READ(BASE, OFF, WIDTH) \
 ({ __s64 __a64_xdp_off = (__s64)((__u8 *)ARM64_SIM_L_READ_REG_PTR(BASE) - (__u8 *)__a64_sim_helper_ctx) + (OFF); \
    struct xdp_md *__a64_xdp_ctx = __a64_sim_helper_ctx; \
    __u64 __a64_xdp_value = 0; \
    if ((WIDTH) == ARM64_WIDTH_64 && __a64_xdp_off == KPROG_ABI_XDP_DATA_OFF) \
        __a64_xdp_value = (__u64)(long)(void *)(long)__a64_xdp_ctx->data; \
    else if ((WIDTH) == ARM64_WIDTH_64 && __a64_xdp_off == KPROG_ABI_XDP_DATA_END_OFF) \
        __a64_xdp_value = (__u64)(long)(void *)(long)__a64_xdp_ctx->data_end; \
    else arm64_sim_unmapped_xdp_read(); \
    __a64_xdp_value; })

'''
text=text.replace(anchor,macro+anchor)
anchor='switch (__a64_mrd_src) {'
assert text.count(anchor)==1
replacement=r'''if (__a64_sim_abi_kind == KPROG_ABI_KIND_XDP && __a64_mrd_tag == ARM64_SIM_TAG_ABI) { \
            __a64_mrd_value = ARM64_SIM_L_XDP_READ((BASE), __a64_mrd_off, (WIDTH)); \
        } else switch (__a64_mrd_src) {'''
text=text.replace(anchor,replacement)
anchor='__a64_sim_abi_kind, __a64_mrt_off,'
assert text.count(anchor)==1
text=text.replace(anchor,'__a64_sim_abi_kind, (__a64_sim_abi_kind == KPROG_ABI_KIND_XDP ? (__s64)((__u8 *)ARM64_SIM_L_READ_REG_PTR(BASE) - (__u8 *)__a64_sim_helper_ctx) : 0) + __a64_mrt_off,')
pins={}
def freeze(path):
 path=path.resolve();rel=path.relative_to(R);dest=D/'includes'/rel
 if str(rel) in pins:return dest
 pins[str(rel)]=hashlib.sha256(path.read_bytes()).hexdigest();dest.parent.mkdir(parents=True,exist_ok=True)
 body=path.read_text()
 body=re.sub(r'^#include "([^"\n]+)"',lambda m:'#include '+json.dumps(str(freeze(path.parent/m[1]))),body,flags=re.M)
 dest.write_text(body);return dest
text=re.sub(r'^#include "([^"\n]+)"',lambda m:'#include '+json.dumps(str(freeze(source.parent/m[1]))),text,flags=re.M)
(D/'arm64_sim_local_bpf.h').write_text(text)
(D/'source-pins.json').write_text(json.dumps(dict(original_header=hashlib.sha256(source.read_bytes()).hexdigest(),dependencies=pins),indent=2)+'\n')
print('frozen',D,'dependencies',len(pins))
