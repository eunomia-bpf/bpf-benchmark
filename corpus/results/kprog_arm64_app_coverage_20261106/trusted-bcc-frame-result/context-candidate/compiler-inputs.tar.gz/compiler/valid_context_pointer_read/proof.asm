
/workspaces/repository/kprog/arm64/build/trusted-transport/context-candidate/compiler/valid_context_pointer_read/generated/trusted_arm64.bpf.o:	file format elf64-bpf

Disassembly of section xdp:

0000000000000000 <trusted_arm64_arm64_sim_xdp>:
       0:	bf 12 00 00 00 00 00 00	r2 = r1
       1:	07 02 00 00 08 00 00 00	r2 += 0x8
       2:	1d 12 06 00 00 00 00 00	if r2 == r1 goto +0x6 <LBB0_3>
       3:	61 12 00 00 00 00 00 00	r2 = *(u32 *)(r1 + 0x0)
       4:	bf 23 00 00 00 00 00 00	r3 = r2
       5:	07 03 00 00 04 00 00 00	r3 += 0x4
       6:	61 11 04 00 00 00 00 00	r1 = *(u32 *)(r1 + 0x4)
       7:	2d 13 01 00 00 00 00 00	if r3 > r1 goto +0x1 <LBB0_3>
       8:	61 21 00 00 00 00 00 00	r1 = *(u32 *)(r2 + 0x0)

0000000000000048 <LBB0_3>:
       9:	b4 00 00 00 02 00 00 00	w0 = 0x2
      10:	95 00 00 00 00 00 00 00	exit
