
/workspaces/repository/kprog/arm64/build/trusted-transport/context-candidate/compiler/context_alias_write/generated/trusted_arm64.bpf.o:	file format elf64-bpf

Disassembly of section xdp:

0000000000000000 <trusted_arm64_arm64_sim_xdp>:
       0:	07 01 00 00 08 00 00 00	r1 += 0x8
       1:	b7 02 00 00 00 00 00 00	r2 = 0x0
       2:	7b 21 00 00 00 00 00 00	*(u64 *)(r1 + 0x0) = r2
       3:	b4 00 00 00 02 00 00 00	w0 = 0x2
       4:	95 00 00 00 00 00 00 00	exit
