
/workspaces/repository/kprog/arm64/build/trusted-transport/context-candidate/compiler/context_buffer_helper/generated/trusted_arm64.bpf.o:	file format elf64-bpf

Disassembly of section xdp:

0000000000000000 <trusted_arm64_arm64_sim_xdp>:
       0:	7a 0a f8 ff 00 00 00 00	*(u64 *)(r10 - 0x8) = 0x0
       1:	7a 0a e8 ff 00 00 00 00	*(u64 *)(r10 - 0x18) = 0x0
       2:	79 a2 e8 ff 00 00 00 00	r2 = *(u64 *)(r10 - 0x18)
       3:	57 02 00 00 00 ff ff ff	r2 &= -0x100
       4:	7b 2a e8 ff 00 00 00 00	*(u64 *)(r10 - 0x18) = r2
       5:	b7 90 03 00 02 00 00 00	<unknown>
       6:	7b 0a f0 ff 00 00 00 00	*(u64 *)(r10 - 0x10) = r0
       7:	79 a2 e8 ff 00 00 00 00	r2 = *(u64 *)(r10 - 0x18)
       8:	57 02 00 00 ff 00 ff ff	r2 &= -0xff01
       9:	47 02 00 00 00 0a 00 00	r2 |= 0xa00
      10:	7b 2a e8 ff 00 00 00 00	*(u64 *)(r10 - 0x18) = r2
      11:	b4 02 00 00 08 00 00 00	w2 = 0x8
      12:	85 00 00 00 10 00 00 00	call 0x10
      13:	79 a1 f8 ff 00 00 00 00	r1 = *(u64 *)(r10 - 0x8)
      14:	79 a1 f0 ff 00 00 00 00	r1 = *(u64 *)(r10 - 0x10)
      15:	79 a1 e8 ff 00 00 00 00	r1 = *(u64 *)(r10 - 0x18)
      16:	79 a1 e8 ff 00 00 00 00	r1 = *(u64 *)(r10 - 0x18)
      17:	57 01 00 00 00 ff 00 00	r1 &= 0xff00
      18:	15 01 01 00 00 0a 00 00	if r1 == 0xa00 goto +0x1 <LBB0_2>
      19:	85 00 00 00 ff ff ff ff	call -0x1

00000000000000a0 <LBB0_2>:
      20:	b4 00 00 00 02 00 00 00	w0 = 0x2
      21:	95 00 00 00 00 00 00 00	exit
