
/workspaces/repository/kprog/arm64/build/trusted-transport/context-candidate/compiler/context_scalar_alias_write/generated/trusted_arm64.bpf.o:	file format elf64-bpf

Disassembly of section xdp:

0000000000000000 <trusted_arm64_arm64_sim_xdp>:
       0:	b7 02 00 00 00 00 00 00	r2 = 0x0
       1:	7b 21 00 00 00 00 00 00	*(u64 *)(r1 + 0x0) = r2
       2:	b4 00 00 00 02 00 00 00	w0 = 0x2
       3:	95 00 00 00 00 00 00 00	exit
