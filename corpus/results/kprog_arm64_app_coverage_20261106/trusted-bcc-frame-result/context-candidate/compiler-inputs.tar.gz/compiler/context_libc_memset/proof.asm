
/workspaces/repository/kprog/arm64/build/trusted-transport/context-candidate/compiler/context_libc_memset/generated/trusted_arm64.bpf.o:	file format elf64-bpf

Disassembly of section xdp:

0000000000000000 <trusted_arm64_arm64_sim_xdp>:
       0:	7a 0a f8 ff 00 00 00 00	*(u64 *)(r10 - 0x8) = 0x0
       1:	7a 0a e8 ff 00 00 00 00	*(u64 *)(r10 - 0x18) = 0x0
       2:	79 a2 e8 ff 00 00 00 00	r2 = *(u64 *)(r10 - 0x18)
       3:	57 02 00 00 00 ff ff ff	r2 &= -0x100
       4:	7b 2a e8 ff 00 00 00 00	*(u64 *)(r10 - 0x18) = r2
       5:	b7 90 03 00 02 00 00 00	<unknown>
       6:	7b 0a f0 ff 00 00 00 00	*(u64 *)(r10 - 0x10) = r0
       7:	79 a2 e8 ff 00 00 00 00	r2 = *(u64 *)(r10 - 0x18)
       8:	57 02 00 00 ff 00 ff ff	r2 &= -0xff01
       9:	47 02 00 00 00 0a 00 00	r2 |= 0xa00
      10:	7b 2a e8 ff 00 00 00 00	*(u64 *)(r10 - 0x18) = r2
      11:	72 01 05 00 00 00 00 00	*(u8 *)(r1 + 0x5) = 0x0
      12:	72 01 04 00 00 00 00 00	*(u8 *)(r1 + 0x4) = 0x0
      13:	72 01 07 00 00 00 00 00	*(u8 *)(r1 + 0x7) = 0x0
      14:	72 01 06 00 00 00 00 00	*(u8 *)(r1 + 0x6) = 0x0
      15:	72 01 01 00 00 00 00 00	*(u8 *)(r1 + 0x1) = 0x0
      16:	72 01 00 00 00 00 00 00	*(u8 *)(r1 + 0x0) = 0x0
      17:	72 01 03 00 00 00 00 00	*(u8 *)(r1 + 0x3) = 0x0
      18:	72 01 02 00 00 00 00 00	*(u8 *)(r1 + 0x2) = 0x0
      19:	79 a1 f8 ff 00 00 00 00	r1 = *(u64 *)(r10 - 0x8)
      20:	79 a1 f0 ff 00 00 00 00	r1 = *(u64 *)(r10 - 0x10)
      21:	79 a1 e8 ff 00 00 00 00	r1 = *(u64 *)(r10 - 0x18)
      22:	79 a1 e8 ff 00 00 00 00	r1 = *(u64 *)(r10 - 0x18)
      23:	57 01 00 00 00 ff 00 00	r1 &= 0xff00
      24:	15 01 01 00 00 0a 00 00	if r1 == 0xa00 goto +0x1 <LBB0_2>
      25:	85 00 00 00 ff ff ff ff	call -0x1

00000000000000d0 <LBB0_2>:
      26:	b4 00 00 00 02 00 00 00	w0 = 0x2
      27:	95 00 00 00 00 00 00 00	exit
