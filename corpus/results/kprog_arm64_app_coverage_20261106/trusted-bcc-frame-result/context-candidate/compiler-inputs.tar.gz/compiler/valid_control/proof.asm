
/workspaces/repository/kprog/arm64/build/trusted-transport/context-candidate/compiler/valid_control/generated/trusted_arm64.bpf.o:	file format elf64-bpf

Disassembly of section xdp:

0000000000000000 <trusted_arm64_arm64_sim_xdp>:
       0:	b4 00 00 00 02 00 00 00	w0 = 0x2
       1:	95 00 00 00 00 00 00 00	exit
