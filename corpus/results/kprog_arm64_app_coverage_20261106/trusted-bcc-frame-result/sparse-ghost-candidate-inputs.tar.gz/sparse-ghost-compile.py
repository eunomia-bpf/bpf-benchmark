from pathlib import Path
import tarfile,tempfile,json,subprocess,re,hashlib
root=Path('/workspaces/repository'); a=Path('/workspaces/.agent-state/kprog-lanes/A'); r=root/'corpus/results/kprog_arm64_app_coverage_20261106'
header=root/'kprog/arm64/arm64_sim_local_bpf.h'; text=header.read_text(); digest=hashlib.sha256(header.read_bytes()).hexdigest(); nl=chr(10)
anchor='#ifdef ARM64_SIM_ENABLE_STACK'+nl+'#define ARM64_SIM_L_DECLARE_STACK()'
assert text.count(anchor)==1
prefix=nl.join(['#ifndef ARM64_SIM_STACK_PAYLOAD_WORDS','#define ARM64_SIM_STACK_PAYLOAD_WORDS KPROG_ARM64_STACK_WORDS(ARM64_SIM_STACK_BYTES)','#endif','#ifndef ARM64_SIM_L_STACK_PAYLOAD_LOAD','#define ARM64_SIM_L_STACK_PAYLOAD_LOAD(INDEX) (__a64_stack_payload[(INDEX)])','#define ARM64_SIM_L_STACK_PAYLOAD_STORE(INDEX, VALUE) do { __a64_stack_payload[(INDEX)] = (VALUE); } while (0)','#endif'])
text=text.replace(anchor,prefix+nl+anchor)
old='__u64 __a64_stack_payload[KPROG_ARM64_STACK_WORDS(ARM64_SIM_STACK_BYTES)];'; assert text.count(old)==1
text=text.replace(old,'volatile __u64 __a64_stack_payload[ARM64_SIM_STACK_PAYLOAD_WORDS];')
old='__a64_stack_payload[KPROG_ARM64_STACK_WORD_INDEX(__a64_stw_index)] = ARM64_SIM_L_UNMATERIALIZE(__a64_stw_value, (TAG));'; assert text.count(old)==1
text=text.replace(old,'if ((TAG) == ARM64_SIM_TAG_STACK || (TAG) == ARM64_SIM_TAG_RETURN) ARM64_SIM_L_STACK_PAYLOAD_STORE(KPROG_ARM64_STACK_WORD_INDEX(__a64_stw_index), ARM64_SIM_L_UNMATERIALIZE(__a64_stw_value, (TAG)));')
old='__a64_stack_payload[KPROG_ARM64_STACK_WORD_INDEX(__a64_mp_at)]'; assert text.count(old)==1
text=text.replace(old,'ARM64_SIM_L_STACK_PAYLOAD_LOAD(KPROG_ARM64_STACK_WORD_INDEX(__a64_mp_at))')
old='__a64_stack_payload[__a64_mt_at >> 3] = __a64_stack_payload[__a64_mt_src >> 3];';assert text.count(old)==1
text=text.replace(old,'ARM64_SIM_L_STACK_PAYLOAD_STORE(__a64_mt_at >> 3, ARM64_SIM_L_STACK_PAYLOAD_LOAD(__a64_mt_src >> 3));')
summary=dict(input_header_sha256=digest,cases=[])
with tempfile.TemporaryDirectory(prefix='sparse-compile-',dir=a) as tmp:
 d=Path(tmp); h=d/'arm64_sim_local_bpf.h'; h.write_text(text)
 for facts in json.loads((a/'sparse-ghost.json').read_text()):
  app=facts['app']; archive,member=('trusted-bcc-frame-result/compiler-inputs.tar.gz','generated/worker/trusted_arm64.bpf.c') if app=='tcplife' else ('trusted-extern-result/compiler-inputs.tar.gz','katran/trusted_arm64.bpf.c')
  with tarfile.open(r/archive) as t:source=t.extractfile(member).read().decode()
  source=source.replace('#include "'+str(header)+'"','#include "'+str(h)+'"')
  slots=facts['ghost_slots']
  if slots is not None:
   bias=-facts['stack_min']; assert bias%8==0
   indexes=[(offset+bias)//8 for offset in slots]
   rank=' + '.join('((__u64)(INDEX) > '+str(index)+'ULL)' for index in indexes) or '0ULL'
   source=nl.join(['#define ARM64_SIM_STACK_PAYLOAD_WORDS '+str(max(1,len(slots)))+'U',
    '#define ARM64_SIM_L_STACK_PAYLOAD_LOAD(INDEX) (__a64_stack_payload[('+rank+')])',
    '#define ARM64_SIM_L_STACK_PAYLOAD_STORE(INDEX, VALUE) do { __a64_stack_payload[('+rank+')] = (VALUE); } while (0)'])+nl+source
  c=d/(app+'.c');c.write_text(source); obj=d/(app+'.o')
  command=['clang','-g','-O2','-mcpu=v4','-target','bpf','-mllvm','-bpf-stack-size=4096','-D__TARGET_ARCH_arm64','-I',str(header.parent),'-I',str(root/'vendor/libbpf/include/uapi'),'-I',str(root/'vendor/libbpf/src'),'-I','/usr/include/x86_64-linux-gnu','-c',str(c),'-o',str(obj)]
  result=subprocess.run(command,text=True,capture_output=True); (d/(app+'.compiler.log')).write_text(result.stdout+result.stderr);result.check_returncode()
  dump=subprocess.check_output(['llvm-objdump','-d',str(obj)],text=True); (d/(app+'.asm')).write_text(dump)
  values=[int(v,0) for v in re.findall(r'r10 - (0x[0-9a-f]+|[0-9]+)',dump)]
  summary['cases'].append(dict(**facts,compile=0,max_fp_minus=max(values),command=command))
 with tarfile.open(a/'sparse-ghost-compiler-inputs.tar.gz','w:gz') as t:
  for f in d.iterdir():t.add(f,arcname=f.name)
summary['header_unchanged']=hashlib.sha256(header.read_bytes()).hexdigest()==digest; assert summary['header_unchanged']
(a/'sparse-ghost-compile.json').write_text(json.dumps(summary,indent=2)+nl);print(json.dumps(summary))
