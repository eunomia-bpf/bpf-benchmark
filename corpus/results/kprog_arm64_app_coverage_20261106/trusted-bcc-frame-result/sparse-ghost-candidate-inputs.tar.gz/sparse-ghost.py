from pathlib import Path
import importlib.util,sys,json,tarfile,tempfile,hashlib,subprocess,re
root=Path('/workspaces/repository'); a=Path('/workspaces/.agent-state/kprog-lanes/A'); r=root/'corpus/results/kprog_arm64_app_coverage_20261106'
sys.path.insert(0,str(root/'kprog/arm64')); import trusted_specializer as w
abi=Path(w.gen.check_definedness.__code__.co_filename); text=abi.read_text()
def edit(old,new,count=1):
 global text
 assert text.count(old)==count,(old,text.count(old),count)
 text=text.replace(old,new)
edit('    constants: tuple[int | None, ...]','    constants: tuple[int | None, ...]\n    ghost: tuple[bool, ...]\n    ghost_memory: frozenset[int]')
edit('initial = State(tuple(bits), tuple(aliases), 0, {}, {}, (None,)*64)', 'initial = State(tuple(bits), tuple(aliases), 0, {}, {}, (None,)*64, tuple(i in {30,31} for i in range(64)), frozenset())')
edit('tuple(x if x == y else None for x,y in zip(a.constants,b.constants)))','tuple(x if x == y else None for x,y in zip(a.constants,b.constants)),\n                     tuple(x or y for x,y in zip(a.ghost,b.ghost)), a.ghost_memory | b.ghost_memory)')
edit('    stack_min = stack_max = 0','    stack_min = stack_max = 0\n    payload_slots = set()\n    layout_unknown = False')
edit('        constants = list(incoming.constants)','        constants = list(incoming.constants)\n        ghost = list(incoming.ghost)\n        ghost_memory = set(incoming.ghost_memory)')
edit('def write(operand, value=None, pointer=no_pointer, constant=None):','def write(operand, value=None, pointer=no_pointer, constant=None, may_payload=None):')
edit('            constants[register] = constant & ((1 << width)-1) if constant is not None else None','            constants[register] = constant & ((1 << width)-1) if constant is not None else None\n            ghost[register] = (any(incoming.ghost[q[0]] for arg in args[1:] if (q := ri(arg)) and q[0] is not None) if may_payload is None else may_payload) if width == 64 else False')
edit('        def store(location, width, value, pointer=False):','''        def store(location, width, value, pointer=False, may_payload=True):
            nonlocal layout_unknown
            if width == 64 and may_payload:
                base_register = ri(raw(mem.base))[0]
                if location is False and incoming.ghost[base_register]:
                    location = None
                destinations = location.offsets if isinstance(location, PointerAlternatives) else {location} if type(location) is int else set()
                if location is None:
                    layout_unknown = True
                for destination in destinations:
                    if destination % 8 == 0:
                        payload_slots.add(destination)
                        ghost_memory.add(destination)''')
edit('                    write(operand, value, pointer)','''                    base_register = ri(raw(mem.base))[0]
                    if at is False and incoming.ghost[base_register]:
                        at = None
                    if width != 64 or at is False:
                        may_payload = False
                    elif type(at) is int:
                        may_payload = at in incoming.ghost_memory
                    elif isinstance(at, PointerAlternatives):
                        may_payload = any(p in incoming.ghost_memory for p in at.offsets)
                    else:
                        may_payload = True
                    write(operand, value, pointer, may_payload=may_payload)''')
edit('store(at, width, mask(incoming, operand), pointer)','store(at, width, mask(incoming, operand), pointer, incoming.ghost[parsed[0]] if parsed and parsed[0] is not None else False)')
edit('write(args[0], value, pointer, literal)','write(args[0], value, pointer, literal, incoming.ghost[source[0]] if source and source[0] is not None else False)')
edit('write(args[0], pointer=False)','write(args[0], pointer=False, may_payload=False)')
edit('write(base, FULL, shifted_pointer(origin, mem.offset))','write(base, FULL, shifted_pointer(origin, mem.offset), may_payload=incoming.ghost[ri(base)[0]])')
edit('state = State(tuple(bits), tuple(aliases), flags, opaque, pointers, tuple(constants))','state = State(tuple(bits), tuple(aliases), flags, opaque, pointers, tuple(constants), tuple(ghost), frozenset(ghost_memory))')
edit('                    effects.append(State(state.defined,state.aliases,state.flags,written,saved,state.constants))','''                    # Helper copies may transport private pointer tags. Unknown
                    # destinations/lengths retain the complete ghost layout.
                    source_arg = 1 if name == 'memcpy' else HELPER_COPY_SOURCES.get(name)
                    if effect is not None and source_arg is not None:
                        dst,size = effect
                        start,length = incoming.aliases[dst],incoming.constants[size]
                        source = incoming.aliases[source_arg]
                        origins = source.offsets if isinstance(source,PointerAlternatives) else {source} if type(source) is int else set()
                        if ((source is None or source is False) and incoming.ghost[source_arg]) or (origins and (type(start) is not int or length is None)):
                            layout_unknown = True
                        elif origins and length is not None:
                            for origin in origins:
                                for position in incoming.ghost_memory:
                                    if origin <= position and position+8 <= origin+length:
                                        destination = start+position-origin
                                        if destination % 8 == 0:
                                            payload_slots.add(destination)
                                            ghost_memory.add(destination)
                    effects.append(State(state.defined,state.aliases,state.flags,written,saved,state.constants,state.ghost,frozenset(ghost_memory)))''')
edit('bits[register], aliases[register], constants[register] = 0, None, None','bits[register], aliases[register], constants[register] = 0, None, None\n                    ghost[register] = False',2)
edit('bits[0], aliases[0] = FULL, False','bits[0], aliases[0] = FULL, False\n                ghost[0] = False')
edit('aliases[0]=incoming.aliases[0]','aliases[0]=incoming.aliases[0]\n                    ghost[0]=incoming.ghost[0]')
# Same assignment occurs at distinct helper and local call indentation.
edit('                    bits[30], aliases[30] = FULL, False','                    bits[30], aliases[30] = FULL, False\n                    ghost[30] = False')
edit('State(tuple(bits),tuple(aliases),0,opaque,pointers,tuple(constants))','State(tuple(bits),tuple(aliases),0,opaque,pointers,tuple(constants),tuple(ghost),frozenset(ghost_memory))',2)
edit('                bits, aliases = list(state.defined), list(state.aliases)','                bits, aliases = list(state.defined), list(state.aliases)\n                ghost = list(state.ghost)')
edit('\n                bits[30], aliases[30] = FULL, False','\n                bits[30], aliases[30] = FULL, False\n                ghost[30] = False')
edit('State(tuple(bits),tuple(aliases),flags,opaque,pointers,state.constants)','State(tuple(bits),tuple(aliases),flags,opaque,pointers,state.constants,tuple(ghost),frozenset(ghost_memory))')
edit('    return stack_min, stack_max','    return stack_min, stack_max, None if layout_unknown else sorted(payload_slots)')
text=re.sub(r'^( +)layout_unknown = True$', lambda m: m[1]+'if not layout_unknown: print("unknown ghost layout:", where, repr(locals().get("source")), repr(locals().get("location")), repr(locals().get("start")), repr(locals().get("length")), repr(incoming.ghost))'+chr(10)+m[0],text,flags=re.M)
(a/'sparse-ghost-abi.py').write_text(text)
spec=importlib.util.spec_from_file_location('sparse_ghost_abi',a/'sparse-ghost-abi.py'); mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod)
summaries=[]
with tempfile.TemporaryDirectory(prefix='sparse-ghost-',dir=a) as tmp:
 base=Path(tmp)
 for app,archive,member,symbol in [('tcplife','trusted-bcc-frame-result/compiler-inputs.tar.gz','generated/worker/trusted_arm64.proof.o','inet_sock_set_state'),('katran','trusted-extern-result/compiler-inputs.tar.gz','katran/trusted_arm64.proof.o','balancer_ingress')]:
  d=base/app;d.mkdir()
  with tarfile.open(r/archive) as t:(d/'trusted_arm64.proof.o').write_bytes(t.extractfile(member).read())
  functions,_=w.gen.parse_native_linked_program(w.gen.Bench('trusted_arm64',symbol,'raw'),d); insns=[i for b in functions.values() for i in b]
  facts=mod.check_definedness(insns,w.gen.indirect_targets(insns),True,w.gen)
  summaries.append(dict(app=app,stack_min=facts[0],stack_max=facts[1],ghost_slots=facts[2]))
(a/'sparse-ghost.json').write_text(json.dumps(summaries,indent=2)+chr(10)); print(json.dumps(summaries))
