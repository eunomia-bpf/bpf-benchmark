
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_STACK_BYTES 240U
#define ARM64_SIM_STACK_BIAS 240LL
#define ARM64_SIM_STACK_PAYLOAD_WORDS 2U
#define PAYLOAD_INDEX(INDEX) (((__u64)(INDEX)>14ULL)+((__u64)(INDEX)>22ULL))
#define ARM64_SIM_L_STACK_PAYLOAD_LOAD(INDEX) (__a64_stack_payload[PAYLOAD_INDEX(INDEX)])
#define ARM64_SIM_L_STACK_PAYLOAD_STORE(INDEX,VALUE) do { __a64_stack_payload[PAYLOAD_INDEX(INDEX)]=(VALUE); } while (0)
typedef unsigned char __u8;
typedef unsigned short __u16;
typedef unsigned int __u32;
typedef unsigned long long __u64;
typedef signed long long __s64;
typedef signed int __s32;
#define __always_inline inline
#include "arm64_sim_local_bpf.h"
#include <assert.h>
#include <string.h>
static void arm64_sim_unsupported_opcode(void) { abort(); }
unsigned long native_lab_entry_input(unsigned int kind) {
    if(kind==NATIVE_LAB_INPUT_SP) return 0x1234567890000000UL;
    if(kind==NATIVE_LAB_INPUT_RETURN) return 0xfedcba9870000000UL;
    abort();
}
ARM64_SIM_L_DECLARE_STATE();
ARM64_SIM_L_DECLARE_STACK();
static unsigned long checks;
static unsigned char bytes[240],tags[30];
static void compare(void) {
    for(unsigned i=0;i<240;i++) { assert(__a64_stack.b[i]==bytes[i]);checks++; }
    for(unsigned i=0;i<30;i++) { assert(ARM64_SIM_L_TAG_GET(i)==tags[i]);checks++; }
}
static void store(long off,unsigned width,unsigned long long value,unsigned tag) {
    unsigned start=240+off;
    ARM64_SIM_L_STACK_WRITE_TAG(off,width,value,tag);
    unsigned count=width==ARM64_WIDTH_64?8:width==ARM64_WIDTH_32?4:width==ARM64_WIDTH_16?2:1;
    for(unsigned j=0;j<count;j++) bytes[start+j]=(value>>(j*8))&255;
    for(unsigned j=start/8;j<=(start+count-1)/8;j++) tags[j]=0;
    if(count==8 && start%8==0) tags[start/8]=tag;
    compare();
}
static unsigned long long payload(long off) {
    unsigned tag=ARM64_SIM_L_STACK_READ_TAG(off,ARM64_WIDTH_64);
    unsigned long long raw=ARM64_SIM_L_STACK_READ(off,ARM64_WIDTH_64);
    return ARM64_SIM_L_MEM_PAYLOAD(ARM64_SP,ARM64_REG_NONE,0,off,0,raw,tag);
}
int main(void) {
    assert(sizeof(__a64_stack)==240 && sizeof(__a64_stack_payload)==16);
    for(unsigned seed=0;seed<16;seed++) {
        for(unsigned i=0;i<240;i++) store((long)i-240,ARM64_WIDTH_8,(i*37+seed*13)&255,ARM64_SIM_TAG_SCALAR);
        unsigned long long sp=native_lab_entry_input(NATIVE_LAB_INPUT_SP),lr=native_lab_entry_input(NATIVE_LAB_INPUT_RETURN);
        store(-128,ARM64_WIDTH_64,sp-17-seed,ARM64_SIM_TAG_STACK);
        store(-64,ARM64_WIDTH_64,lr+31+seed,ARM64_SIM_TAG_RETURN);
        assert(payload(-128)==(unsigned long long)(-17LL-seed));
        assert(payload(-64)==31+seed);
        assert(__a64_stack_payload[0]==(unsigned long long)(-17LL-seed) && __a64_stack_payload[1]==31+seed);
        for(unsigned count=1;count<=8;count++) {
            store(-128,ARM64_WIDTH_64,sp-17-seed,ARM64_SIM_TAG_STACK);
            memcpy((void*)&__a64_stack.b[176],(const void*)&__a64_stack.b[112],count);
            memcpy(&bytes[176],&bytes[112],count);
            ARM64_SIM_L_MEMORY_TAG_TRANSFER(-64,ARM64_SIM_TAG_STACK,-128,ARM64_SIM_TAG_STACK,count,1);
            tags[22]=count==8?ARM64_SIM_TAG_STACK:ARM64_SIM_TAG_SCALAR;
            compare();
            if(count==8) assert(payload(-64)==(unsigned long long)(-17LL-seed));
        }
        for(unsigned w=0;w<4;w++) {
            unsigned width=w==0?ARM64_WIDTH_8:w==1?ARM64_WIDTH_16:w==2?ARM64_WIDTH_32:ARM64_WIDTH_64;
            for(long off=-134;off<=-121;off++) store(off,width,0x8877665544332211ULL+seed,ARM64_SIM_TAG_SCALAR);
        }
    }
    printf("compact ghost bytes/tags/copy/payload: PASS (%lu checks)\n",checks);
}
