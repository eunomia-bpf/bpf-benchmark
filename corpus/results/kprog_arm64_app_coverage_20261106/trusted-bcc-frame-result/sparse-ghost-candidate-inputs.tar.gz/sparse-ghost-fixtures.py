from pathlib import Path
import importlib.util,sys,subprocess,tempfile,json,tarfile
root=Path('/workspaces/repository'); a=Path('/workspaces/.agent-state/kprog-lanes/A')
sys.path.insert(0,str(root/'kprog/arm64')); import trusted_specializer as w
spec=importlib.util.spec_from_file_location('sparse_ghost_abi',a/'sparse-ghost-abi.py'); mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
cases=[('none',['mov w0,#0','ret'],[]),('outer_return',['sub sp,sp,#32','str x30,[sp,#8]','ldr x30,[sp,#8]','add sp,sp,#32','mov w0,#0','ret'],[-24]),('stack_spill',['sub sp,sp,#32','mov x1,sp','str x1,[sp,#8]','ldr x2,[sp,#8]','str x30,[x2]','add sp,sp,#32','mov w0,#0','ret'],[-32,-24]),('narrow',['sub sp,sp,#32','mov x1,sp','str w1,[sp,#8]','add sp,sp,#32','mov w0,#0','ret'],[]),('dynamic_add',['sub sp,sp,#32','add x1,sp,x0','str x30,[x1]','add sp,sp,#32','mov w0,#0','ret'],None),('joined',['sub sp,sp,#32','cmp x0,#0','mov x1,sp','mov x2,#8','csel x3,x1,x2,eq','str x30,[x3]','add sp,sp,#32','mov w0,#0','ret'],[-32]),('memcpy',['sub sp,sp,#32','str x30,[sp]','add x0,sp,#8','mov x1,sp','mov x2,#8','bl memcpy','ldr x30,[sp]','add sp,sp,#32','mov w0,#0','ret'],[-32,-24]),('copied_return',['sub sp,sp,#32','mov x4,x30','str x4,[sp,#16]','ldr x30,[sp,#16]','add sp,sp,#32','mov w0,#0','ret'],[-16]),('conditional_increment',['sub sp,sp,#32','mov x1,sp','cmp x0,#0','cinc x2,x1,eq','str x30,[x2]','add sp,sp,#32','mov w0,#0','ret'],None)]
cases += [('postindexed_spill', ['sub sp,sp,#32','mov x1,sp','ldr x2,[x1],#8','str x1,[sp,#16]','ldr x3,[sp,#16]','str x30,[x3]','add sp,sp,#32','mov w0,#0','ret'], [-24,-16])]
cases += [('external_probe', ['sub sp,sp,#32','str x30,[sp]','mov x2,x0','add x0,sp,#8','mov x1,#8','bl bpf_probe_read_kernel','ldr x30,[sp]','add sp,sp,#32','mov w0,#0','ret'], [-32]), ('unknown_stack_probe', ['sub sp,sp,#32','str x30,[sp]','add x2,sp,x0','add x0,sp,#8','mov x1,#8','bl bpf_probe_read_kernel','ldr x30,[sp]','add sp,sp,#32','mov w0,#0','ret'], None)]
rows=[]
with tempfile.TemporaryDirectory(prefix='sparse-fixtures-',dir=a) as tmp:
 base=Path(tmp)
 for name,body,expected in cases:
  d=base/name;d.mkdir(); src=d/'native.S'; src.write_text(chr(10).join(['.text','.global bpf_main','.type bpf_main,%function','bpf_main:']+body+['.size bpf_main,.-bpf_main'])+chr(10))
  def run(command):
   p=subprocess.run([str(v) for v in command],text=True,capture_output=True)
   with (d/'commands.jsonl').open('a') as f:f.write(json.dumps(dict(command=[str(v) for v in command],returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))+chr(10))
   p.check_returncode()
  run(['aarch64-linux-gnu-gcc','-c',src,'-o',d/'native.o'])
  run([root/'kprog/arm64/build/app-native-link/release/native-link','--input',d/'native.o','--symbol','bpf_main','--mode','proof','--preserve-entry-abi','--output',d/'fixture.proof.o'])
  functions,_=w.gen.parse_native_linked_program(w.gen.Bench('fixture','bpf_main','raw'),d); insns=[i for b in functions.values() for i in b]
  original=w.gen.check_definedness(insns,w.gen.indirect_targets(insns),True,w.gen)
  result=mod.check_definedness(insns,w.gen.indirect_targets(insns),True,w.gen)
  assert result[:2]==original,(name,result,original)
  assert result[2]==expected,(name,result,expected)
  rows.append(dict(case=name,stack_bounds=result[:2],ghost_offsets=result[2],expected=expected))
 with tarfile.open(a/'sparse-ghost-fixtures.tar.gz','w:gz') as t:
  for p in base.rglob('*'):
   if p.is_file():t.add(p,arcname=p.relative_to(base))
(a/'sparse-ghost-fixtures.json').write_text(json.dumps(rows,indent=2)+chr(10));print(json.dumps(rows))
