audit:
	taskset -c 20-23 python3 /workspaces/.agent-state/kprog-lanes/A/sparse-ghost.py

compile:
	taskset -c 20-23 python3 /workspaces/.agent-state/kprog-lanes/A/sparse-ghost-compile.py

fixtures:
	taskset -c 20-23 python3 /workspaces/.agent-state/kprog-lanes/A/sparse-ghost-fixtures.py

host:
	cc -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -I/workspaces/repository/kprog/arm64 -I/workspaces/repository/vendor/libbpf/src -I/workspaces/repository/kprog/formal/oracles /workspaces/.agent-state/kprog-lanes/A/payload-candidate/host.c -o /workspaces/.agent-state/kprog-lanes/A/payload-candidate/host
	/workspaces/.agent-state/kprog-lanes/A/payload-candidate/host
