audit:
	taskset -c 20-23 python3 /workspaces/.agent-state/kprog-lanes/A/sparse-ghost.py

compile:
	taskset -c 20-23 python3 /workspaces/.agent-state/kprog-lanes/A/sparse-ghost-compile.py

fixtures:
	taskset -c 20-23 python3 /workspaces/.agent-state/kprog-lanes/A/sparse-ghost-fixtures.py
