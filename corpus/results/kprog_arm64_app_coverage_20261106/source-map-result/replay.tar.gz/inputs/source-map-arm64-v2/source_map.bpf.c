#include "/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/source-map-arm64-v2/simulator/arm64_sim_local_bpf.h"

extern __u8 __source_map_base_0[] __ksym;
static const char __arm64_source_map_metadata[] SEC(".native_lab.source_maps") = "{\"version\":1,\"objects\":[{\"native_symbol\":\"__native_source_map_0\",\"source_insn\":0,\"proof_symbol\":\"__source_map_base_0\"}]}";
SEC("socket")
int source_map_arm64_sim_xdp(void *ctx)
{
	ARM64_SIM_ENTRY_RAW(ctx);
arm64_l_0:
	/* 0x0: adrp x8, 0 <__native_source_map_0> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)(__source_map_base_0 + 16ULL)));
arm64_l_4:
	/* 0x4: mov w9, #0x2a */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 42ULL);
arm64_l_8:
	/* 0x8: mov x0, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c:
	/* 0xc: ldr x8, [x8] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X8, ARM64_SIM_L_READ_REG_PTR(ARM64_X8), ARM64_SIM_TAG_MAP_VALUE);
arm64_l_10:
	/* 0x10: str x9, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_14:
	/* 0x14: b 18 <__native_link_arm64_ret_trampoline> */
	ARM64_SIM_A64_JMP(0x14, 0x18, arm64_l_18);
arm64_l_18:
	/* 0x18: mov x7, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
