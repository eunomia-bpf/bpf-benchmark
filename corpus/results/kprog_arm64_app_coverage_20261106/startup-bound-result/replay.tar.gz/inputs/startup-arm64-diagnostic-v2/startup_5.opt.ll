; ModuleID = '/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/startup-arm64-v1/startup_5.ll'
source_filename = "bpf-source"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i64 @bpf_main(ptr nocapture readnone %0) local_unnamed_addr #0 {
setupBlock:
  ret i64 127
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) }
