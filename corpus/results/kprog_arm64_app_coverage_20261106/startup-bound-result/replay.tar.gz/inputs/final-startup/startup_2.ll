; ModuleID = 'bpf-source'
source_filename = "bpf-source"

define i64 @bpf_main(ptr %0) {
setupBlock:
  %r0 = alloca i64, align 8
  %r1 = alloca i64, align 8
  %r2 = alloca i64, align 8
  %r3 = alloca i64, align 8
  %r4 = alloca i64, align 8
  %r5 = alloca i64, align 8
  %r6 = alloca i64, align 8
  %r7 = alloca i64, align 8
  %r8 = alloca i64, align 8
  %r9 = alloca i64, align 8
  %r10 = alloca i64, align 8
  store i64 0, ptr %r0, align 4
  store i64 0, ptr %r1, align 4
  store i64 0, ptr %r2, align 4
  store i64 0, ptr %r3, align 4
  store i64 0, ptr %r4, align 4
  store i64 0, ptr %r5, align 4
  store i64 0, ptr %r6, align 4
  store i64 0, ptr %r7, align 4
  store i64 0, ptr %r8, align 4
  store i64 0, ptr %r9, align 4
  store i64 0, ptr %r10, align 4
  %stackBegin = alloca i8, align 8
  %stackEnd = getelementptr i8, ptr %stackBegin, i32 1
  store ptr %stackEnd, ptr %r10, align 8
  store ptr %0, ptr %r1, align 8
  br label %bb_inst_0

bb_inst_0:                                        ; preds = %setupBlock
  %1 = load i64, ptr %r1, align 4
  %2 = load i64, ptr %r2, align 4
  %3 = load i64, ptr %r3, align 4
  %4 = load i64, ptr %r4, align 4
  %5 = load i64, ptr %r5, align 4
  %6 = call i64 @bpf_ktime_get_coarse_ns(i64 %1, i64 %2, i64 %3, i64 %4, i64 %5)
  store i64 %6, ptr %r0, align 4
  br label %bb_inst_1

bb_inst_1:                                        ; preds = %bb_inst_0
  br label %exitBlock

exitBlock:                                        ; preds = %bb_inst_1
  %7 = load i64, ptr %r0, align 4
  ret i64 %7
}

declare i64 @bpf_ktime_get_coarse_ns(i64, i64, i64, i64, i64)
