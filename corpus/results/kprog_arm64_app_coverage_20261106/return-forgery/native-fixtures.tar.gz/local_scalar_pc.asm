
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/return-forgery/local_scalar_pc.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f81f0ffe 	str	x30, [sp, #-16]!
   4:	94000004 	bl	14 <entry+0x14>
   8:	f84107fe 	ldr	x30, [sp], #16
   c:	52800040 	mov	w0, #0x2                   	// #2
  10:	d65f03c0 	ret
  14:	d280011e 	mov	x30, #0x8                   	// #8
  18:	d65f03c0 	ret
