
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/return-forgery/outer_scalar_zero.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	52800040 	mov	w0, #0x2                   	// #2
   4:	d280001e 	mov	x30, #0x0                   	// #0
   8:	d65f03c0 	ret
