#include <linux/bpf.h>
#include <bpf_helpers.h>
#define __BPF_HELPERS_H
#include "katran/lib/bpf/balancer.c"
