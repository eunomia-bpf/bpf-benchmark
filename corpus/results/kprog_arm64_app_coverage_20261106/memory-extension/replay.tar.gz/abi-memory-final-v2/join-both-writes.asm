
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-memory-final-v2/join-both-writes.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	b4000060 	cbz	x0, c <entry+0xc>
   4:	52800041 	mov	w1, #0x2                   	// #2
   8:	14000002 	b	10 <entry+0x10>
   c:	52800061 	mov	w1, #0x3                   	// #3
  10:	2a0103e0 	mov	w0, w1
  14:	d65f03c0 	ret
