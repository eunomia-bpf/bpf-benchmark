
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-memory-final-v2/unused-nv-flags.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	9a80f000 	csel	x0, x0, x0, nv
   4:	d65f03c0 	ret
