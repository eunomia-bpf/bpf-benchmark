
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-memory-final-v2/partial-movk-low-return.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f2800040 	movk	x0, #0x2
   4:	d65f03c0 	ret
