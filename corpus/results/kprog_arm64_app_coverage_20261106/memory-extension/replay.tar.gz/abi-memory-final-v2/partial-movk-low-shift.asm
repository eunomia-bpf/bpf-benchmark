
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-memory-final-v2/partial-movk-low-shift.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f2800041 	movk	x1, #0x2
   4:	d3503c20 	lsl	x0, x1, #48
   8:	d65f03c0 	ret
