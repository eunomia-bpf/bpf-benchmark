
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-memory-final-v2/helper-opaque-copy.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	a9be7bf3 	stp	x19, x30, [sp, #-32]!
   4:	f9000be1 	str	x1, [sp, #16]
   8:	910063e0 	add	x0, sp, #0x18
   c:	d2800101 	mov	x1, #0x8                   	// #8
  10:	910043e2 	add	x2, sp, #0x10
  14:	94000000 	bl	0 <bpf_probe_read_kernel>
			14: R_AARCH64_CALL26	bpf_probe_read_kernel
  18:	f9400fe0 	ldr	x0, [sp, #24]
  1c:	a8c27bf3 	ldp	x19, x30, [sp], #32
  20:	d65f03c0 	ret
