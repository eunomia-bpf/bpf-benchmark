#include <linux/bpf.h>
#include <bpf_helpers.h>
SEC("xdp") int helper_dispatch_bad(struct xdp_md *ctx) { void *p=(void *)(long)ctx->data; void *e=(void *)(long)ctx->data_end; if (p+8>e) return 0; *(__u64 *)p=((*(unsigned char *)p ^ 0) ? bpf_get_current_pid_tgid() : bpf_get_current_uid_gid()) != 0; return 2; }
char LICENSE[] SEC("license")="GPL";
