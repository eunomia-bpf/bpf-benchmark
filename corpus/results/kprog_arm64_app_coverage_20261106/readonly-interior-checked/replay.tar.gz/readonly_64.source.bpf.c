#include <linux/bpf.h>
#include <bpf_helpers.h>
SEC("xdp") int readonly_64(struct xdp_md *ctx) { return 71; }
char LICENSE[] SEC("license")="GPL";
