#include <linux/bpf.h>
#include <bpf_helpers.h>
SEC("xdp") int readonly_119(struct xdp_md *ctx) { return 18; }
char LICENSE[] SEC("license")="GPL";
