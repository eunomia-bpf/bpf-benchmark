#include <linux/bpf.h>
#include <bpf_helpers.h>
SEC("xdp") int readonly_7(struct xdp_md *ctx) { return 98; }
char LICENSE[] SEC("license")="GPL";
