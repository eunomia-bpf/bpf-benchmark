#define LICENSE __arm64_original_license
#include "/workspaces/repository/vendor/bpf/bcc/libbpf-tools/vfsstat.bpf.c"
#undef LICENSE
#include "/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/bcc-bound-v5/simulator/arm64_sim_local_bpf.h"

SEC("fentry/vfs_read")
int bcc_vfsstat_fentry_vfs_read_arm64_sim_xdp(void *ctx)
{
	ARM64_SIM_ENTRY_RAW(ctx);
arm64_l_0:
	/* 0x0: adrp x8, 0 <stats> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&stats));
arm64_l_4:
	/* 0x4: ldr x8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_8:
	/* 0x8: ldxr x9, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c:
	/* 0xc: add x9, x9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_10:
	/* 0x10: stxr w10, x9, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STLXR, ARM64_X10, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0);
arm64_l_14:
	/* 0x14: cbnz w10, 8 <fentry_vfs_read+0x8> */
	ARM64_SIM_A64_CBNZ_W(ARM64_X10, 0x14, 0x8, arm64_l_8);
arm64_l_18:
	/* 0x18: mov w0, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1c:
	/* 0x1c: b 20 <__native_link_arm64_ret_trampoline> */
	ARM64_SIM_A64_JMP(0x1c, 0x20, arm64_l_20);
arm64_l_20:
	/* 0x20: mov x7, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
