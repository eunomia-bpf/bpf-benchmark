#include <linux/bpf.h>
#include <bpf_helpers.h>
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 16);
    __uint(max_entries, 1024);
    __uint(map_flags, 0);
} stats SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 8);
    __uint(max_entries, 16);
    __uint(map_flags, 0);
} ctl_array SEC(".maps");
struct {
    __uint(type, 1);
    __uint(key_size, 20);
    __uint(value_size, 8);
    __uint(max_entries, 512);
    __uint(map_flags, 0);
} vip_map SEC(".maps");
struct {
    __uint(type, 9);
    __uint(key_size, 40);
    __uint(value_size, 16);
    __uint(max_entries, 1000);
    __uint(map_flags, 0);
} fallback_cache SEC(".maps");
struct __trusted_inner_0 {
    __uint(type, 9);
    __uint(key_size, 40);
    __uint(value_size, 16);
    __uint(max_entries, 1000);
    __uint(map_flags, 0);
};
struct {
    __uint(type, 12);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 128);
    __uint(map_flags, 0);
    __array(values, struct __trusted_inner_0);
} lru_mapping SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 33554944);
    __uint(map_flags, 0);
} ch_rings SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 20);
    __uint(max_entries, 4096);
    __uint(map_flags, 0);
} reals SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 16);
    __uint(max_entries, 4096);
    __uint(map_flags, 0);
} reals_stats SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 4096);
    __uint(map_flags, 0);
} lru_miss_stats SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 20);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} vip_miss_stats SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 104);
    __uint(max_entries, 1);
    __uint(map_flags, 0);
} quic_stats_map SEC(".maps");
struct {
    __uint(type, 2);
    __uint(key_size, 4);
    __uint(value_size, 4);
    __uint(max_entries, 16777214);
    __uint(map_flags, 0);
} server_id_map SEC(".maps");
struct {
    __uint(type, 6);
    __uint(key_size, 4);
    __uint(value_size, 16);
    __uint(max_entries, 512);
    __uint(map_flags, 0);
} server_id_stats SEC(".maps");
struct __trusted_inner_1 {
    __uint(type, 1);
    __uint(key_size, 4);
    __uint(value_size, 1);
    __uint(max_entries, 4096);
    __uint(map_flags, 1);
};
struct {
    __uint(type, 13);
    __uint(key_size, 20);
    __uint(value_size, 4);
    __uint(max_entries, 512);
    __uint(map_flags, 1);
    __array(values, struct __trusted_inner_1);
} vip_to_down_reals_map SEC(".maps");
