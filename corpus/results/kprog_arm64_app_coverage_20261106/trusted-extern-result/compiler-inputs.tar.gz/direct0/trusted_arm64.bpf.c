#include "/workspaces/repository/kprog/arm64/arm64_sim_local_bpf.h"

extern __u8 __arm64_trusted_map_0[] __ksym;
extern __u8 __arm64_trusted_map_0_[] __asm__("sys_exit.zero") __ksym;
SEC("xdp")
int trusted_arm64_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
	/* native subroutine trusted_entry */
arm64_l_0:
	/* 0x0: adrp x0, 0 <sys_exit.zero> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)__arm64_trusted_map_0_));
arm64_l_4:
	/* 0x4: ldr x0, [x0] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X0, ARM64_SIM_L_READ_REG_PTR(ARM64_X0), ARM64_SIM_TAG_MAP_VALUE);
arm64_l_8:
	/* 0x8: adrp x1, 0 <__arm64_trusted_map_0> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)__arm64_trusted_map_0));
arm64_l_c:
	/* 0xc: ldr x1, [x1] */
	ARM64_SIM_L_WRITE_REG_PTR_TAG(ARM64_X1, ARM64_SIM_L_READ_REG_PTR(ARM64_X1), ARM64_SIM_TAG_MAP_VALUE);
arm64_l_10:
	/* 0x10: ldr w2, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_14:
	/* 0x14: ldr w0, [x1] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18:
	/* 0x18: eor w0, w2, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X2, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_1c:
	/* 0x1c: b 20 <__native_link_arm64_ret_trampoline> */
	ARM64_SIM_A64_JMP(0x1c, 0x20, arm64_l_20);
arm64_l_20:
	/* 0x20: mov x7, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
