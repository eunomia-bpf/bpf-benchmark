volatile unsigned int a[16] __asm__("sys_exit.zero");
volatile unsigned int b[16] __asm__("__arm64_trusted_map_0");
int trusted_entry(void *ctx) { (void)ctx; return a[2] ^ b[0]; }
