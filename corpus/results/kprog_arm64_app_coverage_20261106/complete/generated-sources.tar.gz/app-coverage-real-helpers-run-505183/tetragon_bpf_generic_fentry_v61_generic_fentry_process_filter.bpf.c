extern char CONFIG_ITER_NUM;
extern char PARENTS_MAP_ENABLED;
extern char buffer_heap_map;
extern char execve_map;
extern char fentry_calls;
extern char filter_map;
extern char process_call_heap;
extern char string_maps_heap;
extern char string_postfix_maps;
extern char string_postfix_maps_heap;
extern char string_prefix_maps;
extern char tg_errmetrics_map;
extern char tg_mb_paths;
extern char tg_mb_sel_opts;
extern char tg_mbset_gen;
extern char tg_mbset_map;
extern char tg_parents_bin;
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_RETURN_CASES \
	case 0x38ULL: goto arm64_l_38; \
	case 0x50ULL: goto arm64_l_50; \
	case 0x78ULL: goto arm64_l_78; \
	case 0x9cULL: goto arm64_l_9c; \
	case 0xd4ULL: goto arm64_l_d4; \
	case 0x100ULL: goto arm64_l_100; \
	case 0x11cULL: goto arm64_l_11c; \
	case 0x154ULL: goto arm64_l_154; \
	case 0x180ULL: goto arm64_l_180; \
	case 0x19cULL: goto arm64_l_19c; \
	case 0x1d4ULL: goto arm64_l_1d4; \
	case 0x200ULL: goto arm64_l_200; \
	case 0x21cULL: goto arm64_l_21c; \
	case 0x254ULL: goto arm64_l_254; \
	case 0x25cULL: goto arm64_l_25c; \
	case 0x278ULL: goto arm64_l_278; \
	case 0x28cULL: goto arm64_l_28c; \
	case 0x2b8ULL: goto arm64_l_2b8; \
	case 0x2ecULL: goto arm64_l_2ec; \
	case 0x330ULL: goto arm64_l_330; \
	case 0x364ULL: goto arm64_l_364; \
	case 0x380ULL: goto arm64_l_380; \
	case 0x398ULL: goto arm64_l_398; \
	case 0x3acULL: goto arm64_l_3ac; \
	case 0x3ccULL: goto arm64_l_3cc; \
	case 0x3f0ULL: goto arm64_l_3f0; \
	case 0x410ULL: goto arm64_l_410; \
	case 0x434ULL: goto arm64_l_434; \
	case 0x458ULL: goto arm64_l_458; \
	case 0x470ULL: goto arm64_l_470; \
	case 0x4a0ULL: goto arm64_l_4a0; \
	case 0x4d8ULL: goto arm64_l_4d8; \
	case 0x4f8ULL: goto arm64_l_4f8; \
	case 0x52cULL: goto arm64_l_52c; \
	case 0x550ULL: goto arm64_l_550; \
	case 0x574ULL: goto arm64_l_574; \
	case 0x598ULL: goto arm64_l_598; \
	case 0x5bcULL: goto arm64_l_5bc; \
	case 0x5e0ULL: goto arm64_l_5e0; \
	case 0x604ULL: goto arm64_l_604; \
	case 0x624ULL: goto arm64_l_624; \
	case 0x64cULL: goto arm64_l_64c; \
	case 0x678ULL: goto arm64_l_678; \
	case 0x698ULL: goto arm64_l_698; \
	case 0x6b8ULL: goto arm64_l_6b8; \
	case 0x6dcULL: goto arm64_l_6dc; \
	case 0x6fcULL: goto arm64_l_6fc; \
	case 0x71cULL: goto arm64_l_71c; \
	case 0x734ULL: goto arm64_l_734; \
	case 0x794ULL: goto arm64_l_794; \
	case 0x7a8ULL: goto arm64_l_7a8; \
	case 0x7bcULL: goto arm64_l_7bc; \
	case 0x7ccULL: goto arm64_l_7cc; \
	case 0x820ULL: goto arm64_l_820; \
	case 0x844ULL: goto arm64_l_844; \
	case 0x86cULL: goto arm64_l_86c; \
	case 0x888ULL: goto arm64_l_888; \
	case 0x8f8ULL: goto arm64_l_8f8; \
	case 0x92cULL: goto arm64_l_92c; \
	case 0x954ULL: goto arm64_l_954; \
	case 0x988ULL: goto arm64_l_988; \
	case 0x9e4ULL: goto arm64_l_9e4; \
	case 0xa94ULL: goto arm64_l_a94; \
	case 0xad4ULL: goto arm64_l_ad4; \
	case 0xb0cULL: goto arm64_l_b0c; \
	case 0xb28ULL: goto arm64_l_b28; \
	case 0xb60ULL: goto arm64_l_b60; \
	case 0xbb8ULL: goto arm64_l_bb8; \
	case 0xbe8ULL: goto arm64_l_be8; \
	case 0xc2cULL: goto arm64_l_c2c; \
	case 0xc64ULL: goto arm64_l_c64; \
	case 0xc94ULL: goto arm64_l_c94; \
	case 0xcdcULL: goto arm64_l_cdc; \
	case 0xd14ULL: goto arm64_l_d14; \
	case 0xd38ULL: goto arm64_l_d38; \
	case 0xd8cULL: goto arm64_l_d8c; \
	case 0xe00ULL: goto arm64_l_e00; \
	case 0xe34ULL: goto arm64_l_e34; \
	case 0xeccULL: goto arm64_l_ecc; \
	case 0xf50ULL: goto arm64_l_f50; \
	case 0xf70ULL: goto arm64_l_f70; \
	case 0xf84ULL: goto arm64_l_f84; \
	case 0xfacULL: goto arm64_l_fac; \
	case 0xfdcULL: goto arm64_l_fdc; \
	case 0x103cULL: goto arm64_l_103c; \
	case 0x1058ULL: goto arm64_l_1058; \
	case 0x10b0ULL: goto arm64_l_10b0; \
	case 0x1108ULL: goto arm64_l_1108; \
	case 0x1160ULL: goto arm64_l_1160; \
	case 0x1174ULL: goto arm64_l_1174; \
	case 0x11d0ULL: goto arm64_l_11d0; \
	case 0x11f8ULL: goto arm64_l_11f8; \
	case 0x1268ULL: goto arm64_l_1268; \
	case 0x1298ULL: goto arm64_l_1298; \
	case 0x1320ULL: goto arm64_l_1320; \
	case 0x1344ULL: goto arm64_l_1344; \
	case 0x1364ULL: goto arm64_l_1364; \
	case 0x1378ULL: goto arm64_l_1378; \
	case 0x139cULL: goto arm64_l_139c; \
	case 0x13ccULL: goto arm64_l_13cc; \
	case 0x1424ULL: goto arm64_l_1424; \
	case 0x1440ULL: goto arm64_l_1440; \
	case 0x1498ULL: goto arm64_l_1498; \
	case 0x14f0ULL: goto arm64_l_14f0; \
	case 0x1540ULL: goto arm64_l_1540; \
	case 0x1550ULL: goto arm64_l_1550; \
	case 0x16d4ULL: goto arm64_l_16d4; \
	case 0x1714ULL: goto arm64_l_1714; \
	case 0x1754ULL: goto arm64_l_1754; \
	case 0x1794ULL: goto arm64_l_1794; \
	case 0x17d4ULL: goto arm64_l_17d4; \
	case 0x1814ULL: goto arm64_l_1814; \
	case 0x1854ULL: goto arm64_l_1854; \
	case 0x1894ULL: goto arm64_l_1894; \
	case 0x1938ULL: goto arm64_l_1938; \
	case 0x195cULL: goto arm64_l_195c; \
	case 0x1980ULL: goto arm64_l_1980; \
	case 0x19a4ULL: goto arm64_l_19a4; \
	case 0x19c8ULL: goto arm64_l_19c8; \
	case 0x19ecULL: goto arm64_l_19ec; \
	case 0x1a10ULL: goto arm64_l_1a10; \
	case 0x1a34ULL: goto arm64_l_1a34; \
	case 0x1a60ULL: goto arm64_l_1a60; \
	case 0x1b64ULL: goto arm64_l_1b64; \
	case 0x1d28ULL: goto arm64_l_1d28; \
	case 0x1d48ULL: goto arm64_l_1d48; \
	case 0x20f0ULL: goto arm64_l_20f0; \
	case 0x2110ULL: goto arm64_l_2110; \
	case 0x21dcULL: goto arm64_l_21dc;
#include "../arm64_sim_local_bpf.h"

static const __u64 __arm64_rodata_0[2] = {12178401890396095487ULL, 12178947204542846966ULL};

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} CONFIG_ITER_NUM_0 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} PARENTS_MAP_ENABLED_1 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} arm64_section_Some_SectionIndex_12_addend_0_2 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} buffer_heap_map_3 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} execve_map_4 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} fentry_calls_5 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} filter_map_6 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} memset_7 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} process_call_heap_8 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_heap_9 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_postfix_maps_10 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_postfix_maps_heap_11 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_prefix_maps_12 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_errmetrics_map_13 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_mb_paths_14 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_mb_sel_opts_15 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_mbset_gen_16 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_mbset_map_17 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_parents_bin_18 SEC(".maps");

SEC("xdp")
int tetragon_bpf_generic_fentry_v61_generic_fentry_process_filter_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
	/* native subroutine tetragon_bpf_generic_fentry_v61_generic_fentry_process_filter_xdp */
arm64_l_0:
	/* 0x0: sub sp, sp, #0x130 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 304ULL);
arm64_l_4:
	/* 0x4: str x29, [sp, #224] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_8:
	/* 0x8: stp x30, x25, [sp, #240] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 240ULL);
arm64_l_c:
	/* 0xc: stp x24, x23, [sp, #256] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 256ULL);
arm64_l_10:
	/* 0x10: stp x22, x21, [sp, #272] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 272ULL);
arm64_l_14:
	/* 0x14: stp x20, x19, [sp, #288] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 288ULL);
arm64_l_18:
	/* 0x18: mov x20, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c:
	/* 0x1c: str wzr, [sp, #84] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 84ULL);
arm64_l_20:
	/* 0x20: adrp x0, 0 <process_call_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_8));
arm64_l_24:
	/* 0x24: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28:
	/* 0x28: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c:
	/* 0x2c: add x9, sp, #0x54 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 84ULL);
arm64_l_30:
	/* 0x30: add x1, sp, #0x54 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 84ULL);
arm64_l_34:
	/* 0x34: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x38ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_38:
	/* 0x38: cbz x0, 21dc <generic_fentry_process_filter+0x21dc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x38, 0x21dc, arm64_l_21dc);
arm64_l_3c:
	/* 0x3c: mov w8, #0x5ec0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24256ULL);
arm64_l_40:
	/* 0x40: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_44:
	/* 0x44: add x21, x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X21, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_48:
	/* 0x48: mov w8, #0x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 35ULL);
arm64_l_4c:
	/* 0x4c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 35ULL: ARM64_SIM_A64_LINK(0x50ULL); ARM64_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_50:
	/* 0x50: str x0, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_54:
	/* 0x54: add x8, x0, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_58:
	/* 0x58: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_5c:
	/* 0x5c: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_60:
	/* 0x60: add x11, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_64:
	/* 0x64: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_68:
	/* 0x68: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_6c:
	/* 0x6c: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_70:
	/* 0x70: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_74:
	/* 0x74: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x78ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_78:
	/* 0x78: ldr w8, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_7c:
	/* 0x7c: adrp x19, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_80:
	/* 0x80: add x9, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_84:
	/* 0x84: add x1, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_88:
	/* 0x88: str w8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_8c:
	/* 0x8c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_90:
	/* 0x90: ldr x19, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_94:
	/* 0x94: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_98:
	/* 0x98: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x9cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_9c:
	/* 0x9c: cbz x0, ac <generic_fentry_process_filter+0xac> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x9c, 0xac, arm64_l_ac);
arm64_l_a0:
	/* 0xa0: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_a4:
	/* 0xa4: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a8:
	/* 0xa8: cbnz x8, d20 <generic_fentry_process_filter+0xd20> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0xa8, 0xd20, arm64_l_d20);
arm64_l_ac:
	/* 0xac: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_b0:
	/* 0xb0: mov w9, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_b4:
	/* 0xb4: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_b8:
	/* 0xb8: add x11, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_bc:
	/* 0xbc: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_c0:
	/* 0xc0: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_c4:
	/* 0xc4: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_c8:
	/* 0xc8: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_cc:
	/* 0xcc: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_d0:
	/* 0xd0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xd4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_d4:
	/* 0xd4: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_d8:
	/* 0xd8: cbz x8, 254 <generic_fentry_process_filter+0x254> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xd8, 0x254, arm64_l_254);
arm64_l_dc:
	/* 0xdc: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_e0:
	/* 0xe0: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_e4:
	/* 0xe4: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_e8:
	/* 0xe8: add x11, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_ec:
	/* 0xec: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_f0:
	/* 0xf0: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_f4:
	/* 0xf4: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_f8:
	/* 0xf8: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_fc:
	/* 0xfc: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x100ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_100:
	/* 0x100: ldr w8, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_104:
	/* 0x104: add x9, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_108:
	/* 0x108: add x1, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_10c:
	/* 0x10c: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_110:
	/* 0x110: str w8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_114:
	/* 0x114: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_118:
	/* 0x118: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x11cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_11c:
	/* 0x11c: cbz x0, 12c <generic_fentry_process_filter+0x12c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x11c, 0x12c, arm64_l_12c);
arm64_l_120:
	/* 0x120: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_124:
	/* 0x124: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_128:
	/* 0x128: cbnz x8, d20 <generic_fentry_process_filter+0xd20> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0x128, 0xd20, arm64_l_d20);
arm64_l_12c:
	/* 0x12c: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_130:
	/* 0x130: mov w9, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_134:
	/* 0x134: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_138:
	/* 0x138: add x11, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_13c:
	/* 0x13c: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_140:
	/* 0x140: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_144:
	/* 0x144: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_148:
	/* 0x148: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_14c:
	/* 0x14c: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_150:
	/* 0x150: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x154ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_154:
	/* 0x154: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_158:
	/* 0x158: cbz x8, 254 <generic_fentry_process_filter+0x254> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x158, 0x254, arm64_l_254);
arm64_l_15c:
	/* 0x15c: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_160:
	/* 0x160: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_164:
	/* 0x164: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_168:
	/* 0x168: add x11, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_16c:
	/* 0x16c: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_170:
	/* 0x170: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_174:
	/* 0x174: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_178:
	/* 0x178: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_17c:
	/* 0x17c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x180ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_180:
	/* 0x180: ldr w8, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_184:
	/* 0x184: add x9, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_188:
	/* 0x188: add x1, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_18c:
	/* 0x18c: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_190:
	/* 0x190: str w8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_194:
	/* 0x194: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_198:
	/* 0x198: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x19cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_19c:
	/* 0x19c: cbz x0, 1ac <generic_fentry_process_filter+0x1ac> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x19c, 0x1ac, arm64_l_1ac);
arm64_l_1a0:
	/* 0x1a0: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1a4:
	/* 0x1a4: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a8:
	/* 0x1a8: cbnz x8, d20 <generic_fentry_process_filter+0xd20> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0x1a8, 0xd20, arm64_l_d20);
arm64_l_1ac:
	/* 0x1ac: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1b0:
	/* 0x1b0: mov w9, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1b4:
	/* 0x1b4: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1b8:
	/* 0x1b8: add x11, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1bc:
	/* 0x1bc: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1c0:
	/* 0x1c0: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1c4:
	/* 0x1c4: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_1c8:
	/* 0x1c8: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1cc:
	/* 0x1cc: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_1d0:
	/* 0x1d0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1d4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1d4:
	/* 0x1d4: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1d8:
	/* 0x1d8: cbz x8, 254 <generic_fentry_process_filter+0x254> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1d8, 0x254, arm64_l_254);
arm64_l_1dc:
	/* 0x1dc: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_1e0:
	/* 0x1e0: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1e4:
	/* 0x1e4: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1e8:
	/* 0x1e8: add x11, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_1ec:
	/* 0x1ec: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1f0:
	/* 0x1f0: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_1f4:
	/* 0x1f4: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1f8:
	/* 0x1f8: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_1fc:
	/* 0x1fc: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x200ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_200:
	/* 0x200: ldr w8, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_204:
	/* 0x204: add x9, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_208:
	/* 0x208: add x1, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_20c:
	/* 0x20c: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_210:
	/* 0x210: str w8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_214:
	/* 0x214: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_218:
	/* 0x218: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x21cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_21c:
	/* 0x21c: cbz x0, 22c <generic_fentry_process_filter+0x22c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x21c, 0x22c, arm64_l_22c);
arm64_l_220:
	/* 0x220: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_224:
	/* 0x224: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_228:
	/* 0x228: cbnz x8, d20 <generic_fentry_process_filter+0xd20> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0x228, 0xd20, arm64_l_d20);
arm64_l_22c:
	/* 0x22c: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_230:
	/* 0x230: mov w9, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_234:
	/* 0x234: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_238:
	/* 0x238: add x11, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_23c:
	/* 0x23c: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_240:
	/* 0x240: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_244:
	/* 0x244: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_248:
	/* 0x248: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_24c:
	/* 0x24c: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_250:
	/* 0x250: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x254ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_254:
	/* 0x254: mov w8, #0x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 35ULL);
arm64_l_258:
	/* 0x258: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 35ULL: ARM64_SIM_A64_LINK(0x25cULL); ARM64_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_25c:
	/* 0x25c: add x2, x0, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_260:
	/* 0x260: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_264:
	/* 0x264: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_268:
	/* 0x268: mov x23, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_26c:
	/* 0x26c: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_270:
	/* 0x270: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_274:
	/* 0x274: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x278ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_278:
	/* 0x278: ldr w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_27c:
	/* 0x27c: mov x19, x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_280:
	/* 0x280: str w8, [x19, #80]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 80ULL);
arm64_l_284:
	/* 0x284: mov w8, #0x7d */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 125ULL);
arm64_l_288:
	/* 0x288: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 125ULL: ARM64_SIM_A64_LINK(0x28cULL); ARM64_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_28c:
	/* 0x28c: str x0, [x29, #24344] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24344ULL);
arm64_l_290:
	/* 0x290: str wzr, [x19, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_294:
	/* 0x294: add x2, x23, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_298:
	/* 0x298: mov w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_29c:
	/* 0x29c: mov w9, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2a0:
	/* 0x2a0: add x10, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_2a4:
	/* 0x2a4: str xzr, [x29, #24360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24360ULL);
arm64_l_2a8:
	/* 0x2a8: str wzr, [x19, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2ac:
	/* 0x2ac: add x0, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_2b0:
	/* 0x2b0: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2b4:
	/* 0x2b4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2b8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2b8:
	/* 0x2b8: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_2bc:
	/* 0x2bc: str x20, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2c0:
	/* 0x2c0: str x19, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2c4:
	/* 0x2c4: cbz x8, 334 <generic_fentry_process_filter+0x334> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x2c4, 0x334, arm64_l_334);
arm64_l_2c8:
	/* 0x2c8: add x8, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2cc:
	/* 0x2cc: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2d0:
	/* 0x2d0: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2d4:
	/* 0x2d4: add x11, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_2d8:
	/* 0x2d8: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_2dc:
	/* 0x2dc: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_2e0:
	/* 0x2e0: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2e4:
	/* 0x2e4: add x2, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2e8:
	/* 0x2e8: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2ecULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2ec:
	/* 0x2ec: ldr w8, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_2f0:
	/* 0x2f0: cbz w8, 334 <generic_fentry_process_filter+0x334> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x2f0, 0x334, arm64_l_334);
arm64_l_2f4:
	/* 0x2f4: ldr x9, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_2f8:
	/* 0x2f8: lsl w8, w8, #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 4ULL);
arm64_l_2fc:
	/* 0x2fc: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_300:
	/* 0x300: add x11, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_304:
	/* 0x304: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_308:
	/* 0x308: mov w1, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_30c:
	/* 0x30c: add x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_310:
	/* 0x310: mov w9, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_314:
	/* 0x314: add x8, x8, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_318:
	/* 0x318: ldr w9, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_31c:
	/* 0x31c: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_320:
	/* 0x320: lsl w9, w9, #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 4ULL);
arm64_l_324:
	/* 0x324: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_328:
	/* 0x328: add x2, x8, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_32c:
	/* 0x32c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x330ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_330:
	/* 0x330: ldr w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_334:
	/* 0x334: str w8, [x21, #116] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 116ULL);
arm64_l_338:
	/* 0x338: mov w8, #0x5f60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24416ULL);
arm64_l_33c:
	/* 0x33c: add x2, x23, #0xae0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2784ULL);
arm64_l_340:
	/* 0x340: mov w19, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_344:
	/* 0x344: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_348:
	/* 0x348: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_34c:
	/* 0x34c: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_350:
	/* 0x350: add x24, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_354:
	/* 0x354: add x8, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_358:
	/* 0x358: mov x22, x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_35c:
	/* 0x35c: mov w21, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_360:
	/* 0x360: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x364ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_364:
	/* 0x364: ldr x20, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_368:
	/* 0x368: mov w8, #0x5f68 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24424ULL);
arm64_l_36c:
	/* 0x36c: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_370:
	/* 0x370: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_374:
	/* 0x374: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_378:
	/* 0x378: add x2, x20, #0x40 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_37c:
	/* 0x37c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x380ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_380:
	/* 0x380: mov w8, #0x5f70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24432ULL);
arm64_l_384:
	/* 0x384: add x2, x20, #0x30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_388:
	/* 0x388: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_38c:
	/* 0x38c: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_390:
	/* 0x390: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_394:
	/* 0x394: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x398ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_398:
	/* 0x398: add x2, x20, #0x38 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_39c:
	/* 0x39c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_3a0:
	/* 0x3a0: mov x0, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3a4:
	/* 0x3a4: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3a8:
	/* 0x3a8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x3acULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3ac:
	/* 0x3ac: mov w8, #0x5f38 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24376ULL);
arm64_l_3b0:
	/* 0x3b0: add x2, x23, #0xb50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2896ULL);
arm64_l_3b4:
	/* 0x3b4: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_3b8:
	/* 0x3b8: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_3bc:
	/* 0x3bc: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3c0:
	/* 0x3c0: add x24, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_3c4:
	/* 0x3c4: add x8, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_3c8:
	/* 0x3c8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x3ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3cc:
	/* 0x3cc: add x12, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_3d0:
	/* 0x3d0: mov w9, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 72ULL);
arm64_l_3d4:
	/* 0x3d4: add x10, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_3d8:
	/* 0x3d8: ldr x8, [x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3dc:
	/* 0x3dc: mov w11, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_3e0:
	/* 0x3e0: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_3e4:
	/* 0x3e4: mov w1, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 72ULL);
arm64_l_3e8:
	/* 0x3e8: ldr x2, [x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3ec:
	/* 0x3ec: blr x11 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X11);
		if (ARM64_SIM_L_REG_TAG(ARM64_X11) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x3f0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3f0:
	/* 0x3f0: ldr x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_3f4:
	/* 0x3f4: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_3f8:
	/* 0x3f8: mov x0, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3fc:
	/* 0x3fc: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_400:
	/* 0x400: add x8, x8, #0x218 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 536ULL);
arm64_l_404:
	/* 0x404: ldr x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_408:
	/* 0x408: add x2, x8, #0x218 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 536ULL);
arm64_l_40c:
	/* 0x40c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x410ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_410:
	/* 0x410: mov w8, #0x5f3c */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24380ULL);
arm64_l_414:
	/* 0x414: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_418:
	/* 0x418: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_41c:
	/* 0x41c: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_420:
	/* 0x420: ldr x8, [sp, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_424:
	/* 0x424: add x8, x8, #0x4d8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1240ULL);
arm64_l_428:
	/* 0x428: ldr x8, [sp, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_42c:
	/* 0x42c: add x2, x8, #0x4d8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1240ULL);
arm64_l_430:
	/* 0x430: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x434ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_434:
	/* 0x434: mov w8, #0x5f40 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24384ULL);
arm64_l_438:
	/* 0x438: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_43c:
	/* 0x43c: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_440:
	/* 0x440: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_444:
	/* 0x444: ldr x8, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_448:
	/* 0x448: add x8, x8, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_44c:
	/* 0x44c: ldr x8, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_450:
	/* 0x450: add x2, x8, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_454:
	/* 0x454: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x458ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_458:
	/* 0x458: str xzr, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_45c:
	/* 0x45c: add x2, x23, #0x938 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2360ULL);
arm64_l_460:
	/* 0x460: add x8, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_464:
	/* 0x464: add x0, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_468:
	/* 0x468: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_46c:
	/* 0x46c: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x470ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_470:
	/* 0x470: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_474:
	/* 0x474: cbz x8, 4fc <generic_fentry_process_filter+0x4fc> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x474, 0x4fc, arm64_l_4fc);
arm64_l_478:
	/* 0x478: str wzr, [sp, #184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_47c:
	/* 0x47c: add x8, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_480:
	/* 0x480: add x9, sp, #0xb8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 184ULL);
arm64_l_484:
	/* 0x484: mov w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_488:
	/* 0x488: add x0, sp, #0xb8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 184ULL);
arm64_l_48c:
	/* 0x48c: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_490:
	/* 0x490: mov w19, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_494:
	/* 0x494: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_498:
	/* 0x498: add x2, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_49c:
	/* 0x49c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x4a0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_4a0:
	/* 0x4a0: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_4a4:
	/* 0x4a4: ldrsw x9, [sp, #184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDRSW, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_4a8:
	/* 0x4a8: add x10, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_4ac:
	/* 0x4ac: mov w11, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_4b0:
	/* 0x4b0: add x0, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_4b4:
	/* 0x4b4: mov w1, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_4b8:
	/* 0x4b8: add x8, x8, x9, lsl #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 4), 0);
arm64_l_4bc:
	/* 0x4bc: mov w9, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_4c0:
	/* 0x4c0: add x8, x8, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_4c4:
	/* 0x4c4: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_4c8:
	/* 0x4c8: ldrsw x9, [sp, #184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDRSW, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_4cc:
	/* 0x4cc: add x8, x8, x9, lsl #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 4), 0);
arm64_l_4d0:
	/* 0x4d0: add x2, x8, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_4d4:
	/* 0x4d4: blr x11 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X11);
		if (ARM64_SIM_L_REG_TAG(ARM64_X11) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x4d8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_4d8:
	/* 0x4d8: mov w8, #0x5f44 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24388ULL);
arm64_l_4dc:
	/* 0x4dc: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_4e0:
	/* 0x4e0: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_4e4:
	/* 0x4e4: ldr x8, [sp, #208] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_4e8:
	/* 0x4e8: add x8, x8, #0x158 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_4ec:
	/* 0x4ec: ldr x8, [sp, #208] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_4f0:
	/* 0x4f0: add x2, x8, #0x158 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_4f4:
	/* 0x4f4: blr x19 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X19);
		if (ARM64_SIM_L_REG_TAG(ARM64_X19) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x4f8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_4f8:
	/* 0x4f8: b 500 <generic_fentry_process_filter+0x500> */
	ARM64_SIM_A64_JMP(0x4f8, 0x500, arm64_l_500);
arm64_l_4fc:
	/* 0x4fc: str wzr, [x22, #132] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 132ULL);
arm64_l_500:
	/* 0x500: mov w8, #0x5f48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24392ULL);
arm64_l_504:
	/* 0x504: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_508:
	/* 0x508: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_50c:
	/* 0x50c: mov x21, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_510:
	/* 0x510: mov w19, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_514:
	/* 0x514: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_518:
	/* 0x518: ldr x8, [sp, #120] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_51c:
	/* 0x51c: add x8, x8, #0x158 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_520:
	/* 0x520: ldr x8, [sp, #120] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_524:
	/* 0x524: add x2, x8, #0x158 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_528:
	/* 0x528: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x52cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_52c:
	/* 0x52c: mov w8, #0x5f4c */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24396ULL);
arm64_l_530:
	/* 0x530: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_534:
	/* 0x534: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_538:
	/* 0x538: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_53c:
	/* 0x53c: ldr x8, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_540:
	/* 0x540: add x8, x8, #0x118 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 280ULL);
arm64_l_544:
	/* 0x544: ldr x8, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_548:
	/* 0x548: add x2, x8, #0x118 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 280ULL);
arm64_l_54c:
	/* 0x54c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x550ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_550:
	/* 0x550: mov w8, #0x5f50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24400ULL);
arm64_l_554:
	/* 0x554: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_558:
	/* 0x558: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_55c:
	/* 0x55c: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_560:
	/* 0x560: ldr x8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_564:
	/* 0x564: add x8, x8, #0x98 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_568:
	/* 0x568: ldr x8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_56c:
	/* 0x56c: add x2, x8, #0x98 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_570:
	/* 0x570: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x574ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_574:
	/* 0x574: mov w8, #0x5f54 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24404ULL);
arm64_l_578:
	/* 0x578: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_57c:
	/* 0x57c: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_580:
	/* 0x580: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_584:
	/* 0x584: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_588:
	/* 0x588: add x8, x8, #0x98 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_58c:
	/* 0x58c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_590:
	/* 0x590: add x2, x8, #0x98 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_594:
	/* 0x594: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x598ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_598:
	/* 0x598: mov w8, #0x5f58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24408ULL);
arm64_l_59c:
	/* 0x59c: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_5a0:
	/* 0x5a0: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_5a4:
	/* 0x5a4: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_5a8:
	/* 0x5a8: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_5ac:
	/* 0x5ac: add x8, x8, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_5b0:
	/* 0x5b0: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_5b4:
	/* 0x5b4: add x2, x8, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_5b8:
	/* 0x5b8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x5bcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_5bc:
	/* 0x5bc: str xzr, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_5c0:
	/* 0x5c0: add x24, x23, #0x858 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2136ULL);
arm64_l_5c4:
	/* 0x5c4: mov w20, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_5c8:
	/* 0x5c8: add x8, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_5cc:
	/* 0x5cc: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_5d0:
	/* 0x5d0: add x0, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_5d4:
	/* 0x5d4: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_5d8:
	/* 0x5d8: mov x2, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5dc:
	/* 0x5dc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x5e0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_5e0:
	/* 0x5e0: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_5e4:
	/* 0x5e4: add x9, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_5e8:
	/* 0x5e8: mov w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_5ec:
	/* 0x5ec: add x0, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_5f0:
	/* 0x5f0: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_5f4:
	/* 0x5f4: add x8, x8, #0x520 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1312ULL);
arm64_l_5f8:
	/* 0x5f8: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_5fc:
	/* 0x5fc: add x2, x8, #0x520 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1312ULL);
arm64_l_600:
	/* 0x600: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x604ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_604:
	/* 0x604: mov w8, #0x5f5c */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24412ULL);
arm64_l_608:
	/* 0x608: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_60c:
	/* 0x60c: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_610:
	/* 0x610: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_614:
	/* 0x614: add x8, x8, #0x158 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_618:
	/* 0x618: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_61c:
	/* 0x61c: add x2, x8, #0x158 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_620:
	/* 0x620: blr x19 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X19);
		if (ARM64_SIM_L_REG_TAG(ARM64_X19) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x624ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_624:
	/* 0x624: ldr w8, [x22, #116] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 116ULL);
arm64_l_628:
	/* 0x628: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_62c:
	/* 0x62c: b.ne 63c <generic_fentry_process_filter+0x63c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x62c, 0x63c, arm64_l_63c);
arm64_l_630:
	/* 0x630: ldr w8, [x21, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_634:
	/* 0x634: orr w8, w8, #0x2000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 33554432ULL);
arm64_l_638:
	/* 0x638: str w8, [x21, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_63c:
	/* 0x63c: add x0, x21, #0xb8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 184ULL);
arm64_l_640:
	/* 0x640: mov w1, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_644:
	/* 0x644: mov w2, #0x308 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 776ULL);
arm64_l_648:
	/* 0x648: bl 0 <memset> */
	ARM64_SIM_A64_CALL(arm64_l_0, 0x64cULL);
arm64_l_64c:
	/* 0x64c: mov w8, #0x6290 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 25232ULL);
arm64_l_650:
	/* 0x650: str x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_654:
	/* 0x654: mov w19, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_658:
	/* 0x658: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_65c:
	/* 0x65c: add x0, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_660:
	/* 0x660: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_664:
	/* 0x664: mov x2, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_668:
	/* 0x668: add x22, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_66c:
	/* 0x66c: add x8, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_670:
	/* 0x670: mov w20, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_674:
	/* 0x674: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x678ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_678:
	/* 0x678: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_67c:
	/* 0x67c: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_680:
	/* 0x680: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_684:
	/* 0x684: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_688:
	/* 0x688: add x8, x8, #0x528 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1320ULL);
arm64_l_68c:
	/* 0x68c: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_690:
	/* 0x690: add x2, x8, #0x528 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1320ULL);
arm64_l_694:
	/* 0x694: blr x20 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X20);
		if (ARM64_SIM_L_REG_TAG(ARM64_X20) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x698ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_698:
	/* 0x698: str wzr, [sp, #164] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 164ULL);
arm64_l_69c:
	/* 0x69c: adrp x0, 0 <buffer_heap_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&buffer_heap_map_3));
arm64_l_6a0:
	/* 0x6a0: ldr x19, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_6a4:
	/* 0x6a4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_6a8:
	/* 0x6a8: add x9, sp, #0xa4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 164ULL);
arm64_l_6ac:
	/* 0x6ac: add x1, sp, #0xa4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 164ULL);
arm64_l_6b0:
	/* 0x6b0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6b4:
	/* 0x6b4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x6b8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_6b8:
	/* 0x6b8: cbz x0, b70 <generic_fentry_process_filter+0xb70> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x6b8, 0xb70, arm64_l_b70);
arm64_l_6bc:
	/* 0x6bc: mov w8, #0x1000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_6c0:
	/* 0x6c0: str x22, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_6c4:
	/* 0x6c4: str x21, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_6c8:
	/* 0x6c8: mov x24, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6cc:
	/* 0x6cc: add x20, x0, #0x1, lsl #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_6d0:
	/* 0x6d0: str w8, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_6d4:
	/* 0x6d4: mov w8, #0x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 35ULL);
arm64_l_6d8:
	/* 0x6d8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 35ULL: ARM64_SIM_A64_LINK(0x6dcULL); ARM64_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_6dc:
	/* 0x6dc: add x2, x0, #0xb30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2864ULL);
arm64_l_6e0:
	/* 0x6e0: mov w23, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_6e4:
	/* 0x6e4: add x8, sp, #0xa8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_6e8:
	/* 0x6e8: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_6ec:
	/* 0x6ec: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_6f0:
	/* 0x6f0: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_6f4:
	/* 0x6f4: mov w29, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_6f8:
	/* 0x6f8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x6fcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_6fc:
	/* 0x6fc: ldr x22, [sp, #168] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_700:
	/* 0x700: add x25, x19, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_704:
	/* 0x704: add x8, sp, #0xb0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 176ULL);
arm64_l_708:
	/* 0x708: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_70c:
	/* 0x70c: add x0, sp, #0xb0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 176ULL);
arm64_l_710:
	/* 0x710: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_714:
	/* 0x714: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_718:
	/* 0x718: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x71cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_71c:
	/* 0x71c: ldr x21, [sp, #176] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_720:
	/* 0x720: add x8, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_724:
	/* 0x724: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_728:
	/* 0x728: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_72c:
	/* 0x72c: add x2, x21, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_730:
	/* 0x730: blr x29 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X29);
		if (ARM64_SIM_L_REG_TAG(ARM64_X29) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x734ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_734:
	/* 0x734: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_738:
	/* 0x738: cbz x8, 96c <generic_fentry_process_filter+0x96c> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x738, 0x96c, arm64_l_96c);
arm64_l_73c:
	/* 0x73c: ldr x8, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_740:
	/* 0x740: stp xzr, xzr, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_744:
	/* 0x744: add x21, x22, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_748:
	/* 0x748: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_74c:
	/* 0x74c: add x2, x22, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_750:
	/* 0x750: mov w22, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_754:
	/* 0x754: stp x24, xzr, [sp, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_758:
	/* 0x758: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_75c:
	/* 0x75c: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_760:
	/* 0x760: add x29, x19, #0x40 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_764:
	/* 0x764: add x19, x9, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_768:
	/* 0x768: add x24, x9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_76c:
	/* 0x76c: stp xzr, xzr, [sp, #120] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_770:
	/* 0x770: add x23, x9, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_774:
	/* 0x774: str x20, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_778:
	/* 0x778: str x20, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_77c:
	/* 0x77c: mov w20, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_780:
	/* 0x780: ldr w8, [x8, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_784:
	/* 0x784: strb wzr, [sp, #148] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 148ULL);
arm64_l_788:
	/* 0x788: str w8, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_78c:
	/* 0x78c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_790:
	/* 0x790: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x794ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_794:
	/* 0x794: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_798:
	/* 0x798: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_79c:
	/* 0x79c: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_7a0:
	/* 0x7a0: mov x2, x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7a4:
	/* 0x7a4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x7a8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_7a8:
	/* 0x7a8: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_7ac:
	/* 0x7ac: mov x0, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7b0:
	/* 0x7b0: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_7b4:
	/* 0x7b4: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7b8:
	/* 0x7b8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x7bcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_7bc:
	/* 0x7bc: mov x0, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7c0:
	/* 0x7c0: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_7c4:
	/* 0x7c4: mov x2, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7c8:
	/* 0x7c8: blr x20 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X20);
		if (ARM64_SIM_L_REG_TAG(ARM64_X20) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x7ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_7cc:
	/* 0x7cc: ldr x8, [sp, #120] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_7d0:
	/* 0x7d0: sub x8, x8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_7d4:
	/* 0x7d4: str x8, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_7d8:
	/* 0x7d8: adrp x8, 0 <CONFIG_ITER_NUM> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM_0));
arm64_l_7dc:
	/* 0x7dc: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_7e0:
	/* 0x7e0: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_7e4:
	/* 0x7e4: cbz w8, 9c0 <generic_fentry_process_filter+0x9c0> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x7e4, 0x9c0, arm64_l_9c0);
arm64_l_7e8:
	/* 0x7e8: mov w19, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_7ec:
	/* 0x7ec: mov w21, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_7f0:
	/* 0x7f0: add x23, sp, #0xb8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 184ULL);
arm64_l_7f4:
	/* 0x7f4: add x29, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_7f8:
	/* 0x7f8: ldp x20, x2, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_7fc:
	/* 0x7fc: ldp x8, x9, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_800:
	/* 0x800: cmp x20, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_804:
	/* 0x804: ccmp x2, x9, #0x0, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X2, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_EQ, 0), 0);
arm64_l_808:
	/* 0x808: b.eq a34 <generic_fentry_process_filter+0xa34> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x808, 0xa34, arm64_l_a34);
arm64_l_80c:
	/* 0x80c: ldr x22, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_810:
	/* 0x810: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_814:
	/* 0x814: add x0, sp, #0xb8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 184ULL);
arm64_l_818:
	/* 0x818: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_81c:
	/* 0x81c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x820ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_820:
	/* 0x820: ldr x8, [sp, #184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_824:
	/* 0x824: cmp x20, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_828:
	/* 0x828: b.eq 918 <generic_fentry_process_filter+0x918> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x828, 0x918, arm64_l_918);
arm64_l_82c:
	/* 0x82c: add x25, x20, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_830:
	/* 0x830: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_834:
	/* 0x834: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_838:
	/* 0x838: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_83c:
	/* 0x83c: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_840:
	/* 0x840: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x844ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_844:
	/* 0x844: add x8, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_848:
	/* 0x848: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_84c:
	/* 0x84c: cmp x8, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_850:
	/* 0x850: b.eq 918 <generic_fentry_process_filter+0x918> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x850, 0x918, arm64_l_918);
arm64_l_854:
	/* 0x854: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_858:
	/* 0x858: add x9, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_85c:
	/* 0x85c: add x0, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_860:
	/* 0x860: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_864:
	/* 0x864: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_868:
	/* 0x868: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x86cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_86c:
	/* 0x86c: add x2, x20, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_870:
	/* 0x870: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_874:
	/* 0x874: mov w9, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_878:
	/* 0x878: add x10, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_87c:
	/* 0x87c: add x0, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_880:
	/* 0x880: mov w1, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_884:
	/* 0x884: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x888ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_888:
	/* 0x888: ldr w20, [sp, #204] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 204ULL);
arm64_l_88c:
	/* 0x88c: ldr x8, [sp, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_890:
	/* 0x890: ldr x10, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_894:
	/* 0x894: sub x12, x10, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_898:
	/* 0x898: ldr w22, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_89c:
	/* 0x89c: subs w10, w20, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X10, ARM64_X20, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8a0:
	/* 0x8a0: ldr x9, [sp, #208] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_8a4:
	/* 0x8a4: csel w10, wzr, w10, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X10, ARM64_XZR, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_8a8:
	/* 0x8a8: cmp w22, w20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X22, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8ac:
	/* 0x8ac: csel w11, w22, w20, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X22, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_8b0:
	/* 0x8b0: cinc w13, w11, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CINC, ARM64_X13, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_8b4:
	/* 0x8b4: sub w14, w22, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X22, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_8b8:
	/* 0x8b8: subs x12, x12, x13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X12, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8bc:
	/* 0x8bc: str w14, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_8c0:
	/* 0x8c0: b.cc 9e4 <generic_fentry_process_filter+0x9e4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x8c0, 0x9e4, arm64_l_9e4);
arm64_l_8c4:
	/* 0x8c4: cmp x12, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_8c8:
	/* 0x8c8: b.hi 9e4 <generic_fentry_process_filter+0x9e4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x8c8, 0x9e4, arm64_l_9e4);
arm64_l_8cc:
	/* 0x8cc: cmp w22, w20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X22, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8d0:
	/* 0x8d0: b.ls 8dc <generic_fentry_process_filter+0x8dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x8d0, 0x8dc, arm64_l_8dc);
arm64_l_8d4:
	/* 0x8d4: mov w13, #0x2f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_8d8:
	/* 0x8d8: strb w13, [x8, x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X12, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_8dc:
	/* 0x8dc: add x25, x8, x12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X25, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_8e0:
	/* 0x8e0: cmp w22, w20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X22, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8e4:
	/* 0x8e4: add x2, x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_8e8:
	/* 0x8e8: and w1, w11, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_8ec:
	/* 0x8ec: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_8f0:
	/* 0x8f0: cinc x0, x25, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CINC, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_HI, 0);
arm64_l_8f4:
	/* 0x8f4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x8f8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_8f8:
	/* 0x8f8: cmp w22, w20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X22, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8fc:
	/* 0x8fc: str x25, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_900:
	/* 0x900: b.ls 9e4 <generic_fentry_process_filter+0x9e4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x900, 0x9e4, arm64_l_9e4);
arm64_l_904:
	/* 0x904: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_908:
	/* 0x908: str x8, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_90c:
	/* 0x90c: subs w19, w19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_910:
	/* 0x910: b.ne 7f8 <generic_fentry_process_filter+0x7f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x910, 0x7f8, arm64_l_7f8);
arm64_l_914:
	/* 0x914: b 9e4 <generic_fentry_process_filter+0x9e4> */
	ARM64_SIM_A64_JMP(0x914, 0x9e4, arm64_l_9e4);
arm64_l_918:
	/* 0x918: add x2, x22, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_91c:
	/* 0x91c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_920:
	/* 0x920: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_924:
	/* 0x924: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_928:
	/* 0x928: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x92cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_92c:
	/* 0x92c: add x20, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_930:
	/* 0x930: ldr x8, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_934:
	/* 0x934: ldr x9, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_938:
	/* 0x938: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_93c:
	/* 0x93c: b.eq a34 <generic_fentry_process_filter+0xa34> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x93c, 0xa34, arm64_l_a34);
arm64_l_940:
	/* 0x940: add x2, x22, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_944:
	/* 0x944: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_948:
	/* 0x948: mov x0, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_94c:
	/* 0x94c: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_950:
	/* 0x950: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x954ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_954:
	/* 0x954: ldr x8, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_958:
	/* 0x958: add x9, x8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_95c:
	/* 0x95c: stp x9, x8, [sp, #120] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_960:
	/* 0x960: subs w19, w19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_964:
	/* 0x964: b.ne 7f8 <generic_fentry_process_filter+0x7f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x964, 0x7f8, arm64_l_7f8);
arm64_l_968:
	/* 0x968: b 9e4 <generic_fentry_process_filter+0x9e4> */
	ARM64_SIM_A64_JMP(0x968, 0x9e4, arm64_l_9e4);
arm64_l_96c:
	/* 0x96c: add x2, x21, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_970:
	/* 0x970: mov w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_974:
	/* 0x974: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_978:
	/* 0x978: add x10, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_97c:
	/* 0x97c: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_980:
	/* 0x980: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_984:
	/* 0x984: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x988ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_988:
	/* 0x988: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_98c:
	/* 0x98c: cmp x8, x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_990:
	/* 0x990: b.eq 73c <generic_fentry_process_filter+0x73c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x990, 0x73c, arm64_l_73c);
arm64_l_994:
	/* 0x994: ldr x21, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_998:
	/* 0x998: ldr w9, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_99c:
	/* 0x99c: sub w8, w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_9a0:
	/* 0x9a0: cmp w9, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_9a4:
	/* 0x9a4: str w8, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_9a8:
	/* 0x9a8: b.gt f1c <generic_fentry_process_filter+0xf1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x9a8, 0xf1c, arm64_l_f1c);
arm64_l_9ac:
	/* 0x9ac: ldr x22, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_9b0:
	/* 0x9b0: mov w9, #0xffffffdc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967260ULL);
arm64_l_9b4:
	/* 0x9b4: mov x24, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_9b8:
	/* 0x9b8: str w9, [x21, #1364] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1364ULL);
arm64_l_9bc:
	/* 0x9bc: b a60 <generic_fentry_process_filter+0xa60> */
	ARM64_SIM_A64_JMP(0x9bc, 0xa60, arm64_l_a60);
arm64_l_9c0:
	/* 0x9c0: mov x3, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_9c4:
	/* 0x9c4: adrp x1, 0 <generic_fentry_process_filter> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_RODATA, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)__arm64_rodata_0));
arm64_l_9c8:
	/* 0x9c8: add x1, x1, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_9cc:
	/* 0x9cc: mov w8, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_9d0:
	/* 0x9d0: mov w9, #0xb5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 181ULL);
arm64_l_9d4:
	/* 0x9d4: add x10, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_9d8:
	/* 0x9d8: add x2, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_9dc:
	/* 0x9dc: mov w0, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_9e0:
	/* 0x9e0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 181ULL: ARM64_SIM_A64_LINK(0x9e4ULL); ARM64_SIM_BPF_CALL_bpf_loop(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_9e4:
	/* 0x9e4: ldr x24, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_9e8:
	/* 0x9e8: ldr x9, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_9ec:
	/* 0x9ec: cmp x24, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_9f0:
	/* 0x9f0: b.eq a4c <generic_fentry_process_filter+0xa4c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x9f0, 0xa4c, arm64_l_a4c);
arm64_l_9f4:
	/* 0x9f4: ldrb w8, [sp, #148] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 148ULL);
arm64_l_9f8:
	/* 0x9f8: ldr x21, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_9fc:
	/* 0x9fc: cmp w8, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_a00:
	/* 0xa00: ldr x22, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_a04:
	/* 0xa04: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_a08:
	/* 0xa08: lsl w9, w8, #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 1ULL);
arm64_l_a0c:
	/* 0xa0c: ldr w8, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_a10:
	/* 0xa10: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_a14:
	/* 0xa14: str w8, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_a18:
	/* 0xa18: str w9, [x21, #1364] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1364ULL);
arm64_l_a1c:
	/* 0xa1c: b.lt a2c <generic_fentry_process_filter+0xa2c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0xa1c, 0xa2c, arm64_l_a2c);
arm64_l_a20:
	/* 0xa20: mov w9, #0x1000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_a24:
	/* 0xa24: sub w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_a28:
	/* 0xa28: str w8, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_a2c:
	/* 0xa2c: cbnz x24, a60 <generic_fentry_process_filter+0xa60> */
	ARM64_SIM_A64_CBNZ(ARM64_X24, 0xa2c, 0xa60, arm64_l_a60);
arm64_l_a30:
	/* 0xa30: b b70 <generic_fentry_process_filter+0xb70> */
	ARM64_SIM_A64_JMP(0xa30, 0xb70, arm64_l_b70);
arm64_l_a34:
	/* 0xa34: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a38:
	/* 0xa38: strb w8, [sp, #148] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 148ULL);
arm64_l_a3c:
	/* 0xa3c: ldr x24, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_a40:
	/* 0xa40: ldr x9, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_a44:
	/* 0xa44: cmp x24, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_a48:
	/* 0xa48: b.ne 9f4 <generic_fentry_process_filter+0x9f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xa48, 0x9f4, arm64_l_9f4);
arm64_l_a4c:
	/* 0xa4c: ldr x21, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_a50:
	/* 0xa50: ldr x22, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_a54:
	/* 0xa54: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_a58:
	/* 0xa58: mov x24, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a5c:
	/* 0xa5c: str xzr, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_a60:
	/* 0xa60: subs w9, w8, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_a64:
	/* 0xa64: mov w10, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_a68:
	/* 0xa68: mov x0, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a6c:
	/* 0xa6c: mov x2, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a70:
	/* 0xa70: csel w29, w8, w10, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X29, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_a74:
	/* 0xa74: csel w19, wzr, w9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X19, ARM64_XZR, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_a78:
	/* 0xa78: cmp w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_a7c:
	/* 0xa7c: mov w9, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 255ULL);
arm64_l_a80:
	/* 0xa80: csel w8, w8, w9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_a84:
	/* 0xa84: str w8, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_a88:
	/* 0xa88: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_a8c:
	/* 0xa8c: ldr w1, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_a90:
	/* 0xa90: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xa94ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_a94:
	/* 0xa94: adrp x25, 0 <tg_errmetrics_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_errmetrics_map_13));
arm64_l_a98:
	/* 0xa98: ldr x25, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a9c:
	/* 0xa9c: cbz x0, b0c <generic_fentry_process_filter+0xb0c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xa9c, 0xb0c, arm64_l_b0c);
arm64_l_aa0:
	/* 0xaa0: neg w8, w0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_aa4:
	/* 0xaa4: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_aa8:
	/* 0xaa8: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_aac:
	/* 0xaac: strh w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_ab0:
	/* 0xab0: mov w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_ab4:
	/* 0xab4: mov x0, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ab8:
	/* 0xab8: mov w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_abc:
	/* 0xabc: strh w8, [sp, #90] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 90ULL);
arm64_l_ac0:
	/* 0xac0: mov x8, #0x2da */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 730ULL);
arm64_l_ac4:
	/* 0xac4: movk x8, #0x4, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 4ULL);
arm64_l_ac8:
	/* 0xac8: stur x8, [sp, #92] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_acc:
	/* 0xacc: add x8, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_ad0:
	/* 0xad0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xad4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_ad4:
	/* 0xad4: cbz x0, ae8 <generic_fentry_process_filter+0xae8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xad4, 0xae8, arm64_l_ae8);
arm64_l_ad8:
	/* 0xad8: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_adc:
	/* 0xadc: add w8, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_ae0:
	/* 0xae0: str w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ae4:
	/* 0xae4: b b0c <generic_fentry_process_filter+0xb0c> */
	ARM64_SIM_A64_JMP(0xae4, 0xb0c, arm64_l_b0c);
arm64_l_ae8:
	/* 0xae8: str w20, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_aec:
	/* 0xaec: mov x3, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_af0:
	/* 0xaf0: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_af4:
	/* 0xaf4: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_af8:
	/* 0xaf8: add x10, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_afc:
	/* 0xafc: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_b00:
	/* 0xb00: add x2, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_b04:
	/* 0xb04: mov x0, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b08:
	/* 0xb08: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0xb0cULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_b0c:
	/* 0xb0c: ldr x9, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_b10:
	/* 0xb10: mov w8, #0x6390 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 25488ULL);
arm64_l_b14:
	/* 0xb14: add x2, x24, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X24, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_b18:
	/* 0xb18: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_b1c:
	/* 0xb1c: add x0, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_b20:
	/* 0xb20: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_b24:
	/* 0xb24: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xb28ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_b28:
	/* 0xb28: cbz x0, b70 <generic_fentry_process_filter+0xb70> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xb28, 0xb70, arm64_l_b70);
arm64_l_b2c:
	/* 0xb2c: neg w8, w0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_b30:
	/* 0xb30: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_b34:
	/* 0xb34: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_b38:
	/* 0xb38: strh w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_b3c:
	/* 0xb3c: mov w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_b40:
	/* 0xb40: mov x0, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b44:
	/* 0xb44: mov w19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_b48:
	/* 0xb48: strh w8, [sp, #90] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 90ULL);
arm64_l_b4c:
	/* 0xb4c: mov x8, #0x2dc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 732ULL);
arm64_l_b50:
	/* 0xb50: movk x8, #0x4, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 4ULL);
arm64_l_b54:
	/* 0xb54: stur x8, [sp, #92] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_b58:
	/* 0xb58: add x8, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_b5c:
	/* 0xb5c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xb60ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_b60:
	/* 0xb60: cbz x0, b94 <generic_fentry_process_filter+0xb94> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xb60, 0xb94, arm64_l_b94);
arm64_l_b64:
	/* 0xb64: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b68:
	/* 0xb68: add w8, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_b6c:
	/* 0xb6c: str w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b70:
	/* 0xb70: ldr w8, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_b74:
	/* 0xb74: sub w9, w8, #0x101 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 257ULL);
arm64_l_b78:
	/* 0xb78: cmn w9, #0x101 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 257ULL);
arm64_l_b7c:
	/* 0xb7c: b.hi bc8 <generic_fentry_process_filter+0xbc8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xb7c, 0xbc8, arm64_l_bc8);
arm64_l_b80:
	/* 0xb80: ldp x20, x29, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_b84:
	/* 0xb84: mov w8, #0xffffffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967295ULL);
arm64_l_b88:
	/* 0xb88: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_b8c:
	/* 0xb8c: stur w8, [x21, #184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_b90:
	/* 0xb90: b d14 <generic_fentry_process_filter+0xd14> */
	ARM64_SIM_A64_JMP(0xb90, 0xd14, arm64_l_d14);
arm64_l_b94:
	/* 0xb94: str w19, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_b98:
	/* 0xb98: mov x3, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b9c:
	/* 0xb9c: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_ba0:
	/* 0xba0: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_ba4:
	/* 0xba4: add x10, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_ba8:
	/* 0xba8: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_bac:
	/* 0xbac: add x2, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_bb0:
	/* 0xbb0: mov x0, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_bb4:
	/* 0xbb4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0xbb8ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_bb8:
	/* 0xbb8: ldr w8, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_bbc:
	/* 0xbbc: sub w9, w8, #0x101 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 257ULL);
arm64_l_bc0:
	/* 0xbc0: cmn w9, #0x101 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 257ULL);
arm64_l_bc4:
	/* 0xbc4: b.ls b80 <generic_fentry_process_filter+0xb80> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0xbc4, 0xb80, arm64_l_b80);
arm64_l_bc8:
	/* 0xbc8: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_bcc:
	/* 0xbcc: and x24, x8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_bd0:
	/* 0xbd0: mov w8, #0x5f80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24448ULL);
arm64_l_bd4:
	/* 0xbd4: mov x2, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_bd8:
	/* 0xbd8: mov w1, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_bdc:
	/* 0xbdc: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_be0:
	/* 0xbe0: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_be4:
	/* 0xbe4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xbe8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_be8:
	/* 0xbe8: mov x23, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_bec:
	/* 0xbec: cbz x0, c64 <generic_fentry_process_filter+0xc64> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xbec, 0xc64, arm64_l_c64);
arm64_l_bf0:
	/* 0xbf0: neg w8, w23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_bf4:
	/* 0xbf4: adrp x25, 0 <tg_errmetrics_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_errmetrics_map_13));
arm64_l_bf8:
	/* 0xbf8: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_bfc:
	/* 0xbfc: strh w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_c00:
	/* 0xc00: mov w8, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 15ULL);
arm64_l_c04:
	/* 0xc04: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_c08:
	/* 0xc08: mov w19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_c0c:
	/* 0xc0c: strh w8, [sp, #90] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 90ULL);
arm64_l_c10:
	/* 0xc10: mov x8, #0x168 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 360ULL);
arm64_l_c14:
	/* 0xc14: movk x8, #0x4, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 4ULL);
arm64_l_c18:
	/* 0xc18: stur x8, [sp, #92] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_c1c:
	/* 0xc1c: add x8, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_c20:
	/* 0xc20: ldr x25, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c24:
	/* 0xc24: mov x0, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c28:
	/* 0xc28: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xc2cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_c2c:
	/* 0xc2c: cbz x0, c40 <generic_fentry_process_filter+0xc40> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xc2c, 0xc40, arm64_l_c40);
arm64_l_c30:
	/* 0xc30: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c34:
	/* 0xc34: add w8, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_c38:
	/* 0xc38: str w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c3c:
	/* 0xc3c: b c64 <generic_fentry_process_filter+0xc64> */
	ARM64_SIM_A64_JMP(0xc3c, 0xc64, arm64_l_c64);
arm64_l_c40:
	/* 0xc40: str w19, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_c44:
	/* 0xc44: mov x3, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c48:
	/* 0xc48: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_c4c:
	/* 0xc4c: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_c50:
	/* 0xc50: add x10, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_c54:
	/* 0xc54: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_c58:
	/* 0xc58: add x2, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_c5c:
	/* 0xc5c: mov x0, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c60:
	/* 0xc60: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0xc64ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_c64:
	/* 0xc64: cmp w23, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_c68:
	/* 0xc68: csel w8, w24, w23, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_c6c:
	/* 0xc6c: cmp w24, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_c70:
	/* 0xc70: stur w8, [x21, #184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_c74:
	/* 0xc74: mov w8, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_c78:
	/* 0xc78: csel w1, w24, w8, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X1, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_c7c:
	/* 0xc7c: mov w8, #0x6080 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24704ULL);
arm64_l_c80:
	/* 0xc80: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_c84:
	/* 0xc84: mov w8, #0x6390 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 25488ULL);
arm64_l_c88:
	/* 0xc88: add x2, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_c8c:
	/* 0xc8c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_c90:
	/* 0xc90: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xc94ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_c94:
	/* 0xc94: ldr x20, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_c98:
	/* 0xc98: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_c9c:
	/* 0xc9c: cbz x0, d14 <generic_fentry_process_filter+0xd14> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xc9c, 0xd14, arm64_l_d14);
arm64_l_ca0:
	/* 0xca0: neg w8, w0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_ca4:
	/* 0xca4: adrp x23, 0 <tg_errmetrics_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_errmetrics_map_13));
arm64_l_ca8:
	/* 0xca8: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_cac:
	/* 0xcac: strh w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_cb0:
	/* 0xcb0: mov w8, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 15ULL);
arm64_l_cb4:
	/* 0xcb4: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_cb8:
	/* 0xcb8: mov w19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_cbc:
	/* 0xcbc: strh w8, [sp, #90] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 90ULL);
arm64_l_cc0:
	/* 0xcc0: mov x8, #0x16e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 366ULL);
arm64_l_cc4:
	/* 0xcc4: movk x8, #0x4, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 4ULL);
arm64_l_cc8:
	/* 0xcc8: stur x8, [sp, #92] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_ccc:
	/* 0xccc: add x8, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_cd0:
	/* 0xcd0: ldr x23, [x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cd4:
	/* 0xcd4: mov x0, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_cd8:
	/* 0xcd8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xcdcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_cdc:
	/* 0xcdc: cbz x0, cf0 <generic_fentry_process_filter+0xcf0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xcdc, 0xcf0, arm64_l_cf0);
arm64_l_ce0:
	/* 0xce0: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ce4:
	/* 0xce4: add w8, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_ce8:
	/* 0xce8: str w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cec:
	/* 0xcec: b d14 <generic_fentry_process_filter+0xd14> */
	ARM64_SIM_A64_JMP(0xcec, 0xd14, arm64_l_d14);
arm64_l_cf0:
	/* 0xcf0: str w19, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_cf4:
	/* 0xcf4: mov x3, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_cf8:
	/* 0xcf8: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_cfc:
	/* 0xcfc: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_d00:
	/* 0xd00: add x10, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_d04:
	/* 0xd04: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_d08:
	/* 0xd08: add x2, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_d0c:
	/* 0xd0c: mov x0, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d10:
	/* 0xd10: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0xd14ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_d14:
	/* 0xd14: ldrb w8, [x29, #1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1ULL);
arm64_l_d18:
	/* 0xd18: orr w8, w8, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_d1c:
	/* 0xd1c: strb w8, [x29, #1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1ULL);
arm64_l_d20:
	/* 0xd20: adrp x0, 0 <filter_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&filter_map_6));
arm64_l_d24:
	/* 0xd24: mov w8, #0x5ef8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24312ULL);
arm64_l_d28:
	/* 0xd28: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d2c:
	/* 0xd2c: add x1, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X1, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_d30:
	/* 0xd30: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d34:
	/* 0xd34: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xd38ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_d38:
	/* 0xd38: cbz x0, 21dc <generic_fentry_process_filter+0x21dc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xd38, 0x21dc, arm64_l_21dc);
arm64_l_d3c:
	/* 0xd3c: str x21, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_d40:
	/* 0xd40: ldr x21, [x29, #24248] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24248ULL);
arm64_l_d44:
	/* 0xd44: cmp x21, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_d48:
	/* 0xd48: b.cs edc <generic_fentry_process_filter+0xedc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xd48, 0xedc, arm64_l_edc);
arm64_l_d4c:
	/* 0xd4c: ldrsw x8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDRSW, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d50:
	/* 0xd50: mov x23, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d54:
	/* 0xd54: cbz w8, efc <generic_fentry_process_filter+0xefc> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xd54, 0xefc, arm64_l_efc);
arm64_l_d58:
	/* 0xd58: cmp x21, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d5c:
	/* 0xd5c: b.cs edc <generic_fentry_process_filter+0xedc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xd5c, 0xedc, arm64_l_edc);
arm64_l_d60:
	/* 0xd60: stp x8, x20, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_d64:
	/* 0xd64: adrp x24, 0 <tg_mb_sel_opts> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mb_sel_opts_15));
arm64_l_d68:
	/* 0xd68: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d6c:
	/* 0xd6c: add x9, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_d70:
	/* 0xd70: add x1, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_d74:
	/* 0xd74: str x22, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_d78:
	/* 0xd78: str w21, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_d7c:
	/* 0xd7c: str wzr, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_d80:
	/* 0xd80: ldr x24, [x24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d84:
	/* 0xd84: mov x0, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d88:
	/* 0xd88: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xd8cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_d8c:
	/* 0xd8c: cbz x0, 11ac <generic_fentry_process_filter+0x11ac> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xd8c, 0x11ac, arm64_l_11ac);
arm64_l_d90:
	/* 0xd90: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d94:
	/* 0xd94: mov x25, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d98:
	/* 0xd98: cbz w8, 11ac <generic_fentry_process_filter+0x11ac> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xd98, 0x11ac, arm64_l_11ac);
arm64_l_d9c:
	/* 0xd9c: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_da0:
	/* 0xda0: str x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_da4:
	/* 0xda4: ldr w9, [x9, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_da8:
	/* 0xda8: tbnz w9, #31, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_TBNZ(ARM64_X9, 31, 0xda8, 0x1584, arm64_l_1584);
arm64_l_dac:
	/* 0xdac: cmp w8, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_db0:
	/* 0xdb0: b.hi 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xdb0, 0x1584, arm64_l_1584);
arm64_l_db4:
	/* 0xdb4: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_db8:
	/* 0xdb8: lsl w9, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_dbc:
	/* 0xdbc: tst w9, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_dc0:
	/* 0xdc0: b.ne fc0 <generic_fentry_process_filter+0xfc0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xdc0, 0xfc0, arm64_l_fc0);
arm64_l_dc4:
	/* 0xdc4: mov w10, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_dc8:
	/* 0xdc8: movk w10, #0x400, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 1024ULL);
arm64_l_dcc:
	/* 0xdcc: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_dd0:
	/* 0xdd0: b.ne f3c <generic_fentry_process_filter+0xf3c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xdd0, 0xf3c, arm64_l_f3c);
arm64_l_dd4:
	/* 0xdd4: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_dd8:
	/* 0xdd8: lsl w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_ddc:
	/* 0xddc: mov w9, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 512ULL);
arm64_l_de0:
	/* 0xde0: movk w9, #0x800, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 2048ULL);
arm64_l_de4:
	/* 0xde4: tst w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_de8:
	/* 0xde8: b.eq 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xde8, 0x1584, arm64_l_1584);
arm64_l_dec:
	/* 0xdec: adrp x0, 0 <string_postfix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_10));
arm64_l_df0:
	/* 0xdf0: add x1, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_df4:
	/* 0xdf4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_df8:
	/* 0xdf8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_dfc:
	/* 0xdfc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xe00ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_e00:
	/* 0xe00: cbz x0, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xe00, 0x1584, arm64_l_1584);
arm64_l_e04:
	/* 0xe04: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_e08:
	/* 0xe08: mov x20, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e0c:
	/* 0xe0c: adrp x0, 0 <string_postfix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap_11));
arm64_l_e10:
	/* 0xe10: mov w9, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_e14:
	/* 0xe14: ldr w8, [x8, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_e18:
	/* 0xe18: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e1c:
	/* 0xe1c: add x1, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_e20:
	/* 0xe20: cmp w8, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_e24:
	/* 0xe24: csel w19, w8, w9, lt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X19, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LT, 0);
arm64_l_e28:
	/* 0xe28: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_e2c:
	/* 0xe2c: add x9, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_e30:
	/* 0xe30: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xe34ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_e34:
	/* 0xe34: cbz x0, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xe34, 0x1584, arm64_l_1584);
arm64_l_e38:
	/* 0xe38: sxtw x1, w19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SXTW, ARM64_X1, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e3c:
	/* 0xe3c: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e40:
	/* 0xe40: lsl w8, w1, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_e44:
	/* 0xe44: str w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e48:
	/* 0xe48: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_e4c:
	/* 0xe4c: ldr w8, [x8, #108] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 108ULL);
arm64_l_e50:
	/* 0xe50: cbnz w8, eb0 <generic_fentry_process_filter+0xeb0> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0xe50, 0xeb0, arm64_l_eb0);
arm64_l_e54:
	/* 0xe54: ldr x11, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_e58:
	/* 0xe58: and w13, w1, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_e5c:
	/* 0xe5c: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e60:
	/* 0xe60: ldr w12, [x11, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_e64:
	/* 0xe64: add x9, x11, #0x1f0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 496ULL);
arm64_l_e68:
	/* 0xe68: add x10, x11, #0x170 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 368ULL);
arm64_l_e6c:
	/* 0xe6c: sub w11, w12, w1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X12, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_e70:
	/* 0xe70: add w12, w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_e74:
	/* 0xe74: add w11, w11, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X11, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_e78:
	/* 0xe78: mvn w13, w1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MVN, ARM64_X13, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_e7c:
	/* 0xe7c: add w12, w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_e80:
	/* 0xe80: cmp x8, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_e84:
	/* 0xe84: b.eq ea4 <generic_fentry_process_filter+0xea4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe84, 0xea4, arm64_l_ea4);
arm64_l_e88:
	/* 0xe88: and x13, x12, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_e8c:
	/* 0xe8c: sub w12, w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_e90:
	/* 0xe90: ldrb w13, [x10, x13] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X10, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X13, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e94:
	/* 0xe94: strb w13, [x9, x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X13, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e98:
	/* 0xe98: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_e9c:
	/* 0xe9c: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ea0:
	/* 0xea0: b.ne e80 <generic_fentry_process_filter+0xe80> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xea0, 0xe80, arm64_l_e80);
arm64_l_ea4:
	/* 0xea4: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_ea8:
	/* 0xea8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_eac:
	/* 0xeac: str w8, [x9, #108] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 108ULL);
arm64_l_eb0:
	/* 0xeb0: cmp w1, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_eb4:
	/* 0xeb4: b.hi ed0 <generic_fentry_process_filter+0xed0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xeb4, 0xed0, arm64_l_ed0);
arm64_l_eb8:
	/* 0xeb8: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_ebc:
	/* 0xebc: add x0, x29, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_ec0:
	/* 0xec0: add x2, x8, #0x1f0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 496ULL);
arm64_l_ec4:
	/* 0xec4: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_ec8:
	/* 0xec8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xeccULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_ecc:
	/* 0xecc: tbnz x0, #63, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0xecc, 0x1584, arm64_l_1584);
arm64_l_ed0:
	/* 0xed0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ed4:
	/* 0xed4: mov x0, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ed8:
	/* 0xed8: b fb8 <generic_fentry_process_filter+0xfb8> */
	ARM64_SIM_A64_JMP(0xed8, 0xfb8, arm64_l_fb8);
arm64_l_edc:
	/* 0xedc: ldr w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ee0:
	/* 0xee0: str w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_ee4:
	/* 0xee4: ldr x8, [x22, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_ee8:
	/* 0xee8: str x8, [x29, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_eec:
	/* 0xeec: ldr x8, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_ef0:
	/* 0xef0: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ef4:
	/* 0xef4: cbnz w8, 21c0 <generic_fentry_process_filter+0x21c0> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0xef4, 0x21c0, arm64_l_21c0);
arm64_l_ef8:
	/* 0xef8: b 21dc <generic_fentry_process_filter+0x21dc> */
	ARM64_SIM_A64_JMP(0xef8, 0x21dc, arm64_l_21dc);
arm64_l_efc:
	/* 0xefc: ldr x9, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_f00:
	/* 0xf00: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f04:
	/* 0xf04: strb w8, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f08:
	/* 0xf08: ldr w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f0c:
	/* 0xf0c: str w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_f10:
	/* 0xf10: ldr x8, [x22, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_f14:
	/* 0xf14: str x8, [x29, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_f18:
	/* 0xf18: b 21c0 <generic_fentry_process_filter+0x21c0> */
	ARM64_SIM_A64_JMP(0xf18, 0x21c0, arm64_l_21c0);
arm64_l_f1c:
	/* 0xf1c: mov w8, #0x2964 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10596ULL);
arm64_l_f20:
	/* 0xf20: add x20, x24, #0xff6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4086ULL);
arm64_l_f24:
	/* 0xf24: strh w8, [x24, #4094] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4094ULL);
arm64_l_f28:
	/* 0xf28: adrp x8, 10 <generic_fentry_process_filter+0x10> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&arm64_section_Some_SectionIndex_12_addend_0_2));
arm64_l_f2c:
	/* 0xf2c: add x8, x8, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_f30:
	/* 0xf30: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f34:
	/* 0xf34: str x8, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f38:
	/* 0xf38: b 73c <generic_fentry_process_filter+0x73c> */
	ARM64_SIM_A64_JMP(0xf38, 0x73c, arm64_l_73c);
arm64_l_f3c:
	/* 0xf3c: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_12));
arm64_l_f40:
	/* 0xf40: add x1, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_f44:
	/* 0xf44: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f48:
	/* 0xf48: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f4c:
	/* 0xf4c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xf50ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_f50:
	/* 0xf50: cbz x0, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xf50, 0x1584, arm64_l_1584);
arm64_l_f54:
	/* 0xf54: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f58:
	/* 0xf58: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_9));
arm64_l_f5c:
	/* 0xf5c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f60:
	/* 0xf60: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f64:
	/* 0xf64: add x9, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_f68:
	/* 0xf68: add x1, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_f6c:
	/* 0xf6c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xf70ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_f70:
	/* 0xf70: cbz x0, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xf70, 0x1584, arm64_l_1584);
arm64_l_f74:
	/* 0xf74: mov w1, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_f78:
	/* 0xf78: mov w2, #0x104 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 260ULL);
arm64_l_f7c:
	/* 0xf7c: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f80:
	/* 0xf80: bl 0 <memset> */
	ARM64_SIM_A64_CALL(arm64_l_0, 0xf84ULL);
arm64_l_f84:
	/* 0xf84: ldr x10, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_f88:
	/* 0xf88: mov x0, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f8c:
	/* 0xf8c: ldr w8, [x10, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_f90:
	/* 0xf90: add x2, x10, #0x70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_f94:
	/* 0xf94: lsl w9, w8, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_f98:
	/* 0xf98: and x8, x8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_f9c:
	/* 0xf9c: str w9, [x0], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_fa0:
	/* 0xfa0: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_fa4:
	/* 0xfa4: ldrb w1, [x10, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_fa8:
	/* 0xfa8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xfacULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_fac:
	/* 0xfac: tbnz x0, #63, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0xfac, 0x1584, arm64_l_1584);
arm64_l_fb0:
	/* 0xfb0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_fb4:
	/* 0xfb4: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_fb8:
	/* 0xfb8: mov x1, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_fbc:
	/* 0xfbc: b 1170 <generic_fentry_process_filter+0x1170> */
	ARM64_SIM_A64_JMP(0xfbc, 0x1170, arm64_l_1170);
arm64_l_fc0:
	/* 0xfc0: str wzr, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_fc4:
	/* 0xfc4: adrp x0, 0 <tg_mbset_gen> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mbset_gen_16));
arm64_l_fc8:
	/* 0xfc8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_fcc:
	/* 0xfcc: add x9, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_fd0:
	/* 0xfd0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_fd4:
	/* 0xfd4: add x1, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_fd8:
	/* 0xfd8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xfdcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_fdc:
	/* 0xfdc: cbz x0, 111c <generic_fentry_process_filter+0x111c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xfdc, 0x111c, arm64_l_111c);
arm64_l_fe0:
	/* 0xfe0: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_fe4:
	/* 0xfe4: ldr x8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_fe8:
	/* 0xfe8: ldr x9, [x9, #888] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 888ULL);
arm64_l_fec:
	/* 0xfec: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ff0:
	/* 0xff0: b.eq 111c <generic_fentry_process_filter+0x111c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xff0, 0x111c, arm64_l_111c);
arm64_l_ff4:
	/* 0xff4: str x0, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_ff8:
	/* 0xff8: adrp x8, 0 <CONFIG_ITER_NUM> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM_0));
arm64_l_ffc:
	/* 0xffc: mov w20, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1000:
	/* 0x1000: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1004:
	/* 0x1004: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1008:
	/* 0x1008: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_100c:
	/* 0x100c: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1010:
	/* 0x1010: add x19, x9, #0x370 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 880ULL);
arm64_l_1014:
	/* 0x1014: cbz w8, 10e4 <generic_fentry_process_filter+0x10e4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1014, 0x10e4, arm64_l_10e4);
arm64_l_1018:
	/* 0x1018: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_101c:
	/* 0x101c: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1020:
	/* 0x1020: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1024:
	/* 0x1024: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1028:
	/* 0x1028: ldr w8, [x8, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_102c:
	/* 0x102c: str w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1030:
	/* 0x1030: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1034:
	/* 0x1034: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1038:
	/* 0x1038: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x103cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_103c:
	/* 0x103c: cbz x0, 110c <generic_fentry_process_filter+0x110c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x103c, 0x110c, arm64_l_110c);
arm64_l_1040:
	/* 0x1040: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1044:
	/* 0x1044: add x1, x0, #0x70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_1048:
	/* 0x1048: adrp x0, 0 <tg_mbset_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mbset_map_17));
arm64_l_104c:
	/* 0x104c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1050:
	/* 0x1050: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1054:
	/* 0x1054: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1058ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1058:
	/* 0x1058: cbz x0, 1074 <generic_fentry_process_filter+0x1074> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1058, 0x1074, arm64_l_1074);
arm64_l_105c:
	/* 0x105c: ldr x8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1060:
	/* 0x1060: cbz x8, 1074 <generic_fentry_process_filter+0x1074> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1060, 0x1074, arm64_l_1074);
arm64_l_1064:
	/* 0x1064: ldaxr x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1068:
	/* 0x1068: orr x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_106c:
	/* 0x106c: stlxr w10, x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STLXR, ARM64_X10, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0);
arm64_l_1070:
	/* 0x1070: cbnz w10, 1064 <generic_fentry_process_filter+0x1064> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0x1070, 0x1064, arm64_l_1064);
arm64_l_1074:
	/* 0x1074: cmp x29, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1078:
	/* 0x1078: b.eq 110c <generic_fentry_process_filter+0x110c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1078, 0x110c, arm64_l_110c);
arm64_l_107c:
	/* 0x107c: mov w8, #0x86a0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 34464ULL);
arm64_l_1080:
	/* 0x1080: add w20, w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1084:
	/* 0x1084: mov x22, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1088:
	/* 0x1088: movk w8, #0x1, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 1ULL);
arm64_l_108c:
	/* 0x108c: cmp w20, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1090:
	/* 0x1090: b.ne 1018 <generic_fentry_process_filter+0x1018> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1090, 0x1018, arm64_l_1018);
arm64_l_1094:
	/* 0x1094: b 110c <generic_fentry_process_filter+0x110c> */
	ARM64_SIM_A64_JMP(0x1094, 0x110c, arm64_l_110c);
arm64_l_1098:
	/* 0x1098: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_109c:
	/* 0x109c: add x1, x0, #0x70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_10a0:
	/* 0x10a0: adrp x0, 0 <tg_mbset_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mbset_map_17));
arm64_l_10a4:
	/* 0x10a4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_10a8:
	/* 0x10a8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_10ac:
	/* 0x10ac: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x10b0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_10b0:
	/* 0x10b0: cbz x0, 10cc <generic_fentry_process_filter+0x10cc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x10b0, 0x10cc, arm64_l_10cc);
arm64_l_10b4:
	/* 0x10b4: ldr x8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_10b8:
	/* 0x10b8: cbz x8, 10cc <generic_fentry_process_filter+0x10cc> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x10b8, 0x10cc, arm64_l_10cc);
arm64_l_10bc:
	/* 0x10bc: ldaxr x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_10c0:
	/* 0x10c0: orr x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_10c4:
	/* 0x10c4: stlxr w10, x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STLXR, ARM64_X10, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0);
arm64_l_10c8:
	/* 0x10c8: cbnz w10, 10bc <generic_fentry_process_filter+0x10bc> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0x10c8, 0x10bc, arm64_l_10bc);
arm64_l_10cc:
	/* 0x10cc: cmp x29, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_10d0:
	/* 0x10d0: b.eq 110c <generic_fentry_process_filter+0x110c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x10d0, 0x110c, arm64_l_110c);
arm64_l_10d4:
	/* 0x10d4: add w20, w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_10d8:
	/* 0x10d8: mov x22, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10dc:
	/* 0x10dc: cmp w20, #0x400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1024ULL);
arm64_l_10e0:
	/* 0x10e0: b.eq 110c <generic_fentry_process_filter+0x110c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x10e0, 0x110c, arm64_l_110c);
arm64_l_10e4:
	/* 0x10e4: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_10e8:
	/* 0x10e8: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_10ec:
	/* 0x10ec: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_10f0:
	/* 0x10f0: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_10f4:
	/* 0x10f4: ldr w8, [x8, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_10f8:
	/* 0x10f8: str w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_10fc:
	/* 0x10fc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1100:
	/* 0x1100: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1104:
	/* 0x1104: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1108ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1108:
	/* 0x1108: cbnz x0, 1098 <generic_fentry_process_filter+0x1098> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x1108, 0x1098, arm64_l_1098);
arm64_l_110c:
	/* 0x110c: ldr x8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1110:
	/* 0x1110: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1114:
	/* 0x1114: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1118:
	/* 0x1118: str x8, [x9, #888] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 888ULL);
arm64_l_111c:
	/* 0x111c: ldr w8, [x25, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1120:
	/* 0x1120: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1124:
	/* 0x1124: b.eq 1148 <generic_fentry_process_filter+0x1148> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1124, 0x1148, arm64_l_1148);
arm64_l_1128:
	/* 0x1128: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_112c:
	/* 0x112c: ldr x9, [x9, #880] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 880ULL);
arm64_l_1130:
	/* 0x1130: lsr x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 0);
arm64_l_1134:
	/* 0x1134: tbz w8, #0, 1148 <generic_fentry_process_filter+0x1148> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 0, 0x1134, 0x1148, arm64_l_1148);
arm64_l_1138:
	/* 0x1138: mov x0, #0xffee */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 65518ULL);
arm64_l_113c:
	/* 0x113c: movk x0, #0xadc0, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 44480ULL);
arm64_l_1140:
	/* 0x1140: movk x0, #0xb, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 11ULL);
arm64_l_1144:
	/* 0x1144: b 1174 <generic_fentry_process_filter+0x1174> */
	ARM64_SIM_A64_JMP(0x1144, 0x1174, arm64_l_1174);
arm64_l_1148:
	/* 0x1148: adrp x0, 0 <tg_mb_paths> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mb_paths_14));
arm64_l_114c:
	/* 0x114c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1150:
	/* 0x1150: add x9, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_1154:
	/* 0x1154: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1158:
	/* 0x1158: add x1, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_115c:
	/* 0x115c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1160ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1160:
	/* 0x1160: cbz x0, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1160, 0x1584, arm64_l_1584);
arm64_l_1164:
	/* 0x1164: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1168:
	/* 0x1168: add x1, x8, #0x70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_116c:
	/* 0x116c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1170:
	/* 0x1170: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1174ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1174:
	/* 0x1174: ldr w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1178:
	/* 0x1178: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_117c:
	/* 0x117c: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_1180:
	/* 0x1180: b.hi 11a8 <generic_fentry_process_filter+0x11a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1180, 0x11a8, arm64_l_11a8);
arm64_l_1184:
	/* 0x1184: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1188:
	/* 0x1188: lsl x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_118c:
	/* 0x118c: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_1190:
	/* 0x1190: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_1194:
	/* 0x1194: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_1198:
	/* 0x1198: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_119c:
	/* 0x119c: b.eq 11a8 <generic_fentry_process_filter+0x11a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x119c, 0x11a8, arm64_l_11a8);
arm64_l_11a0:
	/* 0x11a0: cbnz x0, 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x11a0, 0x2184, arm64_l_2184);
arm64_l_11a4:
	/* 0x11a4: b 11ac <generic_fentry_process_filter+0x11ac> */
	ARM64_SIM_A64_JMP(0x11a4, 0x11ac, arm64_l_11ac);
arm64_l_11a8:
	/* 0x11a8: cbz x0, 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x11a8, 0x2184, arm64_l_2184);
arm64_l_11ac:
	/* 0x11ac: adrp x8, 0 <PARENTS_MAP_ENABLED> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&PARENTS_MAP_ENABLED_1));
arm64_l_11b0:
	/* 0x11b0: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_11b4:
	/* 0x11b4: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_11b8:
	/* 0x11b8: cbz w8, 1590 <generic_fentry_process_filter+0x1590> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x11b8, 0x1590, arm64_l_1590);
arm64_l_11bc:
	/* 0x11bc: adrp x0, 0 <tg_parents_bin> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_parents_bin_18));
arm64_l_11c0:
	/* 0x11c0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_11c4:
	/* 0x11c4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_11c8:
	/* 0x11c8: ldr x1, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_11cc:
	/* 0x11cc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x11d0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_11d0:
	/* 0x11d0: cbz x0, 1590 <generic_fentry_process_filter+0x1590> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x11d0, 0x1590, arm64_l_1590);
arm64_l_11d4:
	/* 0x11d4: add w8, w21, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_11d8:
	/* 0x11d8: str wzr, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_11dc:
	/* 0x11dc: add x9, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_11e0:
	/* 0x11e0: mov x25, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11e4:
	/* 0x11e4: str w8, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_11e8:
	/* 0x11e8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_11ec:
	/* 0x11ec: add x1, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_11f0:
	/* 0x11f0: mov x0, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11f4:
	/* 0x11f4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x11f8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_11f8:
	/* 0x11f8: cbz x0, 1590 <generic_fentry_process_filter+0x1590> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x11f8, 0x1590, arm64_l_1590);
arm64_l_11fc:
	/* 0x11fc: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1200:
	/* 0x1200: mov x24, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1204:
	/* 0x1204: cbz w8, 1590 <generic_fentry_process_filter+0x1590> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1204, 0x1590, arm64_l_1590);
arm64_l_1208:
	/* 0x1208: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_120c:
	/* 0x120c: str x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1210:
	/* 0x1210: tbnz w9, #31, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_TBNZ(ARM64_X9, 31, 0x1210, 0x1584, arm64_l_1584);
arm64_l_1214:
	/* 0x1214: cmp w8, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_1218:
	/* 0x1218: b.hi 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1218, 0x1584, arm64_l_1584);
arm64_l_121c:
	/* 0x121c: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1220:
	/* 0x1220: lsl w9, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1224:
	/* 0x1224: tst w9, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1228:
	/* 0x1228: b.ne 13b0 <generic_fentry_process_filter+0x13b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1228, 0x13b0, arm64_l_13b0);
arm64_l_122c:
	/* 0x122c: mov w10, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_1230:
	/* 0x1230: movk w10, #0x400, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 1024ULL);
arm64_l_1234:
	/* 0x1234: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1238:
	/* 0x1238: b.ne 1330 <generic_fentry_process_filter+0x1330> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1238, 0x1330, arm64_l_1330);
arm64_l_123c:
	/* 0x123c: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1240:
	/* 0x1240: lsl w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1244:
	/* 0x1244: mov w9, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 512ULL);
arm64_l_1248:
	/* 0x1248: movk w9, #0x800, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 2048ULL);
arm64_l_124c:
	/* 0x124c: tst w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1250:
	/* 0x1250: b.eq 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1250, 0x1584, arm64_l_1584);
arm64_l_1254:
	/* 0x1254: adrp x0, 0 <string_postfix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_10));
arm64_l_1258:
	/* 0x1258: add x1, x24, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_125c:
	/* 0x125c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1260:
	/* 0x1260: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1264:
	/* 0x1264: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1268ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1268:
	/* 0x1268: cbz x0, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1268, 0x1584, arm64_l_1584);
arm64_l_126c:
	/* 0x126c: ldr w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1270:
	/* 0x1270: mov x20, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1274:
	/* 0x1274: adrp x0, 0 <string_postfix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap_11));
arm64_l_1278:
	/* 0x1278: mov w9, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_127c:
	/* 0x127c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1280:
	/* 0x1280: add x1, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_1284:
	/* 0x1284: cmp w8, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_1288:
	/* 0x1288: csel w19, w8, w9, lt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X19, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LT, 0);
arm64_l_128c:
	/* 0x128c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1290:
	/* 0x1290: add x9, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_1294:
	/* 0x1294: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1298ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1298:
	/* 0x1298: cbz x0, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1298, 0x1584, arm64_l_1584);
arm64_l_129c:
	/* 0x129c: sxtw x1, w19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SXTW, ARM64_X1, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_12a0:
	/* 0x12a0: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_12a4:
	/* 0x12a4: lsl w8, w1, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_12a8:
	/* 0x12a8: str w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_12ac:
	/* 0x12ac: ldr w8, [x25, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_12b0:
	/* 0x12b0: cbnz w8, 1308 <generic_fentry_process_filter+0x1308> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0x12b0, 0x1308, arm64_l_1308);
arm64_l_12b4:
	/* 0x12b4: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_12b8:
	/* 0x12b8: and w13, w1, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_12bc:
	/* 0x12bc: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_12c0:
	/* 0x12c0: add x9, x25, #0x188 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 392ULL);
arm64_l_12c4:
	/* 0x12c4: add x10, x25, #0x108 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 264ULL);
arm64_l_12c8:
	/* 0x12c8: sub w11, w12, w1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X12, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_12cc:
	/* 0x12cc: add w12, w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_12d0:
	/* 0x12d0: add w11, w11, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X11, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_12d4:
	/* 0x12d4: mvn w13, w1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MVN, ARM64_X13, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_12d8:
	/* 0x12d8: add w12, w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_12dc:
	/* 0x12dc: cmp x8, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_12e0:
	/* 0x12e0: b.eq 1300 <generic_fentry_process_filter+0x1300> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x12e0, 0x1300, arm64_l_1300);
arm64_l_12e4:
	/* 0x12e4: and x13, x12, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_12e8:
	/* 0x12e8: sub w12, w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_12ec:
	/* 0x12ec: ldrb w13, [x10, x13] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X10, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X13, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_12f0:
	/* 0x12f0: strb w13, [x9, x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X13, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_12f4:
	/* 0x12f4: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_12f8:
	/* 0x12f8: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_12fc:
	/* 0x12fc: b.ne 12dc <generic_fentry_process_filter+0x12dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x12fc, 0x12dc, arm64_l_12dc);
arm64_l_1300:
	/* 0x1300: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1304:
	/* 0x1304: str w8, [x25, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1308:
	/* 0x1308: cmp w1, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_130c:
	/* 0x130c: b.hi 1324 <generic_fentry_process_filter+0x1324> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x130c, 0x1324, arm64_l_1324);
arm64_l_1310:
	/* 0x1310: add x0, x29, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1314:
	/* 0x1314: add x2, x25, #0x188 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 392ULL);
arm64_l_1318:
	/* 0x1318: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_131c:
	/* 0x131c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1320ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1320:
	/* 0x1320: tbnz x0, #63, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x1320, 0x1584, arm64_l_1584);
arm64_l_1324:
	/* 0x1324: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1328:
	/* 0x1328: mov x0, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_132c:
	/* 0x132c: b 13a8 <generic_fentry_process_filter+0x13a8> */
	ARM64_SIM_A64_JMP(0x132c, 0x13a8, arm64_l_13a8);
arm64_l_1330:
	/* 0x1330: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_12));
arm64_l_1334:
	/* 0x1334: add x1, x24, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1338:
	/* 0x1338: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_133c:
	/* 0x133c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1340:
	/* 0x1340: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1344ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1344:
	/* 0x1344: cbz x0, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1344, 0x1584, arm64_l_1584);
arm64_l_1348:
	/* 0x1348: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_134c:
	/* 0x134c: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_9));
arm64_l_1350:
	/* 0x1350: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1354:
	/* 0x1354: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1358:
	/* 0x1358: add x9, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_135c:
	/* 0x135c: add x1, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_1360:
	/* 0x1360: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1364ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1364:
	/* 0x1364: cbz x0, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1364, 0x1584, arm64_l_1584);
arm64_l_1368:
	/* 0x1368: mov w1, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_136c:
	/* 0x136c: mov w2, #0x104 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 260ULL);
arm64_l_1370:
	/* 0x1370: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1374:
	/* 0x1374: bl 0 <memset> */
	ARM64_SIM_A64_CALL(arm64_l_0, 0x1378ULL);
arm64_l_1378:
	/* 0x1378: ldr w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_137c:
	/* 0x137c: mov x0, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1380:
	/* 0x1380: add x2, x25, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1384:
	/* 0x1384: lsl w9, w8, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_1388:
	/* 0x1388: and x8, x8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_138c:
	/* 0x138c: str w9, [x0], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_1390:
	/* 0x1390: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1394:
	/* 0x1394: ldrb w1, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1398:
	/* 0x1398: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x139cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_139c:
	/* 0x139c: tbnz x0, #63, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x139c, 0x1584, arm64_l_1584);
arm64_l_13a0:
	/* 0x13a0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_13a4:
	/* 0x13a4: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_13a8:
	/* 0x13a8: mov x1, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_13ac:
	/* 0x13ac: b 154c <generic_fentry_process_filter+0x154c> */
	ARM64_SIM_A64_JMP(0x13ac, 0x154c, arm64_l_154c);
arm64_l_13b0:
	/* 0x13b0: str wzr, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_13b4:
	/* 0x13b4: adrp x0, 0 <tg_mbset_gen> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mbset_gen_16));
arm64_l_13b8:
	/* 0x13b8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_13bc:
	/* 0x13bc: add x9, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_13c0:
	/* 0x13c0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_13c4:
	/* 0x13c4: add x1, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_13c8:
	/* 0x13c8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x13ccULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_13cc:
	/* 0x13cc: cbz x0, 1500 <generic_fentry_process_filter+0x1500> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x13cc, 0x1500, arm64_l_1500);
arm64_l_13d0:
	/* 0x13d0: ldr x8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_13d4:
	/* 0x13d4: ldr x9, [x25, #784] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 784ULL);
arm64_l_13d8:
	/* 0x13d8: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_13dc:
	/* 0x13dc: b.eq 1500 <generic_fentry_process_filter+0x1500> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x13dc, 0x1500, arm64_l_1500);
arm64_l_13e0:
	/* 0x13e0: str x0, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_13e4:
	/* 0x13e4: adrp x8, 0 <CONFIG_ITER_NUM> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM_0));
arm64_l_13e8:
	/* 0x13e8: add x19, x25, #0x308 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 776ULL);
arm64_l_13ec:
	/* 0x13ec: mov w20, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_13f0:
	/* 0x13f0: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_13f4:
	/* 0x13f4: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_13f8:
	/* 0x13f8: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_13fc:
	/* 0x13fc: cbz w8, 14cc <generic_fentry_process_filter+0x14cc> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x13fc, 0x14cc, arm64_l_14cc);
arm64_l_1400:
	/* 0x1400: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1404:
	/* 0x1404: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1408:
	/* 0x1408: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_140c:
	/* 0x140c: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1410:
	/* 0x1410: ldr w8, [x8, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1414:
	/* 0x1414: str w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1418:
	/* 0x1418: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_141c:
	/* 0x141c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1420:
	/* 0x1420: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1424ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1424:
	/* 0x1424: cbz x0, 14f4 <generic_fentry_process_filter+0x14f4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1424, 0x14f4, arm64_l_14f4);
arm64_l_1428:
	/* 0x1428: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_142c:
	/* 0x142c: add x1, x0, #0x70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_1430:
	/* 0x1430: adrp x0, 0 <tg_mbset_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mbset_map_17));
arm64_l_1434:
	/* 0x1434: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1438:
	/* 0x1438: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_143c:
	/* 0x143c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1440ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1440:
	/* 0x1440: cbz x0, 145c <generic_fentry_process_filter+0x145c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1440, 0x145c, arm64_l_145c);
arm64_l_1444:
	/* 0x1444: ldr x8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1448:
	/* 0x1448: cbz x8, 145c <generic_fentry_process_filter+0x145c> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1448, 0x145c, arm64_l_145c);
arm64_l_144c:
	/* 0x144c: ldaxr x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1450:
	/* 0x1450: orr x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1454:
	/* 0x1454: stlxr w10, x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STLXR, ARM64_X10, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0);
arm64_l_1458:
	/* 0x1458: cbnz w10, 144c <generic_fentry_process_filter+0x144c> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0x1458, 0x144c, arm64_l_144c);
arm64_l_145c:
	/* 0x145c: cmp x29, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1460:
	/* 0x1460: b.eq 14f4 <generic_fentry_process_filter+0x14f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1460, 0x14f4, arm64_l_14f4);
arm64_l_1464:
	/* 0x1464: mov w8, #0x86a0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 34464ULL);
arm64_l_1468:
	/* 0x1468: add w20, w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_146c:
	/* 0x146c: mov x22, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1470:
	/* 0x1470: movk w8, #0x1, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 1ULL);
arm64_l_1474:
	/* 0x1474: cmp w20, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1478:
	/* 0x1478: b.ne 1400 <generic_fentry_process_filter+0x1400> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1478, 0x1400, arm64_l_1400);
arm64_l_147c:
	/* 0x147c: b 14f4 <generic_fentry_process_filter+0x14f4> */
	ARM64_SIM_A64_JMP(0x147c, 0x14f4, arm64_l_14f4);
arm64_l_1480:
	/* 0x1480: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1484:
	/* 0x1484: add x1, x0, #0x70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_1488:
	/* 0x1488: adrp x0, 0 <tg_mbset_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mbset_map_17));
arm64_l_148c:
	/* 0x148c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1490:
	/* 0x1490: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1494:
	/* 0x1494: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1498ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1498:
	/* 0x1498: cbz x0, 14b4 <generic_fentry_process_filter+0x14b4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1498, 0x14b4, arm64_l_14b4);
arm64_l_149c:
	/* 0x149c: ldr x8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_14a0:
	/* 0x14a0: cbz x8, 14b4 <generic_fentry_process_filter+0x14b4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x14a0, 0x14b4, arm64_l_14b4);
arm64_l_14a4:
	/* 0x14a4: ldaxr x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_14a8:
	/* 0x14a8: orr x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_14ac:
	/* 0x14ac: stlxr w10, x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STLXR, ARM64_X10, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0);
arm64_l_14b0:
	/* 0x14b0: cbnz w10, 14a4 <generic_fentry_process_filter+0x14a4> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0x14b0, 0x14a4, arm64_l_14a4);
arm64_l_14b4:
	/* 0x14b4: cmp x29, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_14b8:
	/* 0x14b8: b.eq 14f4 <generic_fentry_process_filter+0x14f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x14b8, 0x14f4, arm64_l_14f4);
arm64_l_14bc:
	/* 0x14bc: add w20, w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_14c0:
	/* 0x14c0: mov x22, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14c4:
	/* 0x14c4: cmp w20, #0x400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1024ULL);
arm64_l_14c8:
	/* 0x14c8: b.eq 14f4 <generic_fentry_process_filter+0x14f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x14c8, 0x14f4, arm64_l_14f4);
arm64_l_14cc:
	/* 0x14cc: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_14d0:
	/* 0x14d0: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_14d4:
	/* 0x14d4: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_14d8:
	/* 0x14d8: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_14dc:
	/* 0x14dc: ldr w8, [x8, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_14e0:
	/* 0x14e0: str w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_14e4:
	/* 0x14e4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_14e8:
	/* 0x14e8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_14ec:
	/* 0x14ec: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x14f0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_14f0:
	/* 0x14f0: cbnz x0, 1480 <generic_fentry_process_filter+0x1480> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x14f0, 0x1480, arm64_l_1480);
arm64_l_14f4:
	/* 0x14f4: ldr x8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_14f8:
	/* 0x14f8: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_14fc:
	/* 0x14fc: str x8, [x25, #784] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 784ULL);
arm64_l_1500:
	/* 0x1500: ldr w8, [x24, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1504:
	/* 0x1504: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1508:
	/* 0x1508: b.eq 1528 <generic_fentry_process_filter+0x1528> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1508, 0x1528, arm64_l_1528);
arm64_l_150c:
	/* 0x150c: ldr x9, [x25, #776] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 776ULL);
arm64_l_1510:
	/* 0x1510: lsr x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 0);
arm64_l_1514:
	/* 0x1514: tbz w8, #0, 1528 <generic_fentry_process_filter+0x1528> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 0, 0x1514, 0x1528, arm64_l_1528);
arm64_l_1518:
	/* 0x1518: mov x0, #0xffee */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 65518ULL);
arm64_l_151c:
	/* 0x151c: movk x0, #0xadc0, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 44480ULL);
arm64_l_1520:
	/* 0x1520: movk x0, #0xb, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 11ULL);
arm64_l_1524:
	/* 0x1524: b 1550 <generic_fentry_process_filter+0x1550> */
	ARM64_SIM_A64_JMP(0x1524, 0x1550, arm64_l_1550);
arm64_l_1528:
	/* 0x1528: adrp x0, 0 <tg_mb_paths> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mb_paths_14));
arm64_l_152c:
	/* 0x152c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1530:
	/* 0x1530: add x9, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_1534:
	/* 0x1534: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1538:
	/* 0x1538: add x1, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_153c:
	/* 0x153c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1540ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1540:
	/* 0x1540: cbz x0, 1584 <generic_fentry_process_filter+0x1584> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1540, 0x1584, arm64_l_1584);
arm64_l_1544:
	/* 0x1544: add x1, x25, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1548:
	/* 0x1548: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_154c:
	/* 0x154c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1550ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1550:
	/* 0x1550: ldr w8, [x24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1554:
	/* 0x1554: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1558:
	/* 0x1558: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_155c:
	/* 0x155c: b.hi 158c <generic_fentry_process_filter+0x158c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x155c, 0x158c, arm64_l_158c);
arm64_l_1560:
	/* 0x1560: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1564:
	/* 0x1564: lsl x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1568:
	/* 0x1568: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_156c:
	/* 0x156c: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_1570:
	/* 0x1570: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_1574:
	/* 0x1574: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1578:
	/* 0x1578: b.eq 158c <generic_fentry_process_filter+0x158c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1578, 0x158c, arm64_l_158c);
arm64_l_157c:
	/* 0x157c: cbnz x0, 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x157c, 0x2184, arm64_l_2184);
arm64_l_1580:
	/* 0x1580: b 1590 <generic_fentry_process_filter+0x1590> */
	ARM64_SIM_A64_JMP(0x1580, 0x1590, arm64_l_1590);
arm64_l_1584:
	/* 0x1584: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1588:
	/* 0x1588: b 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_JMP(0x1588, 0x2184, arm64_l_2184);
arm64_l_158c:
	/* 0x158c: cbz x0, 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x158c, 0x2184, arm64_l_2184);
arm64_l_1590:
	/* 0x1590: lsl w8, w21, #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_1594:
	/* 0x1594: add x9, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1598:
	/* 0x1598: ldr w8, [x9, x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X23, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_159c:
	/* 0x159c: add w9, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_15a0:
	/* 0x15a0: and w11, w9, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_15a4:
	/* 0x15a4: add w9, w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_15a8:
	/* 0x15a8: and x9, x9, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_15ac:
	/* 0x15ac: add x10, x11, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_15b0:
	/* 0x15b0: ldr w9, [x9, x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X23, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_15b4:
	/* 0x15b4: cmp w9, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_15b8:
	/* 0x15b8: b.cc 1650 <generic_fentry_process_filter+0x1650> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x15b8, 0x1650, arm64_l_1650);
arm64_l_15bc:
	/* 0x15bc: add x9, x10, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_15c0:
	/* 0x15c0: str x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_15c4:
	/* 0x15c4: ldr w10, [x9, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_15c8:
	/* 0x15c8: ldp w12, w13, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_15cc:
	/* 0x15cc: stp x9, x11, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_15d0:
	/* 0x15d0: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_15d4:
	/* 0x15d4: cmp w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_15d8:
	/* 0x15d8: stp xzr, xzr, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_15dc:
	/* 0x15dc: csel w9, w10, w9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_15e0:
	/* 0x15e0: cmp w12, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_15e4:
	/* 0x15e4: b.ne 15f0 <generic_fentry_process_filter+0x15f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x15e4, 0x15f0, arm64_l_15f0);
arm64_l_15e8:
	/* 0x15e8: mov x11, #0x100000001 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 4294967297ULL);
arm64_l_15ec:
	/* 0x15ec: stp x11, x11, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_15f0:
	/* 0x15f0: cbz w10, 1a80 <generic_fentry_process_filter+0x1a80> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x15f0, 0x1a80, arm64_l_1a80);
arm64_l_15f4:
	/* 0x15f4: ldr x10, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_15f8:
	/* 0x15f8: add w8, w8, w21, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_15fc:
	/* 0x15fc: tst x13, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1600:
	/* 0x1600: add x25, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1604:
	/* 0x1604: str w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1608:
	/* 0x1608: mov x22, x13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_160c:
	/* 0x160c: add w8, w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1610:
	/* 0x1610: and x8, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1614:
	/* 0x1614: add x21, x8, #0x14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_1618:
	/* 0x1618: sub x8, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_161c:
	/* 0x161c: mov w9, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_1620:
	/* 0x1620: add x11, x10, #0x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 36ULL);
arm64_l_1624:
	/* 0x1624: str x11, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1628:
	/* 0x1628: csel x11, x10, x11, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_EQ, 0);
arm64_l_162c:
	/* 0x162c: cmp x8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1630:
	/* 0x1630: add x10, x10, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1634:
	/* 0x1634: csel x8, x8, x9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_1638:
	/* 0x1638: and x9, x21, #0x7fc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2044ULL);
arm64_l_163c:
	/* 0x163c: mov x20, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1640:
	/* 0x1640: str x10, [sp, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1644:
	/* 0x1644: add x24, x23, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X23, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1648:
	/* 0x1648: add x19, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_164c:
	/* 0x164c: b 168c <generic_fentry_process_filter+0x168c> */
	ARM64_SIM_A64_JMP(0x164c, 0x168c, arm64_l_168c);
arm64_l_1650:
	/* 0x1650: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1654:
	/* 0x1654: mov w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1658:
	/* 0x1658: b 1acc <generic_fentry_process_filter+0x1acc> */
	ARM64_SIM_A64_JMP(0x1658, 0x1acc, arm64_l_1acc);
arm64_l_165c:
	/* 0x165c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1660:
	/* 0x1660: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1664:
	/* 0x1664: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1668:
	/* 0x1668: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_166c:
	/* 0x166c: cmp w12, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1670:
	/* 0x1670: eor w8, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1674:
	/* 0x1674: csinc w9, w8, wzr, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1678:
	/* 0x1678: str w9, [x25], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_167c:
	/* 0x167c: add x21, x21, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1680:
	/* 0x1680: add x24, x24, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1684:
	/* 0x1684: subs x19, x19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 1ULL);
arm64_l_1688:
	/* 0x1688: b.eq 1a80 <generic_fentry_process_filter+0x1a80> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1688, 0x1a80, arm64_l_1a80);
arm64_l_168c:
	/* 0x168c: cmp x21, #0x3e8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1000ULL);
arm64_l_1690:
	/* 0x1690: b.ls 18d4 <generic_fentry_process_filter+0x18d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1690, 0x18d4, arm64_l_18d4);
arm64_l_1694:
	/* 0x1694: mov x29, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1698:
	/* 0x1698: tbz w13, #1, 18dc <generic_fentry_process_filter+0x18dc> */
	ARM64_SIM_A64_TBZ(ARM64_X13, 1, 0x1698, 0x18dc, arm64_l_18dc);
arm64_l_169c:
	/* 0x169c: tbnz w13, #0, 1908 <generic_fentry_process_filter+0x1908> */
	ARM64_SIM_A64_TBNZ(ARM64_X13, 0, 0x169c, 0x1908, arm64_l_1908);
arm64_l_16a0:
	/* 0x16a0: ldr x10, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_16a4:
	/* 0x16a4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_16a8:
	/* 0x16a8: ldr w9, [x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_16ac:
	/* 0x16ac: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_16b0:
	/* 0x16b0: b.eq 166c <generic_fentry_process_filter+0x166c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x16b0, 0x166c, arm64_l_166c);
arm64_l_16b4:
	/* 0x16b4: ldr w9, [x10, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_16b8:
	/* 0x16b8: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_16bc:
	/* 0x16bc: b.eq 166c <generic_fentry_process_filter+0x166c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x16bc, 0x166c, arm64_l_166c);
arm64_l_16c0:
	/* 0x16c0: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_16c4:
	/* 0x16c4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_16c8:
	/* 0x16c8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_16cc:
	/* 0x16cc: ldr x1, [sp, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_16d0:
	/* 0x16d0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x16d4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_16d4:
	/* 0x16d4: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x16d4, 0x1a60, arm64_l_1a60);
arm64_l_16d8:
	/* 0x16d8: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_16dc:
	/* 0x16dc: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_16e0:
	/* 0x16e0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_16e4:
	/* 0x16e4: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_16e8:
	/* 0x16e8: b.eq 1660 <generic_fentry_process_filter+0x1660> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x16e8, 0x1660, arm64_l_1660);
arm64_l_16ec:
	/* 0x16ec: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_16f0:
	/* 0x16f0: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_16f4:
	/* 0x16f4: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_16f8:
	/* 0x16f8: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_16fc:
	/* 0x16fc: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1700:
	/* 0x1700: b.eq 166c <generic_fentry_process_filter+0x166c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1700, 0x166c, arm64_l_166c);
arm64_l_1704:
	/* 0x1704: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1708:
	/* 0x1708: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_170c:
	/* 0x170c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1710:
	/* 0x1710: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1714ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1714:
	/* 0x1714: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1714, 0x1a60, arm64_l_1a60);
arm64_l_1718:
	/* 0x1718: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_171c:
	/* 0x171c: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1720:
	/* 0x1720: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1724:
	/* 0x1724: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1728:
	/* 0x1728: b.eq 1660 <generic_fentry_process_filter+0x1660> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1728, 0x1660, arm64_l_1660);
arm64_l_172c:
	/* 0x172c: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_1730:
	/* 0x1730: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1734:
	/* 0x1734: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1738:
	/* 0x1738: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_173c:
	/* 0x173c: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1740:
	/* 0x1740: b.eq 166c <generic_fentry_process_filter+0x166c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1740, 0x166c, arm64_l_166c);
arm64_l_1744:
	/* 0x1744: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1748:
	/* 0x1748: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_174c:
	/* 0x174c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1750:
	/* 0x1750: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1754ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1754:
	/* 0x1754: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1754, 0x1a60, arm64_l_1a60);
arm64_l_1758:
	/* 0x1758: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_175c:
	/* 0x175c: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1760:
	/* 0x1760: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1764:
	/* 0x1764: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1768:
	/* 0x1768: b.eq 1660 <generic_fentry_process_filter+0x1660> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1768, 0x1660, arm64_l_1660);
arm64_l_176c:
	/* 0x176c: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_1770:
	/* 0x1770: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1774:
	/* 0x1774: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1778:
	/* 0x1778: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_177c:
	/* 0x177c: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1780:
	/* 0x1780: b.eq 166c <generic_fentry_process_filter+0x166c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1780, 0x166c, arm64_l_166c);
arm64_l_1784:
	/* 0x1784: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1788:
	/* 0x1788: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_178c:
	/* 0x178c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1790:
	/* 0x1790: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1794ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1794:
	/* 0x1794: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1794, 0x1a60, arm64_l_1a60);
arm64_l_1798:
	/* 0x1798: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_179c:
	/* 0x179c: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_17a0:
	/* 0x17a0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_17a4:
	/* 0x17a4: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17a8:
	/* 0x17a8: b.eq 1660 <generic_fentry_process_filter+0x1660> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x17a8, 0x1660, arm64_l_1660);
arm64_l_17ac:
	/* 0x17ac: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_17b0:
	/* 0x17b0: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_17b4:
	/* 0x17b4: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_17b8:
	/* 0x17b8: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_17bc:
	/* 0x17bc: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17c0:
	/* 0x17c0: b.eq 166c <generic_fentry_process_filter+0x166c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x17c0, 0x166c, arm64_l_166c);
arm64_l_17c4:
	/* 0x17c4: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_17c8:
	/* 0x17c8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_17cc:
	/* 0x17cc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17d0:
	/* 0x17d0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x17d4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_17d4:
	/* 0x17d4: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x17d4, 0x1a60, arm64_l_1a60);
arm64_l_17d8:
	/* 0x17d8: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17dc:
	/* 0x17dc: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_17e0:
	/* 0x17e0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_17e4:
	/* 0x17e4: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17e8:
	/* 0x17e8: b.eq 1660 <generic_fentry_process_filter+0x1660> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x17e8, 0x1660, arm64_l_1660);
arm64_l_17ec:
	/* 0x17ec: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_17f0:
	/* 0x17f0: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_17f4:
	/* 0x17f4: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_17f8:
	/* 0x17f8: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_17fc:
	/* 0x17fc: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1800:
	/* 0x1800: b.eq 166c <generic_fentry_process_filter+0x166c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1800, 0x166c, arm64_l_166c);
arm64_l_1804:
	/* 0x1804: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1808:
	/* 0x1808: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_180c:
	/* 0x180c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1810:
	/* 0x1810: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1814ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1814:
	/* 0x1814: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1814, 0x1a60, arm64_l_1a60);
arm64_l_1818:
	/* 0x1818: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_181c:
	/* 0x181c: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1820:
	/* 0x1820: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1824:
	/* 0x1824: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1828:
	/* 0x1828: b.eq 1660 <generic_fentry_process_filter+0x1660> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1828, 0x1660, arm64_l_1660);
arm64_l_182c:
	/* 0x182c: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_1830:
	/* 0x1830: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1834:
	/* 0x1834: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1838:
	/* 0x1838: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_183c:
	/* 0x183c: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1840:
	/* 0x1840: b.eq 166c <generic_fentry_process_filter+0x166c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1840, 0x166c, arm64_l_166c);
arm64_l_1844:
	/* 0x1844: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1848:
	/* 0x1848: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_184c:
	/* 0x184c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1850:
	/* 0x1850: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1854ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1854:
	/* 0x1854: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1854, 0x1a60, arm64_l_1a60);
arm64_l_1858:
	/* 0x1858: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_185c:
	/* 0x185c: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1860:
	/* 0x1860: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1864:
	/* 0x1864: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1868:
	/* 0x1868: b.eq 1660 <generic_fentry_process_filter+0x1660> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1868, 0x1660, arm64_l_1660);
arm64_l_186c:
	/* 0x186c: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_1870:
	/* 0x1870: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1874:
	/* 0x1874: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1878:
	/* 0x1878: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_187c:
	/* 0x187c: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1880:
	/* 0x1880: b.eq 166c <generic_fentry_process_filter+0x166c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1880, 0x166c, arm64_l_166c);
arm64_l_1884:
	/* 0x1884: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1888:
	/* 0x1888: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_188c:
	/* 0x188c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1890:
	/* 0x1890: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1894ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1894:
	/* 0x1894: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1894, 0x1a60, arm64_l_1a60);
arm64_l_1898:
	/* 0x1898: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_189c:
	/* 0x189c: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_18a0:
	/* 0x18a0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_18a4:
	/* 0x18a4: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_18a8:
	/* 0x18a8: b.eq 1660 <generic_fentry_process_filter+0x1660> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x18a8, 0x1660, arm64_l_1660);
arm64_l_18ac:
	/* 0x18ac: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_18b0:
	/* 0x18b0: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_18b4:
	/* 0x18b4: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_18b8:
	/* 0x18b8: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_18bc:
	/* 0x18bc: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_18c0:
	/* 0x18c0: b.eq 166c <generic_fentry_process_filter+0x166c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x18c0, 0x166c, arm64_l_166c);
arm64_l_18c4:
	/* 0x18c4: adrp x9, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_18c8:
	/* 0x18c8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_18cc:
	/* 0x18cc: ldr x9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18d0:
	/* 0x18d0: b 1a54 <generic_fentry_process_filter+0x1a54> */
	ARM64_SIM_A64_JMP(0x18d0, 0x1a54, arm64_l_1a54);
arm64_l_18d4:
	/* 0x18d4: ldr w29, [x24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18d8:
	/* 0x18d8: tbnz w13, #1, 169c <generic_fentry_process_filter+0x169c> */
	ARM64_SIM_A64_TBNZ(ARM64_X13, 1, 0x18d8, 0x169c, arm64_l_169c);
arm64_l_18dc:
	/* 0x18dc: ldr w8, [x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18e0:
	/* 0x18e0: cmp w12, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_18e4:
	/* 0x18e4: b.ne 18f8 <generic_fentry_process_filter+0x18f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x18e4, 0x18f8, arm64_l_18f8);
arm64_l_18e8:
	/* 0x18e8: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_18ec:
	/* 0x18ec: b.eq 18f8 <generic_fentry_process_filter+0x18f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x18ec, 0x18f8, arm64_l_18f8);
arm64_l_18f0:
	/* 0x18f0: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_18f4:
	/* 0x18f4: b 1678 <generic_fentry_process_filter+0x1678> */
	ARM64_SIM_A64_JMP(0x18f4, 0x1678, arm64_l_1678);
arm64_l_18f8:
	/* 0x18f8: cmp w12, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_18fc:
	/* 0x18fc: ccmp x29, x8, #0x0, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_EQ, 0), 0);
arm64_l_1900:
	/* 0x1900: cset w9, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1904:
	/* 0x1904: b 1678 <generic_fentry_process_filter+0x1678> */
	ARM64_SIM_A64_JMP(0x1904, 0x1678, arm64_l_1678);
arm64_l_1908:
	/* 0x1908: ldr x8, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_190c:
	/* 0x190c: ldr w9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1910:
	/* 0x1910: cbz w9, 1678 <generic_fentry_process_filter+0x1678> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1910, 0x1678, arm64_l_1678);
arm64_l_1914:
	/* 0x1914: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1918:
	/* 0x1918: cbz x29, 166c <generic_fentry_process_filter+0x166c> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x1918, 0x166c, arm64_l_166c);
arm64_l_191c:
	/* 0x191c: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1920:
	/* 0x1920: b.eq 166c <generic_fentry_process_filter+0x166c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1920, 0x166c, arm64_l_166c);
arm64_l_1924:
	/* 0x1924: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1928:
	/* 0x1928: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_192c:
	/* 0x192c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1930:
	/* 0x1930: ldr x1, [sp, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1934:
	/* 0x1934: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1938ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1938:
	/* 0x1938: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1938, 0x1a60, arm64_l_1a60);
arm64_l_193c:
	/* 0x193c: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1940:
	/* 0x1940: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1944:
	/* 0x1944: b.eq 165c <generic_fentry_process_filter+0x165c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1944, 0x165c, arm64_l_165c);
arm64_l_1948:
	/* 0x1948: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_194c:
	/* 0x194c: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1950:
	/* 0x1950: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1954:
	/* 0x1954: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1958:
	/* 0x1958: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x195cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_195c:
	/* 0x195c: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x195c, 0x1a60, arm64_l_1a60);
arm64_l_1960:
	/* 0x1960: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1964:
	/* 0x1964: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1968:
	/* 0x1968: b.eq 165c <generic_fentry_process_filter+0x165c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1968, 0x165c, arm64_l_165c);
arm64_l_196c:
	/* 0x196c: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1970:
	/* 0x1970: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1974:
	/* 0x1974: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1978:
	/* 0x1978: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_197c:
	/* 0x197c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1980ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1980:
	/* 0x1980: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1980, 0x1a60, arm64_l_1a60);
arm64_l_1984:
	/* 0x1984: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1988:
	/* 0x1988: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_198c:
	/* 0x198c: b.eq 165c <generic_fentry_process_filter+0x165c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x198c, 0x165c, arm64_l_165c);
arm64_l_1990:
	/* 0x1990: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1994:
	/* 0x1994: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1998:
	/* 0x1998: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_199c:
	/* 0x199c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19a0:
	/* 0x19a0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x19a4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_19a4:
	/* 0x19a4: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x19a4, 0x1a60, arm64_l_1a60);
arm64_l_19a8:
	/* 0x19a8: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_19ac:
	/* 0x19ac: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19b0:
	/* 0x19b0: b.eq 165c <generic_fentry_process_filter+0x165c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x19b0, 0x165c, arm64_l_165c);
arm64_l_19b4:
	/* 0x19b4: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_19b8:
	/* 0x19b8: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_19bc:
	/* 0x19bc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_19c0:
	/* 0x19c0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19c4:
	/* 0x19c4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x19c8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_19c8:
	/* 0x19c8: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x19c8, 0x1a60, arm64_l_1a60);
arm64_l_19cc:
	/* 0x19cc: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_19d0:
	/* 0x19d0: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19d4:
	/* 0x19d4: b.eq 165c <generic_fentry_process_filter+0x165c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x19d4, 0x165c, arm64_l_165c);
arm64_l_19d8:
	/* 0x19d8: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_19dc:
	/* 0x19dc: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_19e0:
	/* 0x19e0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_19e4:
	/* 0x19e4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19e8:
	/* 0x19e8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x19ecULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_19ec:
	/* 0x19ec: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x19ec, 0x1a60, arm64_l_1a60);
arm64_l_19f0:
	/* 0x19f0: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_19f4:
	/* 0x19f4: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19f8:
	/* 0x19f8: b.eq 165c <generic_fentry_process_filter+0x165c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x19f8, 0x165c, arm64_l_165c);
arm64_l_19fc:
	/* 0x19fc: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1a00:
	/* 0x1a00: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1a04:
	/* 0x1a04: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1a08:
	/* 0x1a08: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a0c:
	/* 0x1a0c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1a10ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1a10:
	/* 0x1a10: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1a10, 0x1a60, arm64_l_1a60);
arm64_l_1a14:
	/* 0x1a14: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1a18:
	/* 0x1a18: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a1c:
	/* 0x1a1c: b.eq 165c <generic_fentry_process_filter+0x165c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1a1c, 0x165c, arm64_l_165c);
arm64_l_1a20:
	/* 0x1a20: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1a24:
	/* 0x1a24: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1a28:
	/* 0x1a28: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1a2c:
	/* 0x1a2c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a30:
	/* 0x1a30: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1a34ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1a34:
	/* 0x1a34: cbz x0, 1a60 <generic_fentry_process_filter+0x1a60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1a34, 0x1a60, arm64_l_1a60);
arm64_l_1a38:
	/* 0x1a38: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1a3c:
	/* 0x1a3c: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a40:
	/* 0x1a40: b.eq 165c <generic_fentry_process_filter+0x165c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1a40, 0x165c, arm64_l_165c);
arm64_l_1a44:
	/* 0x1a44: adrp x9, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1a48:
	/* 0x1a48: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1a4c:
	/* 0x1a4c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1a50:
	/* 0x1a50: ldr x9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a54:
	/* 0x1a54: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1a58:
	/* 0x1a58: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a5c:
	/* 0x1a5c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1a60ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1a60:
	/* 0x1a60: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1a64:
	/* 0x1a64: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1a68:
	/* 0x1a68: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1a6c:
	/* 0x1a6c: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a70:
	/* 0x1a70: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a74:
	/* 0x1a74: cmp w12, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1a78:
	/* 0x1a78: b.ne 166c <generic_fentry_process_filter+0x166c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1a78, 0x166c, arm64_l_166c);
arm64_l_1a7c:
	/* 0x1a7c: b 1678 <generic_fentry_process_filter+0x1678> */
	ARM64_SIM_A64_JMP(0x1a7c, 0x1678, arm64_l_1678);
arm64_l_1a80:
	/* 0x1a80: ldp w8, w9, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1a84:
	/* 0x1a84: ldp w10, w11, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1a88:
	/* 0x1a88: cmp w12, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1a8c:
	/* 0x1a8c: b.ne 1aa0 <generic_fentry_process_filter+0x1aa0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1a8c, 0x1aa0, arm64_l_1aa0);
arm64_l_1a90:
	/* 0x1a90: and w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1a94:
	/* 0x1a94: and w9, w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1a98:
	/* 0x1a98: and w9, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1a9c:
	/* 0x1a9c: b 1aac <generic_fentry_process_filter+0x1aac> */
	ARM64_SIM_A64_JMP(0x1a9c, 0x1aac, arm64_l_1aac);
arm64_l_1aa0:
	/* 0x1aa0: orr w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1aa4:
	/* 0x1aa4: orr w9, w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1aa8:
	/* 0x1aa8: orr w9, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1aac:
	/* 0x1aac: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1ab0:
	/* 0x1ab0: ldr x8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1ab4:
	/* 0x1ab4: cbz w9, 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1ab4, 0x2184, arm64_l_2184);
arm64_l_1ab8:
	/* 0x1ab8: ldr x10, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1abc:
	/* 0x1abc: add w8, w8, #0x14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_1ac0:
	/* 0x1ac0: ldr w10, [x10, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1ac4:
	/* 0x1ac4: ubfiz w10, w10, #2, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_BITFIELD, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFIZ, 2, 3), 0);
arm64_l_1ac8:
	/* 0x1ac8: add w8, w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1acc:
	/* 0x1acc: and x10, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1ad0:
	/* 0x1ad0: add w8, w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1ad4:
	/* 0x1ad4: add x22, x29, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_1ad8:
	/* 0x1ad8: ldr w10, [x10, x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X23, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1adc:
	/* 0x1adc: mov w19, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_1ae0:
	/* 0x1ae0: mov w14, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1ae4:
	/* 0x1ae4: sub w24, w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1ae8:
	/* 0x1ae8: b 1af8 <generic_fentry_process_filter+0x1af8> */
	ARM64_SIM_A64_JMP(0x1ae8, 0x1af8, arm64_l_1af8);
arm64_l_1aec:
	/* 0x1aec: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1af0:
	/* 0x1af0: subs x19, x19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 1ULL);
arm64_l_1af4:
	/* 0x1af4: b.eq 1cdc <generic_fentry_process_filter+0x1cdc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1af4, 0x1cdc, arm64_l_1cdc);
arm64_l_1af8:
	/* 0x1af8: cbz w24, 1af0 <generic_fentry_process_filter+0x1af0> */
	ARM64_SIM_A64_CBZ(ARM64_X24, 0x1af8, 0x1af0, arm64_l_1af0);
arm64_l_1afc:
	/* 0x1afc: and x9, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1b00:
	/* 0x1b00: mov x20, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b04:
	/* 0x1b04: add x10, x9, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1b08:
	/* 0x1b08: ldr w21, [x10, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1b0c:
	/* 0x1b0c: ldp w9, w29, [x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X9, ARM64_X29, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b10:
	/* 0x1b10: stp xzr, xzr, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1b14:
	/* 0x1b14: cmp w21, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1b18:
	/* 0x1b18: csel w10, w21, w14, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X10, ARM64_X21, ARM64_X14, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_1b1c:
	/* 0x1b1c: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1b20:
	/* 0x1b20: b.ne 1b2c <generic_fentry_process_filter+0x1b2c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1b20, 0x1b2c, arm64_l_1b2c);
arm64_l_1b24:
	/* 0x1b24: mov x11, #0x100000001 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 4294967297ULL);
arm64_l_1b28:
	/* 0x1b28: stp x11, x11, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1b2c:
	/* 0x1b2c: add w25, w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1b30:
	/* 0x1b30: cbz w21, 1c90 <generic_fentry_process_filter+0x1c90> */
	ARM64_SIM_A64_CBZ(ARM64_X21, 0x1b30, 0x1c90, arm64_l_1c90);
arm64_l_1b34:
	/* 0x1b34: and x9, x9, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_1b38:
	/* 0x1b38: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1b3c:
	/* 0x1b3c: b.cc 1b6c <generic_fentry_process_filter+0x1b6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1b3c, 0x1b6c, arm64_l_1b6c);
arm64_l_1b40:
	/* 0x1b40: sub x8, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b44:
	/* 0x1b44: mov w9, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_1b48:
	/* 0x1b48: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1b4c:
	/* 0x1b4c: mov w1, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1b50:
	/* 0x1b50: cmp x8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1b54:
	/* 0x1b54: csel x8, x8, x9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_1b58:
	/* 0x1b58: lsl x8, x8, #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_1b5c:
	/* 0x1b5c: add x2, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1b60:
	/* 0x1b60: bl 0 <memset> */
	ARM64_SIM_A64_CALL(arm64_l_0, 0x1b64ULL);
arm64_l_1b64:
	/* 0x1b64: mov w14, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1b68:
	/* 0x1b68: b 1c90 <generic_fentry_process_filter+0x1c90> */
	ARM64_SIM_A64_JMP(0x1b68, 0x1c90, arm64_l_1c90);
arm64_l_1b6c:
	/* 0x1b6c: cmp w25, #0x3e8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1000ULL);
arm64_l_1b70:
	/* 0x1b70: b.ls 1b7c <generic_fentry_process_filter+0x1b7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1b70, 0x1b7c, arm64_l_1b7c);
arm64_l_1b74:
	/* 0x1b74: mov w11, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1b78:
	/* 0x1b78: b 1b84 <generic_fentry_process_filter+0x1b84> */
	ARM64_SIM_A64_JMP(0x1b78, 0x1b84, arm64_l_1b84);
arm64_l_1b7c:
	/* 0x1b7c: and w11, w25, #0xfffffffc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967292ULL);
arm64_l_1b80:
	/* 0x1b80: ldr w11, [x23, w11, uxtw] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X23, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_UXTW, 0, 0), 0ULL);
arm64_l_1b84:
	/* 0x1b84: ldr w9, [x22, x9, lsl #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_LSL, 2, 0), 0ULL);
arm64_l_1b88:
	/* 0x1b88: cmp w29, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1b8c:
	/* 0x1b8c: sub x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b90:
	/* 0x1b90: cset w12, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1b94:
	/* 0x1b94: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1b98:
	/* 0x1b98: cset w13, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1b9c:
	/* 0x1b9c: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ba0:
	/* 0x1ba0: csinc w11, w12, wzr, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X11, ARM64_X12, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1ba4:
	/* 0x1ba4: csinc w12, w13, wzr, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X12, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1ba8:
	/* 0x1ba8: and w11, w11, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X11, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1bac:
	/* 0x1bac: str w11, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1bb0:
	/* 0x1bb0: cbz x10, 1c90 <generic_fentry_process_filter+0x1c90> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x1bb0, 0x1c90, arm64_l_1c90);
arm64_l_1bb4:
	/* 0x1bb4: add w11, w8, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1bb8:
	/* 0x1bb8: cmp w11, #0x3e8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1000ULL);
arm64_l_1bbc:
	/* 0x1bbc: b.ls 1bc8 <generic_fentry_process_filter+0x1bc8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1bbc, 0x1bc8, arm64_l_1bc8);
arm64_l_1bc0:
	/* 0x1bc0: mov w11, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1bc4:
	/* 0x1bc4: b 1bd0 <generic_fentry_process_filter+0x1bd0> */
	ARM64_SIM_A64_JMP(0x1bc4, 0x1bd0, arm64_l_1bd0);
arm64_l_1bc8:
	/* 0x1bc8: and w11, w11, #0xfffffffc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967292ULL);
arm64_l_1bcc:
	/* 0x1bcc: ldr w11, [x23, w11, uxtw] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X23, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_UXTW, 0, 0), 0ULL);
arm64_l_1bd0:
	/* 0x1bd0: cmp w29, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1bd4:
	/* 0x1bd4: cset w12, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1bd8:
	/* 0x1bd8: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1bdc:
	/* 0x1bdc: cset w13, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1be0:
	/* 0x1be0: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1be4:
	/* 0x1be4: csinc w11, w12, wzr, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X11, ARM64_X12, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1be8:
	/* 0x1be8: csinc w12, w13, wzr, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X12, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1bec:
	/* 0x1bec: cmp x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1bf0:
	/* 0x1bf0: and w11, w11, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X11, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1bf4:
	/* 0x1bf4: str w11, [sp, #92] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_1bf8:
	/* 0x1bf8: b.eq 1c90 <generic_fentry_process_filter+0x1c90> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1bf8, 0x1c90, arm64_l_1c90);
arm64_l_1bfc:
	/* 0x1bfc: add w11, w8, #0x14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_1c00:
	/* 0x1c00: cmp w11, #0x3e8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1000ULL);
arm64_l_1c04:
	/* 0x1c04: b.ls 1c10 <generic_fentry_process_filter+0x1c10> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1c04, 0x1c10, arm64_l_1c10);
arm64_l_1c08:
	/* 0x1c08: mov w11, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1c0c:
	/* 0x1c0c: b 1c18 <generic_fentry_process_filter+0x1c18> */
	ARM64_SIM_A64_JMP(0x1c0c, 0x1c18, arm64_l_1c18);
arm64_l_1c10:
	/* 0x1c10: and w11, w11, #0xfffffffc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967292ULL);
arm64_l_1c14:
	/* 0x1c14: ldr w11, [x23, w11, uxtw] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X23, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_UXTW, 0, 0), 0ULL);
arm64_l_1c18:
	/* 0x1c18: cmp w29, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1c1c:
	/* 0x1c1c: cset w12, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1c20:
	/* 0x1c20: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1c24:
	/* 0x1c24: cset w13, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1c28:
	/* 0x1c28: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c2c:
	/* 0x1c2c: csinc w11, w12, wzr, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X11, ARM64_X12, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1c30:
	/* 0x1c30: csinc w12, w13, wzr, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X12, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1c34:
	/* 0x1c34: cmp x10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1c38:
	/* 0x1c38: and w11, w11, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X11, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1c3c:
	/* 0x1c3c: str w11, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1c40:
	/* 0x1c40: b.eq 1c90 <generic_fentry_process_filter+0x1c90> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c40, 0x1c90, arm64_l_1c90);
arm64_l_1c44:
	/* 0x1c44: add w8, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1c48:
	/* 0x1c48: cmp w8, #0x3e8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1000ULL);
arm64_l_1c4c:
	/* 0x1c4c: b.ls 1c58 <generic_fentry_process_filter+0x1c58> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1c4c, 0x1c58, arm64_l_1c58);
arm64_l_1c50:
	/* 0x1c50: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1c54:
	/* 0x1c54: b 1c60 <generic_fentry_process_filter+0x1c60> */
	ARM64_SIM_A64_JMP(0x1c54, 0x1c60, arm64_l_1c60);
arm64_l_1c58:
	/* 0x1c58: and w8, w8, #0xfffffffc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967292ULL);
arm64_l_1c5c:
	/* 0x1c5c: ldr w8, [x23, w8, uxtw] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_UXTW, 0, 0), 0ULL);
arm64_l_1c60:
	/* 0x1c60: cmp w29, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1c64:
	/* 0x1c64: cset w10, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1c68:
	/* 0x1c68: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1c6c:
	/* 0x1c6c: cset w11, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1c70:
	/* 0x1c70: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c74:
	/* 0x1c74: csinc w8, w10, wzr, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X8, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1c78:
	/* 0x1c78: csinc w9, w11, wzr, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1c7c:
	/* 0x1c7c: and w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1c80:
	/* 0x1c80: str w8, [sp, #100] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 100ULL);
arm64_l_1c84:
	/* 0x1c84: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c88:
	/* 0x1c88: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c8c:
	/* 0x1c8c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c90:
	/* 0x1c90: ldp w8, w9, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1c94:
	/* 0x1c94: ldp w10, w11, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1c98:
	/* 0x1c98: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1c9c:
	/* 0x1c9c: b.ne 1cb0 <generic_fentry_process_filter+0x1cb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1c9c, 0x1cb0, arm64_l_1cb0);
arm64_l_1ca0:
	/* 0x1ca0: and w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1ca4:
	/* 0x1ca4: and w9, w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1ca8:
	/* 0x1ca8: and w9, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1cac:
	/* 0x1cac: b 1cbc <generic_fentry_process_filter+0x1cbc> */
	ARM64_SIM_A64_JMP(0x1cac, 0x1cbc, arm64_l_1cbc);
arm64_l_1cb0:
	/* 0x1cb0: orr w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1cb4:
	/* 0x1cb4: orr w9, w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1cb8:
	/* 0x1cb8: orr w9, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1cbc:
	/* 0x1cbc: mov x29, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1cc0:
	/* 0x1cc0: cbz w9, 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1cc0, 0x2184, arm64_l_2184);
arm64_l_1cc4:
	/* 0x1cc4: lsl w8, w21, #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_1cc8:
	/* 0x1cc8: sub w10, w24, w21, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X24, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_LSL, 2), 0);
arm64_l_1ccc:
	/* 0x1ccc: and w8, w8, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_1cd0:
	/* 0x1cd0: sub w24, w10, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1cd4:
	/* 0x1cd4: add w8, w8, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1cd8:
	/* 0x1cd8: b 1af0 <generic_fentry_process_filter+0x1af0> */
	ARM64_SIM_A64_JMP(0x1cd8, 0x1af0, arm64_l_1af0);
arm64_l_1cdc:
	/* 0x1cdc: mov w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1ce0:
	/* 0x1ce0: add w19, w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1ce4:
	/* 0x1ce4: and x10, x10, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1ce8:
	/* 0x1ce8: ldr w10, [x10, x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X23, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1cec:
	/* 0x1cec: cmp w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1cf0:
	/* 0x1cf0: b.ne 1d80 <generic_fentry_process_filter+0x1d80> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1cf0, 0x1d80, arm64_l_1d80);
arm64_l_1cf4:
	/* 0x1cf4: cbz w9, 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1cf4, 0x2184, arm64_l_2184);
arm64_l_1cf8:
	/* 0x1cf8: mov w8, w19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1cfc:
	/* 0x1cfc: and x8, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1d00:
	/* 0x1d00: ldr w9, [x8, x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X23, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1d04:
	/* 0x1d04: add w8, w19, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1d08:
	/* 0x1d08: cmp w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1d0c:
	/* 0x1d0c: mov w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1d10:
	/* 0x1d10: b.eq 2094 <generic_fentry_process_filter+0x2094> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d10, 0x2094, arm64_l_2094);
arm64_l_1d14:
	/* 0x1d14: and x8, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1d18:
	/* 0x1d18: add x8, x8, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1d1c:
	/* 0x1d1c: ldp w20, w24, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1d20:
	/* 0x1d20: mov w8, #0xe */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_1d24:
	/* 0x1d24: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x1d28ULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1d28:
	/* 0x1d28: lsr x8, x0, #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 32ULL);
arm64_l_1d2c:
	/* 0x1d2c: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1d30:
	/* 0x1d30: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1d34:
	/* 0x1d34: str w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1d38:
	/* 0x1d38: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1d3c:
	/* 0x1d3c: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1d40:
	/* 0x1d40: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1d44:
	/* 0x1d44: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1d48ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1d48:
	/* 0x1d48: cbz x0, 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1d48, 0x2184, arm64_l_2184);
arm64_l_1d4c:
	/* 0x1d4c: cmp w20, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1d50:
	/* 0x1d50: b.eq 1df4 <generic_fentry_process_filter+0x1df4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d50, 0x1df4, arm64_l_1df4);
arm64_l_1d54:
	/* 0x1d54: cmp w20, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1d58:
	/* 0x1d58: b.ne 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1d58, 0x2184, arm64_l_2184);
arm64_l_1d5c:
	/* 0x1d5c: mov w8, #0x5ee8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24296ULL);
arm64_l_1d60:
	/* 0x1d60: add x8, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1d64:
	/* 0x1d64: tbnz w24, #0, 1e20 <generic_fentry_process_filter+0x1e20> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 0, 0x1d64, 0x1e20, arm64_l_1e20);
arm64_l_1d68:
	/* 0x1d68: ldr w9, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1d6c:
	/* 0x1d6c: cbz w9, 1e18 <generic_fentry_process_filter+0x1e18> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1d6c, 0x1e18, arm64_l_1e18);
arm64_l_1d70:
	/* 0x1d70: ldr w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1d74:
	/* 0x1d74: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d78:
	/* 0x1d78: b.eq 1e20 <generic_fentry_process_filter+0x1e20> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d78, 0x1e20, arm64_l_1e20);
arm64_l_1d7c:
	/* 0x1d7c: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x1d7c, 0x2088, arm64_l_2088);
arm64_l_1d80:
	/* 0x1d80: and x9, x19, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1d84:
	/* 0x1d84: add w19, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1d88:
	/* 0x1d88: add x9, x9, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1d8c:
	/* 0x1d8c: ldp w8, w10, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1d90:
	/* 0x1d90: ldr w12, [x9, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1d94:
	/* 0x1d94: ldur x11, [x9, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1d98:
	/* 0x1d98: cbz w12, 1db8 <generic_fentry_process_filter+0x1db8> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0x1d98, 0x1db8, arm64_l_1db8);
arm64_l_1d9c:
	/* 0x1d9c: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1da0:
	/* 0x1da0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1da4:
	/* 0x1da4: b.hi 1cf4 <generic_fentry_process_filter+0x1cf4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1da4, 0x1cf4, arm64_l_1cf4);
arm64_l_1da8:
	/* 0x1da8: ldr w13, [x29, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_1dac:
	/* 0x1dac: cmp w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1db0:
	/* 0x1db0: b.ne 1dc8 <generic_fentry_process_filter+0x1dc8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1db0, 0x1dc8, arm64_l_1dc8);
arm64_l_1db4:
	/* 0x1db4: b 1cf4 <generic_fentry_process_filter+0x1cf4> */
	ARM64_SIM_A64_JMP(0x1db4, 0x1cf4, arm64_l_1cf4);
arm64_l_1db8:
	/* 0x1db8: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1dbc:
	/* 0x1dbc: b.ls 1dc8 <generic_fentry_process_filter+0x1dc8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1dbc, 0x1dc8, arm64_l_1dc8);
arm64_l_1dc0:
	/* 0x1dc0: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1dc4:
	/* 0x1dc4: b 1cf4 <generic_fentry_process_filter+0x1cf4> */
	ARM64_SIM_A64_JMP(0x1dc4, 0x1cf4, arm64_l_1cf4);
arm64_l_1dc8:
	/* 0x1dc8: add x9, x29, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1dcc:
	/* 0x1dcc: cmp w10, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1dd0:
	/* 0x1dd0: ldr x8, [x9, x8, lsl #3] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_LSL, 3, 0), 0ULL);
arm64_l_1dd4:
	/* 0x1dd4: and x8, x8, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1dd8:
	/* 0x1dd8: b.ne 1de8 <generic_fentry_process_filter+0x1de8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1dd8, 0x1de8, arm64_l_1de8);
arm64_l_1ddc:
	/* 0x1ddc: cmp x8, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1de0:
	/* 0x1de0: cset w9, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1de4:
	/* 0x1de4: b 1cf4 <generic_fentry_process_filter+0x1cf4> */
	ARM64_SIM_A64_JMP(0x1de4, 0x1cf4, arm64_l_1cf4);
arm64_l_1de8:
	/* 0x1de8: cmp x8, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1dec:
	/* 0x1dec: cset w9, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1df0:
	/* 0x1df0: b 1cf4 <generic_fentry_process_filter+0x1cf4> */
	ARM64_SIM_A64_JMP(0x1df0, 0x1cf4, arm64_l_1cf4);
arm64_l_1df4:
	/* 0x1df4: mov w8, #0x5ee8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24296ULL);
arm64_l_1df8:
	/* 0x1df8: add x8, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1dfc:
	/* 0x1dfc: tbz w24, #0, 1e44 <generic_fentry_process_filter+0x1e44> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 0, 0x1dfc, 0x1e44, arm64_l_1e44);
arm64_l_1e00:
	/* 0x1e00: ldr w9, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1e04:
	/* 0x1e04: cbz w9, 1e3c <generic_fentry_process_filter+0x1e3c> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1e04, 0x1e3c, arm64_l_1e3c);
arm64_l_1e08:
	/* 0x1e08: ldr w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e0c:
	/* 0x1e0c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e10:
	/* 0x1e10: b.eq 1e44 <generic_fentry_process_filter+0x1e44> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e10, 0x1e44, arm64_l_1e44);
arm64_l_1e14:
	/* 0x1e14: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x1e14, 0x2088, arm64_l_2088);
arm64_l_1e18:
	/* 0x1e18: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e1c:
	/* 0x1e1c: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e20:
	/* 0x1e20: tbnz w24, #1, 1e68 <generic_fentry_process_filter+0x1e68> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 1, 0x1e20, 0x1e68, arm64_l_1e68);
arm64_l_1e24:
	/* 0x1e24: ldr w9, [x0, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_1e28:
	/* 0x1e28: cbz w9, 1e60 <generic_fentry_process_filter+0x1e60> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1e28, 0x1e60, arm64_l_1e60);
arm64_l_1e2c:
	/* 0x1e2c: ldr w10, [x29, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1e30:
	/* 0x1e30: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e34:
	/* 0x1e34: b.eq 1e68 <generic_fentry_process_filter+0x1e68> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e34, 0x1e68, arm64_l_1e68);
arm64_l_1e38:
	/* 0x1e38: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x1e38, 0x2088, arm64_l_2088);
arm64_l_1e3c:
	/* 0x1e3c: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e40:
	/* 0x1e40: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e44:
	/* 0x1e44: tbz w24, #1, 1e8c <generic_fentry_process_filter+0x1e8c> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 1, 0x1e44, 0x1e8c, arm64_l_1e8c);
arm64_l_1e48:
	/* 0x1e48: ldr w9, [x0, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_1e4c:
	/* 0x1e4c: cbz w9, 1e84 <generic_fentry_process_filter+0x1e84> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1e4c, 0x1e84, arm64_l_1e84);
arm64_l_1e50:
	/* 0x1e50: ldr w10, [x29, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1e54:
	/* 0x1e54: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e58:
	/* 0x1e58: b.eq 1e8c <generic_fentry_process_filter+0x1e8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e58, 0x1e8c, arm64_l_1e8c);
arm64_l_1e5c:
	/* 0x1e5c: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x1e5c, 0x2088, arm64_l_2088);
arm64_l_1e60:
	/* 0x1e60: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e64:
	/* 0x1e64: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e68:
	/* 0x1e68: tbnz w24, #2, 1eb0 <generic_fentry_process_filter+0x1eb0> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 2, 0x1e68, 0x1eb0, arm64_l_1eb0);
arm64_l_1e6c:
	/* 0x1e6c: ldr w9, [x0, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1e70:
	/* 0x1e70: cbz w9, 1ea8 <generic_fentry_process_filter+0x1ea8> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1e70, 0x1ea8, arm64_l_1ea8);
arm64_l_1e74:
	/* 0x1e74: ldr w10, [x29, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1e78:
	/* 0x1e78: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e7c:
	/* 0x1e7c: b.eq 1eb0 <generic_fentry_process_filter+0x1eb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e7c, 0x1eb0, arm64_l_1eb0);
arm64_l_1e80:
	/* 0x1e80: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x1e80, 0x2088, arm64_l_2088);
arm64_l_1e84:
	/* 0x1e84: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e88:
	/* 0x1e88: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e8c:
	/* 0x1e8c: tbz w24, #2, 1ed4 <generic_fentry_process_filter+0x1ed4> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 2, 0x1e8c, 0x1ed4, arm64_l_1ed4);
arm64_l_1e90:
	/* 0x1e90: ldr w9, [x0, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1e94:
	/* 0x1e94: cbz w9, 1ecc <generic_fentry_process_filter+0x1ecc> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1e94, 0x1ecc, arm64_l_1ecc);
arm64_l_1e98:
	/* 0x1e98: ldr w10, [x29, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1e9c:
	/* 0x1e9c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ea0:
	/* 0x1ea0: b.eq 1ed4 <generic_fentry_process_filter+0x1ed4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ea0, 0x1ed4, arm64_l_1ed4);
arm64_l_1ea4:
	/* 0x1ea4: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x1ea4, 0x2088, arm64_l_2088);
arm64_l_1ea8:
	/* 0x1ea8: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1eac:
	/* 0x1eac: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1eb0:
	/* 0x1eb0: tbnz w24, #3, 1ef8 <generic_fentry_process_filter+0x1ef8> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 3, 0x1eb0, 0x1ef8, arm64_l_1ef8);
arm64_l_1eb4:
	/* 0x1eb4: ldr w9, [x0, #52] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 52ULL);
arm64_l_1eb8:
	/* 0x1eb8: cbz w9, 1ef0 <generic_fentry_process_filter+0x1ef0> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1eb8, 0x1ef0, arm64_l_1ef0);
arm64_l_1ebc:
	/* 0x1ebc: ldr w10, [x29, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_1ec0:
	/* 0x1ec0: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ec4:
	/* 0x1ec4: b.eq 1ef8 <generic_fentry_process_filter+0x1ef8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ec4, 0x1ef8, arm64_l_1ef8);
arm64_l_1ec8:
	/* 0x1ec8: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x1ec8, 0x2088, arm64_l_2088);
arm64_l_1ecc:
	/* 0x1ecc: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ed0:
	/* 0x1ed0: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ed4:
	/* 0x1ed4: tbz w24, #3, 1f1c <generic_fentry_process_filter+0x1f1c> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 3, 0x1ed4, 0x1f1c, arm64_l_1f1c);
arm64_l_1ed8:
	/* 0x1ed8: ldr w9, [x0, #52] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 52ULL);
arm64_l_1edc:
	/* 0x1edc: cbz w9, 1f14 <generic_fentry_process_filter+0x1f14> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1edc, 0x1f14, arm64_l_1f14);
arm64_l_1ee0:
	/* 0x1ee0: ldr w10, [x29, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_1ee4:
	/* 0x1ee4: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ee8:
	/* 0x1ee8: b.eq 1f1c <generic_fentry_process_filter+0x1f1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ee8, 0x1f1c, arm64_l_1f1c);
arm64_l_1eec:
	/* 0x1eec: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x1eec, 0x2088, arm64_l_2088);
arm64_l_1ef0:
	/* 0x1ef0: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ef4:
	/* 0x1ef4: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ef8:
	/* 0x1ef8: tbnz w24, #4, 1f40 <generic_fentry_process_filter+0x1f40> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 4, 0x1ef8, 0x1f40, arm64_l_1f40);
arm64_l_1efc:
	/* 0x1efc: ldr w9, [x0, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1f00:
	/* 0x1f00: cbz w9, 1f38 <generic_fentry_process_filter+0x1f38> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1f00, 0x1f38, arm64_l_1f38);
arm64_l_1f04:
	/* 0x1f04: ldr w10, [x29, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1f08:
	/* 0x1f08: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f0c:
	/* 0x1f0c: b.eq 1f40 <generic_fentry_process_filter+0x1f40> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f0c, 0x1f40, arm64_l_1f40);
arm64_l_1f10:
	/* 0x1f10: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x1f10, 0x2088, arm64_l_2088);
arm64_l_1f14:
	/* 0x1f14: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f18:
	/* 0x1f18: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f1c:
	/* 0x1f1c: tbz w24, #4, 1f64 <generic_fentry_process_filter+0x1f64> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 4, 0x1f1c, 0x1f64, arm64_l_1f64);
arm64_l_1f20:
	/* 0x1f20: ldr w9, [x0, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1f24:
	/* 0x1f24: cbz w9, 1f5c <generic_fentry_process_filter+0x1f5c> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1f24, 0x1f5c, arm64_l_1f5c);
arm64_l_1f28:
	/* 0x1f28: ldr w10, [x29, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1f2c:
	/* 0x1f2c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f30:
	/* 0x1f30: b.eq 1f64 <generic_fentry_process_filter+0x1f64> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f30, 0x1f64, arm64_l_1f64);
arm64_l_1f34:
	/* 0x1f34: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x1f34, 0x2088, arm64_l_2088);
arm64_l_1f38:
	/* 0x1f38: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f3c:
	/* 0x1f3c: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f40:
	/* 0x1f40: tbnz w24, #5, 1f88 <generic_fentry_process_filter+0x1f88> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 5, 0x1f40, 0x1f88, arm64_l_1f88);
arm64_l_1f44:
	/* 0x1f44: ldr w9, [x0, #60] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 60ULL);
arm64_l_1f48:
	/* 0x1f48: cbz w9, 1f80 <generic_fentry_process_filter+0x1f80> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1f48, 0x1f80, arm64_l_1f80);
arm64_l_1f4c:
	/* 0x1f4c: ldr w10, [x29, #52] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 52ULL);
arm64_l_1f50:
	/* 0x1f50: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f54:
	/* 0x1f54: b.eq 1f88 <generic_fentry_process_filter+0x1f88> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f54, 0x1f88, arm64_l_1f88);
arm64_l_1f58:
	/* 0x1f58: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x1f58, 0x2088, arm64_l_2088);
arm64_l_1f5c:
	/* 0x1f5c: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f60:
	/* 0x1f60: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f64:
	/* 0x1f64: tbz w24, #5, 1fac <generic_fentry_process_filter+0x1fac> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 5, 0x1f64, 0x1fac, arm64_l_1fac);
arm64_l_1f68:
	/* 0x1f68: ldr w9, [x0, #60] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 60ULL);
arm64_l_1f6c:
	/* 0x1f6c: cbz w9, 1fa4 <generic_fentry_process_filter+0x1fa4> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1f6c, 0x1fa4, arm64_l_1fa4);
arm64_l_1f70:
	/* 0x1f70: ldr w10, [x29, #52] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 52ULL);
arm64_l_1f74:
	/* 0x1f74: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f78:
	/* 0x1f78: b.eq 1fac <generic_fentry_process_filter+0x1fac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f78, 0x1fac, arm64_l_1fac);
arm64_l_1f7c:
	/* 0x1f7c: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x1f7c, 0x2088, arm64_l_2088);
arm64_l_1f80:
	/* 0x1f80: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f84:
	/* 0x1f84: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f88:
	/* 0x1f88: tbnz w24, #6, 1fd0 <generic_fentry_process_filter+0x1fd0> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 6, 0x1f88, 0x1fd0, arm64_l_1fd0);
arm64_l_1f8c:
	/* 0x1f8c: ldr w9, [x0, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1f90:
	/* 0x1f90: cbz w9, 1fc8 <generic_fentry_process_filter+0x1fc8> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1f90, 0x1fc8, arm64_l_1fc8);
arm64_l_1f94:
	/* 0x1f94: ldr w10, [x29, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1f98:
	/* 0x1f98: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f9c:
	/* 0x1f9c: b.eq 1fd0 <generic_fentry_process_filter+0x1fd0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f9c, 0x1fd0, arm64_l_1fd0);
arm64_l_1fa0:
	/* 0x1fa0: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x1fa0, 0x2088, arm64_l_2088);
arm64_l_1fa4:
	/* 0x1fa4: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1fa8:
	/* 0x1fa8: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1fac:
	/* 0x1fac: tbz w24, #6, 1ff4 <generic_fentry_process_filter+0x1ff4> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 6, 0x1fac, 0x1ff4, arm64_l_1ff4);
arm64_l_1fb0:
	/* 0x1fb0: ldr w9, [x0, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1fb4:
	/* 0x1fb4: cbz w9, 1fec <generic_fentry_process_filter+0x1fec> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1fb4, 0x1fec, arm64_l_1fec);
arm64_l_1fb8:
	/* 0x1fb8: ldr w10, [x29, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1fbc:
	/* 0x1fbc: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fc0:
	/* 0x1fc0: b.eq 1ff4 <generic_fentry_process_filter+0x1ff4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1fc0, 0x1ff4, arm64_l_1ff4);
arm64_l_1fc4:
	/* 0x1fc4: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x1fc4, 0x2088, arm64_l_2088);
arm64_l_1fc8:
	/* 0x1fc8: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1fcc:
	/* 0x1fcc: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1fd0:
	/* 0x1fd0: tbnz w24, #7, 2018 <generic_fentry_process_filter+0x2018> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 7, 0x1fd0, 0x2018, arm64_l_2018);
arm64_l_1fd4:
	/* 0x1fd4: ldr w9, [x0, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_1fd8:
	/* 0x1fd8: cbz w9, 2010 <generic_fentry_process_filter+0x2010> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1fd8, 0x2010, arm64_l_2010);
arm64_l_1fdc:
	/* 0x1fdc: ldr w10, [x29, #60] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 60ULL);
arm64_l_1fe0:
	/* 0x1fe0: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fe4:
	/* 0x1fe4: b.eq 2018 <generic_fentry_process_filter+0x2018> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1fe4, 0x2018, arm64_l_2018);
arm64_l_1fe8:
	/* 0x1fe8: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x1fe8, 0x2088, arm64_l_2088);
arm64_l_1fec:
	/* 0x1fec: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ff0:
	/* 0x1ff0: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ff4:
	/* 0x1ff4: tbz w24, #7, 203c <generic_fentry_process_filter+0x203c> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 7, 0x1ff4, 0x203c, arm64_l_203c);
arm64_l_1ff8:
	/* 0x1ff8: ldr w9, [x0, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_1ffc:
	/* 0x1ffc: cbz w9, 2034 <generic_fentry_process_filter+0x2034> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1ffc, 0x2034, arm64_l_2034);
arm64_l_2000:
	/* 0x2000: ldr w10, [x29, #60] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 60ULL);
arm64_l_2004:
	/* 0x2004: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2008:
	/* 0x2008: b.eq 203c <generic_fentry_process_filter+0x203c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2008, 0x203c, arm64_l_203c);
arm64_l_200c:
	/* 0x200c: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x200c, 0x2088, arm64_l_2088);
arm64_l_2010:
	/* 0x2010: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2014:
	/* 0x2014: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2018:
	/* 0x2018: tbnz w24, #8, 2060 <generic_fentry_process_filter+0x2060> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 8, 0x2018, 0x2060, arm64_l_2060);
arm64_l_201c:
	/* 0x201c: ldr w9, [x0, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2020:
	/* 0x2020: cbz w9, 2058 <generic_fentry_process_filter+0x2058> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x2020, 0x2058, arm64_l_2058);
arm64_l_2024:
	/* 0x2024: ldr w10, [x29, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_2028:
	/* 0x2028: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_202c:
	/* 0x202c: b.eq 2060 <generic_fentry_process_filter+0x2060> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x202c, 0x2060, arm64_l_2060);
arm64_l_2030:
	/* 0x2030: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x2030, 0x2088, arm64_l_2088);
arm64_l_2034:
	/* 0x2034: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2038:
	/* 0x2038: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_203c:
	/* 0x203c: tbz w24, #8, 2070 <generic_fentry_process_filter+0x2070> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 8, 0x203c, 0x2070, arm64_l_2070);
arm64_l_2040:
	/* 0x2040: ldr w9, [x0, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2044:
	/* 0x2044: cbz w9, 2068 <generic_fentry_process_filter+0x2068> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x2044, 0x2068, arm64_l_2068);
arm64_l_2048:
	/* 0x2048: ldr w10, [x29, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_204c:
	/* 0x204c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2050:
	/* 0x2050: b.eq 2070 <generic_fentry_process_filter+0x2070> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2050, 0x2070, arm64_l_2070);
arm64_l_2054:
	/* 0x2054: b 2088 <generic_fentry_process_filter+0x2088> */
	ARM64_SIM_A64_JMP(0x2054, 0x2088, arm64_l_2088);
arm64_l_2058:
	/* 0x2058: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_205c:
	/* 0x205c: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2060:
	/* 0x2060: tbz w24, #9, 2074 <generic_fentry_process_filter+0x2074> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 9, 0x2060, 0x2074, arm64_l_2074);
arm64_l_2064:
	/* 0x2064: b 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_JMP(0x2064, 0x2184, arm64_l_2184);
arm64_l_2068:
	/* 0x2068: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_206c:
	/* 0x206c: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2070:
	/* 0x2070: tbz w24, #9, 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 9, 0x2070, 0x2184, arm64_l_2184);
arm64_l_2074:
	/* 0x2074: ldr w9, [x0, #76] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_2078:
	/* 0x2078: cbz w9, 217c <generic_fentry_process_filter+0x217c> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x2078, 0x217c, arm64_l_217c);
arm64_l_207c:
	/* 0x207c: ldr w10, [x29, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_2080:
	/* 0x2080: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2084:
	/* 0x2084: b.eq 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2084, 0x2184, arm64_l_2184);
arm64_l_2088:
	/* 0x2088: add w9, w19, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_208c:
	/* 0x208c: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2090:
	/* 0x2090: str x10, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2094:
	/* 0x2094: and x8, x9, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_2098:
	/* 0x2098: ldr w8, [x8, x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X23, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_209c:
	/* 0x209c: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_20a0:
	/* 0x20a0: b.ne 20d0 <generic_fentry_process_filter+0x20d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x20a0, 0x20d0, arm64_l_20d0);
arm64_l_20a4:
	/* 0x20a4: ldr x9, [x29, #24248] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24248ULL);
arm64_l_20a8:
	/* 0x20a8: mov w8, #0x5eb8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24248ULL);
arm64_l_20ac:
	/* 0x20ac: add x8, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_20b0:
	/* 0x20b0: and x9, x9, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_20b4:
	/* 0x20b4: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_20b8:
	/* 0x20b8: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_20bc:
	/* 0x20bc: strb w9, [x8, #9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 9ULL);
arm64_l_20c0:
	/* 0x20c0: ldr x8, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_20c4:
	/* 0x20c4: strb w9, [x8, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_20c8:
	/* 0x20c8: strb w9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_20cc:
	/* 0x20cc: b 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_JMP(0x20cc, 0x2184, arm64_l_2184);
arm64_l_20d0:
	/* 0x20d0: add w8, w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_20d4:
	/* 0x20d4: and x8, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_20d8:
	/* 0x20d8: add x8, x8, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_20dc:
	/* 0x20dc: ldp w21, w19, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X21, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_20e0:
	/* 0x20e0: ldr w22, [x8, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_20e4:
	/* 0x20e4: ldur x20, [x8, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_20e8:
	/* 0x20e8: mov w8, #0xe */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_20ec:
	/* 0x20ec: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x20f0ULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_20f0:
	/* 0x20f0: lsr x8, x0, #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 32ULL);
arm64_l_20f4:
	/* 0x20f4: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_20f8:
	/* 0x20f8: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_20fc:
	/* 0x20fc: str w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_2100:
	/* 0x2100: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2104:
	/* 0x2104: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_2108:
	/* 0x2108: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_210c:
	/* 0x210c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2110ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2110:
	/* 0x2110: cbz x0, 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2110, 0x2184, arm64_l_2184);
arm64_l_2114:
	/* 0x2114: cmp w21, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2118:
	/* 0x2118: cbz w22, 2130 <generic_fentry_process_filter+0x2130> */
	ARM64_SIM_A64_CBZ(ARM64_X22, 0x2118, 0x2130, arm64_l_2130);
arm64_l_211c:
	/* 0x211c: b.hi 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x211c, 0x2184, arm64_l_2184);
arm64_l_2120:
	/* 0x2120: ldr w8, [x29, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_2124:
	/* 0x2124: cmp w8, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2128:
	/* 0x2128: b.ne 2134 <generic_fentry_process_filter+0x2134> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2128, 0x2134, arm64_l_2134);
arm64_l_212c:
	/* 0x212c: b 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_JMP(0x212c, 0x2184, arm64_l_2184);
arm64_l_2130:
	/* 0x2130: b.hi 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2130, 0x2184, arm64_l_2184);
arm64_l_2134:
	/* 0x2134: add x9, x29, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2138:
	/* 0x2138: add x8, x0, x21, lsl #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 3), 0);
arm64_l_213c:
	/* 0x213c: lsl x10, x21, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_2140:
	/* 0x2140: ldr x8, [x8, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_2144:
	/* 0x2144: ldr x9, [x9, x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_X10, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2148:
	/* 0x2148: eor x10, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_214c:
	/* 0x214c: tst x10, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2150:
	/* 0x2150: b.eq 2160 <generic_fentry_process_filter+0x2160> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2150, 0x2160, arm64_l_2160);
arm64_l_2154:
	/* 0x2154: cmp w19, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2158:
	/* 0x2158: b.eq 2170 <generic_fentry_process_filter+0x2170> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2158, 0x2170, arm64_l_2170);
arm64_l_215c:
	/* 0x215c: b 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_JMP(0x215c, 0x2184, arm64_l_2184);
arm64_l_2160:
	/* 0x2160: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2164:
	/* 0x2164: b.eq 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2164, 0x2184, arm64_l_2184);
arm64_l_2168:
	/* 0x2168: cmp w19, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_216c:
	/* 0x216c: b.ne 2184 <generic_fentry_process_filter+0x2184> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x216c, 0x2184, arm64_l_2184);
arm64_l_2170:
	/* 0x2170: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2174:
	/* 0x2174: str x8, [x29, #24304] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24304ULL);
arm64_l_2178:
	/* 0x2178: b 20a4 <generic_fentry_process_filter+0x20a4> */
	ARM64_SIM_A64_JMP(0x2178, 0x20a4, arm64_l_20a4);
arm64_l_217c:
	/* 0x217c: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2180:
	/* 0x2180: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2184:
	/* 0x2184: ldr x8, [x29, #24248] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24248ULL);
arm64_l_2188:
	/* 0x2188: ldr x9, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_218c:
	/* 0x218c: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2190:
	/* 0x2190: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2194:
	/* 0x2194: str x8, [x29, #24248] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24248ULL);
arm64_l_2198:
	/* 0x2198: b.ls 21fc <generic_fentry_process_filter+0x21fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2198, 0x21fc, arm64_l_21fc);
arm64_l_219c:
	/* 0x219c: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_21a0:
	/* 0x21a0: ldr x20, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_21a4:
	/* 0x21a4: ldr w8, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_21a8:
	/* 0x21a8: str w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_21ac:
	/* 0x21ac: ldr x8, [x9, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_21b0:
	/* 0x21b0: str x8, [x29, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_21b4:
	/* 0x21b4: ldr x8, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_21b8:
	/* 0x21b8: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_21bc:
	/* 0x21bc: cbz w8, 21dc <generic_fentry_process_filter+0x21dc> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x21bc, 0x21dc, arm64_l_21dc);
arm64_l_21c0:
	/* 0x21c0: adrp x1, 0 <fentry_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&fentry_calls_5));
arm64_l_21c4:
	/* 0x21c4: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_21c8:
	/* 0x21c8: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_21cc:
	/* 0x21cc: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_21d0:
	/* 0x21d0: mov x0, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_21d4:
	/* 0x21d4: mov w2, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_21d8:
	/* 0x21d8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x21dcULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_21dc:
	/* 0x21dc: ldp x20, x19, [sp, #288] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 288ULL);
arm64_l_21e0:
	/* 0x21e0: mov w0, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_21e4:
	/* 0x21e4: ldr x29, [sp, #224] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_21e8:
	/* 0x21e8: ldp x22, x21, [sp, #272] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 272ULL);
arm64_l_21ec:
	/* 0x21ec: ldp x24, x23, [sp, #256] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 256ULL);
arm64_l_21f0:
	/* 0x21f0: ldp x30, x25, [sp, #240] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 240ULL);
arm64_l_21f4:
	/* 0x21f4: add sp, sp, #0x130 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 304ULL);
arm64_l_21f8:
	/* 0x21f8: b 2218 <__native_link_arm64_ret_trampoline> */
	ARM64_SIM_A64_JMP(0x21f8, 0x2218, arm64_l_2218);
arm64_l_21fc:
	/* 0x21fc: adrp x1, 0 <fentry_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&fentry_calls_5));
arm64_l_2200:
	/* 0x2200: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2204:
	/* 0x2204: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_2208:
	/* 0x2208: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_220c:
	/* 0x220c: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2210:
	/* 0x2210: mov w2, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2214:
	/* 0x2214: b 21d8 <generic_fentry_process_filter+0x21d8> */
	ARM64_SIM_A64_JMP(0x2214, 0x21d8, arm64_l_21d8);
arm64_l_2218:
	/* 0x2218: mov x7, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
