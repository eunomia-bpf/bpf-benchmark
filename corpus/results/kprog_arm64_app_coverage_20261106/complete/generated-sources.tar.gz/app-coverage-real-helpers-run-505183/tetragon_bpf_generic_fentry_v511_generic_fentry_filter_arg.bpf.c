extern char addr4lpm_maps;
extern char addr6lpm_maps;
extern char argfilter_maps;
extern char fentry_calls;
extern char filter_map;
extern char heap_ro_zero;
extern char process_call_heap;
extern char retprobe_map;
extern char string_maps_0;
extern char string_maps_1;
extern char string_maps_10;
extern char string_maps_2;
extern char string_maps_3;
extern char string_maps_4;
extern char string_maps_5;
extern char string_maps_6;
extern char string_maps_7;
extern char string_maps_8;
extern char string_maps_9;
extern char string_maps_heap;
extern char string_postfix_maps;
extern char string_postfix_maps_heap;
extern char string_prefix_maps;
extern char string_prefix_maps_heap;
extern char substring_map;
#define ARM64_SIM_RET_CASES_34a0 case 0x15d0ULL: goto arm64_l_15d0;
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_RETURN_CASES \
	case 0x38ULL: goto arm64_l_38; \
	case 0x64ULL: goto arm64_l_64; \
	case 0x18cULL: goto arm64_l_18c; \
	case 0x1a8ULL: goto arm64_l_1a8; \
	case 0x244ULL: goto arm64_l_244; \
	case 0x250ULL: goto arm64_l_250; \
	case 0x270ULL: goto arm64_l_270; \
	case 0x288ULL: goto arm64_l_288; \
	case 0x5d8ULL: goto arm64_l_5d8; \
	case 0x6fcULL: goto arm64_l_6fc; \
	case 0x724ULL: goto arm64_l_724; \
	case 0x828ULL: goto arm64_l_828; \
	case 0x850ULL: goto arm64_l_850; \
	case 0x8f8ULL: goto arm64_l_8f8; \
	case 0x920ULL: goto arm64_l_920; \
	case 0x950ULL: goto arm64_l_950; \
	case 0x960ULL: goto arm64_l_960; \
	case 0xa9cULL: goto arm64_l_a9c; \
	case 0xab8ULL: goto arm64_l_ab8; \
	case 0xaf8ULL: goto arm64_l_af8; \
	case 0xbf8ULL: goto arm64_l_bf8; \
	case 0xd18ULL: goto arm64_l_d18; \
	case 0xd40ULL: goto arm64_l_d40; \
	case 0xd70ULL: goto arm64_l_d70; \
	case 0xd80ULL: goto arm64_l_d80; \
	case 0xf9cULL: goto arm64_l_f9c; \
	case 0xfc4ULL: goto arm64_l_fc4; \
	case 0x11acULL: goto arm64_l_11ac; \
	case 0x1220ULL: goto arm64_l_1220; \
	case 0x1390ULL: goto arm64_l_1390; \
	case 0x1408ULL: goto arm64_l_1408; \
	case 0x1440ULL: goto arm64_l_1440; \
	case 0x14d4ULL: goto arm64_l_14d4; \
	case 0x14fcULL: goto arm64_l_14fc; \
	case 0x15bcULL: goto arm64_l_15bc; \
	case 0x15d0ULL: goto arm64_l_15d0; \
	case 0x162cULL: goto arm64_l_162c; \
	case 0x1654ULL: goto arm64_l_1654; \
	case 0x167cULL: goto arm64_l_167c; \
	case 0x168cULL: goto arm64_l_168c; \
	case 0x16e4ULL: goto arm64_l_16e4; \
	case 0x1720ULL: goto arm64_l_1720; \
	case 0x1748ULL: goto arm64_l_1748; \
	case 0x1778ULL: goto arm64_l_1778; \
	case 0x184cULL: goto arm64_l_184c; \
	case 0x1864ULL: goto arm64_l_1864; \
	case 0x1c2cULL: goto arm64_l_1c2c; \
	case 0x1da4ULL: goto arm64_l_1da4; \
	case 0x1dbcULL: goto arm64_l_1dbc; \
	case 0x20ccULL: goto arm64_l_20cc; \
	case 0x20e4ULL: goto arm64_l_20e4; \
	case 0x2130ULL: goto arm64_l_2130; \
	case 0x217cULL: goto arm64_l_217c; \
	case 0x21a4ULL: goto arm64_l_21a4; \
	case 0x24e4ULL: goto arm64_l_24e4; \
	case 0x24fcULL: goto arm64_l_24fc; \
	case 0x254cULL: goto arm64_l_254c; \
	case 0x257cULL: goto arm64_l_257c; \
	case 0x25a0ULL: goto arm64_l_25a0; \
	case 0x29b0ULL: goto arm64_l_29b0; \
	case 0x29c8ULL: goto arm64_l_29c8; \
	case 0x2a1cULL: goto arm64_l_2a1c; \
	case 0x2a64ULL: goto arm64_l_2a64; \
	case 0x2a88ULL: goto arm64_l_2a88; \
	case 0x2cd4ULL: goto arm64_l_2cd4; \
	case 0x2ce4ULL: goto arm64_l_2ce4; \
	case 0x2dd0ULL: goto arm64_l_2dd0; \
	case 0x2de0ULL: goto arm64_l_2de0; \
	case 0x2edcULL: goto arm64_l_2edc; \
	case 0x2eecULL: goto arm64_l_2eec; \
	case 0x3100ULL: goto arm64_l_3100; \
	case 0x311cULL: goto arm64_l_311c; \
	case 0x3154ULL: goto arm64_l_3154; \
	case 0x318cULL: goto arm64_l_318c; \
	case 0x31b0ULL: goto arm64_l_31b0; \
	case 0x336cULL: goto arm64_l_336c; \
	case 0x337cULL: goto arm64_l_337c;
#include "../arm64_sim_local_bpf.h"

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} addr4lpm_maps_0 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} addr6lpm_maps_1 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} argfilter_maps_2 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} fentry_calls_3 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} filter_map_4 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} heap_ro_zero_5 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} process_call_heap_6 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} retprobe_map_7 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_0_8 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_1_9 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_10_10 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_2_11 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_3_12 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_4_13 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_5_14 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_6_15 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_7_16 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_8_17 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_9_18 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_heap_19 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_postfix_maps_20 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_postfix_maps_heap_21 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_prefix_maps_22 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_prefix_maps_heap_23 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} substring_map_24 SEC(".maps");

SEC("xdp")
int tetragon_bpf_generic_fentry_v511_generic_fentry_filter_arg_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
arm64_l_0:
	/* 0x0: sub sp, sp, #0xf0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_4:
	/* 0x4: str x29, [sp, #160] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_8:
	/* 0x8: stp x30, x25, [sp, #176] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_c:
	/* 0xc: stp x24, x23, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_10:
	/* 0x10: stp x22, x21, [sp, #208] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_14:
	/* 0x14: stp x20, x19, [sp, #224] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_18:
	/* 0x18: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c:
	/* 0x1c: str wzr, [sp, #168] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_20:
	/* 0x20: adrp x0, 0 <process_call_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_6));
arm64_l_24:
	/* 0x24: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28:
	/* 0x28: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c:
	/* 0x2c: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_30:
	/* 0x30: add x1, sp, #0xa8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_34:
	/* 0x34: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x38ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_38:
	/* 0x38: cbz x0, 1a8 <generic_fentry_filter_arg+0x1a8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x38, 0x1a8, arm64_l_1a8);
arm64_l_3c:
	/* 0x3c: mov w8, #0x5ec1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24257ULL);
arm64_l_40:
	/* 0x40: mov x20, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_44:
	/* 0x44: add x22, x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_48:
	/* 0x48: mov w8, #0x5ef8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24312ULL);
arm64_l_4c:
	/* 0x4c: add x1, x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X1, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_50:
	/* 0x50: adrp x0, 0 <filter_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&filter_map_4));
arm64_l_54:
	/* 0x54: ldur w23, [x22, #63] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 63ULL);
arm64_l_58:
	/* 0x58: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_5c:
	/* 0x5c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_60:
	/* 0x60: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x64ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_64:
	/* 0x64: cbz x0, 18c <generic_fentry_filter_arg+0x18c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x64, 0x18c, arm64_l_18c);
arm64_l_68:
	/* 0x68: ldrb w8, [x22, #31] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 31ULL);
arm64_l_6c:
	/* 0x6c: cbz w8, 18c <generic_fentry_filter_arg+0x18c> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x6c, 0x18c, arm64_l_18c);
arm64_l_70:
	/* 0x70: and x8, x23, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_74:
	/* 0x74: mov w10, #0x5ec1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24257ULL);
arm64_l_78:
	/* 0x78: stp x23, x22, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_7c:
	/* 0x7c: add x9, x20, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_80:
	/* 0x80: ldrb w9, [x9, x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X10, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_84:
	/* 0x84: cbz w9, fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x84, 0xfc, arm64_l_fc);
arm64_l_88:
	/* 0x88: lsl w8, w8, #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_8c:
	/* 0x8c: mov x21, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_90:
	/* 0x90: add x8, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_94:
	/* 0x94: ldr w9, [x8, x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X0, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_98:
	/* 0x98: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_9c:
	/* 0x9c: add x8, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_a0:
	/* 0xa0: and x9, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_a4:
	/* 0xa4: ldr w9, [x9, x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X0, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a8:
	/* 0xa8: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_ac:
	/* 0xac: and x9, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_b0:
	/* 0xb0: ldr w9, [x9, x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X0, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b4:
	/* 0xb4: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_b8:
	/* 0xb8: and x9, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_bc:
	/* 0xbc: ldr w9, [x9, x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X0, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c0:
	/* 0xc0: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_c4:
	/* 0xc4: and x9, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_c8:
	/* 0xc8: ldr w9, [x9, x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X0, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cc:
	/* 0xcc: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_d0:
	/* 0xd0: and x9, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_d4:
	/* 0xd4: ldr w9, [x9, x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X0, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d8:
	/* 0xd8: add x16, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X16, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_dc:
	/* 0xdc: and x15, x16, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X16, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_e0:
	/* 0xe0: add x17, x0, x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X17, ARM64_X0, ARM64_X15, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_e4:
	/* 0xe4: ldr w8, [x17] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e8:
	/* 0xe8: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_ec:
	/* 0xec: b.cs 150 <generic_fentry_filter_arg+0x150> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xec, 0x150, arm64_l_150);
arm64_l_f0:
	/* 0xf0: cmp w15, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_f4:
	/* 0xf4: b.eq 18c <generic_fentry_filter_arg+0x18c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf4, 0x18c, arm64_l_18c);
arm64_l_f8:
	/* 0xf8: cbnz w15, 168 <generic_fentry_filter_arg+0x168> */
	ARM64_SIM_A64_CBNZ(ARM64_X15, 0xf8, 0x168, arm64_l_168);
arm64_l_fc:
	/* 0xfc: ldr x8, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_100:
	/* 0x100: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_104:
	/* 0x104: b.gt 124 <generic_fentry_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x104, 0x124, arm64_l_124);
arm64_l_108:
	/* 0x108: ldr x9, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_10c:
	/* 0x10c: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_110:
	/* 0x110: b.eq 1c8 <generic_fentry_filter_arg+0x1c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x110, 0x1c8, arm64_l_1c8);
arm64_l_114:
	/* 0x114: cbz w8, 1d8 <generic_fentry_filter_arg+0x1d8> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x114, 0x1d8, arm64_l_1d8);
arm64_l_118:
	/* 0x118: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_11c:
	/* 0x11c: b.eq 1e8 <generic_fentry_filter_arg+0x1e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x11c, 0x1e8, arm64_l_1e8);
arm64_l_120:
	/* 0x120: b 140 <generic_fentry_filter_arg+0x140> */
	ARM64_SIM_A64_JMP(0x120, 0x140, arm64_l_140);
arm64_l_124:
	/* 0x124: ldr x9, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_128:
	/* 0x128: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_12c:
	/* 0x12c: b.eq 1f8 <generic_fentry_filter_arg+0x1f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x12c, 0x1f8, arm64_l_1f8);
arm64_l_130:
	/* 0x130: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_134:
	/* 0x134: b.eq 208 <generic_fentry_filter_arg+0x208> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x134, 0x208, arm64_l_208);
arm64_l_138:
	/* 0x138: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_13c:
	/* 0x13c: b.eq 218 <generic_fentry_filter_arg+0x218> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x13c, 0x218, arm64_l_218);
arm64_l_140:
	/* 0x140: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_144:
	/* 0x144: b.gt 244 <generic_fentry_filter_arg+0x244> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x144, 0x244, arm64_l_244);
arm64_l_148:
	/* 0x148: add w8, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_14c:
	/* 0x14c: b 224 <generic_fentry_filter_arg+0x224> */
	ARM64_SIM_A64_JMP(0x14c, 0x224, arm64_l_224);
arm64_l_150:
	/* 0x150: mov x24, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_154:
	/* 0x154: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_158:
	/* 0x158: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_15c:
	/* 0x15c: stp x19, x17, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X19, ARM64_X17, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_160:
	/* 0x160: stp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X16, ARM64_X15, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_164:
	/* 0x164: b 2a4 <generic_fentry_filter_arg+0x2a4> */
	ARM64_SIM_A64_JMP(0x164, 0x2a4, arm64_l_2a4);
arm64_l_168:
	/* 0x168: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_16c:
	/* 0x16c: adrp x1, 0 <fentry_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&fentry_calls_3));
arm64_l_170:
	/* 0x170: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_174:
	/* 0x174: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_178:
	/* 0x178: stur w15, [x8, #67] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 67ULL);
arm64_l_17c:
	/* 0x17c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_180:
	/* 0x180: mov w2, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_184:
	/* 0x184: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_188:
	/* 0x188: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x18cULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_18c:
	/* 0x18c: adrp x1, 0 <fentry_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&fentry_calls_3));
arm64_l_190:
	/* 0x190: mov w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_194:
	/* 0x194: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_198:
	/* 0x198: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19c:
	/* 0x19c: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a0:
	/* 0x1a0: mov w2, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_1a4:
	/* 0x1a4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x1a8ULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1a8:
	/* 0x1a8: ldp x20, x19, [sp, #224] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_1ac:
	/* 0x1ac: mov w0, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1b0:
	/* 0x1b0: ldr x29, [sp, #160] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_1b4:
	/* 0x1b4: ldp x22, x21, [sp, #208] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_1b8:
	/* 0x1b8: ldp x24, x23, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_1bc:
	/* 0x1bc: ldp x30, x25, [sp, #176] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_1c0:
	/* 0x1c0: add sp, sp, #0xf0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1c4:
	/* 0x1c4: b 34a8 <__native_link_arm64_ret_trampoline> */
	ARM64_SIM_A64_JMP(0x1c4, 0x34a8, arm64_l_34a8);
arm64_l_1c8:
	/* 0x1c8: ldrb w8, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1cc:
	/* 0x1cc: cbz w8, 1d8 <generic_fentry_filter_arg+0x1d8> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1cc, 0x1d8, arm64_l_1d8);
arm64_l_1d0:
	/* 0x1d0: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1d4:
	/* 0x1d4: b 224 <generic_fentry_filter_arg+0x224> */
	ARM64_SIM_A64_JMP(0x1d4, 0x224, arm64_l_224);
arm64_l_1d8:
	/* 0x1d8: ldrb w8, [x9, #1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1ULL);
arm64_l_1dc:
	/* 0x1dc: cbz w8, 1e8 <generic_fentry_filter_arg+0x1e8> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1dc, 0x1e8, arm64_l_1e8);
arm64_l_1e0:
	/* 0x1e0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e4:
	/* 0x1e4: b 224 <generic_fentry_filter_arg+0x224> */
	ARM64_SIM_A64_JMP(0x1e4, 0x224, arm64_l_224);
arm64_l_1e8:
	/* 0x1e8: ldrb w8, [x9, #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_1ec:
	/* 0x1ec: cbz w8, 1f8 <generic_fentry_filter_arg+0x1f8> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1ec, 0x1f8, arm64_l_1f8);
arm64_l_1f0:
	/* 0x1f0: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1f4:
	/* 0x1f4: b 224 <generic_fentry_filter_arg+0x224> */
	ARM64_SIM_A64_JMP(0x1f4, 0x224, arm64_l_224);
arm64_l_1f8:
	/* 0x1f8: ldrb w8, [x9, #3] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3ULL);
arm64_l_1fc:
	/* 0x1fc: cbz w8, 208 <generic_fentry_filter_arg+0x208> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1fc, 0x208, arm64_l_208);
arm64_l_200:
	/* 0x200: mov w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_204:
	/* 0x204: b 224 <generic_fentry_filter_arg+0x224> */
	ARM64_SIM_A64_JMP(0x204, 0x224, arm64_l_224);
arm64_l_208:
	/* 0x208: ldrb w8, [x9, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_20c:
	/* 0x20c: cbz w8, 218 <generic_fentry_filter_arg+0x218> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x20c, 0x218, arm64_l_218);
arm64_l_210:
	/* 0x210: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_214:
	/* 0x214: b 224 <generic_fentry_filter_arg+0x224> */
	ARM64_SIM_A64_JMP(0x214, 0x224, arm64_l_224);
arm64_l_218:
	/* 0x218: ldrb w8, [x9, #5] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_21c:
	/* 0x21c: cbz w8, 244 <generic_fentry_filter_arg+0x244> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x21c, 0x244, arm64_l_244);
arm64_l_220:
	/* 0x220: mov w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_224:
	/* 0x224: stur w8, [x9, #63] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 63ULL);
arm64_l_228:
	/* 0x228: adrp x1, 0 <fentry_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&fentry_calls_3));
arm64_l_22c:
	/* 0x22c: mov w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_230:
	/* 0x230: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_234:
	/* 0x234: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_238:
	/* 0x238: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_23c:
	/* 0x23c: mov w2, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_240:
	/* 0x240: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x244ULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_244:
	/* 0x244: ldr x19, [x20, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_248:
	/* 0x248: mov w8, #0xe */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_24c:
	/* 0x24c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x250ULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_250:
	/* 0x250: stp x19, x0, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_254:
	/* 0x254: adrp x19, 0 <retprobe_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&retprobe_map_7));
arm64_l_258:
	/* 0x258: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_25c:
	/* 0x25c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_260:
	/* 0x260: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_264:
	/* 0x264: ldr x19, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_268:
	/* 0x268: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_26c:
	/* 0x26c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x270ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_270:
	/* 0x270: cbz x0, 1a8 <generic_fentry_filter_arg+0x1a8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x270, 0x1a8, arm64_l_1a8);
arm64_l_274:
	/* 0x274: mov w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_278:
	/* 0x278: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_27c:
	/* 0x27c: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_280:
	/* 0x280: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_284:
	/* 0x284: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 3ULL: ARM64_SIM_A64_LINK(0x288ULL); ARM64_SIM_BPF_CALL_bpf_map_delete_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_288:
	/* 0x288: b 1a8 <generic_fentry_filter_arg+0x1a8> */
	ARM64_SIM_A64_JMP(0x288, 0x1a8, arm64_l_1a8);
arm64_l_28c:
	/* 0x28c: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_290:
	/* 0x290: cset w22, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_294:
	/* 0x294: cbz x22, fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_CBZ(ARM64_X22, 0x294, 0xfc, arm64_l_fc);
arm64_l_298:
	/* 0x298: add x24, x24, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_29c:
	/* 0x29c: cmp x24, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2a0:
	/* 0x2a0: b.eq f0 <generic_fentry_filter_arg+0xf0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2a0, 0xf0, arm64_l_f0);
arm64_l_2a4:
	/* 0x2a4: add x8, x17, x24, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X17, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_2a8:
	/* 0x2a8: ldr w8, [x8, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2ac:
	/* 0x2ac: tst w8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_2b0:
	/* 0x2b0: b.eq f0 <generic_fentry_filter_arg+0xf0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2b0, 0xf0, arm64_l_f0);
arm64_l_2b4:
	/* 0x2b4: add w8, w16, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X16, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2b8:
	/* 0x2b8: and x8, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_2bc:
	/* 0x2bc: add x23, x21, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2c0:
	/* 0x2c0: ldr w8, [x23, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2c4:
	/* 0x2c4: cmp w8, #0x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 35ULL);
arm64_l_2c8:
	/* 0x2c8: b.eq fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2c8, 0xfc, arm64_l_fc);
arm64_l_2cc:
	/* 0x2cc: ldr w9, [x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d0:
	/* 0x2d0: cmp w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2d4:
	/* 0x2d4: b.hi fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2d4, 0xfc, arm64_l_fc);
arm64_l_2d8:
	/* 0x2d8: add x10, x20, x9, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_2dc:
	/* 0x2dc: ldr w10, [x10, x2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X10, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X2, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2e0:
	/* 0x2e0: cbnz w10, fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0x2e0, 0xfc, arm64_l_fc);
arm64_l_2e4:
	/* 0x2e4: add x9, x20, x9, lsl #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 3), 0);
arm64_l_2e8:
	/* 0x2e8: ldr x9, [x9, #24184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24184ULL);
arm64_l_2ec:
	/* 0x2ec: and x9, x9, #0x7ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2047ULL);
arm64_l_2f0:
	/* 0x2f0: add x9, x20, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2f4:
	/* 0x2f4: add x25, x9, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2f8:
	/* 0x2f8: ldr w9, [x23, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_2fc:
	/* 0x2fc: cmp w9, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_300:
	/* 0x300: b.le 324 <generic_fentry_filter_arg+0x324> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x300, 0x324, arm64_l_324);
arm64_l_304:
	/* 0x304: cmp w9, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_308:
	/* 0x308: b.gt 354 <generic_fentry_filter_arg+0x354> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x308, 0x354, arm64_l_354);
arm64_l_30c:
	/* 0x30c: sub w10, w9, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_310:
	/* 0x310: cmp w10, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_314:
	/* 0x314: b.cc 398 <generic_fentry_filter_arg+0x398> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x314, 0x398, arm64_l_398);
arm64_l_318:
	/* 0x318: cmp w9, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_31c:
	/* 0x31c: b.eq 54c <generic_fentry_filter_arg+0x54c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x31c, 0x54c, arm64_l_54c);
arm64_l_320:
	/* 0x320: b 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JMP(0x320, 0x298, arm64_l_298);
arm64_l_324:
	/* 0x324: cmp w9, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_328:
	/* 0x328: b.le 378 <generic_fentry_filter_arg+0x378> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x328, 0x378, arm64_l_378);
arm64_l_32c:
	/* 0x32c: sub w10, w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_330:
	/* 0x330: cmp w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_334:
	/* 0x334: b.cc 398 <generic_fentry_filter_arg+0x398> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x334, 0x398, arm64_l_398);
arm64_l_338:
	/* 0x338: sub w10, w9, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_33c:
	/* 0x33c: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_340:
	/* 0x340: b.cc 54c <generic_fentry_filter_arg+0x54c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x340, 0x54c, arm64_l_54c);
arm64_l_344:
	/* 0x344: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_348:
	/* 0x348: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x348, 0x298, arm64_l_298);
arm64_l_34c:
	/* 0x34c: add x25, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_350:
	/* 0x350: b 54c <generic_fentry_filter_arg+0x54c> */
	ARM64_SIM_A64_JMP(0x350, 0x54c, arm64_l_54c);
arm64_l_354:
	/* 0x354: cmp w9, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_358:
	/* 0x358: b.gt 4c4 <generic_fentry_filter_arg+0x4c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x358, 0x4c4, arm64_l_4c4);
arm64_l_35c:
	/* 0x35c: sub w10, w9, #0x26 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 38ULL);
arm64_l_360:
	/* 0x360: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_364:
	/* 0x364: b.cc 46c <generic_fentry_filter_arg+0x46c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x364, 0x46c, arm64_l_46c);
arm64_l_368:
	/* 0x368: sub w10, w9, #0x28 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_36c:
	/* 0x36c: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_370:
	/* 0x370: b.cc 444 <generic_fentry_filter_arg+0x444> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x370, 0x444, arm64_l_444);
arm64_l_374:
	/* 0x374: b 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JMP(0x374, 0x298, arm64_l_298);
arm64_l_378:
	/* 0x378: cmp w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_37c:
	/* 0x37c: b.gt 42c <generic_fentry_filter_arg+0x42c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x37c, 0x42c, arm64_l_42c);
arm64_l_380:
	/* 0x380: cmp w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_384:
	/* 0x384: b.eq 398 <generic_fentry_filter_arg+0x398> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x384, 0x398, arm64_l_398);
arm64_l_388:
	/* 0x388: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_38c:
	/* 0x38c: b.eq 97c <generic_fentry_filter_arg+0x97c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x38c, 0x97c, arm64_l_97c);
arm64_l_390:
	/* 0x390: cmp w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_394:
	/* 0x394: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x394, 0x298, arm64_l_298);
arm64_l_398:
	/* 0x398: cmp w9, #0xb */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 11ULL);
arm64_l_39c:
	/* 0x39c: b.le 40c <generic_fentry_filter_arg+0x40c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x39c, 0x40c, arm64_l_40c);
arm64_l_3a0:
	/* 0x3a0: cmp w9, #0x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 36ULL);
arm64_l_3a4:
	/* 0x3a4: b.hi 608 <generic_fentry_filter_arg+0x608> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x3a4, 0x608, arm64_l_608);
arm64_l_3a8:
	/* 0x3a8: lsl x10, x12, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_3ac:
	/* 0x3ac: tst x10, #0x1e00000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 128849018880ULL);
arm64_l_3b0:
	/* 0x3b0: b.ne 49c <generic_fentry_filter_arg+0x49c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3b0, 0x49c, arm64_l_49c);
arm64_l_3b4:
	/* 0x3b4: lsl x10, x12, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_3b8:
	/* 0x3b8: tst x10, #0x60000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1610612736ULL);
arm64_l_3bc:
	/* 0x3bc: b.ne 7c4 <generic_fentry_filter_arg+0x7c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3bc, 0x7c4, arm64_l_7c4);
arm64_l_3c0:
	/* 0x3c0: lsl x10, x12, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_3c4:
	/* 0x3c4: tst x10, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_3c8:
	/* 0x3c8: b.eq 608 <generic_fentry_filter_arg+0x608> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3c8, 0x608, arm64_l_608);
arm64_l_3cc:
	/* 0x3cc: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_3d0:
	/* 0x3d0: b.hi fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x3d0, 0xfc, arm64_l_fc);
arm64_l_3d4:
	/* 0x3d4: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_3d8:
	/* 0x3d8: mov w10, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_3dc:
	/* 0x3dc: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3e0:
	/* 0x3e0: b.eq dfc <generic_fentry_filter_arg+0xdfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3e0, 0xdfc, arm64_l_dfc);
arm64_l_3e4:
	/* 0x3e4: ldr w9, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_3e8:
	/* 0x3e8: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3ec:
	/* 0x3ec: b.le 13a8 <generic_fentry_filter_arg+0x13a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x3ec, 0x13a8, arm64_l_13a8);
arm64_l_3f0:
	/* 0x3f0: sub w10, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_3f4:
	/* 0x3f4: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3f8:
	/* 0x3f8: b.cs 195c <generic_fentry_filter_arg+0x195c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x3f8, 0x195c, arm64_l_195c);
arm64_l_3fc:
	/* 0x3fc: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_400:
	/* 0x400: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_404:
	/* 0x404: b.eq 28c <generic_fentry_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x404, 0x28c, arm64_l_28c);
arm64_l_408:
	/* 0x408: b 1ae4 <generic_fentry_filter_arg+0x1ae4> */
	ARM64_SIM_A64_JMP(0x408, 0x1ae4, arm64_l_1ae4);
arm64_l_40c:
	/* 0x40c: sub w10, w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_410:
	/* 0x410: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_414:
	/* 0x414: b.cc 9f0 <generic_fentry_filter_arg+0x9f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x414, 0x9f0, arm64_l_9f0);
arm64_l_418:
	/* 0x418: cmp w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_41c:
	/* 0x41c: b.eq 614 <generic_fentry_filter_arg+0x614> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x41c, 0x614, arm64_l_614);
arm64_l_420:
	/* 0x420: cmp w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_424:
	/* 0x424: b.eq 614 <generic_fentry_filter_arg+0x614> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x424, 0x614, arm64_l_614);
arm64_l_428:
	/* 0x428: b 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JMP(0x428, 0x298, arm64_l_298);
arm64_l_42c:
	/* 0x42c: cmp w9, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_430:
	/* 0x430: b.eq 444 <generic_fentry_filter_arg+0x444> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x430, 0x444, arm64_l_444);
arm64_l_434:
	/* 0x434: cmp w9, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_438:
	/* 0x438: b.eq 46c <generic_fentry_filter_arg+0x46c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x438, 0x46c, arm64_l_46c);
arm64_l_43c:
	/* 0x43c: cmp w9, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_440:
	/* 0x440: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x440, 0x298, arm64_l_298);
arm64_l_444:
	/* 0x444: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_448:
	/* 0x448: cmp w9, #0x27 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 39ULL);
arm64_l_44c:
	/* 0x44c: stp xzr, xzr, [sp, #120] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_450:
	/* 0x450: str xzr, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_454:
	/* 0x454: stp xzr, xzr, [sp, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_458:
	/* 0x458: b.gt 654 <generic_fentry_filter_arg+0x654> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x458, 0x654, arm64_l_654);
arm64_l_45c:
	/* 0x45c: cmp w9, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_460:
	/* 0x460: b.eq b10 <generic_fentry_filter_arg+0xb10> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x460, 0xb10, arm64_l_b10);
arm64_l_464:
	/* 0x464: cmp w9, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_468:
	/* 0x468: b 660 <generic_fentry_filter_arg+0x660> */
	ARM64_SIM_A64_JMP(0x468, 0x660, arm64_l_660);
arm64_l_46c:
	/* 0x46c: ldr w29, [x25], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_470:
	/* 0x470: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_474:
	/* 0x474: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_478:
	/* 0x478: b.gt 6c0 <generic_fentry_filter_arg+0x6c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x478, 0x6c0, arm64_l_6c0);
arm64_l_47c:
	/* 0x47c: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_480:
	/* 0x480: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_484:
	/* 0x484: b.cc d8c <generic_fentry_filter_arg+0xd8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x484, 0xd8c, arm64_l_d8c);
arm64_l_488:
	/* 0x488: cmp w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_48c:
	/* 0x48c: b.eq cf4 <generic_fentry_filter_arg+0xcf4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x48c, 0xcf4, arm64_l_cf4);
arm64_l_490:
	/* 0x490: cmp w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_494:
	/* 0x494: b.eq 6d8 <generic_fentry_filter_arg+0x6d8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x494, 0x6d8, arm64_l_6d8);
arm64_l_498:
	/* 0x498: b 12c8 <generic_fentry_filter_arg+0x12c8> */
	ARM64_SIM_A64_JMP(0x498, 0x12c8, arm64_l_12c8);
arm64_l_49c:
	/* 0x49c: cmp w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_4a0:
	/* 0x4a0: b.le 96c <generic_fentry_filter_arg+0x96c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x4a0, 0x96c, arm64_l_96c);
arm64_l_4a4:
	/* 0x4a4: cmp w8, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_4a8:
	/* 0x4a8: b.gt cb4 <generic_fentry_filter_arg+0xcb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x4a8, 0xcb4, arm64_l_cb4);
arm64_l_4ac:
	/* 0x4ac: sub w10, w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_4b0:
	/* 0x4b0: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_4b4:
	/* 0x4b4: b.cc a7c <generic_fentry_filter_arg+0xa7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x4b4, 0xa7c, arm64_l_a7c);
arm64_l_4b8:
	/* 0x4b8: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_4bc:
	/* 0x4bc: b.eq a08 <generic_fentry_filter_arg+0xa08> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x4bc, 0xa08, arm64_l_a08);
arm64_l_4c0:
	/* 0x4c0: b fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x4c0, 0xfc, arm64_l_fc);
arm64_l_4c4:
	/* 0x4c4: cmp w9, #0x2a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 42ULL);
arm64_l_4c8:
	/* 0x4c8: b.eq 54c <generic_fentry_filter_arg+0x54c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x4c8, 0x54c, arm64_l_54c);
arm64_l_4cc:
	/* 0x4cc: cmp w9, #0x2c */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_4d0:
	/* 0x4d0: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x4d0, 0x298, arm64_l_298);
arm64_l_4d4:
	/* 0x4d4: ldrb w29, [x25, #3] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3ULL);
arm64_l_4d8:
	/* 0x4d8: add x10, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_4dc:
	/* 0x4dc: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_4e0:
	/* 0x4e0: b.gt 1088 <generic_fentry_filter_arg+0x1088> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x4e0, 0x1088, arm64_l_1088);
arm64_l_4e4:
	/* 0x4e4: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_4e8:
	/* 0x4e8: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_4ec:
	/* 0x4ec: b.cs 15fc <generic_fentry_filter_arg+0x15fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x4ec, 0x15fc, arm64_l_15fc);
arm64_l_4f0:
	/* 0x4f0: cmp w29, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_4f4:
	/* 0x4f4: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_4f8:
	/* 0x4f8: b.hi 1698 <generic_fentry_filter_arg+0x1698> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x4f8, 0x1698, arm64_l_1698);
arm64_l_4fc:
	/* 0x4fc: mov w8, #0xaaab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 43691ULL);
arm64_l_500:
	/* 0x500: mov w9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_504:
	/* 0x504: movk w8, #0xaaa, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 2730ULL);
arm64_l_508:
	/* 0x508: umull x8, w29, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_UMULL, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_50c:
	/* 0x50c: lsr x8, x8, #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 32ULL);
arm64_l_510:
	/* 0x510: msub w8, w8, w9, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MSUB, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_X29, ARM64_WIDTH_32, 0, 0);
arm64_l_514:
	/* 0x514: cbz w29, 520 <generic_fentry_filter_arg+0x520> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x514, 0x520, arm64_l_520);
arm64_l_518:
	/* 0x518: mov w13, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_51c:
	/* 0x51c: cbz w8, 534 <generic_fentry_filter_arg+0x534> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x51c, 0x534, arm64_l_534);
arm64_l_520:
	/* 0x520: sub w8, w29, w8, uxtb */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_UXTB, 0), 0);
arm64_l_524:
	/* 0x524: add w9, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_528:
	/* 0x528: cmp w8, #0x78 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 120ULL);
arm64_l_52c:
	/* 0x52c: and w13, w9, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_530:
	/* 0x530: b.hi 169c <generic_fentry_filter_arg+0x169c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x530, 0x169c, arm64_l_169c);
arm64_l_534:
	/* 0x534: and w8, w13, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_538:
	/* 0x538: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_53c:
	/* 0x53c: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_540:
	/* 0x540: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_544:
	/* 0x544: sub w11, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_548:
	/* 0x548: b 2094 <generic_fentry_filter_arg+0x2094> */
	ARM64_SIM_A64_JMP(0x548, 0x2094, arm64_l_2094);
arm64_l_54c:
	/* 0x54c: ldr w29, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_550:
	/* 0x550: and w9, w8, #0xfffffffe */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967294ULL);
arm64_l_554:
	/* 0x554: cmp w9, #0x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 36ULL);
arm64_l_558:
	/* 0x558: b.eq 560 <generic_fentry_filter_arg+0x560> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x558, 0x560, arm64_l_560);
arm64_l_55c:
	/* 0x55c: cbz w29, fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x55c, 0xfc, arm64_l_fc);
arm64_l_560:
	/* 0x560: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_564:
	/* 0x564: b.hi 7a4 <generic_fentry_filter_arg+0x7a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x564, 0x7a4, arm64_l_7a4);
arm64_l_568:
	/* 0x568: mov w10, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_56c:
	/* 0x56c: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_570:
	/* 0x570: movk w10, #0x400, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 1024ULL);
arm64_l_574:
	/* 0x574: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_578:
	/* 0x578: b.ne 8d4 <generic_fentry_filter_arg+0x8d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x578, 0x8d4, arm64_l_8d4);
arm64_l_57c:
	/* 0x57c: mov w10, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 512ULL);
arm64_l_580:
	/* 0x580: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_584:
	/* 0x584: movk w10, #0x800, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 2048ULL);
arm64_l_588:
	/* 0x588: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_58c:
	/* 0x58c: b.ne 804 <generic_fentry_filter_arg+0x804> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x58c, 0x804, arm64_l_804);
arm64_l_590:
	/* 0x590: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_594:
	/* 0x594: tst x9, #0x3000000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 206158430208ULL);
arm64_l_598:
	/* 0x598: b.eq 7a4 <generic_fentry_filter_arg+0x7a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x598, 0x7a4, arm64_l_7a4);
arm64_l_59c:
	/* 0x59c: cmp w29, #0x1, lsl #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_5a0:
	/* 0x5a0: strh wzr, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_5a4:
	/* 0x5a4: b.hi 7bc <generic_fentry_filter_arg+0x7bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x5a4, 0x7bc, arm64_l_7bc);
arm64_l_5a8:
	/* 0x5a8: add x8, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_5ac:
	/* 0x5ac: mov w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_5b0:
	/* 0x5b0: add x11, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_5b4:
	/* 0x5b4: mov w12, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_5b8:
	/* 0x5b8: add x0, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_5bc:
	/* 0x5bc: mov w1, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_5c0:
	/* 0x5c0: add x9, x8, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_5c4:
	/* 0x5c4: add x9, x9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_5c8:
	/* 0x5c8: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_5cc:
	/* 0x5cc: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_5d0:
	/* 0x5d0: add x2, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_5d4:
	/* 0x5d4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x5d8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_5d8:
	/* 0x5d8: ldr w9, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_5dc:
	/* 0x5dc: cbz w9, 2dec <generic_fentry_filter_arg+0x2dec> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x5dc, 0x2dec, arm64_l_2dec);
arm64_l_5e0:
	/* 0x5e0: ldrh w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_5e4:
	/* 0x5e4: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_5e8:
	/* 0x5e8: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_5ec:
	/* 0x5ec: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_5f0:
	/* 0x5f0: and w8, w8, #0xf000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 61440ULL);
arm64_l_5f4:
	/* 0x5f4: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_5f8:
	/* 0x5f8: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_5fc:
	/* 0x5fc: b.ne 198c <generic_fentry_filter_arg+0x198c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x5fc, 0x198c, arm64_l_198c);
arm64_l_600:
	/* 0x600: mov w22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_604:
	/* 0x604: b 2e00 <generic_fentry_filter_arg+0x2e00> */
	ARM64_SIM_A64_JMP(0x604, 0x2e00, arm64_l_2e00);
arm64_l_608:
	/* 0x608: sub w10, w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_60c:
	/* 0x60c: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_610:
	/* 0x610: b.cs 9e8 <generic_fentry_filter_arg+0x9e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x610, 0x9e8, arm64_l_9e8);
arm64_l_614:
	/* 0x614: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_618:
	/* 0x618: b.hi fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x618, 0xfc, arm64_l_fc);
arm64_l_61c:
	/* 0x61c: lsl x10, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_620:
	/* 0x620: mov w11, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_624:
	/* 0x624: tst x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_628:
	/* 0x628: b.eq 66c <generic_fentry_filter_arg+0x66c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x628, 0x66c, arm64_l_66c);
arm64_l_62c:
	/* 0x62c: ldr w10, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_630:
	/* 0x630: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_634:
	/* 0x634: b.le 9b0 <generic_fentry_filter_arg+0x9b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x634, 0x9b0, arm64_l_9b0);
arm64_l_638:
	/* 0x638: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_63c:
	/* 0x63c: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_640:
	/* 0x640: b.cs de4 <generic_fentry_filter_arg+0xde4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x640, 0xde4, arm64_l_de4);
arm64_l_644:
	/* 0x644: ldr w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_648:
	/* 0x648: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_64c:
	/* 0x64c: b.eq 28c <generic_fentry_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x64c, 0x28c, arm64_l_28c);
arm64_l_650:
	/* 0x650: b 1ebc <generic_fentry_filter_arg+0x1ebc> */
	ARM64_SIM_A64_JMP(0x650, 0x1ebc, arm64_l_1ebc);
arm64_l_654:
	/* 0x654: cmp w9, #0x28 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_658:
	/* 0x658: b.eq b18 <generic_fentry_filter_arg+0xb18> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x658, 0xb18, arm64_l_b18);
arm64_l_65c:
	/* 0x65c: cmp w9, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_660:
	/* 0x660: mov x10, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_664:
	/* 0x664: b.eq b40 <generic_fentry_filter_arg+0xb40> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x664, 0xb40, arm64_l_b40);
arm64_l_668:
	/* 0x668: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x668, 0x294, arm64_l_294);
arm64_l_66c:
	/* 0x66c: lsl x10, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_670:
	/* 0x670: tst x10, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_674:
	/* 0x674: b.ne ad8 <generic_fentry_filter_arg+0xad8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x674, 0xad8, arm64_l_ad8);
arm64_l_678:
	/* 0x678: lsl x10, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_67c:
	/* 0x67c: tst x10, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_680:
	/* 0x680: b.eq fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x680, 0xfc, arm64_l_fc);
arm64_l_684:
	/* 0x684: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_688:
	/* 0x688: b.ne 1058 <generic_fentry_filter_arg+0x1058> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x688, 0x1058, arm64_l_1058);
arm64_l_68c:
	/* 0x68c: ldp w11, w10, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_690:
	/* 0x690: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_694:
	/* 0x694: b.hi 1b58 <generic_fentry_filter_arg+0x1b58> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x694, 0x1b58, arm64_l_1b58);
arm64_l_698:
	/* 0x698: lsl w8, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_69c:
	/* 0x69c: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_6a0:
	/* 0x6a0: tst w8, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_6a4:
	/* 0x6a4: b.eq 1b58 <generic_fentry_filter_arg+0x1b58> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x6a4, 0x1b58, arm64_l_1b58);
arm64_l_6a8:
	/* 0x6a8: ldr w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6ac:
	/* 0x6ac: cmp w11, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_6b0:
	/* 0x6b0: b.gt 1b6c <generic_fentry_filter_arg+0x1b6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x6b0, 0x1b6c, arm64_l_1b6c);
arm64_l_6b4:
	/* 0x6b4: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_6b8:
	/* 0x6b8: b.le 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x6b8, 0x298, arm64_l_298);
arm64_l_6bc:
	/* 0x6bc: b 1b6c <generic_fentry_filter_arg+0x1b6c> */
	ARM64_SIM_A64_JMP(0x6bc, 0x1b6c, arm64_l_1b6c);
arm64_l_6c0:
	/* 0x6c0: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_6c4:
	/* 0x6c4: b.gt bb4 <generic_fentry_filter_arg+0xbb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x6c4, 0xbb4, arm64_l_bb4);
arm64_l_6c8:
	/* 0x6c8: cmp w8, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_6cc:
	/* 0x6cc: b.eq cf4 <generic_fentry_filter_arg+0xcf4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x6cc, 0xcf4, arm64_l_cf4);
arm64_l_6d0:
	/* 0x6d0: cmp w8, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_6d4:
	/* 0x6d4: b.ne 12c8 <generic_fentry_filter_arg+0x12c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x6d4, 0x12c8, arm64_l_12c8);
arm64_l_6d8:
	/* 0x6d8: ldr w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_6dc:
	/* 0x6dc: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_6e0:
	/* 0x6e0: adrp x0, 0 <string_postfix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_20));
arm64_l_6e4:
	/* 0x6e4: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_6e8:
	/* 0x6e8: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_6ec:
	/* 0x6ec: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_6f0:
	/* 0x6f0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_6f4:
	/* 0x6f4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6f8:
	/* 0x6f8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x6fcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_6fc:
	/* 0x6fc: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_700:
	/* 0x700: cbz w29, 12b8 <generic_fentry_filter_arg+0x12b8> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x700, 0x12b8, arm64_l_12b8);
arm64_l_704:
	/* 0x704: cbz x0, 12b8 <generic_fentry_filter_arg+0x12b8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x704, 0x12b8, arm64_l_12b8);
arm64_l_708:
	/* 0x708: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_70c:
	/* 0x70c: adrp x0, 0 <string_postfix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap_21));
arm64_l_710:
	/* 0x710: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_714:
	/* 0x714: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_718:
	/* 0x718: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_71c:
	/* 0x71c: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_720:
	/* 0x720: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x724ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_724:
	/* 0x724: cbz x0, 12b0 <generic_fentry_filter_arg+0x12b0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x724, 0x12b0, arm64_l_12b0);
arm64_l_728:
	/* 0x728: cmp w29, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_72c:
	/* 0x72c: mov w9, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_730:
	/* 0x730: mov w11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_734:
	/* 0x734: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_738:
	/* 0x738: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_73c:
	/* 0x73c: sub w12, w29, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_740:
	/* 0x740: sub w13, w29, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_744:
	/* 0x744: csel w9, w29, w9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X9, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_748:
	/* 0x748: sub x11, x11, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_74c:
	/* 0x74c: lsl w10, w9, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_750:
	/* 0x750: mov x9, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_754:
	/* 0x754: str w10, [x9], #5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 5ULL);
arm64_l_758:
	/* 0x758: neg x10, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_75c:
	/* 0x75c: add w14, w13, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X13, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_760:
	/* 0x760: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_764:
	/* 0x764: and x14, x14, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_768:
	/* 0x768: ldrb w14, [x25, x14] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X14, ARM64_X25, ARM64_X14, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X14, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_76c:
	/* 0x76c: sturb w14, [x9, #-1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 18446744073709551615ULL);
arm64_l_770:
	/* 0x770: b.eq 798 <generic_fentry_filter_arg+0x798> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x770, 0x798, arm64_l_798);
arm64_l_774:
	/* 0x774: cmn x8, #0x7e */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 126ULL);
arm64_l_778:
	/* 0x778: b.eq 798 <generic_fentry_filter_arg+0x798> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x778, 0x798, arm64_l_798);
arm64_l_77c:
	/* 0x77c: add w14, w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_780:
	/* 0x780: sub x8, x8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_784:
	/* 0x784: and x14, x14, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_788:
	/* 0x788: cmp x10, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_78c:
	/* 0x78c: ldrb w14, [x25, x14] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X14, ARM64_X25, ARM64_X14, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X14, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_790:
	/* 0x790: strb w14, [x9], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_794:
	/* 0x794: b.ne 75c <generic_fentry_filter_arg+0x75c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x794, 0x75c, arm64_l_75c);
arm64_l_798:
	/* 0x798: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_79c:
	/* 0x79c: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7a0:
	/* 0x7a0: b d7c <generic_fentry_filter_arg+0xd7c> */
	ARM64_SIM_A64_JMP(0x7a0, 0xd7c, arm64_l_d7c);
arm64_l_7a4:
	/* 0x7a4: sub w8, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_7a8:
	/* 0x7a8: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_7ac:
	/* 0x7ac: b.cs 7bc <generic_fentry_filter_arg+0x7bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x7ac, 0x7bc, arm64_l_7bc);
arm64_l_7b0:
	/* 0x7b0: cmp w29, #0x1, lsl #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_7b4:
	/* 0x7b4: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_7b8:
	/* 0x7b8: b.ls eec <generic_fentry_filter_arg+0xeec> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x7b8, 0xeec, arm64_l_eec);
arm64_l_7bc:
	/* 0x7bc: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7c0:
	/* 0x7c0: b 2e00 <generic_fentry_filter_arg+0x2e00> */
	ARM64_SIM_A64_JMP(0x7c0, 0x2e00, arm64_l_2e00);
arm64_l_7c4:
	/* 0x7c4: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_7c8:
	/* 0x7c8: b.hi fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x7c8, 0xfc, arm64_l_fc);
arm64_l_7cc:
	/* 0x7cc: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_7d0:
	/* 0x7d0: mov w10, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_7d4:
	/* 0x7d4: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_7d8:
	/* 0x7d8: b.eq e28 <generic_fentry_filter_arg+0xe28> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x7d8, 0xe28, arm64_l_e28);
arm64_l_7dc:
	/* 0x7dc: ldr w9, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_7e0:
	/* 0x7e0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_7e4:
	/* 0x7e4: b.le 13c8 <generic_fentry_filter_arg+0x13c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x7e4, 0x13c8, arm64_l_13c8);
arm64_l_7e8:
	/* 0x7e8: sub w10, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_7ec:
	/* 0x7ec: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_7f0:
	/* 0x7f0: b.cs 1974 <generic_fentry_filter_arg+0x1974> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x7f0, 0x1974, arm64_l_1974);
arm64_l_7f4:
	/* 0x7f4: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_7f8:
	/* 0x7f8: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_7fc:
	/* 0x7fc: b.eq 28c <generic_fentry_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x7fc, 0x28c, arm64_l_28c);
arm64_l_800:
	/* 0x800: b 1b24 <generic_fentry_filter_arg+0x1b24> */
	ARM64_SIM_A64_JMP(0x800, 0x1b24, arm64_l_1b24);
arm64_l_804:
	/* 0x804: ldr w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_808:
	/* 0x808: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_80c:
	/* 0x80c: adrp x0, 0 <string_postfix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_20));
arm64_l_810:
	/* 0x810: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_814:
	/* 0x814: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_818:
	/* 0x818: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_81c:
	/* 0x81c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_820:
	/* 0x820: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_824:
	/* 0x824: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x828ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_828:
	/* 0x828: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_82c:
	/* 0x82c: cbz w29, 2df0 <generic_fentry_filter_arg+0x2df0> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x82c, 0x2df0, arm64_l_2df0);
arm64_l_830:
	/* 0x830: cbz x0, 2df0 <generic_fentry_filter_arg+0x2df0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x830, 0x2df0, arm64_l_2df0);
arm64_l_834:
	/* 0x834: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_838:
	/* 0x838: adrp x0, 0 <string_postfix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap_21));
arm64_l_83c:
	/* 0x83c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_840:
	/* 0x840: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_844:
	/* 0x844: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_848:
	/* 0x848: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_84c:
	/* 0x84c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x850ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_850:
	/* 0x850: cbz x0, 19dc <generic_fentry_filter_arg+0x19dc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x850, 0x19dc, arm64_l_19dc);
arm64_l_854:
	/* 0x854: cmp w29, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_858:
	/* 0x858: mov w10, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_85c:
	/* 0x85c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_860:
	/* 0x860: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_864:
	/* 0x864: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_868:
	/* 0x868: add x9, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_86c:
	/* 0x86c: sub w13, w29, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_870:
	/* 0x870: sub w14, w29, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_874:
	/* 0x874: csel w10, w29, w10, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X10, ARM64_X29, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_878:
	/* 0x878: sub x12, x12, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X12, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_87c:
	/* 0x87c: lsl w11, w10, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_880:
	/* 0x880: mov x10, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_884:
	/* 0x884: str w11, [x10], #5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 5ULL);
arm64_l_888:
	/* 0x888: neg x11, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_88c:
	/* 0x88c: add w15, w14, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X15, ARM64_X14, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_890:
	/* 0x890: cmp x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_894:
	/* 0x894: and x15, x15, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_898:
	/* 0x898: ldrb w15, [x9, x15] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X15, ARM64_X9, ARM64_X15, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X15, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_89c:
	/* 0x89c: sturb w15, [x10, #-1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X10, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 18446744073709551615ULL);
arm64_l_8a0:
	/* 0x8a0: b.eq 8c8 <generic_fentry_filter_arg+0x8c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x8a0, 0x8c8, arm64_l_8c8);
arm64_l_8a4:
	/* 0x8a4: cmn x8, #0x7e */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 126ULL);
arm64_l_8a8:
	/* 0x8a8: b.eq 8c8 <generic_fentry_filter_arg+0x8c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x8a8, 0x8c8, arm64_l_8c8);
arm64_l_8ac:
	/* 0x8ac: add w15, w13, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X15, ARM64_X13, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_8b0:
	/* 0x8b0: sub x8, x8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_8b4:
	/* 0x8b4: and x15, x15, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_8b8:
	/* 0x8b8: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8bc:
	/* 0x8bc: ldrb w15, [x9, x15] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X15, ARM64_X9, ARM64_X15, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X15, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_8c0:
	/* 0x8c0: strb w15, [x10], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X10, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_8c4:
	/* 0x8c4: b.ne 88c <generic_fentry_filter_arg+0x88c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x8c4, 0x88c, arm64_l_88c);
arm64_l_8c8:
	/* 0x8c8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_8cc:
	/* 0x8cc: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_8d0:
	/* 0x8d0: b 95c <generic_fentry_filter_arg+0x95c> */
	ARM64_SIM_A64_JMP(0x8d0, 0x95c, arm64_l_95c);
arm64_l_8d4:
	/* 0x8d4: ldr w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_8d8:
	/* 0x8d8: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_8dc:
	/* 0x8dc: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_22));
arm64_l_8e0:
	/* 0x8e0: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_8e4:
	/* 0x8e4: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_8e8:
	/* 0x8e8: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_8ec:
	/* 0x8ec: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_8f0:
	/* 0x8f0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_8f4:
	/* 0x8f4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x8f8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_8f8:
	/* 0x8f8: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_8fc:
	/* 0x8fc: cbz w29, 2df0 <generic_fentry_filter_arg+0x2df0> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x8fc, 0x2df0, arm64_l_2df0);
arm64_l_900:
	/* 0x900: cbz x0, 2df0 <generic_fentry_filter_arg+0x2df0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x900, 0x2df0, arm64_l_2df0);
arm64_l_904:
	/* 0x904: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_908:
	/* 0x908: adrp x0, 0 <string_prefix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap_23));
arm64_l_90c:
	/* 0x90c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_910:
	/* 0x910: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_914:
	/* 0x914: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_918:
	/* 0x918: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_91c:
	/* 0x91c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x920ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_920:
	/* 0x920: cbz x0, 19dc <generic_fentry_filter_arg+0x19dc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x920, 0x19dc, arm64_l_19dc);
arm64_l_924:
	/* 0x924: cmp w29, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_928:
	/* 0x928: mov w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 255ULL);
arm64_l_92c:
	/* 0x92c: add x2, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_930:
	/* 0x930: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_934:
	/* 0x934: csel w1, w29, w8, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X1, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_938:
	/* 0x938: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_93c:
	/* 0x93c: lsl w9, w1, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_940:
	/* 0x940: str w9, [x8], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_944:
	/* 0x944: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_948:
	/* 0x948: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_94c:
	/* 0x94c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x950ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_950:
	/* 0x950: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_954:
	/* 0x954: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_958:
	/* 0x958: mov x1, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_95c:
	/* 0x95c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x960ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_960:
	/* 0x960: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_964:
	/* 0x964: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_968:
	/* 0x968: b 19e0 <generic_fentry_filter_arg+0x19e0> */
	ARM64_SIM_A64_JMP(0x968, 0x19e0, arm64_l_19e0);
arm64_l_96c:
	/* 0x96c: sub w10, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_970:
	/* 0x970: cmp w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_974:
	/* 0x974: b.cc a08 <generic_fentry_filter_arg+0xa08> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x974, 0xa08, arm64_l_a08);
arm64_l_978:
	/* 0x978: b fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x978, 0xfc, arm64_l_fc);
arm64_l_97c:
	/* 0x97c: add x29, x25, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_980:
	/* 0x980: ldr w25, [x25, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_984:
	/* 0x984: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_988:
	/* 0x988: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_98c:
	/* 0x98c: b.gt f5c <generic_fentry_filter_arg+0xf5c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x98c, 0xf5c, arm64_l_f5c);
arm64_l_990:
	/* 0x990: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_994:
	/* 0x994: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_998:
	/* 0x998: b.cc 1788 <generic_fentry_filter_arg+0x1788> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x998, 0x1788, arm64_l_1788);
arm64_l_99c:
	/* 0x99c: cmp w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_9a0:
	/* 0x9a0: b.eq 16fc <generic_fentry_filter_arg+0x16fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x9a0, 0x16fc, arm64_l_16fc);
arm64_l_9a4:
	/* 0x9a4: cmp w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_9a8:
	/* 0x9a8: b.eq f74 <generic_fentry_filter_arg+0xf74> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x9a8, 0xf74, arm64_l_f74);
arm64_l_9ac:
	/* 0x9ac: b 3390 <generic_fentry_filter_arg+0x3390> */
	ARM64_SIM_A64_JMP(0x9ac, 0x3390, arm64_l_3390);
arm64_l_9b0:
	/* 0x9b0: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_9b4:
	/* 0x9b4: b.eq 11c4 <generic_fentry_filter_arg+0x11c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x9b4, 0x11c4, arm64_l_11c4);
arm64_l_9b8:
	/* 0x9b8: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_9bc:
	/* 0x9bc: b.ne 1ebc <generic_fentry_filter_arg+0x1ebc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x9bc, 0x1ebc, arm64_l_1ebc);
arm64_l_9c0:
	/* 0x9c0: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_9c4:
	/* 0x9c4: b.hi 1eb0 <generic_fentry_filter_arg+0x1eb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x9c4, 0x1eb0, arm64_l_1eb0);
arm64_l_9c8:
	/* 0x9c8: lsl w11, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X11, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_9cc:
	/* 0x9cc: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_9d0:
	/* 0x9d0: tst w11, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X11, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_9d4:
	/* 0x9d4: b.eq 1eb0 <generic_fentry_filter_arg+0x1eb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x9d4, 0x1eb0, arm64_l_1eb0);
arm64_l_9d8:
	/* 0x9d8: ldr w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_9dc:
	/* 0x9dc: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_9e0:
	/* 0x9e0: b.lt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x9e0, 0x298, arm64_l_298);
arm64_l_9e4:
	/* 0x9e4: b 1ebc <generic_fentry_filter_arg+0x1ebc> */
	ARM64_SIM_A64_JMP(0x9e4, 0x1ebc, arm64_l_1ebc);
arm64_l_9e8:
	/* 0x9e8: cmp w9, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_9ec:
	/* 0x9ec: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x9ec, 0x298, arm64_l_298);
arm64_l_9f0:
	/* 0x9f0: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_9f4:
	/* 0x9f4: b.hi fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x9f4, 0xfc, arm64_l_fc);
arm64_l_9f8:
	/* 0x9f8: lsl x10, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_9fc:
	/* 0x9fc: mov w11, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_a00:
	/* 0xa00: tst x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_a04:
	/* 0xa04: b.eq a30 <generic_fentry_filter_arg+0xa30> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xa04, 0xa30, arm64_l_a30);
arm64_l_a08:
	/* 0xa08: ldr x10, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_a0c:
	/* 0xa0c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_a10:
	/* 0xa10: b.le a4c <generic_fentry_filter_arg+0xa4c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xa10, 0xa4c, arm64_l_a4c);
arm64_l_a14:
	/* 0xa14: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_a18:
	/* 0xa18: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_a1c:
	/* 0xa1c: b.cs c9c <generic_fentry_filter_arg+0xc9c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xa1c, 0xc9c, arm64_l_c9c);
arm64_l_a20:
	/* 0xa20: ldr x11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a24:
	/* 0xa24: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_a28:
	/* 0xa28: b.eq 28c <generic_fentry_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xa28, 0x28c, arm64_l_28c);
arm64_l_a2c:
	/* 0xa2c: b 18d0 <generic_fentry_filter_arg+0x18d0> */
	ARM64_SIM_A64_JMP(0xa2c, 0x18d0, arm64_l_18d0);
arm64_l_a30:
	/* 0xa30: lsl x10, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_a34:
	/* 0xa34: tst x10, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_a38:
	/* 0xa38: b.ne a7c <generic_fentry_filter_arg+0xa7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xa38, 0xa7c, arm64_l_a7c);
arm64_l_a3c:
	/* 0xa3c: lsl x10, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_a40:
	/* 0xa40: tst x10, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_a44:
	/* 0xa44: b.ne cc0 <generic_fentry_filter_arg+0xcc0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xa44, 0xcc0, arm64_l_cc0);
arm64_l_a48:
	/* 0xa48: b fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0xa48, 0xfc, arm64_l_fc);
arm64_l_a4c:
	/* 0xa4c: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_a50:
	/* 0xa50: b.eq ecc <generic_fentry_filter_arg+0xecc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xa50, 0xecc, arm64_l_ecc);
arm64_l_a54:
	/* 0xa54: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_a58:
	/* 0xa58: b.ne 18d0 <generic_fentry_filter_arg+0x18d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xa58, 0x18d0, arm64_l_18d0);
arm64_l_a5c:
	/* 0xa5c: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_a60:
	/* 0xa60: b.eq a6c <generic_fentry_filter_arg+0xa6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xa60, 0xa6c, arm64_l_a6c);
arm64_l_a64:
	/* 0xa64: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_a68:
	/* 0xa68: b.ne 18c4 <generic_fentry_filter_arg+0x18c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xa68, 0x18c4, arm64_l_18c4);
arm64_l_a6c:
	/* 0xa6c: ldr x11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a70:
	/* 0xa70: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_a74:
	/* 0xa74: b.lt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0xa74, 0x298, arm64_l_298);
arm64_l_a78:
	/* 0xa78: b 18d0 <generic_fentry_filter_arg+0x18d0> */
	ARM64_SIM_A64_JMP(0xa78, 0x18d0, arm64_l_18d0);
arm64_l_a7c:
	/* 0xa7c: ldrb w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_a80:
	/* 0xa80: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_a84:
	/* 0xa84: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_a88:
	/* 0xa88: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_a8c:
	/* 0xa8c: str w8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_a90:
	/* 0xa90: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a94:
	/* 0xa94: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a98:
	/* 0xa98: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xa9cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_a9c:
	/* 0xa9c: cbz x0, 1040 <generic_fentry_filter_arg+0x1040> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xa9c, 0x1040, arm64_l_1040);
arm64_l_aa0:
	/* 0xaa0: ldr x8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_aa4:
	/* 0xaa4: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_aa8:
	/* 0xaa8: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_aac:
	/* 0xaac: str x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_ab0:
	/* 0xab0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ab4:
	/* 0xab4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xab8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_ab8:
	/* 0xab8: ldr w8, [x23, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_abc:
	/* 0xabc: cmp w8, #0xb */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 11ULL);
arm64_l_ac0:
	/* 0xac0: b.eq 147c <generic_fentry_filter_arg+0x147c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xac0, 0x147c, arm64_l_147c);
arm64_l_ac4:
	/* 0xac4: cmp w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_ac8:
	/* 0xac8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_acc:
	/* 0xacc: b.eq 151c <generic_fentry_filter_arg+0x151c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xacc, 0x151c, arm64_l_151c);
arm64_l_ad0:
	/* 0xad0: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_ad4:
	/* 0xad4: b 1524 <generic_fentry_filter_arg+0x1524> */
	ARM64_SIM_A64_JMP(0xad4, 0x1524, arm64_l_1524);
arm64_l_ad8:
	/* 0xad8: ldrb w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_adc:
	/* 0xadc: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_ae0:
	/* 0xae0: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_ae4:
	/* 0xae4: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_ae8:
	/* 0xae8: str w8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_aec:
	/* 0xaec: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_af0:
	/* 0xaf0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_af4:
	/* 0xaf4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xaf8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_af8:
	/* 0xaf8: cbz x0, 1898 <generic_fentry_filter_arg+0x1898> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xaf8, 0x1898, arm64_l_1898);
arm64_l_afc:
	/* 0xafc: ldr w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b00:
	/* 0xb00: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_b04:
	/* 0xb04: str x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_b08:
	/* 0xb08: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_b0c:
	/* 0xb0c: b 1454 <generic_fentry_filter_arg+0x1454> */
	ARM64_SIM_A64_JMP(0xb0c, 0x1454, arm64_l_1454);
arm64_l_b10:
	/* 0xb10: mov x10, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b14:
	/* 0xb14: b b40 <generic_fentry_filter_arg+0xb40> */
	ARM64_SIM_A64_JMP(0xb14, 0xb40, arm64_l_b40);
arm64_l_b18:
	/* 0xb18: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b1c:
	/* 0xb1c: mov x10, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b20:
	/* 0xb20: strh w11, [sp, #134] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 134ULL);
arm64_l_b24:
	/* 0xb24: ldrh w11, [x25, #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_b28:
	/* 0xb28: strh w11, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_b2c:
	/* 0xb2c: ldr x11, [x25, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_b30:
	/* 0xb30: str x11, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_b34:
	/* 0xb34: ldr x11, [x25, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_b38:
	/* 0xb38: add x25, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_b3c:
	/* 0xb3c: str x11, [sp, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_b40:
	/* 0xb40: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b44:
	/* 0xb44: cmp w8, #0x13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 19ULL);
arm64_l_b48:
	/* 0xb48: b.le b70 <generic_fentry_filter_arg+0xb70> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xb48, 0xb70, arm64_l_b70);
arm64_l_b4c:
	/* 0xb4c: cmp w8, #0x17 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 23ULL);
arm64_l_b50:
	/* 0xb50: b.gt b98 <generic_fentry_filter_arg+0xb98> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xb50, 0xb98, arm64_l_b98);
arm64_l_b54:
	/* 0xb54: sub w9, w8, #0x14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_b58:
	/* 0xb58: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_b5c:
	/* 0xb5c: b.cc 10c4 <generic_fentry_filter_arg+0x10c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xb5c, 0x10c4, arm64_l_10c4);
arm64_l_b60:
	/* 0xb60: sub w9, w8, #0x16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 22ULL);
arm64_l_b64:
	/* 0xb64: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_b68:
	/* 0xb68: b.cc 10b0 <generic_fentry_filter_arg+0x10b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xb68, 0x10b0, arm64_l_10b0);
arm64_l_b6c:
	/* 0xb6c: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0xb6c, 0x294, arm64_l_294);
arm64_l_b70:
	/* 0xb70: cmp w8, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_b74:
	/* 0xb74: b.le da0 <generic_fentry_filter_arg+0xda0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xb74, 0xda0, arm64_l_da0);
arm64_l_b78:
	/* 0xb78: cmp w8, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_b7c:
	/* 0xb7c: b.gt 10a0 <generic_fentry_filter_arg+0x10a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xb7c, 0x10a0, arm64_l_10a0);
arm64_l_b80:
	/* 0xb80: cmp w8, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_b84:
	/* 0xb84: b.eq 10b0 <generic_fentry_filter_arg+0x10b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xb84, 0x10b0, arm64_l_10b0);
arm64_l_b88:
	/* 0xb88: cmp w8, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_b8c:
	/* 0xb8c: b.ne 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xb8c, 0x294, arm64_l_294);
arm64_l_b90:
	/* 0xb90: ldrh w22, [x25, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_b94:
	/* 0xb94: b 182c <generic_fentry_filter_arg+0x182c> */
	ARM64_SIM_A64_JMP(0xb94, 0x182c, arm64_l_182c);
arm64_l_b98:
	/* 0xb98: cmp w8, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_b9c:
	/* 0xb9c: b.gt 10d8 <generic_fentry_filter_arg+0x10d8> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xb9c, 0x10d8, arm64_l_10d8);
arm64_l_ba0:
	/* 0xba0: cmp w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_ba4:
	/* 0xba4: b.eq 1108 <generic_fentry_filter_arg+0x1108> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xba4, 0x1108, arm64_l_1108);
arm64_l_ba8:
	/* 0xba8: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_bac:
	/* 0xbac: b.eq 10fc <generic_fentry_filter_arg+0x10fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xbac, 0x10fc, arm64_l_10fc);
arm64_l_bb0:
	/* 0xbb0: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0xbb0, 0x294, arm64_l_294);
arm64_l_bb4:
	/* 0xbb4: cmp w8, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_bb8:
	/* 0xbb8: b.eq 11ec <generic_fentry_filter_arg+0x11ec> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xbb8, 0x11ec, arm64_l_11ec);
arm64_l_bbc:
	/* 0xbbc: cmp w8, #0x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 34ULL);
arm64_l_bc0:
	/* 0xbc0: b.ne 12c8 <generic_fentry_filter_arg+0x12c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xbc0, 0x12c8, arm64_l_12c8);
arm64_l_bc4:
	/* 0xbc4: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_bc8:
	/* 0xbc8: mov w19, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_bcc:
	/* 0xbcc: add x8, x23, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_bd0:
	/* 0xbd0: str x8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_bd4:
	/* 0xbd4: ldr x8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_bd8:
	/* 0xbd8: adrp x0, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_24));
arm64_l_bdc:
	/* 0xbdc: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_be0:
	/* 0xbe0: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_be4:
	/* 0xbe4: ldr w8, [x8, x22, lsl #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X22, ARM64_MOD_LSL, 2, 0), 0ULL);
arm64_l_be8:
	/* 0xbe8: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_bec:
	/* 0xbec: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_bf0:
	/* 0xbf0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_bf4:
	/* 0xbf4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xbf8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_bf8:
	/* 0xbf8: cbz x0, 12b0 <generic_fentry_filter_arg+0x12b0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xbf8, 0x12b0, arm64_l_12b0);
arm64_l_bfc:
	/* 0xbfc: cbz w29, c78 <generic_fentry_filter_arg+0xc78> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0xbfc, 0xc78, arm64_l_c78);
arm64_l_c00:
	/* 0xc00: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c04:
	/* 0xc04: mov x9, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c08:
	/* 0xc08: mov x10, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c0c:
	/* 0xc0c: b c24 <generic_fentry_filter_arg+0xc24> */
	ARM64_SIM_A64_JMP(0xc0c, 0xc24, arm64_l_c24);
arm64_l_c10:
	/* 0xc10: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_c14:
	/* 0xc14: sub x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_c18:
	/* 0xc18: add x9, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_c1c:
	/* 0xc1c: cmp x8, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_c20:
	/* 0xc20: b.eq c78 <generic_fentry_filter_arg+0xc78> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xc20, 0xc78, arm64_l_c78);
arm64_l_c24:
	/* 0xc24: mov x11, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c28:
	/* 0xc28: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_c2c:
	/* 0xc2c: b.eq c10 <generic_fentry_filter_arg+0xc10> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xc2c, 0xc10, arm64_l_c10);
arm64_l_c30:
	/* 0xc30: ldrb w12, [x0, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X0, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c34:
	/* 0xc34: cbz w12, c74 <generic_fentry_filter_arg+0xc74> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0xc34, 0xc74, arm64_l_c74);
arm64_l_c38:
	/* 0xc38: ldrb w13, [x9, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c3c:
	/* 0xc3c: sub w14, w13, #0x41 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 65ULL);
arm64_l_c40:
	/* 0xc40: orr w15, w13, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_c44:
	/* 0xc44: cmp w14, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_c48:
	/* 0xc48: sub w14, w12, #0x41 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 65ULL);
arm64_l_c4c:
	/* 0xc4c: csel w13, w15, w13, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X13, ARM64_X15, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_c50:
	/* 0xc50: orr w15, w12, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_c54:
	/* 0xc54: cmp w14, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_c58:
	/* 0xc58: csel w12, w15, w12, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X12, ARM64_X15, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_c5c:
	/* 0xc5c: cmp x11, #0x62 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 98ULL);
arm64_l_c60:
	/* 0xc60: b.hi c10 <generic_fentry_filter_arg+0xc10> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xc60, 0xc10, arm64_l_c10);
arm64_l_c64:
	/* 0xc64: add x11, x11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_c68:
	/* 0xc68: cmp w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_c6c:
	/* 0xc6c: b.eq c28 <generic_fentry_filter_arg+0xc28> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xc6c, 0xc28, arm64_l_c28);
arm64_l_c70:
	/* 0xc70: b c10 <generic_fentry_filter_arg+0xc10> */
	ARM64_SIM_A64_JMP(0xc70, 0xc10, arm64_l_c10);
arm64_l_c74:
	/* 0xc74: tbz w8, #31, 1ad0 <generic_fentry_filter_arg+0x1ad0> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 31, 0xc74, 0x1ad0, arm64_l_1ad0);
arm64_l_c78:
	/* 0xc78: ldr w9, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_c7c:
	/* 0xc7c: add w8, w19, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_c80:
	/* 0xc80: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_c84:
	/* 0xc84: b.cs 12b0 <generic_fentry_filter_arg+0x12b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xc84, 0x12b0, arm64_l_12b0);
arm64_l_c88:
	/* 0xc88: add x22, x22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_c8c:
	/* 0xc8c: add w19, w19, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_c90:
	/* 0xc90: cmp x22, #0x64 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 100ULL);
arm64_l_c94:
	/* 0xc94: b.ne bd4 <generic_fentry_filter_arg+0xbd4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xc94, 0xbd4, arm64_l_bd4);
arm64_l_c98:
	/* 0xc98: b 12b0 <generic_fentry_filter_arg+0x12b0> */
	ARM64_SIM_A64_JMP(0xc98, 0x12b0, arm64_l_12b0);
arm64_l_c9c:
	/* 0xc9c: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_ca0:
	/* 0xca0: b.ne 18d0 <generic_fentry_filter_arg+0x18d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xca0, 0x18d0, arm64_l_18d0);
arm64_l_ca4:
	/* 0xca4: ldr x11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ca8:
	/* 0xca8: tst x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_cac:
	/* 0xcac: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xcac, 0x298, arm64_l_298);
arm64_l_cb0:
	/* 0xcb0: b 18d0 <generic_fentry_filter_arg+0x18d0> */
	ARM64_SIM_A64_JMP(0xcb0, 0x18d0, arm64_l_18d0);
arm64_l_cb4:
	/* 0xcb4: sub w10, w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_cb8:
	/* 0xcb8: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_cbc:
	/* 0xcbc: b.cs 1548 <generic_fentry_filter_arg+0x1548> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xcbc, 0x1548, arm64_l_1548);
arm64_l_cc0:
	/* 0xcc0: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_cc4:
	/* 0xcc4: b.ne dbc <generic_fentry_filter_arg+0xdbc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xcc4, 0xdbc, arm64_l_dbc);
arm64_l_cc8:
	/* 0xcc8: ldp x11, x10, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_ccc:
	/* 0xccc: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_cd0:
	/* 0xcd0: b.eq cdc <generic_fentry_filter_arg+0xcdc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xcd0, 0xcdc, arm64_l_cdc);
arm64_l_cd4:
	/* 0xcd4: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_cd8:
	/* 0xcd8: b.ne 179c <generic_fentry_filter_arg+0x179c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xcd8, 0x179c, arm64_l_179c);
arm64_l_cdc:
	/* 0xcdc: ldr x8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ce0:
	/* 0xce0: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ce4:
	/* 0xce4: b.gt 17b0 <generic_fentry_filter_arg+0x17b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xce4, 0x17b0, arm64_l_17b0);
arm64_l_ce8:
	/* 0xce8: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_cec:
	/* 0xcec: b.le 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xcec, 0x298, arm64_l_298);
arm64_l_cf0:
	/* 0xcf0: b 17b0 <generic_fentry_filter_arg+0x17b0> */
	ARM64_SIM_A64_JMP(0xcf0, 0x17b0, arm64_l_17b0);
arm64_l_cf4:
	/* 0xcf4: ldr w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_cf8:
	/* 0xcf8: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_cfc:
	/* 0xcfc: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_22));
arm64_l_d00:
	/* 0xd00: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_d04:
	/* 0xd04: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_d08:
	/* 0xd08: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_d0c:
	/* 0xd0c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d10:
	/* 0xd10: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d14:
	/* 0xd14: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xd18ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_d18:
	/* 0xd18: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d1c:
	/* 0xd1c: cbz w29, 12b8 <generic_fentry_filter_arg+0x12b8> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0xd1c, 0x12b8, arm64_l_12b8);
arm64_l_d20:
	/* 0xd20: cbz x0, 12b8 <generic_fentry_filter_arg+0x12b8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xd20, 0x12b8, arm64_l_12b8);
arm64_l_d24:
	/* 0xd24: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d28:
	/* 0xd28: adrp x0, 0 <string_prefix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap_23));
arm64_l_d2c:
	/* 0xd2c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d30:
	/* 0xd30: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d34:
	/* 0xd34: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_d38:
	/* 0xd38: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_d3c:
	/* 0xd3c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xd40ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_d40:
	/* 0xd40: cbz x0, 12b0 <generic_fentry_filter_arg+0x12b0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xd40, 0x12b0, arm64_l_12b0);
arm64_l_d44:
	/* 0xd44: cmp w29, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_d48:
	/* 0xd48: mov w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 255ULL);
arm64_l_d4c:
	/* 0xd4c: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d50:
	/* 0xd50: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d54:
	/* 0xd54: csel w1, w29, w8, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X1, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_d58:
	/* 0xd58: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d5c:
	/* 0xd5c: lsl w9, w1, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_d60:
	/* 0xd60: str w9, [x8], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_d64:
	/* 0xd64: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_d68:
	/* 0xd68: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d6c:
	/* 0xd6c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xd70ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_d70:
	/* 0xd70: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d74:
	/* 0xd74: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d78:
	/* 0xd78: mov x1, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d7c:
	/* 0xd7c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xd80ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_d80:
	/* 0xd80: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_d84:
	/* 0xd84: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_d88:
	/* 0xd88: b 12b4 <generic_fentry_filter_arg+0x12b4> */
	ARM64_SIM_A64_JMP(0xd88, 0x12b4, arm64_l_12b4);
arm64_l_d8c:
	/* 0xd8c: cmp w29, #0x1, lsl #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_d90:
	/* 0xd90: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_d94:
	/* 0xd94: b.ls 12f0 <generic_fentry_filter_arg+0x12f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0xd94, 0x12f0, arm64_l_12f0);
arm64_l_d98:
	/* 0xd98: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d9c:
	/* 0xd9c: b 12c8 <generic_fentry_filter_arg+0x12c8> */
	ARM64_SIM_A64_JMP(0xd9c, 0x12c8, arm64_l_12c8);
arm64_l_da0:
	/* 0xda0: cmp w8, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_da4:
	/* 0xda4: b.eq 1108 <generic_fentry_filter_arg+0x1108> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xda4, 0x1108, arm64_l_1108);
arm64_l_da8:
	/* 0xda8: cmp w8, #0xe */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 14ULL);
arm64_l_dac:
	/* 0xdac: b.eq 10fc <generic_fentry_filter_arg+0x10fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xdac, 0x10fc, arm64_l_10fc);
arm64_l_db0:
	/* 0xdb0: cmp w8, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_db4:
	/* 0xdb4: b.eq 10c4 <generic_fentry_filter_arg+0x10c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xdb4, 0x10c4, arm64_l_10c4);
arm64_l_db8:
	/* 0xdb8: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0xdb8, 0x294, arm64_l_294);
arm64_l_dbc:
	/* 0xdbc: ldp x11, x8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_dc0:
	/* 0xdc0: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_dc4:
	/* 0xdc4: b.eq dd0 <generic_fentry_filter_arg+0xdd0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xdc4, 0xdd0, arm64_l_dd0);
arm64_l_dc8:
	/* 0xdc8: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_dcc:
	/* 0xdcc: b.ne 17e8 <generic_fentry_filter_arg+0x17e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xdcc, 0x17e8, arm64_l_17e8);
arm64_l_dd0:
	/* 0xdd0: ldr x10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_dd4:
	/* 0xdd4: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_dd8:
	/* 0xdd8: ccmp x10, x8, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_ddc:
	/* 0xddc: cset w8, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_de0:
	/* 0xde0: b 17f8 <generic_fentry_filter_arg+0x17f8> */
	ARM64_SIM_A64_JMP(0xde0, 0x17f8, arm64_l_17f8);
arm64_l_de4:
	/* 0xde4: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_de8:
	/* 0xde8: b.ne 1ebc <generic_fentry_filter_arg+0x1ebc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xde8, 0x1ebc, arm64_l_1ebc);
arm64_l_dec:
	/* 0xdec: ldr w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_df0:
	/* 0xdf0: tst w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_df4:
	/* 0xdf4: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xdf4, 0x298, arm64_l_298);
arm64_l_df8:
	/* 0xdf8: b 1ebc <generic_fentry_filter_arg+0x1ebc> */
	ARM64_SIM_A64_JMP(0xdf8, 0x1ebc, arm64_l_1ebc);
arm64_l_dfc:
	/* 0xdfc: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_e00:
	/* 0xe00: tst x9, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_e04:
	/* 0xe04: b.ne 13e8 <generic_fentry_filter_arg+0x13e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xe04, 0x13e8, arm64_l_13e8);
arm64_l_e08:
	/* 0xe08: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_e0c:
	/* 0xe0c: tst x9, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_e10:
	/* 0xe10: b.eq fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe10, 0xfc, arm64_l_fc);
arm64_l_e14:
	/* 0xe14: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_e18:
	/* 0xe18: b.ne 1a0c <generic_fentry_filter_arg+0x1a0c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xe18, 0x1a0c, arm64_l_1a0c);
arm64_l_e1c:
	/* 0xe1c: ldr w9, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_e20:
	/* 0xe20: ldrb w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e24:
	/* 0xe24: b e50 <generic_fentry_filter_arg+0xe50> */
	ARM64_SIM_A64_JMP(0xe24, 0xe50, arm64_l_e50);
arm64_l_e28:
	/* 0xe28: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_e2c:
	/* 0xe2c: tst x9, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_e30:
	/* 0xe30: b.ne 1420 <generic_fentry_filter_arg+0x1420> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xe30, 0x1420, arm64_l_1420);
arm64_l_e34:
	/* 0xe34: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_e38:
	/* 0xe38: tst x9, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_e3c:
	/* 0xe3c: b.eq fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe3c, 0xfc, arm64_l_fc);
arm64_l_e40:
	/* 0xe40: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_e44:
	/* 0xe44: b.ne 1a30 <generic_fentry_filter_arg+0x1a30> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xe44, 0x1a30, arm64_l_1a30);
arm64_l_e48:
	/* 0xe48: ldr w9, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_e4c:
	/* 0xe4c: ldrh w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e50:
	/* 0xe50: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e54:
	/* 0xe54: b.hi e64 <generic_fentry_filter_arg+0xe64> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xe54, 0xe64, arm64_l_e64);
arm64_l_e58:
	/* 0xe58: ldr w9, [x23, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_e5c:
	/* 0xe5c: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e60:
	/* 0xe60: b.cs 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xe60, 0x298, arm64_l_298);
arm64_l_e64:
	/* 0xe64: ldr w9, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_e68:
	/* 0xe68: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_e6c:
	/* 0xe6c: b.cc fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xe6c, 0xfc, arm64_l_fc);
arm64_l_e70:
	/* 0xe70: ldr w10, [x23, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_e74:
	/* 0xe74: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e78:
	/* 0xe78: b.hi e88 <generic_fentry_filter_arg+0xe88> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xe78, 0xe88, arm64_l_e88);
arm64_l_e7c:
	/* 0xe7c: ldr w10, [x23, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_e80:
	/* 0xe80: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e84:
	/* 0xe84: b.cs 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xe84, 0x298, arm64_l_298);
arm64_l_e88:
	/* 0xe88: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_e8c:
	/* 0xe8c: b.cc fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xe8c, 0xfc, arm64_l_fc);
arm64_l_e90:
	/* 0xe90: ldr w10, [x23, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_e94:
	/* 0xe94: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e98:
	/* 0xe98: b.hi ea8 <generic_fentry_filter_arg+0xea8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xe98, 0xea8, arm64_l_ea8);
arm64_l_e9c:
	/* 0xe9c: ldr w10, [x23, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_ea0:
	/* 0xea0: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ea4:
	/* 0xea4: b.cs 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xea4, 0x298, arm64_l_298);
arm64_l_ea8:
	/* 0xea8: cmp w9, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_eac:
	/* 0xeac: b.cc fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xeac, 0xfc, arm64_l_fc);
arm64_l_eb0:
	/* 0xeb0: ldr w9, [x23, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_eb4:
	/* 0xeb4: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_eb8:
	/* 0xeb8: b.hi fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xeb8, 0xfc, arm64_l_fc);
arm64_l_ebc:
	/* 0xebc: ldr w9, [x23, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_ec0:
	/* 0xec0: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ec4:
	/* 0xec4: b.cs 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xec4, 0x298, arm64_l_298);
arm64_l_ec8:
	/* 0xec8: b fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0xec8, 0xfc, arm64_l_fc);
arm64_l_ecc:
	/* 0xecc: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_ed0:
	/* 0xed0: b.eq edc <generic_fentry_filter_arg+0xedc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xed0, 0xedc, arm64_l_edc);
arm64_l_ed4:
	/* 0xed4: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_ed8:
	/* 0xed8: b.ne 18b4 <generic_fentry_filter_arg+0x18b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xed8, 0x18b4, arm64_l_18b4);
arm64_l_edc:
	/* 0xedc: ldr x11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ee0:
	/* 0xee0: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ee4:
	/* 0xee4: b.gt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xee4, 0x298, arm64_l_298);
arm64_l_ee8:
	/* 0xee8: b 18d0 <generic_fentry_filter_arg+0x18d0> */
	ARM64_SIM_A64_JMP(0xee8, 0x18d0, arm64_l_18d0);
arm64_l_eec:
	/* 0xeec: and w8, w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_ef0:
	/* 0xef0: cmp w8, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_ef4:
	/* 0xef4: b.hi 149c <generic_fentry_filter_arg+0x149c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xef4, 0x149c, arm64_l_149c);
arm64_l_ef8:
	/* 0xef8: and w8, w29, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_efc:
	/* 0xefc: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_f00:
	/* 0xf00: tst w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_f04:
	/* 0xf04: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_f08:
	/* 0xf08: mov w9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_f0c:
	/* 0xf0c: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_f10:
	/* 0xf10: msub w8, w8, w9, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MSUB, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_X29, ARM64_WIDTH_32, 0, 0);
arm64_l_f14:
	/* 0xf14: b.eq f28 <generic_fentry_filter_arg+0xf28> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf14, 0xf28, arm64_l_f28);
arm64_l_f18:
	/* 0xf18: tst w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_f1c:
	/* 0xf1c: mov w9, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_f20:
	/* 0xf20: mov w11, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_f24:
	/* 0xf24: b.eq f44 <generic_fentry_filter_arg+0xf44> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf24, 0xf44, arm64_l_f44);
arm64_l_f28:
	/* 0xf28: sub w8, w29, w8, uxtb */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_UXTB, 0), 0);
arm64_l_f2c:
	/* 0xf2c: and w9, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_f30:
	/* 0xf30: add w8, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_f34:
	/* 0xf34: and w11, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_f38:
	/* 0xf38: cmp w9, #0x78 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 120ULL);
arm64_l_f3c:
	/* 0xf3c: b.hi 245c <generic_fentry_filter_arg+0x245c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xf3c, 0x245c, arm64_l_245c);
arm64_l_f40:
	/* 0xf40: mov w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_f44:
	/* 0xf44: and w8, w9, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_f48:
	/* 0xf48: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_f4c:
	/* 0xf4c: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_f50:
	/* 0xf50: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_f54:
	/* 0xf54: sub w10, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_f58:
	/* 0xf58: b 24ac <generic_fentry_filter_arg+0x24ac> */
	ARM64_SIM_A64_JMP(0xf58, 0x24ac, arm64_l_24ac);
arm64_l_f5c:
	/* 0xf5c: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_f60:
	/* 0xf60: b.gt 1588 <generic_fentry_filter_arg+0x1588> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xf60, 0x1588, arm64_l_1588);
arm64_l_f64:
	/* 0xf64: cmp w8, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_f68:
	/* 0xf68: b.eq 16fc <generic_fentry_filter_arg+0x16fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf68, 0x16fc, arm64_l_16fc);
arm64_l_f6c:
	/* 0xf6c: cmp w8, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_f70:
	/* 0xf70: b.ne 3390 <generic_fentry_filter_arg+0x3390> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xf70, 0x3390, arm64_l_3390);
arm64_l_f74:
	/* 0xf74: ldr w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_f78:
	/* 0xf78: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_f7c:
	/* 0xf7c: adrp x0, 0 <string_postfix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_20));
arm64_l_f80:
	/* 0xf80: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_f84:
	/* 0xf84: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_f88:
	/* 0xf88: mov w19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f8c:
	/* 0xf8c: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_f90:
	/* 0xf90: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f94:
	/* 0xf94: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f98:
	/* 0xf98: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xf9cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_f9c:
	/* 0xf9c: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_fa0:
	/* 0xfa0: cbz w25, 338c <generic_fentry_filter_arg+0x338c> */
	ARM64_SIM_A64_CBZ(ARM64_X25, 0xfa0, 0x338c, arm64_l_338c);
arm64_l_fa4:
	/* 0xfa4: cbz x0, 338c <generic_fentry_filter_arg+0x338c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xfa4, 0x338c, arm64_l_338c);
arm64_l_fa8:
	/* 0xfa8: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_fac:
	/* 0xfac: adrp x0, 0 <string_postfix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap_21));
arm64_l_fb0:
	/* 0xfb0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_fb4:
	/* 0xfb4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_fb8:
	/* 0xfb8: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_fbc:
	/* 0xfbc: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_fc0:
	/* 0xfc0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xfc4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_fc4:
	/* 0xfc4: cbz x0, 3388 <generic_fentry_filter_arg+0x3388> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xfc4, 0x3388, arm64_l_3388);
arm64_l_fc8:
	/* 0xfc8: cmp w25, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_fcc:
	/* 0xfcc: mov w9, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_fd0:
	/* 0xfd0: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_fd4:
	/* 0xfd4: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_fd8:
	/* 0xfd8: sub x11, x19, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X19, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_fdc:
	/* 0xfdc: sub w12, w25, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_fe0:
	/* 0xfe0: sub w13, w25, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_fe4:
	/* 0xfe4: csel w9, w25, w9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X9, ARM64_X25, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_fe8:
	/* 0xfe8: lsl w10, w9, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_fec:
	/* 0xfec: mov x9, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ff0:
	/* 0xff0: str w10, [x9], #5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 5ULL);
arm64_l_ff4:
	/* 0xff4: neg x10, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ff8:
	/* 0xff8: add w14, w13, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X13, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_ffc:
	/* 0xffc: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1000:
	/* 0x1000: and x14, x14, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1004:
	/* 0x1004: ldrb w14, [x29, x14] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X14, ARM64_X29, ARM64_X14, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X14, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1008:
	/* 0x1008: sturb w14, [x9, #-1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 18446744073709551615ULL);
arm64_l_100c:
	/* 0x100c: b.eq 1034 <generic_fentry_filter_arg+0x1034> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x100c, 0x1034, arm64_l_1034);
arm64_l_1010:
	/* 0x1010: cmn x8, #0x7e */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 126ULL);
arm64_l_1014:
	/* 0x1014: b.eq 1034 <generic_fentry_filter_arg+0x1034> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1014, 0x1034, arm64_l_1034);
arm64_l_1018:
	/* 0x1018: add w14, w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_101c:
	/* 0x101c: sub x8, x8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1020:
	/* 0x1020: and x14, x14, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1024:
	/* 0x1024: cmp x10, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1028:
	/* 0x1028: ldrb w14, [x29, x14] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X14, ARM64_X29, ARM64_X14, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X14, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_102c:
	/* 0x102c: strb w14, [x9], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_1030:
	/* 0x1030: b.ne ff8 <generic_fentry_filter_arg+0xff8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1030, 0xff8, arm64_l_ff8);
arm64_l_1034:
	/* 0x1034: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1038:
	/* 0x1038: mov x0, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_103c:
	/* 0x103c: b 3378 <generic_fentry_filter_arg+0x3378> */
	ARM64_SIM_A64_JMP(0x103c, 0x3378, arm64_l_3378);
arm64_l_1040:
	/* 0x1040: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1044:
	/* 0x1044: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1048:
	/* 0x1048: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_104c:
	/* 0x104c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1050:
	/* 0x1050: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1054:
	/* 0x1054: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x1054, 0x294, arm64_l_294);
arm64_l_1058:
	/* 0x1058: ldp w11, w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_105c:
	/* 0x105c: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1060:
	/* 0x1060: b.hi 1bb0 <generic_fentry_filter_arg+0x1bb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1060, 0x1bb0, arm64_l_1bb0);
arm64_l_1064:
	/* 0x1064: lsl w10, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1068:
	/* 0x1068: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_106c:
	/* 0x106c: tst w10, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1070:
	/* 0x1070: b.eq 1bb0 <generic_fentry_filter_arg+0x1bb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1070, 0x1bb0, arm64_l_1bb0);
arm64_l_1074:
	/* 0x1074: ldr w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1078:
	/* 0x1078: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_107c:
	/* 0x107c: ccmp w10, w8, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_1080:
	/* 0x1080: cset w8, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_1084:
	/* 0x1084: b 1bc0 <generic_fentry_filter_arg+0x1bc0> */
	ARM64_SIM_A64_JMP(0x1084, 0x1bc0, arm64_l_1bc0);
arm64_l_1088:
	/* 0x1088: cmp w8, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_108c:
	/* 0x108c: b.eq 16c0 <generic_fentry_filter_arg+0x16c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x108c, 0x16c0, arm64_l_16c0);
arm64_l_1090:
	/* 0x1090: mov x25, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1094:
	/* 0x1094: cmp w8, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_1098:
	/* 0x1098: b.eq 1608 <generic_fentry_filter_arg+0x1608> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1098, 0x1608, arm64_l_1608);
arm64_l_109c:
	/* 0x109c: b fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x109c, 0xfc, arm64_l_fc);
arm64_l_10a0:
	/* 0x10a0: cmp w8, #0x12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_10a4:
	/* 0x10a4: b.eq 10c4 <generic_fentry_filter_arg+0x10c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x10a4, 0x10c4, arm64_l_10c4);
arm64_l_10a8:
	/* 0x10a8: cmp w8, #0x13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 19ULL);
arm64_l_10ac:
	/* 0x10ac: b.ne 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x10ac, 0x294, arm64_l_294);
arm64_l_10b0:
	/* 0x10b0: ldrh w29, [x25, #34] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 34ULL);
arm64_l_10b4:
	/* 0x10b4: mov w11, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_10b8:
	/* 0x10b8: mov w13, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_10bc:
	/* 0x10bc: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10c0:
	/* 0x10c0: b 1114 <generic_fentry_filter_arg+0x1114> */
	ARM64_SIM_A64_JMP(0x10c0, 0x1114, arm64_l_1114);
arm64_l_10c4:
	/* 0x10c4: ldrh w29, [x25, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_10c8:
	/* 0x10c8: mov w11, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_10cc:
	/* 0x10cc: mov w13, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_10d0:
	/* 0x10d0: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10d4:
	/* 0x10d4: b 1114 <generic_fentry_filter_arg+0x1114> */
	ARM64_SIM_A64_JMP(0x10d4, 0x1114, arm64_l_1114);
arm64_l_10d8:
	/* 0x10d8: cmp w8, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_10dc:
	/* 0x10dc: b.eq 1828 <generic_fentry_filter_arg+0x1828> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x10dc, 0x1828, arm64_l_1828);
arm64_l_10e0:
	/* 0x10e0: cmp w8, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_10e4:
	/* 0x10e4: b.ne 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x10e4, 0x294, arm64_l_294);
arm64_l_10e8:
	/* 0x10e8: cmp w9, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_10ec:
	/* 0x10ec: b.ne 1d60 <generic_fentry_filter_arg+0x1d60> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x10ec, 0x1d60, arm64_l_1d60);
arm64_l_10f0:
	/* 0x10f0: cbnz x10, 1d70 <generic_fentry_filter_arg+0x1d70> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0x10f0, 0x1d70, arm64_l_1d70);
arm64_l_10f4:
	/* 0x10f4: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10f8:
	/* 0x10f8: b 1d84 <generic_fentry_filter_arg+0x1d84> */
	ARM64_SIM_A64_JMP(0x10f8, 0x1d84, arm64_l_1d84);
arm64_l_10fc:
	/* 0x10fc: ldp w11, w13, [x25, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X13, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1100:
	/* 0x1100: ldr x19, [x25, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1104:
	/* 0x1104: b 1110 <generic_fentry_filter_arg+0x1110> */
	ARM64_SIM_A64_JMP(0x1104, 0x1110, arm64_l_1110);
arm64_l_1108:
	/* 0x1108: ldp w11, w13, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X13, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_110c:
	/* 0x110c: ldr x19, [x25, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1110:
	/* 0x1110: mov x29, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1114:
	/* 0x1114: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1118:
	/* 0x1118: cmp w8, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_111c:
	/* 0x111c: b.gt 1148 <generic_fentry_filter_arg+0x1148> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x111c, 0x1148, arm64_l_1148);
arm64_l_1120:
	/* 0x1120: sub w9, w8, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1124:
	/* 0x1124: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1128:
	/* 0x1128: b.cc 1174 <generic_fentry_filter_arg+0x1174> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1128, 0x1174, arm64_l_1174);
arm64_l_112c:
	/* 0x112c: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1130:
	/* 0x1130: sub w9, w8, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_1134:
	/* 0x1134: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1138:
	/* 0x1138: b.cc 1370 <generic_fentry_filter_arg+0x1370> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1138, 0x1370, arm64_l_1370);
arm64_l_113c:
	/* 0x113c: cmp w8, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1140:
	/* 0x1140: b.eq 182c <generic_fentry_filter_arg+0x182c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1140, 0x182c, arm64_l_182c);
arm64_l_1144:
	/* 0x1144: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x1144, 0x294, arm64_l_294);
arm64_l_1148:
	/* 0x1148: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_114c:
	/* 0x114c: b.hi 1360 <generic_fentry_filter_arg+0x1360> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x114c, 0x1360, arm64_l_1360);
arm64_l_1150:
	/* 0x1150: lsl w9, w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1154:
	/* 0x1154: mov w10, #0x500000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5242880ULL);
arm64_l_1158:
	/* 0x1158: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_115c:
	/* 0x115c: b.ne 145c <generic_fentry_filter_arg+0x145c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x115c, 0x145c, arm64_l_145c);
arm64_l_1160:
	/* 0x1160: mov w10, #0xa00000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10485760ULL);
arm64_l_1164:
	/* 0x1164: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1168:
	/* 0x1168: b.ne 146c <generic_fentry_filter_arg+0x146c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1168, 0x146c, arm64_l_146c);
arm64_l_116c:
	/* 0x116c: tst w9, #0x3000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50331648ULL);
arm64_l_1170:
	/* 0x1170: b.eq 1360 <generic_fentry_filter_arg+0x1360> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1170, 0x1360, arm64_l_1360);
arm64_l_1174:
	/* 0x1174: ldrh w8, [x25, #38] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 38ULL);
arm64_l_1178:
	/* 0x1178: cmp w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_117c:
	/* 0x117c: b.eq 14ac <generic_fentry_filter_arg+0x14ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x117c, 0x14ac, arm64_l_14ac);
arm64_l_1180:
	/* 0x1180: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1184:
	/* 0x1184: b.ne 1538 <generic_fentry_filter_arg+0x1538> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1184, 0x1538, arm64_l_1538);
arm64_l_1188:
	/* 0x1188: ldr w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_118c:
	/* 0x118c: adrp x0, 0 <addr4lpm_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&addr4lpm_maps_0));
arm64_l_1190:
	/* 0x1190: add x9, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1194:
	/* 0x1194: add x1, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1198:
	/* 0x1198: str w8, [sp, #172] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 172ULL);
arm64_l_119c:
	/* 0x119c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_11a0:
	/* 0x11a0: mov w22, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_11a4:
	/* 0x11a4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_11a8:
	/* 0x11a8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x11acULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_11ac:
	/* 0x11ac: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_11b0:
	/* 0x11b0: cbz x0, 1e6c <generic_fentry_filter_arg+0x1e6c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x11b0, 0x1e6c, arm64_l_1e6c);
arm64_l_11b4:
	/* 0x11b4: mov w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 32ULL);
arm64_l_11b8:
	/* 0x11b8: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_11bc:
	/* 0x11bc: stp w8, w22, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_11c0:
	/* 0x11c0: b 14f4 <generic_fentry_filter_arg+0x14f4> */
	ARM64_SIM_A64_JMP(0x11c0, 0x14f4, arm64_l_14f4);
arm64_l_11c4:
	/* 0x11c4: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_11c8:
	/* 0x11c8: b.hi 1ea0 <generic_fentry_filter_arg+0x1ea0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x11c8, 0x1ea0, arm64_l_1ea0);
arm64_l_11cc:
	/* 0x11cc: lsl w11, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X11, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_11d0:
	/* 0x11d0: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_11d4:
	/* 0x11d4: tst w11, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X11, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_11d8:
	/* 0x11d8: b.eq 1ea0 <generic_fentry_filter_arg+0x1ea0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x11d8, 0x1ea0, arm64_l_1ea0);
arm64_l_11dc:
	/* 0x11dc: ldr w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_11e0:
	/* 0x11e0: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_11e4:
	/* 0x11e4: b.gt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x11e4, 0x298, arm64_l_298);
arm64_l_11e8:
	/* 0x11e8: b 1ebc <generic_fentry_filter_arg+0x1ebc> */
	ARM64_SIM_A64_JMP(0x11e8, 0x1ebc, arm64_l_1ebc);
arm64_l_11ec:
	/* 0x11ec: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11f0:
	/* 0x11f0: mov w22, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_11f4:
	/* 0x11f4: add x8, x23, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_11f8:
	/* 0x11f8: str x8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_11fc:
	/* 0x11fc: ldr x8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1200:
	/* 0x1200: adrp x0, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_24));
arm64_l_1204:
	/* 0x1204: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1208:
	/* 0x1208: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_120c:
	/* 0x120c: ldr w8, [x8, x19, lsl #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X19, ARM64_MOD_LSL, 2, 0), 0ULL);
arm64_l_1210:
	/* 0x1210: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1214:
	/* 0x1214: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1218:
	/* 0x1218: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_121c:
	/* 0x121c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1220ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1220:
	/* 0x1220: cbz x0, 12b0 <generic_fentry_filter_arg+0x12b0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1220, 0x12b0, arm64_l_12b0);
arm64_l_1224:
	/* 0x1224: cbz w29, 1290 <generic_fentry_filter_arg+0x1290> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x1224, 0x1290, arm64_l_1290);
arm64_l_1228:
	/* 0x1228: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_122c:
	/* 0x122c: mov x9, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1230:
	/* 0x1230: mov x10, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1234:
	/* 0x1234: b 124c <generic_fentry_filter_arg+0x124c> */
	ARM64_SIM_A64_JMP(0x1234, 0x124c, arm64_l_124c);
arm64_l_1238:
	/* 0x1238: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_123c:
	/* 0x123c: sub x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1240:
	/* 0x1240: add x9, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1244:
	/* 0x1244: cmp x8, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1248:
	/* 0x1248: b.eq 1290 <generic_fentry_filter_arg+0x1290> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1248, 0x1290, arm64_l_1290);
arm64_l_124c:
	/* 0x124c: mov x11, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1250:
	/* 0x1250: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1254:
	/* 0x1254: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1258:
	/* 0x1258: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_125c:
	/* 0x125c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1260:
	/* 0x1260: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1264:
	/* 0x1264: b.eq 1238 <generic_fentry_filter_arg+0x1238> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1264, 0x1238, arm64_l_1238);
arm64_l_1268:
	/* 0x1268: ldrb w12, [x0, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X0, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_126c:
	/* 0x126c: cbz w12, 128c <generic_fentry_filter_arg+0x128c> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0x126c, 0x128c, arm64_l_128c);
arm64_l_1270:
	/* 0x1270: cmp x11, #0x62 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 98ULL);
arm64_l_1274:
	/* 0x1274: b.hi 1238 <generic_fentry_filter_arg+0x1238> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1274, 0x1238, arm64_l_1238);
arm64_l_1278:
	/* 0x1278: ldrb w13, [x9, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_127c:
	/* 0x127c: add x11, x11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1280:
	/* 0x1280: cmp w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1284:
	/* 0x1284: b.eq 1260 <generic_fentry_filter_arg+0x1260> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1284, 0x1260, arm64_l_1260);
arm64_l_1288:
	/* 0x1288: b 1238 <generic_fentry_filter_arg+0x1238> */
	ARM64_SIM_A64_JMP(0x1288, 0x1238, arm64_l_1238);
arm64_l_128c:
	/* 0x128c: tbz w8, #31, 1ad0 <generic_fentry_filter_arg+0x1ad0> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 31, 0x128c, 0x1ad0, arm64_l_1ad0);
arm64_l_1290:
	/* 0x1290: ldr w9, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1294:
	/* 0x1294: add w8, w22, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1298:
	/* 0x1298: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_129c:
	/* 0x129c: b.cs 12b0 <generic_fentry_filter_arg+0x12b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x129c, 0x12b0, arm64_l_12b0);
arm64_l_12a0:
	/* 0x12a0: add x19, x19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_12a4:
	/* 0x12a4: add w22, w22, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_12a8:
	/* 0x12a8: cmp x19, #0x64 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 100ULL);
arm64_l_12ac:
	/* 0x12ac: b.ne 11fc <generic_fentry_filter_arg+0x11fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x12ac, 0x11fc, arm64_l_11fc);
arm64_l_12b0:
	/* 0x12b0: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_12b4:
	/* 0x12b4: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_12b8:
	/* 0x12b8: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_12bc:
	/* 0x12bc: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_12c0:
	/* 0x12c0: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_12c4:
	/* 0x12c4: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_12c8:
	/* 0x12c8: ldr w8, [x23, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_12cc:
	/* 0x12cc: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_12d0:
	/* 0x12d0: b.hi 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x12d0, 0x294, arm64_l_294);
arm64_l_12d4:
	/* 0x12d4: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_12d8:
	/* 0x12d8: lsl x8, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_12dc:
	/* 0x12dc: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_12e0:
	/* 0x12e0: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_12e4:
	/* 0x12e4: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_12e8:
	/* 0x12e8: b.ne 33c4 <generic_fentry_filter_arg+0x33c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x12e8, 0x33c4, arm64_l_33c4);
arm64_l_12ec:
	/* 0x12ec: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x12ec, 0x294, arm64_l_294);
arm64_l_12f0:
	/* 0x12f0: and w8, w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_12f4:
	/* 0x12f4: cmp w8, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_12f8:
	/* 0x12f8: b.hi 18a4 <generic_fentry_filter_arg+0x18a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x12f8, 0x18a4, arm64_l_18a4);
arm64_l_12fc:
	/* 0x12fc: and w8, w29, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1300:
	/* 0x1300: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_1304:
	/* 0x1304: tst w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1308:
	/* 0x1308: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_130c:
	/* 0x130c: mov w9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_1310:
	/* 0x1310: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_1314:
	/* 0x1314: msub w8, w8, w9, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MSUB, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_X29, ARM64_WIDTH_32, 0, 0);
arm64_l_1318:
	/* 0x1318: b.eq 132c <generic_fentry_filter_arg+0x132c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1318, 0x132c, arm64_l_132c);
arm64_l_131c:
	/* 0x131c: tst w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1320:
	/* 0x1320: mov w9, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1324:
	/* 0x1324: mov w11, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1328:
	/* 0x1328: b.eq 1348 <generic_fentry_filter_arg+0x1348> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1328, 0x1348, arm64_l_1348);
arm64_l_132c:
	/* 0x132c: sub w8, w29, w8, uxtb */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_UXTB, 0), 0);
arm64_l_1330:
	/* 0x1330: and w9, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1334:
	/* 0x1334: add w8, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1338:
	/* 0x1338: and w11, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_133c:
	/* 0x133c: cmp w9, #0x78 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 120ULL);
arm64_l_1340:
	/* 0x1340: b.hi 2928 <generic_fentry_filter_arg+0x2928> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1340, 0x2928, arm64_l_2928);
arm64_l_1344:
	/* 0x1344: mov w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1348:
	/* 0x1348: and w8, w9, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_134c:
	/* 0x134c: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_1350:
	/* 0x1350: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1354:
	/* 0x1354: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_1358:
	/* 0x1358: sub w10, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_135c:
	/* 0x135c: b 2978 <generic_fentry_filter_arg+0x2978> */
	ARM64_SIM_A64_JMP(0x135c, 0x2978, arm64_l_2978);
arm64_l_1360:
	/* 0x1360: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1364:
	/* 0x1364: sub w8, w8, #0x12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_1368:
	/* 0x1368: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_136c:
	/* 0x136c: b.cs 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x136c, 0x294, arm64_l_294);
arm64_l_1370:
	/* 0x1370: ldrb w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1374:
	/* 0x1374: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_1378:
	/* 0x1378: add x9, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_137c:
	/* 0x137c: add x1, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1380:
	/* 0x1380: str w8, [sp, #172] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 172ULL);
arm64_l_1384:
	/* 0x1384: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1388:
	/* 0x1388: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_138c:
	/* 0x138c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1390ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1390:
	/* 0x1390: cbz x0, 1898 <generic_fentry_filter_arg+0x1898> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1390, 0x1898, arm64_l_1898);
arm64_l_1394:
	/* 0x1394: str x29, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1398:
	/* 0x1398: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_139c:
	/* 0x139c: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_13a0:
	/* 0x13a0: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_13a4:
	/* 0x13a4: b 1860 <generic_fentry_filter_arg+0x1860> */
	ARM64_SIM_A64_JMP(0x13a4, 0x1860, arm64_l_1860);
arm64_l_13a8:
	/* 0x13a8: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_13ac:
	/* 0x13ac: b.eq 1ad8 <generic_fentry_filter_arg+0x1ad8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x13ac, 0x1ad8, arm64_l_1ad8);
arm64_l_13b0:
	/* 0x13b0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_13b4:
	/* 0x13b4: b.ne 1ae4 <generic_fentry_filter_arg+0x1ae4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x13b4, 0x1ae4, arm64_l_1ae4);
arm64_l_13b8:
	/* 0x13b8: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_13bc:
	/* 0x13bc: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_13c0:
	/* 0x13c0: b.hi 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x13c0, 0x298, arm64_l_298);
arm64_l_13c4:
	/* 0x13c4: b 1ae4 <generic_fentry_filter_arg+0x1ae4> */
	ARM64_SIM_A64_JMP(0x13c4, 0x1ae4, arm64_l_1ae4);
arm64_l_13c8:
	/* 0x13c8: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_13cc:
	/* 0x13cc: b.eq 1b18 <generic_fentry_filter_arg+0x1b18> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x13cc, 0x1b18, arm64_l_1b18);
arm64_l_13d0:
	/* 0x13d0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_13d4:
	/* 0x13d4: b.ne 1b24 <generic_fentry_filter_arg+0x1b24> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x13d4, 0x1b24, arm64_l_1b24);
arm64_l_13d8:
	/* 0x13d8: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_13dc:
	/* 0x13dc: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_13e0:
	/* 0x13e0: b.hi 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x13e0, 0x298, arm64_l_298);
arm64_l_13e4:
	/* 0x13e4: b 1b24 <generic_fentry_filter_arg+0x1b24> */
	ARM64_SIM_A64_JMP(0x13e4, 0x1b24, arm64_l_1b24);
arm64_l_13e8:
	/* 0x13e8: ldrb w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_13ec:
	/* 0x13ec: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_13f0:
	/* 0x13f0: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_13f4:
	/* 0x13f4: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_13f8:
	/* 0x13f8: str w8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_13fc:
	/* 0x13fc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1400:
	/* 0x1400: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1404:
	/* 0x1404: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1408ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1408:
	/* 0x1408: cbz x0, 1898 <generic_fentry_filter_arg+0x1898> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1408, 0x1898, arm64_l_1898);
arm64_l_140c:
	/* 0x140c: ldrb w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1410:
	/* 0x1410: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1414:
	/* 0x1414: str x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1418:
	/* 0x1418: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_141c:
	/* 0x141c: b 1454 <generic_fentry_filter_arg+0x1454> */
	ARM64_SIM_A64_JMP(0x141c, 0x1454, arm64_l_1454);
arm64_l_1420:
	/* 0x1420: ldrb w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1424:
	/* 0x1424: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_1428:
	/* 0x1428: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_142c:
	/* 0x142c: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1430:
	/* 0x1430: str w8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1434:
	/* 0x1434: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1438:
	/* 0x1438: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_143c:
	/* 0x143c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1440ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1440:
	/* 0x1440: cbz x0, 1898 <generic_fentry_filter_arg+0x1898> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1440, 0x1898, arm64_l_1898);
arm64_l_1444:
	/* 0x1444: ldrh w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1448:
	/* 0x1448: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_144c:
	/* 0x144c: str x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1450:
	/* 0x1450: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1454:
	/* 0x1454: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1458:
	/* 0x1458: b 1860 <generic_fentry_filter_arg+0x1860> */
	ARM64_SIM_A64_JMP(0x1458, 0x1860, arm64_l_1860);
arm64_l_145c:
	/* 0x145c: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1460:
	/* 0x1460: cmp x29, #0x400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1024ULL);
arm64_l_1464:
	/* 0x1464: cset w22, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_1468:
	/* 0x1468: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x1468, 0x294, arm64_l_294);
arm64_l_146c:
	/* 0x146c: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1470:
	/* 0x1470: cmp x29, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1474:
	/* 0x1474: cset w22, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_1478:
	/* 0x1478: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x1478, 0x294, arm64_l_294);
arm64_l_147c:
	/* 0x147c: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1480:
	/* 0x1480: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1484:
	/* 0x1484: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1488:
	/* 0x1488: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_148c:
	/* 0x148c: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1490:
	/* 0x1490: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1494:
	/* 0x1494: mov w22, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1498:
	/* 0x1498: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x1498, 0x294, arm64_l_294);
arm64_l_149c:
	/* 0x149c: cmp w8, #0x101 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 257ULL);
arm64_l_14a0:
	/* 0x14a0: b.cs 1ab4 <generic_fentry_filter_arg+0x1ab4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x14a0, 0x1ab4, arm64_l_1ab4);
arm64_l_14a4:
	/* 0x14a4: mov w11, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_14a8:
	/* 0x14a8: b 245c <generic_fentry_filter_arg+0x245c> */
	ARM64_SIM_A64_JMP(0x14a8, 0x245c, arm64_l_245c);
arm64_l_14ac:
	/* 0x14ac: ldr w8, [x23, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_14b0:
	/* 0x14b0: adrp x0, 0 <addr6lpm_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&addr6lpm_maps_1));
arm64_l_14b4:
	/* 0x14b4: add x9, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_14b8:
	/* 0x14b8: add x1, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_14bc:
	/* 0x14bc: str w8, [sp, #172] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 172ULL);
arm64_l_14c0:
	/* 0x14c0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_14c4:
	/* 0x14c4: mov w25, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_14c8:
	/* 0x14c8: mov w22, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_14cc:
	/* 0x14cc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_14d0:
	/* 0x14d0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x14d4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_14d4:
	/* 0x14d4: cbz x0, 1e74 <generic_fentry_filter_arg+0x1e74> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x14d4, 0x1e74, arm64_l_1e74);
arm64_l_14d8:
	/* 0x14d8: mov w8, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 128ULL);
arm64_l_14dc:
	/* 0x14dc: stp w25, w19, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X25, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_14e0:
	/* 0x14e0: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_14e4:
	/* 0x14e4: stp w8, w22, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_14e8:
	/* 0x14e8: lsr x8, x19, #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 32ULL);
arm64_l_14ec:
	/* 0x14ec: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_14f0:
	/* 0x14f0: str w8, [sp, #152] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_14f4:
	/* 0x14f4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_14f8:
	/* 0x14f8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x14fcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_14fc:
	/* 0x14fc: ldr w8, [x23, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1500:
	/* 0x1500: sub w9, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1504:
	/* 0x1504: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1508:
	/* 0x1508: b.cc 1ac8 <generic_fentry_filter_arg+0x1ac8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1508, 0x1ac8, arm64_l_1ac8);
arm64_l_150c:
	/* 0x150c: sub w8, w8, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1510:
	/* 0x1510: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1514:
	/* 0x1514: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1518:
	/* 0x1518: b.hi ad0 <generic_fentry_filter_arg+0xad0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1518, 0xad0, arm64_l_ad0);
arm64_l_151c:
	/* 0x151c: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1520:
	/* 0x1520: cset w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1524:
	/* 0x1524: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1528:
	/* 0x1528: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_152c:
	/* 0x152c: mov w22, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1530:
	/* 0x1530: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1534:
	/* 0x1534: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x1534, 0x294, arm64_l_294);
arm64_l_1538:
	/* 0x1538: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_153c:
	/* 0x153c: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1540:
	/* 0x1540: mov w22, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1544:
	/* 0x1544: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x1544, 0x294, arm64_l_294);
arm64_l_1548:
	/* 0x1548: cmp w8, #0x1e */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 30ULL);
arm64_l_154c:
	/* 0x154c: b.ne fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x154c, 0xfc, arm64_l_fc);
arm64_l_1550:
	/* 0x1550: ldr w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1554:
	/* 0x1554: and x8, x8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_1558:
	/* 0x1558: add x9, x20, x8, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_155c:
	/* 0x155c: ldr w9, [x9, x2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X2, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1560:
	/* 0x1560: cbnz w9, fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_CBNZ(ARM64_X9, 0x1560, 0xfc, arm64_l_fc);
arm64_l_1564:
	/* 0x1564: add x8, x20, x8, lsl #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 3), 0);
arm64_l_1568:
	/* 0x1568: ldr x9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_156c:
	/* 0x156c: ldr x8, [x8, #24184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24184ULL);
arm64_l_1570:
	/* 0x1570: and x8, x8, #0x7ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2047ULL);
arm64_l_1574:
	/* 0x1574: add x8, x20, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1578:
	/* 0x1578: ldr x8, [x8, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_157c:
	/* 0x157c: bics xzr, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_BIC_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1580:
	/* 0x1580: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1584:
	/* 0x1584: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x1584, 0x294, arm64_l_294);
arm64_l_1588:
	/* 0x1588: cmp w8, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_158c:
	/* 0x158c: b.eq 1bfc <generic_fentry_filter_arg+0x1bfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x158c, 0x1bfc, arm64_l_1bfc);
arm64_l_1590:
	/* 0x1590: cmp w8, #0x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 34ULL);
arm64_l_1594:
	/* 0x1594: b.ne 3390 <generic_fentry_filter_arg+0x3390> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1594, 0x3390, arm64_l_3390);
arm64_l_1598:
	/* 0x1598: mov w19, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_159c:
	/* 0x159c: ldr w8, [x23, x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X19, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_15a0:
	/* 0x15a0: adrp x0, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_24));
arm64_l_15a4:
	/* 0x15a4: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_15a8:
	/* 0x15a8: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_15ac:
	/* 0x15ac: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_15b0:
	/* 0x15b0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_15b4:
	/* 0x15b4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_15b8:
	/* 0x15b8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x15bcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_15bc:
	/* 0x15bc: cbz x0, 3388 <generic_fentry_filter_arg+0x3388> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x15bc, 0x3388, arm64_l_3388);
arm64_l_15c0:
	/* 0x15c0: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_15c4:
	/* 0x15c4: mov x0, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_15c8:
	/* 0x15c8: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_15cc:
	/* 0x15cc: bl 3410 <native_bpf_strncasestr> */
	ARM64_SIM_A64_CALL(arm64_l_3410, 0x15d0ULL);
arm64_l_15d0:
	/* 0x15d0: tbz w0, #31, 23e0 <generic_fentry_filter_arg+0x23e0> */
	ARM64_SIM_A64_TBZ(ARM64_X0, 31, 0x15d0, 0x23e0, arm64_l_23e0);
arm64_l_15d4:
	/* 0x15d4: ldr w8, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_15d8:
	/* 0x15d8: add x19, x19, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_15dc:
	/* 0x15dc: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_15e0:
	/* 0x15e0: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_15e4:
	/* 0x15e4: sub w9, w19, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_15e8:
	/* 0x15e8: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_15ec:
	/* 0x15ec: b.cs 3390 <generic_fentry_filter_arg+0x3390> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x15ec, 0x3390, arm64_l_3390);
arm64_l_15f0:
	/* 0x15f0: cmp x19, #0x1a0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 416ULL);
arm64_l_15f4:
	/* 0x15f4: b.ne 159c <generic_fentry_filter_arg+0x159c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x15f4, 0x159c, arm64_l_159c);
arm64_l_15f8:
	/* 0x15f8: b 3390 <generic_fentry_filter_arg+0x3390> */
	ARM64_SIM_A64_JMP(0x15f8, 0x3390, arm64_l_3390);
arm64_l_15fc:
	/* 0x15fc: mov x25, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1600:
	/* 0x1600: cmp w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1604:
	/* 0x1604: b.ne fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1604, 0xfc, arm64_l_fc);
arm64_l_1608:
	/* 0x1608: ldr w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_160c:
	/* 0x160c: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1610:
	/* 0x1610: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_22));
arm64_l_1614:
	/* 0x1614: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1618:
	/* 0x1618: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_161c:
	/* 0x161c: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1620:
	/* 0x1620: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1624:
	/* 0x1624: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1628:
	/* 0x1628: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x162cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_162c:
	/* 0x162c: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1630:
	/* 0x1630: cbz w29, 1fa0 <generic_fentry_filter_arg+0x1fa0> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x1630, 0x1fa0, arm64_l_1fa0);
arm64_l_1634:
	/* 0x1634: cbz x0, 1fa0 <generic_fentry_filter_arg+0x1fa0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1634, 0x1fa0, arm64_l_1fa0);
arm64_l_1638:
	/* 0x1638: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_163c:
	/* 0x163c: adrp x0, 0 <string_prefix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap_23));
arm64_l_1640:
	/* 0x1640: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1644:
	/* 0x1644: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1648:
	/* 0x1648: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_164c:
	/* 0x164c: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1650:
	/* 0x1650: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1654ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1654:
	/* 0x1654: cbz x0, 1f98 <generic_fentry_filter_arg+0x1f98> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1654, 0x1f98, arm64_l_1f98);
arm64_l_1658:
	/* 0x1658: lsl w9, w29, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_165c:
	/* 0x165c: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1660:
	/* 0x1660: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1664:
	/* 0x1664: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1668:
	/* 0x1668: str w9, [x8], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_166c:
	/* 0x166c: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1670:
	/* 0x1670: mov x25, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1674:
	/* 0x1674: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1678:
	/* 0x1678: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x167cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_167c:
	/* 0x167c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1680:
	/* 0x1680: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1684:
	/* 0x1684: mov x1, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1688:
	/* 0x1688: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x168cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_168c:
	/* 0x168c: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1690:
	/* 0x1690: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1694:
	/* 0x1694: b 1f9c <generic_fentry_filter_arg+0x1f9c> */
	ARM64_SIM_A64_JMP(0x1694, 0x1f9c, arm64_l_1f9c);
arm64_l_1698:
	/* 0x1698: mov w13, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_169c:
	/* 0x169c: sub w8, w13, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_16a0:
	/* 0x16a0: ror w8, w8, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_ROR), 8ULL);
arm64_l_16a4:
	/* 0x16a4: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_16a8:
	/* 0x16a8: b.gt 1a9c <generic_fentry_filter_arg+0x1a9c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x16a8, 0x1a9c, arm64_l_1a9c);
arm64_l_16ac:
	/* 0x16ac: cbz w8, 2088 <generic_fentry_filter_arg+0x2088> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x16ac, 0x2088, arm64_l_2088);
arm64_l_16b0:
	/* 0x16b0: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_16b4:
	/* 0x16b4: b.ne 2080 <generic_fentry_filter_arg+0x2080> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x16b4, 0x2080, arm64_l_2080);
arm64_l_16b8:
	/* 0x16b8: mov w11, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 7ULL);
arm64_l_16bc:
	/* 0x16bc: b 2094 <generic_fentry_filter_arg+0x2094> */
	ARM64_SIM_A64_JMP(0x16bc, 0x2094, arm64_l_2094);
arm64_l_16c0:
	/* 0x16c0: ldrb w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_16c4:
	/* 0x16c4: ldrh w19, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_16c8:
	/* 0x16c8: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_16cc:
	/* 0x16cc: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_16d0:
	/* 0x16d0: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_16d4:
	/* 0x16d4: str w8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_16d8:
	/* 0x16d8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_16dc:
	/* 0x16dc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_16e0:
	/* 0x16e0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x16e4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_16e4:
	/* 0x16e4: cbz x0, 1e14 <generic_fentry_filter_arg+0x1e14> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x16e4, 0x1e14, arm64_l_1e14);
arm64_l_16e8:
	/* 0x16e8: str x19, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_16ec:
	/* 0x16ec: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_16f0:
	/* 0x16f0: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_16f4:
	/* 0x16f4: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_16f8:
	/* 0x16f8: b 1db8 <generic_fentry_filter_arg+0x1db8> */
	ARM64_SIM_A64_JMP(0x16f8, 0x1db8, arm64_l_1db8);
arm64_l_16fc:
	/* 0x16fc: ldr w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1700:
	/* 0x1700: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1704:
	/* 0x1704: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_22));
arm64_l_1708:
	/* 0x1708: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_170c:
	/* 0x170c: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1710:
	/* 0x1710: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1714:
	/* 0x1714: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1718:
	/* 0x1718: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_171c:
	/* 0x171c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1720ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1720:
	/* 0x1720: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1724:
	/* 0x1724: cbz w25, 338c <generic_fentry_filter_arg+0x338c> */
	ARM64_SIM_A64_CBZ(ARM64_X25, 0x1724, 0x338c, arm64_l_338c);
arm64_l_1728:
	/* 0x1728: cbz x0, 338c <generic_fentry_filter_arg+0x338c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1728, 0x338c, arm64_l_338c);
arm64_l_172c:
	/* 0x172c: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1730:
	/* 0x1730: adrp x0, 0 <string_prefix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap_23));
arm64_l_1734:
	/* 0x1734: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1738:
	/* 0x1738: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_173c:
	/* 0x173c: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1740:
	/* 0x1740: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1744:
	/* 0x1744: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1748ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1748:
	/* 0x1748: cbz x0, 3388 <generic_fentry_filter_arg+0x3388> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1748, 0x3388, arm64_l_3388);
arm64_l_174c:
	/* 0x174c: cmp w25, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1750:
	/* 0x1750: mov w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 255ULL);
arm64_l_1754:
	/* 0x1754: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1758:
	/* 0x1758: mov x2, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_175c:
	/* 0x175c: csel w1, w25, w8, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X1, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_1760:
	/* 0x1760: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1764:
	/* 0x1764: lsl w9, w1, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_1768:
	/* 0x1768: str w9, [x8], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_176c:
	/* 0x176c: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1770:
	/* 0x1770: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1774:
	/* 0x1774: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1778ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1778:
	/* 0x1778: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_177c:
	/* 0x177c: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1780:
	/* 0x1780: mov x1, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1784:
	/* 0x1784: b 3378 <generic_fentry_filter_arg+0x3378> */
	ARM64_SIM_A64_JMP(0x1784, 0x3378, arm64_l_3378);
arm64_l_1788:
	/* 0x1788: cmp w25, #0x1, lsl #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_178c:
	/* 0x178c: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1790:
	/* 0x1790: b.ls 1cb4 <generic_fentry_filter_arg+0x1cb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1790, 0x1cb4, arm64_l_1cb4);
arm64_l_1794:
	/* 0x1794: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1798:
	/* 0x1798: b 3390 <generic_fentry_filter_arg+0x3390> */
	ARM64_SIM_A64_JMP(0x1798, 0x3390, arm64_l_3390);
arm64_l_179c:
	/* 0x179c: ldr x8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17a0:
	/* 0x17a0: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17a4:
	/* 0x17a4: b.hi 17b0 <generic_fentry_filter_arg+0x17b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x17a4, 0x17b0, arm64_l_17b0);
arm64_l_17a8:
	/* 0x17a8: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17ac:
	/* 0x17ac: b.ls 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x17ac, 0x298, arm64_l_298);
arm64_l_17b0:
	/* 0x17b0: ldr w10, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_17b4:
	/* 0x17b4: cmp w10, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_17b8:
	/* 0x17b8: b.cc fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x17b8, 0xfc, arm64_l_fc);
arm64_l_17bc:
	/* 0x17bc: ldp x12, x11, [x23, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_17c0:
	/* 0x17c0: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_17c4:
	/* 0x17c4: b.eq 17d0 <generic_fentry_filter_arg+0x17d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x17c4, 0x17d0, arm64_l_17d0);
arm64_l_17c8:
	/* 0x17c8: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_17cc:
	/* 0x17cc: b.ne 1e24 <generic_fentry_filter_arg+0x1e24> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x17cc, 0x1e24, arm64_l_1e24);
arm64_l_17d0:
	/* 0x17d0: cmp x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17d4:
	/* 0x17d4: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_17d8:
	/* 0x17d8: b.gt 1e38 <generic_fentry_filter_arg+0x1e38> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x17d8, 0x1e38, arm64_l_1e38);
arm64_l_17dc:
	/* 0x17dc: cmp x8, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17e0:
	/* 0x17e0: b.le 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x17e0, 0x298, arm64_l_298);
arm64_l_17e4:
	/* 0x17e4: b 1e38 <generic_fentry_filter_arg+0x1e38> */
	ARM64_SIM_A64_JMP(0x17e4, 0x1e38, arm64_l_1e38);
arm64_l_17e8:
	/* 0x17e8: ldr x10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17ec:
	/* 0x17ec: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17f0:
	/* 0x17f0: ccmp x10, x8, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_17f4:
	/* 0x17f4: cset w8, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_17f8:
	/* 0x17f8: ldr w11, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_17fc:
	/* 0x17fc: cmp w11, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_1800:
	/* 0x1800: b.cc 2894 <generic_fentry_filter_arg+0x2894> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1800, 0x2894, arm64_l_2894);
arm64_l_1804:
	/* 0x1804: ldp x13, x12, [x23, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X13, ARM64_X12, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1808:
	/* 0x1808: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_180c:
	/* 0x180c: b.eq 1818 <generic_fentry_filter_arg+0x1818> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x180c, 0x1818, arm64_l_1818);
arm64_l_1810:
	/* 0x1810: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1814:
	/* 0x1814: b.ne 1d24 <generic_fentry_filter_arg+0x1d24> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1814, 0x1d24, arm64_l_1d24);
arm64_l_1818:
	/* 0x1818: cmp x13, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_181c:
	/* 0x181c: ccmp x10, x12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_1820:
	/* 0x1820: cset w12, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_1824:
	/* 0x1824: b 1d30 <generic_fentry_filter_arg+0x1d30> */
	ARM64_SIM_A64_JMP(0x1824, 0x1d30, arm64_l_1d30);
arm64_l_1828:
	/* 0x1828: ldrh w22, [x25, #38] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 38ULL);
arm64_l_182c:
	/* 0x182c: ldrb w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1830:
	/* 0x1830: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_1834:
	/* 0x1834: add x9, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1838:
	/* 0x1838: add x1, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_183c:
	/* 0x183c: str w8, [sp, #172] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 172ULL);
arm64_l_1840:
	/* 0x1840: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1844:
	/* 0x1844: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1848:
	/* 0x1848: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x184cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_184c:
	/* 0x184c: cbz x0, 1898 <generic_fentry_filter_arg+0x1898> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x184c, 0x1898, arm64_l_1898);
arm64_l_1850:
	/* 0x1850: str x22, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1854:
	/* 0x1854: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1858:
	/* 0x1858: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_185c:
	/* 0x185c: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1860:
	/* 0x1860: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1864ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1864:
	/* 0x1864: ldr w9, [x23, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1868:
	/* 0x1868: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_186c:
	/* 0x186c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1870:
	/* 0x1870: cmp w9, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_1874:
	/* 0x1874: b.hi 1e00 <generic_fentry_filter_arg+0x1e00> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1874, 0x1e00, arm64_l_1e00);
arm64_l_1878:
	/* 0x1878: mov w10, #0x8400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 33792ULL);
arm64_l_187c:
	/* 0x187c: lsl w9, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1880:
	/* 0x1880: movk w10, #0x3003, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 12291ULL);
arm64_l_1884:
	/* 0x1884: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1888:
	/* 0x1888: b.eq 1de8 <generic_fentry_filter_arg+0x1de8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1888, 0x1de8, arm64_l_1de8);
arm64_l_188c:
	/* 0x188c: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1890:
	/* 0x1890: cset w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1894:
	/* 0x1894: b 1e00 <generic_fentry_filter_arg+0x1e00> */
	ARM64_SIM_A64_JMP(0x1894, 0x1e00, arm64_l_1e00);
arm64_l_1898:
	/* 0x1898: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_189c:
	/* 0x189c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_18a0:
	/* 0x18a0: b 1e04 <generic_fentry_filter_arg+0x1e04> */
	ARM64_SIM_A64_JMP(0x18a0, 0x1e04, arm64_l_1e04);
arm64_l_18a4:
	/* 0x18a4: cmp w8, #0x101 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 257ULL);
arm64_l_18a8:
	/* 0x18a8: b.cs 1f84 <generic_fentry_filter_arg+0x1f84> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x18a8, 0x1f84, arm64_l_1f84);
arm64_l_18ac:
	/* 0x18ac: mov w11, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_18b0:
	/* 0x18b0: b 2928 <generic_fentry_filter_arg+0x2928> */
	ARM64_SIM_A64_JMP(0x18b0, 0x2928, arm64_l_2928);
arm64_l_18b4:
	/* 0x18b4: ldr x11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18b8:
	/* 0x18b8: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_18bc:
	/* 0x18bc: b.hi 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x18bc, 0x298, arm64_l_298);
arm64_l_18c0:
	/* 0x18c0: b 18d0 <generic_fentry_filter_arg+0x18d0> */
	ARM64_SIM_A64_JMP(0x18c0, 0x18d0, arm64_l_18d0);
arm64_l_18c4:
	/* 0x18c4: ldr x11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18c8:
	/* 0x18c8: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_18cc:
	/* 0x18cc: b.cc 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x18cc, 0x298, arm64_l_298);
arm64_l_18d0:
	/* 0x18d0: ldr w10, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_18d4:
	/* 0x18d4: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_18d8:
	/* 0x18d8: b.cc 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x18d8, 0x3400, arm64_l_3400);
arm64_l_18dc:
	/* 0x18dc: ldr x11, [x23, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_18e0:
	/* 0x18e0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_18e4:
	/* 0x18e4: b.le 1908 <generic_fentry_filter_arg+0x1908> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x18e4, 0x1908, arm64_l_1908);
arm64_l_18e8:
	/* 0x18e8: sub w12, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_18ec:
	/* 0x18ec: cmp w12, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_18f0:
	/* 0x18f0: b.cs 193c <generic_fentry_filter_arg+0x193c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x18f0, 0x193c, arm64_l_193c);
arm64_l_18f4:
	/* 0x18f4: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18f8:
	/* 0x18f8: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_18fc:
	/* 0x18fc: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1900:
	/* 0x1900: b.eq 28c <generic_fentry_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1900, 0x28c, arm64_l_28c);
arm64_l_1904:
	/* 0x1904: b 2328 <generic_fentry_filter_arg+0x2328> */
	ARM64_SIM_A64_JMP(0x1904, 0x2328, arm64_l_2328);
arm64_l_1908:
	/* 0x1908: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_190c:
	/* 0x190c: b.eq 19e8 <generic_fentry_filter_arg+0x19e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x190c, 0x19e8, arm64_l_19e8);
arm64_l_1910:
	/* 0x1910: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1914:
	/* 0x1914: b.ne 2328 <generic_fentry_filter_arg+0x2328> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1914, 0x2328, arm64_l_2328);
arm64_l_1918:
	/* 0x1918: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_191c:
	/* 0x191c: b.eq 1928 <generic_fentry_filter_arg+0x1928> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x191c, 0x1928, arm64_l_1928);
arm64_l_1920:
	/* 0x1920: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1924:
	/* 0x1924: b.ne 2318 <generic_fentry_filter_arg+0x2318> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1924, 0x2318, arm64_l_2318);
arm64_l_1928:
	/* 0x1928: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_192c:
	/* 0x192c: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1930:
	/* 0x1930: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1934:
	/* 0x1934: b.lt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x1934, 0x298, arm64_l_298);
arm64_l_1938:
	/* 0x1938: b 2328 <generic_fentry_filter_arg+0x2328> */
	ARM64_SIM_A64_JMP(0x1938, 0x2328, arm64_l_2328);
arm64_l_193c:
	/* 0x193c: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1940:
	/* 0x1940: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1944:
	/* 0x1944: b.ne 2328 <generic_fentry_filter_arg+0x2328> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1944, 0x2328, arm64_l_2328);
arm64_l_1948:
	/* 0x1948: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_194c:
	/* 0x194c: tst x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1950:
	/* 0x1950: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1954:
	/* 0x1954: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1954, 0x298, arm64_l_298);
arm64_l_1958:
	/* 0x1958: b 2328 <generic_fentry_filter_arg+0x2328> */
	ARM64_SIM_A64_JMP(0x1958, 0x2328, arm64_l_2328);
arm64_l_195c:
	/* 0x195c: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1960:
	/* 0x1960: b.ne 1ae4 <generic_fentry_filter_arg+0x1ae4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1960, 0x1ae4, arm64_l_1ae4);
arm64_l_1964:
	/* 0x1964: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1968:
	/* 0x1968: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_196c:
	/* 0x196c: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x196c, 0x298, arm64_l_298);
arm64_l_1970:
	/* 0x1970: b 1ae4 <generic_fentry_filter_arg+0x1ae4> */
	ARM64_SIM_A64_JMP(0x1970, 0x1ae4, arm64_l_1ae4);
arm64_l_1974:
	/* 0x1974: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1978:
	/* 0x1978: b.ne 1b24 <generic_fentry_filter_arg+0x1b24> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1978, 0x1b24, arm64_l_1b24);
arm64_l_197c:
	/* 0x197c: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1980:
	/* 0x1980: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1984:
	/* 0x1984: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1984, 0x298, arm64_l_298);
arm64_l_1988:
	/* 0x1988: b 1b24 <generic_fentry_filter_arg+0x1b24> */
	ARM64_SIM_A64_JMP(0x1988, 0x1b24, arm64_l_1b24);
arm64_l_198c:
	/* 0x198c: ldr w9, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1990:
	/* 0x1990: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1994:
	/* 0x1994: b.cc 7bc <generic_fentry_filter_arg+0x7bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1994, 0x7bc, arm64_l_7bc);
arm64_l_1998:
	/* 0x1998: ldr w10, [x23, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_199c:
	/* 0x199c: cbz w10, 7bc <generic_fentry_filter_arg+0x7bc> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x199c, 0x7bc, arm64_l_7bc);
arm64_l_19a0:
	/* 0x19a0: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19a4:
	/* 0x19a4: b.eq 600 <generic_fentry_filter_arg+0x600> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x19a4, 0x600, arm64_l_600);
arm64_l_19a8:
	/* 0x19a8: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_19ac:
	/* 0x19ac: b.cc 7bc <generic_fentry_filter_arg+0x7bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x19ac, 0x7bc, arm64_l_7bc);
arm64_l_19b0:
	/* 0x19b0: ldr w10, [x23, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_19b4:
	/* 0x19b4: cbz w10, 7bc <generic_fentry_filter_arg+0x7bc> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x19b4, 0x7bc, arm64_l_7bc);
arm64_l_19b8:
	/* 0x19b8: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19bc:
	/* 0x19bc: b.eq 600 <generic_fentry_filter_arg+0x600> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x19bc, 0x600, arm64_l_600);
arm64_l_19c0:
	/* 0x19c0: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_19c4:
	/* 0x19c4: b.cc 19dc <generic_fentry_filter_arg+0x19dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x19c4, 0x19dc, arm64_l_19dc);
arm64_l_19c8:
	/* 0x19c8: ldr w9, [x23, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_19cc:
	/* 0x19cc: cbz w9, 19dc <generic_fentry_filter_arg+0x19dc> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x19cc, 0x19dc, arm64_l_19dc);
arm64_l_19d0:
	/* 0x19d0: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19d4:
	/* 0x19d4: cset w22, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_19d8:
	/* 0x19d8: b 19e0 <generic_fentry_filter_arg+0x19e0> */
	ARM64_SIM_A64_JMP(0x19d8, 0x19e0, arm64_l_19e0);
arm64_l_19dc:
	/* 0x19dc: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_19e0:
	/* 0x19e0: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_19e4:
	/* 0x19e4: b 2df0 <generic_fentry_filter_arg+0x2df0> */
	ARM64_SIM_A64_JMP(0x19e4, 0x2df0, arm64_l_2df0);
arm64_l_19e8:
	/* 0x19e8: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_19ec:
	/* 0x19ec: b.eq 19f8 <generic_fentry_filter_arg+0x19f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x19ec, 0x19f8, arm64_l_19f8);
arm64_l_19f0:
	/* 0x19f0: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_19f4:
	/* 0x19f4: b.ne 2304 <generic_fentry_filter_arg+0x2304> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x19f4, 0x2304, arm64_l_2304);
arm64_l_19f8:
	/* 0x19f8: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19fc:
	/* 0x19fc: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a00:
	/* 0x1a00: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1a04:
	/* 0x1a04: b.gt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1a04, 0x298, arm64_l_298);
arm64_l_1a08:
	/* 0x1a08: b 2328 <generic_fentry_filter_arg+0x2328> */
	ARM64_SIM_A64_JMP(0x1a08, 0x2328, arm64_l_2328);
arm64_l_1a0c:
	/* 0x1a0c: ldp w8, w11, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1a10:
	/* 0x1a10: ldrb w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a14:
	/* 0x1a14: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a18:
	/* 0x1a18: ldr w10, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1a1c:
	/* 0x1a1c: ccmp w11, w9, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_1a20:
	/* 0x1a20: cset w8, cs */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CS, 0);
arm64_l_1a24:
	/* 0x1a24: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1a28:
	/* 0x1a28: b.cc 2b68 <generic_fentry_filter_arg+0x2b68> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1a28, 0x2b68, arm64_l_2b68);
arm64_l_1a2c:
	/* 0x1a2c: b 1a50 <generic_fentry_filter_arg+0x1a50> */
	ARM64_SIM_A64_JMP(0x1a2c, 0x1a50, arm64_l_1a50);
arm64_l_1a30:
	/* 0x1a30: ldp w8, w11, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1a34:
	/* 0x1a34: ldrh w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a38:
	/* 0x1a38: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a3c:
	/* 0x1a3c: ldr w10, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1a40:
	/* 0x1a40: ccmp w11, w9, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_1a44:
	/* 0x1a44: cset w8, cs */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CS, 0);
arm64_l_1a48:
	/* 0x1a48: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1a4c:
	/* 0x1a4c: b.cc 2b68 <generic_fentry_filter_arg+0x2b68> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1a4c, 0x2b68, arm64_l_2b68);
arm64_l_1a50:
	/* 0x1a50: ldp w11, w12, [x23, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X12, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1a54:
	/* 0x1a54: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a58:
	/* 0x1a58: ccmp w12, w9, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_1a5c:
	/* 0x1a5c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1a60:
	/* 0x1a60: csinc w8, w8, wzr, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X8, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_1a64:
	/* 0x1a64: cmp w10, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_1a68:
	/* 0x1a68: b.cc 2b68 <generic_fentry_filter_arg+0x2b68> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1a68, 0x2b68, arm64_l_2b68);
arm64_l_1a6c:
	/* 0x1a6c: ldp w11, w12, [x23, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X12, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1a70:
	/* 0x1a70: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a74:
	/* 0x1a74: ccmp w12, w9, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_1a78:
	/* 0x1a78: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1a7c:
	/* 0x1a7c: csinc w8, w8, wzr, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X8, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_1a80:
	/* 0x1a80: cmp w10, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_1a84:
	/* 0x1a84: b.cc 2b68 <generic_fentry_filter_arg+0x2b68> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1a84, 0x2b68, arm64_l_2b68);
arm64_l_1a88:
	/* 0x1a88: ldp w10, w11, [x23, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1a8c:
	/* 0x1a8c: cmp w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a90:
	/* 0x1a90: ccmp w11, w9, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_1a94:
	/* 0x1a94: csinc w8, w8, wzr, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X8, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_1a98:
	/* 0x1a98: b 2b68 <generic_fentry_filter_arg+0x2b68> */
	ARM64_SIM_A64_JMP(0x1a98, 0x2b68, arm64_l_2b68);
arm64_l_1a9c:
	/* 0x1a9c: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1aa0:
	/* 0x1aa0: b.eq 2090 <generic_fentry_filter_arg+0x2090> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1aa0, 0x2090, arm64_l_2090);
arm64_l_1aa4:
	/* 0x1aa4: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_1aa8:
	/* 0x1aa8: b.ne 2080 <generic_fentry_filter_arg+0x2080> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1aa8, 0x2080, arm64_l_2080);
arm64_l_1aac:
	/* 0x1aac: mov w11, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 9ULL);
arm64_l_1ab0:
	/* 0x1ab0: b 2094 <generic_fentry_filter_arg+0x2094> */
	ARM64_SIM_A64_JMP(0x1ab0, 0x2094, arm64_l_2094);
arm64_l_1ab4:
	/* 0x1ab4: and w8, w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1ab8:
	/* 0x1ab8: cmp w8, #0x201 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 513ULL);
arm64_l_1abc:
	/* 0x1abc: b.cs 2018 <generic_fentry_filter_arg+0x2018> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1abc, 0x2018, arm64_l_2018);
arm64_l_1ac0:
	/* 0x1ac0: mov w11, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 512ULL);
arm64_l_1ac4:
	/* 0x1ac4: b 245c <generic_fentry_filter_arg+0x245c> */
	ARM64_SIM_A64_JMP(0x1ac4, 0x245c, arm64_l_245c);
arm64_l_1ac8:
	/* 0x1ac8: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1acc:
	/* 0x1acc: b 1e84 <generic_fentry_filter_arg+0x1e84> */
	ARM64_SIM_A64_JMP(0x1acc, 0x1e84, arm64_l_1e84);
arm64_l_1ad0:
	/* 0x1ad0: mov w22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ad4:
	/* 0x1ad4: b 12b4 <generic_fentry_filter_arg+0x12b4> */
	ARM64_SIM_A64_JMP(0x1ad4, 0x12b4, arm64_l_12b4);
arm64_l_1ad8:
	/* 0x1ad8: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1adc:
	/* 0x1adc: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ae0:
	/* 0x1ae0: b.cc 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1ae0, 0x298, arm64_l_298);
arm64_l_1ae4:
	/* 0x1ae4: ldr w9, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1ae8:
	/* 0x1ae8: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1aec:
	/* 0x1aec: b.cc 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1aec, 0x3400, arm64_l_3400);
arm64_l_1af0:
	/* 0x1af0: ldr w10, [x23, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1af4:
	/* 0x1af4: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1af8:
	/* 0x1af8: b.le 1fd8 <generic_fentry_filter_arg+0x1fd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1af8, 0x1fd8, arm64_l_1fd8);
arm64_l_1afc:
	/* 0x1afc: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1b00:
	/* 0x1b00: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1b04:
	/* 0x1b04: b.cs 23b0 <generic_fentry_filter_arg+0x23b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1b04, 0x23b0, arm64_l_23b0);
arm64_l_1b08:
	/* 0x1b08: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b0c:
	/* 0x1b0c: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b10:
	/* 0x1b10: b.eq 28c <generic_fentry_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1b10, 0x28c, arm64_l_28c);
arm64_l_1b14:
	/* 0x1b14: b 2664 <generic_fentry_filter_arg+0x2664> */
	ARM64_SIM_A64_JMP(0x1b14, 0x2664, arm64_l_2664);
arm64_l_1b18:
	/* 0x1b18: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b1c:
	/* 0x1b1c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b20:
	/* 0x1b20: b.cc 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1b20, 0x298, arm64_l_298);
arm64_l_1b24:
	/* 0x1b24: ldr w9, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1b28:
	/* 0x1b28: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1b2c:
	/* 0x1b2c: b.cc 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1b2c, 0x3400, arm64_l_3400);
arm64_l_1b30:
	/* 0x1b30: ldr w10, [x23, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1b34:
	/* 0x1b34: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1b38:
	/* 0x1b38: b.le 1ff8 <generic_fentry_filter_arg+0x1ff8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1b38, 0x1ff8, arm64_l_1ff8);
arm64_l_1b3c:
	/* 0x1b3c: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1b40:
	/* 0x1b40: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1b44:
	/* 0x1b44: b.cs 23c8 <generic_fentry_filter_arg+0x23c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1b44, 0x23c8, arm64_l_23c8);
arm64_l_1b48:
	/* 0x1b48: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b4c:
	/* 0x1b4c: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b50:
	/* 0x1b50: b.eq 28c <generic_fentry_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1b50, 0x28c, arm64_l_28c);
arm64_l_1b54:
	/* 0x1b54: b 26a0 <generic_fentry_filter_arg+0x26a0> */
	ARM64_SIM_A64_JMP(0x1b54, 0x26a0, arm64_l_26a0);
arm64_l_1b58:
	/* 0x1b58: ldr w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b5c:
	/* 0x1b5c: cmp w11, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b60:
	/* 0x1b60: b.hi 1b6c <generic_fentry_filter_arg+0x1b6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1b60, 0x1b6c, arm64_l_1b6c);
arm64_l_1b64:
	/* 0x1b64: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b68:
	/* 0x1b68: b.ls 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1b68, 0x298, arm64_l_298);
arm64_l_1b6c:
	/* 0x1b6c: ldr w10, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1b70:
	/* 0x1b70: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1b74:
	/* 0x1b74: b.cc fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1b74, 0xfc, arm64_l_fc);
arm64_l_1b78:
	/* 0x1b78: ldp w12, w11, [x23, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1b7c:
	/* 0x1b7c: mov w13, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1b80:
	/* 0x1b80: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1b84:
	/* 0x1b84: b.hi 2220 <generic_fentry_filter_arg+0x2220> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1b84, 0x2220, arm64_l_2220);
arm64_l_1b88:
	/* 0x1b88: lsl w13, w13, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X13, ARM64_X13, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1b8c:
	/* 0x1b8c: mov w14, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1b90:
	/* 0x1b90: tst w13, w14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X13, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b94:
	/* 0x1b94: b.eq 2220 <generic_fentry_filter_arg+0x2220> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1b94, 0x2220, arm64_l_2220);
arm64_l_1b98:
	/* 0x1b98: cmp w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b9c:
	/* 0x1b9c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ba0:
	/* 0x1ba0: b.gt 2234 <generic_fentry_filter_arg+0x2234> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1ba0, 0x2234, arm64_l_2234);
arm64_l_1ba4:
	/* 0x1ba4: cmp w8, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ba8:
	/* 0x1ba8: b.le 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1ba8, 0x298, arm64_l_298);
arm64_l_1bac:
	/* 0x1bac: b 2234 <generic_fentry_filter_arg+0x2234> */
	ARM64_SIM_A64_JMP(0x1bac, 0x2234, arm64_l_2234);
arm64_l_1bb0:
	/* 0x1bb0: ldr w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1bb4:
	/* 0x1bb4: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1bb8:
	/* 0x1bb8: ccmp w10, w8, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_1bbc:
	/* 0x1bbc: cset w8, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_1bc0:
	/* 0x1bc0: ldr w11, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1bc4:
	/* 0x1bc4: cmp w11, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1bc8:
	/* 0x1bc8: b.cc 2b68 <generic_fentry_filter_arg+0x2b68> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1bc8, 0x2b68, arm64_l_2b68);
arm64_l_1bcc:
	/* 0x1bcc: ldp w13, w12, [x23, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X13, ARM64_X12, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1bd0:
	/* 0x1bd0: mov w14, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1bd4:
	/* 0x1bd4: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1bd8:
	/* 0x1bd8: b.hi 2028 <generic_fentry_filter_arg+0x2028> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1bd8, 0x2028, arm64_l_2028);
arm64_l_1bdc:
	/* 0x1bdc: lsl w14, w14, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X14, ARM64_X14, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1be0:
	/* 0x1be0: mov w1, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1be4:
	/* 0x1be4: tst w14, w1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X14, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1be8:
	/* 0x1be8: b.eq 2028 <generic_fentry_filter_arg+0x2028> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1be8, 0x2028, arm64_l_2028);
arm64_l_1bec:
	/* 0x1bec: cmp w13, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1bf0:
	/* 0x1bf0: ccmp w10, w12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_1bf4:
	/* 0x1bf4: cset w12, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_1bf8:
	/* 0x1bf8: b 2034 <generic_fentry_filter_arg+0x2034> */
	ARM64_SIM_A64_JMP(0x1bf8, 0x2034, arm64_l_2034);
arm64_l_1bfc:
	/* 0x1bfc: str x29, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1c00:
	/* 0x1c00: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c04:
	/* 0x1c04: mov w22, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1c08:
	/* 0x1c08: add x29, x23, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1c0c:
	/* 0x1c0c: ldr w8, [x29, x19, lsl #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X19, ARM64_MOD_LSL, 2, 0), 0ULL);
arm64_l_1c10:
	/* 0x1c10: adrp x0, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_24));
arm64_l_1c14:
	/* 0x1c14: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1c18:
	/* 0x1c18: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1c1c:
	/* 0x1c1c: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1c20:
	/* 0x1c20: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1c24:
	/* 0x1c24: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c28:
	/* 0x1c28: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1c2cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1c2c:
	/* 0x1c2c: cbz x0, 3388 <generic_fentry_filter_arg+0x3388> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1c2c, 0x3388, arm64_l_3388);
arm64_l_1c30:
	/* 0x1c30: cbz w25, 1c90 <generic_fentry_filter_arg+0x1c90> */
	ARM64_SIM_A64_CBZ(ARM64_X25, 0x1c30, 0x1c90, arm64_l_1c90);
arm64_l_1c34:
	/* 0x1c34: ldr x9, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1c38:
	/* 0x1c38: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c3c:
	/* 0x1c3c: mov x10, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c40:
	/* 0x1c40: b 1c58 <generic_fentry_filter_arg+0x1c58> */
	ARM64_SIM_A64_JMP(0x1c40, 0x1c58, arm64_l_1c58);
arm64_l_1c44:
	/* 0x1c44: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1c48:
	/* 0x1c48: sub x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1c4c:
	/* 0x1c4c: add x9, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1c50:
	/* 0x1c50: cmp x8, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c54:
	/* 0x1c54: b.eq 1c90 <generic_fentry_filter_arg+0x1c90> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c54, 0x1c90, arm64_l_1c90);
arm64_l_1c58:
	/* 0x1c58: mov x11, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c5c:
	/* 0x1c5c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c60:
	/* 0x1c60: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c64:
	/* 0x1c64: b.eq 1c44 <generic_fentry_filter_arg+0x1c44> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c64, 0x1c44, arm64_l_1c44);
arm64_l_1c68:
	/* 0x1c68: ldrb w12, [x0, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X0, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c6c:
	/* 0x1c6c: cbz w12, 1c8c <generic_fentry_filter_arg+0x1c8c> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0x1c6c, 0x1c8c, arm64_l_1c8c);
arm64_l_1c70:
	/* 0x1c70: cmp x11, #0x62 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 98ULL);
arm64_l_1c74:
	/* 0x1c74: b.hi 1c44 <generic_fentry_filter_arg+0x1c44> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1c74, 0x1c44, arm64_l_1c44);
arm64_l_1c78:
	/* 0x1c78: ldrb w13, [x9, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c7c:
	/* 0x1c7c: add x11, x11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1c80:
	/* 0x1c80: cmp w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c84:
	/* 0x1c84: b.eq 1c60 <generic_fentry_filter_arg+0x1c60> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c84, 0x1c60, arm64_l_1c60);
arm64_l_1c88:
	/* 0x1c88: b 1c44 <generic_fentry_filter_arg+0x1c44> */
	ARM64_SIM_A64_JMP(0x1c88, 0x1c44, arm64_l_1c44);
arm64_l_1c8c:
	/* 0x1c8c: tbz w8, #31, 23e0 <generic_fentry_filter_arg+0x23e0> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 31, 0x1c8c, 0x23e0, arm64_l_23e0);
arm64_l_1c90:
	/* 0x1c90: ldr w9, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1c94:
	/* 0x1c94: add w8, w22, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1c98:
	/* 0x1c98: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c9c:
	/* 0x1c9c: b.cs 3388 <generic_fentry_filter_arg+0x3388> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1c9c, 0x3388, arm64_l_3388);
arm64_l_1ca0:
	/* 0x1ca0: add x19, x19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1ca4:
	/* 0x1ca4: add w22, w22, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1ca8:
	/* 0x1ca8: cmp x19, #0x64 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 100ULL);
arm64_l_1cac:
	/* 0x1cac: b.ne 1c0c <generic_fentry_filter_arg+0x1c0c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1cac, 0x1c0c, arm64_l_1c0c);
arm64_l_1cb0:
	/* 0x1cb0: b 3388 <generic_fentry_filter_arg+0x3388> */
	ARM64_SIM_A64_JMP(0x1cb0, 0x3388, arm64_l_3388);
arm64_l_1cb4:
	/* 0x1cb4: and w8, w25, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1cb8:
	/* 0x1cb8: cmp w8, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1cbc:
	/* 0x1cbc: b.hi 2274 <generic_fentry_filter_arg+0x2274> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1cbc, 0x2274, arm64_l_2274);
arm64_l_1cc0:
	/* 0x1cc0: and w8, w25, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1cc4:
	/* 0x1cc4: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_1cc8:
	/* 0x1cc8: tst w25, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1ccc:
	/* 0x1ccc: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1cd0:
	/* 0x1cd0: mov w9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_1cd4:
	/* 0x1cd4: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_1cd8:
	/* 0x1cd8: msub w8, w8, w9, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MSUB, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_X25, ARM64_WIDTH_32, 0, 0);
arm64_l_1cdc:
	/* 0x1cdc: b.eq 1cf0 <generic_fentry_filter_arg+0x1cf0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1cdc, 0x1cf0, arm64_l_1cf0);
arm64_l_1ce0:
	/* 0x1ce0: tst w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1ce4:
	/* 0x1ce4: mov w9, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1ce8:
	/* 0x1ce8: mov w11, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1cec:
	/* 0x1cec: b.eq 1d0c <generic_fentry_filter_arg+0x1d0c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1cec, 0x1d0c, arm64_l_1d0c);
arm64_l_1cf0:
	/* 0x1cf0: sub w8, w25, w8, uxtb */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_UXTB, 0), 0);
arm64_l_1cf4:
	/* 0x1cf4: and w9, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1cf8:
	/* 0x1cf8: add w8, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1cfc:
	/* 0x1cfc: and w11, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1d00:
	/* 0x1d00: cmp w9, #0x78 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 120ULL);
arm64_l_1d04:
	/* 0x1d04: b.hi 307c <generic_fentry_filter_arg+0x307c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1d04, 0x307c, arm64_l_307c);
arm64_l_1d08:
	/* 0x1d08: mov w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1d0c:
	/* 0x1d0c: and w8, w9, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1d10:
	/* 0x1d10: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_1d14:
	/* 0x1d14: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1d18:
	/* 0x1d18: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_1d1c:
	/* 0x1d1c: sub w10, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1d20:
	/* 0x1d20: b 30cc <generic_fentry_filter_arg+0x30cc> */
	ARM64_SIM_A64_JMP(0x1d20, 0x30cc, arm64_l_30cc);
arm64_l_1d24:
	/* 0x1d24: cmp x13, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d28:
	/* 0x1d28: ccmp x10, x12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_1d2c:
	/* 0x1d2c: cset w12, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_1d30:
	/* 0x1d30: orr w8, w8, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1d34:
	/* 0x1d34: cmp w11, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1d38:
	/* 0x1d38: b.cc 2894 <generic_fentry_filter_arg+0x2894> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1d38, 0x2894, arm64_l_2894);
arm64_l_1d3c:
	/* 0x1d3c: ldp x13, x12, [x23, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X13, ARM64_X12, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1d40:
	/* 0x1d40: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1d44:
	/* 0x1d44: b.eq 1d50 <generic_fentry_filter_arg+0x1d50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d44, 0x1d50, arm64_l_1d50);
arm64_l_1d48:
	/* 0x1d48: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1d4c:
	/* 0x1d4c: b.ne 2284 <generic_fentry_filter_arg+0x2284> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1d4c, 0x2284, arm64_l_2284);
arm64_l_1d50:
	/* 0x1d50: cmp x13, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d54:
	/* 0x1d54: ccmp x10, x12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_1d58:
	/* 0x1d58: cset w12, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_1d5c:
	/* 0x1d5c: b 2290 <generic_fentry_filter_arg+0x2290> */
	ARM64_SIM_A64_JMP(0x1d5c, 0x2290, arm64_l_2290);
arm64_l_1d60:
	/* 0x1d60: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1d64:
	/* 0x1d64: cmp w9, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1d68:
	/* 0x1d68: b.ne 1d74 <generic_fentry_filter_arg+0x1d74> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1d68, 0x1d74, arm64_l_1d74);
arm64_l_1d6c:
	/* 0x1d6c: cbz x10, 1d74 <generic_fentry_filter_arg+0x1d74> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x1d6c, 0x1d74, arm64_l_1d74);
arm64_l_1d70:
	/* 0x1d70: ldrb w19, [x10, #58] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 58ULL);
arm64_l_1d74:
	/* 0x1d74: cmp w9, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1d78:
	/* 0x1d78: b.eq 1d84 <generic_fentry_filter_arg+0x1d84> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d78, 0x1d84, arm64_l_1d84);
arm64_l_1d7c:
	/* 0x1d7c: cmp w9, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_1d80:
	/* 0x1d80: b.ne 2074 <generic_fentry_filter_arg+0x2074> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1d80, 0x2074, arm64_l_2074);
arm64_l_1d84:
	/* 0x1d84: ldrb w8, [x23, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1d88:
	/* 0x1d88: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_1d8c:
	/* 0x1d8c: add x9, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1d90:
	/* 0x1d90: add x1, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1d94:
	/* 0x1d94: str w8, [sp, #172] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 172ULL);
arm64_l_1d98:
	/* 0x1d98: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1d9c:
	/* 0x1d9c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1da0:
	/* 0x1da0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1da4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1da4:
	/* 0x1da4: cbz x0, 1e14 <generic_fentry_filter_arg+0x1e14> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1da4, 0x1e14, arm64_l_1e14);
arm64_l_1da8:
	/* 0x1da8: str x19, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1dac:
	/* 0x1dac: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1db0:
	/* 0x1db0: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1db4:
	/* 0x1db4: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1db8:
	/* 0x1db8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1dbcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1dbc:
	/* 0x1dbc: ldr w9, [x23, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1dc0:
	/* 0x1dc0: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1dc4:
	/* 0x1dc4: cmp w9, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_1dc8:
	/* 0x1dc8: b.hi 2d34 <generic_fentry_filter_arg+0x2d34> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1dc8, 0x2d34, arm64_l_2d34);
arm64_l_1dcc:
	/* 0x1dcc: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1dd0:
	/* 0x1dd0: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1dd4:
	/* 0x1dd4: mov w10, #0x8400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 33792ULL);
arm64_l_1dd8:
	/* 0x1dd8: lsl w9, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1ddc:
	/* 0x1ddc: movk w10, #0x3003, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 12291ULL);
arm64_l_1de0:
	/* 0x1de0: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1de4:
	/* 0x1de4: b.ne 188c <generic_fentry_filter_arg+0x188c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1de4, 0x188c, arm64_l_188c);
arm64_l_1de8:
	/* 0x1de8: mov w10, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_1dec:
	/* 0x1dec: movk w10, #0xc, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 12ULL);
arm64_l_1df0:
	/* 0x1df0: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1df4:
	/* 0x1df4: b.eq 1e00 <generic_fentry_filter_arg+0x1e00> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1df4, 0x1e00, arm64_l_1e00);
arm64_l_1df8:
	/* 0x1df8: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1dfc:
	/* 0x1dfc: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1e00:
	/* 0x1e00: mov w22, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1e04:
	/* 0x1e04: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1e08:
	/* 0x1e08: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1e0c:
	/* 0x1e0c: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1e10:
	/* 0x1e10: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x1e10, 0x294, arm64_l_294);
arm64_l_1e14:
	/* 0x1e14: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1e18:
	/* 0x1e18: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1e1c:
	/* 0x1e1c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e20:
	/* 0x1e20: b 1e04 <generic_fentry_filter_arg+0x1e04> */
	ARM64_SIM_A64_JMP(0x1e20, 0x1e04, arm64_l_1e04);
arm64_l_1e24:
	/* 0x1e24: cmp x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e28:
	/* 0x1e28: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e2c:
	/* 0x1e2c: b.hi 1e38 <generic_fentry_filter_arg+0x1e38> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1e2c, 0x1e38, arm64_l_1e38);
arm64_l_1e30:
	/* 0x1e30: cmp x8, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e34:
	/* 0x1e34: b.ls 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1e34, 0x298, arm64_l_298);
arm64_l_1e38:
	/* 0x1e38: cmp w10, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1e3c:
	/* 0x1e3c: b.cc fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1e3c, 0xfc, arm64_l_fc);
arm64_l_1e40:
	/* 0x1e40: ldp x12, x11, [x23, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1e44:
	/* 0x1e44: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1e48:
	/* 0x1e48: b.eq 1e54 <generic_fentry_filter_arg+0x1e54> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e48, 0x1e54, arm64_l_1e54);
arm64_l_1e4c:
	/* 0x1e4c: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1e50:
	/* 0x1e50: b.ne 22c0 <generic_fentry_filter_arg+0x22c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1e50, 0x22c0, arm64_l_22c0);
arm64_l_1e54:
	/* 0x1e54: cmp x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e58:
	/* 0x1e58: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e5c:
	/* 0x1e5c: b.gt 22d4 <generic_fentry_filter_arg+0x22d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1e5c, 0x22d4, arm64_l_22d4);
arm64_l_1e60:
	/* 0x1e60: cmp x8, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e64:
	/* 0x1e64: b.le 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1e64, 0x298, arm64_l_298);
arm64_l_1e68:
	/* 0x1e68: b 22d4 <generic_fentry_filter_arg+0x22d4> */
	ARM64_SIM_A64_JMP(0x1e68, 0x22d4, arm64_l_22d4);
arm64_l_1e6c:
	/* 0x1e6c: ldr w8, [x23, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1e70:
	/* 0x1e70: b 1e7c <generic_fentry_filter_arg+0x1e7c> */
	ARM64_SIM_A64_JMP(0x1e70, 0x1e7c, arm64_l_1e7c);
arm64_l_1e74:
	/* 0x1e74: ldr w8, [x23, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1e78:
	/* 0x1e78: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1e7c:
	/* 0x1e7c: and w8, w8, #0xfffffffe */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967294ULL);
arm64_l_1e80:
	/* 0x1e80: cmp w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1e84:
	/* 0x1e84: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1e88:
	/* 0x1e88: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1e8c:
	/* 0x1e8c: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1e90:
	/* 0x1e90: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e94:
	/* 0x1e94: mov w22, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1e98:
	/* 0x1e98: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1e9c:
	/* 0x1e9c: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x1e9c, 0x294, arm64_l_294);
arm64_l_1ea0:
	/* 0x1ea0: ldr w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ea4:
	/* 0x1ea4: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ea8:
	/* 0x1ea8: b.hi 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1ea8, 0x298, arm64_l_298);
arm64_l_1eac:
	/* 0x1eac: b 1ebc <generic_fentry_filter_arg+0x1ebc> */
	ARM64_SIM_A64_JMP(0x1eac, 0x1ebc, arm64_l_1ebc);
arm64_l_1eb0:
	/* 0x1eb0: ldr w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1eb4:
	/* 0x1eb4: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1eb8:
	/* 0x1eb8: b.cc 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1eb8, 0x298, arm64_l_298);
arm64_l_1ebc:
	/* 0x1ebc: ldr w10, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1ec0:
	/* 0x1ec0: cmp w10, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1ec4:
	/* 0x1ec4: b.cc 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1ec4, 0x3400, arm64_l_3400);
arm64_l_1ec8:
	/* 0x1ec8: ldr w11, [x23, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1ecc:
	/* 0x1ecc: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1ed0:
	/* 0x1ed0: b.le 1ef4 <generic_fentry_filter_arg+0x1ef4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1ed0, 0x1ef4, arm64_l_1ef4);
arm64_l_1ed4:
	/* 0x1ed4: sub w12, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1ed8:
	/* 0x1ed8: cmp w12, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1edc:
	/* 0x1edc: b.cs 1f34 <generic_fentry_filter_arg+0x1f34> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1edc, 0x1f34, arm64_l_1f34);
arm64_l_1ee0:
	/* 0x1ee0: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ee4:
	/* 0x1ee4: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ee8:
	/* 0x1ee8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1eec:
	/* 0x1eec: b.eq 28c <generic_fentry_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1eec, 0x28c, arm64_l_28c);
arm64_l_1ef0:
	/* 0x1ef0: b 27c0 <generic_fentry_filter_arg+0x27c0> */
	ARM64_SIM_A64_JMP(0x1ef0, 0x27c0, arm64_l_27c0);
arm64_l_1ef4:
	/* 0x1ef4: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1ef8:
	/* 0x1ef8: b.eq 1f54 <generic_fentry_filter_arg+0x1f54> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ef8, 0x1f54, arm64_l_1f54);
arm64_l_1efc:
	/* 0x1efc: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1f00:
	/* 0x1f00: b.ne 27c0 <generic_fentry_filter_arg+0x27c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1f00, 0x27c0, arm64_l_27c0);
arm64_l_1f04:
	/* 0x1f04: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f08:
	/* 0x1f08: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1f0c:
	/* 0x1f0c: b.hi 27b0 <generic_fentry_filter_arg+0x27b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1f0c, 0x27b0, arm64_l_27b0);
arm64_l_1f10:
	/* 0x1f10: lsl w12, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X12, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1f14:
	/* 0x1f14: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1f18:
	/* 0x1f18: tst w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f1c:
	/* 0x1f1c: b.eq 27b0 <generic_fentry_filter_arg+0x27b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f1c, 0x27b0, arm64_l_27b0);
arm64_l_1f20:
	/* 0x1f20: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f24:
	/* 0x1f24: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f28:
	/* 0x1f28: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f2c:
	/* 0x1f2c: b.lt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x1f2c, 0x298, arm64_l_298);
arm64_l_1f30:
	/* 0x1f30: b 27c0 <generic_fentry_filter_arg+0x27c0> */
	ARM64_SIM_A64_JMP(0x1f30, 0x27c0, arm64_l_27c0);
arm64_l_1f34:
	/* 0x1f34: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1f38:
	/* 0x1f38: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f3c:
	/* 0x1f3c: b.ne 27c0 <generic_fentry_filter_arg+0x27c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1f3c, 0x27c0, arm64_l_27c0);
arm64_l_1f40:
	/* 0x1f40: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f44:
	/* 0x1f44: tst w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f48:
	/* 0x1f48: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f4c:
	/* 0x1f4c: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1f4c, 0x298, arm64_l_298);
arm64_l_1f50:
	/* 0x1f50: b 27c0 <generic_fentry_filter_arg+0x27c0> */
	ARM64_SIM_A64_JMP(0x1f50, 0x27c0, arm64_l_27c0);
arm64_l_1f54:
	/* 0x1f54: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f58:
	/* 0x1f58: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1f5c:
	/* 0x1f5c: b.hi 279c <generic_fentry_filter_arg+0x279c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1f5c, 0x279c, arm64_l_279c);
arm64_l_1f60:
	/* 0x1f60: lsl w12, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X12, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1f64:
	/* 0x1f64: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1f68:
	/* 0x1f68: tst w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f6c:
	/* 0x1f6c: b.eq 279c <generic_fentry_filter_arg+0x279c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f6c, 0x279c, arm64_l_279c);
arm64_l_1f70:
	/* 0x1f70: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f74:
	/* 0x1f74: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f78:
	/* 0x1f78: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f7c:
	/* 0x1f7c: b.gt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1f7c, 0x298, arm64_l_298);
arm64_l_1f80:
	/* 0x1f80: b 27c0 <generic_fentry_filter_arg+0x27c0> */
	ARM64_SIM_A64_JMP(0x1f80, 0x27c0, arm64_l_27c0);
arm64_l_1f84:
	/* 0x1f84: and w8, w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1f88:
	/* 0x1f88: cmp w8, #0x201 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 513ULL);
arm64_l_1f8c:
	/* 0x1f8c: b.cs 23e8 <generic_fentry_filter_arg+0x23e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1f8c, 0x23e8, arm64_l_23e8);
arm64_l_1f90:
	/* 0x1f90: mov w11, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 512ULL);
arm64_l_1f94:
	/* 0x1f94: b 2928 <generic_fentry_filter_arg+0x2928> */
	ARM64_SIM_A64_JMP(0x1f94, 0x2928, arm64_l_2928);
arm64_l_1f98:
	/* 0x1f98: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1f9c:
	/* 0x1f9c: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1fa0:
	/* 0x1fa0: ldr w8, [x23, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1fa4:
	/* 0x1fa4: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_1fa8:
	/* 0x1fa8: b.hi 1044 <generic_fentry_filter_arg+0x1044> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1fa8, 0x1044, arm64_l_1044);
arm64_l_1fac:
	/* 0x1fac: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_1fb0:
	/* 0x1fb0: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1fb4:
	/* 0x1fb4: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1fb8:
	/* 0x1fb8: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1fbc:
	/* 0x1fbc: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_1fc0:
	/* 0x1fc0: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1fc4:
	/* 0x1fc4: lsl x8, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1fc8:
	/* 0x1fc8: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_1fcc:
	/* 0x1fcc: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fd0:
	/* 0x1fd0: b.ne 2e24 <generic_fentry_filter_arg+0x2e24> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1fd0, 0x2e24, arm64_l_2e24);
arm64_l_1fd4:
	/* 0x1fd4: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x1fd4, 0x294, arm64_l_294);
arm64_l_1fd8:
	/* 0x1fd8: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1fdc:
	/* 0x1fdc: b.eq 2658 <generic_fentry_filter_arg+0x2658> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1fdc, 0x2658, arm64_l_2658);
arm64_l_1fe0:
	/* 0x1fe0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1fe4:
	/* 0x1fe4: b.ne 2664 <generic_fentry_filter_arg+0x2664> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1fe4, 0x2664, arm64_l_2664);
arm64_l_1fe8:
	/* 0x1fe8: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1fec:
	/* 0x1fec: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ff0:
	/* 0x1ff0: b.hi 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1ff0, 0x298, arm64_l_298);
arm64_l_1ff4:
	/* 0x1ff4: b 2664 <generic_fentry_filter_arg+0x2664> */
	ARM64_SIM_A64_JMP(0x1ff4, 0x2664, arm64_l_2664);
arm64_l_1ff8:
	/* 0x1ff8: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1ffc:
	/* 0x1ffc: b.eq 2694 <generic_fentry_filter_arg+0x2694> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ffc, 0x2694, arm64_l_2694);
arm64_l_2000:
	/* 0x2000: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2004:
	/* 0x2004: b.ne 26a0 <generic_fentry_filter_arg+0x26a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2004, 0x26a0, arm64_l_26a0);
arm64_l_2008:
	/* 0x2008: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_200c:
	/* 0x200c: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2010:
	/* 0x2010: b.hi 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2010, 0x298, arm64_l_298);
arm64_l_2014:
	/* 0x2014: b 26a0 <generic_fentry_filter_arg+0x26a0> */
	ARM64_SIM_A64_JMP(0x2014, 0x26a0, arm64_l_26a0);
arm64_l_2018:
	/* 0x2018: cmp w8, #0x401 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1025ULL);
arm64_l_201c:
	/* 0x201c: b.cs 2448 <generic_fentry_filter_arg+0x2448> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x201c, 0x2448, arm64_l_2448);
arm64_l_2020:
	/* 0x2020: mov w11, #0x400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1024ULL);
arm64_l_2024:
	/* 0x2024: b 245c <generic_fentry_filter_arg+0x245c> */
	ARM64_SIM_A64_JMP(0x2024, 0x245c, arm64_l_245c);
arm64_l_2028:
	/* 0x2028: cmp w13, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_202c:
	/* 0x202c: ccmp w10, w12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_2030:
	/* 0x2030: cset w12, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_2034:
	/* 0x2034: orr w8, w8, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_2038:
	/* 0x2038: cmp w11, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_203c:
	/* 0x203c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2040:
	/* 0x2040: b.cc 2b68 <generic_fentry_filter_arg+0x2b68> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2040, 0x2b68, arm64_l_2b68);
arm64_l_2044:
	/* 0x2044: ldp w13, w12, [x23, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X13, ARM64_X12, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2048:
	/* 0x2048: mov w14, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_204c:
	/* 0x204c: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2050:
	/* 0x2050: b.hi 26f0 <generic_fentry_filter_arg+0x26f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2050, 0x26f0, arm64_l_26f0);
arm64_l_2054:
	/* 0x2054: lsl w14, w14, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X14, ARM64_X14, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2058:
	/* 0x2058: mov w1, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_205c:
	/* 0x205c: tst w14, w1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X14, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2060:
	/* 0x2060: b.eq 26f0 <generic_fentry_filter_arg+0x26f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2060, 0x26f0, arm64_l_26f0);
arm64_l_2064:
	/* 0x2064: cmp w13, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2068:
	/* 0x2068: ccmp w10, w12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_206c:
	/* 0x206c: cset w12, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_2070:
	/* 0x2070: b 26fc <generic_fentry_filter_arg+0x26fc> */
	ARM64_SIM_A64_JMP(0x2070, 0x26fc, arm64_l_26fc);
arm64_l_2074:
	/* 0x2074: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2078:
	/* 0x2078: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_207c:
	/* 0x207c: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x207c, 0x294, arm64_l_294);
arm64_l_2080:
	/* 0x2080: mov w11, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_2084:
	/* 0x2084: b 2094 <generic_fentry_filter_arg+0x2094> */
	ARM64_SIM_A64_JMP(0x2084, 0x2094, arm64_l_2094);
arm64_l_2088:
	/* 0x2088: mov w11, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 6ULL);
arm64_l_208c:
	/* 0x208c: b 2094 <generic_fentry_filter_arg+0x2094> */
	ARM64_SIM_A64_JMP(0x208c, 0x2094, arm64_l_2094);
arm64_l_2090:
	/* 0x2090: mov w11, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2094:
	/* 0x2094: add x8, x23, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2098:
	/* 0x2098: and w9, w11, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_209c:
	/* 0x209c: ldr w8, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_20a0:
	/* 0x20a0: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_20a4:
	/* 0x20a4: b.eq 2154 <generic_fentry_filter_arg+0x2154> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x20a4, 0x2154, arm64_l_2154);
arm64_l_20a8:
	/* 0x20a8: str w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_20ac:
	/* 0x20ac: stp w13, w11, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X13, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_20b0:
	/* 0x20b0: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_19));
arm64_l_20b4:
	/* 0x20b4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_20b8:
	/* 0x20b8: add x22, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_20bc:
	/* 0x20bc: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_20c0:
	/* 0x20c0: str x10, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_20c4:
	/* 0x20c4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_20c8:
	/* 0x20c8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x20ccULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_20cc:
	/* 0x20cc: mov x25, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_20d0:
	/* 0x20d0: adrp x0, 0 <heap_ro_zero> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero_5));
arm64_l_20d4:
	/* 0x20d4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_20d8:
	/* 0x20d8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_20dc:
	/* 0x20dc: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_20e0:
	/* 0x20e0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x20e4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_20e4:
	/* 0x20e4: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_20e8:
	/* 0x20e8: cbz x25, 2df0 <generic_fentry_filter_arg+0x2df0> */
	ARM64_SIM_A64_CBZ(ARM64_X25, 0x20e8, 0x2df0, arm64_l_2df0);
arm64_l_20ec:
	/* 0x20ec: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_20f0:
	/* 0x20f0: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_20f4:
	/* 0x20f4: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_20f8:
	/* 0x20f8: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_20fc:
	/* 0x20fc: cbz x0, 2e00 <generic_fentry_filter_arg+0x2e00> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x20fc, 0x2e00, arm64_l_2e00);
arm64_l_2100:
	/* 0x2100: mov x8, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2104:
	/* 0x2104: ldr w25, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2108:
	/* 0x2108: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_210c:
	/* 0x210c: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2110:
	/* 0x2110: str x8, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2114:
	/* 0x2114: cmp w25, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2118:
	/* 0x2118: b.gt 2168 <generic_fentry_filter_arg+0x2168> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2118, 0x2168, arm64_l_2168);
arm64_l_211c:
	/* 0x211c: strb w29, [x0], #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 1ULL);
arm64_l_2120:
	/* 0x2120: ldr x2, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2124:
	/* 0x2124: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2128:
	/* 0x2128: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_212c:
	/* 0x212c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2130ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2130:
	/* 0x2130: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2134:
	/* 0x2134: subs w8, w8, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2138:
	/* 0x2138: b.ls 21a4 <generic_fentry_filter_arg+0x21a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2138, 0x21a4, arm64_l_21a4);
arm64_l_213c:
	/* 0x213c: ldr x9, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2140:
	/* 0x2140: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2144:
	/* 0x2144: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2148:
	/* 0x2148: add x9, x9, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_214c:
	/* 0x214c: add x0, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2150:
	/* 0x2150: b 219c <generic_fentry_filter_arg+0x219c> */
	ARM64_SIM_A64_JMP(0x2150, 0x219c, arm64_l_219c);
arm64_l_2154:
	/* 0x2154: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2158:
	/* 0x2158: ldr w8, [x23, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_215c:
	/* 0x215c: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_2160:
	/* 0x2160: b.ls 2e0c <generic_fentry_filter_arg+0x2e0c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2160, 0x2e0c, arm64_l_2e0c);
arm64_l_2164:
	/* 0x2164: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x2164, 0x294, arm64_l_294);
arm64_l_2168:
	/* 0x2168: strh w29, [x0], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_216c:
	/* 0x216c: ldr x2, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2170:
	/* 0x2170: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2174:
	/* 0x2174: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2178:
	/* 0x2178: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x217cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_217c:
	/* 0x217c: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2180:
	/* 0x2180: subs w8, w8, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2184:
	/* 0x2184: b.ls 21a4 <generic_fentry_filter_arg+0x21a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2184, 0x21a4, arm64_l_21a4);
arm64_l_2188:
	/* 0x2188: ldr x9, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_218c:
	/* 0x218c: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2190:
	/* 0x2190: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2194:
	/* 0x2194: add x9, x9, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2198:
	/* 0x2198: add x0, x9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_219c:
	/* 0x219c: mov x2, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_21a0:
	/* 0x21a0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x21a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_21a4:
	/* 0x21a4: ldr w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_21a8:
	/* 0x21a8: cmp w25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_21ac:
	/* 0x21ac: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_21b0:
	/* 0x21b0: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_21b4:
	/* 0x21b4: b.le 21ec <generic_fentry_filter_arg+0x21ec> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x21b4, 0x21ec, arm64_l_21ec);
arm64_l_21b8:
	/* 0x21b8: cmp w25, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_21bc:
	/* 0x21bc: b.gt 241c <generic_fentry_filter_arg+0x241c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x21bc, 0x241c, arm64_l_241c);
arm64_l_21c0:
	/* 0x21c0: cmp w25, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_21c4:
	/* 0x21c4: b.eq 2da4 <generic_fentry_filter_arg+0x2da4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x21c4, 0x2da4, arm64_l_2da4);
arm64_l_21c8:
	/* 0x21c8: cmp w25, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_21cc:
	/* 0x21cc: b.eq 2d68 <generic_fentry_filter_arg+0x2d68> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x21cc, 0x2d68, arm64_l_2d68);
arm64_l_21d0:
	/* 0x21d0: cmp w25, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_21d4:
	/* 0x21d4: b.ne 2e2c <generic_fentry_filter_arg+0x2e2c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x21d4, 0x2e2c, arm64_l_2e2c);
arm64_l_21d8:
	/* 0x21d8: adrp x0, 0 <string_maps_7> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_7_16));
arm64_l_21dc:
	/* 0x21dc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_21e0:
	/* 0x21e0: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_21e4:
	/* 0x21e4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_21e8:
	/* 0x21e8: b 2dc8 <generic_fentry_filter_arg+0x2dc8> */
	ARM64_SIM_A64_JMP(0x21e8, 0x2dc8, arm64_l_2dc8);
arm64_l_21ec:
	/* 0x21ec: cmp w25, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_21f0:
	/* 0x21f0: b.le 28a0 <generic_fentry_filter_arg+0x28a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x21f0, 0x28a0, arm64_l_28a0);
arm64_l_21f4:
	/* 0x21f4: cmp w25, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_21f8:
	/* 0x21f8: b.eq 2d90 <generic_fentry_filter_arg+0x2d90> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x21f8, 0x2d90, arm64_l_2d90);
arm64_l_21fc:
	/* 0x21fc: cmp w25, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2200:
	/* 0x2200: b.eq 2d54 <generic_fentry_filter_arg+0x2d54> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2200, 0x2d54, arm64_l_2d54);
arm64_l_2204:
	/* 0x2204: cmp w25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2208:
	/* 0x2208: b.ne 2e2c <generic_fentry_filter_arg+0x2e2c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2208, 0x2e2c, arm64_l_2e2c);
arm64_l_220c:
	/* 0x220c: adrp x0, 0 <string_maps_4> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_4_13));
arm64_l_2210:
	/* 0x2210: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2214:
	/* 0x2214: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2218:
	/* 0x2218: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_221c:
	/* 0x221c: b 2dc8 <generic_fentry_filter_arg+0x2dc8> */
	ARM64_SIM_A64_JMP(0x221c, 0x2dc8, arm64_l_2dc8);
arm64_l_2220:
	/* 0x2220: cmp w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2224:
	/* 0x2224: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2228:
	/* 0x2228: b.hi 2234 <generic_fentry_filter_arg+0x2234> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2228, 0x2234, arm64_l_2234);
arm64_l_222c:
	/* 0x222c: cmp w8, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2230:
	/* 0x2230: b.ls 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2230, 0x298, arm64_l_298);
arm64_l_2234:
	/* 0x2234: cmp w10, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_2238:
	/* 0x2238: b.cc fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2238, 0xfc, arm64_l_fc);
arm64_l_223c:
	/* 0x223c: ldp w12, w11, [x23, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2240:
	/* 0x2240: mov w13, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2244:
	/* 0x2244: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2248:
	/* 0x2248: b.hi 2750 <generic_fentry_filter_arg+0x2750> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2248, 0x2750, arm64_l_2750);
arm64_l_224c:
	/* 0x224c: lsl w13, w13, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X13, ARM64_X13, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2250:
	/* 0x2250: mov w14, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2254:
	/* 0x2254: tst w13, w14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X13, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2258:
	/* 0x2258: b.eq 2750 <generic_fentry_filter_arg+0x2750> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2258, 0x2750, arm64_l_2750);
arm64_l_225c:
	/* 0x225c: cmp w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2260:
	/* 0x2260: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2264:
	/* 0x2264: b.gt 2764 <generic_fentry_filter_arg+0x2764> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2264, 0x2764, arm64_l_2764);
arm64_l_2268:
	/* 0x2268: cmp w8, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_226c:
	/* 0x226c: b.le 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x226c, 0x298, arm64_l_298);
arm64_l_2270:
	/* 0x2270: b 2764 <generic_fentry_filter_arg+0x2764> */
	ARM64_SIM_A64_JMP(0x2270, 0x2764, arm64_l_2764);
arm64_l_2274:
	/* 0x2274: cmp w8, #0x101 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 257ULL);
arm64_l_2278:
	/* 0x2278: b.cs 273c <generic_fentry_filter_arg+0x273c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2278, 0x273c, arm64_l_273c);
arm64_l_227c:
	/* 0x227c: mov w11, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_2280:
	/* 0x2280: b 307c <generic_fentry_filter_arg+0x307c> */
	ARM64_SIM_A64_JMP(0x2280, 0x307c, arm64_l_307c);
arm64_l_2284:
	/* 0x2284: cmp x13, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2288:
	/* 0x2288: ccmp x10, x12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_228c:
	/* 0x228c: cset w12, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_2290:
	/* 0x2290: orr w8, w8, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_2294:
	/* 0x2294: cmp w11, #0x39 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 57ULL);
arm64_l_2298:
	/* 0x2298: b.cc 2894 <generic_fentry_filter_arg+0x2894> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2298, 0x2894, arm64_l_2894);
arm64_l_229c:
	/* 0x229c: ldp x12, x11, [x23, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_22a0:
	/* 0x22a0: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_22a4:
	/* 0x22a4: b.eq 22b0 <generic_fentry_filter_arg+0x22b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x22a4, 0x22b0, arm64_l_22b0);
arm64_l_22a8:
	/* 0x22a8: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_22ac:
	/* 0x22ac: b.ne 2884 <generic_fentry_filter_arg+0x2884> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x22ac, 0x2884, arm64_l_2884);
arm64_l_22b0:
	/* 0x22b0: cmp x12, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_22b4:
	/* 0x22b4: ccmp x10, x11, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_22b8:
	/* 0x22b8: cset w9, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_22bc:
	/* 0x22bc: b 2890 <generic_fentry_filter_arg+0x2890> */
	ARM64_SIM_A64_JMP(0x22bc, 0x2890, arm64_l_2890);
arm64_l_22c0:
	/* 0x22c0: cmp x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_22c4:
	/* 0x22c4: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_22c8:
	/* 0x22c8: b.hi 22d4 <generic_fentry_filter_arg+0x22d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x22c8, 0x22d4, arm64_l_22d4);
arm64_l_22cc:
	/* 0x22cc: cmp x8, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_22d0:
	/* 0x22d0: b.ls 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x22d0, 0x298, arm64_l_298);
arm64_l_22d4:
	/* 0x22d4: cmp w10, #0x39 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 57ULL);
arm64_l_22d8:
	/* 0x22d8: b.cc fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x22d8, 0xfc, arm64_l_fc);
arm64_l_22dc:
	/* 0x22dc: ldp x11, x10, [x23, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_22e0:
	/* 0x22e0: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_22e4:
	/* 0x22e4: b.eq 22f0 <generic_fentry_filter_arg+0x22f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x22e4, 0x22f0, arm64_l_22f0);
arm64_l_22e8:
	/* 0x22e8: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_22ec:
	/* 0x22ec: b.ne 28c0 <generic_fentry_filter_arg+0x28c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x22ec, 0x28c0, arm64_l_28c0);
arm64_l_22f0:
	/* 0x22f0: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_22f4:
	/* 0x22f4: b.gt fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x22f4, 0xfc, arm64_l_fc);
arm64_l_22f8:
	/* 0x22f8: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_22fc:
	/* 0x22fc: b.le 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x22fc, 0x298, arm64_l_298);
arm64_l_2300:
	/* 0x2300: b fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x2300, 0xfc, arm64_l_fc);
arm64_l_2304:
	/* 0x2304: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2308:
	/* 0x2308: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_230c:
	/* 0x230c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2310:
	/* 0x2310: b.hi 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2310, 0x298, arm64_l_298);
arm64_l_2314:
	/* 0x2314: b 2328 <generic_fentry_filter_arg+0x2328> */
	ARM64_SIM_A64_JMP(0x2314, 0x2328, arm64_l_2328);
arm64_l_2318:
	/* 0x2318: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_231c:
	/* 0x231c: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2320:
	/* 0x2320: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2324:
	/* 0x2324: b.cc 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2324, 0x298, arm64_l_298);
arm64_l_2328:
	/* 0x2328: cmp w10, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_232c:
	/* 0x232c: b.cc 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x232c, 0x3400, arm64_l_3400);
arm64_l_2330:
	/* 0x2330: ldr x11, [x23, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2334:
	/* 0x2334: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2338:
	/* 0x2338: b.le 235c <generic_fentry_filter_arg+0x235c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2338, 0x235c, arm64_l_235c);
arm64_l_233c:
	/* 0x233c: sub w12, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2340:
	/* 0x2340: cmp w12, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2344:
	/* 0x2344: b.cs 2390 <generic_fentry_filter_arg+0x2390> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2344, 0x2390, arm64_l_2390);
arm64_l_2348:
	/* 0x2348: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_234c:
	/* 0x234c: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2350:
	/* 0x2350: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2354:
	/* 0x2354: b.eq 28c <generic_fentry_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2354, 0x28c, arm64_l_28c);
arm64_l_2358:
	/* 0x2358: b 2b94 <generic_fentry_filter_arg+0x2b94> */
	ARM64_SIM_A64_JMP(0x2358, 0x2b94, arm64_l_2b94);
arm64_l_235c:
	/* 0x235c: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2360:
	/* 0x2360: b.eq 23f8 <generic_fentry_filter_arg+0x23f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2360, 0x23f8, arm64_l_23f8);
arm64_l_2364:
	/* 0x2364: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2368:
	/* 0x2368: b.ne 2b94 <generic_fentry_filter_arg+0x2b94> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2368, 0x2b94, arm64_l_2b94);
arm64_l_236c:
	/* 0x236c: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2370:
	/* 0x2370: b.eq 237c <generic_fentry_filter_arg+0x237c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2370, 0x237c, arm64_l_237c);
arm64_l_2374:
	/* 0x2374: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2378:
	/* 0x2378: b.ne 2b84 <generic_fentry_filter_arg+0x2b84> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2378, 0x2b84, arm64_l_2b84);
arm64_l_237c:
	/* 0x237c: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2380:
	/* 0x2380: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2384:
	/* 0x2384: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2388:
	/* 0x2388: b.lt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x2388, 0x298, arm64_l_298);
arm64_l_238c:
	/* 0x238c: b 2b94 <generic_fentry_filter_arg+0x2b94> */
	ARM64_SIM_A64_JMP(0x238c, 0x2b94, arm64_l_2b94);
arm64_l_2390:
	/* 0x2390: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2394:
	/* 0x2394: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2398:
	/* 0x2398: b.ne 2b94 <generic_fentry_filter_arg+0x2b94> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2398, 0x2b94, arm64_l_2b94);
arm64_l_239c:
	/* 0x239c: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_23a0:
	/* 0x23a0: tst x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_23a4:
	/* 0x23a4: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_23a8:
	/* 0x23a8: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x23a8, 0x298, arm64_l_298);
arm64_l_23ac:
	/* 0x23ac: b 2b94 <generic_fentry_filter_arg+0x2b94> */
	ARM64_SIM_A64_JMP(0x23ac, 0x2b94, arm64_l_2b94);
arm64_l_23b0:
	/* 0x23b0: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_23b4:
	/* 0x23b4: b.ne 2664 <generic_fentry_filter_arg+0x2664> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x23b4, 0x2664, arm64_l_2664);
arm64_l_23b8:
	/* 0x23b8: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_23bc:
	/* 0x23bc: tst w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_23c0:
	/* 0x23c0: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x23c0, 0x298, arm64_l_298);
arm64_l_23c4:
	/* 0x23c4: b 2664 <generic_fentry_filter_arg+0x2664> */
	ARM64_SIM_A64_JMP(0x23c4, 0x2664, arm64_l_2664);
arm64_l_23c8:
	/* 0x23c8: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_23cc:
	/* 0x23cc: b.ne 26a0 <generic_fentry_filter_arg+0x26a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x23cc, 0x26a0, arm64_l_26a0);
arm64_l_23d0:
	/* 0x23d0: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_23d4:
	/* 0x23d4: tst w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_23d8:
	/* 0x23d8: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x23d8, 0x298, arm64_l_298);
arm64_l_23dc:
	/* 0x23dc: b 26a0 <generic_fentry_filter_arg+0x26a0> */
	ARM64_SIM_A64_JMP(0x23dc, 0x26a0, arm64_l_26a0);
arm64_l_23e0:
	/* 0x23e0: mov w22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_23e4:
	/* 0x23e4: b 338c <generic_fentry_filter_arg+0x338c> */
	ARM64_SIM_A64_JMP(0x23e4, 0x338c, arm64_l_338c);
arm64_l_23e8:
	/* 0x23e8: cmp w8, #0x401 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1025ULL);
arm64_l_23ec:
	/* 0x23ec: b.cs 2914 <generic_fentry_filter_arg+0x2914> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x23ec, 0x2914, arm64_l_2914);
arm64_l_23f0:
	/* 0x23f0: mov w11, #0x400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1024ULL);
arm64_l_23f4:
	/* 0x23f4: b 2928 <generic_fentry_filter_arg+0x2928> */
	ARM64_SIM_A64_JMP(0x23f4, 0x2928, arm64_l_2928);
arm64_l_23f8:
	/* 0x23f8: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_23fc:
	/* 0x23fc: b.eq 2408 <generic_fentry_filter_arg+0x2408> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x23fc, 0x2408, arm64_l_2408);
arm64_l_2400:
	/* 0x2400: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2404:
	/* 0x2404: b.ne 2b70 <generic_fentry_filter_arg+0x2b70> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2404, 0x2b70, arm64_l_2b70);
arm64_l_2408:
	/* 0x2408: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_240c:
	/* 0x240c: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2410:
	/* 0x2410: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2414:
	/* 0x2414: b.gt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2414, 0x298, arm64_l_298);
arm64_l_2418:
	/* 0x2418: b 2b94 <generic_fentry_filter_arg+0x2b94> */
	ARM64_SIM_A64_JMP(0x2418, 0x2b94, arm64_l_2b94);
arm64_l_241c:
	/* 0x241c: cmp w25, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2420:
	/* 0x2420: b.eq 2db8 <generic_fentry_filter_arg+0x2db8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2420, 0x2db8, arm64_l_2db8);
arm64_l_2424:
	/* 0x2424: cmp w25, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_2428:
	/* 0x2428: b.eq 2d7c <generic_fentry_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2428, 0x2d7c, arm64_l_2d7c);
arm64_l_242c:
	/* 0x242c: cmp w25, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2430:
	/* 0x2430: b.ne 2e2c <generic_fentry_filter_arg+0x2e2c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2430, 0x2e2c, arm64_l_2e2c);
arm64_l_2434:
	/* 0x2434: adrp x0, 0 <string_maps_10> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_10_10));
arm64_l_2438:
	/* 0x2438: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_243c:
	/* 0x243c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2440:
	/* 0x2440: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2444:
	/* 0x2444: b 2dc8 <generic_fentry_filter_arg+0x2dc8> */
	ARM64_SIM_A64_JMP(0x2444, 0x2dc8, arm64_l_2dc8);
arm64_l_2448:
	/* 0x2448: and w8, w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_244c:
	/* 0x244c: mov w9, #0x1000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_2450:
	/* 0x2450: cmp w8, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2048ULL);
arm64_l_2454:
	/* 0x2454: mov w8, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_2458:
	/* 0x2458: csel w11, w9, w8, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_245c:
	/* 0x245c: sub w8, w11, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_2460:
	/* 0x2460: ror w8, w8, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_ROR), 8ULL);
arm64_l_2464:
	/* 0x2464: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2468:
	/* 0x2468: b.gt 2480 <generic_fentry_filter_arg+0x2480> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2468, 0x2480, arm64_l_2480);
arm64_l_246c:
	/* 0x246c: cbz w8, 24a0 <generic_fentry_filter_arg+0x24a0> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x246c, 0x24a0, arm64_l_24a0);
arm64_l_2470:
	/* 0x2470: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2474:
	/* 0x2474: b.ne 2498 <generic_fentry_filter_arg+0x2498> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2474, 0x2498, arm64_l_2498);
arm64_l_2478:
	/* 0x2478: mov w10, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 7ULL);
arm64_l_247c:
	/* 0x247c: b 24ac <generic_fentry_filter_arg+0x24ac> */
	ARM64_SIM_A64_JMP(0x247c, 0x24ac, arm64_l_24ac);
arm64_l_2480:
	/* 0x2480: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2484:
	/* 0x2484: b.eq 24a8 <generic_fentry_filter_arg+0x24a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2484, 0x24a8, arm64_l_24a8);
arm64_l_2488:
	/* 0x2488: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_248c:
	/* 0x248c: b.ne 2498 <generic_fentry_filter_arg+0x2498> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x248c, 0x2498, arm64_l_2498);
arm64_l_2490:
	/* 0x2490: mov w10, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 9ULL);
arm64_l_2494:
	/* 0x2494: b 24ac <generic_fentry_filter_arg+0x24ac> */
	ARM64_SIM_A64_JMP(0x2494, 0x24ac, arm64_l_24ac);
arm64_l_2498:
	/* 0x2498: mov w10, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_249c:
	/* 0x249c: b 24ac <generic_fentry_filter_arg+0x24ac> */
	ARM64_SIM_A64_JMP(0x249c, 0x24ac, arm64_l_24ac);
arm64_l_24a0:
	/* 0x24a0: mov w10, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 6ULL);
arm64_l_24a4:
	/* 0x24a4: b 24ac <generic_fentry_filter_arg+0x24ac> */
	ARM64_SIM_A64_JMP(0x24a4, 0x24ac, arm64_l_24ac);
arm64_l_24a8:
	/* 0x24a8: mov w10, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_24ac:
	/* 0x24ac: add x8, x23, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_24b0:
	/* 0x24b0: and w9, w10, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_24b4:
	/* 0x24b4: ldr w8, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_24b8:
	/* 0x24b8: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_24bc:
	/* 0x24bc: b.eq 2dec <generic_fentry_filter_arg+0x2dec> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x24bc, 0x2dec, arm64_l_2dec);
arm64_l_24c0:
	/* 0x24c0: str w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_24c4:
	/* 0x24c4: str w11, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_24c8:
	/* 0x24c8: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_19));
arm64_l_24cc:
	/* 0x24cc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_24d0:
	/* 0x24d0: add x22, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_24d4:
	/* 0x24d4: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_24d8:
	/* 0x24d8: str w10, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_24dc:
	/* 0x24dc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_24e0:
	/* 0x24e0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x24e4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_24e4:
	/* 0x24e4: str x0, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_24e8:
	/* 0x24e8: adrp x0, 0 <heap_ro_zero> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero_5));
arm64_l_24ec:
	/* 0x24ec: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_24f0:
	/* 0x24f0: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_24f4:
	/* 0x24f4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_24f8:
	/* 0x24f8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x24fcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_24fc:
	/* 0x24fc: ldr x9, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2500:
	/* 0x2500: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2504:
	/* 0x2504: cbz x9, 2df0 <generic_fentry_filter_arg+0x2df0> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x2504, 0x2df0, arm64_l_2df0);
arm64_l_2508:
	/* 0x2508: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_250c:
	/* 0x250c: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_2510:
	/* 0x2510: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2514:
	/* 0x2514: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2518:
	/* 0x2518: cbz x0, 2e00 <generic_fentry_filter_arg+0x2e00> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2518, 0x2e00, arm64_l_2e00);
arm64_l_251c:
	/* 0x251c: mov x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2520:
	/* 0x2520: ldr w9, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2524:
	/* 0x2524: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2528:
	/* 0x2528: add x2, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_252c:
	/* 0x252c: mov x25, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2530:
	/* 0x2530: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2534:
	/* 0x2534: cmp w9, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2538:
	/* 0x2538: b.gt 256c <generic_fentry_filter_arg+0x256c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2538, 0x256c, arm64_l_256c);
arm64_l_253c:
	/* 0x253c: strb w29, [x0], #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 1ULL);
arm64_l_2540:
	/* 0x2540: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2544:
	/* 0x2544: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2548:
	/* 0x2548: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x254cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_254c:
	/* 0x254c: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2550:
	/* 0x2550: subs w8, w8, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2554:
	/* 0x2554: b.ls 25a0 <generic_fentry_filter_arg+0x25a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2554, 0x25a0, arm64_l_25a0);
arm64_l_2558:
	/* 0x2558: add x9, x25, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X25, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_255c:
	/* 0x255c: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2560:
	/* 0x2560: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2564:
	/* 0x2564: add x0, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2568:
	/* 0x2568: b 2598 <generic_fentry_filter_arg+0x2598> */
	ARM64_SIM_A64_JMP(0x2568, 0x2598, arm64_l_2598);
arm64_l_256c:
	/* 0x256c: strh w29, [x0], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_2570:
	/* 0x2570: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2574:
	/* 0x2574: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2578:
	/* 0x2578: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x257cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_257c:
	/* 0x257c: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2580:
	/* 0x2580: subs w8, w8, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2584:
	/* 0x2584: b.ls 25a0 <generic_fentry_filter_arg+0x25a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2584, 0x25a0, arm64_l_25a0);
arm64_l_2588:
	/* 0x2588: add x9, x25, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X25, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_258c:
	/* 0x258c: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2590:
	/* 0x2590: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2594:
	/* 0x2594: add x0, x9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2598:
	/* 0x2598: mov x2, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_259c:
	/* 0x259c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x25a0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_25a0:
	/* 0x25a0: ldr w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_25a4:
	/* 0x25a4: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_25a8:
	/* 0x25a8: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_25ac:
	/* 0x25ac: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_25b0:
	/* 0x25b0: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_25b4:
	/* 0x25b4: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_25b8:
	/* 0x25b8: ldr w8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_25bc:
	/* 0x25bc: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_25c0:
	/* 0x25c0: b.le 25f8 <generic_fentry_filter_arg+0x25f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x25c0, 0x25f8, arm64_l_25f8);
arm64_l_25c4:
	/* 0x25c4: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_25c8:
	/* 0x25c8: b.gt 262c <generic_fentry_filter_arg+0x262c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x25c8, 0x262c, arm64_l_262c);
arm64_l_25cc:
	/* 0x25cc: cmp w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_25d0:
	/* 0x25d0: b.eq 2ca8 <generic_fentry_filter_arg+0x2ca8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x25d0, 0x2ca8, arm64_l_2ca8);
arm64_l_25d4:
	/* 0x25d4: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_25d8:
	/* 0x25d8: b.eq 2c6c <generic_fentry_filter_arg+0x2c6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x25d8, 0x2c6c, arm64_l_2c6c);
arm64_l_25dc:
	/* 0x25dc: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_25e0:
	/* 0x25e0: b.ne 7bc <generic_fentry_filter_arg+0x7bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x25e0, 0x7bc, arm64_l_7bc);
arm64_l_25e4:
	/* 0x25e4: adrp x0, 0 <string_maps_7> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_7_16));
arm64_l_25e8:
	/* 0x25e8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_25ec:
	/* 0x25ec: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_25f0:
	/* 0x25f0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_25f4:
	/* 0x25f4: b 2ccc <generic_fentry_filter_arg+0x2ccc> */
	ARM64_SIM_A64_JMP(0x25f4, 0x2ccc, arm64_l_2ccc);
arm64_l_25f8:
	/* 0x25f8: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_25fc:
	/* 0x25fc: b.le 26d0 <generic_fentry_filter_arg+0x26d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x25fc, 0x26d0, arm64_l_26d0);
arm64_l_2600:
	/* 0x2600: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2604:
	/* 0x2604: b.eq 2c94 <generic_fentry_filter_arg+0x2c94> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2604, 0x2c94, arm64_l_2c94);
arm64_l_2608:
	/* 0x2608: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_260c:
	/* 0x260c: b.eq 2c58 <generic_fentry_filter_arg+0x2c58> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x260c, 0x2c58, arm64_l_2c58);
arm64_l_2610:
	/* 0x2610: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2614:
	/* 0x2614: b.ne 7bc <generic_fentry_filter_arg+0x7bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2614, 0x7bc, arm64_l_7bc);
arm64_l_2618:
	/* 0x2618: adrp x0, 0 <string_maps_4> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_4_13));
arm64_l_261c:
	/* 0x261c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2620:
	/* 0x2620: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2624:
	/* 0x2624: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2628:
	/* 0x2628: b 2ccc <generic_fentry_filter_arg+0x2ccc> */
	ARM64_SIM_A64_JMP(0x2628, 0x2ccc, arm64_l_2ccc);
arm64_l_262c:
	/* 0x262c: cmp w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2630:
	/* 0x2630: b.eq 2cbc <generic_fentry_filter_arg+0x2cbc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2630, 0x2cbc, arm64_l_2cbc);
arm64_l_2634:
	/* 0x2634: cmp w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_2638:
	/* 0x2638: b.eq 2c80 <generic_fentry_filter_arg+0x2c80> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2638, 0x2c80, arm64_l_2c80);
arm64_l_263c:
	/* 0x263c: cmp w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2640:
	/* 0x2640: b.ne 7bc <generic_fentry_filter_arg+0x7bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2640, 0x7bc, arm64_l_7bc);
arm64_l_2644:
	/* 0x2644: adrp x0, 0 <string_maps_10> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_10_10));
arm64_l_2648:
	/* 0x2648: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_264c:
	/* 0x264c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2650:
	/* 0x2650: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2654:
	/* 0x2654: b 2ccc <generic_fentry_filter_arg+0x2ccc> */
	ARM64_SIM_A64_JMP(0x2654, 0x2ccc, arm64_l_2ccc);
arm64_l_2658:
	/* 0x2658: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_265c:
	/* 0x265c: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2660:
	/* 0x2660: b.cc 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2660, 0x298, arm64_l_298);
arm64_l_2664:
	/* 0x2664: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2668:
	/* 0x2668: b.cc 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2668, 0x3400, arm64_l_3400);
arm64_l_266c:
	/* 0x266c: ldr w10, [x23, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2670:
	/* 0x2670: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2674:
	/* 0x2674: b.le 28d4 <generic_fentry_filter_arg+0x28d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2674, 0x28d4, arm64_l_28d4);
arm64_l_2678:
	/* 0x2678: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_267c:
	/* 0x267c: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2680:
	/* 0x2680: b.cs 2c14 <generic_fentry_filter_arg+0x2c14> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2680, 0x2c14, arm64_l_2c14);
arm64_l_2684:
	/* 0x2684: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2688:
	/* 0x2688: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_268c:
	/* 0x268c: b.eq 28c <generic_fentry_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x268c, 0x28c, arm64_l_28c);
arm64_l_2690:
	/* 0x2690: b 2f20 <generic_fentry_filter_arg+0x2f20> */
	ARM64_SIM_A64_JMP(0x2690, 0x2f20, arm64_l_2f20);
arm64_l_2694:
	/* 0x2694: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2698:
	/* 0x2698: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_269c:
	/* 0x269c: b.cc 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x269c, 0x298, arm64_l_298);
arm64_l_26a0:
	/* 0x26a0: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_26a4:
	/* 0x26a4: b.cc 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x26a4, 0x3400, arm64_l_3400);
arm64_l_26a8:
	/* 0x26a8: ldr w10, [x23, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_26ac:
	/* 0x26ac: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_26b0:
	/* 0x26b0: b.le 28f4 <generic_fentry_filter_arg+0x28f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x26b0, 0x28f4, arm64_l_28f4);
arm64_l_26b4:
	/* 0x26b4: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_26b8:
	/* 0x26b8: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_26bc:
	/* 0x26bc: b.cs 2c2c <generic_fentry_filter_arg+0x2c2c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x26bc, 0x2c2c, arm64_l_2c2c);
arm64_l_26c0:
	/* 0x26c0: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_26c4:
	/* 0x26c4: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26c8:
	/* 0x26c8: b.eq 28c <generic_fentry_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x26c8, 0x28c, arm64_l_28c);
arm64_l_26cc:
	/* 0x26cc: b 2f64 <generic_fentry_filter_arg+0x2f64> */
	ARM64_SIM_A64_JMP(0x26cc, 0x2f64, arm64_l_2f64);
arm64_l_26d0:
	/* 0x26d0: cbz w8, 2c44 <generic_fentry_filter_arg+0x2c44> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x26d0, 0x2c44, arm64_l_2c44);
arm64_l_26d4:
	/* 0x26d4: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_26d8:
	/* 0x26d8: b.ne 7bc <generic_fentry_filter_arg+0x7bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x26d8, 0x7bc, arm64_l_7bc);
arm64_l_26dc:
	/* 0x26dc: adrp x0, 0 <string_maps_1> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_1_9));
arm64_l_26e0:
	/* 0x26e0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_26e4:
	/* 0x26e4: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_26e8:
	/* 0x26e8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_26ec:
	/* 0x26ec: b 2ccc <generic_fentry_filter_arg+0x2ccc> */
	ARM64_SIM_A64_JMP(0x26ec, 0x2ccc, arm64_l_2ccc);
arm64_l_26f0:
	/* 0x26f0: cmp w13, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26f4:
	/* 0x26f4: ccmp w10, w12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_26f8:
	/* 0x26f8: cset w12, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_26fc:
	/* 0x26fc: orr w8, w8, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_2700:
	/* 0x2700: cmp w11, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2704:
	/* 0x2704: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2708:
	/* 0x2708: b.cc 2b68 <generic_fentry_filter_arg+0x2b68> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2708, 0x2b68, arm64_l_2b68);
arm64_l_270c:
	/* 0x270c: ldp w12, w11, [x23, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2710:
	/* 0x2710: mov w13, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2714:
	/* 0x2714: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2718:
	/* 0x2718: b.hi 2b54 <generic_fentry_filter_arg+0x2b54> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2718, 0x2b54, arm64_l_2b54);
arm64_l_271c:
	/* 0x271c: lsl w9, w13, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X13, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2720:
	/* 0x2720: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2724:
	/* 0x2724: tst w9, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2728:
	/* 0x2728: b.eq 2b54 <generic_fentry_filter_arg+0x2b54> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2728, 0x2b54, arm64_l_2b54);
arm64_l_272c:
	/* 0x272c: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2730:
	/* 0x2730: ccmp w10, w11, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_2734:
	/* 0x2734: cset w9, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_2738:
	/* 0x2738: b 2b60 <generic_fentry_filter_arg+0x2b60> */
	ARM64_SIM_A64_JMP(0x2738, 0x2b60, arm64_l_2b60);
arm64_l_273c:
	/* 0x273c: and w8, w25, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_2740:
	/* 0x2740: cmp w8, #0x201 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 513ULL);
arm64_l_2744:
	/* 0x2744: b.cs 2cf0 <generic_fentry_filter_arg+0x2cf0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2744, 0x2cf0, arm64_l_2cf0);
arm64_l_2748:
	/* 0x2748: mov w11, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 512ULL);
arm64_l_274c:
	/* 0x274c: b 307c <generic_fentry_filter_arg+0x307c> */
	ARM64_SIM_A64_JMP(0x274c, 0x307c, arm64_l_307c);
arm64_l_2750:
	/* 0x2750: cmp w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2754:
	/* 0x2754: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2758:
	/* 0x2758: b.hi 2764 <generic_fentry_filter_arg+0x2764> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2758, 0x2764, arm64_l_2764);
arm64_l_275c:
	/* 0x275c: cmp w8, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2760:
	/* 0x2760: b.ls 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2760, 0x298, arm64_l_298);
arm64_l_2764:
	/* 0x2764: cmp w10, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2768:
	/* 0x2768: b.cc fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2768, 0xfc, arm64_l_fc);
arm64_l_276c:
	/* 0x276c: ldp w11, w10, [x23, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2770:
	/* 0x2770: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2774:
	/* 0x2774: b.hi 2d00 <generic_fentry_filter_arg+0x2d00> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2774, 0x2d00, arm64_l_2d00);
arm64_l_2778:
	/* 0x2778: lsl w9, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_277c:
	/* 0x277c: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2780:
	/* 0x2780: tst w9, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2784:
	/* 0x2784: b.eq 2d00 <generic_fentry_filter_arg+0x2d00> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2784, 0x2d00, arm64_l_2d00);
arm64_l_2788:
	/* 0x2788: cmp w11, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_278c:
	/* 0x278c: b.gt fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x278c, 0xfc, arm64_l_fc);
arm64_l_2790:
	/* 0x2790: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2794:
	/* 0x2794: b.le 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2794, 0x298, arm64_l_298);
arm64_l_2798:
	/* 0x2798: b fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x2798, 0xfc, arm64_l_fc);
arm64_l_279c:
	/* 0x279c: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_27a0:
	/* 0x27a0: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_27a4:
	/* 0x27a4: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_27a8:
	/* 0x27a8: b.hi 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x27a8, 0x298, arm64_l_298);
arm64_l_27ac:
	/* 0x27ac: b 27c0 <generic_fentry_filter_arg+0x27c0> */
	ARM64_SIM_A64_JMP(0x27ac, 0x27c0, arm64_l_27c0);
arm64_l_27b0:
	/* 0x27b0: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_27b4:
	/* 0x27b4: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_27b8:
	/* 0x27b8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_27bc:
	/* 0x27bc: b.cc 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x27bc, 0x298, arm64_l_298);
arm64_l_27c0:
	/* 0x27c0: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_27c4:
	/* 0x27c4: b.cc 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x27c4, 0x3400, arm64_l_3400);
arm64_l_27c8:
	/* 0x27c8: ldr w11, [x23, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_27cc:
	/* 0x27cc: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_27d0:
	/* 0x27d0: b.le 27f4 <generic_fentry_filter_arg+0x27f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x27d0, 0x27f4, arm64_l_27f4);
arm64_l_27d4:
	/* 0x27d4: sub w12, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_27d8:
	/* 0x27d8: cmp w12, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_27dc:
	/* 0x27dc: b.cs 2834 <generic_fentry_filter_arg+0x2834> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x27dc, 0x2834, arm64_l_2834);
arm64_l_27e0:
	/* 0x27e0: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_27e4:
	/* 0x27e4: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_27e8:
	/* 0x27e8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_27ec:
	/* 0x27ec: b.eq 28c <generic_fentry_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x27ec, 0x28c, arm64_l_28c);
arm64_l_27f0:
	/* 0x27f0: b 2fc0 <generic_fentry_filter_arg+0x2fc0> */
	ARM64_SIM_A64_JMP(0x27f0, 0x2fc0, arm64_l_2fc0);
arm64_l_27f4:
	/* 0x27f4: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_27f8:
	/* 0x27f8: b.eq 2854 <generic_fentry_filter_arg+0x2854> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x27f8, 0x2854, arm64_l_2854);
arm64_l_27fc:
	/* 0x27fc: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2800:
	/* 0x2800: b.ne 2fc0 <generic_fentry_filter_arg+0x2fc0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2800, 0x2fc0, arm64_l_2fc0);
arm64_l_2804:
	/* 0x2804: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2808:
	/* 0x2808: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_280c:
	/* 0x280c: b.hi 2fb0 <generic_fentry_filter_arg+0x2fb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x280c, 0x2fb0, arm64_l_2fb0);
arm64_l_2810:
	/* 0x2810: lsl w12, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X12, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2814:
	/* 0x2814: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2818:
	/* 0x2818: tst w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_281c:
	/* 0x281c: b.eq 2fb0 <generic_fentry_filter_arg+0x2fb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x281c, 0x2fb0, arm64_l_2fb0);
arm64_l_2820:
	/* 0x2820: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2824:
	/* 0x2824: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2828:
	/* 0x2828: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_282c:
	/* 0x282c: b.lt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x282c, 0x298, arm64_l_298);
arm64_l_2830:
	/* 0x2830: b 2fc0 <generic_fentry_filter_arg+0x2fc0> */
	ARM64_SIM_A64_JMP(0x2830, 0x2fc0, arm64_l_2fc0);
arm64_l_2834:
	/* 0x2834: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2838:
	/* 0x2838: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_283c:
	/* 0x283c: b.ne 2fc0 <generic_fentry_filter_arg+0x2fc0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x283c, 0x2fc0, arm64_l_2fc0);
arm64_l_2840:
	/* 0x2840: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2844:
	/* 0x2844: tst w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2848:
	/* 0x2848: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_284c:
	/* 0x284c: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x284c, 0x298, arm64_l_298);
arm64_l_2850:
	/* 0x2850: b 2fc0 <generic_fentry_filter_arg+0x2fc0> */
	ARM64_SIM_A64_JMP(0x2850, 0x2fc0, arm64_l_2fc0);
arm64_l_2854:
	/* 0x2854: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2858:
	/* 0x2858: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_285c:
	/* 0x285c: b.hi 2f9c <generic_fentry_filter_arg+0x2f9c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x285c, 0x2f9c, arm64_l_2f9c);
arm64_l_2860:
	/* 0x2860: lsl w12, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X12, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2864:
	/* 0x2864: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2868:
	/* 0x2868: tst w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_286c:
	/* 0x286c: b.eq 2f9c <generic_fentry_filter_arg+0x2f9c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x286c, 0x2f9c, arm64_l_2f9c);
arm64_l_2870:
	/* 0x2870: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2874:
	/* 0x2874: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2878:
	/* 0x2878: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_287c:
	/* 0x287c: b.gt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x287c, 0x298, arm64_l_298);
arm64_l_2880:
	/* 0x2880: b 2fc0 <generic_fentry_filter_arg+0x2fc0> */
	ARM64_SIM_A64_JMP(0x2880, 0x2fc0, arm64_l_2fc0);
arm64_l_2884:
	/* 0x2884: cmp x12, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2888:
	/* 0x2888: ccmp x10, x11, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_288c:
	/* 0x288c: cset w9, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_2890:
	/* 0x2890: orr w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_2894:
	/* 0x2894: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2898:
	/* 0x2898: tbz w8, #0, 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 0, 0x2898, 0x298, arm64_l_298);
arm64_l_289c:
	/* 0x289c: b fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x289c, 0xfc, arm64_l_fc);
arm64_l_28a0:
	/* 0x28a0: cbz w25, 2d40 <generic_fentry_filter_arg+0x2d40> */
	ARM64_SIM_A64_CBZ(ARM64_X25, 0x28a0, 0x2d40, arm64_l_2d40);
arm64_l_28a4:
	/* 0x28a4: cmp w25, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_28a8:
	/* 0x28a8: b.ne 2e2c <generic_fentry_filter_arg+0x2e2c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x28a8, 0x2e2c, arm64_l_2e2c);
arm64_l_28ac:
	/* 0x28ac: adrp x0, 0 <string_maps_1> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_1_9));
arm64_l_28b0:
	/* 0x28b0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28b4:
	/* 0x28b4: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_28b8:
	/* 0x28b8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_28bc:
	/* 0x28bc: b 2dc8 <generic_fentry_filter_arg+0x2dc8> */
	ARM64_SIM_A64_JMP(0x28bc, 0x2dc8, arm64_l_2dc8);
arm64_l_28c0:
	/* 0x28c0: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_28c4:
	/* 0x28c4: b.hi fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x28c4, 0xfc, arm64_l_fc);
arm64_l_28c8:
	/* 0x28c8: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_28cc:
	/* 0x28cc: b.ls 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x28cc, 0x298, arm64_l_298);
arm64_l_28d0:
	/* 0x28d0: b fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x28d0, 0xfc, arm64_l_fc);
arm64_l_28d4:
	/* 0x28d4: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_28d8:
	/* 0x28d8: b.eq 2f14 <generic_fentry_filter_arg+0x2f14> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x28d8, 0x2f14, arm64_l_2f14);
arm64_l_28dc:
	/* 0x28dc: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_28e0:
	/* 0x28e0: b.ne 2f20 <generic_fentry_filter_arg+0x2f20> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x28e0, 0x2f20, arm64_l_2f20);
arm64_l_28e4:
	/* 0x28e4: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_28e8:
	/* 0x28e8: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_28ec:
	/* 0x28ec: b.hi 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x28ec, 0x298, arm64_l_298);
arm64_l_28f0:
	/* 0x28f0: b 2f20 <generic_fentry_filter_arg+0x2f20> */
	ARM64_SIM_A64_JMP(0x28f0, 0x2f20, arm64_l_2f20);
arm64_l_28f4:
	/* 0x28f4: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_28f8:
	/* 0x28f8: b.eq 2f58 <generic_fentry_filter_arg+0x2f58> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x28f8, 0x2f58, arm64_l_2f58);
arm64_l_28fc:
	/* 0x28fc: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2900:
	/* 0x2900: b.ne 2f64 <generic_fentry_filter_arg+0x2f64> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2900, 0x2f64, arm64_l_2f64);
arm64_l_2904:
	/* 0x2904: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2908:
	/* 0x2908: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_290c:
	/* 0x290c: b.hi 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x290c, 0x298, arm64_l_298);
arm64_l_2910:
	/* 0x2910: b 2f64 <generic_fentry_filter_arg+0x2f64> */
	ARM64_SIM_A64_JMP(0x2910, 0x2f64, arm64_l_2f64);
arm64_l_2914:
	/* 0x2914: and w8, w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_2918:
	/* 0x2918: mov w9, #0x1000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_291c:
	/* 0x291c: cmp w8, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2048ULL);
arm64_l_2920:
	/* 0x2920: mov w8, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_2924:
	/* 0x2924: csel w11, w9, w8, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_2928:
	/* 0x2928: sub w8, w11, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_292c:
	/* 0x292c: ror w8, w8, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_ROR), 8ULL);
arm64_l_2930:
	/* 0x2930: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2934:
	/* 0x2934: b.gt 294c <generic_fentry_filter_arg+0x294c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2934, 0x294c, arm64_l_294c);
arm64_l_2938:
	/* 0x2938: cbz w8, 296c <generic_fentry_filter_arg+0x296c> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x2938, 0x296c, arm64_l_296c);
arm64_l_293c:
	/* 0x293c: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2940:
	/* 0x2940: b.ne 2964 <generic_fentry_filter_arg+0x2964> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2940, 0x2964, arm64_l_2964);
arm64_l_2944:
	/* 0x2944: mov w10, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 7ULL);
arm64_l_2948:
	/* 0x2948: b 2978 <generic_fentry_filter_arg+0x2978> */
	ARM64_SIM_A64_JMP(0x2948, 0x2978, arm64_l_2978);
arm64_l_294c:
	/* 0x294c: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2950:
	/* 0x2950: b.eq 2974 <generic_fentry_filter_arg+0x2974> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2950, 0x2974, arm64_l_2974);
arm64_l_2954:
	/* 0x2954: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_2958:
	/* 0x2958: b.ne 2964 <generic_fentry_filter_arg+0x2964> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2958, 0x2964, arm64_l_2964);
arm64_l_295c:
	/* 0x295c: mov w10, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 9ULL);
arm64_l_2960:
	/* 0x2960: b 2978 <generic_fentry_filter_arg+0x2978> */
	ARM64_SIM_A64_JMP(0x2960, 0x2978, arm64_l_2978);
arm64_l_2964:
	/* 0x2964: mov w10, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_2968:
	/* 0x2968: b 2978 <generic_fentry_filter_arg+0x2978> */
	ARM64_SIM_A64_JMP(0x2968, 0x2978, arm64_l_2978);
arm64_l_296c:
	/* 0x296c: mov w10, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 6ULL);
arm64_l_2970:
	/* 0x2970: b 2978 <generic_fentry_filter_arg+0x2978> */
	ARM64_SIM_A64_JMP(0x2970, 0x2978, arm64_l_2978);
arm64_l_2974:
	/* 0x2974: mov w10, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2978:
	/* 0x2978: add x8, x23, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_297c:
	/* 0x297c: and w9, w10, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_2980:
	/* 0x2980: ldr w8, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_2984:
	/* 0x2984: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2988:
	/* 0x2988: b.eq 2a3c <generic_fentry_filter_arg+0x2a3c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2988, 0x2a3c, arm64_l_2a3c);
arm64_l_298c:
	/* 0x298c: str w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2990:
	/* 0x2990: str w11, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2994:
	/* 0x2994: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_19));
arm64_l_2998:
	/* 0x2998: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_299c:
	/* 0x299c: add x22, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_29a0:
	/* 0x29a0: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_29a4:
	/* 0x29a4: str w10, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_29a8:
	/* 0x29a8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_29ac:
	/* 0x29ac: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x29b0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_29b0:
	/* 0x29b0: str x0, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_29b4:
	/* 0x29b4: adrp x0, 0 <heap_ro_zero> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero_5));
arm64_l_29b8:
	/* 0x29b8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_29bc:
	/* 0x29bc: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_29c0:
	/* 0x29c0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_29c4:
	/* 0x29c4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x29c8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_29c8:
	/* 0x29c8: ldr x9, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_29cc:
	/* 0x29cc: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_29d0:
	/* 0x29d0: cbz x9, 12b8 <generic_fentry_filter_arg+0x12b8> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x29d0, 0x12b8, arm64_l_12b8);
arm64_l_29d4:
	/* 0x29d4: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_29d8:
	/* 0x29d8: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_29dc:
	/* 0x29dc: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_29e0:
	/* 0x29e0: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_29e4:
	/* 0x29e4: cbz x0, 12c8 <generic_fentry_filter_arg+0x12c8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x29e4, 0x12c8, arm64_l_12c8);
arm64_l_29e8:
	/* 0x29e8: mov x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_29ec:
	/* 0x29ec: ldr w9, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_29f0:
	/* 0x29f0: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_29f4:
	/* 0x29f4: cmp w9, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_29f8:
	/* 0x29f8: b.gt 2a44 <generic_fentry_filter_arg+0x2a44> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x29f8, 0x2a44, arm64_l_2a44);
arm64_l_29fc:
	/* 0x29fc: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2a00:
	/* 0x2a00: mov x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2a04:
	/* 0x2a04: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2a08:
	/* 0x2a08: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2a0c:
	/* 0x2a0c: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2a10:
	/* 0x2a10: strb w29, [x0], #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 1ULL);
arm64_l_2a14:
	/* 0x2a14: mov x25, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2a18:
	/* 0x2a18: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2a1cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2a1c:
	/* 0x2a1c: ldr w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2a20:
	/* 0x2a20: subs w8, w8, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2a24:
	/* 0x2a24: b.ls 2a88 <generic_fentry_filter_arg+0x2a88> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2a24, 0x2a88, arm64_l_2a88);
arm64_l_2a28:
	/* 0x2a28: add x9, x25, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X25, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2a2c:
	/* 0x2a2c: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2a30:
	/* 0x2a30: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2a34:
	/* 0x2a34: add x0, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2a38:
	/* 0x2a38: b 2a80 <generic_fentry_filter_arg+0x2a80> */
	ARM64_SIM_A64_JMP(0x2a38, 0x2a80, arm64_l_2a80);
arm64_l_2a3c:
	/* 0x2a3c: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2a40:
	/* 0x2a40: b 12c4 <generic_fentry_filter_arg+0x12c4> */
	ARM64_SIM_A64_JMP(0x2a40, 0x12c4, arm64_l_12c4);
arm64_l_2a44:
	/* 0x2a44: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2a48:
	/* 0x2a48: mov x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2a4c:
	/* 0x2a4c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2a50:
	/* 0x2a50: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2a54:
	/* 0x2a54: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2a58:
	/* 0x2a58: strh w29, [x0], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_2a5c:
	/* 0x2a5c: mov x25, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2a60:
	/* 0x2a60: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2a64ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2a64:
	/* 0x2a64: ldr w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2a68:
	/* 0x2a68: subs w8, w8, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2a6c:
	/* 0x2a6c: b.ls 2a88 <generic_fentry_filter_arg+0x2a88> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2a6c, 0x2a88, arm64_l_2a88);
arm64_l_2a70:
	/* 0x2a70: add x9, x25, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X25, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2a74:
	/* 0x2a74: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2a78:
	/* 0x2a78: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2a7c:
	/* 0x2a7c: add x0, x9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2a80:
	/* 0x2a80: mov x2, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2a84:
	/* 0x2a84: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2a88ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2a88:
	/* 0x2a88: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2a8c:
	/* 0x2a8c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a90:
	/* 0x2a90: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_2a94:
	/* 0x2a94: ldr w8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2a98:
	/* 0x2a98: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2a9c:
	/* 0x2a9c: b.le 2ad4 <generic_fentry_filter_arg+0x2ad4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2a9c, 0x2ad4, arm64_l_2ad4);
arm64_l_2aa0:
	/* 0x2aa0: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_2aa4:
	/* 0x2aa4: b.gt 2b08 <generic_fentry_filter_arg+0x2b08> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2aa4, 0x2b08, arm64_l_2b08);
arm64_l_2aa8:
	/* 0x2aa8: cmp w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2aac:
	/* 0x2aac: b.eq 2eb0 <generic_fentry_filter_arg+0x2eb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2aac, 0x2eb0, arm64_l_2eb0);
arm64_l_2ab0:
	/* 0x2ab0: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2ab4:
	/* 0x2ab4: b.eq 2e74 <generic_fentry_filter_arg+0x2e74> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2ab4, 0x2e74, arm64_l_2e74);
arm64_l_2ab8:
	/* 0x2ab8: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_2abc:
	/* 0x2abc: b.ne 2f00 <generic_fentry_filter_arg+0x2f00> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2abc, 0x2f00, arm64_l_2f00);
arm64_l_2ac0:
	/* 0x2ac0: adrp x0, 0 <string_maps_7> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_7_16));
arm64_l_2ac4:
	/* 0x2ac4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2ac8:
	/* 0x2ac8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2acc:
	/* 0x2acc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ad0:
	/* 0x2ad0: b 2ed4 <generic_fentry_filter_arg+0x2ed4> */
	ARM64_SIM_A64_JMP(0x2ad0, 0x2ed4, arm64_l_2ed4);
arm64_l_2ad4:
	/* 0x2ad4: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2ad8:
	/* 0x2ad8: b.le 2b34 <generic_fentry_filter_arg+0x2b34> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2ad8, 0x2b34, arm64_l_2b34);
arm64_l_2adc:
	/* 0x2adc: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2ae0:
	/* 0x2ae0: b.eq 2e9c <generic_fentry_filter_arg+0x2e9c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2ae0, 0x2e9c, arm64_l_2e9c);
arm64_l_2ae4:
	/* 0x2ae4: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2ae8:
	/* 0x2ae8: b.eq 2e60 <generic_fentry_filter_arg+0x2e60> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2ae8, 0x2e60, arm64_l_2e60);
arm64_l_2aec:
	/* 0x2aec: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2af0:
	/* 0x2af0: b.ne 2f00 <generic_fentry_filter_arg+0x2f00> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2af0, 0x2f00, arm64_l_2f00);
arm64_l_2af4:
	/* 0x2af4: adrp x0, 0 <string_maps_4> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_4_13));
arm64_l_2af8:
	/* 0x2af8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2afc:
	/* 0x2afc: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2b00:
	/* 0x2b00: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b04:
	/* 0x2b04: b 2ed4 <generic_fentry_filter_arg+0x2ed4> */
	ARM64_SIM_A64_JMP(0x2b04, 0x2ed4, arm64_l_2ed4);
arm64_l_2b08:
	/* 0x2b08: cmp w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2b0c:
	/* 0x2b0c: b.eq 2ec4 <generic_fentry_filter_arg+0x2ec4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2b0c, 0x2ec4, arm64_l_2ec4);
arm64_l_2b10:
	/* 0x2b10: cmp w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_2b14:
	/* 0x2b14: b.eq 2e88 <generic_fentry_filter_arg+0x2e88> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2b14, 0x2e88, arm64_l_2e88);
arm64_l_2b18:
	/* 0x2b18: cmp w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2b1c:
	/* 0x2b1c: b.ne 2f00 <generic_fentry_filter_arg+0x2f00> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2b1c, 0x2f00, arm64_l_2f00);
arm64_l_2b20:
	/* 0x2b20: adrp x0, 0 <string_maps_10> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_10_10));
arm64_l_2b24:
	/* 0x2b24: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2b28:
	/* 0x2b28: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2b2c:
	/* 0x2b2c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b30:
	/* 0x2b30: b 2ed4 <generic_fentry_filter_arg+0x2ed4> */
	ARM64_SIM_A64_JMP(0x2b30, 0x2ed4, arm64_l_2ed4);
arm64_l_2b34:
	/* 0x2b34: cbz w8, 2e4c <generic_fentry_filter_arg+0x2e4c> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x2b34, 0x2e4c, arm64_l_2e4c);
arm64_l_2b38:
	/* 0x2b38: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2b3c:
	/* 0x2b3c: b.ne 2f00 <generic_fentry_filter_arg+0x2f00> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2b3c, 0x2f00, arm64_l_2f00);
arm64_l_2b40:
	/* 0x2b40: adrp x0, 0 <string_maps_1> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_1_9));
arm64_l_2b44:
	/* 0x2b44: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2b48:
	/* 0x2b48: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2b4c:
	/* 0x2b4c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b50:
	/* 0x2b50: b 2ed4 <generic_fentry_filter_arg+0x2ed4> */
	ARM64_SIM_A64_JMP(0x2b50, 0x2ed4, arm64_l_2ed4);
arm64_l_2b54:
	/* 0x2b54: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b58:
	/* 0x2b58: ccmp w10, w11, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_2b5c:
	/* 0x2b5c: cset w9, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_2b60:
	/* 0x2b60: orr w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_2b64:
	/* 0x2b64: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2b68:
	/* 0x2b68: tbz w8, #0, 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 0, 0x2b68, 0x298, arm64_l_298);
arm64_l_2b6c:
	/* 0x2b6c: b fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x2b6c, 0xfc, arm64_l_fc);
arm64_l_2b70:
	/* 0x2b70: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b74:
	/* 0x2b74: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b78:
	/* 0x2b78: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2b7c:
	/* 0x2b7c: b.hi 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2b7c, 0x298, arm64_l_298);
arm64_l_2b80:
	/* 0x2b80: b 2b94 <generic_fentry_filter_arg+0x2b94> */
	ARM64_SIM_A64_JMP(0x2b80, 0x2b94, arm64_l_2b94);
arm64_l_2b84:
	/* 0x2b84: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b88:
	/* 0x2b88: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b8c:
	/* 0x2b8c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2b90:
	/* 0x2b90: b.cc 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b90, 0x298, arm64_l_298);
arm64_l_2b94:
	/* 0x2b94: cmp w10, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2b98:
	/* 0x2b98: b.cc 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b98, 0x3400, arm64_l_3400);
arm64_l_2b9c:
	/* 0x2b9c: ldr x10, [x23, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2ba0:
	/* 0x2ba0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2ba4:
	/* 0x2ba4: b.le 2bd4 <generic_fentry_filter_arg+0x2bd4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2ba4, 0x2bd4, arm64_l_2bd4);
arm64_l_2ba8:
	/* 0x2ba8: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2bac:
	/* 0x2bac: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2bb0:
	/* 0x2bb0: b.cc 2c04 <generic_fentry_filter_arg+0x2c04> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2bb0, 0x2c04, arm64_l_2c04);
arm64_l_2bb4:
	/* 0x2bb4: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2bb8:
	/* 0x2bb8: b.eq 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2bb8, 0x298, arm64_l_298);
arm64_l_2bbc:
	/* 0x2bbc: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2bc0:
	/* 0x2bc0: b.ne fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2bc0, 0xfc, arm64_l_fc);
arm64_l_2bc4:
	/* 0x2bc4: ldr x9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2bc8:
	/* 0x2bc8: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2bcc:
	/* 0x2bcc: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2bcc, 0x298, arm64_l_298);
arm64_l_2bd0:
	/* 0x2bd0: b 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JMP(0x2bd0, 0x3400, arm64_l_3400);
arm64_l_2bd4:
	/* 0x2bd4: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2bd8:
	/* 0x2bd8: b.eq 2d14 <generic_fentry_filter_arg+0x2d14> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2bd8, 0x2d14, arm64_l_2d14);
arm64_l_2bdc:
	/* 0x2bdc: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2be0:
	/* 0x2be0: b.ne fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2be0, 0xfc, arm64_l_fc);
arm64_l_2be4:
	/* 0x2be4: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2be8:
	/* 0x2be8: b.eq 2bf4 <generic_fentry_filter_arg+0x2bf4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2be8, 0x2bf4, arm64_l_2bf4);
arm64_l_2bec:
	/* 0x2bec: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2bf0:
	/* 0x2bf0: b.ne 32bc <generic_fentry_filter_arg+0x32bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2bf0, 0x32bc, arm64_l_32bc);
arm64_l_2bf4:
	/* 0x2bf4: ldr x9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2bf8:
	/* 0x2bf8: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2bfc:
	/* 0x2bfc: b.lt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x2bfc, 0x298, arm64_l_298);
arm64_l_2c00:
	/* 0x2c00: b 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JMP(0x2c00, 0x3400, arm64_l_3400);
arm64_l_2c04:
	/* 0x2c04: ldr x9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c08:
	/* 0x2c08: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c0c:
	/* 0x2c0c: b.ne 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2c0c, 0x3400, arm64_l_3400);
arm64_l_2c10:
	/* 0x2c10: b 28c <generic_fentry_filter_arg+0x28c> */
	ARM64_SIM_A64_JMP(0x2c10, 0x28c, arm64_l_28c);
arm64_l_2c14:
	/* 0x2c14: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2c18:
	/* 0x2c18: b.ne 2f20 <generic_fentry_filter_arg+0x2f20> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2c18, 0x2f20, arm64_l_2f20);
arm64_l_2c1c:
	/* 0x2c1c: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c20:
	/* 0x2c20: tst w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c24:
	/* 0x2c24: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2c24, 0x298, arm64_l_298);
arm64_l_2c28:
	/* 0x2c28: b 2f20 <generic_fentry_filter_arg+0x2f20> */
	ARM64_SIM_A64_JMP(0x2c28, 0x2f20, arm64_l_2f20);
arm64_l_2c2c:
	/* 0x2c2c: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2c30:
	/* 0x2c30: b.ne 2f64 <generic_fentry_filter_arg+0x2f64> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2c30, 0x2f64, arm64_l_2f64);
arm64_l_2c34:
	/* 0x2c34: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c38:
	/* 0x2c38: tst w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c3c:
	/* 0x2c3c: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2c3c, 0x298, arm64_l_298);
arm64_l_2c40:
	/* 0x2c40: b 2f64 <generic_fentry_filter_arg+0x2f64> */
	ARM64_SIM_A64_JMP(0x2c40, 0x2f64, arm64_l_2f64);
arm64_l_2c44:
	/* 0x2c44: adrp x0, 0 <string_maps_0> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_0_8));
arm64_l_2c48:
	/* 0x2c48: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2c4c:
	/* 0x2c4c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2c50:
	/* 0x2c50: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c54:
	/* 0x2c54: b 2ccc <generic_fentry_filter_arg+0x2ccc> */
	ARM64_SIM_A64_JMP(0x2c54, 0x2ccc, arm64_l_2ccc);
arm64_l_2c58:
	/* 0x2c58: adrp x0, 0 <string_maps_3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_3_12));
arm64_l_2c5c:
	/* 0x2c5c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2c60:
	/* 0x2c60: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2c64:
	/* 0x2c64: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c68:
	/* 0x2c68: b 2ccc <generic_fentry_filter_arg+0x2ccc> */
	ARM64_SIM_A64_JMP(0x2c68, 0x2ccc, arm64_l_2ccc);
arm64_l_2c6c:
	/* 0x2c6c: adrp x0, 0 <string_maps_6> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_6_15));
arm64_l_2c70:
	/* 0x2c70: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2c74:
	/* 0x2c74: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2c78:
	/* 0x2c78: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c7c:
	/* 0x2c7c: b 2ccc <generic_fentry_filter_arg+0x2ccc> */
	ARM64_SIM_A64_JMP(0x2c7c, 0x2ccc, arm64_l_2ccc);
arm64_l_2c80:
	/* 0x2c80: adrp x0, 0 <string_maps_9> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_9_18));
arm64_l_2c84:
	/* 0x2c84: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2c88:
	/* 0x2c88: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2c8c:
	/* 0x2c8c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c90:
	/* 0x2c90: b 2ccc <generic_fentry_filter_arg+0x2ccc> */
	ARM64_SIM_A64_JMP(0x2c90, 0x2ccc, arm64_l_2ccc);
arm64_l_2c94:
	/* 0x2c94: adrp x0, 0 <string_maps_2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_2_11));
arm64_l_2c98:
	/* 0x2c98: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2c9c:
	/* 0x2c9c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2ca0:
	/* 0x2ca0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ca4:
	/* 0x2ca4: b 2ccc <generic_fentry_filter_arg+0x2ccc> */
	ARM64_SIM_A64_JMP(0x2ca4, 0x2ccc, arm64_l_2ccc);
arm64_l_2ca8:
	/* 0x2ca8: adrp x0, 0 <string_maps_5> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_5_14));
arm64_l_2cac:
	/* 0x2cac: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2cb0:
	/* 0x2cb0: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2cb4:
	/* 0x2cb4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2cb8:
	/* 0x2cb8: b 2ccc <generic_fentry_filter_arg+0x2ccc> */
	ARM64_SIM_A64_JMP(0x2cb8, 0x2ccc, arm64_l_2ccc);
arm64_l_2cbc:
	/* 0x2cbc: adrp x0, 0 <string_maps_8> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_8_17));
arm64_l_2cc0:
	/* 0x2cc0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2cc4:
	/* 0x2cc4: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2cc8:
	/* 0x2cc8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ccc:
	/* 0x2ccc: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2cd0:
	/* 0x2cd0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2cd4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2cd4:
	/* 0x2cd4: cbz x0, 2dec <generic_fentry_filter_arg+0x2dec> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2cd4, 0x2dec, arm64_l_2dec);
arm64_l_2cd8:
	/* 0x2cd8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2cdc:
	/* 0x2cdc: mov x1, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2ce0:
	/* 0x2ce0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2ce4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2ce4:
	/* 0x2ce4: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_2ce8:
	/* 0x2ce8: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2cec:
	/* 0x2cec: b 2df0 <generic_fentry_filter_arg+0x2df0> */
	ARM64_SIM_A64_JMP(0x2cec, 0x2df0, arm64_l_2df0);
arm64_l_2cf0:
	/* 0x2cf0: cmp w8, #0x401 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1025ULL);
arm64_l_2cf4:
	/* 0x2cf4: b.cs 3068 <generic_fentry_filter_arg+0x3068> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2cf4, 0x3068, arm64_l_3068);
arm64_l_2cf8:
	/* 0x2cf8: mov w11, #0x400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1024ULL);
arm64_l_2cfc:
	/* 0x2cfc: b 307c <generic_fentry_filter_arg+0x307c> */
	ARM64_SIM_A64_JMP(0x2cfc, 0x307c, arm64_l_307c);
arm64_l_2d00:
	/* 0x2d00: cmp w11, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d04:
	/* 0x2d04: b.hi fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2d04, 0xfc, arm64_l_fc);
arm64_l_2d08:
	/* 0x2d08: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d0c:
	/* 0x2d0c: b.ls 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2d0c, 0x298, arm64_l_298);
arm64_l_2d10:
	/* 0x2d10: b fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x2d10, 0xfc, arm64_l_fc);
arm64_l_2d14:
	/* 0x2d14: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2d18:
	/* 0x2d18: b.eq 2d24 <generic_fentry_filter_arg+0x2d24> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2d18, 0x2d24, arm64_l_2d24);
arm64_l_2d1c:
	/* 0x2d1c: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2d20:
	/* 0x2d20: b.ne 32cc <generic_fentry_filter_arg+0x32cc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2d20, 0x32cc, arm64_l_32cc);
arm64_l_2d24:
	/* 0x2d24: ldr x9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d28:
	/* 0x2d28: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d2c:
	/* 0x2d2c: b.gt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2d2c, 0x298, arm64_l_298);
arm64_l_2d30:
	/* 0x2d30: b 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JMP(0x2d30, 0x3400, arm64_l_3400);
arm64_l_2d34:
	/* 0x2d34: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2d38:
	/* 0x2d38: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2d3c:
	/* 0x2d3c: b 1e00 <generic_fentry_filter_arg+0x1e00> */
	ARM64_SIM_A64_JMP(0x2d3c, 0x1e00, arm64_l_1e00);
arm64_l_2d40:
	/* 0x2d40: adrp x0, 0 <string_maps_0> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_0_8));
arm64_l_2d44:
	/* 0x2d44: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2d48:
	/* 0x2d48: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2d4c:
	/* 0x2d4c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d50:
	/* 0x2d50: b 2dc8 <generic_fentry_filter_arg+0x2dc8> */
	ARM64_SIM_A64_JMP(0x2d50, 0x2dc8, arm64_l_2dc8);
arm64_l_2d54:
	/* 0x2d54: adrp x0, 0 <string_maps_3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_3_12));
arm64_l_2d58:
	/* 0x2d58: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2d5c:
	/* 0x2d5c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2d60:
	/* 0x2d60: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d64:
	/* 0x2d64: b 2dc8 <generic_fentry_filter_arg+0x2dc8> */
	ARM64_SIM_A64_JMP(0x2d64, 0x2dc8, arm64_l_2dc8);
arm64_l_2d68:
	/* 0x2d68: adrp x0, 0 <string_maps_6> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_6_15));
arm64_l_2d6c:
	/* 0x2d6c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2d70:
	/* 0x2d70: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2d74:
	/* 0x2d74: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d78:
	/* 0x2d78: b 2dc8 <generic_fentry_filter_arg+0x2dc8> */
	ARM64_SIM_A64_JMP(0x2d78, 0x2dc8, arm64_l_2dc8);
arm64_l_2d7c:
	/* 0x2d7c: adrp x0, 0 <string_maps_9> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_9_18));
arm64_l_2d80:
	/* 0x2d80: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2d84:
	/* 0x2d84: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2d88:
	/* 0x2d88: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d8c:
	/* 0x2d8c: b 2dc8 <generic_fentry_filter_arg+0x2dc8> */
	ARM64_SIM_A64_JMP(0x2d8c, 0x2dc8, arm64_l_2dc8);
arm64_l_2d90:
	/* 0x2d90: adrp x0, 0 <string_maps_2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_2_11));
arm64_l_2d94:
	/* 0x2d94: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2d98:
	/* 0x2d98: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2d9c:
	/* 0x2d9c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2da0:
	/* 0x2da0: b 2dc8 <generic_fentry_filter_arg+0x2dc8> */
	ARM64_SIM_A64_JMP(0x2da0, 0x2dc8, arm64_l_2dc8);
arm64_l_2da4:
	/* 0x2da4: adrp x0, 0 <string_maps_5> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_5_14));
arm64_l_2da8:
	/* 0x2da8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2dac:
	/* 0x2dac: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2db0:
	/* 0x2db0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2db4:
	/* 0x2db4: b 2dc8 <generic_fentry_filter_arg+0x2dc8> */
	ARM64_SIM_A64_JMP(0x2db4, 0x2dc8, arm64_l_2dc8);
arm64_l_2db8:
	/* 0x2db8: adrp x0, 0 <string_maps_8> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_8_17));
arm64_l_2dbc:
	/* 0x2dbc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2dc0:
	/* 0x2dc0: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2dc4:
	/* 0x2dc4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2dc8:
	/* 0x2dc8: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2dcc:
	/* 0x2dcc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2dd0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2dd0:
	/* 0x2dd0: cbz x0, 2dec <generic_fentry_filter_arg+0x2dec> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2dd0, 0x2dec, arm64_l_2dec);
arm64_l_2dd4:
	/* 0x2dd4: ldr x1, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2dd8:
	/* 0x2dd8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2ddc:
	/* 0x2ddc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2de0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2de0:
	/* 0x2de0: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_2de4:
	/* 0x2de4: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2de8:
	/* 0x2de8: b 2df0 <generic_fentry_filter_arg+0x2df0> */
	ARM64_SIM_A64_JMP(0x2de8, 0x2df0, arm64_l_2df0);
arm64_l_2dec:
	/* 0x2dec: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2df0:
	/* 0x2df0: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_2df4:
	/* 0x2df4: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_2df8:
	/* 0x2df8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2dfc:
	/* 0x2dfc: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2e00:
	/* 0x2e00: ldr w8, [x23, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2e04:
	/* 0x2e04: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_2e08:
	/* 0x2e08: b.hi 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2e08, 0x294, arm64_l_294);
arm64_l_2e0c:
	/* 0x2e0c: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_2e10:
	/* 0x2e10: lsl x8, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2e14:
	/* 0x2e14: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_2e18:
	/* 0x2e18: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_2e1c:
	/* 0x2e1c: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2e20:
	/* 0x2e20: b.eq 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2e20, 0x294, arm64_l_294);
arm64_l_2e24:
	/* 0x2e24: eor x22, x22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2e28:
	/* 0x2e28: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x2e28, 0x294, arm64_l_294);
arm64_l_2e2c:
	/* 0x2e2c: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_2e30:
	/* 0x2e30: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2e34:
	/* 0x2e34: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_2e38:
	/* 0x2e38: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2e3c:
	/* 0x2e3c: ldr w8, [x23, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2e40:
	/* 0x2e40: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_2e44:
	/* 0x2e44: b.ls 2e0c <generic_fentry_filter_arg+0x2e0c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2e44, 0x2e0c, arm64_l_2e0c);
arm64_l_2e48:
	/* 0x2e48: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x2e48, 0x294, arm64_l_294);
arm64_l_2e4c:
	/* 0x2e4c: adrp x0, 0 <string_maps_0> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_0_8));
arm64_l_2e50:
	/* 0x2e50: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2e54:
	/* 0x2e54: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2e58:
	/* 0x2e58: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2e5c:
	/* 0x2e5c: b 2ed4 <generic_fentry_filter_arg+0x2ed4> */
	ARM64_SIM_A64_JMP(0x2e5c, 0x2ed4, arm64_l_2ed4);
arm64_l_2e60:
	/* 0x2e60: adrp x0, 0 <string_maps_3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_3_12));
arm64_l_2e64:
	/* 0x2e64: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2e68:
	/* 0x2e68: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2e6c:
	/* 0x2e6c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2e70:
	/* 0x2e70: b 2ed4 <generic_fentry_filter_arg+0x2ed4> */
	ARM64_SIM_A64_JMP(0x2e70, 0x2ed4, arm64_l_2ed4);
arm64_l_2e74:
	/* 0x2e74: adrp x0, 0 <string_maps_6> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_6_15));
arm64_l_2e78:
	/* 0x2e78: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2e7c:
	/* 0x2e7c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2e80:
	/* 0x2e80: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2e84:
	/* 0x2e84: b 2ed4 <generic_fentry_filter_arg+0x2ed4> */
	ARM64_SIM_A64_JMP(0x2e84, 0x2ed4, arm64_l_2ed4);
arm64_l_2e88:
	/* 0x2e88: adrp x0, 0 <string_maps_9> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_9_18));
arm64_l_2e8c:
	/* 0x2e8c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2e90:
	/* 0x2e90: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2e94:
	/* 0x2e94: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2e98:
	/* 0x2e98: b 2ed4 <generic_fentry_filter_arg+0x2ed4> */
	ARM64_SIM_A64_JMP(0x2e98, 0x2ed4, arm64_l_2ed4);
arm64_l_2e9c:
	/* 0x2e9c: adrp x0, 0 <string_maps_2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_2_11));
arm64_l_2ea0:
	/* 0x2ea0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2ea4:
	/* 0x2ea4: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2ea8:
	/* 0x2ea8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2eac:
	/* 0x2eac: b 2ed4 <generic_fentry_filter_arg+0x2ed4> */
	ARM64_SIM_A64_JMP(0x2eac, 0x2ed4, arm64_l_2ed4);
arm64_l_2eb0:
	/* 0x2eb0: adrp x0, 0 <string_maps_5> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_5_14));
arm64_l_2eb4:
	/* 0x2eb4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2eb8:
	/* 0x2eb8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2ebc:
	/* 0x2ebc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ec0:
	/* 0x2ec0: b 2ed4 <generic_fentry_filter_arg+0x2ed4> */
	ARM64_SIM_A64_JMP(0x2ec0, 0x2ed4, arm64_l_2ed4);
arm64_l_2ec4:
	/* 0x2ec4: adrp x0, 0 <string_maps_8> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_8_17));
arm64_l_2ec8:
	/* 0x2ec8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2ecc:
	/* 0x2ecc: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2ed0:
	/* 0x2ed0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ed4:
	/* 0x2ed4: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2ed8:
	/* 0x2ed8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2edcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2edc:
	/* 0x2edc: cbz x0, 2ef8 <generic_fentry_filter_arg+0x2ef8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2edc, 0x2ef8, arm64_l_2ef8);
arm64_l_2ee0:
	/* 0x2ee0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2ee4:
	/* 0x2ee4: mov x1, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2ee8:
	/* 0x2ee8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2eecULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2eec:
	/* 0x2eec: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_2ef0:
	/* 0x2ef0: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2ef4:
	/* 0x2ef4: b 12b8 <generic_fentry_filter_arg+0x12b8> */
	ARM64_SIM_A64_JMP(0x2ef4, 0x12b8, arm64_l_12b8);
arm64_l_2ef8:
	/* 0x2ef8: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2efc:
	/* 0x2efc: b 12b8 <generic_fentry_filter_arg+0x12b8> */
	ARM64_SIM_A64_JMP(0x2efc, 0x12b8, arm64_l_12b8);
arm64_l_2f00:
	/* 0x2f00: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_2f04:
	/* 0x2f04: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2f08:
	/* 0x2f08: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_2f0c:
	/* 0x2f0c: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2f10:
	/* 0x2f10: b 12c8 <generic_fentry_filter_arg+0x12c8> */
	ARM64_SIM_A64_JMP(0x2f10, 0x12c8, arm64_l_12c8);
arm64_l_2f14:
	/* 0x2f14: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2f18:
	/* 0x2f18: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2f1c:
	/* 0x2f1c: b.cc 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2f1c, 0x298, arm64_l_298);
arm64_l_2f20:
	/* 0x2f20: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2f24:
	/* 0x2f24: b.cc 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2f24, 0x3400, arm64_l_3400);
arm64_l_2f28:
	/* 0x2f28: ldr w9, [x23, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2f2c:
	/* 0x2f2c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2f30:
	/* 0x2f30: b.le 3274 <generic_fentry_filter_arg+0x3274> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2f30, 0x3274, arm64_l_3274);
arm64_l_2f34:
	/* 0x2f34: sub w10, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2f38:
	/* 0x2f38: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2f3c:
	/* 0x2f3c: b.cc 32a4 <generic_fentry_filter_arg+0x32a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2f3c, 0x32a4, arm64_l_32a4);
arm64_l_2f40:
	/* 0x2f40: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2f44:
	/* 0x2f44: b.eq 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2f44, 0x298, arm64_l_298);
arm64_l_2f48:
	/* 0x2f48: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2f4c:
	/* 0x2f4c: b.ne fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2f4c, 0xfc, arm64_l_fc);
arm64_l_2f50:
	/* 0x2f50: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2f54:
	/* 0x2f54: b 2ff4 <generic_fentry_filter_arg+0x2ff4> */
	ARM64_SIM_A64_JMP(0x2f54, 0x2ff4, arm64_l_2ff4);
arm64_l_2f58:
	/* 0x2f58: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2f5c:
	/* 0x2f5c: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2f60:
	/* 0x2f60: b.cc 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2f60, 0x298, arm64_l_298);
arm64_l_2f64:
	/* 0x2f64: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2f68:
	/* 0x2f68: b.cc 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2f68, 0x3400, arm64_l_3400);
arm64_l_2f6c:
	/* 0x2f6c: ldr w9, [x23, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2f70:
	/* 0x2f70: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2f74:
	/* 0x2f74: b.le 328c <generic_fentry_filter_arg+0x328c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2f74, 0x328c, arm64_l_328c);
arm64_l_2f78:
	/* 0x2f78: sub w10, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2f7c:
	/* 0x2f7c: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2f80:
	/* 0x2f80: b.cc 32ac <generic_fentry_filter_arg+0x32ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2f80, 0x32ac, arm64_l_32ac);
arm64_l_2f84:
	/* 0x2f84: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2f88:
	/* 0x2f88: b.eq 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2f88, 0x298, arm64_l_298);
arm64_l_2f8c:
	/* 0x2f8c: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2f90:
	/* 0x2f90: b.ne fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2f90, 0xfc, arm64_l_fc);
arm64_l_2f94:
	/* 0x2f94: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2f98:
	/* 0x2f98: b 2ff4 <generic_fentry_filter_arg+0x2ff4> */
	ARM64_SIM_A64_JMP(0x2f98, 0x2ff4, arm64_l_2ff4);
arm64_l_2f9c:
	/* 0x2f9c: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2fa0:
	/* 0x2fa0: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2fa4:
	/* 0x2fa4: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2fa8:
	/* 0x2fa8: b.hi 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2fa8, 0x298, arm64_l_298);
arm64_l_2fac:
	/* 0x2fac: b 2fc0 <generic_fentry_filter_arg+0x2fc0> */
	ARM64_SIM_A64_JMP(0x2fac, 0x2fc0, arm64_l_2fc0);
arm64_l_2fb0:
	/* 0x2fb0: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2fb4:
	/* 0x2fb4: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2fb8:
	/* 0x2fb8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2fbc:
	/* 0x2fbc: b.cc 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2fbc, 0x298, arm64_l_298);
arm64_l_2fc0:
	/* 0x2fc0: cmp w10, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2fc4:
	/* 0x2fc4: b.cc 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2fc4, 0x3400, arm64_l_3400);
arm64_l_2fc8:
	/* 0x2fc8: ldr w10, [x23, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2fcc:
	/* 0x2fcc: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2fd0:
	/* 0x2fd0: b.le 3000 <generic_fentry_filter_arg+0x3000> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2fd0, 0x3000, arm64_l_3000);
arm64_l_2fd4:
	/* 0x2fd4: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2fd8:
	/* 0x2fd8: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2fdc:
	/* 0x2fdc: b.cc 3038 <generic_fentry_filter_arg+0x3038> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2fdc, 0x3038, arm64_l_3038);
arm64_l_2fe0:
	/* 0x2fe0: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2fe4:
	/* 0x2fe4: b.eq 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2fe4, 0x298, arm64_l_298);
arm64_l_2fe8:
	/* 0x2fe8: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2fec:
	/* 0x2fec: b.ne fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2fec, 0xfc, arm64_l_fc);
arm64_l_2ff0:
	/* 0x2ff0: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ff4:
	/* 0x2ff4: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2ff8:
	/* 0x2ff8: b.ne 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2ff8, 0x298, arm64_l_298);
arm64_l_2ffc:
	/* 0x2ffc: b 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JMP(0x2ffc, 0x3400, arm64_l_3400);
arm64_l_3000:
	/* 0x3000: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3004:
	/* 0x3004: b.eq 3040 <generic_fentry_filter_arg+0x3040> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3004, 0x3040, arm64_l_3040);
arm64_l_3008:
	/* 0x3008: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_300c:
	/* 0x300c: b.ne fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x300c, 0xfc, arm64_l_fc);
arm64_l_3010:
	/* 0x3010: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_3014:
	/* 0x3014: b.hi 33e4 <generic_fentry_filter_arg+0x33e4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x3014, 0x33e4, arm64_l_33e4);
arm64_l_3018:
	/* 0x3018: lsl w9, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_301c:
	/* 0x301c: mov w11, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_3020:
	/* 0x3020: tst w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3024:
	/* 0x3024: b.eq 33e4 <generic_fentry_filter_arg+0x33e4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3024, 0x33e4, arm64_l_33e4);
arm64_l_3028:
	/* 0x3028: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_302c:
	/* 0x302c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3030:
	/* 0x3030: b.lt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x3030, 0x298, arm64_l_298);
arm64_l_3034:
	/* 0x3034: b 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JMP(0x3034, 0x3400, arm64_l_3400);
arm64_l_3038:
	/* 0x3038: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_303c:
	/* 0x303c: b 32b0 <generic_fentry_filter_arg+0x32b0> */
	ARM64_SIM_A64_JMP(0x303c, 0x32b0, arm64_l_32b0);
arm64_l_3040:
	/* 0x3040: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_3044:
	/* 0x3044: b.hi 33f4 <generic_fentry_filter_arg+0x33f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x3044, 0x33f4, arm64_l_33f4);
arm64_l_3048:
	/* 0x3048: lsl w9, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_304c:
	/* 0x304c: mov w11, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_3050:
	/* 0x3050: tst w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3054:
	/* 0x3054: b.eq 33f4 <generic_fentry_filter_arg+0x33f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3054, 0x33f4, arm64_l_33f4);
arm64_l_3058:
	/* 0x3058: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_305c:
	/* 0x305c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3060:
	/* 0x3060: b.gt 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x3060, 0x298, arm64_l_298);
arm64_l_3064:
	/* 0x3064: b 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JMP(0x3064, 0x3400, arm64_l_3400);
arm64_l_3068:
	/* 0x3068: and w8, w25, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_306c:
	/* 0x306c: mov w9, #0x1000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_3070:
	/* 0x3070: cmp w8, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2048ULL);
arm64_l_3074:
	/* 0x3074: mov w8, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_3078:
	/* 0x3078: csel w11, w9, w8, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_307c:
	/* 0x307c: sub w8, w11, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_3080:
	/* 0x3080: ror w8, w8, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_ROR), 8ULL);
arm64_l_3084:
	/* 0x3084: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3088:
	/* 0x3088: b.gt 30a0 <generic_fentry_filter_arg+0x30a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x3088, 0x30a0, arm64_l_30a0);
arm64_l_308c:
	/* 0x308c: cbz w8, 30c0 <generic_fentry_filter_arg+0x30c0> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x308c, 0x30c0, arm64_l_30c0);
arm64_l_3090:
	/* 0x3090: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3094:
	/* 0x3094: b.ne 30b8 <generic_fentry_filter_arg+0x30b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3094, 0x30b8, arm64_l_30b8);
arm64_l_3098:
	/* 0x3098: mov w10, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 7ULL);
arm64_l_309c:
	/* 0x309c: b 30cc <generic_fentry_filter_arg+0x30cc> */
	ARM64_SIM_A64_JMP(0x309c, 0x30cc, arm64_l_30cc);
arm64_l_30a0:
	/* 0x30a0: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_30a4:
	/* 0x30a4: b.eq 30c8 <generic_fentry_filter_arg+0x30c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x30a4, 0x30c8, arm64_l_30c8);
arm64_l_30a8:
	/* 0x30a8: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_30ac:
	/* 0x30ac: b.ne 30b8 <generic_fentry_filter_arg+0x30b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x30ac, 0x30b8, arm64_l_30b8);
arm64_l_30b0:
	/* 0x30b0: mov w10, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 9ULL);
arm64_l_30b4:
	/* 0x30b4: b 30cc <generic_fentry_filter_arg+0x30cc> */
	ARM64_SIM_A64_JMP(0x30b4, 0x30cc, arm64_l_30cc);
arm64_l_30b8:
	/* 0x30b8: mov w10, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_30bc:
	/* 0x30bc: b 30cc <generic_fentry_filter_arg+0x30cc> */
	ARM64_SIM_A64_JMP(0x30bc, 0x30cc, arm64_l_30cc);
arm64_l_30c0:
	/* 0x30c0: mov w10, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 6ULL);
arm64_l_30c4:
	/* 0x30c4: b 30cc <generic_fentry_filter_arg+0x30cc> */
	ARM64_SIM_A64_JMP(0x30c4, 0x30cc, arm64_l_30cc);
arm64_l_30c8:
	/* 0x30c8: mov w10, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_30cc:
	/* 0x30cc: add x8, x23, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_30d0:
	/* 0x30d0: and w9, w10, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_30d4:
	/* 0x30d4: ldr w8, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_30d8:
	/* 0x30d8: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_30dc:
	/* 0x30dc: b.eq 3388 <generic_fentry_filter_arg+0x3388> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x30dc, 0x3388, arm64_l_3388);
arm64_l_30e0:
	/* 0x30e0: stp w8, w11, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_30e4:
	/* 0x30e4: str w10, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_30e8:
	/* 0x30e8: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_19));
arm64_l_30ec:
	/* 0x30ec: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_30f0:
	/* 0x30f0: add x19, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_30f4:
	/* 0x30f4: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_30f8:
	/* 0x30f8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_30fc:
	/* 0x30fc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x3100ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3100:
	/* 0x3100: mov x9, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3104:
	/* 0x3104: adrp x0, 0 <heap_ro_zero> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero_5));
arm64_l_3108:
	/* 0x3108: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_310c:
	/* 0x310c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3110:
	/* 0x3110: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_3114:
	/* 0x3114: mov x19, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3118:
	/* 0x3118: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x311cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_311c:
	/* 0x311c: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3120:
	/* 0x3120: cbz x19, 338c <generic_fentry_filter_arg+0x338c> */
	ARM64_SIM_A64_CBZ(ARM64_X19, 0x3120, 0x338c, arm64_l_338c);
arm64_l_3124:
	/* 0x3124: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3128:
	/* 0x3128: cbz x0, 3390 <generic_fentry_filter_arg+0x3390> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x3128, 0x3390, arm64_l_3390);
arm64_l_312c:
	/* 0x312c: ldr w22, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_3130:
	/* 0x3130: str x0, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_3134:
	/* 0x3134: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3138:
	/* 0x3138: cmp w22, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_313c:
	/* 0x313c: b.gt 3178 <generic_fentry_filter_arg+0x3178> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x313c, 0x3178, arm64_l_3178);
arm64_l_3140:
	/* 0x3140: strb w25, [x0], #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 1ULL);
arm64_l_3144:
	/* 0x3144: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_3148:
	/* 0x3148: mov w1, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_314c:
	/* 0x314c: mov x2, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3150:
	/* 0x3150: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x3154ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3154:
	/* 0x3154: ldr w8, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_3158:
	/* 0x3158: subs w8, w8, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_315c:
	/* 0x315c: b.ls 31b0 <generic_fentry_filter_arg+0x31b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x315c, 0x31b0, arm64_l_31b0);
arm64_l_3160:
	/* 0x3160: add x9, x19, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X19, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_3164:
	/* 0x3164: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_3168:
	/* 0x3168: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_316c:
	/* 0x316c: ldr x2, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_3170:
	/* 0x3170: add x0, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3174:
	/* 0x3174: b 31ac <generic_fentry_filter_arg+0x31ac> */
	ARM64_SIM_A64_JMP(0x3174, 0x31ac, arm64_l_31ac);
arm64_l_3178:
	/* 0x3178: strh w25, [x0], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_317c:
	/* 0x317c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_3180:
	/* 0x3180: mov w1, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_3184:
	/* 0x3184: mov x2, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3188:
	/* 0x3188: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x318cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_318c:
	/* 0x318c: ldr w8, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_3190:
	/* 0x3190: subs w8, w8, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3194:
	/* 0x3194: b.ls 31b0 <generic_fentry_filter_arg+0x31b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x3194, 0x31b0, arm64_l_31b0);
arm64_l_3198:
	/* 0x3198: add x9, x19, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X19, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_319c:
	/* 0x319c: ldr x2, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_31a0:
	/* 0x31a0: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_31a4:
	/* 0x31a4: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_31a8:
	/* 0x31a8: add x0, x9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_31ac:
	/* 0x31ac: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x31b0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_31b0:
	/* 0x31b0: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_31b4:
	/* 0x31b4: cmp w22, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_31b8:
	/* 0x31b8: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_31bc:
	/* 0x31bc: b.le 31f4 <generic_fentry_filter_arg+0x31f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x31bc, 0x31f4, arm64_l_31f4);
arm64_l_31c0:
	/* 0x31c0: cmp w22, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_31c4:
	/* 0x31c4: b.gt 3228 <generic_fentry_filter_arg+0x3228> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x31c4, 0x3228, arm64_l_3228);
arm64_l_31c8:
	/* 0x31c8: cmp w22, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_31cc:
	/* 0x31cc: b.eq 3340 <generic_fentry_filter_arg+0x3340> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x31cc, 0x3340, arm64_l_3340);
arm64_l_31d0:
	/* 0x31d0: cmp w22, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_31d4:
	/* 0x31d4: b.eq 3304 <generic_fentry_filter_arg+0x3304> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x31d4, 0x3304, arm64_l_3304);
arm64_l_31d8:
	/* 0x31d8: cmp w22, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_31dc:
	/* 0x31dc: b.ne 3388 <generic_fentry_filter_arg+0x3388> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x31dc, 0x3388, arm64_l_3388);
arm64_l_31e0:
	/* 0x31e0: adrp x0, 0 <string_maps_7> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_7_16));
arm64_l_31e4:
	/* 0x31e4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_31e8:
	/* 0x31e8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_31ec:
	/* 0x31ec: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_31f0:
	/* 0x31f0: b 3364 <generic_fentry_filter_arg+0x3364> */
	ARM64_SIM_A64_JMP(0x31f0, 0x3364, arm64_l_3364);
arm64_l_31f4:
	/* 0x31f4: cmp w22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_31f8:
	/* 0x31f8: b.le 3254 <generic_fentry_filter_arg+0x3254> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x31f8, 0x3254, arm64_l_3254);
arm64_l_31fc:
	/* 0x31fc: cmp w22, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3200:
	/* 0x3200: b.eq 332c <generic_fentry_filter_arg+0x332c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3200, 0x332c, arm64_l_332c);
arm64_l_3204:
	/* 0x3204: cmp w22, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_3208:
	/* 0x3208: b.eq 32f0 <generic_fentry_filter_arg+0x32f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3208, 0x32f0, arm64_l_32f0);
arm64_l_320c:
	/* 0x320c: cmp w22, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_3210:
	/* 0x3210: b.ne 3388 <generic_fentry_filter_arg+0x3388> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3210, 0x3388, arm64_l_3388);
arm64_l_3214:
	/* 0x3214: adrp x0, 0 <string_maps_4> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_4_13));
arm64_l_3218:
	/* 0x3218: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_321c:
	/* 0x321c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3220:
	/* 0x3220: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3224:
	/* 0x3224: b 3364 <generic_fentry_filter_arg+0x3364> */
	ARM64_SIM_A64_JMP(0x3224, 0x3364, arm64_l_3364);
arm64_l_3228:
	/* 0x3228: cmp w22, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_322c:
	/* 0x322c: b.eq 3354 <generic_fentry_filter_arg+0x3354> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x322c, 0x3354, arm64_l_3354);
arm64_l_3230:
	/* 0x3230: cmp w22, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_3234:
	/* 0x3234: b.eq 3318 <generic_fentry_filter_arg+0x3318> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3234, 0x3318, arm64_l_3318);
arm64_l_3238:
	/* 0x3238: cmp w22, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_323c:
	/* 0x323c: b.ne 3388 <generic_fentry_filter_arg+0x3388> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x323c, 0x3388, arm64_l_3388);
arm64_l_3240:
	/* 0x3240: adrp x0, 0 <string_maps_10> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_10_10));
arm64_l_3244:
	/* 0x3244: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3248:
	/* 0x3248: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_324c:
	/* 0x324c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3250:
	/* 0x3250: b 3364 <generic_fentry_filter_arg+0x3364> */
	ARM64_SIM_A64_JMP(0x3250, 0x3364, arm64_l_3364);
arm64_l_3254:
	/* 0x3254: cbz w22, 32dc <generic_fentry_filter_arg+0x32dc> */
	ARM64_SIM_A64_CBZ(ARM64_X22, 0x3254, 0x32dc, arm64_l_32dc);
arm64_l_3258:
	/* 0x3258: cmp w22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_325c:
	/* 0x325c: b.ne 3388 <generic_fentry_filter_arg+0x3388> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x325c, 0x3388, arm64_l_3388);
arm64_l_3260:
	/* 0x3260: adrp x0, 0 <string_maps_1> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_1_9));
arm64_l_3264:
	/* 0x3264: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3268:
	/* 0x3268: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_326c:
	/* 0x326c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3270:
	/* 0x3270: b 3364 <generic_fentry_filter_arg+0x3364> */
	ARM64_SIM_A64_JMP(0x3270, 0x3364, arm64_l_3364);
arm64_l_3274:
	/* 0x3274: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3278:
	/* 0x3278: b.eq 33d4 <generic_fentry_filter_arg+0x33d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3278, 0x33d4, arm64_l_33d4);
arm64_l_327c:
	/* 0x327c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3280:
	/* 0x3280: b.ne fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3280, 0xfc, arm64_l_fc);
arm64_l_3284:
	/* 0x3284: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3288:
	/* 0x3288: b 33f8 <generic_fentry_filter_arg+0x33f8> */
	ARM64_SIM_A64_JMP(0x3288, 0x33f8, arm64_l_33f8);
arm64_l_328c:
	/* 0x328c: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3290:
	/* 0x3290: b.eq 33dc <generic_fentry_filter_arg+0x33dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3290, 0x33dc, arm64_l_33dc);
arm64_l_3294:
	/* 0x3294: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3298:
	/* 0x3298: b.ne fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3298, 0xfc, arm64_l_fc);
arm64_l_329c:
	/* 0x329c: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_32a0:
	/* 0x32a0: b 33f8 <generic_fentry_filter_arg+0x33f8> */
	ARM64_SIM_A64_JMP(0x32a0, 0x33f8, arm64_l_33f8);
arm64_l_32a4:
	/* 0x32a4: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_32a8:
	/* 0x32a8: b 32b0 <generic_fentry_filter_arg+0x32b0> */
	ARM64_SIM_A64_JMP(0x32a8, 0x32b0, arm64_l_32b0);
arm64_l_32ac:
	/* 0x32ac: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_32b0:
	/* 0x32b0: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_32b4:
	/* 0x32b4: b.eq 28c <generic_fentry_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x32b4, 0x28c, arm64_l_28c);
arm64_l_32b8:
	/* 0x32b8: b 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JMP(0x32b8, 0x3400, arm64_l_3400);
arm64_l_32bc:
	/* 0x32bc: ldr x9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_32c0:
	/* 0x32c0: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_32c4:
	/* 0x32c4: b.cc 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x32c4, 0x298, arm64_l_298);
arm64_l_32c8:
	/* 0x32c8: b 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JMP(0x32c8, 0x3400, arm64_l_3400);
arm64_l_32cc:
	/* 0x32cc: ldr x9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_32d0:
	/* 0x32d0: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_32d4:
	/* 0x32d4: b.hi 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x32d4, 0x298, arm64_l_298);
arm64_l_32d8:
	/* 0x32d8: b 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JMP(0x32d8, 0x3400, arm64_l_3400);
arm64_l_32dc:
	/* 0x32dc: adrp x0, 0 <string_maps_0> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_0_8));
arm64_l_32e0:
	/* 0x32e0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_32e4:
	/* 0x32e4: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_32e8:
	/* 0x32e8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_32ec:
	/* 0x32ec: b 3364 <generic_fentry_filter_arg+0x3364> */
	ARM64_SIM_A64_JMP(0x32ec, 0x3364, arm64_l_3364);
arm64_l_32f0:
	/* 0x32f0: adrp x0, 0 <string_maps_3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_3_12));
arm64_l_32f4:
	/* 0x32f4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_32f8:
	/* 0x32f8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_32fc:
	/* 0x32fc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3300:
	/* 0x3300: b 3364 <generic_fentry_filter_arg+0x3364> */
	ARM64_SIM_A64_JMP(0x3300, 0x3364, arm64_l_3364);
arm64_l_3304:
	/* 0x3304: adrp x0, 0 <string_maps_6> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_6_15));
arm64_l_3308:
	/* 0x3308: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_330c:
	/* 0x330c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3310:
	/* 0x3310: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3314:
	/* 0x3314: b 3364 <generic_fentry_filter_arg+0x3364> */
	ARM64_SIM_A64_JMP(0x3314, 0x3364, arm64_l_3364);
arm64_l_3318:
	/* 0x3318: adrp x0, 0 <string_maps_9> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_9_18));
arm64_l_331c:
	/* 0x331c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3320:
	/* 0x3320: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3324:
	/* 0x3324: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3328:
	/* 0x3328: b 3364 <generic_fentry_filter_arg+0x3364> */
	ARM64_SIM_A64_JMP(0x3328, 0x3364, arm64_l_3364);
arm64_l_332c:
	/* 0x332c: adrp x0, 0 <string_maps_2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_2_11));
arm64_l_3330:
	/* 0x3330: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3334:
	/* 0x3334: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3338:
	/* 0x3338: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_333c:
	/* 0x333c: b 3364 <generic_fentry_filter_arg+0x3364> */
	ARM64_SIM_A64_JMP(0x333c, 0x3364, arm64_l_3364);
arm64_l_3340:
	/* 0x3340: adrp x0, 0 <string_maps_5> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_5_14));
arm64_l_3344:
	/* 0x3344: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3348:
	/* 0x3348: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_334c:
	/* 0x334c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3350:
	/* 0x3350: b 3364 <generic_fentry_filter_arg+0x3364> */
	ARM64_SIM_A64_JMP(0x3350, 0x3364, arm64_l_3364);
arm64_l_3354:
	/* 0x3354: adrp x0, 0 <string_maps_8> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_8_17));
arm64_l_3358:
	/* 0x3358: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_335c:
	/* 0x335c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3360:
	/* 0x3360: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3364:
	/* 0x3364: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3368:
	/* 0x3368: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x336cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_336c:
	/* 0x336c: cbz x0, 3388 <generic_fentry_filter_arg+0x3388> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x336c, 0x3388, arm64_l_3388);
arm64_l_3370:
	/* 0x3370: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3374:
	/* 0x3374: mov x1, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3378:
	/* 0x3378: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x337cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_337c:
	/* 0x337c: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_3380:
	/* 0x3380: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_3384:
	/* 0x3384: b 338c <generic_fentry_filter_arg+0x338c> */
	ARM64_SIM_A64_JMP(0x3384, 0x338c, arm64_l_338c);
arm64_l_3388:
	/* 0x3388: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_338c:
	/* 0x338c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3390:
	/* 0x3390: ldr w8, [x23, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_3394:
	/* 0x3394: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_3398:
	/* 0x3398: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_339c:
	/* 0x339c: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_33a0:
	/* 0x33a0: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_33a4:
	/* 0x33a4: b.hi 33cc <generic_fentry_filter_arg+0x33cc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x33a4, 0x33cc, arm64_l_33cc);
arm64_l_33a8:
	/* 0x33a8: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_33ac:
	/* 0x33ac: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_33b0:
	/* 0x33b0: lsl x8, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_33b4:
	/* 0x33b4: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_33b8:
	/* 0x33b8: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_33bc:
	/* 0x33bc: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_33c0:
	/* 0x33c0: b.eq 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x33c0, 0x294, arm64_l_294);
arm64_l_33c4:
	/* 0x33c4: cmp x22, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_33c8:
	/* 0x33c8: b 290 <generic_fentry_filter_arg+0x290> */
	ARM64_SIM_A64_JMP(0x33c8, 0x290, arm64_l_290);
arm64_l_33cc:
	/* 0x33cc: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_33d0:
	/* 0x33d0: b 294 <generic_fentry_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x33d0, 0x294, arm64_l_294);
arm64_l_33d4:
	/* 0x33d4: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_33d8:
	/* 0x33d8: b 33e8 <generic_fentry_filter_arg+0x33e8> */
	ARM64_SIM_A64_JMP(0x33d8, 0x33e8, arm64_l_33e8);
arm64_l_33dc:
	/* 0x33dc: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_33e0:
	/* 0x33e0: b 33e8 <generic_fentry_filter_arg+0x33e8> */
	ARM64_SIM_A64_JMP(0x33e0, 0x33e8, arm64_l_33e8);
arm64_l_33e4:
	/* 0x33e4: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_33e8:
	/* 0x33e8: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_33ec:
	/* 0x33ec: b.cc 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x33ec, 0x298, arm64_l_298);
arm64_l_33f0:
	/* 0x33f0: b 3400 <generic_fentry_filter_arg+0x3400> */
	ARM64_SIM_A64_JMP(0x33f0, 0x3400, arm64_l_3400);
arm64_l_33f4:
	/* 0x33f4: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_33f8:
	/* 0x33f8: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_33fc:
	/* 0x33fc: b.hi 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x33fc, 0x298, arm64_l_298);
arm64_l_3400:
	/* 0x3400: orr w8, w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3404:
	/* 0x3404: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_3408:
	/* 0x3408: b.eq 298 <generic_fentry_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3408, 0x298, arm64_l_298);
arm64_l_340c:
	/* 0x340c: b fc <generic_fentry_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x340c, 0xfc, arm64_l_fc);
arm64_l_3410:
	/* 0x3410: cbz x2, 349c <native_bpf_strncasestr+0x8c> */
	ARM64_SIM_A64_CBZ(ARM64_X2, 0x3410, 0x349c, arm64_l_349c);
arm64_l_3414:
	/* 0x3414: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3418:
	/* 0x3418: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_341c:
	/* 0x341c: mov x9, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3420:
	/* 0x3420: b 3444 <native_bpf_strncasestr+0x34> */
	ARM64_SIM_A64_JMP(0x3420, 0x3444, arm64_l_3444);
arm64_l_3424:
	/* 0x3424: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3428:
	/* 0x3428: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_342c:
	/* 0x342c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3430:
	/* 0x3430: add x0, x0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3434:
	/* 0x3434: sub x9, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3438:
	/* 0x3438: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_343c:
	/* 0x343c: cmp x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3440:
	/* 0x3440: b.eq 349c <native_bpf_strncasestr+0x8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3440, 0x349c, arm64_l_349c);
arm64_l_3444:
	/* 0x3444: mov x10, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3448:
	/* 0x3448: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_344c:
	/* 0x344c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3450:
	/* 0x3450: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3454:
	/* 0x3454: b.eq 3430 <native_bpf_strncasestr+0x20> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3454, 0x3430, arm64_l_3430);
arm64_l_3458:
	/* 0x3458: ldrb w11, [x1, x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X1, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X10, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_345c:
	/* 0x345c: cbz w11, 34a0 <native_bpf_strncasestr+0x90> */
	ARM64_SIM_A64_CBZ(ARM64_X11, 0x345c, 0x34a0, arm64_l_34a0);
arm64_l_3460:
	/* 0x3460: ldrb w12, [x8, x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X10, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3464:
	/* 0x3464: sub w13, w12, #0x41 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 65ULL);
arm64_l_3468:
	/* 0x3468: orr w14, w12, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_346c:
	/* 0x346c: cmp w13, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_3470:
	/* 0x3470: sub w13, w11, #0x41 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 65ULL);
arm64_l_3474:
	/* 0x3474: csel w12, w14, w12, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X12, ARM64_X14, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_3478:
	/* 0x3478: orr w14, w11, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_347c:
	/* 0x347c: cmp w13, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_3480:
	/* 0x3480: csel w11, w14, w11, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X14, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_3484:
	/* 0x3484: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3488:
	/* 0x3488: b.ne 3430 <native_bpf_strncasestr+0x20> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3488, 0x3430, arm64_l_3430);
arm64_l_348c:
	/* 0x348c: cmp x10, #0x63 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 99ULL);
arm64_l_3490:
	/* 0x3490: add x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3494:
	/* 0x3494: b.cc 3450 <native_bpf_strncasestr+0x40> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x3494, 0x3450, arm64_l_3450);
arm64_l_3498:
	/* 0x3498: b 3430 <native_bpf_strncasestr+0x20> */
	ARM64_SIM_A64_JMP(0x3498, 0x3430, arm64_l_3430);
arm64_l_349c:
	/* 0x349c: mov w0, #0xffffffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967295ULL);
arm64_l_34a0:
	/* 0x34a0: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_34a0);
arm64_l_34a4:
	/* 0x34a4: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_34a8:
	/* 0x34a8: mov x7, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
