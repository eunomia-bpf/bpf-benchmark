extern char CONFIG_ITER_NUM;
extern char PARENTS_MAP_ENABLED;
extern char buffer_heap_map;
extern char execve_map;
extern char filter_map;
extern char kprobe_calls;
extern char process_call_heap;
extern char string_maps_heap;
extern char string_postfix_maps;
extern char string_postfix_maps_heap;
extern char string_prefix_maps;
extern char tg_errmetrics_map;
extern char tg_mb_paths;
extern char tg_mb_sel_opts;
extern char tg_mbset_gen;
extern char tg_mbset_map;
extern char tg_parents_bin;
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_RETURN_CASES \
	case 0x38ULL: goto arm64_l_38; \
	case 0x50ULL: goto arm64_l_50; \
	case 0x78ULL: goto arm64_l_78; \
	case 0x9cULL: goto arm64_l_9c; \
	case 0xd4ULL: goto arm64_l_d4; \
	case 0x100ULL: goto arm64_l_100; \
	case 0x11cULL: goto arm64_l_11c; \
	case 0x154ULL: goto arm64_l_154; \
	case 0x180ULL: goto arm64_l_180; \
	case 0x19cULL: goto arm64_l_19c; \
	case 0x1d4ULL: goto arm64_l_1d4; \
	case 0x200ULL: goto arm64_l_200; \
	case 0x21cULL: goto arm64_l_21c; \
	case 0x254ULL: goto arm64_l_254; \
	case 0x25cULL: goto arm64_l_25c; \
	case 0x278ULL: goto arm64_l_278; \
	case 0x28cULL: goto arm64_l_28c; \
	case 0x2b8ULL: goto arm64_l_2b8; \
	case 0x2ecULL: goto arm64_l_2ec; \
	case 0x330ULL: goto arm64_l_330; \
	case 0x364ULL: goto arm64_l_364; \
	case 0x380ULL: goto arm64_l_380; \
	case 0x398ULL: goto arm64_l_398; \
	case 0x3acULL: goto arm64_l_3ac; \
	case 0x3ccULL: goto arm64_l_3cc; \
	case 0x3f0ULL: goto arm64_l_3f0; \
	case 0x410ULL: goto arm64_l_410; \
	case 0x434ULL: goto arm64_l_434; \
	case 0x458ULL: goto arm64_l_458; \
	case 0x470ULL: goto arm64_l_470; \
	case 0x4a0ULL: goto arm64_l_4a0; \
	case 0x4d8ULL: goto arm64_l_4d8; \
	case 0x4f8ULL: goto arm64_l_4f8; \
	case 0x52cULL: goto arm64_l_52c; \
	case 0x550ULL: goto arm64_l_550; \
	case 0x574ULL: goto arm64_l_574; \
	case 0x598ULL: goto arm64_l_598; \
	case 0x5bcULL: goto arm64_l_5bc; \
	case 0x5e0ULL: goto arm64_l_5e0; \
	case 0x604ULL: goto arm64_l_604; \
	case 0x624ULL: goto arm64_l_624; \
	case 0x64cULL: goto arm64_l_64c; \
	case 0x678ULL: goto arm64_l_678; \
	case 0x698ULL: goto arm64_l_698; \
	case 0x6b8ULL: goto arm64_l_6b8; \
	case 0x6dcULL: goto arm64_l_6dc; \
	case 0x6fcULL: goto arm64_l_6fc; \
	case 0x71cULL: goto arm64_l_71c; \
	case 0x734ULL: goto arm64_l_734; \
	case 0x794ULL: goto arm64_l_794; \
	case 0x7a8ULL: goto arm64_l_7a8; \
	case 0x7bcULL: goto arm64_l_7bc; \
	case 0x7ccULL: goto arm64_l_7cc; \
	case 0x828ULL: goto arm64_l_828; \
	case 0x84cULL: goto arm64_l_84c; \
	case 0x874ULL: goto arm64_l_874; \
	case 0x890ULL: goto arm64_l_890; \
	case 0x900ULL: goto arm64_l_900; \
	case 0x934ULL: goto arm64_l_934; \
	case 0x95cULL: goto arm64_l_95c; \
	case 0x990ULL: goto arm64_l_990; \
	case 0x9ecULL: goto arm64_l_9ec; \
	case 0xa9cULL: goto arm64_l_a9c; \
	case 0xadcULL: goto arm64_l_adc; \
	case 0xb14ULL: goto arm64_l_b14; \
	case 0xb30ULL: goto arm64_l_b30; \
	case 0xb68ULL: goto arm64_l_b68; \
	case 0xbc0ULL: goto arm64_l_bc0; \
	case 0xbf0ULL: goto arm64_l_bf0; \
	case 0xc34ULL: goto arm64_l_c34; \
	case 0xc6cULL: goto arm64_l_c6c; \
	case 0xc9cULL: goto arm64_l_c9c; \
	case 0xce4ULL: goto arm64_l_ce4; \
	case 0xd1cULL: goto arm64_l_d1c; \
	case 0xd40ULL: goto arm64_l_d40; \
	case 0xd94ULL: goto arm64_l_d94; \
	case 0xe08ULL: goto arm64_l_e08; \
	case 0xe3cULL: goto arm64_l_e3c; \
	case 0xed4ULL: goto arm64_l_ed4; \
	case 0xf58ULL: goto arm64_l_f58; \
	case 0xf78ULL: goto arm64_l_f78; \
	case 0xf8cULL: goto arm64_l_f8c; \
	case 0xfb4ULL: goto arm64_l_fb4; \
	case 0xfe4ULL: goto arm64_l_fe4; \
	case 0x1044ULL: goto arm64_l_1044; \
	case 0x1060ULL: goto arm64_l_1060; \
	case 0x10b8ULL: goto arm64_l_10b8; \
	case 0x1110ULL: goto arm64_l_1110; \
	case 0x1168ULL: goto arm64_l_1168; \
	case 0x117cULL: goto arm64_l_117c; \
	case 0x11d8ULL: goto arm64_l_11d8; \
	case 0x1200ULL: goto arm64_l_1200; \
	case 0x1270ULL: goto arm64_l_1270; \
	case 0x12a0ULL: goto arm64_l_12a0; \
	case 0x1328ULL: goto arm64_l_1328; \
	case 0x134cULL: goto arm64_l_134c; \
	case 0x136cULL: goto arm64_l_136c; \
	case 0x1380ULL: goto arm64_l_1380; \
	case 0x13a4ULL: goto arm64_l_13a4; \
	case 0x13d4ULL: goto arm64_l_13d4; \
	case 0x142cULL: goto arm64_l_142c; \
	case 0x1448ULL: goto arm64_l_1448; \
	case 0x14a0ULL: goto arm64_l_14a0; \
	case 0x14f8ULL: goto arm64_l_14f8; \
	case 0x1548ULL: goto arm64_l_1548; \
	case 0x1558ULL: goto arm64_l_1558; \
	case 0x16dcULL: goto arm64_l_16dc; \
	case 0x171cULL: goto arm64_l_171c; \
	case 0x175cULL: goto arm64_l_175c; \
	case 0x179cULL: goto arm64_l_179c; \
	case 0x17dcULL: goto arm64_l_17dc; \
	case 0x181cULL: goto arm64_l_181c; \
	case 0x185cULL: goto arm64_l_185c; \
	case 0x189cULL: goto arm64_l_189c; \
	case 0x1940ULL: goto arm64_l_1940; \
	case 0x1964ULL: goto arm64_l_1964; \
	case 0x1988ULL: goto arm64_l_1988; \
	case 0x19acULL: goto arm64_l_19ac; \
	case 0x19d0ULL: goto arm64_l_19d0; \
	case 0x19f4ULL: goto arm64_l_19f4; \
	case 0x1a18ULL: goto arm64_l_1a18; \
	case 0x1a3cULL: goto arm64_l_1a3c; \
	case 0x1a68ULL: goto arm64_l_1a68; \
	case 0x1b74ULL: goto arm64_l_1b74; \
	case 0x1d38ULL: goto arm64_l_1d38; \
	case 0x1d58ULL: goto arm64_l_1d58; \
	case 0x2100ULL: goto arm64_l_2100; \
	case 0x2120ULL: goto arm64_l_2120; \
	case 0x21ecULL: goto arm64_l_21ec;
#include "../arm64_sim_local_bpf.h"

static const __u64 __arm64_rodata_0[2] = {12178401890396095487ULL, 12178947204542846966ULL};

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} CONFIG_ITER_NUM_0 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} PARENTS_MAP_ENABLED_1 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} arm64_section_Some_SectionIndex_16_addend_0_2 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} buffer_heap_map_3 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} execve_map_4 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} filter_map_5 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} kprobe_calls_6 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} memset_7 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} process_call_heap_8 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_heap_9 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_postfix_maps_10 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_postfix_maps_heap_11 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_prefix_maps_12 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_errmetrics_map_13 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_mb_paths_14 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_mb_sel_opts_15 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_mbset_gen_16 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_mbset_map_17 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_parents_bin_18 SEC(".maps");

SEC("xdp")
int tetragon_bpf_generic_kprobe_v61_generic_kprobe_process_filter_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
	/* native subroutine tetragon_bpf_generic_kprobe_v61_generic_kprobe_process_filter_xdp */
arm64_l_0:
	/* 0x0: sub sp, sp, #0x130 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 304ULL);
arm64_l_4:
	/* 0x4: str x29, [sp, #224] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_8:
	/* 0x8: stp x30, x25, [sp, #240] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 240ULL);
arm64_l_c:
	/* 0xc: stp x24, x23, [sp, #256] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 256ULL);
arm64_l_10:
	/* 0x10: stp x22, x21, [sp, #272] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 272ULL);
arm64_l_14:
	/* 0x14: stp x20, x19, [sp, #288] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 288ULL);
arm64_l_18:
	/* 0x18: mov x20, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c:
	/* 0x1c: str wzr, [sp, #84] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 84ULL);
arm64_l_20:
	/* 0x20: adrp x0, 0 <process_call_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_8));
arm64_l_24:
	/* 0x24: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28:
	/* 0x28: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c:
	/* 0x2c: add x9, sp, #0x54 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 84ULL);
arm64_l_30:
	/* 0x30: add x1, sp, #0x54 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 84ULL);
arm64_l_34:
	/* 0x34: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x38ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_38:
	/* 0x38: cbz x0, 21ec <generic_kprobe_process_filter+0x21ec> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x38, 0x21ec, arm64_l_21ec);
arm64_l_3c:
	/* 0x3c: mov w8, #0x5ec0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24256ULL);
arm64_l_40:
	/* 0x40: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_44:
	/* 0x44: add x21, x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X21, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_48:
	/* 0x48: mov w8, #0x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 35ULL);
arm64_l_4c:
	/* 0x4c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 35ULL: ARM64_SIM_A64_LINK(0x50ULL); ARM64_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_50:
	/* 0x50: str x0, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_54:
	/* 0x54: add x8, x0, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_58:
	/* 0x58: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_5c:
	/* 0x5c: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_60:
	/* 0x60: add x11, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_64:
	/* 0x64: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_68:
	/* 0x68: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_6c:
	/* 0x6c: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_70:
	/* 0x70: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_74:
	/* 0x74: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x78ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_78:
	/* 0x78: ldr w8, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_7c:
	/* 0x7c: adrp x19, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_80:
	/* 0x80: add x9, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_84:
	/* 0x84: add x1, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_88:
	/* 0x88: str w8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_8c:
	/* 0x8c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_90:
	/* 0x90: ldr x19, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_94:
	/* 0x94: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_98:
	/* 0x98: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x9cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_9c:
	/* 0x9c: cbz x0, ac <generic_kprobe_process_filter+0xac> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x9c, 0xac, arm64_l_ac);
arm64_l_a0:
	/* 0xa0: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_a4:
	/* 0xa4: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a8:
	/* 0xa8: cbnz x8, d28 <generic_kprobe_process_filter+0xd28> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0xa8, 0xd28, arm64_l_d28);
arm64_l_ac:
	/* 0xac: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_b0:
	/* 0xb0: mov w9, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_b4:
	/* 0xb4: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_b8:
	/* 0xb8: add x11, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_bc:
	/* 0xbc: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_c0:
	/* 0xc0: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_c4:
	/* 0xc4: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_c8:
	/* 0xc8: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_cc:
	/* 0xcc: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_d0:
	/* 0xd0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xd4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_d4:
	/* 0xd4: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_d8:
	/* 0xd8: cbz x8, 254 <generic_kprobe_process_filter+0x254> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xd8, 0x254, arm64_l_254);
arm64_l_dc:
	/* 0xdc: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_e0:
	/* 0xe0: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_e4:
	/* 0xe4: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_e8:
	/* 0xe8: add x11, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_ec:
	/* 0xec: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_f0:
	/* 0xf0: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_f4:
	/* 0xf4: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_f8:
	/* 0xf8: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_fc:
	/* 0xfc: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x100ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_100:
	/* 0x100: ldr w8, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_104:
	/* 0x104: add x9, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_108:
	/* 0x108: add x1, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_10c:
	/* 0x10c: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_110:
	/* 0x110: str w8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_114:
	/* 0x114: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_118:
	/* 0x118: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x11cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_11c:
	/* 0x11c: cbz x0, 12c <generic_kprobe_process_filter+0x12c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x11c, 0x12c, arm64_l_12c);
arm64_l_120:
	/* 0x120: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_124:
	/* 0x124: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_128:
	/* 0x128: cbnz x8, d28 <generic_kprobe_process_filter+0xd28> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0x128, 0xd28, arm64_l_d28);
arm64_l_12c:
	/* 0x12c: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_130:
	/* 0x130: mov w9, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_134:
	/* 0x134: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_138:
	/* 0x138: add x11, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_13c:
	/* 0x13c: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_140:
	/* 0x140: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_144:
	/* 0x144: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_148:
	/* 0x148: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_14c:
	/* 0x14c: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_150:
	/* 0x150: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x154ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_154:
	/* 0x154: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_158:
	/* 0x158: cbz x8, 254 <generic_kprobe_process_filter+0x254> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x158, 0x254, arm64_l_254);
arm64_l_15c:
	/* 0x15c: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_160:
	/* 0x160: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_164:
	/* 0x164: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_168:
	/* 0x168: add x11, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_16c:
	/* 0x16c: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_170:
	/* 0x170: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_174:
	/* 0x174: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_178:
	/* 0x178: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_17c:
	/* 0x17c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x180ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_180:
	/* 0x180: ldr w8, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_184:
	/* 0x184: add x9, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_188:
	/* 0x188: add x1, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_18c:
	/* 0x18c: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_190:
	/* 0x190: str w8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_194:
	/* 0x194: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_198:
	/* 0x198: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x19cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_19c:
	/* 0x19c: cbz x0, 1ac <generic_kprobe_process_filter+0x1ac> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x19c, 0x1ac, arm64_l_1ac);
arm64_l_1a0:
	/* 0x1a0: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1a4:
	/* 0x1a4: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a8:
	/* 0x1a8: cbnz x8, d28 <generic_kprobe_process_filter+0xd28> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0x1a8, 0xd28, arm64_l_d28);
arm64_l_1ac:
	/* 0x1ac: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1b0:
	/* 0x1b0: mov w9, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1b4:
	/* 0x1b4: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1b8:
	/* 0x1b8: add x11, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1bc:
	/* 0x1bc: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1c0:
	/* 0x1c0: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1c4:
	/* 0x1c4: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_1c8:
	/* 0x1c8: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1cc:
	/* 0x1cc: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_1d0:
	/* 0x1d0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1d4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1d4:
	/* 0x1d4: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1d8:
	/* 0x1d8: cbz x8, 254 <generic_kprobe_process_filter+0x254> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1d8, 0x254, arm64_l_254);
arm64_l_1dc:
	/* 0x1dc: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_1e0:
	/* 0x1e0: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1e4:
	/* 0x1e4: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1e8:
	/* 0x1e8: add x11, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_1ec:
	/* 0x1ec: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1f0:
	/* 0x1f0: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_1f4:
	/* 0x1f4: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1f8:
	/* 0x1f8: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_1fc:
	/* 0x1fc: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x200ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_200:
	/* 0x200: ldr w8, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_204:
	/* 0x204: add x9, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_208:
	/* 0x208: add x1, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_20c:
	/* 0x20c: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_210:
	/* 0x210: str w8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_214:
	/* 0x214: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_218:
	/* 0x218: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x21cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_21c:
	/* 0x21c: cbz x0, 22c <generic_kprobe_process_filter+0x22c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x21c, 0x22c, arm64_l_22c);
arm64_l_220:
	/* 0x220: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_224:
	/* 0x224: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_228:
	/* 0x228: cbnz x8, d28 <generic_kprobe_process_filter+0xd28> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0x228, 0xd28, arm64_l_d28);
arm64_l_22c:
	/* 0x22c: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_230:
	/* 0x230: mov w9, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_234:
	/* 0x234: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_238:
	/* 0x238: add x11, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_23c:
	/* 0x23c: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_240:
	/* 0x240: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_244:
	/* 0x244: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_248:
	/* 0x248: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_24c:
	/* 0x24c: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_250:
	/* 0x250: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x254ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_254:
	/* 0x254: mov w8, #0x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 35ULL);
arm64_l_258:
	/* 0x258: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 35ULL: ARM64_SIM_A64_LINK(0x25cULL); ARM64_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_25c:
	/* 0x25c: add x2, x0, #0x8d4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_260:
	/* 0x260: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_264:
	/* 0x264: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_268:
	/* 0x268: mov x23, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_26c:
	/* 0x26c: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_270:
	/* 0x270: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_274:
	/* 0x274: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x278ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_278:
	/* 0x278: ldr w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_27c:
	/* 0x27c: mov x19, x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_280:
	/* 0x280: str w8, [x19, #80]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 80ULL);
arm64_l_284:
	/* 0x284: mov w8, #0x7d */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 125ULL);
arm64_l_288:
	/* 0x288: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 125ULL: ARM64_SIM_A64_LINK(0x28cULL); ARM64_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_28c:
	/* 0x28c: str x0, [x29, #24344] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24344ULL);
arm64_l_290:
	/* 0x290: str wzr, [x19, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_294:
	/* 0x294: add x2, x23, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_298:
	/* 0x298: mov w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_29c:
	/* 0x29c: mov w9, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2a0:
	/* 0x2a0: add x10, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_2a4:
	/* 0x2a4: str xzr, [x29, #24360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24360ULL);
arm64_l_2a8:
	/* 0x2a8: str wzr, [x19, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2ac:
	/* 0x2ac: add x0, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_2b0:
	/* 0x2b0: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2b4:
	/* 0x2b4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2b8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2b8:
	/* 0x2b8: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_2bc:
	/* 0x2bc: str x20, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2c0:
	/* 0x2c0: str x19, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2c4:
	/* 0x2c4: cbz x8, 334 <generic_kprobe_process_filter+0x334> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x2c4, 0x334, arm64_l_334);
arm64_l_2c8:
	/* 0x2c8: add x8, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2cc:
	/* 0x2cc: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2d0:
	/* 0x2d0: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2d4:
	/* 0x2d4: add x11, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_2d8:
	/* 0x2d8: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_2dc:
	/* 0x2dc: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_2e0:
	/* 0x2e0: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2e4:
	/* 0x2e4: add x2, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2e8:
	/* 0x2e8: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2ecULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2ec:
	/* 0x2ec: ldr w8, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_2f0:
	/* 0x2f0: cbz w8, 334 <generic_kprobe_process_filter+0x334> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x2f0, 0x334, arm64_l_334);
arm64_l_2f4:
	/* 0x2f4: ldr x9, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_2f8:
	/* 0x2f8: lsl w8, w8, #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 4ULL);
arm64_l_2fc:
	/* 0x2fc: mov w10, #0x71 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_300:
	/* 0x300: add x11, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_304:
	/* 0x304: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_308:
	/* 0x308: mov w1, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_30c:
	/* 0x30c: add x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_310:
	/* 0x310: mov w9, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_314:
	/* 0x314: add x8, x8, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_318:
	/* 0x318: ldr w9, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_31c:
	/* 0x31c: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_320:
	/* 0x320: lsl w9, w9, #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 4ULL);
arm64_l_324:
	/* 0x324: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_328:
	/* 0x328: add x2, x8, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_32c:
	/* 0x32c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x330ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_330:
	/* 0x330: ldr w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_334:
	/* 0x334: str w8, [x21, #116] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 116ULL);
arm64_l_338:
	/* 0x338: mov w8, #0x5f60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24416ULL);
arm64_l_33c:
	/* 0x33c: add x2, x23, #0xae0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2784ULL);
arm64_l_340:
	/* 0x340: mov w19, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_344:
	/* 0x344: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_348:
	/* 0x348: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_34c:
	/* 0x34c: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_350:
	/* 0x350: add x24, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_354:
	/* 0x354: add x8, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_358:
	/* 0x358: mov x22, x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_35c:
	/* 0x35c: mov w21, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_360:
	/* 0x360: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x364ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_364:
	/* 0x364: ldr x20, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_368:
	/* 0x368: mov w8, #0x5f68 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24424ULL);
arm64_l_36c:
	/* 0x36c: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_370:
	/* 0x370: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_374:
	/* 0x374: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_378:
	/* 0x378: add x2, x20, #0x40 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_37c:
	/* 0x37c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x380ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_380:
	/* 0x380: mov w8, #0x5f70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24432ULL);
arm64_l_384:
	/* 0x384: add x2, x20, #0x30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_388:
	/* 0x388: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_38c:
	/* 0x38c: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_390:
	/* 0x390: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_394:
	/* 0x394: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x398ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_398:
	/* 0x398: add x2, x20, #0x38 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_39c:
	/* 0x39c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_3a0:
	/* 0x3a0: mov x0, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3a4:
	/* 0x3a4: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3a8:
	/* 0x3a8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x3acULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3ac:
	/* 0x3ac: mov w8, #0x5f38 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24376ULL);
arm64_l_3b0:
	/* 0x3b0: add x2, x23, #0xb50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2896ULL);
arm64_l_3b4:
	/* 0x3b4: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_3b8:
	/* 0x3b8: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_3bc:
	/* 0x3bc: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3c0:
	/* 0x3c0: add x24, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_3c4:
	/* 0x3c4: add x8, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_3c8:
	/* 0x3c8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x3ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3cc:
	/* 0x3cc: add x12, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_3d0:
	/* 0x3d0: mov w9, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 72ULL);
arm64_l_3d4:
	/* 0x3d4: add x10, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_3d8:
	/* 0x3d8: ldr x8, [x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3dc:
	/* 0x3dc: mov w11, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_3e0:
	/* 0x3e0: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_3e4:
	/* 0x3e4: mov w1, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 72ULL);
arm64_l_3e8:
	/* 0x3e8: ldr x2, [x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3ec:
	/* 0x3ec: blr x11 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X11);
		if (ARM64_SIM_L_REG_TAG(ARM64_X11) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x3f0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3f0:
	/* 0x3f0: ldr x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_3f4:
	/* 0x3f4: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_3f8:
	/* 0x3f8: mov x0, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3fc:
	/* 0x3fc: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_400:
	/* 0x400: add x8, x8, #0x218 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 536ULL);
arm64_l_404:
	/* 0x404: ldr x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_408:
	/* 0x408: add x2, x8, #0x218 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 536ULL);
arm64_l_40c:
	/* 0x40c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x410ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_410:
	/* 0x410: mov w8, #0x5f3c */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24380ULL);
arm64_l_414:
	/* 0x414: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_418:
	/* 0x418: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_41c:
	/* 0x41c: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_420:
	/* 0x420: ldr x8, [sp, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_424:
	/* 0x424: add x8, x8, #0x4d8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1240ULL);
arm64_l_428:
	/* 0x428: ldr x8, [sp, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_42c:
	/* 0x42c: add x2, x8, #0x4d8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1240ULL);
arm64_l_430:
	/* 0x430: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x434ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_434:
	/* 0x434: mov w8, #0x5f40 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24384ULL);
arm64_l_438:
	/* 0x438: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_43c:
	/* 0x43c: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_440:
	/* 0x440: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_444:
	/* 0x444: ldr x8, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_448:
	/* 0x448: add x8, x8, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_44c:
	/* 0x44c: ldr x8, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_450:
	/* 0x450: add x2, x8, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_454:
	/* 0x454: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x458ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_458:
	/* 0x458: str xzr, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_45c:
	/* 0x45c: add x2, x23, #0x938 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2360ULL);
arm64_l_460:
	/* 0x460: add x8, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_464:
	/* 0x464: add x0, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_468:
	/* 0x468: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_46c:
	/* 0x46c: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x470ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_470:
	/* 0x470: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_474:
	/* 0x474: cbz x8, 4fc <generic_kprobe_process_filter+0x4fc> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x474, 0x4fc, arm64_l_4fc);
arm64_l_478:
	/* 0x478: str wzr, [sp, #184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_47c:
	/* 0x47c: add x8, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_480:
	/* 0x480: add x9, sp, #0xb8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 184ULL);
arm64_l_484:
	/* 0x484: mov w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_488:
	/* 0x488: add x0, sp, #0xb8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 184ULL);
arm64_l_48c:
	/* 0x48c: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_490:
	/* 0x490: mov w19, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_494:
	/* 0x494: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_498:
	/* 0x498: add x2, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_49c:
	/* 0x49c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x4a0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_4a0:
	/* 0x4a0: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_4a4:
	/* 0x4a4: ldrsw x9, [sp, #184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDRSW, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_4a8:
	/* 0x4a8: add x10, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_4ac:
	/* 0x4ac: mov w11, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_4b0:
	/* 0x4b0: add x0, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_4b4:
	/* 0x4b4: mov w1, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_4b8:
	/* 0x4b8: add x8, x8, x9, lsl #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 4), 0);
arm64_l_4bc:
	/* 0x4bc: mov w9, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_4c0:
	/* 0x4c0: add x8, x8, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_4c4:
	/* 0x4c4: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_4c8:
	/* 0x4c8: ldrsw x9, [sp, #184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDRSW, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_4cc:
	/* 0x4cc: add x8, x8, x9, lsl #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 4), 0);
arm64_l_4d0:
	/* 0x4d0: add x2, x8, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_4d4:
	/* 0x4d4: blr x11 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X11);
		if (ARM64_SIM_L_REG_TAG(ARM64_X11) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x4d8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_4d8:
	/* 0x4d8: mov w8, #0x5f44 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24388ULL);
arm64_l_4dc:
	/* 0x4dc: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_4e0:
	/* 0x4e0: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_4e4:
	/* 0x4e4: ldr x8, [sp, #208] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_4e8:
	/* 0x4e8: add x8, x8, #0x158 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_4ec:
	/* 0x4ec: ldr x8, [sp, #208] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_4f0:
	/* 0x4f0: add x2, x8, #0x158 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_4f4:
	/* 0x4f4: blr x19 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X19);
		if (ARM64_SIM_L_REG_TAG(ARM64_X19) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x4f8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_4f8:
	/* 0x4f8: b 500 <generic_kprobe_process_filter+0x500> */
	ARM64_SIM_A64_JMP(0x4f8, 0x500, arm64_l_500);
arm64_l_4fc:
	/* 0x4fc: str wzr, [x22, #132] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 132ULL);
arm64_l_500:
	/* 0x500: mov w8, #0x5f48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24392ULL);
arm64_l_504:
	/* 0x504: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_508:
	/* 0x508: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_50c:
	/* 0x50c: mov x21, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_510:
	/* 0x510: mov w19, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_514:
	/* 0x514: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_518:
	/* 0x518: ldr x8, [sp, #120] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_51c:
	/* 0x51c: add x8, x8, #0x158 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_520:
	/* 0x520: ldr x8, [sp, #120] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_524:
	/* 0x524: add x2, x8, #0x158 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_528:
	/* 0x528: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x52cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_52c:
	/* 0x52c: mov w8, #0x5f4c */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24396ULL);
arm64_l_530:
	/* 0x530: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_534:
	/* 0x534: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_538:
	/* 0x538: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_53c:
	/* 0x53c: ldr x8, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_540:
	/* 0x540: add x8, x8, #0x118 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 280ULL);
arm64_l_544:
	/* 0x544: ldr x8, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_548:
	/* 0x548: add x2, x8, #0x118 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 280ULL);
arm64_l_54c:
	/* 0x54c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x550ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_550:
	/* 0x550: mov w8, #0x5f50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24400ULL);
arm64_l_554:
	/* 0x554: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_558:
	/* 0x558: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_55c:
	/* 0x55c: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_560:
	/* 0x560: ldr x8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_564:
	/* 0x564: add x8, x8, #0x98 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_568:
	/* 0x568: ldr x8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_56c:
	/* 0x56c: add x2, x8, #0x98 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_570:
	/* 0x570: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x574ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_574:
	/* 0x574: mov w8, #0x5f54 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24404ULL);
arm64_l_578:
	/* 0x578: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_57c:
	/* 0x57c: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_580:
	/* 0x580: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_584:
	/* 0x584: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_588:
	/* 0x588: add x8, x8, #0x98 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_58c:
	/* 0x58c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_590:
	/* 0x590: add x2, x8, #0x98 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_594:
	/* 0x594: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x598ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_598:
	/* 0x598: mov w8, #0x5f58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24408ULL);
arm64_l_59c:
	/* 0x59c: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_5a0:
	/* 0x5a0: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_5a4:
	/* 0x5a4: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_5a8:
	/* 0x5a8: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_5ac:
	/* 0x5ac: add x8, x8, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_5b0:
	/* 0x5b0: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_5b4:
	/* 0x5b4: add x2, x8, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_5b8:
	/* 0x5b8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x5bcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_5bc:
	/* 0x5bc: str xzr, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_5c0:
	/* 0x5c0: add x24, x23, #0x858 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2136ULL);
arm64_l_5c4:
	/* 0x5c4: mov w20, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_5c8:
	/* 0x5c8: add x8, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_5cc:
	/* 0x5cc: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_5d0:
	/* 0x5d0: add x0, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_5d4:
	/* 0x5d4: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_5d8:
	/* 0x5d8: mov x2, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5dc:
	/* 0x5dc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x5e0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_5e0:
	/* 0x5e0: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_5e4:
	/* 0x5e4: add x9, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_5e8:
	/* 0x5e8: mov w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_5ec:
	/* 0x5ec: add x0, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_5f0:
	/* 0x5f0: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_5f4:
	/* 0x5f4: add x8, x8, #0x520 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1312ULL);
arm64_l_5f8:
	/* 0x5f8: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_5fc:
	/* 0x5fc: add x2, x8, #0x520 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1312ULL);
arm64_l_600:
	/* 0x600: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x604ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_604:
	/* 0x604: mov w8, #0x5f5c */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24412ULL);
arm64_l_608:
	/* 0x608: mov w1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_60c:
	/* 0x60c: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_610:
	/* 0x610: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_614:
	/* 0x614: add x8, x8, #0x158 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_618:
	/* 0x618: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_61c:
	/* 0x61c: add x2, x8, #0x158 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_620:
	/* 0x620: blr x19 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X19);
		if (ARM64_SIM_L_REG_TAG(ARM64_X19) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x624ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_624:
	/* 0x624: ldr w8, [x22, #116] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 116ULL);
arm64_l_628:
	/* 0x628: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_62c:
	/* 0x62c: b.ne 63c <generic_kprobe_process_filter+0x63c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x62c, 0x63c, arm64_l_63c);
arm64_l_630:
	/* 0x630: ldr w8, [x21, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_634:
	/* 0x634: orr w8, w8, #0x2000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 33554432ULL);
arm64_l_638:
	/* 0x638: str w8, [x21, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_63c:
	/* 0x63c: add x0, x21, #0xb8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 184ULL);
arm64_l_640:
	/* 0x640: mov w1, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_644:
	/* 0x644: mov w2, #0x308 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 776ULL);
arm64_l_648:
	/* 0x648: bl 0 <memset> */
	ARM64_SIM_A64_CALL(arm64_l_0, 0x64cULL);
arm64_l_64c:
	/* 0x64c: mov w8, #0x6290 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 25232ULL);
arm64_l_650:
	/* 0x650: str x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_654:
	/* 0x654: mov w19, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_658:
	/* 0x658: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_65c:
	/* 0x65c: add x0, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_660:
	/* 0x660: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_664:
	/* 0x664: mov x2, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_668:
	/* 0x668: add x22, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_66c:
	/* 0x66c: add x8, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_670:
	/* 0x670: mov w20, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_674:
	/* 0x674: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x678ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_678:
	/* 0x678: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_67c:
	/* 0x67c: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_680:
	/* 0x680: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_684:
	/* 0x684: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_688:
	/* 0x688: add x8, x8, #0x528 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1320ULL);
arm64_l_68c:
	/* 0x68c: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_690:
	/* 0x690: add x2, x8, #0x528 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1320ULL);
arm64_l_694:
	/* 0x694: blr x20 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X20);
		if (ARM64_SIM_L_REG_TAG(ARM64_X20) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x698ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_698:
	/* 0x698: str wzr, [sp, #164] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 164ULL);
arm64_l_69c:
	/* 0x69c: adrp x0, 0 <buffer_heap_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&buffer_heap_map_3));
arm64_l_6a0:
	/* 0x6a0: ldr x19, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_6a4:
	/* 0x6a4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_6a8:
	/* 0x6a8: add x9, sp, #0xa4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 164ULL);
arm64_l_6ac:
	/* 0x6ac: add x1, sp, #0xa4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 164ULL);
arm64_l_6b0:
	/* 0x6b0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6b4:
	/* 0x6b4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x6b8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_6b8:
	/* 0x6b8: cbz x0, b78 <generic_kprobe_process_filter+0xb78> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x6b8, 0xb78, arm64_l_b78);
arm64_l_6bc:
	/* 0x6bc: mov w8, #0x1000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_6c0:
	/* 0x6c0: str x22, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_6c4:
	/* 0x6c4: str x21, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_6c8:
	/* 0x6c8: mov x24, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6cc:
	/* 0x6cc: add x20, x0, #0x1, lsl #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_6d0:
	/* 0x6d0: str w8, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_6d4:
	/* 0x6d4: mov w8, #0x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 35ULL);
arm64_l_6d8:
	/* 0x6d8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 35ULL: ARM64_SIM_A64_LINK(0x6dcULL); ARM64_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_6dc:
	/* 0x6dc: add x2, x0, #0xb30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2864ULL);
arm64_l_6e0:
	/* 0x6e0: mov w23, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_6e4:
	/* 0x6e4: add x8, sp, #0xa8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_6e8:
	/* 0x6e8: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_6ec:
	/* 0x6ec: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_6f0:
	/* 0x6f0: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_6f4:
	/* 0x6f4: mov w29, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_6f8:
	/* 0x6f8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x6fcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_6fc:
	/* 0x6fc: ldr x22, [sp, #168] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_700:
	/* 0x700: add x25, x19, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_704:
	/* 0x704: add x8, sp, #0xb0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 176ULL);
arm64_l_708:
	/* 0x708: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_70c:
	/* 0x70c: add x0, sp, #0xb0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 176ULL);
arm64_l_710:
	/* 0x710: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_714:
	/* 0x714: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_718:
	/* 0x718: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x71cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_71c:
	/* 0x71c: ldr x21, [sp, #176] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_720:
	/* 0x720: add x8, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_724:
	/* 0x724: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_728:
	/* 0x728: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_72c:
	/* 0x72c: add x2, x21, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_730:
	/* 0x730: blr x29 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X29);
		if (ARM64_SIM_L_REG_TAG(ARM64_X29) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x734ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_734:
	/* 0x734: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_738:
	/* 0x738: cbz x8, 974 <generic_kprobe_process_filter+0x974> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x738, 0x974, arm64_l_974);
arm64_l_73c:
	/* 0x73c: ldr x8, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_740:
	/* 0x740: stp xzr, xzr, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_744:
	/* 0x744: add x21, x22, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_748:
	/* 0x748: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_74c:
	/* 0x74c: add x2, x22, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_750:
	/* 0x750: mov w22, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_754:
	/* 0x754: stp x24, xzr, [sp, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_758:
	/* 0x758: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_75c:
	/* 0x75c: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_760:
	/* 0x760: add x29, x19, #0x40 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_764:
	/* 0x764: add x19, x9, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_768:
	/* 0x768: add x24, x9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_76c:
	/* 0x76c: stp xzr, xzr, [sp, #120] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_770:
	/* 0x770: add x23, x9, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_774:
	/* 0x774: str x20, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_778:
	/* 0x778: str x20, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_77c:
	/* 0x77c: mov w20, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_780:
	/* 0x780: ldr w8, [x8, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_784:
	/* 0x784: strb wzr, [sp, #148] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 148ULL);
arm64_l_788:
	/* 0x788: str w8, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_78c:
	/* 0x78c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_790:
	/* 0x790: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x794ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_794:
	/* 0x794: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_798:
	/* 0x798: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_79c:
	/* 0x79c: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_7a0:
	/* 0x7a0: mov x2, x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7a4:
	/* 0x7a4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x7a8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_7a8:
	/* 0x7a8: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_7ac:
	/* 0x7ac: mov x0, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7b0:
	/* 0x7b0: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_7b4:
	/* 0x7b4: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7b8:
	/* 0x7b8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x7bcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_7bc:
	/* 0x7bc: mov x0, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7c0:
	/* 0x7c0: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_7c4:
	/* 0x7c4: mov x2, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7c8:
	/* 0x7c8: blr x20 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X20);
		if (ARM64_SIM_L_REG_TAG(ARM64_X20) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x7ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_7cc:
	/* 0x7cc: ldr x8, [sp, #120] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_7d0:
	/* 0x7d0: sub x8, x8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_7d4:
	/* 0x7d4: str x8, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_7d8:
	/* 0x7d8: adrp x8, 0 <CONFIG_ITER_NUM> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM_0));
arm64_l_7dc:
	/* 0x7dc: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_7e0:
	/* 0x7e0: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_7e4:
	/* 0x7e4: cbz w8, 9c8 <generic_kprobe_process_filter+0x9c8> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x7e4, 0x9c8, arm64_l_9c8);
arm64_l_7e8:
	/* 0x7e8: mov w19, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_7ec:
	/* 0x7ec: mov w21, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_7f0:
	/* 0x7f0: add x23, sp, #0xb8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 184ULL);
arm64_l_7f4:
	/* 0x7f4: add x29, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_7f8:
	/* 0x7f8: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7fc:
	/* 0x7fc: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_800:
	/* 0x800: ldp x20, x2, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_804:
	/* 0x804: ldp x8, x9, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_808:
	/* 0x808: cmp x20, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_80c:
	/* 0x80c: ccmp x2, x9, #0x0, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X2, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_EQ, 0), 0);
arm64_l_810:
	/* 0x810: b.eq a3c <generic_kprobe_process_filter+0xa3c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x810, 0xa3c, arm64_l_a3c);
arm64_l_814:
	/* 0x814: ldr x22, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_818:
	/* 0x818: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_81c:
	/* 0x81c: add x0, sp, #0xb8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 184ULL);
arm64_l_820:
	/* 0x820: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_824:
	/* 0x824: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x828ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_828:
	/* 0x828: ldr x8, [sp, #184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_82c:
	/* 0x82c: cmp x20, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_830:
	/* 0x830: b.eq 920 <generic_kprobe_process_filter+0x920> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x830, 0x920, arm64_l_920);
arm64_l_834:
	/* 0x834: add x25, x20, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_838:
	/* 0x838: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_83c:
	/* 0x83c: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_840:
	/* 0x840: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_844:
	/* 0x844: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_848:
	/* 0x848: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x84cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_84c:
	/* 0x84c: add x8, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_850:
	/* 0x850: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_854:
	/* 0x854: cmp x8, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_858:
	/* 0x858: b.eq 920 <generic_kprobe_process_filter+0x920> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x858, 0x920, arm64_l_920);
arm64_l_85c:
	/* 0x85c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_860:
	/* 0x860: add x9, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_864:
	/* 0x864: add x0, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_868:
	/* 0x868: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_86c:
	/* 0x86c: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_870:
	/* 0x870: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x874ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_874:
	/* 0x874: add x2, x20, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_878:
	/* 0x878: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_87c:
	/* 0x87c: mov w9, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_880:
	/* 0x880: add x10, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_884:
	/* 0x884: add x0, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_888:
	/* 0x888: mov w1, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_88c:
	/* 0x88c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x890ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_890:
	/* 0x890: ldr w20, [sp, #204] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 204ULL);
arm64_l_894:
	/* 0x894: ldr x8, [sp, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_898:
	/* 0x898: ldr x10, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_89c:
	/* 0x89c: sub x12, x10, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_8a0:
	/* 0x8a0: ldr w22, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_8a4:
	/* 0x8a4: subs w10, w20, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X10, ARM64_X20, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8a8:
	/* 0x8a8: ldr x9, [sp, #208] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_8ac:
	/* 0x8ac: csel w10, wzr, w10, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X10, ARM64_XZR, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_8b0:
	/* 0x8b0: cmp w22, w20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X22, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8b4:
	/* 0x8b4: csel w11, w22, w20, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X22, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_8b8:
	/* 0x8b8: cinc w13, w11, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CINC, ARM64_X13, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_8bc:
	/* 0x8bc: sub w14, w22, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X22, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_8c0:
	/* 0x8c0: subs x12, x12, x13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X12, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8c4:
	/* 0x8c4: str w14, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_8c8:
	/* 0x8c8: b.cc 9ec <generic_kprobe_process_filter+0x9ec> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x8c8, 0x9ec, arm64_l_9ec);
arm64_l_8cc:
	/* 0x8cc: cmp x12, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_8d0:
	/* 0x8d0: b.hi 9ec <generic_kprobe_process_filter+0x9ec> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x8d0, 0x9ec, arm64_l_9ec);
arm64_l_8d4:
	/* 0x8d4: cmp w22, w20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X22, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8d8:
	/* 0x8d8: b.ls 8e4 <generic_kprobe_process_filter+0x8e4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x8d8, 0x8e4, arm64_l_8e4);
arm64_l_8dc:
	/* 0x8dc: mov w13, #0x2f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_8e0:
	/* 0x8e0: strb w13, [x8, x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X12, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_8e4:
	/* 0x8e4: add x25, x8, x12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X25, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_8e8:
	/* 0x8e8: cmp w22, w20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X22, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8ec:
	/* 0x8ec: add x2, x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_8f0:
	/* 0x8f0: and w1, w11, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_8f4:
	/* 0x8f4: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_8f8:
	/* 0x8f8: cinc x0, x25, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CINC, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_HI, 0);
arm64_l_8fc:
	/* 0x8fc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x900ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_900:
	/* 0x900: cmp w22, w20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X22, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_904:
	/* 0x904: str x25, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_908:
	/* 0x908: b.ls 9ec <generic_kprobe_process_filter+0x9ec> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x908, 0x9ec, arm64_l_9ec);
arm64_l_90c:
	/* 0x90c: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_910:
	/* 0x910: str x8, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_914:
	/* 0x914: subs w19, w19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_918:
	/* 0x918: b.ne 800 <generic_kprobe_process_filter+0x800> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x918, 0x800, arm64_l_800);
arm64_l_91c:
	/* 0x91c: b 9ec <generic_kprobe_process_filter+0x9ec> */
	ARM64_SIM_A64_JMP(0x91c, 0x9ec, arm64_l_9ec);
arm64_l_920:
	/* 0x920: add x2, x22, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_924:
	/* 0x924: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_928:
	/* 0x928: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_92c:
	/* 0x92c: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_930:
	/* 0x930: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x934ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_934:
	/* 0x934: add x20, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_938:
	/* 0x938: ldr x8, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_93c:
	/* 0x93c: ldr x9, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_940:
	/* 0x940: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_944:
	/* 0x944: b.eq a3c <generic_kprobe_process_filter+0xa3c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x944, 0xa3c, arm64_l_a3c);
arm64_l_948:
	/* 0x948: add x2, x22, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_94c:
	/* 0x94c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_950:
	/* 0x950: mov x0, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_954:
	/* 0x954: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_958:
	/* 0x958: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x95cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_95c:
	/* 0x95c: ldr x8, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_960:
	/* 0x960: add x9, x8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_964:
	/* 0x964: stp x9, x8, [sp, #120] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_968:
	/* 0x968: subs w19, w19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_96c:
	/* 0x96c: b.ne 800 <generic_kprobe_process_filter+0x800> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x96c, 0x800, arm64_l_800);
arm64_l_970:
	/* 0x970: b 9ec <generic_kprobe_process_filter+0x9ec> */
	ARM64_SIM_A64_JMP(0x970, 0x9ec, arm64_l_9ec);
arm64_l_974:
	/* 0x974: add x2, x21, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_978:
	/* 0x978: mov w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_97c:
	/* 0x97c: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_980:
	/* 0x980: add x10, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_984:
	/* 0x984: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_988:
	/* 0x988: mov w1, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_98c:
	/* 0x98c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x990ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_990:
	/* 0x990: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_994:
	/* 0x994: cmp x8, x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_998:
	/* 0x998: b.eq 73c <generic_kprobe_process_filter+0x73c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x998, 0x73c, arm64_l_73c);
arm64_l_99c:
	/* 0x99c: ldr x21, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_9a0:
	/* 0x9a0: ldr w9, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_9a4:
	/* 0x9a4: sub w8, w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_9a8:
	/* 0x9a8: cmp w9, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_9ac:
	/* 0x9ac: str w8, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_9b0:
	/* 0x9b0: b.gt f24 <generic_kprobe_process_filter+0xf24> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x9b0, 0xf24, arm64_l_f24);
arm64_l_9b4:
	/* 0x9b4: ldr x22, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_9b8:
	/* 0x9b8: mov w9, #0xffffffdc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967260ULL);
arm64_l_9bc:
	/* 0x9bc: mov x24, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_9c0:
	/* 0x9c0: str w9, [x21, #1364] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1364ULL);
arm64_l_9c4:
	/* 0x9c4: b a68 <generic_kprobe_process_filter+0xa68> */
	ARM64_SIM_A64_JMP(0x9c4, 0xa68, arm64_l_a68);
arm64_l_9c8:
	/* 0x9c8: mov x3, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_9cc:
	/* 0x9cc: adrp x1, 0 <generic_kprobe_process_filter> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_RODATA, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)__arm64_rodata_0));
arm64_l_9d0:
	/* 0x9d0: add x1, x1, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_9d4:
	/* 0x9d4: mov w8, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_9d8:
	/* 0x9d8: mov w9, #0xb5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 181ULL);
arm64_l_9dc:
	/* 0x9dc: add x10, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_9e0:
	/* 0x9e0: add x2, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_9e4:
	/* 0x9e4: mov w0, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_9e8:
	/* 0x9e8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 181ULL: ARM64_SIM_A64_LINK(0x9ecULL); ARM64_SIM_BPF_CALL_bpf_loop(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_9ec:
	/* 0x9ec: ldr x24, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_9f0:
	/* 0x9f0: ldr x9, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_9f4:
	/* 0x9f4: cmp x24, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_9f8:
	/* 0x9f8: b.eq a54 <generic_kprobe_process_filter+0xa54> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x9f8, 0xa54, arm64_l_a54);
arm64_l_9fc:
	/* 0x9fc: ldrb w8, [sp, #148] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 148ULL);
arm64_l_a00:
	/* 0xa00: ldr x21, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_a04:
	/* 0xa04: cmp w8, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_a08:
	/* 0xa08: ldr x22, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_a0c:
	/* 0xa0c: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_a10:
	/* 0xa10: lsl w9, w8, #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 1ULL);
arm64_l_a14:
	/* 0xa14: ldr w8, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_a18:
	/* 0xa18: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_a1c:
	/* 0xa1c: str w8, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_a20:
	/* 0xa20: str w9, [x21, #1364] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1364ULL);
arm64_l_a24:
	/* 0xa24: b.lt a34 <generic_kprobe_process_filter+0xa34> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0xa24, 0xa34, arm64_l_a34);
arm64_l_a28:
	/* 0xa28: mov w9, #0x1000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_a2c:
	/* 0xa2c: sub w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_a30:
	/* 0xa30: str w8, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_a34:
	/* 0xa34: cbnz x24, a68 <generic_kprobe_process_filter+0xa68> */
	ARM64_SIM_A64_CBNZ(ARM64_X24, 0xa34, 0xa68, arm64_l_a68);
arm64_l_a38:
	/* 0xa38: b b78 <generic_kprobe_process_filter+0xb78> */
	ARM64_SIM_A64_JMP(0xa38, 0xb78, arm64_l_b78);
arm64_l_a3c:
	/* 0xa3c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a40:
	/* 0xa40: strb w8, [sp, #148] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 148ULL);
arm64_l_a44:
	/* 0xa44: ldr x24, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_a48:
	/* 0xa48: ldr x9, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_a4c:
	/* 0xa4c: cmp x24, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_a50:
	/* 0xa50: b.ne 9fc <generic_kprobe_process_filter+0x9fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xa50, 0x9fc, arm64_l_9fc);
arm64_l_a54:
	/* 0xa54: ldr x21, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_a58:
	/* 0xa58: ldr x22, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_a5c:
	/* 0xa5c: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_a60:
	/* 0xa60: mov x24, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a64:
	/* 0xa64: str xzr, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_a68:
	/* 0xa68: subs w9, w8, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_a6c:
	/* 0xa6c: mov w10, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_a70:
	/* 0xa70: mov x0, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a74:
	/* 0xa74: mov x2, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a78:
	/* 0xa78: csel w29, w8, w10, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X29, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_a7c:
	/* 0xa7c: csel w19, wzr, w9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X19, ARM64_XZR, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_a80:
	/* 0xa80: cmp w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_a84:
	/* 0xa84: mov w9, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 255ULL);
arm64_l_a88:
	/* 0xa88: csel w8, w8, w9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_a8c:
	/* 0xa8c: str w8, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_a90:
	/* 0xa90: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_a94:
	/* 0xa94: ldr w1, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_a98:
	/* 0xa98: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xa9cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_a9c:
	/* 0xa9c: adrp x25, 0 <tg_errmetrics_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_errmetrics_map_13));
arm64_l_aa0:
	/* 0xaa0: ldr x25, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_aa4:
	/* 0xaa4: cbz x0, b14 <generic_kprobe_process_filter+0xb14> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xaa4, 0xb14, arm64_l_b14);
arm64_l_aa8:
	/* 0xaa8: neg w8, w0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_aac:
	/* 0xaac: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ab0:
	/* 0xab0: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_ab4:
	/* 0xab4: strh w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_ab8:
	/* 0xab8: mov w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_abc:
	/* 0xabc: mov x0, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ac0:
	/* 0xac0: mov w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ac4:
	/* 0xac4: strh w8, [sp, #90] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 90ULL);
arm64_l_ac8:
	/* 0xac8: mov x8, #0x2da */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 730ULL);
arm64_l_acc:
	/* 0xacc: movk x8, #0x4, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 4ULL);
arm64_l_ad0:
	/* 0xad0: stur x8, [sp, #92] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_ad4:
	/* 0xad4: add x8, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_ad8:
	/* 0xad8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xadcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_adc:
	/* 0xadc: cbz x0, af0 <generic_kprobe_process_filter+0xaf0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xadc, 0xaf0, arm64_l_af0);
arm64_l_ae0:
	/* 0xae0: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ae4:
	/* 0xae4: add w8, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_ae8:
	/* 0xae8: str w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_aec:
	/* 0xaec: b b14 <generic_kprobe_process_filter+0xb14> */
	ARM64_SIM_A64_JMP(0xaec, 0xb14, arm64_l_b14);
arm64_l_af0:
	/* 0xaf0: str w20, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_af4:
	/* 0xaf4: mov x3, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_af8:
	/* 0xaf8: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_afc:
	/* 0xafc: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_b00:
	/* 0xb00: add x10, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_b04:
	/* 0xb04: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_b08:
	/* 0xb08: add x2, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_b0c:
	/* 0xb0c: mov x0, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b10:
	/* 0xb10: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0xb14ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_b14:
	/* 0xb14: ldr x9, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_b18:
	/* 0xb18: mov w8, #0x6390 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 25488ULL);
arm64_l_b1c:
	/* 0xb1c: add x2, x24, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X24, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_b20:
	/* 0xb20: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_b24:
	/* 0xb24: add x0, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_b28:
	/* 0xb28: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_b2c:
	/* 0xb2c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xb30ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_b30:
	/* 0xb30: cbz x0, b78 <generic_kprobe_process_filter+0xb78> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xb30, 0xb78, arm64_l_b78);
arm64_l_b34:
	/* 0xb34: neg w8, w0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_b38:
	/* 0xb38: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_b3c:
	/* 0xb3c: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_b40:
	/* 0xb40: strh w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_b44:
	/* 0xb44: mov w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_b48:
	/* 0xb48: mov x0, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b4c:
	/* 0xb4c: mov w19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_b50:
	/* 0xb50: strh w8, [sp, #90] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 90ULL);
arm64_l_b54:
	/* 0xb54: mov x8, #0x2dc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 732ULL);
arm64_l_b58:
	/* 0xb58: movk x8, #0x4, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 4ULL);
arm64_l_b5c:
	/* 0xb5c: stur x8, [sp, #92] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_b60:
	/* 0xb60: add x8, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_b64:
	/* 0xb64: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xb68ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_b68:
	/* 0xb68: cbz x0, b9c <generic_kprobe_process_filter+0xb9c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xb68, 0xb9c, arm64_l_b9c);
arm64_l_b6c:
	/* 0xb6c: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b70:
	/* 0xb70: add w8, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_b74:
	/* 0xb74: str w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b78:
	/* 0xb78: ldr w8, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_b7c:
	/* 0xb7c: sub w9, w8, #0x101 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 257ULL);
arm64_l_b80:
	/* 0xb80: cmn w9, #0x101 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 257ULL);
arm64_l_b84:
	/* 0xb84: b.hi bd0 <generic_kprobe_process_filter+0xbd0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xb84, 0xbd0, arm64_l_bd0);
arm64_l_b88:
	/* 0xb88: ldp x20, x29, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_b8c:
	/* 0xb8c: mov w8, #0xffffffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967295ULL);
arm64_l_b90:
	/* 0xb90: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_b94:
	/* 0xb94: stur w8, [x21, #184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_b98:
	/* 0xb98: b d1c <generic_kprobe_process_filter+0xd1c> */
	ARM64_SIM_A64_JMP(0xb98, 0xd1c, arm64_l_d1c);
arm64_l_b9c:
	/* 0xb9c: str w19, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_ba0:
	/* 0xba0: mov x3, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ba4:
	/* 0xba4: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_ba8:
	/* 0xba8: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_bac:
	/* 0xbac: add x10, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_bb0:
	/* 0xbb0: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_bb4:
	/* 0xbb4: add x2, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_bb8:
	/* 0xbb8: mov x0, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_bbc:
	/* 0xbbc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0xbc0ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_bc0:
	/* 0xbc0: ldr w8, [x21, #1360] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1360ULL);
arm64_l_bc4:
	/* 0xbc4: sub w9, w8, #0x101 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 257ULL);
arm64_l_bc8:
	/* 0xbc8: cmn w9, #0x101 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 257ULL);
arm64_l_bcc:
	/* 0xbcc: b.ls b88 <generic_kprobe_process_filter+0xb88> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0xbcc, 0xb88, arm64_l_b88);
arm64_l_bd0:
	/* 0xbd0: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_bd4:
	/* 0xbd4: and x24, x8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_bd8:
	/* 0xbd8: mov w8, #0x5f80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24448ULL);
arm64_l_bdc:
	/* 0xbdc: mov x2, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_be0:
	/* 0xbe0: mov w1, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_be4:
	/* 0xbe4: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_be8:
	/* 0xbe8: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_bec:
	/* 0xbec: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xbf0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_bf0:
	/* 0xbf0: mov x23, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_bf4:
	/* 0xbf4: cbz x0, c6c <generic_kprobe_process_filter+0xc6c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xbf4, 0xc6c, arm64_l_c6c);
arm64_l_bf8:
	/* 0xbf8: neg w8, w23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_bfc:
	/* 0xbfc: adrp x25, 0 <tg_errmetrics_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_errmetrics_map_13));
arm64_l_c00:
	/* 0xc00: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_c04:
	/* 0xc04: strh w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_c08:
	/* 0xc08: mov w8, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 15ULL);
arm64_l_c0c:
	/* 0xc0c: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_c10:
	/* 0xc10: mov w19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_c14:
	/* 0xc14: strh w8, [sp, #90] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 90ULL);
arm64_l_c18:
	/* 0xc18: mov x8, #0x168 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 360ULL);
arm64_l_c1c:
	/* 0xc1c: movk x8, #0x4, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 4ULL);
arm64_l_c20:
	/* 0xc20: stur x8, [sp, #92] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_c24:
	/* 0xc24: add x8, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_c28:
	/* 0xc28: ldr x25, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c2c:
	/* 0xc2c: mov x0, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c30:
	/* 0xc30: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xc34ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_c34:
	/* 0xc34: cbz x0, c48 <generic_kprobe_process_filter+0xc48> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xc34, 0xc48, arm64_l_c48);
arm64_l_c38:
	/* 0xc38: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c3c:
	/* 0xc3c: add w8, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_c40:
	/* 0xc40: str w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c44:
	/* 0xc44: b c6c <generic_kprobe_process_filter+0xc6c> */
	ARM64_SIM_A64_JMP(0xc44, 0xc6c, arm64_l_c6c);
arm64_l_c48:
	/* 0xc48: str w19, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_c4c:
	/* 0xc4c: mov x3, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c50:
	/* 0xc50: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_c54:
	/* 0xc54: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_c58:
	/* 0xc58: add x10, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_c5c:
	/* 0xc5c: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_c60:
	/* 0xc60: add x2, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_c64:
	/* 0xc64: mov x0, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c68:
	/* 0xc68: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0xc6cULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_c6c:
	/* 0xc6c: cmp w23, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_c70:
	/* 0xc70: csel w8, w24, w23, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_c74:
	/* 0xc74: cmp w24, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_c78:
	/* 0xc78: stur w8, [x21, #184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_c7c:
	/* 0xc7c: mov w8, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_c80:
	/* 0xc80: csel w1, w24, w8, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X1, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_c84:
	/* 0xc84: mov w8, #0x6080 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24704ULL);
arm64_l_c88:
	/* 0xc88: add x0, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_c8c:
	/* 0xc8c: mov w8, #0x6390 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 25488ULL);
arm64_l_c90:
	/* 0xc90: add x2, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_c94:
	/* 0xc94: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_c98:
	/* 0xc98: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xc9cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_c9c:
	/* 0xc9c: ldr x20, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_ca0:
	/* 0xca0: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_ca4:
	/* 0xca4: cbz x0, d1c <generic_kprobe_process_filter+0xd1c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xca4, 0xd1c, arm64_l_d1c);
arm64_l_ca8:
	/* 0xca8: neg w8, w0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_cac:
	/* 0xcac: adrp x23, 0 <tg_errmetrics_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_errmetrics_map_13));
arm64_l_cb0:
	/* 0xcb0: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_cb4:
	/* 0xcb4: strh w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_cb8:
	/* 0xcb8: mov w8, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 15ULL);
arm64_l_cbc:
	/* 0xcbc: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_cc0:
	/* 0xcc0: mov w19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_cc4:
	/* 0xcc4: strh w8, [sp, #90] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 90ULL);
arm64_l_cc8:
	/* 0xcc8: mov x8, #0x16e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 366ULL);
arm64_l_ccc:
	/* 0xccc: movk x8, #0x4, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 4ULL);
arm64_l_cd0:
	/* 0xcd0: stur x8, [sp, #92] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_cd4:
	/* 0xcd4: add x8, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_cd8:
	/* 0xcd8: ldr x23, [x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cdc:
	/* 0xcdc: mov x0, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ce0:
	/* 0xce0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xce4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_ce4:
	/* 0xce4: cbz x0, cf8 <generic_kprobe_process_filter+0xcf8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xce4, 0xcf8, arm64_l_cf8);
arm64_l_ce8:
	/* 0xce8: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cec:
	/* 0xcec: add w8, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_cf0:
	/* 0xcf0: str w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cf4:
	/* 0xcf4: b d1c <generic_kprobe_process_filter+0xd1c> */
	ARM64_SIM_A64_JMP(0xcf4, 0xd1c, arm64_l_d1c);
arm64_l_cf8:
	/* 0xcf8: str w19, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_cfc:
	/* 0xcfc: mov x3, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d00:
	/* 0xd00: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_d04:
	/* 0xd04: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_d08:
	/* 0xd08: add x10, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_d0c:
	/* 0xd0c: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_d10:
	/* 0xd10: add x2, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_d14:
	/* 0xd14: mov x0, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d18:
	/* 0xd18: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0xd1cULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_d1c:
	/* 0xd1c: ldrb w8, [x29, #1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1ULL);
arm64_l_d20:
	/* 0xd20: orr w8, w8, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_d24:
	/* 0xd24: strb w8, [x29, #1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1ULL);
arm64_l_d28:
	/* 0xd28: adrp x0, 0 <filter_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&filter_map_5));
arm64_l_d2c:
	/* 0xd2c: mov w8, #0x5ef8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24312ULL);
arm64_l_d30:
	/* 0xd30: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d34:
	/* 0xd34: add x1, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X1, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_d38:
	/* 0xd38: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d3c:
	/* 0xd3c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xd40ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_d40:
	/* 0xd40: cbz x0, 21ec <generic_kprobe_process_filter+0x21ec> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xd40, 0x21ec, arm64_l_21ec);
arm64_l_d44:
	/* 0xd44: str x21, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_d48:
	/* 0xd48: ldr x21, [x29, #24248] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24248ULL);
arm64_l_d4c:
	/* 0xd4c: cmp x21, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_d50:
	/* 0xd50: b.cs ee4 <generic_kprobe_process_filter+0xee4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xd50, 0xee4, arm64_l_ee4);
arm64_l_d54:
	/* 0xd54: ldrsw x8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDRSW, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d58:
	/* 0xd58: mov x23, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d5c:
	/* 0xd5c: cbz w8, f04 <generic_kprobe_process_filter+0xf04> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xd5c, 0xf04, arm64_l_f04);
arm64_l_d60:
	/* 0xd60: cmp x21, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d64:
	/* 0xd64: b.cs ee4 <generic_kprobe_process_filter+0xee4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xd64, 0xee4, arm64_l_ee4);
arm64_l_d68:
	/* 0xd68: stp x8, x20, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_d6c:
	/* 0xd6c: adrp x24, 0 <tg_mb_sel_opts> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mb_sel_opts_15));
arm64_l_d70:
	/* 0xd70: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d74:
	/* 0xd74: add x9, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_d78:
	/* 0xd78: add x1, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_d7c:
	/* 0xd7c: str x22, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_d80:
	/* 0xd80: str w21, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_d84:
	/* 0xd84: str wzr, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_d88:
	/* 0xd88: ldr x24, [x24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d8c:
	/* 0xd8c: mov x0, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d90:
	/* 0xd90: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xd94ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_d94:
	/* 0xd94: cbz x0, 11b4 <generic_kprobe_process_filter+0x11b4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xd94, 0x11b4, arm64_l_11b4);
arm64_l_d98:
	/* 0xd98: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d9c:
	/* 0xd9c: mov x25, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_da0:
	/* 0xda0: cbz w8, 11b4 <generic_kprobe_process_filter+0x11b4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xda0, 0x11b4, arm64_l_11b4);
arm64_l_da4:
	/* 0xda4: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_da8:
	/* 0xda8: str x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_dac:
	/* 0xdac: ldr w9, [x9, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_db0:
	/* 0xdb0: tbnz w9, #31, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_TBNZ(ARM64_X9, 31, 0xdb0, 0x158c, arm64_l_158c);
arm64_l_db4:
	/* 0xdb4: cmp w8, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_db8:
	/* 0xdb8: b.hi 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xdb8, 0x158c, arm64_l_158c);
arm64_l_dbc:
	/* 0xdbc: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_dc0:
	/* 0xdc0: lsl w9, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_dc4:
	/* 0xdc4: tst w9, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_dc8:
	/* 0xdc8: b.ne fc8 <generic_kprobe_process_filter+0xfc8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xdc8, 0xfc8, arm64_l_fc8);
arm64_l_dcc:
	/* 0xdcc: mov w10, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_dd0:
	/* 0xdd0: movk w10, #0x400, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 1024ULL);
arm64_l_dd4:
	/* 0xdd4: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_dd8:
	/* 0xdd8: b.ne f44 <generic_kprobe_process_filter+0xf44> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xdd8, 0xf44, arm64_l_f44);
arm64_l_ddc:
	/* 0xddc: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_de0:
	/* 0xde0: lsl w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_de4:
	/* 0xde4: mov w9, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 512ULL);
arm64_l_de8:
	/* 0xde8: movk w9, #0x800, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 2048ULL);
arm64_l_dec:
	/* 0xdec: tst w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_df0:
	/* 0xdf0: b.eq 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xdf0, 0x158c, arm64_l_158c);
arm64_l_df4:
	/* 0xdf4: adrp x0, 0 <string_postfix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_10));
arm64_l_df8:
	/* 0xdf8: add x1, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_dfc:
	/* 0xdfc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_e00:
	/* 0xe00: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e04:
	/* 0xe04: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xe08ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_e08:
	/* 0xe08: cbz x0, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xe08, 0x158c, arm64_l_158c);
arm64_l_e0c:
	/* 0xe0c: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_e10:
	/* 0xe10: mov x20, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e14:
	/* 0xe14: adrp x0, 0 <string_postfix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap_11));
arm64_l_e18:
	/* 0xe18: mov w9, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_e1c:
	/* 0xe1c: ldr w8, [x8, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_e20:
	/* 0xe20: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e24:
	/* 0xe24: add x1, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_e28:
	/* 0xe28: cmp w8, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_e2c:
	/* 0xe2c: csel w19, w8, w9, lt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X19, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LT, 0);
arm64_l_e30:
	/* 0xe30: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_e34:
	/* 0xe34: add x9, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_e38:
	/* 0xe38: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xe3cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_e3c:
	/* 0xe3c: cbz x0, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xe3c, 0x158c, arm64_l_158c);
arm64_l_e40:
	/* 0xe40: sxtw x1, w19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SXTW, ARM64_X1, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e44:
	/* 0xe44: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e48:
	/* 0xe48: lsl w8, w1, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_e4c:
	/* 0xe4c: str w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e50:
	/* 0xe50: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_e54:
	/* 0xe54: ldr w8, [x8, #108] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 108ULL);
arm64_l_e58:
	/* 0xe58: cbnz w8, eb8 <generic_kprobe_process_filter+0xeb8> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0xe58, 0xeb8, arm64_l_eb8);
arm64_l_e5c:
	/* 0xe5c: ldr x11, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_e60:
	/* 0xe60: and w13, w1, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_e64:
	/* 0xe64: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e68:
	/* 0xe68: ldr w12, [x11, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_e6c:
	/* 0xe6c: add x9, x11, #0x1f0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 496ULL);
arm64_l_e70:
	/* 0xe70: add x10, x11, #0x170 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 368ULL);
arm64_l_e74:
	/* 0xe74: sub w11, w12, w1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X12, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_e78:
	/* 0xe78: add w12, w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_e7c:
	/* 0xe7c: add w11, w11, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X11, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_e80:
	/* 0xe80: mvn w13, w1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MVN, ARM64_X13, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_e84:
	/* 0xe84: add w12, w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_e88:
	/* 0xe88: cmp x8, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_e8c:
	/* 0xe8c: b.eq eac <generic_kprobe_process_filter+0xeac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe8c, 0xeac, arm64_l_eac);
arm64_l_e90:
	/* 0xe90: and x13, x12, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_e94:
	/* 0xe94: sub w12, w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_e98:
	/* 0xe98: ldrb w13, [x10, x13] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X10, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X13, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e9c:
	/* 0xe9c: strb w13, [x9, x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X13, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ea0:
	/* 0xea0: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_ea4:
	/* 0xea4: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ea8:
	/* 0xea8: b.ne e88 <generic_kprobe_process_filter+0xe88> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xea8, 0xe88, arm64_l_e88);
arm64_l_eac:
	/* 0xeac: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_eb0:
	/* 0xeb0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_eb4:
	/* 0xeb4: str w8, [x9, #108] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 108ULL);
arm64_l_eb8:
	/* 0xeb8: cmp w1, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_ebc:
	/* 0xebc: b.hi ed8 <generic_kprobe_process_filter+0xed8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xebc, 0xed8, arm64_l_ed8);
arm64_l_ec0:
	/* 0xec0: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_ec4:
	/* 0xec4: add x0, x29, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_ec8:
	/* 0xec8: add x2, x8, #0x1f0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 496ULL);
arm64_l_ecc:
	/* 0xecc: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_ed0:
	/* 0xed0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xed4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_ed4:
	/* 0xed4: tbnz x0, #63, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0xed4, 0x158c, arm64_l_158c);
arm64_l_ed8:
	/* 0xed8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_edc:
	/* 0xedc: mov x0, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ee0:
	/* 0xee0: b fc0 <generic_kprobe_process_filter+0xfc0> */
	ARM64_SIM_A64_JMP(0xee0, 0xfc0, arm64_l_fc0);
arm64_l_ee4:
	/* 0xee4: ldr w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ee8:
	/* 0xee8: str w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_eec:
	/* 0xeec: ldr x8, [x22, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_ef0:
	/* 0xef0: str x8, [x29, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_ef4:
	/* 0xef4: ldr x8, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_ef8:
	/* 0xef8: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_efc:
	/* 0xefc: cbnz w8, 21d0 <generic_kprobe_process_filter+0x21d0> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0xefc, 0x21d0, arm64_l_21d0);
arm64_l_f00:
	/* 0xf00: b 21ec <generic_kprobe_process_filter+0x21ec> */
	ARM64_SIM_A64_JMP(0xf00, 0x21ec, arm64_l_21ec);
arm64_l_f04:
	/* 0xf04: ldr x9, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_f08:
	/* 0xf08: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f0c:
	/* 0xf0c: strb w8, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f10:
	/* 0xf10: ldr w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f14:
	/* 0xf14: str w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_f18:
	/* 0xf18: ldr x8, [x22, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_f1c:
	/* 0xf1c: str x8, [x29, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_f20:
	/* 0xf20: b 21d0 <generic_kprobe_process_filter+0x21d0> */
	ARM64_SIM_A64_JMP(0xf20, 0x21d0, arm64_l_21d0);
arm64_l_f24:
	/* 0xf24: mov w8, #0x2964 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10596ULL);
arm64_l_f28:
	/* 0xf28: add x20, x24, #0xff6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4086ULL);
arm64_l_f2c:
	/* 0xf2c: strh w8, [x24, #4094] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4094ULL);
arm64_l_f30:
	/* 0xf30: adrp x8, 10 <generic_kprobe_process_filter+0x10> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&arm64_section_Some_SectionIndex_16_addend_0_2));
arm64_l_f34:
	/* 0xf34: add x8, x8, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_f38:
	/* 0xf38: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f3c:
	/* 0xf3c: str x8, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f40:
	/* 0xf40: b 73c <generic_kprobe_process_filter+0x73c> */
	ARM64_SIM_A64_JMP(0xf40, 0x73c, arm64_l_73c);
arm64_l_f44:
	/* 0xf44: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_12));
arm64_l_f48:
	/* 0xf48: add x1, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_f4c:
	/* 0xf4c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f50:
	/* 0xf50: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f54:
	/* 0xf54: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xf58ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_f58:
	/* 0xf58: cbz x0, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xf58, 0x158c, arm64_l_158c);
arm64_l_f5c:
	/* 0xf5c: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f60:
	/* 0xf60: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_9));
arm64_l_f64:
	/* 0xf64: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f68:
	/* 0xf68: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f6c:
	/* 0xf6c: add x9, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_f70:
	/* 0xf70: add x1, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_f74:
	/* 0xf74: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xf78ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_f78:
	/* 0xf78: cbz x0, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xf78, 0x158c, arm64_l_158c);
arm64_l_f7c:
	/* 0xf7c: mov w1, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_f80:
	/* 0xf80: mov w2, #0x104 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 260ULL);
arm64_l_f84:
	/* 0xf84: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f88:
	/* 0xf88: bl 0 <memset> */
	ARM64_SIM_A64_CALL(arm64_l_0, 0xf8cULL);
arm64_l_f8c:
	/* 0xf8c: ldr x10, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_f90:
	/* 0xf90: mov x0, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f94:
	/* 0xf94: ldr w8, [x10, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_f98:
	/* 0xf98: add x2, x10, #0x70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_f9c:
	/* 0xf9c: lsl w9, w8, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_fa0:
	/* 0xfa0: and x8, x8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_fa4:
	/* 0xfa4: str w9, [x0], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_fa8:
	/* 0xfa8: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_fac:
	/* 0xfac: ldrb w1, [x10, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_fb0:
	/* 0xfb0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xfb4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_fb4:
	/* 0xfb4: tbnz x0, #63, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0xfb4, 0x158c, arm64_l_158c);
arm64_l_fb8:
	/* 0xfb8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_fbc:
	/* 0xfbc: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_fc0:
	/* 0xfc0: mov x1, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_fc4:
	/* 0xfc4: b 1178 <generic_kprobe_process_filter+0x1178> */
	ARM64_SIM_A64_JMP(0xfc4, 0x1178, arm64_l_1178);
arm64_l_fc8:
	/* 0xfc8: str wzr, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_fcc:
	/* 0xfcc: adrp x0, 0 <tg_mbset_gen> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mbset_gen_16));
arm64_l_fd0:
	/* 0xfd0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_fd4:
	/* 0xfd4: add x9, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_fd8:
	/* 0xfd8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_fdc:
	/* 0xfdc: add x1, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_fe0:
	/* 0xfe0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xfe4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_fe4:
	/* 0xfe4: cbz x0, 1124 <generic_kprobe_process_filter+0x1124> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xfe4, 0x1124, arm64_l_1124);
arm64_l_fe8:
	/* 0xfe8: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_fec:
	/* 0xfec: ldr x8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ff0:
	/* 0xff0: ldr x9, [x9, #888] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 888ULL);
arm64_l_ff4:
	/* 0xff4: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ff8:
	/* 0xff8: b.eq 1124 <generic_kprobe_process_filter+0x1124> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xff8, 0x1124, arm64_l_1124);
arm64_l_ffc:
	/* 0xffc: str x0, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1000:
	/* 0x1000: adrp x8, 0 <CONFIG_ITER_NUM> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM_0));
arm64_l_1004:
	/* 0x1004: mov w20, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1008:
	/* 0x1008: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_100c:
	/* 0x100c: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1010:
	/* 0x1010: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1014:
	/* 0x1014: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1018:
	/* 0x1018: add x19, x9, #0x370 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 880ULL);
arm64_l_101c:
	/* 0x101c: cbz w8, 10ec <generic_kprobe_process_filter+0x10ec> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x101c, 0x10ec, arm64_l_10ec);
arm64_l_1020:
	/* 0x1020: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1024:
	/* 0x1024: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1028:
	/* 0x1028: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_102c:
	/* 0x102c: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1030:
	/* 0x1030: ldr w8, [x8, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1034:
	/* 0x1034: str w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1038:
	/* 0x1038: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_103c:
	/* 0x103c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1040:
	/* 0x1040: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1044ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1044:
	/* 0x1044: cbz x0, 1114 <generic_kprobe_process_filter+0x1114> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1044, 0x1114, arm64_l_1114);
arm64_l_1048:
	/* 0x1048: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_104c:
	/* 0x104c: add x1, x0, #0x70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_1050:
	/* 0x1050: adrp x0, 0 <tg_mbset_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mbset_map_17));
arm64_l_1054:
	/* 0x1054: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1058:
	/* 0x1058: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_105c:
	/* 0x105c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1060ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1060:
	/* 0x1060: cbz x0, 107c <generic_kprobe_process_filter+0x107c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1060, 0x107c, arm64_l_107c);
arm64_l_1064:
	/* 0x1064: ldr x8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1068:
	/* 0x1068: cbz x8, 107c <generic_kprobe_process_filter+0x107c> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1068, 0x107c, arm64_l_107c);
arm64_l_106c:
	/* 0x106c: ldaxr x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1070:
	/* 0x1070: orr x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1074:
	/* 0x1074: stlxr w10, x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STLXR, ARM64_X10, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0);
arm64_l_1078:
	/* 0x1078: cbnz w10, 106c <generic_kprobe_process_filter+0x106c> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0x1078, 0x106c, arm64_l_106c);
arm64_l_107c:
	/* 0x107c: cmp x29, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1080:
	/* 0x1080: b.eq 1114 <generic_kprobe_process_filter+0x1114> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1080, 0x1114, arm64_l_1114);
arm64_l_1084:
	/* 0x1084: mov w8, #0x86a0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 34464ULL);
arm64_l_1088:
	/* 0x1088: add w20, w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_108c:
	/* 0x108c: mov x22, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1090:
	/* 0x1090: movk w8, #0x1, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 1ULL);
arm64_l_1094:
	/* 0x1094: cmp w20, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1098:
	/* 0x1098: b.ne 1020 <generic_kprobe_process_filter+0x1020> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1098, 0x1020, arm64_l_1020);
arm64_l_109c:
	/* 0x109c: b 1114 <generic_kprobe_process_filter+0x1114> */
	ARM64_SIM_A64_JMP(0x109c, 0x1114, arm64_l_1114);
arm64_l_10a0:
	/* 0x10a0: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10a4:
	/* 0x10a4: add x1, x0, #0x70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_10a8:
	/* 0x10a8: adrp x0, 0 <tg_mbset_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mbset_map_17));
arm64_l_10ac:
	/* 0x10ac: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_10b0:
	/* 0x10b0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_10b4:
	/* 0x10b4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x10b8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_10b8:
	/* 0x10b8: cbz x0, 10d4 <generic_kprobe_process_filter+0x10d4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x10b8, 0x10d4, arm64_l_10d4);
arm64_l_10bc:
	/* 0x10bc: ldr x8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_10c0:
	/* 0x10c0: cbz x8, 10d4 <generic_kprobe_process_filter+0x10d4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x10c0, 0x10d4, arm64_l_10d4);
arm64_l_10c4:
	/* 0x10c4: ldaxr x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_10c8:
	/* 0x10c8: orr x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_10cc:
	/* 0x10cc: stlxr w10, x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STLXR, ARM64_X10, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0);
arm64_l_10d0:
	/* 0x10d0: cbnz w10, 10c4 <generic_kprobe_process_filter+0x10c4> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0x10d0, 0x10c4, arm64_l_10c4);
arm64_l_10d4:
	/* 0x10d4: cmp x29, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_10d8:
	/* 0x10d8: b.eq 1114 <generic_kprobe_process_filter+0x1114> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x10d8, 0x1114, arm64_l_1114);
arm64_l_10dc:
	/* 0x10dc: add w20, w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_10e0:
	/* 0x10e0: mov x22, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10e4:
	/* 0x10e4: cmp w20, #0x400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1024ULL);
arm64_l_10e8:
	/* 0x10e8: b.eq 1114 <generic_kprobe_process_filter+0x1114> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x10e8, 0x1114, arm64_l_1114);
arm64_l_10ec:
	/* 0x10ec: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_10f0:
	/* 0x10f0: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_10f4:
	/* 0x10f4: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_10f8:
	/* 0x10f8: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_10fc:
	/* 0x10fc: ldr w8, [x8, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1100:
	/* 0x1100: str w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1104:
	/* 0x1104: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1108:
	/* 0x1108: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_110c:
	/* 0x110c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1110ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1110:
	/* 0x1110: cbnz x0, 10a0 <generic_kprobe_process_filter+0x10a0> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x1110, 0x10a0, arm64_l_10a0);
arm64_l_1114:
	/* 0x1114: ldr x8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1118:
	/* 0x1118: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_111c:
	/* 0x111c: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1120:
	/* 0x1120: str x8, [x9, #888] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 888ULL);
arm64_l_1124:
	/* 0x1124: ldr w8, [x25, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1128:
	/* 0x1128: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_112c:
	/* 0x112c: b.eq 1150 <generic_kprobe_process_filter+0x1150> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x112c, 0x1150, arm64_l_1150);
arm64_l_1130:
	/* 0x1130: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1134:
	/* 0x1134: ldr x9, [x9, #880] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 880ULL);
arm64_l_1138:
	/* 0x1138: lsr x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 0);
arm64_l_113c:
	/* 0x113c: tbz w8, #0, 1150 <generic_kprobe_process_filter+0x1150> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 0, 0x113c, 0x1150, arm64_l_1150);
arm64_l_1140:
	/* 0x1140: mov x0, #0xffee */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 65518ULL);
arm64_l_1144:
	/* 0x1144: movk x0, #0xadc0, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 44480ULL);
arm64_l_1148:
	/* 0x1148: movk x0, #0xb, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 11ULL);
arm64_l_114c:
	/* 0x114c: b 117c <generic_kprobe_process_filter+0x117c> */
	ARM64_SIM_A64_JMP(0x114c, 0x117c, arm64_l_117c);
arm64_l_1150:
	/* 0x1150: adrp x0, 0 <tg_mb_paths> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mb_paths_14));
arm64_l_1154:
	/* 0x1154: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1158:
	/* 0x1158: add x9, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_115c:
	/* 0x115c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1160:
	/* 0x1160: add x1, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_1164:
	/* 0x1164: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1168ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1168:
	/* 0x1168: cbz x0, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1168, 0x158c, arm64_l_158c);
arm64_l_116c:
	/* 0x116c: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1170:
	/* 0x1170: add x1, x8, #0x70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_1174:
	/* 0x1174: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1178:
	/* 0x1178: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x117cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_117c:
	/* 0x117c: ldr w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1180:
	/* 0x1180: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1184:
	/* 0x1184: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_1188:
	/* 0x1188: b.hi 11b0 <generic_kprobe_process_filter+0x11b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1188, 0x11b0, arm64_l_11b0);
arm64_l_118c:
	/* 0x118c: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1190:
	/* 0x1190: lsl x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1194:
	/* 0x1194: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_1198:
	/* 0x1198: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_119c:
	/* 0x119c: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_11a0:
	/* 0x11a0: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_11a4:
	/* 0x11a4: b.eq 11b0 <generic_kprobe_process_filter+0x11b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x11a4, 0x11b0, arm64_l_11b0);
arm64_l_11a8:
	/* 0x11a8: cbnz x0, 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x11a8, 0x2194, arm64_l_2194);
arm64_l_11ac:
	/* 0x11ac: b 11b4 <generic_kprobe_process_filter+0x11b4> */
	ARM64_SIM_A64_JMP(0x11ac, 0x11b4, arm64_l_11b4);
arm64_l_11b0:
	/* 0x11b0: cbz x0, 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x11b0, 0x2194, arm64_l_2194);
arm64_l_11b4:
	/* 0x11b4: adrp x8, 0 <PARENTS_MAP_ENABLED> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&PARENTS_MAP_ENABLED_1));
arm64_l_11b8:
	/* 0x11b8: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_11bc:
	/* 0x11bc: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_11c0:
	/* 0x11c0: cbz w8, 1598 <generic_kprobe_process_filter+0x1598> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x11c0, 0x1598, arm64_l_1598);
arm64_l_11c4:
	/* 0x11c4: adrp x0, 0 <tg_parents_bin> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_parents_bin_18));
arm64_l_11c8:
	/* 0x11c8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_11cc:
	/* 0x11cc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_11d0:
	/* 0x11d0: ldr x1, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_11d4:
	/* 0x11d4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x11d8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_11d8:
	/* 0x11d8: cbz x0, 1598 <generic_kprobe_process_filter+0x1598> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x11d8, 0x1598, arm64_l_1598);
arm64_l_11dc:
	/* 0x11dc: add w8, w21, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_11e0:
	/* 0x11e0: str wzr, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_11e4:
	/* 0x11e4: add x9, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_11e8:
	/* 0x11e8: mov x25, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11ec:
	/* 0x11ec: str w8, [sp, #216] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_11f0:
	/* 0x11f0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_11f4:
	/* 0x11f4: add x1, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_11f8:
	/* 0x11f8: mov x0, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11fc:
	/* 0x11fc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1200ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1200:
	/* 0x1200: cbz x0, 1598 <generic_kprobe_process_filter+0x1598> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1200, 0x1598, arm64_l_1598);
arm64_l_1204:
	/* 0x1204: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1208:
	/* 0x1208: mov x24, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_120c:
	/* 0x120c: cbz w8, 1598 <generic_kprobe_process_filter+0x1598> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x120c, 0x1598, arm64_l_1598);
arm64_l_1210:
	/* 0x1210: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1214:
	/* 0x1214: str x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1218:
	/* 0x1218: tbnz w9, #31, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_TBNZ(ARM64_X9, 31, 0x1218, 0x158c, arm64_l_158c);
arm64_l_121c:
	/* 0x121c: cmp w8, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_1220:
	/* 0x1220: b.hi 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1220, 0x158c, arm64_l_158c);
arm64_l_1224:
	/* 0x1224: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1228:
	/* 0x1228: lsl w9, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_122c:
	/* 0x122c: tst w9, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1230:
	/* 0x1230: b.ne 13b8 <generic_kprobe_process_filter+0x13b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1230, 0x13b8, arm64_l_13b8);
arm64_l_1234:
	/* 0x1234: mov w10, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_1238:
	/* 0x1238: movk w10, #0x400, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 1024ULL);
arm64_l_123c:
	/* 0x123c: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1240:
	/* 0x1240: b.ne 1338 <generic_kprobe_process_filter+0x1338> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1240, 0x1338, arm64_l_1338);
arm64_l_1244:
	/* 0x1244: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1248:
	/* 0x1248: lsl w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_124c:
	/* 0x124c: mov w9, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 512ULL);
arm64_l_1250:
	/* 0x1250: movk w9, #0x800, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 2048ULL);
arm64_l_1254:
	/* 0x1254: tst w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1258:
	/* 0x1258: b.eq 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1258, 0x158c, arm64_l_158c);
arm64_l_125c:
	/* 0x125c: adrp x0, 0 <string_postfix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_10));
arm64_l_1260:
	/* 0x1260: add x1, x24, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1264:
	/* 0x1264: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1268:
	/* 0x1268: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_126c:
	/* 0x126c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1270ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1270:
	/* 0x1270: cbz x0, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1270, 0x158c, arm64_l_158c);
arm64_l_1274:
	/* 0x1274: ldr w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1278:
	/* 0x1278: mov x20, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_127c:
	/* 0x127c: adrp x0, 0 <string_postfix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap_11));
arm64_l_1280:
	/* 0x1280: mov w9, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_1284:
	/* 0x1284: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1288:
	/* 0x1288: add x1, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_128c:
	/* 0x128c: cmp w8, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_1290:
	/* 0x1290: csel w19, w8, w9, lt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X19, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LT, 0);
arm64_l_1294:
	/* 0x1294: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1298:
	/* 0x1298: add x9, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_129c:
	/* 0x129c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x12a0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_12a0:
	/* 0x12a0: cbz x0, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x12a0, 0x158c, arm64_l_158c);
arm64_l_12a4:
	/* 0x12a4: sxtw x1, w19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SXTW, ARM64_X1, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_12a8:
	/* 0x12a8: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_12ac:
	/* 0x12ac: lsl w8, w1, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_12b0:
	/* 0x12b0: str w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_12b4:
	/* 0x12b4: ldr w8, [x25, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_12b8:
	/* 0x12b8: cbnz w8, 1310 <generic_kprobe_process_filter+0x1310> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0x12b8, 0x1310, arm64_l_1310);
arm64_l_12bc:
	/* 0x12bc: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_12c0:
	/* 0x12c0: and w13, w1, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_12c4:
	/* 0x12c4: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_12c8:
	/* 0x12c8: add x9, x25, #0x188 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 392ULL);
arm64_l_12cc:
	/* 0x12cc: add x10, x25, #0x108 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 264ULL);
arm64_l_12d0:
	/* 0x12d0: sub w11, w12, w1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X12, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_12d4:
	/* 0x12d4: add w12, w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_12d8:
	/* 0x12d8: add w11, w11, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X11, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_12dc:
	/* 0x12dc: mvn w13, w1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MVN, ARM64_X13, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_12e0:
	/* 0x12e0: add w12, w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_12e4:
	/* 0x12e4: cmp x8, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_12e8:
	/* 0x12e8: b.eq 1308 <generic_kprobe_process_filter+0x1308> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x12e8, 0x1308, arm64_l_1308);
arm64_l_12ec:
	/* 0x12ec: and x13, x12, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_12f0:
	/* 0x12f0: sub w12, w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_12f4:
	/* 0x12f4: ldrb w13, [x10, x13] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X10, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X13, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_12f8:
	/* 0x12f8: strb w13, [x9, x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X13, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_12fc:
	/* 0x12fc: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1300:
	/* 0x1300: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1304:
	/* 0x1304: b.ne 12e4 <generic_kprobe_process_filter+0x12e4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1304, 0x12e4, arm64_l_12e4);
arm64_l_1308:
	/* 0x1308: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_130c:
	/* 0x130c: str w8, [x25, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1310:
	/* 0x1310: cmp w1, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_1314:
	/* 0x1314: b.hi 132c <generic_kprobe_process_filter+0x132c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1314, 0x132c, arm64_l_132c);
arm64_l_1318:
	/* 0x1318: add x0, x29, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_131c:
	/* 0x131c: add x2, x25, #0x188 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 392ULL);
arm64_l_1320:
	/* 0x1320: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1324:
	/* 0x1324: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1328ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1328:
	/* 0x1328: tbnz x0, #63, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x1328, 0x158c, arm64_l_158c);
arm64_l_132c:
	/* 0x132c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1330:
	/* 0x1330: mov x0, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1334:
	/* 0x1334: b 13b0 <generic_kprobe_process_filter+0x13b0> */
	ARM64_SIM_A64_JMP(0x1334, 0x13b0, arm64_l_13b0);
arm64_l_1338:
	/* 0x1338: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_12));
arm64_l_133c:
	/* 0x133c: add x1, x24, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1340:
	/* 0x1340: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1344:
	/* 0x1344: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1348:
	/* 0x1348: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x134cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_134c:
	/* 0x134c: cbz x0, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x134c, 0x158c, arm64_l_158c);
arm64_l_1350:
	/* 0x1350: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1354:
	/* 0x1354: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_9));
arm64_l_1358:
	/* 0x1358: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_135c:
	/* 0x135c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1360:
	/* 0x1360: add x9, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_1364:
	/* 0x1364: add x1, sp, #0xc0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_1368:
	/* 0x1368: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x136cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_136c:
	/* 0x136c: cbz x0, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x136c, 0x158c, arm64_l_158c);
arm64_l_1370:
	/* 0x1370: mov w1, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1374:
	/* 0x1374: mov w2, #0x104 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 260ULL);
arm64_l_1378:
	/* 0x1378: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_137c:
	/* 0x137c: bl 0 <memset> */
	ARM64_SIM_A64_CALL(arm64_l_0, 0x1380ULL);
arm64_l_1380:
	/* 0x1380: ldr w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1384:
	/* 0x1384: mov x0, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1388:
	/* 0x1388: add x2, x25, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_138c:
	/* 0x138c: lsl w9, w8, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_1390:
	/* 0x1390: and x8, x8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1394:
	/* 0x1394: str w9, [x0], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_1398:
	/* 0x1398: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_139c:
	/* 0x139c: ldrb w1, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_13a0:
	/* 0x13a0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x13a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_13a4:
	/* 0x13a4: tbnz x0, #63, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x13a4, 0x158c, arm64_l_158c);
arm64_l_13a8:
	/* 0x13a8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_13ac:
	/* 0x13ac: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_13b0:
	/* 0x13b0: mov x1, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_13b4:
	/* 0x13b4: b 1554 <generic_kprobe_process_filter+0x1554> */
	ARM64_SIM_A64_JMP(0x13b4, 0x1554, arm64_l_1554);
arm64_l_13b8:
	/* 0x13b8: str wzr, [sp, #200] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_13bc:
	/* 0x13bc: adrp x0, 0 <tg_mbset_gen> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mbset_gen_16));
arm64_l_13c0:
	/* 0x13c0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_13c4:
	/* 0x13c4: add x9, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_13c8:
	/* 0x13c8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_13cc:
	/* 0x13cc: add x1, sp, #0xc8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_13d0:
	/* 0x13d0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x13d4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_13d4:
	/* 0x13d4: cbz x0, 1508 <generic_kprobe_process_filter+0x1508> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x13d4, 0x1508, arm64_l_1508);
arm64_l_13d8:
	/* 0x13d8: ldr x8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_13dc:
	/* 0x13dc: ldr x9, [x25, #784] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 784ULL);
arm64_l_13e0:
	/* 0x13e0: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_13e4:
	/* 0x13e4: b.eq 1508 <generic_kprobe_process_filter+0x1508> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x13e4, 0x1508, arm64_l_1508);
arm64_l_13e8:
	/* 0x13e8: str x0, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_13ec:
	/* 0x13ec: adrp x8, 0 <CONFIG_ITER_NUM> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM_0));
arm64_l_13f0:
	/* 0x13f0: add x19, x25, #0x308 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 776ULL);
arm64_l_13f4:
	/* 0x13f4: mov w20, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_13f8:
	/* 0x13f8: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_13fc:
	/* 0x13fc: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1400:
	/* 0x1400: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1404:
	/* 0x1404: cbz w8, 14d4 <generic_kprobe_process_filter+0x14d4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1404, 0x14d4, arm64_l_14d4);
arm64_l_1408:
	/* 0x1408: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_140c:
	/* 0x140c: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1410:
	/* 0x1410: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1414:
	/* 0x1414: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1418:
	/* 0x1418: ldr w8, [x8, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_141c:
	/* 0x141c: str w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1420:
	/* 0x1420: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1424:
	/* 0x1424: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1428:
	/* 0x1428: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x142cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_142c:
	/* 0x142c: cbz x0, 14fc <generic_kprobe_process_filter+0x14fc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x142c, 0x14fc, arm64_l_14fc);
arm64_l_1430:
	/* 0x1430: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1434:
	/* 0x1434: add x1, x0, #0x70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_1438:
	/* 0x1438: adrp x0, 0 <tg_mbset_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mbset_map_17));
arm64_l_143c:
	/* 0x143c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1440:
	/* 0x1440: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1444:
	/* 0x1444: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1448ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1448:
	/* 0x1448: cbz x0, 1464 <generic_kprobe_process_filter+0x1464> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1448, 0x1464, arm64_l_1464);
arm64_l_144c:
	/* 0x144c: ldr x8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1450:
	/* 0x1450: cbz x8, 1464 <generic_kprobe_process_filter+0x1464> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1450, 0x1464, arm64_l_1464);
arm64_l_1454:
	/* 0x1454: ldaxr x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1458:
	/* 0x1458: orr x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_145c:
	/* 0x145c: stlxr w10, x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STLXR, ARM64_X10, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0);
arm64_l_1460:
	/* 0x1460: cbnz w10, 1454 <generic_kprobe_process_filter+0x1454> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0x1460, 0x1454, arm64_l_1454);
arm64_l_1464:
	/* 0x1464: cmp x29, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1468:
	/* 0x1468: b.eq 14fc <generic_kprobe_process_filter+0x14fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1468, 0x14fc, arm64_l_14fc);
arm64_l_146c:
	/* 0x146c: mov w8, #0x86a0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 34464ULL);
arm64_l_1470:
	/* 0x1470: add w20, w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1474:
	/* 0x1474: mov x22, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1478:
	/* 0x1478: movk w8, #0x1, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 1ULL);
arm64_l_147c:
	/* 0x147c: cmp w20, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1480:
	/* 0x1480: b.ne 1408 <generic_kprobe_process_filter+0x1408> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1480, 0x1408, arm64_l_1408);
arm64_l_1484:
	/* 0x1484: b 14fc <generic_kprobe_process_filter+0x14fc> */
	ARM64_SIM_A64_JMP(0x1484, 0x14fc, arm64_l_14fc);
arm64_l_1488:
	/* 0x1488: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_148c:
	/* 0x148c: add x1, x0, #0x70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_1490:
	/* 0x1490: adrp x0, 0 <tg_mbset_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mbset_map_17));
arm64_l_1494:
	/* 0x1494: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1498:
	/* 0x1498: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_149c:
	/* 0x149c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x14a0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_14a0:
	/* 0x14a0: cbz x0, 14bc <generic_kprobe_process_filter+0x14bc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x14a0, 0x14bc, arm64_l_14bc);
arm64_l_14a4:
	/* 0x14a4: ldr x8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_14a8:
	/* 0x14a8: cbz x8, 14bc <generic_kprobe_process_filter+0x14bc> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x14a8, 0x14bc, arm64_l_14bc);
arm64_l_14ac:
	/* 0x14ac: ldaxr x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_14b0:
	/* 0x14b0: orr x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_14b4:
	/* 0x14b4: stlxr w10, x9, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STLXR, ARM64_X10, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0);
arm64_l_14b8:
	/* 0x14b8: cbnz w10, 14ac <generic_kprobe_process_filter+0x14ac> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0x14b8, 0x14ac, arm64_l_14ac);
arm64_l_14bc:
	/* 0x14bc: cmp x29, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_14c0:
	/* 0x14c0: b.eq 14fc <generic_kprobe_process_filter+0x14fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x14c0, 0x14fc, arm64_l_14fc);
arm64_l_14c4:
	/* 0x14c4: add w20, w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_14c8:
	/* 0x14c8: mov x22, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14cc:
	/* 0x14cc: cmp w20, #0x400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1024ULL);
arm64_l_14d0:
	/* 0x14d0: b.eq 14fc <generic_kprobe_process_filter+0x14fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x14d0, 0x14fc, arm64_l_14fc);
arm64_l_14d4:
	/* 0x14d4: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_14d8:
	/* 0x14d8: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_14dc:
	/* 0x14dc: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_14e0:
	/* 0x14e0: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_14e4:
	/* 0x14e4: ldr w8, [x8, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_14e8:
	/* 0x14e8: str w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_14ec:
	/* 0x14ec: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_14f0:
	/* 0x14f0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_14f4:
	/* 0x14f4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x14f8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_14f8:
	/* 0x14f8: cbnz x0, 1488 <generic_kprobe_process_filter+0x1488> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x14f8, 0x1488, arm64_l_1488);
arm64_l_14fc:
	/* 0x14fc: ldr x8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1500:
	/* 0x1500: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1504:
	/* 0x1504: str x8, [x25, #784] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 784ULL);
arm64_l_1508:
	/* 0x1508: ldr w8, [x24, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_150c:
	/* 0x150c: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1510:
	/* 0x1510: b.eq 1530 <generic_kprobe_process_filter+0x1530> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1510, 0x1530, arm64_l_1530);
arm64_l_1514:
	/* 0x1514: ldr x9, [x25, #776] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 776ULL);
arm64_l_1518:
	/* 0x1518: lsr x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 0);
arm64_l_151c:
	/* 0x151c: tbz w8, #0, 1530 <generic_kprobe_process_filter+0x1530> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 0, 0x151c, 0x1530, arm64_l_1530);
arm64_l_1520:
	/* 0x1520: mov x0, #0xffee */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 65518ULL);
arm64_l_1524:
	/* 0x1524: movk x0, #0xadc0, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 44480ULL);
arm64_l_1528:
	/* 0x1528: movk x0, #0xb, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 11ULL);
arm64_l_152c:
	/* 0x152c: b 1558 <generic_kprobe_process_filter+0x1558> */
	ARM64_SIM_A64_JMP(0x152c, 0x1558, arm64_l_1558);
arm64_l_1530:
	/* 0x1530: adrp x0, 0 <tg_mb_paths> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_mb_paths_14));
arm64_l_1534:
	/* 0x1534: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1538:
	/* 0x1538: add x9, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_153c:
	/* 0x153c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1540:
	/* 0x1540: add x1, sp, #0xd8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_1544:
	/* 0x1544: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1548ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1548:
	/* 0x1548: cbz x0, 158c <generic_kprobe_process_filter+0x158c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1548, 0x158c, arm64_l_158c);
arm64_l_154c:
	/* 0x154c: add x1, x25, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1550:
	/* 0x1550: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1554:
	/* 0x1554: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1558ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1558:
	/* 0x1558: ldr w8, [x24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_155c:
	/* 0x155c: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1560:
	/* 0x1560: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_1564:
	/* 0x1564: b.hi 1594 <generic_kprobe_process_filter+0x1594> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1564, 0x1594, arm64_l_1594);
arm64_l_1568:
	/* 0x1568: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_156c:
	/* 0x156c: lsl x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1570:
	/* 0x1570: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_1574:
	/* 0x1574: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_1578:
	/* 0x1578: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_157c:
	/* 0x157c: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1580:
	/* 0x1580: b.eq 1594 <generic_kprobe_process_filter+0x1594> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1580, 0x1594, arm64_l_1594);
arm64_l_1584:
	/* 0x1584: cbnz x0, 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x1584, 0x2194, arm64_l_2194);
arm64_l_1588:
	/* 0x1588: b 1598 <generic_kprobe_process_filter+0x1598> */
	ARM64_SIM_A64_JMP(0x1588, 0x1598, arm64_l_1598);
arm64_l_158c:
	/* 0x158c: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1590:
	/* 0x1590: b 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_JMP(0x1590, 0x2194, arm64_l_2194);
arm64_l_1594:
	/* 0x1594: cbz x0, 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1594, 0x2194, arm64_l_2194);
arm64_l_1598:
	/* 0x1598: lsl w8, w21, #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_159c:
	/* 0x159c: add x9, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_15a0:
	/* 0x15a0: ldr w8, [x9, x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X23, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_15a4:
	/* 0x15a4: add w9, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_15a8:
	/* 0x15a8: and w11, w9, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_15ac:
	/* 0x15ac: add w9, w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_15b0:
	/* 0x15b0: and x9, x9, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_15b4:
	/* 0x15b4: add x10, x11, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_15b8:
	/* 0x15b8: ldr w9, [x9, x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X23, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_15bc:
	/* 0x15bc: cmp w9, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_15c0:
	/* 0x15c0: b.cc 1658 <generic_kprobe_process_filter+0x1658> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x15c0, 0x1658, arm64_l_1658);
arm64_l_15c4:
	/* 0x15c4: add x9, x10, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_15c8:
	/* 0x15c8: str x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_15cc:
	/* 0x15cc: ldr w10, [x9, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_15d0:
	/* 0x15d0: ldp w12, w13, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_15d4:
	/* 0x15d4: stp x9, x11, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_15d8:
	/* 0x15d8: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_15dc:
	/* 0x15dc: cmp w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_15e0:
	/* 0x15e0: stp xzr, xzr, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_15e4:
	/* 0x15e4: csel w9, w10, w9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_15e8:
	/* 0x15e8: cmp w12, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_15ec:
	/* 0x15ec: b.ne 15f8 <generic_kprobe_process_filter+0x15f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x15ec, 0x15f8, arm64_l_15f8);
arm64_l_15f0:
	/* 0x15f0: mov x11, #0x100000001 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 4294967297ULL);
arm64_l_15f4:
	/* 0x15f4: stp x11, x11, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_15f8:
	/* 0x15f8: cbz w10, 1a88 <generic_kprobe_process_filter+0x1a88> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x15f8, 0x1a88, arm64_l_1a88);
arm64_l_15fc:
	/* 0x15fc: ldr x10, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1600:
	/* 0x1600: add w8, w8, w21, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_1604:
	/* 0x1604: tst x13, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1608:
	/* 0x1608: add x25, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_160c:
	/* 0x160c: str w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1610:
	/* 0x1610: mov x22, x13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1614:
	/* 0x1614: add w8, w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1618:
	/* 0x1618: and x8, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_161c:
	/* 0x161c: add x21, x8, #0x14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_1620:
	/* 0x1620: sub x8, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1624:
	/* 0x1624: mov w9, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_1628:
	/* 0x1628: add x11, x10, #0x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 36ULL);
arm64_l_162c:
	/* 0x162c: str x11, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1630:
	/* 0x1630: csel x11, x10, x11, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_EQ, 0);
arm64_l_1634:
	/* 0x1634: cmp x8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1638:
	/* 0x1638: add x10, x10, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_163c:
	/* 0x163c: csel x8, x8, x9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_1640:
	/* 0x1640: and x9, x21, #0x7fc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2044ULL);
arm64_l_1644:
	/* 0x1644: mov x20, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1648:
	/* 0x1648: str x10, [sp, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_164c:
	/* 0x164c: add x24, x23, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X23, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1650:
	/* 0x1650: add x19, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1654:
	/* 0x1654: b 1694 <generic_kprobe_process_filter+0x1694> */
	ARM64_SIM_A64_JMP(0x1654, 0x1694, arm64_l_1694);
arm64_l_1658:
	/* 0x1658: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_165c:
	/* 0x165c: mov w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1660:
	/* 0x1660: b 1ad4 <generic_kprobe_process_filter+0x1ad4> */
	ARM64_SIM_A64_JMP(0x1660, 0x1ad4, arm64_l_1ad4);
arm64_l_1664:
	/* 0x1664: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1668:
	/* 0x1668: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_166c:
	/* 0x166c: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1670:
	/* 0x1670: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1674:
	/* 0x1674: cmp w12, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1678:
	/* 0x1678: eor w8, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_167c:
	/* 0x167c: csinc w9, w8, wzr, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1680:
	/* 0x1680: str w9, [x25], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_1684:
	/* 0x1684: add x21, x21, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1688:
	/* 0x1688: add x24, x24, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_168c:
	/* 0x168c: subs x19, x19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 1ULL);
arm64_l_1690:
	/* 0x1690: b.eq 1a88 <generic_kprobe_process_filter+0x1a88> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1690, 0x1a88, arm64_l_1a88);
arm64_l_1694:
	/* 0x1694: cmp x21, #0x3e8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1000ULL);
arm64_l_1698:
	/* 0x1698: b.ls 18dc <generic_kprobe_process_filter+0x18dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1698, 0x18dc, arm64_l_18dc);
arm64_l_169c:
	/* 0x169c: mov x29, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_16a0:
	/* 0x16a0: tbz w13, #1, 18e4 <generic_kprobe_process_filter+0x18e4> */
	ARM64_SIM_A64_TBZ(ARM64_X13, 1, 0x16a0, 0x18e4, arm64_l_18e4);
arm64_l_16a4:
	/* 0x16a4: tbnz w13, #0, 1910 <generic_kprobe_process_filter+0x1910> */
	ARM64_SIM_A64_TBNZ(ARM64_X13, 0, 0x16a4, 0x1910, arm64_l_1910);
arm64_l_16a8:
	/* 0x16a8: ldr x10, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_16ac:
	/* 0x16ac: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_16b0:
	/* 0x16b0: ldr w9, [x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_16b4:
	/* 0x16b4: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_16b8:
	/* 0x16b8: b.eq 1674 <generic_kprobe_process_filter+0x1674> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x16b8, 0x1674, arm64_l_1674);
arm64_l_16bc:
	/* 0x16bc: ldr w9, [x10, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_16c0:
	/* 0x16c0: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_16c4:
	/* 0x16c4: b.eq 1674 <generic_kprobe_process_filter+0x1674> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x16c4, 0x1674, arm64_l_1674);
arm64_l_16c8:
	/* 0x16c8: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_16cc:
	/* 0x16cc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_16d0:
	/* 0x16d0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_16d4:
	/* 0x16d4: ldr x1, [sp, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_16d8:
	/* 0x16d8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x16dcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_16dc:
	/* 0x16dc: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x16dc, 0x1a68, arm64_l_1a68);
arm64_l_16e0:
	/* 0x16e0: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_16e4:
	/* 0x16e4: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_16e8:
	/* 0x16e8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_16ec:
	/* 0x16ec: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_16f0:
	/* 0x16f0: b.eq 1668 <generic_kprobe_process_filter+0x1668> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x16f0, 0x1668, arm64_l_1668);
arm64_l_16f4:
	/* 0x16f4: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_16f8:
	/* 0x16f8: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_16fc:
	/* 0x16fc: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1700:
	/* 0x1700: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1704:
	/* 0x1704: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1708:
	/* 0x1708: b.eq 1674 <generic_kprobe_process_filter+0x1674> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1708, 0x1674, arm64_l_1674);
arm64_l_170c:
	/* 0x170c: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1710:
	/* 0x1710: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1714:
	/* 0x1714: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1718:
	/* 0x1718: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x171cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_171c:
	/* 0x171c: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x171c, 0x1a68, arm64_l_1a68);
arm64_l_1720:
	/* 0x1720: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1724:
	/* 0x1724: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1728:
	/* 0x1728: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_172c:
	/* 0x172c: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1730:
	/* 0x1730: b.eq 1668 <generic_kprobe_process_filter+0x1668> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1730, 0x1668, arm64_l_1668);
arm64_l_1734:
	/* 0x1734: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_1738:
	/* 0x1738: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_173c:
	/* 0x173c: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1740:
	/* 0x1740: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1744:
	/* 0x1744: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1748:
	/* 0x1748: b.eq 1674 <generic_kprobe_process_filter+0x1674> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1748, 0x1674, arm64_l_1674);
arm64_l_174c:
	/* 0x174c: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1750:
	/* 0x1750: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1754:
	/* 0x1754: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1758:
	/* 0x1758: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x175cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_175c:
	/* 0x175c: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x175c, 0x1a68, arm64_l_1a68);
arm64_l_1760:
	/* 0x1760: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1764:
	/* 0x1764: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1768:
	/* 0x1768: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_176c:
	/* 0x176c: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1770:
	/* 0x1770: b.eq 1668 <generic_kprobe_process_filter+0x1668> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1770, 0x1668, arm64_l_1668);
arm64_l_1774:
	/* 0x1774: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_1778:
	/* 0x1778: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_177c:
	/* 0x177c: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1780:
	/* 0x1780: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1784:
	/* 0x1784: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1788:
	/* 0x1788: b.eq 1674 <generic_kprobe_process_filter+0x1674> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1788, 0x1674, arm64_l_1674);
arm64_l_178c:
	/* 0x178c: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1790:
	/* 0x1790: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1794:
	/* 0x1794: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1798:
	/* 0x1798: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x179cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_179c:
	/* 0x179c: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x179c, 0x1a68, arm64_l_1a68);
arm64_l_17a0:
	/* 0x17a0: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17a4:
	/* 0x17a4: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_17a8:
	/* 0x17a8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_17ac:
	/* 0x17ac: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17b0:
	/* 0x17b0: b.eq 1668 <generic_kprobe_process_filter+0x1668> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x17b0, 0x1668, arm64_l_1668);
arm64_l_17b4:
	/* 0x17b4: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_17b8:
	/* 0x17b8: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_17bc:
	/* 0x17bc: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_17c0:
	/* 0x17c0: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_17c4:
	/* 0x17c4: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17c8:
	/* 0x17c8: b.eq 1674 <generic_kprobe_process_filter+0x1674> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x17c8, 0x1674, arm64_l_1674);
arm64_l_17cc:
	/* 0x17cc: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_17d0:
	/* 0x17d0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_17d4:
	/* 0x17d4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17d8:
	/* 0x17d8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x17dcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_17dc:
	/* 0x17dc: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x17dc, 0x1a68, arm64_l_1a68);
arm64_l_17e0:
	/* 0x17e0: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17e4:
	/* 0x17e4: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_17e8:
	/* 0x17e8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_17ec:
	/* 0x17ec: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17f0:
	/* 0x17f0: b.eq 1668 <generic_kprobe_process_filter+0x1668> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x17f0, 0x1668, arm64_l_1668);
arm64_l_17f4:
	/* 0x17f4: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_17f8:
	/* 0x17f8: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_17fc:
	/* 0x17fc: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1800:
	/* 0x1800: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1804:
	/* 0x1804: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1808:
	/* 0x1808: b.eq 1674 <generic_kprobe_process_filter+0x1674> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1808, 0x1674, arm64_l_1674);
arm64_l_180c:
	/* 0x180c: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1810:
	/* 0x1810: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1814:
	/* 0x1814: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1818:
	/* 0x1818: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x181cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_181c:
	/* 0x181c: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x181c, 0x1a68, arm64_l_1a68);
arm64_l_1820:
	/* 0x1820: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1824:
	/* 0x1824: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1828:
	/* 0x1828: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_182c:
	/* 0x182c: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1830:
	/* 0x1830: b.eq 1668 <generic_kprobe_process_filter+0x1668> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1830, 0x1668, arm64_l_1668);
arm64_l_1834:
	/* 0x1834: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_1838:
	/* 0x1838: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_183c:
	/* 0x183c: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1840:
	/* 0x1840: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1844:
	/* 0x1844: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1848:
	/* 0x1848: b.eq 1674 <generic_kprobe_process_filter+0x1674> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1848, 0x1674, arm64_l_1674);
arm64_l_184c:
	/* 0x184c: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1850:
	/* 0x1850: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1854:
	/* 0x1854: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1858:
	/* 0x1858: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x185cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_185c:
	/* 0x185c: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x185c, 0x1a68, arm64_l_1a68);
arm64_l_1860:
	/* 0x1860: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1864:
	/* 0x1864: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1868:
	/* 0x1868: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_186c:
	/* 0x186c: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1870:
	/* 0x1870: b.eq 1668 <generic_kprobe_process_filter+0x1668> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1870, 0x1668, arm64_l_1668);
arm64_l_1874:
	/* 0x1874: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_1878:
	/* 0x1878: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_187c:
	/* 0x187c: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1880:
	/* 0x1880: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1884:
	/* 0x1884: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1888:
	/* 0x1888: b.eq 1674 <generic_kprobe_process_filter+0x1674> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1888, 0x1674, arm64_l_1674);
arm64_l_188c:
	/* 0x188c: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1890:
	/* 0x1890: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1894:
	/* 0x1894: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1898:
	/* 0x1898: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x189cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_189c:
	/* 0x189c: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x189c, 0x1a68, arm64_l_1a68);
arm64_l_18a0:
	/* 0x18a0: ldr w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18a4:
	/* 0x18a4: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_18a8:
	/* 0x18a8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_18ac:
	/* 0x18ac: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_18b0:
	/* 0x18b0: b.eq 1668 <generic_kprobe_process_filter+0x1668> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x18b0, 0x1668, arm64_l_1668);
arm64_l_18b4:
	/* 0x18b4: ldr w9, [x1, #16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_18b8:
	/* 0x18b8: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_18bc:
	/* 0x18bc: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_18c0:
	/* 0x18c0: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_18c4:
	/* 0x18c4: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_18c8:
	/* 0x18c8: b.eq 1674 <generic_kprobe_process_filter+0x1674> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x18c8, 0x1674, arm64_l_1674);
arm64_l_18cc:
	/* 0x18cc: adrp x9, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_18d0:
	/* 0x18d0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_18d4:
	/* 0x18d4: ldr x9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18d8:
	/* 0x18d8: b 1a5c <generic_kprobe_process_filter+0x1a5c> */
	ARM64_SIM_A64_JMP(0x18d8, 0x1a5c, arm64_l_1a5c);
arm64_l_18dc:
	/* 0x18dc: ldr w29, [x24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18e0:
	/* 0x18e0: tbnz w13, #1, 16a4 <generic_kprobe_process_filter+0x16a4> */
	ARM64_SIM_A64_TBNZ(ARM64_X13, 1, 0x18e0, 0x16a4, arm64_l_16a4);
arm64_l_18e4:
	/* 0x18e4: ldr w8, [x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18e8:
	/* 0x18e8: cmp w12, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_18ec:
	/* 0x18ec: b.ne 1900 <generic_kprobe_process_filter+0x1900> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x18ec, 0x1900, arm64_l_1900);
arm64_l_18f0:
	/* 0x18f0: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_18f4:
	/* 0x18f4: b.eq 1900 <generic_kprobe_process_filter+0x1900> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x18f4, 0x1900, arm64_l_1900);
arm64_l_18f8:
	/* 0x18f8: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_18fc:
	/* 0x18fc: b 1680 <generic_kprobe_process_filter+0x1680> */
	ARM64_SIM_A64_JMP(0x18fc, 0x1680, arm64_l_1680);
arm64_l_1900:
	/* 0x1900: cmp w12, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1904:
	/* 0x1904: ccmp x29, x8, #0x0, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_EQ, 0), 0);
arm64_l_1908:
	/* 0x1908: cset w9, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_190c:
	/* 0x190c: b 1680 <generic_kprobe_process_filter+0x1680> */
	ARM64_SIM_A64_JMP(0x190c, 0x1680, arm64_l_1680);
arm64_l_1910:
	/* 0x1910: ldr x8, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1914:
	/* 0x1914: ldr w9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1918:
	/* 0x1918: cbz w9, 1680 <generic_kprobe_process_filter+0x1680> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1918, 0x1680, arm64_l_1680);
arm64_l_191c:
	/* 0x191c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1920:
	/* 0x1920: cbz x29, 1674 <generic_kprobe_process_filter+0x1674> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x1920, 0x1674, arm64_l_1674);
arm64_l_1924:
	/* 0x1924: cmp x29, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1928:
	/* 0x1928: b.eq 1674 <generic_kprobe_process_filter+0x1674> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1928, 0x1674, arm64_l_1674);
arm64_l_192c:
	/* 0x192c: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1930:
	/* 0x1930: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1934:
	/* 0x1934: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1938:
	/* 0x1938: ldr x1, [sp, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_193c:
	/* 0x193c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1940ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1940:
	/* 0x1940: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1940, 0x1a68, arm64_l_1a68);
arm64_l_1944:
	/* 0x1944: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1948:
	/* 0x1948: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_194c:
	/* 0x194c: b.eq 1664 <generic_kprobe_process_filter+0x1664> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x194c, 0x1664, arm64_l_1664);
arm64_l_1950:
	/* 0x1950: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1954:
	/* 0x1954: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1958:
	/* 0x1958: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_195c:
	/* 0x195c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1960:
	/* 0x1960: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1964ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1964:
	/* 0x1964: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1964, 0x1a68, arm64_l_1a68);
arm64_l_1968:
	/* 0x1968: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_196c:
	/* 0x196c: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1970:
	/* 0x1970: b.eq 1664 <generic_kprobe_process_filter+0x1664> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1970, 0x1664, arm64_l_1664);
arm64_l_1974:
	/* 0x1974: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1978:
	/* 0x1978: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_197c:
	/* 0x197c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1980:
	/* 0x1980: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1984:
	/* 0x1984: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1988ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1988:
	/* 0x1988: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1988, 0x1a68, arm64_l_1a68);
arm64_l_198c:
	/* 0x198c: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1990:
	/* 0x1990: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1994:
	/* 0x1994: b.eq 1664 <generic_kprobe_process_filter+0x1664> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1994, 0x1664, arm64_l_1664);
arm64_l_1998:
	/* 0x1998: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_199c:
	/* 0x199c: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_19a0:
	/* 0x19a0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_19a4:
	/* 0x19a4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19a8:
	/* 0x19a8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x19acULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_19ac:
	/* 0x19ac: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x19ac, 0x1a68, arm64_l_1a68);
arm64_l_19b0:
	/* 0x19b0: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_19b4:
	/* 0x19b4: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19b8:
	/* 0x19b8: b.eq 1664 <generic_kprobe_process_filter+0x1664> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x19b8, 0x1664, arm64_l_1664);
arm64_l_19bc:
	/* 0x19bc: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_19c0:
	/* 0x19c0: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_19c4:
	/* 0x19c4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_19c8:
	/* 0x19c8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19cc:
	/* 0x19cc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x19d0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_19d0:
	/* 0x19d0: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x19d0, 0x1a68, arm64_l_1a68);
arm64_l_19d4:
	/* 0x19d4: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_19d8:
	/* 0x19d8: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19dc:
	/* 0x19dc: b.eq 1664 <generic_kprobe_process_filter+0x1664> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x19dc, 0x1664, arm64_l_1664);
arm64_l_19e0:
	/* 0x19e0: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_19e4:
	/* 0x19e4: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_19e8:
	/* 0x19e8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_19ec:
	/* 0x19ec: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19f0:
	/* 0x19f0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x19f4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_19f4:
	/* 0x19f4: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x19f4, 0x1a68, arm64_l_1a68);
arm64_l_19f8:
	/* 0x19f8: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_19fc:
	/* 0x19fc: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a00:
	/* 0x1a00: b.eq 1664 <generic_kprobe_process_filter+0x1664> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1a00, 0x1664, arm64_l_1664);
arm64_l_1a04:
	/* 0x1a04: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1a08:
	/* 0x1a08: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1a0c:
	/* 0x1a0c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1a10:
	/* 0x1a10: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a14:
	/* 0x1a14: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1a18ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1a18:
	/* 0x1a18: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1a18, 0x1a68, arm64_l_1a68);
arm64_l_1a1c:
	/* 0x1a1c: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1a20:
	/* 0x1a20: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a24:
	/* 0x1a24: b.eq 1664 <generic_kprobe_process_filter+0x1664> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1a24, 0x1664, arm64_l_1664);
arm64_l_1a28:
	/* 0x1a28: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1a2c:
	/* 0x1a2c: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1a30:
	/* 0x1a30: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1a34:
	/* 0x1a34: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a38:
	/* 0x1a38: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1a3cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1a3c:
	/* 0x1a3c: cbz x0, 1a68 <generic_kprobe_process_filter+0x1a68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1a3c, 0x1a68, arm64_l_1a68);
arm64_l_1a40:
	/* 0x1a40: ldr w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1a44:
	/* 0x1a44: cmp x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a48:
	/* 0x1a48: b.eq 1664 <generic_kprobe_process_filter+0x1664> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1a48, 0x1664, arm64_l_1664);
arm64_l_1a4c:
	/* 0x1a4c: adrp x9, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1a50:
	/* 0x1a50: add x1, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1a54:
	/* 0x1a54: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1a58:
	/* 0x1a58: ldr x9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a5c:
	/* 0x1a5c: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1a60:
	/* 0x1a60: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a64:
	/* 0x1a64: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1a68ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1a68:
	/* 0x1a68: ldr w12, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1a6c:
	/* 0x1a6c: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1a70:
	/* 0x1a70: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1a74:
	/* 0x1a74: mov x13, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a78:
	/* 0x1a78: mov x11, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a7c:
	/* 0x1a7c: cmp w12, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1a80:
	/* 0x1a80: b.ne 1674 <generic_kprobe_process_filter+0x1674> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1a80, 0x1674, arm64_l_1674);
arm64_l_1a84:
	/* 0x1a84: b 1680 <generic_kprobe_process_filter+0x1680> */
	ARM64_SIM_A64_JMP(0x1a84, 0x1680, arm64_l_1680);
arm64_l_1a88:
	/* 0x1a88: ldp w8, w9, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1a8c:
	/* 0x1a8c: ldp w10, w11, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1a90:
	/* 0x1a90: cmp w12, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1a94:
	/* 0x1a94: b.ne 1aa8 <generic_kprobe_process_filter+0x1aa8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1a94, 0x1aa8, arm64_l_1aa8);
arm64_l_1a98:
	/* 0x1a98: and w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1a9c:
	/* 0x1a9c: and w9, w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1aa0:
	/* 0x1aa0: and w9, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1aa4:
	/* 0x1aa4: b 1ab4 <generic_kprobe_process_filter+0x1ab4> */
	ARM64_SIM_A64_JMP(0x1aa4, 0x1ab4, arm64_l_1ab4);
arm64_l_1aa8:
	/* 0x1aa8: orr w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1aac:
	/* 0x1aac: orr w9, w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1ab0:
	/* 0x1ab0: orr w9, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1ab4:
	/* 0x1ab4: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1ab8:
	/* 0x1ab8: ldr x8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1abc:
	/* 0x1abc: cbz w9, 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1abc, 0x2194, arm64_l_2194);
arm64_l_1ac0:
	/* 0x1ac0: ldr x10, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1ac4:
	/* 0x1ac4: add w8, w8, #0x14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_1ac8:
	/* 0x1ac8: ldr w10, [x10, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1acc:
	/* 0x1acc: ubfiz w10, w10, #2, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_BITFIELD, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFIZ, 2, 3), 0);
arm64_l_1ad0:
	/* 0x1ad0: add w8, w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1ad4:
	/* 0x1ad4: and x10, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1ad8:
	/* 0x1ad8: add w8, w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1adc:
	/* 0x1adc: add x22, x29, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_1ae0:
	/* 0x1ae0: ldr w10, [x10, x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X23, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ae4:
	/* 0x1ae4: mov w19, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_1ae8:
	/* 0x1ae8: mov w14, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1aec:
	/* 0x1aec: sub w24, w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1af0:
	/* 0x1af0: b 1b08 <generic_kprobe_process_filter+0x1b08> */
	ARM64_SIM_A64_JMP(0x1af0, 0x1b08, arm64_l_1b08);
arm64_l_1af4:
	/* 0x1af4: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1af8:
	/* 0x1af8: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1afc:
	/* 0x1afc: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b00:
	/* 0x1b00: subs x19, x19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 1ULL);
arm64_l_1b04:
	/* 0x1b04: b.eq 1cec <generic_kprobe_process_filter+0x1cec> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1b04, 0x1cec, arm64_l_1cec);
arm64_l_1b08:
	/* 0x1b08: cbz w24, 1b00 <generic_kprobe_process_filter+0x1b00> */
	ARM64_SIM_A64_CBZ(ARM64_X24, 0x1b08, 0x1b00, arm64_l_1b00);
arm64_l_1b0c:
	/* 0x1b0c: and x9, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1b10:
	/* 0x1b10: mov x20, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b14:
	/* 0x1b14: add x10, x9, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1b18:
	/* 0x1b18: ldr w21, [x10, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1b1c:
	/* 0x1b1c: ldp w9, w29, [x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X9, ARM64_X29, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b20:
	/* 0x1b20: stp xzr, xzr, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1b24:
	/* 0x1b24: cmp w21, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1b28:
	/* 0x1b28: csel w10, w21, w14, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X10, ARM64_X21, ARM64_X14, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_1b2c:
	/* 0x1b2c: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1b30:
	/* 0x1b30: b.ne 1b3c <generic_kprobe_process_filter+0x1b3c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1b30, 0x1b3c, arm64_l_1b3c);
arm64_l_1b34:
	/* 0x1b34: mov x11, #0x100000001 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 4294967297ULL);
arm64_l_1b38:
	/* 0x1b38: stp x11, x11, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1b3c:
	/* 0x1b3c: add w25, w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1b40:
	/* 0x1b40: cbz w21, 1ca0 <generic_kprobe_process_filter+0x1ca0> */
	ARM64_SIM_A64_CBZ(ARM64_X21, 0x1b40, 0x1ca0, arm64_l_1ca0);
arm64_l_1b44:
	/* 0x1b44: and x9, x9, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_1b48:
	/* 0x1b48: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1b4c:
	/* 0x1b4c: b.cc 1b7c <generic_kprobe_process_filter+0x1b7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1b4c, 0x1b7c, arm64_l_1b7c);
arm64_l_1b50:
	/* 0x1b50: sub x8, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b54:
	/* 0x1b54: mov w9, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_1b58:
	/* 0x1b58: add x0, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1b5c:
	/* 0x1b5c: mov w1, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1b60:
	/* 0x1b60: cmp x8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1b64:
	/* 0x1b64: csel x8, x8, x9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_1b68:
	/* 0x1b68: lsl x8, x8, #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_1b6c:
	/* 0x1b6c: add x2, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1b70:
	/* 0x1b70: bl 0 <memset> */
	ARM64_SIM_A64_CALL(arm64_l_0, 0x1b74ULL);
arm64_l_1b74:
	/* 0x1b74: mov w14, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1b78:
	/* 0x1b78: b 1ca0 <generic_kprobe_process_filter+0x1ca0> */
	ARM64_SIM_A64_JMP(0x1b78, 0x1ca0, arm64_l_1ca0);
arm64_l_1b7c:
	/* 0x1b7c: cmp w25, #0x3e8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1000ULL);
arm64_l_1b80:
	/* 0x1b80: b.ls 1b8c <generic_kprobe_process_filter+0x1b8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1b80, 0x1b8c, arm64_l_1b8c);
arm64_l_1b84:
	/* 0x1b84: mov w11, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1b88:
	/* 0x1b88: b 1b94 <generic_kprobe_process_filter+0x1b94> */
	ARM64_SIM_A64_JMP(0x1b88, 0x1b94, arm64_l_1b94);
arm64_l_1b8c:
	/* 0x1b8c: and w11, w25, #0xfffffffc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967292ULL);
arm64_l_1b90:
	/* 0x1b90: ldr w11, [x23, w11, uxtw] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X23, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_UXTW, 0, 0), 0ULL);
arm64_l_1b94:
	/* 0x1b94: ldr w9, [x22, x9, lsl #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_LSL, 2, 0), 0ULL);
arm64_l_1b98:
	/* 0x1b98: cmp w29, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1b9c:
	/* 0x1b9c: sub x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1ba0:
	/* 0x1ba0: cset w12, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1ba4:
	/* 0x1ba4: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1ba8:
	/* 0x1ba8: cset w13, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1bac:
	/* 0x1bac: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1bb0:
	/* 0x1bb0: csinc w11, w12, wzr, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X11, ARM64_X12, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1bb4:
	/* 0x1bb4: csinc w12, w13, wzr, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X12, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1bb8:
	/* 0x1bb8: and w11, w11, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X11, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1bbc:
	/* 0x1bbc: str w11, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1bc0:
	/* 0x1bc0: cbz x10, 1ca0 <generic_kprobe_process_filter+0x1ca0> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x1bc0, 0x1ca0, arm64_l_1ca0);
arm64_l_1bc4:
	/* 0x1bc4: add w11, w8, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1bc8:
	/* 0x1bc8: cmp w11, #0x3e8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1000ULL);
arm64_l_1bcc:
	/* 0x1bcc: b.ls 1bd8 <generic_kprobe_process_filter+0x1bd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1bcc, 0x1bd8, arm64_l_1bd8);
arm64_l_1bd0:
	/* 0x1bd0: mov w11, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1bd4:
	/* 0x1bd4: b 1be0 <generic_kprobe_process_filter+0x1be0> */
	ARM64_SIM_A64_JMP(0x1bd4, 0x1be0, arm64_l_1be0);
arm64_l_1bd8:
	/* 0x1bd8: and w11, w11, #0xfffffffc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967292ULL);
arm64_l_1bdc:
	/* 0x1bdc: ldr w11, [x23, w11, uxtw] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X23, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_UXTW, 0, 0), 0ULL);
arm64_l_1be0:
	/* 0x1be0: cmp w29, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1be4:
	/* 0x1be4: cset w12, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1be8:
	/* 0x1be8: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1bec:
	/* 0x1bec: cset w13, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1bf0:
	/* 0x1bf0: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1bf4:
	/* 0x1bf4: csinc w11, w12, wzr, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X11, ARM64_X12, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1bf8:
	/* 0x1bf8: csinc w12, w13, wzr, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X12, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1bfc:
	/* 0x1bfc: cmp x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1c00:
	/* 0x1c00: and w11, w11, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X11, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1c04:
	/* 0x1c04: str w11, [sp, #92] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_1c08:
	/* 0x1c08: b.eq 1ca0 <generic_kprobe_process_filter+0x1ca0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c08, 0x1ca0, arm64_l_1ca0);
arm64_l_1c0c:
	/* 0x1c0c: add w11, w8, #0x14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_1c10:
	/* 0x1c10: cmp w11, #0x3e8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1000ULL);
arm64_l_1c14:
	/* 0x1c14: b.ls 1c20 <generic_kprobe_process_filter+0x1c20> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1c14, 0x1c20, arm64_l_1c20);
arm64_l_1c18:
	/* 0x1c18: mov w11, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1c1c:
	/* 0x1c1c: b 1c28 <generic_kprobe_process_filter+0x1c28> */
	ARM64_SIM_A64_JMP(0x1c1c, 0x1c28, arm64_l_1c28);
arm64_l_1c20:
	/* 0x1c20: and w11, w11, #0xfffffffc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967292ULL);
arm64_l_1c24:
	/* 0x1c24: ldr w11, [x23, w11, uxtw] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X23, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_UXTW, 0, 0), 0ULL);
arm64_l_1c28:
	/* 0x1c28: cmp w29, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1c2c:
	/* 0x1c2c: cset w12, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1c30:
	/* 0x1c30: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1c34:
	/* 0x1c34: cset w13, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1c38:
	/* 0x1c38: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c3c:
	/* 0x1c3c: csinc w11, w12, wzr, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X11, ARM64_X12, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1c40:
	/* 0x1c40: csinc w12, w13, wzr, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X12, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1c44:
	/* 0x1c44: cmp x10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1c48:
	/* 0x1c48: and w11, w11, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X11, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1c4c:
	/* 0x1c4c: str w11, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1c50:
	/* 0x1c50: b.eq 1ca0 <generic_kprobe_process_filter+0x1ca0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c50, 0x1ca0, arm64_l_1ca0);
arm64_l_1c54:
	/* 0x1c54: add w8, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1c58:
	/* 0x1c58: cmp w8, #0x3e8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1000ULL);
arm64_l_1c5c:
	/* 0x1c5c: b.ls 1c68 <generic_kprobe_process_filter+0x1c68> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1c5c, 0x1c68, arm64_l_1c68);
arm64_l_1c60:
	/* 0x1c60: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1c64:
	/* 0x1c64: b 1c70 <generic_kprobe_process_filter+0x1c70> */
	ARM64_SIM_A64_JMP(0x1c64, 0x1c70, arm64_l_1c70);
arm64_l_1c68:
	/* 0x1c68: and w8, w8, #0xfffffffc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967292ULL);
arm64_l_1c6c:
	/* 0x1c6c: ldr w8, [x23, w8, uxtw] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_UXTW, 0, 0), 0ULL);
arm64_l_1c70:
	/* 0x1c70: cmp w29, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1c74:
	/* 0x1c74: cset w10, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1c78:
	/* 0x1c78: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1c7c:
	/* 0x1c7c: cset w11, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1c80:
	/* 0x1c80: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c84:
	/* 0x1c84: csinc w8, w10, wzr, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X8, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1c88:
	/* 0x1c88: csinc w9, w11, wzr, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1c8c:
	/* 0x1c8c: and w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1c90:
	/* 0x1c90: str w8, [sp, #100] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 100ULL);
arm64_l_1c94:
	/* 0x1c94: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c98:
	/* 0x1c98: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c9c:
	/* 0x1c9c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1ca0:
	/* 0x1ca0: ldp w8, w9, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1ca4:
	/* 0x1ca4: ldp w10, w11, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1ca8:
	/* 0x1ca8: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1cac:
	/* 0x1cac: b.ne 1cc0 <generic_kprobe_process_filter+0x1cc0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1cac, 0x1cc0, arm64_l_1cc0);
arm64_l_1cb0:
	/* 0x1cb0: and w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1cb4:
	/* 0x1cb4: and w9, w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1cb8:
	/* 0x1cb8: and w9, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1cbc:
	/* 0x1cbc: b 1ccc <generic_kprobe_process_filter+0x1ccc> */
	ARM64_SIM_A64_JMP(0x1cbc, 0x1ccc, arm64_l_1ccc);
arm64_l_1cc0:
	/* 0x1cc0: orr w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1cc4:
	/* 0x1cc4: orr w9, w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1cc8:
	/* 0x1cc8: orr w9, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1ccc:
	/* 0x1ccc: mov x29, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1cd0:
	/* 0x1cd0: cbz w9, 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1cd0, 0x2194, arm64_l_2194);
arm64_l_1cd4:
	/* 0x1cd4: lsl w8, w21, #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_1cd8:
	/* 0x1cd8: sub w10, w24, w21, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X24, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_LSL, 2), 0);
arm64_l_1cdc:
	/* 0x1cdc: and w8, w8, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_1ce0:
	/* 0x1ce0: sub w24, w10, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1ce4:
	/* 0x1ce4: add w8, w8, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1ce8:
	/* 0x1ce8: b 1b00 <generic_kprobe_process_filter+0x1b00> */
	ARM64_SIM_A64_JMP(0x1ce8, 0x1b00, arm64_l_1b00);
arm64_l_1cec:
	/* 0x1cec: mov w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1cf0:
	/* 0x1cf0: add w19, w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1cf4:
	/* 0x1cf4: and x10, x10, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1cf8:
	/* 0x1cf8: ldr w10, [x10, x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X23, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1cfc:
	/* 0x1cfc: cmp w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1d00:
	/* 0x1d00: b.ne 1d90 <generic_kprobe_process_filter+0x1d90> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1d00, 0x1d90, arm64_l_1d90);
arm64_l_1d04:
	/* 0x1d04: cbz w9, 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1d04, 0x2194, arm64_l_2194);
arm64_l_1d08:
	/* 0x1d08: mov w8, w19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1d0c:
	/* 0x1d0c: and x8, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1d10:
	/* 0x1d10: ldr w9, [x8, x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X23, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1d14:
	/* 0x1d14: add w8, w19, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1d18:
	/* 0x1d18: cmp w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1d1c:
	/* 0x1d1c: mov w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1d20:
	/* 0x1d20: b.eq 20a4 <generic_kprobe_process_filter+0x20a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d20, 0x20a4, arm64_l_20a4);
arm64_l_1d24:
	/* 0x1d24: and x8, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1d28:
	/* 0x1d28: add x8, x8, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1d2c:
	/* 0x1d2c: ldp w20, w24, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1d30:
	/* 0x1d30: mov w8, #0xe */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_1d34:
	/* 0x1d34: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x1d38ULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1d38:
	/* 0x1d38: lsr x8, x0, #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 32ULL);
arm64_l_1d3c:
	/* 0x1d3c: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_1d40:
	/* 0x1d40: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1d44:
	/* 0x1d44: str w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_1d48:
	/* 0x1d48: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1d4c:
	/* 0x1d4c: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1d50:
	/* 0x1d50: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1d54:
	/* 0x1d54: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1d58ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1d58:
	/* 0x1d58: cbz x0, 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1d58, 0x2194, arm64_l_2194);
arm64_l_1d5c:
	/* 0x1d5c: cmp w20, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1d60:
	/* 0x1d60: b.eq 1e04 <generic_kprobe_process_filter+0x1e04> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d60, 0x1e04, arm64_l_1e04);
arm64_l_1d64:
	/* 0x1d64: cmp w20, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1d68:
	/* 0x1d68: b.ne 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1d68, 0x2194, arm64_l_2194);
arm64_l_1d6c:
	/* 0x1d6c: mov w8, #0x5ee8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24296ULL);
arm64_l_1d70:
	/* 0x1d70: add x8, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1d74:
	/* 0x1d74: tbnz w24, #0, 1e30 <generic_kprobe_process_filter+0x1e30> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 0, 0x1d74, 0x1e30, arm64_l_1e30);
arm64_l_1d78:
	/* 0x1d78: ldr w9, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1d7c:
	/* 0x1d7c: cbz w9, 1e28 <generic_kprobe_process_filter+0x1e28> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1d7c, 0x1e28, arm64_l_1e28);
arm64_l_1d80:
	/* 0x1d80: ldr w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1d84:
	/* 0x1d84: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d88:
	/* 0x1d88: b.eq 1e30 <generic_kprobe_process_filter+0x1e30> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d88, 0x1e30, arm64_l_1e30);
arm64_l_1d8c:
	/* 0x1d8c: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x1d8c, 0x2098, arm64_l_2098);
arm64_l_1d90:
	/* 0x1d90: and x9, x19, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1d94:
	/* 0x1d94: add w19, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1d98:
	/* 0x1d98: add x9, x9, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1d9c:
	/* 0x1d9c: ldp w8, w10, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1da0:
	/* 0x1da0: ldr w12, [x9, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1da4:
	/* 0x1da4: ldur x11, [x9, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1da8:
	/* 0x1da8: cbz w12, 1dc8 <generic_kprobe_process_filter+0x1dc8> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0x1da8, 0x1dc8, arm64_l_1dc8);
arm64_l_1dac:
	/* 0x1dac: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1db0:
	/* 0x1db0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1db4:
	/* 0x1db4: b.hi 1d04 <generic_kprobe_process_filter+0x1d04> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1db4, 0x1d04, arm64_l_1d04);
arm64_l_1db8:
	/* 0x1db8: ldr w13, [x29, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_1dbc:
	/* 0x1dbc: cmp w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1dc0:
	/* 0x1dc0: b.ne 1dd8 <generic_kprobe_process_filter+0x1dd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1dc0, 0x1dd8, arm64_l_1dd8);
arm64_l_1dc4:
	/* 0x1dc4: b 1d04 <generic_kprobe_process_filter+0x1d04> */
	ARM64_SIM_A64_JMP(0x1dc4, 0x1d04, arm64_l_1d04);
arm64_l_1dc8:
	/* 0x1dc8: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1dcc:
	/* 0x1dcc: b.ls 1dd8 <generic_kprobe_process_filter+0x1dd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1dcc, 0x1dd8, arm64_l_1dd8);
arm64_l_1dd0:
	/* 0x1dd0: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1dd4:
	/* 0x1dd4: b 1d04 <generic_kprobe_process_filter+0x1d04> */
	ARM64_SIM_A64_JMP(0x1dd4, 0x1d04, arm64_l_1d04);
arm64_l_1dd8:
	/* 0x1dd8: add x9, x29, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1ddc:
	/* 0x1ddc: cmp w10, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1de0:
	/* 0x1de0: ldr x8, [x9, x8, lsl #3] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_LSL, 3, 0), 0ULL);
arm64_l_1de4:
	/* 0x1de4: and x8, x8, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1de8:
	/* 0x1de8: b.ne 1df8 <generic_kprobe_process_filter+0x1df8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1de8, 0x1df8, arm64_l_1df8);
arm64_l_1dec:
	/* 0x1dec: cmp x8, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1df0:
	/* 0x1df0: cset w9, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1df4:
	/* 0x1df4: b 1d04 <generic_kprobe_process_filter+0x1d04> */
	ARM64_SIM_A64_JMP(0x1df4, 0x1d04, arm64_l_1d04);
arm64_l_1df8:
	/* 0x1df8: cmp x8, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1dfc:
	/* 0x1dfc: cset w9, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1e00:
	/* 0x1e00: b 1d04 <generic_kprobe_process_filter+0x1d04> */
	ARM64_SIM_A64_JMP(0x1e00, 0x1d04, arm64_l_1d04);
arm64_l_1e04:
	/* 0x1e04: mov w8, #0x5ee8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24296ULL);
arm64_l_1e08:
	/* 0x1e08: add x8, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1e0c:
	/* 0x1e0c: tbz w24, #0, 1e54 <generic_kprobe_process_filter+0x1e54> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 0, 0x1e0c, 0x1e54, arm64_l_1e54);
arm64_l_1e10:
	/* 0x1e10: ldr w9, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1e14:
	/* 0x1e14: cbz w9, 1e4c <generic_kprobe_process_filter+0x1e4c> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1e14, 0x1e4c, arm64_l_1e4c);
arm64_l_1e18:
	/* 0x1e18: ldr w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e1c:
	/* 0x1e1c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e20:
	/* 0x1e20: b.eq 1e54 <generic_kprobe_process_filter+0x1e54> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e20, 0x1e54, arm64_l_1e54);
arm64_l_1e24:
	/* 0x1e24: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x1e24, 0x2098, arm64_l_2098);
arm64_l_1e28:
	/* 0x1e28: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e2c:
	/* 0x1e2c: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e30:
	/* 0x1e30: tbnz w24, #1, 1e78 <generic_kprobe_process_filter+0x1e78> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 1, 0x1e30, 0x1e78, arm64_l_1e78);
arm64_l_1e34:
	/* 0x1e34: ldr w9, [x0, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_1e38:
	/* 0x1e38: cbz w9, 1e70 <generic_kprobe_process_filter+0x1e70> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1e38, 0x1e70, arm64_l_1e70);
arm64_l_1e3c:
	/* 0x1e3c: ldr w10, [x29, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1e40:
	/* 0x1e40: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e44:
	/* 0x1e44: b.eq 1e78 <generic_kprobe_process_filter+0x1e78> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e44, 0x1e78, arm64_l_1e78);
arm64_l_1e48:
	/* 0x1e48: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x1e48, 0x2098, arm64_l_2098);
arm64_l_1e4c:
	/* 0x1e4c: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e50:
	/* 0x1e50: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e54:
	/* 0x1e54: tbz w24, #1, 1e9c <generic_kprobe_process_filter+0x1e9c> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 1, 0x1e54, 0x1e9c, arm64_l_1e9c);
arm64_l_1e58:
	/* 0x1e58: ldr w9, [x0, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_1e5c:
	/* 0x1e5c: cbz w9, 1e94 <generic_kprobe_process_filter+0x1e94> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1e5c, 0x1e94, arm64_l_1e94);
arm64_l_1e60:
	/* 0x1e60: ldr w10, [x29, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1e64:
	/* 0x1e64: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e68:
	/* 0x1e68: b.eq 1e9c <generic_kprobe_process_filter+0x1e9c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e68, 0x1e9c, arm64_l_1e9c);
arm64_l_1e6c:
	/* 0x1e6c: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x1e6c, 0x2098, arm64_l_2098);
arm64_l_1e70:
	/* 0x1e70: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e74:
	/* 0x1e74: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e78:
	/* 0x1e78: tbnz w24, #2, 1ec0 <generic_kprobe_process_filter+0x1ec0> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 2, 0x1e78, 0x1ec0, arm64_l_1ec0);
arm64_l_1e7c:
	/* 0x1e7c: ldr w9, [x0, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1e80:
	/* 0x1e80: cbz w9, 1eb8 <generic_kprobe_process_filter+0x1eb8> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1e80, 0x1eb8, arm64_l_1eb8);
arm64_l_1e84:
	/* 0x1e84: ldr w10, [x29, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1e88:
	/* 0x1e88: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e8c:
	/* 0x1e8c: b.eq 1ec0 <generic_kprobe_process_filter+0x1ec0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e8c, 0x1ec0, arm64_l_1ec0);
arm64_l_1e90:
	/* 0x1e90: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x1e90, 0x2098, arm64_l_2098);
arm64_l_1e94:
	/* 0x1e94: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e98:
	/* 0x1e98: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e9c:
	/* 0x1e9c: tbz w24, #2, 1ee4 <generic_kprobe_process_filter+0x1ee4> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 2, 0x1e9c, 0x1ee4, arm64_l_1ee4);
arm64_l_1ea0:
	/* 0x1ea0: ldr w9, [x0, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1ea4:
	/* 0x1ea4: cbz w9, 1edc <generic_kprobe_process_filter+0x1edc> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1ea4, 0x1edc, arm64_l_1edc);
arm64_l_1ea8:
	/* 0x1ea8: ldr w10, [x29, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1eac:
	/* 0x1eac: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1eb0:
	/* 0x1eb0: b.eq 1ee4 <generic_kprobe_process_filter+0x1ee4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1eb0, 0x1ee4, arm64_l_1ee4);
arm64_l_1eb4:
	/* 0x1eb4: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x1eb4, 0x2098, arm64_l_2098);
arm64_l_1eb8:
	/* 0x1eb8: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ebc:
	/* 0x1ebc: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ec0:
	/* 0x1ec0: tbnz w24, #3, 1f08 <generic_kprobe_process_filter+0x1f08> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 3, 0x1ec0, 0x1f08, arm64_l_1f08);
arm64_l_1ec4:
	/* 0x1ec4: ldr w9, [x0, #52] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 52ULL);
arm64_l_1ec8:
	/* 0x1ec8: cbz w9, 1f00 <generic_kprobe_process_filter+0x1f00> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1ec8, 0x1f00, arm64_l_1f00);
arm64_l_1ecc:
	/* 0x1ecc: ldr w10, [x29, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_1ed0:
	/* 0x1ed0: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ed4:
	/* 0x1ed4: b.eq 1f08 <generic_kprobe_process_filter+0x1f08> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ed4, 0x1f08, arm64_l_1f08);
arm64_l_1ed8:
	/* 0x1ed8: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x1ed8, 0x2098, arm64_l_2098);
arm64_l_1edc:
	/* 0x1edc: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ee0:
	/* 0x1ee0: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ee4:
	/* 0x1ee4: tbz w24, #3, 1f2c <generic_kprobe_process_filter+0x1f2c> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 3, 0x1ee4, 0x1f2c, arm64_l_1f2c);
arm64_l_1ee8:
	/* 0x1ee8: ldr w9, [x0, #52] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 52ULL);
arm64_l_1eec:
	/* 0x1eec: cbz w9, 1f24 <generic_kprobe_process_filter+0x1f24> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1eec, 0x1f24, arm64_l_1f24);
arm64_l_1ef0:
	/* 0x1ef0: ldr w10, [x29, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_1ef4:
	/* 0x1ef4: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ef8:
	/* 0x1ef8: b.eq 1f2c <generic_kprobe_process_filter+0x1f2c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ef8, 0x1f2c, arm64_l_1f2c);
arm64_l_1efc:
	/* 0x1efc: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x1efc, 0x2098, arm64_l_2098);
arm64_l_1f00:
	/* 0x1f00: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f04:
	/* 0x1f04: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f08:
	/* 0x1f08: tbnz w24, #4, 1f50 <generic_kprobe_process_filter+0x1f50> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 4, 0x1f08, 0x1f50, arm64_l_1f50);
arm64_l_1f0c:
	/* 0x1f0c: ldr w9, [x0, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1f10:
	/* 0x1f10: cbz w9, 1f48 <generic_kprobe_process_filter+0x1f48> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1f10, 0x1f48, arm64_l_1f48);
arm64_l_1f14:
	/* 0x1f14: ldr w10, [x29, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1f18:
	/* 0x1f18: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f1c:
	/* 0x1f1c: b.eq 1f50 <generic_kprobe_process_filter+0x1f50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f1c, 0x1f50, arm64_l_1f50);
arm64_l_1f20:
	/* 0x1f20: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x1f20, 0x2098, arm64_l_2098);
arm64_l_1f24:
	/* 0x1f24: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f28:
	/* 0x1f28: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f2c:
	/* 0x1f2c: tbz w24, #4, 1f74 <generic_kprobe_process_filter+0x1f74> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 4, 0x1f2c, 0x1f74, arm64_l_1f74);
arm64_l_1f30:
	/* 0x1f30: ldr w9, [x0, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1f34:
	/* 0x1f34: cbz w9, 1f6c <generic_kprobe_process_filter+0x1f6c> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1f34, 0x1f6c, arm64_l_1f6c);
arm64_l_1f38:
	/* 0x1f38: ldr w10, [x29, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1f3c:
	/* 0x1f3c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f40:
	/* 0x1f40: b.eq 1f74 <generic_kprobe_process_filter+0x1f74> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f40, 0x1f74, arm64_l_1f74);
arm64_l_1f44:
	/* 0x1f44: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x1f44, 0x2098, arm64_l_2098);
arm64_l_1f48:
	/* 0x1f48: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f4c:
	/* 0x1f4c: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f50:
	/* 0x1f50: tbnz w24, #5, 1f98 <generic_kprobe_process_filter+0x1f98> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 5, 0x1f50, 0x1f98, arm64_l_1f98);
arm64_l_1f54:
	/* 0x1f54: ldr w9, [x0, #60] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 60ULL);
arm64_l_1f58:
	/* 0x1f58: cbz w9, 1f90 <generic_kprobe_process_filter+0x1f90> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1f58, 0x1f90, arm64_l_1f90);
arm64_l_1f5c:
	/* 0x1f5c: ldr w10, [x29, #52] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 52ULL);
arm64_l_1f60:
	/* 0x1f60: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f64:
	/* 0x1f64: b.eq 1f98 <generic_kprobe_process_filter+0x1f98> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f64, 0x1f98, arm64_l_1f98);
arm64_l_1f68:
	/* 0x1f68: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x1f68, 0x2098, arm64_l_2098);
arm64_l_1f6c:
	/* 0x1f6c: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f70:
	/* 0x1f70: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f74:
	/* 0x1f74: tbz w24, #5, 1fbc <generic_kprobe_process_filter+0x1fbc> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 5, 0x1f74, 0x1fbc, arm64_l_1fbc);
arm64_l_1f78:
	/* 0x1f78: ldr w9, [x0, #60] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 60ULL);
arm64_l_1f7c:
	/* 0x1f7c: cbz w9, 1fb4 <generic_kprobe_process_filter+0x1fb4> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1f7c, 0x1fb4, arm64_l_1fb4);
arm64_l_1f80:
	/* 0x1f80: ldr w10, [x29, #52] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 52ULL);
arm64_l_1f84:
	/* 0x1f84: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f88:
	/* 0x1f88: b.eq 1fbc <generic_kprobe_process_filter+0x1fbc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f88, 0x1fbc, arm64_l_1fbc);
arm64_l_1f8c:
	/* 0x1f8c: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x1f8c, 0x2098, arm64_l_2098);
arm64_l_1f90:
	/* 0x1f90: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f94:
	/* 0x1f94: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f98:
	/* 0x1f98: tbnz w24, #6, 1fe0 <generic_kprobe_process_filter+0x1fe0> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 6, 0x1f98, 0x1fe0, arm64_l_1fe0);
arm64_l_1f9c:
	/* 0x1f9c: ldr w9, [x0, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1fa0:
	/* 0x1fa0: cbz w9, 1fd8 <generic_kprobe_process_filter+0x1fd8> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1fa0, 0x1fd8, arm64_l_1fd8);
arm64_l_1fa4:
	/* 0x1fa4: ldr w10, [x29, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1fa8:
	/* 0x1fa8: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fac:
	/* 0x1fac: b.eq 1fe0 <generic_kprobe_process_filter+0x1fe0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1fac, 0x1fe0, arm64_l_1fe0);
arm64_l_1fb0:
	/* 0x1fb0: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x1fb0, 0x2098, arm64_l_2098);
arm64_l_1fb4:
	/* 0x1fb4: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1fb8:
	/* 0x1fb8: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1fbc:
	/* 0x1fbc: tbz w24, #6, 2004 <generic_kprobe_process_filter+0x2004> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 6, 0x1fbc, 0x2004, arm64_l_2004);
arm64_l_1fc0:
	/* 0x1fc0: ldr w9, [x0, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1fc4:
	/* 0x1fc4: cbz w9, 1ffc <generic_kprobe_process_filter+0x1ffc> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1fc4, 0x1ffc, arm64_l_1ffc);
arm64_l_1fc8:
	/* 0x1fc8: ldr w10, [x29, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1fcc:
	/* 0x1fcc: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fd0:
	/* 0x1fd0: b.eq 2004 <generic_kprobe_process_filter+0x2004> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1fd0, 0x2004, arm64_l_2004);
arm64_l_1fd4:
	/* 0x1fd4: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x1fd4, 0x2098, arm64_l_2098);
arm64_l_1fd8:
	/* 0x1fd8: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1fdc:
	/* 0x1fdc: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1fe0:
	/* 0x1fe0: tbnz w24, #7, 2028 <generic_kprobe_process_filter+0x2028> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 7, 0x1fe0, 0x2028, arm64_l_2028);
arm64_l_1fe4:
	/* 0x1fe4: ldr w9, [x0, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_1fe8:
	/* 0x1fe8: cbz w9, 2020 <generic_kprobe_process_filter+0x2020> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1fe8, 0x2020, arm64_l_2020);
arm64_l_1fec:
	/* 0x1fec: ldr w10, [x29, #60] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 60ULL);
arm64_l_1ff0:
	/* 0x1ff0: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ff4:
	/* 0x1ff4: b.eq 2028 <generic_kprobe_process_filter+0x2028> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ff4, 0x2028, arm64_l_2028);
arm64_l_1ff8:
	/* 0x1ff8: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x1ff8, 0x2098, arm64_l_2098);
arm64_l_1ffc:
	/* 0x1ffc: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2000:
	/* 0x2000: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2004:
	/* 0x2004: tbz w24, #7, 204c <generic_kprobe_process_filter+0x204c> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 7, 0x2004, 0x204c, arm64_l_204c);
arm64_l_2008:
	/* 0x2008: ldr w9, [x0, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_200c:
	/* 0x200c: cbz w9, 2044 <generic_kprobe_process_filter+0x2044> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x200c, 0x2044, arm64_l_2044);
arm64_l_2010:
	/* 0x2010: ldr w10, [x29, #60] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 60ULL);
arm64_l_2014:
	/* 0x2014: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2018:
	/* 0x2018: b.eq 204c <generic_kprobe_process_filter+0x204c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2018, 0x204c, arm64_l_204c);
arm64_l_201c:
	/* 0x201c: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x201c, 0x2098, arm64_l_2098);
arm64_l_2020:
	/* 0x2020: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2024:
	/* 0x2024: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2028:
	/* 0x2028: tbnz w24, #8, 2070 <generic_kprobe_process_filter+0x2070> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 8, 0x2028, 0x2070, arm64_l_2070);
arm64_l_202c:
	/* 0x202c: ldr w9, [x0, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2030:
	/* 0x2030: cbz w9, 2068 <generic_kprobe_process_filter+0x2068> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x2030, 0x2068, arm64_l_2068);
arm64_l_2034:
	/* 0x2034: ldr w10, [x29, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_2038:
	/* 0x2038: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_203c:
	/* 0x203c: b.eq 2070 <generic_kprobe_process_filter+0x2070> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x203c, 0x2070, arm64_l_2070);
arm64_l_2040:
	/* 0x2040: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x2040, 0x2098, arm64_l_2098);
arm64_l_2044:
	/* 0x2044: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2048:
	/* 0x2048: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_204c:
	/* 0x204c: tbz w24, #8, 2080 <generic_kprobe_process_filter+0x2080> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 8, 0x204c, 0x2080, arm64_l_2080);
arm64_l_2050:
	/* 0x2050: ldr w9, [x0, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2054:
	/* 0x2054: cbz w9, 2078 <generic_kprobe_process_filter+0x2078> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x2054, 0x2078, arm64_l_2078);
arm64_l_2058:
	/* 0x2058: ldr w10, [x29, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_205c:
	/* 0x205c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2060:
	/* 0x2060: b.eq 2080 <generic_kprobe_process_filter+0x2080> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2060, 0x2080, arm64_l_2080);
arm64_l_2064:
	/* 0x2064: b 2098 <generic_kprobe_process_filter+0x2098> */
	ARM64_SIM_A64_JMP(0x2064, 0x2098, arm64_l_2098);
arm64_l_2068:
	/* 0x2068: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_206c:
	/* 0x206c: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2070:
	/* 0x2070: tbz w24, #9, 2084 <generic_kprobe_process_filter+0x2084> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 9, 0x2070, 0x2084, arm64_l_2084);
arm64_l_2074:
	/* 0x2074: b 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_JMP(0x2074, 0x2194, arm64_l_2194);
arm64_l_2078:
	/* 0x2078: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_207c:
	/* 0x207c: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2080:
	/* 0x2080: tbz w24, #9, 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 9, 0x2080, 0x2194, arm64_l_2194);
arm64_l_2084:
	/* 0x2084: ldr w9, [x0, #76] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_2088:
	/* 0x2088: cbz w9, 218c <generic_kprobe_process_filter+0x218c> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x2088, 0x218c, arm64_l_218c);
arm64_l_208c:
	/* 0x208c: ldr w10, [x29, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_2090:
	/* 0x2090: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2094:
	/* 0x2094: b.eq 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2094, 0x2194, arm64_l_2194);
arm64_l_2098:
	/* 0x2098: add w9, w19, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_209c:
	/* 0x209c: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_20a0:
	/* 0x20a0: str x10, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_20a4:
	/* 0x20a4: and x8, x9, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_20a8:
	/* 0x20a8: ldr w8, [x8, x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X23, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_20ac:
	/* 0x20ac: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_20b0:
	/* 0x20b0: b.ne 20e0 <generic_kprobe_process_filter+0x20e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x20b0, 0x20e0, arm64_l_20e0);
arm64_l_20b4:
	/* 0x20b4: ldr x9, [x29, #24248] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24248ULL);
arm64_l_20b8:
	/* 0x20b8: mov w8, #0x5eb8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24248ULL);
arm64_l_20bc:
	/* 0x20bc: add x8, x29, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_20c0:
	/* 0x20c0: and x9, x9, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_20c4:
	/* 0x20c4: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_20c8:
	/* 0x20c8: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_20cc:
	/* 0x20cc: strb w9, [x8, #9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 9ULL);
arm64_l_20d0:
	/* 0x20d0: ldr x8, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_20d4:
	/* 0x20d4: strb w9, [x8, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_20d8:
	/* 0x20d8: strb w9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_20dc:
	/* 0x20dc: b 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_JMP(0x20dc, 0x2194, arm64_l_2194);
arm64_l_20e0:
	/* 0x20e0: add w8, w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_20e4:
	/* 0x20e4: and x8, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_20e8:
	/* 0x20e8: add x8, x8, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_20ec:
	/* 0x20ec: ldp w21, w19, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X21, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_20f0:
	/* 0x20f0: ldr w22, [x8, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_20f4:
	/* 0x20f4: ldur x20, [x8, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_20f8:
	/* 0x20f8: mov w8, #0xe */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_20fc:
	/* 0x20fc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x2100ULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2100:
	/* 0x2100: lsr x8, x0, #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 32ULL);
arm64_l_2104:
	/* 0x2104: adrp x0, 0 <execve_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_2108:
	/* 0x2108: add x9, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_210c:
	/* 0x210c: str w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_2110:
	/* 0x2110: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2114:
	/* 0x2114: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_2118:
	/* 0x2118: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_211c:
	/* 0x211c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2120ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2120:
	/* 0x2120: cbz x0, 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2120, 0x2194, arm64_l_2194);
arm64_l_2124:
	/* 0x2124: cmp w21, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2128:
	/* 0x2128: cbz w22, 2140 <generic_kprobe_process_filter+0x2140> */
	ARM64_SIM_A64_CBZ(ARM64_X22, 0x2128, 0x2140, arm64_l_2140);
arm64_l_212c:
	/* 0x212c: b.hi 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x212c, 0x2194, arm64_l_2194);
arm64_l_2130:
	/* 0x2130: ldr w8, [x29, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_2134:
	/* 0x2134: cmp w8, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2138:
	/* 0x2138: b.ne 2144 <generic_kprobe_process_filter+0x2144> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2138, 0x2144, arm64_l_2144);
arm64_l_213c:
	/* 0x213c: b 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_JMP(0x213c, 0x2194, arm64_l_2194);
arm64_l_2140:
	/* 0x2140: b.hi 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2140, 0x2194, arm64_l_2194);
arm64_l_2144:
	/* 0x2144: add x9, x29, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2148:
	/* 0x2148: add x8, x0, x21, lsl #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 3), 0);
arm64_l_214c:
	/* 0x214c: lsl x10, x21, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_2150:
	/* 0x2150: ldr x8, [x8, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_2154:
	/* 0x2154: ldr x9, [x9, x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_X10, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2158:
	/* 0x2158: eor x10, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_215c:
	/* 0x215c: tst x10, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2160:
	/* 0x2160: b.eq 2170 <generic_kprobe_process_filter+0x2170> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2160, 0x2170, arm64_l_2170);
arm64_l_2164:
	/* 0x2164: cmp w19, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2168:
	/* 0x2168: b.eq 2180 <generic_kprobe_process_filter+0x2180> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2168, 0x2180, arm64_l_2180);
arm64_l_216c:
	/* 0x216c: b 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_JMP(0x216c, 0x2194, arm64_l_2194);
arm64_l_2170:
	/* 0x2170: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2174:
	/* 0x2174: b.eq 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2174, 0x2194, arm64_l_2194);
arm64_l_2178:
	/* 0x2178: cmp w19, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_217c:
	/* 0x217c: b.ne 2194 <generic_kprobe_process_filter+0x2194> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x217c, 0x2194, arm64_l_2194);
arm64_l_2180:
	/* 0x2180: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2184:
	/* 0x2184: str x8, [x29, #24304] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24304ULL);
arm64_l_2188:
	/* 0x2188: b 20b4 <generic_kprobe_process_filter+0x20b4> */
	ARM64_SIM_A64_JMP(0x2188, 0x20b4, arm64_l_20b4);
arm64_l_218c:
	/* 0x218c: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2190:
	/* 0x2190: str x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2194:
	/* 0x2194: ldr x8, [x29, #24248] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24248ULL);
arm64_l_2198:
	/* 0x2198: ldr x9, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_219c:
	/* 0x219c: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_21a0:
	/* 0x21a0: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_21a4:
	/* 0x21a4: str x8, [x29, #24248] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24248ULL);
arm64_l_21a8:
	/* 0x21a8: b.ls 220c <generic_kprobe_process_filter+0x220c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x21a8, 0x220c, arm64_l_220c);
arm64_l_21ac:
	/* 0x21ac: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_21b0:
	/* 0x21b0: ldr x20, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_21b4:
	/* 0x21b4: ldr w8, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_21b8:
	/* 0x21b8: str w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_21bc:
	/* 0x21bc: ldr x8, [x9, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_21c0:
	/* 0x21c0: str x8, [x29, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_21c4:
	/* 0x21c4: ldr x8, [sp, #232] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_21c8:
	/* 0x21c8: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_21cc:
	/* 0x21cc: cbz w8, 21ec <generic_kprobe_process_filter+0x21ec> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x21cc, 0x21ec, arm64_l_21ec);
arm64_l_21d0:
	/* 0x21d0: adrp x1, 0 <kprobe_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&kprobe_calls_6));
arm64_l_21d4:
	/* 0x21d4: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_21d8:
	/* 0x21d8: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_21dc:
	/* 0x21dc: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_21e0:
	/* 0x21e0: mov x0, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_21e4:
	/* 0x21e4: mov w2, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_21e8:
	/* 0x21e8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x21ecULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_21ec:
	/* 0x21ec: ldp x20, x19, [sp, #288] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 288ULL);
arm64_l_21f0:
	/* 0x21f0: mov w0, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_21f4:
	/* 0x21f4: ldr x29, [sp, #224] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_21f8:
	/* 0x21f8: ldp x22, x21, [sp, #272] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 272ULL);
arm64_l_21fc:
	/* 0x21fc: ldp x24, x23, [sp, #256] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 256ULL);
arm64_l_2200:
	/* 0x2200: ldp x30, x25, [sp, #240] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 240ULL);
arm64_l_2204:
	/* 0x2204: add sp, sp, #0x130 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 304ULL);
arm64_l_2208:
	/* 0x2208: b 2228 <__native_link_arm64_ret_trampoline> */
	ARM64_SIM_A64_JMP(0x2208, 0x2228, arm64_l_2228);
arm64_l_220c:
	/* 0x220c: adrp x1, 0 <kprobe_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&kprobe_calls_6));
arm64_l_2210:
	/* 0x2210: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2214:
	/* 0x2214: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_2218:
	/* 0x2218: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_221c:
	/* 0x221c: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2220:
	/* 0x2220: mov w2, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2224:
	/* 0x2224: b 21e8 <generic_kprobe_process_filter+0x21e8> */
	ARM64_SIM_A64_JMP(0x2224, 0x21e8, arm64_l_21e8);
arm64_l_2228:
	/* 0x2228: mov x7, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
