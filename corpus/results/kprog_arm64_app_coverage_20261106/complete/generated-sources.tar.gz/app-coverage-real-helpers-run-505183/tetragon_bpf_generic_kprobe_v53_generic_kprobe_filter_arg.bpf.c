extern char addr4lpm_maps;
extern char addr6lpm_maps;
extern char argfilter_maps;
extern char filter_map;
extern char heap_ro_zero;
extern char kprobe_calls;
extern char process_call_heap;
extern char retprobe_map;
extern char string_maps_0;
extern char string_maps_1;
extern char string_maps_2;
extern char string_maps_3;
extern char string_maps_4;
extern char string_maps_5;
extern char string_maps_6;
extern char string_maps_7;
extern char string_maps_heap;
extern char string_postfix_maps;
extern char string_postfix_maps_heap;
extern char string_prefix_maps;
extern char string_prefix_maps_heap;
extern char substring_map;
#define ARM64_SIM_RET_CASES_2e1c case 0x1340ULL: goto arm64_l_1340;
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_RETURN_CASES \
	case 0x38ULL: goto arm64_l_38; \
	case 0x64ULL: goto arm64_l_64; \
	case 0x18cULL: goto arm64_l_18c; \
	case 0x1a8ULL: goto arm64_l_1a8; \
	case 0x244ULL: goto arm64_l_244; \
	case 0x250ULL: goto arm64_l_250; \
	case 0x270ULL: goto arm64_l_270; \
	case 0x288ULL: goto arm64_l_288; \
	case 0x44cULL: goto arm64_l_44c; \
	case 0x658ULL: goto arm64_l_658; \
	case 0x680ULL: goto arm64_l_680; \
	case 0x8a4ULL: goto arm64_l_8a4; \
	case 0x8c0ULL: goto arm64_l_8c0; \
	case 0x904ULL: goto arm64_l_904; \
	case 0x934ULL: goto arm64_l_934; \
	case 0x9b4ULL: goto arm64_l_9b4; \
	case 0x9e4ULL: goto arm64_l_9e4; \
	case 0xa0cULL: goto arm64_l_a0c; \
	case 0xa3cULL: goto arm64_l_a3c; \
	case 0xa4cULL: goto arm64_l_a4c; \
	case 0xa78ULL: goto arm64_l_a78; \
	case 0xbd4ULL: goto arm64_l_bd4; \
	case 0xc9cULL: goto arm64_l_c9c; \
	case 0xcc4ULL: goto arm64_l_cc4; \
	case 0xcf4ULL: goto arm64_l_cf4; \
	case 0xd04ULL: goto arm64_l_d04; \
	case 0xdb4ULL: goto arm64_l_db4; \
	case 0xddcULL: goto arm64_l_ddc; \
	case 0x1118ULL: goto arm64_l_1118; \
	case 0x118cULL: goto arm64_l_118c; \
	case 0x12e4ULL: goto arm64_l_12e4; \
	case 0x132cULL: goto arm64_l_132c; \
	case 0x1340ULL: goto arm64_l_1340; \
	case 0x13d8ULL: goto arm64_l_13d8; \
	case 0x1414ULL: goto arm64_l_1414; \
	case 0x1474ULL: goto arm64_l_1474; \
	case 0x149cULL: goto arm64_l_149c; \
	case 0x14ccULL: goto arm64_l_14cc; \
	case 0x15a8ULL: goto arm64_l_15a8; \
	case 0x15c0ULL: goto arm64_l_15c0; \
	case 0x1610ULL: goto arm64_l_1610; \
	case 0x1664ULL: goto arm64_l_1664; \
	case 0x168cULL: goto arm64_l_168c; \
	case 0x1788ULL: goto arm64_l_1788; \
	case 0x17a0ULL: goto arm64_l_17a0; \
	case 0x192cULL: goto arm64_l_192c; \
	case 0x1944ULL: goto arm64_l_1944; \
	case 0x1998ULL: goto arm64_l_1998; \
	case 0x1b04ULL: goto arm64_l_1b04; \
	case 0x1df4ULL: goto arm64_l_1df4; \
	case 0x1e0cULL: goto arm64_l_1e0c; \
	case 0x1fccULL: goto arm64_l_1fcc; \
	case 0x1ff8ULL: goto arm64_l_1ff8; \
	case 0x20d4ULL: goto arm64_l_20d4; \
	case 0x20f0ULL: goto arm64_l_20f0; \
	case 0x2134ULL: goto arm64_l_2134; \
	case 0x2278ULL: goto arm64_l_2278; \
	case 0x22a4ULL: goto arm64_l_22a4; \
	case 0x27a8ULL: goto arm64_l_27a8; \
	case 0x27d4ULL: goto arm64_l_27d4; \
	case 0x288cULL: goto arm64_l_288c; \
	case 0x289cULL: goto arm64_l_289c; \
	case 0x2a60ULL: goto arm64_l_2a60; \
	case 0x2a70ULL: goto arm64_l_2a70; \
	case 0x2cbcULL: goto arm64_l_2cbc; \
	case 0x2cccULL: goto arm64_l_2ccc;
#include "../arm64_sim_local_bpf.h"

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} addr4lpm_maps_0 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} addr6lpm_maps_1 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} argfilter_maps_2 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} filter_map_3 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} heap_ro_zero_4 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} kprobe_calls_5 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} process_call_heap_6 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} retprobe_map_7 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_0_8 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_1_9 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_2_10 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_3_11 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_4_12 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_5_13 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_6_14 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_7_15 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_heap_16 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_postfix_maps_17 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_postfix_maps_heap_18 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_prefix_maps_19 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_prefix_maps_heap_20 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} substring_map_21 SEC(".maps");

SEC("xdp")
int tetragon_bpf_generic_kprobe_v53_generic_kprobe_filter_arg_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
arm64_l_0:
	/* 0x0: sub sp, sp, #0xf0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_4:
	/* 0x4: str x29, [sp, #160] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_8:
	/* 0x8: stp x30, x25, [sp, #176] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_c:
	/* 0xc: stp x24, x23, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_10:
	/* 0x10: stp x22, x21, [sp, #208] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_14:
	/* 0x14: stp x20, x19, [sp, #224] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_18:
	/* 0x18: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c:
	/* 0x1c: str wzr, [sp, #168] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_20:
	/* 0x20: adrp x0, 0 <process_call_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_6));
arm64_l_24:
	/* 0x24: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28:
	/* 0x28: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c:
	/* 0x2c: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_30:
	/* 0x30: add x1, sp, #0xa8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_34:
	/* 0x34: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x38ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_38:
	/* 0x38: cbz x0, 1a8 <generic_kprobe_filter_arg+0x1a8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x38, 0x1a8, arm64_l_1a8);
arm64_l_3c:
	/* 0x3c: mov w8, #0x5ec1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24257ULL);
arm64_l_40:
	/* 0x40: mov x20, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_44:
	/* 0x44: add x22, x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_48:
	/* 0x48: mov w8, #0x5ef8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24312ULL);
arm64_l_4c:
	/* 0x4c: add x1, x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X1, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_50:
	/* 0x50: adrp x0, 0 <filter_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&filter_map_3));
arm64_l_54:
	/* 0x54: ldur w23, [x22, #63] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 63ULL);
arm64_l_58:
	/* 0x58: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_5c:
	/* 0x5c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_60:
	/* 0x60: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x64ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_64:
	/* 0x64: cbz x0, 18c <generic_kprobe_filter_arg+0x18c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x64, 0x18c, arm64_l_18c);
arm64_l_68:
	/* 0x68: ldrb w8, [x22, #31] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 31ULL);
arm64_l_6c:
	/* 0x6c: cbz w8, 18c <generic_kprobe_filter_arg+0x18c> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x6c, 0x18c, arm64_l_18c);
arm64_l_70:
	/* 0x70: and x8, x23, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_74:
	/* 0x74: mov w10, #0x5ec1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24257ULL);
arm64_l_78:
	/* 0x78: stp x23, x22, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_7c:
	/* 0x7c: add x9, x20, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_80:
	/* 0x80: ldrb w9, [x9, x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X10, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_84:
	/* 0x84: cbz w9, fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x84, 0xfc, arm64_l_fc);
arm64_l_88:
	/* 0x88: lsl w8, w8, #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_8c:
	/* 0x8c: mov x21, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_90:
	/* 0x90: add x8, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_94:
	/* 0x94: ldr w9, [x8, x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X0, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_98:
	/* 0x98: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_9c:
	/* 0x9c: add x8, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_a0:
	/* 0xa0: and x9, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_a4:
	/* 0xa4: ldr w9, [x9, x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X0, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a8:
	/* 0xa8: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_ac:
	/* 0xac: and x9, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_b0:
	/* 0xb0: ldr w9, [x9, x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X0, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b4:
	/* 0xb4: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_b8:
	/* 0xb8: and x9, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_bc:
	/* 0xbc: ldr w9, [x9, x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X0, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c0:
	/* 0xc0: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_c4:
	/* 0xc4: and x9, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_c8:
	/* 0xc8: ldr w9, [x9, x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X0, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cc:
	/* 0xcc: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_d0:
	/* 0xd0: and x9, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_d4:
	/* 0xd4: ldr w9, [x9, x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X0, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d8:
	/* 0xd8: add x16, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X16, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_dc:
	/* 0xdc: and x15, x16, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X16, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_e0:
	/* 0xe0: add x17, x0, x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X17, ARM64_X0, ARM64_X15, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_e4:
	/* 0xe4: ldr w8, [x17] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e8:
	/* 0xe8: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_ec:
	/* 0xec: b.cs 150 <generic_kprobe_filter_arg+0x150> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xec, 0x150, arm64_l_150);
arm64_l_f0:
	/* 0xf0: cmp w15, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_f4:
	/* 0xf4: b.eq 18c <generic_kprobe_filter_arg+0x18c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf4, 0x18c, arm64_l_18c);
arm64_l_f8:
	/* 0xf8: cbnz w15, 168 <generic_kprobe_filter_arg+0x168> */
	ARM64_SIM_A64_CBNZ(ARM64_X15, 0xf8, 0x168, arm64_l_168);
arm64_l_fc:
	/* 0xfc: ldr x8, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_100:
	/* 0x100: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_104:
	/* 0x104: b.gt 124 <generic_kprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x104, 0x124, arm64_l_124);
arm64_l_108:
	/* 0x108: ldr x9, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_10c:
	/* 0x10c: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_110:
	/* 0x110: b.eq 1c8 <generic_kprobe_filter_arg+0x1c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x110, 0x1c8, arm64_l_1c8);
arm64_l_114:
	/* 0x114: cbz w8, 1d8 <generic_kprobe_filter_arg+0x1d8> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x114, 0x1d8, arm64_l_1d8);
arm64_l_118:
	/* 0x118: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_11c:
	/* 0x11c: b.eq 1e8 <generic_kprobe_filter_arg+0x1e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x11c, 0x1e8, arm64_l_1e8);
arm64_l_120:
	/* 0x120: b 140 <generic_kprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JMP(0x120, 0x140, arm64_l_140);
arm64_l_124:
	/* 0x124: ldr x9, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_128:
	/* 0x128: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_12c:
	/* 0x12c: b.eq 1f8 <generic_kprobe_filter_arg+0x1f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x12c, 0x1f8, arm64_l_1f8);
arm64_l_130:
	/* 0x130: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_134:
	/* 0x134: b.eq 208 <generic_kprobe_filter_arg+0x208> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x134, 0x208, arm64_l_208);
arm64_l_138:
	/* 0x138: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_13c:
	/* 0x13c: b.eq 218 <generic_kprobe_filter_arg+0x218> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x13c, 0x218, arm64_l_218);
arm64_l_140:
	/* 0x140: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_144:
	/* 0x144: b.gt 244 <generic_kprobe_filter_arg+0x244> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x144, 0x244, arm64_l_244);
arm64_l_148:
	/* 0x148: add w8, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_14c:
	/* 0x14c: b 224 <generic_kprobe_filter_arg+0x224> */
	ARM64_SIM_A64_JMP(0x14c, 0x224, arm64_l_224);
arm64_l_150:
	/* 0x150: mov x25, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_154:
	/* 0x154: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_158:
	/* 0x158: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_15c:
	/* 0x15c: stp x19, x17, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X19, ARM64_X17, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_160:
	/* 0x160: stp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X16, ARM64_X15, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_164:
	/* 0x164: b 2a4 <generic_kprobe_filter_arg+0x2a4> */
	ARM64_SIM_A64_JMP(0x164, 0x2a4, arm64_l_2a4);
arm64_l_168:
	/* 0x168: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_16c:
	/* 0x16c: adrp x1, 0 <kprobe_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&kprobe_calls_5));
arm64_l_170:
	/* 0x170: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_174:
	/* 0x174: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_178:
	/* 0x178: stur w15, [x8, #67] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 67ULL);
arm64_l_17c:
	/* 0x17c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_180:
	/* 0x180: mov w2, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_184:
	/* 0x184: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_188:
	/* 0x188: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x18cULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_18c:
	/* 0x18c: adrp x1, 0 <kprobe_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&kprobe_calls_5));
arm64_l_190:
	/* 0x190: mov w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_194:
	/* 0x194: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_198:
	/* 0x198: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19c:
	/* 0x19c: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a0:
	/* 0x1a0: mov w2, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_1a4:
	/* 0x1a4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x1a8ULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1a8:
	/* 0x1a8: ldp x20, x19, [sp, #224] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_1ac:
	/* 0x1ac: mov w0, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1b0:
	/* 0x1b0: ldr x29, [sp, #160] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_1b4:
	/* 0x1b4: ldp x22, x21, [sp, #208] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_1b8:
	/* 0x1b8: ldp x24, x23, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_1bc:
	/* 0x1bc: ldp x30, x25, [sp, #176] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_1c0:
	/* 0x1c0: add sp, sp, #0xf0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1c4:
	/* 0x1c4: b 2e20 <__native_link_arm64_ret_trampoline> */
	ARM64_SIM_A64_JMP(0x1c4, 0x2e20, arm64_l_2e20);
arm64_l_1c8:
	/* 0x1c8: ldrb w8, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1cc:
	/* 0x1cc: cbz w8, 1d8 <generic_kprobe_filter_arg+0x1d8> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1cc, 0x1d8, arm64_l_1d8);
arm64_l_1d0:
	/* 0x1d0: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1d4:
	/* 0x1d4: b 224 <generic_kprobe_filter_arg+0x224> */
	ARM64_SIM_A64_JMP(0x1d4, 0x224, arm64_l_224);
arm64_l_1d8:
	/* 0x1d8: ldrb w8, [x9, #1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1ULL);
arm64_l_1dc:
	/* 0x1dc: cbz w8, 1e8 <generic_kprobe_filter_arg+0x1e8> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1dc, 0x1e8, arm64_l_1e8);
arm64_l_1e0:
	/* 0x1e0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e4:
	/* 0x1e4: b 224 <generic_kprobe_filter_arg+0x224> */
	ARM64_SIM_A64_JMP(0x1e4, 0x224, arm64_l_224);
arm64_l_1e8:
	/* 0x1e8: ldrb w8, [x9, #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_1ec:
	/* 0x1ec: cbz w8, 1f8 <generic_kprobe_filter_arg+0x1f8> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1ec, 0x1f8, arm64_l_1f8);
arm64_l_1f0:
	/* 0x1f0: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1f4:
	/* 0x1f4: b 224 <generic_kprobe_filter_arg+0x224> */
	ARM64_SIM_A64_JMP(0x1f4, 0x224, arm64_l_224);
arm64_l_1f8:
	/* 0x1f8: ldrb w8, [x9, #3] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3ULL);
arm64_l_1fc:
	/* 0x1fc: cbz w8, 208 <generic_kprobe_filter_arg+0x208> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1fc, 0x208, arm64_l_208);
arm64_l_200:
	/* 0x200: mov w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_204:
	/* 0x204: b 224 <generic_kprobe_filter_arg+0x224> */
	ARM64_SIM_A64_JMP(0x204, 0x224, arm64_l_224);
arm64_l_208:
	/* 0x208: ldrb w8, [x9, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_20c:
	/* 0x20c: cbz w8, 218 <generic_kprobe_filter_arg+0x218> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x20c, 0x218, arm64_l_218);
arm64_l_210:
	/* 0x210: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_214:
	/* 0x214: b 224 <generic_kprobe_filter_arg+0x224> */
	ARM64_SIM_A64_JMP(0x214, 0x224, arm64_l_224);
arm64_l_218:
	/* 0x218: ldrb w8, [x9, #5] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_21c:
	/* 0x21c: cbz w8, 244 <generic_kprobe_filter_arg+0x244> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x21c, 0x244, arm64_l_244);
arm64_l_220:
	/* 0x220: mov w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_224:
	/* 0x224: stur w8, [x9, #63] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 63ULL);
arm64_l_228:
	/* 0x228: adrp x1, 0 <kprobe_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&kprobe_calls_5));
arm64_l_22c:
	/* 0x22c: mov w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_230:
	/* 0x230: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_234:
	/* 0x234: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_238:
	/* 0x238: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_23c:
	/* 0x23c: mov w2, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_240:
	/* 0x240: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x244ULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_244:
	/* 0x244: ldr x19, [x20, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_248:
	/* 0x248: mov w8, #0xe */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_24c:
	/* 0x24c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x250ULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_250:
	/* 0x250: stp x19, x0, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_254:
	/* 0x254: adrp x19, 0 <retprobe_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&retprobe_map_7));
arm64_l_258:
	/* 0x258: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_25c:
	/* 0x25c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_260:
	/* 0x260: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_264:
	/* 0x264: ldr x19, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_268:
	/* 0x268: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_26c:
	/* 0x26c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x270ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_270:
	/* 0x270: cbz x0, 1a8 <generic_kprobe_filter_arg+0x1a8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x270, 0x1a8, arm64_l_1a8);
arm64_l_274:
	/* 0x274: mov w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_278:
	/* 0x278: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_27c:
	/* 0x27c: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_280:
	/* 0x280: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_284:
	/* 0x284: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 3ULL: ARM64_SIM_A64_LINK(0x288ULL); ARM64_SIM_BPF_CALL_bpf_map_delete_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_288:
	/* 0x288: b 1a8 <generic_kprobe_filter_arg+0x1a8> */
	ARM64_SIM_A64_JMP(0x288, 0x1a8, arm64_l_1a8);
arm64_l_28c:
	/* 0x28c: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_290:
	/* 0x290: cset w23, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_294:
	/* 0x294: cbz x23, fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_CBZ(ARM64_X23, 0x294, 0xfc, arm64_l_fc);
arm64_l_298:
	/* 0x298: add x25, x25, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_29c:
	/* 0x29c: cmp x25, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2a0:
	/* 0x2a0: b.eq f0 <generic_kprobe_filter_arg+0xf0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2a0, 0xf0, arm64_l_f0);
arm64_l_2a4:
	/* 0x2a4: add x8, x17, x25, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X17, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_2a8:
	/* 0x2a8: ldr w8, [x8, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2ac:
	/* 0x2ac: tst w8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_2b0:
	/* 0x2b0: b.eq f0 <generic_kprobe_filter_arg+0xf0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2b0, 0xf0, arm64_l_f0);
arm64_l_2b4:
	/* 0x2b4: add w8, w16, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X16, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2b8:
	/* 0x2b8: and x8, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_2bc:
	/* 0x2bc: add x29, x21, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X29, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2c0:
	/* 0x2c0: ldr w8, [x29, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2c4:
	/* 0x2c4: cmp w8, #0x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 35ULL);
arm64_l_2c8:
	/* 0x2c8: b.eq fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2c8, 0xfc, arm64_l_fc);
arm64_l_2cc:
	/* 0x2cc: ldr w9, [x29] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d0:
	/* 0x2d0: cmp w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2d4:
	/* 0x2d4: b.hi fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2d4, 0xfc, arm64_l_fc);
arm64_l_2d8:
	/* 0x2d8: add x10, x20, x9, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_2dc:
	/* 0x2dc: ldr w10, [x10, x2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X10, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X2, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2e0:
	/* 0x2e0: cbnz w10, fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0x2e0, 0xfc, arm64_l_fc);
arm64_l_2e4:
	/* 0x2e4: add x9, x20, x9, lsl #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 3), 0);
arm64_l_2e8:
	/* 0x2e8: ldr x9, [x9, #24184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24184ULL);
arm64_l_2ec:
	/* 0x2ec: and x9, x9, #0x7ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2047ULL);
arm64_l_2f0:
	/* 0x2f0: add x9, x20, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2f4:
	/* 0x2f4: add x22, x9, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2f8:
	/* 0x2f8: ldr w9, [x29, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_2fc:
	/* 0x2fc: cmp w9, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_300:
	/* 0x300: b.le 350 <generic_kprobe_filter_arg+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x300, 0x350, arm64_l_350);
arm64_l_304:
	/* 0x304: sub w10, w9, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_308:
	/* 0x308: cmp w10, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_30c:
	/* 0x30c: b.cc 4c0 <generic_kprobe_filter_arg+0x4c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x30c, 0x4c0, arm64_l_4c0);
arm64_l_310:
	/* 0x310: cmp w9, #0x2a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 42ULL);
arm64_l_314:
	/* 0x314: b.hi 340 <generic_kprobe_filter_arg+0x340> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x314, 0x340, arm64_l_340);
arm64_l_318:
	/* 0x318: lsl x10, x12, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_31c:
	/* 0x31c: tst x10, #0xc000000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 824633720832ULL);
arm64_l_320:
	/* 0x320: b.ne 378 <generic_kprobe_filter_arg+0x378> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x320, 0x378, arm64_l_378);
arm64_l_324:
	/* 0x324: lsl x10, x12, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_328:
	/* 0x328: tst x10, #0x30000000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3298534883328ULL);
arm64_l_32c:
	/* 0x32c: b.ne 768 <generic_kprobe_filter_arg+0x768> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x32c, 0x768, arm64_l_768);
arm64_l_330:
	/* 0x330: lsl x10, x12, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_334:
	/* 0x334: mov x11, #0x42000000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 4535485464576ULL);
arm64_l_338:
	/* 0x338: tst x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_33c:
	/* 0x33c: b.ne 3c0 <generic_kprobe_filter_arg+0x3c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x33c, 0x3c0, arm64_l_3c0);
arm64_l_340:
	/* 0x340: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_344:
	/* 0x344: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x344, 0x298, arm64_l_298);
arm64_l_348:
	/* 0x348: add x22, x22, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_34c:
	/* 0x34c: b 3c0 <generic_kprobe_filter_arg+0x3c0> */
	ARM64_SIM_A64_JMP(0x34c, 0x3c0, arm64_l_3c0);
arm64_l_350:
	/* 0x350: cmp w9, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_354:
	/* 0x354: b.gt 3a8 <generic_kprobe_filter_arg+0x3a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x354, 0x3a8, arm64_l_3a8);
arm64_l_358:
	/* 0x358: cmp w9, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_35c:
	/* 0x35c: b.le 47c <generic_kprobe_filter_arg+0x47c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x35c, 0x47c, arm64_l_47c);
arm64_l_360:
	/* 0x360: cmp w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_364:
	/* 0x364: b.eq 4c0 <generic_kprobe_filter_arg+0x4c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x364, 0x4c0, arm64_l_4c0);
arm64_l_368:
	/* 0x368: cmp w9, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_36c:
	/* 0x36c: b.eq 768 <generic_kprobe_filter_arg+0x768> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x36c, 0x768, arm64_l_768);
arm64_l_370:
	/* 0x370: cmp w9, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_374:
	/* 0x374: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x374, 0x298, arm64_l_298);
arm64_l_378:
	/* 0x378: ldr w24, [x22], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_37c:
	/* 0x37c: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_380:
	/* 0x380: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_384:
	/* 0x384: b.gt 61c <generic_kprobe_filter_arg+0x61c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x384, 0x61c, arm64_l_61c);
arm64_l_388:
	/* 0x388: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_38c:
	/* 0x38c: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_390:
	/* 0x390: b.cc d10 <generic_kprobe_filter_arg+0xd10> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x390, 0xd10, arm64_l_d10);
arm64_l_394:
	/* 0x394: cmp w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_398:
	/* 0x398: b.eq c78 <generic_kprobe_filter_arg+0xc78> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x398, 0xc78, arm64_l_c78);
arm64_l_39c:
	/* 0x39c: cmp w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_3a0:
	/* 0x3a0: b.eq 634 <generic_kprobe_filter_arg+0x634> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3a0, 0x634, arm64_l_634);
arm64_l_3a4:
	/* 0x3a4: b 1228 <generic_kprobe_filter_arg+0x1228> */
	ARM64_SIM_A64_JMP(0x3a4, 0x1228, arm64_l_1228);
arm64_l_3a8:
	/* 0x3a8: sub w10, w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_3ac:
	/* 0x3ac: cmp w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_3b0:
	/* 0x3b0: b.cc 4c0 <generic_kprobe_filter_arg+0x4c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x3b0, 0x4c0, arm64_l_4c0);
arm64_l_3b4:
	/* 0x3b4: sub w10, w9, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_3b8:
	/* 0x3b8: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3bc:
	/* 0x3bc: b.cs 760 <generic_kprobe_filter_arg+0x760> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x3bc, 0x760, arm64_l_760);
arm64_l_3c0:
	/* 0x3c0: ldr w24, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3c4:
	/* 0x3c4: and w9, w8, #0xfffffffe */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967294ULL);
arm64_l_3c8:
	/* 0x3c8: cmp w9, #0x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 36ULL);
arm64_l_3cc:
	/* 0x3cc: b.eq 3d4 <generic_kprobe_filter_arg+0x3d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3cc, 0x3d4, arm64_l_3d4);
arm64_l_3d0:
	/* 0x3d0: cbz w24, fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_CBZ(ARM64_X24, 0x3d0, 0xfc, arm64_l_fc);
arm64_l_3d4:
	/* 0x3d4: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_3d8:
	/* 0x3d8: b.hi 700 <generic_kprobe_filter_arg+0x700> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x3d8, 0x700, arm64_l_700);
arm64_l_3dc:
	/* 0x3dc: mov w10, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_3e0:
	/* 0x3e0: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_3e4:
	/* 0x3e4: movk w10, #0x400, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 1024ULL);
arm64_l_3e8:
	/* 0x3e8: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3ec:
	/* 0x3ec: b.ne 9c0 <generic_kprobe_filter_arg+0x9c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3ec, 0x9c0, arm64_l_9c0);
arm64_l_3f0:
	/* 0x3f0: mov w10, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 512ULL);
arm64_l_3f4:
	/* 0x3f4: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_3f8:
	/* 0x3f8: movk w10, #0x800, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 2048ULL);
arm64_l_3fc:
	/* 0x3fc: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_400:
	/* 0x400: b.ne 8e0 <generic_kprobe_filter_arg+0x8e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x400, 0x8e0, arm64_l_8e0);
arm64_l_404:
	/* 0x404: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_408:
	/* 0x408: tst x9, #0x3000000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 206158430208ULL);
arm64_l_40c:
	/* 0x40c: b.eq 700 <generic_kprobe_filter_arg+0x700> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x40c, 0x700, arm64_l_700);
arm64_l_410:
	/* 0x410: cmp w24, #0x1fe */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 510ULL);
arm64_l_414:
	/* 0x414: strh wzr, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_418:
	/* 0x418: b.hi 718 <generic_kprobe_filter_arg+0x718> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x418, 0x718, arm64_l_718);
arm64_l_41c:
	/* 0x41c: add x8, x22, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_420:
	/* 0x420: mov w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_424:
	/* 0x424: add x11, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_428:
	/* 0x428: mov w12, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_42c:
	/* 0x42c: add x0, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_430:
	/* 0x430: mov w1, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_434:
	/* 0x434: add x9, x8, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_438:
	/* 0x438: add x9, x9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_43c:
	/* 0x43c: ldr w9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_440:
	/* 0x440: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_444:
	/* 0x444: add x2, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_448:
	/* 0x448: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x44cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_44c:
	/* 0x44c: ldr w9, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_450:
	/* 0x450: cbz w9, 28a8 <generic_kprobe_filter_arg+0x28a8> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x450, 0x28a8, arm64_l_28a8);
arm64_l_454:
	/* 0x454: ldrh w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_458:
	/* 0x458: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_45c:
	/* 0x45c: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_460:
	/* 0x460: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_464:
	/* 0x464: and w8, w8, #0xf000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 61440ULL);
arm64_l_468:
	/* 0x468: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_46c:
	/* 0x46c: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_470:
	/* 0x470: b.ne 19e4 <generic_kprobe_filter_arg+0x19e4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x470, 0x19e4, arm64_l_19e4);
arm64_l_474:
	/* 0x474: mov w23, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_478:
	/* 0x478: b 28bc <generic_kprobe_filter_arg+0x28bc> */
	ARM64_SIM_A64_JMP(0x478, 0x28bc, arm64_l_28bc);
arm64_l_47c:
	/* 0x47c: cmp w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_480:
	/* 0x480: b.eq 4c0 <generic_kprobe_filter_arg+0x4c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x480, 0x4c0, arm64_l_4c0);
arm64_l_484:
	/* 0x484: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_488:
	/* 0x488: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x488, 0x298, arm64_l_298);
arm64_l_48c:
	/* 0x48c: add x24, x22, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_490:
	/* 0x490: ldr w22, [x22, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_494:
	/* 0x494: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_498:
	/* 0x498: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_49c:
	/* 0x49c: b.gt d74 <generic_kprobe_filter_arg+0xd74> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x49c, 0xd74, arm64_l_d74);
arm64_l_4a0:
	/* 0x4a0: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_4a4:
	/* 0x4a4: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_4a8:
	/* 0x4a8: b.cc 14dc <generic_kprobe_filter_arg+0x14dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x4a8, 0x14dc, arm64_l_14dc);
arm64_l_4ac:
	/* 0x4ac: cmp w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_4b0:
	/* 0x4b0: b.eq 1450 <generic_kprobe_filter_arg+0x1450> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x4b0, 0x1450, arm64_l_1450);
arm64_l_4b4:
	/* 0x4b4: cmp w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_4b8:
	/* 0x4b8: b.eq d8c <generic_kprobe_filter_arg+0xd8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x4b8, 0xd8c, arm64_l_d8c);
arm64_l_4bc:
	/* 0x4bc: b 2cec <generic_kprobe_filter_arg+0x2cec> */
	ARM64_SIM_A64_JMP(0x4bc, 0x2cec, arm64_l_2cec);
arm64_l_4c0:
	/* 0x4c0: cmp w9, #0xb */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 11ULL);
arm64_l_4c4:
	/* 0x4c4: b.le 534 <generic_kprobe_filter_arg+0x534> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x4c4, 0x534, arm64_l_534);
arm64_l_4c8:
	/* 0x4c8: cmp w9, #0x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 36ULL);
arm64_l_4cc:
	/* 0x4cc: b.hi 57c <generic_kprobe_filter_arg+0x57c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x4cc, 0x57c, arm64_l_57c);
arm64_l_4d0:
	/* 0x4d0: lsl x10, x12, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_4d4:
	/* 0x4d4: tst x10, #0x1e00000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 128849018880ULL);
arm64_l_4d8:
	/* 0x4d8: b.ne 554 <generic_kprobe_filter_arg+0x554> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x4d8, 0x554, arm64_l_554);
arm64_l_4dc:
	/* 0x4dc: lsl x10, x12, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_4e0:
	/* 0x4e0: tst x10, #0x60000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1610612736ULL);
arm64_l_4e4:
	/* 0x4e4: b.ne 720 <generic_kprobe_filter_arg+0x720> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x4e4, 0x720, arm64_l_720);
arm64_l_4e8:
	/* 0x4e8: lsl x10, x12, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_4ec:
	/* 0x4ec: tst x10, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_4f0:
	/* 0x4f0: b.eq 57c <generic_kprobe_filter_arg+0x57c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x4f0, 0x57c, arm64_l_57c);
arm64_l_4f4:
	/* 0x4f4: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_4f8:
	/* 0x4f8: b.hi fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x4f8, 0xfc, arm64_l_fc);
arm64_l_4fc:
	/* 0x4fc: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_500:
	/* 0x500: mov w10, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_504:
	/* 0x504: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_508:
	/* 0x508: b.eq e70 <generic_kprobe_filter_arg+0xe70> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x508, 0xe70, arm64_l_e70);
arm64_l_50c:
	/* 0x50c: ldr w9, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_510:
	/* 0x510: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_514:
	/* 0x514: b.le 1378 <generic_kprobe_filter_arg+0x1378> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x514, 0x1378, arm64_l_1378);
arm64_l_518:
	/* 0x518: sub w10, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_51c:
	/* 0x51c: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_520:
	/* 0x520: b.cs 18a0 <generic_kprobe_filter_arg+0x18a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x520, 0x18a0, arm64_l_18a0);
arm64_l_524:
	/* 0x524: ldrb w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_528:
	/* 0x528: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_52c:
	/* 0x52c: b.eq 28c <generic_kprobe_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x52c, 0x28c, arm64_l_28c);
arm64_l_530:
	/* 0x530: b 1c04 <generic_kprobe_filter_arg+0x1c04> */
	ARM64_SIM_A64_JMP(0x530, 0x1c04, arm64_l_1c04);
arm64_l_534:
	/* 0x534: sub w10, w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_538:
	/* 0x538: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_53c:
	/* 0x53c: b.cc 7f8 <generic_kprobe_filter_arg+0x7f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x53c, 0x7f8, arm64_l_7f8);
arm64_l_540:
	/* 0x540: cmp w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_544:
	/* 0x544: b.eq 588 <generic_kprobe_filter_arg+0x588> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x544, 0x588, arm64_l_588);
arm64_l_548:
	/* 0x548: cmp w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_54c:
	/* 0x54c: b.eq 588 <generic_kprobe_filter_arg+0x588> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x54c, 0x588, arm64_l_588);
arm64_l_550:
	/* 0x550: b 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JMP(0x550, 0x298, arm64_l_298);
arm64_l_554:
	/* 0x554: cmp w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_558:
	/* 0x558: b.le 7a8 <generic_kprobe_filter_arg+0x7a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x558, 0x7a8, arm64_l_7a8);
arm64_l_55c:
	/* 0x55c: cmp w8, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_560:
	/* 0x560: b.gt b50 <generic_kprobe_filter_arg+0xb50> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x560, 0xb50, arm64_l_b50);
arm64_l_564:
	/* 0x564: sub w10, w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_568:
	/* 0x568: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_56c:
	/* 0x56c: b.cc 884 <generic_kprobe_filter_arg+0x884> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x56c, 0x884, arm64_l_884);
arm64_l_570:
	/* 0x570: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_574:
	/* 0x574: b.eq 810 <generic_kprobe_filter_arg+0x810> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x574, 0x810, arm64_l_810);
arm64_l_578:
	/* 0x578: b fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x578, 0xfc, arm64_l_fc);
arm64_l_57c:
	/* 0x57c: sub w10, w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_580:
	/* 0x580: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_584:
	/* 0x584: b.cs 7f0 <generic_kprobe_filter_arg+0x7f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x584, 0x7f0, arm64_l_7f0);
arm64_l_588:
	/* 0x588: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_58c:
	/* 0x58c: b.hi fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x58c, 0xfc, arm64_l_fc);
arm64_l_590:
	/* 0x590: lsl x10, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_594:
	/* 0x594: mov w11, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_598:
	/* 0x598: tst x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_59c:
	/* 0x59c: b.eq 5c8 <generic_kprobe_filter_arg+0x5c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x59c, 0x5c8, arm64_l_5c8);
arm64_l_5a0:
	/* 0x5a0: ldr w10, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_5a4:
	/* 0x5a4: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_5a8:
	/* 0x5a8: b.le 7b8 <generic_kprobe_filter_arg+0x7b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x5a8, 0x7b8, arm64_l_7b8);
arm64_l_5ac:
	/* 0x5ac: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_5b0:
	/* 0x5b0: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_5b4:
	/* 0x5b4: b.cs e58 <generic_kprobe_filter_arg+0xe58> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x5b4, 0xe58, arm64_l_e58);
arm64_l_5b8:
	/* 0x5b8: ldr w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_5bc:
	/* 0x5bc: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_5c0:
	/* 0x5c0: b.eq 28c <generic_kprobe_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x5c0, 0x28c, arm64_l_28c);
arm64_l_5c4:
	/* 0x5c4: b 1e80 <generic_kprobe_filter_arg+0x1e80> */
	ARM64_SIM_A64_JMP(0x5c4, 0x1e80, arm64_l_1e80);
arm64_l_5c8:
	/* 0x5c8: lsl x10, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_5cc:
	/* 0x5cc: tst x10, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_5d0:
	/* 0x5d0: b.ne a58 <generic_kprobe_filter_arg+0xa58> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x5d0, 0xa58, arm64_l_a58);
arm64_l_5d4:
	/* 0x5d4: lsl x10, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_5d8:
	/* 0x5d8: tst x10, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_5dc:
	/* 0x5dc: b.eq fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x5dc, 0xfc, arm64_l_fc);
arm64_l_5e0:
	/* 0x5e0: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_5e4:
	/* 0x5e4: b.ne fdc <generic_kprobe_filter_arg+0xfdc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x5e4, 0xfdc, arm64_l_fdc);
arm64_l_5e8:
	/* 0x5e8: ldp w11, w10, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_5ec:
	/* 0x5ec: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_5f0:
	/* 0x5f0: b.hi 1c80 <generic_kprobe_filter_arg+0x1c80> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x5f0, 0x1c80, arm64_l_1c80);
arm64_l_5f4:
	/* 0x5f4: lsl w8, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_5f8:
	/* 0x5f8: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_5fc:
	/* 0x5fc: tst w8, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_600:
	/* 0x600: b.eq 1c80 <generic_kprobe_filter_arg+0x1c80> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x600, 0x1c80, arm64_l_1c80);
arm64_l_604:
	/* 0x604: ldr w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_608:
	/* 0x608: cmp w11, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_60c:
	/* 0x60c: b.gt 1c94 <generic_kprobe_filter_arg+0x1c94> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x60c, 0x1c94, arm64_l_1c94);
arm64_l_610:
	/* 0x610: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_614:
	/* 0x614: b.le 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x614, 0x298, arm64_l_298);
arm64_l_618:
	/* 0x618: b 1c94 <generic_kprobe_filter_arg+0x1c94> */
	ARM64_SIM_A64_JMP(0x618, 0x1c94, arm64_l_1c94);
arm64_l_61c:
	/* 0x61c: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_620:
	/* 0x620: b.gt b90 <generic_kprobe_filter_arg+0xb90> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x620, 0xb90, arm64_l_b90);
arm64_l_624:
	/* 0x624: cmp w8, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_628:
	/* 0x628: b.eq c78 <generic_kprobe_filter_arg+0xc78> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x628, 0xc78, arm64_l_c78);
arm64_l_62c:
	/* 0x62c: cmp w8, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_630:
	/* 0x630: b.ne 1228 <generic_kprobe_filter_arg+0x1228> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x630, 0x1228, arm64_l_1228);
arm64_l_634:
	/* 0x634: ldr w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_638:
	/* 0x638: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_63c:
	/* 0x63c: adrp x0, 0 <string_postfix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_17));
arm64_l_640:
	/* 0x640: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_644:
	/* 0x644: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_648:
	/* 0x648: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_64c:
	/* 0x64c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_650:
	/* 0x650: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_654:
	/* 0x654: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x658ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_658:
	/* 0x658: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_65c:
	/* 0x65c: cbz w24, 1218 <generic_kprobe_filter_arg+0x1218> */
	ARM64_SIM_A64_CBZ(ARM64_X24, 0x65c, 0x1218, arm64_l_1218);
arm64_l_660:
	/* 0x660: cbz x0, 1218 <generic_kprobe_filter_arg+0x1218> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x660, 0x1218, arm64_l_1218);
arm64_l_664:
	/* 0x664: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_668:
	/* 0x668: adrp x0, 0 <string_postfix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap_18));
arm64_l_66c:
	/* 0x66c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_670:
	/* 0x670: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_674:
	/* 0x674: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_678:
	/* 0x678: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_67c:
	/* 0x67c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x680ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_680:
	/* 0x680: cbz x0, 1210 <generic_kprobe_filter_arg+0x1210> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x680, 0x1210, arm64_l_1210);
arm64_l_684:
	/* 0x684: cmp w24, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_688:
	/* 0x688: mov w9, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_68c:
	/* 0x68c: mov w11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_690:
	/* 0x690: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_694:
	/* 0x694: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_698:
	/* 0x698: sub w12, w24, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_69c:
	/* 0x69c: sub w13, w24, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_6a0:
	/* 0x6a0: csel w9, w24, w9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X9, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_6a4:
	/* 0x6a4: sub x11, x11, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X11, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_6a8:
	/* 0x6a8: lsl w10, w9, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_6ac:
	/* 0x6ac: mov x9, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6b0:
	/* 0x6b0: str w10, [x9], #5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 5ULL);
arm64_l_6b4:
	/* 0x6b4: neg x10, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X10, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6b8:
	/* 0x6b8: add w14, w13, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X13, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_6bc:
	/* 0x6bc: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_6c0:
	/* 0x6c0: and x14, x14, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_6c4:
	/* 0x6c4: ldrb w14, [x22, x14] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X14, ARM64_X22, ARM64_X14, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X14, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6c8:
	/* 0x6c8: sturb w14, [x9, #-1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 18446744073709551615ULL);
arm64_l_6cc:
	/* 0x6cc: b.eq 6f4 <generic_kprobe_filter_arg+0x6f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x6cc, 0x6f4, arm64_l_6f4);
arm64_l_6d0:
	/* 0x6d0: cmn x8, #0x7e */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 126ULL);
arm64_l_6d4:
	/* 0x6d4: b.eq 6f4 <generic_kprobe_filter_arg+0x6f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x6d4, 0x6f4, arm64_l_6f4);
arm64_l_6d8:
	/* 0x6d8: add w14, w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_6dc:
	/* 0x6dc: sub x8, x8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_6e0:
	/* 0x6e0: and x14, x14, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_6e4:
	/* 0x6e4: cmp x10, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_6e8:
	/* 0x6e8: ldrb w14, [x22, x14] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X14, ARM64_X22, ARM64_X14, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X14, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6ec:
	/* 0x6ec: strb w14, [x9], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_6f0:
	/* 0x6f0: b.ne 6b8 <generic_kprobe_filter_arg+0x6b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x6f0, 0x6b8, arm64_l_6b8);
arm64_l_6f4:
	/* 0x6f4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_6f8:
	/* 0x6f8: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6fc:
	/* 0x6fc: b d00 <generic_kprobe_filter_arg+0xd00> */
	ARM64_SIM_A64_JMP(0x6fc, 0xd00, arm64_l_d00);
arm64_l_700:
	/* 0x700: sub w8, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_704:
	/* 0x704: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_708:
	/* 0x708: b.cs 718 <generic_kprobe_filter_arg+0x718> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x708, 0x718, arm64_l_718);
arm64_l_70c:
	/* 0x70c: cmp w24, #0x1fe */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 510ULL);
arm64_l_710:
	/* 0x710: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_714:
	/* 0x714: b.ls f78 <generic_kprobe_filter_arg+0xf78> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x714, 0xf78, arm64_l_f78);
arm64_l_718:
	/* 0x718: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_71c:
	/* 0x71c: b 28bc <generic_kprobe_filter_arg+0x28bc> */
	ARM64_SIM_A64_JMP(0x71c, 0x28bc, arm64_l_28bc);
arm64_l_720:
	/* 0x720: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_724:
	/* 0x724: b.hi fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x724, 0xfc, arm64_l_fc);
arm64_l_728:
	/* 0x728: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_72c:
	/* 0x72c: mov w10, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_730:
	/* 0x730: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_734:
	/* 0x734: b.eq e9c <generic_kprobe_filter_arg+0xe9c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x734, 0xe9c, arm64_l_e9c);
arm64_l_738:
	/* 0x738: ldr w9, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_73c:
	/* 0x73c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_740:
	/* 0x740: b.le 1398 <generic_kprobe_filter_arg+0x1398> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x740, 0x1398, arm64_l_1398);
arm64_l_744:
	/* 0x744: sub w10, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_748:
	/* 0x748: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_74c:
	/* 0x74c: b.cs 18b8 <generic_kprobe_filter_arg+0x18b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x74c, 0x18b8, arm64_l_18b8);
arm64_l_750:
	/* 0x750: ldrh w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_754:
	/* 0x754: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_758:
	/* 0x758: b.eq 28c <generic_kprobe_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x758, 0x28c, arm64_l_28c);
arm64_l_75c:
	/* 0x75c: b 1c44 <generic_kprobe_filter_arg+0x1c44> */
	ARM64_SIM_A64_JMP(0x75c, 0x1c44, arm64_l_1c44);
arm64_l_760:
	/* 0x760: cmp w9, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_764:
	/* 0x764: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x764, 0x298, arm64_l_298);
arm64_l_768:
	/* 0x768: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_76c:
	/* 0x76c: cmp w9, #0x27 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 39ULL);
arm64_l_770:
	/* 0x770: stp xzr, xzr, [sp, #120] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_774:
	/* 0x774: str xzr, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_778:
	/* 0x778: stp xzr, xzr, [sp, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_77c:
	/* 0x77c: b.gt 790 <generic_kprobe_filter_arg+0x790> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x77c, 0x790, arm64_l_790);
arm64_l_780:
	/* 0x780: cmp w9, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_784:
	/* 0x784: b.eq aac <generic_kprobe_filter_arg+0xaac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x784, 0xaac, arm64_l_aac);
arm64_l_788:
	/* 0x788: cmp w9, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_78c:
	/* 0x78c: b 79c <generic_kprobe_filter_arg+0x79c> */
	ARM64_SIM_A64_JMP(0x78c, 0x79c, arm64_l_79c);
arm64_l_790:
	/* 0x790: cmp w9, #0x28 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_794:
	/* 0x794: b.eq ab4 <generic_kprobe_filter_arg+0xab4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x794, 0xab4, arm64_l_ab4);
arm64_l_798:
	/* 0x798: cmp w9, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_79c:
	/* 0x79c: mov x10, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7a0:
	/* 0x7a0: b.eq adc <generic_kprobe_filter_arg+0xadc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x7a0, 0xadc, arm64_l_adc);
arm64_l_7a4:
	/* 0x7a4: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x7a4, 0x294, arm64_l_294);
arm64_l_7a8:
	/* 0x7a8: sub w10, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_7ac:
	/* 0x7ac: cmp w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_7b0:
	/* 0x7b0: b.cc 810 <generic_kprobe_filter_arg+0x810> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x7b0, 0x810, arm64_l_810);
arm64_l_7b4:
	/* 0x7b4: b fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x7b4, 0xfc, arm64_l_fc);
arm64_l_7b8:
	/* 0x7b8: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_7bc:
	/* 0x7bc: b.eq 1130 <generic_kprobe_filter_arg+0x1130> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x7bc, 0x1130, arm64_l_1130);
arm64_l_7c0:
	/* 0x7c0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_7c4:
	/* 0x7c4: b.ne 1e80 <generic_kprobe_filter_arg+0x1e80> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x7c4, 0x1e80, arm64_l_1e80);
arm64_l_7c8:
	/* 0x7c8: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_7cc:
	/* 0x7cc: b.hi 1e74 <generic_kprobe_filter_arg+0x1e74> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x7cc, 0x1e74, arm64_l_1e74);
arm64_l_7d0:
	/* 0x7d0: lsl w11, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X11, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_7d4:
	/* 0x7d4: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_7d8:
	/* 0x7d8: tst w11, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X11, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_7dc:
	/* 0x7dc: b.eq 1e74 <generic_kprobe_filter_arg+0x1e74> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x7dc, 0x1e74, arm64_l_1e74);
arm64_l_7e0:
	/* 0x7e0: ldr w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_7e4:
	/* 0x7e4: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_7e8:
	/* 0x7e8: b.lt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x7e8, 0x298, arm64_l_298);
arm64_l_7ec:
	/* 0x7ec: b 1e80 <generic_kprobe_filter_arg+0x1e80> */
	ARM64_SIM_A64_JMP(0x7ec, 0x1e80, arm64_l_1e80);
arm64_l_7f0:
	/* 0x7f0: cmp w9, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_7f4:
	/* 0x7f4: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x7f4, 0x298, arm64_l_298);
arm64_l_7f8:
	/* 0x7f8: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_7fc:
	/* 0x7fc: b.hi fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x7fc, 0xfc, arm64_l_fc);
arm64_l_800:
	/* 0x800: lsl x10, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_804:
	/* 0x804: mov w11, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_808:
	/* 0x808: tst x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_80c:
	/* 0x80c: b.eq 838 <generic_kprobe_filter_arg+0x838> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x80c, 0x838, arm64_l_838);
arm64_l_810:
	/* 0x810: ldr x10, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_814:
	/* 0x814: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_818:
	/* 0x818: b.le 854 <generic_kprobe_filter_arg+0x854> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x818, 0x854, arm64_l_854);
arm64_l_81c:
	/* 0x81c: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_820:
	/* 0x820: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_824:
	/* 0x824: b.cs a94 <generic_kprobe_filter_arg+0xa94> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x824, 0xa94, arm64_l_a94);
arm64_l_828:
	/* 0x828: ldr x11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_82c:
	/* 0x82c: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_830:
	/* 0x830: b.eq 28c <generic_kprobe_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x830, 0x28c, arm64_l_28c);
arm64_l_834:
	/* 0x834: b 17fc <generic_kprobe_filter_arg+0x17fc> */
	ARM64_SIM_A64_JMP(0x834, 0x17fc, arm64_l_17fc);
arm64_l_838:
	/* 0x838: lsl x10, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_83c:
	/* 0x83c: tst x10, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_840:
	/* 0x840: b.ne 884 <generic_kprobe_filter_arg+0x884> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x840, 0x884, arm64_l_884);
arm64_l_844:
	/* 0x844: lsl x10, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_848:
	/* 0x848: tst x10, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_84c:
	/* 0x84c: b.ne b5c <generic_kprobe_filter_arg+0xb5c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x84c, 0xb5c, arm64_l_b5c);
arm64_l_850:
	/* 0x850: b fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x850, 0xfc, arm64_l_fc);
arm64_l_854:
	/* 0x854: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_858:
	/* 0x858: b.eq f40 <generic_kprobe_filter_arg+0xf40> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x858, 0xf40, arm64_l_f40);
arm64_l_85c:
	/* 0x85c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_860:
	/* 0x860: b.ne 17fc <generic_kprobe_filter_arg+0x17fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x860, 0x17fc, arm64_l_17fc);
arm64_l_864:
	/* 0x864: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_868:
	/* 0x868: b.eq 874 <generic_kprobe_filter_arg+0x874> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x868, 0x874, arm64_l_874);
arm64_l_86c:
	/* 0x86c: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_870:
	/* 0x870: b.ne 17f0 <generic_kprobe_filter_arg+0x17f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x870, 0x17f0, arm64_l_17f0);
arm64_l_874:
	/* 0x874: ldr x11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_878:
	/* 0x878: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_87c:
	/* 0x87c: b.lt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x87c, 0x298, arm64_l_298);
arm64_l_880:
	/* 0x880: b 17fc <generic_kprobe_filter_arg+0x17fc> */
	ARM64_SIM_A64_JMP(0x880, 0x17fc, arm64_l_17fc);
arm64_l_884:
	/* 0x884: ldrb w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_888:
	/* 0x888: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_88c:
	/* 0x88c: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_890:
	/* 0x890: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_894:
	/* 0x894: str w8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_898:
	/* 0x898: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_89c:
	/* 0x89c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_8a0:
	/* 0x8a0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x8a4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_8a4:
	/* 0x8a4: cbz x0, f60 <generic_kprobe_filter_arg+0xf60> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x8a4, 0xf60, arm64_l_f60);
arm64_l_8a8:
	/* 0x8a8: ldr x8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_8ac:
	/* 0x8ac: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_8b0:
	/* 0x8b0: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_8b4:
	/* 0x8b4: str x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_8b8:
	/* 0x8b8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_8bc:
	/* 0x8bc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x8c0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_8c0:
	/* 0x8c0: ldr w8, [x29, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_8c4:
	/* 0x8c4: cmp w8, #0xb */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 11ULL);
arm64_l_8c8:
	/* 0x8c8: b.eq 1430 <generic_kprobe_filter_arg+0x1430> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x8c8, 0x1430, arm64_l_1430);
arm64_l_8cc:
	/* 0x8cc: cmp w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_8d0:
	/* 0x8d0: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_8d4:
	/* 0x8d4: b.eq 16ac <generic_kprobe_filter_arg+0x16ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x8d4, 0x16ac, arm64_l_16ac);
arm64_l_8d8:
	/* 0x8d8: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_8dc:
	/* 0x8dc: b 16b4 <generic_kprobe_filter_arg+0x16b4> */
	ARM64_SIM_A64_JMP(0x8dc, 0x16b4, arm64_l_16b4);
arm64_l_8e0:
	/* 0x8e0: ldr w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_8e4:
	/* 0x8e4: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_8e8:
	/* 0x8e8: adrp x0, 0 <string_postfix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_17));
arm64_l_8ec:
	/* 0x8ec: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_8f0:
	/* 0x8f0: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_8f4:
	/* 0x8f4: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_8f8:
	/* 0x8f8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_8fc:
	/* 0x8fc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_900:
	/* 0x900: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x904ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_904:
	/* 0x904: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_908:
	/* 0x908: cbz w24, 1890 <generic_kprobe_filter_arg+0x1890> */
	ARM64_SIM_A64_CBZ(ARM64_X24, 0x908, 0x1890, arm64_l_1890);
arm64_l_90c:
	/* 0x90c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_910:
	/* 0x910: cbz x0, 1894 <generic_kprobe_filter_arg+0x1894> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x910, 0x1894, arm64_l_1894);
arm64_l_914:
	/* 0x914: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_918:
	/* 0x918: adrp x0, 0 <string_postfix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap_18));
arm64_l_91c:
	/* 0x91c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_920:
	/* 0x920: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_924:
	/* 0x924: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_928:
	/* 0x928: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_92c:
	/* 0x92c: mov w23, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_930:
	/* 0x930: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x934ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_934:
	/* 0x934: cbz x0, 1888 <generic_kprobe_filter_arg+0x1888> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x934, 0x1888, arm64_l_1888);
arm64_l_938:
	/* 0x938: cmp w24, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_93c:
	/* 0x93c: mov w10, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_940:
	/* 0x940: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_944:
	/* 0x944: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_948:
	/* 0x948: add x9, x22, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_94c:
	/* 0x94c: sub x12, x23, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X23, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_950:
	/* 0x950: sub w13, w24, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_954:
	/* 0x954: sub w14, w24, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_958:
	/* 0x958: csel w10, w24, w10, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X10, ARM64_X24, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_95c:
	/* 0x95c: lsl w11, w10, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_960:
	/* 0x960: mov x10, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_964:
	/* 0x964: str w11, [x10], #5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 5ULL);
arm64_l_968:
	/* 0x968: neg x11, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X11, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_96c:
	/* 0x96c: add w15, w14, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X15, ARM64_X14, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_970:
	/* 0x970: cmp x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_974:
	/* 0x974: and x15, x15, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_978:
	/* 0x978: ldrb w15, [x9, x15] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X15, ARM64_X9, ARM64_X15, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X15, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_97c:
	/* 0x97c: sturb w15, [x10, #-1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X10, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 18446744073709551615ULL);
arm64_l_980:
	/* 0x980: b.eq 9a8 <generic_kprobe_filter_arg+0x9a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x980, 0x9a8, arm64_l_9a8);
arm64_l_984:
	/* 0x984: cmn x8, #0x7e */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 126ULL);
arm64_l_988:
	/* 0x988: b.eq 9a8 <generic_kprobe_filter_arg+0x9a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x988, 0x9a8, arm64_l_9a8);
arm64_l_98c:
	/* 0x98c: add w15, w13, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X15, ARM64_X13, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_990:
	/* 0x990: sub x8, x8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_994:
	/* 0x994: and x15, x15, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_998:
	/* 0x998: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_99c:
	/* 0x99c: ldrb w15, [x9, x15] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X15, ARM64_X9, ARM64_X15, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X15, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_9a0:
	/* 0x9a0: strb w15, [x10], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X10, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_9a4:
	/* 0x9a4: b.ne 96c <generic_kprobe_filter_arg+0x96c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x9a4, 0x96c, arm64_l_96c);
arm64_l_9a8:
	/* 0x9a8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_9ac:
	/* 0x9ac: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_9b0:
	/* 0x9b0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x9b4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_9b4:
	/* 0x9b4: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_9b8:
	/* 0x9b8: cset w23, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_9bc:
	/* 0x9bc: b 188c <generic_kprobe_filter_arg+0x188c> */
	ARM64_SIM_A64_JMP(0x9bc, 0x188c, arm64_l_188c);
arm64_l_9c0:
	/* 0x9c0: ldr w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_9c4:
	/* 0x9c4: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_9c8:
	/* 0x9c8: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_19));
arm64_l_9cc:
	/* 0x9cc: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_9d0:
	/* 0x9d0: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_9d4:
	/* 0x9d4: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_9d8:
	/* 0x9d8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_9dc:
	/* 0x9dc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_9e0:
	/* 0x9e0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x9e4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_9e4:
	/* 0x9e4: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_9e8:
	/* 0x9e8: cbz w24, 28ac <generic_kprobe_filter_arg+0x28ac> */
	ARM64_SIM_A64_CBZ(ARM64_X24, 0x9e8, 0x28ac, arm64_l_28ac);
arm64_l_9ec:
	/* 0x9ec: cbz x0, 28ac <generic_kprobe_filter_arg+0x28ac> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x9ec, 0x28ac, arm64_l_28ac);
arm64_l_9f0:
	/* 0x9f0: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_9f4:
	/* 0x9f4: adrp x0, 0 <string_prefix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap_20));
arm64_l_9f8:
	/* 0x9f8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_9fc:
	/* 0x9fc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a00:
	/* 0xa00: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_a04:
	/* 0xa04: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_a08:
	/* 0xa08: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xa0cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_a0c:
	/* 0xa0c: cbz x0, 1a34 <generic_kprobe_filter_arg+0x1a34> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xa0c, 0x1a34, arm64_l_1a34);
arm64_l_a10:
	/* 0xa10: cmp w24, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_a14:
	/* 0xa14: mov w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 255ULL);
arm64_l_a18:
	/* 0xa18: add x2, x22, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_a1c:
	/* 0xa1c: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a20:
	/* 0xa20: csel w1, w24, w8, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X1, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_a24:
	/* 0xa24: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a28:
	/* 0xa28: lsl w9, w1, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_a2c:
	/* 0xa2c: str w9, [x8], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_a30:
	/* 0xa30: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_a34:
	/* 0xa34: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a38:
	/* 0xa38: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xa3cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_a3c:
	/* 0xa3c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a40:
	/* 0xa40: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a44:
	/* 0xa44: mov x1, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a48:
	/* 0xa48: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xa4cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_a4c:
	/* 0xa4c: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_a50:
	/* 0xa50: cset w23, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_a54:
	/* 0xa54: b 1a38 <generic_kprobe_filter_arg+0x1a38> */
	ARM64_SIM_A64_JMP(0xa54, 0x1a38, arm64_l_1a38);
arm64_l_a58:
	/* 0xa58: ldrb w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_a5c:
	/* 0xa5c: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_a60:
	/* 0xa60: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_a64:
	/* 0xa64: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_a68:
	/* 0xa68: str w8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_a6c:
	/* 0xa6c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a70:
	/* 0xa70: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a74:
	/* 0xa74: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xa78ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_a78:
	/* 0xa78: cbz x0, 17d4 <generic_kprobe_filter_arg+0x17d4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xa78, 0x17d4, arm64_l_17d4);
arm64_l_a7c:
	/* 0xa7c: ldr w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a80:
	/* 0xa80: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_a84:
	/* 0xa84: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_a88:
	/* 0xa88: str x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_a8c:
	/* 0xa8c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a90:
	/* 0xa90: b 179c <generic_kprobe_filter_arg+0x179c> */
	ARM64_SIM_A64_JMP(0xa90, 0x179c, arm64_l_179c);
arm64_l_a94:
	/* 0xa94: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_a98:
	/* 0xa98: b.ne 17fc <generic_kprobe_filter_arg+0x17fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xa98, 0x17fc, arm64_l_17fc);
arm64_l_a9c:
	/* 0xa9c: ldr x11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_aa0:
	/* 0xaa0: tst x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_aa4:
	/* 0xaa4: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xaa4, 0x298, arm64_l_298);
arm64_l_aa8:
	/* 0xaa8: b 17fc <generic_kprobe_filter_arg+0x17fc> */
	ARM64_SIM_A64_JMP(0xaa8, 0x17fc, arm64_l_17fc);
arm64_l_aac:
	/* 0xaac: mov x10, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ab0:
	/* 0xab0: b adc <generic_kprobe_filter_arg+0xadc> */
	ARM64_SIM_A64_JMP(0xab0, 0xadc, arm64_l_adc);
arm64_l_ab4:
	/* 0xab4: ldrh w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ab8:
	/* 0xab8: mov x10, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_abc:
	/* 0xabc: strh w11, [sp, #134] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 134ULL);
arm64_l_ac0:
	/* 0xac0: ldrh w11, [x22, #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_ac4:
	/* 0xac4: strh w11, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_ac8:
	/* 0xac8: ldr x11, [x22, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_acc:
	/* 0xacc: str x11, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_ad0:
	/* 0xad0: ldr x11, [x22, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_ad4:
	/* 0xad4: add x22, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_ad8:
	/* 0xad8: str x11, [sp, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_adc:
	/* 0xadc: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ae0:
	/* 0xae0: cmp w8, #0x13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 19ULL);
arm64_l_ae4:
	/* 0xae4: b.le b0c <generic_kprobe_filter_arg+0xb0c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xae4, 0xb0c, arm64_l_b0c);
arm64_l_ae8:
	/* 0xae8: cmp w8, #0x17 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 23ULL);
arm64_l_aec:
	/* 0xaec: b.gt b34 <generic_kprobe_filter_arg+0xb34> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xaec, 0xb34, arm64_l_b34);
arm64_l_af0:
	/* 0xaf0: sub w9, w8, #0x14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_af4:
	/* 0xaf4: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_af8:
	/* 0xaf8: b.cc 1030 <generic_kprobe_filter_arg+0x1030> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xaf8, 0x1030, arm64_l_1030);
arm64_l_afc:
	/* 0xafc: sub w9, w8, #0x16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 22ULL);
arm64_l_b00:
	/* 0xb00: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_b04:
	/* 0xb04: b.cc 101c <generic_kprobe_filter_arg+0x101c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xb04, 0x101c, arm64_l_101c);
arm64_l_b08:
	/* 0xb08: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0xb08, 0x294, arm64_l_294);
arm64_l_b0c:
	/* 0xb0c: cmp w8, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_b10:
	/* 0xb10: b.le d58 <generic_kprobe_filter_arg+0xd58> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xb10, 0xd58, arm64_l_d58);
arm64_l_b14:
	/* 0xb14: cmp w8, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_b18:
	/* 0xb18: b.gt 100c <generic_kprobe_filter_arg+0x100c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xb18, 0x100c, arm64_l_100c);
arm64_l_b1c:
	/* 0xb1c: cmp w8, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_b20:
	/* 0xb20: b.eq 101c <generic_kprobe_filter_arg+0x101c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xb20, 0x101c, arm64_l_101c);
arm64_l_b24:
	/* 0xb24: cmp w8, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_b28:
	/* 0xb28: b.ne 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xb28, 0x294, arm64_l_294);
arm64_l_b2c:
	/* 0xb2c: ldrh w23, [x22, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_b30:
	/* 0xb30: b 1768 <generic_kprobe_filter_arg+0x1768> */
	ARM64_SIM_A64_JMP(0xb30, 0x1768, arm64_l_1768);
arm64_l_b34:
	/* 0xb34: cmp w8, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_b38:
	/* 0xb38: b.gt 1044 <generic_kprobe_filter_arg+0x1044> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xb38, 0x1044, arm64_l_1044);
arm64_l_b3c:
	/* 0xb3c: cmp w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_b40:
	/* 0xb40: b.eq 1074 <generic_kprobe_filter_arg+0x1074> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xb40, 0x1074, arm64_l_1074);
arm64_l_b44:
	/* 0xb44: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_b48:
	/* 0xb48: b.eq 1068 <generic_kprobe_filter_arg+0x1068> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xb48, 0x1068, arm64_l_1068);
arm64_l_b4c:
	/* 0xb4c: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0xb4c, 0x294, arm64_l_294);
arm64_l_b50:
	/* 0xb50: sub w10, w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_b54:
	/* 0xb54: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_b58:
	/* 0xb58: b.cs 14f0 <generic_kprobe_filter_arg+0x14f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xb58, 0x14f0, arm64_l_14f0);
arm64_l_b5c:
	/* 0xb5c: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_b60:
	/* 0xb60: b.ne d30 <generic_kprobe_filter_arg+0xd30> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xb60, 0xd30, arm64_l_d30);
arm64_l_b64:
	/* 0xb64: ldp x11, x10, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_b68:
	/* 0xb68: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_b6c:
	/* 0xb6c: b.eq b78 <generic_kprobe_filter_arg+0xb78> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xb6c, 0xb78, arm64_l_b78);
arm64_l_b70:
	/* 0xb70: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_b74:
	/* 0xb74: b.ne 16d8 <generic_kprobe_filter_arg+0x16d8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xb74, 0x16d8, arm64_l_16d8);
arm64_l_b78:
	/* 0xb78: ldr x8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b7c:
	/* 0xb7c: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_b80:
	/* 0xb80: b.gt 16ec <generic_kprobe_filter_arg+0x16ec> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xb80, 0x16ec, arm64_l_16ec);
arm64_l_b84:
	/* 0xb84: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_b88:
	/* 0xb88: b.le 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xb88, 0x298, arm64_l_298);
arm64_l_b8c:
	/* 0xb8c: b 16ec <generic_kprobe_filter_arg+0x16ec> */
	ARM64_SIM_A64_JMP(0xb8c, 0x16ec, arm64_l_16ec);
arm64_l_b90:
	/* 0xb90: cmp w8, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_b94:
	/* 0xb94: b.eq 1158 <generic_kprobe_filter_arg+0x1158> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xb94, 0x1158, arm64_l_1158);
arm64_l_b98:
	/* 0xb98: cmp w8, #0x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 34ULL);
arm64_l_b9c:
	/* 0xb9c: b.ne 1228 <generic_kprobe_filter_arg+0x1228> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xb9c, 0x1228, arm64_l_1228);
arm64_l_ba0:
	/* 0xba0: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ba4:
	/* 0xba4: mov w19, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_ba8:
	/* 0xba8: add x8, x29, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_bac:
	/* 0xbac: str x8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_bb0:
	/* 0xbb0: ldr x8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_bb4:
	/* 0xbb4: adrp x0, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_21));
arm64_l_bb8:
	/* 0xbb8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_bbc:
	/* 0xbbc: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_bc0:
	/* 0xbc0: ldr w8, [x8, x23, lsl #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X23, ARM64_MOD_LSL, 2, 0), 0ULL);
arm64_l_bc4:
	/* 0xbc4: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_bc8:
	/* 0xbc8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_bcc:
	/* 0xbcc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_bd0:
	/* 0xbd0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xbd4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_bd4:
	/* 0xbd4: cbz x0, 1210 <generic_kprobe_filter_arg+0x1210> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xbd4, 0x1210, arm64_l_1210);
arm64_l_bd8:
	/* 0xbd8: cbz w24, c54 <generic_kprobe_filter_arg+0xc54> */
	ARM64_SIM_A64_CBZ(ARM64_X24, 0xbd8, 0xc54, arm64_l_c54);
arm64_l_bdc:
	/* 0xbdc: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_be0:
	/* 0xbe0: mov x9, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_be4:
	/* 0xbe4: mov x10, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_be8:
	/* 0xbe8: b c00 <generic_kprobe_filter_arg+0xc00> */
	ARM64_SIM_A64_JMP(0xbe8, 0xc00, arm64_l_c00);
arm64_l_bec:
	/* 0xbec: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_bf0:
	/* 0xbf0: sub x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_bf4:
	/* 0xbf4: add x9, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_bf8:
	/* 0xbf8: cmp x8, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_bfc:
	/* 0xbfc: b.eq c54 <generic_kprobe_filter_arg+0xc54> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xbfc, 0xc54, arm64_l_c54);
arm64_l_c00:
	/* 0xc00: mov x11, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c04:
	/* 0xc04: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_c08:
	/* 0xc08: b.eq bec <generic_kprobe_filter_arg+0xbec> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xc08, 0xbec, arm64_l_bec);
arm64_l_c0c:
	/* 0xc0c: ldrb w12, [x0, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X0, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c10:
	/* 0xc10: cbz w12, c50 <generic_kprobe_filter_arg+0xc50> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0xc10, 0xc50, arm64_l_c50);
arm64_l_c14:
	/* 0xc14: ldrb w13, [x9, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c18:
	/* 0xc18: sub w14, w13, #0x41 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 65ULL);
arm64_l_c1c:
	/* 0xc1c: orr w15, w13, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_c20:
	/* 0xc20: cmp w14, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_c24:
	/* 0xc24: sub w14, w12, #0x41 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 65ULL);
arm64_l_c28:
	/* 0xc28: csel w13, w15, w13, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X13, ARM64_X15, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_c2c:
	/* 0xc2c: orr w15, w12, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_c30:
	/* 0xc30: cmp w14, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_c34:
	/* 0xc34: csel w12, w15, w12, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X12, ARM64_X15, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_c38:
	/* 0xc38: cmp x11, #0x62 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 98ULL);
arm64_l_c3c:
	/* 0xc3c: b.hi bec <generic_kprobe_filter_arg+0xbec> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xc3c, 0xbec, arm64_l_bec);
arm64_l_c40:
	/* 0xc40: add x11, x11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_c44:
	/* 0xc44: cmp w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_c48:
	/* 0xc48: b.eq c04 <generic_kprobe_filter_arg+0xc04> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xc48, 0xc04, arm64_l_c04);
arm64_l_c4c:
	/* 0xc4c: b bec <generic_kprobe_filter_arg+0xbec> */
	ARM64_SIM_A64_JMP(0xc4c, 0xbec, arm64_l_bec);
arm64_l_c50:
	/* 0xc50: tbz w8, #31, 1d24 <generic_kprobe_filter_arg+0x1d24> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 31, 0xc50, 0x1d24, arm64_l_1d24);
arm64_l_c54:
	/* 0xc54: ldr w9, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_c58:
	/* 0xc58: add w8, w19, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_c5c:
	/* 0xc5c: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_c60:
	/* 0xc60: b.cs 1210 <generic_kprobe_filter_arg+0x1210> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xc60, 0x1210, arm64_l_1210);
arm64_l_c64:
	/* 0xc64: add x23, x23, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_c68:
	/* 0xc68: add w19, w19, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_c6c:
	/* 0xc6c: cmp x23, #0x64 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 100ULL);
arm64_l_c70:
	/* 0xc70: b.ne bb0 <generic_kprobe_filter_arg+0xbb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xc70, 0xbb0, arm64_l_bb0);
arm64_l_c74:
	/* 0xc74: b 1210 <generic_kprobe_filter_arg+0x1210> */
	ARM64_SIM_A64_JMP(0xc74, 0x1210, arm64_l_1210);
arm64_l_c78:
	/* 0xc78: ldr w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_c7c:
	/* 0xc7c: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_c80:
	/* 0xc80: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_19));
arm64_l_c84:
	/* 0xc84: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_c88:
	/* 0xc88: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_c8c:
	/* 0xc8c: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_c90:
	/* 0xc90: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_c94:
	/* 0xc94: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c98:
	/* 0xc98: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xc9cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_c9c:
	/* 0xc9c: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ca0:
	/* 0xca0: cbz w24, 1218 <generic_kprobe_filter_arg+0x1218> */
	ARM64_SIM_A64_CBZ(ARM64_X24, 0xca0, 0x1218, arm64_l_1218);
arm64_l_ca4:
	/* 0xca4: cbz x0, 1218 <generic_kprobe_filter_arg+0x1218> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xca4, 0x1218, arm64_l_1218);
arm64_l_ca8:
	/* 0xca8: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_cac:
	/* 0xcac: adrp x0, 0 <string_prefix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap_20));
arm64_l_cb0:
	/* 0xcb0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_cb4:
	/* 0xcb4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cb8:
	/* 0xcb8: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_cbc:
	/* 0xcbc: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_cc0:
	/* 0xcc0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xcc4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_cc4:
	/* 0xcc4: cbz x0, 1210 <generic_kprobe_filter_arg+0x1210> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xcc4, 0x1210, arm64_l_1210);
arm64_l_cc8:
	/* 0xcc8: cmp w24, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_ccc:
	/* 0xccc: mov w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 255ULL);
arm64_l_cd0:
	/* 0xcd0: mov x2, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_cd4:
	/* 0xcd4: csel w1, w24, w8, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X1, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_cd8:
	/* 0xcd8: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_cdc:
	/* 0xcdc: mov x24, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ce0:
	/* 0xce0: lsl w9, w1, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_ce4:
	/* 0xce4: str w9, [x8], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_ce8:
	/* 0xce8: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_cec:
	/* 0xcec: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_cf0:
	/* 0xcf0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xcf4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_cf4:
	/* 0xcf4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_cf8:
	/* 0xcf8: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_cfc:
	/* 0xcfc: mov x1, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d00:
	/* 0xd00: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xd04ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_d04:
	/* 0xd04: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_d08:
	/* 0xd08: cset w23, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_d0c:
	/* 0xd0c: b 1214 <generic_kprobe_filter_arg+0x1214> */
	ARM64_SIM_A64_JMP(0xd0c, 0x1214, arm64_l_1214);
arm64_l_d10:
	/* 0xd10: cmp w24, #0x1fe */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 510ULL);
arm64_l_d14:
	/* 0xd14: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_d18:
	/* 0xd18: b.ls 1250 <generic_kprobe_filter_arg+0x1250> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0xd18, 0x1250, arm64_l_1250);
arm64_l_d1c:
	/* 0xd1c: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d20:
	/* 0xd20: ldr w8, [x29, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_d24:
	/* 0xd24: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_d28:
	/* 0xd28: b.ls 1234 <generic_kprobe_filter_arg+0x1234> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0xd28, 0x1234, arm64_l_1234);
arm64_l_d2c:
	/* 0xd2c: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0xd2c, 0x294, arm64_l_294);
arm64_l_d30:
	/* 0xd30: ldp x11, x8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_d34:
	/* 0xd34: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_d38:
	/* 0xd38: b.eq d44 <generic_kprobe_filter_arg+0xd44> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd38, 0xd44, arm64_l_d44);
arm64_l_d3c:
	/* 0xd3c: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_d40:
	/* 0xd40: b.ne 1724 <generic_kprobe_filter_arg+0x1724> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xd40, 0x1724, arm64_l_1724);
arm64_l_d44:
	/* 0xd44: ldr x10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d48:
	/* 0xd48: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d4c:
	/* 0xd4c: ccmp x10, x8, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_d50:
	/* 0xd50: cset w8, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_d54:
	/* 0xd54: b 1734 <generic_kprobe_filter_arg+0x1734> */
	ARM64_SIM_A64_JMP(0xd54, 0x1734, arm64_l_1734);
arm64_l_d58:
	/* 0xd58: cmp w8, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_d5c:
	/* 0xd5c: b.eq 1074 <generic_kprobe_filter_arg+0x1074> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd5c, 0x1074, arm64_l_1074);
arm64_l_d60:
	/* 0xd60: cmp w8, #0xe */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 14ULL);
arm64_l_d64:
	/* 0xd64: b.eq 1068 <generic_kprobe_filter_arg+0x1068> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd64, 0x1068, arm64_l_1068);
arm64_l_d68:
	/* 0xd68: cmp w8, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_d6c:
	/* 0xd6c: b.eq 1030 <generic_kprobe_filter_arg+0x1030> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd6c, 0x1030, arm64_l_1030);
arm64_l_d70:
	/* 0xd70: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0xd70, 0x294, arm64_l_294);
arm64_l_d74:
	/* 0xd74: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_d78:
	/* 0xd78: b.gt 12f8 <generic_kprobe_filter_arg+0x12f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xd78, 0x12f8, arm64_l_12f8);
arm64_l_d7c:
	/* 0xd7c: cmp w8, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_d80:
	/* 0xd80: b.eq 1450 <generic_kprobe_filter_arg+0x1450> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd80, 0x1450, arm64_l_1450);
arm64_l_d84:
	/* 0xd84: cmp w8, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_d88:
	/* 0xd88: b.ne 2cec <generic_kprobe_filter_arg+0x2cec> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xd88, 0x2cec, arm64_l_2cec);
arm64_l_d8c:
	/* 0xd8c: ldr w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_d90:
	/* 0xd90: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_d94:
	/* 0xd94: adrp x0, 0 <string_postfix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_17));
arm64_l_d98:
	/* 0xd98: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_d9c:
	/* 0xd9c: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_da0:
	/* 0xda0: mov w19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_da4:
	/* 0xda4: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_da8:
	/* 0xda8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_dac:
	/* 0xdac: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_db0:
	/* 0xdb0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xdb4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_db4:
	/* 0xdb4: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_db8:
	/* 0xdb8: cbz w22, 2cdc <generic_kprobe_filter_arg+0x2cdc> */
	ARM64_SIM_A64_CBZ(ARM64_X22, 0xdb8, 0x2cdc, arm64_l_2cdc);
arm64_l_dbc:
	/* 0xdbc: cbz x0, 2cdc <generic_kprobe_filter_arg+0x2cdc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xdbc, 0x2cdc, arm64_l_2cdc);
arm64_l_dc0:
	/* 0xdc0: mov x23, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_dc4:
	/* 0xdc4: adrp x0, 0 <string_postfix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap_18));
arm64_l_dc8:
	/* 0xdc8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_dcc:
	/* 0xdcc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_dd0:
	/* 0xdd0: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_dd4:
	/* 0xdd4: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_dd8:
	/* 0xdd8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xddcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_ddc:
	/* 0xddc: cbz x0, 2cd8 <generic_kprobe_filter_arg+0x2cd8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xddc, 0x2cd8, arm64_l_2cd8);
arm64_l_de0:
	/* 0xde0: cmp w22, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_de4:
	/* 0xde4: mov w9, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_de8:
	/* 0xde8: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_dec:
	/* 0xdec: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_df0:
	/* 0xdf0: sub x11, x19, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X19, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_df4:
	/* 0xdf4: sub w12, w22, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_df8:
	/* 0xdf8: sub w13, w22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_dfc:
	/* 0xdfc: csel w9, w22, w9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X9, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_e00:
	/* 0xe00: lsl w10, w9, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_e04:
	/* 0xe04: mov x9, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e08:
	/* 0xe08: str w10, [x9], #5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 5ULL);
arm64_l_e0c:
	/* 0xe0c: neg x10, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e10:
	/* 0xe10: add w14, w13, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X13, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_e14:
	/* 0xe14: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e18:
	/* 0xe18: and x14, x14, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_e1c:
	/* 0xe1c: ldrb w14, [x24, x14] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X14, ARM64_X24, ARM64_X14, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X14, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e20:
	/* 0xe20: sturb w14, [x9, #-1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 18446744073709551615ULL);
arm64_l_e24:
	/* 0xe24: b.eq e4c <generic_kprobe_filter_arg+0xe4c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe24, 0xe4c, arm64_l_e4c);
arm64_l_e28:
	/* 0xe28: cmn x8, #0x7e */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 126ULL);
arm64_l_e2c:
	/* 0xe2c: b.eq e4c <generic_kprobe_filter_arg+0xe4c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe2c, 0xe4c, arm64_l_e4c);
arm64_l_e30:
	/* 0xe30: add w14, w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_e34:
	/* 0xe34: sub x8, x8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_e38:
	/* 0xe38: and x14, x14, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_e3c:
	/* 0xe3c: cmp x10, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e40:
	/* 0xe40: ldrb w14, [x24, x14] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X14, ARM64_X24, ARM64_X14, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X14, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e44:
	/* 0xe44: strb w14, [x9], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_e48:
	/* 0xe48: b.ne e10 <generic_kprobe_filter_arg+0xe10> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xe48, 0xe10, arm64_l_e10);
arm64_l_e4c:
	/* 0xe4c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_e50:
	/* 0xe50: mov x0, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e54:
	/* 0xe54: b 2cc8 <generic_kprobe_filter_arg+0x2cc8> */
	ARM64_SIM_A64_JMP(0xe54, 0x2cc8, arm64_l_2cc8);
arm64_l_e58:
	/* 0xe58: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_e5c:
	/* 0xe5c: b.ne 1e80 <generic_kprobe_filter_arg+0x1e80> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xe5c, 0x1e80, arm64_l_1e80);
arm64_l_e60:
	/* 0xe60: ldr w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e64:
	/* 0xe64: tst w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e68:
	/* 0xe68: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xe68, 0x298, arm64_l_298);
arm64_l_e6c:
	/* 0xe6c: b 1e80 <generic_kprobe_filter_arg+0x1e80> */
	ARM64_SIM_A64_JMP(0xe6c, 0x1e80, arm64_l_1e80);
arm64_l_e70:
	/* 0xe70: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_e74:
	/* 0xe74: tst x9, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_e78:
	/* 0xe78: b.ne 13b8 <generic_kprobe_filter_arg+0x13b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xe78, 0x13b8, arm64_l_13b8);
arm64_l_e7c:
	/* 0xe7c: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_e80:
	/* 0xe80: tst x9, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_e84:
	/* 0xe84: b.eq fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe84, 0xfc, arm64_l_fc);
arm64_l_e88:
	/* 0xe88: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_e8c:
	/* 0xe8c: b.ne 1a40 <generic_kprobe_filter_arg+0x1a40> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xe8c, 0x1a40, arm64_l_1a40);
arm64_l_e90:
	/* 0xe90: ldr w9, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_e94:
	/* 0xe94: ldrb w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e98:
	/* 0xe98: b ec4 <generic_kprobe_filter_arg+0xec4> */
	ARM64_SIM_A64_JMP(0xe98, 0xec4, arm64_l_ec4);
arm64_l_e9c:
	/* 0xe9c: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_ea0:
	/* 0xea0: tst x9, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_ea4:
	/* 0xea4: b.ne 13f4 <generic_kprobe_filter_arg+0x13f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xea4, 0x13f4, arm64_l_13f4);
arm64_l_ea8:
	/* 0xea8: lsl x9, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_eac:
	/* 0xeac: tst x9, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_eb0:
	/* 0xeb0: b.eq fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xeb0, 0xfc, arm64_l_fc);
arm64_l_eb4:
	/* 0xeb4: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_eb8:
	/* 0xeb8: b.ne 1a64 <generic_kprobe_filter_arg+0x1a64> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xeb8, 0x1a64, arm64_l_1a64);
arm64_l_ebc:
	/* 0xebc: ldr w9, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_ec0:
	/* 0xec0: ldrh w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ec4:
	/* 0xec4: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ec8:
	/* 0xec8: b.hi ed8 <generic_kprobe_filter_arg+0xed8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xec8, 0xed8, arm64_l_ed8);
arm64_l_ecc:
	/* 0xecc: ldr w9, [x29, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_ed0:
	/* 0xed0: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ed4:
	/* 0xed4: b.cs 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xed4, 0x298, arm64_l_298);
arm64_l_ed8:
	/* 0xed8: ldr w9, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_edc:
	/* 0xedc: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_ee0:
	/* 0xee0: b.cc fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xee0, 0xfc, arm64_l_fc);
arm64_l_ee4:
	/* 0xee4: ldr w10, [x29, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_ee8:
	/* 0xee8: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_eec:
	/* 0xeec: b.hi efc <generic_kprobe_filter_arg+0xefc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xeec, 0xefc, arm64_l_efc);
arm64_l_ef0:
	/* 0xef0: ldr w10, [x29, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_ef4:
	/* 0xef4: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ef8:
	/* 0xef8: b.cs 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xef8, 0x298, arm64_l_298);
arm64_l_efc:
	/* 0xefc: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_f00:
	/* 0xf00: b.cc fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xf00, 0xfc, arm64_l_fc);
arm64_l_f04:
	/* 0xf04: ldr w10, [x29, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_f08:
	/* 0xf08: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f0c:
	/* 0xf0c: b.hi f1c <generic_kprobe_filter_arg+0xf1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xf0c, 0xf1c, arm64_l_f1c);
arm64_l_f10:
	/* 0xf10: ldr w10, [x29, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_f14:
	/* 0xf14: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f18:
	/* 0xf18: b.cs 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xf18, 0x298, arm64_l_298);
arm64_l_f1c:
	/* 0xf1c: cmp w9, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_f20:
	/* 0xf20: b.cc fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xf20, 0xfc, arm64_l_fc);
arm64_l_f24:
	/* 0xf24: ldr w9, [x29, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_f28:
	/* 0xf28: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f2c:
	/* 0xf2c: b.hi fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xf2c, 0xfc, arm64_l_fc);
arm64_l_f30:
	/* 0xf30: ldr w9, [x29, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_f34:
	/* 0xf34: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f38:
	/* 0xf38: b.cs 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xf38, 0x298, arm64_l_298);
arm64_l_f3c:
	/* 0xf3c: b fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0xf3c, 0xfc, arm64_l_fc);
arm64_l_f40:
	/* 0xf40: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_f44:
	/* 0xf44: b.eq f50 <generic_kprobe_filter_arg+0xf50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf44, 0xf50, arm64_l_f50);
arm64_l_f48:
	/* 0xf48: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_f4c:
	/* 0xf4c: b.ne 17e0 <generic_kprobe_filter_arg+0x17e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xf4c, 0x17e0, arm64_l_17e0);
arm64_l_f50:
	/* 0xf50: ldr x11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f54:
	/* 0xf54: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f58:
	/* 0xf58: b.gt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xf58, 0x298, arm64_l_298);
arm64_l_f5c:
	/* 0xf5c: b 17fc <generic_kprobe_filter_arg+0x17fc> */
	ARM64_SIM_A64_JMP(0xf5c, 0x17fc, arm64_l_17fc);
arm64_l_f60:
	/* 0xf60: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_f64:
	/* 0xf64: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f68:
	/* 0xf68: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_f6c:
	/* 0xf6c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f70:
	/* 0xf70: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_f74:
	/* 0xf74: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0xf74, 0x294, arm64_l_294);
arm64_l_f78:
	/* 0xf78: and w8, w24, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_f7c:
	/* 0xf7c: cmp w8, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_f80:
	/* 0xf80: b.hi 1550 <generic_kprobe_filter_arg+0x1550> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xf80, 0x1550, arm64_l_1550);
arm64_l_f84:
	/* 0xf84: and w8, w24, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_f88:
	/* 0xf88: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_f8c:
	/* 0xf8c: tst w24, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_f90:
	/* 0xf90: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_f94:
	/* 0xf94: mov w9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_f98:
	/* 0xf98: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_f9c:
	/* 0xf9c: msub w8, w8, w9, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MSUB, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_X24, ARM64_WIDTH_32, 0, 0);
arm64_l_fa0:
	/* 0xfa0: b.eq fb0 <generic_kprobe_filter_arg+0xfb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xfa0, 0xfb0, arm64_l_fb0);
arm64_l_fa4:
	/* 0xfa4: tst w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_fa8:
	/* 0xfa8: mov w11, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_fac:
	/* 0xfac: b.eq fc4 <generic_kprobe_filter_arg+0xfc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xfac, 0xfc4, arm64_l_fc4);
arm64_l_fb0:
	/* 0xfb0: sub w8, w24, w8, uxtb */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_UXTB, 0), 0);
arm64_l_fb4:
	/* 0xfb4: and w9, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_fb8:
	/* 0xfb8: add w11, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_fbc:
	/* 0xfbc: cmp w9, #0x78 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 120ULL);
arm64_l_fc0:
	/* 0xfc0: b.hi 1564 <generic_kprobe_filter_arg+0x1564> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xfc0, 0x1564, arm64_l_1564);
arm64_l_fc4:
	/* 0xfc4: and w8, w11, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_fc8:
	/* 0xfc8: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_fcc:
	/* 0xfcc: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_fd0:
	/* 0xfd0: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_fd4:
	/* 0xfd4: sub w10, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_fd8:
	/* 0xfd8: b 1574 <generic_kprobe_filter_arg+0x1574> */
	ARM64_SIM_A64_JMP(0xfd8, 0x1574, arm64_l_1574);
arm64_l_fdc:
	/* 0xfdc: ldp w11, w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_fe0:
	/* 0xfe0: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_fe4:
	/* 0xfe4: b.hi 1cd8 <generic_kprobe_filter_arg+0x1cd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xfe4, 0x1cd8, arm64_l_1cd8);
arm64_l_fe8:
	/* 0xfe8: lsl w10, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_fec:
	/* 0xfec: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_ff0:
	/* 0xff0: tst w10, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ff4:
	/* 0xff4: b.eq 1cd8 <generic_kprobe_filter_arg+0x1cd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xff4, 0x1cd8, arm64_l_1cd8);
arm64_l_ff8:
	/* 0xff8: ldr w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ffc:
	/* 0xffc: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1000:
	/* 0x1000: ccmp w10, w8, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_1004:
	/* 0x1004: cset w8, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_1008:
	/* 0x1008: b 1ce8 <generic_kprobe_filter_arg+0x1ce8> */
	ARM64_SIM_A64_JMP(0x1008, 0x1ce8, arm64_l_1ce8);
arm64_l_100c:
	/* 0x100c: cmp w8, #0x12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_1010:
	/* 0x1010: b.eq 1030 <generic_kprobe_filter_arg+0x1030> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1010, 0x1030, arm64_l_1030);
arm64_l_1014:
	/* 0x1014: cmp w8, #0x13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 19ULL);
arm64_l_1018:
	/* 0x1018: b.ne 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1018, 0x294, arm64_l_294);
arm64_l_101c:
	/* 0x101c: ldrh w24, [x22, #34] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 34ULL);
arm64_l_1020:
	/* 0x1020: mov w11, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1024:
	/* 0x1024: mov w13, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1028:
	/* 0x1028: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_102c:
	/* 0x102c: b 1080 <generic_kprobe_filter_arg+0x1080> */
	ARM64_SIM_A64_JMP(0x102c, 0x1080, arm64_l_1080);
arm64_l_1030:
	/* 0x1030: ldrh w24, [x22, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1034:
	/* 0x1034: mov w11, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1038:
	/* 0x1038: mov w13, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_103c:
	/* 0x103c: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1040:
	/* 0x1040: b 1080 <generic_kprobe_filter_arg+0x1080> */
	ARM64_SIM_A64_JMP(0x1040, 0x1080, arm64_l_1080);
arm64_l_1044:
	/* 0x1044: cmp w8, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_1048:
	/* 0x1048: b.eq 1764 <generic_kprobe_filter_arg+0x1764> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1048, 0x1764, arm64_l_1764);
arm64_l_104c:
	/* 0x104c: cmp w8, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_1050:
	/* 0x1050: b.ne 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1050, 0x294, arm64_l_294);
arm64_l_1054:
	/* 0x1054: cmp w9, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_1058:
	/* 0x1058: b.ne 1db0 <generic_kprobe_filter_arg+0x1db0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1058, 0x1db0, arm64_l_1db0);
arm64_l_105c:
	/* 0x105c: cbnz x10, 1dc0 <generic_kprobe_filter_arg+0x1dc0> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0x105c, 0x1dc0, arm64_l_1dc0);
arm64_l_1060:
	/* 0x1060: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1064:
	/* 0x1064: b 1dd4 <generic_kprobe_filter_arg+0x1dd4> */
	ARM64_SIM_A64_JMP(0x1064, 0x1dd4, arm64_l_1dd4);
arm64_l_1068:
	/* 0x1068: ldp w11, w13, [x22, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_106c:
	/* 0x106c: ldr x19, [x22, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1070:
	/* 0x1070: b 107c <generic_kprobe_filter_arg+0x107c> */
	ARM64_SIM_A64_JMP(0x1070, 0x107c, arm64_l_107c);
arm64_l_1074:
	/* 0x1074: ldp w11, w13, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1078:
	/* 0x1078: ldr x19, [x22, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_107c:
	/* 0x107c: mov x24, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1080:
	/* 0x1080: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1084:
	/* 0x1084: cmp w8, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1088:
	/* 0x1088: b.gt 10b4 <generic_kprobe_filter_arg+0x10b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1088, 0x10b4, arm64_l_10b4);
arm64_l_108c:
	/* 0x108c: sub w9, w8, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1090:
	/* 0x1090: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1094:
	/* 0x1094: b.cc 10e0 <generic_kprobe_filter_arg+0x10e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1094, 0x10e0, arm64_l_10e0);
arm64_l_1098:
	/* 0x1098: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_109c:
	/* 0x109c: sub w9, w8, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_10a0:
	/* 0x10a0: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_10a4:
	/* 0x10a4: b.cc 12c4 <generic_kprobe_filter_arg+0x12c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x10a4, 0x12c4, arm64_l_12c4);
arm64_l_10a8:
	/* 0x10a8: cmp w8, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_10ac:
	/* 0x10ac: b.eq 1768 <generic_kprobe_filter_arg+0x1768> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x10ac, 0x1768, arm64_l_1768);
arm64_l_10b0:
	/* 0x10b0: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x10b0, 0x294, arm64_l_294);
arm64_l_10b4:
	/* 0x10b4: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_10b8:
	/* 0x10b8: b.hi 12b4 <generic_kprobe_filter_arg+0x12b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x10b8, 0x12b4, arm64_l_12b4);
arm64_l_10bc:
	/* 0x10bc: lsl w9, w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_10c0:
	/* 0x10c0: mov w10, #0x500000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5242880ULL);
arm64_l_10c4:
	/* 0x10c4: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_10c8:
	/* 0x10c8: b.ne 1530 <generic_kprobe_filter_arg+0x1530> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x10c8, 0x1530, arm64_l_1530);
arm64_l_10cc:
	/* 0x10cc: mov w10, #0xa00000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10485760ULL);
arm64_l_10d0:
	/* 0x10d0: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_10d4:
	/* 0x10d4: b.ne 1540 <generic_kprobe_filter_arg+0x1540> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x10d4, 0x1540, arm64_l_1540);
arm64_l_10d8:
	/* 0x10d8: tst w9, #0x3000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50331648ULL);
arm64_l_10dc:
	/* 0x10dc: b.eq 12b4 <generic_kprobe_filter_arg+0x12b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x10dc, 0x12b4, arm64_l_12b4);
arm64_l_10e0:
	/* 0x10e0: ldrh w8, [x22, #38] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 38ULL);
arm64_l_10e4:
	/* 0x10e4: cmp w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_10e8:
	/* 0x10e8: b.eq 163c <generic_kprobe_filter_arg+0x163c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x10e8, 0x163c, arm64_l_163c);
arm64_l_10ec:
	/* 0x10ec: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_10f0:
	/* 0x10f0: b.ne 16c8 <generic_kprobe_filter_arg+0x16c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x10f0, 0x16c8, arm64_l_16c8);
arm64_l_10f4:
	/* 0x10f4: ldr w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_10f8:
	/* 0x10f8: adrp x0, 0 <addr4lpm_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&addr4lpm_maps_0));
arm64_l_10fc:
	/* 0x10fc: add x9, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1100:
	/* 0x1100: add x1, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1104:
	/* 0x1104: str w8, [sp, #172] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 172ULL);
arm64_l_1108:
	/* 0x1108: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_110c:
	/* 0x110c: mov w22, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1110:
	/* 0x1110: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1114:
	/* 0x1114: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1118ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1118:
	/* 0x1118: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_111c:
	/* 0x111c: cbz x0, 1f48 <generic_kprobe_filter_arg+0x1f48> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x111c, 0x1f48, arm64_l_1f48);
arm64_l_1120:
	/* 0x1120: mov w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 32ULL);
arm64_l_1124:
	/* 0x1124: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1128:
	/* 0x1128: stp w8, w22, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_112c:
	/* 0x112c: b 1684 <generic_kprobe_filter_arg+0x1684> */
	ARM64_SIM_A64_JMP(0x112c, 0x1684, arm64_l_1684);
arm64_l_1130:
	/* 0x1130: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1134:
	/* 0x1134: b.hi 1e64 <generic_kprobe_filter_arg+0x1e64> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1134, 0x1e64, arm64_l_1e64);
arm64_l_1138:
	/* 0x1138: lsl w11, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X11, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_113c:
	/* 0x113c: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1140:
	/* 0x1140: tst w11, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X11, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1144:
	/* 0x1144: b.eq 1e64 <generic_kprobe_filter_arg+0x1e64> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1144, 0x1e64, arm64_l_1e64);
arm64_l_1148:
	/* 0x1148: ldr w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_114c:
	/* 0x114c: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1150:
	/* 0x1150: b.gt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1150, 0x298, arm64_l_298);
arm64_l_1154:
	/* 0x1154: b 1e80 <generic_kprobe_filter_arg+0x1e80> */
	ARM64_SIM_A64_JMP(0x1154, 0x1e80, arm64_l_1e80);
arm64_l_1158:
	/* 0x1158: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_115c:
	/* 0x115c: mov w23, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1160:
	/* 0x1160: add x8, x29, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1164:
	/* 0x1164: str x8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1168:
	/* 0x1168: ldr x8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_116c:
	/* 0x116c: adrp x0, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_21));
arm64_l_1170:
	/* 0x1170: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1174:
	/* 0x1174: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1178:
	/* 0x1178: ldr w8, [x8, x19, lsl #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X19, ARM64_MOD_LSL, 2, 0), 0ULL);
arm64_l_117c:
	/* 0x117c: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1180:
	/* 0x1180: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1184:
	/* 0x1184: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1188:
	/* 0x1188: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x118cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_118c:
	/* 0x118c: cbz x0, 1210 <generic_kprobe_filter_arg+0x1210> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x118c, 0x1210, arm64_l_1210);
arm64_l_1190:
	/* 0x1190: cbz w24, 11f0 <generic_kprobe_filter_arg+0x11f0> */
	ARM64_SIM_A64_CBZ(ARM64_X24, 0x1190, 0x11f0, arm64_l_11f0);
arm64_l_1194:
	/* 0x1194: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1198:
	/* 0x1198: mov x9, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_119c:
	/* 0x119c: mov x10, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11a0:
	/* 0x11a0: b 11b8 <generic_kprobe_filter_arg+0x11b8> */
	ARM64_SIM_A64_JMP(0x11a0, 0x11b8, arm64_l_11b8);
arm64_l_11a4:
	/* 0x11a4: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_11a8:
	/* 0x11a8: sub x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_11ac:
	/* 0x11ac: add x9, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_11b0:
	/* 0x11b0: cmp x8, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_11b4:
	/* 0x11b4: b.eq 11f0 <generic_kprobe_filter_arg+0x11f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x11b4, 0x11f0, arm64_l_11f0);
arm64_l_11b8:
	/* 0x11b8: mov x11, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11bc:
	/* 0x11bc: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11c0:
	/* 0x11c0: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_11c4:
	/* 0x11c4: b.eq 11a4 <generic_kprobe_filter_arg+0x11a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x11c4, 0x11a4, arm64_l_11a4);
arm64_l_11c8:
	/* 0x11c8: ldrb w12, [x0, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X0, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_11cc:
	/* 0x11cc: cbz w12, 11ec <generic_kprobe_filter_arg+0x11ec> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0x11cc, 0x11ec, arm64_l_11ec);
arm64_l_11d0:
	/* 0x11d0: cmp x11, #0x62 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 98ULL);
arm64_l_11d4:
	/* 0x11d4: b.hi 11a4 <generic_kprobe_filter_arg+0x11a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x11d4, 0x11a4, arm64_l_11a4);
arm64_l_11d8:
	/* 0x11d8: ldrb w13, [x9, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_11dc:
	/* 0x11dc: add x11, x11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_11e0:
	/* 0x11e0: cmp w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_11e4:
	/* 0x11e4: b.eq 11c0 <generic_kprobe_filter_arg+0x11c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x11e4, 0x11c0, arm64_l_11c0);
arm64_l_11e8:
	/* 0x11e8: b 11a4 <generic_kprobe_filter_arg+0x11a4> */
	ARM64_SIM_A64_JMP(0x11e8, 0x11a4, arm64_l_11a4);
arm64_l_11ec:
	/* 0x11ec: tbz w8, #31, 1d24 <generic_kprobe_filter_arg+0x1d24> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 31, 0x11ec, 0x1d24, arm64_l_1d24);
arm64_l_11f0:
	/* 0x11f0: ldr w9, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_11f4:
	/* 0x11f4: add w8, w23, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_11f8:
	/* 0x11f8: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_11fc:
	/* 0x11fc: b.cs 1210 <generic_kprobe_filter_arg+0x1210> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x11fc, 0x1210, arm64_l_1210);
arm64_l_1200:
	/* 0x1200: add x19, x19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1204:
	/* 0x1204: add w23, w23, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1208:
	/* 0x1208: cmp x19, #0x64 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 100ULL);
arm64_l_120c:
	/* 0x120c: b.ne 1168 <generic_kprobe_filter_arg+0x1168> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x120c, 0x1168, arm64_l_1168);
arm64_l_1210:
	/* 0x1210: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1214:
	/* 0x1214: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1218:
	/* 0x1218: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_121c:
	/* 0x121c: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1220:
	/* 0x1220: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1224:
	/* 0x1224: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1228:
	/* 0x1228: ldr w8, [x29, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_122c:
	/* 0x122c: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_1230:
	/* 0x1230: b.hi 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1230, 0x294, arm64_l_294);
arm64_l_1234:
	/* 0x1234: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_1238:
	/* 0x1238: lsl x8, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_123c:
	/* 0x123c: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_1240:
	/* 0x1240: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_1244:
	/* 0x1244: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1248:
	/* 0x1248: b.ne 2d14 <generic_kprobe_filter_arg+0x2d14> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1248, 0x2d14, arm64_l_2d14);
arm64_l_124c:
	/* 0x124c: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x124c, 0x294, arm64_l_294);
arm64_l_1250:
	/* 0x1250: and w8, w24, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1254:
	/* 0x1254: cmp w8, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1258:
	/* 0x1258: b.hi 18d0 <generic_kprobe_filter_arg+0x18d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1258, 0x18d0, arm64_l_18d0);
arm64_l_125c:
	/* 0x125c: and w8, w24, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1260:
	/* 0x1260: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_1264:
	/* 0x1264: tst w24, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1268:
	/* 0x1268: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_126c:
	/* 0x126c: mov w9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_1270:
	/* 0x1270: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_1274:
	/* 0x1274: msub w8, w8, w9, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MSUB, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_X24, ARM64_WIDTH_32, 0, 0);
arm64_l_1278:
	/* 0x1278: b.eq 1288 <generic_kprobe_filter_arg+0x1288> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1278, 0x1288, arm64_l_1288);
arm64_l_127c:
	/* 0x127c: tst w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1280:
	/* 0x1280: mov w11, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1284:
	/* 0x1284: b.eq 129c <generic_kprobe_filter_arg+0x129c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1284, 0x129c, arm64_l_129c);
arm64_l_1288:
	/* 0x1288: sub w8, w24, w8, uxtb */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_UXTB, 0), 0);
arm64_l_128c:
	/* 0x128c: and w9, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1290:
	/* 0x1290: add w11, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1294:
	/* 0x1294: cmp w9, #0x78 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 120ULL);
arm64_l_1298:
	/* 0x1298: b.hi 18e4 <generic_kprobe_filter_arg+0x18e4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1298, 0x18e4, arm64_l_18e4);
arm64_l_129c:
	/* 0x129c: and w8, w11, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_12a0:
	/* 0x12a0: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_12a4:
	/* 0x12a4: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_12a8:
	/* 0x12a8: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_12ac:
	/* 0x12ac: sub w10, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_12b0:
	/* 0x12b0: b 18f4 <generic_kprobe_filter_arg+0x18f4> */
	ARM64_SIM_A64_JMP(0x12b0, 0x18f4, arm64_l_18f4);
arm64_l_12b4:
	/* 0x12b4: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_12b8:
	/* 0x12b8: sub w8, w8, #0x12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_12bc:
	/* 0x12bc: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_12c0:
	/* 0x12c0: b.cs 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x12c0, 0x294, arm64_l_294);
arm64_l_12c4:
	/* 0x12c4: ldrb w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_12c8:
	/* 0x12c8: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_12cc:
	/* 0x12cc: add x9, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_12d0:
	/* 0x12d0: add x1, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_12d4:
	/* 0x12d4: str w8, [sp, #172] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 172ULL);
arm64_l_12d8:
	/* 0x12d8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_12dc:
	/* 0x12dc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_12e0:
	/* 0x12e0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x12e4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_12e4:
	/* 0x12e4: cbz x0, 17d4 <generic_kprobe_filter_arg+0x17d4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x12e4, 0x17d4, arm64_l_17d4);
arm64_l_12e8:
	/* 0x12e8: str x24, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_12ec:
	/* 0x12ec: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_12f0:
	/* 0x12f0: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_12f4:
	/* 0x12f4: b 1798 <generic_kprobe_filter_arg+0x1798> */
	ARM64_SIM_A64_JMP(0x12f4, 0x1798, arm64_l_1798);
arm64_l_12f8:
	/* 0x12f8: cmp w8, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_12fc:
	/* 0x12fc: b.eq 1ad0 <generic_kprobe_filter_arg+0x1ad0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x12fc, 0x1ad0, arm64_l_1ad0);
arm64_l_1300:
	/* 0x1300: cmp w8, #0x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 34ULL);
arm64_l_1304:
	/* 0x1304: b.ne 2cec <generic_kprobe_filter_arg+0x2cec> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1304, 0x2cec, arm64_l_2cec);
arm64_l_1308:
	/* 0x1308: mov w19, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_130c:
	/* 0x130c: ldr w8, [x29, x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X19, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1310:
	/* 0x1310: adrp x0, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_21));
arm64_l_1314:
	/* 0x1314: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1318:
	/* 0x1318: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_131c:
	/* 0x131c: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1320:
	/* 0x1320: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1324:
	/* 0x1324: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1328:
	/* 0x1328: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x132cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_132c:
	/* 0x132c: cbz x0, 24a0 <generic_kprobe_filter_arg+0x24a0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x132c, 0x24a0, arm64_l_24a0);
arm64_l_1330:
	/* 0x1330: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1334:
	/* 0x1334: mov x0, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1338:
	/* 0x1338: mov x2, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_133c:
	/* 0x133c: bl 2d8c <native_bpf_strncasestr> */
	ARM64_SIM_A64_CALL(arm64_l_2d8c, 0x1340ULL);
arm64_l_1340:
	/* 0x1340: tbz w0, #31, 24a8 <generic_kprobe_filter_arg+0x24a8> */
	ARM64_SIM_A64_TBZ(ARM64_X0, 31, 0x1340, 0x24a8, arm64_l_24a8);
arm64_l_1344:
	/* 0x1344: ldr w8, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1348:
	/* 0x1348: add x19, x19, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_134c:
	/* 0x134c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1350:
	/* 0x1350: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1354:
	/* 0x1354: sub w9, w19, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1358:
	/* 0x1358: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_135c:
	/* 0x135c: b.cs 24b0 <generic_kprobe_filter_arg+0x24b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x135c, 0x24b0, arm64_l_24b0);
arm64_l_1360:
	/* 0x1360: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1364:
	/* 0x1364: cmp x19, #0x1a0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 416ULL);
arm64_l_1368:
	/* 0x1368: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_136c:
	/* 0x136c: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1370:
	/* 0x1370: b.ne 130c <generic_kprobe_filter_arg+0x130c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1370, 0x130c, arm64_l_130c);
arm64_l_1374:
	/* 0x1374: b 2cec <generic_kprobe_filter_arg+0x2cec> */
	ARM64_SIM_A64_JMP(0x1374, 0x2cec, arm64_l_2cec);
arm64_l_1378:
	/* 0x1378: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_137c:
	/* 0x137c: b.eq 1bf8 <generic_kprobe_filter_arg+0x1bf8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x137c, 0x1bf8, arm64_l_1bf8);
arm64_l_1380:
	/* 0x1380: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1384:
	/* 0x1384: b.ne 1c04 <generic_kprobe_filter_arg+0x1c04> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1384, 0x1c04, arm64_l_1c04);
arm64_l_1388:
	/* 0x1388: ldrb w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_138c:
	/* 0x138c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1390:
	/* 0x1390: b.hi 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1390, 0x298, arm64_l_298);
arm64_l_1394:
	/* 0x1394: b 1c04 <generic_kprobe_filter_arg+0x1c04> */
	ARM64_SIM_A64_JMP(0x1394, 0x1c04, arm64_l_1c04);
arm64_l_1398:
	/* 0x1398: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_139c:
	/* 0x139c: b.eq 1c38 <generic_kprobe_filter_arg+0x1c38> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x139c, 0x1c38, arm64_l_1c38);
arm64_l_13a0:
	/* 0x13a0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_13a4:
	/* 0x13a4: b.ne 1c44 <generic_kprobe_filter_arg+0x1c44> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x13a4, 0x1c44, arm64_l_1c44);
arm64_l_13a8:
	/* 0x13a8: ldrh w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_13ac:
	/* 0x13ac: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_13b0:
	/* 0x13b0: b.hi 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x13b0, 0x298, arm64_l_298);
arm64_l_13b4:
	/* 0x13b4: b 1c44 <generic_kprobe_filter_arg+0x1c44> */
	ARM64_SIM_A64_JMP(0x13b4, 0x1c44, arm64_l_1c44);
arm64_l_13b8:
	/* 0x13b8: ldrb w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_13bc:
	/* 0x13bc: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_13c0:
	/* 0x13c0: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_13c4:
	/* 0x13c4: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_13c8:
	/* 0x13c8: str w8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_13cc:
	/* 0x13cc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_13d0:
	/* 0x13d0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_13d4:
	/* 0x13d4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x13d8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_13d8:
	/* 0x13d8: cbz x0, 17d4 <generic_kprobe_filter_arg+0x17d4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x13d8, 0x17d4, arm64_l_17d4);
arm64_l_13dc:
	/* 0x13dc: ldrb w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_13e0:
	/* 0x13e0: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_13e4:
	/* 0x13e4: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_13e8:
	/* 0x13e8: str x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_13ec:
	/* 0x13ec: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_13f0:
	/* 0x13f0: b 179c <generic_kprobe_filter_arg+0x179c> */
	ARM64_SIM_A64_JMP(0x13f0, 0x179c, arm64_l_179c);
arm64_l_13f4:
	/* 0x13f4: ldrb w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_13f8:
	/* 0x13f8: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_13fc:
	/* 0x13fc: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1400:
	/* 0x1400: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1404:
	/* 0x1404: str w8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1408:
	/* 0x1408: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_140c:
	/* 0x140c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1410:
	/* 0x1410: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1414ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1414:
	/* 0x1414: cbz x0, 17d4 <generic_kprobe_filter_arg+0x17d4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1414, 0x17d4, arm64_l_17d4);
arm64_l_1418:
	/* 0x1418: ldrh w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_141c:
	/* 0x141c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1420:
	/* 0x1420: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1424:
	/* 0x1424: str x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1428:
	/* 0x1428: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_142c:
	/* 0x142c: b 179c <generic_kprobe_filter_arg+0x179c> */
	ARM64_SIM_A64_JMP(0x142c, 0x179c, arm64_l_179c);
arm64_l_1430:
	/* 0x1430: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1434:
	/* 0x1434: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1438:
	/* 0x1438: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_143c:
	/* 0x143c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1440:
	/* 0x1440: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1444:
	/* 0x1444: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1448:
	/* 0x1448: mov w23, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_144c:
	/* 0x144c: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x144c, 0x294, arm64_l_294);
arm64_l_1450:
	/* 0x1450: ldr w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1454:
	/* 0x1454: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1458:
	/* 0x1458: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_19));
arm64_l_145c:
	/* 0x145c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1460:
	/* 0x1460: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1464:
	/* 0x1464: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1468:
	/* 0x1468: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_146c:
	/* 0x146c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1470:
	/* 0x1470: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1474ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1474:
	/* 0x1474: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1478:
	/* 0x1478: cbz w22, 2cdc <generic_kprobe_filter_arg+0x2cdc> */
	ARM64_SIM_A64_CBZ(ARM64_X22, 0x1478, 0x2cdc, arm64_l_2cdc);
arm64_l_147c:
	/* 0x147c: cbz x0, 2cdc <generic_kprobe_filter_arg+0x2cdc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x147c, 0x2cdc, arm64_l_2cdc);
arm64_l_1480:
	/* 0x1480: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1484:
	/* 0x1484: adrp x0, 0 <string_prefix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap_20));
arm64_l_1488:
	/* 0x1488: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_148c:
	/* 0x148c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1490:
	/* 0x1490: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1494:
	/* 0x1494: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1498:
	/* 0x1498: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x149cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_149c:
	/* 0x149c: cbz x0, 2cd8 <generic_kprobe_filter_arg+0x2cd8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x149c, 0x2cd8, arm64_l_2cd8);
arm64_l_14a0:
	/* 0x14a0: cmp w22, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_14a4:
	/* 0x14a4: mov w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 255ULL);
arm64_l_14a8:
	/* 0x14a8: mov x2, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14ac:
	/* 0x14ac: csel w1, w22, w8, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X1, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_14b0:
	/* 0x14b0: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14b4:
	/* 0x14b4: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14b8:
	/* 0x14b8: lsl w9, w1, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_14bc:
	/* 0x14bc: str w9, [x8], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_14c0:
	/* 0x14c0: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14c4:
	/* 0x14c4: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14c8:
	/* 0x14c8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x14ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_14cc:
	/* 0x14cc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_14d0:
	/* 0x14d0: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14d4:
	/* 0x14d4: mov x1, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14d8:
	/* 0x14d8: b 2cc8 <generic_kprobe_filter_arg+0x2cc8> */
	ARM64_SIM_A64_JMP(0x14d8, 0x2cc8, arm64_l_2cc8);
arm64_l_14dc:
	/* 0x14dc: cmp w22, #0x1fe */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 510ULL);
arm64_l_14e0:
	/* 0x14e0: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_14e4:
	/* 0x14e4: b.ls 1b94 <generic_kprobe_filter_arg+0x1b94> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x14e4, 0x1b94, arm64_l_1b94);
arm64_l_14e8:
	/* 0x14e8: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14ec:
	/* 0x14ec: b 2cec <generic_kprobe_filter_arg+0x2cec> */
	ARM64_SIM_A64_JMP(0x14ec, 0x2cec, arm64_l_2cec);
arm64_l_14f0:
	/* 0x14f0: cmp w8, #0x1e */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 30ULL);
arm64_l_14f4:
	/* 0x14f4: b.ne fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x14f4, 0xfc, arm64_l_fc);
arm64_l_14f8:
	/* 0x14f8: ldr w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_14fc:
	/* 0x14fc: and x8, x8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_1500:
	/* 0x1500: add x9, x20, x8, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_1504:
	/* 0x1504: ldr w9, [x9, x2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X2, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1508:
	/* 0x1508: cbnz w9, fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_CBNZ(ARM64_X9, 0x1508, 0xfc, arm64_l_fc);
arm64_l_150c:
	/* 0x150c: add x8, x20, x8, lsl #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 3), 0);
arm64_l_1510:
	/* 0x1510: ldr x9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1514:
	/* 0x1514: ldr x8, [x8, #24184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24184ULL);
arm64_l_1518:
	/* 0x1518: and x8, x8, #0x7ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2047ULL);
arm64_l_151c:
	/* 0x151c: add x8, x20, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1520:
	/* 0x1520: ldr x8, [x8, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1524:
	/* 0x1524: bics xzr, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_BIC_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1528:
	/* 0x1528: cset w23, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_152c:
	/* 0x152c: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x152c, 0x294, arm64_l_294);
arm64_l_1530:
	/* 0x1530: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1534:
	/* 0x1534: cmp x24, #0x400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1024ULL);
arm64_l_1538:
	/* 0x1538: cset w23, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_153c:
	/* 0x153c: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x153c, 0x294, arm64_l_294);
arm64_l_1540:
	/* 0x1540: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1544:
	/* 0x1544: cmp x24, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1548:
	/* 0x1548: cset w23, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_154c:
	/* 0x154c: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x154c, 0x294, arm64_l_294);
arm64_l_1550:
	/* 0x1550: and w8, w24, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1554:
	/* 0x1554: mov w9, #0x1fe */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 510ULL);
arm64_l_1558:
	/* 0x1558: cmp w8, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_155c:
	/* 0x155c: mov w8, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_1560:
	/* 0x1560: csel w11, w9, w8, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_1564:
	/* 0x1564: and w8, w11, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1568:
	/* 0x1568: cmp w8, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_156c:
	/* 0x156c: mov w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 6ULL);
arm64_l_1570:
	/* 0x1570: cinc w10, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CINC, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1574:
	/* 0x1574: add x8, x29, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1578:
	/* 0x1578: and w9, w10, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_157c:
	/* 0x157c: ldr w8, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_1580:
	/* 0x1580: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1584:
	/* 0x1584: b.eq 28a8 <generic_kprobe_filter_arg+0x28a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1584, 0x28a8, arm64_l_28a8);
arm64_l_1588:
	/* 0x1588: str w11, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_158c:
	/* 0x158c: stp w8, w10, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_1590:
	/* 0x1590: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_16));
arm64_l_1594:
	/* 0x1594: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1598:
	/* 0x1598: add x23, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_159c:
	/* 0x159c: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_15a0:
	/* 0x15a0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_15a4:
	/* 0x15a4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x15a8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_15a8:
	/* 0x15a8: str x0, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_15ac:
	/* 0x15ac: adrp x0, 0 <heap_ro_zero> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero_4));
arm64_l_15b0:
	/* 0x15b0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_15b4:
	/* 0x15b4: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_15b8:
	/* 0x15b8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_15bc:
	/* 0x15bc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x15c0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_15c0:
	/* 0x15c0: ldr x9, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_15c4:
	/* 0x15c4: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_15c8:
	/* 0x15c8: cbz x9, 28ac <generic_kprobe_filter_arg+0x28ac> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x15c8, 0x28ac, arm64_l_28ac);
arm64_l_15cc:
	/* 0x15cc: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_15d0:
	/* 0x15d0: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_15d4:
	/* 0x15d4: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_15d8:
	/* 0x15d8: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_15dc:
	/* 0x15dc: cbz x0, 28bc <generic_kprobe_filter_arg+0x28bc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x15dc, 0x28bc, arm64_l_28bc);
arm64_l_15e0:
	/* 0x15e0: ldr w23, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_15e4:
	/* 0x15e4: mov x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_15e8:
	/* 0x15e8: str x0, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_15ec:
	/* 0x15ec: add x2, x22, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_15f0:
	/* 0x15f0: mov x22, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_15f4:
	/* 0x15f4: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_15f8:
	/* 0x15f8: cmp w23, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_15fc:
	/* 0x15fc: b.gt 1fbc <generic_kprobe_filter_arg+0x1fbc> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x15fc, 0x1fbc, arm64_l_1fbc);
arm64_l_1600:
	/* 0x1600: strb w24, [x0], #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 1ULL);
arm64_l_1604:
	/* 0x1604: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1608:
	/* 0x1608: mov w1, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_160c:
	/* 0x160c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1610ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1610:
	/* 0x1610: ldr w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1614:
	/* 0x1614: and w8, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1618:
	/* 0x1618: cmp w8, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_161c:
	/* 0x161c: b.ls 1ff8 <generic_kprobe_filter_arg+0x1ff8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x161c, 0x1ff8, arm64_l_1ff8);
arm64_l_1620:
	/* 0x1620: add x9, x22, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X22, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1624:
	/* 0x1624: sub w8, w8, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_1628:
	/* 0x1628: ldr x2, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_162c:
	/* 0x162c: add x0, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1630:
	/* 0x1630: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1634:
	/* 0x1634: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1638:
	/* 0x1638: b 1ff4 <generic_kprobe_filter_arg+0x1ff4> */
	ARM64_SIM_A64_JMP(0x1638, 0x1ff4, arm64_l_1ff4);
arm64_l_163c:
	/* 0x163c: ldr w8, [x29, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1640:
	/* 0x1640: adrp x0, 0 <addr6lpm_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&addr6lpm_maps_1));
arm64_l_1644:
	/* 0x1644: add x9, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1648:
	/* 0x1648: add x1, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_164c:
	/* 0x164c: str w8, [sp, #172] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 172ULL);
arm64_l_1650:
	/* 0x1650: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1654:
	/* 0x1654: mov w23, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1658:
	/* 0x1658: mov w22, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_165c:
	/* 0x165c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1660:
	/* 0x1660: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1664ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1664:
	/* 0x1664: cbz x0, 1f50 <generic_kprobe_filter_arg+0x1f50> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1664, 0x1f50, arm64_l_1f50);
arm64_l_1668:
	/* 0x1668: mov w8, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 128ULL);
arm64_l_166c:
	/* 0x166c: stp w23, w19, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X23, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1670:
	/* 0x1670: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1674:
	/* 0x1674: stp w8, w22, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1678:
	/* 0x1678: lsr x8, x19, #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 32ULL);
arm64_l_167c:
	/* 0x167c: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1680:
	/* 0x1680: str w8, [sp, #152] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1684:
	/* 0x1684: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1688:
	/* 0x1688: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x168cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_168c:
	/* 0x168c: ldr w8, [x29, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1690:
	/* 0x1690: sub w9, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1694:
	/* 0x1694: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1698:
	/* 0x1698: b.cc 1c78 <generic_kprobe_filter_arg+0x1c78> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1698, 0x1c78, arm64_l_1c78);
arm64_l_169c:
	/* 0x169c: sub w8, w8, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_16a0:
	/* 0x16a0: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_16a4:
	/* 0x16a4: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_16a8:
	/* 0x16a8: b.hi 8d8 <generic_kprobe_filter_arg+0x8d8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x16a8, 0x8d8, arm64_l_8d8);
arm64_l_16ac:
	/* 0x16ac: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_16b0:
	/* 0x16b0: cset w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_16b4:
	/* 0x16b4: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_16b8:
	/* 0x16b8: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_16bc:
	/* 0x16bc: mov w23, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_16c0:
	/* 0x16c0: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_16c4:
	/* 0x16c4: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x16c4, 0x294, arm64_l_294);
arm64_l_16c8:
	/* 0x16c8: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_16cc:
	/* 0x16cc: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_16d0:
	/* 0x16d0: mov w23, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_16d4:
	/* 0x16d4: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x16d4, 0x294, arm64_l_294);
arm64_l_16d8:
	/* 0x16d8: ldr x8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_16dc:
	/* 0x16dc: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_16e0:
	/* 0x16e0: b.hi 16ec <generic_kprobe_filter_arg+0x16ec> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x16e0, 0x16ec, arm64_l_16ec);
arm64_l_16e4:
	/* 0x16e4: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_16e8:
	/* 0x16e8: b.ls 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x16e8, 0x298, arm64_l_298);
arm64_l_16ec:
	/* 0x16ec: ldr w10, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_16f0:
	/* 0x16f0: cmp w10, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_16f4:
	/* 0x16f4: b.cc fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x16f4, 0xfc, arm64_l_fc);
arm64_l_16f8:
	/* 0x16f8: ldp x12, x11, [x29, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_16fc:
	/* 0x16fc: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1700:
	/* 0x1700: b.eq 170c <generic_kprobe_filter_arg+0x170c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1700, 0x170c, arm64_l_170c);
arm64_l_1704:
	/* 0x1704: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1708:
	/* 0x1708: b.ne 1d68 <generic_kprobe_filter_arg+0x1d68> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1708, 0x1d68, arm64_l_1d68);
arm64_l_170c:
	/* 0x170c: cmp x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1710:
	/* 0x1710: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1714:
	/* 0x1714: b.gt 1d7c <generic_kprobe_filter_arg+0x1d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1714, 0x1d7c, arm64_l_1d7c);
arm64_l_1718:
	/* 0x1718: cmp x8, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_171c:
	/* 0x171c: b.le 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x171c, 0x298, arm64_l_298);
arm64_l_1720:
	/* 0x1720: b 1d7c <generic_kprobe_filter_arg+0x1d7c> */
	ARM64_SIM_A64_JMP(0x1720, 0x1d7c, arm64_l_1d7c);
arm64_l_1724:
	/* 0x1724: ldr x10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1728:
	/* 0x1728: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_172c:
	/* 0x172c: ccmp x10, x8, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_1730:
	/* 0x1730: cset w8, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_1734:
	/* 0x1734: ldr w11, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1738:
	/* 0x1738: cmp w11, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_173c:
	/* 0x173c: b.cc 26c4 <generic_kprobe_filter_arg+0x26c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x173c, 0x26c4, arm64_l_26c4);
arm64_l_1740:
	/* 0x1740: ldp x13, x12, [x29, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X13, ARM64_X12, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1744:
	/* 0x1744: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1748:
	/* 0x1748: b.eq 1754 <generic_kprobe_filter_arg+0x1754> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1748, 0x1754, arm64_l_1754);
arm64_l_174c:
	/* 0x174c: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1750:
	/* 0x1750: b.ne 1d2c <generic_kprobe_filter_arg+0x1d2c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1750, 0x1d2c, arm64_l_1d2c);
arm64_l_1754:
	/* 0x1754: cmp x13, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1758:
	/* 0x1758: ccmp x10, x12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_175c:
	/* 0x175c: cset w12, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_1760:
	/* 0x1760: b 1d38 <generic_kprobe_filter_arg+0x1d38> */
	ARM64_SIM_A64_JMP(0x1760, 0x1d38, arm64_l_1d38);
arm64_l_1764:
	/* 0x1764: ldrh w23, [x22, #38] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 38ULL);
arm64_l_1768:
	/* 0x1768: ldrb w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_176c:
	/* 0x176c: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_1770:
	/* 0x1770: add x9, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1774:
	/* 0x1774: add x1, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1778:
	/* 0x1778: str w8, [sp, #172] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 172ULL);
arm64_l_177c:
	/* 0x177c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1780:
	/* 0x1780: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1784:
	/* 0x1784: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1788ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1788:
	/* 0x1788: cbz x0, 17d4 <generic_kprobe_filter_arg+0x17d4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1788, 0x17d4, arm64_l_17d4);
arm64_l_178c:
	/* 0x178c: str x23, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1790:
	/* 0x1790: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1794:
	/* 0x1794: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1798:
	/* 0x1798: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_179c:
	/* 0x179c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x17a0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_17a0:
	/* 0x17a0: ldr w9, [x29, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_17a4:
	/* 0x17a4: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_17a8:
	/* 0x17a8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_17ac:
	/* 0x17ac: cmp w9, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_17b0:
	/* 0x17b0: b.hi 1e50 <generic_kprobe_filter_arg+0x1e50> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x17b0, 0x1e50, arm64_l_1e50);
arm64_l_17b4:
	/* 0x17b4: mov w10, #0x8400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 33792ULL);
arm64_l_17b8:
	/* 0x17b8: lsl w9, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_17bc:
	/* 0x17bc: movk w10, #0x3003, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 12291ULL);
arm64_l_17c0:
	/* 0x17c0: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17c4:
	/* 0x17c4: b.eq 1e38 <generic_kprobe_filter_arg+0x1e38> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x17c4, 0x1e38, arm64_l_1e38);
arm64_l_17c8:
	/* 0x17c8: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_17cc:
	/* 0x17cc: cset w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_17d0:
	/* 0x17d0: b 1e50 <generic_kprobe_filter_arg+0x1e50> */
	ARM64_SIM_A64_JMP(0x17d0, 0x1e50, arm64_l_1e50);
arm64_l_17d4:
	/* 0x17d4: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_17d8:
	/* 0x17d8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_17dc:
	/* 0x17dc: b 1e54 <generic_kprobe_filter_arg+0x1e54> */
	ARM64_SIM_A64_JMP(0x17dc, 0x1e54, arm64_l_1e54);
arm64_l_17e0:
	/* 0x17e0: ldr x11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17e4:
	/* 0x17e4: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17e8:
	/* 0x17e8: b.hi 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x17e8, 0x298, arm64_l_298);
arm64_l_17ec:
	/* 0x17ec: b 17fc <generic_kprobe_filter_arg+0x17fc> */
	ARM64_SIM_A64_JMP(0x17ec, 0x17fc, arm64_l_17fc);
arm64_l_17f0:
	/* 0x17f0: ldr x11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17f4:
	/* 0x17f4: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17f8:
	/* 0x17f8: b.cc 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x17f8, 0x298, arm64_l_298);
arm64_l_17fc:
	/* 0x17fc: ldr w10, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1800:
	/* 0x1800: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1804:
	/* 0x1804: b.cc 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1804, 0x2d7c, arm64_l_2d7c);
arm64_l_1808:
	/* 0x1808: ldr x11, [x29, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_180c:
	/* 0x180c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1810:
	/* 0x1810: b.le 1834 <generic_kprobe_filter_arg+0x1834> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1810, 0x1834, arm64_l_1834);
arm64_l_1814:
	/* 0x1814: sub w12, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1818:
	/* 0x1818: cmp w12, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_181c:
	/* 0x181c: b.cs 1868 <generic_kprobe_filter_arg+0x1868> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x181c, 0x1868, arm64_l_1868);
arm64_l_1820:
	/* 0x1820: ldr x12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1824:
	/* 0x1824: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1828:
	/* 0x1828: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_182c:
	/* 0x182c: b.eq 28c <generic_kprobe_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x182c, 0x28c, arm64_l_28c);
arm64_l_1830:
	/* 0x1830: b 237c <generic_kprobe_filter_arg+0x237c> */
	ARM64_SIM_A64_JMP(0x1830, 0x237c, arm64_l_237c);
arm64_l_1834:
	/* 0x1834: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1838:
	/* 0x1838: b.eq 19c0 <generic_kprobe_filter_arg+0x19c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1838, 0x19c0, arm64_l_19c0);
arm64_l_183c:
	/* 0x183c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1840:
	/* 0x1840: b.ne 237c <generic_kprobe_filter_arg+0x237c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1840, 0x237c, arm64_l_237c);
arm64_l_1844:
	/* 0x1844: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1848:
	/* 0x1848: b.eq 1854 <generic_kprobe_filter_arg+0x1854> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1848, 0x1854, arm64_l_1854);
arm64_l_184c:
	/* 0x184c: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1850:
	/* 0x1850: b.ne 236c <generic_kprobe_filter_arg+0x236c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1850, 0x236c, arm64_l_236c);
arm64_l_1854:
	/* 0x1854: ldr x12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1858:
	/* 0x1858: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_185c:
	/* 0x185c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1860:
	/* 0x1860: b.lt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x1860, 0x298, arm64_l_298);
arm64_l_1864:
	/* 0x1864: b 237c <generic_kprobe_filter_arg+0x237c> */
	ARM64_SIM_A64_JMP(0x1864, 0x237c, arm64_l_237c);
arm64_l_1868:
	/* 0x1868: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_186c:
	/* 0x186c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1870:
	/* 0x1870: b.ne 237c <generic_kprobe_filter_arg+0x237c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1870, 0x237c, arm64_l_237c);
arm64_l_1874:
	/* 0x1874: ldr x12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1878:
	/* 0x1878: tst x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_187c:
	/* 0x187c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1880:
	/* 0x1880: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1880, 0x298, arm64_l_298);
arm64_l_1884:
	/* 0x1884: b 237c <generic_kprobe_filter_arg+0x237c> */
	ARM64_SIM_A64_JMP(0x1884, 0x237c, arm64_l_237c);
arm64_l_1888:
	/* 0x1888: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_188c:
	/* 0x188c: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1890:
	/* 0x1890: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1894:
	/* 0x1894: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1898:
	/* 0x1898: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_189c:
	/* 0x189c: b 28b8 <generic_kprobe_filter_arg+0x28b8> */
	ARM64_SIM_A64_JMP(0x189c, 0x28b8, arm64_l_28b8);
arm64_l_18a0:
	/* 0x18a0: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_18a4:
	/* 0x18a4: b.ne 1c04 <generic_kprobe_filter_arg+0x1c04> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x18a4, 0x1c04, arm64_l_1c04);
arm64_l_18a8:
	/* 0x18a8: ldrb w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18ac:
	/* 0x18ac: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_18b0:
	/* 0x18b0: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x18b0, 0x298, arm64_l_298);
arm64_l_18b4:
	/* 0x18b4: b 1c04 <generic_kprobe_filter_arg+0x1c04> */
	ARM64_SIM_A64_JMP(0x18b4, 0x1c04, arm64_l_1c04);
arm64_l_18b8:
	/* 0x18b8: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_18bc:
	/* 0x18bc: b.ne 1c44 <generic_kprobe_filter_arg+0x1c44> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x18bc, 0x1c44, arm64_l_1c44);
arm64_l_18c0:
	/* 0x18c0: ldrh w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18c4:
	/* 0x18c4: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_18c8:
	/* 0x18c8: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x18c8, 0x298, arm64_l_298);
arm64_l_18cc:
	/* 0x18cc: b 1c44 <generic_kprobe_filter_arg+0x1c44> */
	ARM64_SIM_A64_JMP(0x18cc, 0x1c44, arm64_l_1c44);
arm64_l_18d0:
	/* 0x18d0: and w8, w24, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_18d4:
	/* 0x18d4: mov w9, #0x1fe */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 510ULL);
arm64_l_18d8:
	/* 0x18d8: cmp w8, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_18dc:
	/* 0x18dc: mov w8, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_18e0:
	/* 0x18e0: csel w11, w9, w8, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_18e4:
	/* 0x18e4: and w8, w11, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_18e8:
	/* 0x18e8: cmp w8, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_18ec:
	/* 0x18ec: mov w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 6ULL);
arm64_l_18f0:
	/* 0x18f0: cinc w10, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CINC, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_18f4:
	/* 0x18f4: add x8, x29, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_18f8:
	/* 0x18f8: and w9, w10, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_18fc:
	/* 0x18fc: ldr w8, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_1900:
	/* 0x1900: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1904:
	/* 0x1904: b.eq 2718 <generic_kprobe_filter_arg+0x2718> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1904, 0x2718, arm64_l_2718);
arm64_l_1908:
	/* 0x1908: str w11, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_190c:
	/* 0x190c: str w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_1910:
	/* 0x1910: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_16));
arm64_l_1914:
	/* 0x1914: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1918:
	/* 0x1918: add x23, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_191c:
	/* 0x191c: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1920:
	/* 0x1920: str w10, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1924:
	/* 0x1924: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1928:
	/* 0x1928: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x192cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_192c:
	/* 0x192c: str x0, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1930:
	/* 0x1930: adrp x0, 0 <heap_ro_zero> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero_4));
arm64_l_1934:
	/* 0x1934: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1938:
	/* 0x1938: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_193c:
	/* 0x193c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1940:
	/* 0x1940: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1944ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1944:
	/* 0x1944: ldr x9, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1948:
	/* 0x1948: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_194c:
	/* 0x194c: cbz x9, 1218 <generic_kprobe_filter_arg+0x1218> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x194c, 0x1218, arm64_l_1218);
arm64_l_1950:
	/* 0x1950: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1954:
	/* 0x1954: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1958:
	/* 0x1958: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_195c:
	/* 0x195c: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1960:
	/* 0x1960: cbz x0, 1228 <generic_kprobe_filter_arg+0x1228> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1960, 0x1228, arm64_l_1228);
arm64_l_1964:
	/* 0x1964: mov x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1968:
	/* 0x1968: ldr w9, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_196c:
	/* 0x196c: mov x23, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1970:
	/* 0x1970: cmp w9, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1974:
	/* 0x1974: b.gt 2258 <generic_kprobe_filter_arg+0x2258> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1974, 0x2258, arm64_l_2258);
arm64_l_1978:
	/* 0x1978: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_197c:
	/* 0x197c: mov x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1980:
	/* 0x1980: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1984:
	/* 0x1984: mov w1, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1988:
	/* 0x1988: mov x2, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_198c:
	/* 0x198c: strb w24, [x0], #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 1ULL);
arm64_l_1990:
	/* 0x1990: mov x22, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1994:
	/* 0x1994: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1998ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1998:
	/* 0x1998: ldr w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_199c:
	/* 0x199c: and w8, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_19a0:
	/* 0x19a0: cmp w8, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19a4:
	/* 0x19a4: b.ls 22a4 <generic_kprobe_filter_arg+0x22a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x19a4, 0x22a4, arm64_l_22a4);
arm64_l_19a8:
	/* 0x19a8: add x9, x22, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X22, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_19ac:
	/* 0x19ac: sub w8, w8, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_19b0:
	/* 0x19b0: add x0, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_19b4:
	/* 0x19b4: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_19b8:
	/* 0x19b8: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_19bc:
	/* 0x19bc: b 229c <generic_kprobe_filter_arg+0x229c> */
	ARM64_SIM_A64_JMP(0x19bc, 0x229c, arm64_l_229c);
arm64_l_19c0:
	/* 0x19c0: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_19c4:
	/* 0x19c4: b.eq 19d0 <generic_kprobe_filter_arg+0x19d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x19c4, 0x19d0, arm64_l_19d0);
arm64_l_19c8:
	/* 0x19c8: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_19cc:
	/* 0x19cc: b.ne 2358 <generic_kprobe_filter_arg+0x2358> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x19cc, 0x2358, arm64_l_2358);
arm64_l_19d0:
	/* 0x19d0: ldr x12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19d4:
	/* 0x19d4: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19d8:
	/* 0x19d8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_19dc:
	/* 0x19dc: b.gt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x19dc, 0x298, arm64_l_298);
arm64_l_19e0:
	/* 0x19e0: b 237c <generic_kprobe_filter_arg+0x237c> */
	ARM64_SIM_A64_JMP(0x19e0, 0x237c, arm64_l_237c);
arm64_l_19e4:
	/* 0x19e4: ldr w9, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_19e8:
	/* 0x19e8: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_19ec:
	/* 0x19ec: b.cc 718 <generic_kprobe_filter_arg+0x718> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x19ec, 0x718, arm64_l_718);
arm64_l_19f0:
	/* 0x19f0: ldr w10, [x29, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_19f4:
	/* 0x19f4: cbz w10, 718 <generic_kprobe_filter_arg+0x718> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x19f4, 0x718, arm64_l_718);
arm64_l_19f8:
	/* 0x19f8: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19fc:
	/* 0x19fc: b.eq 474 <generic_kprobe_filter_arg+0x474> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x19fc, 0x474, arm64_l_474);
arm64_l_1a00:
	/* 0x1a00: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1a04:
	/* 0x1a04: b.cc 718 <generic_kprobe_filter_arg+0x718> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1a04, 0x718, arm64_l_718);
arm64_l_1a08:
	/* 0x1a08: ldr w10, [x29, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1a0c:
	/* 0x1a0c: cbz w10, 718 <generic_kprobe_filter_arg+0x718> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x1a0c, 0x718, arm64_l_718);
arm64_l_1a10:
	/* 0x1a10: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a14:
	/* 0x1a14: b.eq 474 <generic_kprobe_filter_arg+0x474> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1a14, 0x474, arm64_l_474);
arm64_l_1a18:
	/* 0x1a18: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_1a1c:
	/* 0x1a1c: b.cc 1a34 <generic_kprobe_filter_arg+0x1a34> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1a1c, 0x1a34, arm64_l_1a34);
arm64_l_1a20:
	/* 0x1a20: ldr w9, [x29, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_1a24:
	/* 0x1a24: cbz w9, 1a34 <generic_kprobe_filter_arg+0x1a34> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1a24, 0x1a34, arm64_l_1a34);
arm64_l_1a28:
	/* 0x1a28: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a2c:
	/* 0x1a2c: cset w23, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1a30:
	/* 0x1a30: b 1a38 <generic_kprobe_filter_arg+0x1a38> */
	ARM64_SIM_A64_JMP(0x1a30, 0x1a38, arm64_l_1a38);
arm64_l_1a34:
	/* 0x1a34: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a38:
	/* 0x1a38: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1a3c:
	/* 0x1a3c: b 28ac <generic_kprobe_filter_arg+0x28ac> */
	ARM64_SIM_A64_JMP(0x1a3c, 0x28ac, arm64_l_28ac);
arm64_l_1a40:
	/* 0x1a40: ldp w8, w11, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1a44:
	/* 0x1a44: ldrb w9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a48:
	/* 0x1a48: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a4c:
	/* 0x1a4c: ldr w10, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1a50:
	/* 0x1a50: ccmp w11, w9, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_1a54:
	/* 0x1a54: cset w8, cs */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CS, 0);
arm64_l_1a58:
	/* 0x1a58: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1a5c:
	/* 0x1a5c: b.cc 28fc <generic_kprobe_filter_arg+0x28fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1a5c, 0x28fc, arm64_l_28fc);
arm64_l_1a60:
	/* 0x1a60: b 1a84 <generic_kprobe_filter_arg+0x1a84> */
	ARM64_SIM_A64_JMP(0x1a60, 0x1a84, arm64_l_1a84);
arm64_l_1a64:
	/* 0x1a64: ldp w8, w11, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1a68:
	/* 0x1a68: ldrh w9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a6c:
	/* 0x1a6c: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a70:
	/* 0x1a70: ldr w10, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1a74:
	/* 0x1a74: ccmp w11, w9, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_1a78:
	/* 0x1a78: cset w8, cs */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CS, 0);
arm64_l_1a7c:
	/* 0x1a7c: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1a80:
	/* 0x1a80: b.cc 28fc <generic_kprobe_filter_arg+0x28fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1a80, 0x28fc, arm64_l_28fc);
arm64_l_1a84:
	/* 0x1a84: ldp w11, w12, [x29, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X12, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1a88:
	/* 0x1a88: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a8c:
	/* 0x1a8c: ccmp w12, w9, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_1a90:
	/* 0x1a90: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1a94:
	/* 0x1a94: csinc w8, w8, wzr, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X8, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_1a98:
	/* 0x1a98: cmp w10, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_1a9c:
	/* 0x1a9c: b.cc 28fc <generic_kprobe_filter_arg+0x28fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1a9c, 0x28fc, arm64_l_28fc);
arm64_l_1aa0:
	/* 0x1aa0: ldp w11, w12, [x29, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X12, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1aa4:
	/* 0x1aa4: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1aa8:
	/* 0x1aa8: ccmp w12, w9, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_1aac:
	/* 0x1aac: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ab0:
	/* 0x1ab0: csinc w8, w8, wzr, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X8, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_1ab4:
	/* 0x1ab4: cmp w10, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_1ab8:
	/* 0x1ab8: b.cc 28fc <generic_kprobe_filter_arg+0x28fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1ab8, 0x28fc, arm64_l_28fc);
arm64_l_1abc:
	/* 0x1abc: ldp w10, w11, [x29, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1ac0:
	/* 0x1ac0: cmp w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ac4:
	/* 0x1ac4: ccmp w11, w9, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_1ac8:
	/* 0x1ac8: csinc w8, w8, wzr, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X8, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_1acc:
	/* 0x1acc: b 28fc <generic_kprobe_filter_arg+0x28fc> */
	ARM64_SIM_A64_JMP(0x1acc, 0x28fc, arm64_l_28fc);
arm64_l_1ad0:
	/* 0x1ad0: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1ad4:
	/* 0x1ad4: mov w23, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1ad8:
	/* 0x1ad8: add x8, x29, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1adc:
	/* 0x1adc: str x8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1ae0:
	/* 0x1ae0: ldr x8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1ae4:
	/* 0x1ae4: adrp x0, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_21));
arm64_l_1ae8:
	/* 0x1ae8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1aec:
	/* 0x1aec: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1af0:
	/* 0x1af0: ldr w8, [x8, x19, lsl #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X19, ARM64_MOD_LSL, 2, 0), 0ULL);
arm64_l_1af4:
	/* 0x1af4: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1af8:
	/* 0x1af8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1afc:
	/* 0x1afc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b00:
	/* 0x1b00: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1b04ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1b04:
	/* 0x1b04: cbz x0, 2cd8 <generic_kprobe_filter_arg+0x2cd8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1b04, 0x2cd8, arm64_l_2cd8);
arm64_l_1b08:
	/* 0x1b08: cbz w22, 1b70 <generic_kprobe_filter_arg+0x1b70> */
	ARM64_SIM_A64_CBZ(ARM64_X22, 0x1b08, 0x1b70, arm64_l_1b70);
arm64_l_1b0c:
	/* 0x1b0c: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b10:
	/* 0x1b10: mov x9, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b14:
	/* 0x1b14: mov x10, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b18:
	/* 0x1b18: b 1b30 <generic_kprobe_filter_arg+0x1b30> */
	ARM64_SIM_A64_JMP(0x1b18, 0x1b30, arm64_l_1b30);
arm64_l_1b1c:
	/* 0x1b1c: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b20:
	/* 0x1b20: sub x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b24:
	/* 0x1b24: add x9, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b28:
	/* 0x1b28: cmp x8, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b2c:
	/* 0x1b2c: b.eq 1b70 <generic_kprobe_filter_arg+0x1b70> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1b2c, 0x1b70, arm64_l_1b70);
arm64_l_1b30:
	/* 0x1b30: mov x11, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b34:
	/* 0x1b34: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b38:
	/* 0x1b38: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b3c:
	/* 0x1b3c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b40:
	/* 0x1b40: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b44:
	/* 0x1b44: b.eq 1b1c <generic_kprobe_filter_arg+0x1b1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1b44, 0x1b1c, arm64_l_1b1c);
arm64_l_1b48:
	/* 0x1b48: ldrb w12, [x0, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X0, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b4c:
	/* 0x1b4c: cbz w12, 1b6c <generic_kprobe_filter_arg+0x1b6c> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0x1b4c, 0x1b6c, arm64_l_1b6c);
arm64_l_1b50:
	/* 0x1b50: cmp x11, #0x62 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 98ULL);
arm64_l_1b54:
	/* 0x1b54: b.hi 1b1c <generic_kprobe_filter_arg+0x1b1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1b54, 0x1b1c, arm64_l_1b1c);
arm64_l_1b58:
	/* 0x1b58: ldrb w13, [x9, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b5c:
	/* 0x1b5c: add x11, x11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b60:
	/* 0x1b60: cmp w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b64:
	/* 0x1b64: b.eq 1b40 <generic_kprobe_filter_arg+0x1b40> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1b64, 0x1b40, arm64_l_1b40);
arm64_l_1b68:
	/* 0x1b68: b 1b1c <generic_kprobe_filter_arg+0x1b1c> */
	ARM64_SIM_A64_JMP(0x1b68, 0x1b1c, arm64_l_1b1c);
arm64_l_1b6c:
	/* 0x1b6c: tbz w8, #31, 278c <generic_kprobe_filter_arg+0x278c> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 31, 0x1b6c, 0x278c, arm64_l_278c);
arm64_l_1b70:
	/* 0x1b70: ldr w9, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1b74:
	/* 0x1b74: add w8, w23, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1b78:
	/* 0x1b78: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b7c:
	/* 0x1b7c: b.cs 2cd8 <generic_kprobe_filter_arg+0x2cd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1b7c, 0x2cd8, arm64_l_2cd8);
arm64_l_1b80:
	/* 0x1b80: add x19, x19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b84:
	/* 0x1b84: add w23, w23, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1b88:
	/* 0x1b88: cmp x19, #0x64 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 100ULL);
arm64_l_1b8c:
	/* 0x1b8c: b.ne 1ae0 <generic_kprobe_filter_arg+0x1ae0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1b8c, 0x1ae0, arm64_l_1ae0);
arm64_l_1b90:
	/* 0x1b90: b 2cd8 <generic_kprobe_filter_arg+0x2cd8> */
	ARM64_SIM_A64_JMP(0x1b90, 0x2cd8, arm64_l_2cd8);
arm64_l_1b94:
	/* 0x1b94: and w8, w22, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1b98:
	/* 0x1b98: cmp w8, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1b9c:
	/* 0x1b9c: b.hi 207c <generic_kprobe_filter_arg+0x207c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1b9c, 0x207c, arm64_l_207c);
arm64_l_1ba0:
	/* 0x1ba0: and w8, w22, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1ba4:
	/* 0x1ba4: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_1ba8:
	/* 0x1ba8: tst w22, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1bac:
	/* 0x1bac: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1bb0:
	/* 0x1bb0: mov w9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_1bb4:
	/* 0x1bb4: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_1bb8:
	/* 0x1bb8: msub w8, w8, w9, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MSUB, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_X22, ARM64_WIDTH_32, 0, 0);
arm64_l_1bbc:
	/* 0x1bbc: b.eq 1bcc <generic_kprobe_filter_arg+0x1bcc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1bbc, 0x1bcc, arm64_l_1bcc);
arm64_l_1bc0:
	/* 0x1bc0: tst w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1bc4:
	/* 0x1bc4: mov w11, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1bc8:
	/* 0x1bc8: b.eq 1be0 <generic_kprobe_filter_arg+0x1be0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1bc8, 0x1be0, arm64_l_1be0);
arm64_l_1bcc:
	/* 0x1bcc: sub w8, w22, w8, uxtb */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_UXTB, 0), 0);
arm64_l_1bd0:
	/* 0x1bd0: and w9, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1bd4:
	/* 0x1bd4: add w11, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1bd8:
	/* 0x1bd8: cmp w9, #0x78 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 120ULL);
arm64_l_1bdc:
	/* 0x1bdc: b.hi 2090 <generic_kprobe_filter_arg+0x2090> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1bdc, 0x2090, arm64_l_2090);
arm64_l_1be0:
	/* 0x1be0: and w8, w11, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1be4:
	/* 0x1be4: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_1be8:
	/* 0x1be8: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1bec:
	/* 0x1bec: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_1bf0:
	/* 0x1bf0: sub w10, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1bf4:
	/* 0x1bf4: b 20a0 <generic_kprobe_filter_arg+0x20a0> */
	ARM64_SIM_A64_JMP(0x1bf4, 0x20a0, arm64_l_20a0);
arm64_l_1bf8:
	/* 0x1bf8: ldrb w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1bfc:
	/* 0x1bfc: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c00:
	/* 0x1c00: b.cc 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1c00, 0x298, arm64_l_298);
arm64_l_1c04:
	/* 0x1c04: ldr w9, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1c08:
	/* 0x1c08: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1c0c:
	/* 0x1c0c: b.cc 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1c0c, 0x2d7c, arm64_l_2d7c);
arm64_l_1c10:
	/* 0x1c10: ldr w10, [x29, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1c14:
	/* 0x1c14: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1c18:
	/* 0x1c18: b.le 1f7c <generic_kprobe_filter_arg+0x1f7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1c18, 0x1f7c, arm64_l_1f7c);
arm64_l_1c1c:
	/* 0x1c1c: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1c20:
	/* 0x1c20: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1c24:
	/* 0x1c24: b.cs 2404 <generic_kprobe_filter_arg+0x2404> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1c24, 0x2404, arm64_l_2404);
arm64_l_1c28:
	/* 0x1c28: ldrb w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c2c:
	/* 0x1c2c: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c30:
	/* 0x1c30: b.eq 28c <generic_kprobe_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c30, 0x28c, arm64_l_28c);
arm64_l_1c34:
	/* 0x1c34: b 24c8 <generic_kprobe_filter_arg+0x24c8> */
	ARM64_SIM_A64_JMP(0x1c34, 0x24c8, arm64_l_24c8);
arm64_l_1c38:
	/* 0x1c38: ldrh w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c3c:
	/* 0x1c3c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c40:
	/* 0x1c40: b.cc 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1c40, 0x298, arm64_l_298);
arm64_l_1c44:
	/* 0x1c44: ldr w9, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1c48:
	/* 0x1c48: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1c4c:
	/* 0x1c4c: b.cc 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1c4c, 0x2d7c, arm64_l_2d7c);
arm64_l_1c50:
	/* 0x1c50: ldr w10, [x29, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1c54:
	/* 0x1c54: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1c58:
	/* 0x1c58: b.le 1f9c <generic_kprobe_filter_arg+0x1f9c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1c58, 0x1f9c, arm64_l_1f9c);
arm64_l_1c5c:
	/* 0x1c5c: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1c60:
	/* 0x1c60: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1c64:
	/* 0x1c64: b.cs 241c <generic_kprobe_filter_arg+0x241c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1c64, 0x241c, arm64_l_241c);
arm64_l_1c68:
	/* 0x1c68: ldrh w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c6c:
	/* 0x1c6c: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c70:
	/* 0x1c70: b.eq 28c <generic_kprobe_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c70, 0x28c, arm64_l_28c);
arm64_l_1c74:
	/* 0x1c74: b 2504 <generic_kprobe_filter_arg+0x2504> */
	ARM64_SIM_A64_JMP(0x1c74, 0x2504, arm64_l_2504);
arm64_l_1c78:
	/* 0x1c78: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1c7c:
	/* 0x1c7c: b 1f60 <generic_kprobe_filter_arg+0x1f60> */
	ARM64_SIM_A64_JMP(0x1c7c, 0x1f60, arm64_l_1f60);
arm64_l_1c80:
	/* 0x1c80: ldr w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c84:
	/* 0x1c84: cmp w11, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c88:
	/* 0x1c88: b.hi 1c94 <generic_kprobe_filter_arg+0x1c94> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1c88, 0x1c94, arm64_l_1c94);
arm64_l_1c8c:
	/* 0x1c8c: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c90:
	/* 0x1c90: b.ls 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1c90, 0x298, arm64_l_298);
arm64_l_1c94:
	/* 0x1c94: ldr w10, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1c98:
	/* 0x1c98: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1c9c:
	/* 0x1c9c: b.cc fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1c9c, 0xfc, arm64_l_fc);
arm64_l_1ca0:
	/* 0x1ca0: ldp w12, w11, [x29, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1ca4:
	/* 0x1ca4: mov w13, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ca8:
	/* 0x1ca8: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1cac:
	/* 0x1cac: b.hi 21ac <generic_kprobe_filter_arg+0x21ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1cac, 0x21ac, arm64_l_21ac);
arm64_l_1cb0:
	/* 0x1cb0: lsl w13, w13, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X13, ARM64_X13, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1cb4:
	/* 0x1cb4: mov w14, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1cb8:
	/* 0x1cb8: tst w13, w14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X13, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1cbc:
	/* 0x1cbc: b.eq 21ac <generic_kprobe_filter_arg+0x21ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1cbc, 0x21ac, arm64_l_21ac);
arm64_l_1cc0:
	/* 0x1cc0: cmp w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1cc4:
	/* 0x1cc4: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1cc8:
	/* 0x1cc8: b.gt 21c0 <generic_kprobe_filter_arg+0x21c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1cc8, 0x21c0, arm64_l_21c0);
arm64_l_1ccc:
	/* 0x1ccc: cmp w8, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1cd0:
	/* 0x1cd0: b.le 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1cd0, 0x298, arm64_l_298);
arm64_l_1cd4:
	/* 0x1cd4: b 21c0 <generic_kprobe_filter_arg+0x21c0> */
	ARM64_SIM_A64_JMP(0x1cd4, 0x21c0, arm64_l_21c0);
arm64_l_1cd8:
	/* 0x1cd8: ldr w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1cdc:
	/* 0x1cdc: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ce0:
	/* 0x1ce0: ccmp w10, w8, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_1ce4:
	/* 0x1ce4: cset w8, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_1ce8:
	/* 0x1ce8: ldr w11, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1cec:
	/* 0x1cec: cmp w11, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1cf0:
	/* 0x1cf0: b.cc 28fc <generic_kprobe_filter_arg+0x28fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1cf0, 0x28fc, arm64_l_28fc);
arm64_l_1cf4:
	/* 0x1cf4: ldp w13, w12, [x29, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X13, ARM64_X12, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1cf8:
	/* 0x1cf8: mov w14, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1cfc:
	/* 0x1cfc: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1d00:
	/* 0x1d00: b.hi 2160 <generic_kprobe_filter_arg+0x2160> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1d00, 0x2160, arm64_l_2160);
arm64_l_1d04:
	/* 0x1d04: lsl w14, w14, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X14, ARM64_X14, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1d08:
	/* 0x1d08: mov w1, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1d0c:
	/* 0x1d0c: tst w14, w1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X14, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d10:
	/* 0x1d10: b.eq 2160 <generic_kprobe_filter_arg+0x2160> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d10, 0x2160, arm64_l_2160);
arm64_l_1d14:
	/* 0x1d14: cmp w13, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d18:
	/* 0x1d18: ccmp w10, w12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_1d1c:
	/* 0x1d1c: cset w12, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_1d20:
	/* 0x1d20: b 216c <generic_kprobe_filter_arg+0x216c> */
	ARM64_SIM_A64_JMP(0x1d20, 0x216c, arm64_l_216c);
arm64_l_1d24:
	/* 0x1d24: mov w23, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1d28:
	/* 0x1d28: b 1214 <generic_kprobe_filter_arg+0x1214> */
	ARM64_SIM_A64_JMP(0x1d28, 0x1214, arm64_l_1214);
arm64_l_1d2c:
	/* 0x1d2c: cmp x13, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d30:
	/* 0x1d30: ccmp x10, x12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_1d34:
	/* 0x1d34: cset w12, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_1d38:
	/* 0x1d38: orr w8, w8, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1d3c:
	/* 0x1d3c: cmp w11, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1d40:
	/* 0x1d40: b.cc 26c4 <generic_kprobe_filter_arg+0x26c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1d40, 0x26c4, arm64_l_26c4);
arm64_l_1d44:
	/* 0x1d44: ldp x13, x12, [x29, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X13, ARM64_X12, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1d48:
	/* 0x1d48: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1d4c:
	/* 0x1d4c: b.eq 1d58 <generic_kprobe_filter_arg+0x1d58> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d4c, 0x1d58, arm64_l_1d58);
arm64_l_1d50:
	/* 0x1d50: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1d54:
	/* 0x1d54: b.ne 2200 <generic_kprobe_filter_arg+0x2200> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1d54, 0x2200, arm64_l_2200);
arm64_l_1d58:
	/* 0x1d58: cmp x13, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d5c:
	/* 0x1d5c: ccmp x10, x12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_1d60:
	/* 0x1d60: cset w12, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_1d64:
	/* 0x1d64: b 220c <generic_kprobe_filter_arg+0x220c> */
	ARM64_SIM_A64_JMP(0x1d64, 0x220c, arm64_l_220c);
arm64_l_1d68:
	/* 0x1d68: cmp x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d6c:
	/* 0x1d6c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1d70:
	/* 0x1d70: b.hi 1d7c <generic_kprobe_filter_arg+0x1d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1d70, 0x1d7c, arm64_l_1d7c);
arm64_l_1d74:
	/* 0x1d74: cmp x8, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d78:
	/* 0x1d78: b.ls 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1d78, 0x298, arm64_l_298);
arm64_l_1d7c:
	/* 0x1d7c: cmp w10, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1d80:
	/* 0x1d80: b.cc fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1d80, 0xfc, arm64_l_fc);
arm64_l_1d84:
	/* 0x1d84: ldp x12, x11, [x29, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1d88:
	/* 0x1d88: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1d8c:
	/* 0x1d8c: b.eq 1d98 <generic_kprobe_filter_arg+0x1d98> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d8c, 0x1d98, arm64_l_1d98);
arm64_l_1d90:
	/* 0x1d90: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1d94:
	/* 0x1d94: b.ne 2314 <generic_kprobe_filter_arg+0x2314> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1d94, 0x2314, arm64_l_2314);
arm64_l_1d98:
	/* 0x1d98: cmp x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d9c:
	/* 0x1d9c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1da0:
	/* 0x1da0: b.gt 2328 <generic_kprobe_filter_arg+0x2328> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1da0, 0x2328, arm64_l_2328);
arm64_l_1da4:
	/* 0x1da4: cmp x8, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1da8:
	/* 0x1da8: b.le 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1da8, 0x298, arm64_l_298);
arm64_l_1dac:
	/* 0x1dac: b 2328 <generic_kprobe_filter_arg+0x2328> */
	ARM64_SIM_A64_JMP(0x1dac, 0x2328, arm64_l_2328);
arm64_l_1db0:
	/* 0x1db0: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1db4:
	/* 0x1db4: cmp w9, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1db8:
	/* 0x1db8: b.ne 1dc4 <generic_kprobe_filter_arg+0x1dc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1db8, 0x1dc4, arm64_l_1dc4);
arm64_l_1dbc:
	/* 0x1dbc: cbz x10, 1dc4 <generic_kprobe_filter_arg+0x1dc4> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x1dbc, 0x1dc4, arm64_l_1dc4);
arm64_l_1dc0:
	/* 0x1dc0: ldrb w19, [x10, #58] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 58ULL);
arm64_l_1dc4:
	/* 0x1dc4: cmp w9, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1dc8:
	/* 0x1dc8: b.eq 1dd4 <generic_kprobe_filter_arg+0x1dd4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1dc8, 0x1dd4, arm64_l_1dd4);
arm64_l_1dcc:
	/* 0x1dcc: cmp w9, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_1dd0:
	/* 0x1dd0: b.ne 224c <generic_kprobe_filter_arg+0x224c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1dd0, 0x224c, arm64_l_224c);
arm64_l_1dd4:
	/* 0x1dd4: ldrb w8, [x29, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1dd8:
	/* 0x1dd8: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_1ddc:
	/* 0x1ddc: add x9, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1de0:
	/* 0x1de0: add x1, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1de4:
	/* 0x1de4: str w8, [sp, #172] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 172ULL);
arm64_l_1de8:
	/* 0x1de8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1dec:
	/* 0x1dec: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1df0:
	/* 0x1df0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1df4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1df4:
	/* 0x1df4: cbz x0, 223c <generic_kprobe_filter_arg+0x223c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1df4, 0x223c, arm64_l_223c);
arm64_l_1df8:
	/* 0x1df8: str x19, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1dfc:
	/* 0x1dfc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e00:
	/* 0x1e00: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1e04:
	/* 0x1e04: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1e08:
	/* 0x1e08: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1e0cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1e0c:
	/* 0x1e0c: ldr w9, [x29, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1e10:
	/* 0x1e10: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1e14:
	/* 0x1e14: cmp w9, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_1e18:
	/* 0x1e18: b.hi 2d24 <generic_kprobe_filter_arg+0x2d24> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1e18, 0x2d24, arm64_l_2d24);
arm64_l_1e1c:
	/* 0x1e1c: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1e20:
	/* 0x1e20: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e24:
	/* 0x1e24: mov w10, #0x8400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 33792ULL);
arm64_l_1e28:
	/* 0x1e28: lsl w9, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1e2c:
	/* 0x1e2c: movk w10, #0x3003, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 12291ULL);
arm64_l_1e30:
	/* 0x1e30: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e34:
	/* 0x1e34: b.ne 17c8 <generic_kprobe_filter_arg+0x17c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1e34, 0x17c8, arm64_l_17c8);
arm64_l_1e38:
	/* 0x1e38: mov w10, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_1e3c:
	/* 0x1e3c: movk w10, #0xc, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 12ULL);
arm64_l_1e40:
	/* 0x1e40: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e44:
	/* 0x1e44: b.eq 1e50 <generic_kprobe_filter_arg+0x1e50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e44, 0x1e50, arm64_l_1e50);
arm64_l_1e48:
	/* 0x1e48: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1e4c:
	/* 0x1e4c: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1e50:
	/* 0x1e50: mov w23, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1e54:
	/* 0x1e54: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1e58:
	/* 0x1e58: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1e5c:
	/* 0x1e5c: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1e60:
	/* 0x1e60: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x1e60, 0x294, arm64_l_294);
arm64_l_1e64:
	/* 0x1e64: ldr w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e68:
	/* 0x1e68: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e6c:
	/* 0x1e6c: b.hi 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1e6c, 0x298, arm64_l_298);
arm64_l_1e70:
	/* 0x1e70: b 1e80 <generic_kprobe_filter_arg+0x1e80> */
	ARM64_SIM_A64_JMP(0x1e70, 0x1e80, arm64_l_1e80);
arm64_l_1e74:
	/* 0x1e74: ldr w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e78:
	/* 0x1e78: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e7c:
	/* 0x1e7c: b.cc 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1e7c, 0x298, arm64_l_298);
arm64_l_1e80:
	/* 0x1e80: ldr w10, [x29, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1e84:
	/* 0x1e84: cmp w10, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1e88:
	/* 0x1e88: b.cc 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1e88, 0x2d7c, arm64_l_2d7c);
arm64_l_1e8c:
	/* 0x1e8c: ldr w11, [x29, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1e90:
	/* 0x1e90: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1e94:
	/* 0x1e94: b.le 1eb8 <generic_kprobe_filter_arg+0x1eb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1e94, 0x1eb8, arm64_l_1eb8);
arm64_l_1e98:
	/* 0x1e98: sub w12, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1e9c:
	/* 0x1e9c: cmp w12, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1ea0:
	/* 0x1ea0: b.cs 1ef8 <generic_kprobe_filter_arg+0x1ef8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1ea0, 0x1ef8, arm64_l_1ef8);
arm64_l_1ea4:
	/* 0x1ea4: ldr w12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ea8:
	/* 0x1ea8: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1eac:
	/* 0x1eac: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1eb0:
	/* 0x1eb0: b.eq 28c <generic_kprobe_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1eb0, 0x28c, arm64_l_28c);
arm64_l_1eb4:
	/* 0x1eb4: b 25f0 <generic_kprobe_filter_arg+0x25f0> */
	ARM64_SIM_A64_JMP(0x1eb4, 0x25f0, arm64_l_25f0);
arm64_l_1eb8:
	/* 0x1eb8: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1ebc:
	/* 0x1ebc: b.eq 1f18 <generic_kprobe_filter_arg+0x1f18> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ebc, 0x1f18, arm64_l_1f18);
arm64_l_1ec0:
	/* 0x1ec0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1ec4:
	/* 0x1ec4: b.ne 25f0 <generic_kprobe_filter_arg+0x25f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1ec4, 0x25f0, arm64_l_25f0);
arm64_l_1ec8:
	/* 0x1ec8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ecc:
	/* 0x1ecc: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1ed0:
	/* 0x1ed0: b.hi 25e0 <generic_kprobe_filter_arg+0x25e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1ed0, 0x25e0, arm64_l_25e0);
arm64_l_1ed4:
	/* 0x1ed4: lsl w12, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X12, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1ed8:
	/* 0x1ed8: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1edc:
	/* 0x1edc: tst w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ee0:
	/* 0x1ee0: b.eq 25e0 <generic_kprobe_filter_arg+0x25e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ee0, 0x25e0, arm64_l_25e0);
arm64_l_1ee4:
	/* 0x1ee4: ldr w12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ee8:
	/* 0x1ee8: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1eec:
	/* 0x1eec: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ef0:
	/* 0x1ef0: b.lt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x1ef0, 0x298, arm64_l_298);
arm64_l_1ef4:
	/* 0x1ef4: b 25f0 <generic_kprobe_filter_arg+0x25f0> */
	ARM64_SIM_A64_JMP(0x1ef4, 0x25f0, arm64_l_25f0);
arm64_l_1ef8:
	/* 0x1ef8: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1efc:
	/* 0x1efc: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f00:
	/* 0x1f00: b.ne 25f0 <generic_kprobe_filter_arg+0x25f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1f00, 0x25f0, arm64_l_25f0);
arm64_l_1f04:
	/* 0x1f04: ldr w12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f08:
	/* 0x1f08: tst w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f0c:
	/* 0x1f0c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f10:
	/* 0x1f10: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1f10, 0x298, arm64_l_298);
arm64_l_1f14:
	/* 0x1f14: b 25f0 <generic_kprobe_filter_arg+0x25f0> */
	ARM64_SIM_A64_JMP(0x1f14, 0x25f0, arm64_l_25f0);
arm64_l_1f18:
	/* 0x1f18: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f1c:
	/* 0x1f1c: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1f20:
	/* 0x1f20: b.hi 25cc <generic_kprobe_filter_arg+0x25cc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1f20, 0x25cc, arm64_l_25cc);
arm64_l_1f24:
	/* 0x1f24: lsl w12, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X12, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1f28:
	/* 0x1f28: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1f2c:
	/* 0x1f2c: tst w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f30:
	/* 0x1f30: b.eq 25cc <generic_kprobe_filter_arg+0x25cc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f30, 0x25cc, arm64_l_25cc);
arm64_l_1f34:
	/* 0x1f34: ldr w12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f38:
	/* 0x1f38: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f3c:
	/* 0x1f3c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f40:
	/* 0x1f40: b.gt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1f40, 0x298, arm64_l_298);
arm64_l_1f44:
	/* 0x1f44: b 25f0 <generic_kprobe_filter_arg+0x25f0> */
	ARM64_SIM_A64_JMP(0x1f44, 0x25f0, arm64_l_25f0);
arm64_l_1f48:
	/* 0x1f48: ldr w8, [x29, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1f4c:
	/* 0x1f4c: b 1f58 <generic_kprobe_filter_arg+0x1f58> */
	ARM64_SIM_A64_JMP(0x1f4c, 0x1f58, arm64_l_1f58);
arm64_l_1f50:
	/* 0x1f50: ldr w8, [x29, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1f54:
	/* 0x1f54: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1f58:
	/* 0x1f58: and w8, w8, #0xfffffffe */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967294ULL);
arm64_l_1f5c:
	/* 0x1f5c: cmp w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1f60:
	/* 0x1f60: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1f64:
	/* 0x1f64: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1f68:
	/* 0x1f68: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1f6c:
	/* 0x1f6c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f70:
	/* 0x1f70: mov w23, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1f74:
	/* 0x1f74: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1f78:
	/* 0x1f78: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x1f78, 0x294, arm64_l_294);
arm64_l_1f7c:
	/* 0x1f7c: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1f80:
	/* 0x1f80: b.eq 24bc <generic_kprobe_filter_arg+0x24bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f80, 0x24bc, arm64_l_24bc);
arm64_l_1f84:
	/* 0x1f84: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1f88:
	/* 0x1f88: b.ne 24c8 <generic_kprobe_filter_arg+0x24c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1f88, 0x24c8, arm64_l_24c8);
arm64_l_1f8c:
	/* 0x1f8c: ldrb w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f90:
	/* 0x1f90: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f94:
	/* 0x1f94: b.hi 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1f94, 0x298, arm64_l_298);
arm64_l_1f98:
	/* 0x1f98: b 24c8 <generic_kprobe_filter_arg+0x24c8> */
	ARM64_SIM_A64_JMP(0x1f98, 0x24c8, arm64_l_24c8);
arm64_l_1f9c:
	/* 0x1f9c: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1fa0:
	/* 0x1fa0: b.eq 24f8 <generic_kprobe_filter_arg+0x24f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1fa0, 0x24f8, arm64_l_24f8);
arm64_l_1fa4:
	/* 0x1fa4: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1fa8:
	/* 0x1fa8: b.ne 2504 <generic_kprobe_filter_arg+0x2504> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1fa8, 0x2504, arm64_l_2504);
arm64_l_1fac:
	/* 0x1fac: ldrh w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1fb0:
	/* 0x1fb0: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fb4:
	/* 0x1fb4: b.hi 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1fb4, 0x298, arm64_l_298);
arm64_l_1fb8:
	/* 0x1fb8: b 2504 <generic_kprobe_filter_arg+0x2504> */
	ARM64_SIM_A64_JMP(0x1fb8, 0x2504, arm64_l_2504);
arm64_l_1fbc:
	/* 0x1fbc: strh w24, [x0], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_1fc0:
	/* 0x1fc0: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1fc4:
	/* 0x1fc4: mov w1, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1fc8:
	/* 0x1fc8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1fccULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1fcc:
	/* 0x1fcc: ldr w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1fd0:
	/* 0x1fd0: and w8, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1fd4:
	/* 0x1fd4: cmp w8, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fd8:
	/* 0x1fd8: b.ls 1ff8 <generic_kprobe_filter_arg+0x1ff8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1fd8, 0x1ff8, arm64_l_1ff8);
arm64_l_1fdc:
	/* 0x1fdc: add x9, x22, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X22, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1fe0:
	/* 0x1fe0: sub w8, w8, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_1fe4:
	/* 0x1fe4: ldr x2, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1fe8:
	/* 0x1fe8: add x0, x9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1fec:
	/* 0x1fec: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1ff0:
	/* 0x1ff0: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1ff4:
	/* 0x1ff4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1ff8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1ff8:
	/* 0x1ff8: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_1ffc:
	/* 0x1ffc: cmp w23, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2000:
	/* 0x2000: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_2004:
	/* 0x2004: b.gt 2040 <generic_kprobe_filter_arg+0x2040> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2004, 0x2040, arm64_l_2040);
arm64_l_2008:
	/* 0x2008: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_200c:
	/* 0x200c: cmp w23, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2010:
	/* 0x2010: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_2014:
	/* 0x2014: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2018:
	/* 0x2018: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_201c:
	/* 0x201c: b.gt 2458 <generic_kprobe_filter_arg+0x2458> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x201c, 0x2458, arm64_l_2458);
arm64_l_2020:
	/* 0x2020: cbz w23, 2838 <generic_kprobe_filter_arg+0x2838> */
	ARM64_SIM_A64_CBZ(ARM64_X23, 0x2020, 0x2838, arm64_l_2838);
arm64_l_2024:
	/* 0x2024: cmp w23, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2028:
	/* 0x2028: b.ne 718 <generic_kprobe_filter_arg+0x718> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2028, 0x718, arm64_l_718);
arm64_l_202c:
	/* 0x202c: adrp x0, 0 <string_maps_1> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_1_9));
arm64_l_2030:
	/* 0x2030: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2034:
	/* 0x2034: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2038:
	/* 0x2038: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_203c:
	/* 0x203c: b 2884 <generic_kprobe_filter_arg+0x2884> */
	ARM64_SIM_A64_JMP(0x203c, 0x2884, arm64_l_2884);
arm64_l_2040:
	/* 0x2040: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_2044:
	/* 0x2044: cmp w23, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2048:
	/* 0x2048: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_204c:
	/* 0x204c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2050:
	/* 0x2050: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2054:
	/* 0x2054: b.gt 247c <generic_kprobe_filter_arg+0x247c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2054, 0x247c, arm64_l_247c);
arm64_l_2058:
	/* 0x2058: cmp w23, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_205c:
	/* 0x205c: b.eq 284c <generic_kprobe_filter_arg+0x284c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x205c, 0x284c, arm64_l_284c);
arm64_l_2060:
	/* 0x2060: cmp w23, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2064:
	/* 0x2064: b.ne 718 <generic_kprobe_filter_arg+0x718> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2064, 0x718, arm64_l_718);
arm64_l_2068:
	/* 0x2068: adrp x0, 0 <string_maps_5> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_5_13));
arm64_l_206c:
	/* 0x206c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2070:
	/* 0x2070: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2074:
	/* 0x2074: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2078:
	/* 0x2078: b 2884 <generic_kprobe_filter_arg+0x2884> */
	ARM64_SIM_A64_JMP(0x2078, 0x2884, arm64_l_2884);
arm64_l_207c:
	/* 0x207c: and w8, w22, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_2080:
	/* 0x2080: mov w9, #0x1fe */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 510ULL);
arm64_l_2084:
	/* 0x2084: cmp w8, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_2088:
	/* 0x2088: mov w8, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_208c:
	/* 0x208c: csel w11, w9, w8, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_2090:
	/* 0x2090: and w8, w11, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_2094:
	/* 0x2094: cmp w8, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_2098:
	/* 0x2098: mov w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 6ULL);
arm64_l_209c:
	/* 0x209c: cinc w10, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CINC, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_20a0:
	/* 0x20a0: add x8, x29, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_20a4:
	/* 0x20a4: and w9, w10, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_20a8:
	/* 0x20a8: ldr w8, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_20ac:
	/* 0x20ac: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_20b0:
	/* 0x20b0: b.eq 2cd8 <generic_kprobe_filter_arg+0x2cd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x20b0, 0x2cd8, arm64_l_2cd8);
arm64_l_20b4:
	/* 0x20b4: stp w11, w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_20b8:
	/* 0x20b8: str w10, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_20bc:
	/* 0x20bc: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_16));
arm64_l_20c0:
	/* 0x20c0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_20c4:
	/* 0x20c4: add x19, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_20c8:
	/* 0x20c8: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_20cc:
	/* 0x20cc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_20d0:
	/* 0x20d0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x20d4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_20d4:
	/* 0x20d4: mov x9, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_20d8:
	/* 0x20d8: adrp x0, 0 <heap_ro_zero> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero_4));
arm64_l_20dc:
	/* 0x20dc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_20e0:
	/* 0x20e0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_20e4:
	/* 0x20e4: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_20e8:
	/* 0x20e8: mov x19, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_20ec:
	/* 0x20ec: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x20f0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_20f0:
	/* 0x20f0: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_20f4:
	/* 0x20f4: cbz x19, 2cdc <generic_kprobe_filter_arg+0x2cdc> */
	ARM64_SIM_A64_CBZ(ARM64_X19, 0x20f4, 0x2cdc, arm64_l_2cdc);
arm64_l_20f8:
	/* 0x20f8: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_20fc:
	/* 0x20fc: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_2100:
	/* 0x2100: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2104:
	/* 0x2104: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2108:
	/* 0x2108: cbz x0, 2cec <generic_kprobe_filter_arg+0x2cec> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2108, 0x2cec, arm64_l_2cec);
arm64_l_210c:
	/* 0x210c: ldr w23, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2110:
	/* 0x2110: str x0, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2114:
	/* 0x2114: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2118:
	/* 0x2118: cmp w23, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_211c:
	/* 0x211c: b.gt 2794 <generic_kprobe_filter_arg+0x2794> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x211c, 0x2794, arm64_l_2794);
arm64_l_2120:
	/* 0x2120: strb w22, [x0], #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 1ULL);
arm64_l_2124:
	/* 0x2124: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2128:
	/* 0x2128: mov w1, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_212c:
	/* 0x212c: mov x2, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2130:
	/* 0x2130: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2134ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2134:
	/* 0x2134: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2138:
	/* 0x2138: and w8, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_213c:
	/* 0x213c: cmp w8, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2140:
	/* 0x2140: b.ls 27d4 <generic_kprobe_filter_arg+0x27d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2140, 0x27d4, arm64_l_27d4);
arm64_l_2144:
	/* 0x2144: add x9, x19, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X19, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2148:
	/* 0x2148: sub w8, w8, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_214c:
	/* 0x214c: ldr x2, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2150:
	/* 0x2150: add x0, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2154:
	/* 0x2154: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2158:
	/* 0x2158: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_215c:
	/* 0x215c: b 27d0 <generic_kprobe_filter_arg+0x27d0> */
	ARM64_SIM_A64_JMP(0x215c, 0x27d0, arm64_l_27d0);
arm64_l_2160:
	/* 0x2160: cmp w13, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2164:
	/* 0x2164: ccmp w10, w12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_2168:
	/* 0x2168: cset w12, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_216c:
	/* 0x216c: orr w8, w8, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_2170:
	/* 0x2170: cmp w11, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_2174:
	/* 0x2174: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2178:
	/* 0x2178: b.cc 28fc <generic_kprobe_filter_arg+0x28fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2178, 0x28fc, arm64_l_28fc);
arm64_l_217c:
	/* 0x217c: ldp w13, w12, [x29, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X13, ARM64_X12, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2180:
	/* 0x2180: mov w14, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2184:
	/* 0x2184: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2188:
	/* 0x2188: b.hi 2534 <generic_kprobe_filter_arg+0x2534> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2188, 0x2534, arm64_l_2534);
arm64_l_218c:
	/* 0x218c: lsl w14, w14, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X14, ARM64_X14, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2190:
	/* 0x2190: mov w1, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2194:
	/* 0x2194: tst w14, w1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X14, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2198:
	/* 0x2198: b.eq 2534 <generic_kprobe_filter_arg+0x2534> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2198, 0x2534, arm64_l_2534);
arm64_l_219c:
	/* 0x219c: cmp w13, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_21a0:
	/* 0x21a0: ccmp w10, w12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_21a4:
	/* 0x21a4: cset w12, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_21a8:
	/* 0x21a8: b 2540 <generic_kprobe_filter_arg+0x2540> */
	ARM64_SIM_A64_JMP(0x21a8, 0x2540, arm64_l_2540);
arm64_l_21ac:
	/* 0x21ac: cmp w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_21b0:
	/* 0x21b0: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_21b4:
	/* 0x21b4: b.hi 21c0 <generic_kprobe_filter_arg+0x21c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x21b4, 0x21c0, arm64_l_21c0);
arm64_l_21b8:
	/* 0x21b8: cmp w8, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_21bc:
	/* 0x21bc: b.ls 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x21bc, 0x298, arm64_l_298);
arm64_l_21c0:
	/* 0x21c0: cmp w10, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_21c4:
	/* 0x21c4: b.cc fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x21c4, 0xfc, arm64_l_fc);
arm64_l_21c8:
	/* 0x21c8: ldp w12, w11, [x29, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_21cc:
	/* 0x21cc: mov w13, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_21d0:
	/* 0x21d0: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_21d4:
	/* 0x21d4: b.hi 2580 <generic_kprobe_filter_arg+0x2580> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x21d4, 0x2580, arm64_l_2580);
arm64_l_21d8:
	/* 0x21d8: lsl w13, w13, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X13, ARM64_X13, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_21dc:
	/* 0x21dc: mov w14, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_21e0:
	/* 0x21e0: tst w13, w14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X13, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_21e4:
	/* 0x21e4: b.eq 2580 <generic_kprobe_filter_arg+0x2580> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x21e4, 0x2580, arm64_l_2580);
arm64_l_21e8:
	/* 0x21e8: cmp w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_21ec:
	/* 0x21ec: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_21f0:
	/* 0x21f0: b.gt 2594 <generic_kprobe_filter_arg+0x2594> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x21f0, 0x2594, arm64_l_2594);
arm64_l_21f4:
	/* 0x21f4: cmp w8, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_21f8:
	/* 0x21f8: b.le 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x21f8, 0x298, arm64_l_298);
arm64_l_21fc:
	/* 0x21fc: b 2594 <generic_kprobe_filter_arg+0x2594> */
	ARM64_SIM_A64_JMP(0x21fc, 0x2594, arm64_l_2594);
arm64_l_2200:
	/* 0x2200: cmp x13, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2204:
	/* 0x2204: ccmp x10, x12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_2208:
	/* 0x2208: cset w12, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_220c:
	/* 0x220c: orr w8, w8, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_2210:
	/* 0x2210: cmp w11, #0x39 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 57ULL);
arm64_l_2214:
	/* 0x2214: b.cc 26c4 <generic_kprobe_filter_arg+0x26c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2214, 0x26c4, arm64_l_26c4);
arm64_l_2218:
	/* 0x2218: ldp x12, x11, [x29, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_221c:
	/* 0x221c: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2220:
	/* 0x2220: b.eq 222c <generic_kprobe_filter_arg+0x222c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2220, 0x222c, arm64_l_222c);
arm64_l_2224:
	/* 0x2224: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2228:
	/* 0x2228: b.ne 26b4 <generic_kprobe_filter_arg+0x26b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2228, 0x26b4, arm64_l_26b4);
arm64_l_222c:
	/* 0x222c: cmp x12, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2230:
	/* 0x2230: ccmp x10, x11, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_2234:
	/* 0x2234: cset w9, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_2238:
	/* 0x2238: b 26c0 <generic_kprobe_filter_arg+0x26c0> */
	ARM64_SIM_A64_JMP(0x2238, 0x26c0, arm64_l_26c0);
arm64_l_223c:
	/* 0x223c: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2240:
	/* 0x2240: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2244:
	/* 0x2244: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2248:
	/* 0x2248: b 1e54 <generic_kprobe_filter_arg+0x1e54> */
	ARM64_SIM_A64_JMP(0x2248, 0x1e54, arm64_l_1e54);
arm64_l_224c:
	/* 0x224c: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2250:
	/* 0x2250: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2254:
	/* 0x2254: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x2254, 0x294, arm64_l_294);
arm64_l_2258:
	/* 0x2258: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_225c:
	/* 0x225c: mov x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2260:
	/* 0x2260: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2264:
	/* 0x2264: mov w1, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2268:
	/* 0x2268: mov x2, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_226c:
	/* 0x226c: strh w24, [x0], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_2270:
	/* 0x2270: mov x22, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2274:
	/* 0x2274: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2278ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2278:
	/* 0x2278: ldr w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_227c:
	/* 0x227c: and w8, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_2280:
	/* 0x2280: cmp w8, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2284:
	/* 0x2284: b.ls 22a4 <generic_kprobe_filter_arg+0x22a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2284, 0x22a4, arm64_l_22a4);
arm64_l_2288:
	/* 0x2288: add x9, x22, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X22, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_228c:
	/* 0x228c: sub w8, w8, w24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_2290:
	/* 0x2290: add x0, x9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2294:
	/* 0x2294: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2298:
	/* 0x2298: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_229c:
	/* 0x229c: mov x2, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_22a0:
	/* 0x22a0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x22a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_22a4:
	/* 0x22a4: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_22a8:
	/* 0x22a8: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_22ac:
	/* 0x22ac: ldr w8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_22b0:
	/* 0x22b0: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_22b4:
	/* 0x22b4: b.gt 22e4 <generic_kprobe_filter_arg+0x22e4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x22b4, 0x22e4, arm64_l_22e4);
arm64_l_22b8:
	/* 0x22b8: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_22bc:
	/* 0x22bc: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_22c0:
	/* 0x22c0: b.gt 26d0 <generic_kprobe_filter_arg+0x26d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x22c0, 0x26d0, arm64_l_26d0);
arm64_l_22c4:
	/* 0x22c4: cbz w8, 2a0c <generic_kprobe_filter_arg+0x2a0c> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x22c4, 0x2a0c, arm64_l_2a0c);
arm64_l_22c8:
	/* 0x22c8: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_22cc:
	/* 0x22cc: b.ne 2718 <generic_kprobe_filter_arg+0x2718> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x22cc, 0x2718, arm64_l_2718);
arm64_l_22d0:
	/* 0x22d0: adrp x0, 0 <string_maps_1> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_1_9));
arm64_l_22d4:
	/* 0x22d4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_22d8:
	/* 0x22d8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_22dc:
	/* 0x22dc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_22e0:
	/* 0x22e0: b 2a58 <generic_kprobe_filter_arg+0x2a58> */
	ARM64_SIM_A64_JMP(0x22e0, 0x2a58, arm64_l_2a58);
arm64_l_22e4:
	/* 0x22e4: cmp w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_22e8:
	/* 0x22e8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_22ec:
	/* 0x22ec: b.gt 26f4 <generic_kprobe_filter_arg+0x26f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x22ec, 0x26f4, arm64_l_26f4);
arm64_l_22f0:
	/* 0x22f0: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_22f4:
	/* 0x22f4: b.eq 2a20 <generic_kprobe_filter_arg+0x2a20> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x22f4, 0x2a20, arm64_l_2a20);
arm64_l_22f8:
	/* 0x22f8: cmp w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_22fc:
	/* 0x22fc: b.ne 2718 <generic_kprobe_filter_arg+0x2718> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x22fc, 0x2718, arm64_l_2718);
arm64_l_2300:
	/* 0x2300: adrp x0, 0 <string_maps_5> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_5_13));
arm64_l_2304:
	/* 0x2304: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2308:
	/* 0x2308: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_230c:
	/* 0x230c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2310:
	/* 0x2310: b 2a58 <generic_kprobe_filter_arg+0x2a58> */
	ARM64_SIM_A64_JMP(0x2310, 0x2a58, arm64_l_2a58);
arm64_l_2314:
	/* 0x2314: cmp x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2318:
	/* 0x2318: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_231c:
	/* 0x231c: b.hi 2328 <generic_kprobe_filter_arg+0x2328> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x231c, 0x2328, arm64_l_2328);
arm64_l_2320:
	/* 0x2320: cmp x8, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2324:
	/* 0x2324: b.ls 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2324, 0x298, arm64_l_298);
arm64_l_2328:
	/* 0x2328: cmp w10, #0x39 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 57ULL);
arm64_l_232c:
	/* 0x232c: b.cc fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x232c, 0xfc, arm64_l_fc);
arm64_l_2330:
	/* 0x2330: ldp x11, x10, [x29, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_2334:
	/* 0x2334: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2338:
	/* 0x2338: b.eq 2344 <generic_kprobe_filter_arg+0x2344> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2338, 0x2344, arm64_l_2344);
arm64_l_233c:
	/* 0x233c: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2340:
	/* 0x2340: b.ne 2738 <generic_kprobe_filter_arg+0x2738> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2340, 0x2738, arm64_l_2738);
arm64_l_2344:
	/* 0x2344: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2348:
	/* 0x2348: b.gt fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2348, 0xfc, arm64_l_fc);
arm64_l_234c:
	/* 0x234c: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2350:
	/* 0x2350: b.le 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2350, 0x298, arm64_l_298);
arm64_l_2354:
	/* 0x2354: b fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x2354, 0xfc, arm64_l_fc);
arm64_l_2358:
	/* 0x2358: ldr x12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_235c:
	/* 0x235c: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2360:
	/* 0x2360: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2364:
	/* 0x2364: b.hi 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2364, 0x298, arm64_l_298);
arm64_l_2368:
	/* 0x2368: b 237c <generic_kprobe_filter_arg+0x237c> */
	ARM64_SIM_A64_JMP(0x2368, 0x237c, arm64_l_237c);
arm64_l_236c:
	/* 0x236c: ldr x12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2370:
	/* 0x2370: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2374:
	/* 0x2374: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2378:
	/* 0x2378: b.cc 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2378, 0x298, arm64_l_298);
arm64_l_237c:
	/* 0x237c: cmp w10, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_2380:
	/* 0x2380: b.cc 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2380, 0x2d7c, arm64_l_2d7c);
arm64_l_2384:
	/* 0x2384: ldr x11, [x29, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2388:
	/* 0x2388: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_238c:
	/* 0x238c: b.le 23b0 <generic_kprobe_filter_arg+0x23b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x238c, 0x23b0, arm64_l_23b0);
arm64_l_2390:
	/* 0x2390: sub w12, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2394:
	/* 0x2394: cmp w12, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2398:
	/* 0x2398: b.cs 23e4 <generic_kprobe_filter_arg+0x23e4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2398, 0x23e4, arm64_l_23e4);
arm64_l_239c:
	/* 0x239c: ldr x12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_23a0:
	/* 0x23a0: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_23a4:
	/* 0x23a4: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_23a8:
	/* 0x23a8: b.eq 28c <generic_kprobe_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x23a8, 0x28c, arm64_l_28c);
arm64_l_23ac:
	/* 0x23ac: b 2928 <generic_kprobe_filter_arg+0x2928> */
	ARM64_SIM_A64_JMP(0x23ac, 0x2928, arm64_l_2928);
arm64_l_23b0:
	/* 0x23b0: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_23b4:
	/* 0x23b4: b.eq 2434 <generic_kprobe_filter_arg+0x2434> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x23b4, 0x2434, arm64_l_2434);
arm64_l_23b8:
	/* 0x23b8: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_23bc:
	/* 0x23bc: b.ne 2928 <generic_kprobe_filter_arg+0x2928> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x23bc, 0x2928, arm64_l_2928);
arm64_l_23c0:
	/* 0x23c0: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_23c4:
	/* 0x23c4: b.eq 23d0 <generic_kprobe_filter_arg+0x23d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x23c4, 0x23d0, arm64_l_23d0);
arm64_l_23c8:
	/* 0x23c8: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_23cc:
	/* 0x23cc: b.ne 2918 <generic_kprobe_filter_arg+0x2918> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x23cc, 0x2918, arm64_l_2918);
arm64_l_23d0:
	/* 0x23d0: ldr x12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_23d4:
	/* 0x23d4: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_23d8:
	/* 0x23d8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_23dc:
	/* 0x23dc: b.lt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x23dc, 0x298, arm64_l_298);
arm64_l_23e0:
	/* 0x23e0: b 2928 <generic_kprobe_filter_arg+0x2928> */
	ARM64_SIM_A64_JMP(0x23e0, 0x2928, arm64_l_2928);
arm64_l_23e4:
	/* 0x23e4: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_23e8:
	/* 0x23e8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_23ec:
	/* 0x23ec: b.ne 2928 <generic_kprobe_filter_arg+0x2928> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x23ec, 0x2928, arm64_l_2928);
arm64_l_23f0:
	/* 0x23f0: ldr x12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_23f4:
	/* 0x23f4: tst x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_23f8:
	/* 0x23f8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_23fc:
	/* 0x23fc: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x23fc, 0x298, arm64_l_298);
arm64_l_2400:
	/* 0x2400: b 2928 <generic_kprobe_filter_arg+0x2928> */
	ARM64_SIM_A64_JMP(0x2400, 0x2928, arm64_l_2928);
arm64_l_2404:
	/* 0x2404: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2408:
	/* 0x2408: b.ne 24c8 <generic_kprobe_filter_arg+0x24c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2408, 0x24c8, arm64_l_24c8);
arm64_l_240c:
	/* 0x240c: ldrb w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2410:
	/* 0x2410: tst w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2414:
	/* 0x2414: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2414, 0x298, arm64_l_298);
arm64_l_2418:
	/* 0x2418: b 24c8 <generic_kprobe_filter_arg+0x24c8> */
	ARM64_SIM_A64_JMP(0x2418, 0x24c8, arm64_l_24c8);
arm64_l_241c:
	/* 0x241c: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2420:
	/* 0x2420: b.ne 2504 <generic_kprobe_filter_arg+0x2504> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2420, 0x2504, arm64_l_2504);
arm64_l_2424:
	/* 0x2424: ldrh w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2428:
	/* 0x2428: tst w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_242c:
	/* 0x242c: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x242c, 0x298, arm64_l_298);
arm64_l_2430:
	/* 0x2430: b 2504 <generic_kprobe_filter_arg+0x2504> */
	ARM64_SIM_A64_JMP(0x2430, 0x2504, arm64_l_2504);
arm64_l_2434:
	/* 0x2434: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2438:
	/* 0x2438: b.eq 2444 <generic_kprobe_filter_arg+0x2444> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2438, 0x2444, arm64_l_2444);
arm64_l_243c:
	/* 0x243c: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2440:
	/* 0x2440: b.ne 2904 <generic_kprobe_filter_arg+0x2904> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2440, 0x2904, arm64_l_2904);
arm64_l_2444:
	/* 0x2444: ldr x12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2448:
	/* 0x2448: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_244c:
	/* 0x244c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2450:
	/* 0x2450: b.gt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2450, 0x298, arm64_l_298);
arm64_l_2454:
	/* 0x2454: b 2928 <generic_kprobe_filter_arg+0x2928> */
	ARM64_SIM_A64_JMP(0x2454, 0x2928, arm64_l_2928);
arm64_l_2458:
	/* 0x2458: cmp w23, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_245c:
	/* 0x245c: b.eq 2860 <generic_kprobe_filter_arg+0x2860> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x245c, 0x2860, arm64_l_2860);
arm64_l_2460:
	/* 0x2460: cmp w23, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2464:
	/* 0x2464: b.ne 718 <generic_kprobe_filter_arg+0x718> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2464, 0x718, arm64_l_718);
arm64_l_2468:
	/* 0x2468: adrp x0, 0 <string_maps_3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_3_11));
arm64_l_246c:
	/* 0x246c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2470:
	/* 0x2470: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2474:
	/* 0x2474: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2478:
	/* 0x2478: b 2884 <generic_kprobe_filter_arg+0x2884> */
	ARM64_SIM_A64_JMP(0x2478, 0x2884, arm64_l_2884);
arm64_l_247c:
	/* 0x247c: cmp w23, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2480:
	/* 0x2480: b.eq 2874 <generic_kprobe_filter_arg+0x2874> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2480, 0x2874, arm64_l_2874);
arm64_l_2484:
	/* 0x2484: cmp w23, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_2488:
	/* 0x2488: b.ne 718 <generic_kprobe_filter_arg+0x718> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2488, 0x718, arm64_l_718);
arm64_l_248c:
	/* 0x248c: adrp x0, 0 <string_maps_7> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_7_15));
arm64_l_2490:
	/* 0x2490: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2494:
	/* 0x2494: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2498:
	/* 0x2498: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_249c:
	/* 0x249c: b 2884 <generic_kprobe_filter_arg+0x2884> */
	ARM64_SIM_A64_JMP(0x249c, 0x2884, arm64_l_2884);
arm64_l_24a0:
	/* 0x24a0: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_24a4:
	/* 0x24a4: b 24ac <generic_kprobe_filter_arg+0x24ac> */
	ARM64_SIM_A64_JMP(0x24a4, 0x24ac, arm64_l_24ac);
arm64_l_24a8:
	/* 0x24a8: mov w23, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_24ac:
	/* 0x24ac: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_24b0:
	/* 0x24b0: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_24b4:
	/* 0x24b4: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_24b8:
	/* 0x24b8: b 2ce8 <generic_kprobe_filter_arg+0x2ce8> */
	ARM64_SIM_A64_JMP(0x24b8, 0x2ce8, arm64_l_2ce8);
arm64_l_24bc:
	/* 0x24bc: ldrb w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_24c0:
	/* 0x24c0: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_24c4:
	/* 0x24c4: b.cc 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x24c4, 0x298, arm64_l_298);
arm64_l_24c8:
	/* 0x24c8: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_24cc:
	/* 0x24cc: b.cc 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x24cc, 0x2d7c, arm64_l_2d7c);
arm64_l_24d0:
	/* 0x24d0: ldr w10, [x29, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_24d4:
	/* 0x24d4: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_24d8:
	/* 0x24d8: b.le 274c <generic_kprobe_filter_arg+0x274c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x24d8, 0x274c, arm64_l_274c);
arm64_l_24dc:
	/* 0x24dc: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_24e0:
	/* 0x24e0: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_24e4:
	/* 0x24e4: b.cs 29a8 <generic_kprobe_filter_arg+0x29a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x24e4, 0x29a8, arm64_l_29a8);
arm64_l_24e8:
	/* 0x24e8: ldrb w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_24ec:
	/* 0x24ec: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_24f0:
	/* 0x24f0: b.eq 28c <generic_kprobe_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x24f0, 0x28c, arm64_l_28c);
arm64_l_24f4:
	/* 0x24f4: b 2ad8 <generic_kprobe_filter_arg+0x2ad8> */
	ARM64_SIM_A64_JMP(0x24f4, 0x2ad8, arm64_l_2ad8);
arm64_l_24f8:
	/* 0x24f8: ldrh w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_24fc:
	/* 0x24fc: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2500:
	/* 0x2500: b.cc 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2500, 0x298, arm64_l_298);
arm64_l_2504:
	/* 0x2504: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2508:
	/* 0x2508: b.cc 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2508, 0x2d7c, arm64_l_2d7c);
arm64_l_250c:
	/* 0x250c: ldr w10, [x29, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2510:
	/* 0x2510: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2514:
	/* 0x2514: b.le 276c <generic_kprobe_filter_arg+0x276c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2514, 0x276c, arm64_l_276c);
arm64_l_2518:
	/* 0x2518: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_251c:
	/* 0x251c: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2520:
	/* 0x2520: b.cs 29c0 <generic_kprobe_filter_arg+0x29c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2520, 0x29c0, arm64_l_29c0);
arm64_l_2524:
	/* 0x2524: ldrh w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2528:
	/* 0x2528: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_252c:
	/* 0x252c: b.eq 28c <generic_kprobe_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x252c, 0x28c, arm64_l_28c);
arm64_l_2530:
	/* 0x2530: b 2b1c <generic_kprobe_filter_arg+0x2b1c> */
	ARM64_SIM_A64_JMP(0x2530, 0x2b1c, arm64_l_2b1c);
arm64_l_2534:
	/* 0x2534: cmp w13, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2538:
	/* 0x2538: ccmp w10, w12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_253c:
	/* 0x253c: cset w12, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_2540:
	/* 0x2540: orr w8, w8, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_2544:
	/* 0x2544: cmp w11, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2548:
	/* 0x2548: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_254c:
	/* 0x254c: b.cc 28fc <generic_kprobe_filter_arg+0x28fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x254c, 0x28fc, arm64_l_28fc);
arm64_l_2550:
	/* 0x2550: ldp w12, w11, [x29, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2554:
	/* 0x2554: mov w13, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2558:
	/* 0x2558: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_255c:
	/* 0x255c: b.hi 28e8 <generic_kprobe_filter_arg+0x28e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x255c, 0x28e8, arm64_l_28e8);
arm64_l_2560:
	/* 0x2560: lsl w9, w13, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X13, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2564:
	/* 0x2564: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2568:
	/* 0x2568: tst w9, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_256c:
	/* 0x256c: b.eq 28e8 <generic_kprobe_filter_arg+0x28e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x256c, 0x28e8, arm64_l_28e8);
arm64_l_2570:
	/* 0x2570: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2574:
	/* 0x2574: ccmp w10, w11, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_2578:
	/* 0x2578: cset w9, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_257c:
	/* 0x257c: b 28f4 <generic_kprobe_filter_arg+0x28f4> */
	ARM64_SIM_A64_JMP(0x257c, 0x28f4, arm64_l_28f4);
arm64_l_2580:
	/* 0x2580: cmp w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2584:
	/* 0x2584: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2588:
	/* 0x2588: b.hi 2594 <generic_kprobe_filter_arg+0x2594> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2588, 0x2594, arm64_l_2594);
arm64_l_258c:
	/* 0x258c: cmp w8, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2590:
	/* 0x2590: b.ls 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2590, 0x298, arm64_l_298);
arm64_l_2594:
	/* 0x2594: cmp w10, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2598:
	/* 0x2598: b.cc fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2598, 0xfc, arm64_l_fc);
arm64_l_259c:
	/* 0x259c: ldp w11, w10, [x29, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_25a0:
	/* 0x25a0: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_25a4:
	/* 0x25a4: b.hi 29d8 <generic_kprobe_filter_arg+0x29d8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x25a4, 0x29d8, arm64_l_29d8);
arm64_l_25a8:
	/* 0x25a8: lsl w9, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_25ac:
	/* 0x25ac: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_25b0:
	/* 0x25b0: tst w9, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_25b4:
	/* 0x25b4: b.eq 29d8 <generic_kprobe_filter_arg+0x29d8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x25b4, 0x29d8, arm64_l_29d8);
arm64_l_25b8:
	/* 0x25b8: cmp w11, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_25bc:
	/* 0x25bc: b.gt fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x25bc, 0xfc, arm64_l_fc);
arm64_l_25c0:
	/* 0x25c0: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_25c4:
	/* 0x25c4: b.le 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x25c4, 0x298, arm64_l_298);
arm64_l_25c8:
	/* 0x25c8: b fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x25c8, 0xfc, arm64_l_fc);
arm64_l_25cc:
	/* 0x25cc: ldr w12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_25d0:
	/* 0x25d0: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_25d4:
	/* 0x25d4: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_25d8:
	/* 0x25d8: b.hi 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x25d8, 0x298, arm64_l_298);
arm64_l_25dc:
	/* 0x25dc: b 25f0 <generic_kprobe_filter_arg+0x25f0> */
	ARM64_SIM_A64_JMP(0x25dc, 0x25f0, arm64_l_25f0);
arm64_l_25e0:
	/* 0x25e0: ldr w12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_25e4:
	/* 0x25e4: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_25e8:
	/* 0x25e8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_25ec:
	/* 0x25ec: b.cc 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x25ec, 0x298, arm64_l_298);
arm64_l_25f0:
	/* 0x25f0: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_25f4:
	/* 0x25f4: b.cc 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x25f4, 0x2d7c, arm64_l_2d7c);
arm64_l_25f8:
	/* 0x25f8: ldr w11, [x29, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_25fc:
	/* 0x25fc: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2600:
	/* 0x2600: b.le 2624 <generic_kprobe_filter_arg+0x2624> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2600, 0x2624, arm64_l_2624);
arm64_l_2604:
	/* 0x2604: sub w12, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2608:
	/* 0x2608: cmp w12, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_260c:
	/* 0x260c: b.cs 2664 <generic_kprobe_filter_arg+0x2664> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x260c, 0x2664, arm64_l_2664);
arm64_l_2610:
	/* 0x2610: ldr w12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2614:
	/* 0x2614: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2618:
	/* 0x2618: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_261c:
	/* 0x261c: b.eq 28c <generic_kprobe_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x261c, 0x28c, arm64_l_28c);
arm64_l_2620:
	/* 0x2620: b 2b78 <generic_kprobe_filter_arg+0x2b78> */
	ARM64_SIM_A64_JMP(0x2620, 0x2b78, arm64_l_2b78);
arm64_l_2624:
	/* 0x2624: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2628:
	/* 0x2628: b.eq 2684 <generic_kprobe_filter_arg+0x2684> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2628, 0x2684, arm64_l_2684);
arm64_l_262c:
	/* 0x262c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2630:
	/* 0x2630: b.ne 2b78 <generic_kprobe_filter_arg+0x2b78> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2630, 0x2b78, arm64_l_2b78);
arm64_l_2634:
	/* 0x2634: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2638:
	/* 0x2638: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_263c:
	/* 0x263c: b.hi 2b68 <generic_kprobe_filter_arg+0x2b68> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x263c, 0x2b68, arm64_l_2b68);
arm64_l_2640:
	/* 0x2640: lsl w12, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X12, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2644:
	/* 0x2644: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2648:
	/* 0x2648: tst w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_264c:
	/* 0x264c: b.eq 2b68 <generic_kprobe_filter_arg+0x2b68> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x264c, 0x2b68, arm64_l_2b68);
arm64_l_2650:
	/* 0x2650: ldr w12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2654:
	/* 0x2654: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2658:
	/* 0x2658: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_265c:
	/* 0x265c: b.lt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x265c, 0x298, arm64_l_298);
arm64_l_2660:
	/* 0x2660: b 2b78 <generic_kprobe_filter_arg+0x2b78> */
	ARM64_SIM_A64_JMP(0x2660, 0x2b78, arm64_l_2b78);
arm64_l_2664:
	/* 0x2664: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2668:
	/* 0x2668: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_266c:
	/* 0x266c: b.ne 2b78 <generic_kprobe_filter_arg+0x2b78> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x266c, 0x2b78, arm64_l_2b78);
arm64_l_2670:
	/* 0x2670: ldr w12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2674:
	/* 0x2674: tst w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2678:
	/* 0x2678: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_267c:
	/* 0x267c: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x267c, 0x298, arm64_l_298);
arm64_l_2680:
	/* 0x2680: b 2b78 <generic_kprobe_filter_arg+0x2b78> */
	ARM64_SIM_A64_JMP(0x2680, 0x2b78, arm64_l_2b78);
arm64_l_2684:
	/* 0x2684: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2688:
	/* 0x2688: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_268c:
	/* 0x268c: b.hi 2b54 <generic_kprobe_filter_arg+0x2b54> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x268c, 0x2b54, arm64_l_2b54);
arm64_l_2690:
	/* 0x2690: lsl w12, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X12, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2694:
	/* 0x2694: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2698:
	/* 0x2698: tst w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_269c:
	/* 0x269c: b.eq 2b54 <generic_kprobe_filter_arg+0x2b54> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x269c, 0x2b54, arm64_l_2b54);
arm64_l_26a0:
	/* 0x26a0: ldr w12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_26a4:
	/* 0x26a4: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26a8:
	/* 0x26a8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_26ac:
	/* 0x26ac: b.gt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x26ac, 0x298, arm64_l_298);
arm64_l_26b0:
	/* 0x26b0: b 2b78 <generic_kprobe_filter_arg+0x2b78> */
	ARM64_SIM_A64_JMP(0x26b0, 0x2b78, arm64_l_2b78);
arm64_l_26b4:
	/* 0x26b4: cmp x12, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26b8:
	/* 0x26b8: ccmp x10, x11, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_26bc:
	/* 0x26bc: cset w9, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_26c0:
	/* 0x26c0: orr w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_26c4:
	/* 0x26c4: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_26c8:
	/* 0x26c8: tbz w8, #0, 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 0, 0x26c8, 0x298, arm64_l_298);
arm64_l_26cc:
	/* 0x26cc: b fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x26cc, 0xfc, arm64_l_fc);
arm64_l_26d0:
	/* 0x26d0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_26d4:
	/* 0x26d4: b.eq 2a34 <generic_kprobe_filter_arg+0x2a34> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x26d4, 0x2a34, arm64_l_2a34);
arm64_l_26d8:
	/* 0x26d8: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_26dc:
	/* 0x26dc: b.ne 2718 <generic_kprobe_filter_arg+0x2718> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x26dc, 0x2718, arm64_l_2718);
arm64_l_26e0:
	/* 0x26e0: adrp x0, 0 <string_maps_3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_3_11));
arm64_l_26e4:
	/* 0x26e4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_26e8:
	/* 0x26e8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_26ec:
	/* 0x26ec: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_26f0:
	/* 0x26f0: b 2a58 <generic_kprobe_filter_arg+0x2a58> */
	ARM64_SIM_A64_JMP(0x26f0, 0x2a58, arm64_l_2a58);
arm64_l_26f4:
	/* 0x26f4: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_26f8:
	/* 0x26f8: b.eq 2a48 <generic_kprobe_filter_arg+0x2a48> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x26f8, 0x2a48, arm64_l_2a48);
arm64_l_26fc:
	/* 0x26fc: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_2700:
	/* 0x2700: b.ne 2718 <generic_kprobe_filter_arg+0x2718> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2700, 0x2718, arm64_l_2718);
arm64_l_2704:
	/* 0x2704: adrp x0, 0 <string_maps_7> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_7_15));
arm64_l_2708:
	/* 0x2708: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_270c:
	/* 0x270c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2710:
	/* 0x2710: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2714:
	/* 0x2714: b 2a58 <generic_kprobe_filter_arg+0x2a58> */
	ARM64_SIM_A64_JMP(0x2714, 0x2a58, arm64_l_2a58);
arm64_l_2718:
	/* 0x2718: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_271c:
	/* 0x271c: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2720:
	/* 0x2720: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_2724:
	/* 0x2724: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2728:
	/* 0x2728: ldr w8, [x29, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_272c:
	/* 0x272c: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_2730:
	/* 0x2730: b.ls 1234 <generic_kprobe_filter_arg+0x1234> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2730, 0x1234, arm64_l_1234);
arm64_l_2734:
	/* 0x2734: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x2734, 0x294, arm64_l_294);
arm64_l_2738:
	/* 0x2738: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_273c:
	/* 0x273c: b.hi fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x273c, 0xfc, arm64_l_fc);
arm64_l_2740:
	/* 0x2740: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2744:
	/* 0x2744: b.ls 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2744, 0x298, arm64_l_298);
arm64_l_2748:
	/* 0x2748: b fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x2748, 0xfc, arm64_l_fc);
arm64_l_274c:
	/* 0x274c: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2750:
	/* 0x2750: b.eq 2acc <generic_kprobe_filter_arg+0x2acc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2750, 0x2acc, arm64_l_2acc);
arm64_l_2754:
	/* 0x2754: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2758:
	/* 0x2758: b.ne 2ad8 <generic_kprobe_filter_arg+0x2ad8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2758, 0x2ad8, arm64_l_2ad8);
arm64_l_275c:
	/* 0x275c: ldrb w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2760:
	/* 0x2760: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2764:
	/* 0x2764: b.hi 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2764, 0x298, arm64_l_298);
arm64_l_2768:
	/* 0x2768: b 2ad8 <generic_kprobe_filter_arg+0x2ad8> */
	ARM64_SIM_A64_JMP(0x2768, 0x2ad8, arm64_l_2ad8);
arm64_l_276c:
	/* 0x276c: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2770:
	/* 0x2770: b.eq 2b10 <generic_kprobe_filter_arg+0x2b10> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2770, 0x2b10, arm64_l_2b10);
arm64_l_2774:
	/* 0x2774: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2778:
	/* 0x2778: b.ne 2b1c <generic_kprobe_filter_arg+0x2b1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2778, 0x2b1c, arm64_l_2b1c);
arm64_l_277c:
	/* 0x277c: ldrh w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2780:
	/* 0x2780: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2784:
	/* 0x2784: b.hi 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2784, 0x298, arm64_l_298);
arm64_l_2788:
	/* 0x2788: b 2b1c <generic_kprobe_filter_arg+0x2b1c> */
	ARM64_SIM_A64_JMP(0x2788, 0x2b1c, arm64_l_2b1c);
arm64_l_278c:
	/* 0x278c: mov w23, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2790:
	/* 0x2790: b 2cdc <generic_kprobe_filter_arg+0x2cdc> */
	ARM64_SIM_A64_JMP(0x2790, 0x2cdc, arm64_l_2cdc);
arm64_l_2794:
	/* 0x2794: strh w22, [x0], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_2798:
	/* 0x2798: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_279c:
	/* 0x279c: mov w1, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_27a0:
	/* 0x27a0: mov x2, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_27a4:
	/* 0x27a4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x27a8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_27a8:
	/* 0x27a8: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_27ac:
	/* 0x27ac: and w8, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_27b0:
	/* 0x27b0: cmp w8, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_27b4:
	/* 0x27b4: b.ls 27d4 <generic_kprobe_filter_arg+0x27d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x27b4, 0x27d4, arm64_l_27d4);
arm64_l_27b8:
	/* 0x27b8: add x9, x19, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X19, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_27bc:
	/* 0x27bc: sub w8, w8, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_27c0:
	/* 0x27c0: ldr x2, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_27c4:
	/* 0x27c4: add x0, x9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_27c8:
	/* 0x27c8: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_27cc:
	/* 0x27cc: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_27d0:
	/* 0x27d0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x27d4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_27d4:
	/* 0x27d4: ldr w8, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_27d8:
	/* 0x27d8: cmp w23, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_27dc:
	/* 0x27dc: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_27e0:
	/* 0x27e0: b.gt 280c <generic_kprobe_filter_arg+0x280c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x27e0, 0x280c, arm64_l_280c);
arm64_l_27e4:
	/* 0x27e4: cmp w23, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_27e8:
	/* 0x27e8: b.gt 2a84 <generic_kprobe_filter_arg+0x2a84> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x27e8, 0x2a84, arm64_l_2a84);
arm64_l_27ec:
	/* 0x27ec: cbz w23, 2c68 <generic_kprobe_filter_arg+0x2c68> */
	ARM64_SIM_A64_CBZ(ARM64_X23, 0x27ec, 0x2c68, arm64_l_2c68);
arm64_l_27f0:
	/* 0x27f0: cmp w23, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_27f4:
	/* 0x27f4: b.ne 2cd8 <generic_kprobe_filter_arg+0x2cd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x27f4, 0x2cd8, arm64_l_2cd8);
arm64_l_27f8:
	/* 0x27f8: adrp x0, 0 <string_maps_1> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_1_9));
arm64_l_27fc:
	/* 0x27fc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2800:
	/* 0x2800: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2804:
	/* 0x2804: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2808:
	/* 0x2808: b 2cb4 <generic_kprobe_filter_arg+0x2cb4> */
	ARM64_SIM_A64_JMP(0x2808, 0x2cb4, arm64_l_2cb4);
arm64_l_280c:
	/* 0x280c: cmp w23, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2810:
	/* 0x2810: b.gt 2aa8 <generic_kprobe_filter_arg+0x2aa8> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2810, 0x2aa8, arm64_l_2aa8);
arm64_l_2814:
	/* 0x2814: cmp w23, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2818:
	/* 0x2818: b.eq 2c7c <generic_kprobe_filter_arg+0x2c7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2818, 0x2c7c, arm64_l_2c7c);
arm64_l_281c:
	/* 0x281c: cmp w23, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2820:
	/* 0x2820: b.ne 2cd8 <generic_kprobe_filter_arg+0x2cd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2820, 0x2cd8, arm64_l_2cd8);
arm64_l_2824:
	/* 0x2824: adrp x0, 0 <string_maps_5> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_5_13));
arm64_l_2828:
	/* 0x2828: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_282c:
	/* 0x282c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2830:
	/* 0x2830: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2834:
	/* 0x2834: b 2cb4 <generic_kprobe_filter_arg+0x2cb4> */
	ARM64_SIM_A64_JMP(0x2834, 0x2cb4, arm64_l_2cb4);
arm64_l_2838:
	/* 0x2838: adrp x0, 0 <string_maps_0> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_0_8));
arm64_l_283c:
	/* 0x283c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2840:
	/* 0x2840: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2844:
	/* 0x2844: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2848:
	/* 0x2848: b 2884 <generic_kprobe_filter_arg+0x2884> */
	ARM64_SIM_A64_JMP(0x2848, 0x2884, arm64_l_2884);
arm64_l_284c:
	/* 0x284c: adrp x0, 0 <string_maps_4> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_4_12));
arm64_l_2850:
	/* 0x2850: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2854:
	/* 0x2854: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2858:
	/* 0x2858: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_285c:
	/* 0x285c: b 2884 <generic_kprobe_filter_arg+0x2884> */
	ARM64_SIM_A64_JMP(0x285c, 0x2884, arm64_l_2884);
arm64_l_2860:
	/* 0x2860: adrp x0, 0 <string_maps_2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_2_10));
arm64_l_2864:
	/* 0x2864: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2868:
	/* 0x2868: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_286c:
	/* 0x286c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2870:
	/* 0x2870: b 2884 <generic_kprobe_filter_arg+0x2884> */
	ARM64_SIM_A64_JMP(0x2870, 0x2884, arm64_l_2884);
arm64_l_2874:
	/* 0x2874: adrp x0, 0 <string_maps_6> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_6_14));
arm64_l_2878:
	/* 0x2878: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_287c:
	/* 0x287c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2880:
	/* 0x2880: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2884:
	/* 0x2884: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2888:
	/* 0x2888: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x288cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_288c:
	/* 0x288c: cbz x0, 28a8 <generic_kprobe_filter_arg+0x28a8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x288c, 0x28a8, arm64_l_28a8);
arm64_l_2890:
	/* 0x2890: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2894:
	/* 0x2894: mov x1, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2898:
	/* 0x2898: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x289cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_289c:
	/* 0x289c: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_28a0:
	/* 0x28a0: cset w23, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_28a4:
	/* 0x28a4: b 28ac <generic_kprobe_filter_arg+0x28ac> */
	ARM64_SIM_A64_JMP(0x28a4, 0x28ac, arm64_l_28ac);
arm64_l_28a8:
	/* 0x28a8: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_28ac:
	/* 0x28ac: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_28b0:
	/* 0x28b0: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_28b4:
	/* 0x28b4: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28b8:
	/* 0x28b8: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_28bc:
	/* 0x28bc: ldr w8, [x29, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_28c0:
	/* 0x28c0: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_28c4:
	/* 0x28c4: b.hi 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x28c4, 0x294, arm64_l_294);
arm64_l_28c8:
	/* 0x28c8: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_28cc:
	/* 0x28cc: lsl x8, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_28d0:
	/* 0x28d0: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_28d4:
	/* 0x28d4: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_28d8:
	/* 0x28d8: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_28dc:
	/* 0x28dc: b.eq 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x28dc, 0x294, arm64_l_294);
arm64_l_28e0:
	/* 0x28e0: eor x23, x23, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_28e4:
	/* 0x28e4: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x28e4, 0x294, arm64_l_294);
arm64_l_28e8:
	/* 0x28e8: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_28ec:
	/* 0x28ec: ccmp w10, w11, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_28f0:
	/* 0x28f0: cset w9, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_28f4:
	/* 0x28f4: orr w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_28f8:
	/* 0x28f8: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28fc:
	/* 0x28fc: tbz w8, #0, 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 0, 0x28fc, 0x298, arm64_l_298);
arm64_l_2900:
	/* 0x2900: b fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x2900, 0xfc, arm64_l_fc);
arm64_l_2904:
	/* 0x2904: ldr x12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2908:
	/* 0x2908: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_290c:
	/* 0x290c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2910:
	/* 0x2910: b.hi 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2910, 0x298, arm64_l_298);
arm64_l_2914:
	/* 0x2914: b 2928 <generic_kprobe_filter_arg+0x2928> */
	ARM64_SIM_A64_JMP(0x2914, 0x2928, arm64_l_2928);
arm64_l_2918:
	/* 0x2918: ldr x12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_291c:
	/* 0x291c: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2920:
	/* 0x2920: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2924:
	/* 0x2924: b.cc 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2924, 0x298, arm64_l_298);
arm64_l_2928:
	/* 0x2928: cmp w10, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_292c:
	/* 0x292c: b.cc 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x292c, 0x2d7c, arm64_l_2d7c);
arm64_l_2930:
	/* 0x2930: ldr x10, [x29, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2934:
	/* 0x2934: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2938:
	/* 0x2938: b.le 2968 <generic_kprobe_filter_arg+0x2968> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2938, 0x2968, arm64_l_2968);
arm64_l_293c:
	/* 0x293c: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2940:
	/* 0x2940: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2944:
	/* 0x2944: b.cc 2998 <generic_kprobe_filter_arg+0x2998> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2944, 0x2998, arm64_l_2998);
arm64_l_2948:
	/* 0x2948: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_294c:
	/* 0x294c: b.eq 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x294c, 0x298, arm64_l_298);
arm64_l_2950:
	/* 0x2950: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2954:
	/* 0x2954: b.ne fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2954, 0xfc, arm64_l_fc);
arm64_l_2958:
	/* 0x2958: ldr x9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_295c:
	/* 0x295c: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2960:
	/* 0x2960: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2960, 0x298, arm64_l_298);
arm64_l_2964:
	/* 0x2964: b 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JMP(0x2964, 0x2d7c, arm64_l_2d7c);
arm64_l_2968:
	/* 0x2968: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_296c:
	/* 0x296c: b.eq 29ec <generic_kprobe_filter_arg+0x29ec> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x296c, 0x29ec, arm64_l_29ec);
arm64_l_2970:
	/* 0x2970: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2974:
	/* 0x2974: b.ne fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2974, 0xfc, arm64_l_fc);
arm64_l_2978:
	/* 0x2978: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_297c:
	/* 0x297c: b.eq 2988 <generic_kprobe_filter_arg+0x2988> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x297c, 0x2988, arm64_l_2988);
arm64_l_2980:
	/* 0x2980: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2984:
	/* 0x2984: b.ne 2d30 <generic_kprobe_filter_arg+0x2d30> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2984, 0x2d30, arm64_l_2d30);
arm64_l_2988:
	/* 0x2988: ldr x9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_298c:
	/* 0x298c: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2990:
	/* 0x2990: b.lt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x2990, 0x298, arm64_l_298);
arm64_l_2994:
	/* 0x2994: b 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JMP(0x2994, 0x2d7c, arm64_l_2d7c);
arm64_l_2998:
	/* 0x2998: ldr x9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_299c:
	/* 0x299c: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_29a0:
	/* 0x29a0: b.ne 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x29a0, 0x2d7c, arm64_l_2d7c);
arm64_l_29a4:
	/* 0x29a4: b 28c <generic_kprobe_filter_arg+0x28c> */
	ARM64_SIM_A64_JMP(0x29a4, 0x28c, arm64_l_28c);
arm64_l_29a8:
	/* 0x29a8: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_29ac:
	/* 0x29ac: b.ne 2ad8 <generic_kprobe_filter_arg+0x2ad8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x29ac, 0x2ad8, arm64_l_2ad8);
arm64_l_29b0:
	/* 0x29b0: ldrb w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_29b4:
	/* 0x29b4: tst w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_29b8:
	/* 0x29b8: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x29b8, 0x298, arm64_l_298);
arm64_l_29bc:
	/* 0x29bc: b 2ad8 <generic_kprobe_filter_arg+0x2ad8> */
	ARM64_SIM_A64_JMP(0x29bc, 0x2ad8, arm64_l_2ad8);
arm64_l_29c0:
	/* 0x29c0: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_29c4:
	/* 0x29c4: b.ne 2b1c <generic_kprobe_filter_arg+0x2b1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x29c4, 0x2b1c, arm64_l_2b1c);
arm64_l_29c8:
	/* 0x29c8: ldrh w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_29cc:
	/* 0x29cc: tst w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_29d0:
	/* 0x29d0: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x29d0, 0x298, arm64_l_298);
arm64_l_29d4:
	/* 0x29d4: b 2b1c <generic_kprobe_filter_arg+0x2b1c> */
	ARM64_SIM_A64_JMP(0x29d4, 0x2b1c, arm64_l_2b1c);
arm64_l_29d8:
	/* 0x29d8: cmp w11, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_29dc:
	/* 0x29dc: b.hi fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x29dc, 0xfc, arm64_l_fc);
arm64_l_29e0:
	/* 0x29e0: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_29e4:
	/* 0x29e4: b.ls 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x29e4, 0x298, arm64_l_298);
arm64_l_29e8:
	/* 0x29e8: b fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x29e8, 0xfc, arm64_l_fc);
arm64_l_29ec:
	/* 0x29ec: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_29f0:
	/* 0x29f0: b.eq 29fc <generic_kprobe_filter_arg+0x29fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x29f0, 0x29fc, arm64_l_29fc);
arm64_l_29f4:
	/* 0x29f4: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_29f8:
	/* 0x29f8: b.ne 2d40 <generic_kprobe_filter_arg+0x2d40> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x29f8, 0x2d40, arm64_l_2d40);
arm64_l_29fc:
	/* 0x29fc: ldr x9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2a00:
	/* 0x2a00: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2a04:
	/* 0x2a04: b.gt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2a04, 0x298, arm64_l_298);
arm64_l_2a08:
	/* 0x2a08: b 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JMP(0x2a08, 0x2d7c, arm64_l_2d7c);
arm64_l_2a0c:
	/* 0x2a0c: adrp x0, 0 <string_maps_0> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_0_8));
arm64_l_2a10:
	/* 0x2a10: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a14:
	/* 0x2a14: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2a18:
	/* 0x2a18: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2a1c:
	/* 0x2a1c: b 2a58 <generic_kprobe_filter_arg+0x2a58> */
	ARM64_SIM_A64_JMP(0x2a1c, 0x2a58, arm64_l_2a58);
arm64_l_2a20:
	/* 0x2a20: adrp x0, 0 <string_maps_4> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_4_12));
arm64_l_2a24:
	/* 0x2a24: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a28:
	/* 0x2a28: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2a2c:
	/* 0x2a2c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2a30:
	/* 0x2a30: b 2a58 <generic_kprobe_filter_arg+0x2a58> */
	ARM64_SIM_A64_JMP(0x2a30, 0x2a58, arm64_l_2a58);
arm64_l_2a34:
	/* 0x2a34: adrp x0, 0 <string_maps_2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_2_10));
arm64_l_2a38:
	/* 0x2a38: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a3c:
	/* 0x2a3c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2a40:
	/* 0x2a40: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2a44:
	/* 0x2a44: b 2a58 <generic_kprobe_filter_arg+0x2a58> */
	ARM64_SIM_A64_JMP(0x2a44, 0x2a58, arm64_l_2a58);
arm64_l_2a48:
	/* 0x2a48: adrp x0, 0 <string_maps_6> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_6_14));
arm64_l_2a4c:
	/* 0x2a4c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a50:
	/* 0x2a50: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2a54:
	/* 0x2a54: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2a58:
	/* 0x2a58: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2a5c:
	/* 0x2a5c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2a60ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2a60:
	/* 0x2a60: cbz x0, 2a7c <generic_kprobe_filter_arg+0x2a7c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2a60, 0x2a7c, arm64_l_2a7c);
arm64_l_2a64:
	/* 0x2a64: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a68:
	/* 0x2a68: mov x1, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2a6c:
	/* 0x2a6c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2a70ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2a70:
	/* 0x2a70: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_2a74:
	/* 0x2a74: cset w23, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2a78:
	/* 0x2a78: b 1218 <generic_kprobe_filter_arg+0x1218> */
	ARM64_SIM_A64_JMP(0x2a78, 0x1218, arm64_l_1218);
arm64_l_2a7c:
	/* 0x2a7c: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2a80:
	/* 0x2a80: b 1218 <generic_kprobe_filter_arg+0x1218> */
	ARM64_SIM_A64_JMP(0x2a80, 0x1218, arm64_l_1218);
arm64_l_2a84:
	/* 0x2a84: cmp w23, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2a88:
	/* 0x2a88: b.eq 2c90 <generic_kprobe_filter_arg+0x2c90> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2a88, 0x2c90, arm64_l_2c90);
arm64_l_2a8c:
	/* 0x2a8c: cmp w23, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2a90:
	/* 0x2a90: b.ne 2cd8 <generic_kprobe_filter_arg+0x2cd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2a90, 0x2cd8, arm64_l_2cd8);
arm64_l_2a94:
	/* 0x2a94: adrp x0, 0 <string_maps_3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_3_11));
arm64_l_2a98:
	/* 0x2a98: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a9c:
	/* 0x2a9c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2aa0:
	/* 0x2aa0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2aa4:
	/* 0x2aa4: b 2cb4 <generic_kprobe_filter_arg+0x2cb4> */
	ARM64_SIM_A64_JMP(0x2aa4, 0x2cb4, arm64_l_2cb4);
arm64_l_2aa8:
	/* 0x2aa8: cmp w23, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2aac:
	/* 0x2aac: b.eq 2ca4 <generic_kprobe_filter_arg+0x2ca4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2aac, 0x2ca4, arm64_l_2ca4);
arm64_l_2ab0:
	/* 0x2ab0: cmp w23, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_2ab4:
	/* 0x2ab4: b.ne 2cd8 <generic_kprobe_filter_arg+0x2cd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2ab4, 0x2cd8, arm64_l_2cd8);
arm64_l_2ab8:
	/* 0x2ab8: adrp x0, 0 <string_maps_7> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_7_15));
arm64_l_2abc:
	/* 0x2abc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2ac0:
	/* 0x2ac0: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2ac4:
	/* 0x2ac4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ac8:
	/* 0x2ac8: b 2cb4 <generic_kprobe_filter_arg+0x2cb4> */
	ARM64_SIM_A64_JMP(0x2ac8, 0x2cb4, arm64_l_2cb4);
arm64_l_2acc:
	/* 0x2acc: ldrb w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ad0:
	/* 0x2ad0: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2ad4:
	/* 0x2ad4: b.cc 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2ad4, 0x298, arm64_l_298);
arm64_l_2ad8:
	/* 0x2ad8: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2adc:
	/* 0x2adc: b.cc 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2adc, 0x2d7c, arm64_l_2d7c);
arm64_l_2ae0:
	/* 0x2ae0: ldr w9, [x29, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2ae4:
	/* 0x2ae4: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2ae8:
	/* 0x2ae8: b.le 2c20 <generic_kprobe_filter_arg+0x2c20> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2ae8, 0x2c20, arm64_l_2c20);
arm64_l_2aec:
	/* 0x2aec: sub w10, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2af0:
	/* 0x2af0: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2af4:
	/* 0x2af4: b.cc 2c50 <generic_kprobe_filter_arg+0x2c50> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2af4, 0x2c50, arm64_l_2c50);
arm64_l_2af8:
	/* 0x2af8: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2afc:
	/* 0x2afc: b.eq 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2afc, 0x298, arm64_l_298);
arm64_l_2b00:
	/* 0x2b00: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2b04:
	/* 0x2b04: b.ne fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2b04, 0xfc, arm64_l_fc);
arm64_l_2b08:
	/* 0x2b08: ldrb w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b0c:
	/* 0x2b0c: b 2bac <generic_kprobe_filter_arg+0x2bac> */
	ARM64_SIM_A64_JMP(0x2b0c, 0x2bac, arm64_l_2bac);
arm64_l_2b10:
	/* 0x2b10: ldrh w11, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b14:
	/* 0x2b14: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b18:
	/* 0x2b18: b.cc 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b18, 0x298, arm64_l_298);
arm64_l_2b1c:
	/* 0x2b1c: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2b20:
	/* 0x2b20: b.cc 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b20, 0x2d7c, arm64_l_2d7c);
arm64_l_2b24:
	/* 0x2b24: ldr w9, [x29, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2b28:
	/* 0x2b28: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2b2c:
	/* 0x2b2c: b.le 2c38 <generic_kprobe_filter_arg+0x2c38> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2b2c, 0x2c38, arm64_l_2c38);
arm64_l_2b30:
	/* 0x2b30: sub w10, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2b34:
	/* 0x2b34: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2b38:
	/* 0x2b38: b.cc 2c58 <generic_kprobe_filter_arg+0x2c58> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b38, 0x2c58, arm64_l_2c58);
arm64_l_2b3c:
	/* 0x2b3c: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2b40:
	/* 0x2b40: b.eq 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2b40, 0x298, arm64_l_298);
arm64_l_2b44:
	/* 0x2b44: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2b48:
	/* 0x2b48: b.ne fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2b48, 0xfc, arm64_l_fc);
arm64_l_2b4c:
	/* 0x2b4c: ldrh w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b50:
	/* 0x2b50: b 2bac <generic_kprobe_filter_arg+0x2bac> */
	ARM64_SIM_A64_JMP(0x2b50, 0x2bac, arm64_l_2bac);
arm64_l_2b54:
	/* 0x2b54: ldr w12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b58:
	/* 0x2b58: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b5c:
	/* 0x2b5c: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2b60:
	/* 0x2b60: b.hi 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2b60, 0x298, arm64_l_298);
arm64_l_2b64:
	/* 0x2b64: b 2b78 <generic_kprobe_filter_arg+0x2b78> */
	ARM64_SIM_A64_JMP(0x2b64, 0x2b78, arm64_l_2b78);
arm64_l_2b68:
	/* 0x2b68: ldr w12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b6c:
	/* 0x2b6c: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b70:
	/* 0x2b70: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2b74:
	/* 0x2b74: b.cc 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b74, 0x298, arm64_l_298);
arm64_l_2b78:
	/* 0x2b78: cmp w10, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2b7c:
	/* 0x2b7c: b.cc 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b7c, 0x2d7c, arm64_l_2d7c);
arm64_l_2b80:
	/* 0x2b80: ldr w10, [x29, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2b84:
	/* 0x2b84: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2b88:
	/* 0x2b88: b.le 2bb8 <generic_kprobe_filter_arg+0x2bb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2b88, 0x2bb8, arm64_l_2bb8);
arm64_l_2b8c:
	/* 0x2b8c: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2b90:
	/* 0x2b90: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2b94:
	/* 0x2b94: b.cc 2bf0 <generic_kprobe_filter_arg+0x2bf0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b94, 0x2bf0, arm64_l_2bf0);
arm64_l_2b98:
	/* 0x2b98: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2b9c:
	/* 0x2b9c: b.eq 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2b9c, 0x298, arm64_l_298);
arm64_l_2ba0:
	/* 0x2ba0: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2ba4:
	/* 0x2ba4: b.ne fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2ba4, 0xfc, arm64_l_fc);
arm64_l_2ba8:
	/* 0x2ba8: ldr w9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2bac:
	/* 0x2bac: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2bb0:
	/* 0x2bb0: b.ne 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2bb0, 0x298, arm64_l_298);
arm64_l_2bb4:
	/* 0x2bb4: b 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JMP(0x2bb4, 0x2d7c, arm64_l_2d7c);
arm64_l_2bb8:
	/* 0x2bb8: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2bbc:
	/* 0x2bbc: b.eq 2bf8 <generic_kprobe_filter_arg+0x2bf8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2bbc, 0x2bf8, arm64_l_2bf8);
arm64_l_2bc0:
	/* 0x2bc0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2bc4:
	/* 0x2bc4: b.ne fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2bc4, 0xfc, arm64_l_fc);
arm64_l_2bc8:
	/* 0x2bc8: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2bcc:
	/* 0x2bcc: b.hi 2d60 <generic_kprobe_filter_arg+0x2d60> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2bcc, 0x2d60, arm64_l_2d60);
arm64_l_2bd0:
	/* 0x2bd0: lsl w9, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2bd4:
	/* 0x2bd4: mov w11, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2bd8:
	/* 0x2bd8: tst w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2bdc:
	/* 0x2bdc: b.eq 2d60 <generic_kprobe_filter_arg+0x2d60> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2bdc, 0x2d60, arm64_l_2d60);
arm64_l_2be0:
	/* 0x2be0: ldr w9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2be4:
	/* 0x2be4: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2be8:
	/* 0x2be8: b.lt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x2be8, 0x298, arm64_l_298);
arm64_l_2bec:
	/* 0x2bec: b 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JMP(0x2bec, 0x2d7c, arm64_l_2d7c);
arm64_l_2bf0:
	/* 0x2bf0: ldr w9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2bf4:
	/* 0x2bf4: b 2c5c <generic_kprobe_filter_arg+0x2c5c> */
	ARM64_SIM_A64_JMP(0x2bf4, 0x2c5c, arm64_l_2c5c);
arm64_l_2bf8:
	/* 0x2bf8: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2bfc:
	/* 0x2bfc: b.hi 2d70 <generic_kprobe_filter_arg+0x2d70> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2bfc, 0x2d70, arm64_l_2d70);
arm64_l_2c00:
	/* 0x2c00: lsl w9, w12, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2c04:
	/* 0x2c04: mov w11, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2c08:
	/* 0x2c08: tst w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c0c:
	/* 0x2c0c: b.eq 2d70 <generic_kprobe_filter_arg+0x2d70> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2c0c, 0x2d70, arm64_l_2d70);
arm64_l_2c10:
	/* 0x2c10: ldr w9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c14:
	/* 0x2c14: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c18:
	/* 0x2c18: b.gt 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2c18, 0x298, arm64_l_298);
arm64_l_2c1c:
	/* 0x2c1c: b 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JMP(0x2c1c, 0x2d7c, arm64_l_2d7c);
arm64_l_2c20:
	/* 0x2c20: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2c24:
	/* 0x2c24: b.eq 2d50 <generic_kprobe_filter_arg+0x2d50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2c24, 0x2d50, arm64_l_2d50);
arm64_l_2c28:
	/* 0x2c28: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2c2c:
	/* 0x2c2c: b.ne fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2c2c, 0xfc, arm64_l_fc);
arm64_l_2c30:
	/* 0x2c30: ldrb w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c34:
	/* 0x2c34: b 2d74 <generic_kprobe_filter_arg+0x2d74> */
	ARM64_SIM_A64_JMP(0x2c34, 0x2d74, arm64_l_2d74);
arm64_l_2c38:
	/* 0x2c38: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2c3c:
	/* 0x2c3c: b.eq 2d58 <generic_kprobe_filter_arg+0x2d58> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2c3c, 0x2d58, arm64_l_2d58);
arm64_l_2c40:
	/* 0x2c40: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2c44:
	/* 0x2c44: b.ne fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2c44, 0xfc, arm64_l_fc);
arm64_l_2c48:
	/* 0x2c48: ldrh w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c4c:
	/* 0x2c4c: b 2d74 <generic_kprobe_filter_arg+0x2d74> */
	ARM64_SIM_A64_JMP(0x2c4c, 0x2d74, arm64_l_2d74);
arm64_l_2c50:
	/* 0x2c50: ldrb w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c54:
	/* 0x2c54: b 2c5c <generic_kprobe_filter_arg+0x2c5c> */
	ARM64_SIM_A64_JMP(0x2c54, 0x2c5c, arm64_l_2c5c);
arm64_l_2c58:
	/* 0x2c58: ldrh w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c5c:
	/* 0x2c5c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c60:
	/* 0x2c60: b.eq 28c <generic_kprobe_filter_arg+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2c60, 0x28c, arm64_l_28c);
arm64_l_2c64:
	/* 0x2c64: b 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JMP(0x2c64, 0x2d7c, arm64_l_2d7c);
arm64_l_2c68:
	/* 0x2c68: adrp x0, 0 <string_maps_0> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_0_8));
arm64_l_2c6c:
	/* 0x2c6c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2c70:
	/* 0x2c70: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2c74:
	/* 0x2c74: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c78:
	/* 0x2c78: b 2cb4 <generic_kprobe_filter_arg+0x2cb4> */
	ARM64_SIM_A64_JMP(0x2c78, 0x2cb4, arm64_l_2cb4);
arm64_l_2c7c:
	/* 0x2c7c: adrp x0, 0 <string_maps_4> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_4_12));
arm64_l_2c80:
	/* 0x2c80: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2c84:
	/* 0x2c84: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2c88:
	/* 0x2c88: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c8c:
	/* 0x2c8c: b 2cb4 <generic_kprobe_filter_arg+0x2cb4> */
	ARM64_SIM_A64_JMP(0x2c8c, 0x2cb4, arm64_l_2cb4);
arm64_l_2c90:
	/* 0x2c90: adrp x0, 0 <string_maps_2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_2_10));
arm64_l_2c94:
	/* 0x2c94: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2c98:
	/* 0x2c98: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2c9c:
	/* 0x2c9c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ca0:
	/* 0x2ca0: b 2cb4 <generic_kprobe_filter_arg+0x2cb4> */
	ARM64_SIM_A64_JMP(0x2ca0, 0x2cb4, arm64_l_2cb4);
arm64_l_2ca4:
	/* 0x2ca4: adrp x0, 0 <string_maps_6> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_6_14));
arm64_l_2ca8:
	/* 0x2ca8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2cac:
	/* 0x2cac: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2cb0:
	/* 0x2cb0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2cb4:
	/* 0x2cb4: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2cb8:
	/* 0x2cb8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2cbcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2cbc:
	/* 0x2cbc: cbz x0, 2cd8 <generic_kprobe_filter_arg+0x2cd8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2cbc, 0x2cd8, arm64_l_2cd8);
arm64_l_2cc0:
	/* 0x2cc0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2cc4:
	/* 0x2cc4: mov x1, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2cc8:
	/* 0x2cc8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2cccULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2ccc:
	/* 0x2ccc: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_2cd0:
	/* 0x2cd0: cset w23, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2cd4:
	/* 0x2cd4: b 2cdc <generic_kprobe_filter_arg+0x2cdc> */
	ARM64_SIM_A64_JMP(0x2cd4, 0x2cdc, arm64_l_2cdc);
arm64_l_2cd8:
	/* 0x2cd8: mov x23, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2cdc:
	/* 0x2cdc: ldp x16, x15, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X16, ARM64_X15, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_2ce0:
	/* 0x2ce0: mov w2, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_2ce4:
	/* 0x2ce4: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2ce8:
	/* 0x2ce8: ldr x17, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X17, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2cec:
	/* 0x2cec: ldr w8, [x29, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2cf0:
	/* 0x2cf0: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_2cf4:
	/* 0x2cf4: b.hi 2d1c <generic_kprobe_filter_arg+0x2d1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2cf4, 0x2d1c, arm64_l_2d1c);
arm64_l_2cf8:
	/* 0x2cf8: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_2cfc:
	/* 0x2cfc: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2d00:
	/* 0x2d00: lsl x8, x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2d04:
	/* 0x2d04: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_2d08:
	/* 0x2d08: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_2d0c:
	/* 0x2d0c: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d10:
	/* 0x2d10: b.eq 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2d10, 0x294, arm64_l_294);
arm64_l_2d14:
	/* 0x2d14: cmp x23, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_2d18:
	/* 0x2d18: b 290 <generic_kprobe_filter_arg+0x290> */
	ARM64_SIM_A64_JMP(0x2d18, 0x290, arm64_l_290);
arm64_l_2d1c:
	/* 0x2d1c: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2d20:
	/* 0x2d20: b 294 <generic_kprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JMP(0x2d20, 0x294, arm64_l_294);
arm64_l_2d24:
	/* 0x2d24: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2d28:
	/* 0x2d28: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2d2c:
	/* 0x2d2c: b 1e50 <generic_kprobe_filter_arg+0x1e50> */
	ARM64_SIM_A64_JMP(0x2d2c, 0x1e50, arm64_l_1e50);
arm64_l_2d30:
	/* 0x2d30: ldr x9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d34:
	/* 0x2d34: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d38:
	/* 0x2d38: b.cc 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2d38, 0x298, arm64_l_298);
arm64_l_2d3c:
	/* 0x2d3c: b 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JMP(0x2d3c, 0x2d7c, arm64_l_2d7c);
arm64_l_2d40:
	/* 0x2d40: ldr x9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d44:
	/* 0x2d44: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d48:
	/* 0x2d48: b.hi 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2d48, 0x298, arm64_l_298);
arm64_l_2d4c:
	/* 0x2d4c: b 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JMP(0x2d4c, 0x2d7c, arm64_l_2d7c);
arm64_l_2d50:
	/* 0x2d50: ldrb w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d54:
	/* 0x2d54: b 2d64 <generic_kprobe_filter_arg+0x2d64> */
	ARM64_SIM_A64_JMP(0x2d54, 0x2d64, arm64_l_2d64);
arm64_l_2d58:
	/* 0x2d58: ldrh w10, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d5c:
	/* 0x2d5c: b 2d64 <generic_kprobe_filter_arg+0x2d64> */
	ARM64_SIM_A64_JMP(0x2d5c, 0x2d64, arm64_l_2d64);
arm64_l_2d60:
	/* 0x2d60: ldr w9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d64:
	/* 0x2d64: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d68:
	/* 0x2d68: b.cc 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2d68, 0x298, arm64_l_298);
arm64_l_2d6c:
	/* 0x2d6c: b 2d7c <generic_kprobe_filter_arg+0x2d7c> */
	ARM64_SIM_A64_JMP(0x2d6c, 0x2d7c, arm64_l_2d7c);
arm64_l_2d70:
	/* 0x2d70: ldr w9, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d74:
	/* 0x2d74: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d78:
	/* 0x2d78: b.hi 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2d78, 0x298, arm64_l_298);
arm64_l_2d7c:
	/* 0x2d7c: orr w8, w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2d80:
	/* 0x2d80: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2d84:
	/* 0x2d84: b.eq 298 <generic_kprobe_filter_arg+0x298> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2d84, 0x298, arm64_l_298);
arm64_l_2d88:
	/* 0x2d88: b fc <generic_kprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0x2d88, 0xfc, arm64_l_fc);
arm64_l_2d8c:
	/* 0x2d8c: cbz x2, 2e18 <native_bpf_strncasestr+0x8c> */
	ARM64_SIM_A64_CBZ(ARM64_X2, 0x2d8c, 0x2e18, arm64_l_2e18);
arm64_l_2d90:
	/* 0x2d90: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d94:
	/* 0x2d94: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d98:
	/* 0x2d98: mov x9, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d9c:
	/* 0x2d9c: b 2dc0 <native_bpf_strncasestr+0x34> */
	ARM64_SIM_A64_JMP(0x2d9c, 0x2dc0, arm64_l_2dc0);
arm64_l_2da0:
	/* 0x2da0: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2da4:
	/* 0x2da4: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2da8:
	/* 0x2da8: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2dac:
	/* 0x2dac: add x0, x0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2db0:
	/* 0x2db0: sub x9, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2db4:
	/* 0x2db4: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2db8:
	/* 0x2db8: cmp x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2dbc:
	/* 0x2dbc: b.eq 2e18 <native_bpf_strncasestr+0x8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2dbc, 0x2e18, arm64_l_2e18);
arm64_l_2dc0:
	/* 0x2dc0: mov x10, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2dc4:
	/* 0x2dc4: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2dc8:
	/* 0x2dc8: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2dcc:
	/* 0x2dcc: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2dd0:
	/* 0x2dd0: b.eq 2dac <native_bpf_strncasestr+0x20> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2dd0, 0x2dac, arm64_l_2dac);
arm64_l_2dd4:
	/* 0x2dd4: ldrb w11, [x1, x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X1, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X10, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2dd8:
	/* 0x2dd8: cbz w11, 2e1c <native_bpf_strncasestr+0x90> */
	ARM64_SIM_A64_CBZ(ARM64_X11, 0x2dd8, 0x2e1c, arm64_l_2e1c);
arm64_l_2ddc:
	/* 0x2ddc: ldrb w12, [x8, x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X10, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2de0:
	/* 0x2de0: sub w13, w12, #0x41 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 65ULL);
arm64_l_2de4:
	/* 0x2de4: orr w14, w12, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2de8:
	/* 0x2de8: cmp w13, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_2dec:
	/* 0x2dec: sub w13, w11, #0x41 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 65ULL);
arm64_l_2df0:
	/* 0x2df0: csel w12, w14, w12, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X12, ARM64_X14, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_2df4:
	/* 0x2df4: orr w14, w11, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2df8:
	/* 0x2df8: cmp w13, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_2dfc:
	/* 0x2dfc: csel w11, w14, w11, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X14, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_2e00:
	/* 0x2e00: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2e04:
	/* 0x2e04: b.ne 2dac <native_bpf_strncasestr+0x20> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2e04, 0x2dac, arm64_l_2dac);
arm64_l_2e08:
	/* 0x2e08: cmp x10, #0x63 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 99ULL);
arm64_l_2e0c:
	/* 0x2e0c: add x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2e10:
	/* 0x2e10: b.cc 2dcc <native_bpf_strncasestr+0x40> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2e10, 0x2dcc, arm64_l_2dcc);
arm64_l_2e14:
	/* 0x2e14: b 2dac <native_bpf_strncasestr+0x20> */
	ARM64_SIM_A64_JMP(0x2e14, 0x2dac, arm64_l_2dac);
arm64_l_2e18:
	/* 0x2e18: mov w0, #0xffffffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967295ULL);
arm64_l_2e1c:
	/* 0x2e1c: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_2e1c);
arm64_l_2e20:
	/* 0x2e20: mov x7, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
