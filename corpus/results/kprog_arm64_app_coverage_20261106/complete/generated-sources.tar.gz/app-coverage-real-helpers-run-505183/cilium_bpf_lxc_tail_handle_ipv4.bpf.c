extern char __config_debug_lb;
extern char __config_enable_conntrack_accounting;
extern char __config_enable_ipv4_fragments;
extern char __config_enable_jiffies;
extern char __config_enable_lrp;
extern char __config_enable_no_service_endpoints_routable;
extern char __config_endpoint_netns_cookie;
extern char __config_kernel_hz;
extern char __config_nodeport_port_max;
extern char __config_nodeport_port_min;
extern char __config_security_label;
extern char __config_service_loopback_ipv4;
extern char __config_trace_payload_len;
extern char cilium_calls;
extern char cilium_ct4_global;
extern char cilium_ct_any4_global;
extern char cilium_ipcache_v2;
extern char cilium_ipv4_frag_datagrams;
extern char cilium_lb4_affinity;
extern char cilium_lb4_backends_v3;
extern char cilium_lb4_services_v2;
extern char cilium_lb_affinity_match;
extern char cilium_metrics;
extern char cilium_nodeport_nat_buffer;
extern char cilium_skip_lb4;
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_RETURN_CASES \
	case 0xf0ULL: goto arm64_l_f0; \
	case 0x114ULL: goto arm64_l_114; \
	case 0x144ULL: goto arm64_l_144; \
	case 0x188ULL: goto arm64_l_188; \
	case 0x1c0ULL: goto arm64_l_1c0; \
	case 0x1f8ULL: goto arm64_l_1f8; \
	case 0x278ULL: goto arm64_l_278; \
	case 0x2d8ULL: goto arm64_l_2d8; \
	case 0x314ULL: goto arm64_l_314; \
	case 0x360ULL: goto arm64_l_360; \
	case 0x3d0ULL: goto arm64_l_3d0; \
	case 0x3f8ULL: goto arm64_l_3f8; \
	case 0x42cULL: goto arm64_l_42c; \
	case 0x458ULL: goto arm64_l_458; \
	case 0x4e0ULL: goto arm64_l_4e0; \
	case 0x508ULL: goto arm64_l_508; \
	case 0x540ULL: goto arm64_l_540; \
	case 0x550ULL: goto arm64_l_550; \
	case 0x618ULL: goto arm64_l_618; \
	case 0x628ULL: goto arm64_l_628; \
	case 0x7acULL: goto arm64_l_7ac; \
	case 0x7f0ULL: goto arm64_l_7f0; \
	case 0x800ULL: goto arm64_l_800; \
	case 0x8bcULL: goto arm64_l_8bc; \
	case 0x8fcULL: goto arm64_l_8fc; \
	case 0x930ULL: goto arm64_l_930; \
	case 0x95cULL: goto arm64_l_95c; \
	case 0x978ULL: goto arm64_l_978; \
	case 0x9a4ULL: goto arm64_l_9a4; \
	case 0x9dcULL: goto arm64_l_9dc; \
	case 0xa08ULL: goto arm64_l_a08; \
	case 0xaa8ULL: goto arm64_l_aa8; \
	case 0xab8ULL: goto arm64_l_ab8; \
	case 0xb80ULL: goto arm64_l_b80; \
	case 0xba0ULL: goto arm64_l_ba0; \
	case 0xbb0ULL: goto arm64_l_bb0; \
	case 0xc2cULL: goto arm64_l_c2c; \
	case 0xc54ULL: goto arm64_l_c54; \
	case 0xc88ULL: goto arm64_l_c88; \
	case 0xc90ULL: goto arm64_l_c90; \
	case 0xcc4ULL: goto arm64_l_cc4; \
	case 0xcf4ULL: goto arm64_l_cf4; \
	case 0xdecULL: goto arm64_l_dec; \
	case 0xdfcULL: goto arm64_l_dfc; \
	case 0xeb8ULL: goto arm64_l_eb8; \
	case 0xee8ULL: goto arm64_l_ee8; \
	case 0xef8ULL: goto arm64_l_ef8; \
	case 0xf58ULL: goto arm64_l_f58; \
	case 0x1060ULL: goto arm64_l_1060; \
	case 0x10a4ULL: goto arm64_l_10a4; \
	case 0x10dcULL: goto arm64_l_10dc; \
	case 0x1118ULL: goto arm64_l_1118; \
	case 0x1160ULL: goto arm64_l_1160; \
	case 0x1188ULL: goto arm64_l_1188; \
	case 0x11f8ULL: goto arm64_l_11f8; \
	case 0x1234ULL: goto arm64_l_1234; \
	case 0x124cULL: goto arm64_l_124c; \
	case 0x12b4ULL: goto arm64_l_12b4;
#include "../arm64_sim_local_bpf.h"

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_debug_lb_0 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_enable_conntrack_accounting_1 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_enable_ipv4_fragments_2 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_enable_jiffies_3 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_enable_lrp_4 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_enable_no_service_endpoints_routable_5 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_endpoint_netns_cookie_6 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_kernel_hz_7 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_nodeport_port_max_8 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_nodeport_port_min_9 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_security_label_10 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_service_loopback_ipv4_11 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_trace_payload_len_12 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} cilium_calls_13 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} cilium_ct4_global_14 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} cilium_ct_any4_global_15 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} cilium_ipcache_v2_16 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} cilium_ipv4_frag_datagrams_17 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} cilium_lb4_affinity_18 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} cilium_lb4_backends_v3_19 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} cilium_lb4_services_v2_20 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} cilium_lb_affinity_match_21 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} cilium_metrics_22 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} cilium_nodeport_nat_buffer_23 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} cilium_skip_lb4_24 SEC(".maps");

SEC("xdp")
int cilium_bpf_lxc_tail_handle_ipv4_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
arm64_l_0:
	/* 0x0: sub sp, sp, #0xe0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_4:
	/* 0x4: str x29, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_8:
	/* 0x8: stp x30, x25, [sp, #160] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_c:
	/* 0xc: stp x24, x23, [sp, #176] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_10:
	/* 0x10: stp x22, x21, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_14:
	/* 0x14: stp x20, x19, [sp, #208] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_18:
	/* 0x18: ldp w8, w9, [x0, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_1c:
	/* 0x1c: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_20:
	/* 0x20: sub w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_24:
	/* 0x24: cmp w8, #0x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 34ULL);
arm64_l_28:
	/* 0x28: b.cs 38 <tail_handle_ipv4+0x38> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x28, 0x38, arm64_l_38);
arm64_l_2c:
	/* 0x2c: mov w22, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_30:
	/* 0x30: mov w8, #0xffffff7a */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967162ULL);
arm64_l_34:
	/* 0x34: b 11a0 <tail_handle_ipv4+0x11a0> */
	ARM64_SIM_A64_JMP(0x34, 0x11a0, arm64_l_11a0);
arm64_l_38:
	/* 0x38: adrp x23, 0 <__config_enable_ipv4_fragments> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_enable_ipv4_fragments_2));
arm64_l_3c:
	/* 0x3c: ldr x8, [x19, #208] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_40:
	/* 0x40: ldr x23, [x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_44:
	/* 0x44: ldrb w11, [x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_48:
	/* 0x48: ldrh w9, [x8, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_4c:
	/* 0x4c: and w10, w9, #0xffffff3f */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967103ULL);
arm64_l_50:
	/* 0x50: cbz w11, 15c <tail_handle_ipv4+0x15c> */
	ARM64_SIM_A64_CBZ(ARM64_X11, 0x50, 0x15c, arm64_l_15c);
arm64_l_54:
	/* 0x54: ldrh w11, [x8, #18] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 18ULL);
arm64_l_58:
	/* 0x58: ldrb w12, [x8, #23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 23ULL);
arm64_l_5c:
	/* 0x5c: cmp w10, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_60:
	/* 0x60: orr x11, x11, x12, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X11, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_LSL, 32), 0);
arm64_l_64:
	/* 0x64: strh wzr, [sp, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_68:
	/* 0x68: str wzr, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_6c:
	/* 0x6c: str xzr, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_70:
	/* 0x70: strb w12, [sp, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_74:
	/* 0x74: orr x13, x11, #0x10000000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 1099511627776ULL);
arm64_l_78:
	/* 0x78: csel x10, x11, x13, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X10, ARM64_X11, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_EQ, 0);
arm64_l_7c:
	/* 0x7c: mov w13, #0xff1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 65311ULL);
arm64_l_80:
	/* 0x80: orr x11, x10, #0x20000000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 2199023255552ULL);
arm64_l_84:
	/* 0x84: tst w9, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_88:
	/* 0x88: ldur w9, [x8, #30] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 30ULL);
arm64_l_8c:
	/* 0x8c: csel x24, x10, x11, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X24, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_EQ, 0);
arm64_l_90:
	/* 0x90: ldrb w10, [x8, #14] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 14ULL);
arm64_l_94:
	/* 0x94: ldur w8, [x8, #26] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 26ULL);
arm64_l_98:
	/* 0x98: cmp w12, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_9c:
	/* 0x9c: ccmp w12, #0x6, #0x4, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_NE, 4), 6ULL);
arm64_l_a0:
	/* 0xa0: str w9, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_a4:
	/* 0xa4: stp w8, wzr, [sp, #60] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 60ULL);
arm64_l_a8:
	/* 0xa8: b.ne 2e0 <tail_handle_ipv4+0x2e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xa8, 0x2e0, arm64_l_2e0);
arm64_l_ac:
	/* 0xac: ubfiz x10, x10, #2, #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_BITFIELD, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFIZ, 2, 4), 0);
arm64_l_b0:
	/* 0xb0: add x20, sp, #0x38 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_b4:
	/* 0xb4: add x29, x10, #0xe */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 14ULL);
arm64_l_b8:
	/* 0xb8: ldrb w10, [x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_bc:
	/* 0xbc: cbz w10, 16c <tail_handle_ipv4+0x16c> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0xbc, 0x16c, arm64_l_16c);
arm64_l_c0:
	/* 0xc0: stp w9, w8, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_c4:
	/* 0xc4: lsr x8, x24, #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 32ULL);
arm64_l_c8:
	/* 0xc8: strh w24, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_cc:
	/* 0xcc: strb wzr, [sp, #139] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 139ULL);
arm64_l_d0:
	/* 0xd0: strb w8, [sp, #138] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 138ULL);
arm64_l_d4:
	/* 0xd4: tbnz x24, #41, 990 <tail_handle_ipv4+0x990> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 41, 0xd4, 0x990, arm64_l_990);
arm64_l_d8:
	/* 0xd8: mov w8, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 26ULL);
arm64_l_dc:
	/* 0xdc: add x2, x20, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_e0:
	/* 0xe0: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e4:
	/* 0xe4: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_e8:
	/* 0xe8: mov w3, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X3, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_ec:
	/* 0xec: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 26ULL: ARM64_SIM_A64_LINK(0xf0ULL); ARM64_SIM_BPF_CALL_bpf_skb_load_bytes(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_f0:
	/* 0xf0: tbnz w0, #31, 324 <tail_handle_ipv4+0x324> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0xf0, 0x324, arm64_l_324);
arm64_l_f4:
	/* 0xf4: tbz x24, #40, 18c <tail_handle_ipv4+0x18c> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 40, 0xf4, 0x18c, arm64_l_18c);
arm64_l_f8:
	/* 0xf8: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_fc:
	/* 0xfc: adrp x0, 0 <cilium_ipv4_frag_datagrams> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_ipv4_frag_datagrams_17));
arm64_l_100:
	/* 0x100: add x1, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_104:
	/* 0x104: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_108:
	/* 0x108: add x2, x20, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_10c:
	/* 0x10c: mov w3, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_110:
	/* 0x110: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0x114ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_114:
	/* 0x114: cbz w0, 18c <tail_handle_ipv4+0x18c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x114, 0x18c, arm64_l_18c);
arm64_l_118:
	/* 0x118: mov x8, #0x20a */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 522ULL);
arm64_l_11c:
	/* 0x11c: stp xzr, xzr, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_120:
	/* 0x120: adrp x0, 0 <cilium_metrics> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_metrics_22));
arm64_l_124:
	/* 0x124: add x1, sp, #0x98 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_128:
	/* 0x128: movk x8, #0x85, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 133ULL);
arm64_l_12c:
	/* 0x12c: ldr w20, [x19, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_130:
	/* 0x130: movk x8, #0x6b, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 107ULL);
arm64_l_134:
	/* 0x134: str x8, [sp, #152] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_138:
	/* 0x138: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_13c:
	/* 0x13c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_140:
	/* 0x140: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x144ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_144:
	/* 0x144: cbz x0, 9e4 <tail_handle_ipv4+0x9e4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x144, 0x9e4, arm64_l_9e4);
arm64_l_148:
	/* 0x148: ldp x8, x9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_14c:
	/* 0x14c: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_150:
	/* 0x150: add x9, x9, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_154:
	/* 0x154: stp x8, x9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_158:
	/* 0x158: b 18c <tail_handle_ipv4+0x18c> */
	ARM64_SIM_A64_JMP(0x158, 0x18c, arm64_l_18c);
arm64_l_15c:
	/* 0x15c: mov w22, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_160:
	/* 0x160: cbz w10, 31c <tail_handle_ipv4+0x31c> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x160, 0x31c, arm64_l_31c);
arm64_l_164:
	/* 0x164: mov w8, #0xffffff63 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967139ULL);
arm64_l_168:
	/* 0x168: b 11a0 <tail_handle_ipv4+0x11a0> */
	ARM64_SIM_A64_JMP(0x168, 0x11a0, arm64_l_11a0);
arm64_l_16c:
	/* 0x16c: tbnz x24, #41, 9b4 <tail_handle_ipv4+0x9b4> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 41, 0x16c, 0x9b4, arm64_l_9b4);
arm64_l_170:
	/* 0x170: mov w8, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 26ULL);
arm64_l_174:
	/* 0x174: add x2, x20, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_178:
	/* 0x178: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_17c:
	/* 0x17c: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_180:
	/* 0x180: mov w3, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X3, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_184:
	/* 0x184: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 26ULL: ARM64_SIM_A64_LINK(0x188ULL); ARM64_SIM_BPF_CALL_bpf_skb_load_bytes(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_188:
	/* 0x188: tbnz w0, #31, 434 <tail_handle_ipv4+0x434> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x188, 0x434, arm64_l_434);
arm64_l_18c:
	/* 0x18c: ldrb w8, [sp, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_190:
	/* 0x190: strh wzr, [sp, #46] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 46ULL);
arm64_l_194:
	/* 0x194: adrp x0, 0 <cilium_lb4_services_v2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_lb4_services_v2_20));
arm64_l_198:
	/* 0x198: add x1, sp, #0x28 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_19c:
	/* 0x19c: strb wzr, [sp, #49] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 49ULL);
arm64_l_1a0:
	/* 0x1a0: strb w8, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1a4:
	/* 0x1a4: ldr w8, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1a8:
	/* 0x1a8: str w8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1ac:
	/* 0x1ac: ldrh w8, [sp, #66] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 66ULL);
arm64_l_1b0:
	/* 0x1b0: strh w8, [sp, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_1b4:
	/* 0x1b4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1b8:
	/* 0x1b8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1bc:
	/* 0x1bc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1c0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1c0:
	/* 0x1c0: adrp x20, 0 <cilium_ct_any4_global> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_ct_any4_global_15));
arm64_l_1c4:
	/* 0x1c4: adrp x22, 0 <cilium_ct4_global> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_ct4_global_14));
arm64_l_1c8:
	/* 0x1c8: ldr x20, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1cc:
	/* 0x1cc: ldr x22, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1d0:
	/* 0x1d0: cbz x0, 290 <tail_handle_ipv4+0x290> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1d0, 0x290, arm64_l_290);
arm64_l_1d4:
	/* 0x1d4: ldrb w8, [x0, #9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 9ULL);
arm64_l_1d8:
	/* 0x1d8: mov x21, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1dc:
	/* 0x1dc: tbz w8, #5, 200 <tail_handle_ipv4+0x200> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 5, 0x1dc, 0x200, arm64_l_200);
arm64_l_1e0:
	/* 0x1e0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e4:
	/* 0x1e4: adrp x0, 0 <cilium_lb4_services_v2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_lb4_services_v2_20));
arm64_l_1e8:
	/* 0x1e8: add x1, sp, #0x28 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_1ec:
	/* 0x1ec: strb w8, [sp, #49] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 49ULL);
arm64_l_1f0:
	/* 0x1f0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f4:
	/* 0x1f4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1f8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1f8:
	/* 0x1f8: mov x21, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1fc:
	/* 0x1fc: cbz x0, 290 <tail_handle_ipv4+0x290> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1fc, 0x290, arm64_l_290);
arm64_l_200:
	/* 0x200: str x29, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_204:
	/* 0x204: adrp x8, 0 <__config_enable_lrp> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_enable_lrp_4));
arm64_l_208:
	/* 0x208: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_20c:
	/* 0x20c: ldrb wzr, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_210:
	/* 0x210: ldrb w29, [sp, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_214:
	/* 0x214: ldrb w8, [sp, #69] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 69ULL);
arm64_l_218:
	/* 0x218: ldrh w25, [x21, #6] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_21c:
	/* 0x21c: str wzr, [sp, #152] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_220:
	/* 0x220: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_224:
	/* 0x224: str w8, [sp, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_228:
	/* 0x228: csel x8, x22, x20, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X22, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_EQ, 0);
arm64_l_22c:
	/* 0x22c: str x8, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_230:
	/* 0x230: ldr w8, [sp, #60] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 60ULL);
arm64_l_234:
	/* 0x234: str x8, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_238:
	/* 0x238: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_23c:
	/* 0x23c: strb w8, [sp, #69] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 69ULL);
arm64_l_240:
	/* 0x240: ldrb w8, [x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_244:
	/* 0x244: cbz w8, 3d0 <tail_handle_ipv4+0x3d0> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x244, 0x3d0, arm64_l_3d0);
arm64_l_248:
	/* 0x248: tbz x24, #40, 3d0 <tail_handle_ipv4+0x3d0> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 40, 0x248, 0x3d0, arm64_l_3d0);
arm64_l_24c:
	/* 0x24c: mov x8, #0x309 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 777ULL);
arm64_l_250:
	/* 0x250: stp xzr, xzr, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_254:
	/* 0x254: adrp x0, 0 <cilium_metrics> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_metrics_22));
arm64_l_258:
	/* 0x258: add x1, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_25c:
	/* 0x25c: movk x8, #0x3a5, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 933ULL);
arm64_l_260:
	/* 0x260: ldr w20, [x19, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_264:
	/* 0x264: movk x8, #0x6c, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 108ULL);
arm64_l_268:
	/* 0x268: str x8, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_26c:
	/* 0x26c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_270:
	/* 0x270: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_274:
	/* 0x274: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x278ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_278:
	/* 0x278: cbz x0, 3ac <tail_handle_ipv4+0x3ac> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x278, 0x3ac, arm64_l_3ac);
arm64_l_27c:
	/* 0x27c: ldp x8, x9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_280:
	/* 0x280: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_284:
	/* 0x284: add x9, x9, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_288:
	/* 0x288: stp x8, x9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_28c:
	/* 0x28c: b 3d0 <tail_handle_ipv4+0x3d0> */
	ARM64_SIM_A64_JMP(0x28c, 0x3d0, arm64_l_3d0);
arm64_l_290:
	/* 0x290: ldur x8, [sp, #62] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 62ULL);
arm64_l_294:
	/* 0x294: add x1, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_298:
	/* 0x298: mov w21, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_29c:
	/* 0x29c: stur x8, [sp, #134] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 134ULL);
arm64_l_2a0:
	/* 0x2a0: ldr x8, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2a4:
	/* 0x2a4: ldr w10, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_2a8:
	/* 0x2a8: ldrb w25, [sp, #141] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 141ULL);
arm64_l_2ac:
	/* 0x2ac: strb wzr, [sp, #141] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 141ULL);
arm64_l_2b0:
	/* 0x2b0: lsr x9, x8, #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 32ULL);
arm64_l_2b4:
	/* 0x2b4: str x8, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_2b8:
	/* 0x2b8: stp w9, w8, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_2bc:
	/* 0x2bc: ror w8, w10, #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_ROR), 16ULL);
arm64_l_2c0:
	/* 0x2c0: str w8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_2c4:
	/* 0x2c4: ldrb w8, [sp, #140] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 140ULL);
arm64_l_2c8:
	/* 0x2c8: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2cc:
	/* 0x2cc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2d0:
	/* 0x2d0: csel x0, x22, x20, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_X22, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_EQ, 0);
arm64_l_2d4:
	/* 0x2d4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2d8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2d8:
	/* 0x2d8: strb w25, [sp, #141] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 141ULL);
arm64_l_2dc:
	/* 0x2dc: cbz x0, 32c <tail_handle_ipv4+0x32c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2dc, 0x32c, arm64_l_32c);
arm64_l_2e0:
	/* 0x2e0: mov w25, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2e4:
	/* 0x2e4: mov w29, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2e8:
	/* 0x2e8: and w8, w29, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2ec:
	/* 0x2ec: str xzr, [x19, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2f0:
	/* 0x2f0: adrp x1, 0 <cilium_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_calls_13));
arm64_l_2f4:
	/* 0x2f4: mov w22, #0x1e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 30ULL);
arm64_l_2f8:
	/* 0x2f8: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2fc:
	/* 0x2fc: mov w2, #0x1e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 30ULL);
arm64_l_300:
	/* 0x300: orr w8, w8, w25, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_LSL, 16), 0);
arm64_l_304:
	/* 0x304: str w8, [x19, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_308:
	/* 0x308: mov w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_30c:
	/* 0x30c: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_310:
	/* 0x310: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x314ULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_314:
	/* 0x314: mov w8, #0xffffff74 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967156ULL);
arm64_l_318:
	/* 0x318: b 11a0 <tail_handle_ipv4+0x11a0> */
	ARM64_SIM_A64_JMP(0x318, 0x11a0, arm64_l_11a0);
arm64_l_31c:
	/* 0x31c: mov w10, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_320:
	/* 0x320: b 54 <tail_handle_ipv4+0x54> */
	ARM64_SIM_A64_JMP(0x320, 0x54, arm64_l_54);
arm64_l_324:
	/* 0x324: mov w8, #0xffffff79 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967161ULL);
arm64_l_328:
	/* 0x328: b 119c <tail_handle_ipv4+0x119c> */
	ARM64_SIM_A64_JMP(0x328, 0x119c, arm64_l_119c);
arm64_l_32c:
	/* 0x32c: mov w8, #0x40 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 64ULL);
arm64_l_330:
	/* 0x330: stur xzr, [sp, #78] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 78ULL);
arm64_l_334:
	/* 0x334: strh wzr, [sp, #94] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 94ULL);
arm64_l_338:
	/* 0x338: adrp x0, 0 <cilium_ipcache_v2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_ipcache_v2_16));
arm64_l_33c:
	/* 0x33c: add x1, sp, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_340:
	/* 0x340: str w8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_344:
	/* 0x344: ldr w8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_348:
	/* 0x348: stur xzr, [sp, #86] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 86ULL);
arm64_l_34c:
	/* 0x34c: strb w21, [sp, #79] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 79ULL);
arm64_l_350:
	/* 0x350: strh wzr, [sp, #76] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_354:
	/* 0x354: str w8, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_358:
	/* 0x358: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_35c:
	/* 0x35c: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x360ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_360:
	/* 0x360: cbz x0, 2e0 <tail_handle_ipv4+0x2e0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x360, 0x2e0, arm64_l_2e0);
arm64_l_364:
	/* 0x364: adrp x9, 0 <__config_nodeport_port_min> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_nodeport_port_min_9));
arm64_l_368:
	/* 0x368: ldrh w8, [sp, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_36c:
	/* 0x36c: ldr x9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_370:
	/* 0x370: rev w8, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_REV, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_374:
	/* 0x374: ldrh w9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_378:
	/* 0x378: lsr w8, w8, #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 16ULL);
arm64_l_37c:
	/* 0x37c: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_380:
	/* 0x380: b.cc 398 <tail_handle_ipv4+0x398> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x380, 0x398, arm64_l_398);
arm64_l_384:
	/* 0x384: adrp x9, 0 <__config_nodeport_port_max> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_nodeport_port_max_8));
arm64_l_388:
	/* 0x388: ldr x9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_38c:
	/* 0x38c: ldrh w9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_390:
	/* 0x390: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_394:
	/* 0x394: b.ls 4b0 <tail_handle_ipv4+0x4b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x394, 0x4b0, arm64_l_4b0);
arm64_l_398:
	/* 0x398: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_39c:
	/* 0x39c: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3a0:
	/* 0x3a0: b.ne 2e0 <tail_handle_ipv4+0x2e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3a0, 0x2e0, arm64_l_2e0);
arm64_l_3a4:
	/* 0x3a4: mov w25, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_3a8:
	/* 0x3a8: b 4c0 <tail_handle_ipv4+0x4c0> */
	ARM64_SIM_A64_JMP(0x3a8, 0x4c0, arm64_l_4c0);
arm64_l_3ac:
	/* 0x3ac: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3b0:
	/* 0x3b0: adrp x0, 0 <cilium_metrics> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_metrics_22));
arm64_l_3b4:
	/* 0x3b4: add x1, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_3b8:
	/* 0x3b8: stp x8, x20, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3bc:
	/* 0x3bc: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_3c0:
	/* 0x3c0: add x2, sp, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3c4:
	/* 0x3c4: mov w3, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_3c8:
	/* 0x3c8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3cc:
	/* 0x3cc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0x3d0ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3d0:
	/* 0x3d0: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_3d4:
	/* 0x3d4: b.ne 440 <tail_handle_ipv4+0x440> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3d4, 0x440, arm64_l_440);
arm64_l_3d8:
	/* 0x3d8: tbnz x24, #41, 440 <tail_handle_ipv4+0x440> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 41, 0x3d8, 0x440, arm64_l_440);
arm64_l_3dc:
	/* 0x3dc: mov w8, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 26ULL);
arm64_l_3e0:
	/* 0x3e0: add x2, sp, #0x98 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3e4:
	/* 0x3e4: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3e8:
	/* 0x3e8: ldr x9, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_3ec:
	/* 0x3ec: mov w3, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X3, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_3f0:
	/* 0x3f0: add w1, w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_3f4:
	/* 0x3f4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 26ULL: ARM64_SIM_A64_LINK(0x3f8ULL); ARM64_SIM_BPF_CALL_bpf_skb_load_bytes(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3f8:
	/* 0x3f8: tbnz w0, #31, 434 <tail_handle_ipv4+0x434> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x3f8, 0x434, arm64_l_434);
arm64_l_3fc:
	/* 0x3fc: ldr w23, [sp, #152] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_400:
	/* 0x400: mov w8, #0x500 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1280ULL);
arm64_l_404:
	/* 0x404: tst w23, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_408:
	/* 0x408: b.ne 9c8 <tail_handle_ipv4+0x9c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x408, 0x9c8, arm64_l_9c8);
arm64_l_40c:
	/* 0x40c: mov w8, #0x1200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4608ULL);
arm64_l_410:
	/* 0x410: and w8, w23, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_414:
	/* 0x414: cmp w8, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 512ULL);
arm64_l_418:
	/* 0x418: cset w20, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_41c:
	/* 0x41c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_420:
	/* 0x420: add x1, sp, #0x38 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_424:
	/* 0x424: ldr x0, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_428:
	/* 0x428: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x42cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_42c:
	/* 0x42c: cbnz x0, 45c <tail_handle_ipv4+0x45c> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x42c, 0x45c, arm64_l_45c);
arm64_l_430:
	/* 0x430: b b38 <tail_handle_ipv4+0xb38> */
	ARM64_SIM_A64_JMP(0x430, 0xb38, arm64_l_b38);
arm64_l_434:
	/* 0x434: mov w22, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_438:
	/* 0x438: mov w8, #0xffffff79 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967161ULL);
arm64_l_43c:
	/* 0x43c: b 11a0 <tail_handle_ipv4+0x11a0> */
	ARM64_SIM_A64_JMP(0x43c, 0x11a0, arm64_l_11a0);
arm64_l_440:
	/* 0x440: ldr w23, [sp, #152] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_444:
	/* 0x444: mov w20, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_448:
	/* 0x448: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_44c:
	/* 0x44c: add x1, sp, #0x38 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_450:
	/* 0x450: ldr x0, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_454:
	/* 0x454: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x458ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_458:
	/* 0x458: cbz x0, b38 <tail_handle_ipv4+0xb38> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x458, 0xb38, arm64_l_b38);
arm64_l_45c:
	/* 0x45c: ldrh w8, [x0, #38] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 38ULL);
arm64_l_460:
	/* 0x460: cmp w8, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_464:
	/* 0x464: b.ne b38 <tail_handle_ipv4+0xb38> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x464, 0xb38, arm64_l_b38);
arm64_l_468:
	/* 0x468: and w8, w23, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 512ULL);
arm64_l_46c:
	/* 0x46c: str w8, [sp, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_470:
	/* 0x470: cbz w8, 57c <tail_handle_ipv4+0x57c> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x470, 0x57c, arm64_l_57c);
arm64_l_474:
	/* 0x474: ldrh w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_478:
	/* 0x478: tst w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_47c:
	/* 0x47c: b.eq 57c <tail_handle_ipv4+0x57c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x47c, 0x57c, arm64_l_57c);
arm64_l_480:
	/* 0x480: adrp x8, 0 <__config_enable_jiffies> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_enable_jiffies_3));
arm64_l_484:
	/* 0x484: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_488:
	/* 0x488: ldrb w9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_48c:
	/* 0x48c: str w25, [sp] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_490:
	/* 0x490: cbz w9, 520 <tail_handle_ipv4+0x520> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x490, 0x520, arm64_l_520);
arm64_l_494:
	/* 0x494: adrp x9, 0 <__config_kernel_hz> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_kernel_hz_7));
arm64_l_498:
	/* 0x498: ldr x9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_49c:
	/* 0x49c: ldr w9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_4a0:
	/* 0x4a0: lsl w10, w9, #5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 5ULL);
arm64_l_4a4:
	/* 0x4a4: sub w9, w10, w9, lsl #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_LSL, 1), 0);
arm64_l_4a8:
	/* 0x4a8: lsr w9, w9, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_4ac:
	/* 0x4ac: b 524 <tail_handle_ipv4+0x524> */
	ARM64_SIM_A64_JMP(0x4ac, 0x524, arm64_l_524);
arm64_l_4b0:
	/* 0x4b0: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_4b4:
	/* 0x4b4: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_4b8:
	/* 0x4b8: b.ne 7b0 <tail_handle_ipv4+0x7b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x4b8, 0x7b0, arm64_l_7b0);
arm64_l_4bc:
	/* 0x4bc: mov w25, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_4c0:
	/* 0x4c0: str wzr, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_4c4:
	/* 0x4c4: strh wzr, [sp, #46] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 46ULL);
arm64_l_4c8:
	/* 0x4c8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_4cc:
	/* 0x4cc: adrp x0, 0 <cilium_lb4_services_v2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_lb4_services_v2_20));
arm64_l_4d0:
	/* 0x4d0: add x1, sp, #0x28 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_4d4:
	/* 0x4d4: strb wzr, [sp, #49] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 49ULL);
arm64_l_4d8:
	/* 0x4d8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_4dc:
	/* 0x4dc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x4e0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_4e0:
	/* 0x4e0: cbz x0, 2e0 <tail_handle_ipv4+0x2e0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x4e0, 0x2e0, arm64_l_2e0);
arm64_l_4e4:
	/* 0x4e4: ldrb w8, [x0, #9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 9ULL);
arm64_l_4e8:
	/* 0x4e8: mov x21, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_4ec:
	/* 0x4ec: tbz w8, #5, 510 <tail_handle_ipv4+0x510> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 5, 0x4ec, 0x510, arm64_l_510);
arm64_l_4f0:
	/* 0x4f0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_4f4:
	/* 0x4f4: adrp x0, 0 <cilium_lb4_services_v2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_lb4_services_v2_20));
arm64_l_4f8:
	/* 0x4f8: add x1, sp, #0x28 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_4fc:
	/* 0x4fc: strb w8, [sp, #49] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 49ULL);
arm64_l_500:
	/* 0x500: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_504:
	/* 0x504: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x508ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_508:
	/* 0x508: mov x21, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_50c:
	/* 0x50c: cbz x0, 2e0 <tail_handle_ipv4+0x2e0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x50c, 0x2e0, arm64_l_2e0);
arm64_l_510:
	/* 0x510: ldrb w8, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_514:
	/* 0x514: cbz w25, 774 <tail_handle_ipv4+0x774> */
	ARM64_SIM_A64_CBZ(ARM64_X25, 0x514, 0x774, arm64_l_774);
arm64_l_518:
	/* 0x518: tbz w8, #1, 2e0 <tail_handle_ipv4+0x2e0> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 1, 0x518, 0x2e0, arm64_l_2e0);
arm64_l_51c:
	/* 0x51c: b 778 <tail_handle_ipv4+0x778> */
	ARM64_SIM_A64_JMP(0x51c, 0x778, arm64_l_778);
arm64_l_520:
	/* 0x520: mov w9, #0x1e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 30ULL);
arm64_l_524:
	/* 0x524: ldr w10, [x0, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_528:
	/* 0x528: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_52c:
	/* 0x52c: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_530:
	/* 0x530: add w25, w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X25, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_534:
	/* 0x534: cbz w8, 548 <tail_handle_ipv4+0x548> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x534, 0x548, arm64_l_548);
arm64_l_538:
	/* 0x538: mov w8, #0x76 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 118ULL);
arm64_l_53c:
	/* 0x53c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 118ULL: ARM64_SIM_A64_LINK(0x540ULL); ARM64_SIM_BPF_CALL_bpf_jiffies64(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_540:
	/* 0x540: lsr x8, x0, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_544:
	/* 0x544: b 56c <tail_handle_ipv4+0x56c> */
	ARM64_SIM_A64_JMP(0x544, 0x56c, arm64_l_56c);
arm64_l_548:
	/* 0x548: mov w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_54c:
	/* 0x54c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 5ULL: ARM64_SIM_A64_LINK(0x550ULL); ARM64_SIM_BPF_CALL_bpf_ktime_get_ns(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_550:
	/* 0x550: mov x9, #0x5a53 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 23123ULL);
arm64_l_554:
	/* 0x554: lsr x8, x0, #9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 9ULL);
arm64_l_558:
	/* 0x558: movk x9, #0xa09b, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 41115ULL);
arm64_l_55c:
	/* 0x55c: movk x9, #0xb82f, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 47151ULL);
arm64_l_560:
	/* 0x560: movk x9, #0x44, lsl #48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 68ULL);
arm64_l_564:
	/* 0x564: umulh x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_UMULH, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_568:
	/* 0x568: lsr x8, x8, #11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 11ULL);
arm64_l_56c:
	/* 0x56c: cmp x8, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_570:
	/* 0x570: ldr w25, [sp] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_574:
	/* 0x574: mov x0, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_578:
	/* 0x578: b.cs b38 <tail_handle_ipv4+0xb38> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x578, 0xb38, arm64_l_b38);
arm64_l_57c:
	/* 0x57c: ldrh w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_580:
	/* 0x580: mov w9, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_584:
	/* 0x584: bics wzr, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_BIC_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_588:
	/* 0x588: b.eq 6bc <tail_handle_ipv4+0x6bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x588, 0x6bc, arm64_l_6bc);
arm64_l_58c:
	/* 0x58c: adrp x11, 0 <__config_enable_jiffies> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_enable_jiffies_3));
arm64_l_590:
	/* 0x590: ldr x11, [x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_594:
	/* 0x594: ldrb w9, [x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_598:
	/* 0x598: cbz w9, 5b8 <tail_handle_ipv4+0x5b8> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x598, 0x5b8, arm64_l_5b8);
arm64_l_59c:
	/* 0x59c: adrp x9, 0 <__config_kernel_hz> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_kernel_hz_7));
arm64_l_5a0:
	/* 0x5a0: ldr x9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_5a4:
	/* 0x5a4: ldr w9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_5a8:
	/* 0x5a8: lsl w10, w9, #6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 6ULL);
arm64_l_5ac:
	/* 0x5ac: sub w9, w10, w9, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_LSL, 2), 0);
arm64_l_5b0:
	/* 0x5b0: lsr w22, w9, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_5b4:
	/* 0x5b4: b 5bc <tail_handle_ipv4+0x5bc> */
	ARM64_SIM_A64_JMP(0x5b4, 0x5bc, arm64_l_5bc);
arm64_l_5b8:
	/* 0x5b8: mov w22, #0x3c */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 60ULL);
arm64_l_5bc:
	/* 0x5bc: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_5c0:
	/* 0x5c0: b.ne 600 <tail_handle_ipv4+0x600> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x5c0, 0x600, arm64_l_600);
arm64_l_5c4:
	/* 0x5c4: mov w9, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_5c8:
	/* 0x5c8: mov w10, #0x3c */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 60ULL);
arm64_l_5cc:
	/* 0x5cc: bic w9, w9, w23, lsr #5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_BIC, ARM64_MOD_LSR, 5), 0);
arm64_l_5d0:
	/* 0x5d0: orr w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_5d4:
	/* 0x5d4: strh w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_5d8:
	/* 0x5d8: tst w8, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_5dc:
	/* 0x5dc: mov w8, #0x5460 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 21600ULL);
arm64_l_5e0:
	/* 0x5e0: ldrb w9, [x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_5e4:
	/* 0x5e4: csel w22, w10, w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X22, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_5e8:
	/* 0x5e8: cbz w9, 600 <tail_handle_ipv4+0x600> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x5e8, 0x600, arm64_l_600);
arm64_l_5ec:
	/* 0x5ec: adrp x8, 0 <__config_kernel_hz> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_kernel_hz_7));
arm64_l_5f0:
	/* 0x5f0: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_5f4:
	/* 0x5f4: ldr w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_5f8:
	/* 0x5f8: mul w8, w8, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_5fc:
	/* 0x5fc: lsr w22, w8, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_600:
	/* 0x600: str w25, [sp] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_604:
	/* 0x604: mov x25, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_608:
	/* 0x608: ldrb w8, [x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_60c:
	/* 0x60c: cbz w8, 620 <tail_handle_ipv4+0x620> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x60c, 0x620, arm64_l_620);
arm64_l_610:
	/* 0x610: mov w8, #0x76 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 118ULL);
arm64_l_614:
	/* 0x614: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 118ULL: ARM64_SIM_A64_LINK(0x618ULL); ARM64_SIM_BPF_CALL_bpf_jiffies64(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_618:
	/* 0x618: lsr x8, x0, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_61c:
	/* 0x61c: b 644 <tail_handle_ipv4+0x644> */
	ARM64_SIM_A64_JMP(0x61c, 0x644, arm64_l_644);
arm64_l_620:
	/* 0x620: mov w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_624:
	/* 0x624: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 5ULL: ARM64_SIM_A64_LINK(0x628ULL); ARM64_SIM_BPF_CALL_bpf_ktime_get_ns(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_628:
	/* 0x628: mov x9, #0x5a53 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 23123ULL);
arm64_l_62c:
	/* 0x62c: lsr x8, x0, #9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 9ULL);
arm64_l_630:
	/* 0x630: movk x9, #0xa09b, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 41115ULL);
arm64_l_634:
	/* 0x634: movk x9, #0xb82f, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 47151ULL);
arm64_l_638:
	/* 0x638: movk x9, #0x44, lsl #48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 68ULL);
arm64_l_63c:
	/* 0x63c: umulh x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_UMULH, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_640:
	/* 0x640: lsr x8, x8, #11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 11ULL);
arm64_l_644:
	/* 0x644: add w9, w22, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_648:
	/* 0x648: adrp x12, 0 <__config_enable_jiffies> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_enable_jiffies_3));
arm64_l_64c:
	/* 0x64c: lsr w11, w23, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_650:
	/* 0x650: str w9, [x25, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_654:
	/* 0x654: mov x0, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_658:
	/* 0x658: and w11, w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_65c:
	/* 0x65c: ldrb w9, [x25, #42] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 42ULL);
arm64_l_660:
	/* 0x660: ldr w10, [x25, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_664:
	/* 0x664: ldr x12, [x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_668:
	/* 0x668: ldrb w12, [x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_66c:
	/* 0x66c: cbz w12, 688 <tail_handle_ipv4+0x688> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0x66c, 0x688, arm64_l_688);
arm64_l_670:
	/* 0x670: adrp x12, 0 <__config_kernel_hz> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_kernel_hz_7));
arm64_l_674:
	/* 0x674: ldr x12, [x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_678:
	/* 0x678: ldr w12, [x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_67c:
	/* 0x67c: add w12, w12, w12, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_680:
	/* 0x680: lsr w12, w12, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_684:
	/* 0x684: b 68c <tail_handle_ipv4+0x68c> */
	ARM64_SIM_A64_JMP(0x684, 0x68c, arm64_l_68c);
arm64_l_688:
	/* 0x688: mov w12, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_68c:
	/* 0x68c: ldr w25, [sp] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_690:
	/* 0x690: add w10, w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_694:
	/* 0x694: orr w11, w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_698:
	/* 0x698: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_69c:
	/* 0x69c: b.cc 6a8 <tail_handle_ipv4+0x6a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x69c, 0x6a8, arm64_l_6a8);
arm64_l_6a0:
	/* 0x6a0: cmp w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_6a4:
	/* 0x6a4: b.eq 6bc <tail_handle_ipv4+0x6bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x6a4, 0x6bc, arm64_l_6bc);
arm64_l_6a8:
	/* 0x6a8: strb w11, [x0, #42] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 42ULL);
arm64_l_6ac:
	/* 0x6ac: str w8, [x0, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_6b0:
	/* 0x6b0: adrp x8, 0 <__config_trace_payload_len> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_trace_payload_len_12));
arm64_l_6b4:
	/* 0x6b4: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6b8:
	/* 0x6b8: ldr wzr, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6bc:
	/* 0x6bc: adrp x8, 0 <__config_enable_conntrack_accounting> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_enable_conntrack_accounting_1));
arm64_l_6c0:
	/* 0x6c0: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6c4:
	/* 0x6c4: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6c8:
	/* 0x6c8: cbz w8, 710 <tail_handle_ipv4+0x710> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x6c8, 0x710, arm64_l_710);
arm64_l_6cc:
	/* 0x6cc: add x8, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_6d0:
	/* 0x6d0: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6d4:
	/* 0x6d4: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6d8:
	/* 0x6d8: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6dc:
	/* 0x6dc: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6e0:
	/* 0x6e0: ldaxr x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6e4:
	/* 0x6e4: add x9, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_6e8:
	/* 0x6e8: stlxr w10, x9, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STLXR, ARM64_X10, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0);
arm64_l_6ec:
	/* 0x6ec: cbnz w10, 6e0 <tail_handle_ipv4+0x6e0> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0x6ec, 0x6e0, arm64_l_6e0);
arm64_l_6f0:
	/* 0x6f0: ldr w9, [x19, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_6f4:
	/* 0x6f4: add x8, x0, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_6f8:
	/* 0x6f8: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6fc:
	/* 0x6fc: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_700:
	/* 0x700: ldaxr x10, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_704:
	/* 0x704: add x10, x10, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_708:
	/* 0x708: stlxr w11, x10, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STLXR, ARM64_X11, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0);
arm64_l_70c:
	/* 0x70c: cbnz w11, 700 <tail_handle_ipv4+0x700> */
	ARM64_SIM_A64_CBNZ(ARM64_X11, 0x70c, 0x700, arm64_l_700);
arm64_l_710:
	/* 0x710: cmp w20, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_714:
	/* 0x714: b.eq 734 <tail_handle_ipv4+0x734> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x714, 0x734, arm64_l_734);
arm64_l_718:
	/* 0x718: cmp w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_71c:
	/* 0x71c: b.ne 72c <tail_handle_ipv4+0x72c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x71c, 0x72c, arm64_l_72c);
arm64_l_720:
	/* 0x720: ldrh w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_724:
	/* 0x724: tst w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_728:
	/* 0x728: b.ne a0c <tail_handle_ipv4+0xa0c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x728, 0xa0c, arm64_l_a0c);
arm64_l_72c:
	/* 0x72c: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_730:
	/* 0x730: b 884 <tail_handle_ipv4+0x884> */
	ARM64_SIM_A64_JMP(0x730, 0x884, arm64_l_884);
arm64_l_734:
	/* 0x734: ldrh w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_738:
	/* 0x738: adrp x20, 0 <__config_trace_payload_len> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_trace_payload_len_12));
arm64_l_73c:
	/* 0x73c: adrp x22, 0 <__config_enable_jiffies> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_enable_jiffies_3));
arm64_l_740:
	/* 0x740: orr w8, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_744:
	/* 0x744: strh w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_748:
	/* 0x748: ldr x20, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_74c:
	/* 0x74c: ldr wzr, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_XZR, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_750:
	/* 0x750: ldr x22, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_754:
	/* 0x754: ldrb w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_758:
	/* 0x758: cbz w8, 7d8 <tail_handle_ipv4+0x7d8> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x758, 0x7d8, arm64_l_7d8);
arm64_l_75c:
	/* 0x75c: adrp x8, 0 <__config_kernel_hz> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_kernel_hz_7));
arm64_l_760:
	/* 0x760: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_764:
	/* 0x764: ldr w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_768:
	/* 0x768: add w8, w8, w8, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_76c:
	/* 0x76c: ubfx w25, w8, #7, #24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_BITFIELD, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFX, 7, 24), 0);
arm64_l_770:
	/* 0x770: b 7dc <tail_handle_ipv4+0x7dc> */
	ARM64_SIM_A64_JMP(0x770, 0x7dc, arm64_l_7dc);
arm64_l_774:
	/* 0x774: tbz w8, #3, 2e0 <tail_handle_ipv4+0x2e0> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 3, 0x774, 0x2e0, arm64_l_2e0);
arm64_l_778:
	/* 0x778: ldr w8, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_77c:
	/* 0x77c: str xzr, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_780:
	/* 0x780: adrp x0, 0 <cilium_nodeport_nat_buffer> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_nodeport_nat_buffer_23));
arm64_l_784:
	/* 0x784: add x1, sp, #0x98 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_788:
	/* 0x788: add x2, sp, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_78c:
	/* 0x78c: mov w3, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_790:
	/* 0x790: str wzr, [sp, #152] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_794:
	/* 0x794: stp wzr, w8, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_798:
	/* 0x798: ldrh w8, [sp, #66] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 66ULL);
arm64_l_79c:
	/* 0x79c: strh w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_7a0:
	/* 0x7a0: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_7a4:
	/* 0x7a4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_7a8:
	/* 0x7a8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0x7acULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_7ac:
	/* 0x7ac: b 200 <tail_handle_ipv4+0x200> */
	ARM64_SIM_A64_JMP(0x7ac, 0x200, arm64_l_200);
arm64_l_7b0:
	/* 0x7b0: and w9, w8, #0xfffffffe */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967294ULL);
arm64_l_7b4:
	/* 0x7b4: cmp w9, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_7b8:
	/* 0x7b8: b.eq 7cc <tail_handle_ipv4+0x7cc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x7b8, 0x7cc, arm64_l_7cc);
arm64_l_7bc:
	/* 0x7bc: and w8, w8, #0xff000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4278190080ULL);
arm64_l_7c0:
	/* 0x7c0: mov w9, #0x2000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 33554432ULL);
arm64_l_7c4:
	/* 0x7c4: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_7c8:
	/* 0x7c8: b.ne 2e0 <tail_handle_ipv4+0x2e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x7c8, 0x2e0, arm64_l_2e0);
arm64_l_7cc:
	/* 0x7cc: ldrb w8, [x0, #23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 23ULL);
arm64_l_7d0:
	/* 0x7d0: tbnz w8, #3, 2e0 <tail_handle_ipv4+0x2e0> */
	ARM64_SIM_A64_TBNZ(ARM64_X8, 3, 0x7d0, 0x2e0, arm64_l_2e0);
arm64_l_7d4:
	/* 0x7d4: b 4bc <tail_handle_ipv4+0x4bc> */
	ARM64_SIM_A64_JMP(0x7d4, 0x4bc, arm64_l_4bc);
arm64_l_7d8:
	/* 0x7d8: mov w25, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_7dc:
	/* 0x7dc: ldrb w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_7e0:
	/* 0x7e0: mov x29, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7e4:
	/* 0x7e4: cbz w8, 7f8 <tail_handle_ipv4+0x7f8> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x7e4, 0x7f8, arm64_l_7f8);
arm64_l_7e8:
	/* 0x7e8: mov w8, #0x76 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 118ULL);
arm64_l_7ec:
	/* 0x7ec: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 118ULL: ARM64_SIM_A64_LINK(0x7f0ULL); ARM64_SIM_BPF_CALL_bpf_jiffies64(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_7f0:
	/* 0x7f0: lsr x8, x0, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_7f4:
	/* 0x7f4: b 81c <tail_handle_ipv4+0x81c> */
	ARM64_SIM_A64_JMP(0x7f4, 0x81c, arm64_l_81c);
arm64_l_7f8:
	/* 0x7f8: mov w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_7fc:
	/* 0x7fc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 5ULL: ARM64_SIM_A64_LINK(0x800ULL); ARM64_SIM_BPF_CALL_bpf_ktime_get_ns(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_800:
	/* 0x800: mov x9, #0x5a53 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 23123ULL);
arm64_l_804:
	/* 0x804: lsr x8, x0, #9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 9ULL);
arm64_l_808:
	/* 0x808: movk x9, #0xa09b, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 41115ULL);
arm64_l_80c:
	/* 0x80c: movk x9, #0xb82f, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 47151ULL);
arm64_l_810:
	/* 0x810: movk x9, #0x44, lsl #48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 68ULL);
arm64_l_814:
	/* 0x814: umulh x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_UMULH, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_818:
	/* 0x818: lsr x8, x8, #11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 11ULL);
arm64_l_81c:
	/* 0x81c: add w9, w25, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_820:
	/* 0x820: lsr w11, w23, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_824:
	/* 0x824: mov x0, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_828:
	/* 0x828: str w9, [x29, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_82c:
	/* 0x82c: and w11, w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_830:
	/* 0x830: ldrb w9, [x29, #42] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 42ULL);
arm64_l_834:
	/* 0x834: ldr w10, [x29, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_838:
	/* 0x838: ldrb w12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_83c:
	/* 0x83c: cbz w12, 858 <tail_handle_ipv4+0x858> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0x83c, 0x858, arm64_l_858);
arm64_l_840:
	/* 0x840: adrp x12, 0 <__config_kernel_hz> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_kernel_hz_7));
arm64_l_844:
	/* 0x844: ldr x12, [x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_848:
	/* 0x848: ldr w12, [x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_84c:
	/* 0x84c: add w12, w12, w12, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_850:
	/* 0x850: lsr w12, w12, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_854:
	/* 0x854: b 85c <tail_handle_ipv4+0x85c> */
	ARM64_SIM_A64_JMP(0x854, 0x85c, arm64_l_85c);
arm64_l_858:
	/* 0x858: mov w12, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_85c:
	/* 0x85c: add w10, w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_860:
	/* 0x860: orr w11, w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_864:
	/* 0x864: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_868:
	/* 0x868: b.cc 874 <tail_handle_ipv4+0x874> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x868, 0x874, arm64_l_874);
arm64_l_86c:
	/* 0x86c: cmp w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_870:
	/* 0x870: b.eq 880 <tail_handle_ipv4+0x880> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x870, 0x880, arm64_l_880);
arm64_l_874:
	/* 0x874: strb w11, [x0, #42] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 42ULL);
arm64_l_878:
	/* 0x878: str w8, [x0, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_87c:
	/* 0x87c: ldr wzr, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_XZR, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_880:
	/* 0x880: mov w8, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_884:
	/* 0x884: ldrb w9, [sp, #69] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 69ULL);
arm64_l_888:
	/* 0x888: tbnz w9, #1, 8d4 <tail_handle_ipv4+0x8d4> */
	ARM64_SIM_A64_TBNZ(ARM64_X9, 1, 0x888, 0x8d4, arm64_l_8d4);
arm64_l_88c:
	/* 0x88c: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_890:
	/* 0x890: ldr w10, [sp, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_894:
	/* 0x894: add x1, sp, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_898:
	/* 0x898: lsr w22, w10, #6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X22, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 6ULL);
arm64_l_89c:
	/* 0x89c: str w9, [sp, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_8a0:
	/* 0x8a0: str w9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_8a4:
	/* 0x8a4: ldrh w25, [x0, #38] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 38ULL);
arm64_l_8a8:
	/* 0x8a8: adrp x0, 0 <cilium_lb4_backends_v3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_lb4_backends_v3_19));
arm64_l_8ac:
	/* 0x8ac: orr w29, w8, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X29, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_8b0:
	/* 0x8b0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_8b4:
	/* 0x8b4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_8b8:
	/* 0x8b8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x8bcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_8bc:
	/* 0x8bc: cbz x0, 8e0 <tail_handle_ipv4+0x8e0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x8bc, 0x8e0, arm64_l_8e0);
arm64_l_8c0:
	/* 0x8c0: ldrb w8, [x0, #7] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_8c4:
	/* 0x8c4: mov x23, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_8c8:
	/* 0x8c8: cbz w8, ec0 <tail_handle_ipv4+0xec0> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x8c8, 0xec0, arm64_l_ec0);
arm64_l_8cc:
	/* 0x8cc: cbnz w22, 8ec <tail_handle_ipv4+0x8ec> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x8cc, 0x8ec, arm64_l_8ec);
arm64_l_8d0:
	/* 0x8d0: b ec0 <tail_handle_ipv4+0xec0> */
	ARM64_SIM_A64_JMP(0x8d0, 0xec0, arm64_l_ec0);
arm64_l_8d4:
	/* 0x8d4: mov w22, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_8d8:
	/* 0x8d8: mov w8, #0xffffff5d */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967133ULL);
arm64_l_8dc:
	/* 0x8dc: b 11a0 <tail_handle_ipv4+0x11a0> */
	ARM64_SIM_A64_JMP(0x8dc, 0x11a0, arm64_l_11a0);
arm64_l_8e0:
	/* 0x8e0: adrp x8, 0 <__config_debug_lb> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_debug_lb_0));
arm64_l_8e4:
	/* 0x8e4: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_8e8:
	/* 0x8e8: ldrb wzr, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_8ec:
	/* 0x8ec: ldrh w8, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_8f0:
	/* 0x8f0: cbz w8, d58 <tail_handle_ipv4+0xd58> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x8f0, 0xd58, arm64_l_d58);
arm64_l_8f4:
	/* 0x8f4: mov w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 7ULL);
arm64_l_8f8:
	/* 0x8f8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 7ULL: ARM64_SIM_A64_LINK(0x8fcULL); ARM64_SIM_BPF_CALL_bpf_get_prandom_u32(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_8fc:
	/* 0x8fc: ldrh w8, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_900:
	/* 0x900: adrp x22, 0 <__config_debug_lb> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_debug_lb_0));
arm64_l_904:
	/* 0x904: add x1, sp, #0x28 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_908:
	/* 0x908: udiv w9, w0, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_UDIV, ARM64_X9, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_90c:
	/* 0x90c: msub w8, w9, w8, w0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MSUB, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_X0, ARM64_WIDTH_32, 0, 0);
arm64_l_910:
	/* 0x910: adrp x0, 0 <cilium_lb4_services_v2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_lb4_services_v2_20));
arm64_l_914:
	/* 0x914: add w8, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_918:
	/* 0x918: strh w8, [sp, #46] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 46ULL);
arm64_l_91c:
	/* 0x91c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_920:
	/* 0x920: ldr x22, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_924:
	/* 0x924: ldrb wzr, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_XZR, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_928:
	/* 0x928: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_92c:
	/* 0x92c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x930ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_930:
	/* 0x930: cbz x0, 93c <tail_handle_ipv4+0x93c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x930, 0x93c, arm64_l_93c);
arm64_l_934:
	/* 0x934: ldr w20, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_938:
	/* 0x938: b 944 <tail_handle_ipv4+0x944> */
	ARM64_SIM_A64_JMP(0x938, 0x944, arm64_l_944);
arm64_l_93c:
	/* 0x93c: ldrb wzr, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_XZR, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_940:
	/* 0x940: mov w20, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_944:
	/* 0x944: str w20, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_948:
	/* 0x948: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_94c:
	/* 0x94c: adrp x0, 0 <cilium_lb4_backends_v3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_lb4_backends_v3_19));
arm64_l_950:
	/* 0x950: add x1, sp, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_954:
	/* 0x954: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_958:
	/* 0x958: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x95cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_95c:
	/* 0x95c: cbz x0, d4c <tail_handle_ipv4+0xd4c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x95c, 0xd4c, arm64_l_d4c);
arm64_l_960:
	/* 0x960: ldrh w25, [x21, #6] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_964:
	/* 0x964: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_968:
	/* 0x968: mov x23, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_96c:
	/* 0x96c: add x1, sp, #0x38 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_970:
	/* 0x970: ldr x0, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_974:
	/* 0x974: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x978ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_978:
	/* 0x978: str w20, [sp, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_97c:
	/* 0x97c: cbz x0, ec0 <tail_handle_ipv4+0xec0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x97c, 0xec0, arm64_l_ec0);
arm64_l_980:
	/* 0x980: mov w8, w20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_984:
	/* 0x984: strh w25, [x0, #38] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 38ULL);
arm64_l_988:
	/* 0x988: str x8, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_98c:
	/* 0x98c: b ec0 <tail_handle_ipv4+0xec0> */
	ARM64_SIM_A64_JMP(0x98c, 0xec0, arm64_l_ec0);
arm64_l_990:
	/* 0x990: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_994:
	/* 0x994: adrp x0, 0 <cilium_ipv4_frag_datagrams> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_ipv4_frag_datagrams_17));
arm64_l_998:
	/* 0x998: add x1, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_99c:
	/* 0x99c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_9a0:
	/* 0x9a0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x9a4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_9a4:
	/* 0x9a4: cbz x0, 9c0 <tail_handle_ipv4+0x9c0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x9a4, 0x9c0, arm64_l_9c0);
arm64_l_9a8:
	/* 0x9a8: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_9ac:
	/* 0x9ac: str w8, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_9b0:
	/* 0x9b0: b 18c <tail_handle_ipv4+0x18c> */
	ARM64_SIM_A64_JMP(0x9b0, 0x18c, arm64_l_18c);
arm64_l_9b4:
	/* 0x9b4: mov w22, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_9b8:
	/* 0x9b8: mov w8, #0xffffff63 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967139ULL);
arm64_l_9bc:
	/* 0x9bc: b 11a0 <tail_handle_ipv4+0x11a0> */
	ARM64_SIM_A64_JMP(0x9bc, 0x11a0, arm64_l_11a0);
arm64_l_9c0:
	/* 0x9c0: mov w8, #0xffffff51 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967121ULL);
arm64_l_9c4:
	/* 0x9c4: b 119c <tail_handle_ipv4+0x119c> */
	ARM64_SIM_A64_JMP(0x9c4, 0x119c, arm64_l_119c);
arm64_l_9c8:
	/* 0x9c8: mov w20, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_9cc:
	/* 0x9cc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_9d0:
	/* 0x9d0: add x1, sp, #0x38 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_9d4:
	/* 0x9d4: ldr x0, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_9d8:
	/* 0x9d8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x9dcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_9dc:
	/* 0x9dc: cbnz x0, 45c <tail_handle_ipv4+0x45c> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x9dc, 0x45c, arm64_l_45c);
arm64_l_9e0:
	/* 0x9e0: b b38 <tail_handle_ipv4+0xb38> */
	ARM64_SIM_A64_JMP(0x9e0, 0xb38, arm64_l_b38);
arm64_l_9e4:
	/* 0x9e4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_9e8:
	/* 0x9e8: adrp x0, 0 <cilium_metrics> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_metrics_22));
arm64_l_9ec:
	/* 0x9ec: add x1, sp, #0x98 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_9f0:
	/* 0x9f0: stp x8, x20, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_9f4:
	/* 0x9f4: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_9f8:
	/* 0x9f8: add x2, sp, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_9fc:
	/* 0x9fc: mov w3, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_a00:
	/* 0xa00: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a04:
	/* 0xa04: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0xa08ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_a08:
	/* 0xa08: b 18c <tail_handle_ipv4+0x18c> */
	ARM64_SIM_A64_JMP(0xa08, 0x18c, arm64_l_18c);
arm64_l_a0c:
	/* 0xa0c: mov w9, #0xffec */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 65516ULL);
arm64_l_a10:
	/* 0xa10: str w25, [sp] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a14:
	/* 0xa14: strh wzr, [x0, #42] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 42ULL);
arm64_l_a18:
	/* 0xa18: mov x20, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a1c:
	/* 0xa1c: and w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_a20:
	/* 0xa20: adrp x9, 0 <__config_enable_jiffies> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_enable_jiffies_3));
arm64_l_a24:
	/* 0xa24: strh w8, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_a28:
	/* 0xa28: ldr x9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a2c:
	/* 0xa2c: mov x25, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a30:
	/* 0xa30: ldrb w9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a34:
	/* 0xa34: cbz w9, a54 <tail_handle_ipv4+0xa54> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0xa34, 0xa54, arm64_l_a54);
arm64_l_a38:
	/* 0xa38: adrp x9, 0 <__config_kernel_hz> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_kernel_hz_7));
arm64_l_a3c:
	/* 0xa3c: ldr x9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a40:
	/* 0xa40: ldr w9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a44:
	/* 0xa44: lsl w10, w9, #6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 6ULL);
arm64_l_a48:
	/* 0xa48: sub w9, w10, w9, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_LSL, 2), 0);
arm64_l_a4c:
	/* 0xa4c: lsr w22, w9, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_a50:
	/* 0xa50: b a58 <tail_handle_ipv4+0xa58> */
	ARM64_SIM_A64_JMP(0xa50, 0xa58, arm64_l_a58);
arm64_l_a54:
	/* 0xa54: mov w22, #0x3c */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 60ULL);
arm64_l_a58:
	/* 0xa58: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_a5c:
	/* 0xa5c: b.ne a98 <tail_handle_ipv4+0xa98> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xa5c, 0xa98, arm64_l_a98);
arm64_l_a60:
	/* 0xa60: mov w9, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_a64:
	/* 0xa64: mov w10, #0x3c */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 60ULL);
arm64_l_a68:
	/* 0xa68: bics w9, w9, w23, lsr #5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_BICS_REG, ARM64_X9, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_LSR, 5), 0);
arm64_l_a6c:
	/* 0xa6c: orr w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_a70:
	/* 0xa70: mov w9, #0x5460 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 21600ULL);
arm64_l_a74:
	/* 0xa74: strh w8, [x20, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_a78:
	/* 0xa78: csel w22, w10, w9, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X22, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_a7c:
	/* 0xa7c: ldrb w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a80:
	/* 0xa80: cbz w8, a98 <tail_handle_ipv4+0xa98> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xa80, 0xa98, arm64_l_a98);
arm64_l_a84:
	/* 0xa84: adrp x8, 0 <__config_kernel_hz> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_kernel_hz_7));
arm64_l_a88:
	/* 0xa88: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a8c:
	/* 0xa8c: ldr w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a90:
	/* 0xa90: mul w8, w8, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_a94:
	/* 0xa94: lsr w22, w8, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_a98:
	/* 0xa98: ldrb w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a9c:
	/* 0xa9c: cbz w8, ab0 <tail_handle_ipv4+0xab0> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xa9c, 0xab0, arm64_l_ab0);
arm64_l_aa0:
	/* 0xaa0: mov w8, #0x76 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 118ULL);
arm64_l_aa4:
	/* 0xaa4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 118ULL: ARM64_SIM_A64_LINK(0xaa8ULL); ARM64_SIM_BPF_CALL_bpf_jiffies64(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_aa8:
	/* 0xaa8: lsr x8, x0, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_aac:
	/* 0xaac: b ad4 <tail_handle_ipv4+0xad4> */
	ARM64_SIM_A64_JMP(0xaac, 0xad4, arm64_l_ad4);
arm64_l_ab0:
	/* 0xab0: mov w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_ab4:
	/* 0xab4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 5ULL: ARM64_SIM_A64_LINK(0xab8ULL); ARM64_SIM_BPF_CALL_bpf_ktime_get_ns(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_ab8:
	/* 0xab8: mov x9, #0x5a53 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 23123ULL);
arm64_l_abc:
	/* 0xabc: lsr x8, x0, #9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 9ULL);
arm64_l_ac0:
	/* 0xac0: movk x9, #0xa09b, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 41115ULL);
arm64_l_ac4:
	/* 0xac4: movk x9, #0xb82f, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 47151ULL);
arm64_l_ac8:
	/* 0xac8: movk x9, #0x44, lsl #48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 68ULL);
arm64_l_acc:
	/* 0xacc: umulh x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_UMULH, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ad0:
	/* 0xad0: lsr x8, x8, #11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 11ULL);
arm64_l_ad4:
	/* 0xad4: add w9, w22, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_ad8:
	/* 0xad8: mov x10, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_adc:
	/* 0xadc: lsr w11, w23, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_ae0:
	/* 0xae0: str w9, [x20, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_ae4:
	/* 0xae4: and w11, w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_ae8:
	/* 0xae8: ldrb w9, [x20, #42] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 42ULL);
arm64_l_aec:
	/* 0xaec: ldr w10, [x20, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_af0:
	/* 0xaf0: ldrb w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_af4:
	/* 0xaf4: cbz w12, b10 <tail_handle_ipv4+0xb10> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0xaf4, 0xb10, arm64_l_b10);
arm64_l_af8:
	/* 0xaf8: adrp x12, 0 <__config_kernel_hz> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_kernel_hz_7));
arm64_l_afc:
	/* 0xafc: ldr x12, [x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b00:
	/* 0xb00: ldr w12, [x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b04:
	/* 0xb04: add w12, w12, w12, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_b08:
	/* 0xb08: lsr w12, w12, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_b0c:
	/* 0xb0c: b b14 <tail_handle_ipv4+0xb14> */
	ARM64_SIM_A64_JMP(0xb0c, 0xb14, arm64_l_b14);
arm64_l_b10:
	/* 0xb10: mov w12, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_b14:
	/* 0xb14: ldr w25, [sp] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b18:
	/* 0xb18: add w10, w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_b1c:
	/* 0xb1c: orr w11, w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_b20:
	/* 0xb20: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_b24:
	/* 0xb24: b.cc b30 <tail_handle_ipv4+0xb30> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xb24, 0xb30, arm64_l_b30);
arm64_l_b28:
	/* 0xb28: cmp w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_b2c:
	/* 0xb2c: b.eq b44 <tail_handle_ipv4+0xb44> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xb2c, 0xb44, arm64_l_b44);
arm64_l_b30:
	/* 0xb30: strb w11, [x20, #42] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 42ULL);
arm64_l_b34:
	/* 0xb34: str w8, [x20, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_b38:
	/* 0xb38: adrp x8, 0 <__config_trace_payload_len> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_trace_payload_len_12));
arm64_l_b3c:
	/* 0xb3c: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b40:
	/* 0xb40: ldr wzr, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b44:
	/* 0xb44: ldrh w8, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_b48:
	/* 0xb48: cbz w8, d58 <tail_handle_ipv4+0xd58> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xb48, 0xd58, arm64_l_d58);
arm64_l_b4c:
	/* 0xb4c: ldrb w8, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_b50:
	/* 0xb50: tbz w8, #4, c88 <tail_handle_ipv4+0xc88> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 4, 0xb50, 0xc88, arm64_l_c88);
arm64_l_b54:
	/* 0xb54: ldr x8, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_b58:
	/* 0xb58: adrp x0, 0 <cilium_lb4_affinity> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_lb4_affinity_18));
arm64_l_b5c:
	/* 0xb5c: add x1, sp, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_b60:
	/* 0xb60: str x8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_b64:
	/* 0xb64: ldrh w8, [x21, #6] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_b68:
	/* 0xb68: strh wzr, [sp, #82] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 82ULL);
arm64_l_b6c:
	/* 0xb6c: str wzr, [sp, #84] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 84ULL);
arm64_l_b70:
	/* 0xb70: strh w8, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_b74:
	/* 0xb74: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_b78:
	/* 0xb78: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b7c:
	/* 0xb7c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xb80ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_b80:
	/* 0xb80: cbz x0, c88 <tail_handle_ipv4+0xc88> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xb80, 0xc88, arm64_l_c88);
arm64_l_b84:
	/* 0xb84: adrp x20, 0 <__config_enable_jiffies> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_enable_jiffies_3));
arm64_l_b88:
	/* 0xb88: mov x23, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b8c:
	/* 0xb8c: ldr x20, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b90:
	/* 0xb90: ldrb w8, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b94:
	/* 0xb94: cbz w8, ba8 <tail_handle_ipv4+0xba8> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xb94, 0xba8, arm64_l_ba8);
arm64_l_b98:
	/* 0xb98: mov w8, #0x76 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 118ULL);
arm64_l_b9c:
	/* 0xb9c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 118ULL: ARM64_SIM_A64_LINK(0xba0ULL); ARM64_SIM_BPF_CALL_bpf_jiffies64(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_ba0:
	/* 0xba0: lsr x8, x0, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_ba4:
	/* 0xba4: b bcc <tail_handle_ipv4+0xbcc> */
	ARM64_SIM_A64_JMP(0xba4, 0xbcc, arm64_l_bcc);
arm64_l_ba8:
	/* 0xba8: mov w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_bac:
	/* 0xbac: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 5ULL: ARM64_SIM_A64_LINK(0xbb0ULL); ARM64_SIM_BPF_CALL_bpf_ktime_get_ns(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_bb0:
	/* 0xbb0: mov x9, #0x5a53 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 23123ULL);
arm64_l_bb4:
	/* 0xbb4: lsr x8, x0, #9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 9ULL);
arm64_l_bb8:
	/* 0xbb8: movk x9, #0xa09b, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 41115ULL);
arm64_l_bbc:
	/* 0xbbc: movk x9, #0xb82f, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 47151ULL);
arm64_l_bc0:
	/* 0xbc0: movk x9, #0x44, lsl #48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 68ULL);
arm64_l_bc4:
	/* 0xbc4: umulh x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_UMULH, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_bc8:
	/* 0xbc8: lsr x8, x8, #11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 11ULL);
arm64_l_bcc:
	/* 0xbcc: ldr w9, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_bd0:
	/* 0xbd0: str w9, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_bd4:
	/* 0xbd4: ldrh w9, [x21, #6] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_bd8:
	/* 0xbd8: strh wzr, [sp, #134] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 134ULL);
arm64_l_bdc:
	/* 0xbdc: strh w9, [sp, #132] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 132ULL);
arm64_l_be0:
	/* 0xbe0: ldr x9, [x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_be4:
	/* 0xbe4: ldr w10, [x21] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_be8:
	/* 0xbe8: ldrb w11, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_bec:
	/* 0xbec: and w10, w10, #0xffffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16777215ULL);
arm64_l_bf0:
	/* 0xbf0: cbz w11, c08 <tail_handle_ipv4+0xc08> */
	ARM64_SIM_A64_CBZ(ARM64_X11, 0xbf0, 0xc08, arm64_l_c08);
arm64_l_bf4:
	/* 0xbf4: adrp x11, 0 <__config_kernel_hz> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_kernel_hz_7));
arm64_l_bf8:
	/* 0xbf8: ldr x11, [x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_bfc:
	/* 0xbfc: ldr w11, [x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c00:
	/* 0xc00: mul w10, w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X10, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_c04:
	/* 0xc04: lsr w10, w10, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_c08:
	/* 0xc08: add x9, x9, w10, uxtw */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTW, 0), 0);
arm64_l_c0c:
	/* 0xc0c: and x20, x8, #0xffffffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967295ULL);
arm64_l_c10:
	/* 0xc10: cmp x9, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_c14:
	/* 0xc14: b.ls c6c <tail_handle_ipv4+0xc6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0xc14, 0xc6c, arm64_l_c6c);
arm64_l_c18:
	/* 0xc18: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_c1c:
	/* 0xc1c: adrp x0, 0 <cilium_lb_affinity_match> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_lb_affinity_match_21));
arm64_l_c20:
	/* 0xc20: add x1, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_c24:
	/* 0xc24: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c28:
	/* 0xc28: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xc2cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_c2c:
	/* 0xc2c: cbz x0, c74 <tail_handle_ipv4+0xc74> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xc2c, 0xc74, arm64_l_c74);
arm64_l_c30:
	/* 0xc30: str x20, [x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c34:
	/* 0xc34: ldr w22, [x23, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_c38:
	/* 0xc38: cbz w22, c88 <tail_handle_ipv4+0xc88> */
	ARM64_SIM_A64_CBZ(ARM64_X22, 0xc38, 0xc88, arm64_l_c88);
arm64_l_c3c:
	/* 0xc3c: str w22, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_c40:
	/* 0xc40: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_c44:
	/* 0xc44: adrp x0, 0 <cilium_lb4_backends_v3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_lb4_backends_v3_19));
arm64_l_c48:
	/* 0xc48: add x1, sp, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_c4c:
	/* 0xc4c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c50:
	/* 0xc50: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xc54ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_c54:
	/* 0xc54: mov x23, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c58:
	/* 0xc58: cbnz x0, cfc <tail_handle_ipv4+0xcfc> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0xc58, 0xcfc, arm64_l_cfc);
arm64_l_c5c:
	/* 0xc5c: adrp x8, 0 <__config_debug_lb> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_debug_lb_0));
arm64_l_c60:
	/* 0xc60: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c64:
	/* 0xc64: ldrb wzr, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c68:
	/* 0xc68: b c88 <tail_handle_ipv4+0xc88> */
	ARM64_SIM_A64_JMP(0xc68, 0xc88, arm64_l_c88);
arm64_l_c6c:
	/* 0xc6c: mov w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_c70:
	/* 0xc70: b c78 <tail_handle_ipv4+0xc78> */
	ARM64_SIM_A64_JMP(0xc70, 0xc78, arm64_l_c78);
arm64_l_c74:
	/* 0xc74: mov w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_c78:
	/* 0xc78: adrp x0, 0 <cilium_lb4_affinity> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_lb4_affinity_18));
arm64_l_c7c:
	/* 0xc7c: add x1, sp, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_c80:
	/* 0xc80: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c84:
	/* 0xc84: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 3ULL: ARM64_SIM_A64_LINK(0xc88ULL); ARM64_SIM_BPF_CALL_bpf_map_delete_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_c88:
	/* 0xc88: mov w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 7ULL);
arm64_l_c8c:
	/* 0xc8c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 7ULL: ARM64_SIM_A64_LINK(0xc90ULL); ARM64_SIM_BPF_CALL_bpf_get_prandom_u32(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_c90:
	/* 0xc90: ldrh w8, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_c94:
	/* 0xc94: adrp x22, 0 <__config_debug_lb> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_debug_lb_0));
arm64_l_c98:
	/* 0xc98: add x1, sp, #0x28 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_c9c:
	/* 0xc9c: udiv w9, w0, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_UDIV, ARM64_X9, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_ca0:
	/* 0xca0: msub w8, w9, w8, w0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MSUB, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_X0, ARM64_WIDTH_32, 0, 0);
arm64_l_ca4:
	/* 0xca4: adrp x0, 0 <cilium_lb4_services_v2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_lb4_services_v2_20));
arm64_l_ca8:
	/* 0xca8: add w8, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_cac:
	/* 0xcac: strh w8, [sp, #46] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 46ULL);
arm64_l_cb0:
	/* 0xcb0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_cb4:
	/* 0xcb4: ldr x22, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cb8:
	/* 0xcb8: ldrb wzr, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_XZR, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cbc:
	/* 0xcbc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cc0:
	/* 0xcc0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xcc4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_cc4:
	/* 0xcc4: cbz x0, cd0 <tail_handle_ipv4+0xcd0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xcc4, 0xcd0, arm64_l_cd0);
arm64_l_cc8:
	/* 0xcc8: ldr w22, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ccc:
	/* 0xccc: b cdc <tail_handle_ipv4+0xcdc> */
	ARM64_SIM_A64_JMP(0xccc, 0xcdc, arm64_l_cdc);
arm64_l_cd0:
	/* 0xcd0: ldrb wzr, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_XZR, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cd4:
	/* 0xcd4: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_cd8:
	/* 0xcd8: mov w22, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_cdc:
	/* 0xcdc: str w22, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_ce0:
	/* 0xce0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ce4:
	/* 0xce4: adrp x0, 0 <cilium_lb4_backends_v3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_lb4_backends_v3_19));
arm64_l_ce8:
	/* 0xce8: add x1, sp, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_cec:
	/* 0xcec: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cf0:
	/* 0xcf0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xcf4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_cf4:
	/* 0xcf4: mov x23, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_cf8:
	/* 0xcf8: cbz x0, d4c <tail_handle_ipv4+0xd4c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xcf8, 0xd4c, arm64_l_d4c);
arm64_l_cfc:
	/* 0xcfc: mov w8, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_d00:
	/* 0xd00: stp xzr, xzr, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_d04:
	/* 0xd04: mov w20, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_d08:
	/* 0xd08: str w22, [sp, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_d0c:
	/* 0xd0c: adrp x22, 0 <__config_enable_jiffies> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_enable_jiffies_3));
arm64_l_d10:
	/* 0xd10: stp xzr, xzr, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_d14:
	/* 0xd14: strh w25, [sp, #110] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 110ULL);
arm64_l_d18:
	/* 0xd18: str xzr, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_d1c:
	/* 0xd1c: ldrb w29, [sp, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_d20:
	/* 0xd20: stp x8, xzr, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_d24:
	/* 0xd24: ldr x22, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d28:
	/* 0xd28: ldrb w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d2c:
	/* 0xd2c: cbz w8, d8c <tail_handle_ipv4+0xd8c> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xd2c, 0xd8c, arm64_l_d8c);
arm64_l_d30:
	/* 0xd30: adrp x8, 0 <__config_kernel_hz> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_kernel_hz_7));
arm64_l_d34:
	/* 0xd34: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d38:
	/* 0xd38: ldr w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d3c:
	/* 0xd3c: lsl w9, w8, #6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 6ULL);
arm64_l_d40:
	/* 0xd40: sub w8, w9, w8, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_LSL, 2), 0);
arm64_l_d44:
	/* 0xd44: lsr w25, w8, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_d48:
	/* 0xd48: b d90 <tail_handle_ipv4+0xd90> */
	ARM64_SIM_A64_JMP(0xd48, 0xd90, arm64_l_d90);
arm64_l_d4c:
	/* 0xd4c: adrp x8, 0 <__config_debug_lb> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_debug_lb_0));
arm64_l_d50:
	/* 0xd50: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d54:
	/* 0xd54: ldrb wzr, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d58:
	/* 0xd58: ldr w8, [sp, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_d5c:
	/* 0xd5c: strb w8, [sp, #69] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 69ULL);
arm64_l_d60:
	/* 0xd60: adrp x8, 0 <__config_enable_no_service_endpoints_routable> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_enable_no_service_endpoints_routable_5));
arm64_l_d64:
	/* 0xd64: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d68:
	/* 0xd68: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d6c:
	/* 0xd6c: cbz w8, dbc <tail_handle_ipv4+0xdbc> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xd6c, 0xdbc, arm64_l_dbc);
arm64_l_d70:
	/* 0xd70: mov w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_d74:
	/* 0xd74: adrp x1, 0 <cilium_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_calls_13));
arm64_l_d78:
	/* 0xd78: mov w22, #0x2d */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_d7c:
	/* 0xd7c: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d80:
	/* 0xd80: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d84:
	/* 0xd84: mov w2, #0x2d */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_d88:
	/* 0xd88: b 310 <tail_handle_ipv4+0x310> */
	ARM64_SIM_A64_JMP(0xd88, 0x310, arm64_l_310);
arm64_l_d8c:
	/* 0xd8c: mov w25, #0x3c */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 60ULL);
arm64_l_d90:
	/* 0xd90: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_d94:
	/* 0xd94: b.ne ddc <tail_handle_ipv4+0xddc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xd94, 0xddc, arm64_l_ddc);
arm64_l_d98:
	/* 0xd98: ldrb w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d9c:
	/* 0xd9c: cbz w8, dd8 <tail_handle_ipv4+0xdd8> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xd9c, 0xdd8, arm64_l_dd8);
arm64_l_da0:
	/* 0xda0: adrp x8, 0 <__config_kernel_hz> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_kernel_hz_7));
arm64_l_da4:
	/* 0xda4: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_da8:
	/* 0xda8: ldr w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_dac:
	/* 0xdac: lsl w9, w8, #6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 6ULL);
arm64_l_db0:
	/* 0xdb0: sub w8, w9, w8, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_LSL, 2), 0);
arm64_l_db4:
	/* 0xdb4: lsr w25, w8, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_db8:
	/* 0xdb8: b ddc <tail_handle_ipv4+0xddc> */
	ARM64_SIM_A64_JMP(0xdb8, 0xddc, arm64_l_ddc);
arm64_l_dbc:
	/* 0xdbc: ldrb w8, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_dc0:
	/* 0xdc0: mov w9, #0x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 35ULL);
arm64_l_dc4:
	/* 0xdc4: tst w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_dc8:
	/* 0xdc8: b.eq 126c <tail_handle_ipv4+0x126c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xdc8, 0x126c, arm64_l_126c);
arm64_l_dcc:
	/* 0xdcc: tbnz w8, #2, 1274 <tail_handle_ipv4+0x1274> */
	ARM64_SIM_A64_TBNZ(ARM64_X8, 2, 0xdcc, 0x1274, arm64_l_1274);
arm64_l_dd0:
	/* 0xdd0: mov w0, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_dd4:
	/* 0xdd4: b 1250 <tail_handle_ipv4+0x1250> */
	ARM64_SIM_A64_JMP(0xdd4, 0x1250, arm64_l_1250);
arm64_l_dd8:
	/* 0xdd8: mov w25, #0x3c */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 60ULL);
arm64_l_ddc:
	/* 0xddc: ldrb w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_de0:
	/* 0xde0: cbz w8, df4 <tail_handle_ipv4+0xdf4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xde0, 0xdf4, arm64_l_df4);
arm64_l_de4:
	/* 0xde4: mov w8, #0x76 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 118ULL);
arm64_l_de8:
	/* 0xde8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 118ULL: ARM64_SIM_A64_LINK(0xdecULL); ARM64_SIM_BPF_CALL_bpf_jiffies64(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_dec:
	/* 0xdec: lsr x8, x0, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_df0:
	/* 0xdf0: b e18 <tail_handle_ipv4+0xe18> */
	ARM64_SIM_A64_JMP(0xdf0, 0xe18, arm64_l_e18);
arm64_l_df4:
	/* 0xdf4: mov w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_df8:
	/* 0xdf8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 5ULL: ARM64_SIM_A64_LINK(0xdfcULL); ARM64_SIM_BPF_CALL_bpf_ktime_get_ns(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_dfc:
	/* 0xdfc: mov x9, #0x5a53 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 23123ULL);
arm64_l_e00:
	/* 0xe00: lsr x8, x0, #9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 9ULL);
arm64_l_e04:
	/* 0xe04: movk x9, #0xa09b, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 41115ULL);
arm64_l_e08:
	/* 0xe08: movk x9, #0xb82f, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 47151ULL);
arm64_l_e0c:
	/* 0xe0c: movk x9, #0x44, lsl #48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 68ULL);
arm64_l_e10:
	/* 0xe10: umulh x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_UMULH, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e14:
	/* 0xe14: lsr x8, x8, #11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 11ULL);
arm64_l_e18:
	/* 0xe18: add w9, w25, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_e1c:
	/* 0xe1c: cmp w29, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_e20:
	/* 0xe20: str w9, [sp, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_e24:
	/* 0xe24: cset w10, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_e28:
	/* 0xe28: ldrb w9, [sp, #114] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 114ULL);
arm64_l_e2c:
	/* 0xe2c: ldr w11, [sp, #120] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_e30:
	/* 0xe30: ldrb w12, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e34:
	/* 0xe34: cbz w12, e50 <tail_handle_ipv4+0xe50> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0xe34, 0xe50, arm64_l_e50);
arm64_l_e38:
	/* 0xe38: adrp x12, 0 <__config_kernel_hz> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_kernel_hz_7));
arm64_l_e3c:
	/* 0xe3c: ldr x12, [x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e40:
	/* 0xe40: ldr w12, [x12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e44:
	/* 0xe44: add w12, w12, w12, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_e48:
	/* 0xe48: lsr w12, w12, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X12, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_e4c:
	/* 0xe4c: b e54 <tail_handle_ipv4+0xe54> */
	ARM64_SIM_A64_JMP(0xe4c, 0xe54, arm64_l_e54);
arm64_l_e50:
	/* 0xe50: mov w12, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_e54:
	/* 0xe54: add w11, w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_e58:
	/* 0xe58: mov w25, w20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_e5c:
	/* 0xe5c: orr w10, w9, w10, lsl #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_LSL, 1), 0);
arm64_l_e60:
	/* 0xe60: cmp w11, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e64:
	/* 0xe64: b.cc e70 <tail_handle_ipv4+0xe70> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xe64, 0xe70, arm64_l_e70);
arm64_l_e68:
	/* 0xe68: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e6c:
	/* 0xe6c: b.eq e84 <tail_handle_ipv4+0xe84> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe6c, 0xe84, arm64_l_e84);
arm64_l_e70:
	/* 0xe70: strb w10, [sp, #114] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 114ULL);
arm64_l_e74:
	/* 0xe74: str w8, [sp, #120] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_e78:
	/* 0xe78: adrp x8, 0 <__config_trace_payload_len> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_trace_payload_len_12));
arm64_l_e7c:
	/* 0xe7c: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e80:
	/* 0xe80: ldr wzr, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e84:
	/* 0xe84: adrp x8, 0 <__config_enable_conntrack_accounting> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_enable_conntrack_accounting_1));
arm64_l_e88:
	/* 0xe88: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e8c:
	/* 0xe8c: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e90:
	/* 0xe90: cbz w8, ea0 <tail_handle_ipv4+0xea0> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xe90, 0xea0, arm64_l_ea0);
arm64_l_e94:
	/* 0xe94: ldr w9, [x19, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_e98:
	/* 0xe98: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_e9c:
	/* 0xe9c: stp x8, x9, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_ea0:
	/* 0xea0: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_ea4:
	/* 0xea4: add x1, sp, #0x38 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_ea8:
	/* 0xea8: add x2, sp, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_eac:
	/* 0xeac: ldr x0, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_eb0:
	/* 0xeb0: mov w3, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_eb4:
	/* 0xeb4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0xeb8ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_eb8:
	/* 0xeb8: mov w29, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_ebc:
	/* 0xebc: tbnz w0, #31, 1280 <tail_handle_ipv4+0x1280> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0xebc, 0x1280, arm64_l_1280);
arm64_l_ec0:
	/* 0xec0: ldr w8, [sp, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_ec4:
	/* 0xec4: strb w8, [sp, #69] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 69ULL);
arm64_l_ec8:
	/* 0xec8: ldrb w8, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_ecc:
	/* 0xecc: tbz w8, #4, f58 <tail_handle_ipv4+0xf58> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 4, 0xecc, 0xf58, arm64_l_f58);
arm64_l_ed0:
	/* 0xed0: adrp x8, 0 <__config_enable_jiffies> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_enable_jiffies_3));
arm64_l_ed4:
	/* 0xed4: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ed8:
	/* 0xed8: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_edc:
	/* 0xedc: cbz w8, ef0 <tail_handle_ipv4+0xef0> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xedc, 0xef0, arm64_l_ef0);
arm64_l_ee0:
	/* 0xee0: mov w8, #0x76 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 118ULL);
arm64_l_ee4:
	/* 0xee4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 118ULL: ARM64_SIM_A64_LINK(0xee8ULL); ARM64_SIM_BPF_CALL_bpf_jiffies64(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_ee8:
	/* 0xee8: lsr x8, x0, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_eec:
	/* 0xeec: b f14 <tail_handle_ipv4+0xf14> */
	ARM64_SIM_A64_JMP(0xeec, 0xf14, arm64_l_f14);
arm64_l_ef0:
	/* 0xef0: mov w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_ef4:
	/* 0xef4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 5ULL: ARM64_SIM_A64_LINK(0xef8ULL); ARM64_SIM_BPF_CALL_bpf_ktime_get_ns(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_ef8:
	/* 0xef8: mov x9, #0x5a53 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 23123ULL);
arm64_l_efc:
	/* 0xefc: lsr x8, x0, #9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 9ULL);
arm64_l_f00:
	/* 0xf00: movk x9, #0xa09b, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 41115ULL);
arm64_l_f04:
	/* 0xf04: movk x9, #0xb82f, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 47151ULL);
arm64_l_f08:
	/* 0xf08: movk x9, #0x44, lsl #48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 68ULL);
arm64_l_f0c:
	/* 0xf0c: umulh x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_UMULH, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f10:
	/* 0xf10: lsr x8, x8, #11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 11ULL);
arm64_l_f14:
	/* 0xf14: ldr x9, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_f18:
	/* 0xf18: ldr w10, [sp, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_f1c:
	/* 0xf1c: and x8, x8, #0xffffffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967295ULL);
arm64_l_f20:
	/* 0xf20: adrp x0, 0 <cilium_lb4_affinity> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_lb4_affinity_18));
arm64_l_f24:
	/* 0xf24: add x1, sp, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_f28:
	/* 0xf28: add x2, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_f2c:
	/* 0xf2c: str x9, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_f30:
	/* 0xf30: mov w3, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_f34:
	/* 0xf34: ldrh w9, [x21, #6] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_f38:
	/* 0xf38: strh wzr, [sp, #82] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 82ULL);
arm64_l_f3c:
	/* 0xf3c: str wzr, [sp, #84] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 84ULL);
arm64_l_f40:
	/* 0xf40: str x8, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_f44:
	/* 0xf44: stp w10, wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_f48:
	/* 0xf48: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_f4c:
	/* 0xf4c: strh w9, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_f50:
	/* 0xf50: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f54:
	/* 0xf54: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0xf58ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_f58:
	/* 0xf58: ldr w20, [sp, #60] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 60ULL);
arm64_l_f5c:
	/* 0xf5c: ldr w8, [x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f60:
	/* 0xf60: cmp w20, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f64:
	/* 0xf64: b.ne fa4 <tail_handle_ipv4+0xfa4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xf64, 0xfa4, arm64_l_fa4);
arm64_l_f68:
	/* 0xf68: adrp x8, 0 <__config_enable_lrp> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_enable_lrp_4));
arm64_l_f6c:
	/* 0xf6c: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f70:
	/* 0xf70: ldrb w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f74:
	/* 0xf74: cbz w8, f90 <tail_handle_ipv4+0xf90> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xf74, 0xf90, arm64_l_f90);
arm64_l_f78:
	/* 0xf78: adrp x8, 0 <__config_endpoint_netns_cookie> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_endpoint_netns_cookie_6));
arm64_l_f7c:
	/* 0xf7c: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f80:
	/* 0xf80: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f84:
	/* 0xf84: cbz x8, f90 <tail_handle_ipv4+0xf90> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xf84, 0xf90, arm64_l_f90);
arm64_l_f88:
	/* 0xf88: ldrb w9, [x21, #9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 9ULL);
arm64_l_f8c:
	/* 0xf8c: tbnz w9, #0, 128c <tail_handle_ipv4+0x128c> */
	ARM64_SIM_A64_TBNZ(ARM64_X9, 0, 0xf8c, 0x128c, arm64_l_128c);
arm64_l_f90:
	/* 0xf90: ldrh w8, [sp, #66] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 66ULL);
arm64_l_f94:
	/* 0xf94: ldr w22, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_f98:
	/* 0xf98: mov w29, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f9c:
	/* 0xf9c: str w8, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_fa0:
	/* 0xfa0: b fc4 <tail_handle_ipv4+0xfc4> */
	ARM64_SIM_A64_JMP(0xfa0, 0xfc4, arm64_l_fc4);
arm64_l_fa4:
	/* 0xfa4: ldr w22, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_fa8:
	/* 0xfa8: ldrh w8, [sp, #66] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 66ULL);
arm64_l_fac:
	/* 0xfac: str wzr, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_fb0:
	/* 0xfb0: str w8, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_fb4:
	/* 0xfb4: tbnz w29, #0, fc4 <tail_handle_ipv4+0xfc4> */
	ARM64_SIM_A64_TBNZ(ARM64_X29, 0, 0xfb4, 0xfc4, arm64_l_fc4);
arm64_l_fb8:
	/* 0xfb8: ldr w8, [x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_fbc:
	/* 0xfbc: str w8, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_fc0:
	/* 0xfc0: b fd4 <tail_handle_ipv4+0xfd4> */
	ARM64_SIM_A64_JMP(0xfc0, 0xfd4, arm64_l_fd4);
arm64_l_fc4:
	/* 0xfc4: adrp x8, 0 <__config_service_loopback_ipv4> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_service_loopback_ipv4_11));
arm64_l_fc8:
	/* 0xfc8: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_fcc:
	/* 0xfcc: ldr w8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_fd0:
	/* 0xfd0: str w8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_fd4:
	/* 0xfd4: ldrh w8, [x23, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_fd8:
	/* 0xfd8: cbz w8, fe0 <tail_handle_ipv4+0xfe0> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xfd8, 0xfe0, arm64_l_fe0);
arm64_l_fdc:
	/* 0xfdc: strh w8, [sp, #66] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 66ULL);
arm64_l_fe0:
	/* 0xfe0: tbz x24, #41, ff4 <tail_handle_ipv4+0xff4> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 41, 0xfe0, 0xff4, arm64_l_ff4);
arm64_l_fe4:
	/* 0xfe4: str xzr, [sp, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_fe8:
	/* 0xfe8: str wzr, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_fec:
	/* 0xfec: mov w21, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ff0:
	/* 0xff0: b 1044 <tail_handle_ipv4+0x1044> */
	ARM64_SIM_A64_JMP(0xff0, 0x1044, arm64_l_1044);
arm64_l_ff4:
	/* 0xff4: ldrb w8, [sp, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_ff8:
	/* 0xff8: cmp w8, #0x3a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 58ULL);
arm64_l_ffc:
	/* 0xffc: b.eq 1034 <tail_handle_ipv4+0x1034> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xffc, 0x1034, arm64_l_1034);
arm64_l_1000:
	/* 0x1000: cmp w8, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1004:
	/* 0x1004: b.eq 1020 <tail_handle_ipv4+0x1020> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1004, 0x1020, arm64_l_1020);
arm64_l_1008:
	/* 0x1008: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_100c:
	/* 0x100c: b.ne fe4 <tail_handle_ipv4+0xfe4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x100c, 0xfe4, arm64_l_fe4);
arm64_l_1010:
	/* 0x1010: mov w21, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1014:
	/* 0x1014: str wzr, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1018:
	/* 0x1018: mov w8, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_101c:
	/* 0x101c: b 1040 <tail_handle_ipv4+0x1040> */
	ARM64_SIM_A64_JMP(0x101c, 0x1040, arm64_l_1040);
arm64_l_1020:
	/* 0x1020: mov w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 32ULL);
arm64_l_1024:
	/* 0x1024: mov w21, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1028:
	/* 0x1028: str w8, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_102c:
	/* 0x102c: mov w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 6ULL);
arm64_l_1030:
	/* 0x1030: b 1040 <tail_handle_ipv4+0x1040> */
	ARM64_SIM_A64_JMP(0x1030, 0x1040, arm64_l_1040);
arm64_l_1034:
	/* 0x1034: mov w21, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1038:
	/* 0x1038: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_103c:
	/* 0x103c: str wzr, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1040:
	/* 0x1040: str x8, [sp, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1044:
	/* 0x1044: mov w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 9ULL);
arm64_l_1048:
	/* 0x1048: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_104c:
	/* 0x104c: mov w1, #0x1e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 30ULL);
arm64_l_1050:
	/* 0x1050: mov x2, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1054:
	/* 0x1054: mov w3, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X3, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1058:
	/* 0x1058: mov w4, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X4, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_105c:
	/* 0x105c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 9ULL: ARM64_SIM_A64_LINK(0x1060ULL); ARM64_SIM_BPF_CALL_bpf_skb_store_bytes(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1060:
	/* 0x1060: tbnz w0, #31, 1198 <tail_handle_ipv4+0x1198> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x1060, 0x1198, arm64_l_1198);
arm64_l_1064:
	/* 0x1064: ldr w9, [x23] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1068:
	/* 0x1068: mvn w8, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MVN, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_106c:
	/* 0x106c: adds w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADDS_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1070:
	/* 0x1070: cinc w22, w8, cs */
	ARM64_SIM_RUN_OP3(ARM64_OP_CINC, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CS, 0);
arm64_l_1074:
	/* 0x1074: ldr w8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1078:
	/* 0x1078: cbz w8, 10c0 <tail_handle_ipv4+0x10c0> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1078, 0x10c0, arm64_l_10c0);
arm64_l_107c:
	/* 0x107c: adrp x8, 0 <__config_debug_lb> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_debug_lb_0));
arm64_l_1080:
	/* 0x1080: add x2, sp, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1084:
	/* 0x1084: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1088:
	/* 0x1088: ldr x8, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_108c:
	/* 0x108c: mov w1, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 26ULL);
arm64_l_1090:
	/* 0x1090: mov w3, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X3, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1094:
	/* 0x1094: mov w4, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X4, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1098:
	/* 0x1098: ldrb wzr, [x8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_109c:
	/* 0x109c: mov w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 9ULL);
arm64_l_10a0:
	/* 0x10a0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 9ULL: ARM64_SIM_A64_LINK(0x10a4ULL); ARM64_SIM_BPF_CALL_bpf_skb_store_bytes(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_10a4:
	/* 0x10a4: tbnz w0, #31, 1198 <tail_handle_ipv4+0x1198> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x10a4, 0x1198, arm64_l_1198);
arm64_l_10a8:
	/* 0x10a8: ldr w8, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_10ac:
	/* 0x10ac: mvn w9, w20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MVN, ARM64_X9, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_10b0:
	/* 0x10b0: adds w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADDS_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_10b4:
	/* 0x10b4: cinc w8, w8, cs */
	ARM64_SIM_RUN_OP3(ARM64_OP_CINC, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CS, 0);
arm64_l_10b8:
	/* 0x10b8: adds w8, w8, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADDS_REG, ARM64_X8, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_10bc:
	/* 0x10bc: cinc w22, w8, cs */
	ARM64_SIM_RUN_OP3(ARM64_OP_CINC, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CS, 0);
arm64_l_10c0:
	/* 0x10c0: mov w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_10c4:
	/* 0x10c4: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10c8:
	/* 0x10c8: mov w1, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_10cc:
	/* 0x10cc: mov w2, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_10d0:
	/* 0x10d0: mov w3, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_10d4:
	/* 0x10d4: mov w4, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X4, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_10d8:
	/* 0x10d8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 10ULL: ARM64_SIM_A64_LINK(0x10dcULL); ARM64_SIM_BPF_CALL_bpf_l3_csum_replace(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_10dc:
	/* 0x10dc: tbnz w0, #31, 10ec <tail_handle_ipv4+0x10ec> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x10dc, 0x10ec, arm64_l_10ec);
arm64_l_10e0:
	/* 0x10e0: tbz w21, #0, 10f4 <tail_handle_ipv4+0x10f4> */
	ARM64_SIM_A64_TBZ(ARM64_X21, 0, 0x10e0, 0x10f4, arm64_l_10f4);
arm64_l_10e4:
	/* 0x10e4: tbnz x24, #41, 2e8 <tail_handle_ipv4+0x2e8> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 41, 0x10e4, 0x2e8, arm64_l_2e8);
arm64_l_10e8:
	/* 0x10e8: b 1128 <tail_handle_ipv4+0x1128> */
	ARM64_SIM_A64_JMP(0x10e8, 0x1128, arm64_l_1128);
arm64_l_10ec:
	/* 0x10ec: mov w8, #0xffffff67 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967143ULL);
arm64_l_10f0:
	/* 0x10f0: b 119c <tail_handle_ipv4+0x119c> */
	ARM64_SIM_A64_JMP(0x10f0, 0x119c, arm64_l_119c);
arm64_l_10f4:
	/* 0x10f4: ldp x9, x10, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X9, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_10f8:
	/* 0x10f8: mov w8, #0xb */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 11ULL);
arm64_l_10fc:
	/* 0x10fc: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1100:
	/* 0x1100: mov w2, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1104:
	/* 0x1104: mov w3, w22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1108:
	/* 0x1108: add w1, w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X1, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_110c:
	/* 0x110c: ldr w9, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1110:
	/* 0x1110: orr w4, w9, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X4, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1114:
	/* 0x1114: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 11ULL: ARM64_SIM_A64_LINK(0x1118ULL); ARM64_SIM_BPF_CALL_bpf_l4_csum_replace(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1118:
	/* 0x1118: mov w8, #0xffffff66 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967142ULL);
arm64_l_111c:
	/* 0x111c: and w8, w8, w0, asr #31 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_ASR, 31), 0);
arm64_l_1120:
	/* 0x1120: tbnz x24, #41, 1190 <tail_handle_ipv4+0x1190> */
	ARM64_SIM_A64_TBNZ(ARM64_X24, 41, 0x1120, 0x1190, arm64_l_1190);
arm64_l_1124:
	/* 0x1124: tbnz w0, #31, 1190 <tail_handle_ipv4+0x1190> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x1124, 0x1190, arm64_l_1190);
arm64_l_1128:
	/* 0x1128: ldrh w8, [x23, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_112c:
	/* 0x112c: cbz w8, 2e8 <tail_handle_ipv4+0x2e8> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x112c, 0x2e8, arm64_l_2e8);
arm64_l_1130:
	/* 0x1130: ldr w9, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1134:
	/* 0x1134: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1138:
	/* 0x1138: b.eq 2e8 <tail_handle_ipv4+0x2e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1138, 0x2e8, arm64_l_2e8);
arm64_l_113c:
	/* 0x113c: strh w8, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_1140:
	/* 0x1140: mov w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 9ULL);
arm64_l_1144:
	/* 0x1144: add x2, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_1148:
	/* 0x1148: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_114c:
	/* 0x114c: mov w3, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X3, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1150:
	/* 0x1150: mov w4, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X4, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1154:
	/* 0x1154: ldr x20, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1158:
	/* 0x1158: add w1, w20, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_115c:
	/* 0x115c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 9ULL: ARM64_SIM_A64_LINK(0x1160ULL); ARM64_SIM_BPF_CALL_bpf_skb_store_bytes(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1160:
	/* 0x1160: tbnz w0, #31, 1198 <tail_handle_ipv4+0x1198> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x1160, 0x1198, arm64_l_1198);
arm64_l_1164:
	/* 0x1164: ldr x9, [sp, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1168:
	/* 0x1168: ldrh w3, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X3, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_116c:
	/* 0x116c: mov w8, #0xb */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 11ULL);
arm64_l_1170:
	/* 0x1170: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1174:
	/* 0x1174: add w1, w9, w20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X1, ARM64_X9, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1178:
	/* 0x1178: ldr w9, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_117c:
	/* 0x117c: ldr w2, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1180:
	/* 0x1180: orr w4, w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X4, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1184:
	/* 0x1184: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 11ULL: ARM64_SIM_A64_LINK(0x1188ULL); ARM64_SIM_BPF_CALL_bpf_l4_csum_replace(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1188:
	/* 0x1188: tbz w0, #31, 2e8 <tail_handle_ipv4+0x2e8> */
	ARM64_SIM_A64_TBZ(ARM64_X0, 31, 0x1188, 0x2e8, arm64_l_2e8);
arm64_l_118c:
	/* 0x118c: mov w8, #0xffffff66 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967142ULL);
arm64_l_1190:
	/* 0x1190: tbz w8, #31, 2e8 <tail_handle_ipv4+0x2e8> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 31, 0x1190, 0x2e8, arm64_l_2e8);
arm64_l_1194:
	/* 0x1194: b 119c <tail_handle_ipv4+0x119c> */
	ARM64_SIM_A64_JMP(0x1194, 0x119c, arm64_l_119c);
arm64_l_1198:
	/* 0x1198: mov w8, #0xffffff73 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967155ULL);
arm64_l_119c:
	/* 0x119c: mov w22, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_11a0:
	/* 0x11a0: adrp x9, 0 <__config_security_label> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_security_label_10));
arm64_l_11a4:
	/* 0x11a4: ubfiz w11, w22, #8, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_BITFIELD, ARM64_X11, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFIZ, 8, 8), 0);
arm64_l_11a8:
	/* 0x11a8: neg w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_11ac:
	/* 0x11ac: ldr x9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_11b0:
	/* 0x11b0: sub w8, w11, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_11b4:
	/* 0x11b4: adrp x0, 0 <cilium_metrics> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_metrics_22));
arm64_l_11b8:
	/* 0x11b8: add x1, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_11bc:
	/* 0x11bc: ldr w9, [x9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_11c0:
	/* 0x11c0: str w8, [x19, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_11c4:
	/* 0x11c4: mov x8, #0x20200000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 2207613190144ULL);
arm64_l_11c8:
	/* 0x11c8: ldr w20, [x19, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_11cc:
	/* 0x11cc: movk x8, #0x6cf, lsl #48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 1743ULL);
arm64_l_11d0:
	/* 0x11d0: stur x8, [x19, #52] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 52ULL);
arm64_l_11d4:
	/* 0x11d4: mov x8, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 512ULL);
arm64_l_11d8:
	/* 0x11d8: movk x8, #0x6cf, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 1743ULL);
arm64_l_11dc:
	/* 0x11dc: movk x8, #0x2, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 2ULL);
arm64_l_11e0:
	/* 0x11e0: stp w9, wzr, [x19, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_X19, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_11e4:
	/* 0x11e4: str x8, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_11e8:
	/* 0x11e8: strb w10, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_11ec:
	/* 0x11ec: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_11f0:
	/* 0x11f0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_11f4:
	/* 0x11f4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x11f8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_11f8:
	/* 0x11f8: cbz x0, 1210 <tail_handle_ipv4+0x1210> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x11f8, 0x1210, arm64_l_1210);
arm64_l_11fc:
	/* 0x11fc: ldp x8, x9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1200:
	/* 0x1200: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1204:
	/* 0x1204: add x9, x9, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1208:
	/* 0x1208: stp x8, x9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_120c:
	/* 0x120c: b 1234 <tail_handle_ipv4+0x1234> */
	ARM64_SIM_A64_JMP(0x120c, 0x1234, arm64_l_1234);
arm64_l_1210:
	/* 0x1210: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1214:
	/* 0x1214: adrp x0, 0 <cilium_metrics> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_metrics_22));
arm64_l_1218:
	/* 0x1218: add x1, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_121c:
	/* 0x121c: stp x8, x20, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1220:
	/* 0x1220: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1224:
	/* 0x1224: add x2, sp, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1228:
	/* 0x1228: mov w3, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_122c:
	/* 0x122c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1230:
	/* 0x1230: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0x1234ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1234:
	/* 0x1234: mov w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_1238:
	/* 0x1238: adrp x1, 0 <cilium_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_calls_13));
arm64_l_123c:
	/* 0x123c: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1240:
	/* 0x1240: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1244:
	/* 0x1244: mov w2, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1248:
	/* 0x1248: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x124cULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_124c:
	/* 0x124c: mov w0, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1250:
	/* 0x1250: ldp x20, x19, [sp, #208] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_1254:
	/* 0x1254: ldr x29, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1258:
	/* 0x1258: ldp x22, x21, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_125c:
	/* 0x125c: ldp x24, x23, [sp, #176] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_1260:
	/* 0x1260: ldp x30, x25, [sp, #160] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_1264:
	/* 0x1264: add sp, sp, #0xe0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_1268:
	/* 0x1268: b 12c0 <__native_link_arm64_ret_trampoline> */
	ARM64_SIM_A64_JMP(0x1268, 0x12c0, arm64_l_12c0);
arm64_l_126c:
	/* 0x126c: ldrb w8, [x21, #9] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 9ULL);
arm64_l_1270:
	/* 0x1270: tbz w8, #4, dd0 <tail_handle_ipv4+0xdd0> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 4, 0x1270, 0xdd0, arm64_l_dd0);
arm64_l_1274:
	/* 0x1274: mov w22, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1278:
	/* 0x1278: mov w8, #0xffffff62 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967138ULL);
arm64_l_127c:
	/* 0x127c: b 11a0 <tail_handle_ipv4+0x11a0> */
	ARM64_SIM_A64_JMP(0x127c, 0x11a0, arm64_l_11a0);
arm64_l_1280:
	/* 0x1280: mov w22, w0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1284:
	/* 0x1284: mov w8, #0xffffff65 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967141ULL);
arm64_l_1288:
	/* 0x1288: b 11a0 <tail_handle_ipv4+0x11a0> */
	ARM64_SIM_A64_JMP(0x1288, 0x11a0, arm64_l_11a0);
arm64_l_128c:
	/* 0x128c: ldr w9, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1290:
	/* 0x1290: ldrh w10, [sp, #66] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 66ULL);
arm64_l_1294:
	/* 0x1294: adrp x0, 0 <cilium_skip_lb4> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&cilium_skip_lb4_24));
arm64_l_1298:
	/* 0x1298: add x1, sp, #0x48 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_129c:
	/* 0x129c: stp x8, xzr, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_12a0:
	/* 0x12a0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_12a4:
	/* 0x12a4: str w9, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_12a8:
	/* 0x12a8: strh w10, [sp, #84] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 84ULL);
arm64_l_12ac:
	/* 0x12ac: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_12b0:
	/* 0x12b0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x12b4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_12b4:
	/* 0x12b4: cbnz x0, 2e8 <tail_handle_ipv4+0x2e8> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x12b4, 0x2e8, arm64_l_2e8);
arm64_l_12b8:
	/* 0x12b8: ldr w20, [sp, #60] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 60ULL);
arm64_l_12bc:
	/* 0x12bc: b f90 <tail_handle_ipv4+0xf90> */
	ARM64_SIM_A64_JMP(0x12bc, 0xf90, arm64_l_f90);
arm64_l_12c0:
	/* 0x12c0: mov x7, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
