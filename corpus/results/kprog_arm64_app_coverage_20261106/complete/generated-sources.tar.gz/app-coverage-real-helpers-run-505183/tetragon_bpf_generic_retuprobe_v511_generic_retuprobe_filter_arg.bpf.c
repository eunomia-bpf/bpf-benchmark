extern char addr4lpm_maps;
extern char addr6lpm_maps;
extern char argfilter_maps;
extern char filter_map;
extern char heap_ro_zero;
extern char process_call_heap;
extern char retprobe_map;
extern char retuprobe_calls;
extern char string_maps_0;
extern char string_maps_1;
extern char string_maps_10;
extern char string_maps_2;
extern char string_maps_3;
extern char string_maps_4;
extern char string_maps_5;
extern char string_maps_6;
extern char string_maps_7;
extern char string_maps_8;
extern char string_maps_9;
extern char string_maps_heap;
extern char string_postfix_maps;
extern char string_postfix_maps_heap;
extern char string_prefix_maps;
extern char string_prefix_maps_heap;
extern char substring_map;
#define ARM64_SIM_RET_CASES_34f0 case 0x1484ULL: goto arm64_l_1484;
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_RETURN_CASES \
	case 0x38ULL: goto arm64_l_38; \
	case 0x64ULL: goto arm64_l_64; \
	case 0x484ULL: goto arm64_l_484; \
	case 0x5a4ULL: goto arm64_l_5a4; \
	case 0x5ccULL: goto arm64_l_5cc; \
	case 0x6d0ULL: goto arm64_l_6d0; \
	case 0x6f8ULL: goto arm64_l_6f8; \
	case 0x7a0ULL: goto arm64_l_7a0; \
	case 0x7c8ULL: goto arm64_l_7c8; \
	case 0x7f8ULL: goto arm64_l_7f8; \
	case 0x808ULL: goto arm64_l_808; \
	case 0x944ULL: goto arm64_l_944; \
	case 0x960ULL: goto arm64_l_960; \
	case 0x9b0ULL: goto arm64_l_9b0; \
	case 0xaacULL: goto arm64_l_aac; \
	case 0xbd4ULL: goto arm64_l_bd4; \
	case 0xbfcULL: goto arm64_l_bfc; \
	case 0xc2cULL: goto arm64_l_c2c; \
	case 0xc3cULL: goto arm64_l_c3c; \
	case 0xe58ULL: goto arm64_l_e58; \
	case 0xe80ULL: goto arm64_l_e80; \
	case 0x1068ULL: goto arm64_l_1068; \
	case 0x10d8ULL: goto arm64_l_10d8; \
	case 0x1218ULL: goto arm64_l_1218; \
	case 0x1290ULL: goto arm64_l_1290; \
	case 0x12c8ULL: goto arm64_l_12c8; \
	case 0x137cULL: goto arm64_l_137c; \
	case 0x13a4ULL: goto arm64_l_13a4; \
	case 0x1470ULL: goto arm64_l_1470; \
	case 0x1484ULL: goto arm64_l_1484; \
	case 0x14e4ULL: goto arm64_l_14e4; \
	case 0x150cULL: goto arm64_l_150c; \
	case 0x1534ULL: goto arm64_l_1534; \
	case 0x1544ULL: goto arm64_l_1544; \
	case 0x159cULL: goto arm64_l_159c; \
	case 0x15b4ULL: goto arm64_l_15b4; \
	case 0x15f0ULL: goto arm64_l_15f0; \
	case 0x1618ULL: goto arm64_l_1618; \
	case 0x1648ULL: goto arm64_l_1648; \
	case 0x171cULL: goto arm64_l_171c; \
	case 0x1734ULL: goto arm64_l_1734; \
	case 0x1b10ULL: goto arm64_l_1b10; \
	case 0x1c98ULL: goto arm64_l_1c98; \
	case 0x1cb0ULL: goto arm64_l_1cb0; \
	case 0x2008ULL: goto arm64_l_2008; \
	case 0x2020ULL: goto arm64_l_2020; \
	case 0x206cULL: goto arm64_l_206c; \
	case 0x20b8ULL: goto arm64_l_20b8; \
	case 0x20e0ULL: goto arm64_l_20e0; \
	case 0x2418ULL: goto arm64_l_2418; \
	case 0x2430ULL: goto arm64_l_2430; \
	case 0x2480ULL: goto arm64_l_2480; \
	case 0x24b0ULL: goto arm64_l_24b0; \
	case 0x24d4ULL: goto arm64_l_24d4; \
	case 0x28d8ULL: goto arm64_l_28d8; \
	case 0x28f0ULL: goto arm64_l_28f0; \
	case 0x2944ULL: goto arm64_l_2944; \
	case 0x298cULL: goto arm64_l_298c; \
	case 0x29b0ULL: goto arm64_l_29b0; \
	case 0x2c10ULL: goto arm64_l_2c10; \
	case 0x2c20ULL: goto arm64_l_2c20; \
	case 0x2d00ULL: goto arm64_l_2d00; \
	case 0x2d10ULL: goto arm64_l_2d10; \
	case 0x2e04ULL: goto arm64_l_2e04; \
	case 0x2e14ULL: goto arm64_l_2e14; \
	case 0x3020ULL: goto arm64_l_3020; \
	case 0x303cULL: goto arm64_l_303c; \
	case 0x3078ULL: goto arm64_l_3078; \
	case 0x30b0ULL: goto arm64_l_30b0; \
	case 0x30d4ULL: goto arm64_l_30d4; \
	case 0x329cULL: goto arm64_l_329c; \
	case 0x32acULL: goto arm64_l_32ac; \
	case 0x3360ULL: goto arm64_l_3360; \
	case 0x337cULL: goto arm64_l_337c; \
	case 0x3418ULL: goto arm64_l_3418; \
	case 0x3424ULL: goto arm64_l_3424; \
	case 0x3444ULL: goto arm64_l_3444; \
	case 0x345cULL: goto arm64_l_345c;
#include "../arm64_sim_local_bpf.h"

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} addr4lpm_maps_0 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} addr6lpm_maps_1 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} argfilter_maps_2 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} filter_map_3 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} heap_ro_zero_4 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} process_call_heap_5 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} retprobe_map_6 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} retuprobe_calls_7 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_0_8 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_1_9 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_10_10 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_2_11 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_3_12 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_4_13 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_5_14 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_6_15 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_7_16 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_8_17 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_9_18 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_heap_19 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_postfix_maps_20 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_postfix_maps_heap_21 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_prefix_maps_22 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_prefix_maps_heap_23 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} substring_map_24 SEC(".maps");

SEC("xdp")
int tetragon_bpf_generic_retuprobe_v511_generic_retuprobe_filter_arg_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
arm64_l_0:
	/* 0x0: sub sp, sp, #0xf0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_4:
	/* 0x4: str x29, [sp, #160] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_8:
	/* 0x8: stp x30, x25, [sp, #176] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_c:
	/* 0xc: stp x24, x23, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_10:
	/* 0x10: stp x22, x21, [sp, #208] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_14:
	/* 0x14: stp x20, x19, [sp, #224] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_18:
	/* 0x18: mov x23, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c:
	/* 0x1c: str wzr, [sp, #168] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_20:
	/* 0x20: adrp x0, 0 <process_call_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_5));
arm64_l_24:
	/* 0x24: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28:
	/* 0x28: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c:
	/* 0x2c: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_30:
	/* 0x30: add x1, sp, #0xa8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_34:
	/* 0x34: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x38ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_38:
	/* 0x38: cbz x0, 337c <generic_retuprobe_filter_arg+0x337c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x38, 0x337c, arm64_l_337c);
arm64_l_3c:
	/* 0x3c: mov w8, #0x5ec1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24257ULL);
arm64_l_40:
	/* 0x40: mov x20, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_44:
	/* 0x44: add x19, x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_48:
	/* 0x48: mov w8, #0x5ef8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24312ULL);
arm64_l_4c:
	/* 0x4c: add x1, x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X1, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_50:
	/* 0x50: adrp x0, 0 <filter_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&filter_map_3));
arm64_l_54:
	/* 0x54: ldur w21, [x19, #63] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 63ULL);
arm64_l_58:
	/* 0x58: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_5c:
	/* 0x5c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_60:
	/* 0x60: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x64ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_64:
	/* 0x64: cbz x0, 3360 <generic_retuprobe_filter_arg+0x3360> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x64, 0x3360, arm64_l_3360);
arm64_l_68:
	/* 0x68: ldrb w8, [x19, #31] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 31ULL);
arm64_l_6c:
	/* 0x6c: cbz w8, 3360 <generic_retuprobe_filter_arg+0x3360> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x6c, 0x3360, arm64_l_3360);
arm64_l_70:
	/* 0x70: and x8, x21, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_74:
	/* 0x74: mov w10, #0x5ec1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24257ULL);
arm64_l_78:
	/* 0x78: str x21, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_7c:
	/* 0x7c: add x9, x20, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_80:
	/* 0x80: ldrb w9, [x9, x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X10, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_84:
	/* 0x84: cbz w9, c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x84, 0xc4, arm64_l_c4);
arm64_l_88:
	/* 0x88: lsl w8, w8, #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_8c:
	/* 0x8c: add x8, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_90:
	/* 0x90: ldr w9, [x8, x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X0, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_94:
	/* 0x94: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_98:
	/* 0x98: add x12, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_9c:
	/* 0x9c: and x8, x12, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_a0:
	/* 0xa0: add x16, x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X16, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_a4:
	/* 0xa4: str x8, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_a8:
	/* 0xa8: ldr w8, [x16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X16, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ac:
	/* 0xac: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_b0:
	/* 0xb0: b.cs 110 <generic_retuprobe_filter_arg+0x110> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xb0, 0x110, arm64_l_110);
arm64_l_b4:
	/* 0xb4: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_b8:
	/* 0xb8: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_bc:
	/* 0xbc: b.eq 3360 <generic_retuprobe_filter_arg+0x3360> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xbc, 0x3360, arm64_l_3360);
arm64_l_c0:
	/* 0xc0: cbnz w8, 333c <generic_retuprobe_filter_arg+0x333c> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0xc0, 0x333c, arm64_l_333c);
arm64_l_c4:
	/* 0xc4: ldr x8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_c8:
	/* 0xc8: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_cc:
	/* 0xcc: b.gt e8 <generic_retuprobe_filter_arg+0xe8> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xcc, 0xe8, arm64_l_e8);
arm64_l_d0:
	/* 0xd0: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d4:
	/* 0xd4: b.eq 339c <generic_retuprobe_filter_arg+0x339c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd4, 0x339c, arm64_l_339c);
arm64_l_d8:
	/* 0xd8: cbz w8, 33ac <generic_retuprobe_filter_arg+0x33ac> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xd8, 0x33ac, arm64_l_33ac);
arm64_l_dc:
	/* 0xdc: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_e0:
	/* 0xe0: b.eq 33bc <generic_retuprobe_filter_arg+0x33bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe0, 0x33bc, arm64_l_33bc);
arm64_l_e4:
	/* 0xe4: b 100 <generic_retuprobe_filter_arg+0x100> */
	ARM64_SIM_A64_JMP(0xe4, 0x100, arm64_l_100);
arm64_l_e8:
	/* 0xe8: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_ec:
	/* 0xec: b.eq 33cc <generic_retuprobe_filter_arg+0x33cc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xec, 0x33cc, arm64_l_33cc);
arm64_l_f0:
	/* 0xf0: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_f4:
	/* 0xf4: b.eq 33dc <generic_retuprobe_filter_arg+0x33dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf4, 0x33dc, arm64_l_33dc);
arm64_l_f8:
	/* 0xf8: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_fc:
	/* 0xfc: b.eq 33ec <generic_retuprobe_filter_arg+0x33ec> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xfc, 0x33ec, arm64_l_33ec);
arm64_l_100:
	/* 0x100: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_104:
	/* 0x104: b.gt 3418 <generic_retuprobe_filter_arg+0x3418> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x104, 0x3418, arm64_l_3418);
arm64_l_108:
	/* 0x108: add w8, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_10c:
	/* 0x10c: b 33f8 <generic_retuprobe_filter_arg+0x33f8> */
	ARM64_SIM_A64_JMP(0x10c, 0x33f8, arm64_l_33f8);
arm64_l_110:
	/* 0x110: mov x24, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_114:
	/* 0x114: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_118:
	/* 0x118: stp x19, x0, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_11c:
	/* 0x11c: stp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X12, ARM64_X16, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_120:
	/* 0x120: b 14c <generic_retuprobe_filter_arg+0x14c> */
	ARM64_SIM_A64_JMP(0x120, 0x14c, arm64_l_14c);
arm64_l_124:
	/* 0x124: orr w8, w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_128:
	/* 0x128: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_12c:
	/* 0x12c: b.ne c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x12c, 0xc4, arm64_l_c4);
arm64_l_130:
	/* 0x130: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_134:
	/* 0x134: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_138:
	/* 0x138: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_13c:
	/* 0x13c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_140:
	/* 0x140: add x24, x24, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_144:
	/* 0x144: cmp x24, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_148:
	/* 0x148: b.eq b4 <generic_retuprobe_filter_arg+0xb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x148, 0xb4, arm64_l_b4);
arm64_l_14c:
	/* 0x14c: add x8, x16, x24, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X16, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_150:
	/* 0x150: ldr w8, [x8, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_154:
	/* 0x154: tst w8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_158:
	/* 0x158: b.eq b4 <generic_retuprobe_filter_arg+0xb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x158, 0xb4, arm64_l_b4);
arm64_l_15c:
	/* 0x15c: add w8, w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_160:
	/* 0x160: and x8, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_164:
	/* 0x164: add x21, x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X21, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_168:
	/* 0x168: ldr w8, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_16c:
	/* 0x16c: cmp w8, #0x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 35ULL);
arm64_l_170:
	/* 0x170: b.eq c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x170, 0xc4, arm64_l_c4);
arm64_l_174:
	/* 0x174: ldr w9, [x21] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_178:
	/* 0x178: cmp w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_17c:
	/* 0x17c: b.hi c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x17c, 0xc4, arm64_l_c4);
arm64_l_180:
	/* 0x180: add x10, x20, x9, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_184:
	/* 0x184: mov w11, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_188:
	/* 0x188: ldr w10, [x10, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18c:
	/* 0x18c: cbnz w10, c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0x18c, 0xc4, arm64_l_c4);
arm64_l_190:
	/* 0x190: add x9, x20, x9, lsl #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 3), 0);
arm64_l_194:
	/* 0x194: ldr x9, [x9, #24184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24184ULL);
arm64_l_198:
	/* 0x198: and x9, x9, #0x7ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2047ULL);
arm64_l_19c:
	/* 0x19c: add x9, x20, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1a0:
	/* 0x1a0: add x25, x9, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1a4:
	/* 0x1a4: ldr w9, [x21, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1a8:
	/* 0x1a8: cmp w9, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_1ac:
	/* 0x1ac: b.le 1d0 <generic_retuprobe_filter_arg+0x1d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1ac, 0x1d0, arm64_l_1d0);
arm64_l_1b0:
	/* 0x1b0: cmp w9, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_1b4:
	/* 0x1b4: b.gt 200 <generic_retuprobe_filter_arg+0x200> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1b4, 0x200, arm64_l_200);
arm64_l_1b8:
	/* 0x1b8: sub w10, w9, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_1bc:
	/* 0x1bc: cmp w10, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_1c0:
	/* 0x1c0: b.cc 244 <generic_retuprobe_filter_arg+0x244> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1c0, 0x244, arm64_l_244);
arm64_l_1c4:
	/* 0x1c4: cmp w9, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_1c8:
	/* 0x1c8: b.eq 3f8 <generic_retuprobe_filter_arg+0x3f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c8, 0x3f8, arm64_l_3f8);
arm64_l_1cc:
	/* 0x1cc: b 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JMP(0x1cc, 0x140, arm64_l_140);
arm64_l_1d0:
	/* 0x1d0: cmp w9, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_1d4:
	/* 0x1d4: b.le 224 <generic_retuprobe_filter_arg+0x224> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1d4, 0x224, arm64_l_224);
arm64_l_1d8:
	/* 0x1d8: sub w10, w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1dc:
	/* 0x1dc: cmp w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1e0:
	/* 0x1e0: b.cc 244 <generic_retuprobe_filter_arg+0x244> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1e0, 0x244, arm64_l_244);
arm64_l_1e4:
	/* 0x1e4: sub w10, w9, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_1e8:
	/* 0x1e8: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1ec:
	/* 0x1ec: b.cc 3f8 <generic_retuprobe_filter_arg+0x3f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1ec, 0x3f8, arm64_l_3f8);
arm64_l_1f0:
	/* 0x1f0: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1f4:
	/* 0x1f4: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1f4, 0x140, arm64_l_140);
arm64_l_1f8:
	/* 0x1f8: add x25, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1fc:
	/* 0x1fc: b 3f8 <generic_retuprobe_filter_arg+0x3f8> */
	ARM64_SIM_A64_JMP(0x1fc, 0x3f8, arm64_l_3f8);
arm64_l_200:
	/* 0x200: cmp w9, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_204:
	/* 0x204: b.gt 370 <generic_retuprobe_filter_arg+0x370> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x204, 0x370, arm64_l_370);
arm64_l_208:
	/* 0x208: sub w10, w9, #0x26 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 38ULL);
arm64_l_20c:
	/* 0x20c: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_210:
	/* 0x210: b.cc 318 <generic_retuprobe_filter_arg+0x318> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x210, 0x318, arm64_l_318);
arm64_l_214:
	/* 0x214: sub w10, w9, #0x28 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_218:
	/* 0x218: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_21c:
	/* 0x21c: b.cc 2f0 <generic_retuprobe_filter_arg+0x2f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x21c, 0x2f0, arm64_l_2f0);
arm64_l_220:
	/* 0x220: b 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JMP(0x220, 0x140, arm64_l_140);
arm64_l_224:
	/* 0x224: cmp w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_228:
	/* 0x228: b.gt 2d8 <generic_retuprobe_filter_arg+0x2d8> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x228, 0x2d8, arm64_l_2d8);
arm64_l_22c:
	/* 0x22c: cmp w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_230:
	/* 0x230: b.eq 244 <generic_retuprobe_filter_arg+0x244> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x230, 0x244, arm64_l_244);
arm64_l_234:
	/* 0x234: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_238:
	/* 0x238: b.eq 824 <generic_retuprobe_filter_arg+0x824> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x238, 0x824, arm64_l_824);
arm64_l_23c:
	/* 0x23c: cmp w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_240:
	/* 0x240: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x240, 0x140, arm64_l_140);
arm64_l_244:
	/* 0x244: cmp w9, #0xb */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 11ULL);
arm64_l_248:
	/* 0x248: b.le 2b8 <generic_retuprobe_filter_arg+0x2b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x248, 0x2b8, arm64_l_2b8);
arm64_l_24c:
	/* 0x24c: cmp w9, #0x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 36ULL);
arm64_l_250:
	/* 0x250: b.hi 4b0 <generic_retuprobe_filter_arg+0x4b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x250, 0x4b0, arm64_l_4b0);
arm64_l_254:
	/* 0x254: lsl x10, x17, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_258:
	/* 0x258: tst x10, #0x1e00000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 128849018880ULL);
arm64_l_25c:
	/* 0x25c: b.ne 348 <generic_retuprobe_filter_arg+0x348> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x25c, 0x348, arm64_l_348);
arm64_l_260:
	/* 0x260: lsl x10, x17, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_264:
	/* 0x264: tst x10, #0x60000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1610612736ULL);
arm64_l_268:
	/* 0x268: b.ne 66c <generic_retuprobe_filter_arg+0x66c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x268, 0x66c, arm64_l_66c);
arm64_l_26c:
	/* 0x26c: lsl x10, x17, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_270:
	/* 0x270: tst x10, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_274:
	/* 0x274: b.eq 4b0 <generic_retuprobe_filter_arg+0x4b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x274, 0x4b0, arm64_l_4b0);
arm64_l_278:
	/* 0x278: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_27c:
	/* 0x27c: b.hi c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x27c, 0xc4, arm64_l_c4);
arm64_l_280:
	/* 0x280: lsl x9, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_284:
	/* 0x284: mov w10, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_288:
	/* 0x288: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_28c:
	/* 0x28c: b.eq cb8 <generic_retuprobe_filter_arg+0xcb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x28c, 0xcb8, arm64_l_cb8);
arm64_l_290:
	/* 0x290: ldr w9, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_294:
	/* 0x294: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_298:
	/* 0x298: b.le 1230 <generic_retuprobe_filter_arg+0x1230> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x298, 0x1230, arm64_l_1230);
arm64_l_29c:
	/* 0x29c: sub w10, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2a0:
	/* 0x2a0: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2a4:
	/* 0x2a4: b.cs 1844 <generic_retuprobe_filter_arg+0x1844> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2a4, 0x1844, arm64_l_1844);
arm64_l_2a8:
	/* 0x2a8: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ac:
	/* 0x2ac: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b0:
	/* 0x2b0: b.ne 19d0 <generic_retuprobe_filter_arg+0x19d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2b0, 0x19d0, arm64_l_19d0);
arm64_l_2b4:
	/* 0x2b4: b 31dc <generic_retuprobe_filter_arg+0x31dc> */
	ARM64_SIM_A64_JMP(0x2b4, 0x31dc, arm64_l_31dc);
arm64_l_2b8:
	/* 0x2b8: sub w10, w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2bc:
	/* 0x2bc: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2c0:
	/* 0x2c0: b.cc 898 <generic_retuprobe_filter_arg+0x898> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2c0, 0x898, arm64_l_898);
arm64_l_2c4:
	/* 0x2c4: cmp w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2c8:
	/* 0x2c8: b.eq 4bc <generic_retuprobe_filter_arg+0x4bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2c8, 0x4bc, arm64_l_4bc);
arm64_l_2cc:
	/* 0x2cc: cmp w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2d0:
	/* 0x2d0: b.eq 4bc <generic_retuprobe_filter_arg+0x4bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2d0, 0x4bc, arm64_l_4bc);
arm64_l_2d4:
	/* 0x2d4: b 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JMP(0x2d4, 0x140, arm64_l_140);
arm64_l_2d8:
	/* 0x2d8: cmp w9, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2dc:
	/* 0x2dc: b.eq 2f0 <generic_retuprobe_filter_arg+0x2f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2dc, 0x2f0, arm64_l_2f0);
arm64_l_2e0:
	/* 0x2e0: cmp w9, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2e4:
	/* 0x2e4: b.eq 318 <generic_retuprobe_filter_arg+0x318> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2e4, 0x318, arm64_l_318);
arm64_l_2e8:
	/* 0x2e8: cmp w9, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_2ec:
	/* 0x2ec: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2ec, 0x140, arm64_l_140);
arm64_l_2f0:
	/* 0x2f0: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2f4:
	/* 0x2f4: cmp w9, #0x27 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 39ULL);
arm64_l_2f8:
	/* 0x2f8: stp xzr, xzr, [sp, #120] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_2fc:
	/* 0x2fc: str xzr, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_300:
	/* 0x300: stp xzr, xzr, [sp, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_304:
	/* 0x304: b.gt 4fc <generic_retuprobe_filter_arg+0x4fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x304, 0x4fc, arm64_l_4fc);
arm64_l_308:
	/* 0x308: cmp w9, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_30c:
	/* 0x30c: b.eq 9c8 <generic_retuprobe_filter_arg+0x9c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x30c, 0x9c8, arm64_l_9c8);
arm64_l_310:
	/* 0x310: cmp w9, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_314:
	/* 0x314: b 508 <generic_retuprobe_filter_arg+0x508> */
	ARM64_SIM_A64_JMP(0x314, 0x508, arm64_l_508);
arm64_l_318:
	/* 0x318: ldr w29, [x25], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_31c:
	/* 0x31c: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_320:
	/* 0x320: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_324:
	/* 0x324: b.gt 568 <generic_retuprobe_filter_arg+0x568> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x324, 0x568, arm64_l_568);
arm64_l_328:
	/* 0x328: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_32c:
	/* 0x32c: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_330:
	/* 0x330: b.cc c48 <generic_retuprobe_filter_arg+0xc48> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x330, 0xc48, arm64_l_c48);
arm64_l_334:
	/* 0x334: cmp w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_338:
	/* 0x338: b.eq bb0 <generic_retuprobe_filter_arg+0xbb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x338, 0xbb0, arm64_l_bb0);
arm64_l_33c:
	/* 0x33c: cmp w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_340:
	/* 0x340: b.eq 580 <generic_retuprobe_filter_arg+0x580> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x340, 0x580, arm64_l_580);
arm64_l_344:
	/* 0x344: b 1d18 <generic_retuprobe_filter_arg+0x1d18> */
	ARM64_SIM_A64_JMP(0x344, 0x1d18, arm64_l_1d18);
arm64_l_348:
	/* 0x348: cmp w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_34c:
	/* 0x34c: b.le 814 <generic_retuprobe_filter_arg+0x814> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x34c, 0x814, arm64_l_814);
arm64_l_350:
	/* 0x350: cmp w8, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_354:
	/* 0x354: b.gt b70 <generic_retuprobe_filter_arg+0xb70> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x354, 0xb70, arm64_l_b70);
arm64_l_358:
	/* 0x358: sub w10, w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_35c:
	/* 0x35c: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_360:
	/* 0x360: b.cc 924 <generic_retuprobe_filter_arg+0x924> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x360, 0x924, arm64_l_924);
arm64_l_364:
	/* 0x364: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_368:
	/* 0x368: b.eq 8b0 <generic_retuprobe_filter_arg+0x8b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x368, 0x8b0, arm64_l_8b0);
arm64_l_36c:
	/* 0x36c: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x36c, 0xc4, arm64_l_c4);
arm64_l_370:
	/* 0x370: cmp w9, #0x2a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 42ULL);
arm64_l_374:
	/* 0x374: b.eq 3f8 <generic_retuprobe_filter_arg+0x3f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x374, 0x3f8, arm64_l_3f8);
arm64_l_378:
	/* 0x378: cmp w9, #0x2c */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_37c:
	/* 0x37c: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x37c, 0x140, arm64_l_140);
arm64_l_380:
	/* 0x380: ldrb w29, [x25, #3] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3ULL);
arm64_l_384:
	/* 0x384: add x10, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_388:
	/* 0x388: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_38c:
	/* 0x38c: b.gt f44 <generic_retuprobe_filter_arg+0xf44> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x38c, 0xf44, arm64_l_f44);
arm64_l_390:
	/* 0x390: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_394:
	/* 0x394: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_398:
	/* 0x398: b.cs 14b4 <generic_retuprobe_filter_arg+0x14b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x398, 0x14b4, arm64_l_14b4);
arm64_l_39c:
	/* 0x39c: cmp w29, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3a0:
	/* 0x3a0: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_3a4:
	/* 0x3a4: b.hi 1550 <generic_retuprobe_filter_arg+0x1550> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x3a4, 0x1550, arm64_l_1550);
arm64_l_3a8:
	/* 0x3a8: mov w8, #0xaaab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 43691ULL);
arm64_l_3ac:
	/* 0x3ac: mov w9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_3b0:
	/* 0x3b0: movk w8, #0xaaa, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 2730ULL);
arm64_l_3b4:
	/* 0x3b4: umull x8, w29, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_UMULL, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3b8:
	/* 0x3b8: lsr x8, x8, #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 32ULL);
arm64_l_3bc:
	/* 0x3bc: msub w8, w8, w9, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MSUB, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_X29, ARM64_WIDTH_32, 0, 0);
arm64_l_3c0:
	/* 0x3c0: cbz w29, 3cc <generic_retuprobe_filter_arg+0x3cc> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x3c0, 0x3cc, arm64_l_3cc);
arm64_l_3c4:
	/* 0x3c4: mov w13, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_3c8:
	/* 0x3c8: cbz w8, 3e0 <generic_retuprobe_filter_arg+0x3e0> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x3c8, 0x3e0, arm64_l_3e0);
arm64_l_3cc:
	/* 0x3cc: sub w8, w29, w8, uxtb */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_UXTB, 0), 0);
arm64_l_3d0:
	/* 0x3d0: add w9, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_3d4:
	/* 0x3d4: cmp w8, #0x78 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 120ULL);
arm64_l_3d8:
	/* 0x3d8: and w13, w9, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_3dc:
	/* 0x3dc: b.hi 1554 <generic_retuprobe_filter_arg+0x1554> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x3dc, 0x1554, arm64_l_1554);
arm64_l_3e0:
	/* 0x3e0: and w8, w13, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_3e4:
	/* 0x3e4: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_3e8:
	/* 0x3e8: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_3ec:
	/* 0x3ec: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_3f0:
	/* 0x3f0: sub w11, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3f4:
	/* 0x3f4: b 1fd0 <generic_retuprobe_filter_arg+0x1fd0> */
	ARM64_SIM_A64_JMP(0x3f4, 0x1fd0, arm64_l_1fd0);
arm64_l_3f8:
	/* 0x3f8: ldr w29, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3fc:
	/* 0x3fc: and w9, w8, #0xfffffffe */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967294ULL);
arm64_l_400:
	/* 0x400: cmp w9, #0x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 36ULL);
arm64_l_404:
	/* 0x404: b.eq 40c <generic_retuprobe_filter_arg+0x40c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x404, 0x40c, arm64_l_40c);
arm64_l_408:
	/* 0x408: cbz w29, c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x408, 0xc4, arm64_l_c4);
arm64_l_40c:
	/* 0x40c: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_410:
	/* 0x410: b.hi 64c <generic_retuprobe_filter_arg+0x64c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x410, 0x64c, arm64_l_64c);
arm64_l_414:
	/* 0x414: mov w10, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_418:
	/* 0x418: lsl x9, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_41c:
	/* 0x41c: movk w10, #0x400, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 1024ULL);
arm64_l_420:
	/* 0x420: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_424:
	/* 0x424: b.ne 77c <generic_retuprobe_filter_arg+0x77c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x424, 0x77c, arm64_l_77c);
arm64_l_428:
	/* 0x428: mov w10, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 512ULL);
arm64_l_42c:
	/* 0x42c: lsl x9, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_430:
	/* 0x430: movk w10, #0x800, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 2048ULL);
arm64_l_434:
	/* 0x434: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_438:
	/* 0x438: b.ne 6ac <generic_retuprobe_filter_arg+0x6ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x438, 0x6ac, arm64_l_6ac);
arm64_l_43c:
	/* 0x43c: lsl x9, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_440:
	/* 0x440: tst x9, #0x3000000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 206158430208ULL);
arm64_l_444:
	/* 0x444: b.eq 64c <generic_retuprobe_filter_arg+0x64c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x444, 0x64c, arm64_l_64c);
arm64_l_448:
	/* 0x448: cmp w29, #0x1, lsl #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_44c:
	/* 0x44c: strh wzr, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_450:
	/* 0x450: b.hi 664 <generic_retuprobe_filter_arg+0x664> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x450, 0x664, arm64_l_664);
arm64_l_454:
	/* 0x454: add x8, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_458:
	/* 0x458: mov w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_45c:
	/* 0x45c: add x11, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_460:
	/* 0x460: mov w12, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_464:
	/* 0x464: add x0, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_468:
	/* 0x468: mov w1, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_46c:
	/* 0x46c: add x9, x8, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_470:
	/* 0x470: add x9, x9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_474:
	/* 0x474: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_478:
	/* 0x478: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_47c:
	/* 0x47c: add x2, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_480:
	/* 0x480: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x484ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_484:
	/* 0x484: ldr w9, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_488:
	/* 0x488: cbz w9, 2d1c <generic_retuprobe_filter_arg+0x2d1c> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x488, 0x2d1c, arm64_l_2d1c);
arm64_l_48c:
	/* 0x48c: ldrh w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_490:
	/* 0x490: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_494:
	/* 0x494: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_498:
	/* 0x498: and w8, w8, #0xf000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 61440ULL);
arm64_l_49c:
	/* 0x49c: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_4a0:
	/* 0x4a0: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_4a4:
	/* 0x4a4: b.ne 1874 <generic_retuprobe_filter_arg+0x1874> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x4a4, 0x1874, arm64_l_1874);
arm64_l_4a8:
	/* 0x4a8: mov w22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_4ac:
	/* 0x4ac: b 2d2c <generic_retuprobe_filter_arg+0x2d2c> */
	ARM64_SIM_A64_JMP(0x4ac, 0x2d2c, arm64_l_2d2c);
arm64_l_4b0:
	/* 0x4b0: sub w10, w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_4b4:
	/* 0x4b4: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_4b8:
	/* 0x4b8: b.cs 890 <generic_retuprobe_filter_arg+0x890> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x4b8, 0x890, arm64_l_890);
arm64_l_4bc:
	/* 0x4bc: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_4c0:
	/* 0x4c0: b.hi c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x4c0, 0xc4, arm64_l_c4);
arm64_l_4c4:
	/* 0x4c4: lsl x10, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_4c8:
	/* 0x4c8: mov w11, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_4cc:
	/* 0x4cc: tst x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_4d0:
	/* 0x4d0: b.eq 514 <generic_retuprobe_filter_arg+0x514> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x4d0, 0x514, arm64_l_514);
arm64_l_4d4:
	/* 0x4d4: ldr w10, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_4d8:
	/* 0x4d8: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_4dc:
	/* 0x4dc: b.le 858 <generic_retuprobe_filter_arg+0x858> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x4dc, 0x858, arm64_l_858);
arm64_l_4e0:
	/* 0x4e0: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_4e4:
	/* 0x4e4: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_4e8:
	/* 0x4e8: b.cs ca0 <generic_retuprobe_filter_arg+0xca0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x4e8, 0xca0, arm64_l_ca0);
arm64_l_4ec:
	/* 0x4ec: ldr w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_4f0:
	/* 0x4f0: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_4f4:
	/* 0x4f4: b.ne 1df4 <generic_retuprobe_filter_arg+0x1df4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x4f4, 0x1df4, arm64_l_1df4);
arm64_l_4f8:
	/* 0x4f8: b 31dc <generic_retuprobe_filter_arg+0x31dc> */
	ARM64_SIM_A64_JMP(0x4f8, 0x31dc, arm64_l_31dc);
arm64_l_4fc:
	/* 0x4fc: cmp w9, #0x28 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_500:
	/* 0x500: b.eq 9d0 <generic_retuprobe_filter_arg+0x9d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x500, 0x9d0, arm64_l_9d0);
arm64_l_504:
	/* 0x504: cmp w9, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_508:
	/* 0x508: mov x10, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_50c:
	/* 0x50c: b.eq 9f8 <generic_retuprobe_filter_arg+0x9f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x50c, 0x9f8, arm64_l_9f8);
arm64_l_510:
	/* 0x510: b 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JMP(0x510, 0x1ce4, arm64_l_1ce4);
arm64_l_514:
	/* 0x514: lsl x10, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_518:
	/* 0x518: tst x10, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_51c:
	/* 0x51c: b.ne 990 <generic_retuprobe_filter_arg+0x990> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x51c, 0x990, arm64_l_990);
arm64_l_520:
	/* 0x520: lsl x10, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_524:
	/* 0x524: tst x10, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_528:
	/* 0x528: b.eq c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x528, 0xc4, arm64_l_c4);
arm64_l_52c:
	/* 0x52c: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_530:
	/* 0x530: b.ne f14 <generic_retuprobe_filter_arg+0xf14> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x530, 0xf14, arm64_l_f14);
arm64_l_534:
	/* 0x534: ldp w11, w10, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_538:
	/* 0x538: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_53c:
	/* 0x53c: b.hi 1a44 <generic_retuprobe_filter_arg+0x1a44> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x53c, 0x1a44, arm64_l_1a44);
arm64_l_540:
	/* 0x540: lsl w8, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_544:
	/* 0x544: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_548:
	/* 0x548: tst w8, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_54c:
	/* 0x54c: b.eq 1a44 <generic_retuprobe_filter_arg+0x1a44> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x54c, 0x1a44, arm64_l_1a44);
arm64_l_550:
	/* 0x550: ldr w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_554:
	/* 0x554: cmp w11, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_558:
	/* 0x558: b.gt 1a58 <generic_retuprobe_filter_arg+0x1a58> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x558, 0x1a58, arm64_l_1a58);
arm64_l_55c:
	/* 0x55c: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_560:
	/* 0x560: b.le 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x560, 0x140, arm64_l_140);
arm64_l_564:
	/* 0x564: b 1a58 <generic_retuprobe_filter_arg+0x1a58> */
	ARM64_SIM_A64_JMP(0x564, 0x1a58, arm64_l_1a58);
arm64_l_568:
	/* 0x568: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_56c:
	/* 0x56c: b.gt a6c <generic_retuprobe_filter_arg+0xa6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x56c, 0xa6c, arm64_l_a6c);
arm64_l_570:
	/* 0x570: cmp w8, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_574:
	/* 0x574: b.eq bb0 <generic_retuprobe_filter_arg+0xbb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x574, 0xbb0, arm64_l_bb0);
arm64_l_578:
	/* 0x578: cmp w8, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_57c:
	/* 0x57c: b.ne 1d18 <generic_retuprobe_filter_arg+0x1d18> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x57c, 0x1d18, arm64_l_1d18);
arm64_l_580:
	/* 0x580: ldr w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_584:
	/* 0x584: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_588:
	/* 0x588: adrp x0, 0 <string_postfix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_20));
arm64_l_58c:
	/* 0x58c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_590:
	/* 0x590: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_594:
	/* 0x594: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_598:
	/* 0x598: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_59c:
	/* 0x59c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_5a0:
	/* 0x5a0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x5a4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_5a4:
	/* 0x5a4: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5a8:
	/* 0x5a8: cbz w29, 1314 <generic_retuprobe_filter_arg+0x1314> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x5a8, 0x1314, arm64_l_1314);
arm64_l_5ac:
	/* 0x5ac: cbz x0, 1314 <generic_retuprobe_filter_arg+0x1314> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x5ac, 0x1314, arm64_l_1314);
arm64_l_5b0:
	/* 0x5b0: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5b4:
	/* 0x5b4: adrp x0, 0 <string_postfix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap_21));
arm64_l_5b8:
	/* 0x5b8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_5bc:
	/* 0x5bc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_5c0:
	/* 0x5c0: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_5c4:
	/* 0x5c4: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_5c8:
	/* 0x5c8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x5ccULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_5cc:
	/* 0x5cc: cbz x0, 130c <generic_retuprobe_filter_arg+0x130c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x5cc, 0x130c, arm64_l_130c);
arm64_l_5d0:
	/* 0x5d0: cmp w29, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_5d4:
	/* 0x5d4: mov w9, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_5d8:
	/* 0x5d8: mov w11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_5dc:
	/* 0x5dc: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5e0:
	/* 0x5e0: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5e4:
	/* 0x5e4: sub w12, w29, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_5e8:
	/* 0x5e8: sub w13, w29, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_5ec:
	/* 0x5ec: csel w9, w29, w9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X9, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_5f0:
	/* 0x5f0: sub x11, x11, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_5f4:
	/* 0x5f4: lsl w10, w9, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_5f8:
	/* 0x5f8: mov x9, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5fc:
	/* 0x5fc: str w10, [x9], #5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 5ULL);
arm64_l_600:
	/* 0x600: neg x10, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_604:
	/* 0x604: add w14, w13, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X13, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_608:
	/* 0x608: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_60c:
	/* 0x60c: and x14, x14, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_610:
	/* 0x610: ldrb w14, [x25, x14] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X14, ARM64_X25, ARM64_X14, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X14, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_614:
	/* 0x614: sturb w14, [x9, #-1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 18446744073709551615ULL);
arm64_l_618:
	/* 0x618: b.eq 640 <generic_retuprobe_filter_arg+0x640> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x618, 0x640, arm64_l_640);
arm64_l_61c:
	/* 0x61c: cmn x8, #0x7e */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 126ULL);
arm64_l_620:
	/* 0x620: b.eq 640 <generic_retuprobe_filter_arg+0x640> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x620, 0x640, arm64_l_640);
arm64_l_624:
	/* 0x624: add w14, w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_628:
	/* 0x628: sub x8, x8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_62c:
	/* 0x62c: and x14, x14, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_630:
	/* 0x630: cmp x10, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_634:
	/* 0x634: ldrb w14, [x25, x14] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X14, ARM64_X25, ARM64_X14, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X14, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_638:
	/* 0x638: strb w14, [x9], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_63c:
	/* 0x63c: b.ne 604 <generic_retuprobe_filter_arg+0x604> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x63c, 0x604, arm64_l_604);
arm64_l_640:
	/* 0x640: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_644:
	/* 0x644: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_648:
	/* 0x648: b c38 <generic_retuprobe_filter_arg+0xc38> */
	ARM64_SIM_A64_JMP(0x648, 0xc38, arm64_l_c38);
arm64_l_64c:
	/* 0x64c: sub w8, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_650:
	/* 0x650: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_654:
	/* 0x654: b.cs 664 <generic_retuprobe_filter_arg+0x664> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x654, 0x664, arm64_l_664);
arm64_l_658:
	/* 0x658: cmp w29, #0x1, lsl #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_65c:
	/* 0x65c: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_660:
	/* 0x660: b.ls da8 <generic_retuprobe_filter_arg+0xda8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x660, 0xda8, arm64_l_da8);
arm64_l_664:
	/* 0x664: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_668:
	/* 0x668: b 2d2c <generic_retuprobe_filter_arg+0x2d2c> */
	ARM64_SIM_A64_JMP(0x668, 0x2d2c, arm64_l_2d2c);
arm64_l_66c:
	/* 0x66c: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_670:
	/* 0x670: b.hi c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x670, 0xc4, arm64_l_c4);
arm64_l_674:
	/* 0x674: lsl x9, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_678:
	/* 0x678: mov w10, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_67c:
	/* 0x67c: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_680:
	/* 0x680: b.eq ce4 <generic_retuprobe_filter_arg+0xce4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x680, 0xce4, arm64_l_ce4);
arm64_l_684:
	/* 0x684: ldr w9, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_688:
	/* 0x688: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_68c:
	/* 0x68c: b.le 1250 <generic_retuprobe_filter_arg+0x1250> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x68c, 0x1250, arm64_l_1250);
arm64_l_690:
	/* 0x690: sub w10, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_694:
	/* 0x694: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_698:
	/* 0x698: b.cs 185c <generic_retuprobe_filter_arg+0x185c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x698, 0x185c, arm64_l_185c);
arm64_l_69c:
	/* 0x69c: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6a0:
	/* 0x6a0: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_6a4:
	/* 0x6a4: b.ne 1a10 <generic_retuprobe_filter_arg+0x1a10> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x6a4, 0x1a10, arm64_l_1a10);
arm64_l_6a8:
	/* 0x6a8: b 31dc <generic_retuprobe_filter_arg+0x31dc> */
	ARM64_SIM_A64_JMP(0x6a8, 0x31dc, arm64_l_31dc);
arm64_l_6ac:
	/* 0x6ac: ldr w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_6b0:
	/* 0x6b0: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_6b4:
	/* 0x6b4: adrp x0, 0 <string_postfix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_20));
arm64_l_6b8:
	/* 0x6b8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_6bc:
	/* 0x6bc: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_6c0:
	/* 0x6c0: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_6c4:
	/* 0x6c4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_6c8:
	/* 0x6c8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6cc:
	/* 0x6cc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x6d0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_6d0:
	/* 0x6d0: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6d4:
	/* 0x6d4: cbz w29, 2d20 <generic_retuprobe_filter_arg+0x2d20> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x6d4, 0x2d20, arm64_l_2d20);
arm64_l_6d8:
	/* 0x6d8: cbz x0, 2d20 <generic_retuprobe_filter_arg+0x2d20> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x6d8, 0x2d20, arm64_l_2d20);
arm64_l_6dc:
	/* 0x6dc: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6e0:
	/* 0x6e0: adrp x0, 0 <string_postfix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap_21));
arm64_l_6e4:
	/* 0x6e4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_6e8:
	/* 0x6e8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6ec:
	/* 0x6ec: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_6f0:
	/* 0x6f0: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_6f4:
	/* 0x6f4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x6f8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_6f8:
	/* 0x6f8: cbz x0, 18c4 <generic_retuprobe_filter_arg+0x18c4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x6f8, 0x18c4, arm64_l_18c4);
arm64_l_6fc:
	/* 0x6fc: cmp w29, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_700:
	/* 0x700: mov w10, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_704:
	/* 0x704: mov w12, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_708:
	/* 0x708: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_70c:
	/* 0x70c: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_710:
	/* 0x710: add x9, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_714:
	/* 0x714: sub w13, w29, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_718:
	/* 0x718: sub w14, w29, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_71c:
	/* 0x71c: csel w10, w29, w10, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X10, ARM64_X29, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_720:
	/* 0x720: sub x12, x12, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X12, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_724:
	/* 0x724: lsl w11, w10, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_728:
	/* 0x728: mov x10, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_72c:
	/* 0x72c: str w11, [x10], #5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 5ULL);
arm64_l_730:
	/* 0x730: neg x11, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_734:
	/* 0x734: add w15, w14, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X15, ARM64_X14, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_738:
	/* 0x738: cmp x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_73c:
	/* 0x73c: and x15, x15, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_740:
	/* 0x740: ldrb w15, [x9, x15] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X15, ARM64_X9, ARM64_X15, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X15, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_744:
	/* 0x744: sturb w15, [x10, #-1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X10, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 18446744073709551615ULL);
arm64_l_748:
	/* 0x748: b.eq 770 <generic_retuprobe_filter_arg+0x770> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x748, 0x770, arm64_l_770);
arm64_l_74c:
	/* 0x74c: cmn x8, #0x7e */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 126ULL);
arm64_l_750:
	/* 0x750: b.eq 770 <generic_retuprobe_filter_arg+0x770> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x750, 0x770, arm64_l_770);
arm64_l_754:
	/* 0x754: add w15, w13, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X15, ARM64_X13, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_758:
	/* 0x758: sub x8, x8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_75c:
	/* 0x75c: and x15, x15, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_760:
	/* 0x760: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_764:
	/* 0x764: ldrb w15, [x9, x15] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X15, ARM64_X9, ARM64_X15, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X15, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_768:
	/* 0x768: strb w15, [x10], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X10, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_76c:
	/* 0x76c: b.ne 734 <generic_retuprobe_filter_arg+0x734> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x76c, 0x734, arm64_l_734);
arm64_l_770:
	/* 0x770: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_774:
	/* 0x774: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_778:
	/* 0x778: b 804 <generic_retuprobe_filter_arg+0x804> */
	ARM64_SIM_A64_JMP(0x778, 0x804, arm64_l_804);
arm64_l_77c:
	/* 0x77c: ldr w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_780:
	/* 0x780: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_784:
	/* 0x784: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_22));
arm64_l_788:
	/* 0x788: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_78c:
	/* 0x78c: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_790:
	/* 0x790: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_794:
	/* 0x794: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_798:
	/* 0x798: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_79c:
	/* 0x79c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x7a0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_7a0:
	/* 0x7a0: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7a4:
	/* 0x7a4: cbz w29, 2d20 <generic_retuprobe_filter_arg+0x2d20> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x7a4, 0x2d20, arm64_l_2d20);
arm64_l_7a8:
	/* 0x7a8: cbz x0, 2d20 <generic_retuprobe_filter_arg+0x2d20> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x7a8, 0x2d20, arm64_l_2d20);
arm64_l_7ac:
	/* 0x7ac: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7b0:
	/* 0x7b0: adrp x0, 0 <string_prefix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap_23));
arm64_l_7b4:
	/* 0x7b4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_7b8:
	/* 0x7b8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_7bc:
	/* 0x7bc: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_7c0:
	/* 0x7c0: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_7c4:
	/* 0x7c4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x7c8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_7c8:
	/* 0x7c8: cbz x0, 18c4 <generic_retuprobe_filter_arg+0x18c4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x7c8, 0x18c4, arm64_l_18c4);
arm64_l_7cc:
	/* 0x7cc: cmp w29, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_7d0:
	/* 0x7d0: mov w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 255ULL);
arm64_l_7d4:
	/* 0x7d4: add x2, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_7d8:
	/* 0x7d8: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7dc:
	/* 0x7dc: csel w1, w29, w8, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X1, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_7e0:
	/* 0x7e0: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7e4:
	/* 0x7e4: lsl w9, w1, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_7e8:
	/* 0x7e8: str w9, [x8], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_7ec:
	/* 0x7ec: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_7f0:
	/* 0x7f0: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7f4:
	/* 0x7f4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x7f8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_7f8:
	/* 0x7f8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_7fc:
	/* 0x7fc: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_800:
	/* 0x800: mov x1, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_804:
	/* 0x804: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x808ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_808:
	/* 0x808: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_80c:
	/* 0x80c: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_810:
	/* 0x810: b 18c8 <generic_retuprobe_filter_arg+0x18c8> */
	ARM64_SIM_A64_JMP(0x810, 0x18c8, arm64_l_18c8);
arm64_l_814:
	/* 0x814: sub w10, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_818:
	/* 0x818: cmp w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_81c:
	/* 0x81c: b.cc 8b0 <generic_retuprobe_filter_arg+0x8b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x81c, 0x8b0, arm64_l_8b0);
arm64_l_820:
	/* 0x820: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x820, 0xc4, arm64_l_c4);
arm64_l_824:
	/* 0x824: add x29, x25, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_828:
	/* 0x828: ldr w25, [x25, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_82c:
	/* 0x82c: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_830:
	/* 0x830: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_834:
	/* 0x834: b.gt e18 <generic_retuprobe_filter_arg+0xe18> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x834, 0xe18, arm64_l_e18);
arm64_l_838:
	/* 0x838: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_83c:
	/* 0x83c: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_840:
	/* 0x840: b.cc 1658 <generic_retuprobe_filter_arg+0x1658> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x840, 0x1658, arm64_l_1658);
arm64_l_844:
	/* 0x844: cmp w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_848:
	/* 0x848: b.eq 15cc <generic_retuprobe_filter_arg+0x15cc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x848, 0x15cc, arm64_l_15cc);
arm64_l_84c:
	/* 0x84c: cmp w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_850:
	/* 0x850: b.eq e30 <generic_retuprobe_filter_arg+0xe30> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x850, 0xe30, arm64_l_e30);
arm64_l_854:
	/* 0x854: b 32c4 <generic_retuprobe_filter_arg+0x32c4> */
	ARM64_SIM_A64_JMP(0x854, 0x32c4, arm64_l_32c4);
arm64_l_858:
	/* 0x858: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_85c:
	/* 0x85c: b.eq 1080 <generic_retuprobe_filter_arg+0x1080> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x85c, 0x1080, arm64_l_1080);
arm64_l_860:
	/* 0x860: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_864:
	/* 0x864: b.ne 1df4 <generic_retuprobe_filter_arg+0x1df4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x864, 0x1df4, arm64_l_1df4);
arm64_l_868:
	/* 0x868: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_86c:
	/* 0x86c: b.hi 1de8 <generic_retuprobe_filter_arg+0x1de8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x86c, 0x1de8, arm64_l_1de8);
arm64_l_870:
	/* 0x870: lsl w11, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X11, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_874:
	/* 0x874: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_878:
	/* 0x878: tst w11, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X11, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_87c:
	/* 0x87c: b.eq 1de8 <generic_retuprobe_filter_arg+0x1de8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x87c, 0x1de8, arm64_l_1de8);
arm64_l_880:
	/* 0x880: ldr w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_884:
	/* 0x884: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_888:
	/* 0x888: b.lt 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x888, 0x140, arm64_l_140);
arm64_l_88c:
	/* 0x88c: b 1df4 <generic_retuprobe_filter_arg+0x1df4> */
	ARM64_SIM_A64_JMP(0x88c, 0x1df4, arm64_l_1df4);
arm64_l_890:
	/* 0x890: cmp w9, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_894:
	/* 0x894: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x894, 0x140, arm64_l_140);
arm64_l_898:
	/* 0x898: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_89c:
	/* 0x89c: b.hi c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x89c, 0xc4, arm64_l_c4);
arm64_l_8a0:
	/* 0x8a0: lsl x10, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_8a4:
	/* 0x8a4: mov w11, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_8a8:
	/* 0x8a8: tst x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8ac:
	/* 0x8ac: b.eq 8d8 <generic_retuprobe_filter_arg+0x8d8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x8ac, 0x8d8, arm64_l_8d8);
arm64_l_8b0:
	/* 0x8b0: ldr x10, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_8b4:
	/* 0x8b4: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_8b8:
	/* 0x8b8: b.le 8f4 <generic_retuprobe_filter_arg+0x8f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x8b8, 0x8f4, arm64_l_8f4);
arm64_l_8bc:
	/* 0x8bc: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_8c0:
	/* 0x8c0: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_8c4:
	/* 0x8c4: b.cs b58 <generic_retuprobe_filter_arg+0xb58> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x8c4, 0xb58, arm64_l_b58);
arm64_l_8c8:
	/* 0x8c8: ldr x11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_8cc:
	/* 0x8cc: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8d0:
	/* 0x8d0: b.ne 17b8 <generic_retuprobe_filter_arg+0x17b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x8d0, 0x17b8, arm64_l_17b8);
arm64_l_8d4:
	/* 0x8d4: b 31dc <generic_retuprobe_filter_arg+0x31dc> */
	ARM64_SIM_A64_JMP(0x8d4, 0x31dc, arm64_l_31dc);
arm64_l_8d8:
	/* 0x8d8: lsl x10, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_8dc:
	/* 0x8dc: tst x10, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_8e0:
	/* 0x8e0: b.ne 924 <generic_retuprobe_filter_arg+0x924> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x8e0, 0x924, arm64_l_924);
arm64_l_8e4:
	/* 0x8e4: lsl x10, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_8e8:
	/* 0x8e8: tst x10, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_8ec:
	/* 0x8ec: b.ne b7c <generic_retuprobe_filter_arg+0xb7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x8ec, 0xb7c, arm64_l_b7c);
arm64_l_8f0:
	/* 0x8f0: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x8f0, 0xc4, arm64_l_c4);
arm64_l_8f4:
	/* 0x8f4: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_8f8:
	/* 0x8f8: b.eq d88 <generic_retuprobe_filter_arg+0xd88> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x8f8, 0xd88, arm64_l_d88);
arm64_l_8fc:
	/* 0x8fc: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_900:
	/* 0x900: b.ne 17b8 <generic_retuprobe_filter_arg+0x17b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x900, 0x17b8, arm64_l_17b8);
arm64_l_904:
	/* 0x904: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_908:
	/* 0x908: b.eq 914 <generic_retuprobe_filter_arg+0x914> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x908, 0x914, arm64_l_914);
arm64_l_90c:
	/* 0x90c: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_910:
	/* 0x910: b.ne 17ac <generic_retuprobe_filter_arg+0x17ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x910, 0x17ac, arm64_l_17ac);
arm64_l_914:
	/* 0x914: ldr x11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_918:
	/* 0x918: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_91c:
	/* 0x91c: b.lt 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x91c, 0x140, arm64_l_140);
arm64_l_920:
	/* 0x920: b 17b8 <generic_retuprobe_filter_arg+0x17b8> */
	ARM64_SIM_A64_JMP(0x920, 0x17b8, arm64_l_17b8);
arm64_l_924:
	/* 0x924: ldrb w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_928:
	/* 0x928: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_92c:
	/* 0x92c: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_930:
	/* 0x930: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_934:
	/* 0x934: str w8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_938:
	/* 0x938: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_93c:
	/* 0x93c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_940:
	/* 0x940: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x944ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_944:
	/* 0x944: cbz x0, efc <generic_retuprobe_filter_arg+0xefc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x944, 0xefc, arm64_l_efc);
arm64_l_948:
	/* 0x948: ldr x8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_94c:
	/* 0x94c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_950:
	/* 0x950: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_954:
	/* 0x954: str x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_958:
	/* 0x958: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_95c:
	/* 0x95c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x960ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_960:
	/* 0x960: ldr w8, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_964:
	/* 0x964: cmp w8, #0xb */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 11ULL);
arm64_l_968:
	/* 0x968: b.eq 1324 <generic_retuprobe_filter_arg+0x1324> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x968, 0x1324, arm64_l_1324);
arm64_l_96c:
	/* 0x96c: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_970:
	/* 0x970: cmp w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_974:
	/* 0x974: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_978:
	/* 0x978: b.eq 13c8 <generic_retuprobe_filter_arg+0x13c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x978, 0x13c8, arm64_l_13c8);
arm64_l_97c:
	/* 0x97c: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_980:
	/* 0x980: mov w22, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_984:
	/* 0x984: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_988:
	/* 0x988: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x988, 0x140, arm64_l_140);
arm64_l_98c:
	/* 0x98c: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x98c, 0xc4, arm64_l_c4);
arm64_l_990:
	/* 0x990: ldrb w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_994:
	/* 0x994: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_998:
	/* 0x998: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_99c:
	/* 0x99c: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_9a0:
	/* 0x9a0: str w8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_9a4:
	/* 0x9a4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_9a8:
	/* 0x9a8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_9ac:
	/* 0x9ac: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x9b0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_9b0:
	/* 0x9b0: cbz x0, 1cd4 <generic_retuprobe_filter_arg+0x1cd4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x9b0, 0x1cd4, arm64_l_1cd4);
arm64_l_9b4:
	/* 0x9b4: ldr w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_9b8:
	/* 0x9b8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_9bc:
	/* 0x9bc: str x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_9c0:
	/* 0x9c0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_9c4:
	/* 0x9c4: b 12dc <generic_retuprobe_filter_arg+0x12dc> */
	ARM64_SIM_A64_JMP(0x9c4, 0x12dc, arm64_l_12dc);
arm64_l_9c8:
	/* 0x9c8: mov x10, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_9cc:
	/* 0x9cc: b 9f8 <generic_retuprobe_filter_arg+0x9f8> */
	ARM64_SIM_A64_JMP(0x9cc, 0x9f8, arm64_l_9f8);
arm64_l_9d0:
	/* 0x9d0: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_9d4:
	/* 0x9d4: mov x10, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_9d8:
	/* 0x9d8: strh w11, [sp, #134] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 134ULL);
arm64_l_9dc:
	/* 0x9dc: ldrh w11, [x25, #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_9e0:
	/* 0x9e0: strh w11, [sp, #128] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 128ULL);
arm64_l_9e4:
	/* 0x9e4: ldr x11, [x25, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_9e8:
	/* 0x9e8: str x11, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_9ec:
	/* 0x9ec: ldr x11, [x25, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_9f0:
	/* 0x9f0: add x25, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_9f4:
	/* 0x9f4: str x11, [sp, #104] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_9f8:
	/* 0x9f8: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_9fc:
	/* 0x9fc: cmp w8, #0x13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 19ULL);
arm64_l_a00:
	/* 0xa00: b.le a28 <generic_retuprobe_filter_arg+0xa28> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xa00, 0xa28, arm64_l_a28);
arm64_l_a04:
	/* 0xa04: cmp w8, #0x17 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 23ULL);
arm64_l_a08:
	/* 0xa08: b.gt a50 <generic_retuprobe_filter_arg+0xa50> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xa08, 0xa50, arm64_l_a50);
arm64_l_a0c:
	/* 0xa0c: sub w9, w8, #0x14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_a10:
	/* 0xa10: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_a14:
	/* 0xa14: b.cc f80 <generic_retuprobe_filter_arg+0xf80> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xa14, 0xf80, arm64_l_f80);
arm64_l_a18:
	/* 0xa18: sub w9, w8, #0x16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 22ULL);
arm64_l_a1c:
	/* 0xa1c: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_a20:
	/* 0xa20: b.cc f6c <generic_retuprobe_filter_arg+0xf6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xa20, 0xf6c, arm64_l_f6c);
arm64_l_a24:
	/* 0xa24: b 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JMP(0xa24, 0x1ce4, arm64_l_1ce4);
arm64_l_a28:
	/* 0xa28: cmp w8, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_a2c:
	/* 0xa2c: b.le c5c <generic_retuprobe_filter_arg+0xc5c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xa2c, 0xc5c, arm64_l_c5c);
arm64_l_a30:
	/* 0xa30: cmp w8, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_a34:
	/* 0xa34: b.gt f5c <generic_retuprobe_filter_arg+0xf5c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xa34, 0xf5c, arm64_l_f5c);
arm64_l_a38:
	/* 0xa38: cmp w8, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_a3c:
	/* 0xa3c: b.eq f6c <generic_retuprobe_filter_arg+0xf6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xa3c, 0xf6c, arm64_l_f6c);
arm64_l_a40:
	/* 0xa40: cmp w8, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_a44:
	/* 0xa44: b.ne 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xa44, 0x1ce4, arm64_l_1ce4);
arm64_l_a48:
	/* 0xa48: ldrh w22, [x25, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_a4c:
	/* 0xa4c: b 16fc <generic_retuprobe_filter_arg+0x16fc> */
	ARM64_SIM_A64_JMP(0xa4c, 0x16fc, arm64_l_16fc);
arm64_l_a50:
	/* 0xa50: cmp w8, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_a54:
	/* 0xa54: b.gt f94 <generic_retuprobe_filter_arg+0xf94> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xa54, 0xf94, arm64_l_f94);
arm64_l_a58:
	/* 0xa58: cmp w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_a5c:
	/* 0xa5c: b.eq fc4 <generic_retuprobe_filter_arg+0xfc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xa5c, 0xfc4, arm64_l_fc4);
arm64_l_a60:
	/* 0xa60: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_a64:
	/* 0xa64: b.eq fb8 <generic_retuprobe_filter_arg+0xfb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xa64, 0xfb8, arm64_l_fb8);
arm64_l_a68:
	/* 0xa68: b 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JMP(0xa68, 0x1ce4, arm64_l_1ce4);
arm64_l_a6c:
	/* 0xa6c: cmp w8, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_a70:
	/* 0xa70: b.eq 10a8 <generic_retuprobe_filter_arg+0x10a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xa70, 0x10a8, arm64_l_10a8);
arm64_l_a74:
	/* 0xa74: cmp w8, #0x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 34ULL);
arm64_l_a78:
	/* 0xa78: b.ne 1d18 <generic_retuprobe_filter_arg+0x1d18> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xa78, 0x1d18, arm64_l_1d18);
arm64_l_a7c:
	/* 0xa7c: str x23, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_a80:
	/* 0xa80: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a84:
	/* 0xa84: mov w23, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_a88:
	/* 0xa88: add x19, x21, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_a8c:
	/* 0xa8c: ldr w8, [x19, x22, lsl #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X22, ARM64_MOD_LSL, 2, 0), 0ULL);
arm64_l_a90:
	/* 0xa90: adrp x0, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_24));
arm64_l_a94:
	/* 0xa94: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_a98:
	/* 0xa98: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_a9c:
	/* 0xa9c: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_aa0:
	/* 0xaa0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_aa4:
	/* 0xaa4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_aa8:
	/* 0xaa8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xaacULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_aac:
	/* 0xaac: cbz x0, 1d00 <generic_retuprobe_filter_arg+0x1d00> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xaac, 0x1d00, arm64_l_1d00);
arm64_l_ab0:
	/* 0xab0: ldr x16, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_ab4:
	/* 0xab4: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ab8:
	/* 0xab8: cbz w29, b34 <generic_retuprobe_filter_arg+0xb34> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0xab8, 0xb34, arm64_l_b34);
arm64_l_abc:
	/* 0xabc: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ac0:
	/* 0xac0: mov x9, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ac4:
	/* 0xac4: mov x10, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ac8:
	/* 0xac8: b ae0 <generic_retuprobe_filter_arg+0xae0> */
	ARM64_SIM_A64_JMP(0xac8, 0xae0, arm64_l_ae0);
arm64_l_acc:
	/* 0xacc: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_ad0:
	/* 0xad0: sub x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_ad4:
	/* 0xad4: add x9, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_ad8:
	/* 0xad8: cmp x8, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_adc:
	/* 0xadc: b.eq b34 <generic_retuprobe_filter_arg+0xb34> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xadc, 0xb34, arm64_l_b34);
arm64_l_ae0:
	/* 0xae0: mov x11, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ae4:
	/* 0xae4: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ae8:
	/* 0xae8: b.eq acc <generic_retuprobe_filter_arg+0xacc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xae8, 0xacc, arm64_l_acc);
arm64_l_aec:
	/* 0xaec: ldrb w12, [x0, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X0, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_af0:
	/* 0xaf0: cbz w12, b30 <generic_retuprobe_filter_arg+0xb30> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0xaf0, 0xb30, arm64_l_b30);
arm64_l_af4:
	/* 0xaf4: ldrb w13, [x9, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_af8:
	/* 0xaf8: sub w14, w13, #0x41 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 65ULL);
arm64_l_afc:
	/* 0xafc: orr w15, w13, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_b00:
	/* 0xb00: cmp w14, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_b04:
	/* 0xb04: sub w14, w12, #0x41 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 65ULL);
arm64_l_b08:
	/* 0xb08: csel w13, w15, w13, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X13, ARM64_X15, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_b0c:
	/* 0xb0c: orr w15, w12, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_b10:
	/* 0xb10: cmp w14, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_b14:
	/* 0xb14: csel w12, w15, w12, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X12, ARM64_X15, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_b18:
	/* 0xb18: cmp x11, #0x62 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 98ULL);
arm64_l_b1c:
	/* 0xb1c: b.hi acc <generic_retuprobe_filter_arg+0xacc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xb1c, 0xacc, arm64_l_acc);
arm64_l_b20:
	/* 0xb20: add x11, x11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_b24:
	/* 0xb24: cmp w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_b28:
	/* 0xb28: b.eq ae4 <generic_retuprobe_filter_arg+0xae4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xb28, 0xae4, arm64_l_ae4);
arm64_l_b2c:
	/* 0xb2c: b acc <generic_retuprobe_filter_arg+0xacc> */
	ARM64_SIM_A64_JMP(0xb2c, 0xacc, arm64_l_acc);
arm64_l_b30:
	/* 0xb30: tbz w8, #31, 19bc <generic_retuprobe_filter_arg+0x19bc> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 31, 0xb30, 0x19bc, arm64_l_19bc);
arm64_l_b34:
	/* 0xb34: ldr w9, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_b38:
	/* 0xb38: add w8, w23, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_b3c:
	/* 0xb3c: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_b40:
	/* 0xb40: b.cs 1170 <generic_retuprobe_filter_arg+0x1170> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xb40, 0x1170, arm64_l_1170);
arm64_l_b44:
	/* 0xb44: add x22, x22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_b48:
	/* 0xb48: add w23, w23, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_b4c:
	/* 0xb4c: cmp x22, #0x64 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 100ULL);
arm64_l_b50:
	/* 0xb50: b.ne a8c <generic_retuprobe_filter_arg+0xa8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xb50, 0xa8c, arm64_l_a8c);
arm64_l_b54:
	/* 0xb54: b 1170 <generic_retuprobe_filter_arg+0x1170> */
	ARM64_SIM_A64_JMP(0xb54, 0x1170, arm64_l_1170);
arm64_l_b58:
	/* 0xb58: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_b5c:
	/* 0xb5c: b.ne 17b8 <generic_retuprobe_filter_arg+0x17b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xb5c, 0x17b8, arm64_l_17b8);
arm64_l_b60:
	/* 0xb60: ldr x11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b64:
	/* 0xb64: tst x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_b68:
	/* 0xb68: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xb68, 0x140, arm64_l_140);
arm64_l_b6c:
	/* 0xb6c: b 17b8 <generic_retuprobe_filter_arg+0x17b8> */
	ARM64_SIM_A64_JMP(0xb6c, 0x17b8, arm64_l_17b8);
arm64_l_b70:
	/* 0xb70: sub w10, w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_b74:
	/* 0xb74: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_b78:
	/* 0xb78: b.cs 13f4 <generic_retuprobe_filter_arg+0x13f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xb78, 0x13f4, arm64_l_13f4);
arm64_l_b7c:
	/* 0xb7c: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_b80:
	/* 0xb80: b.ne c78 <generic_retuprobe_filter_arg+0xc78> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xb80, 0xc78, arm64_l_c78);
arm64_l_b84:
	/* 0xb84: ldp x11, x10, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_b88:
	/* 0xb88: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_b8c:
	/* 0xb8c: b.eq b98 <generic_retuprobe_filter_arg+0xb98> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xb8c, 0xb98, arm64_l_b98);
arm64_l_b90:
	/* 0xb90: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_b94:
	/* 0xb94: b.ne 166c <generic_retuprobe_filter_arg+0x166c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xb94, 0x166c, arm64_l_166c);
arm64_l_b98:
	/* 0xb98: ldr x8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b9c:
	/* 0xb9c: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ba0:
	/* 0xba0: b.gt 1680 <generic_retuprobe_filter_arg+0x1680> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xba0, 0x1680, arm64_l_1680);
arm64_l_ba4:
	/* 0xba4: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ba8:
	/* 0xba8: b.le 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xba8, 0x140, arm64_l_140);
arm64_l_bac:
	/* 0xbac: b 1680 <generic_retuprobe_filter_arg+0x1680> */
	ARM64_SIM_A64_JMP(0xbac, 0x1680, arm64_l_1680);
arm64_l_bb0:
	/* 0xbb0: ldr w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_bb4:
	/* 0xbb4: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_bb8:
	/* 0xbb8: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_22));
arm64_l_bbc:
	/* 0xbbc: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_bc0:
	/* 0xbc0: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_bc4:
	/* 0xbc4: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_bc8:
	/* 0xbc8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_bcc:
	/* 0xbcc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_bd0:
	/* 0xbd0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xbd4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_bd4:
	/* 0xbd4: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_bd8:
	/* 0xbd8: cbz w29, 1314 <generic_retuprobe_filter_arg+0x1314> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0xbd8, 0x1314, arm64_l_1314);
arm64_l_bdc:
	/* 0xbdc: cbz x0, 1314 <generic_retuprobe_filter_arg+0x1314> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xbdc, 0x1314, arm64_l_1314);
arm64_l_be0:
	/* 0xbe0: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_be4:
	/* 0xbe4: adrp x0, 0 <string_prefix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap_23));
arm64_l_be8:
	/* 0xbe8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_bec:
	/* 0xbec: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_bf0:
	/* 0xbf0: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_bf4:
	/* 0xbf4: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_bf8:
	/* 0xbf8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xbfcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_bfc:
	/* 0xbfc: cbz x0, 130c <generic_retuprobe_filter_arg+0x130c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xbfc, 0x130c, arm64_l_130c);
arm64_l_c00:
	/* 0xc00: cmp w29, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_c04:
	/* 0xc04: mov w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 255ULL);
arm64_l_c08:
	/* 0xc08: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c0c:
	/* 0xc0c: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c10:
	/* 0xc10: csel w1, w29, w8, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X1, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_c14:
	/* 0xc14: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c18:
	/* 0xc18: lsl w9, w1, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_c1c:
	/* 0xc1c: str w9, [x8], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_c20:
	/* 0xc20: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_c24:
	/* 0xc24: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c28:
	/* 0xc28: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xc2cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_c2c:
	/* 0xc2c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_c30:
	/* 0xc30: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c34:
	/* 0xc34: mov x1, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c38:
	/* 0xc38: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xc3cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_c3c:
	/* 0xc3c: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_c40:
	/* 0xc40: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_c44:
	/* 0xc44: b 1310 <generic_retuprobe_filter_arg+0x1310> */
	ARM64_SIM_A64_JMP(0xc44, 0x1310, arm64_l_1310);
arm64_l_c48:
	/* 0xc48: cmp w29, #0x1, lsl #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_c4c:
	/* 0xc4c: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_c50:
	/* 0xc50: b.ls 1178 <generic_retuprobe_filter_arg+0x1178> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0xc50, 0x1178, arm64_l_1178);
arm64_l_c54:
	/* 0xc54: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c58:
	/* 0xc58: b 1d18 <generic_retuprobe_filter_arg+0x1d18> */
	ARM64_SIM_A64_JMP(0xc58, 0x1d18, arm64_l_1d18);
arm64_l_c5c:
	/* 0xc5c: cmp w8, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_c60:
	/* 0xc60: b.eq fc4 <generic_retuprobe_filter_arg+0xfc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xc60, 0xfc4, arm64_l_fc4);
arm64_l_c64:
	/* 0xc64: cmp w8, #0xe */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 14ULL);
arm64_l_c68:
	/* 0xc68: b.eq fb8 <generic_retuprobe_filter_arg+0xfb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xc68, 0xfb8, arm64_l_fb8);
arm64_l_c6c:
	/* 0xc6c: cmp w8, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_c70:
	/* 0xc70: b.eq f80 <generic_retuprobe_filter_arg+0xf80> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xc70, 0xf80, arm64_l_f80);
arm64_l_c74:
	/* 0xc74: b 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JMP(0xc74, 0x1ce4, arm64_l_1ce4);
arm64_l_c78:
	/* 0xc78: ldp x11, x8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_c7c:
	/* 0xc7c: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_c80:
	/* 0xc80: b.eq c8c <generic_retuprobe_filter_arg+0xc8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xc80, 0xc8c, arm64_l_c8c);
arm64_l_c84:
	/* 0xc84: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_c88:
	/* 0xc88: b.ne 16b8 <generic_retuprobe_filter_arg+0x16b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xc88, 0x16b8, arm64_l_16b8);
arm64_l_c8c:
	/* 0xc8c: ldr x10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c90:
	/* 0xc90: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_c94:
	/* 0xc94: ccmp x10, x8, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_c98:
	/* 0xc98: cset w8, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_c9c:
	/* 0xc9c: b 16c8 <generic_retuprobe_filter_arg+0x16c8> */
	ARM64_SIM_A64_JMP(0xc9c, 0x16c8, arm64_l_16c8);
arm64_l_ca0:
	/* 0xca0: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_ca4:
	/* 0xca4: b.ne 1df4 <generic_retuprobe_filter_arg+0x1df4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xca4, 0x1df4, arm64_l_1df4);
arm64_l_ca8:
	/* 0xca8: ldr w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cac:
	/* 0xcac: tst w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_cb0:
	/* 0xcb0: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xcb0, 0x140, arm64_l_140);
arm64_l_cb4:
	/* 0xcb4: b 1df4 <generic_retuprobe_filter_arg+0x1df4> */
	ARM64_SIM_A64_JMP(0xcb4, 0x1df4, arm64_l_1df4);
arm64_l_cb8:
	/* 0xcb8: lsl x9, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_cbc:
	/* 0xcbc: tst x9, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_cc0:
	/* 0xcc0: b.ne 1270 <generic_retuprobe_filter_arg+0x1270> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xcc0, 0x1270, arm64_l_1270);
arm64_l_cc4:
	/* 0xcc4: lsl x9, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_cc8:
	/* 0xcc8: tst x9, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_ccc:
	/* 0xccc: b.eq c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xccc, 0xc4, arm64_l_c4);
arm64_l_cd0:
	/* 0xcd0: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_cd4:
	/* 0xcd4: b.ne 18f4 <generic_retuprobe_filter_arg+0x18f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xcd4, 0x18f4, arm64_l_18f4);
arm64_l_cd8:
	/* 0xcd8: ldr w9, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_cdc:
	/* 0xcdc: ldrb w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ce0:
	/* 0xce0: b d0c <generic_retuprobe_filter_arg+0xd0c> */
	ARM64_SIM_A64_JMP(0xce0, 0xd0c, arm64_l_d0c);
arm64_l_ce4:
	/* 0xce4: lsl x9, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_ce8:
	/* 0xce8: tst x9, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_cec:
	/* 0xcec: b.ne 12a8 <generic_retuprobe_filter_arg+0x12a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xcec, 0x12a8, arm64_l_12a8);
arm64_l_cf0:
	/* 0xcf0: lsl x9, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_cf4:
	/* 0xcf4: tst x9, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_cf8:
	/* 0xcf8: b.eq c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xcf8, 0xc4, arm64_l_c4);
arm64_l_cfc:
	/* 0xcfc: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_d00:
	/* 0xd00: b.ne 1918 <generic_retuprobe_filter_arg+0x1918> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xd00, 0x1918, arm64_l_1918);
arm64_l_d04:
	/* 0xd04: ldr w9, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_d08:
	/* 0xd08: ldrh w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d0c:
	/* 0xd0c: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d10:
	/* 0xd10: b.hi d20 <generic_retuprobe_filter_arg+0xd20> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xd10, 0xd20, arm64_l_d20);
arm64_l_d14:
	/* 0xd14: ldr w9, [x21, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_d18:
	/* 0xd18: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d1c:
	/* 0xd1c: b.cs 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xd1c, 0x140, arm64_l_140);
arm64_l_d20:
	/* 0xd20: ldr w9, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_d24:
	/* 0xd24: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_d28:
	/* 0xd28: b.cc c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xd28, 0xc4, arm64_l_c4);
arm64_l_d2c:
	/* 0xd2c: ldr w10, [x21, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_d30:
	/* 0xd30: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d34:
	/* 0xd34: b.hi d44 <generic_retuprobe_filter_arg+0xd44> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xd34, 0xd44, arm64_l_d44);
arm64_l_d38:
	/* 0xd38: ldr w10, [x21, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_d3c:
	/* 0xd3c: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d40:
	/* 0xd40: b.cs 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xd40, 0x140, arm64_l_140);
arm64_l_d44:
	/* 0xd44: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_d48:
	/* 0xd48: b.cc c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xd48, 0xc4, arm64_l_c4);
arm64_l_d4c:
	/* 0xd4c: ldr w10, [x21, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_d50:
	/* 0xd50: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d54:
	/* 0xd54: b.hi d64 <generic_retuprobe_filter_arg+0xd64> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xd54, 0xd64, arm64_l_d64);
arm64_l_d58:
	/* 0xd58: ldr w10, [x21, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_d5c:
	/* 0xd5c: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d60:
	/* 0xd60: b.cs 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xd60, 0x140, arm64_l_140);
arm64_l_d64:
	/* 0xd64: cmp w9, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_d68:
	/* 0xd68: b.cc c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xd68, 0xc4, arm64_l_c4);
arm64_l_d6c:
	/* 0xd6c: ldr w9, [x21, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_d70:
	/* 0xd70: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d74:
	/* 0xd74: b.hi c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xd74, 0xc4, arm64_l_c4);
arm64_l_d78:
	/* 0xd78: ldr w9, [x21, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_d7c:
	/* 0xd7c: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d80:
	/* 0xd80: b.cs 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xd80, 0x140, arm64_l_140);
arm64_l_d84:
	/* 0xd84: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0xd84, 0xc4, arm64_l_c4);
arm64_l_d88:
	/* 0xd88: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_d8c:
	/* 0xd8c: b.eq d98 <generic_retuprobe_filter_arg+0xd98> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd8c, 0xd98, arm64_l_d98);
arm64_l_d90:
	/* 0xd90: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_d94:
	/* 0xd94: b.ne 179c <generic_retuprobe_filter_arg+0x179c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xd94, 0x179c, arm64_l_179c);
arm64_l_d98:
	/* 0xd98: ldr x11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d9c:
	/* 0xd9c: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_da0:
	/* 0xda0: b.gt 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xda0, 0x140, arm64_l_140);
arm64_l_da4:
	/* 0xda4: b 17b8 <generic_retuprobe_filter_arg+0x17b8> */
	ARM64_SIM_A64_JMP(0xda4, 0x17b8, arm64_l_17b8);
arm64_l_da8:
	/* 0xda8: and w8, w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_dac:
	/* 0xdac: cmp w8, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_db0:
	/* 0xdb0: b.hi 1344 <generic_retuprobe_filter_arg+0x1344> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xdb0, 0x1344, arm64_l_1344);
arm64_l_db4:
	/* 0xdb4: and w8, w29, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_db8:
	/* 0xdb8: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_dbc:
	/* 0xdbc: tst w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_dc0:
	/* 0xdc0: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_dc4:
	/* 0xdc4: mov w9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_dc8:
	/* 0xdc8: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_dcc:
	/* 0xdcc: msub w8, w8, w9, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MSUB, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_X29, ARM64_WIDTH_32, 0, 0);
arm64_l_dd0:
	/* 0xdd0: b.eq de4 <generic_retuprobe_filter_arg+0xde4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xdd0, 0xde4, arm64_l_de4);
arm64_l_dd4:
	/* 0xdd4: tst w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_dd8:
	/* 0xdd8: mov w9, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_ddc:
	/* 0xddc: mov w11, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_de0:
	/* 0xde0: b.eq e00 <generic_retuprobe_filter_arg+0xe00> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xde0, 0xe00, arm64_l_e00);
arm64_l_de4:
	/* 0xde4: sub w8, w29, w8, uxtb */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_UXTB, 0), 0);
arm64_l_de8:
	/* 0xde8: and w9, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_dec:
	/* 0xdec: add w8, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_df0:
	/* 0xdf0: and w11, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_df4:
	/* 0xdf4: cmp w9, #0x78 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 120ULL);
arm64_l_df8:
	/* 0xdf8: b.hi 2390 <generic_retuprobe_filter_arg+0x2390> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xdf8, 0x2390, arm64_l_2390);
arm64_l_dfc:
	/* 0xdfc: mov w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_e00:
	/* 0xe00: and w8, w9, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_e04:
	/* 0xe04: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_e08:
	/* 0xe08: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_e0c:
	/* 0xe0c: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_e10:
	/* 0xe10: sub w10, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_e14:
	/* 0xe14: b 23e0 <generic_retuprobe_filter_arg+0x23e0> */
	ARM64_SIM_A64_JMP(0xe14, 0x23e0, arm64_l_23e0);
arm64_l_e18:
	/* 0xe18: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_e1c:
	/* 0xe1c: b.gt 143c <generic_retuprobe_filter_arg+0x143c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xe1c, 0x143c, arm64_l_143c);
arm64_l_e20:
	/* 0xe20: cmp w8, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_e24:
	/* 0xe24: b.eq 15cc <generic_retuprobe_filter_arg+0x15cc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe24, 0x15cc, arm64_l_15cc);
arm64_l_e28:
	/* 0xe28: cmp w8, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_e2c:
	/* 0xe2c: b.ne 32c4 <generic_retuprobe_filter_arg+0x32c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xe2c, 0x32c4, arm64_l_32c4);
arm64_l_e30:
	/* 0xe30: ldr w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_e34:
	/* 0xe34: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_e38:
	/* 0xe38: adrp x0, 0 <string_postfix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_20));
arm64_l_e3c:
	/* 0xe3c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_e40:
	/* 0xe40: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_e44:
	/* 0xe44: mov w19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_e48:
	/* 0xe48: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_e4c:
	/* 0xe4c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_e50:
	/* 0xe50: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e54:
	/* 0xe54: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xe58ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_e58:
	/* 0xe58: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e5c:
	/* 0xe5c: cbz w25, 32bc <generic_retuprobe_filter_arg+0x32bc> */
	ARM64_SIM_A64_CBZ(ARM64_X25, 0xe5c, 0x32bc, arm64_l_32bc);
arm64_l_e60:
	/* 0xe60: cbz x0, 32bc <generic_retuprobe_filter_arg+0x32bc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xe60, 0x32bc, arm64_l_32bc);
arm64_l_e64:
	/* 0xe64: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e68:
	/* 0xe68: adrp x0, 0 <string_postfix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap_21));
arm64_l_e6c:
	/* 0xe6c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_e70:
	/* 0xe70: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e74:
	/* 0xe74: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_e78:
	/* 0xe78: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_e7c:
	/* 0xe7c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xe80ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_e80:
	/* 0xe80: cbz x0, 32b8 <generic_retuprobe_filter_arg+0x32b8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xe80, 0x32b8, arm64_l_32b8);
arm64_l_e84:
	/* 0xe84: cmp w25, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_e88:
	/* 0xe88: mov w9, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_e8c:
	/* 0xe8c: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e90:
	/* 0xe90: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e94:
	/* 0xe94: sub x11, x19, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X19, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_e98:
	/* 0xe98: sub w12, w25, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_e9c:
	/* 0xe9c: sub w13, w25, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_ea0:
	/* 0xea0: csel w9, w25, w9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X9, ARM64_X25, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_ea4:
	/* 0xea4: lsl w10, w9, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_ea8:
	/* 0xea8: mov x9, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_eac:
	/* 0xeac: str w10, [x9], #5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 5ULL);
arm64_l_eb0:
	/* 0xeb0: neg x10, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_NEG, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_eb4:
	/* 0xeb4: add w14, w13, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X13, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_eb8:
	/* 0xeb8: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ebc:
	/* 0xebc: and x14, x14, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_ec0:
	/* 0xec0: ldrb w14, [x29, x14] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X14, ARM64_X29, ARM64_X14, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X14, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ec4:
	/* 0xec4: sturb w14, [x9, #-1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 18446744073709551615ULL);
arm64_l_ec8:
	/* 0xec8: b.eq ef0 <generic_retuprobe_filter_arg+0xef0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xec8, 0xef0, arm64_l_ef0);
arm64_l_ecc:
	/* 0xecc: cmn x8, #0x7e */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 126ULL);
arm64_l_ed0:
	/* 0xed0: b.eq ef0 <generic_retuprobe_filter_arg+0xef0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xed0, 0xef0, arm64_l_ef0);
arm64_l_ed4:
	/* 0xed4: add w14, w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_ed8:
	/* 0xed8: sub x8, x8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_edc:
	/* 0xedc: and x14, x14, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_ee0:
	/* 0xee0: cmp x10, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ee4:
	/* 0xee4: ldrb w14, [x29, x14] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X14, ARM64_X29, ARM64_X14, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X14, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ee8:
	/* 0xee8: strb w14, [x9], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_eec:
	/* 0xeec: b.ne eb4 <generic_retuprobe_filter_arg+0xeb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xeec, 0xeb4, arm64_l_eb4);
arm64_l_ef0:
	/* 0xef0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ef4:
	/* 0xef4: mov x0, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ef8:
	/* 0xef8: b 32a8 <generic_retuprobe_filter_arg+0x32a8> */
	ARM64_SIM_A64_JMP(0xef8, 0x32a8, arm64_l_32a8);
arm64_l_efc:
	/* 0xefc: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f00:
	/* 0xf00: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_f04:
	/* 0xf04: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_f08:
	/* 0xf08: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f0c:
	/* 0xf0c: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0xf0c, 0x140, arm64_l_140);
arm64_l_f10:
	/* 0xf10: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0xf10, 0xc4, arm64_l_c4);
arm64_l_f14:
	/* 0xf14: ldp w11, w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_f18:
	/* 0xf18: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_f1c:
	/* 0xf1c: b.hi 1a98 <generic_retuprobe_filter_arg+0x1a98> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xf1c, 0x1a98, arm64_l_1a98);
arm64_l_f20:
	/* 0xf20: lsl w10, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_f24:
	/* 0xf24: mov w12, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_f28:
	/* 0xf28: tst w10, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f2c:
	/* 0xf2c: b.eq 1a98 <generic_retuprobe_filter_arg+0x1a98> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf2c, 0x1a98, arm64_l_1a98);
arm64_l_f30:
	/* 0xf30: ldr w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f34:
	/* 0xf34: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f38:
	/* 0xf38: ccmp w10, w8, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_f3c:
	/* 0xf3c: cset w8, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_f40:
	/* 0xf40: b 1aa8 <generic_retuprobe_filter_arg+0x1aa8> */
	ARM64_SIM_A64_JMP(0xf40, 0x1aa8, arm64_l_1aa8);
arm64_l_f44:
	/* 0xf44: cmp w8, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_f48:
	/* 0xf48: b.eq 1578 <generic_retuprobe_filter_arg+0x1578> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf48, 0x1578, arm64_l_1578);
arm64_l_f4c:
	/* 0xf4c: mov x25, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f50:
	/* 0xf50: cmp w8, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_f54:
	/* 0xf54: b.eq 14c0 <generic_retuprobe_filter_arg+0x14c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf54, 0x14c0, arm64_l_14c0);
arm64_l_f58:
	/* 0xf58: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0xf58, 0xc4, arm64_l_c4);
arm64_l_f5c:
	/* 0xf5c: cmp w8, #0x12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_f60:
	/* 0xf60: b.eq f80 <generic_retuprobe_filter_arg+0xf80> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf60, 0xf80, arm64_l_f80);
arm64_l_f64:
	/* 0xf64: cmp w8, #0x13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 19ULL);
arm64_l_f68:
	/* 0xf68: b.ne 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xf68, 0x1ce4, arm64_l_1ce4);
arm64_l_f6c:
	/* 0xf6c: ldrh w29, [x25, #34] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 34ULL);
arm64_l_f70:
	/* 0xf70: mov w11, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_f74:
	/* 0xf74: mov w13, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_f78:
	/* 0xf78: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f7c:
	/* 0xf7c: b fd0 <generic_retuprobe_filter_arg+0xfd0> */
	ARM64_SIM_A64_JMP(0xf7c, 0xfd0, arm64_l_fd0);
arm64_l_f80:
	/* 0xf80: ldrh w29, [x25, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_f84:
	/* 0xf84: mov w11, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_f88:
	/* 0xf88: mov w13, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_f8c:
	/* 0xf8c: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f90:
	/* 0xf90: b fd0 <generic_retuprobe_filter_arg+0xfd0> */
	ARM64_SIM_A64_JMP(0xf90, 0xfd0, arm64_l_fd0);
arm64_l_f94:
	/* 0xf94: cmp w8, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_f98:
	/* 0xf98: b.eq 16f8 <generic_retuprobe_filter_arg+0x16f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf98, 0x16f8, arm64_l_16f8);
arm64_l_f9c:
	/* 0xf9c: cmp w8, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_fa0:
	/* 0xfa0: b.ne 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xfa0, 0x1ce4, arm64_l_1ce4);
arm64_l_fa4:
	/* 0xfa4: cmp w9, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_fa8:
	/* 0xfa8: b.ne 1c54 <generic_retuprobe_filter_arg+0x1c54> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xfa8, 0x1c54, arm64_l_1c54);
arm64_l_fac:
	/* 0xfac: cbnz x10, 1c64 <generic_retuprobe_filter_arg+0x1c64> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0xfac, 0x1c64, arm64_l_1c64);
arm64_l_fb0:
	/* 0xfb0: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_fb4:
	/* 0xfb4: b 1c78 <generic_retuprobe_filter_arg+0x1c78> */
	ARM64_SIM_A64_JMP(0xfb4, 0x1c78, arm64_l_1c78);
arm64_l_fb8:
	/* 0xfb8: ldp w11, w13, [x25, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X13, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_fbc:
	/* 0xfbc: ldr x19, [x25, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_fc0:
	/* 0xfc0: b fcc <generic_retuprobe_filter_arg+0xfcc> */
	ARM64_SIM_A64_JMP(0xfc0, 0xfcc, arm64_l_fcc);
arm64_l_fc4:
	/* 0xfc4: ldp w11, w13, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X13, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_fc8:
	/* 0xfc8: ldr x19, [x25, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_fcc:
	/* 0xfcc: mov x29, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_fd0:
	/* 0xfd0: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_fd4:
	/* 0xfd4: cmp w8, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_fd8:
	/* 0xfd8: b.gt 1004 <generic_retuprobe_filter_arg+0x1004> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xfd8, 0x1004, arm64_l_1004);
arm64_l_fdc:
	/* 0xfdc: sub w9, w8, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_fe0:
	/* 0xfe0: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_fe4:
	/* 0xfe4: b.cc 1030 <generic_retuprobe_filter_arg+0x1030> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xfe4, 0x1030, arm64_l_1030);
arm64_l_fe8:
	/* 0xfe8: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_fec:
	/* 0xfec: sub w9, w8, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_ff0:
	/* 0xff0: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_ff4:
	/* 0xff4: b.cc 11f8 <generic_retuprobe_filter_arg+0x11f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xff4, 0x11f8, arm64_l_11f8);
arm64_l_ff8:
	/* 0xff8: cmp w8, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_ffc:
	/* 0xffc: b.eq 16fc <generic_retuprobe_filter_arg+0x16fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xffc, 0x16fc, arm64_l_16fc);
arm64_l_1000:
	/* 0x1000: b 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JMP(0x1000, 0x1ce4, arm64_l_1ce4);
arm64_l_1004:
	/* 0x1004: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_1008:
	/* 0x1008: b.hi 11e8 <generic_retuprobe_filter_arg+0x11e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1008, 0x11e8, arm64_l_11e8);
arm64_l_100c:
	/* 0x100c: lsl w9, w17, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1010:
	/* 0x1010: mov w10, #0x500000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5242880ULL);
arm64_l_1014:
	/* 0x1014: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1018:
	/* 0x1018: b.ne 12e4 <generic_retuprobe_filter_arg+0x12e4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1018, 0x12e4, arm64_l_12e4);
arm64_l_101c:
	/* 0x101c: mov w10, #0xa00000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10485760ULL);
arm64_l_1020:
	/* 0x1020: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1024:
	/* 0x1024: b.ne 12f8 <generic_retuprobe_filter_arg+0x12f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1024, 0x12f8, arm64_l_12f8);
arm64_l_1028:
	/* 0x1028: tst w9, #0x3000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50331648ULL);
arm64_l_102c:
	/* 0x102c: b.eq 11e8 <generic_retuprobe_filter_arg+0x11e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x102c, 0x11e8, arm64_l_11e8);
arm64_l_1030:
	/* 0x1030: ldrh w8, [x25, #38] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 38ULL);
arm64_l_1034:
	/* 0x1034: cmp w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1038:
	/* 0x1038: b.eq 1354 <generic_retuprobe_filter_arg+0x1354> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1038, 0x1354, arm64_l_1354);
arm64_l_103c:
	/* 0x103c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1040:
	/* 0x1040: b.ne 13e0 <generic_retuprobe_filter_arg+0x13e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1040, 0x13e0, arm64_l_13e0);
arm64_l_1044:
	/* 0x1044: ldr w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1048:
	/* 0x1048: adrp x0, 0 <addr4lpm_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&addr4lpm_maps_0));
arm64_l_104c:
	/* 0x104c: add x9, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1050:
	/* 0x1050: add x1, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1054:
	/* 0x1054: str w8, [sp, #172] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 172ULL);
arm64_l_1058:
	/* 0x1058: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_105c:
	/* 0x105c: mov w22, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1060:
	/* 0x1060: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1064:
	/* 0x1064: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1068ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1068:
	/* 0x1068: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_106c:
	/* 0x106c: cbz x0, 1d88 <generic_retuprobe_filter_arg+0x1d88> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x106c, 0x1d88, arm64_l_1d88);
arm64_l_1070:
	/* 0x1070: mov w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 32ULL);
arm64_l_1074:
	/* 0x1074: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1078:
	/* 0x1078: stp w8, w22, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_107c:
	/* 0x107c: b 139c <generic_retuprobe_filter_arg+0x139c> */
	ARM64_SIM_A64_JMP(0x107c, 0x139c, arm64_l_139c);
arm64_l_1080:
	/* 0x1080: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1084:
	/* 0x1084: b.hi 1dd8 <generic_retuprobe_filter_arg+0x1dd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1084, 0x1dd8, arm64_l_1dd8);
arm64_l_1088:
	/* 0x1088: lsl w11, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X11, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_108c:
	/* 0x108c: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1090:
	/* 0x1090: tst w11, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X11, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1094:
	/* 0x1094: b.eq 1dd8 <generic_retuprobe_filter_arg+0x1dd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1094, 0x1dd8, arm64_l_1dd8);
arm64_l_1098:
	/* 0x1098: ldr w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_109c:
	/* 0x109c: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_10a0:
	/* 0x10a0: b.gt 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x10a0, 0x140, arm64_l_140);
arm64_l_10a4:
	/* 0x10a4: b 1df4 <generic_retuprobe_filter_arg+0x1df4> */
	ARM64_SIM_A64_JMP(0x10a4, 0x1df4, arm64_l_1df4);
arm64_l_10a8:
	/* 0x10a8: str x23, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_10ac:
	/* 0x10ac: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10b0:
	/* 0x10b0: mov w22, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_10b4:
	/* 0x10b4: add x23, x21, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_10b8:
	/* 0x10b8: ldr w8, [x23, x19, lsl #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X19, ARM64_MOD_LSL, 2, 0), 0ULL);
arm64_l_10bc:
	/* 0x10bc: adrp x0, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_24));
arm64_l_10c0:
	/* 0x10c0: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_10c4:
	/* 0x10c4: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_10c8:
	/* 0x10c8: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_10cc:
	/* 0x10cc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_10d0:
	/* 0x10d0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_10d4:
	/* 0x10d4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x10d8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_10d8:
	/* 0x10d8: cbz x0, 1cec <generic_retuprobe_filter_arg+0x1cec> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x10d8, 0x1cec, arm64_l_1cec);
arm64_l_10dc:
	/* 0x10dc: ldr x16, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_10e0:
	/* 0x10e0: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_10e4:
	/* 0x10e4: cbz w29, 1150 <generic_retuprobe_filter_arg+0x1150> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x10e4, 0x1150, arm64_l_1150);
arm64_l_10e8:
	/* 0x10e8: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10ec:
	/* 0x10ec: mov x9, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10f0:
	/* 0x10f0: mov x10, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10f4:
	/* 0x10f4: b 110c <generic_retuprobe_filter_arg+0x110c> */
	ARM64_SIM_A64_JMP(0x10f4, 0x110c, arm64_l_110c);
arm64_l_10f8:
	/* 0x10f8: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_10fc:
	/* 0x10fc: sub x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1100:
	/* 0x1100: add x9, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1104:
	/* 0x1104: cmp x8, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1108:
	/* 0x1108: b.eq 1150 <generic_retuprobe_filter_arg+0x1150> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1108, 0x1150, arm64_l_1150);
arm64_l_110c:
	/* 0x110c: mov x11, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1110:
	/* 0x1110: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1114:
	/* 0x1114: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1118:
	/* 0x1118: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_111c:
	/* 0x111c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1120:
	/* 0x1120: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1124:
	/* 0x1124: b.eq 10f8 <generic_retuprobe_filter_arg+0x10f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1124, 0x10f8, arm64_l_10f8);
arm64_l_1128:
	/* 0x1128: ldrb w12, [x0, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X0, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_112c:
	/* 0x112c: cbz w12, 114c <generic_retuprobe_filter_arg+0x114c> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0x112c, 0x114c, arm64_l_114c);
arm64_l_1130:
	/* 0x1130: cmp x11, #0x62 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 98ULL);
arm64_l_1134:
	/* 0x1134: b.hi 10f8 <generic_retuprobe_filter_arg+0x10f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1134, 0x10f8, arm64_l_10f8);
arm64_l_1138:
	/* 0x1138: ldrb w13, [x9, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_113c:
	/* 0x113c: add x11, x11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1140:
	/* 0x1140: cmp w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1144:
	/* 0x1144: b.eq 1120 <generic_retuprobe_filter_arg+0x1120> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1144, 0x1120, arm64_l_1120);
arm64_l_1148:
	/* 0x1148: b 10f8 <generic_retuprobe_filter_arg+0x10f8> */
	ARM64_SIM_A64_JMP(0x1148, 0x10f8, arm64_l_10f8);
arm64_l_114c:
	/* 0x114c: tbz w8, #31, 19bc <generic_retuprobe_filter_arg+0x19bc> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 31, 0x114c, 0x19bc, arm64_l_19bc);
arm64_l_1150:
	/* 0x1150: ldr w9, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1154:
	/* 0x1154: add w8, w22, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1158:
	/* 0x1158: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_115c:
	/* 0x115c: b.cs 1170 <generic_retuprobe_filter_arg+0x1170> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x115c, 0x1170, arm64_l_1170);
arm64_l_1160:
	/* 0x1160: add x19, x19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1164:
	/* 0x1164: add w22, w22, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1168:
	/* 0x1168: cmp x19, #0x64 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 100ULL);
arm64_l_116c:
	/* 0x116c: b.ne 10b8 <generic_retuprobe_filter_arg+0x10b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x116c, 0x10b8, arm64_l_10b8);
arm64_l_1170:
	/* 0x1170: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1174:
	/* 0x1174: b 1d0c <generic_retuprobe_filter_arg+0x1d0c> */
	ARM64_SIM_A64_JMP(0x1174, 0x1d0c, arm64_l_1d0c);
arm64_l_1178:
	/* 0x1178: and w8, w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_117c:
	/* 0x117c: cmp w8, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1180:
	/* 0x1180: b.hi 178c <generic_retuprobe_filter_arg+0x178c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1180, 0x178c, arm64_l_178c);
arm64_l_1184:
	/* 0x1184: and w8, w29, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1188:
	/* 0x1188: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_118c:
	/* 0x118c: tst w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1190:
	/* 0x1190: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1194:
	/* 0x1194: mov w9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_1198:
	/* 0x1198: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_119c:
	/* 0x119c: msub w8, w8, w9, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MSUB, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_X29, ARM64_WIDTH_32, 0, 0);
arm64_l_11a0:
	/* 0x11a0: b.eq 11b4 <generic_retuprobe_filter_arg+0x11b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x11a0, 0x11b4, arm64_l_11b4);
arm64_l_11a4:
	/* 0x11a4: tst w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_11a8:
	/* 0x11a8: mov w9, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_11ac:
	/* 0x11ac: mov w11, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_11b0:
	/* 0x11b0: b.eq 11d0 <generic_retuprobe_filter_arg+0x11d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x11b0, 0x11d0, arm64_l_11d0);
arm64_l_11b4:
	/* 0x11b4: sub w8, w29, w8, uxtb */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_UXTB, 0), 0);
arm64_l_11b8:
	/* 0x11b8: and w9, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_11bc:
	/* 0x11bc: add w8, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_11c0:
	/* 0x11c0: and w11, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_11c4:
	/* 0x11c4: cmp w9, #0x78 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 120ULL);
arm64_l_11c8:
	/* 0x11c8: b.hi 2850 <generic_retuprobe_filter_arg+0x2850> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x11c8, 0x2850, arm64_l_2850);
arm64_l_11cc:
	/* 0x11cc: mov w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_11d0:
	/* 0x11d0: and w8, w9, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_11d4:
	/* 0x11d4: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_11d8:
	/* 0x11d8: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_11dc:
	/* 0x11dc: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_11e0:
	/* 0x11e0: sub w10, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_11e4:
	/* 0x11e4: b 28a0 <generic_retuprobe_filter_arg+0x28a0> */
	ARM64_SIM_A64_JMP(0x11e4, 0x28a0, arm64_l_28a0);
arm64_l_11e8:
	/* 0x11e8: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_11ec:
	/* 0x11ec: sub w8, w8, #0x12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_11f0:
	/* 0x11f0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_11f4:
	/* 0x11f4: b.cs 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x11f4, 0x1ce4, arm64_l_1ce4);
arm64_l_11f8:
	/* 0x11f8: ldrb w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_11fc:
	/* 0x11fc: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_1200:
	/* 0x1200: add x9, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1204:
	/* 0x1204: add x1, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1208:
	/* 0x1208: str w8, [sp, #172] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 172ULL);
arm64_l_120c:
	/* 0x120c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1210:
	/* 0x1210: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1214:
	/* 0x1214: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1218ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1218:
	/* 0x1218: cbz x0, 1cd4 <generic_retuprobe_filter_arg+0x1cd4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1218, 0x1cd4, arm64_l_1cd4);
arm64_l_121c:
	/* 0x121c: str x29, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1220:
	/* 0x1220: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1224:
	/* 0x1224: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1228:
	/* 0x1228: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_122c:
	/* 0x122c: b 1730 <generic_retuprobe_filter_arg+0x1730> */
	ARM64_SIM_A64_JMP(0x122c, 0x1730, arm64_l_1730);
arm64_l_1230:
	/* 0x1230: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1234:
	/* 0x1234: b.eq 19c4 <generic_retuprobe_filter_arg+0x19c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1234, 0x19c4, arm64_l_19c4);
arm64_l_1238:
	/* 0x1238: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_123c:
	/* 0x123c: b.ne 19d0 <generic_retuprobe_filter_arg+0x19d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x123c, 0x19d0, arm64_l_19d0);
arm64_l_1240:
	/* 0x1240: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1244:
	/* 0x1244: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1248:
	/* 0x1248: b.hi 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1248, 0x140, arm64_l_140);
arm64_l_124c:
	/* 0x124c: b 19d0 <generic_retuprobe_filter_arg+0x19d0> */
	ARM64_SIM_A64_JMP(0x124c, 0x19d0, arm64_l_19d0);
arm64_l_1250:
	/* 0x1250: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1254:
	/* 0x1254: b.eq 1a04 <generic_retuprobe_filter_arg+0x1a04> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1254, 0x1a04, arm64_l_1a04);
arm64_l_1258:
	/* 0x1258: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_125c:
	/* 0x125c: b.ne 1a10 <generic_retuprobe_filter_arg+0x1a10> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x125c, 0x1a10, arm64_l_1a10);
arm64_l_1260:
	/* 0x1260: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1264:
	/* 0x1264: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1268:
	/* 0x1268: b.hi 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1268, 0x140, arm64_l_140);
arm64_l_126c:
	/* 0x126c: b 1a10 <generic_retuprobe_filter_arg+0x1a10> */
	ARM64_SIM_A64_JMP(0x126c, 0x1a10, arm64_l_1a10);
arm64_l_1270:
	/* 0x1270: ldrb w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1274:
	/* 0x1274: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_1278:
	/* 0x1278: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_127c:
	/* 0x127c: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1280:
	/* 0x1280: str w8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1284:
	/* 0x1284: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1288:
	/* 0x1288: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_128c:
	/* 0x128c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1290ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1290:
	/* 0x1290: cbz x0, 1cd4 <generic_retuprobe_filter_arg+0x1cd4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1290, 0x1cd4, arm64_l_1cd4);
arm64_l_1294:
	/* 0x1294: ldrb w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1298:
	/* 0x1298: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_129c:
	/* 0x129c: str x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_12a0:
	/* 0x12a0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_12a4:
	/* 0x12a4: b 12dc <generic_retuprobe_filter_arg+0x12dc> */
	ARM64_SIM_A64_JMP(0x12a4, 0x12dc, arm64_l_12dc);
arm64_l_12a8:
	/* 0x12a8: ldrb w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_12ac:
	/* 0x12ac: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_12b0:
	/* 0x12b0: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_12b4:
	/* 0x12b4: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_12b8:
	/* 0x12b8: str w8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_12bc:
	/* 0x12bc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_12c0:
	/* 0x12c0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_12c4:
	/* 0x12c4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x12c8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_12c8:
	/* 0x12c8: cbz x0, 1cd4 <generic_retuprobe_filter_arg+0x1cd4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x12c8, 0x1cd4, arm64_l_1cd4);
arm64_l_12cc:
	/* 0x12cc: ldrh w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_12d0:
	/* 0x12d0: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_12d4:
	/* 0x12d4: str x8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_12d8:
	/* 0x12d8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_12dc:
	/* 0x12dc: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_12e0:
	/* 0x12e0: b 1730 <generic_retuprobe_filter_arg+0x1730> */
	ARM64_SIM_A64_JMP(0x12e0, 0x1730, arm64_l_1730);
arm64_l_12e4:
	/* 0x12e4: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_12e8:
	/* 0x12e8: cmp x29, #0x400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1024ULL);
arm64_l_12ec:
	/* 0x12ec: cset w22, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_12f0:
	/* 0x12f0: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x12f0, 0x140, arm64_l_140);
arm64_l_12f4:
	/* 0x12f4: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x12f4, 0xc4, arm64_l_c4);
arm64_l_12f8:
	/* 0x12f8: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_12fc:
	/* 0x12fc: cmp x29, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_1300:
	/* 0x1300: cset w22, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_1304:
	/* 0x1304: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x1304, 0x140, arm64_l_140);
arm64_l_1308:
	/* 0x1308: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x1308, 0xc4, arm64_l_c4);
arm64_l_130c:
	/* 0x130c: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1310:
	/* 0x1310: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1314:
	/* 0x1314: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1318:
	/* 0x1318: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_131c:
	/* 0x131c: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1320:
	/* 0x1320: b 1d18 <generic_retuprobe_filter_arg+0x1d18> */
	ARM64_SIM_A64_JMP(0x1320, 0x1d18, arm64_l_1d18);
arm64_l_1324:
	/* 0x1324: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1328:
	/* 0x1328: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_132c:
	/* 0x132c: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1330:
	/* 0x1330: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1334:
	/* 0x1334: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1338:
	/* 0x1338: mov w22, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_133c:
	/* 0x133c: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x133c, 0x140, arm64_l_140);
arm64_l_1340:
	/* 0x1340: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x1340, 0xc4, arm64_l_c4);
arm64_l_1344:
	/* 0x1344: cmp w8, #0x101 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 257ULL);
arm64_l_1348:
	/* 0x1348: b.cs 19a0 <generic_retuprobe_filter_arg+0x19a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1348, 0x19a0, arm64_l_19a0);
arm64_l_134c:
	/* 0x134c: mov w11, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_1350:
	/* 0x1350: b 2390 <generic_retuprobe_filter_arg+0x2390> */
	ARM64_SIM_A64_JMP(0x1350, 0x2390, arm64_l_2390);
arm64_l_1354:
	/* 0x1354: ldr w8, [x21, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1358:
	/* 0x1358: adrp x0, 0 <addr6lpm_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&addr6lpm_maps_1));
arm64_l_135c:
	/* 0x135c: add x9, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1360:
	/* 0x1360: add x1, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1364:
	/* 0x1364: str w8, [sp, #172] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 172ULL);
arm64_l_1368:
	/* 0x1368: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_136c:
	/* 0x136c: mov w25, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1370:
	/* 0x1370: mov w22, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1374:
	/* 0x1374: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1378:
	/* 0x1378: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x137cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_137c:
	/* 0x137c: cbz x0, 1db0 <generic_retuprobe_filter_arg+0x1db0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x137c, 0x1db0, arm64_l_1db0);
arm64_l_1380:
	/* 0x1380: mov w8, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 128ULL);
arm64_l_1384:
	/* 0x1384: stp w25, w19, [sp, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X25, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1388:
	/* 0x1388: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_138c:
	/* 0x138c: stp w8, w22, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1390:
	/* 0x1390: lsr x8, x19, #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 32ULL);
arm64_l_1394:
	/* 0x1394: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1398:
	/* 0x1398: str w8, [sp, #152] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_139c:
	/* 0x139c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_13a0:
	/* 0x13a0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x13a4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_13a4:
	/* 0x13a4: ldr w8, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_13a8:
	/* 0x13a8: sub w9, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_13ac:
	/* 0x13ac: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_13b0:
	/* 0x13b0: b.cc 19b4 <generic_retuprobe_filter_arg+0x19b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x13b0, 0x19b4, arm64_l_19b4);
arm64_l_13b4:
	/* 0x13b4: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_13b8:
	/* 0x13b8: sub w8, w8, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_13bc:
	/* 0x13bc: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_13c0:
	/* 0x13c0: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_13c4:
	/* 0x13c4: b.hi 1f54 <generic_retuprobe_filter_arg+0x1f54> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x13c4, 0x1f54, arm64_l_1f54);
arm64_l_13c8:
	/* 0x13c8: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_13cc:
	/* 0x13cc: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_13d0:
	/* 0x13d0: cset w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_13d4:
	/* 0x13d4: mov w22, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_13d8:
	/* 0x13d8: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x13d8, 0x140, arm64_l_140);
arm64_l_13dc:
	/* 0x13dc: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x13dc, 0xc4, arm64_l_c4);
arm64_l_13e0:
	/* 0x13e0: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_13e4:
	/* 0x13e4: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_13e8:
	/* 0x13e8: mov w22, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_13ec:
	/* 0x13ec: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x13ec, 0x140, arm64_l_140);
arm64_l_13f0:
	/* 0x13f0: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x13f0, 0xc4, arm64_l_c4);
arm64_l_13f4:
	/* 0x13f4: cmp w8, #0x1e */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 30ULL);
arm64_l_13f8:
	/* 0x13f8: b.ne c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x13f8, 0xc4, arm64_l_c4);
arm64_l_13fc:
	/* 0x13fc: ldr w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1400:
	/* 0x1400: mov w10, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1404:
	/* 0x1404: and x8, x8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_1408:
	/* 0x1408: add x9, x20, x8, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_140c:
	/* 0x140c: ldr w9, [x9, x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X10, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1410:
	/* 0x1410: cbnz w9, c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_CBNZ(ARM64_X9, 0x1410, 0xc4, arm64_l_c4);
arm64_l_1414:
	/* 0x1414: add x8, x20, x8, lsl #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 3), 0);
arm64_l_1418:
	/* 0x1418: ldr x9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_141c:
	/* 0x141c: ldr x8, [x8, #24184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24184ULL);
arm64_l_1420:
	/* 0x1420: and x8, x8, #0x7ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2047ULL);
arm64_l_1424:
	/* 0x1424: add x8, x20, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1428:
	/* 0x1428: ldr x8, [x8, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_142c:
	/* 0x142c: bics xzr, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_BIC_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1430:
	/* 0x1430: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1434:
	/* 0x1434: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x1434, 0x140, arm64_l_140);
arm64_l_1438:
	/* 0x1438: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x1438, 0xc4, arm64_l_c4);
arm64_l_143c:
	/* 0x143c: cmp w8, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_1440:
	/* 0x1440: b.eq 1ae0 <generic_retuprobe_filter_arg+0x1ae0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1440, 0x1ae0, arm64_l_1ae0);
arm64_l_1444:
	/* 0x1444: cmp w8, #0x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 34ULL);
arm64_l_1448:
	/* 0x1448: b.ne 32c4 <generic_retuprobe_filter_arg+0x32c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1448, 0x32c4, arm64_l_32c4);
arm64_l_144c:
	/* 0x144c: mov w19, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1450:
	/* 0x1450: ldr w8, [x21, x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X19, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1454:
	/* 0x1454: adrp x0, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_24));
arm64_l_1458:
	/* 0x1458: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_145c:
	/* 0x145c: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1460:
	/* 0x1460: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1464:
	/* 0x1464: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1468:
	/* 0x1468: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_146c:
	/* 0x146c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1470ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1470:
	/* 0x1470: cbz x0, 32b8 <generic_retuprobe_filter_arg+0x32b8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1470, 0x32b8, arm64_l_32b8);
arm64_l_1474:
	/* 0x1474: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1478:
	/* 0x1478: mov x0, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_147c:
	/* 0x147c: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1480:
	/* 0x1480: bl 3460 <native_bpf_strncasestr> */
	ARM64_SIM_A64_CALL(arm64_l_3460, 0x1484ULL);
arm64_l_1484:
	/* 0x1484: tbz w0, #31, 2674 <generic_retuprobe_filter_arg+0x2674> */
	ARM64_SIM_A64_TBZ(ARM64_X0, 31, 0x1484, 0x2674, arm64_l_2674);
arm64_l_1488:
	/* 0x1488: ldr w8, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_148c:
	/* 0x148c: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1490:
	/* 0x1490: add x19, x19, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1494:
	/* 0x1494: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1498:
	/* 0x1498: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_149c:
	/* 0x149c: sub w9, w19, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_14a0:
	/* 0x14a0: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_14a4:
	/* 0x14a4: b.cs 32c4 <generic_retuprobe_filter_arg+0x32c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x14a4, 0x32c4, arm64_l_32c4);
arm64_l_14a8:
	/* 0x14a8: cmp x19, #0x1a0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 416ULL);
arm64_l_14ac:
	/* 0x14ac: b.ne 1450 <generic_retuprobe_filter_arg+0x1450> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x14ac, 0x1450, arm64_l_1450);
arm64_l_14b0:
	/* 0x14b0: b 32c4 <generic_retuprobe_filter_arg+0x32c4> */
	ARM64_SIM_A64_JMP(0x14b0, 0x32c4, arm64_l_32c4);
arm64_l_14b4:
	/* 0x14b4: mov x25, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14b8:
	/* 0x14b8: cmp w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_14bc:
	/* 0x14bc: b.ne c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x14bc, 0xc4, arm64_l_c4);
arm64_l_14c0:
	/* 0x14c0: ldr w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_14c4:
	/* 0x14c4: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_14c8:
	/* 0x14c8: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_22));
arm64_l_14cc:
	/* 0x14cc: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_14d0:
	/* 0x14d0: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_14d4:
	/* 0x14d4: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_14d8:
	/* 0x14d8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_14dc:
	/* 0x14dc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_14e0:
	/* 0x14e0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x14e4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_14e4:
	/* 0x14e4: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14e8:
	/* 0x14e8: cbz w29, 1ed0 <generic_retuprobe_filter_arg+0x1ed0> */
	ARM64_SIM_A64_CBZ(ARM64_X29, 0x14e8, 0x1ed0, arm64_l_1ed0);
arm64_l_14ec:
	/* 0x14ec: cbz x0, 1ed0 <generic_retuprobe_filter_arg+0x1ed0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x14ec, 0x1ed0, arm64_l_1ed0);
arm64_l_14f0:
	/* 0x14f0: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14f4:
	/* 0x14f4: adrp x0, 0 <string_prefix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap_23));
arm64_l_14f8:
	/* 0x14f8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_14fc:
	/* 0x14fc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1500:
	/* 0x1500: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1504:
	/* 0x1504: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1508:
	/* 0x1508: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x150cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_150c:
	/* 0x150c: cbz x0, 1ec8 <generic_retuprobe_filter_arg+0x1ec8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x150c, 0x1ec8, arm64_l_1ec8);
arm64_l_1510:
	/* 0x1510: lsl w9, w29, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_1514:
	/* 0x1514: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1518:
	/* 0x1518: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_151c:
	/* 0x151c: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1520:
	/* 0x1520: str w9, [x8], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_1524:
	/* 0x1524: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1528:
	/* 0x1528: mov x25, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_152c:
	/* 0x152c: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1530:
	/* 0x1530: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1534ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1534:
	/* 0x1534: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1538:
	/* 0x1538: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_153c:
	/* 0x153c: mov x1, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1540:
	/* 0x1540: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1544ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1544:
	/* 0x1544: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1548:
	/* 0x1548: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_154c:
	/* 0x154c: b 1ecc <generic_retuprobe_filter_arg+0x1ecc> */
	ARM64_SIM_A64_JMP(0x154c, 0x1ecc, arm64_l_1ecc);
arm64_l_1550:
	/* 0x1550: mov w13, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_1554:
	/* 0x1554: sub w8, w13, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_1558:
	/* 0x1558: ror w8, w8, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_ROR), 8ULL);
arm64_l_155c:
	/* 0x155c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1560:
	/* 0x1560: b.gt 1988 <generic_retuprobe_filter_arg+0x1988> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1560, 0x1988, arm64_l_1988);
arm64_l_1564:
	/* 0x1564: cbz w8, 1fc4 <generic_retuprobe_filter_arg+0x1fc4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x1564, 0x1fc4, arm64_l_1fc4);
arm64_l_1568:
	/* 0x1568: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_156c:
	/* 0x156c: b.ne 1fbc <generic_retuprobe_filter_arg+0x1fbc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x156c, 0x1fbc, arm64_l_1fbc);
arm64_l_1570:
	/* 0x1570: mov w11, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 7ULL);
arm64_l_1574:
	/* 0x1574: b 1fd0 <generic_retuprobe_filter_arg+0x1fd0> */
	ARM64_SIM_A64_JMP(0x1574, 0x1fd0, arm64_l_1fd0);
arm64_l_1578:
	/* 0x1578: ldrb w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_157c:
	/* 0x157c: ldrh w19, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1580:
	/* 0x1580: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_1584:
	/* 0x1584: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1588:
	/* 0x1588: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_158c:
	/* 0x158c: str w8, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1590:
	/* 0x1590: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1594:
	/* 0x1594: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1598:
	/* 0x1598: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x159cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_159c:
	/* 0x159c: cbz x0, 1cd0 <generic_retuprobe_filter_arg+0x1cd0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x159c, 0x1cd0, arm64_l_1cd0);
arm64_l_15a0:
	/* 0x15a0: str x19, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_15a4:
	/* 0x15a4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_15a8:
	/* 0x15a8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_15ac:
	/* 0x15ac: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_15b0:
	/* 0x15b0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x15b4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_15b4:
	/* 0x15b4: ldr w9, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_15b8:
	/* 0x15b8: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_15bc:
	/* 0x15bc: cmp w9, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_15c0:
	/* 0x15c0: b.hi 1cc0 <generic_retuprobe_filter_arg+0x1cc0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x15c0, 0x1cc0, arm64_l_1cc0);
arm64_l_15c4:
	/* 0x15c4: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_15c8:
	/* 0x15c8: b 1744 <generic_retuprobe_filter_arg+0x1744> */
	ARM64_SIM_A64_JMP(0x15c8, 0x1744, arm64_l_1744);
arm64_l_15cc:
	/* 0x15cc: ldr w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_15d0:
	/* 0x15d0: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_15d4:
	/* 0x15d4: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_22));
arm64_l_15d8:
	/* 0x15d8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_15dc:
	/* 0x15dc: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_15e0:
	/* 0x15e0: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_15e4:
	/* 0x15e4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_15e8:
	/* 0x15e8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_15ec:
	/* 0x15ec: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x15f0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_15f0:
	/* 0x15f0: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_15f4:
	/* 0x15f4: cbz w25, 32bc <generic_retuprobe_filter_arg+0x32bc> */
	ARM64_SIM_A64_CBZ(ARM64_X25, 0x15f4, 0x32bc, arm64_l_32bc);
arm64_l_15f8:
	/* 0x15f8: cbz x0, 32bc <generic_retuprobe_filter_arg+0x32bc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x15f8, 0x32bc, arm64_l_32bc);
arm64_l_15fc:
	/* 0x15fc: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1600:
	/* 0x1600: adrp x0, 0 <string_prefix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap_23));
arm64_l_1604:
	/* 0x1604: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1608:
	/* 0x1608: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_160c:
	/* 0x160c: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1610:
	/* 0x1610: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1614:
	/* 0x1614: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1618ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1618:
	/* 0x1618: cbz x0, 32b8 <generic_retuprobe_filter_arg+0x32b8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1618, 0x32b8, arm64_l_32b8);
arm64_l_161c:
	/* 0x161c: cmp w25, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1620:
	/* 0x1620: mov w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 255ULL);
arm64_l_1624:
	/* 0x1624: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1628:
	/* 0x1628: mov x2, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_162c:
	/* 0x162c: csel w1, w25, w8, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X1, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_1630:
	/* 0x1630: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1634:
	/* 0x1634: lsl w9, w1, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_1638:
	/* 0x1638: str w9, [x8], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_163c:
	/* 0x163c: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1640:
	/* 0x1640: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1644:
	/* 0x1644: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1648ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1648:
	/* 0x1648: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_164c:
	/* 0x164c: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1650:
	/* 0x1650: mov x1, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1654:
	/* 0x1654: b 32a8 <generic_retuprobe_filter_arg+0x32a8> */
	ARM64_SIM_A64_JMP(0x1654, 0x32a8, arm64_l_32a8);
arm64_l_1658:
	/* 0x1658: cmp w25, #0x1, lsl #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_165c:
	/* 0x165c: str wzr, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1660:
	/* 0x1660: b.ls 1ba8 <generic_retuprobe_filter_arg+0x1ba8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1660, 0x1ba8, arm64_l_1ba8);
arm64_l_1664:
	/* 0x1664: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1668:
	/* 0x1668: b 32c4 <generic_retuprobe_filter_arg+0x32c4> */
	ARM64_SIM_A64_JMP(0x1668, 0x32c4, arm64_l_32c4);
arm64_l_166c:
	/* 0x166c: ldr x8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1670:
	/* 0x1670: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1674:
	/* 0x1674: b.hi 1680 <generic_retuprobe_filter_arg+0x1680> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1674, 0x1680, arm64_l_1680);
arm64_l_1678:
	/* 0x1678: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_167c:
	/* 0x167c: b.ls 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x167c, 0x140, arm64_l_140);
arm64_l_1680:
	/* 0x1680: ldr w10, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1684:
	/* 0x1684: cmp w10, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_1688:
	/* 0x1688: b.cc c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1688, 0xc4, arm64_l_c4);
arm64_l_168c:
	/* 0x168c: ldp x12, x11, [x21, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1690:
	/* 0x1690: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1694:
	/* 0x1694: b.eq 16a0 <generic_retuprobe_filter_arg+0x16a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1694, 0x16a0, arm64_l_16a0);
arm64_l_1698:
	/* 0x1698: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_169c:
	/* 0x169c: b.ne 1d40 <generic_retuprobe_filter_arg+0x1d40> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x169c, 0x1d40, arm64_l_1d40);
arm64_l_16a0:
	/* 0x16a0: cmp x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_16a4:
	/* 0x16a4: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_16a8:
	/* 0x16a8: b.gt 1d54 <generic_retuprobe_filter_arg+0x1d54> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x16a8, 0x1d54, arm64_l_1d54);
arm64_l_16ac:
	/* 0x16ac: cmp x8, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_16b0:
	/* 0x16b0: b.le 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x16b0, 0x140, arm64_l_140);
arm64_l_16b4:
	/* 0x16b4: b 1d54 <generic_retuprobe_filter_arg+0x1d54> */
	ARM64_SIM_A64_JMP(0x16b4, 0x1d54, arm64_l_1d54);
arm64_l_16b8:
	/* 0x16b8: ldr x10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_16bc:
	/* 0x16bc: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_16c0:
	/* 0x16c0: ccmp x10, x8, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_16c4:
	/* 0x16c4: cset w8, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_16c8:
	/* 0x16c8: ldr w11, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_16cc:
	/* 0x16cc: cmp w11, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_16d0:
	/* 0x16d0: b.cc 2aa0 <generic_retuprobe_filter_arg+0x2aa0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x16d0, 0x2aa0, arm64_l_2aa0);
arm64_l_16d4:
	/* 0x16d4: ldp x13, x12, [x21, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X13, ARM64_X12, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_16d8:
	/* 0x16d8: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_16dc:
	/* 0x16dc: b.eq 16e8 <generic_retuprobe_filter_arg+0x16e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x16dc, 0x16e8, arm64_l_16e8);
arm64_l_16e0:
	/* 0x16e0: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_16e4:
	/* 0x16e4: b.ne 1c18 <generic_retuprobe_filter_arg+0x1c18> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x16e4, 0x1c18, arm64_l_1c18);
arm64_l_16e8:
	/* 0x16e8: cmp x13, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_16ec:
	/* 0x16ec: ccmp x10, x12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_16f0:
	/* 0x16f0: cset w12, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_16f4:
	/* 0x16f4: b 1c24 <generic_retuprobe_filter_arg+0x1c24> */
	ARM64_SIM_A64_JMP(0x16f4, 0x1c24, arm64_l_1c24);
arm64_l_16f8:
	/* 0x16f8: ldrh w22, [x25, #38] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 38ULL);
arm64_l_16fc:
	/* 0x16fc: ldrb w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1700:
	/* 0x1700: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_1704:
	/* 0x1704: add x9, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1708:
	/* 0x1708: add x1, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_170c:
	/* 0x170c: str w8, [sp, #172] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 172ULL);
arm64_l_1710:
	/* 0x1710: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1714:
	/* 0x1714: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1718:
	/* 0x1718: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x171cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_171c:
	/* 0x171c: cbz x0, 1cd4 <generic_retuprobe_filter_arg+0x1cd4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x171c, 0x1cd4, arm64_l_1cd4);
arm64_l_1720:
	/* 0x1720: str x22, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1724:
	/* 0x1724: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1728:
	/* 0x1728: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_172c:
	/* 0x172c: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1730:
	/* 0x1730: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1734ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1734:
	/* 0x1734: ldr w9, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1738:
	/* 0x1738: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_173c:
	/* 0x173c: cmp w9, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_1740:
	/* 0x1740: b.hi 1cc4 <generic_retuprobe_filter_arg+0x1cc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1740, 0x1cc4, arm64_l_1cc4);
arm64_l_1744:
	/* 0x1744: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1748:
	/* 0x1748: mov w10, #0x8400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 33792ULL);
arm64_l_174c:
	/* 0x174c: lsl w9, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1750:
	/* 0x1750: movk w10, #0x3003, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 12291ULL);
arm64_l_1754:
	/* 0x1754: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1758:
	/* 0x1758: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_175c:
	/* 0x175c: b.eq 176c <generic_retuprobe_filter_arg+0x176c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x175c, 0x176c, arm64_l_176c);
arm64_l_1760:
	/* 0x1760: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1764:
	/* 0x1764: cset w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1768:
	/* 0x1768: b 1784 <generic_retuprobe_filter_arg+0x1784> */
	ARM64_SIM_A64_JMP(0x1768, 0x1784, arm64_l_1784);
arm64_l_176c:
	/* 0x176c: mov w10, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_1770:
	/* 0x1770: movk w10, #0xc, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 12ULL);
arm64_l_1774:
	/* 0x1774: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1778:
	/* 0x1778: b.eq 1784 <generic_retuprobe_filter_arg+0x1784> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1778, 0x1784, arm64_l_1784);
arm64_l_177c:
	/* 0x177c: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1780:
	/* 0x1780: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1784:
	/* 0x1784: mov w22, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1788:
	/* 0x1788: b 1ce0 <generic_retuprobe_filter_arg+0x1ce0> */
	ARM64_SIM_A64_JMP(0x1788, 0x1ce0, arm64_l_1ce0);
arm64_l_178c:
	/* 0x178c: cmp w8, #0x101 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 257ULL);
arm64_l_1790:
	/* 0x1790: b.cs 1eb4 <generic_retuprobe_filter_arg+0x1eb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1790, 0x1eb4, arm64_l_1eb4);
arm64_l_1794:
	/* 0x1794: mov w11, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_1798:
	/* 0x1798: b 2850 <generic_retuprobe_filter_arg+0x2850> */
	ARM64_SIM_A64_JMP(0x1798, 0x2850, arm64_l_2850);
arm64_l_179c:
	/* 0x179c: ldr x11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17a0:
	/* 0x17a0: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17a4:
	/* 0x17a4: b.hi 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x17a4, 0x140, arm64_l_140);
arm64_l_17a8:
	/* 0x17a8: b 17b8 <generic_retuprobe_filter_arg+0x17b8> */
	ARM64_SIM_A64_JMP(0x17a8, 0x17b8, arm64_l_17b8);
arm64_l_17ac:
	/* 0x17ac: ldr x11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17b0:
	/* 0x17b0: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17b4:
	/* 0x17b4: b.cc 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x17b4, 0x140, arm64_l_140);
arm64_l_17b8:
	/* 0x17b8: ldr w10, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_17bc:
	/* 0x17bc: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_17c0:
	/* 0x17c0: b.cc 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x17c0, 0x124, arm64_l_124);
arm64_l_17c4:
	/* 0x17c4: ldr x11, [x21, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_17c8:
	/* 0x17c8: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_17cc:
	/* 0x17cc: b.le 17f0 <generic_retuprobe_filter_arg+0x17f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x17cc, 0x17f0, arm64_l_17f0);
arm64_l_17d0:
	/* 0x17d0: sub w12, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_17d4:
	/* 0x17d4: cmp w12, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_17d8:
	/* 0x17d8: b.cs 1824 <generic_retuprobe_filter_arg+0x1824> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x17d8, 0x1824, arm64_l_1824);
arm64_l_17dc:
	/* 0x17dc: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17e0:
	/* 0x17e0: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17e4:
	/* 0x17e4: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_17e8:
	/* 0x17e8: b.ne 2264 <generic_retuprobe_filter_arg+0x2264> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x17e8, 0x2264, arm64_l_2264);
arm64_l_17ec:
	/* 0x17ec: b 31dc <generic_retuprobe_filter_arg+0x31dc> */
	ARM64_SIM_A64_JMP(0x17ec, 0x31dc, arm64_l_31dc);
arm64_l_17f0:
	/* 0x17f0: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_17f4:
	/* 0x17f4: b.eq 18d0 <generic_retuprobe_filter_arg+0x18d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x17f4, 0x18d0, arm64_l_18d0);
arm64_l_17f8:
	/* 0x17f8: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_17fc:
	/* 0x17fc: b.ne 2264 <generic_retuprobe_filter_arg+0x2264> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x17fc, 0x2264, arm64_l_2264);
arm64_l_1800:
	/* 0x1800: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1804:
	/* 0x1804: b.eq 1810 <generic_retuprobe_filter_arg+0x1810> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1804, 0x1810, arm64_l_1810);
arm64_l_1808:
	/* 0x1808: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_180c:
	/* 0x180c: b.ne 2254 <generic_retuprobe_filter_arg+0x2254> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x180c, 0x2254, arm64_l_2254);
arm64_l_1810:
	/* 0x1810: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1814:
	/* 0x1814: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1818:
	/* 0x1818: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_181c:
	/* 0x181c: b.lt 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x181c, 0x140, arm64_l_140);
arm64_l_1820:
	/* 0x1820: b 2264 <generic_retuprobe_filter_arg+0x2264> */
	ARM64_SIM_A64_JMP(0x1820, 0x2264, arm64_l_2264);
arm64_l_1824:
	/* 0x1824: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1828:
	/* 0x1828: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_182c:
	/* 0x182c: b.ne 2264 <generic_retuprobe_filter_arg+0x2264> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x182c, 0x2264, arm64_l_2264);
arm64_l_1830:
	/* 0x1830: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1834:
	/* 0x1834: tst x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1838:
	/* 0x1838: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_183c:
	/* 0x183c: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x183c, 0x140, arm64_l_140);
arm64_l_1840:
	/* 0x1840: b 2264 <generic_retuprobe_filter_arg+0x2264> */
	ARM64_SIM_A64_JMP(0x1840, 0x2264, arm64_l_2264);
arm64_l_1844:
	/* 0x1844: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1848:
	/* 0x1848: b.ne 19d0 <generic_retuprobe_filter_arg+0x19d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1848, 0x19d0, arm64_l_19d0);
arm64_l_184c:
	/* 0x184c: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1850:
	/* 0x1850: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1854:
	/* 0x1854: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1854, 0x140, arm64_l_140);
arm64_l_1858:
	/* 0x1858: b 19d0 <generic_retuprobe_filter_arg+0x19d0> */
	ARM64_SIM_A64_JMP(0x1858, 0x19d0, arm64_l_19d0);
arm64_l_185c:
	/* 0x185c: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1860:
	/* 0x1860: b.ne 1a10 <generic_retuprobe_filter_arg+0x1a10> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1860, 0x1a10, arm64_l_1a10);
arm64_l_1864:
	/* 0x1864: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1868:
	/* 0x1868: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_186c:
	/* 0x186c: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x186c, 0x140, arm64_l_140);
arm64_l_1870:
	/* 0x1870: b 1a10 <generic_retuprobe_filter_arg+0x1a10> */
	ARM64_SIM_A64_JMP(0x1870, 0x1a10, arm64_l_1a10);
arm64_l_1874:
	/* 0x1874: ldr w9, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1878:
	/* 0x1878: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_187c:
	/* 0x187c: b.cc 664 <generic_retuprobe_filter_arg+0x664> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x187c, 0x664, arm64_l_664);
arm64_l_1880:
	/* 0x1880: ldr w10, [x21, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1884:
	/* 0x1884: cbz w10, 664 <generic_retuprobe_filter_arg+0x664> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x1884, 0x664, arm64_l_664);
arm64_l_1888:
	/* 0x1888: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_188c:
	/* 0x188c: b.eq 4a8 <generic_retuprobe_filter_arg+0x4a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x188c, 0x4a8, arm64_l_4a8);
arm64_l_1890:
	/* 0x1890: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1894:
	/* 0x1894: b.cc 664 <generic_retuprobe_filter_arg+0x664> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1894, 0x664, arm64_l_664);
arm64_l_1898:
	/* 0x1898: ldr w10, [x21, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_189c:
	/* 0x189c: cbz w10, 664 <generic_retuprobe_filter_arg+0x664> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x189c, 0x664, arm64_l_664);
arm64_l_18a0:
	/* 0x18a0: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_18a4:
	/* 0x18a4: b.eq 4a8 <generic_retuprobe_filter_arg+0x4a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x18a4, 0x4a8, arm64_l_4a8);
arm64_l_18a8:
	/* 0x18a8: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_18ac:
	/* 0x18ac: b.cc 18c4 <generic_retuprobe_filter_arg+0x18c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x18ac, 0x18c4, arm64_l_18c4);
arm64_l_18b0:
	/* 0x18b0: ldr w9, [x21, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_18b4:
	/* 0x18b4: cbz w9, 18c4 <generic_retuprobe_filter_arg+0x18c4> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x18b4, 0x18c4, arm64_l_18c4);
arm64_l_18b8:
	/* 0x18b8: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_18bc:
	/* 0x18bc: cset w22, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_18c0:
	/* 0x18c0: b 18c8 <generic_retuprobe_filter_arg+0x18c8> */
	ARM64_SIM_A64_JMP(0x18c0, 0x18c8, arm64_l_18c8);
arm64_l_18c4:
	/* 0x18c4: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_18c8:
	/* 0x18c8: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_18cc:
	/* 0x18cc: b 2d20 <generic_retuprobe_filter_arg+0x2d20> */
	ARM64_SIM_A64_JMP(0x18cc, 0x2d20, arm64_l_2d20);
arm64_l_18d0:
	/* 0x18d0: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_18d4:
	/* 0x18d4: b.eq 18e0 <generic_retuprobe_filter_arg+0x18e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x18d4, 0x18e0, arm64_l_18e0);
arm64_l_18d8:
	/* 0x18d8: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_18dc:
	/* 0x18dc: b.ne 2240 <generic_retuprobe_filter_arg+0x2240> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x18dc, 0x2240, arm64_l_2240);
arm64_l_18e0:
	/* 0x18e0: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18e4:
	/* 0x18e4: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_18e8:
	/* 0x18e8: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_18ec:
	/* 0x18ec: b.gt 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x18ec, 0x140, arm64_l_140);
arm64_l_18f0:
	/* 0x18f0: b 2264 <generic_retuprobe_filter_arg+0x2264> */
	ARM64_SIM_A64_JMP(0x18f0, 0x2264, arm64_l_2264);
arm64_l_18f4:
	/* 0x18f4: ldp w8, w11, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X11, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_18f8:
	/* 0x18f8: ldrb w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18fc:
	/* 0x18fc: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1900:
	/* 0x1900: ldr w10, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1904:
	/* 0x1904: ccmp w11, w9, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_1908:
	/* 0x1908: cset w8, cs */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CS, 0);
arm64_l_190c:
	/* 0x190c: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1910:
	/* 0x1910: b.cs 1938 <generic_retuprobe_filter_arg+0x1938> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1910, 0x1938, arm64_l_1938);
arm64_l_1914:
	/* 0x1914: b 1980 <generic_retuprobe_filter_arg+0x1980> */
	ARM64_SIM_A64_JMP(0x1914, 0x1980, arm64_l_1980);
arm64_l_1918:
	/* 0x1918: ldp w8, w11, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X11, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_191c:
	/* 0x191c: ldrh w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1920:
	/* 0x1920: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1924:
	/* 0x1924: ldr w10, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1928:
	/* 0x1928: ccmp w11, w9, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_192c:
	/* 0x192c: cset w8, cs */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CS, 0);
arm64_l_1930:
	/* 0x1930: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1934:
	/* 0x1934: b.cc 1980 <generic_retuprobe_filter_arg+0x1980> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1934, 0x1980, arm64_l_1980);
arm64_l_1938:
	/* 0x1938: ldp w11, w12, [x21, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X12, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_193c:
	/* 0x193c: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1940:
	/* 0x1940: ccmp w12, w9, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_1944:
	/* 0x1944: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1948:
	/* 0x1948: csinc w8, w8, wzr, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X8, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_194c:
	/* 0x194c: cmp w10, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_1950:
	/* 0x1950: b.cc 1980 <generic_retuprobe_filter_arg+0x1980> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1950, 0x1980, arm64_l_1980);
arm64_l_1954:
	/* 0x1954: ldp w11, w12, [x21, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X12, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1958:
	/* 0x1958: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_195c:
	/* 0x195c: ccmp w12, w9, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X12, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_1960:
	/* 0x1960: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1964:
	/* 0x1964: csinc w8, w8, wzr, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X8, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_1968:
	/* 0x1968: cmp w10, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_196c:
	/* 0x196c: b.cc 1980 <generic_retuprobe_filter_arg+0x1980> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x196c, 0x1980, arm64_l_1980);
arm64_l_1970:
	/* 0x1970: ldp w10, w11, [x21, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1974:
	/* 0x1974: cmp w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1978:
	/* 0x1978: ccmp w11, w9, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_197c:
	/* 0x197c: csinc w8, w8, wzr, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X8, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_1980:
	/* 0x1980: tbz w8, #0, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 0, 0x1980, 0x140, arm64_l_140);
arm64_l_1984:
	/* 0x1984: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x1984, 0xc4, arm64_l_c4);
arm64_l_1988:
	/* 0x1988: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_198c:
	/* 0x198c: b.eq 1fcc <generic_retuprobe_filter_arg+0x1fcc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x198c, 0x1fcc, arm64_l_1fcc);
arm64_l_1990:
	/* 0x1990: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_1994:
	/* 0x1994: b.ne 1fbc <generic_retuprobe_filter_arg+0x1fbc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1994, 0x1fbc, arm64_l_1fbc);
arm64_l_1998:
	/* 0x1998: mov w11, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 9ULL);
arm64_l_199c:
	/* 0x199c: b 1fd0 <generic_retuprobe_filter_arg+0x1fd0> */
	ARM64_SIM_A64_JMP(0x199c, 0x1fd0, arm64_l_1fd0);
arm64_l_19a0:
	/* 0x19a0: and w8, w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_19a4:
	/* 0x19a4: cmp w8, #0x201 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 513ULL);
arm64_l_19a8:
	/* 0x19a8: b.cs 1f44 <generic_retuprobe_filter_arg+0x1f44> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x19a8, 0x1f44, arm64_l_1f44);
arm64_l_19ac:
	/* 0x19ac: mov w11, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 512ULL);
arm64_l_19b0:
	/* 0x19b0: b 2390 <generic_retuprobe_filter_arg+0x2390> */
	ARM64_SIM_A64_JMP(0x19b0, 0x2390, arm64_l_2390);
arm64_l_19b4:
	/* 0x19b4: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_19b8:
	/* 0x19b8: b 1d94 <generic_retuprobe_filter_arg+0x1d94> */
	ARM64_SIM_A64_JMP(0x19b8, 0x1d94, arm64_l_1d94);
arm64_l_19bc:
	/* 0x19bc: mov w22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_19c0:
	/* 0x19c0: b 1d0c <generic_retuprobe_filter_arg+0x1d0c> */
	ARM64_SIM_A64_JMP(0x19c0, 0x1d0c, arm64_l_1d0c);
arm64_l_19c4:
	/* 0x19c4: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19c8:
	/* 0x19c8: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19cc:
	/* 0x19cc: b.cc 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x19cc, 0x140, arm64_l_140);
arm64_l_19d0:
	/* 0x19d0: ldr w9, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_19d4:
	/* 0x19d4: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_19d8:
	/* 0x19d8: b.cc 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x19d8, 0x124, arm64_l_124);
arm64_l_19dc:
	/* 0x19dc: ldr w10, [x21, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_19e0:
	/* 0x19e0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_19e4:
	/* 0x19e4: b.le 1f04 <generic_retuprobe_filter_arg+0x1f04> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x19e4, 0x1f04, arm64_l_1f04);
arm64_l_19e8:
	/* 0x19e8: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_19ec:
	/* 0x19ec: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_19f0:
	/* 0x19f0: b.cs 22ec <generic_retuprobe_filter_arg+0x22ec> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x19f0, 0x22ec, arm64_l_22ec);
arm64_l_19f4:
	/* 0x19f4: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19f8:
	/* 0x19f8: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19fc:
	/* 0x19fc: b.ne 2594 <generic_retuprobe_filter_arg+0x2594> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x19fc, 0x2594, arm64_l_2594);
arm64_l_1a00:
	/* 0x1a00: b 31dc <generic_retuprobe_filter_arg+0x31dc> */
	ARM64_SIM_A64_JMP(0x1a00, 0x31dc, arm64_l_31dc);
arm64_l_1a04:
	/* 0x1a04: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a08:
	/* 0x1a08: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a0c:
	/* 0x1a0c: b.cc 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1a0c, 0x140, arm64_l_140);
arm64_l_1a10:
	/* 0x1a10: ldr w9, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1a14:
	/* 0x1a14: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1a18:
	/* 0x1a18: b.cc 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1a18, 0x124, arm64_l_124);
arm64_l_1a1c:
	/* 0x1a1c: ldr w10, [x21, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1a20:
	/* 0x1a20: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1a24:
	/* 0x1a24: b.le 1f24 <generic_retuprobe_filter_arg+0x1f24> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1a24, 0x1f24, arm64_l_1f24);
arm64_l_1a28:
	/* 0x1a28: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1a2c:
	/* 0x1a2c: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1a30:
	/* 0x1a30: b.cs 2304 <generic_retuprobe_filter_arg+0x2304> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1a30, 0x2304, arm64_l_2304);
arm64_l_1a34:
	/* 0x1a34: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a38:
	/* 0x1a38: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a3c:
	/* 0x1a3c: b.ne 25d0 <generic_retuprobe_filter_arg+0x25d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1a3c, 0x25d0, arm64_l_25d0);
arm64_l_1a40:
	/* 0x1a40: b 31dc <generic_retuprobe_filter_arg+0x31dc> */
	ARM64_SIM_A64_JMP(0x1a40, 0x31dc, arm64_l_31dc);
arm64_l_1a44:
	/* 0x1a44: ldr w8, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a48:
	/* 0x1a48: cmp w11, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a4c:
	/* 0x1a4c: b.hi 1a58 <generic_retuprobe_filter_arg+0x1a58> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1a4c, 0x1a58, arm64_l_1a58);
arm64_l_1a50:
	/* 0x1a50: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a54:
	/* 0x1a54: b.ls 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1a54, 0x140, arm64_l_140);
arm64_l_1a58:
	/* 0x1a58: ldr w10, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1a5c:
	/* 0x1a5c: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1a60:
	/* 0x1a60: b.cc c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1a60, 0xc4, arm64_l_c4);
arm64_l_1a64:
	/* 0x1a64: ldp w12, w11, [x21, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1a68:
	/* 0x1a68: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1a6c:
	/* 0x1a6c: b.hi 2160 <generic_retuprobe_filter_arg+0x2160> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1a6c, 0x2160, arm64_l_2160);
arm64_l_1a70:
	/* 0x1a70: lsl w13, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X13, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1a74:
	/* 0x1a74: mov w14, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1a78:
	/* 0x1a78: tst w13, w14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X13, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a7c:
	/* 0x1a7c: b.eq 2160 <generic_retuprobe_filter_arg+0x2160> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1a7c, 0x2160, arm64_l_2160);
arm64_l_1a80:
	/* 0x1a80: cmp w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a84:
	/* 0x1a84: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1a88:
	/* 0x1a88: b.gt 2174 <generic_retuprobe_filter_arg+0x2174> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1a88, 0x2174, arm64_l_2174);
arm64_l_1a8c:
	/* 0x1a8c: cmp w8, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a90:
	/* 0x1a90: b.le 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1a90, 0x140, arm64_l_140);
arm64_l_1a94:
	/* 0x1a94: b 2174 <generic_retuprobe_filter_arg+0x2174> */
	ARM64_SIM_A64_JMP(0x1a94, 0x2174, arm64_l_2174);
arm64_l_1a98:
	/* 0x1a98: ldr w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a9c:
	/* 0x1a9c: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1aa0:
	/* 0x1aa0: ccmp w10, w8, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_1aa4:
	/* 0x1aa4: cset w8, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_1aa8:
	/* 0x1aa8: ldr w11, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1aac:
	/* 0x1aac: cmp w11, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1ab0:
	/* 0x1ab0: b.cc 2aa0 <generic_retuprobe_filter_arg+0x2aa0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1ab0, 0x2aa0, arm64_l_2aa0);
arm64_l_1ab4:
	/* 0x1ab4: ldp w13, w12, [x21, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X13, ARM64_X12, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1ab8:
	/* 0x1ab8: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1abc:
	/* 0x1abc: b.hi 1f68 <generic_retuprobe_filter_arg+0x1f68> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1abc, 0x1f68, arm64_l_1f68);
arm64_l_1ac0:
	/* 0x1ac0: lsl w14, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X14, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1ac4:
	/* 0x1ac4: mov w15, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1ac8:
	/* 0x1ac8: tst w14, w15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X14, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1acc:
	/* 0x1acc: b.eq 1f68 <generic_retuprobe_filter_arg+0x1f68> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1acc, 0x1f68, arm64_l_1f68);
arm64_l_1ad0:
	/* 0x1ad0: cmp w13, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ad4:
	/* 0x1ad4: ccmp w10, w12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_1ad8:
	/* 0x1ad8: cset w12, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_1adc:
	/* 0x1adc: b 1f74 <generic_retuprobe_filter_arg+0x1f74> */
	ARM64_SIM_A64_JMP(0x1adc, 0x1f74, arm64_l_1f74);
arm64_l_1ae0:
	/* 0x1ae0: str x23, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1ae4:
	/* 0x1ae4: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1ae8:
	/* 0x1ae8: mov w22, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1aec:
	/* 0x1aec: add x23, x21, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1af0:
	/* 0x1af0: ldr w8, [x23, x19, lsl #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X19, ARM64_MOD_LSL, 2, 0), 0ULL);
arm64_l_1af4:
	/* 0x1af4: adrp x0, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_24));
arm64_l_1af8:
	/* 0x1af8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1afc:
	/* 0x1afc: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_1b00:
	/* 0x1b00: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1b04:
	/* 0x1b04: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1b08:
	/* 0x1b08: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b0c:
	/* 0x1b0c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1b10ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1b10:
	/* 0x1b10: cbz x0, 2600 <generic_retuprobe_filter_arg+0x2600> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1b10, 0x2600, arm64_l_2600);
arm64_l_1b14:
	/* 0x1b14: ldr x16, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_1b18:
	/* 0x1b18: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1b1c:
	/* 0x1b1c: cbz w25, 1b78 <generic_retuprobe_filter_arg+0x1b78> */
	ARM64_SIM_A64_CBZ(ARM64_X25, 0x1b1c, 0x1b78, arm64_l_1b78);
arm64_l_1b20:
	/* 0x1b20: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b24:
	/* 0x1b24: mov x9, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b28:
	/* 0x1b28: mov x10, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b2c:
	/* 0x1b2c: b 1b44 <generic_retuprobe_filter_arg+0x1b44> */
	ARM64_SIM_A64_JMP(0x1b2c, 0x1b44, arm64_l_1b44);
arm64_l_1b30:
	/* 0x1b30: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b34:
	/* 0x1b34: sub x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b38:
	/* 0x1b38: add x9, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b3c:
	/* 0x1b3c: cmp x8, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b40:
	/* 0x1b40: b.eq 1b78 <generic_retuprobe_filter_arg+0x1b78> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1b40, 0x1b78, arm64_l_1b78);
arm64_l_1b44:
	/* 0x1b44: mov x11, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b48:
	/* 0x1b48: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b4c:
	/* 0x1b4c: b.eq 1b30 <generic_retuprobe_filter_arg+0x1b30> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1b4c, 0x1b30, arm64_l_1b30);
arm64_l_1b50:
	/* 0x1b50: ldrb w12, [x0, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X0, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b54:
	/* 0x1b54: cbz w12, 1b74 <generic_retuprobe_filter_arg+0x1b74> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0x1b54, 0x1b74, arm64_l_1b74);
arm64_l_1b58:
	/* 0x1b58: cmp x11, #0x62 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 98ULL);
arm64_l_1b5c:
	/* 0x1b5c: b.hi 1b30 <generic_retuprobe_filter_arg+0x1b30> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1b5c, 0x1b30, arm64_l_1b30);
arm64_l_1b60:
	/* 0x1b60: ldrb w13, [x9, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b64:
	/* 0x1b64: add x11, x11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b68:
	/* 0x1b68: cmp w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b6c:
	/* 0x1b6c: b.eq 1b48 <generic_retuprobe_filter_arg+0x1b48> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1b6c, 0x1b48, arm64_l_1b48);
arm64_l_1b70:
	/* 0x1b70: b 1b30 <generic_retuprobe_filter_arg+0x1b30> */
	ARM64_SIM_A64_JMP(0x1b70, 0x1b30, arm64_l_1b30);
arm64_l_1b74:
	/* 0x1b74: tbz w8, #31, 2a80 <generic_retuprobe_filter_arg+0x2a80> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 31, 0x1b74, 0x2a80, arm64_l_2a80);
arm64_l_1b78:
	/* 0x1b78: ldr w9, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1b7c:
	/* 0x1b7c: add w8, w22, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1b80:
	/* 0x1b80: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b84:
	/* 0x1b84: b.cs 1b98 <generic_retuprobe_filter_arg+0x1b98> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1b84, 0x1b98, arm64_l_1b98);
arm64_l_1b88:
	/* 0x1b88: add x19, x19, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b8c:
	/* 0x1b8c: add w22, w22, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1b90:
	/* 0x1b90: cmp x19, #0x64 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 100ULL);
arm64_l_1b94:
	/* 0x1b94: b.ne 1af0 <generic_retuprobe_filter_arg+0x1af0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1b94, 0x1af0, arm64_l_1af0);
arm64_l_1b98:
	/* 0x1b98: ldr x23, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1b9c:
	/* 0x1b9c: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1ba0:
	/* 0x1ba0: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1ba4:
	/* 0x1ba4: b 32c4 <generic_retuprobe_filter_arg+0x32c4> */
	ARM64_SIM_A64_JMP(0x1ba4, 0x32c4, arm64_l_32c4);
arm64_l_1ba8:
	/* 0x1ba8: and w8, w25, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1bac:
	/* 0x1bac: cmp w8, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1bb0:
	/* 0x1bb0: b.hi 21b0 <generic_retuprobe_filter_arg+0x21b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1bb0, 0x21b0, arm64_l_21b0);
arm64_l_1bb4:
	/* 0x1bb4: and w8, w25, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1bb8:
	/* 0x1bb8: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_1bbc:
	/* 0x1bbc: tst w25, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1bc0:
	/* 0x1bc0: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1bc4:
	/* 0x1bc4: mov w9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_1bc8:
	/* 0x1bc8: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_1bcc:
	/* 0x1bcc: msub w8, w8, w9, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MSUB, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_X25, ARM64_WIDTH_32, 0, 0);
arm64_l_1bd0:
	/* 0x1bd0: b.eq 1be4 <generic_retuprobe_filter_arg+0x1be4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1bd0, 0x1be4, arm64_l_1be4);
arm64_l_1bd4:
	/* 0x1bd4: tst w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1bd8:
	/* 0x1bd8: mov w9, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1bdc:
	/* 0x1bdc: mov w11, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1be0:
	/* 0x1be0: b.eq 1c00 <generic_retuprobe_filter_arg+0x1c00> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1be0, 0x1c00, arm64_l_1c00);
arm64_l_1be4:
	/* 0x1be4: sub w8, w25, w8, uxtb */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_UXTB, 0), 0);
arm64_l_1be8:
	/* 0x1be8: and w9, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1bec:
	/* 0x1bec: add w8, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1bf0:
	/* 0x1bf0: and w11, w8, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1bf4:
	/* 0x1bf4: cmp w9, #0x78 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 120ULL);
arm64_l_1bf8:
	/* 0x1bf8: b.hi 2f9c <generic_retuprobe_filter_arg+0x2f9c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1bf8, 0x2f9c, arm64_l_2f9c);
arm64_l_1bfc:
	/* 0x1bfc: mov w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1c00:
	/* 0x1c00: and w8, w9, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1c04:
	/* 0x1c04: mov w9, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_1c08:
	/* 0x1c08: mul w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1c0c:
	/* 0x1c0c: lsr w8, w8, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_1c10:
	/* 0x1c10: sub w10, w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1c14:
	/* 0x1c14: b 2fec <generic_retuprobe_filter_arg+0x2fec> */
	ARM64_SIM_A64_JMP(0x1c14, 0x2fec, arm64_l_2fec);
arm64_l_1c18:
	/* 0x1c18: cmp x13, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c1c:
	/* 0x1c1c: ccmp x10, x12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_1c20:
	/* 0x1c20: cset w12, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_1c24:
	/* 0x1c24: orr w8, w8, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1c28:
	/* 0x1c28: cmp w11, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1c2c:
	/* 0x1c2c: b.cc 2aa0 <generic_retuprobe_filter_arg+0x2aa0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1c2c, 0x2aa0, arm64_l_2aa0);
arm64_l_1c30:
	/* 0x1c30: ldp x13, x12, [x21, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X13, ARM64_X12, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1c34:
	/* 0x1c34: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1c38:
	/* 0x1c38: b.eq 1c44 <generic_retuprobe_filter_arg+0x1c44> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c38, 0x1c44, arm64_l_1c44);
arm64_l_1c3c:
	/* 0x1c3c: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1c40:
	/* 0x1c40: b.ne 21c0 <generic_retuprobe_filter_arg+0x21c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1c40, 0x21c0, arm64_l_21c0);
arm64_l_1c44:
	/* 0x1c44: cmp x13, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c48:
	/* 0x1c48: ccmp x10, x12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_1c4c:
	/* 0x1c4c: cset w12, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_1c50:
	/* 0x1c50: b 21cc <generic_retuprobe_filter_arg+0x21cc> */
	ARM64_SIM_A64_JMP(0x1c50, 0x21cc, arm64_l_21cc);
arm64_l_1c54:
	/* 0x1c54: mov x19, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c58:
	/* 0x1c58: cmp w9, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1c5c:
	/* 0x1c5c: b.ne 1c68 <generic_retuprobe_filter_arg+0x1c68> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1c5c, 0x1c68, arm64_l_1c68);
arm64_l_1c60:
	/* 0x1c60: cbz x10, 1c68 <generic_retuprobe_filter_arg+0x1c68> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x1c60, 0x1c68, arm64_l_1c68);
arm64_l_1c64:
	/* 0x1c64: ldrb w19, [x10, #58] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 58ULL);
arm64_l_1c68:
	/* 0x1c68: cmp w9, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1c6c:
	/* 0x1c6c: b.eq 1c78 <generic_retuprobe_filter_arg+0x1c78> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c6c, 0x1c78, arm64_l_1c78);
arm64_l_1c70:
	/* 0x1c70: cmp w9, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_1c74:
	/* 0x1c74: b.ne 1fac <generic_retuprobe_filter_arg+0x1fac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1c74, 0x1fac, arm64_l_1fac);
arm64_l_1c78:
	/* 0x1c78: ldrb w8, [x21, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1c7c:
	/* 0x1c7c: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_1c80:
	/* 0x1c80: add x9, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1c84:
	/* 0x1c84: add x1, sp, #0xac */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1c88:
	/* 0x1c88: str w8, [sp, #172] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 172ULL);
arm64_l_1c8c:
	/* 0x1c8c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1c90:
	/* 0x1c90: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c94:
	/* 0x1c94: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1c98ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1c98:
	/* 0x1c98: cbz x0, 1cd0 <generic_retuprobe_filter_arg+0x1cd0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1c98, 0x1cd0, arm64_l_1cd0);
arm64_l_1c9c:
	/* 0x1c9c: str x19, [sp, #136] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1ca0:
	/* 0x1ca0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ca4:
	/* 0x1ca4: add x9, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1ca8:
	/* 0x1ca8: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1cac:
	/* 0x1cac: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1cb0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_1cb0:
	/* 0x1cb0: ldr w9, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1cb4:
	/* 0x1cb4: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1cb8:
	/* 0x1cb8: cmp w9, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_1cbc:
	/* 0x1cbc: b.ls 15c4 <generic_retuprobe_filter_arg+0x15c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1cbc, 0x15c4, arm64_l_15c4);
arm64_l_1cc0:
	/* 0x1cc0: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1cc4:
	/* 0x1cc4: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1cc8:
	/* 0x1cc8: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ccc:
	/* 0x1ccc: b 1784 <generic_retuprobe_filter_arg+0x1784> */
	ARM64_SIM_A64_JMP(0x1ccc, 0x1784, arm64_l_1784);
arm64_l_1cd0:
	/* 0x1cd0: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1cd4:
	/* 0x1cd4: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1cd8:
	/* 0x1cd8: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1cdc:
	/* 0x1cdc: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ce0:
	/* 0x1ce0: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1ce4:
	/* 0x1ce4: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x1ce4, 0x140, arm64_l_140);
arm64_l_1ce8:
	/* 0x1ce8: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x1ce8, 0xc4, arm64_l_c4);
arm64_l_1cec:
	/* 0x1cec: ldp x23, x19, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X23, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1cf0:
	/* 0x1cf0: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1cf4:
	/* 0x1cf4: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1cf8:
	/* 0x1cf8: ldr x16, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_1cfc:
	/* 0x1cfc: b 1d10 <generic_retuprobe_filter_arg+0x1d10> */
	ARM64_SIM_A64_JMP(0x1cfc, 0x1d10, arm64_l_1d10);
arm64_l_1d00:
	/* 0x1d00: ldr x16, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_1d04:
	/* 0x1d04: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1d08:
	/* 0x1d08: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1d0c:
	/* 0x1d0c: ldp x23, x19, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X23, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1d10:
	/* 0x1d10: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1d14:
	/* 0x1d14: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1d18:
	/* 0x1d18: ldr w8, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1d1c:
	/* 0x1d1c: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_1d20:
	/* 0x1d20: b.hi 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1d20, 0x1ce4, arm64_l_1ce4);
arm64_l_1d24:
	/* 0x1d24: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_1d28:
	/* 0x1d28: lsl x8, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1d2c:
	/* 0x1d2c: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_1d30:
	/* 0x1d30: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_1d34:
	/* 0x1d34: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d38:
	/* 0x1d38: b.ne 32f0 <generic_retuprobe_filter_arg+0x32f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1d38, 0x32f0, arm64_l_32f0);
arm64_l_1d3c:
	/* 0x1d3c: b 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JMP(0x1d3c, 0x1ce4, arm64_l_1ce4);
arm64_l_1d40:
	/* 0x1d40: cmp x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d44:
	/* 0x1d44: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1d48:
	/* 0x1d48: b.hi 1d54 <generic_retuprobe_filter_arg+0x1d54> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1d48, 0x1d54, arm64_l_1d54);
arm64_l_1d4c:
	/* 0x1d4c: cmp x8, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d50:
	/* 0x1d50: b.ls 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1d50, 0x140, arm64_l_140);
arm64_l_1d54:
	/* 0x1d54: cmp w10, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1d58:
	/* 0x1d58: b.cc c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1d58, 0xc4, arm64_l_c4);
arm64_l_1d5c:
	/* 0x1d5c: ldp x12, x11, [x21, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1d60:
	/* 0x1d60: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1d64:
	/* 0x1d64: b.eq 1d70 <generic_retuprobe_filter_arg+0x1d70> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d64, 0x1d70, arm64_l_1d70);
arm64_l_1d68:
	/* 0x1d68: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1d6c:
	/* 0x1d6c: b.ne 21fc <generic_retuprobe_filter_arg+0x21fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1d6c, 0x21fc, arm64_l_21fc);
arm64_l_1d70:
	/* 0x1d70: cmp x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d74:
	/* 0x1d74: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1d78:
	/* 0x1d78: b.gt 2210 <generic_retuprobe_filter_arg+0x2210> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1d78, 0x2210, arm64_l_2210);
arm64_l_1d7c:
	/* 0x1d7c: cmp x8, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d80:
	/* 0x1d80: b.le 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1d80, 0x140, arm64_l_140);
arm64_l_1d84:
	/* 0x1d84: b 2210 <generic_retuprobe_filter_arg+0x2210> */
	ARM64_SIM_A64_JMP(0x1d84, 0x2210, arm64_l_2210);
arm64_l_1d88:
	/* 0x1d88: ldr w8, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1d8c:
	/* 0x1d8c: and w8, w8, #0xfffffffe */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967294ULL);
arm64_l_1d90:
	/* 0x1d90: cmp w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1d94:
	/* 0x1d94: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1d98:
	/* 0x1d98: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1d9c:
	/* 0x1d9c: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1da0:
	/* 0x1da0: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1da4:
	/* 0x1da4: mov w22, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1da8:
	/* 0x1da8: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x1da8, 0x140, arm64_l_140);
arm64_l_1dac:
	/* 0x1dac: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x1dac, 0xc4, arm64_l_c4);
arm64_l_1db0:
	/* 0x1db0: ldr w8, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1db4:
	/* 0x1db4: ldp x19, x0, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X19, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1db8:
	/* 0x1db8: and w8, w8, #0xfffffffe */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967294ULL);
arm64_l_1dbc:
	/* 0x1dbc: cmp w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1dc0:
	/* 0x1dc0: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1dc4:
	/* 0x1dc4: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1dc8:
	/* 0x1dc8: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1dcc:
	/* 0x1dcc: mov w22, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1dd0:
	/* 0x1dd0: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x1dd0, 0x140, arm64_l_140);
arm64_l_1dd4:
	/* 0x1dd4: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x1dd4, 0xc4, arm64_l_c4);
arm64_l_1dd8:
	/* 0x1dd8: ldr w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ddc:
	/* 0x1ddc: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1de0:
	/* 0x1de0: b.hi 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1de0, 0x140, arm64_l_140);
arm64_l_1de4:
	/* 0x1de4: b 1df4 <generic_retuprobe_filter_arg+0x1df4> */
	ARM64_SIM_A64_JMP(0x1de4, 0x1df4, arm64_l_1df4);
arm64_l_1de8:
	/* 0x1de8: ldr w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1dec:
	/* 0x1dec: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1df0:
	/* 0x1df0: b.cc 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1df0, 0x140, arm64_l_140);
arm64_l_1df4:
	/* 0x1df4: ldr w10, [x21, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1df8:
	/* 0x1df8: cmp w10, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1dfc:
	/* 0x1dfc: b.cc 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1dfc, 0x124, arm64_l_124);
arm64_l_1e00:
	/* 0x1e00: ldr w11, [x21, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1e04:
	/* 0x1e04: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1e08:
	/* 0x1e08: b.le 1e2c <generic_retuprobe_filter_arg+0x1e2c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1e08, 0x1e2c, arm64_l_1e2c);
arm64_l_1e0c:
	/* 0x1e0c: sub w12, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1e10:
	/* 0x1e10: cmp w12, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1e14:
	/* 0x1e14: b.cs 1e68 <generic_retuprobe_filter_arg+0x1e68> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1e14, 0x1e68, arm64_l_1e68);
arm64_l_1e18:
	/* 0x1e18: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e1c:
	/* 0x1e1c: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e20:
	/* 0x1e20: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1e24:
	/* 0x1e24: b.ne 2700 <generic_retuprobe_filter_arg+0x2700> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1e24, 0x2700, arm64_l_2700);
arm64_l_1e28:
	/* 0x1e28: b 31dc <generic_retuprobe_filter_arg+0x31dc> */
	ARM64_SIM_A64_JMP(0x1e28, 0x31dc, arm64_l_31dc);
arm64_l_1e2c:
	/* 0x1e2c: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1e30:
	/* 0x1e30: b.eq 1e88 <generic_retuprobe_filter_arg+0x1e88> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e30, 0x1e88, arm64_l_1e88);
arm64_l_1e34:
	/* 0x1e34: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1e38:
	/* 0x1e38: b.ne 2700 <generic_retuprobe_filter_arg+0x2700> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1e38, 0x2700, arm64_l_2700);
arm64_l_1e3c:
	/* 0x1e3c: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1e40:
	/* 0x1e40: b.hi 26f0 <generic_retuprobe_filter_arg+0x26f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1e40, 0x26f0, arm64_l_26f0);
arm64_l_1e44:
	/* 0x1e44: lsl w12, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X12, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1e48:
	/* 0x1e48: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1e4c:
	/* 0x1e4c: tst w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e50:
	/* 0x1e50: b.eq 26f0 <generic_retuprobe_filter_arg+0x26f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e50, 0x26f0, arm64_l_26f0);
arm64_l_1e54:
	/* 0x1e54: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e58:
	/* 0x1e58: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e5c:
	/* 0x1e5c: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1e60:
	/* 0x1e60: b.lt 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x1e60, 0x140, arm64_l_140);
arm64_l_1e64:
	/* 0x1e64: b 2700 <generic_retuprobe_filter_arg+0x2700> */
	ARM64_SIM_A64_JMP(0x1e64, 0x2700, arm64_l_2700);
arm64_l_1e68:
	/* 0x1e68: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1e6c:
	/* 0x1e6c: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1e70:
	/* 0x1e70: b.ne 2700 <generic_retuprobe_filter_arg+0x2700> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1e70, 0x2700, arm64_l_2700);
arm64_l_1e74:
	/* 0x1e74: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1e78:
	/* 0x1e78: tst w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e7c:
	/* 0x1e7c: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1e80:
	/* 0x1e80: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1e80, 0x140, arm64_l_140);
arm64_l_1e84:
	/* 0x1e84: b 2700 <generic_retuprobe_filter_arg+0x2700> */
	ARM64_SIM_A64_JMP(0x1e84, 0x2700, arm64_l_2700);
arm64_l_1e88:
	/* 0x1e88: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1e8c:
	/* 0x1e8c: b.hi 26dc <generic_retuprobe_filter_arg+0x26dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1e8c, 0x26dc, arm64_l_26dc);
arm64_l_1e90:
	/* 0x1e90: lsl w12, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X12, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1e94:
	/* 0x1e94: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1e98:
	/* 0x1e98: tst w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e9c:
	/* 0x1e9c: b.eq 26dc <generic_retuprobe_filter_arg+0x26dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e9c, 0x26dc, arm64_l_26dc);
arm64_l_1ea0:
	/* 0x1ea0: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ea4:
	/* 0x1ea4: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ea8:
	/* 0x1ea8: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1eac:
	/* 0x1eac: b.gt 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1eac, 0x140, arm64_l_140);
arm64_l_1eb0:
	/* 0x1eb0: b 2700 <generic_retuprobe_filter_arg+0x2700> */
	ARM64_SIM_A64_JMP(0x1eb0, 0x2700, arm64_l_2700);
arm64_l_1eb4:
	/* 0x1eb4: and w8, w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1eb8:
	/* 0x1eb8: cmp w8, #0x201 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 513ULL);
arm64_l_1ebc:
	/* 0x1ebc: b.cs 231c <generic_retuprobe_filter_arg+0x231c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1ebc, 0x231c, arm64_l_231c);
arm64_l_1ec0:
	/* 0x1ec0: mov w11, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 512ULL);
arm64_l_1ec4:
	/* 0x1ec4: b 2850 <generic_retuprobe_filter_arg+0x2850> */
	ARM64_SIM_A64_JMP(0x1ec4, 0x2850, arm64_l_2850);
arm64_l_1ec8:
	/* 0x1ec8: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1ecc:
	/* 0x1ecc: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1ed0:
	/* 0x1ed0: ldr w8, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1ed4:
	/* 0x1ed4: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_1ed8:
	/* 0x1ed8: b.hi f00 <generic_retuprobe_filter_arg+0xf00> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1ed8, 0xf00, arm64_l_f00);
arm64_l_1edc:
	/* 0x1edc: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_1ee0:
	/* 0x1ee0: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1ee4:
	/* 0x1ee4: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1ee8:
	/* 0x1ee8: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1eec:
	/* 0x1eec: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_1ef0:
	/* 0x1ef0: lsl x8, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1ef4:
	/* 0x1ef4: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_1ef8:
	/* 0x1ef8: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1efc:
	/* 0x1efc: b.ne 2d50 <generic_retuprobe_filter_arg+0x2d50> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1efc, 0x2d50, arm64_l_2d50);
arm64_l_1f00:
	/* 0x1f00: b 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JMP(0x1f00, 0x1ce4, arm64_l_1ce4);
arm64_l_1f04:
	/* 0x1f04: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1f08:
	/* 0x1f08: b.eq 2588 <generic_retuprobe_filter_arg+0x2588> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f08, 0x2588, arm64_l_2588);
arm64_l_1f0c:
	/* 0x1f0c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1f10:
	/* 0x1f10: b.ne 2594 <generic_retuprobe_filter_arg+0x2594> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1f10, 0x2594, arm64_l_2594);
arm64_l_1f14:
	/* 0x1f14: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f18:
	/* 0x1f18: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f1c:
	/* 0x1f1c: b.hi 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1f1c, 0x140, arm64_l_140);
arm64_l_1f20:
	/* 0x1f20: b 2594 <generic_retuprobe_filter_arg+0x2594> */
	ARM64_SIM_A64_JMP(0x1f20, 0x2594, arm64_l_2594);
arm64_l_1f24:
	/* 0x1f24: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1f28:
	/* 0x1f28: b.eq 25c4 <generic_retuprobe_filter_arg+0x25c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f28, 0x25c4, arm64_l_25c4);
arm64_l_1f2c:
	/* 0x1f2c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1f30:
	/* 0x1f30: b.ne 25d0 <generic_retuprobe_filter_arg+0x25d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1f30, 0x25d0, arm64_l_25d0);
arm64_l_1f34:
	/* 0x1f34: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f38:
	/* 0x1f38: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f3c:
	/* 0x1f3c: b.hi 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1f3c, 0x140, arm64_l_140);
arm64_l_1f40:
	/* 0x1f40: b 25d0 <generic_retuprobe_filter_arg+0x25d0> */
	ARM64_SIM_A64_JMP(0x1f40, 0x25d0, arm64_l_25d0);
arm64_l_1f44:
	/* 0x1f44: cmp w8, #0x401 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1025ULL);
arm64_l_1f48:
	/* 0x1f48: b.cs 237c <generic_retuprobe_filter_arg+0x237c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1f48, 0x237c, arm64_l_237c);
arm64_l_1f4c:
	/* 0x1f4c: mov w11, #0x400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1024ULL);
arm64_l_1f50:
	/* 0x1f50: b 2390 <generic_retuprobe_filter_arg+0x2390> */
	ARM64_SIM_A64_JMP(0x1f50, 0x2390, arm64_l_2390);
arm64_l_1f54:
	/* 0x1f54: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1f58:
	/* 0x1f58: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1f5c:
	/* 0x1f5c: mov w22, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1f60:
	/* 0x1f60: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x1f60, 0x140, arm64_l_140);
arm64_l_1f64:
	/* 0x1f64: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x1f64, 0xc4, arm64_l_c4);
arm64_l_1f68:
	/* 0x1f68: cmp w13, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f6c:
	/* 0x1f6c: ccmp w10, w12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_1f70:
	/* 0x1f70: cset w12, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_1f74:
	/* 0x1f74: orr w8, w8, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_1f78:
	/* 0x1f78: cmp w11, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_1f7c:
	/* 0x1f7c: b.cc 2aa0 <generic_retuprobe_filter_arg+0x2aa0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1f7c, 0x2aa0, arm64_l_2aa0);
arm64_l_1f80:
	/* 0x1f80: ldp w13, w12, [x21, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X13, ARM64_X12, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1f84:
	/* 0x1f84: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1f88:
	/* 0x1f88: b.hi 2630 <generic_retuprobe_filter_arg+0x2630> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1f88, 0x2630, arm64_l_2630);
arm64_l_1f8c:
	/* 0x1f8c: lsl w14, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X14, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1f90:
	/* 0x1f90: mov w15, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1f94:
	/* 0x1f94: tst w14, w15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X14, ARM64_X15, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f98:
	/* 0x1f98: b.eq 2630 <generic_retuprobe_filter_arg+0x2630> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f98, 0x2630, arm64_l_2630);
arm64_l_1f9c:
	/* 0x1f9c: cmp w13, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fa0:
	/* 0x1fa0: ccmp w10, w12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_1fa4:
	/* 0x1fa4: cset w12, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_1fa8:
	/* 0x1fa8: b 263c <generic_retuprobe_filter_arg+0x263c> */
	ARM64_SIM_A64_JMP(0x1fa8, 0x263c, arm64_l_263c);
arm64_l_1fac:
	/* 0x1fac: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1fb0:
	/* 0x1fb0: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1fb4:
	/* 0x1fb4: cbnz xzr, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_XZR, 0x1fb4, 0x140, arm64_l_140);
arm64_l_1fb8:
	/* 0x1fb8: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x1fb8, 0xc4, arm64_l_c4);
arm64_l_1fbc:
	/* 0x1fbc: mov w11, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_1fc0:
	/* 0x1fc0: b 1fd0 <generic_retuprobe_filter_arg+0x1fd0> */
	ARM64_SIM_A64_JMP(0x1fc0, 0x1fd0, arm64_l_1fd0);
arm64_l_1fc4:
	/* 0x1fc4: mov w11, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 6ULL);
arm64_l_1fc8:
	/* 0x1fc8: b 1fd0 <generic_retuprobe_filter_arg+0x1fd0> */
	ARM64_SIM_A64_JMP(0x1fc8, 0x1fd0, arm64_l_1fd0);
arm64_l_1fcc:
	/* 0x1fcc: mov w11, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1fd0:
	/* 0x1fd0: add x8, x21, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1fd4:
	/* 0x1fd4: and w9, w11, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_1fd8:
	/* 0x1fd8: ldr w8, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_1fdc:
	/* 0x1fdc: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1fe0:
	/* 0x1fe0: b.eq 2090 <generic_retuprobe_filter_arg+0x2090> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1fe0, 0x2090, arm64_l_2090);
arm64_l_1fe4:
	/* 0x1fe4: str w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1fe8:
	/* 0x1fe8: stp w13, w11, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X13, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_1fec:
	/* 0x1fec: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_19));
arm64_l_1ff0:
	/* 0x1ff0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ff4:
	/* 0x1ff4: add x22, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1ff8:
	/* 0x1ff8: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1ffc:
	/* 0x1ffc: str x10, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2000:
	/* 0x2000: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2004:
	/* 0x2004: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2008ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2008:
	/* 0x2008: mov x25, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_200c:
	/* 0x200c: adrp x0, 0 <heap_ro_zero> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero_4));
arm64_l_2010:
	/* 0x2010: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2014:
	/* 0x2014: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2018:
	/* 0x2018: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_201c:
	/* 0x201c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2020ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2020:
	/* 0x2020: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2024:
	/* 0x2024: cbz x25, 2d20 <generic_retuprobe_filter_arg+0x2d20> */
	ARM64_SIM_A64_CBZ(ARM64_X25, 0x2024, 0x2d20, arm64_l_2d20);
arm64_l_2028:
	/* 0x2028: mov x9, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_202c:
	/* 0x202c: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2030:
	/* 0x2030: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2034:
	/* 0x2034: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2038:
	/* 0x2038: cbz x9, 2d2c <generic_retuprobe_filter_arg+0x2d2c> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x2038, 0x2d2c, arm64_l_2d2c);
arm64_l_203c:
	/* 0x203c: mov x8, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2040:
	/* 0x2040: ldr w25, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2044:
	/* 0x2044: mov x22, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2048:
	/* 0x2048: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_204c:
	/* 0x204c: str x8, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2050:
	/* 0x2050: cmp w25, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2054:
	/* 0x2054: b.gt 20a4 <generic_retuprobe_filter_arg+0x20a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2054, 0x20a4, arm64_l_20a4);
arm64_l_2058:
	/* 0x2058: strb w29, [x0], #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 1ULL);
arm64_l_205c:
	/* 0x205c: ldr x2, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2060:
	/* 0x2060: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2064:
	/* 0x2064: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2068:
	/* 0x2068: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x206cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_206c:
	/* 0x206c: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2070:
	/* 0x2070: subs w8, w8, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2074:
	/* 0x2074: b.ls 20e0 <generic_retuprobe_filter_arg+0x20e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2074, 0x20e0, arm64_l_20e0);
arm64_l_2078:
	/* 0x2078: ldr x9, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_207c:
	/* 0x207c: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2080:
	/* 0x2080: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2084:
	/* 0x2084: add x9, x9, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2088:
	/* 0x2088: add x0, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_208c:
	/* 0x208c: b 20d8 <generic_retuprobe_filter_arg+0x20d8> */
	ARM64_SIM_A64_JMP(0x208c, 0x20d8, arm64_l_20d8);
arm64_l_2090:
	/* 0x2090: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2094:
	/* 0x2094: ldr w8, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2098:
	/* 0x2098: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_209c:
	/* 0x209c: b.ls 2d38 <generic_retuprobe_filter_arg+0x2d38> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x209c, 0x2d38, arm64_l_2d38);
arm64_l_20a0:
	/* 0x20a0: b 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JMP(0x20a0, 0x1ce4, arm64_l_1ce4);
arm64_l_20a4:
	/* 0x20a4: strh w29, [x0], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_20a8:
	/* 0x20a8: ldr x2, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_20ac:
	/* 0x20ac: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_20b0:
	/* 0x20b0: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_20b4:
	/* 0x20b4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x20b8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_20b8:
	/* 0x20b8: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_20bc:
	/* 0x20bc: subs w8, w8, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_20c0:
	/* 0x20c0: b.ls 20e0 <generic_retuprobe_filter_arg+0x20e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x20c0, 0x20e0, arm64_l_20e0);
arm64_l_20c4:
	/* 0x20c4: ldr x9, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_20c8:
	/* 0x20c8: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_20cc:
	/* 0x20cc: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_20d0:
	/* 0x20d0: add x9, x9, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_20d4:
	/* 0x20d4: add x0, x9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_20d8:
	/* 0x20d8: mov x2, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_20dc:
	/* 0x20dc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x20e0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_20e0:
	/* 0x20e0: ldr w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_20e4:
	/* 0x20e4: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_20e8:
	/* 0x20e8: cmp w25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_20ec:
	/* 0x20ec: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_20f0:
	/* 0x20f0: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_20f4:
	/* 0x20f4: b.le 212c <generic_retuprobe_filter_arg+0x212c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x20f4, 0x212c, arm64_l_212c);
arm64_l_20f8:
	/* 0x20f8: cmp w25, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_20fc:
	/* 0x20fc: b.gt 2350 <generic_retuprobe_filter_arg+0x2350> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x20fc, 0x2350, arm64_l_2350);
arm64_l_2100:
	/* 0x2100: cmp w25, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2104:
	/* 0x2104: b.eq 2cd4 <generic_retuprobe_filter_arg+0x2cd4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2104, 0x2cd4, arm64_l_2cd4);
arm64_l_2108:
	/* 0x2108: cmp w25, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_210c:
	/* 0x210c: b.eq 2c98 <generic_retuprobe_filter_arg+0x2c98> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x210c, 0x2c98, arm64_l_2c98);
arm64_l_2110:
	/* 0x2110: cmp w25, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_2114:
	/* 0x2114: b.ne 2d5c <generic_retuprobe_filter_arg+0x2d5c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2114, 0x2d5c, arm64_l_2d5c);
arm64_l_2118:
	/* 0x2118: adrp x0, 0 <string_maps_7> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_7_16));
arm64_l_211c:
	/* 0x211c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2120:
	/* 0x2120: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2124:
	/* 0x2124: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2128:
	/* 0x2128: b 2cf8 <generic_retuprobe_filter_arg+0x2cf8> */
	ARM64_SIM_A64_JMP(0x2128, 0x2cf8, arm64_l_2cf8);
arm64_l_212c:
	/* 0x212c: cmp w25, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2130:
	/* 0x2130: b.le 27c8 <generic_retuprobe_filter_arg+0x27c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2130, 0x27c8, arm64_l_27c8);
arm64_l_2134:
	/* 0x2134: cmp w25, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2138:
	/* 0x2138: b.eq 2cc0 <generic_retuprobe_filter_arg+0x2cc0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2138, 0x2cc0, arm64_l_2cc0);
arm64_l_213c:
	/* 0x213c: cmp w25, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2140:
	/* 0x2140: b.eq 2c84 <generic_retuprobe_filter_arg+0x2c84> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2140, 0x2c84, arm64_l_2c84);
arm64_l_2144:
	/* 0x2144: cmp w25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2148:
	/* 0x2148: b.ne 2d5c <generic_retuprobe_filter_arg+0x2d5c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2148, 0x2d5c, arm64_l_2d5c);
arm64_l_214c:
	/* 0x214c: adrp x0, 0 <string_maps_4> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_4_13));
arm64_l_2150:
	/* 0x2150: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2154:
	/* 0x2154: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2158:
	/* 0x2158: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_215c:
	/* 0x215c: b 2cf8 <generic_retuprobe_filter_arg+0x2cf8> */
	ARM64_SIM_A64_JMP(0x215c, 0x2cf8, arm64_l_2cf8);
arm64_l_2160:
	/* 0x2160: cmp w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2164:
	/* 0x2164: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2168:
	/* 0x2168: b.hi 2174 <generic_retuprobe_filter_arg+0x2174> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2168, 0x2174, arm64_l_2174);
arm64_l_216c:
	/* 0x216c: cmp w8, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2170:
	/* 0x2170: b.ls 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2170, 0x140, arm64_l_140);
arm64_l_2174:
	/* 0x2174: cmp w10, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_2178:
	/* 0x2178: b.cc c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2178, 0xc4, arm64_l_c4);
arm64_l_217c:
	/* 0x217c: ldp w12, w11, [x21, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2180:
	/* 0x2180: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2184:
	/* 0x2184: b.hi 2690 <generic_retuprobe_filter_arg+0x2690> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2184, 0x2690, arm64_l_2690);
arm64_l_2188:
	/* 0x2188: lsl w13, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X13, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_218c:
	/* 0x218c: mov w14, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2190:
	/* 0x2190: tst w13, w14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X13, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2194:
	/* 0x2194: b.eq 2690 <generic_retuprobe_filter_arg+0x2690> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2194, 0x2690, arm64_l_2690);
arm64_l_2198:
	/* 0x2198: cmp w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_219c:
	/* 0x219c: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_21a0:
	/* 0x21a0: b.gt 26a4 <generic_retuprobe_filter_arg+0x26a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x21a0, 0x26a4, arm64_l_26a4);
arm64_l_21a4:
	/* 0x21a4: cmp w8, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_21a8:
	/* 0x21a8: b.le 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x21a8, 0x140, arm64_l_140);
arm64_l_21ac:
	/* 0x21ac: b 26a4 <generic_retuprobe_filter_arg+0x26a4> */
	ARM64_SIM_A64_JMP(0x21ac, 0x26a4, arm64_l_26a4);
arm64_l_21b0:
	/* 0x21b0: cmp w8, #0x101 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 257ULL);
arm64_l_21b4:
	/* 0x21b4: b.cs 267c <generic_retuprobe_filter_arg+0x267c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x21b4, 0x267c, arm64_l_267c);
arm64_l_21b8:
	/* 0x21b8: mov w11, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_21bc:
	/* 0x21bc: b 2f9c <generic_retuprobe_filter_arg+0x2f9c> */
	ARM64_SIM_A64_JMP(0x21bc, 0x2f9c, arm64_l_2f9c);
arm64_l_21c0:
	/* 0x21c0: cmp x13, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_21c4:
	/* 0x21c4: ccmp x10, x12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_21c8:
	/* 0x21c8: cset w12, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_21cc:
	/* 0x21cc: orr w8, w8, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_21d0:
	/* 0x21d0: cmp w11, #0x39 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 57ULL);
arm64_l_21d4:
	/* 0x21d4: b.cc 2aa0 <generic_retuprobe_filter_arg+0x2aa0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x21d4, 0x2aa0, arm64_l_2aa0);
arm64_l_21d8:
	/* 0x21d8: ldp x12, x11, [x21, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_21dc:
	/* 0x21dc: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_21e0:
	/* 0x21e0: b.eq 21ec <generic_retuprobe_filter_arg+0x21ec> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x21e0, 0x21ec, arm64_l_21ec);
arm64_l_21e4:
	/* 0x21e4: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_21e8:
	/* 0x21e8: b.ne 27bc <generic_retuprobe_filter_arg+0x27bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x21e8, 0x27bc, arm64_l_27bc);
arm64_l_21ec:
	/* 0x21ec: cmp x12, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_21f0:
	/* 0x21f0: ccmp x10, x11, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_21f4:
	/* 0x21f4: cset w9, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_21f8:
	/* 0x21f8: b 2a9c <generic_retuprobe_filter_arg+0x2a9c> */
	ARM64_SIM_A64_JMP(0x21f8, 0x2a9c, arm64_l_2a9c);
arm64_l_21fc:
	/* 0x21fc: cmp x12, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2200:
	/* 0x2200: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2204:
	/* 0x2204: b.hi 2210 <generic_retuprobe_filter_arg+0x2210> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2204, 0x2210, arm64_l_2210);
arm64_l_2208:
	/* 0x2208: cmp x8, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_220c:
	/* 0x220c: b.ls 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x220c, 0x140, arm64_l_140);
arm64_l_2210:
	/* 0x2210: cmp w10, #0x39 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 57ULL);
arm64_l_2214:
	/* 0x2214: b.cc c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2214, 0xc4, arm64_l_c4);
arm64_l_2218:
	/* 0x2218: ldp x11, x10, [x21, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_221c:
	/* 0x221c: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2220:
	/* 0x2220: b.eq 222c <generic_retuprobe_filter_arg+0x222c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2220, 0x222c, arm64_l_222c);
arm64_l_2224:
	/* 0x2224: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2228:
	/* 0x2228: b.ne 27e8 <generic_retuprobe_filter_arg+0x27e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2228, 0x27e8, arm64_l_27e8);
arm64_l_222c:
	/* 0x222c: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2230:
	/* 0x2230: b.gt c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2230, 0xc4, arm64_l_c4);
arm64_l_2234:
	/* 0x2234: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2238:
	/* 0x2238: b.le 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2238, 0x140, arm64_l_140);
arm64_l_223c:
	/* 0x223c: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x223c, 0xc4, arm64_l_c4);
arm64_l_2240:
	/* 0x2240: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2244:
	/* 0x2244: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2248:
	/* 0x2248: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_224c:
	/* 0x224c: b.hi 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x224c, 0x140, arm64_l_140);
arm64_l_2250:
	/* 0x2250: b 2264 <generic_retuprobe_filter_arg+0x2264> */
	ARM64_SIM_A64_JMP(0x2250, 0x2264, arm64_l_2264);
arm64_l_2254:
	/* 0x2254: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2258:
	/* 0x2258: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_225c:
	/* 0x225c: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2260:
	/* 0x2260: b.cc 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2260, 0x140, arm64_l_140);
arm64_l_2264:
	/* 0x2264: cmp w10, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_2268:
	/* 0x2268: b.cc 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2268, 0x124, arm64_l_124);
arm64_l_226c:
	/* 0x226c: ldr x11, [x21, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2270:
	/* 0x2270: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2274:
	/* 0x2274: b.le 2298 <generic_retuprobe_filter_arg+0x2298> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2274, 0x2298, arm64_l_2298);
arm64_l_2278:
	/* 0x2278: sub w12, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_227c:
	/* 0x227c: cmp w12, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2280:
	/* 0x2280: b.cs 22cc <generic_retuprobe_filter_arg+0x22cc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2280, 0x22cc, arm64_l_22cc);
arm64_l_2284:
	/* 0x2284: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2288:
	/* 0x2288: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_228c:
	/* 0x228c: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2290:
	/* 0x2290: b.ne 2ad0 <generic_retuprobe_filter_arg+0x2ad0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2290, 0x2ad0, arm64_l_2ad0);
arm64_l_2294:
	/* 0x2294: b 31dc <generic_retuprobe_filter_arg+0x31dc> */
	ARM64_SIM_A64_JMP(0x2294, 0x31dc, arm64_l_31dc);
arm64_l_2298:
	/* 0x2298: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_229c:
	/* 0x229c: b.eq 232c <generic_retuprobe_filter_arg+0x232c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x229c, 0x232c, arm64_l_232c);
arm64_l_22a0:
	/* 0x22a0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_22a4:
	/* 0x22a4: b.ne 2ad0 <generic_retuprobe_filter_arg+0x2ad0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x22a4, 0x2ad0, arm64_l_2ad0);
arm64_l_22a8:
	/* 0x22a8: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_22ac:
	/* 0x22ac: b.eq 22b8 <generic_retuprobe_filter_arg+0x22b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x22ac, 0x22b8, arm64_l_22b8);
arm64_l_22b0:
	/* 0x22b0: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_22b4:
	/* 0x22b4: b.ne 2ac0 <generic_retuprobe_filter_arg+0x2ac0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x22b4, 0x2ac0, arm64_l_2ac0);
arm64_l_22b8:
	/* 0x22b8: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_22bc:
	/* 0x22bc: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_22c0:
	/* 0x22c0: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_22c4:
	/* 0x22c4: b.lt 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x22c4, 0x140, arm64_l_140);
arm64_l_22c8:
	/* 0x22c8: b 2ad0 <generic_retuprobe_filter_arg+0x2ad0> */
	ARM64_SIM_A64_JMP(0x22c8, 0x2ad0, arm64_l_2ad0);
arm64_l_22cc:
	/* 0x22cc: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_22d0:
	/* 0x22d0: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_22d4:
	/* 0x22d4: b.ne 2ad0 <generic_retuprobe_filter_arg+0x2ad0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x22d4, 0x2ad0, arm64_l_2ad0);
arm64_l_22d8:
	/* 0x22d8: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_22dc:
	/* 0x22dc: tst x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_22e0:
	/* 0x22e0: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_22e4:
	/* 0x22e4: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x22e4, 0x140, arm64_l_140);
arm64_l_22e8:
	/* 0x22e8: b 2ad0 <generic_retuprobe_filter_arg+0x2ad0> */
	ARM64_SIM_A64_JMP(0x22e8, 0x2ad0, arm64_l_2ad0);
arm64_l_22ec:
	/* 0x22ec: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_22f0:
	/* 0x22f0: b.ne 2594 <generic_retuprobe_filter_arg+0x2594> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x22f0, 0x2594, arm64_l_2594);
arm64_l_22f4:
	/* 0x22f4: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_22f8:
	/* 0x22f8: tst w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_22fc:
	/* 0x22fc: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x22fc, 0x140, arm64_l_140);
arm64_l_2300:
	/* 0x2300: b 2594 <generic_retuprobe_filter_arg+0x2594> */
	ARM64_SIM_A64_JMP(0x2300, 0x2594, arm64_l_2594);
arm64_l_2304:
	/* 0x2304: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2308:
	/* 0x2308: b.ne 25d0 <generic_retuprobe_filter_arg+0x25d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2308, 0x25d0, arm64_l_25d0);
arm64_l_230c:
	/* 0x230c: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2310:
	/* 0x2310: tst w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2314:
	/* 0x2314: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2314, 0x140, arm64_l_140);
arm64_l_2318:
	/* 0x2318: b 25d0 <generic_retuprobe_filter_arg+0x25d0> */
	ARM64_SIM_A64_JMP(0x2318, 0x25d0, arm64_l_25d0);
arm64_l_231c:
	/* 0x231c: cmp w8, #0x401 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1025ULL);
arm64_l_2320:
	/* 0x2320: b.cs 283c <generic_retuprobe_filter_arg+0x283c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2320, 0x283c, arm64_l_283c);
arm64_l_2324:
	/* 0x2324: mov w11, #0x400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1024ULL);
arm64_l_2328:
	/* 0x2328: b 2850 <generic_retuprobe_filter_arg+0x2850> */
	ARM64_SIM_A64_JMP(0x2328, 0x2850, arm64_l_2850);
arm64_l_232c:
	/* 0x232c: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2330:
	/* 0x2330: b.eq 233c <generic_retuprobe_filter_arg+0x233c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2330, 0x233c, arm64_l_233c);
arm64_l_2334:
	/* 0x2334: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2338:
	/* 0x2338: b.ne 2aac <generic_retuprobe_filter_arg+0x2aac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2338, 0x2aac, arm64_l_2aac);
arm64_l_233c:
	/* 0x233c: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2340:
	/* 0x2340: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2344:
	/* 0x2344: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2348:
	/* 0x2348: b.gt 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2348, 0x140, arm64_l_140);
arm64_l_234c:
	/* 0x234c: b 2ad0 <generic_retuprobe_filter_arg+0x2ad0> */
	ARM64_SIM_A64_JMP(0x234c, 0x2ad0, arm64_l_2ad0);
arm64_l_2350:
	/* 0x2350: cmp w25, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2354:
	/* 0x2354: b.eq 2ce8 <generic_retuprobe_filter_arg+0x2ce8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2354, 0x2ce8, arm64_l_2ce8);
arm64_l_2358:
	/* 0x2358: cmp w25, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_235c:
	/* 0x235c: b.eq 2cac <generic_retuprobe_filter_arg+0x2cac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x235c, 0x2cac, arm64_l_2cac);
arm64_l_2360:
	/* 0x2360: cmp w25, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2364:
	/* 0x2364: b.ne 2d5c <generic_retuprobe_filter_arg+0x2d5c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2364, 0x2d5c, arm64_l_2d5c);
arm64_l_2368:
	/* 0x2368: adrp x0, 0 <string_maps_10> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_10_10));
arm64_l_236c:
	/* 0x236c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2370:
	/* 0x2370: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2374:
	/* 0x2374: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2378:
	/* 0x2378: b 2cf8 <generic_retuprobe_filter_arg+0x2cf8> */
	ARM64_SIM_A64_JMP(0x2378, 0x2cf8, arm64_l_2cf8);
arm64_l_237c:
	/* 0x237c: and w8, w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_2380:
	/* 0x2380: mov w9, #0x1000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_2384:
	/* 0x2384: cmp w8, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2048ULL);
arm64_l_2388:
	/* 0x2388: mov w8, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_238c:
	/* 0x238c: csel w11, w9, w8, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_2390:
	/* 0x2390: sub w8, w11, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_2394:
	/* 0x2394: ror w8, w8, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_ROR), 8ULL);
arm64_l_2398:
	/* 0x2398: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_239c:
	/* 0x239c: b.gt 23b4 <generic_retuprobe_filter_arg+0x23b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x239c, 0x23b4, arm64_l_23b4);
arm64_l_23a0:
	/* 0x23a0: cbz w8, 23d4 <generic_retuprobe_filter_arg+0x23d4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x23a0, 0x23d4, arm64_l_23d4);
arm64_l_23a4:
	/* 0x23a4: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_23a8:
	/* 0x23a8: b.ne 23cc <generic_retuprobe_filter_arg+0x23cc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x23a8, 0x23cc, arm64_l_23cc);
arm64_l_23ac:
	/* 0x23ac: mov w10, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 7ULL);
arm64_l_23b0:
	/* 0x23b0: b 23e0 <generic_retuprobe_filter_arg+0x23e0> */
	ARM64_SIM_A64_JMP(0x23b0, 0x23e0, arm64_l_23e0);
arm64_l_23b4:
	/* 0x23b4: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_23b8:
	/* 0x23b8: b.eq 23dc <generic_retuprobe_filter_arg+0x23dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x23b8, 0x23dc, arm64_l_23dc);
arm64_l_23bc:
	/* 0x23bc: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_23c0:
	/* 0x23c0: b.ne 23cc <generic_retuprobe_filter_arg+0x23cc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x23c0, 0x23cc, arm64_l_23cc);
arm64_l_23c4:
	/* 0x23c4: mov w10, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 9ULL);
arm64_l_23c8:
	/* 0x23c8: b 23e0 <generic_retuprobe_filter_arg+0x23e0> */
	ARM64_SIM_A64_JMP(0x23c8, 0x23e0, arm64_l_23e0);
arm64_l_23cc:
	/* 0x23cc: mov w10, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_23d0:
	/* 0x23d0: b 23e0 <generic_retuprobe_filter_arg+0x23e0> */
	ARM64_SIM_A64_JMP(0x23d0, 0x23e0, arm64_l_23e0);
arm64_l_23d4:
	/* 0x23d4: mov w10, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 6ULL);
arm64_l_23d8:
	/* 0x23d8: b 23e0 <generic_retuprobe_filter_arg+0x23e0> */
	ARM64_SIM_A64_JMP(0x23d8, 0x23e0, arm64_l_23e0);
arm64_l_23dc:
	/* 0x23dc: mov w10, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_23e0:
	/* 0x23e0: add x8, x21, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_23e4:
	/* 0x23e4: and w9, w10, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_23e8:
	/* 0x23e8: ldr w8, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_23ec:
	/* 0x23ec: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_23f0:
	/* 0x23f0: b.eq 2d1c <generic_retuprobe_filter_arg+0x2d1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x23f0, 0x2d1c, arm64_l_2d1c);
arm64_l_23f4:
	/* 0x23f4: str w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_23f8:
	/* 0x23f8: str w11, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_23fc:
	/* 0x23fc: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_19));
arm64_l_2400:
	/* 0x2400: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2404:
	/* 0x2404: add x22, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_2408:
	/* 0x2408: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_240c:
	/* 0x240c: str w10, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2410:
	/* 0x2410: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2414:
	/* 0x2414: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2418ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2418:
	/* 0x2418: str x0, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_241c:
	/* 0x241c: adrp x0, 0 <heap_ro_zero> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero_4));
arm64_l_2420:
	/* 0x2420: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2424:
	/* 0x2424: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_2428:
	/* 0x2428: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_242c:
	/* 0x242c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2430ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2430:
	/* 0x2430: ldr x10, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2434:
	/* 0x2434: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2438:
	/* 0x2438: cbz x10, 2d20 <generic_retuprobe_filter_arg+0x2d20> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x2438, 0x2d20, arm64_l_2d20);
arm64_l_243c:
	/* 0x243c: mov x9, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2440:
	/* 0x2440: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2444:
	/* 0x2444: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2448:
	/* 0x2448: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_244c:
	/* 0x244c: cbz x9, 2d2c <generic_retuprobe_filter_arg+0x2d2c> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x244c, 0x2d2c, arm64_l_2d2c);
arm64_l_2450:
	/* 0x2450: mov x22, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2454:
	/* 0x2454: ldr w9, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2458:
	/* 0x2458: mov x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_245c:
	/* 0x245c: add x2, x25, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2460:
	/* 0x2460: mov x25, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2464:
	/* 0x2464: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2468:
	/* 0x2468: cmp w9, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_246c:
	/* 0x246c: b.gt 24a0 <generic_retuprobe_filter_arg+0x24a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x246c, 0x24a0, arm64_l_24a0);
arm64_l_2470:
	/* 0x2470: strb w29, [x0], #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 1ULL);
arm64_l_2474:
	/* 0x2474: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2478:
	/* 0x2478: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_247c:
	/* 0x247c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2480ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2480:
	/* 0x2480: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2484:
	/* 0x2484: subs w8, w8, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2488:
	/* 0x2488: b.ls 24d4 <generic_retuprobe_filter_arg+0x24d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2488, 0x24d4, arm64_l_24d4);
arm64_l_248c:
	/* 0x248c: add x9, x25, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X25, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2490:
	/* 0x2490: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2494:
	/* 0x2494: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2498:
	/* 0x2498: add x0, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_249c:
	/* 0x249c: b 24cc <generic_retuprobe_filter_arg+0x24cc> */
	ARM64_SIM_A64_JMP(0x249c, 0x24cc, arm64_l_24cc);
arm64_l_24a0:
	/* 0x24a0: strh w29, [x0], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_24a4:
	/* 0x24a4: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_24a8:
	/* 0x24a8: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_24ac:
	/* 0x24ac: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x24b0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_24b0:
	/* 0x24b0: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_24b4:
	/* 0x24b4: subs w8, w8, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_24b8:
	/* 0x24b8: b.ls 24d4 <generic_retuprobe_filter_arg+0x24d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x24b8, 0x24d4, arm64_l_24d4);
arm64_l_24bc:
	/* 0x24bc: add x9, x25, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X25, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_24c0:
	/* 0x24c0: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_24c4:
	/* 0x24c4: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_24c8:
	/* 0x24c8: add x0, x9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_24cc:
	/* 0x24cc: mov x2, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_24d0:
	/* 0x24d0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x24d4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_24d4:
	/* 0x24d4: ldr w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_24d8:
	/* 0x24d8: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_24dc:
	/* 0x24dc: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_24e0:
	/* 0x24e0: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_24e4:
	/* 0x24e4: ldr w8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_24e8:
	/* 0x24e8: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_24ec:
	/* 0x24ec: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_24f0:
	/* 0x24f0: b.le 2528 <generic_retuprobe_filter_arg+0x2528> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x24f0, 0x2528, arm64_l_2528);
arm64_l_24f4:
	/* 0x24f4: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_24f8:
	/* 0x24f8: b.gt 255c <generic_retuprobe_filter_arg+0x255c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x24f8, 0x255c, arm64_l_255c);
arm64_l_24fc:
	/* 0x24fc: cmp w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2500:
	/* 0x2500: b.eq 2be4 <generic_retuprobe_filter_arg+0x2be4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2500, 0x2be4, arm64_l_2be4);
arm64_l_2504:
	/* 0x2504: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2508:
	/* 0x2508: b.eq 2ba8 <generic_retuprobe_filter_arg+0x2ba8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2508, 0x2ba8, arm64_l_2ba8);
arm64_l_250c:
	/* 0x250c: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_2510:
	/* 0x2510: b.ne 664 <generic_retuprobe_filter_arg+0x664> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2510, 0x664, arm64_l_664);
arm64_l_2514:
	/* 0x2514: adrp x0, 0 <string_maps_7> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_7_16));
arm64_l_2518:
	/* 0x2518: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_251c:
	/* 0x251c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2520:
	/* 0x2520: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2524:
	/* 0x2524: b 2c08 <generic_retuprobe_filter_arg+0x2c08> */
	ARM64_SIM_A64_JMP(0x2524, 0x2c08, arm64_l_2c08);
arm64_l_2528:
	/* 0x2528: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_252c:
	/* 0x252c: b.le 2610 <generic_retuprobe_filter_arg+0x2610> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x252c, 0x2610, arm64_l_2610);
arm64_l_2530:
	/* 0x2530: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2534:
	/* 0x2534: b.eq 2bd0 <generic_retuprobe_filter_arg+0x2bd0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2534, 0x2bd0, arm64_l_2bd0);
arm64_l_2538:
	/* 0x2538: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_253c:
	/* 0x253c: b.eq 2b94 <generic_retuprobe_filter_arg+0x2b94> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x253c, 0x2b94, arm64_l_2b94);
arm64_l_2540:
	/* 0x2540: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2544:
	/* 0x2544: b.ne 664 <generic_retuprobe_filter_arg+0x664> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2544, 0x664, arm64_l_664);
arm64_l_2548:
	/* 0x2548: adrp x0, 0 <string_maps_4> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_4_13));
arm64_l_254c:
	/* 0x254c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2550:
	/* 0x2550: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2554:
	/* 0x2554: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2558:
	/* 0x2558: b 2c08 <generic_retuprobe_filter_arg+0x2c08> */
	ARM64_SIM_A64_JMP(0x2558, 0x2c08, arm64_l_2c08);
arm64_l_255c:
	/* 0x255c: cmp w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2560:
	/* 0x2560: b.eq 2bf8 <generic_retuprobe_filter_arg+0x2bf8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2560, 0x2bf8, arm64_l_2bf8);
arm64_l_2564:
	/* 0x2564: cmp w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_2568:
	/* 0x2568: b.eq 2bbc <generic_retuprobe_filter_arg+0x2bbc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2568, 0x2bbc, arm64_l_2bbc);
arm64_l_256c:
	/* 0x256c: cmp w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2570:
	/* 0x2570: b.ne 664 <generic_retuprobe_filter_arg+0x664> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2570, 0x664, arm64_l_664);
arm64_l_2574:
	/* 0x2574: adrp x0, 0 <string_maps_10> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_10_10));
arm64_l_2578:
	/* 0x2578: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_257c:
	/* 0x257c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2580:
	/* 0x2580: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2584:
	/* 0x2584: b 2c08 <generic_retuprobe_filter_arg+0x2c08> */
	ARM64_SIM_A64_JMP(0x2584, 0x2c08, arm64_l_2c08);
arm64_l_2588:
	/* 0x2588: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_258c:
	/* 0x258c: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2590:
	/* 0x2590: b.cc 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2590, 0x140, arm64_l_140);
arm64_l_2594:
	/* 0x2594: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2598:
	/* 0x2598: b.cc 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2598, 0x124, arm64_l_124);
arm64_l_259c:
	/* 0x259c: ldr w10, [x21, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_25a0:
	/* 0x25a0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_25a4:
	/* 0x25a4: b.le 27fc <generic_retuprobe_filter_arg+0x27fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x25a4, 0x27fc, arm64_l_27fc);
arm64_l_25a8:
	/* 0x25a8: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_25ac:
	/* 0x25ac: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_25b0:
	/* 0x25b0: b.cs 2b50 <generic_retuprobe_filter_arg+0x2b50> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x25b0, 0x2b50, arm64_l_2b50);
arm64_l_25b4:
	/* 0x25b4: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_25b8:
	/* 0x25b8: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_25bc:
	/* 0x25bc: b.ne 2e40 <generic_retuprobe_filter_arg+0x2e40> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x25bc, 0x2e40, arm64_l_2e40);
arm64_l_25c0:
	/* 0x25c0: b 31dc <generic_retuprobe_filter_arg+0x31dc> */
	ARM64_SIM_A64_JMP(0x25c0, 0x31dc, arm64_l_31dc);
arm64_l_25c4:
	/* 0x25c4: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_25c8:
	/* 0x25c8: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_25cc:
	/* 0x25cc: b.cc 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x25cc, 0x140, arm64_l_140);
arm64_l_25d0:
	/* 0x25d0: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_25d4:
	/* 0x25d4: b.cc 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x25d4, 0x124, arm64_l_124);
arm64_l_25d8:
	/* 0x25d8: ldr w10, [x21, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_25dc:
	/* 0x25dc: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_25e0:
	/* 0x25e0: b.le 281c <generic_retuprobe_filter_arg+0x281c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x25e0, 0x281c, arm64_l_281c);
arm64_l_25e4:
	/* 0x25e4: sub w11, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_25e8:
	/* 0x25e8: cmp w11, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_25ec:
	/* 0x25ec: b.cs 2b68 <generic_retuprobe_filter_arg+0x2b68> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x25ec, 0x2b68, arm64_l_2b68);
arm64_l_25f0:
	/* 0x25f0: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_25f4:
	/* 0x25f4: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_25f8:
	/* 0x25f8: b.ne 2e84 <generic_retuprobe_filter_arg+0x2e84> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x25f8, 0x2e84, arm64_l_2e84);
arm64_l_25fc:
	/* 0x25fc: b 31dc <generic_retuprobe_filter_arg+0x31dc> */
	ARM64_SIM_A64_JMP(0x25fc, 0x31dc, arm64_l_31dc);
arm64_l_2600:
	/* 0x2600: ldr x23, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2604:
	/* 0x2604: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2608:
	/* 0x2608: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_260c:
	/* 0x260c: b 32c0 <generic_retuprobe_filter_arg+0x32c0> */
	ARM64_SIM_A64_JMP(0x260c, 0x32c0, arm64_l_32c0);
arm64_l_2610:
	/* 0x2610: cbz w8, 2b80 <generic_retuprobe_filter_arg+0x2b80> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x2610, 0x2b80, arm64_l_2b80);
arm64_l_2614:
	/* 0x2614: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2618:
	/* 0x2618: b.ne 664 <generic_retuprobe_filter_arg+0x664> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2618, 0x664, arm64_l_664);
arm64_l_261c:
	/* 0x261c: adrp x0, 0 <string_maps_1> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_1_9));
arm64_l_2620:
	/* 0x2620: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2624:
	/* 0x2624: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2628:
	/* 0x2628: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_262c:
	/* 0x262c: b 2c08 <generic_retuprobe_filter_arg+0x2c08> */
	ARM64_SIM_A64_JMP(0x262c, 0x2c08, arm64_l_2c08);
arm64_l_2630:
	/* 0x2630: cmp w13, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2634:
	/* 0x2634: ccmp w10, w12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_2638:
	/* 0x2638: cset w12, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_263c:
	/* 0x263c: orr w8, w8, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_2640:
	/* 0x2640: cmp w11, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2644:
	/* 0x2644: b.cc 2aa0 <generic_retuprobe_filter_arg+0x2aa0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2644, 0x2aa0, arm64_l_2aa0);
arm64_l_2648:
	/* 0x2648: ldp w12, w11, [x21, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X11, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_264c:
	/* 0x264c: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2650:
	/* 0x2650: b.hi 2a90 <generic_retuprobe_filter_arg+0x2a90> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2650, 0x2a90, arm64_l_2a90);
arm64_l_2654:
	/* 0x2654: lsl w9, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2658:
	/* 0x2658: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_265c:
	/* 0x265c: tst w9, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2660:
	/* 0x2660: b.eq 2a90 <generic_retuprobe_filter_arg+0x2a90> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2660, 0x2a90, arm64_l_2a90);
arm64_l_2664:
	/* 0x2664: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2668:
	/* 0x2668: ccmp w10, w11, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_266c:
	/* 0x266c: cset w9, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_2670:
	/* 0x2670: b 2a9c <generic_retuprobe_filter_arg+0x2a9c> */
	ARM64_SIM_A64_JMP(0x2670, 0x2a9c, arm64_l_2a9c);
arm64_l_2674:
	/* 0x2674: mov w22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2678:
	/* 0x2678: b 32bc <generic_retuprobe_filter_arg+0x32bc> */
	ARM64_SIM_A64_JMP(0x2678, 0x32bc, arm64_l_32bc);
arm64_l_267c:
	/* 0x267c: and w8, w25, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_2680:
	/* 0x2680: cmp w8, #0x201 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 513ULL);
arm64_l_2684:
	/* 0x2684: b.cs 2c2c <generic_retuprobe_filter_arg+0x2c2c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2684, 0x2c2c, arm64_l_2c2c);
arm64_l_2688:
	/* 0x2688: mov w11, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 512ULL);
arm64_l_268c:
	/* 0x268c: b 2f9c <generic_retuprobe_filter_arg+0x2f9c> */
	ARM64_SIM_A64_JMP(0x268c, 0x2f9c, arm64_l_2f9c);
arm64_l_2690:
	/* 0x2690: cmp w12, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2694:
	/* 0x2694: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2698:
	/* 0x2698: b.hi 26a4 <generic_retuprobe_filter_arg+0x26a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2698, 0x26a4, arm64_l_26a4);
arm64_l_269c:
	/* 0x269c: cmp w8, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26a0:
	/* 0x26a0: b.ls 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x26a0, 0x140, arm64_l_140);
arm64_l_26a4:
	/* 0x26a4: cmp w10, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_26a8:
	/* 0x26a8: b.cc c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x26a8, 0xc4, arm64_l_c4);
arm64_l_26ac:
	/* 0x26ac: ldp w11, w10, [x21, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_26b0:
	/* 0x26b0: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_26b4:
	/* 0x26b4: b.hi 2c3c <generic_retuprobe_filter_arg+0x2c3c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x26b4, 0x2c3c, arm64_l_2c3c);
arm64_l_26b8:
	/* 0x26b8: lsl w9, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_26bc:
	/* 0x26bc: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_26c0:
	/* 0x26c0: tst w9, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26c4:
	/* 0x26c4: b.eq 2c3c <generic_retuprobe_filter_arg+0x2c3c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x26c4, 0x2c3c, arm64_l_2c3c);
arm64_l_26c8:
	/* 0x26c8: cmp w11, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26cc:
	/* 0x26cc: b.gt c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x26cc, 0xc4, arm64_l_c4);
arm64_l_26d0:
	/* 0x26d0: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26d4:
	/* 0x26d4: b.le 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x26d4, 0x140, arm64_l_140);
arm64_l_26d8:
	/* 0x26d8: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x26d8, 0xc4, arm64_l_c4);
arm64_l_26dc:
	/* 0x26dc: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_26e0:
	/* 0x26e0: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26e4:
	/* 0x26e4: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_26e8:
	/* 0x26e8: b.hi 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x26e8, 0x140, arm64_l_140);
arm64_l_26ec:
	/* 0x26ec: b 2700 <generic_retuprobe_filter_arg+0x2700> */
	ARM64_SIM_A64_JMP(0x26ec, 0x2700, arm64_l_2700);
arm64_l_26f0:
	/* 0x26f0: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_26f4:
	/* 0x26f4: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26f8:
	/* 0x26f8: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_26fc:
	/* 0x26fc: b.cc 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x26fc, 0x140, arm64_l_140);
arm64_l_2700:
	/* 0x2700: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2704:
	/* 0x2704: b.cc 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2704, 0x124, arm64_l_124);
arm64_l_2708:
	/* 0x2708: ldr w11, [x21, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_270c:
	/* 0x270c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2710:
	/* 0x2710: b.le 2734 <generic_retuprobe_filter_arg+0x2734> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2710, 0x2734, arm64_l_2734);
arm64_l_2714:
	/* 0x2714: sub w12, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2718:
	/* 0x2718: cmp w12, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_271c:
	/* 0x271c: b.cs 2770 <generic_retuprobe_filter_arg+0x2770> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x271c, 0x2770, arm64_l_2770);
arm64_l_2720:
	/* 0x2720: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2724:
	/* 0x2724: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2728:
	/* 0x2728: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_272c:
	/* 0x272c: b.ne 2ee0 <generic_retuprobe_filter_arg+0x2ee0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x272c, 0x2ee0, arm64_l_2ee0);
arm64_l_2730:
	/* 0x2730: b 31dc <generic_retuprobe_filter_arg+0x31dc> */
	ARM64_SIM_A64_JMP(0x2730, 0x31dc, arm64_l_31dc);
arm64_l_2734:
	/* 0x2734: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2738:
	/* 0x2738: b.eq 2790 <generic_retuprobe_filter_arg+0x2790> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2738, 0x2790, arm64_l_2790);
arm64_l_273c:
	/* 0x273c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2740:
	/* 0x2740: b.ne 2ee0 <generic_retuprobe_filter_arg+0x2ee0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2740, 0x2ee0, arm64_l_2ee0);
arm64_l_2744:
	/* 0x2744: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2748:
	/* 0x2748: b.hi 2ed0 <generic_retuprobe_filter_arg+0x2ed0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2748, 0x2ed0, arm64_l_2ed0);
arm64_l_274c:
	/* 0x274c: lsl w12, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X12, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2750:
	/* 0x2750: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2754:
	/* 0x2754: tst w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2758:
	/* 0x2758: b.eq 2ed0 <generic_retuprobe_filter_arg+0x2ed0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2758, 0x2ed0, arm64_l_2ed0);
arm64_l_275c:
	/* 0x275c: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2760:
	/* 0x2760: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2764:
	/* 0x2764: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2768:
	/* 0x2768: b.lt 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x2768, 0x140, arm64_l_140);
arm64_l_276c:
	/* 0x276c: b 2ee0 <generic_retuprobe_filter_arg+0x2ee0> */
	ARM64_SIM_A64_JMP(0x276c, 0x2ee0, arm64_l_2ee0);
arm64_l_2770:
	/* 0x2770: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2774:
	/* 0x2774: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2778:
	/* 0x2778: b.ne 2ee0 <generic_retuprobe_filter_arg+0x2ee0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2778, 0x2ee0, arm64_l_2ee0);
arm64_l_277c:
	/* 0x277c: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2780:
	/* 0x2780: tst w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2784:
	/* 0x2784: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2788:
	/* 0x2788: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2788, 0x140, arm64_l_140);
arm64_l_278c:
	/* 0x278c: b 2ee0 <generic_retuprobe_filter_arg+0x2ee0> */
	ARM64_SIM_A64_JMP(0x278c, 0x2ee0, arm64_l_2ee0);
arm64_l_2790:
	/* 0x2790: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2794:
	/* 0x2794: b.hi 2ebc <generic_retuprobe_filter_arg+0x2ebc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2794, 0x2ebc, arm64_l_2ebc);
arm64_l_2798:
	/* 0x2798: lsl w12, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X12, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_279c:
	/* 0x279c: mov w13, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_27a0:
	/* 0x27a0: tst w12, w13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_27a4:
	/* 0x27a4: b.eq 2ebc <generic_retuprobe_filter_arg+0x2ebc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x27a4, 0x2ebc, arm64_l_2ebc);
arm64_l_27a8:
	/* 0x27a8: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_27ac:
	/* 0x27ac: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_27b0:
	/* 0x27b0: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_27b4:
	/* 0x27b4: b.gt 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x27b4, 0x140, arm64_l_140);
arm64_l_27b8:
	/* 0x27b8: b 2ee0 <generic_retuprobe_filter_arg+0x2ee0> */
	ARM64_SIM_A64_JMP(0x27b8, 0x2ee0, arm64_l_2ee0);
arm64_l_27bc:
	/* 0x27bc: cmp x12, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_27c0:
	/* 0x27c0: ccmp x10, x11, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_27c4:
	/* 0x27c4: b 2a98 <generic_retuprobe_filter_arg+0x2a98> */
	ARM64_SIM_A64_JMP(0x27c4, 0x2a98, arm64_l_2a98);
arm64_l_27c8:
	/* 0x27c8: cbz w25, 2c70 <generic_retuprobe_filter_arg+0x2c70> */
	ARM64_SIM_A64_CBZ(ARM64_X25, 0x27c8, 0x2c70, arm64_l_2c70);
arm64_l_27cc:
	/* 0x27cc: cmp w25, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_27d0:
	/* 0x27d0: b.ne 2d5c <generic_retuprobe_filter_arg+0x2d5c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x27d0, 0x2d5c, arm64_l_2d5c);
arm64_l_27d4:
	/* 0x27d4: adrp x0, 0 <string_maps_1> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_1_9));
arm64_l_27d8:
	/* 0x27d8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_27dc:
	/* 0x27dc: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_27e0:
	/* 0x27e0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_27e4:
	/* 0x27e4: b 2cf8 <generic_retuprobe_filter_arg+0x2cf8> */
	ARM64_SIM_A64_JMP(0x27e4, 0x2cf8, arm64_l_2cf8);
arm64_l_27e8:
	/* 0x27e8: cmp x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_27ec:
	/* 0x27ec: b.hi c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x27ec, 0xc4, arm64_l_c4);
arm64_l_27f0:
	/* 0x27f0: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_27f4:
	/* 0x27f4: b.ls 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x27f4, 0x140, arm64_l_140);
arm64_l_27f8:
	/* 0x27f8: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x27f8, 0xc4, arm64_l_c4);
arm64_l_27fc:
	/* 0x27fc: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2800:
	/* 0x2800: b.eq 2e34 <generic_retuprobe_filter_arg+0x2e34> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2800, 0x2e34, arm64_l_2e34);
arm64_l_2804:
	/* 0x2804: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2808:
	/* 0x2808: b.ne 2e40 <generic_retuprobe_filter_arg+0x2e40> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2808, 0x2e40, arm64_l_2e40);
arm64_l_280c:
	/* 0x280c: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2810:
	/* 0x2810: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2814:
	/* 0x2814: b.hi 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2814, 0x140, arm64_l_140);
arm64_l_2818:
	/* 0x2818: b 2e40 <generic_retuprobe_filter_arg+0x2e40> */
	ARM64_SIM_A64_JMP(0x2818, 0x2e40, arm64_l_2e40);
arm64_l_281c:
	/* 0x281c: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2820:
	/* 0x2820: b.eq 2e78 <generic_retuprobe_filter_arg+0x2e78> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2820, 0x2e78, arm64_l_2e78);
arm64_l_2824:
	/* 0x2824: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2828:
	/* 0x2828: b.ne 2e84 <generic_retuprobe_filter_arg+0x2e84> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2828, 0x2e84, arm64_l_2e84);
arm64_l_282c:
	/* 0x282c: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2830:
	/* 0x2830: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2834:
	/* 0x2834: b.hi 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2834, 0x140, arm64_l_140);
arm64_l_2838:
	/* 0x2838: b 2e84 <generic_retuprobe_filter_arg+0x2e84> */
	ARM64_SIM_A64_JMP(0x2838, 0x2e84, arm64_l_2e84);
arm64_l_283c:
	/* 0x283c: and w8, w29, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_2840:
	/* 0x2840: mov w9, #0x1000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_2844:
	/* 0x2844: cmp w8, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2048ULL);
arm64_l_2848:
	/* 0x2848: mov w8, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_284c:
	/* 0x284c: csel w11, w9, w8, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_2850:
	/* 0x2850: sub w8, w11, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_2854:
	/* 0x2854: ror w8, w8, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_ROR), 8ULL);
arm64_l_2858:
	/* 0x2858: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_285c:
	/* 0x285c: b.gt 2874 <generic_retuprobe_filter_arg+0x2874> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x285c, 0x2874, arm64_l_2874);
arm64_l_2860:
	/* 0x2860: cbz w8, 2894 <generic_retuprobe_filter_arg+0x2894> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x2860, 0x2894, arm64_l_2894);
arm64_l_2864:
	/* 0x2864: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2868:
	/* 0x2868: b.ne 288c <generic_retuprobe_filter_arg+0x288c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2868, 0x288c, arm64_l_288c);
arm64_l_286c:
	/* 0x286c: mov w10, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 7ULL);
arm64_l_2870:
	/* 0x2870: b 28a0 <generic_retuprobe_filter_arg+0x28a0> */
	ARM64_SIM_A64_JMP(0x2870, 0x28a0, arm64_l_28a0);
arm64_l_2874:
	/* 0x2874: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2878:
	/* 0x2878: b.eq 289c <generic_retuprobe_filter_arg+0x289c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2878, 0x289c, arm64_l_289c);
arm64_l_287c:
	/* 0x287c: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_2880:
	/* 0x2880: b.ne 288c <generic_retuprobe_filter_arg+0x288c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2880, 0x288c, arm64_l_288c);
arm64_l_2884:
	/* 0x2884: mov w10, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 9ULL);
arm64_l_2888:
	/* 0x2888: b 28a0 <generic_retuprobe_filter_arg+0x28a0> */
	ARM64_SIM_A64_JMP(0x2888, 0x28a0, arm64_l_28a0);
arm64_l_288c:
	/* 0x288c: mov w10, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_2890:
	/* 0x2890: b 28a0 <generic_retuprobe_filter_arg+0x28a0> */
	ARM64_SIM_A64_JMP(0x2890, 0x28a0, arm64_l_28a0);
arm64_l_2894:
	/* 0x2894: mov w10, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 6ULL);
arm64_l_2898:
	/* 0x2898: b 28a0 <generic_retuprobe_filter_arg+0x28a0> */
	ARM64_SIM_A64_JMP(0x2898, 0x28a0, arm64_l_28a0);
arm64_l_289c:
	/* 0x289c: mov w10, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_28a0:
	/* 0x28a0: add x8, x21, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_28a4:
	/* 0x28a4: and w9, w10, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_28a8:
	/* 0x28a8: ldr w8, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_28ac:
	/* 0x28ac: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28b0:
	/* 0x28b0: b.eq 2964 <generic_retuprobe_filter_arg+0x2964> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x28b0, 0x2964, arm64_l_2964);
arm64_l_28b4:
	/* 0x28b4: str w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_28b8:
	/* 0x28b8: str w11, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_28bc:
	/* 0x28bc: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_19));
arm64_l_28c0:
	/* 0x28c0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28c4:
	/* 0x28c4: add x22, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_28c8:
	/* 0x28c8: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_28cc:
	/* 0x28cc: str w10, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_28d0:
	/* 0x28d0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_28d4:
	/* 0x28d4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x28d8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_28d8:
	/* 0x28d8: str x0, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_28dc:
	/* 0x28dc: adrp x0, 0 <heap_ro_zero> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero_4));
arm64_l_28e0:
	/* 0x28e0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28e4:
	/* 0x28e4: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_28e8:
	/* 0x28e8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_28ec:
	/* 0x28ec: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x28f0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_28f0:
	/* 0x28f0: ldr x10, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_28f4:
	/* 0x28f4: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_28f8:
	/* 0x28f8: cbz x10, 1314 <generic_retuprobe_filter_arg+0x1314> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x28f8, 0x1314, arm64_l_1314);
arm64_l_28fc:
	/* 0x28fc: mov x9, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2900:
	/* 0x2900: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2904:
	/* 0x2904: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2908:
	/* 0x2908: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_290c:
	/* 0x290c: cbz x9, 1d18 <generic_retuprobe_filter_arg+0x1d18> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x290c, 0x1d18, arm64_l_1d18);
arm64_l_2910:
	/* 0x2910: mov x22, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2914:
	/* 0x2914: ldr w9, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2918:
	/* 0x2918: mov x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_291c:
	/* 0x291c: cmp w9, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2920:
	/* 0x2920: b.gt 296c <generic_retuprobe_filter_arg+0x296c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2920, 0x296c, arm64_l_296c);
arm64_l_2924:
	/* 0x2924: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2928:
	/* 0x2928: mov x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_292c:
	/* 0x292c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2930:
	/* 0x2930: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2934:
	/* 0x2934: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2938:
	/* 0x2938: strb w29, [x0], #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 1ULL);
arm64_l_293c:
	/* 0x293c: mov x25, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2940:
	/* 0x2940: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2944ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2944:
	/* 0x2944: ldr w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2948:
	/* 0x2948: subs w8, w8, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_294c:
	/* 0x294c: b.ls 29b0 <generic_retuprobe_filter_arg+0x29b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x294c, 0x29b0, arm64_l_29b0);
arm64_l_2950:
	/* 0x2950: add x9, x25, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X25, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2954:
	/* 0x2954: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2958:
	/* 0x2958: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_295c:
	/* 0x295c: add x0, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2960:
	/* 0x2960: b 29a8 <generic_retuprobe_filter_arg+0x29a8> */
	ARM64_SIM_A64_JMP(0x2960, 0x29a8, arm64_l_29a8);
arm64_l_2964:
	/* 0x2964: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2968:
	/* 0x2968: b 131c <generic_retuprobe_filter_arg+0x131c> */
	ARM64_SIM_A64_JMP(0x2968, 0x131c, arm64_l_131c);
arm64_l_296c:
	/* 0x296c: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2970:
	/* 0x2970: mov x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2974:
	/* 0x2974: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2978:
	/* 0x2978: mov w1, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_297c:
	/* 0x297c: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2980:
	/* 0x2980: strh w29, [x0], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_2984:
	/* 0x2984: mov x25, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2988:
	/* 0x2988: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x298cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_298c:
	/* 0x298c: ldr w8, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2990:
	/* 0x2990: subs w8, w8, w29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2994:
	/* 0x2994: b.ls 29b0 <generic_retuprobe_filter_arg+0x29b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2994, 0x29b0, arm64_l_29b0);
arm64_l_2998:
	/* 0x2998: add x9, x25, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X25, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_299c:
	/* 0x299c: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_29a0:
	/* 0x29a0: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_29a4:
	/* 0x29a4: add x0, x9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_29a8:
	/* 0x29a8: mov x2, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_29ac:
	/* 0x29ac: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x29b0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_29b0:
	/* 0x29b0: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_29b4:
	/* 0x29b4: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_29b8:
	/* 0x29b8: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_29bc:
	/* 0x29bc: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_29c0:
	/* 0x29c0: ldr w8, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_29c4:
	/* 0x29c4: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_29c8:
	/* 0x29c8: b.le 2a00 <generic_retuprobe_filter_arg+0x2a00> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x29c8, 0x2a00, arm64_l_2a00);
arm64_l_29cc:
	/* 0x29cc: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_29d0:
	/* 0x29d0: b.gt 2a34 <generic_retuprobe_filter_arg+0x2a34> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x29d0, 0x2a34, arm64_l_2a34);
arm64_l_29d4:
	/* 0x29d4: cmp w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_29d8:
	/* 0x29d8: b.eq 2dd8 <generic_retuprobe_filter_arg+0x2dd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x29d8, 0x2dd8, arm64_l_2dd8);
arm64_l_29dc:
	/* 0x29dc: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_29e0:
	/* 0x29e0: b.eq 2d9c <generic_retuprobe_filter_arg+0x2d9c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x29e0, 0x2d9c, arm64_l_2d9c);
arm64_l_29e4:
	/* 0x29e4: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_29e8:
	/* 0x29e8: b.ne 2e28 <generic_retuprobe_filter_arg+0x2e28> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x29e8, 0x2e28, arm64_l_2e28);
arm64_l_29ec:
	/* 0x29ec: adrp x0, 0 <string_maps_7> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_7_16));
arm64_l_29f0:
	/* 0x29f0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_29f4:
	/* 0x29f4: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_29f8:
	/* 0x29f8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_29fc:
	/* 0x29fc: b 2dfc <generic_retuprobe_filter_arg+0x2dfc> */
	ARM64_SIM_A64_JMP(0x29fc, 0x2dfc, arm64_l_2dfc);
arm64_l_2a00:
	/* 0x2a00: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2a04:
	/* 0x2a04: b.le 2a60 <generic_retuprobe_filter_arg+0x2a60> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2a04, 0x2a60, arm64_l_2a60);
arm64_l_2a08:
	/* 0x2a08: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2a0c:
	/* 0x2a0c: b.eq 2dc4 <generic_retuprobe_filter_arg+0x2dc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2a0c, 0x2dc4, arm64_l_2dc4);
arm64_l_2a10:
	/* 0x2a10: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2a14:
	/* 0x2a14: b.eq 2d88 <generic_retuprobe_filter_arg+0x2d88> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2a14, 0x2d88, arm64_l_2d88);
arm64_l_2a18:
	/* 0x2a18: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2a1c:
	/* 0x2a1c: b.ne 2e28 <generic_retuprobe_filter_arg+0x2e28> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2a1c, 0x2e28, arm64_l_2e28);
arm64_l_2a20:
	/* 0x2a20: adrp x0, 0 <string_maps_4> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_4_13));
arm64_l_2a24:
	/* 0x2a24: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a28:
	/* 0x2a28: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2a2c:
	/* 0x2a2c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2a30:
	/* 0x2a30: b 2dfc <generic_retuprobe_filter_arg+0x2dfc> */
	ARM64_SIM_A64_JMP(0x2a30, 0x2dfc, arm64_l_2dfc);
arm64_l_2a34:
	/* 0x2a34: cmp w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2a38:
	/* 0x2a38: b.eq 2dec <generic_retuprobe_filter_arg+0x2dec> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2a38, 0x2dec, arm64_l_2dec);
arm64_l_2a3c:
	/* 0x2a3c: cmp w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_2a40:
	/* 0x2a40: b.eq 2db0 <generic_retuprobe_filter_arg+0x2db0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2a40, 0x2db0, arm64_l_2db0);
arm64_l_2a44:
	/* 0x2a44: cmp w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2a48:
	/* 0x2a48: b.ne 2e28 <generic_retuprobe_filter_arg+0x2e28> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2a48, 0x2e28, arm64_l_2e28);
arm64_l_2a4c:
	/* 0x2a4c: adrp x0, 0 <string_maps_10> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_10_10));
arm64_l_2a50:
	/* 0x2a50: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a54:
	/* 0x2a54: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2a58:
	/* 0x2a58: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2a5c:
	/* 0x2a5c: b 2dfc <generic_retuprobe_filter_arg+0x2dfc> */
	ARM64_SIM_A64_JMP(0x2a5c, 0x2dfc, arm64_l_2dfc);
arm64_l_2a60:
	/* 0x2a60: cbz w8, 2d74 <generic_retuprobe_filter_arg+0x2d74> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x2a60, 0x2d74, arm64_l_2d74);
arm64_l_2a64:
	/* 0x2a64: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2a68:
	/* 0x2a68: b.ne 2e28 <generic_retuprobe_filter_arg+0x2e28> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2a68, 0x2e28, arm64_l_2e28);
arm64_l_2a6c:
	/* 0x2a6c: adrp x0, 0 <string_maps_1> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_1_9));
arm64_l_2a70:
	/* 0x2a70: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a74:
	/* 0x2a74: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2a78:
	/* 0x2a78: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2a7c:
	/* 0x2a7c: b 2dfc <generic_retuprobe_filter_arg+0x2dfc> */
	ARM64_SIM_A64_JMP(0x2a7c, 0x2dfc, arm64_l_2dfc);
arm64_l_2a80:
	/* 0x2a80: ldr x23, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2a84:
	/* 0x2a84: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2a88:
	/* 0x2a88: mov w22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a8c:
	/* 0x2a8c: b 32c4 <generic_retuprobe_filter_arg+0x32c4> */
	ARM64_SIM_A64_JMP(0x2a8c, 0x32c4, arm64_l_32c4);
arm64_l_2a90:
	/* 0x2a90: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2a94:
	/* 0x2a94: ccmp w10, w11, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_2a98:
	/* 0x2a98: cset w9, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_2a9c:
	/* 0x2a9c: orr w8, w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 0);
arm64_l_2aa0:
	/* 0x2aa0: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2aa4:
	/* 0x2aa4: tbz w8, #0, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 0, 0x2aa4, 0x140, arm64_l_140);
arm64_l_2aa8:
	/* 0x2aa8: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x2aa8, 0xc4, arm64_l_c4);
arm64_l_2aac:
	/* 0x2aac: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ab0:
	/* 0x2ab0: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2ab4:
	/* 0x2ab4: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2ab8:
	/* 0x2ab8: b.hi 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2ab8, 0x140, arm64_l_140);
arm64_l_2abc:
	/* 0x2abc: b 2ad0 <generic_retuprobe_filter_arg+0x2ad0> */
	ARM64_SIM_A64_JMP(0x2abc, 0x2ad0, arm64_l_2ad0);
arm64_l_2ac0:
	/* 0x2ac0: ldr x12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ac4:
	/* 0x2ac4: cmp x12, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2ac8:
	/* 0x2ac8: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2acc:
	/* 0x2acc: b.cc 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2acc, 0x140, arm64_l_140);
arm64_l_2ad0:
	/* 0x2ad0: cmp w10, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2ad4:
	/* 0x2ad4: b.cc 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2ad4, 0x124, arm64_l_124);
arm64_l_2ad8:
	/* 0x2ad8: ldr x10, [x21, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2adc:
	/* 0x2adc: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2ae0:
	/* 0x2ae0: b.le 2b10 <generic_retuprobe_filter_arg+0x2b10> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2ae0, 0x2b10, arm64_l_2b10);
arm64_l_2ae4:
	/* 0x2ae4: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2ae8:
	/* 0x2ae8: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2aec:
	/* 0x2aec: b.cc 2b40 <generic_retuprobe_filter_arg+0x2b40> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2aec, 0x2b40, arm64_l_2b40);
arm64_l_2af0:
	/* 0x2af0: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2af4:
	/* 0x2af4: b.eq 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2af4, 0x140, arm64_l_140);
arm64_l_2af8:
	/* 0x2af8: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2afc:
	/* 0x2afc: b.ne c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2afc, 0xc4, arm64_l_c4);
arm64_l_2b00:
	/* 0x2b00: ldr x9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b04:
	/* 0x2b04: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b08:
	/* 0x2b08: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2b08, 0x140, arm64_l_140);
arm64_l_2b0c:
	/* 0x2b0c: b 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JMP(0x2b0c, 0x124, arm64_l_124);
arm64_l_2b10:
	/* 0x2b10: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2b14:
	/* 0x2b14: b.eq 2c50 <generic_retuprobe_filter_arg+0x2c50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2b14, 0x2c50, arm64_l_2c50);
arm64_l_2b18:
	/* 0x2b18: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2b1c:
	/* 0x2b1c: b.ne c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2b1c, 0xc4, arm64_l_c4);
arm64_l_2b20:
	/* 0x2b20: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2b24:
	/* 0x2b24: b.eq 2b30 <generic_retuprobe_filter_arg+0x2b30> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2b24, 0x2b30, arm64_l_2b30);
arm64_l_2b28:
	/* 0x2b28: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2b2c:
	/* 0x2b2c: b.ne 31ec <generic_retuprobe_filter_arg+0x31ec> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2b2c, 0x31ec, arm64_l_31ec);
arm64_l_2b30:
	/* 0x2b30: ldr x9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b34:
	/* 0x2b34: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b38:
	/* 0x2b38: b.ge 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x2b38, 0x124, arm64_l_124);
arm64_l_2b3c:
	/* 0x2b3c: b 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JMP(0x2b3c, 0x140, arm64_l_140);
arm64_l_2b40:
	/* 0x2b40: ldr x9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b44:
	/* 0x2b44: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b48:
	/* 0x2b48: b.eq 31dc <generic_retuprobe_filter_arg+0x31dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2b48, 0x31dc, arm64_l_31dc);
arm64_l_2b4c:
	/* 0x2b4c: b 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JMP(0x2b4c, 0x124, arm64_l_124);
arm64_l_2b50:
	/* 0x2b50: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2b54:
	/* 0x2b54: b.ne 2e40 <generic_retuprobe_filter_arg+0x2e40> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2b54, 0x2e40, arm64_l_2e40);
arm64_l_2b58:
	/* 0x2b58: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b5c:
	/* 0x2b5c: tst w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b60:
	/* 0x2b60: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2b60, 0x140, arm64_l_140);
arm64_l_2b64:
	/* 0x2b64: b 2e40 <generic_retuprobe_filter_arg+0x2e40> */
	ARM64_SIM_A64_JMP(0x2b64, 0x2e40, arm64_l_2e40);
arm64_l_2b68:
	/* 0x2b68: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2b6c:
	/* 0x2b6c: b.ne 2e84 <generic_retuprobe_filter_arg+0x2e84> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2b6c, 0x2e84, arm64_l_2e84);
arm64_l_2b70:
	/* 0x2b70: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b74:
	/* 0x2b74: tst w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b78:
	/* 0x2b78: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2b78, 0x140, arm64_l_140);
arm64_l_2b7c:
	/* 0x2b7c: b 2e84 <generic_retuprobe_filter_arg+0x2e84> */
	ARM64_SIM_A64_JMP(0x2b7c, 0x2e84, arm64_l_2e84);
arm64_l_2b80:
	/* 0x2b80: adrp x0, 0 <string_maps_0> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_0_8));
arm64_l_2b84:
	/* 0x2b84: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2b88:
	/* 0x2b88: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2b8c:
	/* 0x2b8c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b90:
	/* 0x2b90: b 2c08 <generic_retuprobe_filter_arg+0x2c08> */
	ARM64_SIM_A64_JMP(0x2b90, 0x2c08, arm64_l_2c08);
arm64_l_2b94:
	/* 0x2b94: adrp x0, 0 <string_maps_3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_3_12));
arm64_l_2b98:
	/* 0x2b98: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2b9c:
	/* 0x2b9c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2ba0:
	/* 0x2ba0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ba4:
	/* 0x2ba4: b 2c08 <generic_retuprobe_filter_arg+0x2c08> */
	ARM64_SIM_A64_JMP(0x2ba4, 0x2c08, arm64_l_2c08);
arm64_l_2ba8:
	/* 0x2ba8: adrp x0, 0 <string_maps_6> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_6_15));
arm64_l_2bac:
	/* 0x2bac: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2bb0:
	/* 0x2bb0: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2bb4:
	/* 0x2bb4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2bb8:
	/* 0x2bb8: b 2c08 <generic_retuprobe_filter_arg+0x2c08> */
	ARM64_SIM_A64_JMP(0x2bb8, 0x2c08, arm64_l_2c08);
arm64_l_2bbc:
	/* 0x2bbc: adrp x0, 0 <string_maps_9> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_9_18));
arm64_l_2bc0:
	/* 0x2bc0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2bc4:
	/* 0x2bc4: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2bc8:
	/* 0x2bc8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2bcc:
	/* 0x2bcc: b 2c08 <generic_retuprobe_filter_arg+0x2c08> */
	ARM64_SIM_A64_JMP(0x2bcc, 0x2c08, arm64_l_2c08);
arm64_l_2bd0:
	/* 0x2bd0: adrp x0, 0 <string_maps_2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_2_11));
arm64_l_2bd4:
	/* 0x2bd4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2bd8:
	/* 0x2bd8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2bdc:
	/* 0x2bdc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2be0:
	/* 0x2be0: b 2c08 <generic_retuprobe_filter_arg+0x2c08> */
	ARM64_SIM_A64_JMP(0x2be0, 0x2c08, arm64_l_2c08);
arm64_l_2be4:
	/* 0x2be4: adrp x0, 0 <string_maps_5> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_5_14));
arm64_l_2be8:
	/* 0x2be8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2bec:
	/* 0x2bec: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2bf0:
	/* 0x2bf0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2bf4:
	/* 0x2bf4: b 2c08 <generic_retuprobe_filter_arg+0x2c08> */
	ARM64_SIM_A64_JMP(0x2bf4, 0x2c08, arm64_l_2c08);
arm64_l_2bf8:
	/* 0x2bf8: adrp x0, 0 <string_maps_8> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_8_17));
arm64_l_2bfc:
	/* 0x2bfc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2c00:
	/* 0x2c00: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2c04:
	/* 0x2c04: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c08:
	/* 0x2c08: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2c0c:
	/* 0x2c0c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2c10ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2c10:
	/* 0x2c10: cbz x0, 2d1c <generic_retuprobe_filter_arg+0x2d1c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2c10, 0x2d1c, arm64_l_2d1c);
arm64_l_2c14:
	/* 0x2c14: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2c18:
	/* 0x2c18: mov x1, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2c1c:
	/* 0x2c1c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2c20ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2c20:
	/* 0x2c20: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_2c24:
	/* 0x2c24: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2c28:
	/* 0x2c28: b 2d20 <generic_retuprobe_filter_arg+0x2d20> */
	ARM64_SIM_A64_JMP(0x2c28, 0x2d20, arm64_l_2d20);
arm64_l_2c2c:
	/* 0x2c2c: cmp w8, #0x401 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1025ULL);
arm64_l_2c30:
	/* 0x2c30: b.cs 2f88 <generic_retuprobe_filter_arg+0x2f88> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2c30, 0x2f88, arm64_l_2f88);
arm64_l_2c34:
	/* 0x2c34: mov w11, #0x400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1024ULL);
arm64_l_2c38:
	/* 0x2c38: b 2f9c <generic_retuprobe_filter_arg+0x2f9c> */
	ARM64_SIM_A64_JMP(0x2c38, 0x2f9c, arm64_l_2f9c);
arm64_l_2c3c:
	/* 0x2c3c: cmp w11, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c40:
	/* 0x2c40: b.hi c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2c40, 0xc4, arm64_l_c4);
arm64_l_2c44:
	/* 0x2c44: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c48:
	/* 0x2c48: b.ls 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2c48, 0x140, arm64_l_140);
arm64_l_2c4c:
	/* 0x2c4c: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x2c4c, 0xc4, arm64_l_c4);
arm64_l_2c50:
	/* 0x2c50: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2c54:
	/* 0x2c54: b.eq 2c60 <generic_retuprobe_filter_arg+0x2c60> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2c54, 0x2c60, arm64_l_2c60);
arm64_l_2c58:
	/* 0x2c58: cmp w9, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_2c5c:
	/* 0x2c5c: b.ne 31fc <generic_retuprobe_filter_arg+0x31fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2c5c, 0x31fc, arm64_l_31fc);
arm64_l_2c60:
	/* 0x2c60: ldr x9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c64:
	/* 0x2c64: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c68:
	/* 0x2c68: b.le 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2c68, 0x124, arm64_l_124);
arm64_l_2c6c:
	/* 0x2c6c: b 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JMP(0x2c6c, 0x140, arm64_l_140);
arm64_l_2c70:
	/* 0x2c70: adrp x0, 0 <string_maps_0> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_0_8));
arm64_l_2c74:
	/* 0x2c74: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2c78:
	/* 0x2c78: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2c7c:
	/* 0x2c7c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c80:
	/* 0x2c80: b 2cf8 <generic_retuprobe_filter_arg+0x2cf8> */
	ARM64_SIM_A64_JMP(0x2c80, 0x2cf8, arm64_l_2cf8);
arm64_l_2c84:
	/* 0x2c84: adrp x0, 0 <string_maps_3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_3_12));
arm64_l_2c88:
	/* 0x2c88: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2c8c:
	/* 0x2c8c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2c90:
	/* 0x2c90: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c94:
	/* 0x2c94: b 2cf8 <generic_retuprobe_filter_arg+0x2cf8> */
	ARM64_SIM_A64_JMP(0x2c94, 0x2cf8, arm64_l_2cf8);
arm64_l_2c98:
	/* 0x2c98: adrp x0, 0 <string_maps_6> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_6_15));
arm64_l_2c9c:
	/* 0x2c9c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2ca0:
	/* 0x2ca0: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2ca4:
	/* 0x2ca4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ca8:
	/* 0x2ca8: b 2cf8 <generic_retuprobe_filter_arg+0x2cf8> */
	ARM64_SIM_A64_JMP(0x2ca8, 0x2cf8, arm64_l_2cf8);
arm64_l_2cac:
	/* 0x2cac: adrp x0, 0 <string_maps_9> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_9_18));
arm64_l_2cb0:
	/* 0x2cb0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2cb4:
	/* 0x2cb4: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2cb8:
	/* 0x2cb8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2cbc:
	/* 0x2cbc: b 2cf8 <generic_retuprobe_filter_arg+0x2cf8> */
	ARM64_SIM_A64_JMP(0x2cbc, 0x2cf8, arm64_l_2cf8);
arm64_l_2cc0:
	/* 0x2cc0: adrp x0, 0 <string_maps_2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_2_11));
arm64_l_2cc4:
	/* 0x2cc4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2cc8:
	/* 0x2cc8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2ccc:
	/* 0x2ccc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2cd0:
	/* 0x2cd0: b 2cf8 <generic_retuprobe_filter_arg+0x2cf8> */
	ARM64_SIM_A64_JMP(0x2cd0, 0x2cf8, arm64_l_2cf8);
arm64_l_2cd4:
	/* 0x2cd4: adrp x0, 0 <string_maps_5> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_5_14));
arm64_l_2cd8:
	/* 0x2cd8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2cdc:
	/* 0x2cdc: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2ce0:
	/* 0x2ce0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ce4:
	/* 0x2ce4: b 2cf8 <generic_retuprobe_filter_arg+0x2cf8> */
	ARM64_SIM_A64_JMP(0x2ce4, 0x2cf8, arm64_l_2cf8);
arm64_l_2ce8:
	/* 0x2ce8: adrp x0, 0 <string_maps_8> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_8_17));
arm64_l_2cec:
	/* 0x2cec: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2cf0:
	/* 0x2cf0: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2cf4:
	/* 0x2cf4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2cf8:
	/* 0x2cf8: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2cfc:
	/* 0x2cfc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2d00ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2d00:
	/* 0x2d00: cbz x0, 2d1c <generic_retuprobe_filter_arg+0x2d1c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2d00, 0x2d1c, arm64_l_2d1c);
arm64_l_2d04:
	/* 0x2d04: ldr x1, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2d08:
	/* 0x2d08: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2d0c:
	/* 0x2d0c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2d10ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2d10:
	/* 0x2d10: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_2d14:
	/* 0x2d14: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2d18:
	/* 0x2d18: b 2d20 <generic_retuprobe_filter_arg+0x2d20> */
	ARM64_SIM_A64_JMP(0x2d18, 0x2d20, arm64_l_2d20);
arm64_l_2d1c:
	/* 0x2d1c: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d20:
	/* 0x2d20: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2d24:
	/* 0x2d24: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2d28:
	/* 0x2d28: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2d2c:
	/* 0x2d2c: ldr w8, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2d30:
	/* 0x2d30: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_2d34:
	/* 0x2d34: b.hi 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2d34, 0x1ce4, arm64_l_1ce4);
arm64_l_2d38:
	/* 0x2d38: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_2d3c:
	/* 0x2d3c: lsl x8, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2d40:
	/* 0x2d40: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_2d44:
	/* 0x2d44: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_2d48:
	/* 0x2d48: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d4c:
	/* 0x2d4c: b.eq 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2d4c, 0x1ce4, arm64_l_1ce4);
arm64_l_2d50:
	/* 0x2d50: eor x22, x22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2d54:
	/* 0x2d54: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x2d54, 0x140, arm64_l_140);
arm64_l_2d58:
	/* 0x2d58: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x2d58, 0xc4, arm64_l_c4);
arm64_l_2d5c:
	/* 0x2d5c: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2d60:
	/* 0x2d60: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d64:
	/* 0x2d64: ldr w8, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2d68:
	/* 0x2d68: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_2d6c:
	/* 0x2d6c: b.ls 2d38 <generic_retuprobe_filter_arg+0x2d38> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2d6c, 0x2d38, arm64_l_2d38);
arm64_l_2d70:
	/* 0x2d70: b 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JMP(0x2d70, 0x1ce4, arm64_l_1ce4);
arm64_l_2d74:
	/* 0x2d74: adrp x0, 0 <string_maps_0> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_0_8));
arm64_l_2d78:
	/* 0x2d78: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2d7c:
	/* 0x2d7c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2d80:
	/* 0x2d80: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d84:
	/* 0x2d84: b 2dfc <generic_retuprobe_filter_arg+0x2dfc> */
	ARM64_SIM_A64_JMP(0x2d84, 0x2dfc, arm64_l_2dfc);
arm64_l_2d88:
	/* 0x2d88: adrp x0, 0 <string_maps_3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_3_12));
arm64_l_2d8c:
	/* 0x2d8c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2d90:
	/* 0x2d90: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2d94:
	/* 0x2d94: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d98:
	/* 0x2d98: b 2dfc <generic_retuprobe_filter_arg+0x2dfc> */
	ARM64_SIM_A64_JMP(0x2d98, 0x2dfc, arm64_l_2dfc);
arm64_l_2d9c:
	/* 0x2d9c: adrp x0, 0 <string_maps_6> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_6_15));
arm64_l_2da0:
	/* 0x2da0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2da4:
	/* 0x2da4: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2da8:
	/* 0x2da8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2dac:
	/* 0x2dac: b 2dfc <generic_retuprobe_filter_arg+0x2dfc> */
	ARM64_SIM_A64_JMP(0x2dac, 0x2dfc, arm64_l_2dfc);
arm64_l_2db0:
	/* 0x2db0: adrp x0, 0 <string_maps_9> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_9_18));
arm64_l_2db4:
	/* 0x2db4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2db8:
	/* 0x2db8: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2dbc:
	/* 0x2dbc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2dc0:
	/* 0x2dc0: b 2dfc <generic_retuprobe_filter_arg+0x2dfc> */
	ARM64_SIM_A64_JMP(0x2dc0, 0x2dfc, arm64_l_2dfc);
arm64_l_2dc4:
	/* 0x2dc4: adrp x0, 0 <string_maps_2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_2_11));
arm64_l_2dc8:
	/* 0x2dc8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2dcc:
	/* 0x2dcc: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2dd0:
	/* 0x2dd0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2dd4:
	/* 0x2dd4: b 2dfc <generic_retuprobe_filter_arg+0x2dfc> */
	ARM64_SIM_A64_JMP(0x2dd4, 0x2dfc, arm64_l_2dfc);
arm64_l_2dd8:
	/* 0x2dd8: adrp x0, 0 <string_maps_5> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_5_14));
arm64_l_2ddc:
	/* 0x2ddc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2de0:
	/* 0x2de0: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2de4:
	/* 0x2de4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2de8:
	/* 0x2de8: b 2dfc <generic_retuprobe_filter_arg+0x2dfc> */
	ARM64_SIM_A64_JMP(0x2de8, 0x2dfc, arm64_l_2dfc);
arm64_l_2dec:
	/* 0x2dec: adrp x0, 0 <string_maps_8> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_8_17));
arm64_l_2df0:
	/* 0x2df0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2df4:
	/* 0x2df4: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2df8:
	/* 0x2df8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2dfc:
	/* 0x2dfc: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2e00:
	/* 0x2e00: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2e04ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2e04:
	/* 0x2e04: cbz x0, 2e20 <generic_retuprobe_filter_arg+0x2e20> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2e04, 0x2e20, arm64_l_2e20);
arm64_l_2e08:
	/* 0x2e08: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2e0c:
	/* 0x2e0c: mov x1, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2e10:
	/* 0x2e10: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2e14ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_2e14:
	/* 0x2e14: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_2e18:
	/* 0x2e18: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2e1c:
	/* 0x2e1c: b 1314 <generic_retuprobe_filter_arg+0x1314> */
	ARM64_SIM_A64_JMP(0x2e1c, 0x1314, arm64_l_1314);
arm64_l_2e20:
	/* 0x2e20: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2e24:
	/* 0x2e24: b 1314 <generic_retuprobe_filter_arg+0x1314> */
	ARM64_SIM_A64_JMP(0x2e24, 0x1314, arm64_l_1314);
arm64_l_2e28:
	/* 0x2e28: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2e2c:
	/* 0x2e2c: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2e30:
	/* 0x2e30: b 1d18 <generic_retuprobe_filter_arg+0x1d18> */
	ARM64_SIM_A64_JMP(0x2e30, 0x1d18, arm64_l_1d18);
arm64_l_2e34:
	/* 0x2e34: ldrb w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2e38:
	/* 0x2e38: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2e3c:
	/* 0x2e3c: b.cc 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2e3c, 0x140, arm64_l_140);
arm64_l_2e40:
	/* 0x2e40: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2e44:
	/* 0x2e44: b.cc 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2e44, 0x124, arm64_l_124);
arm64_l_2e48:
	/* 0x2e48: ldr w9, [x21, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2e4c:
	/* 0x2e4c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2e50:
	/* 0x2e50: b.le 3198 <generic_retuprobe_filter_arg+0x3198> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2e50, 0x3198, arm64_l_3198);
arm64_l_2e54:
	/* 0x2e54: sub w10, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2e58:
	/* 0x2e58: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2e5c:
	/* 0x2e5c: b.cc 31c8 <generic_retuprobe_filter_arg+0x31c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2e5c, 0x31c8, arm64_l_31c8);
arm64_l_2e60:
	/* 0x2e60: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2e64:
	/* 0x2e64: b.eq 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2e64, 0x140, arm64_l_140);
arm64_l_2e68:
	/* 0x2e68: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2e6c:
	/* 0x2e6c: b.ne c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2e6c, 0xc4, arm64_l_c4);
arm64_l_2e70:
	/* 0x2e70: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2e74:
	/* 0x2e74: b 2f14 <generic_retuprobe_filter_arg+0x2f14> */
	ARM64_SIM_A64_JMP(0x2e74, 0x2f14, arm64_l_2f14);
arm64_l_2e78:
	/* 0x2e78: ldrh w11, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2e7c:
	/* 0x2e7c: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2e80:
	/* 0x2e80: b.cc 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2e80, 0x140, arm64_l_140);
arm64_l_2e84:
	/* 0x2e84: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2e88:
	/* 0x2e88: b.cc 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2e88, 0x124, arm64_l_124);
arm64_l_2e8c:
	/* 0x2e8c: ldr w9, [x21, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2e90:
	/* 0x2e90: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2e94:
	/* 0x2e94: b.le 31b0 <generic_retuprobe_filter_arg+0x31b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2e94, 0x31b0, arm64_l_31b0);
arm64_l_2e98:
	/* 0x2e98: sub w10, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2e9c:
	/* 0x2e9c: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2ea0:
	/* 0x2ea0: b.cc 31d0 <generic_retuprobe_filter_arg+0x31d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2ea0, 0x31d0, arm64_l_31d0);
arm64_l_2ea4:
	/* 0x2ea4: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2ea8:
	/* 0x2ea8: b.eq 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2ea8, 0x140, arm64_l_140);
arm64_l_2eac:
	/* 0x2eac: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2eb0:
	/* 0x2eb0: b.ne c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2eb0, 0xc4, arm64_l_c4);
arm64_l_2eb4:
	/* 0x2eb4: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2eb8:
	/* 0x2eb8: b 2f14 <generic_retuprobe_filter_arg+0x2f14> */
	ARM64_SIM_A64_JMP(0x2eb8, 0x2f14, arm64_l_2f14);
arm64_l_2ebc:
	/* 0x2ebc: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ec0:
	/* 0x2ec0: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2ec4:
	/* 0x2ec4: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2ec8:
	/* 0x2ec8: b.hi 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2ec8, 0x140, arm64_l_140);
arm64_l_2ecc:
	/* 0x2ecc: b 2ee0 <generic_retuprobe_filter_arg+0x2ee0> */
	ARM64_SIM_A64_JMP(0x2ecc, 0x2ee0, arm64_l_2ee0);
arm64_l_2ed0:
	/* 0x2ed0: ldr w12, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ed4:
	/* 0x2ed4: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2ed8:
	/* 0x2ed8: ldr x12, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2edc:
	/* 0x2edc: b.cc 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2edc, 0x140, arm64_l_140);
arm64_l_2ee0:
	/* 0x2ee0: cmp w10, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2ee4:
	/* 0x2ee4: b.cc 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2ee4, 0x124, arm64_l_124);
arm64_l_2ee8:
	/* 0x2ee8: ldr w10, [x21, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2eec:
	/* 0x2eec: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2ef0:
	/* 0x2ef0: b.le 2f20 <generic_retuprobe_filter_arg+0x2f20> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2ef0, 0x2f20, arm64_l_2f20);
arm64_l_2ef4:
	/* 0x2ef4: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2ef8:
	/* 0x2ef8: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2efc:
	/* 0x2efc: b.cc 2f58 <generic_retuprobe_filter_arg+0x2f58> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2efc, 0x2f58, arm64_l_2f58);
arm64_l_2f00:
	/* 0x2f00: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2f04:
	/* 0x2f04: b.eq 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2f04, 0x140, arm64_l_140);
arm64_l_2f08:
	/* 0x2f08: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2f0c:
	/* 0x2f0c: b.ne c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2f0c, 0xc4, arm64_l_c4);
arm64_l_2f10:
	/* 0x2f10: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2f14:
	/* 0x2f14: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2f18:
	/* 0x2f18: b.ne 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2f18, 0x140, arm64_l_140);
arm64_l_2f1c:
	/* 0x2f1c: b 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JMP(0x2f1c, 0x124, arm64_l_124);
arm64_l_2f20:
	/* 0x2f20: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2f24:
	/* 0x2f24: b.eq 2f60 <generic_retuprobe_filter_arg+0x2f60> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2f24, 0x2f60, arm64_l_2f60);
arm64_l_2f28:
	/* 0x2f28: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2f2c:
	/* 0x2f2c: b.ne c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2f2c, 0xc4, arm64_l_c4);
arm64_l_2f30:
	/* 0x2f30: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2f34:
	/* 0x2f34: b.hi 331c <generic_retuprobe_filter_arg+0x331c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2f34, 0x331c, arm64_l_331c);
arm64_l_2f38:
	/* 0x2f38: lsl w9, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2f3c:
	/* 0x2f3c: mov w11, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2f40:
	/* 0x2f40: tst w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2f44:
	/* 0x2f44: b.eq 331c <generic_retuprobe_filter_arg+0x331c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2f44, 0x331c, arm64_l_331c);
arm64_l_2f48:
	/* 0x2f48: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2f4c:
	/* 0x2f4c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2f50:
	/* 0x2f50: b.ge 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x2f50, 0x124, arm64_l_124);
arm64_l_2f54:
	/* 0x2f54: b 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JMP(0x2f54, 0x140, arm64_l_140);
arm64_l_2f58:
	/* 0x2f58: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2f5c:
	/* 0x2f5c: b 31d4 <generic_retuprobe_filter_arg+0x31d4> */
	ARM64_SIM_A64_JMP(0x2f5c, 0x31d4, arm64_l_31d4);
arm64_l_2f60:
	/* 0x2f60: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2f64:
	/* 0x2f64: b.hi 332c <generic_retuprobe_filter_arg+0x332c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2f64, 0x332c, arm64_l_332c);
arm64_l_2f68:
	/* 0x2f68: lsl w9, w17, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X17, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2f6c:
	/* 0x2f6c: mov w11, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2f70:
	/* 0x2f70: tst w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2f74:
	/* 0x2f74: b.eq 332c <generic_retuprobe_filter_arg+0x332c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2f74, 0x332c, arm64_l_332c);
arm64_l_2f78:
	/* 0x2f78: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2f7c:
	/* 0x2f7c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2f80:
	/* 0x2f80: b.le 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2f80, 0x124, arm64_l_124);
arm64_l_2f84:
	/* 0x2f84: b 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JMP(0x2f84, 0x140, arm64_l_140);
arm64_l_2f88:
	/* 0x2f88: and w8, w25, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_2f8c:
	/* 0x2f8c: mov w9, #0x1000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_2f90:
	/* 0x2f90: cmp w8, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2048ULL);
arm64_l_2f94:
	/* 0x2f94: mov w8, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_2f98:
	/* 0x2f98: csel w11, w9, w8, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_2f9c:
	/* 0x2f9c: sub w8, w11, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_2fa0:
	/* 0x2fa0: ror w8, w8, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_ROR), 8ULL);
arm64_l_2fa4:
	/* 0x2fa4: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2fa8:
	/* 0x2fa8: b.gt 2fc0 <generic_retuprobe_filter_arg+0x2fc0> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2fa8, 0x2fc0, arm64_l_2fc0);
arm64_l_2fac:
	/* 0x2fac: cbz w8, 2fe0 <generic_retuprobe_filter_arg+0x2fe0> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x2fac, 0x2fe0, arm64_l_2fe0);
arm64_l_2fb0:
	/* 0x2fb0: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2fb4:
	/* 0x2fb4: b.ne 2fd8 <generic_retuprobe_filter_arg+0x2fd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2fb4, 0x2fd8, arm64_l_2fd8);
arm64_l_2fb8:
	/* 0x2fb8: mov w10, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 7ULL);
arm64_l_2fbc:
	/* 0x2fbc: b 2fec <generic_retuprobe_filter_arg+0x2fec> */
	ARM64_SIM_A64_JMP(0x2fbc, 0x2fec, arm64_l_2fec);
arm64_l_2fc0:
	/* 0x2fc0: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2fc4:
	/* 0x2fc4: b.eq 2fe8 <generic_retuprobe_filter_arg+0x2fe8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2fc4, 0x2fe8, arm64_l_2fe8);
arm64_l_2fc8:
	/* 0x2fc8: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_2fcc:
	/* 0x2fcc: b.ne 2fd8 <generic_retuprobe_filter_arg+0x2fd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2fcc, 0x2fd8, arm64_l_2fd8);
arm64_l_2fd0:
	/* 0x2fd0: mov w10, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 9ULL);
arm64_l_2fd4:
	/* 0x2fd4: b 2fec <generic_retuprobe_filter_arg+0x2fec> */
	ARM64_SIM_A64_JMP(0x2fd4, 0x2fec, arm64_l_2fec);
arm64_l_2fd8:
	/* 0x2fd8: mov w10, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_2fdc:
	/* 0x2fdc: b 2fec <generic_retuprobe_filter_arg+0x2fec> */
	ARM64_SIM_A64_JMP(0x2fdc, 0x2fec, arm64_l_2fec);
arm64_l_2fe0:
	/* 0x2fe0: mov w10, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 6ULL);
arm64_l_2fe4:
	/* 0x2fe4: b 2fec <generic_retuprobe_filter_arg+0x2fec> */
	ARM64_SIM_A64_JMP(0x2fe4, 0x2fec, arm64_l_2fec);
arm64_l_2fe8:
	/* 0x2fe8: mov w10, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2fec:
	/* 0x2fec: add x8, x21, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2ff0:
	/* 0x2ff0: and w9, w10, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_2ff4:
	/* 0x2ff4: ldr w8, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_2ff8:
	/* 0x2ff8: cmn w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2ffc:
	/* 0x2ffc: b.eq 32b8 <generic_retuprobe_filter_arg+0x32b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2ffc, 0x32b8, arm64_l_32b8);
arm64_l_3000:
	/* 0x3000: stp w8, w11, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_3004:
	/* 0x3004: str w10, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_3008:
	/* 0x3008: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_19));
arm64_l_300c:
	/* 0x300c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3010:
	/* 0x3010: add x19, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_3014:
	/* 0x3014: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_3018:
	/* 0x3018: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_301c:
	/* 0x301c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x3020ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3020:
	/* 0x3020: mov x9, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3024:
	/* 0x3024: adrp x0, 0 <heap_ro_zero> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero_4));
arm64_l_3028:
	/* 0x3028: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_302c:
	/* 0x302c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3030:
	/* 0x3030: add x1, sp, #0x88 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_3034:
	/* 0x3034: mov x19, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3038:
	/* 0x3038: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x303cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_303c:
	/* 0x303c: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3040:
	/* 0x3040: cbz x19, 32bc <generic_retuprobe_filter_arg+0x32bc> */
	ARM64_SIM_A64_CBZ(ARM64_X19, 0x3040, 0x32bc, arm64_l_32bc);
arm64_l_3044:
	/* 0x3044: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3048:
	/* 0x3048: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_304c:
	/* 0x304c: cbz x0, 32c4 <generic_retuprobe_filter_arg+0x32c4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x304c, 0x32c4, arm64_l_32c4);
arm64_l_3050:
	/* 0x3050: ldr w22, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_3054:
	/* 0x3054: str x0, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_3058:
	/* 0x3058: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_305c:
	/* 0x305c: cmp w22, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_3060:
	/* 0x3060: b.gt 309c <generic_retuprobe_filter_arg+0x309c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x3060, 0x309c, arm64_l_309c);
arm64_l_3064:
	/* 0x3064: strb w25, [x0], #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 1ULL);
arm64_l_3068:
	/* 0x3068: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_306c:
	/* 0x306c: mov w1, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_3070:
	/* 0x3070: mov x2, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3074:
	/* 0x3074: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x3078ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3078:
	/* 0x3078: ldr w8, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_307c:
	/* 0x307c: subs w8, w8, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3080:
	/* 0x3080: b.ls 30d4 <generic_retuprobe_filter_arg+0x30d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x3080, 0x30d4, arm64_l_30d4);
arm64_l_3084:
	/* 0x3084: add x9, x19, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X19, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_3088:
	/* 0x3088: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_308c:
	/* 0x308c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_3090:
	/* 0x3090: ldr x2, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_3094:
	/* 0x3094: add x0, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3098:
	/* 0x3098: b 30d0 <generic_retuprobe_filter_arg+0x30d0> */
	ARM64_SIM_A64_JMP(0x3098, 0x30d0, arm64_l_30d0);
arm64_l_309c:
	/* 0x309c: strh w25, [x0], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_30a0:
	/* 0x30a0: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_30a4:
	/* 0x30a4: mov w1, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_30a8:
	/* 0x30a8: mov x2, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_30ac:
	/* 0x30ac: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x30b0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_30b0:
	/* 0x30b0: ldr w8, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_30b4:
	/* 0x30b4: subs w8, w8, w25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_30b8:
	/* 0x30b8: b.ls 30d4 <generic_retuprobe_filter_arg+0x30d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x30b8, 0x30d4, arm64_l_30d4);
arm64_l_30bc:
	/* 0x30bc: add x9, x19, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X19, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_30c0:
	/* 0x30c0: ldr x2, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_30c4:
	/* 0x30c4: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_30c8:
	/* 0x30c8: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_30cc:
	/* 0x30cc: add x0, x9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_30d0:
	/* 0x30d0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x30d4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_30d4:
	/* 0x30d4: ldr w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_30d8:
	/* 0x30d8: cmp w22, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_30dc:
	/* 0x30dc: str w8, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_30e0:
	/* 0x30e0: b.le 3118 <generic_retuprobe_filter_arg+0x3118> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x30e0, 0x3118, arm64_l_3118);
arm64_l_30e4:
	/* 0x30e4: cmp w22, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_30e8:
	/* 0x30e8: b.gt 314c <generic_retuprobe_filter_arg+0x314c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x30e8, 0x314c, arm64_l_314c);
arm64_l_30ec:
	/* 0x30ec: cmp w22, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_30f0:
	/* 0x30f0: b.eq 3270 <generic_retuprobe_filter_arg+0x3270> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x30f0, 0x3270, arm64_l_3270);
arm64_l_30f4:
	/* 0x30f4: cmp w22, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_30f8:
	/* 0x30f8: b.eq 3234 <generic_retuprobe_filter_arg+0x3234> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x30f8, 0x3234, arm64_l_3234);
arm64_l_30fc:
	/* 0x30fc: cmp w22, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_3100:
	/* 0x3100: b.ne 32b8 <generic_retuprobe_filter_arg+0x32b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3100, 0x32b8, arm64_l_32b8);
arm64_l_3104:
	/* 0x3104: adrp x0, 0 <string_maps_7> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_7_16));
arm64_l_3108:
	/* 0x3108: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_310c:
	/* 0x310c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3110:
	/* 0x3110: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3114:
	/* 0x3114: b 3294 <generic_retuprobe_filter_arg+0x3294> */
	ARM64_SIM_A64_JMP(0x3114, 0x3294, arm64_l_3294);
arm64_l_3118:
	/* 0x3118: cmp w22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_311c:
	/* 0x311c: b.le 3178 <generic_retuprobe_filter_arg+0x3178> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x311c, 0x3178, arm64_l_3178);
arm64_l_3120:
	/* 0x3120: cmp w22, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3124:
	/* 0x3124: b.eq 325c <generic_retuprobe_filter_arg+0x325c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3124, 0x325c, arm64_l_325c);
arm64_l_3128:
	/* 0x3128: cmp w22, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_312c:
	/* 0x312c: b.eq 3220 <generic_retuprobe_filter_arg+0x3220> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x312c, 0x3220, arm64_l_3220);
arm64_l_3130:
	/* 0x3130: cmp w22, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_3134:
	/* 0x3134: b.ne 32b8 <generic_retuprobe_filter_arg+0x32b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3134, 0x32b8, arm64_l_32b8);
arm64_l_3138:
	/* 0x3138: adrp x0, 0 <string_maps_4> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_4_13));
arm64_l_313c:
	/* 0x313c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3140:
	/* 0x3140: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3144:
	/* 0x3144: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3148:
	/* 0x3148: b 3294 <generic_retuprobe_filter_arg+0x3294> */
	ARM64_SIM_A64_JMP(0x3148, 0x3294, arm64_l_3294);
arm64_l_314c:
	/* 0x314c: cmp w22, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3150:
	/* 0x3150: b.eq 3284 <generic_retuprobe_filter_arg+0x3284> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3150, 0x3284, arm64_l_3284);
arm64_l_3154:
	/* 0x3154: cmp w22, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_3158:
	/* 0x3158: b.eq 3248 <generic_retuprobe_filter_arg+0x3248> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3158, 0x3248, arm64_l_3248);
arm64_l_315c:
	/* 0x315c: cmp w22, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_3160:
	/* 0x3160: b.ne 32b8 <generic_retuprobe_filter_arg+0x32b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3160, 0x32b8, arm64_l_32b8);
arm64_l_3164:
	/* 0x3164: adrp x0, 0 <string_maps_10> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_10_10));
arm64_l_3168:
	/* 0x3168: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_316c:
	/* 0x316c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3170:
	/* 0x3170: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3174:
	/* 0x3174: b 3294 <generic_retuprobe_filter_arg+0x3294> */
	ARM64_SIM_A64_JMP(0x3174, 0x3294, arm64_l_3294);
arm64_l_3178:
	/* 0x3178: cbz w22, 320c <generic_retuprobe_filter_arg+0x320c> */
	ARM64_SIM_A64_CBZ(ARM64_X22, 0x3178, 0x320c, arm64_l_320c);
arm64_l_317c:
	/* 0x317c: cmp w22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3180:
	/* 0x3180: b.ne 32b8 <generic_retuprobe_filter_arg+0x32b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3180, 0x32b8, arm64_l_32b8);
arm64_l_3184:
	/* 0x3184: adrp x0, 0 <string_maps_1> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_1_9));
arm64_l_3188:
	/* 0x3188: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_318c:
	/* 0x318c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3190:
	/* 0x3190: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3194:
	/* 0x3194: b 3294 <generic_retuprobe_filter_arg+0x3294> */
	ARM64_SIM_A64_JMP(0x3194, 0x3294, arm64_l_3294);
arm64_l_3198:
	/* 0x3198: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_319c:
	/* 0x319c: b.eq 330c <generic_retuprobe_filter_arg+0x330c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x319c, 0x330c, arm64_l_330c);
arm64_l_31a0:
	/* 0x31a0: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_31a4:
	/* 0x31a4: b.ne c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x31a4, 0xc4, arm64_l_c4);
arm64_l_31a8:
	/* 0x31a8: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_31ac:
	/* 0x31ac: b 3330 <generic_retuprobe_filter_arg+0x3330> */
	ARM64_SIM_A64_JMP(0x31ac, 0x3330, arm64_l_3330);
arm64_l_31b0:
	/* 0x31b0: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_31b4:
	/* 0x31b4: b.eq 3314 <generic_retuprobe_filter_arg+0x3314> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x31b4, 0x3314, arm64_l_3314);
arm64_l_31b8:
	/* 0x31b8: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_31bc:
	/* 0x31bc: b.ne c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x31bc, 0xc4, arm64_l_c4);
arm64_l_31c0:
	/* 0x31c0: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_31c4:
	/* 0x31c4: b 3330 <generic_retuprobe_filter_arg+0x3330> */
	ARM64_SIM_A64_JMP(0x31c4, 0x3330, arm64_l_3330);
arm64_l_31c8:
	/* 0x31c8: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_31cc:
	/* 0x31cc: b 31d4 <generic_retuprobe_filter_arg+0x31d4> */
	ARM64_SIM_A64_JMP(0x31cc, 0x31d4, arm64_l_31d4);
arm64_l_31d0:
	/* 0x31d0: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_31d4:
	/* 0x31d4: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_31d8:
	/* 0x31d8: b.ne 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x31d8, 0x124, arm64_l_124);
arm64_l_31dc:
	/* 0x31dc: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_31e0:
	/* 0x31e0: cset w22, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_31e4:
	/* 0x31e4: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x31e4, 0x140, arm64_l_140);
arm64_l_31e8:
	/* 0x31e8: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x31e8, 0xc4, arm64_l_c4);
arm64_l_31ec:
	/* 0x31ec: ldr x9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_31f0:
	/* 0x31f0: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_31f4:
	/* 0x31f4: b.cs 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x31f4, 0x124, arm64_l_124);
arm64_l_31f8:
	/* 0x31f8: b 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JMP(0x31f8, 0x140, arm64_l_140);
arm64_l_31fc:
	/* 0x31fc: ldr x9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3200:
	/* 0x3200: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3204:
	/* 0x3204: b.ls 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x3204, 0x124, arm64_l_124);
arm64_l_3208:
	/* 0x3208: b 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JMP(0x3208, 0x140, arm64_l_140);
arm64_l_320c:
	/* 0x320c: adrp x0, 0 <string_maps_0> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_0_8));
arm64_l_3210:
	/* 0x3210: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3214:
	/* 0x3214: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3218:
	/* 0x3218: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_321c:
	/* 0x321c: b 3294 <generic_retuprobe_filter_arg+0x3294> */
	ARM64_SIM_A64_JMP(0x321c, 0x3294, arm64_l_3294);
arm64_l_3220:
	/* 0x3220: adrp x0, 0 <string_maps_3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_3_12));
arm64_l_3224:
	/* 0x3224: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3228:
	/* 0x3228: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_322c:
	/* 0x322c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3230:
	/* 0x3230: b 3294 <generic_retuprobe_filter_arg+0x3294> */
	ARM64_SIM_A64_JMP(0x3230, 0x3294, arm64_l_3294);
arm64_l_3234:
	/* 0x3234: adrp x0, 0 <string_maps_6> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_6_15));
arm64_l_3238:
	/* 0x3238: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_323c:
	/* 0x323c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3240:
	/* 0x3240: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3244:
	/* 0x3244: b 3294 <generic_retuprobe_filter_arg+0x3294> */
	ARM64_SIM_A64_JMP(0x3244, 0x3294, arm64_l_3294);
arm64_l_3248:
	/* 0x3248: adrp x0, 0 <string_maps_9> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_9_18));
arm64_l_324c:
	/* 0x324c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3250:
	/* 0x3250: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3254:
	/* 0x3254: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3258:
	/* 0x3258: b 3294 <generic_retuprobe_filter_arg+0x3294> */
	ARM64_SIM_A64_JMP(0x3258, 0x3294, arm64_l_3294);
arm64_l_325c:
	/* 0x325c: adrp x0, 0 <string_maps_2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_2_11));
arm64_l_3260:
	/* 0x3260: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3264:
	/* 0x3264: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3268:
	/* 0x3268: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_326c:
	/* 0x326c: b 3294 <generic_retuprobe_filter_arg+0x3294> */
	ARM64_SIM_A64_JMP(0x326c, 0x3294, arm64_l_3294);
arm64_l_3270:
	/* 0x3270: adrp x0, 0 <string_maps_5> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_5_14));
arm64_l_3274:
	/* 0x3274: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3278:
	/* 0x3278: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_327c:
	/* 0x327c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3280:
	/* 0x3280: b 3294 <generic_retuprobe_filter_arg+0x3294> */
	ARM64_SIM_A64_JMP(0x3280, 0x3294, arm64_l_3294);
arm64_l_3284:
	/* 0x3284: adrp x0, 0 <string_maps_8> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_8_17));
arm64_l_3288:
	/* 0x3288: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_328c:
	/* 0x328c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3290:
	/* 0x3290: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3294:
	/* 0x3294: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3298:
	/* 0x3298: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x329cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_329c:
	/* 0x329c: cbz x0, 32b8 <generic_retuprobe_filter_arg+0x32b8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x329c, 0x32b8, arm64_l_32b8);
arm64_l_32a0:
	/* 0x32a0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_32a4:
	/* 0x32a4: mov x1, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_32a8:
	/* 0x32a8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x32acULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_32ac:
	/* 0x32ac: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_32b0:
	/* 0x32b0: cset w22, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_32b4:
	/* 0x32b4: b 32bc <generic_retuprobe_filter_arg+0x32bc> */
	ARM64_SIM_A64_JMP(0x32b4, 0x32bc, arm64_l_32bc);
arm64_l_32b8:
	/* 0x32b8: mov x22, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_32bc:
	/* 0x32bc: ldp x12, x16, [sp, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X16, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_32c0:
	/* 0x32c0: mov w17, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X17, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_32c4:
	/* 0x32c4: ldr w8, [x21, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_32c8:
	/* 0x32c8: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_32cc:
	/* 0x32cc: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_32d0:
	/* 0x32d0: b.hi 3300 <generic_retuprobe_filter_arg+0x3300> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x32d0, 0x3300, arm64_l_3300);
arm64_l_32d4:
	/* 0x32d4: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_32d8:
	/* 0x32d8: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_32dc:
	/* 0x32dc: lsl x8, x17, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X17, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_32e0:
	/* 0x32e0: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_32e4:
	/* 0x32e4: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_32e8:
	/* 0x32e8: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_32ec:
	/* 0x32ec: b.eq 1ce4 <generic_retuprobe_filter_arg+0x1ce4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x32ec, 0x1ce4, arm64_l_1ce4);
arm64_l_32f0:
	/* 0x32f0: cmp x22, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_32f4:
	/* 0x32f4: cset w22, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_32f8:
	/* 0x32f8: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x32f8, 0x140, arm64_l_140);
arm64_l_32fc:
	/* 0x32fc: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x32fc, 0xc4, arm64_l_c4);
arm64_l_3300:
	/* 0x3300: ldr x19, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_3304:
	/* 0x3304: cbnz x22, 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_CBNZ(ARM64_X22, 0x3304, 0x140, arm64_l_140);
arm64_l_3308:
	/* 0x3308: b c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JMP(0x3308, 0xc4, arm64_l_c4);
arm64_l_330c:
	/* 0x330c: ldrb w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3310:
	/* 0x3310: b 3320 <generic_retuprobe_filter_arg+0x3320> */
	ARM64_SIM_A64_JMP(0x3310, 0x3320, arm64_l_3320);
arm64_l_3314:
	/* 0x3314: ldrh w10, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3318:
	/* 0x3318: b 3320 <generic_retuprobe_filter_arg+0x3320> */
	ARM64_SIM_A64_JMP(0x3318, 0x3320, arm64_l_3320);
arm64_l_331c:
	/* 0x331c: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3320:
	/* 0x3320: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3324:
	/* 0x3324: b.cs 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x3324, 0x124, arm64_l_124);
arm64_l_3328:
	/* 0x3328: b 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JMP(0x3328, 0x140, arm64_l_140);
arm64_l_332c:
	/* 0x332c: ldr w9, [x25] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3330:
	/* 0x3330: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3334:
	/* 0x3334: b.ls 124 <generic_retuprobe_filter_arg+0x124> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x3334, 0x124, arm64_l_124);
arm64_l_3338:
	/* 0x3338: b 140 <generic_retuprobe_filter_arg+0x140> */
	ARM64_SIM_A64_JMP(0x3338, 0x140, arm64_l_140);
arm64_l_333c:
	/* 0x333c: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_3340:
	/* 0x3340: adrp x1, 0 <retuprobe_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&retuprobe_calls_7));
arm64_l_3344:
	/* 0x3344: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_3348:
	/* 0x3348: mov x0, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_334c:
	/* 0x334c: stur w8, [x19, #67] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 67ULL);
arm64_l_3350:
	/* 0x3350: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_3354:
	/* 0x3354: mov w2, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_3358:
	/* 0x3358: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_335c:
	/* 0x335c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x3360ULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3360:
	/* 0x3360: adrp x1, 0 <retuprobe_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&retuprobe_calls_7));
arm64_l_3364:
	/* 0x3364: mov w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_3368:
	/* 0x3368: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_336c:
	/* 0x336c: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3370:
	/* 0x3370: mov x0, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3374:
	/* 0x3374: mov w2, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_3378:
	/* 0x3378: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x337cULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_337c:
	/* 0x337c: ldp x20, x19, [sp, #224] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_3380:
	/* 0x3380: mov w0, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_3384:
	/* 0x3384: ldr x29, [sp, #160] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_3388:
	/* 0x3388: ldp x22, x21, [sp, #208] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_338c:
	/* 0x338c: ldp x24, x23, [sp, #192] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_3390:
	/* 0x3390: ldp x30, x25, [sp, #176] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_3394:
	/* 0x3394: add sp, sp, #0xf0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_3398:
	/* 0x3398: b 34f8 <__native_link_arm64_ret_trampoline> */
	ARM64_SIM_A64_JMP(0x3398, 0x34f8, arm64_l_34f8);
arm64_l_339c:
	/* 0x339c: ldrb w8, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_33a0:
	/* 0x33a0: cbz w8, 33ac <generic_retuprobe_filter_arg+0x33ac> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x33a0, 0x33ac, arm64_l_33ac);
arm64_l_33a4:
	/* 0x33a4: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_33a8:
	/* 0x33a8: b 33f8 <generic_retuprobe_filter_arg+0x33f8> */
	ARM64_SIM_A64_JMP(0x33a8, 0x33f8, arm64_l_33f8);
arm64_l_33ac:
	/* 0x33ac: ldrb w8, [x19, #1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1ULL);
arm64_l_33b0:
	/* 0x33b0: cbz w8, 33bc <generic_retuprobe_filter_arg+0x33bc> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x33b0, 0x33bc, arm64_l_33bc);
arm64_l_33b4:
	/* 0x33b4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_33b8:
	/* 0x33b8: b 33f8 <generic_retuprobe_filter_arg+0x33f8> */
	ARM64_SIM_A64_JMP(0x33b8, 0x33f8, arm64_l_33f8);
arm64_l_33bc:
	/* 0x33bc: ldrb w8, [x19, #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_33c0:
	/* 0x33c0: cbz w8, 33cc <generic_retuprobe_filter_arg+0x33cc> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x33c0, 0x33cc, arm64_l_33cc);
arm64_l_33c4:
	/* 0x33c4: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_33c8:
	/* 0x33c8: b 33f8 <generic_retuprobe_filter_arg+0x33f8> */
	ARM64_SIM_A64_JMP(0x33c8, 0x33f8, arm64_l_33f8);
arm64_l_33cc:
	/* 0x33cc: ldrb w8, [x19, #3] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3ULL);
arm64_l_33d0:
	/* 0x33d0: cbz w8, 33dc <generic_retuprobe_filter_arg+0x33dc> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x33d0, 0x33dc, arm64_l_33dc);
arm64_l_33d4:
	/* 0x33d4: mov w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_33d8:
	/* 0x33d8: b 33f8 <generic_retuprobe_filter_arg+0x33f8> */
	ARM64_SIM_A64_JMP(0x33d8, 0x33f8, arm64_l_33f8);
arm64_l_33dc:
	/* 0x33dc: ldrb w8, [x19, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_33e0:
	/* 0x33e0: cbz w8, 33ec <generic_retuprobe_filter_arg+0x33ec> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x33e0, 0x33ec, arm64_l_33ec);
arm64_l_33e4:
	/* 0x33e4: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_33e8:
	/* 0x33e8: b 33f8 <generic_retuprobe_filter_arg+0x33f8> */
	ARM64_SIM_A64_JMP(0x33e8, 0x33f8, arm64_l_33f8);
arm64_l_33ec:
	/* 0x33ec: ldrb w8, [x19, #5] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_33f0:
	/* 0x33f0: cbz w8, 3418 <generic_retuprobe_filter_arg+0x3418> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x33f0, 0x3418, arm64_l_3418);
arm64_l_33f4:
	/* 0x33f4: mov w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_33f8:
	/* 0x33f8: stur w8, [x19, #63] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 63ULL);
arm64_l_33fc:
	/* 0x33fc: adrp x1, 0 <retuprobe_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&retuprobe_calls_7));
arm64_l_3400:
	/* 0x3400: mov w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_3404:
	/* 0x3404: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_3408:
	/* 0x3408: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_340c:
	/* 0x340c: mov x0, x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3410:
	/* 0x3410: mov w2, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_3414:
	/* 0x3414: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x3418ULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3418:
	/* 0x3418: ldr x19, [x20, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_341c:
	/* 0x341c: mov w8, #0xe */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_3420:
	/* 0x3420: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x3424ULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3424:
	/* 0x3424: stp x19, x0, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_3428:
	/* 0x3428: adrp x19, 0 <retprobe_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&retprobe_map_6));
arm64_l_342c:
	/* 0x342c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3430:
	/* 0x3430: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3434:
	/* 0x3434: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3438:
	/* 0x3438: ldr x19, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_343c:
	/* 0x343c: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3440:
	/* 0x3440: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x3444ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_3444:
	/* 0x3444: cbz x0, 337c <generic_retuprobe_filter_arg+0x337c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x3444, 0x337c, arm64_l_337c);
arm64_l_3448:
	/* 0x3448: mov w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_344c:
	/* 0x344c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3450:
	/* 0x3450: add x1, sp, #0x60 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_3454:
	/* 0x3454: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3458:
	/* 0x3458: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		} else {
			switch (__a64_target) {
			case 3ULL: ARM64_SIM_A64_LINK(0x345cULL); ARM64_SIM_BPF_CALL_bpf_map_delete_elem(); break;
			default: ARM64_SIM_L_UNSUPPORTED_OPCODE(); break;
			}
		}
	}
arm64_l_345c:
	/* 0x345c: b 337c <generic_retuprobe_filter_arg+0x337c> */
	ARM64_SIM_A64_JMP(0x345c, 0x337c, arm64_l_337c);
arm64_l_3460:
	/* 0x3460: cbz x2, 34ec <native_bpf_strncasestr+0x8c> */
	ARM64_SIM_A64_CBZ(ARM64_X2, 0x3460, 0x34ec, arm64_l_34ec);
arm64_l_3464:
	/* 0x3464: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3468:
	/* 0x3468: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_346c:
	/* 0x346c: mov x9, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3470:
	/* 0x3470: b 3494 <native_bpf_strncasestr+0x34> */
	ARM64_SIM_A64_JMP(0x3470, 0x3494, arm64_l_3494);
arm64_l_3474:
	/* 0x3474: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3478:
	/* 0x3478: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_347c:
	/* 0x347c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3480:
	/* 0x3480: add x0, x0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3484:
	/* 0x3484: sub x9, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3488:
	/* 0x3488: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_348c:
	/* 0x348c: cmp x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3490:
	/* 0x3490: b.eq 34ec <native_bpf_strncasestr+0x8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3490, 0x34ec, arm64_l_34ec);
arm64_l_3494:
	/* 0x3494: mov x10, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3498:
	/* 0x3498: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_349c:
	/* 0x349c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_34a0:
	/* 0x34a0: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_34a4:
	/* 0x34a4: b.eq 3480 <native_bpf_strncasestr+0x20> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x34a4, 0x3480, arm64_l_3480);
arm64_l_34a8:
	/* 0x34a8: ldrb w11, [x1, x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X1, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X10, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_34ac:
	/* 0x34ac: cbz w11, 34f0 <native_bpf_strncasestr+0x90> */
	ARM64_SIM_A64_CBZ(ARM64_X11, 0x34ac, 0x34f0, arm64_l_34f0);
arm64_l_34b0:
	/* 0x34b0: ldrb w12, [x8, x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X10, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_34b4:
	/* 0x34b4: sub w13, w12, #0x41 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 65ULL);
arm64_l_34b8:
	/* 0x34b8: orr w14, w12, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_34bc:
	/* 0x34bc: cmp w13, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_34c0:
	/* 0x34c0: sub w13, w11, #0x41 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 65ULL);
arm64_l_34c4:
	/* 0x34c4: csel w12, w14, w12, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X12, ARM64_X14, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_34c8:
	/* 0x34c8: orr w14, w11, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_34cc:
	/* 0x34cc: cmp w13, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_34d0:
	/* 0x34d0: csel w11, w14, w11, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X14, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_34d4:
	/* 0x34d4: cmp w12, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_34d8:
	/* 0x34d8: b.ne 3480 <native_bpf_strncasestr+0x20> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x34d8, 0x3480, arm64_l_3480);
arm64_l_34dc:
	/* 0x34dc: cmp x10, #0x63 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 99ULL);
arm64_l_34e0:
	/* 0x34e0: add x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_34e4:
	/* 0x34e4: b.cc 34a0 <native_bpf_strncasestr+0x40> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x34e4, 0x34a0, arm64_l_34a0);
arm64_l_34e8:
	/* 0x34e8: b 3480 <native_bpf_strncasestr+0x20> */
	ARM64_SIM_A64_JMP(0x34e8, 0x3480, arm64_l_3480);
arm64_l_34ec:
	/* 0x34ec: mov w0, #0xffffffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967295ULL);
arm64_l_34f0:
	/* 0x34f0: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_34f0);
arm64_l_34f4:
	/* 0x34f4: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_34f8:
	/* 0x34f8: mov x7, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
