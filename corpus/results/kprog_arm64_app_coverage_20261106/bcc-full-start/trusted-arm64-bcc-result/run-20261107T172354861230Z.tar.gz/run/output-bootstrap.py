from pathlib import Path
import importlib.util,sys
R=Path('/workspaces/repository')
p=R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py'
s=importlib.util.spec_from_file_location('canonical_arm_bcc_transport',p)
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.HERE=R/'corpus/results/kprog_arm64_app_coverage_20261106/bcc-full-start'
m.HERE.mkdir(parents=True,exist_ok=True)
if sys.argv[1:]!=['host','bcc']:raise SystemExit('expected host bcc')
m.host('bcc')
