#!/bin/sh
cd /workspaces/repository
PYTHONDONTWRITEBYTECODE=1 make -f corpus/results/kprog_arm64_app_coverage_20261106/Makefile trusted-bcc-arm64-run HERE=/workspaces/repository/kprog/arm64/build/trusted-transport/bcc-full-start
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/bcc-full-start.exit
exit "$rc"
