#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_STACK_BIAS 32LL
#define ARM64_SIM_STACK_BYTES 32U
#define ARM64_SIM_RETURN_CASES \
	case 0x24ULL: goto arm64_l_24; \
	case 0x34ULL: goto arm64_l_34; \
	case 0x44ULL: goto arm64_l_44;
#include "/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/katran-root-v3/simulator/arm64_sim_local_bpf.h"

/* Copyright (C) 2018-present, Facebook, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <linux/bpf.h>
#include <bpf_helpers.h>

#define ROOT_ARRAY_SIZE 3

struct {
  __uint(type, BPF_MAP_TYPE_PROG_ARRAY);
  __type(key, __u32);
  __type(value, __u32);
  __uint(max_entries, ROOT_ARRAY_SIZE);
} root_array SEC(".maps");

SEC("xdp")
int katran_xdp_root_arm64_sim_xdp(void *ctx)
{
	ARM64_SIM_ENTRY_RAW(ctx);
arm64_l_0:
	/* 0x0: stp x30, x21, [sp, #-32]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551584ULL);
arm64_l_4:
	/* 0x4: stp x20, x19, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_8:
	/* 0x8: adrp x20, 0 <root_array> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&root_array));
arm64_l_c:
	/* 0xc: mov w21, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_10:
	/* 0x10: mov w2, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_14:
	/* 0x14: ldr x20, [x20] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18:
	/* 0x18: mov x19, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c:
	/* 0x1c: mov x1, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_20:
	/* 0x20: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x24ULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_24:
	/* 0x24: mov x0, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_28:
	/* 0x28: mov x1, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2c:
	/* 0x2c: mov w2, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_30:
	/* 0x30: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x34ULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_34:
	/* 0x34: mov x0, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_38:
	/* 0x38: mov x1, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3c:
	/* 0x3c: mov w2, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_40:
	/* 0x40: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x44ULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_44:
	/* 0x44: ldp x20, x19, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_48:
	/* 0x48: mov w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_4c:
	/* 0x4c: ldp x30, x21, [sp], #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 32ULL);
arm64_l_50:
	/* 0x50: b 58 <__native_link_arm64_ret_trampoline> */
	ARM64_SIM_A64_JMP(0x50, 0x58, arm64_l_58);
arm64_l_54:
	/* 0x54: nop */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_58:
	/* 0x58: mov x7, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
