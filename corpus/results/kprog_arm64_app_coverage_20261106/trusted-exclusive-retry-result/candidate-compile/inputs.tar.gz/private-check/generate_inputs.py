from pathlib import Path
import hashlib,json,sys,traceback
R=Path('/workspaces/repository');D=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'kprog/arm64'))
import trusted_specializer as worker
from elftools.elf.elffile import ELFFile
native=(D/'exclusive_retry.native.o').read_bytes();rows=json.loads((D/'regression-cases.json').read_text());result=[]
for row in rows:
 output=D/'worker-inputs'/row['name']
 try:
  artifacts=worker.specialize(native,row['symbol'],dict(version=1,prog_type=6,section='xdp',maps=[]),output,R/'kprog/arm64/build/app-native-link/release/native-link')
  with Path(artifacts['simulator_object']).open('rb') as f:
   elf=ELFFile(f);sections={s.name:hashlib.sha256(s.data()).hexdigest() for s in elf.iter_sections() if s['sh_flags']&4}
  record=dict(**row,generated=True,compiled=True,executable_sections=sections,object_sha256=hashlib.sha256(Path(artifacts['simulator_object']).read_bytes()).hexdigest())
 except Exception as error:
  record=dict(**row,generated=False,compiled=False,error=str(error),traceback=traceback.format_exc())
 result.append(record);(D/'compiler-cases.json').write_text(json.dumps(result,indent=2)+'\n');print(row['name'],record['compiled'],flush=True)
assert len(result)==7 and all(r['compiled'] for r in result),result
print('7 fixtures generate/compile; no verifier or runtime result',flush=True)
