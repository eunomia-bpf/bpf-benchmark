# Native exclusive retry: private convergence candidate

The actual vfsstat LDXR/ADD/STXR/CBNZ proof fails the current verifier's
termination check. The existing canonical exclusive environment chooses failure
or success separately on every dynamic attempt. It permits failure forever;
there is no finite retry bound or eventual-success premise.

The proposed change checks a conditional memory-safety invariant over arbitrary
finite failure histories. A visited sealed exclusive input advances verifier
bookkeeping. An exact repeated state inside that native proof region reuses the
existing SCC backedge/read/precision propagation. All success/failure successors
remain; the C simulator, native bytes, flags and control flow are unchanged.
Ordinary eBPF, ordinary kinsn and marker-free native loops retain their checks.
This proposal deliberately makes no native termination or time-bound claim.

The existing kernel requires a native JIT emitter for native-proof regions in
lower_kinsn_proof_regions. After verification it validates the bound proof and
restores each region's original sidecar/call in restore_kinsn_proof_regions;
bpf_prog_select_runtime requires JIT for native_proof. Thus these proof cycles
are verifier inputs, not executable eBPF cycles. Their native counterparts keep
the original hardware retry behavior. Sealed native bytes, source-PC/site binding
and simulator refinement remain required trust obligations, not facts supplied
by the new bookkeeping fields.

Current validation is an external ARM Kbuild object compile only. It does not
link or boot a new kernel, load the candidate or prove SCC soundness. The first
object invocation used the wrong absolute external target; its error log is
retained. The corrected relative target compiles with the current kernel config.
Seven assembler fixtures cover two safe retry shapes, delayed unsafe memory on a
later failure, unsafe memory after later success, a failure-dependent pointer
used after the loop, unsafe first-failure memory and a marker-free infinite loop.
Fixture generation/compilation is separate from real verifier/runtime admission.

No source in vendor/linux-framework, no running Image/module, and no canonical
ARM producer is modified by this check. The existing BCC run and its collector
continue. Actual candidate-kernel checks, delayed-branch/precision behavior,
existing ARM safety regressions and a real BCC completion remain outstanding.
