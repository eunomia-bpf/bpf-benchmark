#!/bin/sh
cd /workspaces/repository
PYTHONDONTWRITEBYTECODE=1 taskset -c 12-15 make -C /workspaces/.agent-state/kprog-lanes/A/exclusive-convergence-check worker-inputs
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/exclusive-regression-compile.exit
exit "$rc"
