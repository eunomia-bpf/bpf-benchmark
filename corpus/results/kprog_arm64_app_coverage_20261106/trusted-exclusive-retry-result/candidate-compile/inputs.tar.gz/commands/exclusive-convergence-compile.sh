#!/bin/sh
cd /workspaces/repository
PYTHONDONTWRITEBYTECODE=1 taskset -c 12-15 make -C vendor/build/arm64/linux M=/workspaces/.agent-state/kprog-lanes/A/exclusive-convergence-check ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- verifier.o
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/A/exclusive-convergence-compile.exit
exit "$rc"
