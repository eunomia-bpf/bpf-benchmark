"""Private candidate admission diagnostic: every fixture is LOAD ONLY."""
from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,traceback,shutil
R=Path('/workspaces/repository');B=Path(__file__).resolve().parent
OUT=R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted-exclusive-retry-result/candidate-constant-cycle'
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def prepare():
 subprocess.run(['aarch64-linux-gnu-gcc','-c',str(B/'exclusive_retry.S'),'-o',str(B/'exclusive_retry.native.o')],check=True)
 rows=json.loads((B/'case-spec.json').read_text());native=B/'exclusive_retry.native.o';sha=hashlib.sha256(native.read_bytes()).hexdigest()
 for row in rows:
  p=B/(row['name']+'.manifest.json');p.write_text(json.dumps({'objects':[dict(program='neg_source',source_btf_symbol='neg_source',native_object=str(native),symbol=row['symbol'])]},indent=2)+'\n');row.update(manifest=str(p),native_sha256=sha,load_only=True)
 (B/'cases.json').write_text(json.dumps(rows,indent=2)+'\n')
def guest(live):
 live=Path(live);suite=load('suite',R/'kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp/check.py');suite.ARCH='arm64'
 rows=json.loads((B/'cases.json').read_text());shutil.copytree(B,live/'diagnostic-inputs')
 state=live/'requests';state.mkdir(mode=0o700);outcomes=[];logs=[]
 argv=[sys.executable,str(R/'kprog/trusted_service.py'),'--arch','2','--endpoint','/sys/kernel/debug/bpf_arm64_native_lab/specializer','--state',str(state),'--native-link',str(suite.native_link()),'--loader',str(suite.loader_build()/'trusted-native-loader')]
 service=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 summary=dict(ok=False,diagnostic_only=True,all_load_only=True,candidate_adopted=False)
 try:
  line=service.stdout.readline();logs.append(line);assert json.loads(line)['ready']
  for row in rows:
   # No TEST_RUN for positives or negatives in this admission diagnostic.
   command=[str(B/'bound-probe'),str(B/'context_hash.bpf.o' if row['negative'] else B/'context_array.bpf.o'),row['manifest']];assert len(command)==3
   done=subprocess.run(command,cwd=R/'kprog/fidelity',env=dict(os.environ,BPFREJIT_NATIVE_LOADER_REQUIRE_BOUND_PROOF='1'),text=True,capture_output=True)
   (live/(row['name']+'.stdout')).write_text(done.stdout);(live/(row['name']+'.stderr')).write_text(done.stderr)
   if done.returncode and 'trusted specializer refused native program:' not in done.stderr:raise RuntimeError('producer/setup failure '+row['name']+'\n'+done.stderr)
   line=service.stdout.readline();logs.append(line);receipt=json.loads(line);assert receipt['native_sha256']==row['native_sha256']
   stage,message=('accepted_load_only',done.stdout+done.stderr) if receipt['status']==0 else suite.classify(receipt)
   record=dict(**row,command=command,returncode=done.returncode,request=receipt,stage=stage,message=message,native_executed=False)
   outcomes.append(record);(live/'outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n');print(row['name'],stage,flush=True)
  summary.update(ok=True,cases=len(outcomes),negative_accepted=sum(r['negative'] and r['request']['status']==0 for r in outcomes))
 except BaseException as error:
  summary.update(error=str(error),traceback=traceback.format_exc());raise
 finally:
  service.terminate();logs.append(service.communicate()[0]);(live/'service.log').write_text(''.join(logs))
  (live/'guest.json').write_text(json.dumps(summary,indent=2)+'\n')
def host():
 m=load('transport',R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py');m.HERE=OUT;m.HERE.mkdir(parents=True,exist_ok=True);m.__file__=__file__
 class ProcessProxy:
  def __getattr__(self,name):return getattr(subprocess,name)
  def Popen(self,argv,*args,**kwargs):
   if isinstance(argv,list) and 'qemu-system-aarch64' in argv:
    argv=list(argv);argv[2]='12-15'
   return subprocess.Popen(argv,*args,**kwargs)
 m.subprocess=ProcessProxy();m.host()
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='host':host()
 elif sys.argv[1]=='guest':guest(sys.argv[2])
 else:raise SystemExit('unknown diagnostic command')
