
/workspaces/repository/kprog/fidelity/build-arm64-a-unary/instructions.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	2a2103e0 	mvn	w0, w1
   4:	2a2107e0 	mvn	w0, w1, lsl #1
   8:	2a210fe0 	mvn	w0, w1, lsl #3
   c:	2a217fe0 	mvn	w0, w1, lsl #31
  10:	2a6103e0 	mvn	w0, w1, lsr #0
  14:	2a6107e0 	mvn	w0, w1, lsr #1
  18:	2a610fe0 	mvn	w0, w1, lsr #3
  1c:	2a617fe0 	mvn	w0, w1, lsr #31
  20:	2aa103e0 	mvn	w0, w1, asr #0
  24:	2aa107e0 	mvn	w0, w1, asr #1
  28:	2aa10fe0 	mvn	w0, w1, asr #3
  2c:	2aa17fe0 	mvn	w0, w1, asr #31
  30:	2ae103e0 	mvn	w0, w1, ror #0
  34:	2ae107e0 	mvn	w0, w1, ror #1
  38:	2ae10fe0 	mvn	w0, w1, ror #3
  3c:	2ae17fe0 	mvn	w0, w1, ror #31
  40:	4b0103e0 	neg	w0, w1
  44:	4b0107e0 	neg	w0, w1, lsl #1
  48:	4b010fe0 	neg	w0, w1, lsl #3
  4c:	4b017fe0 	neg	w0, w1, lsl #31
  50:	4b4103e0 	neg	w0, w1, lsr #0
  54:	4b4107e0 	neg	w0, w1, lsr #1
  58:	4b410fe0 	neg	w0, w1, lsr #3
  5c:	4b417fe0 	neg	w0, w1, lsr #31
  60:	4b8103e0 	neg	w0, w1, asr #0
  64:	4b8107e0 	neg	w0, w1, asr #1
  68:	4b810fe0 	neg	w0, w1, asr #3
  6c:	4b817fe0 	neg	w0, w1, asr #31
  70:	aa2103e0 	mvn	x0, x1
  74:	aa2107e0 	mvn	x0, x1, lsl #1
  78:	aa210fe0 	mvn	x0, x1, lsl #3
  7c:	aa217fe0 	mvn	x0, x1, lsl #31
  80:	aa2183e0 	mvn	x0, x1, lsl #32
  84:	aa21ffe0 	mvn	x0, x1, lsl #63
  88:	aa6103e0 	mvn	x0, x1, lsr #0
  8c:	aa6107e0 	mvn	x0, x1, lsr #1
  90:	aa610fe0 	mvn	x0, x1, lsr #3
  94:	aa617fe0 	mvn	x0, x1, lsr #31
  98:	aa6183e0 	mvn	x0, x1, lsr #32
  9c:	aa61ffe0 	mvn	x0, x1, lsr #63
  a0:	aaa103e0 	mvn	x0, x1, asr #0
  a4:	aaa107e0 	mvn	x0, x1, asr #1
  a8:	aaa10fe0 	mvn	x0, x1, asr #3
  ac:	aaa17fe0 	mvn	x0, x1, asr #31
  b0:	aaa183e0 	mvn	x0, x1, asr #32
  b4:	aaa1ffe0 	mvn	x0, x1, asr #63
  b8:	aae103e0 	mvn	x0, x1, ror #0
  bc:	aae107e0 	mvn	x0, x1, ror #1
  c0:	aae10fe0 	mvn	x0, x1, ror #3
  c4:	aae17fe0 	mvn	x0, x1, ror #31
  c8:	aae183e0 	mvn	x0, x1, ror #32
  cc:	aae1ffe0 	mvn	x0, x1, ror #63
  d0:	cb0103e0 	neg	x0, x1
  d4:	cb0107e0 	neg	x0, x1, lsl #1
  d8:	cb010fe0 	neg	x0, x1, lsl #3
  dc:	cb017fe0 	neg	x0, x1, lsl #31
  e0:	cb0183e0 	neg	x0, x1, lsl #32
  e4:	cb01ffe0 	neg	x0, x1, lsl #63
  e8:	cb4103e0 	neg	x0, x1, lsr #0
  ec:	cb4107e0 	neg	x0, x1, lsr #1
  f0:	cb410fe0 	neg	x0, x1, lsr #3
  f4:	cb417fe0 	neg	x0, x1, lsr #31
  f8:	cb4183e0 	neg	x0, x1, lsr #32
  fc:	cb41ffe0 	neg	x0, x1, lsr #63
 100:	cb8103e0 	neg	x0, x1, asr #0
 104:	cb8107e0 	neg	x0, x1, asr #1
 108:	cb810fe0 	neg	x0, x1, asr #3
 10c:	cb817fe0 	neg	x0, x1, asr #31
 110:	cb8183e0 	neg	x0, x1, asr #32
 114:	cb81ffe0 	neg	x0, x1, asr #63
