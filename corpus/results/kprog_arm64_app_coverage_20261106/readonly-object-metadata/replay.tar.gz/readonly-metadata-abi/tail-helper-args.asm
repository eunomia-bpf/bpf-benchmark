
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/readonly-metadata-abi/tail-helper-args.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d2800028 	mov	x8, #0x1                   	// #1
   4:	d61f0100 	br	x8
