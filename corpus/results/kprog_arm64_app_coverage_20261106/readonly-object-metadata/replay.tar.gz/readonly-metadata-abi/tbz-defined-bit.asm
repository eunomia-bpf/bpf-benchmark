
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/readonly-metadata-abi/tbz-defined-bit.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f2800041 	movk	x1, #0x2
   4:	36000021 	tbz	w1, #0, 8 <entry+0x8>
   8:	52800040 	mov	w0, #0x2                   	// #2
   c:	d65f03c0 	ret
