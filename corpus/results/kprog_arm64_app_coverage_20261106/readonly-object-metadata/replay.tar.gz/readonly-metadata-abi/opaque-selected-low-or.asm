
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/readonly-metadata-abi/opaque-selected-low-or.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10083ff 	sub	sp, sp, #0x20
   4:	f90007e1 	str	x1, [sp, #8]
   8:	f9000fe2 	str	x2, [sp, #24]
   c:	910003e3 	mov	x3, sp
  10:	910043e4 	add	x4, sp, #0x10
  14:	f100001f 	cmp	x0, #0x0
  18:	9a840065 	csel	x5, x3, x4, eq	// eq = none
  1c:	b27d00a5 	orr	x5, x5, #0x8
  20:	f94000a0 	ldr	x0, [x5]
  24:	910083ff 	add	sp, sp, #0x20
  28:	d65f03c0 	ret
