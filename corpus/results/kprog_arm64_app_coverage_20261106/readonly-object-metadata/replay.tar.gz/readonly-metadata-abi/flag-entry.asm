
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/readonly-metadata-abi/flag-entry.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	54000040 	b.eq	8 <entry+0x8>  // b.none
   4:	52800040 	mov	w0, #0x2                   	// #2
   8:	d65f03c0 	ret
