
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/readonly-metadata-abi/memcpy-opaque-copy.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	a9be7bf3 	stp	x19, x30, [sp, #-32]!
   4:	f9000be1 	str	x1, [sp, #16]
   8:	910063e0 	add	x0, sp, #0x18
   c:	910043e1 	add	x1, sp, #0x10
  10:	d2800102 	mov	x2, #0x8                   	// #8
  14:	94000000 	bl	0 <memcpy>
			14: R_AARCH64_CALL26	memcpy
  18:	f9400fe0 	ldr	x0, [sp, #24]
  1c:	a8c27bf3 	ldp	x19, x30, [sp], #32
  20:	d65f03c0 	ret
