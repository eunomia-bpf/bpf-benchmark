
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/readonly-metadata-abi/partial-four-lanes.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f2800021 	movk	x1, #0x1
   4:	f2a00041 	movk	x1, #0x2, lsl #16
   8:	f2c00061 	movk	x1, #0x3, lsl #32
   c:	f2e00081 	movk	x1, #0x4, lsl #48
  10:	aa0103e0 	mov	x0, x1
  14:	d65f03c0 	ret
