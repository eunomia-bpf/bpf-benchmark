#include <linux/bpf.h>
#include <bpf_helpers.h>
SEC("xdp") int helper_ctx_preserved(struct xdp_md *ctx) { void *p=(void *)(long)ctx->data; void *e=(void *)(long)ctx->data_end; if (p+8>e) return 0; if (bpf_xdp_adjust_head(ctx,4)) return 0; p=(void *)(long)ctx->data; e=(void *)(long)ctx->data_end; if (p+8>e) return 0; *(__u64 *)p=37; return 2; }
char LICENSE[] SEC("license")="GPL";
