
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-alias-fixed-final/memset-opaque-suffix.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	a9be7bf3 	stp	x19, x30, [sp, #-32]!
   4:	f9000be1 	str	x1, [sp, #16]
   8:	910043e0 	add	x0, sp, #0x10
   c:	52800001 	mov	w1, #0x0                   	// #0
  10:	d2800022 	mov	x2, #0x1                   	// #1
  14:	94000000 	bl	0 <memset>
			14: R_AARCH64_CALL26	memset
  18:	f9400be0 	ldr	x0, [sp, #16]
  1c:	a8c27bf3 	ldp	x19, x30, [sp], #32
  20:	d65f03c0 	ret
