
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-alias-fixed-final/join-missing-write.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	b4000040 	cbz	x0, 8 <entry+0x8>
   4:	52800041 	mov	w1, #0x2                   	// #2
   8:	2a0103e0 	mov	w0, w1
   c:	d65f03c0 	ret
