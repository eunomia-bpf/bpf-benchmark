
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-alias-fixed-final/local-call-context.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f81f0ffe 	str	x30, [sp, #-16]!
   4:	52800041 	mov	w1, #0x2                   	// #2
   8:	94000003 	bl	14 <entry+0x14>
   c:	f84107fe 	ldr	x30, [sp], #16
  10:	d65f03c0 	ret
  14:	2a0103e0 	mov	w0, w1
  18:	d65f03c0 	ret
