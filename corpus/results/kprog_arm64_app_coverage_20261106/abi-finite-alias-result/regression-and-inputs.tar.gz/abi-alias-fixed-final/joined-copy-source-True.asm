
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-alias-fixed-final/joined-copy-source-True.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	a9bc7bf3 	stp	x19, x30, [sp, #-64]!
   4:	f9000be1 	str	x1, [sp, #16]
   8:	528000e4 	mov	w4, #0x7                   	// #7
   c:	f9000be4 	str	x4, [sp, #16]
  10:	aa0003e2 	mov	x2, x0
  14:	910043e3 	add	x3, sp, #0x10
  18:	f100001f 	cmp	x0, #0x0
  1c:	9a820062 	csel	x2, x3, x2, eq	// eq = none
  20:	910083e0 	add	x0, sp, #0x20
  24:	d2800101 	mov	x1, #0x8                   	// #8
  28:	94000000 	bl	0 <bpf_probe_read_kernel>
			28: R_AARCH64_CALL26	bpf_probe_read_kernel
  2c:	f94013e0 	ldr	x0, [sp, #32]
  30:	a8c47bf3 	ldp	x19, x30, [sp], #64
  34:	d65f03c0 	ret
