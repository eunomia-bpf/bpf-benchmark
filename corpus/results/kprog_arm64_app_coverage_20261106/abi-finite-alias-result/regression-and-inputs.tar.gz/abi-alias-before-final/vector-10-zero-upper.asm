
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-alias-before-final/vector-10-zero-upper.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	52800041 	mov	w1, #0x2                   	// #2
   4:	1e27002a 	fmov	s10, w1
   8:	9e660140 	fmov	x0, d10
   c:	d65f03c0 	ret
