
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-alias-before-final/opaque-reload.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f81f0fe1 	str	x1, [sp, #-16]!
   4:	f84107e0 	ldr	x0, [sp], #16
   8:	d65f03c0 	ret
