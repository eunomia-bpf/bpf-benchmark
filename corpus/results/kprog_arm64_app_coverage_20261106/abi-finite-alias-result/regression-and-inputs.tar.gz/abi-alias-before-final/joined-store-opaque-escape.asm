
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-alias-before-final/joined-store-opaque-escape.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10083ff 	sub	sp, sp, #0x20
   4:	910003e3 	mov	x3, sp
   8:	f100001f 	cmp	x0, #0x0
   c:	9a800065 	csel	x5, x3, x0, eq	// eq = none
  10:	f90000a1 	str	x1, [x5]
  14:	52800040 	mov	w0, #0x2                   	// #2
  18:	910083ff 	add	sp, sp, #0x20
  1c:	d65f03c0 	ret
