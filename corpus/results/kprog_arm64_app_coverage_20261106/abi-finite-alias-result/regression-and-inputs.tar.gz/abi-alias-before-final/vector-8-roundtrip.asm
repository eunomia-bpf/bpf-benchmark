
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-alias-before-final/vector-8-roundtrip.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d2800041 	mov	x1, #0x2                   	// #2
   4:	9e670028 	fmov	d8, x1
   8:	9e660100 	fmov	x0, d8
   c:	d65f03c0 	ret
