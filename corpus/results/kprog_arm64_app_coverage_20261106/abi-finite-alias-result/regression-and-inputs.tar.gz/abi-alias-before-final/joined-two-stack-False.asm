
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-alias-before-final/joined-two-stack-False.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10083ff 	sub	sp, sp, #0x20
   4:	f9000fe1 	str	x1, [sp, #24]
   8:	f90003e1 	str	x1, [sp]
   c:	f90007e1 	str	x1, [sp, #8]
  10:	528000e2 	mov	w2, #0x7                   	// #7
  14:	f90003e2 	str	x2, [sp]
  18:	910003e3 	mov	x3, sp
  1c:	910023e4 	add	x4, sp, #0x8
  20:	f100001f 	cmp	x0, #0x0
  24:	9a840065 	csel	x5, x3, x4, eq	// eq = none
  28:	f94000a0 	ldr	x0, [x5]
  2c:	910083ff 	add	sp, sp, #0x20
  30:	d65f03c0 	ret
