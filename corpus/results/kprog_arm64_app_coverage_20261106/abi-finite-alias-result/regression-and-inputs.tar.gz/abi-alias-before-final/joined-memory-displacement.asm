
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-alias-before-final/joined-memory-displacement.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10083ff 	sub	sp, sp, #0x20
   4:	f9000fe1 	str	x1, [sp, #24]
   8:	f90007e1 	str	x1, [sp, #8]
   c:	528000e2 	mov	w2, #0x7                   	// #7
  10:	f90007e2 	str	x2, [sp, #8]
  14:	910003e3 	mov	x3, sp
  18:	f100001f 	cmp	x0, #0x0
  1c:	9a800065 	csel	x5, x3, x0, eq	// eq = none
  20:	f94004a0 	ldr	x0, [x5, #8]
  24:	910083ff 	add	sp, sp, #0x20
  28:	d65f03c0 	ret
