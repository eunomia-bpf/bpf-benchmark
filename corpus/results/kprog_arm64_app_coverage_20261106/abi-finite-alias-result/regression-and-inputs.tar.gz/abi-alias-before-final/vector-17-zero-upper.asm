
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-alias-before-final/vector-17-zero-upper.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	52800041 	mov	w1, #0x2                   	// #2
   4:	1e270031 	fmov	s17, w1
   8:	9e660220 	fmov	x0, d17
   c:	d65f03c0 	ret
