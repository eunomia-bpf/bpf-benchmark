
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-alias-before-final/joined-external-False.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10083ff 	sub	sp, sp, #0x20
   4:	f9000fe1 	str	x1, [sp, #24]
   8:	f90003e1 	str	x1, [sp]
   c:	910003e3 	mov	x3, sp
  10:	f100001f 	cmp	x0, #0x0
  14:	9a800065 	csel	x5, x3, x0, eq	// eq = none
  18:	f94000a0 	ldr	x0, [x5]
  1c:	910083ff 	add	sp, sp, #0x20
  20:	d65f03c0 	ret
