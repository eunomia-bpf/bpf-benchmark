
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-alias-before-final/vector-7-zero-upper.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	52800041 	mov	w1, #0x2                   	// #2
   4:	1e270027 	fmov	s7, w1
   8:	9e6600e0 	fmov	x0, d7
   c:	d65f03c0 	ret
