
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-alias-before-final/vector-21-zero-upper.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	52800041 	mov	w1, #0x2                   	// #2
   4:	1e270035 	fmov	s21, w1
   8:	9e6602a0 	fmov	x0, d21
   c:	d65f03c0 	ret
