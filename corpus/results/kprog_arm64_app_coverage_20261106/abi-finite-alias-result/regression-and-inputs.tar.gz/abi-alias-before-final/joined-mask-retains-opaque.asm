
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-alias-before-final/joined-mask-retains-opaque.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10083ff 	sub	sp, sp, #0x20
   4:	f90003e1 	str	x1, [sp]
   8:	910003e3 	mov	x3, sp
   c:	f100001f 	cmp	x0, #0x0
  10:	9a800065 	csel	x5, x3, x0, eq	// eq = none
  14:	927df0a5 	and	x5, x5, #0xfffffffffffffff8
  18:	f94000a0 	ldr	x0, [x5]
  1c:	910083ff 	add	sp, sp, #0x20
  20:	d65f03c0 	ret
