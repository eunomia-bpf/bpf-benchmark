extern char addr4lpm_maps;
extern char addr6lpm_maps;
extern char argfilter_maps;
extern char filter_map;
extern char heap_ro_zero;
extern char process_call_heap;
extern char retprobe_map;
extern char retuprobe_calls;
extern char string_maps_0;
extern char string_maps_1;
extern char string_maps_10;
extern char string_maps_2;
extern char string_maps_3;
extern char string_maps_4;
extern char string_maps_5;
extern char string_maps_6;
extern char string_maps_7;
extern char string_maps_8;
extern char string_maps_9;
extern char string_maps_heap;
extern char string_postfix_maps;
extern char string_postfix_maps_heap;
extern char string_prefix_maps;
extern char string_prefix_maps_heap;
extern char substring_map;
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_RETURN_CASES \
	case 0x1d0ULL: __a64_lr = 0; goto arm64_l_1d0; \
	case 0x258ULL: __a64_lr = 0; goto arm64_l_258; \
	case 0x298ULL: __a64_lr = 0; goto arm64_l_298; \
	case 0x2fcULL: __a64_lr = 0; goto arm64_l_2fc; \
	case 0x304ULL: __a64_lr = 0; goto arm64_l_304; \
	case 0x318ULL: __a64_lr = 0; goto arm64_l_318; \
	case 0x320ULL: __a64_lr = 0; goto arm64_l_320; \
	case 0x32cULL: __a64_lr = 0; goto arm64_l_32c; \
	case 0x33cULL: __a64_lr = 0; goto arm64_l_33c; \
	case 0x4f4ULL: __a64_lr = 0; goto arm64_l_4f4; \
	case 0x51cULL: __a64_lr = 0; goto arm64_l_51c; \
	case 0x538ULL: __a64_lr = 0; goto arm64_l_538; \
	case 0x554ULL: __a64_lr = 0; goto arm64_l_554; \
	case 0x5d0ULL: __a64_lr = 0; goto arm64_l_5d0; \
	case 0x600ULL: __a64_lr = 0; goto arm64_l_600; \
	case 0x610ULL: __a64_lr = 0; goto arm64_l_610; \
	case 0x990ULL: __a64_lr = 0; goto arm64_l_990; \
	case 0xa50ULL: __a64_lr = 0; goto arm64_l_a50; \
	case 0xab0ULL: __a64_lr = 0; goto arm64_l_ab0; \
	case 0xafcULL: __a64_lr = 0; goto arm64_l_afc; \
	case 0xb3cULL: __a64_lr = 0; goto arm64_l_b3c; \
	case 0xb6cULL: __a64_lr = 0; goto arm64_l_b6c; \
	case 0xb7cULL: __a64_lr = 0; goto arm64_l_b7c; \
	case 0xbb8ULL: __a64_lr = 0; goto arm64_l_bb8; \
	case 0xbe8ULL: __a64_lr = 0; goto arm64_l_be8; \
	case 0xbf8ULL: __a64_lr = 0; goto arm64_l_bf8; \
	case 0xc68ULL: __a64_lr = 0; goto arm64_l_c68; \
	case 0xc90ULL: __a64_lr = 0; goto arm64_l_c90; \
	case 0xc9cULL: __a64_lr = 0; goto arm64_l_c9c; \
	case 0xcacULL: __a64_lr = 0; goto arm64_l_cac; \
	case 0xd1cULL: __a64_lr = 0; goto arm64_l_d1c; \
	case 0xd4cULL: __a64_lr = 0; goto arm64_l_d4c; \
	case 0xd5cULL: __a64_lr = 0; goto arm64_l_d5c;
#include "/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/label-all/simulator/arm64_sim_local_bpf.h"

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} addr4lpm_maps_0 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} addr6lpm_maps_1 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} argfilter_maps_2 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} filter_map_3 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} heap_ro_zero_4 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} process_call_heap_5 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} retprobe_map_6 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} retuprobe_calls_7 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_0_8 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_1_9 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_10_10 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_2_11 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_3_12 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_4_13 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_5_14 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_6_15 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_7_16 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_8_17 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_9_18 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_maps_heap_19 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_postfix_maps_20 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_postfix_maps_heap_21 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_prefix_maps_22 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} string_prefix_maps_heap_23 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} substring_map_24 SEC(".maps");

SEC("xdp")
int tetragon_bpf_generic_retuprobe_v61_generic_retuprobe_filter_arg_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
arm64_l_0:
	/* 0x0: sub sp, sp, #0x70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_4:
	/* 0x4: str x29, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_8:
	/* 0x8: stp x30, x25, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_c:
	/* 0xc: stp x24, x23, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_10:
	/* 0x10: stp x22, x21, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_14:
	/* 0x14: stp x20, x19, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_18:
	/* 0x18: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c:
	/* 0x1c: str wzr, [sp, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_20:
	/* 0x20: adrp x0, 0 <process_call_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_5));
arm64_l_24:
	/* 0x24: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28:
	/* 0x28: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c:
	/* 0x2c: add x9, sp, #0x2c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_30:
	/* 0x30: add x1, sp, #0x2c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_34:
	/* 0x34: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_38:
	/* 0x38: cbz x0, 394 <generic_retuprobe_filter_arg+0x394> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x38, 0x394, arm64_l_394);
arm64_l_3c:
	/* 0x3c: mov w8, #0x5ec1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24257ULL);
arm64_l_40:
	/* 0x40: mov x20, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_44:
	/* 0x44: add x22, x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_48:
	/* 0x48: mov w8, #0x5ef8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24312ULL);
arm64_l_4c:
	/* 0x4c: add x1, x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X1, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_50:
	/* 0x50: adrp x0, 0 <filter_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&filter_map_3));
arm64_l_54:
	/* 0x54: ldur w23, [x22, #63] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 63ULL);
arm64_l_58:
	/* 0x58: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_5c:
	/* 0x5c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_60:
	/* 0x60: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_64:
	/* 0x64: cbz x0, 378 <generic_retuprobe_filter_arg+0x378> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x64, 0x378, arm64_l_378);
arm64_l_68:
	/* 0x68: ldrb w8, [x22, #31] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 31ULL);
arm64_l_6c:
	/* 0x6c: cbz w8, 378 <generic_retuprobe_filter_arg+0x378> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x6c, 0x378, arm64_l_378);
arm64_l_70:
	/* 0x70: and x8, x23, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_74:
	/* 0x74: mov w10, #0x5ec1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24257ULL);
arm64_l_78:
	/* 0x78: add x9, x20, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_7c:
	/* 0x7c: ldrb w9, [x9, x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X10, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_80:
	/* 0x80: cbz w9, c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x80, 0xc4, arm64_l_c4);
arm64_l_84:
	/* 0x84: lsl w8, w8, #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_88:
	/* 0x88: mov x21, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_8c:
	/* 0x8c: add x8, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_90:
	/* 0x90: ldr w9, [x8, x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X0, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_94:
	/* 0x94: add x8, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_98:
	/* 0x98: add x25, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_9c:
	/* 0x9c: and x8, x25, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_a0:
	/* 0xa0: add x29, x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X29, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_a4:
	/* 0xa4: str x8, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_a8:
	/* 0xa8: ldr w8, [x29] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ac:
	/* 0xac: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_b0:
	/* 0xb0: b.cs 10c <generic_retuprobe_filter_arg+0x10c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xb0, 0x10c, arm64_l_10c);
arm64_l_b4:
	/* 0xb4: ldr x8, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_b8:
	/* 0xb8: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_bc:
	/* 0xbc: b.eq 378 <generic_retuprobe_filter_arg+0x378> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xbc, 0x378, arm64_l_378);
arm64_l_c0:
	/* 0xc0: cbnz w8, 354 <generic_retuprobe_filter_arg+0x354> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0xc0, 0x354, arm64_l_354);
arm64_l_c4:
	/* 0xc4: cmp w23, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_c8:
	/* 0xc8: b.gt e4 <generic_retuprobe_filter_arg+0xe4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xc8, 0xe4, arm64_l_e4);
arm64_l_cc:
	/* 0xcc: cmn w23, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d0:
	/* 0xd0: b.eq 3b4 <generic_retuprobe_filter_arg+0x3b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd0, 0x3b4, arm64_l_3b4);
arm64_l_d4:
	/* 0xd4: cbz w23, 3c4 <generic_retuprobe_filter_arg+0x3c4> */
	ARM64_SIM_A64_CBZ(ARM64_X23, 0xd4, 0x3c4, arm64_l_3c4);
arm64_l_d8:
	/* 0xd8: cmp w23, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_dc:
	/* 0xdc: b.eq 3d4 <generic_retuprobe_filter_arg+0x3d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xdc, 0x3d4, arm64_l_3d4);
arm64_l_e0:
	/* 0xe0: b fc <generic_retuprobe_filter_arg+0xfc> */
	ARM64_SIM_A64_JMP(0xe0, 0xfc, arm64_l_fc);
arm64_l_e4:
	/* 0xe4: cmp w23, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_e8:
	/* 0xe8: b.eq 3e4 <generic_retuprobe_filter_arg+0x3e4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe8, 0x3e4, arm64_l_3e4);
arm64_l_ec:
	/* 0xec: cmp w23, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_f0:
	/* 0xf0: b.eq 3f4 <generic_retuprobe_filter_arg+0x3f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf0, 0x3f4, arm64_l_3f4);
arm64_l_f4:
	/* 0xf4: cmp w23, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_f8:
	/* 0xf8: b.eq 404 <generic_retuprobe_filter_arg+0x404> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf8, 0x404, arm64_l_404);
arm64_l_fc:
	/* 0xfc: cmp w23, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_100:
	/* 0x100: b.gt 430 <generic_retuprobe_filter_arg+0x430> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x100, 0x430, arm64_l_430);
arm64_l_104:
	/* 0x104: add w8, w23, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_108:
	/* 0x108: b 410 <generic_retuprobe_filter_arg+0x410> */
	ARM64_SIM_A64_JMP(0x108, 0x410, arm64_l_410);
arm64_l_10c:
	/* 0x10c: mov w24, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_110:
	/* 0x110: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_114:
	/* 0x114: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_118:
	/* 0x118: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11c:
	/* 0x11c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_120:
	/* 0x120: ldr w8, [x29, x24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X24, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_124:
	/* 0x124: tst w8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_128:
	/* 0x128: b.eq b4 <generic_retuprobe_filter_arg+0xb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x128, 0xb4, arm64_l_b4);
arm64_l_12c:
	/* 0x12c: add w8, w25, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_130:
	/* 0x130: and x8, x8, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_134:
	/* 0x134: add x0, x21, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_138:
	/* 0x138: ldr w9, [x0, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_13c:
	/* 0x13c: cmp w9, #0x23 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 35ULL);
arm64_l_140:
	/* 0x140: b.eq c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x140, 0xc4, arm64_l_c4);
arm64_l_144:
	/* 0x144: ldr w8, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_148:
	/* 0x148: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_14c:
	/* 0x14c: b.hi c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x14c, 0xc4, arm64_l_c4);
arm64_l_150:
	/* 0x150: add x10, x20, x8, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_154:
	/* 0x154: mov w11, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_158:
	/* 0x158: ldr w10, [x10, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_15c:
	/* 0x15c: cbnz w10, c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_CBNZ(ARM64_X10, 0x15c, 0xc4, arm64_l_c4);
arm64_l_160:
	/* 0x160: add x8, x20, x8, lsl #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 3), 0);
arm64_l_164:
	/* 0x164: ldr x8, [x8, #24184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24184ULL);
arm64_l_168:
	/* 0x168: and x8, x8, #0x7ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2047ULL);
arm64_l_16c:
	/* 0x16c: add x8, x20, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_170:
	/* 0x170: add x1, x8, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_174:
	/* 0x174: ldr w8, [x0, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_178:
	/* 0x178: cmp w8, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_17c:
	/* 0x17c: b.le 1a0 <generic_retuprobe_filter_arg+0x1a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x17c, 0x1a0, arm64_l_1a0);
arm64_l_180:
	/* 0x180: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_184:
	/* 0x184: b.gt 1d4 <generic_retuprobe_filter_arg+0x1d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x184, 0x1d4, arm64_l_1d4);
arm64_l_188:
	/* 0x188: sub w10, w8, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_18c:
	/* 0x18c: cmp w10, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_190:
	/* 0x190: b.cc 218 <generic_retuprobe_filter_arg+0x218> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x190, 0x218, arm64_l_218);
arm64_l_194:
	/* 0x194: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_198:
	/* 0x198: b.eq 300 <generic_retuprobe_filter_arg+0x300> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x198, 0x300, arm64_l_300);
arm64_l_19c:
	/* 0x19c: b 344 <generic_retuprobe_filter_arg+0x344> */
	ARM64_SIM_A64_JMP(0x19c, 0x344, arm64_l_344);
arm64_l_1a0:
	/* 0x1a0: cmp w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_1a4:
	/* 0x1a4: b.le 1f8 <generic_retuprobe_filter_arg+0x1f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1a4, 0x1f8, arm64_l_1f8);
arm64_l_1a8:
	/* 0x1a8: sub w10, w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1ac:
	/* 0x1ac: cmp w10, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1b0:
	/* 0x1b0: b.cc 218 <generic_retuprobe_filter_arg+0x218> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1b0, 0x218, arm64_l_218);
arm64_l_1b4:
	/* 0x1b4: sub w9, w8, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_1b8:
	/* 0x1b8: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1bc:
	/* 0x1bc: b.cc 300 <generic_retuprobe_filter_arg+0x300> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1bc, 0x300, arm64_l_300);
arm64_l_1c0:
	/* 0x1c0: cmp w8, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1c4:
	/* 0x1c4: b.ne 344 <generic_retuprobe_filter_arg+0x344> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1c4, 0x344, arm64_l_344);
arm64_l_1c8:
	/* 0x1c8: add x1, x1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1cc:
	/* 0x1cc: bl 478 <filter_file_buf> */
	ARM64_SIM_A64_CALL(arm64_l_478, 0x1d0ULL);
arm64_l_1d0:
	/* 0x1d0: b 340 <generic_retuprobe_filter_arg+0x340> */
	ARM64_SIM_A64_JMP(0x1d0, 0x340, arm64_l_340);
arm64_l_1d4:
	/* 0x1d4: cmp w8, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1d8:
	/* 0x1d8: b.gt 2e8 <generic_retuprobe_filter_arg+0x2e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1d8, 0x2e8, arm64_l_2e8);
arm64_l_1dc:
	/* 0x1dc: sub w9, w8, #0x26 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 38ULL);
arm64_l_1e0:
	/* 0x1e0: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1e4:
	/* 0x1e4: b.cc 29c <generic_retuprobe_filter_arg+0x29c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1e4, 0x29c, arm64_l_29c);
arm64_l_1e8:
	/* 0x1e8: sub w8, w8, #0x28 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_1ec:
	/* 0x1ec: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1f0:
	/* 0x1f0: b.cc 294 <generic_retuprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1f0, 0x294, arm64_l_294);
arm64_l_1f4:
	/* 0x1f4: b 344 <generic_retuprobe_filter_arg+0x344> */
	ARM64_SIM_A64_JMP(0x1f4, 0x344, arm64_l_344);
arm64_l_1f8:
	/* 0x1f8: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1fc:
	/* 0x1fc: b.gt 27c <generic_retuprobe_filter_arg+0x27c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1fc, 0x27c, arm64_l_27c);
arm64_l_200:
	/* 0x200: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_204:
	/* 0x204: b.eq 218 <generic_retuprobe_filter_arg+0x218> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x204, 0x218, arm64_l_218);
arm64_l_208:
	/* 0x208: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_20c:
	/* 0x20c: b.eq 324 <generic_retuprobe_filter_arg+0x324> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x20c, 0x324, arm64_l_324);
arm64_l_210:
	/* 0x210: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_214:
	/* 0x214: b.ne 344 <generic_retuprobe_filter_arg+0x344> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x214, 0x344, arm64_l_344);
arm64_l_218:
	/* 0x218: cmp w8, #0xb */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 11ULL);
arm64_l_21c:
	/* 0x21c: b.le 25c <generic_retuprobe_filter_arg+0x25c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x21c, 0x25c, arm64_l_25c);
arm64_l_220:
	/* 0x220: cmp w8, #0x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 36ULL);
arm64_l_224:
	/* 0x224: b.hi 308 <generic_retuprobe_filter_arg+0x308> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x224, 0x308, arm64_l_308);
arm64_l_228:
	/* 0x228: mov w11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_22c:
	/* 0x22c: lsl x10, x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_230:
	/* 0x230: tst x10, #0x1e00000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 128849018880ULL);
arm64_l_234:
	/* 0x234: b.ne 2a4 <generic_retuprobe_filter_arg+0x2a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x234, 0x2a4, arm64_l_2a4);
arm64_l_238:
	/* 0x238: lsl x9, x11, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_23c:
	/* 0x23c: tst x9, #0x60000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1610612736ULL);
arm64_l_240:
	/* 0x240: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_244:
	/* 0x244: b.ne 31c <generic_retuprobe_filter_arg+0x31c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x244, 0x31c, arm64_l_31c);
arm64_l_248:
	/* 0x248: lsl x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_24c:
	/* 0x24c: tst x9, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_250:
	/* 0x250: b.eq 308 <generic_retuprobe_filter_arg+0x308> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x250, 0x308, arm64_l_308);
arm64_l_254:
	/* 0x254: bl 59c <filter_8ty> */
	ARM64_SIM_A64_CALL(arm64_l_59c, 0x258ULL);
arm64_l_258:
	/* 0x258: b 340 <generic_retuprobe_filter_arg+0x340> */
	ARM64_SIM_A64_JMP(0x258, 0x340, arm64_l_340);
arm64_l_25c:
	/* 0x25c: sub w9, w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_260:
	/* 0x260: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_264:
	/* 0x264: b.cc 338 <generic_retuprobe_filter_arg+0x338> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x264, 0x338, arm64_l_338);
arm64_l_268:
	/* 0x268: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_26c:
	/* 0x26c: b.eq 314 <generic_retuprobe_filter_arg+0x314> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x26c, 0x314, arm64_l_314);
arm64_l_270:
	/* 0x270: cmp w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_274:
	/* 0x274: b.eq 314 <generic_retuprobe_filter_arg+0x314> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x274, 0x314, arm64_l_314);
arm64_l_278:
	/* 0x278: b 344 <generic_retuprobe_filter_arg+0x344> */
	ARM64_SIM_A64_JMP(0x278, 0x344, arm64_l_344);
arm64_l_27c:
	/* 0x27c: cmp w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_280:
	/* 0x280: b.eq 294 <generic_retuprobe_filter_arg+0x294> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x280, 0x294, arm64_l_294);
arm64_l_284:
	/* 0x284: cmp w8, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_288:
	/* 0x288: b.eq 29c <generic_retuprobe_filter_arg+0x29c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x288, 0x29c, arm64_l_29c);
arm64_l_28c:
	/* 0x28c: cmp w8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_290:
	/* 0x290: b.ne 344 <generic_retuprobe_filter_arg+0x344> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x290, 0x344, arm64_l_344);
arm64_l_294:
	/* 0x294: bl 618 <filter_inet> */
	ARM64_SIM_A64_CALL(arm64_l_618, 0x298ULL);
arm64_l_298:
	/* 0x298: b 340 <generic_retuprobe_filter_arg+0x340> */
	ARM64_SIM_A64_JMP(0x298, 0x340, arm64_l_340);
arm64_l_29c:
	/* 0x29c: mov w2, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2a0:
	/* 0x2a0: b 328 <generic_retuprobe_filter_arg+0x328> */
	ARM64_SIM_A64_JMP(0x2a0, 0x328, arm64_l_328);
arm64_l_2a4:
	/* 0x2a4: cmp w9, #0x1e */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 30ULL);
arm64_l_2a8:
	/* 0x2a8: b.ne 338 <generic_retuprobe_filter_arg+0x338> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2a8, 0x338, arm64_l_338);
arm64_l_2ac:
	/* 0x2ac: ldr w8, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2b0:
	/* 0x2b0: mov w10, #0x5ea0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_2b4:
	/* 0x2b4: and x8, x8, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_2b8:
	/* 0x2b8: add x9, x20, x8, lsl #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_2bc:
	/* 0x2bc: ldr w9, [x9, x10] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X10, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c0:
	/* 0x2c0: cbnz w9, c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_CBNZ(ARM64_X9, 0x2c0, 0xc4, arm64_l_c4);
arm64_l_2c4:
	/* 0x2c4: add x8, x20, x8, lsl #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 3), 0);
arm64_l_2c8:
	/* 0x2c8: ldr x9, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2cc:
	/* 0x2cc: ldr x8, [x8, #24184] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24184ULL);
arm64_l_2d0:
	/* 0x2d0: and x8, x8, #0x7ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2047ULL);
arm64_l_2d4:
	/* 0x2d4: add x8, x20, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2d8:
	/* 0x2d8: ldr x8, [x8, #144] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2dc:
	/* 0x2dc: bics xzr, x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_BIC_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2e0:
	/* 0x2e0: cset w0, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2e4:
	/* 0x2e4: b 340 <generic_retuprobe_filter_arg+0x340> */
	ARM64_SIM_A64_JMP(0x2e4, 0x340, arm64_l_340);
arm64_l_2e8:
	/* 0x2e8: cmp w8, #0x2a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 42ULL);
arm64_l_2ec:
	/* 0x2ec: b.eq 300 <generic_retuprobe_filter_arg+0x300> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2ec, 0x300, arm64_l_300);
arm64_l_2f0:
	/* 0x2f0: cmp w8, #0x2c */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_2f4:
	/* 0x2f4: b.ne 344 <generic_retuprobe_filter_arg+0x344> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2f4, 0x344, arm64_l_344);
arm64_l_2f8:
	/* 0x2f8: bl a18 <filter_sockaddr_un> */
	ARM64_SIM_A64_CALL(arm64_l_a18, 0x2fcULL);
arm64_l_2fc:
	/* 0x2fc: b 340 <generic_retuprobe_filter_arg+0x340> */
	ARM64_SIM_A64_JMP(0x2fc, 0x340, arm64_l_340);
arm64_l_300:
	/* 0x300: bl 478 <filter_file_buf> */
	ARM64_SIM_A64_CALL(arm64_l_478, 0x304ULL);
arm64_l_304:
	/* 0x304: b 340 <generic_retuprobe_filter_arg+0x340> */
	ARM64_SIM_A64_JMP(0x304, 0x340, arm64_l_340);
arm64_l_308:
	/* 0x308: sub w9, w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_30c:
	/* 0x30c: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_310:
	/* 0x310: b.cs 330 <generic_retuprobe_filter_arg+0x330> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x310, 0x330, arm64_l_330);
arm64_l_314:
	/* 0x314: bl b08 <filter_32ty> */
	ARM64_SIM_A64_CALL(arm64_l_b08, 0x318ULL);
arm64_l_318:
	/* 0x318: b 340 <generic_retuprobe_filter_arg+0x340> */
	ARM64_SIM_A64_JMP(0x318, 0x340, arm64_l_340);
arm64_l_31c:
	/* 0x31c: bl b84 <filter_16ty> */
	ARM64_SIM_A64_CALL(arm64_l_b84, 0x320ULL);
arm64_l_320:
	/* 0x320: b 340 <generic_retuprobe_filter_arg+0x340> */
	ARM64_SIM_A64_JMP(0x320, 0x340, arm64_l_340);
arm64_l_324:
	/* 0x324: mov w2, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_328:
	/* 0x328: bl c00 <filter_char_buf> */
	ARM64_SIM_A64_CALL(arm64_l_c00, 0x32cULL);
arm64_l_32c:
	/* 0x32c: b 340 <generic_retuprobe_filter_arg+0x340> */
	ARM64_SIM_A64_JMP(0x32c, 0x340, arm64_l_340);
arm64_l_330:
	/* 0x330: cmp w8, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_334:
	/* 0x334: b.ne 344 <generic_retuprobe_filter_arg+0x344> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x334, 0x344, arm64_l_344);
arm64_l_338:
	/* 0x338: bl ce8 <filter_64ty> */
	ARM64_SIM_A64_CALL(arm64_l_ce8, 0x33cULL);
arm64_l_33c:
	/* 0x33c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_340:
	/* 0x340: cbz x0, c4 <generic_retuprobe_filter_arg+0xc4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x340, 0xc4, arm64_l_c4);
arm64_l_344:
	/* 0x344: add x24, x24, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_348:
	/* 0x348: cmp x24, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_34c:
	/* 0x34c: b.ne 120 <generic_retuprobe_filter_arg+0x120> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x34c, 0x120, arm64_l_120);
arm64_l_350:
	/* 0x350: b b4 <generic_retuprobe_filter_arg+0xb4> */
	ARM64_SIM_A64_JMP(0x350, 0xb4, arm64_l_b4);
arm64_l_354:
	/* 0x354: ldr x8, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_358:
	/* 0x358: adrp x1, 0 <retuprobe_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&retuprobe_calls_7));
arm64_l_35c:
	/* 0x35c: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_360:
	/* 0x360: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_364:
	/* 0x364: stur w8, [x22, #67] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 67ULL);
arm64_l_368:
	/* 0x368: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_36c:
	/* 0x36c: mov w2, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_370:
	/* 0x370: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_374:
	/* 0x374: blr x9 */
	ARM64_SIM_BPF_CALL_bpf_tail_call();
arm64_l_378:
	/* 0x378: adrp x1, 0 <retuprobe_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&retuprobe_calls_7));
arm64_l_37c:
	/* 0x37c: mov w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_380:
	/* 0x380: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_384:
	/* 0x384: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_388:
	/* 0x388: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_38c:
	/* 0x38c: mov w2, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_390:
	/* 0x390: blr x9 */
	ARM64_SIM_BPF_CALL_bpf_tail_call();
arm64_l_394:
	/* 0x394: ldp x20, x19, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_398:
	/* 0x398: mov w0, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_39c:
	/* 0x39c: ldr x29, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_3a0:
	/* 0x3a0: ldp x22, x21, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_3a4:
	/* 0x3a4: ldp x24, x23, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_3a8:
	/* 0x3a8: ldp x30, x25, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_3ac:
	/* 0x3ac: add sp, sp, #0x70 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_3b0:
	/* 0x3b0: b 2fe8 <__native_link_arm64_ret_trampoline> */
	ARM64_SIM_A64_JMP(0x3b0, 0x2fe8, arm64_l_2fe8);
arm64_l_3b4:
	/* 0x3b4: ldrb w8, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3b8:
	/* 0x3b8: cbz w8, 3c4 <generic_retuprobe_filter_arg+0x3c4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x3b8, 0x3c4, arm64_l_3c4);
arm64_l_3bc:
	/* 0x3bc: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_3c0:
	/* 0x3c0: b 410 <generic_retuprobe_filter_arg+0x410> */
	ARM64_SIM_A64_JMP(0x3c0, 0x410, arm64_l_410);
arm64_l_3c4:
	/* 0x3c4: ldrb w8, [x22, #1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1ULL);
arm64_l_3c8:
	/* 0x3c8: cbz w8, 3d4 <generic_retuprobe_filter_arg+0x3d4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x3c8, 0x3d4, arm64_l_3d4);
arm64_l_3cc:
	/* 0x3cc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3d0:
	/* 0x3d0: b 410 <generic_retuprobe_filter_arg+0x410> */
	ARM64_SIM_A64_JMP(0x3d0, 0x410, arm64_l_410);
arm64_l_3d4:
	/* 0x3d4: ldrb w8, [x22, #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_3d8:
	/* 0x3d8: cbz w8, 3e4 <generic_retuprobe_filter_arg+0x3e4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x3d8, 0x3e4, arm64_l_3e4);
arm64_l_3dc:
	/* 0x3dc: mov w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_3e0:
	/* 0x3e0: b 410 <generic_retuprobe_filter_arg+0x410> */
	ARM64_SIM_A64_JMP(0x3e0, 0x410, arm64_l_410);
arm64_l_3e4:
	/* 0x3e4: ldrb w8, [x22, #3] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3ULL);
arm64_l_3e8:
	/* 0x3e8: cbz w8, 3f4 <generic_retuprobe_filter_arg+0x3f4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x3e8, 0x3f4, arm64_l_3f4);
arm64_l_3ec:
	/* 0x3ec: mov w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_3f0:
	/* 0x3f0: b 410 <generic_retuprobe_filter_arg+0x410> */
	ARM64_SIM_A64_JMP(0x3f0, 0x410, arm64_l_410);
arm64_l_3f4:
	/* 0x3f4: ldrb w8, [x22, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_3f8:
	/* 0x3f8: cbz w8, 404 <generic_retuprobe_filter_arg+0x404> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x3f8, 0x404, arm64_l_404);
arm64_l_3fc:
	/* 0x3fc: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_400:
	/* 0x400: b 410 <generic_retuprobe_filter_arg+0x410> */
	ARM64_SIM_A64_JMP(0x400, 0x410, arm64_l_410);
arm64_l_404:
	/* 0x404: ldrb w8, [x22, #5] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_408:
	/* 0x408: cbz w8, 430 <generic_retuprobe_filter_arg+0x430> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x408, 0x430, arm64_l_430);
arm64_l_40c:
	/* 0x40c: mov w8, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_410:
	/* 0x410: stur w8, [x22, #63] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 63ULL);
arm64_l_414:
	/* 0x414: adrp x1, 0 <retuprobe_calls> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&retuprobe_calls_7));
arm64_l_418:
	/* 0x418: mov w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_41c:
	/* 0x41c: mov w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_420:
	/* 0x420: ldr x1, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_424:
	/* 0x424: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_428:
	/* 0x428: mov w2, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_42c:
	/* 0x42c: blr x9 */
	ARM64_SIM_BPF_CALL_bpf_tail_call();
arm64_l_430:
	/* 0x430: ldr x19, [x20, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_434:
	/* 0x434: mov w8, #0xe */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_438:
	/* 0x438: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid();
arm64_l_43c:
	/* 0x43c: stp x19, x0, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_440:
	/* 0x440: adrp x19, 0 <retprobe_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&retprobe_map_6));
arm64_l_444:
	/* 0x444: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_448:
	/* 0x448: add x9, sp, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_44c:
	/* 0x44c: add x1, sp, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_450:
	/* 0x450: ldr x19, [x19] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_454:
	/* 0x454: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_458:
	/* 0x458: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_45c:
	/* 0x45c: cbz x0, 394 <generic_retuprobe_filter_arg+0x394> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x45c, 0x394, arm64_l_394);
arm64_l_460:
	/* 0x460: mov w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_464:
	/* 0x464: add x9, sp, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_468:
	/* 0x468: add x1, sp, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_46c:
	/* 0x46c: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_470:
	/* 0x470: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_delete_elem();
arm64_l_474:
	/* 0x474: b 394 <generic_retuprobe_filter_arg+0x394> */
	ARM64_SIM_A64_JMP(0x474, 0x394, arm64_l_394);
arm64_l_478:
	/* 0x478: stp x30, x19, [sp, #-16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_47c:
	/* 0x47c: ldr w2, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_480:
	/* 0x480: ldr w8, [x0, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_484:
	/* 0x484: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_488:
	/* 0x488: cbnz w2, 4a4 <filter_file_buf+0x2c> */
	ARM64_SIM_A64_CBNZ(ARM64_X2, 0x488, 0x4a4, arm64_l_4a4);
arm64_l_48c:
	/* 0x48c: and w9, w8, #0xfffffffe */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967294ULL);
arm64_l_490:
	/* 0x490: cmp w9, #0x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 36ULL);
arm64_l_494:
	/* 0x494: b.eq 4a4 <filter_file_buf+0x2c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x494, 0x4a4, arm64_l_4a4);
arm64_l_498:
	/* 0x498: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_49c:
	/* 0x49c: ldp x30, x19, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_4a0:
	/* 0x4a0: ret */
	ARM64_SIM_A64_RET();
arm64_l_4a4:
	/* 0x4a4: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_4a8:
	/* 0x4a8: b.hi 504 <filter_file_buf+0x8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x4a8, 0x504, arm64_l_504);
arm64_l_4ac:
	/* 0x4ac: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_4b0:
	/* 0x4b0: mov w10, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_4b4:
	/* 0x4b4: lsl x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_4b8:
	/* 0x4b8: movk w10, #0x400, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 1024ULL);
arm64_l_4bc:
	/* 0x4bc: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_4c0:
	/* 0x4c0: b.ne 548 <filter_file_buf+0xd0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x4c0, 0x548, arm64_l_548);
arm64_l_4c4:
	/* 0x4c4: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_4c8:
	/* 0x4c8: mov w10, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 512ULL);
arm64_l_4cc:
	/* 0x4cc: lsl x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_4d0:
	/* 0x4d0: movk w10, #0x800, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 2048ULL);
arm64_l_4d4:
	/* 0x4d4: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_4d8:
	/* 0x4d8: b.ne 52c <filter_file_buf+0xb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x4d8, 0x52c, arm64_l_52c);
arm64_l_4dc:
	/* 0x4dc: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_4e0:
	/* 0x4e0: lsl x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_4e4:
	/* 0x4e4: tst x9, #0x3000000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 206158430208ULL);
arm64_l_4e8:
	/* 0x4e8: b.eq 504 <filter_file_buf+0x8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x4e8, 0x504, arm64_l_504);
arm64_l_4ec:
	/* 0x4ec: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_4f0:
	/* 0x4f0: bl 2ee8 <filter_file_type> */
	ARM64_SIM_A64_CALL(arm64_l_2ee8, 0x4f4ULL);
arm64_l_4f4:
	/* 0x4f4: ldr w8, [x19, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_4f8:
	/* 0x4f8: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_4fc:
	/* 0x4fc: b.ls 570 <filter_file_buf+0xf8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x4fc, 0x570, arm64_l_570);
arm64_l_500:
	/* 0x500: b 594 <filter_file_buf+0x11c> */
	ARM64_SIM_A64_JMP(0x500, 0x594, arm64_l_594);
arm64_l_504:
	/* 0x504: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_508:
	/* 0x508: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_50c:
	/* 0x50c: b.cs 564 <filter_file_buf+0xec> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x50c, 0x564, arm64_l_564);
arm64_l_510:
	/* 0x510: add x1, x1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_514:
	/* 0x514: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_518:
	/* 0x518: bl 1518 <filter_char_buf_equal> */
	ARM64_SIM_A64_CALL(arm64_l_1518, 0x51cULL);
arm64_l_51c:
	/* 0x51c: ldr w8, [x19, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_520:
	/* 0x520: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_524:
	/* 0x524: b.ls 570 <filter_file_buf+0xf8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x524, 0x570, arm64_l_570);
arm64_l_528:
	/* 0x528: b 594 <filter_file_buf+0x11c> */
	ARM64_SIM_A64_JMP(0x528, 0x594, arm64_l_594);
arm64_l_52c:
	/* 0x52c: ldr w0, [x19, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_530:
	/* 0x530: add x1, x1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_534:
	/* 0x534: bl 1394 <filter_char_buf_postfix> */
	ARM64_SIM_A64_CALL(arm64_l_1394, 0x538ULL);
arm64_l_538:
	/* 0x538: ldr w8, [x19, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_53c:
	/* 0x53c: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_540:
	/* 0x540: b.ls 570 <filter_file_buf+0xf8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x540, 0x570, arm64_l_570);
arm64_l_544:
	/* 0x544: b 594 <filter_file_buf+0x11c> */
	ARM64_SIM_A64_JMP(0x544, 0x594, arm64_l_594);
arm64_l_548:
	/* 0x548: ldr w0, [x19, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_54c:
	/* 0x54c: add x1, x1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_550:
	/* 0x550: bl 1464 <filter_char_buf_prefix> */
	ARM64_SIM_A64_CALL(arm64_l_1464, 0x554ULL);
arm64_l_554:
	/* 0x554: ldr w8, [x19, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_558:
	/* 0x558: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_55c:
	/* 0x55c: b.ls 570 <filter_file_buf+0xf8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x55c, 0x570, arm64_l_570);
arm64_l_560:
	/* 0x560: b 594 <filter_file_buf+0x11c> */
	ARM64_SIM_A64_JMP(0x560, 0x594, arm64_l_594);
arm64_l_564:
	/* 0x564: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_568:
	/* 0x568: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_56c:
	/* 0x56c: b.hi 594 <filter_file_buf+0x11c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x56c, 0x594, arm64_l_594);
arm64_l_570:
	/* 0x570: mov w8, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_574:
	/* 0x574: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_578:
	/* 0x578: lsl x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_57c:
	/* 0x57c: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_580:
	/* 0x580: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_584:
	/* 0x584: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_588:
	/* 0x588: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_58c:
	/* 0x58c: b.eq 594 <filter_file_buf+0x11c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x58c, 0x594, arm64_l_594);
arm64_l_590:
	/* 0x590: eor x0, x0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_594:
	/* 0x594: ldp x30, x19, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_598:
	/* 0x598: ret */
	ARM64_SIM_A64_RET();
arm64_l_59c:
	/* 0x59c: str x30, [sp, #-16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_5a0:
	/* 0x5a0: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5a4:
	/* 0x5a4: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5a8:
	/* 0x5a8: ldr w9, [x8, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_5ac:
	/* 0x5ac: cmp w9, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_5b0:
	/* 0x5b0: b.hi 610 <filter_8ty+0x74> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x5b0, 0x610, arm64_l_610);
arm64_l_5b4:
	/* 0x5b4: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_5b8:
	/* 0x5b8: mov w11, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_5bc:
	/* 0x5bc: lsl x10, x10, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_5c0:
	/* 0x5c0: tst x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_5c4:
	/* 0x5c4: b.eq 5d8 <filter_8ty+0x3c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x5c4, 0x5d8, arm64_l_5d8);
arm64_l_5c8:
	/* 0x5c8: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5cc:
	/* 0x5cc: bl 2894 <filter_8ty_selector_val> */
	ARM64_SIM_A64_CALL(arm64_l_2894, 0x5d0ULL);
arm64_l_5d0:
	/* 0x5d0: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_5d4:
	/* 0x5d4: ret */
	ARM64_SIM_A64_RET();
arm64_l_5d8:
	/* 0x5d8: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_5dc:
	/* 0x5dc: lsl x10, x10, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_5e0:
	/* 0x5e0: tst x10, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_5e4:
	/* 0x5e4: b.ne 608 <filter_8ty+0x6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x5e4, 0x608, arm64_l_608);
arm64_l_5e8:
	/* 0x5e8: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_5ec:
	/* 0x5ec: lsl x9, x10, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_5f0:
	/* 0x5f0: tst x9, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_5f4:
	/* 0x5f4: b.eq 610 <filter_8ty+0x74> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x5f4, 0x610, arm64_l_610);
arm64_l_5f8:
	/* 0x5f8: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5fc:
	/* 0x5fc: bl 2bec <filter_8ty_range> */
	ARM64_SIM_A64_CALL(arm64_l_2bec, 0x600ULL);
arm64_l_600:
	/* 0x600: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_604:
	/* 0x604: ret */
	ARM64_SIM_A64_RET();
arm64_l_608:
	/* 0x608: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_60c:
	/* 0x60c: bl 2e30 <filter_8ty_map> */
	ARM64_SIM_A64_CALL(arm64_l_2e30, 0x610ULL);
arm64_l_610:
	/* 0x610: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_614:
	/* 0x614: ret */
	ARM64_SIM_A64_RET();
arm64_l_618:
	/* 0x618: sub sp, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_61c:
	/* 0x61c: str x30, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_620:
	/* 0x620: stp x22, x21, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_624:
	/* 0x624: stp x20, x19, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_628:
	/* 0x628: ldr w10, [x0, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_62c:
	/* 0x62c: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_630:
	/* 0x630: stp xzr, xzr, [sp, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_634:
	/* 0x634: cmp w10, #0x27 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 39ULL);
arm64_l_638:
	/* 0x638: str xzr, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_63c:
	/* 0x63c: stp xzr, xzr, [sp, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_640:
	/* 0x640: str wzr, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_644:
	/* 0x644: str wzr, [sp, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_648:
	/* 0x648: b.gt 694 <filter_inet+0x7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x648, 0x694, arm64_l_694);
arm64_l_64c:
	/* 0x64c: cmp w10, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_650:
	/* 0x650: b.eq 6c8 <filter_inet+0xb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x650, 0x6c8, arm64_l_6c8);
arm64_l_654:
	/* 0x654: cmp w10, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_658:
	/* 0x658: mov x11, x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_65c:
	/* 0x65c: b.ne 89c <filter_inet+0x284> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x65c, 0x89c, arm64_l_89c);
arm64_l_660:
	/* 0x660: ldr w9, [x0, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_664:
	/* 0x664: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_668:
	/* 0x668: cmp w9, #0x13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 19ULL);
arm64_l_66c:
	/* 0x66c: b.le 710 <filter_inet+0xf8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x66c, 0x710, arm64_l_710);
arm64_l_670:
	/* 0x670: cmp w9, #0x17 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 23ULL);
arm64_l_674:
	/* 0x674: b.gt 6ac <filter_inet+0x94> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x674, 0x6ac, arm64_l_6ac);
arm64_l_678:
	/* 0x678: sub w10, w9, #0x14 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_67c:
	/* 0x67c: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_680:
	/* 0x680: b.cc 76c <filter_inet+0x154> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x680, 0x76c, arm64_l_76c);
arm64_l_684:
	/* 0x684: sub w10, w9, #0x16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 22ULL);
arm64_l_688:
	/* 0x688: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_68c:
	/* 0x68c: b.cc 764 <filter_inet+0x14c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x68c, 0x764, arm64_l_764);
arm64_l_690:
	/* 0x690: b 89c <filter_inet+0x284> */
	ARM64_SIM_A64_JMP(0x690, 0x89c, arm64_l_89c);
arm64_l_694:
	/* 0x694: cmp w10, #0x28 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_698:
	/* 0x698: b.eq 6e0 <filter_inet+0xc8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x698, 0x6e0, arm64_l_6e0);
arm64_l_69c:
	/* 0x69c: cmp w10, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_6a0:
	/* 0x6a0: mov x11, x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6a4:
	/* 0x6a4: b.eq 660 <filter_inet+0x48> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x6a4, 0x660, arm64_l_660);
arm64_l_6a8:
	/* 0x6a8: b 89c <filter_inet+0x284> */
	ARM64_SIM_A64_JMP(0x6a8, 0x89c, arm64_l_89c);
arm64_l_6ac:
	/* 0x6ac: cmp w9, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_6b0:
	/* 0x6b0: b.gt 7b0 <filter_inet+0x198> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x6b0, 0x7b0, arm64_l_7b0);
arm64_l_6b4:
	/* 0x6b4: cmp w9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_6b8:
	/* 0x6b8: b.eq 86c <filter_inet+0x254> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x6b8, 0x86c, arm64_l_86c);
arm64_l_6bc:
	/* 0x6bc: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_6c0:
	/* 0x6c0: b.eq 7d0 <filter_inet+0x1b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x6c0, 0x7d0, arm64_l_7d0);
arm64_l_6c4:
	/* 0x6c4: b 89c <filter_inet+0x284> */
	ARM64_SIM_A64_JMP(0x6c4, 0x89c, arm64_l_89c);
arm64_l_6c8:
	/* 0x6c8: mov x11, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6cc:
	/* 0x6cc: ldr w9, [x0, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_6d0:
	/* 0x6d0: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6d4:
	/* 0x6d4: cmp w9, #0x13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 19ULL);
arm64_l_6d8:
	/* 0x6d8: b.gt 670 <filter_inet+0x58> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x6d8, 0x670, arm64_l_670);
arm64_l_6dc:
	/* 0x6dc: b 710 <filter_inet+0xf8> */
	ARM64_SIM_A64_JMP(0x6dc, 0x710, arm64_l_710);
arm64_l_6e0:
	/* 0x6e0: ldrh w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6e4:
	/* 0x6e4: ldrh w9, [x1, #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_6e8:
	/* 0x6e8: mov x11, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6ec:
	/* 0x6ec: strh w8, [sp, #54] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 54ULL);
arm64_l_6f0:
	/* 0x6f0: strh w9, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_6f4:
	/* 0x6f4: ldp x8, x9, [x1, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_6f8:
	/* 0x6f8: add x1, sp, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_6fc:
	/* 0x6fc: stp x8, x9, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_700:
	/* 0x700: ldr w9, [x0, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_704:
	/* 0x704: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_708:
	/* 0x708: cmp w9, #0x13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 19ULL);
arm64_l_70c:
	/* 0x70c: b.gt 670 <filter_inet+0x58> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x70c, 0x670, arm64_l_670);
arm64_l_710:
	/* 0x710: cmp w9, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_714:
	/* 0x714: b.le 738 <filter_inet+0x120> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x714, 0x738, arm64_l_738);
arm64_l_718:
	/* 0x718: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_71c:
	/* 0x71c: b.gt 754 <filter_inet+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x71c, 0x754, arm64_l_754);
arm64_l_720:
	/* 0x720: cmp w9, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_724:
	/* 0x724: b.eq 764 <filter_inet+0x14c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x724, 0x764, arm64_l_764);
arm64_l_728:
	/* 0x728: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_72c:
	/* 0x72c: b.ne 89c <filter_inet+0x284> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x72c, 0x89c, arm64_l_89c);
arm64_l_730:
	/* 0x730: ldrh w8, [x1, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_734:
	/* 0x734: b 984 <filter_inet+0x36c> */
	ARM64_SIM_A64_JMP(0x734, 0x984, arm64_l_984);
arm64_l_738:
	/* 0x738: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_73c:
	/* 0x73c: b.eq 86c <filter_inet+0x254> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x73c, 0x86c, arm64_l_86c);
arm64_l_740:
	/* 0x740: cmp w9, #0xe */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 14ULL);
arm64_l_744:
	/* 0x744: b.eq 7d0 <filter_inet+0x1b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x744, 0x7d0, arm64_l_7d0);
arm64_l_748:
	/* 0x748: cmp w9, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_74c:
	/* 0x74c: b.eq 76c <filter_inet+0x154> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x74c, 0x76c, arm64_l_76c);
arm64_l_750:
	/* 0x750: b 89c <filter_inet+0x284> */
	ARM64_SIM_A64_JMP(0x750, 0x89c, arm64_l_89c);
arm64_l_754:
	/* 0x754: cmp w9, #0x12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_758:
	/* 0x758: b.eq 76c <filter_inet+0x154> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x758, 0x76c, arm64_l_76c);
arm64_l_75c:
	/* 0x75c: cmp w9, #0x13 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 19ULL);
arm64_l_760:
	/* 0x760: b.ne 89c <filter_inet+0x284> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x760, 0x89c, arm64_l_89c);
arm64_l_764:
	/* 0x764: ldrh w10, [x1, #34] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 34ULL);
arm64_l_768:
	/* 0x768: b 770 <filter_inet+0x158> */
	ARM64_SIM_A64_JMP(0x768, 0x770, arm64_l_770);
arm64_l_76c:
	/* 0x76c: ldrh w10, [x1, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_770:
	/* 0x770: mov w19, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_774:
	/* 0x774: mov w20, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_778:
	/* 0x778: mov x21, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_77c:
	/* 0x77c: str w10, [sp, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_780:
	/* 0x780: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_784:
	/* 0x784: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_788:
	/* 0x788: b.gt 7e8 <filter_inet+0x1d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x788, 0x7e8, arm64_l_7e8);
arm64_l_78c:
	/* 0x78c: sub w10, w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_790:
	/* 0x790: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_794:
	/* 0x794: b.cc 820 <filter_inet+0x208> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x794, 0x820, arm64_l_820);
arm64_l_798:
	/* 0x798: sub w10, w9, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_79c:
	/* 0x79c: cmp w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_7a0:
	/* 0x7a0: b.cc 894 <filter_inet+0x27c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x7a0, 0x894, arm64_l_894);
arm64_l_7a4:
	/* 0x7a4: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_7a8:
	/* 0x7a8: b.eq 988 <filter_inet+0x370> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x7a8, 0x988, arm64_l_988);
arm64_l_7ac:
	/* 0x7ac: b 89c <filter_inet+0x284> */
	ARM64_SIM_A64_JMP(0x7ac, 0x89c, arm64_l_89c);
arm64_l_7b0:
	/* 0x7b0: cmp w9, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_7b4:
	/* 0x7b4: b.eq 980 <filter_inet+0x368> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x7b4, 0x980, arm64_l_980);
arm64_l_7b8:
	/* 0x7b8: cmp w9, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_7bc:
	/* 0x7bc: b.ne 89c <filter_inet+0x284> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x7bc, 0x89c, arm64_l_89c);
arm64_l_7c0:
	/* 0x7c0: cmp w10, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_7c4:
	/* 0x7c4: b.ne 9d8 <filter_inet+0x3c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x7c4, 0x9d8, arm64_l_9d8);
arm64_l_7c8:
	/* 0x7c8: cbnz x11, 9e4 <filter_inet+0x3cc> */
	ARM64_SIM_A64_CBNZ(ARM64_X11, 0x7c8, 0x9e4, arm64_l_9e4);
arm64_l_7cc:
	/* 0x7cc: b 988 <filter_inet+0x370> */
	ARM64_SIM_A64_JMP(0x7cc, 0x988, arm64_l_988);
arm64_l_7d0:
	/* 0x7d0: ldp w19, w20, [x1, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X19, ARM64_X20, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_7d4:
	/* 0x7d4: ldr x21, [x1, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_7d8:
	/* 0x7d8: mov w10, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_7dc:
	/* 0x7dc: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7e0:
	/* 0x7e0: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_7e4:
	/* 0x7e4: b.le 78c <filter_inet+0x174> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x7e4, 0x78c, arm64_l_78c);
arm64_l_7e8:
	/* 0x7e8: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_7ec:
	/* 0x7ec: b.hi 888 <filter_inet+0x270> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x7ec, 0x888, arm64_l_888);
arm64_l_7f0:
	/* 0x7f0: mov w11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_7f4:
	/* 0x7f4: mov w12, #0x500000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5242880ULL);
arm64_l_7f8:
	/* 0x7f8: lsl w11, w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X11, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_7fc:
	/* 0x7fc: tst w11, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X11, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_800:
	/* 0x800: b.ne 8b4 <filter_inet+0x29c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x800, 0x8b4, arm64_l_8b4);
arm64_l_804:
	/* 0x804: mov w12, #0xa00000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10485760ULL);
arm64_l_808:
	/* 0x808: tst w11, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X11, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_80c:
	/* 0x80c: b.ne 8d4 <filter_inet+0x2bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x80c, 0x8d4, arm64_l_8d4);
arm64_l_810:
	/* 0x810: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_814:
	/* 0x814: lsl w10, w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_818:
	/* 0x818: tst w10, #0x3000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50331648ULL);
arm64_l_81c:
	/* 0x81c: b.eq 888 <filter_inet+0x270> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x81c, 0x888, arm64_l_888);
arm64_l_820:
	/* 0x820: ldrh w8, [x1, #38] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 38ULL);
arm64_l_824:
	/* 0x824: cmp w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_828:
	/* 0x828: b.eq 8f4 <filter_inet+0x2dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x828, 0x8f4, arm64_l_8f4);
arm64_l_82c:
	/* 0x82c: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_830:
	/* 0x830: b.ne 964 <filter_inet+0x34c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x830, 0x964, arm64_l_964);
arm64_l_834:
	/* 0x834: ldr w8, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_838:
	/* 0x838: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_83c:
	/* 0x83c: adrp x0, 0 <addr4lpm_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&addr4lpm_maps_0));
arm64_l_840:
	/* 0x840: add x9, sp, #0x5c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 92ULL);
arm64_l_844:
	/* 0x844: str w8, [sp, #92] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_848:
	/* 0x848: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_84c:
	/* 0x84c: add x1, sp, #0x5c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 92ULL);
arm64_l_850:
	/* 0x850: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_854:
	/* 0x854: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_858:
	/* 0x858: cbz x0, 9a4 <filter_inet+0x38c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x858, 0x9a4, arm64_l_9a4);
arm64_l_85c:
	/* 0x85c: mov w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 32ULL);
arm64_l_860:
	/* 0x860: add x1, sp, #0x3c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_864:
	/* 0x864: stp w8, w19, [sp, #60] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 60ULL);
arm64_l_868:
	/* 0x868: b 934 <filter_inet+0x31c> */
	ARM64_SIM_A64_JMP(0x868, 0x934, arm64_l_934);
arm64_l_86c:
	/* 0x86c: ldp w19, w20, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X19, ARM64_X20, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_870:
	/* 0x870: ldr x21, [x1, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_874:
	/* 0x874: mov w10, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_878:
	/* 0x878: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_87c:
	/* 0x87c: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_880:
	/* 0x880: b.le 78c <filter_inet+0x174> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x880, 0x78c, arm64_l_78c);
arm64_l_884:
	/* 0x884: b 7e8 <filter_inet+0x1d0> */
	ARM64_SIM_A64_JMP(0x884, 0x7e8, arm64_l_7e8);
arm64_l_888:
	/* 0x888: sub w9, w9, #0x12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_88c:
	/* 0x88c: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_890:
	/* 0x890: b.cs 89c <filter_inet+0x284> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x890, 0x89c, arm64_l_89c);
arm64_l_894:
	/* 0x894: add x1, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_898:
	/* 0x898: b 98c <filter_inet+0x374> */
	ARM64_SIM_A64_JMP(0x898, 0x98c, arm64_l_98c);
arm64_l_89c:
	/* 0x89c: ldp x20, x19, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_8a0:
	/* 0x8a0: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_8a4:
	/* 0x8a4: ldr x30, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_8a8:
	/* 0x8a8: ldp x22, x21, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_8ac:
	/* 0x8ac: add sp, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_8b0:
	/* 0x8b0: ret */
	ARM64_SIM_A64_RET();
arm64_l_8b4:
	/* 0x8b4: cmp w10, #0x400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1024ULL);
arm64_l_8b8:
	/* 0x8b8: cset w8, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_8bc:
	/* 0x8bc: ldp x20, x19, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_8c0:
	/* 0x8c0: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_8c4:
	/* 0x8c4: ldr x30, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_8c8:
	/* 0x8c8: ldp x22, x21, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_8cc:
	/* 0x8cc: add sp, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_8d0:
	/* 0x8d0: ret */
	ARM64_SIM_A64_RET();
arm64_l_8d4:
	/* 0x8d4: cmp w10, #0x3ff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_8d8:
	/* 0x8d8: cset w8, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_8dc:
	/* 0x8dc: ldp x20, x19, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_8e0:
	/* 0x8e0: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_8e4:
	/* 0x8e4: ldr x30, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_8e8:
	/* 0x8e8: ldp x22, x21, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_8ec:
	/* 0x8ec: add sp, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_8f0:
	/* 0x8f0: ret */
	ARM64_SIM_A64_RET();
arm64_l_8f4:
	/* 0x8f4: ldr w8, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_8f8:
	/* 0x8f8: mov x22, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_8fc:
	/* 0x8fc: adrp x0, 0 <addr6lpm_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&addr6lpm_maps_1));
arm64_l_900:
	/* 0x900: add x9, sp, #0x5c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 92ULL);
arm64_l_904:
	/* 0x904: str w8, [sp, #92] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_908:
	/* 0x908: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_90c:
	/* 0x90c: add x1, sp, #0x5c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 92ULL);
arm64_l_910:
	/* 0x910: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_914:
	/* 0x914: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_918:
	/* 0x918: cbz x0, 9a4 <filter_inet+0x38c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x918, 0x9a4, arm64_l_9a4);
arm64_l_91c:
	/* 0x91c: mov w8, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 128ULL);
arm64_l_920:
	/* 0x920: add x1, sp, #0x3c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_924:
	/* 0x924: stp w20, w21, [sp, #68] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_928:
	/* 0x928: stp w8, w19, [sp, #60] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 60ULL);
arm64_l_92c:
	/* 0x92c: lsr x8, x21, #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 32ULL);
arm64_l_930:
	/* 0x930: str w8, [sp, #76] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_934:
	/* 0x934: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_938:
	/* 0x938: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_93c:
	/* 0x93c: ldr w8, [x22, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_940:
	/* 0x940: sub w9, w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_944:
	/* 0x944: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_948:
	/* 0x948: b.cc 9b4 <filter_inet+0x39c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x948, 0x9b4, arm64_l_9b4);
arm64_l_94c:
	/* 0x94c: sub w8, w8, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_950:
	/* 0x950: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_954:
	/* 0x954: b.hi 964 <filter_inet+0x34c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x954, 0x964, arm64_l_964);
arm64_l_958:
	/* 0x958: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_95c:
	/* 0x95c: cset w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_960:
	/* 0x960: b 9bc <filter_inet+0x3a4> */
	ARM64_SIM_A64_JMP(0x960, 0x9bc, arm64_l_9bc);
arm64_l_964:
	/* 0x964: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_968:
	/* 0x968: ldp x20, x19, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_96c:
	/* 0x96c: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_970:
	/* 0x970: ldr x30, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_974:
	/* 0x974: ldp x22, x21, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_978:
	/* 0x978: add sp, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_97c:
	/* 0x97c: ret */
	ARM64_SIM_A64_RET();
arm64_l_980:
	/* 0x980: ldrh w8, [x1, #38] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 38ULL);
arm64_l_984:
	/* 0x984: str w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_988:
	/* 0x988: add x1, sp, #0x58 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_98c:
	/* 0x98c: bl 27dc <filter_32ty_map> */
	ARM64_SIM_A64_CALL(arm64_l_27dc, 0x990ULL);
arm64_l_990:
	/* 0x990: ldp x20, x19, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_994:
	/* 0x994: ldr x30, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_998:
	/* 0x998: ldp x22, x21, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_99c:
	/* 0x99c: add sp, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_9a0:
	/* 0x9a0: ret */
	ARM64_SIM_A64_RET();
arm64_l_9a4:
	/* 0x9a4: ldr w8, [x22, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_9a8:
	/* 0x9a8: and w8, w8, #0xfffffffe */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967294ULL);
arm64_l_9ac:
	/* 0x9ac: cmp w8, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_9b0:
	/* 0x9b0: b 9b8 <filter_inet+0x3a0> */
	ARM64_SIM_A64_JMP(0x9b0, 0x9b8, arm64_l_9b8);
arm64_l_9b4:
	/* 0x9b4: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_9b8:
	/* 0x9b8: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_9bc:
	/* 0x9bc: mov w8, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_9c0:
	/* 0x9c0: ldp x20, x19, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_9c4:
	/* 0x9c4: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_9c8:
	/* 0x9c8: ldr x30, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_9cc:
	/* 0x9cc: ldp x22, x21, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_9d0:
	/* 0x9d0: add sp, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_9d4:
	/* 0x9d4: ret */
	ARM64_SIM_A64_RET();
arm64_l_9d8:
	/* 0x9d8: cmp w10, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_9dc:
	/* 0x9dc: b.ne 9ec <filter_inet+0x3d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x9dc, 0x9ec, arm64_l_9ec);
arm64_l_9e0:
	/* 0x9e0: cbz x11, 9ec <filter_inet+0x3d4> */
	ARM64_SIM_A64_CBZ(ARM64_X11, 0x9e0, 0x9ec, arm64_l_9ec);
arm64_l_9e4:
	/* 0x9e4: ldrb w8, [x11, #58] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 58ULL);
arm64_l_9e8:
	/* 0x9e8: str w8, [sp, #88] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_9ec:
	/* 0x9ec: cmp w10, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_9f0:
	/* 0x9f0: b.eq 988 <filter_inet+0x370> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x9f0, 0x988, arm64_l_988);
arm64_l_9f4:
	/* 0x9f4: cmp w10, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_9f8:
	/* 0x9f8: b.eq 988 <filter_inet+0x370> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x9f8, 0x988, arm64_l_988);
arm64_l_9fc:
	/* 0x9fc: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a00:
	/* 0xa00: ldp x20, x19, [sp, #112] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_a04:
	/* 0xa04: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a08:
	/* 0xa08: ldr x30, [sp, #80] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_a0c:
	/* 0xa0c: ldp x22, x21, [sp, #96] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_a10:
	/* 0xa10: add sp, sp, #0x80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_a14:
	/* 0xa14: ret */
	ARM64_SIM_A64_RET();
arm64_l_a18:
	/* 0xa18: sub sp, sp, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_a1c:
	/* 0xa1c: stp x30, x19, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_a20:
	/* 0xa20: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a24:
	/* 0xa24: ldrb w2, [x1, #3] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3ULL);
arm64_l_a28:
	/* 0xa28: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a2c:
	/* 0xa2c: ldr w8, [x19, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_a30:
	/* 0xa30: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_a34:
	/* 0xa34: b.gt a88 <filter_sockaddr_un+0x70> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xa34, 0xa88, arm64_l_a88);
arm64_l_a38:
	/* 0xa38: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_a3c:
	/* 0xa3c: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_a40:
	/* 0xa40: b.cs a9c <filter_sockaddr_un+0x84> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xa40, 0xa9c, arm64_l_a9c);
arm64_l_a44:
	/* 0xa44: add x1, x1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_a48:
	/* 0xa48: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a4c:
	/* 0xa4c: bl 1518 <filter_char_buf_equal> */
	ARM64_SIM_A64_CALL(arm64_l_1518, 0xa50ULL);
arm64_l_a50:
	/* 0xa50: ldr w8, [x19, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_a54:
	/* 0xa54: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_a58:
	/* 0xa58: b.hi a7c <filter_sockaddr_un+0x64> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xa58, 0xa7c, arm64_l_a7c);
arm64_l_a5c:
	/* 0xa5c: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a60:
	/* 0xa60: lsl x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_a64:
	/* 0xa64: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_a68:
	/* 0xa68: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_a6c:
	/* 0xa6c: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_a70:
	/* 0xa70: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_a74:
	/* 0xa74: b.eq a7c <filter_sockaddr_un+0x64> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xa74, 0xa7c, arm64_l_a7c);
arm64_l_a78:
	/* 0xa78: eor x0, x0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_a7c:
	/* 0xa7c: ldp x30, x19, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_a80:
	/* 0xa80: add sp, sp, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_a84:
	/* 0xa84: ret */
	ARM64_SIM_A64_RET();
arm64_l_a88:
	/* 0xa88: cmp w8, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_a8c:
	/* 0xa8c: b.eq ae8 <filter_sockaddr_un+0xd0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xa8c, 0xae8, arm64_l_ae8);
arm64_l_a90:
	/* 0xa90: cmp w8, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_a94:
	/* 0xa94: b.eq aa4 <filter_sockaddr_un+0x8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xa94, 0xaa4, arm64_l_aa4);
arm64_l_a98:
	/* 0xa98: b a7c <filter_sockaddr_un+0x64> */
	ARM64_SIM_A64_JMP(0xa98, 0xa7c, arm64_l_a7c);
arm64_l_a9c:
	/* 0xa9c: cmp w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_aa0:
	/* 0xaa0: b.ne a7c <filter_sockaddr_un+0x64> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xaa0, 0xa7c, arm64_l_a7c);
arm64_l_aa4:
	/* 0xaa4: ldr w0, [x19, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_aa8:
	/* 0xaa8: add x1, x1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_aac:
	/* 0xaac: bl 1464 <filter_char_buf_prefix> */
	ARM64_SIM_A64_CALL(arm64_l_1464, 0xab0ULL);
arm64_l_ab0:
	/* 0xab0: ldr w8, [x19, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_ab4:
	/* 0xab4: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_ab8:
	/* 0xab8: b.hi a7c <filter_sockaddr_un+0x64> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xab8, 0xa7c, arm64_l_a7c);
arm64_l_abc:
	/* 0xabc: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ac0:
	/* 0xac0: lsl x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_ac4:
	/* 0xac4: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_ac8:
	/* 0xac8: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_acc:
	/* 0xacc: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_ad0:
	/* 0xad0: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ad4:
	/* 0xad4: b.eq a7c <filter_sockaddr_un+0x64> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xad4, 0xa7c, arm64_l_a7c);
arm64_l_ad8:
	/* 0xad8: eor x0, x0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_adc:
	/* 0xadc: ldp x30, x19, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_ae0:
	/* 0xae0: add sp, sp, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_ae4:
	/* 0xae4: ret */
	ARM64_SIM_A64_RET();
arm64_l_ae8:
	/* 0xae8: ldrh w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_aec:
	/* 0xaec: add x1, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_af0:
	/* 0xaf0: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_af4:
	/* 0xaf4: str w8, [sp, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_af8:
	/* 0xaf8: bl 27dc <filter_32ty_map> */
	ARM64_SIM_A64_CALL(arm64_l_27dc, 0xafcULL);
arm64_l_afc:
	/* 0xafc: ldp x30, x19, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_b00:
	/* 0xb00: add sp, sp, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_b04:
	/* 0xb04: ret */
	ARM64_SIM_A64_RET();
arm64_l_b08:
	/* 0xb08: str x30, [sp, #-16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_b0c:
	/* 0xb0c: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b10:
	/* 0xb10: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b14:
	/* 0xb14: ldr w9, [x8, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_b18:
	/* 0xb18: cmp w9, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_b1c:
	/* 0xb1c: b.hi b7c <filter_32ty+0x74> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xb1c, 0xb7c, arm64_l_b7c);
arm64_l_b20:
	/* 0xb20: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_b24:
	/* 0xb24: mov w11, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_b28:
	/* 0xb28: lsl x10, x10, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_b2c:
	/* 0xb2c: tst x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_b30:
	/* 0xb30: b.eq b44 <filter_32ty+0x3c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xb30, 0xb44, arm64_l_b44);
arm64_l_b34:
	/* 0xb34: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b38:
	/* 0xb38: bl 2240 <filter_32ty_selector_val> */
	ARM64_SIM_A64_CALL(arm64_l_2240, 0xb3cULL);
arm64_l_b3c:
	/* 0xb3c: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_b40:
	/* 0xb40: ret */
	ARM64_SIM_A64_RET();
arm64_l_b44:
	/* 0xb44: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_b48:
	/* 0xb48: lsl x10, x10, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_b4c:
	/* 0xb4c: tst x10, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_b50:
	/* 0xb50: b.ne b74 <filter_32ty+0x6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xb50, 0xb74, arm64_l_b74);
arm64_l_b54:
	/* 0xb54: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_b58:
	/* 0xb58: lsl x9, x10, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_b5c:
	/* 0xb5c: tst x9, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_b60:
	/* 0xb60: b.eq b7c <filter_32ty+0x74> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xb60, 0xb7c, arm64_l_b7c);
arm64_l_b64:
	/* 0xb64: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b68:
	/* 0xb68: bl 2598 <filter_32ty_range> */
	ARM64_SIM_A64_CALL(arm64_l_2598, 0xb6cULL);
arm64_l_b6c:
	/* 0xb6c: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_b70:
	/* 0xb70: ret */
	ARM64_SIM_A64_RET();
arm64_l_b74:
	/* 0xb74: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b78:
	/* 0xb78: bl 27dc <filter_32ty_map> */
	ARM64_SIM_A64_CALL(arm64_l_27dc, 0xb7cULL);
arm64_l_b7c:
	/* 0xb7c: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_b80:
	/* 0xb80: ret */
	ARM64_SIM_A64_RET();
arm64_l_b84:
	/* 0xb84: str x30, [sp, #-16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_b88:
	/* 0xb88: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b8c:
	/* 0xb8c: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b90:
	/* 0xb90: ldr w9, [x8, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_b94:
	/* 0xb94: cmp w9, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_b98:
	/* 0xb98: b.hi bf8 <filter_16ty+0x74> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xb98, 0xbf8, arm64_l_bf8);
arm64_l_b9c:
	/* 0xb9c: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ba0:
	/* 0xba0: mov w11, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_ba4:
	/* 0xba4: lsl x10, x10, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_ba8:
	/* 0xba8: tst x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_bac:
	/* 0xbac: b.eq bc0 <filter_16ty+0x3c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xbac, 0xbc0, arm64_l_bc0);
arm64_l_bb0:
	/* 0xbb0: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_bb4:
	/* 0xbb4: bl 1bec <filter_16ty_selector_val> */
	ARM64_SIM_A64_CALL(arm64_l_1bec, 0xbb8ULL);
arm64_l_bb8:
	/* 0xbb8: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_bbc:
	/* 0xbbc: ret */
	ARM64_SIM_A64_RET();
arm64_l_bc0:
	/* 0xbc0: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_bc4:
	/* 0xbc4: lsl x10, x10, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_bc8:
	/* 0xbc8: tst x10, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_bcc:
	/* 0xbcc: b.ne bf0 <filter_16ty+0x6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xbcc, 0xbf0, arm64_l_bf0);
arm64_l_bd0:
	/* 0xbd0: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_bd4:
	/* 0xbd4: lsl x9, x10, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_bd8:
	/* 0xbd8: tst x9, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_bdc:
	/* 0xbdc: b.eq bf8 <filter_16ty+0x74> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xbdc, 0xbf8, arm64_l_bf8);
arm64_l_be0:
	/* 0xbe0: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_be4:
	/* 0xbe4: bl 1f44 <filter_16ty_range> */
	ARM64_SIM_A64_CALL(arm64_l_1f44, 0xbe8ULL);
arm64_l_be8:
	/* 0xbe8: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_bec:
	/* 0xbec: ret */
	ARM64_SIM_A64_RET();
arm64_l_bf0:
	/* 0xbf0: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_bf4:
	/* 0xbf4: bl 2188 <filter_16ty_map> */
	ARM64_SIM_A64_CALL(arm64_l_2188, 0xbf8ULL);
arm64_l_bf8:
	/* 0xbf8: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_bfc:
	/* 0xbfc: ret */
	ARM64_SIM_A64_RET();
arm64_l_c00:
	/* 0xc00: stp x30, x19, [sp, #-16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_c04:
	/* 0xc04: mov w8, w2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_c08:
	/* 0xc08: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c0c:
	/* 0xc0c: add x9, x1, w2, sxtw */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X1, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_SXTW, 0), 0);
arm64_l_c10:
	/* 0xc10: ldur w2, [x9, #-4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 18446744073709551612ULL);
arm64_l_c14:
	/* 0xc14: add x1, x1, w8, uxtw */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X1, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTW, 0), 0);
arm64_l_c18:
	/* 0xc18: ldr w8, [x0, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_c1c:
	/* 0xc1c: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c20:
	/* 0xc20: cmp w8, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_c24:
	/* 0xc24: b.gt c48 <filter_char_buf+0x48> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xc24, 0xc48, arm64_l_c48);
arm64_l_c28:
	/* 0xc28: sub w9, w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_c2c:
	/* 0xc2c: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_c30:
	/* 0xc30: b.cc c94 <filter_char_buf+0x94> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xc30, 0xc94, arm64_l_c94);
arm64_l_c34:
	/* 0xc34: cmp w8, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_c38:
	/* 0xc38: b.eq c88 <filter_char_buf+0x88> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xc38, 0xc88, arm64_l_c88);
arm64_l_c3c:
	/* 0xc3c: cmp w8, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_c40:
	/* 0xc40: b.eq c60 <filter_char_buf+0x60> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xc40, 0xc60, arm64_l_c60);
arm64_l_c44:
	/* 0xc44: b cb0 <filter_char_buf+0xb0> */
	ARM64_SIM_A64_JMP(0xc44, 0xcb0, arm64_l_cb0);
arm64_l_c48:
	/* 0xc48: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_c4c:
	/* 0xc4c: b.gt c6c <filter_char_buf+0x6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xc4c, 0xc6c, arm64_l_c6c);
arm64_l_c50:
	/* 0xc50: cmp w8, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_c54:
	/* 0xc54: b.eq c88 <filter_char_buf+0x88> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xc54, 0xc88, arm64_l_c88);
arm64_l_c58:
	/* 0xc58: cmp w8, #0x1b */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_c5c:
	/* 0xc5c: b.ne cb0 <filter_char_buf+0xb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xc5c, 0xcb0, arm64_l_cb0);
arm64_l_c60:
	/* 0xc60: ldr w0, [x19, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_c64:
	/* 0xc64: bl 1394 <filter_char_buf_postfix> */
	ARM64_SIM_A64_CALL(arm64_l_1394, 0xc68ULL);
arm64_l_c68:
	/* 0xc68: b cac <filter_char_buf+0xac> */
	ARM64_SIM_A64_JMP(0xc68, 0xcac, arm64_l_cac);
arm64_l_c6c:
	/* 0xc6c: cmp w8, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_c70:
	/* 0xc70: b.eq ca0 <filter_char_buf+0xa0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xc70, 0xca0, arm64_l_ca0);
arm64_l_c74:
	/* 0xc74: cmp w8, #0x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 34ULL);
arm64_l_c78:
	/* 0xc78: b.ne cb0 <filter_char_buf+0xb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xc78, 0xcb0, arm64_l_cb0);
arm64_l_c7c:
	/* 0xc7c: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c80:
	/* 0xc80: mov w3, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X3, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_c84:
	/* 0xc84: b ca8 <filter_char_buf+0xa8> */
	ARM64_SIM_A64_JMP(0xc84, 0xca8, arm64_l_ca8);
arm64_l_c88:
	/* 0xc88: ldr w0, [x19, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_c8c:
	/* 0xc8c: bl 1464 <filter_char_buf_prefix> */
	ARM64_SIM_A64_CALL(arm64_l_1464, 0xc90ULL);
arm64_l_c90:
	/* 0xc90: b cac <filter_char_buf+0xac> */
	ARM64_SIM_A64_JMP(0xc90, 0xcac, arm64_l_cac);
arm64_l_c94:
	/* 0xc94: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c98:
	/* 0xc98: bl 1518 <filter_char_buf_equal> */
	ARM64_SIM_A64_CALL(arm64_l_1518, 0xc9cULL);
arm64_l_c9c:
	/* 0xc9c: b cac <filter_char_buf+0xac> */
	ARM64_SIM_A64_JMP(0xc9c, 0xcac, arm64_l_cac);
arm64_l_ca0:
	/* 0xca0: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ca4:
	/* 0xca4: mov w3, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_ca8:
	/* 0xca8: bl 1940 <filter_char_substring> */
	ARM64_SIM_A64_CALL(arm64_l_1940, 0xcacULL);
arm64_l_cac:
	/* 0xcac: ldr w8, [x19, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_cb0:
	/* 0xcb0: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_cb4:
	/* 0xcb4: b.hi ce0 <filter_char_buf+0xe0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xcb4, 0xce0, arm64_l_ce0);
arm64_l_cb8:
	/* 0xcb8: mov w8, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_cbc:
	/* 0xcbc: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_cc0:
	/* 0xcc0: lsl x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_cc4:
	/* 0xcc4: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_cc8:
	/* 0xcc8: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_ccc:
	/* 0xccc: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_cd0:
	/* 0xcd0: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_cd4:
	/* 0xcd4: b.eq ce0 <filter_char_buf+0xe0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xcd4, 0xce0, arm64_l_ce0);
arm64_l_cd8:
	/* 0xcd8: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_cdc:
	/* 0xcdc: cset w0, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_ce0:
	/* 0xce0: ldp x30, x19, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_ce4:
	/* 0xce4: ret */
	ARM64_SIM_A64_RET();
arm64_l_ce8:
	/* 0xce8: str x30, [sp, #-16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_cec:
	/* 0xcec: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_cf0:
	/* 0xcf0: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_cf4:
	/* 0xcf4: ldr w9, [x8, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_cf8:
	/* 0xcf8: cmp w9, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_cfc:
	/* 0xcfc: b.hi d5c <filter_64ty+0x74> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xcfc, 0xd5c, arm64_l_d5c);
arm64_l_d00:
	/* 0xd00: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d04:
	/* 0xd04: mov w11, #0x101e */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4126ULL);
arm64_l_d08:
	/* 0xd08: lsl x10, x10, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_d0c:
	/* 0xd0c: tst x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d10:
	/* 0xd10: b.eq d24 <filter_64ty+0x3c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd10, 0xd24, arm64_l_d24);
arm64_l_d14:
	/* 0xd14: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d18:
	/* 0xd18: bl d64 <filter_64ty_selector_val> */
	ARM64_SIM_A64_CALL(arm64_l_d64, 0xd1cULL);
arm64_l_d1c:
	/* 0xd1c: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_d20:
	/* 0xd20: ret */
	ARM64_SIM_A64_RET();
arm64_l_d24:
	/* 0xd24: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d28:
	/* 0xd28: lsl x10, x10, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_d2c:
	/* 0xd2c: tst x10, #0xc00 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3072ULL);
arm64_l_d30:
	/* 0xd30: b.ne d54 <filter_64ty+0x6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xd30, 0xd54, arm64_l_d54);
arm64_l_d34:
	/* 0xd34: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d38:
	/* 0xd38: lsl x9, x10, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_d3c:
	/* 0xd3c: tst x9, #0x180000000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6442450944ULL);
arm64_l_d40:
	/* 0xd40: b.eq d5c <filter_64ty+0x74> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd40, 0xd5c, arm64_l_d5c);
arm64_l_d44:
	/* 0xd44: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d48:
	/* 0xd48: bl 10bc <filter_64ty_range> */
	ARM64_SIM_A64_CALL(arm64_l_10bc, 0xd4cULL);
arm64_l_d4c:
	/* 0xd4c: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_d50:
	/* 0xd50: ret */
	ARM64_SIM_A64_RET();
arm64_l_d54:
	/* 0xd54: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d58:
	/* 0xd58: bl 1300 <filter_64ty_map> */
	ARM64_SIM_A64_CALL(arm64_l_1300, 0xd5cULL);
arm64_l_d5c:
	/* 0xd5c: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_d60:
	/* 0xd60: ret */
	ARM64_SIM_A64_RET();
arm64_l_d64:
	/* 0xd64: ldr w8, [x0, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_d68:
	/* 0xd68: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_d6c:
	/* 0xd6c: b.hi de0 <filter_64ty_selector_val+0x7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xd6c, 0xde0, arm64_l_de0);
arm64_l_d70:
	/* 0xd70: mov x10, #0x40 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 64ULL);
arm64_l_d74:
	/* 0xd74: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d78:
	/* 0xd78: movk x10, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_d7c:
	/* 0xd7c: lsl x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_d80:
	/* 0xd80: movk x10, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_d84:
	/* 0xd84: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d88:
	/* 0xd88: b.eq d94 <filter_64ty_selector_val+0x30> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd88, 0xd94, arm64_l_d94);
arm64_l_d8c:
	/* 0xd8c: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d90:
	/* 0xd90: ret */
	ARM64_SIM_A64_RET();
arm64_l_d94:
	/* 0xd94: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d98:
	/* 0xd98: lsl x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_d9c:
	/* 0xd9c: tst x9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_da0:
	/* 0xda0: b.eq dc0 <filter_64ty_selector_val+0x5c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xda0, 0xdc0, arm64_l_dc0);
arm64_l_da4:
	/* 0xda4: ldr x9, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_da8:
	/* 0xda8: ldr x10, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_dac:
	/* 0xdac: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_db0:
	/* 0xdb0: b.ne e60 <filter_64ty_selector_val+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xdb0, 0xe60, arm64_l_e60);
arm64_l_db4:
	/* 0xdb4: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_db8:
	/* 0xdb8: cset w0, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_dbc:
	/* 0xdbc: ret */
	ARM64_SIM_A64_RET();
arm64_l_dc0:
	/* 0xdc0: cmp x8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_dc4:
	/* 0xdc4: b.ne de0 <filter_64ty_selector_val+0x7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xdc4, 0xde0, arm64_l_de0);
arm64_l_dc8:
	/* 0xdc8: ldr x8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_dcc:
	/* 0xdcc: ldr x9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_dd0:
	/* 0xdd0: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_dd4:
	/* 0xdd4: b.eq f0c <filter_64ty_selector_val+0x1a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xdd4, 0xf0c, arm64_l_f0c);
arm64_l_dd8:
	/* 0xdd8: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ddc:
	/* 0xddc: ret */
	ARM64_SIM_A64_RET();
arm64_l_de0:
	/* 0xde0: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_de4:
	/* 0xde4: b.eq e28 <filter_64ty_selector_val+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xde4, 0xe28, arm64_l_e28);
arm64_l_de8:
	/* 0xde8: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_dec:
	/* 0xdec: b.ne 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xdec, 0x10b4, arm64_l_10b4);
arm64_l_df0:
	/* 0xdf0: ldr w8, [x0, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_df4:
	/* 0xdf4: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_df8:
	/* 0xdf8: b.hi f44 <filter_64ty_selector_val+0x1e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xdf8, 0xf44, arm64_l_f44);
arm64_l_dfc:
	/* 0xdfc: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_e00:
	/* 0xe00: lsl w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_e04:
	/* 0xe04: mov w9, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_e08:
	/* 0xe08: tst w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e0c:
	/* 0xe0c: b.eq f44 <filter_64ty_selector_val+0x1e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe0c, 0xf44, arm64_l_f44);
arm64_l_e10:
	/* 0xe10: ldr x8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e14:
	/* 0xe14: ldr x9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_e18:
	/* 0xe18: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e1c:
	/* 0xe1c: b.ge eec <filter_64ty_selector_val+0x188> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0xe1c, 0xeec, arm64_l_eec);
arm64_l_e20:
	/* 0xe20: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_e24:
	/* 0xe24: ret */
	ARM64_SIM_A64_RET();
arm64_l_e28:
	/* 0xe28: ldr w8, [x0, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_e2c:
	/* 0xe2c: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_e30:
	/* 0xe30: b.hi f2c <filter_64ty_selector_val+0x1c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xe30, 0xf2c, arm64_l_f2c);
arm64_l_e34:
	/* 0xe34: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_e38:
	/* 0xe38: lsl w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_e3c:
	/* 0xe3c: mov w9, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_e40:
	/* 0xe40: tst w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e44:
	/* 0xe44: b.eq f2c <filter_64ty_selector_val+0x1c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe44, 0xf2c, arm64_l_f2c);
arm64_l_e48:
	/* 0xe48: ldr x8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_e4c:
	/* 0xe4c: ldr x9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_e50:
	/* 0xe50: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e54:
	/* 0xe54: b.le ecc <filter_64ty_selector_val+0x168> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xe54, 0xecc, arm64_l_ecc);
arm64_l_e58:
	/* 0xe58: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_e5c:
	/* 0xe5c: ret */
	ARM64_SIM_A64_RET();
arm64_l_e60:
	/* 0xe60: ldr w10, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_e64:
	/* 0xe64: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_e68:
	/* 0xe68: b.cc ea0 <filter_64ty_selector_val+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xe68, 0xea0, arm64_l_ea0);
arm64_l_e6c:
	/* 0xe6c: ldr x11, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_e70:
	/* 0xe70: cmp x9, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e74:
	/* 0xe74: b.eq db4 <filter_64ty_selector_val+0x50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe74, 0xdb4, arm64_l_db4);
arm64_l_e78:
	/* 0xe78: cmp w10, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_e7c:
	/* 0xe7c: b.cc ea0 <filter_64ty_selector_val+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xe7c, 0xea0, arm64_l_ea0);
arm64_l_e80:
	/* 0xe80: ldr x11, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_e84:
	/* 0xe84: cmp x9, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e88:
	/* 0xe88: b.eq db4 <filter_64ty_selector_val+0x50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe88, 0xdb4, arm64_l_db4);
arm64_l_e8c:
	/* 0xe8c: cmp w10, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_e90:
	/* 0xe90: b.cc ea0 <filter_64ty_selector_val+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xe90, 0xea0, arm64_l_ea0);
arm64_l_e94:
	/* 0xe94: ldr x10, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_e98:
	/* 0xe98: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e9c:
	/* 0xe9c: b.eq db4 <filter_64ty_selector_val+0x50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe9c, 0xdb4, arm64_l_db4);
arm64_l_ea0:
	/* 0xea0: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_ea4:
	/* 0xea4: b.hi 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xea4, 0x10b4, arm64_l_10b4);
arm64_l_ea8:
	/* 0xea8: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_eac:
	/* 0xeac: lsl x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_eb0:
	/* 0xeb0: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_eb4:
	/* 0xeb4: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_eb8:
	/* 0xeb8: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_ebc:
	/* 0xebc: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ec0:
	/* 0xec0: b.eq 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xec0, 0x10b4, arm64_l_10b4);
arm64_l_ec4:
	/* 0xec4: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ec8:
	/* 0xec8: ret */
	ARM64_SIM_A64_RET();
arm64_l_ecc:
	/* 0xecc: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_ed0:
	/* 0xed0: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_ed4:
	/* 0xed4: b.cc 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xed4, 0x10b4, arm64_l_10b4);
arm64_l_ed8:
	/* 0xed8: ldr x10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_edc:
	/* 0xedc: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ee0:
	/* 0xee0: b.le f9c <filter_64ty_selector_val+0x238> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xee0, 0xf9c, arm64_l_f9c);
arm64_l_ee4:
	/* 0xee4: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ee8:
	/* 0xee8: ret */
	ARM64_SIM_A64_RET();
arm64_l_eec:
	/* 0xeec: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_ef0:
	/* 0xef0: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_ef4:
	/* 0xef4: b.cc 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xef4, 0x10b4, arm64_l_10b4);
arm64_l_ef8:
	/* 0xef8: ldr x10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_efc:
	/* 0xefc: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f00:
	/* 0xf00: b.ge fb8 <filter_64ty_selector_val+0x254> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0xf00, 0xfb8, arm64_l_fb8);
arm64_l_f04:
	/* 0xf04: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f08:
	/* 0xf08: ret */
	ARM64_SIM_A64_RET();
arm64_l_f0c:
	/* 0xf0c: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_f10:
	/* 0xf10: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_f14:
	/* 0xf14: b.cc 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xf14, 0x10b4, arm64_l_10b4);
arm64_l_f18:
	/* 0xf18: ldr x10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_f1c:
	/* 0xf1c: tst x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f20:
	/* 0xf20: b.eq fd4 <filter_64ty_selector_val+0x270> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf20, 0xfd4, arm64_l_fd4);
arm64_l_f24:
	/* 0xf24: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f28:
	/* 0xf28: ret */
	ARM64_SIM_A64_RET();
arm64_l_f2c:
	/* 0xf2c: ldr x8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f30:
	/* 0xf30: ldr x9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_f34:
	/* 0xf34: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f38:
	/* 0xf38: b.ls f5c <filter_64ty_selector_val+0x1f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0xf38, 0xf5c, arm64_l_f5c);
arm64_l_f3c:
	/* 0xf3c: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f40:
	/* 0xf40: ret */
	ARM64_SIM_A64_RET();
arm64_l_f44:
	/* 0xf44: ldr x8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f48:
	/* 0xf48: ldr x9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_f4c:
	/* 0xf4c: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f50:
	/* 0xf50: b.cs f7c <filter_64ty_selector_val+0x218> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xf50, 0xf7c, arm64_l_f7c);
arm64_l_f54:
	/* 0xf54: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f58:
	/* 0xf58: ret */
	ARM64_SIM_A64_RET();
arm64_l_f5c:
	/* 0xf5c: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_f60:
	/* 0xf60: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_f64:
	/* 0xf64: b.cc 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xf64, 0x10b4, arm64_l_10b4);
arm64_l_f68:
	/* 0xf68: ldr x10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_f6c:
	/* 0xf6c: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f70:
	/* 0xf70: b.ls ff0 <filter_64ty_selector_val+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0xf70, 0xff0, arm64_l_ff0);
arm64_l_f74:
	/* 0xf74: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f78:
	/* 0xf78: ret */
	ARM64_SIM_A64_RET();
arm64_l_f7c:
	/* 0xf7c: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_f80:
	/* 0xf80: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_f84:
	/* 0xf84: b.cc 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xf84, 0x10b4, arm64_l_10b4);
arm64_l_f88:
	/* 0xf88: ldr x10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_f8c:
	/* 0xf8c: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f90:
	/* 0xf90: b.cs 100c <filter_64ty_selector_val+0x2a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xf90, 0x100c, arm64_l_100c);
arm64_l_f94:
	/* 0xf94: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_f98:
	/* 0xf98: ret */
	ARM64_SIM_A64_RET();
arm64_l_f9c:
	/* 0xf9c: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_fa0:
	/* 0xfa0: b.cc 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xfa0, 0x10b4, arm64_l_10b4);
arm64_l_fa4:
	/* 0xfa4: ldr x10, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_fa8:
	/* 0xfa8: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_fac:
	/* 0xfac: b.le 1028 <filter_64ty_selector_val+0x2c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xfac, 0x1028, arm64_l_1028);
arm64_l_fb0:
	/* 0xfb0: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_fb4:
	/* 0xfb4: ret */
	ARM64_SIM_A64_RET();
arm64_l_fb8:
	/* 0xfb8: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_fbc:
	/* 0xfbc: b.cc 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xfbc, 0x10b4, arm64_l_10b4);
arm64_l_fc0:
	/* 0xfc0: ldr x10, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_fc4:
	/* 0xfc4: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_fc8:
	/* 0xfc8: b.ge 1044 <filter_64ty_selector_val+0x2e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0xfc8, 0x1044, arm64_l_1044);
arm64_l_fcc:
	/* 0xfcc: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_fd0:
	/* 0xfd0: ret */
	ARM64_SIM_A64_RET();
arm64_l_fd4:
	/* 0xfd4: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_fd8:
	/* 0xfd8: b.cc 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xfd8, 0x10b4, arm64_l_10b4);
arm64_l_fdc:
	/* 0xfdc: ldr x10, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_fe0:
	/* 0xfe0: tst x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_fe4:
	/* 0xfe4: b.eq 1060 <filter_64ty_selector_val+0x2fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xfe4, 0x1060, arm64_l_1060);
arm64_l_fe8:
	/* 0xfe8: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_fec:
	/* 0xfec: ret */
	ARM64_SIM_A64_RET();
arm64_l_ff0:
	/* 0xff0: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_ff4:
	/* 0xff4: b.cc 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xff4, 0x10b4, arm64_l_10b4);
arm64_l_ff8:
	/* 0xff8: ldr x10, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_ffc:
	/* 0xffc: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1000:
	/* 0x1000: b.ls 107c <filter_64ty_selector_val+0x318> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1000, 0x107c, arm64_l_107c);
arm64_l_1004:
	/* 0x1004: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1008:
	/* 0x1008: ret */
	ARM64_SIM_A64_RET();
arm64_l_100c:
	/* 0x100c: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_1010:
	/* 0x1010: b.cc 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1010, 0x10b4, arm64_l_10b4);
arm64_l_1014:
	/* 0x1014: ldr x10, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1018:
	/* 0x1018: cmp x8, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_101c:
	/* 0x101c: b.cs 1098 <filter_64ty_selector_val+0x334> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x101c, 0x1098, arm64_l_1098);
arm64_l_1020:
	/* 0x1020: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1024:
	/* 0x1024: ret */
	ARM64_SIM_A64_RET();
arm64_l_1028:
	/* 0x1028: cmp w9, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_102c:
	/* 0x102c: b.cc 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x102c, 0x10b4, arm64_l_10b4);
arm64_l_1030:
	/* 0x1030: ldr x9, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1034:
	/* 0x1034: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1038:
	/* 0x1038: b.le 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1038, 0x10b4, arm64_l_10b4);
arm64_l_103c:
	/* 0x103c: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1040:
	/* 0x1040: ret */
	ARM64_SIM_A64_RET();
arm64_l_1044:
	/* 0x1044: cmp w9, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_1048:
	/* 0x1048: b.cc 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1048, 0x10b4, arm64_l_10b4);
arm64_l_104c:
	/* 0x104c: ldr x9, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1050:
	/* 0x1050: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1054:
	/* 0x1054: b.ge 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x1054, 0x10b4, arm64_l_10b4);
arm64_l_1058:
	/* 0x1058: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_105c:
	/* 0x105c: ret */
	ARM64_SIM_A64_RET();
arm64_l_1060:
	/* 0x1060: cmp w9, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_1064:
	/* 0x1064: b.cc 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1064, 0x10b4, arm64_l_10b4);
arm64_l_1068:
	/* 0x1068: ldr x9, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_106c:
	/* 0x106c: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1070:
	/* 0x1070: b.eq 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1070, 0x10b4, arm64_l_10b4);
arm64_l_1074:
	/* 0x1074: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1078:
	/* 0x1078: ret */
	ARM64_SIM_A64_RET();
arm64_l_107c:
	/* 0x107c: cmp w9, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_1080:
	/* 0x1080: b.cc 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1080, 0x10b4, arm64_l_10b4);
arm64_l_1084:
	/* 0x1084: ldr x9, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1088:
	/* 0x1088: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_108c:
	/* 0x108c: b.ls 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x108c, 0x10b4, arm64_l_10b4);
arm64_l_1090:
	/* 0x1090: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1094:
	/* 0x1094: ret */
	ARM64_SIM_A64_RET();
arm64_l_1098:
	/* 0x1098: cmp w9, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_109c:
	/* 0x109c: b.cc 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x109c, 0x10b4, arm64_l_10b4);
arm64_l_10a0:
	/* 0x10a0: ldr x9, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_10a4:
	/* 0x10a4: cmp x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_10a8:
	/* 0x10a8: b.cs 10b4 <filter_64ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x10a8, 0x10b4, arm64_l_10b4);
arm64_l_10ac:
	/* 0x10ac: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_10b0:
	/* 0x10b0: ret */
	ARM64_SIM_A64_RET();
arm64_l_10b4:
	/* 0x10b4: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10b8:
	/* 0x10b8: ret */
	ARM64_SIM_A64_RET();
arm64_l_10bc:
	/* 0x10bc: ldr w9, [x0, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_10c0:
	/* 0x10c0: ldr w8, [x0, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_10c4:
	/* 0x10c4: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_10c8:
	/* 0x10c8: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_10cc:
	/* 0x10cc: lsl w9, w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_10d0:
	/* 0x10d0: mov w10, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_10d4:
	/* 0x10d4: and w9, w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_10d8:
	/* 0x10d8: ccmp w9, #0x0, #0x4, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 4), 0ULL);
arm64_l_10dc:
	/* 0x10dc: b.eq 11dc <filter_64ty_range+0x120> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x10dc, 0x11dc, arm64_l_11dc);
arm64_l_10e0:
	/* 0x10e0: ldr x10, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_10e4:
	/* 0x10e4: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_10e8:
	/* 0x10e8: b.ne 1170 <filter_64ty_range+0xb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x10e8, 0x1170, arm64_l_1170);
arm64_l_10ec:
	/* 0x10ec: ldr x9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_10f0:
	/* 0x10f0: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_10f4:
	/* 0x10f4: b.gt 1104 <filter_64ty_range+0x48> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x10f4, 0x1104, arm64_l_1104);
arm64_l_10f8:
	/* 0x10f8: ldr x9, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_10fc:
	/* 0x10fc: cmp x10, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1100:
	/* 0x1100: b.le 1200 <filter_64ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1100, 0x1200, arm64_l_1200);
arm64_l_1104:
	/* 0x1104: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1108:
	/* 0x1108: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_110c:
	/* 0x110c: b.cc 12ec <filter_64ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x110c, 0x12ec, arm64_l_12ec);
arm64_l_1110:
	/* 0x1110: ldr x11, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1114:
	/* 0x1114: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1118:
	/* 0x1118: b.gt 1128 <filter_64ty_range+0x6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1118, 0x1128, arm64_l_1128);
arm64_l_111c:
	/* 0x111c: ldr x11, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1120:
	/* 0x1120: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1124:
	/* 0x1124: b.le 1200 <filter_64ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1124, 0x1200, arm64_l_1200);
arm64_l_1128:
	/* 0x1128: cmp w9, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_112c:
	/* 0x112c: b.cc 12ec <filter_64ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x112c, 0x12ec, arm64_l_12ec);
arm64_l_1130:
	/* 0x1130: ldr x11, [x0, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1134:
	/* 0x1134: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1138:
	/* 0x1138: b.gt 1148 <filter_64ty_range+0x8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1138, 0x1148, arm64_l_1148);
arm64_l_113c:
	/* 0x113c: ldr x11, [x0, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1140:
	/* 0x1140: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1144:
	/* 0x1144: b.le 1200 <filter_64ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1144, 0x1200, arm64_l_1200);
arm64_l_1148:
	/* 0x1148: cmp w9, #0x39 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 57ULL);
arm64_l_114c:
	/* 0x114c: b.cc 12ec <filter_64ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x114c, 0x12ec, arm64_l_12ec);
arm64_l_1150:
	/* 0x1150: ldr x11, [x0, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1154:
	/* 0x1154: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1158:
	/* 0x1158: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_115c:
	/* 0x115c: b.gt 12dc <filter_64ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x115c, 0x12dc, arm64_l_12dc);
arm64_l_1160:
	/* 0x1160: ldr x11, [x0, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1164:
	/* 0x1164: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1168:
	/* 0x1168: b.le 1200 <filter_64ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1168, 0x1200, arm64_l_1200);
arm64_l_116c:
	/* 0x116c: b 12dc <filter_64ty_range+0x220> */
	ARM64_SIM_A64_JMP(0x116c, 0x12dc, arm64_l_12dc);
arm64_l_1170:
	/* 0x1170: ldp x9, x12, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X9, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1174:
	/* 0x1174: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1178:
	/* 0x1178: ldr w11, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_117c:
	/* 0x117c: ccmp x10, x12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_1180:
	/* 0x1180: cset w9, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_1184:
	/* 0x1184: cmp w11, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_1188:
	/* 0x1188: b.cc 12dc <filter_64ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1188, 0x12dc, arm64_l_12dc);
arm64_l_118c:
	/* 0x118c: ldp x12, x13, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1190:
	/* 0x1190: cmp x12, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1194:
	/* 0x1194: ccmp x10, x13, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_1198:
	/* 0x1198: csinc w9, w9, wzr, gt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_GT, 0);
arm64_l_119c:
	/* 0x119c: cmp w11, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_11a0:
	/* 0x11a0: b.cc 12dc <filter_64ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x11a0, 0x12dc, arm64_l_12dc);
arm64_l_11a4:
	/* 0x11a4: ldp x12, x13, [x0, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_11a8:
	/* 0x11a8: cmp x12, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_11ac:
	/* 0x11ac: ccmp x10, x13, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_11b0:
	/* 0x11b0: csinc w9, w9, wzr, gt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_GT, 0);
arm64_l_11b4:
	/* 0x11b4: cmp w11, #0x39 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 57ULL);
arm64_l_11b8:
	/* 0x11b8: b.cc 12dc <filter_64ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x11b8, 0x12dc, arm64_l_12dc);
arm64_l_11bc:
	/* 0x11bc: ldp x11, x12, [x0, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_11c0:
	/* 0x11c0: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_11c4:
	/* 0x11c4: ccmp x10, x12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_11c8:
	/* 0x11c8: csinc w9, w9, wzr, gt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_GT, 0);
arm64_l_11cc:
	/* 0x11cc: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_11d0:
	/* 0x11d0: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_11d4:
	/* 0x11d4: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_11d8:
	/* 0x11d8: ret */
	ARM64_SIM_A64_RET();
arm64_l_11dc:
	/* 0x11dc: ldr x10, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_11e0:
	/* 0x11e0: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_11e4:
	/* 0x11e4: b.ne 1208 <filter_64ty_range+0x14c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x11e4, 0x1208, arm64_l_1208);
arm64_l_11e8:
	/* 0x11e8: ldr x9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_11ec:
	/* 0x11ec: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_11f0:
	/* 0x11f0: b.hi 1274 <filter_64ty_range+0x1b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x11f0, 0x1274, arm64_l_1274);
arm64_l_11f4:
	/* 0x11f4: ldr x9, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_11f8:
	/* 0x11f8: cmp x10, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_11fc:
	/* 0x11fc: b.hi 1274 <filter_64ty_range+0x1b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x11fc, 0x1274, arm64_l_1274);
arm64_l_1200:
	/* 0x1200: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1204:
	/* 0x1204: ret */
	ARM64_SIM_A64_RET();
arm64_l_1208:
	/* 0x1208: ldp x9, x12, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X9, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_120c:
	/* 0x120c: cmp x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1210:
	/* 0x1210: ldr w11, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1214:
	/* 0x1214: ccmp x10, x12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_1218:
	/* 0x1218: cset w9, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_121c:
	/* 0x121c: cmp w11, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_1220:
	/* 0x1220: b.cc 12dc <filter_64ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1220, 0x12dc, arm64_l_12dc);
arm64_l_1224:
	/* 0x1224: ldp x12, x13, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1228:
	/* 0x1228: cmp x12, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_122c:
	/* 0x122c: ccmp x10, x13, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_1230:
	/* 0x1230: csinc w9, w9, wzr, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_1234:
	/* 0x1234: cmp w11, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1238:
	/* 0x1238: b.cc 12dc <filter_64ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1238, 0x12dc, arm64_l_12dc);
arm64_l_123c:
	/* 0x123c: ldp x12, x13, [x0, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1240:
	/* 0x1240: cmp x12, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1244:
	/* 0x1244: ccmp x10, x13, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_1248:
	/* 0x1248: csinc w9, w9, wzr, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_124c:
	/* 0x124c: cmp w11, #0x39 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 57ULL);
arm64_l_1250:
	/* 0x1250: b.cc 12dc <filter_64ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1250, 0x12dc, arm64_l_12dc);
arm64_l_1254:
	/* 0x1254: ldp x11, x12, [x0, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1258:
	/* 0x1258: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_125c:
	/* 0x125c: ccmp x10, x12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_1260:
	/* 0x1260: csinc w9, w9, wzr, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_1264:
	/* 0x1264: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_1268:
	/* 0x1268: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_126c:
	/* 0x126c: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1270:
	/* 0x1270: ret */
	ARM64_SIM_A64_RET();
arm64_l_1274:
	/* 0x1274: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1278:
	/* 0x1278: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_127c:
	/* 0x127c: b.cc 12ec <filter_64ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x127c, 0x12ec, arm64_l_12ec);
arm64_l_1280:
	/* 0x1280: ldr x11, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1284:
	/* 0x1284: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1288:
	/* 0x1288: b.hi 1298 <filter_64ty_range+0x1dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1288, 0x1298, arm64_l_1298);
arm64_l_128c:
	/* 0x128c: ldr x11, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1290:
	/* 0x1290: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1294:
	/* 0x1294: b.ls 1200 <filter_64ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1294, 0x1200, arm64_l_1200);
arm64_l_1298:
	/* 0x1298: cmp w9, #0x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_129c:
	/* 0x129c: b.cc 12ec <filter_64ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x129c, 0x12ec, arm64_l_12ec);
arm64_l_12a0:
	/* 0x12a0: ldr x11, [x0, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_12a4:
	/* 0x12a4: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_12a8:
	/* 0x12a8: b.hi 12b8 <filter_64ty_range+0x1fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x12a8, 0x12b8, arm64_l_12b8);
arm64_l_12ac:
	/* 0x12ac: ldr x11, [x0, #56] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_12b0:
	/* 0x12b0: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_12b4:
	/* 0x12b4: b.ls 1200 <filter_64ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x12b4, 0x1200, arm64_l_1200);
arm64_l_12b8:
	/* 0x12b8: cmp w9, #0x39 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 57ULL);
arm64_l_12bc:
	/* 0x12bc: b.cc 12ec <filter_64ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x12bc, 0x12ec, arm64_l_12ec);
arm64_l_12c0:
	/* 0x12c0: ldr x11, [x0, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_12c4:
	/* 0x12c4: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_12c8:
	/* 0x12c8: cmp x11, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_12cc:
	/* 0x12cc: b.hi 12dc <filter_64ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x12cc, 0x12dc, arm64_l_12dc);
arm64_l_12d0:
	/* 0x12d0: ldr x11, [x0, #72] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_12d4:
	/* 0x12d4: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_12d8:
	/* 0x12d8: b.ls 1200 <filter_64ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x12d8, 0x1200, arm64_l_1200);
arm64_l_12dc:
	/* 0x12dc: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_12e0:
	/* 0x12e0: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_12e4:
	/* 0x12e4: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_12e8:
	/* 0x12e8: ret */
	ARM64_SIM_A64_RET();
arm64_l_12ec:
	/* 0x12ec: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_12f0:
	/* 0x12f0: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_12f4:
	/* 0x12f4: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_12f8:
	/* 0x12f8: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_12fc:
	/* 0x12fc: ret */
	ARM64_SIM_A64_RET();
arm64_l_1300:
	/* 0x1300: sub sp, sp, #0x30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_1304:
	/* 0x1304: str x30, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1308:
	/* 0x1308: stp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_130c:
	/* 0x130c: ldrb w8, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1310:
	/* 0x1310: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1314:
	/* 0x1314: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_1318:
	/* 0x1318: add x9, sp, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_131c:
	/* 0x131c: str w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_1320:
	/* 0x1320: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1324:
	/* 0x1324: mov x20, x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1328:
	/* 0x1328: add x1, sp, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_132c:
	/* 0x132c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1330:
	/* 0x1330: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_1334:
	/* 0x1334: cbz x0, 1384 <filter_64ty_map+0x84> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1334, 0x1384, arm64_l_1384);
arm64_l_1338:
	/* 0x1338: ldr x8, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_133c:
	/* 0x133c: add x9, sp, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1340:
	/* 0x1340: add x1, sp, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1344:
	/* 0x1344: str x8, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1348:
	/* 0x1348: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_134c:
	/* 0x134c: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_1350:
	/* 0x1350: ldr w8, [x19, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1354:
	/* 0x1354: cmp w8, #0xb */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 11ULL);
arm64_l_1358:
	/* 0x1358: b.eq 1370 <filter_64ty_map+0x70> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1358, 0x1370, arm64_l_1370);
arm64_l_135c:
	/* 0x135c: cmp w8, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1360:
	/* 0x1360: b.ne 137c <filter_64ty_map+0x7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1360, 0x137c, arm64_l_137c);
arm64_l_1364:
	/* 0x1364: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1368:
	/* 0x1368: cset w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_136c:
	/* 0x136c: b 1380 <filter_64ty_map+0x80> */
	ARM64_SIM_A64_JMP(0x136c, 0x1380, arm64_l_1380);
arm64_l_1370:
	/* 0x1370: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1374:
	/* 0x1374: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1378:
	/* 0x1378: b 1380 <filter_64ty_map+0x80> */
	ARM64_SIM_A64_JMP(0x1378, 0x1380, arm64_l_1380);
arm64_l_137c:
	/* 0x137c: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1380:
	/* 0x1380: mov w0, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1384:
	/* 0x1384: ldp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1388:
	/* 0x1388: ldr x30, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_138c:
	/* 0x138c: add sp, sp, #0x30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_1390:
	/* 0x1390: ret */
	ARM64_SIM_A64_RET();
arm64_l_1394:
	/* 0x1394: sub sp, sp, #0x30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_1398:
	/* 0x1398: stp x30, x21, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_139c:
	/* 0x139c: stp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_13a0:
	/* 0x13a0: stp wzr, w0, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_13a4:
	/* 0x13a4: adrp x0, 0 <string_postfix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_20));
arm64_l_13a8:
	/* 0x13a8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_13ac:
	/* 0x13ac: add x9, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_13b0:
	/* 0x13b0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_13b4:
	/* 0x13b4: mov x19, x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_13b8:
	/* 0x13b8: add x1, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_13bc:
	/* 0x13bc: mov w20, w2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_13c0:
	/* 0x13c0: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_13c4:
	/* 0x13c4: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_13c8:
	/* 0x13c8: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_13cc:
	/* 0x13cc: cbz w20, 1454 <filter_char_buf_postfix+0xc0> */
	ARM64_SIM_A64_CBZ(ARM64_X20, 0x13cc, 0x1454, arm64_l_1454);
arm64_l_13d0:
	/* 0x13d0: cbz x8, 1454 <filter_char_buf_postfix+0xc0> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x13d0, 0x1454, arm64_l_1454);
arm64_l_13d4:
	/* 0x13d4: adrp x0, 0 <string_postfix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_postfix_maps_heap_21));
arm64_l_13d8:
	/* 0x13d8: mov x21, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_13dc:
	/* 0x13dc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_13e0:
	/* 0x13e0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_13e4:
	/* 0x13e4: add x9, sp, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_13e8:
	/* 0x13e8: add x1, sp, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_13ec:
	/* 0x13ec: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_13f0:
	/* 0x13f0: cbz x0, 1454 <filter_char_buf_postfix+0xc0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x13f0, 0x1454, arm64_l_1454);
arm64_l_13f4:
	/* 0x13f4: cmp w20, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_13f8:
	/* 0x13f8: mov w9, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 127ULL);
arm64_l_13fc:
	/* 0x13fc: mov x1, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1400:
	/* 0x1400: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1404:
	/* 0x1404: sub w10, w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1408:
	/* 0x1408: csel w9, w20, w9, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X9, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_140c:
	/* 0x140c: lsl w9, w9, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_1410:
	/* 0x1410: str w9, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1414:
	/* 0x1414: mov w9, w20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1418:
	/* 0x1418: cmp x8, #0x7f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 127ULL);
arm64_l_141c:
	/* 0x141c: b.eq 1440 <filter_char_buf_postfix+0xac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x141c, 0x1440, arm64_l_1440);
arm64_l_1420:
	/* 0x1420: and x11, x10, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1424:
	/* 0x1424: add x12, x1, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1428:
	/* 0x1428: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_142c:
	/* 0x142c: ldrb w11, [x19, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X19, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1430:
	/* 0x1430: sub w10, w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1434:
	/* 0x1434: cmp x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1438:
	/* 0x1438: strb w11, [x12, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X12, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_143c:
	/* 0x143c: b.ne 1418 <filter_char_buf_postfix+0x84> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x143c, 0x1418, arm64_l_1418);
arm64_l_1440:
	/* 0x1440: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1444:
	/* 0x1444: mov x0, x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1448:
	/* 0x1448: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_144c:
	/* 0x144c: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1450:
	/* 0x1450: cset w0, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1454:
	/* 0x1454: ldp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1458:
	/* 0x1458: ldp x30, x21, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_145c:
	/* 0x145c: add sp, sp, #0x30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_1460:
	/* 0x1460: ret */
	ARM64_SIM_A64_RET();
arm64_l_1464:
	/* 0x1464: sub sp, sp, #0x30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_1468:
	/* 0x1468: stp x30, x21, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_146c:
	/* 0x146c: stp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1470:
	/* 0x1470: stp wzr, w0, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1474:
	/* 0x1474: adrp x0, 0 <string_prefix_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_22));
arm64_l_1478:
	/* 0x1478: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_147c:
	/* 0x147c: add x9, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1480:
	/* 0x1480: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1484:
	/* 0x1484: mov x19, x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1488:
	/* 0x1488: add x1, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_148c:
	/* 0x148c: mov w20, w2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1490:
	/* 0x1490: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_1494:
	/* 0x1494: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1498:
	/* 0x1498: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_149c:
	/* 0x149c: cbz w20, 1508 <filter_char_buf_prefix+0xa4> */
	ARM64_SIM_A64_CBZ(ARM64_X20, 0x149c, 0x1508, arm64_l_1508);
arm64_l_14a0:
	/* 0x14a0: cbz x8, 1508 <filter_char_buf_prefix+0xa4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x14a0, 0x1508, arm64_l_1508);
arm64_l_14a4:
	/* 0x14a4: adrp x0, 0 <string_prefix_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_prefix_maps_heap_23));
arm64_l_14a8:
	/* 0x14a8: mov x21, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14ac:
	/* 0x14ac: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_14b0:
	/* 0x14b0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_14b4:
	/* 0x14b4: add x9, sp, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_14b8:
	/* 0x14b8: add x1, sp, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_14bc:
	/* 0x14bc: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_14c0:
	/* 0x14c0: cbz x0, 1508 <filter_char_buf_prefix+0xa4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x14c0, 0x1508, arm64_l_1508);
arm64_l_14c4:
	/* 0x14c4: cmp w20, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_14c8:
	/* 0x14c8: mov w8, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 255ULL);
arm64_l_14cc:
	/* 0x14cc: mov x2, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14d0:
	/* 0x14d0: csel w1, w20, w8, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X1, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_14d4:
	/* 0x14d4: mov x8, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14d8:
	/* 0x14d8: mov x20, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14dc:
	/* 0x14dc: lsl w9, w1, #3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_14e0:
	/* 0x14e0: str w9, [x8], #4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_14e4:
	/* 0x14e4: mov w9, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14e8:
	/* 0x14e8: mov x0, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14ec:
	/* 0x14ec: blr x9 */
	ARM64_SIM_BPF_CALL_bpf_probe_read();
arm64_l_14f0:
	/* 0x14f0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_14f4:
	/* 0x14f4: mov x0, x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14f8:
	/* 0x14f8: mov x1, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_14fc:
	/* 0x14fc: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_1500:
	/* 0x1500: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1504:
	/* 0x1504: cset w0, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1508:
	/* 0x1508: ldp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_150c:
	/* 0x150c: ldp x30, x21, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1510:
	/* 0x1510: add sp, sp, #0x30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_1514:
	/* 0x1514: ret */
	ARM64_SIM_A64_RET();
arm64_l_1518:
	/* 0x1518: str x29, [sp, #-80]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551536ULL);
arm64_l_151c:
	/* 0x151c: stp x30, x25, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1520:
	/* 0x1520: stp x24, x23, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1524:
	/* 0x1524: stp x22, x21, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1528:
	/* 0x1528: stp x20, x19, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_152c:
	/* 0x152c: cmp w2, #0x1, lsl #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_1530:
	/* 0x1530: str wzr, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1534:
	/* 0x1534: b.ls 1554 <filter_char_buf_equal+0x3c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1534, 0x1554, arm64_l_1554);
arm64_l_1538:
	/* 0x1538: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_153c:
	/* 0x153c: ldp x20, x19, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1540:
	/* 0x1540: ldp x22, x21, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1544:
	/* 0x1544: ldp x24, x23, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1548:
	/* 0x1548: ldp x30, x25, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_154c:
	/* 0x154c: ldr x29, [sp], #80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 80ULL);
arm64_l_1550:
	/* 0x1550: ret */
	ARM64_SIM_A64_RET();
arm64_l_1554:
	/* 0x1554: and w9, w2, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1558:
	/* 0x1558: add x8, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_155c:
	/* 0x155c: cmp w9, #0x90 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1560:
	/* 0x1560: b.hi 15d0 <filter_char_buf_equal+0xb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1560, 0x15d0, arm64_l_15d0);
arm64_l_1564:
	/* 0x1564: and w9, w2, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1568:
	/* 0x1568: mov w10, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_156c:
	/* 0x156c: tst w2, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1570:
	/* 0x1570: mul w9, w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1574:
	/* 0x1574: mov w10, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_1578:
	/* 0x1578: lsr w9, w9, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_157c:
	/* 0x157c: msub w9, w9, w10, w2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MSUB, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_X2, ARM64_WIDTH_32, 0, 0);
arm64_l_1580:
	/* 0x1580: b.eq 1590 <filter_char_buf_equal+0x78> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1580, 0x1590, arm64_l_1590);
arm64_l_1584:
	/* 0x1584: tst w9, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1588:
	/* 0x1588: mov w23, w2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_158c:
	/* 0x158c: b.eq 15a8 <filter_char_buf_equal+0x90> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x158c, 0x15a8, arm64_l_15a8);
arm64_l_1590:
	/* 0x1590: sub w9, w2, w9, uxtb */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X2, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_UXTB, 0), 0);
arm64_l_1594:
	/* 0x1594: and w10, w9, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1598:
	/* 0x1598: add w9, w9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_159c:
	/* 0x159c: and w23, w9, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_15a0:
	/* 0x15a0: cmp w10, #0x78 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 120ULL);
arm64_l_15a4:
	/* 0x15a4: b.hi 1644 <filter_char_buf_equal+0x12c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x15a4, 0x1644, arm64_l_1644);
arm64_l_15a8:
	/* 0x15a8: and w9, w23, #0xff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_15ac:
	/* 0x15ac: mov w10, #0xab */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 171ULL);
arm64_l_15b0:
	/* 0x15b0: mul w9, w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MUL, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_15b4:
	/* 0x15b4: lsr w9, w9, #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 12ULL);
arm64_l_15b8:
	/* 0x15b8: sub w22, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_15bc:
	/* 0x15bc: and w9, w22, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_15c0:
	/* 0x15c0: ldr w24, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_15c4:
	/* 0x15c4: cmn w24, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_15c8:
	/* 0x15c8: b.ne 16bc <filter_char_buf_equal+0x1a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x15c8, 0x16bc, arm64_l_16bc);
arm64_l_15cc:
	/* 0x15cc: b 1864 <filter_char_buf_equal+0x34c> */
	ARM64_SIM_A64_JMP(0x15cc, 0x1864, arm64_l_1864);
arm64_l_15d0:
	/* 0x15d0: cmp w9, #0x101 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 257ULL);
arm64_l_15d4:
	/* 0x15d4: b.cs 1614 <filter_char_buf_equal+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x15d4, 0x1614, arm64_l_1614);
arm64_l_15d8:
	/* 0x15d8: mov w23, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_15dc:
	/* 0x15dc: sub w9, w23, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_15e0:
	/* 0x15e0: ror w9, w9, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_ROR), 8ULL);
arm64_l_15e4:
	/* 0x15e4: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_15e8:
	/* 0x15e8: b.le 1654 <filter_char_buf_equal+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x15e8, 0x1654, arm64_l_1654);
arm64_l_15ec:
	/* 0x15ec: cmp w9, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_15f0:
	/* 0x15f0: b.eq 1690 <filter_char_buf_equal+0x178> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x15f0, 0x1690, arm64_l_1690);
arm64_l_15f4:
	/* 0x15f4: cmp w9, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_15f8:
	/* 0x15f8: b.ne 1678 <filter_char_buf_equal+0x160> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x15f8, 0x1678, arm64_l_1678);
arm64_l_15fc:
	/* 0x15fc: mov w22, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 9ULL);
arm64_l_1600:
	/* 0x1600: and w9, w22, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_1604:
	/* 0x1604: ldr w24, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_1608:
	/* 0x1608: cmn w24, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_160c:
	/* 0x160c: b.ne 16bc <filter_char_buf_equal+0x1a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x160c, 0x16bc, arm64_l_16bc);
arm64_l_1610:
	/* 0x1610: b 1864 <filter_char_buf_equal+0x34c> */
	ARM64_SIM_A64_JMP(0x1610, 0x1864, arm64_l_1864);
arm64_l_1614:
	/* 0x1614: and w9, w2, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1618:
	/* 0x1618: cmp w9, #0x201 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 513ULL);
arm64_l_161c:
	/* 0x161c: b.cs 1638 <filter_char_buf_equal+0x120> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x161c, 0x1638, arm64_l_1638);
arm64_l_1620:
	/* 0x1620: mov w23, #0x200 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 512ULL);
arm64_l_1624:
	/* 0x1624: sub w9, w23, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_1628:
	/* 0x1628: ror w9, w9, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_ROR), 8ULL);
arm64_l_162c:
	/* 0x162c: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1630:
	/* 0x1630: b.le 1654 <filter_char_buf_equal+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1630, 0x1654, arm64_l_1654);
arm64_l_1634:
	/* 0x1634: b 15ec <filter_char_buf_equal+0xd4> */
	ARM64_SIM_A64_JMP(0x1634, 0x15ec, arm64_l_15ec);
arm64_l_1638:
	/* 0x1638: cmp w9, #0x401 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1025ULL);
arm64_l_163c:
	/* 0x163c: b.cs 181c <filter_char_buf_equal+0x304> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x163c, 0x181c, arm64_l_181c);
arm64_l_1640:
	/* 0x1640: mov w23, #0x400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1024ULL);
arm64_l_1644:
	/* 0x1644: sub w9, w23, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_1648:
	/* 0x1648: ror w9, w9, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_ROR), 8ULL);
arm64_l_164c:
	/* 0x164c: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1650:
	/* 0x1650: b.gt 15ec <filter_char_buf_equal+0xd4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1650, 0x15ec, arm64_l_15ec);
arm64_l_1654:
	/* 0x1654: cbz w9, 16a8 <filter_char_buf_equal+0x190> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x1654, 0x16a8, arm64_l_16a8);
arm64_l_1658:
	/* 0x1658: cmp w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_165c:
	/* 0x165c: b.ne 1678 <filter_char_buf_equal+0x160> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x165c, 0x1678, arm64_l_1678);
arm64_l_1660:
	/* 0x1660: mov w22, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 7ULL);
arm64_l_1664:
	/* 0x1664: and w9, w22, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_1668:
	/* 0x1668: ldr w24, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_166c:
	/* 0x166c: cmn w24, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1670:
	/* 0x1670: b.ne 16bc <filter_char_buf_equal+0x1a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1670, 0x16bc, arm64_l_16bc);
arm64_l_1674:
	/* 0x1674: b 1864 <filter_char_buf_equal+0x34c> */
	ARM64_SIM_A64_JMP(0x1674, 0x1864, arm64_l_1864);
arm64_l_1678:
	/* 0x1678: mov w22, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_167c:
	/* 0x167c: and w9, w22, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_1680:
	/* 0x1680: ldr w24, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_1684:
	/* 0x1684: cmn w24, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1688:
	/* 0x1688: b.ne 16bc <filter_char_buf_equal+0x1a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1688, 0x16bc, arm64_l_16bc);
arm64_l_168c:
	/* 0x168c: b 1864 <filter_char_buf_equal+0x34c> */
	ARM64_SIM_A64_JMP(0x168c, 0x1864, arm64_l_1864);
arm64_l_1690:
	/* 0x1690: mov w22, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1694:
	/* 0x1694: and w9, w22, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_1698:
	/* 0x1698: ldr w24, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_169c:
	/* 0x169c: cmn w24, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_16a0:
	/* 0x16a0: b.ne 16bc <filter_char_buf_equal+0x1a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x16a0, 0x16bc, arm64_l_16bc);
arm64_l_16a4:
	/* 0x16a4: b 1864 <filter_char_buf_equal+0x34c> */
	ARM64_SIM_A64_JMP(0x16a4, 0x1864, arm64_l_1864);
arm64_l_16a8:
	/* 0x16a8: mov w22, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 6ULL);
arm64_l_16ac:
	/* 0x16ac: and w9, w22, #0xf */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_16b0:
	/* 0x16b0: ldr w24, [x8, w9, uxtw #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_UXTW, 2, 0), 0ULL);
arm64_l_16b4:
	/* 0x16b4: cmn w24, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMN_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_16b8:
	/* 0x16b8: b.eq 1864 <filter_char_buf_equal+0x34c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x16b8, 0x1864, arm64_l_1864);
arm64_l_16bc:
	/* 0x16bc: adrp x0, 0 <string_maps_heap> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_heap_19));
arm64_l_16c0:
	/* 0x16c0: add x29, sp, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_16c4:
	/* 0x16c4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_16c8:
	/* 0x16c8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_16cc:
	/* 0x16cc: mov x25, x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_16d0:
	/* 0x16d0: add x1, sp, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_16d4:
	/* 0x16d4: mov w21, w2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_16d8:
	/* 0x16d8: mov w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_16dc:
	/* 0x16dc: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_16e0:
	/* 0x16e0: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_16e4:
	/* 0x16e4: adrp x0, 0 <heap_ro_zero> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&heap_ro_zero_4));
arm64_l_16e8:
	/* 0x16e8: add x1, sp, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_16ec:
	/* 0x16ec: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_16f0:
	/* 0x16f0: blr x20 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_16f4:
	/* 0x16f4: mov x20, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_16f8:
	/* 0x16f8: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_16fc:
	/* 0x16fc: cbz x19, 153c <filter_char_buf_equal+0x24> */
	ARM64_SIM_A64_CBZ(ARM64_X19, 0x16fc, 0x153c, arm64_l_153c);
arm64_l_1700:
	/* 0x1700: cbz x20, 153c <filter_char_buf_equal+0x24> */
	ARM64_SIM_A64_CBZ(ARM64_X20, 0x1700, 0x153c, arm64_l_153c);
arm64_l_1704:
	/* 0x1704: mov x0, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1708:
	/* 0x1708: cmp w22, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_170c:
	/* 0x170c: b.gt 1744 <filter_char_buf_equal+0x22c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x170c, 0x1744, arm64_l_1744);
arm64_l_1710:
	/* 0x1710: strb w21, [x0], #1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 1ULL);
arm64_l_1714:
	/* 0x1714: mov w29, w21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1718:
	/* 0x1718: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_171c:
	/* 0x171c: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1720:
	/* 0x1720: mov w1, w21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1724:
	/* 0x1724: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_probe_read();
arm64_l_1728:
	/* 0x1728: subs w8, w23, w21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_172c:
	/* 0x172c: b.ls 177c <filter_char_buf_equal+0x264> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x172c, 0x177c, arm64_l_177c);
arm64_l_1730:
	/* 0x1730: add x9, x19, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X19, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1734:
	/* 0x1734: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1738:
	/* 0x1738: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_173c:
	/* 0x173c: add x0, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1740:
	/* 0x1740: b 1774 <filter_char_buf_equal+0x25c> */
	ARM64_SIM_A64_JMP(0x1740, 0x1774, arm64_l_1774);
arm64_l_1744:
	/* 0x1744: strh w21, [x0], #2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 2ULL);
arm64_l_1748:
	/* 0x1748: mov w29, w21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_174c:
	/* 0x174c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1750:
	/* 0x1750: mov x2, x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1754:
	/* 0x1754: mov w1, w21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1758:
	/* 0x1758: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_probe_read();
arm64_l_175c:
	/* 0x175c: subs w8, w23, w21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1760:
	/* 0x1760: b.ls 177c <filter_char_buf_equal+0x264> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1760, 0x177c, arm64_l_177c);
arm64_l_1764:
	/* 0x1764: add x9, x19, x29 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X19, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1768:
	/* 0x1768: and w1, w8, #0xfff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_176c:
	/* 0x176c: mov w8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1770:
	/* 0x1770: add x0, x9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1774:
	/* 0x1774: mov x2, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1778:
	/* 0x1778: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_probe_read();
arm64_l_177c:
	/* 0x177c: cmp w22, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1780:
	/* 0x1780: str w24, [sp, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1784:
	/* 0x1784: b.le 17bc <filter_char_buf_equal+0x2a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1784, 0x17bc, arm64_l_17bc);
arm64_l_1788:
	/* 0x1788: cmp w22, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_178c:
	/* 0x178c: b.gt 17f0 <filter_char_buf_equal+0x2d8> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x178c, 0x17f0, arm64_l_17f0);
arm64_l_1790:
	/* 0x1790: cmp w22, #0x5 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1794:
	/* 0x1794: b.eq 18e4 <filter_char_buf_equal+0x3cc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1794, 0x18e4, arm64_l_18e4);
arm64_l_1798:
	/* 0x1798: cmp w22, #0x6 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_179c:
	/* 0x179c: b.eq 18a8 <filter_char_buf_equal+0x390> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x179c, 0x18a8, arm64_l_18a8);
arm64_l_17a0:
	/* 0x17a0: cmp w22, #0x7 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_17a4:
	/* 0x17a4: b.ne 1864 <filter_char_buf_equal+0x34c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x17a4, 0x1864, arm64_l_1864);
arm64_l_17a8:
	/* 0x17a8: adrp x0, 0 <string_maps_7> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_7_16));
arm64_l_17ac:
	/* 0x17ac: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_17b0:
	/* 0x17b0: add x9, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_17b4:
	/* 0x17b4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17b8:
	/* 0x17b8: b 1908 <filter_char_buf_equal+0x3f0> */
	ARM64_SIM_A64_JMP(0x17b8, 0x1908, arm64_l_1908);
arm64_l_17bc:
	/* 0x17bc: cmp w22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_17c0:
	/* 0x17c0: b.le 1844 <filter_char_buf_equal+0x32c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x17c0, 0x1844, arm64_l_1844);
arm64_l_17c4:
	/* 0x17c4: cmp w22, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_17c8:
	/* 0x17c8: b.eq 18d0 <filter_char_buf_equal+0x3b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x17c8, 0x18d0, arm64_l_18d0);
arm64_l_17cc:
	/* 0x17cc: cmp w22, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_17d0:
	/* 0x17d0: b.eq 1894 <filter_char_buf_equal+0x37c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x17d0, 0x1894, arm64_l_1894);
arm64_l_17d4:
	/* 0x17d4: cmp w22, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_17d8:
	/* 0x17d8: b.ne 1864 <filter_char_buf_equal+0x34c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x17d8, 0x1864, arm64_l_1864);
arm64_l_17dc:
	/* 0x17dc: adrp x0, 0 <string_maps_4> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_4_13));
arm64_l_17e0:
	/* 0x17e0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_17e4:
	/* 0x17e4: add x9, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_17e8:
	/* 0x17e8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17ec:
	/* 0x17ec: b 1908 <filter_char_buf_equal+0x3f0> */
	ARM64_SIM_A64_JMP(0x17ec, 0x1908, arm64_l_1908);
arm64_l_17f0:
	/* 0x17f0: cmp w22, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_17f4:
	/* 0x17f4: b.eq 18f8 <filter_char_buf_equal+0x3e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x17f4, 0x18f8, arm64_l_18f8);
arm64_l_17f8:
	/* 0x17f8: cmp w22, #0x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_17fc:
	/* 0x17fc: b.eq 18bc <filter_char_buf_equal+0x3a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x17fc, 0x18bc, arm64_l_18bc);
arm64_l_1800:
	/* 0x1800: cmp w22, #0xa */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1804:
	/* 0x1804: b.ne 1864 <filter_char_buf_equal+0x34c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1804, 0x1864, arm64_l_1864);
arm64_l_1808:
	/* 0x1808: adrp x0, 0 <string_maps_10> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_10_10));
arm64_l_180c:
	/* 0x180c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1810:
	/* 0x1810: add x9, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1814:
	/* 0x1814: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1818:
	/* 0x1818: b 1908 <filter_char_buf_equal+0x3f0> */
	ARM64_SIM_A64_JMP(0x1818, 0x1908, arm64_l_1908);
arm64_l_181c:
	/* 0x181c: and w9, w2, #0xffff */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 65535ULL);
arm64_l_1820:
	/* 0x1820: mov w10, #0x1000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_1824:
	/* 0x1824: cmp w9, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2048ULL);
arm64_l_1828:
	/* 0x1828: mov w9, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_182c:
	/* 0x182c: csel w23, w10, w9, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X23, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_1830:
	/* 0x1830: sub w9, w23, #0x100 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_1834:
	/* 0x1834: ror w9, w9, #8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_ROR), 8ULL);
arm64_l_1838:
	/* 0x1838: cmp w9, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_183c:
	/* 0x183c: b.le 1654 <filter_char_buf_equal+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x183c, 0x1654, arm64_l_1654);
arm64_l_1840:
	/* 0x1840: b 15ec <filter_char_buf_equal+0xd4> */
	ARM64_SIM_A64_JMP(0x1840, 0x15ec, arm64_l_15ec);
arm64_l_1844:
	/* 0x1844: cbz w22, 1880 <filter_char_buf_equal+0x368> */
	ARM64_SIM_A64_CBZ(ARM64_X22, 0x1844, 0x1880, arm64_l_1880);
arm64_l_1848:
	/* 0x1848: cmp w22, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_184c:
	/* 0x184c: b.ne 1864 <filter_char_buf_equal+0x34c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x184c, 0x1864, arm64_l_1864);
arm64_l_1850:
	/* 0x1850: adrp x0, 0 <string_maps_1> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_1_9));
arm64_l_1854:
	/* 0x1854: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1858:
	/* 0x1858: add x9, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_185c:
	/* 0x185c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1860:
	/* 0x1860: b 1908 <filter_char_buf_equal+0x3f0> */
	ARM64_SIM_A64_JMP(0x1860, 0x1908, arm64_l_1908);
arm64_l_1864:
	/* 0x1864: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1868:
	/* 0x1868: ldp x20, x19, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_186c:
	/* 0x186c: ldp x22, x21, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1870:
	/* 0x1870: ldp x24, x23, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1874:
	/* 0x1874: ldp x30, x25, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1878:
	/* 0x1878: ldr x29, [sp], #80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 80ULL);
arm64_l_187c:
	/* 0x187c: ret */
	ARM64_SIM_A64_RET();
arm64_l_1880:
	/* 0x1880: adrp x0, 0 <string_maps_0> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_0_8));
arm64_l_1884:
	/* 0x1884: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1888:
	/* 0x1888: add x9, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_188c:
	/* 0x188c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1890:
	/* 0x1890: b 1908 <filter_char_buf_equal+0x3f0> */
	ARM64_SIM_A64_JMP(0x1890, 0x1908, arm64_l_1908);
arm64_l_1894:
	/* 0x1894: adrp x0, 0 <string_maps_3> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_3_12));
arm64_l_1898:
	/* 0x1898: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_189c:
	/* 0x189c: add x9, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_18a0:
	/* 0x18a0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18a4:
	/* 0x18a4: b 1908 <filter_char_buf_equal+0x3f0> */
	ARM64_SIM_A64_JMP(0x18a4, 0x1908, arm64_l_1908);
arm64_l_18a8:
	/* 0x18a8: adrp x0, 0 <string_maps_6> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_6_15));
arm64_l_18ac:
	/* 0x18ac: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_18b0:
	/* 0x18b0: add x9, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_18b4:
	/* 0x18b4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18b8:
	/* 0x18b8: b 1908 <filter_char_buf_equal+0x3f0> */
	ARM64_SIM_A64_JMP(0x18b8, 0x1908, arm64_l_1908);
arm64_l_18bc:
	/* 0x18bc: adrp x0, 0 <string_maps_9> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_9_18));
arm64_l_18c0:
	/* 0x18c0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_18c4:
	/* 0x18c4: add x9, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_18c8:
	/* 0x18c8: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18cc:
	/* 0x18cc: b 1908 <filter_char_buf_equal+0x3f0> */
	ARM64_SIM_A64_JMP(0x18cc, 0x1908, arm64_l_1908);
arm64_l_18d0:
	/* 0x18d0: adrp x0, 0 <string_maps_2> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_2_11));
arm64_l_18d4:
	/* 0x18d4: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_18d8:
	/* 0x18d8: add x9, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_18dc:
	/* 0x18dc: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18e0:
	/* 0x18e0: b 1908 <filter_char_buf_equal+0x3f0> */
	ARM64_SIM_A64_JMP(0x18e0, 0x1908, arm64_l_1908);
arm64_l_18e4:
	/* 0x18e4: adrp x0, 0 <string_maps_5> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_5_14));
arm64_l_18e8:
	/* 0x18e8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_18ec:
	/* 0x18ec: add x9, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_18f0:
	/* 0x18f0: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18f4:
	/* 0x18f4: b 1908 <filter_char_buf_equal+0x3f0> */
	ARM64_SIM_A64_JMP(0x18f4, 0x1908, arm64_l_1908);
arm64_l_18f8:
	/* 0x18f8: adrp x0, 0 <string_maps_8> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&string_maps_8_17));
arm64_l_18fc:
	/* 0x18fc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1900:
	/* 0x1900: add x9, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1904:
	/* 0x1904: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1908:
	/* 0x1908: add x1, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_190c:
	/* 0x190c: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_1910:
	/* 0x1910: cbz x0, 153c <filter_char_buf_equal+0x24> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1910, 0x153c, arm64_l_153c);
arm64_l_1914:
	/* 0x1914: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1918:
	/* 0x1918: mov x1, x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_191c:
	/* 0x191c: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_1920:
	/* 0x1920: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1924:
	/* 0x1924: cset w0, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1928:
	/* 0x1928: ldp x20, x19, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_192c:
	/* 0x192c: ldp x22, x21, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1930:
	/* 0x1930: ldp x24, x23, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1934:
	/* 0x1934: ldp x30, x25, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1938:
	/* 0x1938: ldr x29, [sp], #80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 80ULL);
arm64_l_193c:
	/* 0x193c: ret */
	ARM64_SIM_A64_RET();
arm64_l_1940:
	/* 0x1940: str x29, [sp, #-80]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551536ULL);
arm64_l_1944:
	/* 0x1944: stp x30, x25, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1948:
	/* 0x1948: stp x24, x23, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_194c:
	/* 0x194c: stp x22, x21, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1950:
	/* 0x1950: stp x20, x19, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1954:
	/* 0x1954: mov x21, x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1958:
	/* 0x1958: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_195c:
	/* 0x195c: add x23, x0, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1960:
	/* 0x1960: mov w24, w2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1964:
	/* 0x1964: tbz w3, #0, 1a58 <filter_char_substring+0x118> */
	ARM64_SIM_A64_TBZ(ARM64_X3, 0, 0x1964, 0x1a58, arm64_l_1a58);
arm64_l_1968:
	/* 0x1968: cbz w2, 1b18 <filter_char_substring+0x1d8> */
	ARM64_SIM_A64_CBZ(ARM64_X2, 0x1968, 0x1b18, arm64_l_1b18);
arm64_l_196c:
	/* 0x196c: adrp x22, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_24));
arm64_l_1970:
	/* 0x1970: mov x25, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1974:
	/* 0x1974: mov w29, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1978:
	/* 0x1978: ldr x22, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_197c:
	/* 0x197c: add x20, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1980:
	/* 0x1980: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1984:
	/* 0x1984: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1988:
	/* 0x1988: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_198c:
	/* 0x198c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1990:
	/* 0x1990: ldr w8, [x23, x25, lsl #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X25, ARM64_MOD_LSL, 2, 0), 0ULL);
arm64_l_1994:
	/* 0x1994: add x1, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1998:
	/* 0x1998: mov x0, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_199c:
	/* 0x199c: str w8, [sp, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_19a0:
	/* 0x19a0: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_19a4:
	/* 0x19a4: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_19a8:
	/* 0x19a8: cbz x0, 1bb8 <filter_char_substring+0x278> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x19a8, 0x1bb8, arm64_l_1bb8);
arm64_l_19ac:
	/* 0x19ac: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_19b0:
	/* 0x19b0: mov x9, x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_19b4:
	/* 0x19b4: mov x10, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_19b8:
	/* 0x19b8: b 19d0 <filter_char_substring+0x90> */
	ARM64_SIM_A64_JMP(0x19b8, 0x19d0, arm64_l_19d0);
arm64_l_19bc:
	/* 0x19bc: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_19c0:
	/* 0x19c0: sub x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_19c4:
	/* 0x19c4: add x9, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_19c8:
	/* 0x19c8: cmp x8, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19cc:
	/* 0x19cc: b.eq 1a34 <filter_char_substring+0xf4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x19cc, 0x1a34, arm64_l_1a34);
arm64_l_19d0:
	/* 0x19d0: mov x11, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_19d4:
	/* 0x19d4: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19d8:
	/* 0x19d8: b.eq 19bc <filter_char_substring+0x7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x19d8, 0x19bc, arm64_l_19bc);
arm64_l_19dc:
	/* 0x19dc: ldrb w12, [x0, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X0, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19e0:
	/* 0x19e0: cbz w12, 1a30 <filter_char_substring+0xf0> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0x19e0, 0x1a30, arm64_l_1a30);
arm64_l_19e4:
	/* 0x19e4: ldrb w13, [x9, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19e8:
	/* 0x19e8: sub w14, w13, #0x41 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 65ULL);
arm64_l_19ec:
	/* 0x19ec: orr w15, w13, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_19f0:
	/* 0x19f0: cmp w14, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_19f4:
	/* 0x19f4: sub w14, w12, #0x41 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X14, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 65ULL);
arm64_l_19f8:
	/* 0x19f8: csel w13, w15, w13, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X13, ARM64_X15, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_19fc:
	/* 0x19fc: orr w15, w12, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X15, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_1a00:
	/* 0x1a00: cmp w14, #0x1a */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_1a04:
	/* 0x1a04: csel w12, w15, w12, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X12, ARM64_X15, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_1a08:
	/* 0x1a08: cmp x11, #0x62 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 98ULL);
arm64_l_1a0c:
	/* 0x1a0c: b.hi 19bc <filter_char_substring+0x7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1a0c, 0x19bc, arm64_l_19bc);
arm64_l_1a10:
	/* 0x1a10: add x11, x11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1a14:
	/* 0x1a14: cmp w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a18:
	/* 0x1a18: b.eq 19d4 <filter_char_substring+0x94> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1a18, 0x19d4, arm64_l_19d4);
arm64_l_1a1c:
	/* 0x1a1c: b 19bc <filter_char_substring+0x7c> */
	ARM64_SIM_A64_JMP(0x1a1c, 0x19bc, arm64_l_19bc);
arm64_l_1a20:
	/* 0x1a20: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a24:
	/* 0x1a24: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a28:
	/* 0x1a28: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a2c:
	/* 0x1a2c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a30:
	/* 0x1a30: tbz w8, #31, 1bd0 <filter_char_substring+0x290> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 31, 0x1a30, 0x1bd0, arm64_l_1bd0);
arm64_l_1a34:
	/* 0x1a34: ldr w9, [x19, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1a38:
	/* 0x1a38: add w8, w29, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1a3c:
	/* 0x1a3c: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a40:
	/* 0x1a40: b.cs 1bb4 <filter_char_substring+0x274> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1a40, 0x1bb4, arm64_l_1bb4);
arm64_l_1a44:
	/* 0x1a44: add x25, x25, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1a48:
	/* 0x1a48: add w29, w29, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1a4c:
	/* 0x1a4c: cmp x25, #0x64 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 100ULL);
arm64_l_1a50:
	/* 0x1a50: b.ne 1990 <filter_char_substring+0x50> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1a50, 0x1990, arm64_l_1990);
arm64_l_1a54:
	/* 0x1a54: b 1bb4 <filter_char_substring+0x274> */
	ARM64_SIM_A64_JMP(0x1a54, 0x1bb4, arm64_l_1bb4);
arm64_l_1a58:
	/* 0x1a58: cbz w2, 1b6c <filter_char_substring+0x22c> */
	ARM64_SIM_A64_CBZ(ARM64_X2, 0x1a58, 0x1b6c, arm64_l_1b6c);
arm64_l_1a5c:
	/* 0x1a5c: adrp x22, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_24));
arm64_l_1a60:
	/* 0x1a60: mov x25, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a64:
	/* 0x1a64: mov w29, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1a68:
	/* 0x1a68: ldr x22, [x22] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a6c:
	/* 0x1a6c: add x20, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1a70:
	/* 0x1a70: ldr w8, [x23, x25, lsl #2] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X25, ARM64_MOD_LSL, 2, 0), 0ULL);
arm64_l_1a74:
	/* 0x1a74: add x1, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1a78:
	/* 0x1a78: mov x0, x22 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a7c:
	/* 0x1a7c: str w8, [sp, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1a80:
	/* 0x1a80: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1a84:
	/* 0x1a84: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_1a88:
	/* 0x1a88: cbz x0, 1bb8 <filter_char_substring+0x278> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1a88, 0x1bb8, arm64_l_1bb8);
arm64_l_1a8c:
	/* 0x1a8c: mov x8, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a90:
	/* 0x1a90: mov x9, x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a94:
	/* 0x1a94: mov x10, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a98:
	/* 0x1a98: b 1ab0 <filter_char_substring+0x170> */
	ARM64_SIM_A64_JMP(0x1a98, 0x1ab0, arm64_l_1ab0);
arm64_l_1a9c:
	/* 0x1a9c: add x8, x8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1aa0:
	/* 0x1aa0: sub x10, x10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1aa4:
	/* 0x1aa4: add x9, x9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1aa8:
	/* 0x1aa8: cmp x8, x24 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1aac:
	/* 0x1aac: b.eq 1af4 <filter_char_substring+0x1b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1aac, 0x1af4, arm64_l_1af4);
arm64_l_1ab0:
	/* 0x1ab0: mov x11, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1ab4:
	/* 0x1ab4: cmp x10, x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ab8:
	/* 0x1ab8: b.eq 1a9c <filter_char_substring+0x15c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ab8, 0x1a9c, arm64_l_1a9c);
arm64_l_1abc:
	/* 0x1abc: ldrb w12, [x0, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X12, ARM64_X0, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ac0:
	/* 0x1ac0: cbz w12, 1af0 <filter_char_substring+0x1b0> */
	ARM64_SIM_A64_CBZ(ARM64_X12, 0x1ac0, 0x1af0, arm64_l_1af0);
arm64_l_1ac4:
	/* 0x1ac4: cmp x11, #0x62 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 98ULL);
arm64_l_1ac8:
	/* 0x1ac8: b.hi 1a9c <filter_char_substring+0x15c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1ac8, 0x1a9c, arm64_l_1a9c);
arm64_l_1acc:
	/* 0x1acc: ldrb w13, [x9, x11] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X13, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X11, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ad0:
	/* 0x1ad0: add x11, x11, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1ad4:
	/* 0x1ad4: cmp w13, w12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ad8:
	/* 0x1ad8: b.eq 1ab4 <filter_char_substring+0x174> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ad8, 0x1ab4, arm64_l_1ab4);
arm64_l_1adc:
	/* 0x1adc: b 1a9c <filter_char_substring+0x15c> */
	ARM64_SIM_A64_JMP(0x1adc, 0x1a9c, arm64_l_1a9c);
arm64_l_1ae0:
	/* 0x1ae0: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1ae4:
	/* 0x1ae4: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1ae8:
	/* 0x1ae8: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1aec:
	/* 0x1aec: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1af0:
	/* 0x1af0: tbz w8, #31, 1bd0 <filter_char_substring+0x290> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 31, 0x1af0, 0x1bd0, arm64_l_1bd0);
arm64_l_1af4:
	/* 0x1af4: ldr w9, [x19, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1af8:
	/* 0x1af8: add w8, w29, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1afc:
	/* 0x1afc: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b00:
	/* 0x1b00: b.cs 1bb4 <filter_char_substring+0x274> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1b00, 0x1bb4, arm64_l_1bb4);
arm64_l_1b04:
	/* 0x1b04: add x25, x25, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b08:
	/* 0x1b08: add w29, w29, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1b0c:
	/* 0x1b0c: cmp x25, #0x64 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 100ULL);
arm64_l_1b10:
	/* 0x1b10: b.ne 1a70 <filter_char_substring+0x130> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1b10, 0x1a70, arm64_l_1a70);
arm64_l_1b14:
	/* 0x1b14: b 1bb4 <filter_char_substring+0x274> */
	ARM64_SIM_A64_JMP(0x1b14, 0x1bb4, arm64_l_1bb4);
arm64_l_1b18:
	/* 0x1b18: adrp x20, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_24));
arm64_l_1b1c:
	/* 0x1b1c: mov w21, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1b20:
	/* 0x1b20: add x22, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1b24:
	/* 0x1b24: ldr x20, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b28:
	/* 0x1b28: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b2c:
	/* 0x1b2c: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b30:
	/* 0x1b30: ldr w8, [x19, x21] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X21, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b34:
	/* 0x1b34: add x1, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1b38:
	/* 0x1b38: mov x0, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b3c:
	/* 0x1b3c: str w8, [sp, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1b40:
	/* 0x1b40: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1b44:
	/* 0x1b44: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_1b48:
	/* 0x1b48: cbz x0, 1bb8 <filter_char_substring+0x278> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1b48, 0x1bb8, arm64_l_1bb8);
arm64_l_1b4c:
	/* 0x1b4c: ldr w8, [x19, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1b50:
	/* 0x1b50: add x21, x21, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1b54:
	/* 0x1b54: sub w9, w21, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1b58:
	/* 0x1b58: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b5c:
	/* 0x1b5c: b.cs 1bb4 <filter_char_substring+0x274> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1b5c, 0x1bb4, arm64_l_1bb4);
arm64_l_1b60:
	/* 0x1b60: cmp x21, #0x1a0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 416ULL);
arm64_l_1b64:
	/* 0x1b64: b.ne 1b30 <filter_char_substring+0x1f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1b64, 0x1b30, arm64_l_1b30);
arm64_l_1b68:
	/* 0x1b68: b 1bb4 <filter_char_substring+0x274> */
	ARM64_SIM_A64_JMP(0x1b68, 0x1bb4, arm64_l_1bb4);
arm64_l_1b6c:
	/* 0x1b6c: adrp x20, 0 <substring_map> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&substring_map_24));
arm64_l_1b70:
	/* 0x1b70: mov w21, #0x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1b74:
	/* 0x1b74: add x22, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1b78:
	/* 0x1b78: ldr x20, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b7c:
	/* 0x1b7c: ldr w8, [x19, x21] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X21, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b80:
	/* 0x1b80: add x1, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1b84:
	/* 0x1b84: mov x0, x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b88:
	/* 0x1b88: str w8, [sp, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1b8c:
	/* 0x1b8c: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1b90:
	/* 0x1b90: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_1b94:
	/* 0x1b94: cbz x0, 1bb8 <filter_char_substring+0x278> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1b94, 0x1bb8, arm64_l_1bb8);
arm64_l_1b98:
	/* 0x1b98: ldr w8, [x19, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1b9c:
	/* 0x1b9c: add x21, x21, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1ba0:
	/* 0x1ba0: sub w9, w21, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1ba4:
	/* 0x1ba4: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ba8:
	/* 0x1ba8: b.cs 1bb4 <filter_char_substring+0x274> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1ba8, 0x1bb4, arm64_l_1bb4);
arm64_l_1bac:
	/* 0x1bac: cmp x21, #0x1a0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 416ULL);
arm64_l_1bb0:
	/* 0x1bb0: b.ne 1b7c <filter_char_substring+0x23c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1bb0, 0x1b7c, arm64_l_1b7c);
arm64_l_1bb4:
	/* 0x1bb4: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1bb8:
	/* 0x1bb8: ldp x20, x19, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1bbc:
	/* 0x1bbc: ldp x22, x21, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1bc0:
	/* 0x1bc0: ldp x24, x23, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1bc4:
	/* 0x1bc4: ldp x30, x25, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1bc8:
	/* 0x1bc8: ldr x29, [sp], #80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 80ULL);
arm64_l_1bcc:
	/* 0x1bcc: ret */
	ARM64_SIM_A64_RET();
arm64_l_1bd0:
	/* 0x1bd0: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1bd4:
	/* 0x1bd4: ldp x20, x19, [sp, #64] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1bd8:
	/* 0x1bd8: ldp x22, x21, [sp, #48] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1bdc:
	/* 0x1bdc: ldp x24, x23, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1be0:
	/* 0x1be0: ldp x30, x25, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1be4:
	/* 0x1be4: ldr x29, [sp], #80 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 80ULL);
arm64_l_1be8:
	/* 0x1be8: ret */
	ARM64_SIM_A64_RET();
arm64_l_1bec:
	/* 0x1bec: ldr w8, [x0, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1bf0:
	/* 0x1bf0: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_1bf4:
	/* 0x1bf4: b.hi 1c68 <filter_16ty_selector_val+0x7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1bf4, 0x1c68, arm64_l_1c68);
arm64_l_1bf8:
	/* 0x1bf8: mov x10, #0x40 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 64ULL);
arm64_l_1bfc:
	/* 0x1bfc: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1c00:
	/* 0x1c00: movk x10, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_1c04:
	/* 0x1c04: lsl x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1c08:
	/* 0x1c08: movk x10, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_1c0c:
	/* 0x1c0c: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c10:
	/* 0x1c10: b.eq 1c1c <filter_16ty_selector_val+0x30> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c10, 0x1c1c, arm64_l_1c1c);
arm64_l_1c14:
	/* 0x1c14: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1c18:
	/* 0x1c18: ret */
	ARM64_SIM_A64_RET();
arm64_l_1c1c:
	/* 0x1c1c: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1c20:
	/* 0x1c20: lsl x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1c24:
	/* 0x1c24: tst x9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1c28:
	/* 0x1c28: b.eq 1c48 <filter_16ty_selector_val+0x5c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c28, 0x1c48, arm64_l_1c48);
arm64_l_1c2c:
	/* 0x1c2c: ldrh w9, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c30:
	/* 0x1c30: ldr w10, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1c34:
	/* 0x1c34: cmp w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c38:
	/* 0x1c38: b.ne 1ce8 <filter_16ty_selector_val+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1c38, 0x1ce8, arm64_l_1ce8);
arm64_l_1c3c:
	/* 0x1c3c: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1c40:
	/* 0x1c40: cset w0, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_1c44:
	/* 0x1c44: ret */
	ARM64_SIM_A64_RET();
arm64_l_1c48:
	/* 0x1c48: cmp x8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1c4c:
	/* 0x1c4c: b.ne 1c68 <filter_16ty_selector_val+0x7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1c4c, 0x1c68, arm64_l_1c68);
arm64_l_1c50:
	/* 0x1c50: ldrh w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c54:
	/* 0x1c54: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1c58:
	/* 0x1c58: tst w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c5c:
	/* 0x1c5c: b.eq 1d94 <filter_16ty_selector_val+0x1a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c5c, 0x1d94, arm64_l_1d94);
arm64_l_1c60:
	/* 0x1c60: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1c64:
	/* 0x1c64: ret */
	ARM64_SIM_A64_RET();
arm64_l_1c68:
	/* 0x1c68: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1c6c:
	/* 0x1c6c: b.eq 1cb0 <filter_16ty_selector_val+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c6c, 0x1cb0, arm64_l_1cb0);
arm64_l_1c70:
	/* 0x1c70: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1c74:
	/* 0x1c74: b.ne 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1c74, 0x1f3c, arm64_l_1f3c);
arm64_l_1c78:
	/* 0x1c78: ldr w8, [x0, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1c7c:
	/* 0x1c7c: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1c80:
	/* 0x1c80: b.hi 1dcc <filter_16ty_selector_val+0x1e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1c80, 0x1dcc, arm64_l_1dcc);
arm64_l_1c84:
	/* 0x1c84: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1c88:
	/* 0x1c88: lsl w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1c8c:
	/* 0x1c8c: mov w9, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1c90:
	/* 0x1c90: tst w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c94:
	/* 0x1c94: b.eq 1dcc <filter_16ty_selector_val+0x1e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c94, 0x1dcc, arm64_l_1dcc);
arm64_l_1c98:
	/* 0x1c98: ldrsh w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDRSH, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c9c:
	/* 0x1c9c: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1ca0:
	/* 0x1ca0: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ca4:
	/* 0x1ca4: b.le 1d74 <filter_16ty_selector_val+0x188> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1ca4, 0x1d74, arm64_l_1d74);
arm64_l_1ca8:
	/* 0x1ca8: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1cac:
	/* 0x1cac: ret */
	ARM64_SIM_A64_RET();
arm64_l_1cb0:
	/* 0x1cb0: ldr w8, [x0, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1cb4:
	/* 0x1cb4: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1cb8:
	/* 0x1cb8: b.hi 1db4 <filter_16ty_selector_val+0x1c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1cb8, 0x1db4, arm64_l_1db4);
arm64_l_1cbc:
	/* 0x1cbc: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1cc0:
	/* 0x1cc0: lsl w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1cc4:
	/* 0x1cc4: mov w9, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1cc8:
	/* 0x1cc8: tst w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ccc:
	/* 0x1ccc: b.eq 1db4 <filter_16ty_selector_val+0x1c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ccc, 0x1db4, arm64_l_1db4);
arm64_l_1cd0:
	/* 0x1cd0: ldrsh w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDRSH, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1cd4:
	/* 0x1cd4: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1cd8:
	/* 0x1cd8: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1cdc:
	/* 0x1cdc: b.ge 1d54 <filter_16ty_selector_val+0x168> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x1cdc, 0x1d54, arm64_l_1d54);
arm64_l_1ce0:
	/* 0x1ce0: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ce4:
	/* 0x1ce4: ret */
	ARM64_SIM_A64_RET();
arm64_l_1ce8:
	/* 0x1ce8: ldr w10, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1cec:
	/* 0x1cec: cmp w10, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1cf0:
	/* 0x1cf0: b.cc 1d28 <filter_16ty_selector_val+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1cf0, 0x1d28, arm64_l_1d28);
arm64_l_1cf4:
	/* 0x1cf4: ldr w11, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1cf8:
	/* 0x1cf8: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1cfc:
	/* 0x1cfc: b.eq 1c3c <filter_16ty_selector_val+0x50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1cfc, 0x1c3c, arm64_l_1c3c);
arm64_l_1d00:
	/* 0x1d00: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1d04:
	/* 0x1d04: b.cc 1d28 <filter_16ty_selector_val+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1d04, 0x1d28, arm64_l_1d28);
arm64_l_1d08:
	/* 0x1d08: ldr w11, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1d0c:
	/* 0x1d0c: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d10:
	/* 0x1d10: b.eq 1c3c <filter_16ty_selector_val+0x50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d10, 0x1c3c, arm64_l_1c3c);
arm64_l_1d14:
	/* 0x1d14: cmp w10, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_1d18:
	/* 0x1d18: b.cc 1d28 <filter_16ty_selector_val+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1d18, 0x1d28, arm64_l_1d28);
arm64_l_1d1c:
	/* 0x1d1c: ldr w10, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_1d20:
	/* 0x1d20: cmp w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d24:
	/* 0x1d24: b.eq 1c3c <filter_16ty_selector_val+0x50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d24, 0x1c3c, arm64_l_1c3c);
arm64_l_1d28:
	/* 0x1d28: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_1d2c:
	/* 0x1d2c: b.hi 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1d2c, 0x1f3c, arm64_l_1f3c);
arm64_l_1d30:
	/* 0x1d30: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1d34:
	/* 0x1d34: lsl x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1d38:
	/* 0x1d38: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_1d3c:
	/* 0x1d3c: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_1d40:
	/* 0x1d40: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_1d44:
	/* 0x1d44: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d48:
	/* 0x1d48: b.eq 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d48, 0x1f3c, arm64_l_1f3c);
arm64_l_1d4c:
	/* 0x1d4c: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1d50:
	/* 0x1d50: ret */
	ARM64_SIM_A64_RET();
arm64_l_1d54:
	/* 0x1d54: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1d58:
	/* 0x1d58: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1d5c:
	/* 0x1d5c: b.cc 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1d5c, 0x1f3c, arm64_l_1f3c);
arm64_l_1d60:
	/* 0x1d60: ldr w10, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1d64:
	/* 0x1d64: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d68:
	/* 0x1d68: b.ge 1e24 <filter_16ty_selector_val+0x238> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x1d68, 0x1e24, arm64_l_1e24);
arm64_l_1d6c:
	/* 0x1d6c: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1d70:
	/* 0x1d70: ret */
	ARM64_SIM_A64_RET();
arm64_l_1d74:
	/* 0x1d74: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1d78:
	/* 0x1d78: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1d7c:
	/* 0x1d7c: b.cc 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1d7c, 0x1f3c, arm64_l_1f3c);
arm64_l_1d80:
	/* 0x1d80: ldr w10, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1d84:
	/* 0x1d84: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d88:
	/* 0x1d88: b.le 1e40 <filter_16ty_selector_val+0x254> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1d88, 0x1e40, arm64_l_1e40);
arm64_l_1d8c:
	/* 0x1d8c: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1d90:
	/* 0x1d90: ret */
	ARM64_SIM_A64_RET();
arm64_l_1d94:
	/* 0x1d94: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1d98:
	/* 0x1d98: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1d9c:
	/* 0x1d9c: b.cc 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1d9c, 0x1f3c, arm64_l_1f3c);
arm64_l_1da0:
	/* 0x1da0: ldr w10, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1da4:
	/* 0x1da4: tst w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1da8:
	/* 0x1da8: b.eq 1e5c <filter_16ty_selector_val+0x270> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1da8, 0x1e5c, arm64_l_1e5c);
arm64_l_1dac:
	/* 0x1dac: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1db0:
	/* 0x1db0: ret */
	ARM64_SIM_A64_RET();
arm64_l_1db4:
	/* 0x1db4: ldrh w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1db8:
	/* 0x1db8: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1dbc:
	/* 0x1dbc: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1dc0:
	/* 0x1dc0: b.cs 1de4 <filter_16ty_selector_val+0x1f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1dc0, 0x1de4, arm64_l_1de4);
arm64_l_1dc4:
	/* 0x1dc4: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1dc8:
	/* 0x1dc8: ret */
	ARM64_SIM_A64_RET();
arm64_l_1dcc:
	/* 0x1dcc: ldrh w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1dd0:
	/* 0x1dd0: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1dd4:
	/* 0x1dd4: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1dd8:
	/* 0x1dd8: b.ls 1e04 <filter_16ty_selector_val+0x218> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1dd8, 0x1e04, arm64_l_1e04);
arm64_l_1ddc:
	/* 0x1ddc: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1de0:
	/* 0x1de0: ret */
	ARM64_SIM_A64_RET();
arm64_l_1de4:
	/* 0x1de4: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1de8:
	/* 0x1de8: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1dec:
	/* 0x1dec: b.cc 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1dec, 0x1f3c, arm64_l_1f3c);
arm64_l_1df0:
	/* 0x1df0: ldr w10, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1df4:
	/* 0x1df4: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1df8:
	/* 0x1df8: b.cs 1e78 <filter_16ty_selector_val+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1df8, 0x1e78, arm64_l_1e78);
arm64_l_1dfc:
	/* 0x1dfc: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e00:
	/* 0x1e00: ret */
	ARM64_SIM_A64_RET();
arm64_l_1e04:
	/* 0x1e04: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1e08:
	/* 0x1e08: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_1e0c:
	/* 0x1e0c: b.cc 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1e0c, 0x1f3c, arm64_l_1f3c);
arm64_l_1e10:
	/* 0x1e10: ldr w10, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1e14:
	/* 0x1e14: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e18:
	/* 0x1e18: b.ls 1e94 <filter_16ty_selector_val+0x2a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1e18, 0x1e94, arm64_l_1e94);
arm64_l_1e1c:
	/* 0x1e1c: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e20:
	/* 0x1e20: ret */
	ARM64_SIM_A64_RET();
arm64_l_1e24:
	/* 0x1e24: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1e28:
	/* 0x1e28: b.cc 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1e28, 0x1f3c, arm64_l_1f3c);
arm64_l_1e2c:
	/* 0x1e2c: ldr w10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1e30:
	/* 0x1e30: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e34:
	/* 0x1e34: b.ge 1eb0 <filter_16ty_selector_val+0x2c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x1e34, 0x1eb0, arm64_l_1eb0);
arm64_l_1e38:
	/* 0x1e38: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e3c:
	/* 0x1e3c: ret */
	ARM64_SIM_A64_RET();
arm64_l_1e40:
	/* 0x1e40: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1e44:
	/* 0x1e44: b.cc 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1e44, 0x1f3c, arm64_l_1f3c);
arm64_l_1e48:
	/* 0x1e48: ldr w10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1e4c:
	/* 0x1e4c: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e50:
	/* 0x1e50: b.le 1ecc <filter_16ty_selector_val+0x2e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1e50, 0x1ecc, arm64_l_1ecc);
arm64_l_1e54:
	/* 0x1e54: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e58:
	/* 0x1e58: ret */
	ARM64_SIM_A64_RET();
arm64_l_1e5c:
	/* 0x1e5c: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1e60:
	/* 0x1e60: b.cc 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1e60, 0x1f3c, arm64_l_1f3c);
arm64_l_1e64:
	/* 0x1e64: ldr w10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1e68:
	/* 0x1e68: tst w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e6c:
	/* 0x1e6c: b.eq 1ee8 <filter_16ty_selector_val+0x2fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e6c, 0x1ee8, arm64_l_1ee8);
arm64_l_1e70:
	/* 0x1e70: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e74:
	/* 0x1e74: ret */
	ARM64_SIM_A64_RET();
arm64_l_1e78:
	/* 0x1e78: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1e7c:
	/* 0x1e7c: b.cc 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1e7c, 0x1f3c, arm64_l_1f3c);
arm64_l_1e80:
	/* 0x1e80: ldr w10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1e84:
	/* 0x1e84: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e88:
	/* 0x1e88: b.cs 1f04 <filter_16ty_selector_val+0x318> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1e88, 0x1f04, arm64_l_1f04);
arm64_l_1e8c:
	/* 0x1e8c: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1e90:
	/* 0x1e90: ret */
	ARM64_SIM_A64_RET();
arm64_l_1e94:
	/* 0x1e94: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1e98:
	/* 0x1e98: b.cc 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1e98, 0x1f3c, arm64_l_1f3c);
arm64_l_1e9c:
	/* 0x1e9c: ldr w10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1ea0:
	/* 0x1ea0: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ea4:
	/* 0x1ea4: b.ls 1f20 <filter_16ty_selector_val+0x334> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1ea4, 0x1f20, arm64_l_1f20);
arm64_l_1ea8:
	/* 0x1ea8: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1eac:
	/* 0x1eac: ret */
	ARM64_SIM_A64_RET();
arm64_l_1eb0:
	/* 0x1eb0: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_1eb4:
	/* 0x1eb4: b.cc 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1eb4, 0x1f3c, arm64_l_1f3c);
arm64_l_1eb8:
	/* 0x1eb8: ldr w9, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_1ebc:
	/* 0x1ebc: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ec0:
	/* 0x1ec0: b.ge 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x1ec0, 0x1f3c, arm64_l_1f3c);
arm64_l_1ec4:
	/* 0x1ec4: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ec8:
	/* 0x1ec8: ret */
	ARM64_SIM_A64_RET();
arm64_l_1ecc:
	/* 0x1ecc: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_1ed0:
	/* 0x1ed0: b.cc 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1ed0, 0x1f3c, arm64_l_1f3c);
arm64_l_1ed4:
	/* 0x1ed4: ldr w9, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_1ed8:
	/* 0x1ed8: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1edc:
	/* 0x1edc: b.le 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x1edc, 0x1f3c, arm64_l_1f3c);
arm64_l_1ee0:
	/* 0x1ee0: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ee4:
	/* 0x1ee4: ret */
	ARM64_SIM_A64_RET();
arm64_l_1ee8:
	/* 0x1ee8: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_1eec:
	/* 0x1eec: b.cc 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1eec, 0x1f3c, arm64_l_1f3c);
arm64_l_1ef0:
	/* 0x1ef0: ldr w9, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_1ef4:
	/* 0x1ef4: tst w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ef8:
	/* 0x1ef8: b.eq 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ef8, 0x1f3c, arm64_l_1f3c);
arm64_l_1efc:
	/* 0x1efc: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f00:
	/* 0x1f00: ret */
	ARM64_SIM_A64_RET();
arm64_l_1f04:
	/* 0x1f04: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_1f08:
	/* 0x1f08: b.cc 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1f08, 0x1f3c, arm64_l_1f3c);
arm64_l_1f0c:
	/* 0x1f0c: ldr w9, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_1f10:
	/* 0x1f10: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f14:
	/* 0x1f14: b.cs 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1f14, 0x1f3c, arm64_l_1f3c);
arm64_l_1f18:
	/* 0x1f18: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f1c:
	/* 0x1f1c: ret */
	ARM64_SIM_A64_RET();
arm64_l_1f20:
	/* 0x1f20: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_1f24:
	/* 0x1f24: b.cc 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1f24, 0x1f3c, arm64_l_1f3c);
arm64_l_1f28:
	/* 0x1f28: ldr w9, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_1f2c:
	/* 0x1f2c: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f30:
	/* 0x1f30: b.ls 1f3c <filter_16ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1f30, 0x1f3c, arm64_l_1f3c);
arm64_l_1f34:
	/* 0x1f34: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f38:
	/* 0x1f38: ret */
	ARM64_SIM_A64_RET();
arm64_l_1f3c:
	/* 0x1f3c: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1f40:
	/* 0x1f40: ret */
	ARM64_SIM_A64_RET();
arm64_l_1f44:
	/* 0x1f44: ldr w9, [x0, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1f48:
	/* 0x1f48: ldr w8, [x0, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1f4c:
	/* 0x1f4c: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1f50:
	/* 0x1f50: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1f54:
	/* 0x1f54: lsl w9, w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_1f58:
	/* 0x1f58: mov w10, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_1f5c:
	/* 0x1f5c: and w9, w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_1f60:
	/* 0x1f60: ccmp w9, #0x0, #0x4, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 4), 0ULL);
arm64_l_1f64:
	/* 0x1f64: b.eq 2064 <filter_16ty_range+0x120> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f64, 0x2064, arm64_l_2064);
arm64_l_1f68:
	/* 0x1f68: ldrsh w10, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDRSH, ARM64_X10, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f6c:
	/* 0x1f6c: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_1f70:
	/* 0x1f70: b.ne 1ff8 <filter_16ty_range+0xb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1f70, 0x1ff8, arm64_l_1ff8);
arm64_l_1f74:
	/* 0x1f74: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1f78:
	/* 0x1f78: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f7c:
	/* 0x1f7c: b.gt 1f8c <filter_16ty_range+0x48> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1f7c, 0x1f8c, arm64_l_1f8c);
arm64_l_1f80:
	/* 0x1f80: ldr w9, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_1f84:
	/* 0x1f84: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f88:
	/* 0x1f88: b.ge 2088 <filter_16ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x1f88, 0x2088, arm64_l_2088);
arm64_l_1f8c:
	/* 0x1f8c: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1f90:
	/* 0x1f90: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_1f94:
	/* 0x1f94: b.cc 2174 <filter_16ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1f94, 0x2174, arm64_l_2174);
arm64_l_1f98:
	/* 0x1f98: ldr w11, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1f9c:
	/* 0x1f9c: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fa0:
	/* 0x1fa0: b.gt 1fb0 <filter_16ty_range+0x6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1fa0, 0x1fb0, arm64_l_1fb0);
arm64_l_1fa4:
	/* 0x1fa4: ldr w11, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_1fa8:
	/* 0x1fa8: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fac:
	/* 0x1fac: b.ge 2088 <filter_16ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x1fac, 0x2088, arm64_l_2088);
arm64_l_1fb0:
	/* 0x1fb0: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_1fb4:
	/* 0x1fb4: b.cc 2174 <filter_16ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1fb4, 0x2174, arm64_l_2174);
arm64_l_1fb8:
	/* 0x1fb8: ldr w11, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1fbc:
	/* 0x1fbc: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fc0:
	/* 0x1fc0: b.gt 1fd0 <filter_16ty_range+0x8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1fc0, 0x1fd0, arm64_l_1fd0);
arm64_l_1fc4:
	/* 0x1fc4: ldr w11, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1fc8:
	/* 0x1fc8: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fcc:
	/* 0x1fcc: b.ge 2088 <filter_16ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x1fcc, 0x2088, arm64_l_2088);
arm64_l_1fd0:
	/* 0x1fd0: cmp w9, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_1fd4:
	/* 0x1fd4: b.cc 2174 <filter_16ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1fd4, 0x2174, arm64_l_2174);
arm64_l_1fd8:
	/* 0x1fd8: ldr w11, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1fdc:
	/* 0x1fdc: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1fe0:
	/* 0x1fe0: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fe4:
	/* 0x1fe4: b.gt 2164 <filter_16ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x1fe4, 0x2164, arm64_l_2164);
arm64_l_1fe8:
	/* 0x1fe8: ldr w11, [x0, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_1fec:
	/* 0x1fec: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ff0:
	/* 0x1ff0: b.ge 2088 <filter_16ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x1ff0, 0x2088, arm64_l_2088);
arm64_l_1ff4:
	/* 0x1ff4: b 2164 <filter_16ty_range+0x220> */
	ARM64_SIM_A64_JMP(0x1ff4, 0x2164, arm64_l_2164);
arm64_l_1ff8:
	/* 0x1ff8: ldp w9, w12, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X9, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1ffc:
	/* 0x1ffc: ldr w11, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2000:
	/* 0x2000: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2004:
	/* 0x2004: ccmp w12, w10, #0x8, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 8), 0);
arm64_l_2008:
	/* 0x2008: cset w9, ge */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_GE, 0);
arm64_l_200c:
	/* 0x200c: cmp w11, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2010:
	/* 0x2010: b.cc 2164 <filter_16ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2010, 0x2164, arm64_l_2164);
arm64_l_2014:
	/* 0x2014: ldp w12, w13, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2018:
	/* 0x2018: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_201c:
	/* 0x201c: ccmp w13, w10, #0x8, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 8), 0);
arm64_l_2020:
	/* 0x2020: csinc w9, w9, wzr, lt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LT, 0);
arm64_l_2024:
	/* 0x2024: cmp w11, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_2028:
	/* 0x2028: b.cc 2164 <filter_16ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2028, 0x2164, arm64_l_2164);
arm64_l_202c:
	/* 0x202c: ldp w12, w13, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2030:
	/* 0x2030: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2034:
	/* 0x2034: ccmp w13, w10, #0x8, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 8), 0);
arm64_l_2038:
	/* 0x2038: csinc w9, w9, wzr, lt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LT, 0);
arm64_l_203c:
	/* 0x203c: cmp w11, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2040:
	/* 0x2040: b.cc 2164 <filter_16ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2040, 0x2164, arm64_l_2164);
arm64_l_2044:
	/* 0x2044: ldp w11, w12, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2048:
	/* 0x2048: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_204c:
	/* 0x204c: ccmp w12, w10, #0x8, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 8), 0);
arm64_l_2050:
	/* 0x2050: csinc w9, w9, wzr, lt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LT, 0);
arm64_l_2054:
	/* 0x2054: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2058:
	/* 0x2058: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_205c:
	/* 0x205c: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2060:
	/* 0x2060: ret */
	ARM64_SIM_A64_RET();
arm64_l_2064:
	/* 0x2064: ldrh w10, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2068:
	/* 0x2068: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_206c:
	/* 0x206c: b.ne 2090 <filter_16ty_range+0x14c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x206c, 0x2090, arm64_l_2090);
arm64_l_2070:
	/* 0x2070: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2074:
	/* 0x2074: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2078:
	/* 0x2078: b.hi 20fc <filter_16ty_range+0x1b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2078, 0x20fc, arm64_l_20fc);
arm64_l_207c:
	/* 0x207c: ldr w9, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_2080:
	/* 0x2080: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2084:
	/* 0x2084: b.cc 20fc <filter_16ty_range+0x1b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2084, 0x20fc, arm64_l_20fc);
arm64_l_2088:
	/* 0x2088: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_208c:
	/* 0x208c: ret */
	ARM64_SIM_A64_RET();
arm64_l_2090:
	/* 0x2090: ldp w9, w12, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X9, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2094:
	/* 0x2094: ldr w11, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2098:
	/* 0x2098: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_209c:
	/* 0x209c: ccmp w12, w10, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_20a0:
	/* 0x20a0: cset w9, cs */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CS, 0);
arm64_l_20a4:
	/* 0x20a4: cmp w11, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_20a8:
	/* 0x20a8: b.cc 2164 <filter_16ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x20a8, 0x2164, arm64_l_2164);
arm64_l_20ac:
	/* 0x20ac: ldp w12, w13, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_20b0:
	/* 0x20b0: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_20b4:
	/* 0x20b4: ccmp w13, w10, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_20b8:
	/* 0x20b8: csinc w9, w9, wzr, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_20bc:
	/* 0x20bc: cmp w11, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_20c0:
	/* 0x20c0: b.cc 2164 <filter_16ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x20c0, 0x2164, arm64_l_2164);
arm64_l_20c4:
	/* 0x20c4: ldp w12, w13, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_20c8:
	/* 0x20c8: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_20cc:
	/* 0x20cc: ccmp w13, w10, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_20d0:
	/* 0x20d0: csinc w9, w9, wzr, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_20d4:
	/* 0x20d4: cmp w11, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_20d8:
	/* 0x20d8: b.cc 2164 <filter_16ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x20d8, 0x2164, arm64_l_2164);
arm64_l_20dc:
	/* 0x20dc: ldp w11, w12, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_20e0:
	/* 0x20e0: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_20e4:
	/* 0x20e4: ccmp w12, w10, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_20e8:
	/* 0x20e8: csinc w9, w9, wzr, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_20ec:
	/* 0x20ec: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_20f0:
	/* 0x20f0: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_20f4:
	/* 0x20f4: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_20f8:
	/* 0x20f8: ret */
	ARM64_SIM_A64_RET();
arm64_l_20fc:
	/* 0x20fc: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2100:
	/* 0x2100: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2104:
	/* 0x2104: b.cc 2174 <filter_16ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2104, 0x2174, arm64_l_2174);
arm64_l_2108:
	/* 0x2108: ldr w11, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_210c:
	/* 0x210c: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2110:
	/* 0x2110: b.hi 2120 <filter_16ty_range+0x1dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2110, 0x2120, arm64_l_2120);
arm64_l_2114:
	/* 0x2114: ldr w11, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2118:
	/* 0x2118: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_211c:
	/* 0x211c: b.cs 2088 <filter_16ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x211c, 0x2088, arm64_l_2088);
arm64_l_2120:
	/* 0x2120: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_2124:
	/* 0x2124: b.cc 2174 <filter_16ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2124, 0x2174, arm64_l_2174);
arm64_l_2128:
	/* 0x2128: ldr w11, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_212c:
	/* 0x212c: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2130:
	/* 0x2130: b.hi 2140 <filter_16ty_range+0x1fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2130, 0x2140, arm64_l_2140);
arm64_l_2134:
	/* 0x2134: ldr w11, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_2138:
	/* 0x2138: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_213c:
	/* 0x213c: b.cs 2088 <filter_16ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x213c, 0x2088, arm64_l_2088);
arm64_l_2140:
	/* 0x2140: cmp w9, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2144:
	/* 0x2144: b.cc 2174 <filter_16ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2144, 0x2174, arm64_l_2174);
arm64_l_2148:
	/* 0x2148: ldr w11, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_214c:
	/* 0x214c: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2150:
	/* 0x2150: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2154:
	/* 0x2154: b.hi 2164 <filter_16ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2154, 0x2164, arm64_l_2164);
arm64_l_2158:
	/* 0x2158: ldr w11, [x0, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_215c:
	/* 0x215c: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2160:
	/* 0x2160: b.cs 2088 <filter_16ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2160, 0x2088, arm64_l_2088);
arm64_l_2164:
	/* 0x2164: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2168:
	/* 0x2168: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_216c:
	/* 0x216c: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2170:
	/* 0x2170: ret */
	ARM64_SIM_A64_RET();
arm64_l_2174:
	/* 0x2174: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2178:
	/* 0x2178: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_217c:
	/* 0x217c: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2180:
	/* 0x2180: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2184:
	/* 0x2184: ret */
	ARM64_SIM_A64_RET();
arm64_l_2188:
	/* 0x2188: sub sp, sp, #0x30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_218c:
	/* 0x218c: str x30, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2190:
	/* 0x2190: stp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2194:
	/* 0x2194: ldrb w8, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2198:
	/* 0x2198: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_219c:
	/* 0x219c: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_21a0:
	/* 0x21a0: add x9, sp, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_21a4:
	/* 0x21a4: str w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_21a8:
	/* 0x21a8: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_21ac:
	/* 0x21ac: mov x20, x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_21b0:
	/* 0x21b0: add x1, sp, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_21b4:
	/* 0x21b4: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_21b8:
	/* 0x21b8: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_21bc:
	/* 0x21bc: cbz x0, 2230 <filter_16ty_map+0xa8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x21bc, 0x2230, arm64_l_2230);
arm64_l_21c0:
	/* 0x21c0: ldrh w8, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_21c4:
	/* 0x21c4: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_21c8:
	/* 0x21c8: add x1, sp, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_21cc:
	/* 0x21cc: mov w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_21d0:
	/* 0x21d0: str x8, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_21d4:
	/* 0x21d4: add x8, sp, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_21d8:
	/* 0x21d8: blr x9 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_21dc:
	/* 0x21dc: ldr w9, [x19, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_21e0:
	/* 0x21e0: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_21e4:
	/* 0x21e4: cmp w9, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_21e8:
	/* 0x21e8: b.hi 222c <filter_16ty_map+0xa4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x21e8, 0x222c, arm64_l_222c);
arm64_l_21ec:
	/* 0x21ec: mov w11, #0x8400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 33792ULL);
arm64_l_21f0:
	/* 0x21f0: lsl w10, w20, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_21f4:
	/* 0x21f4: movk w11, #0x3003, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 12291ULL);
arm64_l_21f8:
	/* 0x21f8: tst w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_21fc:
	/* 0x21fc: b.eq 220c <filter_16ty_map+0x84> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x21fc, 0x220c, arm64_l_220c);
arm64_l_2200:
	/* 0x2200: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_2204:
	/* 0x2204: cset w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2208:
	/* 0x2208: b 222c <filter_16ty_map+0xa4> */
	ARM64_SIM_A64_JMP(0x2208, 0x222c, arm64_l_222c);
arm64_l_220c:
	/* 0x220c: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2210:
	/* 0x2210: lsl w9, w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2214:
	/* 0x2214: mov w10, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_2218:
	/* 0x2218: movk w10, #0xc, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 12ULL);
arm64_l_221c:
	/* 0x221c: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2220:
	/* 0x2220: b.eq 222c <filter_16ty_map+0xa4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2220, 0x222c, arm64_l_222c);
arm64_l_2224:
	/* 0x2224: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_2228:
	/* 0x2228: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_222c:
	/* 0x222c: mov w0, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2230:
	/* 0x2230: ldp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2234:
	/* 0x2234: ldr x30, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2238:
	/* 0x2238: add sp, sp, #0x30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_223c:
	/* 0x223c: ret */
	ARM64_SIM_A64_RET();
arm64_l_2240:
	/* 0x2240: ldr w8, [x0, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2244:
	/* 0x2244: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_2248:
	/* 0x2248: b.hi 22bc <filter_32ty_selector_val+0x7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2248, 0x22bc, arm64_l_22bc);
arm64_l_224c:
	/* 0x224c: mov x10, #0x40 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 64ULL);
arm64_l_2250:
	/* 0x2250: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2254:
	/* 0x2254: movk x10, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_2258:
	/* 0x2258: lsl x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_225c:
	/* 0x225c: movk x10, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_2260:
	/* 0x2260: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2264:
	/* 0x2264: b.eq 2270 <filter_32ty_selector_val+0x30> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2264, 0x2270, arm64_l_2270);
arm64_l_2268:
	/* 0x2268: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_226c:
	/* 0x226c: ret */
	ARM64_SIM_A64_RET();
arm64_l_2270:
	/* 0x2270: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2274:
	/* 0x2274: lsl x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2278:
	/* 0x2278: tst x9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_227c:
	/* 0x227c: b.eq 229c <filter_32ty_selector_val+0x5c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x227c, 0x229c, arm64_l_229c);
arm64_l_2280:
	/* 0x2280: ldr w9, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2284:
	/* 0x2284: ldr w10, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2288:
	/* 0x2288: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_228c:
	/* 0x228c: b.ne 233c <filter_32ty_selector_val+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x228c, 0x233c, arm64_l_233c);
arm64_l_2290:
	/* 0x2290: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2294:
	/* 0x2294: cset w0, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_2298:
	/* 0x2298: ret */
	ARM64_SIM_A64_RET();
arm64_l_229c:
	/* 0x229c: cmp x8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_22a0:
	/* 0x22a0: b.ne 22bc <filter_32ty_selector_val+0x7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x22a0, 0x22bc, arm64_l_22bc);
arm64_l_22a4:
	/* 0x22a4: ldr w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_22a8:
	/* 0x22a8: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_22ac:
	/* 0x22ac: tst w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_22b0:
	/* 0x22b0: b.eq 23e8 <filter_32ty_selector_val+0x1a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x22b0, 0x23e8, arm64_l_23e8);
arm64_l_22b4:
	/* 0x22b4: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_22b8:
	/* 0x22b8: ret */
	ARM64_SIM_A64_RET();
arm64_l_22bc:
	/* 0x22bc: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_22c0:
	/* 0x22c0: b.eq 2304 <filter_32ty_selector_val+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x22c0, 0x2304, arm64_l_2304);
arm64_l_22c4:
	/* 0x22c4: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_22c8:
	/* 0x22c8: b.ne 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x22c8, 0x2590, arm64_l_2590);
arm64_l_22cc:
	/* 0x22cc: ldr w8, [x0, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_22d0:
	/* 0x22d0: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_22d4:
	/* 0x22d4: b.hi 2420 <filter_32ty_selector_val+0x1e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x22d4, 0x2420, arm64_l_2420);
arm64_l_22d8:
	/* 0x22d8: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_22dc:
	/* 0x22dc: lsl w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_22e0:
	/* 0x22e0: mov w9, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_22e4:
	/* 0x22e4: tst w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_22e8:
	/* 0x22e8: b.eq 2420 <filter_32ty_selector_val+0x1e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x22e8, 0x2420, arm64_l_2420);
arm64_l_22ec:
	/* 0x22ec: ldr w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_22f0:
	/* 0x22f0: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_22f4:
	/* 0x22f4: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_22f8:
	/* 0x22f8: b.ge 23c8 <filter_32ty_selector_val+0x188> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x22f8, 0x23c8, arm64_l_23c8);
arm64_l_22fc:
	/* 0x22fc: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2300:
	/* 0x2300: ret */
	ARM64_SIM_A64_RET();
arm64_l_2304:
	/* 0x2304: ldr w8, [x0, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_2308:
	/* 0x2308: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_230c:
	/* 0x230c: b.hi 2408 <filter_32ty_selector_val+0x1c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x230c, 0x2408, arm64_l_2408);
arm64_l_2310:
	/* 0x2310: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2314:
	/* 0x2314: lsl w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2318:
	/* 0x2318: mov w9, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_231c:
	/* 0x231c: tst w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2320:
	/* 0x2320: b.eq 2408 <filter_32ty_selector_val+0x1c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2320, 0x2408, arm64_l_2408);
arm64_l_2324:
	/* 0x2324: ldr w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2328:
	/* 0x2328: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_232c:
	/* 0x232c: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2330:
	/* 0x2330: b.le 23a8 <filter_32ty_selector_val+0x168> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2330, 0x23a8, arm64_l_23a8);
arm64_l_2334:
	/* 0x2334: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2338:
	/* 0x2338: ret */
	ARM64_SIM_A64_RET();
arm64_l_233c:
	/* 0x233c: ldr w10, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2340:
	/* 0x2340: cmp w10, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_2344:
	/* 0x2344: b.cc 237c <filter_32ty_selector_val+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2344, 0x237c, arm64_l_237c);
arm64_l_2348:
	/* 0x2348: ldr w11, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_234c:
	/* 0x234c: cmp w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2350:
	/* 0x2350: b.eq 2290 <filter_32ty_selector_val+0x50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2350, 0x2290, arm64_l_2290);
arm64_l_2354:
	/* 0x2354: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2358:
	/* 0x2358: b.cc 237c <filter_32ty_selector_val+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2358, 0x237c, arm64_l_237c);
arm64_l_235c:
	/* 0x235c: ldr w11, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2360:
	/* 0x2360: cmp w9, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2364:
	/* 0x2364: b.eq 2290 <filter_32ty_selector_val+0x50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2364, 0x2290, arm64_l_2290);
arm64_l_2368:
	/* 0x2368: cmp w10, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_236c:
	/* 0x236c: b.cc 237c <filter_32ty_selector_val+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x236c, 0x237c, arm64_l_237c);
arm64_l_2370:
	/* 0x2370: ldr w10, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2374:
	/* 0x2374: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2378:
	/* 0x2378: b.eq 2290 <filter_32ty_selector_val+0x50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2378, 0x2290, arm64_l_2290);
arm64_l_237c:
	/* 0x237c: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_2380:
	/* 0x2380: b.hi 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2380, 0x2590, arm64_l_2590);
arm64_l_2384:
	/* 0x2384: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2388:
	/* 0x2388: lsl x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_238c:
	/* 0x238c: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_2390:
	/* 0x2390: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_2394:
	/* 0x2394: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_2398:
	/* 0x2398: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_239c:
	/* 0x239c: b.eq 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x239c, 0x2590, arm64_l_2590);
arm64_l_23a0:
	/* 0x23a0: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_23a4:
	/* 0x23a4: ret */
	ARM64_SIM_A64_RET();
arm64_l_23a8:
	/* 0x23a8: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_23ac:
	/* 0x23ac: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_23b0:
	/* 0x23b0: b.cc 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x23b0, 0x2590, arm64_l_2590);
arm64_l_23b4:
	/* 0x23b4: ldr w10, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_23b8:
	/* 0x23b8: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_23bc:
	/* 0x23bc: b.le 2478 <filter_32ty_selector_val+0x238> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x23bc, 0x2478, arm64_l_2478);
arm64_l_23c0:
	/* 0x23c0: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_23c4:
	/* 0x23c4: ret */
	ARM64_SIM_A64_RET();
arm64_l_23c8:
	/* 0x23c8: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_23cc:
	/* 0x23cc: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_23d0:
	/* 0x23d0: b.cc 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x23d0, 0x2590, arm64_l_2590);
arm64_l_23d4:
	/* 0x23d4: ldr w10, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_23d8:
	/* 0x23d8: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_23dc:
	/* 0x23dc: b.ge 2494 <filter_32ty_selector_val+0x254> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x23dc, 0x2494, arm64_l_2494);
arm64_l_23e0:
	/* 0x23e0: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_23e4:
	/* 0x23e4: ret */
	ARM64_SIM_A64_RET();
arm64_l_23e8:
	/* 0x23e8: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_23ec:
	/* 0x23ec: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_23f0:
	/* 0x23f0: b.cc 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x23f0, 0x2590, arm64_l_2590);
arm64_l_23f4:
	/* 0x23f4: ldr w10, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_23f8:
	/* 0x23f8: tst w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_23fc:
	/* 0x23fc: b.eq 24b0 <filter_32ty_selector_val+0x270> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x23fc, 0x24b0, arm64_l_24b0);
arm64_l_2400:
	/* 0x2400: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2404:
	/* 0x2404: ret */
	ARM64_SIM_A64_RET();
arm64_l_2408:
	/* 0x2408: ldr w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_240c:
	/* 0x240c: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2410:
	/* 0x2410: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2414:
	/* 0x2414: b.ls 2438 <filter_32ty_selector_val+0x1f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2414, 0x2438, arm64_l_2438);
arm64_l_2418:
	/* 0x2418: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_241c:
	/* 0x241c: ret */
	ARM64_SIM_A64_RET();
arm64_l_2420:
	/* 0x2420: ldr w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2424:
	/* 0x2424: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2428:
	/* 0x2428: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_242c:
	/* 0x242c: b.cs 2458 <filter_32ty_selector_val+0x218> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x242c, 0x2458, arm64_l_2458);
arm64_l_2430:
	/* 0x2430: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2434:
	/* 0x2434: ret */
	ARM64_SIM_A64_RET();
arm64_l_2438:
	/* 0x2438: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_243c:
	/* 0x243c: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_2440:
	/* 0x2440: b.cc 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2440, 0x2590, arm64_l_2590);
arm64_l_2444:
	/* 0x2444: ldr w10, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_2448:
	/* 0x2448: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_244c:
	/* 0x244c: b.ls 24cc <filter_32ty_selector_val+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x244c, 0x24cc, arm64_l_24cc);
arm64_l_2450:
	/* 0x2450: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2454:
	/* 0x2454: ret */
	ARM64_SIM_A64_RET();
arm64_l_2458:
	/* 0x2458: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_245c:
	/* 0x245c: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_2460:
	/* 0x2460: b.cc 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2460, 0x2590, arm64_l_2590);
arm64_l_2464:
	/* 0x2464: ldr w10, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_2468:
	/* 0x2468: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_246c:
	/* 0x246c: b.cs 24e8 <filter_32ty_selector_val+0x2a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x246c, 0x24e8, arm64_l_24e8);
arm64_l_2470:
	/* 0x2470: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2474:
	/* 0x2474: ret */
	ARM64_SIM_A64_RET();
arm64_l_2478:
	/* 0x2478: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_247c:
	/* 0x247c: b.cc 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x247c, 0x2590, arm64_l_2590);
arm64_l_2480:
	/* 0x2480: ldr w10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2484:
	/* 0x2484: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2488:
	/* 0x2488: b.le 2504 <filter_32ty_selector_val+0x2c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2488, 0x2504, arm64_l_2504);
arm64_l_248c:
	/* 0x248c: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2490:
	/* 0x2490: ret */
	ARM64_SIM_A64_RET();
arm64_l_2494:
	/* 0x2494: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2498:
	/* 0x2498: b.cc 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2498, 0x2590, arm64_l_2590);
arm64_l_249c:
	/* 0x249c: ldr w10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_24a0:
	/* 0x24a0: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_24a4:
	/* 0x24a4: b.ge 2520 <filter_32ty_selector_val+0x2e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x24a4, 0x2520, arm64_l_2520);
arm64_l_24a8:
	/* 0x24a8: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_24ac:
	/* 0x24ac: ret */
	ARM64_SIM_A64_RET();
arm64_l_24b0:
	/* 0x24b0: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_24b4:
	/* 0x24b4: b.cc 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x24b4, 0x2590, arm64_l_2590);
arm64_l_24b8:
	/* 0x24b8: ldr w10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_24bc:
	/* 0x24bc: tst w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_24c0:
	/* 0x24c0: b.eq 253c <filter_32ty_selector_val+0x2fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x24c0, 0x253c, arm64_l_253c);
arm64_l_24c4:
	/* 0x24c4: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_24c8:
	/* 0x24c8: ret */
	ARM64_SIM_A64_RET();
arm64_l_24cc:
	/* 0x24cc: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_24d0:
	/* 0x24d0: b.cc 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x24d0, 0x2590, arm64_l_2590);
arm64_l_24d4:
	/* 0x24d4: ldr w10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_24d8:
	/* 0x24d8: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_24dc:
	/* 0x24dc: b.ls 2558 <filter_32ty_selector_val+0x318> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x24dc, 0x2558, arm64_l_2558);
arm64_l_24e0:
	/* 0x24e0: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_24e4:
	/* 0x24e4: ret */
	ARM64_SIM_A64_RET();
arm64_l_24e8:
	/* 0x24e8: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_24ec:
	/* 0x24ec: b.cc 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x24ec, 0x2590, arm64_l_2590);
arm64_l_24f0:
	/* 0x24f0: ldr w10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_24f4:
	/* 0x24f4: cmp w8, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_24f8:
	/* 0x24f8: b.cs 2574 <filter_32ty_selector_val+0x334> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x24f8, 0x2574, arm64_l_2574);
arm64_l_24fc:
	/* 0x24fc: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2500:
	/* 0x2500: ret */
	ARM64_SIM_A64_RET();
arm64_l_2504:
	/* 0x2504: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2508:
	/* 0x2508: b.cc 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2508, 0x2590, arm64_l_2590);
arm64_l_250c:
	/* 0x250c: ldr w9, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2510:
	/* 0x2510: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2514:
	/* 0x2514: b.le 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2514, 0x2590, arm64_l_2590);
arm64_l_2518:
	/* 0x2518: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_251c:
	/* 0x251c: ret */
	ARM64_SIM_A64_RET();
arm64_l_2520:
	/* 0x2520: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2524:
	/* 0x2524: b.cc 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2524, 0x2590, arm64_l_2590);
arm64_l_2528:
	/* 0x2528: ldr w9, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_252c:
	/* 0x252c: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2530:
	/* 0x2530: b.ge 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x2530, 0x2590, arm64_l_2590);
arm64_l_2534:
	/* 0x2534: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2538:
	/* 0x2538: ret */
	ARM64_SIM_A64_RET();
arm64_l_253c:
	/* 0x253c: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2540:
	/* 0x2540: b.cc 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2540, 0x2590, arm64_l_2590);
arm64_l_2544:
	/* 0x2544: ldr w9, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2548:
	/* 0x2548: tst w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_254c:
	/* 0x254c: b.eq 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x254c, 0x2590, arm64_l_2590);
arm64_l_2550:
	/* 0x2550: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2554:
	/* 0x2554: ret */
	ARM64_SIM_A64_RET();
arm64_l_2558:
	/* 0x2558: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_255c:
	/* 0x255c: b.cc 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x255c, 0x2590, arm64_l_2590);
arm64_l_2560:
	/* 0x2560: ldr w9, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2564:
	/* 0x2564: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2568:
	/* 0x2568: b.ls 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2568, 0x2590, arm64_l_2590);
arm64_l_256c:
	/* 0x256c: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2570:
	/* 0x2570: ret */
	ARM64_SIM_A64_RET();
arm64_l_2574:
	/* 0x2574: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2578:
	/* 0x2578: b.cc 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2578, 0x2590, arm64_l_2590);
arm64_l_257c:
	/* 0x257c: ldr w9, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2580:
	/* 0x2580: cmp w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2584:
	/* 0x2584: b.cs 2590 <filter_32ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2584, 0x2590, arm64_l_2590);
arm64_l_2588:
	/* 0x2588: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_258c:
	/* 0x258c: ret */
	ARM64_SIM_A64_RET();
arm64_l_2590:
	/* 0x2590: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2594:
	/* 0x2594: ret */
	ARM64_SIM_A64_RET();
arm64_l_2598:
	/* 0x2598: ldr w9, [x0, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_259c:
	/* 0x259c: ldr w8, [x0, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_25a0:
	/* 0x25a0: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_25a4:
	/* 0x25a4: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_25a8:
	/* 0x25a8: lsl w9, w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_25ac:
	/* 0x25ac: mov w10, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_25b0:
	/* 0x25b0: and w9, w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_25b4:
	/* 0x25b4: ccmp w9, #0x0, #0x4, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 4), 0ULL);
arm64_l_25b8:
	/* 0x25b8: b.eq 26b8 <filter_32ty_range+0x120> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x25b8, 0x26b8, arm64_l_26b8);
arm64_l_25bc:
	/* 0x25bc: ldr w10, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_25c0:
	/* 0x25c0: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_25c4:
	/* 0x25c4: b.ne 264c <filter_32ty_range+0xb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x25c4, 0x264c, arm64_l_264c);
arm64_l_25c8:
	/* 0x25c8: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_25cc:
	/* 0x25cc: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_25d0:
	/* 0x25d0: b.gt 25e0 <filter_32ty_range+0x48> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x25d0, 0x25e0, arm64_l_25e0);
arm64_l_25d4:
	/* 0x25d4: ldr w9, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_25d8:
	/* 0x25d8: cmp w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_25dc:
	/* 0x25dc: b.le 26dc <filter_32ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x25dc, 0x26dc, arm64_l_26dc);
arm64_l_25e0:
	/* 0x25e0: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_25e4:
	/* 0x25e4: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_25e8:
	/* 0x25e8: b.cc 27c8 <filter_32ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x25e8, 0x27c8, arm64_l_27c8);
arm64_l_25ec:
	/* 0x25ec: ldr w11, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_25f0:
	/* 0x25f0: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_25f4:
	/* 0x25f4: b.gt 2604 <filter_32ty_range+0x6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x25f4, 0x2604, arm64_l_2604);
arm64_l_25f8:
	/* 0x25f8: ldr w11, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_25fc:
	/* 0x25fc: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2600:
	/* 0x2600: b.le 26dc <filter_32ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2600, 0x26dc, arm64_l_26dc);
arm64_l_2604:
	/* 0x2604: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_2608:
	/* 0x2608: b.cc 27c8 <filter_32ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2608, 0x27c8, arm64_l_27c8);
arm64_l_260c:
	/* 0x260c: ldr w11, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2610:
	/* 0x2610: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2614:
	/* 0x2614: b.gt 2624 <filter_32ty_range+0x8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2614, 0x2624, arm64_l_2624);
arm64_l_2618:
	/* 0x2618: ldr w11, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_261c:
	/* 0x261c: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2620:
	/* 0x2620: b.le 26dc <filter_32ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2620, 0x26dc, arm64_l_26dc);
arm64_l_2624:
	/* 0x2624: cmp w9, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2628:
	/* 0x2628: b.cc 27c8 <filter_32ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2628, 0x27c8, arm64_l_27c8);
arm64_l_262c:
	/* 0x262c: ldr w11, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2630:
	/* 0x2630: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2634:
	/* 0x2634: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2638:
	/* 0x2638: b.gt 27b8 <filter_32ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2638, 0x27b8, arm64_l_27b8);
arm64_l_263c:
	/* 0x263c: ldr w11, [x0, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_2640:
	/* 0x2640: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2644:
	/* 0x2644: b.le 26dc <filter_32ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2644, 0x26dc, arm64_l_26dc);
arm64_l_2648:
	/* 0x2648: b 27b8 <filter_32ty_range+0x220> */
	ARM64_SIM_A64_JMP(0x2648, 0x27b8, arm64_l_27b8);
arm64_l_264c:
	/* 0x264c: ldp w9, w12, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X9, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2650:
	/* 0x2650: ldr w11, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2654:
	/* 0x2654: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2658:
	/* 0x2658: ccmp w10, w12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_265c:
	/* 0x265c: cset w9, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LE, 0);
arm64_l_2660:
	/* 0x2660: cmp w11, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2664:
	/* 0x2664: b.cc 27b8 <filter_32ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2664, 0x27b8, arm64_l_27b8);
arm64_l_2668:
	/* 0x2668: ldp w12, w13, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_266c:
	/* 0x266c: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2670:
	/* 0x2670: ccmp w10, w13, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_2674:
	/* 0x2674: csinc w9, w9, wzr, gt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_GT, 0);
arm64_l_2678:
	/* 0x2678: cmp w11, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_267c:
	/* 0x267c: b.cc 27b8 <filter_32ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x267c, 0x27b8, arm64_l_27b8);
arm64_l_2680:
	/* 0x2680: ldp w12, w13, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2684:
	/* 0x2684: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2688:
	/* 0x2688: ccmp w10, w13, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_268c:
	/* 0x268c: csinc w9, w9, wzr, gt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_GT, 0);
arm64_l_2690:
	/* 0x2690: cmp w11, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2694:
	/* 0x2694: b.cc 27b8 <filter_32ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2694, 0x27b8, arm64_l_27b8);
arm64_l_2698:
	/* 0x2698: ldp w11, w12, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_269c:
	/* 0x269c: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26a0:
	/* 0x26a0: ccmp w10, w12, #0x0, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 0), 0);
arm64_l_26a4:
	/* 0x26a4: csinc w9, w9, wzr, gt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_GT, 0);
arm64_l_26a8:
	/* 0x26a8: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_26ac:
	/* 0x26ac: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_26b0:
	/* 0x26b0: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_26b4:
	/* 0x26b4: ret */
	ARM64_SIM_A64_RET();
arm64_l_26b8:
	/* 0x26b8: ldr w10, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_26bc:
	/* 0x26bc: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_26c0:
	/* 0x26c0: b.ne 26e4 <filter_32ty_range+0x14c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x26c0, 0x26e4, arm64_l_26e4);
arm64_l_26c4:
	/* 0x26c4: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_26c8:
	/* 0x26c8: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26cc:
	/* 0x26cc: b.hi 2750 <filter_32ty_range+0x1b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x26cc, 0x2750, arm64_l_2750);
arm64_l_26d0:
	/* 0x26d0: ldr w9, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_26d4:
	/* 0x26d4: cmp w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26d8:
	/* 0x26d8: b.hi 2750 <filter_32ty_range+0x1b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x26d8, 0x2750, arm64_l_2750);
arm64_l_26dc:
	/* 0x26dc: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_26e0:
	/* 0x26e0: ret */
	ARM64_SIM_A64_RET();
arm64_l_26e4:
	/* 0x26e4: ldp w9, w12, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X9, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_26e8:
	/* 0x26e8: ldr w11, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_26ec:
	/* 0x26ec: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26f0:
	/* 0x26f0: ccmp w10, w12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_26f4:
	/* 0x26f4: cset w9, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LS, 0);
arm64_l_26f8:
	/* 0x26f8: cmp w11, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_26fc:
	/* 0x26fc: b.cc 27b8 <filter_32ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x26fc, 0x27b8, arm64_l_27b8);
arm64_l_2700:
	/* 0x2700: ldp w12, w13, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2704:
	/* 0x2704: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2708:
	/* 0x2708: ccmp w10, w13, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_270c:
	/* 0x270c: csinc w9, w9, wzr, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_2710:
	/* 0x2710: cmp w11, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_2714:
	/* 0x2714: b.cc 27b8 <filter_32ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2714, 0x27b8, arm64_l_27b8);
arm64_l_2718:
	/* 0x2718: ldp w12, w13, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_271c:
	/* 0x271c: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2720:
	/* 0x2720: ccmp w10, w13, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_2724:
	/* 0x2724: csinc w9, w9, wzr, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_2728:
	/* 0x2728: cmp w11, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_272c:
	/* 0x272c: b.cc 27b8 <filter_32ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x272c, 0x27b8, arm64_l_27b8);
arm64_l_2730:
	/* 0x2730: ldp w11, w12, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2734:
	/* 0x2734: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2738:
	/* 0x2738: ccmp w10, w12, #0x2, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X10, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 2), 0);
arm64_l_273c:
	/* 0x273c: csinc w9, w9, wzr, hi */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_2740:
	/* 0x2740: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2744:
	/* 0x2744: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2748:
	/* 0x2748: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_274c:
	/* 0x274c: ret */
	ARM64_SIM_A64_RET();
arm64_l_2750:
	/* 0x2750: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2754:
	/* 0x2754: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2758:
	/* 0x2758: b.cc 27c8 <filter_32ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2758, 0x27c8, arm64_l_27c8);
arm64_l_275c:
	/* 0x275c: ldr w11, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2760:
	/* 0x2760: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2764:
	/* 0x2764: b.hi 2774 <filter_32ty_range+0x1dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2764, 0x2774, arm64_l_2774);
arm64_l_2768:
	/* 0x2768: ldr w11, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_276c:
	/* 0x276c: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2770:
	/* 0x2770: b.ls 26dc <filter_32ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2770, 0x26dc, arm64_l_26dc);
arm64_l_2774:
	/* 0x2774: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_2778:
	/* 0x2778: b.cc 27c8 <filter_32ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2778, 0x27c8, arm64_l_27c8);
arm64_l_277c:
	/* 0x277c: ldr w11, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2780:
	/* 0x2780: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2784:
	/* 0x2784: b.hi 2794 <filter_32ty_range+0x1fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2784, 0x2794, arm64_l_2794);
arm64_l_2788:
	/* 0x2788: ldr w11, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_278c:
	/* 0x278c: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2790:
	/* 0x2790: b.ls 26dc <filter_32ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2790, 0x26dc, arm64_l_26dc);
arm64_l_2794:
	/* 0x2794: cmp w9, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2798:
	/* 0x2798: b.cc 27c8 <filter_32ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2798, 0x27c8, arm64_l_27c8);
arm64_l_279c:
	/* 0x279c: ldr w11, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_27a0:
	/* 0x27a0: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_27a4:
	/* 0x27a4: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_27a8:
	/* 0x27a8: b.hi 27b8 <filter_32ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x27a8, 0x27b8, arm64_l_27b8);
arm64_l_27ac:
	/* 0x27ac: ldr w11, [x0, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_27b0:
	/* 0x27b0: cmp w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_27b4:
	/* 0x27b4: b.ls 26dc <filter_32ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x27b4, 0x26dc, arm64_l_26dc);
arm64_l_27b8:
	/* 0x27b8: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_27bc:
	/* 0x27bc: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_27c0:
	/* 0x27c0: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_27c4:
	/* 0x27c4: ret */
	ARM64_SIM_A64_RET();
arm64_l_27c8:
	/* 0x27c8: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_27cc:
	/* 0x27cc: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_27d0:
	/* 0x27d0: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_27d4:
	/* 0x27d4: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_27d8:
	/* 0x27d8: ret */
	ARM64_SIM_A64_RET();
arm64_l_27dc:
	/* 0x27dc: sub sp, sp, #0x30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_27e0:
	/* 0x27e0: str x30, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_27e4:
	/* 0x27e4: stp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_27e8:
	/* 0x27e8: ldrb w8, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_27ec:
	/* 0x27ec: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_27f0:
	/* 0x27f0: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_27f4:
	/* 0x27f4: add x9, sp, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_27f8:
	/* 0x27f8: str w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_27fc:
	/* 0x27fc: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2800:
	/* 0x2800: mov x20, x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2804:
	/* 0x2804: add x1, sp, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_2808:
	/* 0x2808: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_280c:
	/* 0x280c: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_2810:
	/* 0x2810: cbz x0, 2884 <filter_32ty_map+0xa8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2810, 0x2884, arm64_l_2884);
arm64_l_2814:
	/* 0x2814: ldr w8, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2818:
	/* 0x2818: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_281c:
	/* 0x281c: add x1, sp, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2820:
	/* 0x2820: mov w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2824:
	/* 0x2824: str x8, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2828:
	/* 0x2828: add x8, sp, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_282c:
	/* 0x282c: blr x9 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_2830:
	/* 0x2830: ldr w9, [x19, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2834:
	/* 0x2834: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2838:
	/* 0x2838: cmp w9, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_283c:
	/* 0x283c: b.hi 2880 <filter_32ty_map+0xa4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x283c, 0x2880, arm64_l_2880);
arm64_l_2840:
	/* 0x2840: mov w11, #0x8400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 33792ULL);
arm64_l_2844:
	/* 0x2844: lsl w10, w20, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2848:
	/* 0x2848: movk w11, #0x3003, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 12291ULL);
arm64_l_284c:
	/* 0x284c: tst w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2850:
	/* 0x2850: b.eq 2860 <filter_32ty_map+0x84> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2850, 0x2860, arm64_l_2860);
arm64_l_2854:
	/* 0x2854: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_2858:
	/* 0x2858: cset w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_285c:
	/* 0x285c: b 2880 <filter_32ty_map+0xa4> */
	ARM64_SIM_A64_JMP(0x285c, 0x2880, arm64_l_2880);
arm64_l_2860:
	/* 0x2860: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2864:
	/* 0x2864: lsl w9, w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2868:
	/* 0x2868: mov w10, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_286c:
	/* 0x286c: movk w10, #0xc, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 12ULL);
arm64_l_2870:
	/* 0x2870: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2874:
	/* 0x2874: b.eq 2880 <filter_32ty_map+0xa4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2874, 0x2880, arm64_l_2880);
arm64_l_2878:
	/* 0x2878: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_287c:
	/* 0x287c: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_2880:
	/* 0x2880: mov w0, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2884:
	/* 0x2884: ldp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2888:
	/* 0x2888: ldr x30, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_288c:
	/* 0x288c: add sp, sp, #0x30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_2890:
	/* 0x2890: ret */
	ARM64_SIM_A64_RET();
arm64_l_2894:
	/* 0x2894: ldr w8, [x0, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2898:
	/* 0x2898: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_289c:
	/* 0x289c: b.hi 2910 <filter_8ty_selector_val+0x7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x289c, 0x2910, arm64_l_2910);
arm64_l_28a0:
	/* 0x28a0: mov x10, #0x40 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 64ULL);
arm64_l_28a4:
	/* 0x28a4: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28a8:
	/* 0x28a8: movk x10, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_28ac:
	/* 0x28ac: lsl x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_28b0:
	/* 0x28b0: movk x10, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_28b4:
	/* 0x28b4: tst x9, x10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_28b8:
	/* 0x28b8: b.eq 28c4 <filter_8ty_selector_val+0x30> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x28b8, 0x28c4, arm64_l_28c4);
arm64_l_28bc:
	/* 0x28bc: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28c0:
	/* 0x28c0: ret */
	ARM64_SIM_A64_RET();
arm64_l_28c4:
	/* 0x28c4: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28c8:
	/* 0x28c8: lsl x9, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_28cc:
	/* 0x28cc: tst x9, #0x18 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_28d0:
	/* 0x28d0: b.eq 28f0 <filter_8ty_selector_val+0x5c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x28d0, 0x28f0, arm64_l_28f0);
arm64_l_28d4:
	/* 0x28d4: ldrb w9, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_28d8:
	/* 0x28d8: ldr w10, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_28dc:
	/* 0x28dc: cmp w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_28e0:
	/* 0x28e0: b.ne 2990 <filter_8ty_selector_val+0xfc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x28e0, 0x2990, arm64_l_2990);
arm64_l_28e4:
	/* 0x28e4: cmp w8, #0x3 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_28e8:
	/* 0x28e8: cset w0, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_28ec:
	/* 0x28ec: ret */
	ARM64_SIM_A64_RET();
arm64_l_28f0:
	/* 0x28f0: cmp x8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_28f4:
	/* 0x28f4: b.ne 2910 <filter_8ty_selector_val+0x7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x28f4, 0x2910, arm64_l_2910);
arm64_l_28f8:
	/* 0x28f8: ldrb w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_28fc:
	/* 0x28fc: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2900:
	/* 0x2900: tst w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2904:
	/* 0x2904: b.eq 2a3c <filter_8ty_selector_val+0x1a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2904, 0x2a3c, arm64_l_2a3c);
arm64_l_2908:
	/* 0x2908: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_290c:
	/* 0x290c: ret */
	ARM64_SIM_A64_RET();
arm64_l_2910:
	/* 0x2910: cmp w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2914:
	/* 0x2914: b.eq 2958 <filter_8ty_selector_val+0xc4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2914, 0x2958, arm64_l_2958);
arm64_l_2918:
	/* 0x2918: cmp w8, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_291c:
	/* 0x291c: b.ne 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x291c, 0x2be4, arm64_l_2be4);
arm64_l_2920:
	/* 0x2920: ldr w8, [x0, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_2924:
	/* 0x2924: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2928:
	/* 0x2928: b.hi 2a74 <filter_8ty_selector_val+0x1e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2928, 0x2a74, arm64_l_2a74);
arm64_l_292c:
	/* 0x292c: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2930:
	/* 0x2930: lsl w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2934:
	/* 0x2934: mov w9, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2938:
	/* 0x2938: tst w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_293c:
	/* 0x293c: b.eq 2a74 <filter_8ty_selector_val+0x1e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x293c, 0x2a74, arm64_l_2a74);
arm64_l_2940:
	/* 0x2940: ldrsb w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDRSB, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2944:
	/* 0x2944: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2948:
	/* 0x2948: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_294c:
	/* 0x294c: b.le 2a1c <filter_8ty_selector_val+0x188> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x294c, 0x2a1c, arm64_l_2a1c);
arm64_l_2950:
	/* 0x2950: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2954:
	/* 0x2954: ret */
	ARM64_SIM_A64_RET();
arm64_l_2958:
	/* 0x2958: ldr w8, [x0, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_295c:
	/* 0x295c: cmp w8, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2960:
	/* 0x2960: b.hi 2a5c <filter_8ty_selector_val+0x1c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2960, 0x2a5c, arm64_l_2a5c);
arm64_l_2964:
	/* 0x2964: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2968:
	/* 0x2968: lsl w8, w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_296c:
	/* 0x296c: mov w9, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2970:
	/* 0x2970: tst w8, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2974:
	/* 0x2974: b.eq 2a5c <filter_8ty_selector_val+0x1c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2974, 0x2a5c, arm64_l_2a5c);
arm64_l_2978:
	/* 0x2978: ldrsb w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDRSB, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_297c:
	/* 0x297c: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2980:
	/* 0x2980: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2984:
	/* 0x2984: b.ge 29fc <filter_8ty_selector_val+0x168> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x2984, 0x29fc, arm64_l_29fc);
arm64_l_2988:
	/* 0x2988: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_298c:
	/* 0x298c: ret */
	ARM64_SIM_A64_RET();
arm64_l_2990:
	/* 0x2990: ldr w10, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2994:
	/* 0x2994: cmp w10, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_2998:
	/* 0x2998: b.cc 29d0 <filter_8ty_selector_val+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2998, 0x29d0, arm64_l_29d0);
arm64_l_299c:
	/* 0x299c: ldr w11, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_29a0:
	/* 0x29a0: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_29a4:
	/* 0x29a4: b.eq 28e4 <filter_8ty_selector_val+0x50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x29a4, 0x28e4, arm64_l_28e4);
arm64_l_29a8:
	/* 0x29a8: cmp w10, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_29ac:
	/* 0x29ac: b.cc 29d0 <filter_8ty_selector_val+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x29ac, 0x29d0, arm64_l_29d0);
arm64_l_29b0:
	/* 0x29b0: ldr w11, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_29b4:
	/* 0x29b4: cmp w11, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_29b8:
	/* 0x29b8: b.eq 28e4 <filter_8ty_selector_val+0x50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x29b8, 0x28e4, arm64_l_28e4);
arm64_l_29bc:
	/* 0x29bc: cmp w10, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_29c0:
	/* 0x29c0: b.cc 29d0 <filter_8ty_selector_val+0x13c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x29c0, 0x29d0, arm64_l_29d0);
arm64_l_29c4:
	/* 0x29c4: ldr w10, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_29c8:
	/* 0x29c8: cmp w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_29cc:
	/* 0x29cc: b.eq 28e4 <filter_8ty_selector_val+0x50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x29cc, 0x28e4, arm64_l_28e4);
arm64_l_29d0:
	/* 0x29d0: cmp w8, #0x25 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_29d4:
	/* 0x29d4: b.hi 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x29d4, 0x2be4, arm64_l_2be4);
arm64_l_29d8:
	/* 0x29d8: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_29dc:
	/* 0x29dc: lsl x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_29e0:
	/* 0x29e0: mov x9, #0x50 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 80ULL);
arm64_l_29e4:
	/* 0x29e4: movk x9, #0xc00, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 3072ULL);
arm64_l_29e8:
	/* 0x29e8: movk x9, #0x20, lsl #32 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 32ULL);
arm64_l_29ec:
	/* 0x29ec: tst x8, x9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_29f0:
	/* 0x29f0: b.eq 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x29f0, 0x2be4, arm64_l_2be4);
arm64_l_29f4:
	/* 0x29f4: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_29f8:
	/* 0x29f8: ret */
	ARM64_SIM_A64_RET();
arm64_l_29fc:
	/* 0x29fc: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2a00:
	/* 0x2a00: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_2a04:
	/* 0x2a04: b.cc 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2a04, 0x2be4, arm64_l_2be4);
arm64_l_2a08:
	/* 0x2a08: ldr w10, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_2a0c:
	/* 0x2a0c: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2a10:
	/* 0x2a10: b.ge 2acc <filter_8ty_selector_val+0x238> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x2a10, 0x2acc, arm64_l_2acc);
arm64_l_2a14:
	/* 0x2a14: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a18:
	/* 0x2a18: ret */
	ARM64_SIM_A64_RET();
arm64_l_2a1c:
	/* 0x2a1c: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2a20:
	/* 0x2a20: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_2a24:
	/* 0x2a24: b.cc 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2a24, 0x2be4, arm64_l_2be4);
arm64_l_2a28:
	/* 0x2a28: ldr w10, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_2a2c:
	/* 0x2a2c: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2a30:
	/* 0x2a30: b.le 2ae8 <filter_8ty_selector_val+0x254> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2a30, 0x2ae8, arm64_l_2ae8);
arm64_l_2a34:
	/* 0x2a34: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a38:
	/* 0x2a38: ret */
	ARM64_SIM_A64_RET();
arm64_l_2a3c:
	/* 0x2a3c: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2a40:
	/* 0x2a40: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_2a44:
	/* 0x2a44: b.cc 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2a44, 0x2be4, arm64_l_2be4);
arm64_l_2a48:
	/* 0x2a48: ldr w10, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_2a4c:
	/* 0x2a4c: tst w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2a50:
	/* 0x2a50: b.eq 2b04 <filter_8ty_selector_val+0x270> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2a50, 0x2b04, arm64_l_2b04);
arm64_l_2a54:
	/* 0x2a54: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a58:
	/* 0x2a58: ret */
	ARM64_SIM_A64_RET();
arm64_l_2a5c:
	/* 0x2a5c: ldrb w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2a60:
	/* 0x2a60: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2a64:
	/* 0x2a64: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2a68:
	/* 0x2a68: b.cs 2a8c <filter_8ty_selector_val+0x1f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2a68, 0x2a8c, arm64_l_2a8c);
arm64_l_2a6c:
	/* 0x2a6c: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a70:
	/* 0x2a70: ret */
	ARM64_SIM_A64_RET();
arm64_l_2a74:
	/* 0x2a74: ldrb w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2a78:
	/* 0x2a78: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2a7c:
	/* 0x2a7c: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2a80:
	/* 0x2a80: b.ls 2aac <filter_8ty_selector_val+0x218> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2a80, 0x2aac, arm64_l_2aac);
arm64_l_2a84:
	/* 0x2a84: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2a88:
	/* 0x2a88: ret */
	ARM64_SIM_A64_RET();
arm64_l_2a8c:
	/* 0x2a8c: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2a90:
	/* 0x2a90: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_2a94:
	/* 0x2a94: b.cc 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2a94, 0x2be4, arm64_l_2be4);
arm64_l_2a98:
	/* 0x2a98: ldr w10, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_2a9c:
	/* 0x2a9c: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2aa0:
	/* 0x2aa0: b.cs 2b20 <filter_8ty_selector_val+0x28c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2aa0, 0x2b20, arm64_l_2b20);
arm64_l_2aa4:
	/* 0x2aa4: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2aa8:
	/* 0x2aa8: ret */
	ARM64_SIM_A64_RET();
arm64_l_2aac:
	/* 0x2aac: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2ab0:
	/* 0x2ab0: cmp w9, #0xd */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 13ULL);
arm64_l_2ab4:
	/* 0x2ab4: b.cc 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2ab4, 0x2be4, arm64_l_2be4);
arm64_l_2ab8:
	/* 0x2ab8: ldr w10, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_2abc:
	/* 0x2abc: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2ac0:
	/* 0x2ac0: b.ls 2b3c <filter_8ty_selector_val+0x2a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2ac0, 0x2b3c, arm64_l_2b3c);
arm64_l_2ac4:
	/* 0x2ac4: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2ac8:
	/* 0x2ac8: ret */
	ARM64_SIM_A64_RET();
arm64_l_2acc:
	/* 0x2acc: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2ad0:
	/* 0x2ad0: b.cc 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2ad0, 0x2be4, arm64_l_2be4);
arm64_l_2ad4:
	/* 0x2ad4: ldr w10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2ad8:
	/* 0x2ad8: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2adc:
	/* 0x2adc: b.ge 2b58 <filter_8ty_selector_val+0x2c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x2adc, 0x2b58, arm64_l_2b58);
arm64_l_2ae0:
	/* 0x2ae0: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2ae4:
	/* 0x2ae4: ret */
	ARM64_SIM_A64_RET();
arm64_l_2ae8:
	/* 0x2ae8: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2aec:
	/* 0x2aec: b.cc 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2aec, 0x2be4, arm64_l_2be4);
arm64_l_2af0:
	/* 0x2af0: ldr w10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2af4:
	/* 0x2af4: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2af8:
	/* 0x2af8: b.le 2b74 <filter_8ty_selector_val+0x2e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2af8, 0x2b74, arm64_l_2b74);
arm64_l_2afc:
	/* 0x2afc: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2b00:
	/* 0x2b00: ret */
	ARM64_SIM_A64_RET();
arm64_l_2b04:
	/* 0x2b04: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2b08:
	/* 0x2b08: b.cc 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b08, 0x2be4, arm64_l_2be4);
arm64_l_2b0c:
	/* 0x2b0c: ldr w10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2b10:
	/* 0x2b10: tst w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b14:
	/* 0x2b14: b.eq 2b90 <filter_8ty_selector_val+0x2fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2b14, 0x2b90, arm64_l_2b90);
arm64_l_2b18:
	/* 0x2b18: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2b1c:
	/* 0x2b1c: ret */
	ARM64_SIM_A64_RET();
arm64_l_2b20:
	/* 0x2b20: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2b24:
	/* 0x2b24: b.cc 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b24, 0x2be4, arm64_l_2be4);
arm64_l_2b28:
	/* 0x2b28: ldr w10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2b2c:
	/* 0x2b2c: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b30:
	/* 0x2b30: b.cs 2bac <filter_8ty_selector_val+0x318> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2b30, 0x2bac, arm64_l_2bac);
arm64_l_2b34:
	/* 0x2b34: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2b38:
	/* 0x2b38: ret */
	ARM64_SIM_A64_RET();
arm64_l_2b3c:
	/* 0x2b3c: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2b40:
	/* 0x2b40: b.cc 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b40, 0x2be4, arm64_l_2be4);
arm64_l_2b44:
	/* 0x2b44: ldr w10, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2b48:
	/* 0x2b48: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b4c:
	/* 0x2b4c: b.ls 2bc8 <filter_8ty_selector_val+0x334> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2b4c, 0x2bc8, arm64_l_2bc8);
arm64_l_2b50:
	/* 0x2b50: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2b54:
	/* 0x2b54: ret */
	ARM64_SIM_A64_RET();
arm64_l_2b58:
	/* 0x2b58: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2b5c:
	/* 0x2b5c: b.cc 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b5c, 0x2be4, arm64_l_2be4);
arm64_l_2b60:
	/* 0x2b60: ldr w9, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2b64:
	/* 0x2b64: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b68:
	/* 0x2b68: b.ge 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x2b68, 0x2be4, arm64_l_2be4);
arm64_l_2b6c:
	/* 0x2b6c: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2b70:
	/* 0x2b70: ret */
	ARM64_SIM_A64_RET();
arm64_l_2b74:
	/* 0x2b74: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2b78:
	/* 0x2b78: b.cc 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b78, 0x2be4, arm64_l_2be4);
arm64_l_2b7c:
	/* 0x2b7c: ldr w9, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2b80:
	/* 0x2b80: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b84:
	/* 0x2b84: b.le 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2b84, 0x2be4, arm64_l_2be4);
arm64_l_2b88:
	/* 0x2b88: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2b8c:
	/* 0x2b8c: ret */
	ARM64_SIM_A64_RET();
arm64_l_2b90:
	/* 0x2b90: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2b94:
	/* 0x2b94: b.cc 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b94, 0x2be4, arm64_l_2be4);
arm64_l_2b98:
	/* 0x2b98: ldr w9, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2b9c:
	/* 0x2b9c: tst w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2ba0:
	/* 0x2ba0: b.eq 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2ba0, 0x2be4, arm64_l_2be4);
arm64_l_2ba4:
	/* 0x2ba4: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2ba8:
	/* 0x2ba8: ret */
	ARM64_SIM_A64_RET();
arm64_l_2bac:
	/* 0x2bac: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2bb0:
	/* 0x2bb0: b.cc 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2bb0, 0x2be4, arm64_l_2be4);
arm64_l_2bb4:
	/* 0x2bb4: ldr w9, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2bb8:
	/* 0x2bb8: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2bbc:
	/* 0x2bbc: b.cs 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2bbc, 0x2be4, arm64_l_2be4);
arm64_l_2bc0:
	/* 0x2bc0: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2bc4:
	/* 0x2bc4: ret */
	ARM64_SIM_A64_RET();
arm64_l_2bc8:
	/* 0x2bc8: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2bcc:
	/* 0x2bcc: b.cc 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2bcc, 0x2be4, arm64_l_2be4);
arm64_l_2bd0:
	/* 0x2bd0: ldr w9, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2bd4:
	/* 0x2bd4: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2bd8:
	/* 0x2bd8: b.ls 2be4 <filter_8ty_selector_val+0x350> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2bd8, 0x2be4, arm64_l_2be4);
arm64_l_2bdc:
	/* 0x2bdc: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2be0:
	/* 0x2be0: ret */
	ARM64_SIM_A64_RET();
arm64_l_2be4:
	/* 0x2be4: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2be8:
	/* 0x2be8: ret */
	ARM64_SIM_A64_RET();
arm64_l_2bec:
	/* 0x2bec: ldr w9, [x0, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_2bf0:
	/* 0x2bf0: ldr w8, [x0, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2bf4:
	/* 0x2bf4: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2bf8:
	/* 0x2bf8: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2bfc:
	/* 0x2bfc: lsl w9, w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2c00:
	/* 0x2c00: mov w10, #0x1402 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5122ULL);
arm64_l_2c04:
	/* 0x2c04: and w9, w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 0);
arm64_l_2c08:
	/* 0x2c08: ccmp w9, #0x0, #0x4, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 4), 0ULL);
arm64_l_2c0c:
	/* 0x2c0c: b.eq 2d0c <filter_8ty_range+0x120> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2c0c, 0x2d0c, arm64_l_2d0c);
arm64_l_2c10:
	/* 0x2c10: ldrsb w10, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDRSB, ARM64_X10, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c14:
	/* 0x2c14: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_2c18:
	/* 0x2c18: b.ne 2ca0 <filter_8ty_range+0xb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2c18, 0x2ca0, arm64_l_2ca0);
arm64_l_2c1c:
	/* 0x2c1c: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2c20:
	/* 0x2c20: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c24:
	/* 0x2c24: b.gt 2c34 <filter_8ty_range+0x48> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2c24, 0x2c34, arm64_l_2c34);
arm64_l_2c28:
	/* 0x2c28: ldr w9, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_2c2c:
	/* 0x2c2c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c30:
	/* 0x2c30: b.ge 2d30 <filter_8ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x2c30, 0x2d30, arm64_l_2d30);
arm64_l_2c34:
	/* 0x2c34: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2c38:
	/* 0x2c38: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2c3c:
	/* 0x2c3c: b.cc 2e1c <filter_8ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2c3c, 0x2e1c, arm64_l_2e1c);
arm64_l_2c40:
	/* 0x2c40: ldr w11, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2c44:
	/* 0x2c44: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c48:
	/* 0x2c48: b.gt 2c58 <filter_8ty_range+0x6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2c48, 0x2c58, arm64_l_2c58);
arm64_l_2c4c:
	/* 0x2c4c: ldr w11, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2c50:
	/* 0x2c50: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c54:
	/* 0x2c54: b.ge 2d30 <filter_8ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x2c54, 0x2d30, arm64_l_2d30);
arm64_l_2c58:
	/* 0x2c58: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_2c5c:
	/* 0x2c5c: b.cc 2e1c <filter_8ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2c5c, 0x2e1c, arm64_l_2e1c);
arm64_l_2c60:
	/* 0x2c60: ldr w11, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2c64:
	/* 0x2c64: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c68:
	/* 0x2c68: b.gt 2c78 <filter_8ty_range+0x8c> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2c68, 0x2c78, arm64_l_2c78);
arm64_l_2c6c:
	/* 0x2c6c: ldr w11, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_2c70:
	/* 0x2c70: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c74:
	/* 0x2c74: b.ge 2d30 <filter_8ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x2c74, 0x2d30, arm64_l_2d30);
arm64_l_2c78:
	/* 0x2c78: cmp w9, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2c7c:
	/* 0x2c7c: b.cc 2e1c <filter_8ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2c7c, 0x2e1c, arm64_l_2e1c);
arm64_l_2c80:
	/* 0x2c80: ldr w11, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2c84:
	/* 0x2c84: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2c88:
	/* 0x2c88: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c8c:
	/* 0x2c8c: b.gt 2e0c <filter_8ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2c8c, 0x2e0c, arm64_l_2e0c);
arm64_l_2c90:
	/* 0x2c90: ldr w11, [x0, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_2c94:
	/* 0x2c94: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c98:
	/* 0x2c98: b.ge 2d30 <filter_8ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x2c98, 0x2d30, arm64_l_2d30);
arm64_l_2c9c:
	/* 0x2c9c: b 2e0c <filter_8ty_range+0x220> */
	ARM64_SIM_A64_JMP(0x2c9c, 0x2e0c, arm64_l_2e0c);
arm64_l_2ca0:
	/* 0x2ca0: ldp w9, w12, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X9, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2ca4:
	/* 0x2ca4: ldr w11, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2ca8:
	/* 0x2ca8: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2cac:
	/* 0x2cac: ccmp w12, w10, #0x8, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 8), 0);
arm64_l_2cb0:
	/* 0x2cb0: cset w9, ge */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_GE, 0);
arm64_l_2cb4:
	/* 0x2cb4: cmp w11, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2cb8:
	/* 0x2cb8: b.cc 2e0c <filter_8ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2cb8, 0x2e0c, arm64_l_2e0c);
arm64_l_2cbc:
	/* 0x2cbc: ldp w12, w13, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2cc0:
	/* 0x2cc0: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2cc4:
	/* 0x2cc4: ccmp w13, w10, #0x8, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 8), 0);
arm64_l_2cc8:
	/* 0x2cc8: csinc w9, w9, wzr, lt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LT, 0);
arm64_l_2ccc:
	/* 0x2ccc: cmp w11, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_2cd0:
	/* 0x2cd0: b.cc 2e0c <filter_8ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2cd0, 0x2e0c, arm64_l_2e0c);
arm64_l_2cd4:
	/* 0x2cd4: ldp w12, w13, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2cd8:
	/* 0x2cd8: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2cdc:
	/* 0x2cdc: ccmp w13, w10, #0x8, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 8), 0);
arm64_l_2ce0:
	/* 0x2ce0: csinc w9, w9, wzr, lt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LT, 0);
arm64_l_2ce4:
	/* 0x2ce4: cmp w11, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2ce8:
	/* 0x2ce8: b.cc 2e0c <filter_8ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2ce8, 0x2e0c, arm64_l_2e0c);
arm64_l_2cec:
	/* 0x2cec: ldp w11, w12, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2cf0:
	/* 0x2cf0: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2cf4:
	/* 0x2cf4: ccmp w12, w10, #0x8, le */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LE, 8), 0);
arm64_l_2cf8:
	/* 0x2cf8: csinc w9, w9, wzr, lt */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LT, 0);
arm64_l_2cfc:
	/* 0x2cfc: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2d00:
	/* 0x2d00: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2d04:
	/* 0x2d04: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2d08:
	/* 0x2d08: ret */
	ARM64_SIM_A64_RET();
arm64_l_2d0c:
	/* 0x2d0c: ldrb w10, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2d10:
	/* 0x2d10: cmp w8, #0x1f */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_2d14:
	/* 0x2d14: b.ne 2d38 <filter_8ty_range+0x14c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2d14, 0x2d38, arm64_l_2d38);
arm64_l_2d18:
	/* 0x2d18: ldr w9, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2d1c:
	/* 0x2d1c: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d20:
	/* 0x2d20: b.hi 2da4 <filter_8ty_range+0x1b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2d20, 0x2da4, arm64_l_2da4);
arm64_l_2d24:
	/* 0x2d24: ldr w9, [x0, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_2d28:
	/* 0x2d28: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d2c:
	/* 0x2d2c: b.cc 2da4 <filter_8ty_range+0x1b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2d2c, 0x2da4, arm64_l_2da4);
arm64_l_2d30:
	/* 0x2d30: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2d34:
	/* 0x2d34: ret */
	ARM64_SIM_A64_RET();
arm64_l_2d38:
	/* 0x2d38: ldp w9, w12, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X9, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2d3c:
	/* 0x2d3c: ldr w11, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2d40:
	/* 0x2d40: cmp w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d44:
	/* 0x2d44: ccmp w12, w10, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_2d48:
	/* 0x2d48: cset w9, cs */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CS, 0);
arm64_l_2d4c:
	/* 0x2d4c: cmp w11, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2d50:
	/* 0x2d50: b.cc 2e0c <filter_8ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2d50, 0x2e0c, arm64_l_2e0c);
arm64_l_2d54:
	/* 0x2d54: ldp w12, w13, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2d58:
	/* 0x2d58: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d5c:
	/* 0x2d5c: ccmp w13, w10, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_2d60:
	/* 0x2d60: csinc w9, w9, wzr, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_2d64:
	/* 0x2d64: cmp w11, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_2d68:
	/* 0x2d68: b.cc 2e0c <filter_8ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2d68, 0x2e0c, arm64_l_2e0c);
arm64_l_2d6c:
	/* 0x2d6c: ldp w12, w13, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X12, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2d70:
	/* 0x2d70: cmp w12, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d74:
	/* 0x2d74: ccmp w13, w10, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X13, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_2d78:
	/* 0x2d78: csinc w9, w9, wzr, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_2d7c:
	/* 0x2d7c: cmp w11, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2d80:
	/* 0x2d80: b.cc 2e0c <filter_8ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2d80, 0x2e0c, arm64_l_2e0c);
arm64_l_2d84:
	/* 0x2d84: ldp w11, w12, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X11, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2d88:
	/* 0x2d88: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d8c:
	/* 0x2d8c: ccmp w12, w10, #0x0, ls */
	ARM64_SIM_RUN_OP3(ARM64_OP_CCMP_REG, ARM64_X12, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_CCMP(ARM64_COND_LS, 0), 0);
arm64_l_2d90:
	/* 0x2d90: csinc w9, w9, wzr, cc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSINC, ARM64_X9, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_2d94:
	/* 0x2d94: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2d98:
	/* 0x2d98: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2d9c:
	/* 0x2d9c: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2da0:
	/* 0x2da0: ret */
	ARM64_SIM_A64_RET();
arm64_l_2da4:
	/* 0x2da4: ldr w9, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2da8:
	/* 0x2da8: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2dac:
	/* 0x2dac: b.cc 2e1c <filter_8ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2dac, 0x2e1c, arm64_l_2e1c);
arm64_l_2db0:
	/* 0x2db0: ldr w11, [x0, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2db4:
	/* 0x2db4: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2db8:
	/* 0x2db8: b.hi 2dc8 <filter_8ty_range+0x1dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2db8, 0x2dc8, arm64_l_2dc8);
arm64_l_2dbc:
	/* 0x2dbc: ldr w11, [x0, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2dc0:
	/* 0x2dc0: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2dc4:
	/* 0x2dc4: b.cs 2d30 <filter_8ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2dc4, 0x2d30, arm64_l_2d30);
arm64_l_2dc8:
	/* 0x2dc8: cmp w9, #0x19 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_2dcc:
	/* 0x2dcc: b.cc 2e1c <filter_8ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2dcc, 0x2e1c, arm64_l_2e1c);
arm64_l_2dd0:
	/* 0x2dd0: ldr w11, [x0, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2dd4:
	/* 0x2dd4: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2dd8:
	/* 0x2dd8: b.hi 2de8 <filter_8ty_range+0x1fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2dd8, 0x2de8, arm64_l_2de8);
arm64_l_2ddc:
	/* 0x2ddc: ldr w11, [x0, #36] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_2de0:
	/* 0x2de0: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2de4:
	/* 0x2de4: b.cs 2d30 <filter_8ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2de4, 0x2d30, arm64_l_2d30);
arm64_l_2de8:
	/* 0x2de8: cmp w9, #0x21 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2dec:
	/* 0x2dec: b.cc 2e1c <filter_8ty_range+0x230> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2dec, 0x2e1c, arm64_l_2e1c);
arm64_l_2df0:
	/* 0x2df0: ldr w11, [x0, #40] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2df4:
	/* 0x2df4: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2df8:
	/* 0x2df8: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2dfc:
	/* 0x2dfc: b.hi 2e0c <filter_8ty_range+0x220> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2dfc, 0x2e0c, arm64_l_2e0c);
arm64_l_2e00:
	/* 0x2e00: ldr w11, [x0, #44] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_2e04:
	/* 0x2e04: cmp w11, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2e08:
	/* 0x2e08: b.cs 2d30 <filter_8ty_range+0x144> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x2e08, 0x2d30, arm64_l_2d30);
arm64_l_2e0c:
	/* 0x2e0c: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2e10:
	/* 0x2e10: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2e14:
	/* 0x2e14: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2e18:
	/* 0x2e18: ret */
	ARM64_SIM_A64_RET();
arm64_l_2e1c:
	/* 0x2e1c: mov w9, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2e20:
	/* 0x2e20: cmp w8, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2e24:
	/* 0x2e24: eor w8, w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2e28:
	/* 0x2e28: csel w0, wzr, w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2e2c:
	/* 0x2e2c: ret */
	ARM64_SIM_A64_RET();
arm64_l_2e30:
	/* 0x2e30: sub sp, sp, #0x30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_2e34:
	/* 0x2e34: str x30, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2e38:
	/* 0x2e38: stp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2e3c:
	/* 0x2e3c: ldrb w8, [x0, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2e40:
	/* 0x2e40: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2e44:
	/* 0x2e44: adrp x0, 0 <argfilter_maps> */
	ARM64_SIM_RUN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&argfilter_maps_2));
arm64_l_2e48:
	/* 0x2e48: add x9, sp, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_2e4c:
	/* 0x2e4c: str w8, [sp, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2e50:
	/* 0x2e50: mov w8, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2e54:
	/* 0x2e54: mov x20, x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2e58:
	/* 0x2e58: add x1, sp, #0x1c */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_2e5c:
	/* 0x2e5c: ldr x0, [x0] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2e60:
	/* 0x2e60: blr x8 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_2e64:
	/* 0x2e64: cbz x0, 2ed8 <filter_8ty_map+0xa8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2e64, 0x2ed8, arm64_l_2ed8);
arm64_l_2e68:
	/* 0x2e68: ldrb w8, [x20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2e6c:
	/* 0x2e6c: mov w9, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2e70:
	/* 0x2e70: add x1, sp, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2e74:
	/* 0x2e74: mov w20, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2e78:
	/* 0x2e78: str x8, [sp, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2e7c:
	/* 0x2e7c: add x8, sp, #0x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2e80:
	/* 0x2e80: blr x9 */
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_2e84:
	/* 0x2e84: ldr w9, [x19, #4] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2e88:
	/* 0x2e88: mov w8, wzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2e8c:
	/* 0x2e8c: cmp w9, #0x1d */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_2e90:
	/* 0x2e90: b.hi 2ed4 <filter_8ty_map+0xa4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2e90, 0x2ed4, arm64_l_2ed4);
arm64_l_2e94:
	/* 0x2e94: mov w11, #0x8400 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 33792ULL);
arm64_l_2e98:
	/* 0x2e98: lsl w10, w20, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2e9c:
	/* 0x2e9c: movk w11, #0x3003, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 12291ULL);
arm64_l_2ea0:
	/* 0x2ea0: tst w10, w11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2ea4:
	/* 0x2ea4: b.eq 2eb4 <filter_8ty_map+0x84> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2ea4, 0x2eb4, arm64_l_2eb4);
arm64_l_2ea8:
	/* 0x2ea8: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_2eac:
	/* 0x2eac: cset w8, ne */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_2eb0:
	/* 0x2eb0: b 2ed4 <filter_8ty_map+0xa4> */
	ARM64_SIM_A64_JMP(0x2eb0, 0x2ed4, arm64_l_2ed4);
arm64_l_2eb4:
	/* 0x2eb4: mov w10, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2eb8:
	/* 0x2eb8: lsl w9, w10, w9 */
	ARM64_SIM_RUN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2ebc:
	/* 0x2ebc: mov w10, #0x800 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_2ec0:
	/* 0x2ec0: movk w10, #0xc, lsl #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MOVK(16), 12ULL);
arm64_l_2ec4:
	/* 0x2ec4: tst w9, w10 */
	ARM64_SIM_RUN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2ec8:
	/* 0x2ec8: b.eq 2ed4 <filter_8ty_map+0xa4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2ec8, 0x2ed4, arm64_l_2ed4);
arm64_l_2ecc:
	/* 0x2ecc: cmp x0, #0x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_2ed0:
	/* 0x2ed0: cset w8, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_2ed4:
	/* 0x2ed4: mov w0, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2ed8:
	/* 0x2ed8: ldp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2edc:
	/* 0x2edc: ldr x30, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2ee0:
	/* 0x2ee0: add sp, sp, #0x30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_2ee4:
	/* 0x2ee4: ret */
	ARM64_SIM_A64_RET();
arm64_l_2ee8:
	/* 0x2ee8: sub sp, sp, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2eec:
	/* 0x2eec: stp x30, x19, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2ef0:
	/* 0x2ef0: ldr w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ef4:
	/* 0x2ef4: strh wzr, [sp, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_2ef8:
	/* 0x2ef8: cmp w8, #0x1, lsl #12 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_2efc:
	/* 0x2efc: b.hi 2fd4 <filter_file_type+0xec> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2efc, 0x2fd4, arm64_l_2fd4);
arm64_l_2f00:
	/* 0x2f00: add x9, x1, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2f04:
	/* 0x2f04: mov w10, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2f08:
	/* 0x2f08: mov w11, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2f0c:
	/* 0x2f0c: add x12, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2f10:
	/* 0x2f10: mov x19, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2f14:
	/* 0x2f14: add x0, sp, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2f18:
	/* 0x2f18: add x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2f1c:
	/* 0x2f1c: add x8, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2f20:
	/* 0x2f20: ldr w8, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2f24:
	/* 0x2f24: mov w1, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2f28:
	/* 0x2f28: add x8, x9, x8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2f2c:
	/* 0x2f2c: add x2, x8, #0x4 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2f30:
	/* 0x2f30: blr x11 */
	ARM64_SIM_BPF_CALL_bpf_probe_read();
arm64_l_2f34:
	/* 0x2f34: ldr w9, [x19, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2f38:
	/* 0x2f38: cbz w9, 2fd4 <filter_file_type+0xec> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x2f38, 0x2fd4, arm64_l_2fd4);
arm64_l_2f3c:
	/* 0x2f3c: ldrh w8, [sp, #12] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_2f40:
	/* 0x2f40: and w8, w8, #0xf000 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 61440ULL);
arm64_l_2f44:
	/* 0x2f44: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2f48:
	/* 0x2f48: b.ne 2f5c <filter_file_type+0x74> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2f48, 0x2f5c, arm64_l_2f5c);
arm64_l_2f4c:
	/* 0x2f4c: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2f50:
	/* 0x2f50: ldp x30, x19, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2f54:
	/* 0x2f54: add sp, sp, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2f58:
	/* 0x2f58: ret */
	ARM64_SIM_A64_RET();
arm64_l_2f5c:
	/* 0x2f5c: ldr w9, [x19, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2f60:
	/* 0x2f60: cmp w9, #0xc */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2f64:
	/* 0x2f64: b.ls 2fd4 <filter_file_type+0xec> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2f64, 0x2fd4, arm64_l_2fd4);
arm64_l_2f68:
	/* 0x2f68: ldr w10, [x19, #20] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_2f6c:
	/* 0x2f6c: cbz w10, 2fd4 <filter_file_type+0xec> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x2f6c, 0x2fd4, arm64_l_2fd4);
arm64_l_2f70:
	/* 0x2f70: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2f74:
	/* 0x2f74: b.ne 2f88 <filter_file_type+0xa0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2f74, 0x2f88, arm64_l_2f88);
arm64_l_2f78:
	/* 0x2f78: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2f7c:
	/* 0x2f7c: ldp x30, x19, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2f80:
	/* 0x2f80: add sp, sp, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2f84:
	/* 0x2f84: ret */
	ARM64_SIM_A64_RET();
arm64_l_2f88:
	/* 0x2f88: cmp w9, #0x11 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2f8c:
	/* 0x2f8c: b.cc 2fd4 <filter_file_type+0xec> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2f8c, 0x2fd4, arm64_l_2fd4);
arm64_l_2f90:
	/* 0x2f90: ldr w10, [x19, #24] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2f94:
	/* 0x2f94: cbz w10, 2fd4 <filter_file_type+0xec> */
	ARM64_SIM_A64_CBZ(ARM64_X10, 0x2f94, 0x2fd4, arm64_l_2fd4);
arm64_l_2f98:
	/* 0x2f98: cmp w10, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2f9c:
	/* 0x2f9c: b.ne 2fb0 <filter_file_type+0xc8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2f9c, 0x2fb0, arm64_l_2fb0);
arm64_l_2fa0:
	/* 0x2fa0: mov w0, #0x1 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2fa4:
	/* 0x2fa4: ldp x30, x19, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2fa8:
	/* 0x2fa8: add sp, sp, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2fac:
	/* 0x2fac: ret */
	ARM64_SIM_A64_RET();
arm64_l_2fb0:
	/* 0x2fb0: cmp w9, #0x15 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_2fb4:
	/* 0x2fb4: b.cc 2fd4 <filter_file_type+0xec> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2fb4, 0x2fd4, arm64_l_2fd4);
arm64_l_2fb8:
	/* 0x2fb8: ldr w9, [x19, #28] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_2fbc:
	/* 0x2fbc: cbz w9, 2fd4 <filter_file_type+0xec> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x2fbc, 0x2fd4, arm64_l_2fd4);
arm64_l_2fc0:
	/* 0x2fc0: cmp w9, w8 */
	ARM64_SIM_RUN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2fc4:
	/* 0x2fc4: cset w0, eq */
	ARM64_SIM_RUN_OP3(ARM64_OP_CSET, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_2fc8:
	/* 0x2fc8: ldp x30, x19, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2fcc:
	/* 0x2fcc: add sp, sp, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2fd0:
	/* 0x2fd0: ret */
	ARM64_SIM_A64_RET();
arm64_l_2fd4:
	/* 0x2fd4: mov x0, xzr */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2fd8:
	/* 0x2fd8: ldp x30, x19, [sp, #16] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2fdc:
	/* 0x2fdc: add sp, sp, #0x20 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2fe0:
	/* 0x2fe0: ret */
	ARM64_SIM_A64_RET();
arm64_l_2fe4:
	/* 0x2fe4: nop */
	ARM64_SIM_RUN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2fe8:
	/* 0x2fe8: mov x7, x0 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
