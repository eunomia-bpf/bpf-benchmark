#include <stddef.h>
extern void *memset(void *,int,size_t);
void *call(void*p,int c,size_t n){return memset(p,c,n);}
