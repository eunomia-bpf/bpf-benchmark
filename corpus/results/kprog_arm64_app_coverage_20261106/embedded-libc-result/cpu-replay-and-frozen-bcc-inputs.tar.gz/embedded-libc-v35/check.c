
#include <stdint.h>
#include <stdio.h>
#include <stddef.h>
extern void *__kprog_memset(void *, int, size_t);
int main(void) {
 unsigned cases=0,failures=0;
 const int values[]={0,-1,0x42,0x1234};
 for (unsigned at=0;at<16;at++) for(unsigned n=0;n<=128;n++)
 for(unsigned v=0;v<4;v++) {
  unsigned char bytes[192];
  for(unsigned i=0;i<sizeof(bytes);i++)bytes[i]=(unsigned char)(i*17+3);
  void *result=__kprog_memset(bytes+at,values[v],n);
  unsigned bad=result!=(void *)(bytes+at);
  for(unsigned i=0;i<sizeof(bytes);i++) {
   unsigned char expected=(i>=at && i<at+n)?(unsigned char)values[v]:(unsigned char)(i*17+3);
   bad |= bytes[i]!=expected;
  }
  if(bad){printf("FAIL at=%u n=%u value=%d\n",at,n,values[v]);failures++;}
  cases++;
 }
 cases++;if(__kprog_memset(NULL,0x42,0)!=NULL)failures++;
 printf("embedded memset CPU: %u cases, %u failures\n",cases,failures);
 return failures!=0;
}
