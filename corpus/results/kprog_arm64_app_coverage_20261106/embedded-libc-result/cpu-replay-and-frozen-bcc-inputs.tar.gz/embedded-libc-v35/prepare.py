from pathlib import Path
import subprocess,json,shutil,ast,sys
root=Path('/workspaces/repository')
base=root/'corpus/results/kprog_arm64_app_coverage_20261106'
phase=base/'embedded-libc-v35'
mode=sys.argv[1]
if mode=='build':
 commands=[]
 def run(args):
  args=list(map(str,args))
  r=subprocess.run(args,text=True,capture_output=True)
  commands.append(dict(command=args,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr))
  (phase/'build-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  r.check_returncode()
  return r
 source=phase/'x86-input'
 (source/'native').mkdir(parents=True)
 (source/'control.c').write_text('#include <stddef.h>\nextern void *memset(void *,int,size_t);\nvoid *call(void*p,int c,size_t n){return memset(p,c,n);}\n')
 run(['cc','-O0','-fno-builtin','-c',source/'control.c','-o',source/'native/control.native.o'])
 run(['python3',root/'corpus/results/kprog_app_coverage_20261106/embed_memory_runtime.py',source,phase/'x86-output'])
 original=subprocess.check_output(['git','show','35d992c3e:corpus/results/kprog_app_coverage_20261106/embed_memory_runtime.py'],text=True)
 tree=ast.parse(original)
 body=next(node.value.args[0].value for node in tree.body if isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and node.value.func.attr=='write_text')
 assert (phase/'x86-output/memset.S').read_text()==body
 run(['cc','-O2','-fno-builtin','-Wall','-Wextra','-Werror',phase/'check.c',phase/'x86-output/memset.o','-o',phase/'x86-check'])
 r=run(['taskset','-c','20-23',phase/'x86-check'])
 (phase/'x86-cpu.log').write_text(r.stdout)
 run(['aarch64-linux-gnu-gcc','-static','-O2','-fno-builtin','-Wall','-Wextra','-Werror',phase/'check.c',base/'bcc-memory-input-v35/memset.o','-o',phase/'arm64-check'])
elif mode=='package':
 guest=phase/'root'
 guest.mkdir()
 with Path(sys.argv[2]).open('rb') as f:
  r=subprocess.run(['gzip','-dc'],stdin=f,capture_output=True,check=True)
 subprocess.run(['cpio','-id','--quiet','--no-absolute-filenames','bin/busybox','lib/*','dev/console'],cwd=guest,input=r.stdout,check=True)
 for n in ['proc','sys','results']:(guest/n).mkdir()
 (guest/'bin/sh').symlink_to('busybox')
 shutil.copy2(phase/'arm64-check',guest/'memset-check')
 lines=['#!/bin/sh','export PATH=/bin','busybox mount -t proc proc /proc || exit 1','busybox mount -t sysfs sysfs /sys || exit 1','busybox mount -t 9p -o trans=virtio results /results || exit 1','/memset-check >/results/arm64-cpu.log 2>&1','rc=$?','echo "$rc" >/results/cpu.exit','busybox sync','busybox poweroff -f']
 (guest/'init').write_text('\n'.join(lines)+'\n')
 (guest/'init').chmod(0o755)
 names='\n'.join(['.']+sorted(str(p.relative_to(guest)) for p in guest.rglob('*')))+'\n'
 cpio=subprocess.run(['cpio','-o','-H','newc','--quiet'],cwd=guest,input=names.encode(),capture_output=True,check=True)
 with (phase/'initramfs.cpio.gz').open('wb') as out:
  subprocess.run(['gzip','-c'],input=cpio.stdout,stdout=out,check=True)
else:raise ValueError(mode)
