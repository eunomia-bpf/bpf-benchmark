#include <stdio.h>
extern unsigned long sp_restore(void);
int main(void){unsigned long value=sp_restore();printf("native MOV-to-SP result=%lu\n",value);return value!=0;}
