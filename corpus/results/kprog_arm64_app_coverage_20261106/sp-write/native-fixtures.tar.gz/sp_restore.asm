
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/sp-write/sp_restore.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <sp_restore>:
   0:	d10083ff 	sub	sp, sp, #0x20
   4:	910003e3 	mov	x3, sp
   8:	910043ff 	add	sp, sp, #0x10
   c:	9100007f 	mov	sp, x3
  10:	910003e0 	mov	x0, sp
  14:	cb030000 	sub	x0, x0, x3
  18:	910083ff 	add	sp, sp, #0x20
  1c:	d65f03c0 	ret
