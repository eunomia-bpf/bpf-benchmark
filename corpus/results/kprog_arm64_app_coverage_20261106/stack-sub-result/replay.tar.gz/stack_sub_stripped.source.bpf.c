#include <linux/bpf.h>
#include <bpf_helpers.h>
SEC("xdp") int stack_sub_stripped(struct xdp_md *ctx) { void *p=(void *)(long)ctx->data; void *e=(void *)(long)ctx->data_end; if (p+8>e) return 0; __u64 value=37; bpf_probe_read_kernel(&value,8,(void *)0); *(__u64 *)p=value; return 2; }
char LICENSE[] SEC("license")="GPL";
