
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-effects-tail/tbz-unknown-bit.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f2800041 	movk	x1, #0x2
   4:	b6000021 	tbz	x1, #32, 8 <entry+0x8>
   8:	52800040 	mov	w0, #0x2                   	// #2
   c:	d65f03c0 	ret
