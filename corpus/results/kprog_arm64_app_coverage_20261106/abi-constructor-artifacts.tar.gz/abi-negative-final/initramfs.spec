dir /dev 0755 0 0
dir /proc 0755 0 0
dir /sys 0755 0 0
dir /lib 0755 0 0
dir /proofs 0755 0 0
nod /dev/console 0600 0 0 c 5 1
file /init /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/negative-bound-init 0755 0 0
file /cases /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/cases 0755 0 0
file /bound-probe /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/bound-probe 0755 0 0
file /module.ko /workspaces/repository/kprog/tv/build-arm64/bpf_arm64_native_lab.ko 0755 0 0
file /companion.bpf.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/negative-companion.bpf.o 0755 0 0
file /native-link /workspaces/repository/kprog/x86/native_lab/native_link/target/aarch64-unknown-linux-gnu/release/native-link 0755 0 0
file /lib/libc.so.6 /usr/aarch64-linux-gnu/lib/libc.so.6 0755 0 0
file /lib/ld-linux-aarch64.so.1 /usr/aarch64-linux-gnu/lib/ld-linux-aarch64.so.1 0755 0 0
file /lib/libgcc_s.so.1 /usr/aarch64-linux-gnu/lib/libgcc_s.so.1 0755 0 0
file /lib/libelf.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libelf-0.190.so 0755 0 0
file /lib/libz.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libz.so.1.3 0755 0 0
file /lib/libzstd.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libzstd.so.1.5.5 0755 0 0
file /proofs/past_data_end_read.bpf.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/past_data_end_read.bpf.o 0755 0 0
file /proofs/past_data_end_read.native.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/past_data_end_read.native.o 0755 0 0
file /proofs/past_data_end_read.manifest.json /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/past_data_end_read.manifest.json 0755 0 0
file /proofs/past_data_end_write.bpf.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/past_data_end_write.bpf.o 0755 0 0
file /proofs/past_data_end_write.native.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/past_data_end_write.native.o 0755 0 0
file /proofs/past_data_end_write.manifest.json /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/past_data_end_write.manifest.json 0755 0 0
file /proofs/missing_data_end_check.bpf.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/missing_data_end_check.bpf.o 0755 0 0
file /proofs/missing_data_end_check.native.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/missing_data_end_check.native.o 0755 0 0
file /proofs/missing_data_end_check.manifest.json /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/missing_data_end_check.manifest.json 0755 0 0
file /proofs/map_value_oob.bpf.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/map_value_oob.bpf.o 0755 0 0
file /proofs/map_value_oob.native.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/map_value_oob.native.o 0755 0 0
file /proofs/map_value_oob.manifest.json /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/map_value_oob.manifest.json 0755 0 0
file /proofs/nullable_map_dereference.bpf.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/nullable_map_dereference.bpf.o 0755 0 0
file /proofs/nullable_map_dereference.native.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/nullable_map_dereference.native.o 0755 0 0
file /proofs/nullable_map_dereference.manifest.json /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/nullable_map_dereference.manifest.json 0755 0 0
file /proofs/invalid_helper_argument.bpf.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/invalid_helper_argument.bpf.o 0755 0 0
file /proofs/invalid_helper_argument.native.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/invalid_helper_argument.native.o 0755 0 0
file /proofs/invalid_helper_argument.manifest.json /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/invalid_helper_argument.manifest.json 0755 0 0
file /proofs/stack_oob.bpf.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/stack_oob.bpf.o 0755 0 0
file /proofs/stack_oob.native.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/stack_oob.native.o 0755 0 0
file /proofs/stack_oob.manifest.json /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/stack_oob.manifest.json 0755 0 0
file /proofs/uninitialized_stack.bpf.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/uninitialized_stack.bpf.o 0755 0 0
file /proofs/uninitialized_stack.native.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/uninitialized_stack.native.o 0755 0 0
file /proofs/uninitialized_stack.manifest.json /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/uninitialized_stack.manifest.json 0755 0 0
file /proofs/unbounded_loop.bpf.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/unbounded_loop.bpf.o 0755 0 0
file /proofs/unbounded_loop.native.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/unbounded_loop.native.o 0755 0 0
file /proofs/unbounded_loop.manifest.json /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/unbounded_loop.manifest.json 0755 0 0
file /proofs/entry_return_address_flags.bpf.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/entry_return_address_flags.bpf.o 0755 0 0
file /proofs/entry_return_address_flags.native.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/entry_return_address_flags.native.o 0755 0 0
file /proofs/entry_return_address_flags.manifest.json /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/entry_return_address_flags.manifest.json 0755 0 0
file /proofs/return_register_overwrite.bpf.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/return_register_overwrite.bpf.o 0755 0 0
file /proofs/return_register_overwrite.native.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/return_register_overwrite.native.o 0755 0 0
file /proofs/return_register_overwrite.manifest.json /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/return_register_overwrite.manifest.json 0755 0 0
file /proofs/stack_base_flags.bpf.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/stack_base_flags.bpf.o 0755 0 0
file /proofs/stack_base_flags.native.o /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/stack_base_flags.native.o 0755 0 0
file /proofs/stack_base_flags.manifest.json /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/stack_base_flags.manifest.json 0755 0 0
