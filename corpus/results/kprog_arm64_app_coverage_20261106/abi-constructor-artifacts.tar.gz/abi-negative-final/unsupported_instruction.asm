
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/unsupported_instruction.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d4200000 	brk	#0x0
   4:	d65f03c0 	ret
