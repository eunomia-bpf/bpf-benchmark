
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/entry_return_address_flags.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	52800040 	mov	w0, #0x2                   	// #2
   4:	f10003df 	cmp	x30, #0x0
   8:	54000060 	b.eq	14 <entry+0x14>  // b.none
   c:	d2800001 	mov	x1, #0x0                   	// #0
  10:	b9400020 	ldr	w0, [x1]
  14:	d65f03c0 	ret
