
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-negative-final/invalid_helper_argument.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f81f0ffe 	str	x30, [sp, #-16]!
   4:	d2800020 	mov	x0, #0x1                   	// #1
   8:	d2800001 	mov	x1, #0x0                   	// #0
   c:	94000000 	bl	0 <bpf_map_lookup_elem>
			c: R_AARCH64_CALL26	bpf_map_lookup_elem
  10:	f84107fe 	ldr	x30, [sp], #16
  14:	d65f03c0 	ret
