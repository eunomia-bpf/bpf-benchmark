
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-effects-fixed/local-call-bad-context.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f81f0ffe 	str	x30, [sp, #-16]!
   4:	94000006 	bl	1c <entry+0x1c>
   8:	34000020 	cbz	w0, c <entry+0xc>
   c:	52800041 	mov	w1, #0x2                   	// #2
  10:	94000003 	bl	1c <entry+0x1c>
  14:	f84107fe 	ldr	x30, [sp], #16
  18:	d65f03c0 	ret
  1c:	2a0103e0 	mov	w0, w1
  20:	d65f03c0 	ret
