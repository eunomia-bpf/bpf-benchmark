
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-effects-fixed/opaque-escape.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f9000001 	str	x1, [x0]
   4:	52800040 	mov	w0, #0x2                   	// #2
   8:	d65f03c0 	ret
