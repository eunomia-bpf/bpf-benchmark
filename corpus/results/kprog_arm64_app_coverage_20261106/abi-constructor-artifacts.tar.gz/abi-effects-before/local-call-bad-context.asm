
/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/abi-effects-before/local-call-bad-context.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f81f0ffe 	str	x30, [sp, #-16]!
   4:	94000005 	bl	18 <entry+0x18>
   8:	52800041 	mov	w1, #0x2                   	// #2
   c:	94000003 	bl	18 <entry+0x18>
  10:	f84107fe 	ldr	x30, [sp], #16
  14:	d65f03c0 	ret
  18:	2a0103e0 	mov	w0, w1
  1c:	d65f03c0 	ret
