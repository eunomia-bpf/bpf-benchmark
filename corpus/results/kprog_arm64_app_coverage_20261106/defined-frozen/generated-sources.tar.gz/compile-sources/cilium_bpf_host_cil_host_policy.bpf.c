#include "/workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/defined-frozen/simulator/arm64_sim_local_bpf.h"

SEC("xdp")
int cilium_bpf_host_cil_host_policy_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
arm64_l_0:
	/* 0x0: mov w0, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_4:
	/* 0x4: b 8 <__native_link_arm64_ret_trampoline> */
	ARM64_SIM_A64_JMP(0x4, 0x8, arm64_l_8);
arm64_l_8:
	/* 0x8: mov x7, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
