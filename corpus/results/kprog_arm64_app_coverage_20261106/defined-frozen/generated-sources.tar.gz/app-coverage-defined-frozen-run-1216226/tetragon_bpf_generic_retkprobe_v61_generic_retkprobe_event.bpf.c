extern char CONFIG_ITER_NUM;
extern char buffer_heap_map;
extern char config_map;
extern char execve_map;
extern char fdinstall_map;
extern char process_call_heap;
extern char retkprobe_calls;
extern char retprobe_map;
extern char socktrack_map;
extern char tg_ipv6_ext_heap;
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_RETURN_CASES \
	case 0x44ULL: goto arm64_l_44; \
	case 0x6cULL: goto arm64_l_6c; \
	case 0x84ULL: goto arm64_l_84; \
	case 0x9cULL: goto arm64_l_9c; \
	case 0xc4ULL: goto arm64_l_c4; \
	case 0xe8ULL: goto arm64_l_e8; \
	case 0x11cULL: goto arm64_l_11c; \
	case 0x190ULL: goto arm64_l_190; \
	case 0x1e0ULL: goto arm64_l_1e0; \
	case 0x230ULL: goto arm64_l_230; \
	case 0x28cULL: goto arm64_l_28c; \
	case 0x364ULL: goto arm64_l_364; \
	case 0x3a0ULL: goto arm64_l_3a0; \
	case 0x3c8ULL: goto arm64_l_3c8; \
	case 0x3ecULL: goto arm64_l_3ec; \
	case 0x424ULL: goto arm64_l_424; \
	case 0x450ULL: goto arm64_l_450; \
	case 0x46cULL: goto arm64_l_46c; \
	case 0x4a4ULL: goto arm64_l_4a4; \
	case 0x4d0ULL: goto arm64_l_4d0; \
	case 0x4ecULL: goto arm64_l_4ec; \
	case 0x524ULL: goto arm64_l_524; \
	case 0x550ULL: goto arm64_l_550; \
	case 0x56cULL: goto arm64_l_56c; \
	case 0x5a4ULL: goto arm64_l_5a4; \
	case 0x5b8ULL: goto arm64_l_5b8; \
	case 0x5fcULL: goto arm64_l_5fc; \
	case 0x640ULL: goto arm64_l_640; \
	case 0x668ULL: goto arm64_l_668; \
	case 0x6a4ULL: goto arm64_l_6a4; \
	case 0x6d8ULL: goto arm64_l_6d8; \
	case 0x704ULL: goto arm64_l_704; \
	case 0x724ULL: goto arm64_l_724; \
	case 0x744ULL: goto arm64_l_744; \
	case 0x770ULL: goto arm64_l_770; \
	case 0x788ULL: goto arm64_l_788; \
	case 0x7b8ULL: goto arm64_l_7b8; \
	case 0x828ULL: goto arm64_l_828; \
	case 0x83cULL: goto arm64_l_83c; \
	case 0x854ULL: goto arm64_l_854; \
	case 0x864ULL: goto arm64_l_864; \
	case 0x8b8ULL: goto arm64_l_8b8; \
	case 0x8e4ULL: goto arm64_l_8e4; \
	case 0x908ULL: goto arm64_l_908; \
	case 0x924ULL: goto arm64_l_924; \
	case 0x99cULL: goto arm64_l_99c; \
	case 0x9d8ULL: goto arm64_l_9d8; \
	case 0xa00ULL: goto arm64_l_a00; \
	case 0xa40ULL: goto arm64_l_a40; \
	case 0xa88ULL: goto arm64_l_a88; \
	case 0xad4ULL: goto arm64_l_ad4; \
	case 0xb50ULL: goto arm64_l_b50; \
	case 0xbc8ULL: goto arm64_l_bc8; \
	case 0xc38ULL: goto arm64_l_c38; \
	case 0xc58ULL: goto arm64_l_c58; \
	case 0xc7cULL: goto arm64_l_c7c; \
	case 0xc98ULL: goto arm64_l_c98; \
	case 0xd64ULL: goto arm64_l_d64; \
	case 0xd7cULL: goto arm64_l_d7c; \
	case 0xd90ULL: goto arm64_l_d90; \
	case 0xda4ULL: goto arm64_l_da4; \
	case 0xdb8ULL: goto arm64_l_db8; \
	case 0xdc8ULL: goto arm64_l_dc8; \
	case 0xe00ULL: goto arm64_l_e00; \
	case 0xe10ULL: goto arm64_l_e10; \
	case 0xe88ULL: goto arm64_l_e88; \
	case 0xea4ULL: goto arm64_l_ea4; \
	case 0xf0cULL: goto arm64_l_f0c; \
	case 0xf94ULL: goto arm64_l_f94; \
	case 0xfb8ULL: goto arm64_l_fb8; \
	case 0xfecULL: goto arm64_l_fec; \
	case 0x103cULL: goto arm64_l_103c; \
	case 0x1084ULL: goto arm64_l_1084; \
	case 0x10bcULL: goto arm64_l_10bc; \
	case 0x10e8ULL: goto arm64_l_10e8; \
	case 0x1100ULL: goto arm64_l_1100; \
	case 0x1114ULL: goto arm64_l_1114; \
	case 0x1128ULL: goto arm64_l_1128; \
	case 0x113cULL: goto arm64_l_113c; \
	case 0x114cULL: goto arm64_l_114c; \
	case 0x1188ULL: goto arm64_l_1188; \
	case 0x1198ULL: goto arm64_l_1198; \
	case 0x11e0ULL: goto arm64_l_11e0; \
	case 0x1200ULL: goto arm64_l_1200; \
	case 0x1230ULL: goto arm64_l_1230; \
	case 0x126cULL: goto arm64_l_126c; \
	case 0x1288ULL: goto arm64_l_1288; \
	case 0x12a4ULL: goto arm64_l_12a4; \
	case 0x12c0ULL: goto arm64_l_12c0; \
	case 0x12d4ULL: goto arm64_l_12d4; \
	case 0x130cULL: goto arm64_l_130c; \
	case 0x1320ULL: goto arm64_l_1320; \
	case 0x1344ULL: goto arm64_l_1344; \
	case 0x1364ULL: goto arm64_l_1364; \
	case 0x1390ULL: goto arm64_l_1390; \
	case 0x13acULL: goto arm64_l_13ac; \
	case 0x13c4ULL: goto arm64_l_13c4; \
	case 0x13f8ULL: goto arm64_l_13f8; \
	case 0x1428ULL: goto arm64_l_1428; \
	case 0x1440ULL: goto arm64_l_1440; \
	case 0x145cULL: goto arm64_l_145c; \
	case 0x14a4ULL: goto arm64_l_14a4; \
	case 0x14b8ULL: goto arm64_l_14b8; \
	case 0x14ccULL: goto arm64_l_14cc; \
	case 0x14e0ULL: goto arm64_l_14e0; \
	case 0x1500ULL: goto arm64_l_1500; \
	case 0x151cULL: goto arm64_l_151c; \
	case 0x1540ULL: goto arm64_l_1540; \
	case 0x157cULL: goto arm64_l_157c; \
	case 0x15b0ULL: goto arm64_l_15b0; \
	case 0x15c4ULL: goto arm64_l_15c4; \
	case 0x15fcULL: goto arm64_l_15fc; \
	case 0x1640ULL: goto arm64_l_1640; \
	case 0x1678ULL: goto arm64_l_1678; \
	case 0x1698ULL: goto arm64_l_1698; \
	case 0x16d0ULL: goto arm64_l_16d0; \
	case 0x1738ULL: goto arm64_l_1738; \
	case 0x1760ULL: goto arm64_l_1760; \
	case 0x179cULL: goto arm64_l_179c; \
	case 0x17b0ULL: goto arm64_l_17b0; \
	case 0x17c4ULL: goto arm64_l_17c4; \
	case 0x17d8ULL: goto arm64_l_17d8; \
	case 0x17ecULL: goto arm64_l_17ec; \
	case 0x1800ULL: goto arm64_l_1800; \
	case 0x1814ULL: goto arm64_l_1814; \
	case 0x1828ULL: goto arm64_l_1828; \
	case 0x1840ULL: goto arm64_l_1840; \
	case 0x185cULL: goto arm64_l_185c; \
	case 0x1870ULL: goto arm64_l_1870; \
	case 0x1884ULL: goto arm64_l_1884; \
	case 0x189cULL: goto arm64_l_189c; \
	case 0x18b4ULL: goto arm64_l_18b4; \
	case 0x18c8ULL: goto arm64_l_18c8; \
	case 0x18dcULL: goto arm64_l_18dc; \
	case 0x18f8ULL: goto arm64_l_18f8; \
	case 0x191cULL: goto arm64_l_191c; \
	case 0x1934ULL: goto arm64_l_1934; \
	case 0x1948ULL: goto arm64_l_1948; \
	case 0x1958ULL: goto arm64_l_1958; \
	case 0x1980ULL: goto arm64_l_1980; \
	case 0x199cULL: goto arm64_l_199c; \
	case 0x19b0ULL: goto arm64_l_19b0; \
	case 0x19c4ULL: goto arm64_l_19c4; \
	case 0x19e0ULL: goto arm64_l_19e0; \
	case 0x1a04ULL: goto arm64_l_1a04; \
	case 0x1a1cULL: goto arm64_l_1a1c; \
	case 0x1a4cULL: goto arm64_l_1a4c; \
	case 0x1a6cULL: goto arm64_l_1a6c; \
	case 0x1a94ULL: goto arm64_l_1a94; \
	case 0x1ab4ULL: goto arm64_l_1ab4; \
	case 0x1af8ULL: goto arm64_l_1af8; \
	case 0x1b24ULL: goto arm64_l_1b24; \
	case 0x1b48ULL: goto arm64_l_1b48; \
	case 0x1b70ULL: goto arm64_l_1b70; \
	case 0x1b84ULL: goto arm64_l_1b84; \
	case 0x1bccULL: goto arm64_l_1bcc; \
	case 0x1be4ULL: goto arm64_l_1be4; \
	case 0x1c04ULL: goto arm64_l_1c04; \
	case 0x1c58ULL: goto arm64_l_1c58; \
	case 0x1c8cULL: goto arm64_l_1c8c; \
	case 0x1cd0ULL: goto arm64_l_1cd0; \
	case 0x1ce0ULL: goto arm64_l_1ce0; \
	case 0x1d04ULL: goto arm64_l_1d04; \
	case 0x1d14ULL: goto arm64_l_1d14; \
	case 0x1d48ULL: goto arm64_l_1d48; \
	case 0x1db8ULL: goto arm64_l_1db8; \
	case 0x1dccULL: goto arm64_l_1dcc; \
	case 0x1e1cULL: goto arm64_l_1e1c; \
	case 0x1e54ULL: goto arm64_l_1e54; \
	case 0x1e88ULL: goto arm64_l_1e88; \
	case 0x1e98ULL: goto arm64_l_1e98; \
	case 0x1ebcULL: goto arm64_l_1ebc; \
	case 0x1eccULL: goto arm64_l_1ecc; \
	case 0x1f00ULL: goto arm64_l_1f00; \
	case 0x1f94ULL: goto arm64_l_1f94; \
	case 0x1fdcULL: goto arm64_l_1fdc; \
	case 0x2024ULL: goto arm64_l_2024; \
	case 0x206cULL: goto arm64_l_206c; \
	case 0x20b8ULL: goto arm64_l_20b8; \
	case 0x2100ULL: goto arm64_l_2100; \
	case 0x2148ULL: goto arm64_l_2148; \
	case 0x218cULL: goto arm64_l_218c; \
	case 0x2210ULL: goto arm64_l_2210; \
	case 0x22e8ULL: goto arm64_l_22e8; \
	case 0x23bcULL: goto arm64_l_23bc; \
	case 0x2490ULL: goto arm64_l_2490; \
	case 0x2564ULL: goto arm64_l_2564; \
	case 0x2638ULL: goto arm64_l_2638; \
	case 0x270cULL: goto arm64_l_270c; \
	case 0x2740ULL: goto arm64_l_2740; \
	case 0x2750ULL: goto arm64_l_2750; \
	case 0x2790ULL: goto arm64_l_2790; \
	case 0x27c8ULL: goto arm64_l_27c8; \
	case 0x27d8ULL: goto arm64_l_27d8; \
	case 0x2824ULL: goto arm64_l_2824; \
	case 0x2858ULL: goto arm64_l_2858; \
	case 0x287cULL: goto arm64_l_287c; \
	case 0x288cULL: goto arm64_l_288c;
#include "../arm64_sim_local_bpf.h"

static const __u64 __arm64_rodata_0[2] = {12178401890396095487ULL, 12178947204542846966ULL};

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} CONFIG_ITER_NUM_0 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} arm64_section_Some_SectionIndex_12_addend_0_1 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} buffer_heap_map_2 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_map_3 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} execve_map_4 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} fdinstall_map_5 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} process_call_heap_6 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} retkprobe_calls_7 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} retprobe_map_8 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} socktrack_map_9 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_ipv6_ext_heap_10 SEC(".maps");

SEC("xdp")
int tetragon_bpf_generic_retkprobe_v61_generic_retkprobe_event_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
	/* native subroutine tetragon_bpf_generic_retkprobe_v61_generic_retkprobe_event_xdp */
arm64_l_0:
	/* 0x0: sub sp, sp, #0x150 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 336ULL);
arm64_l_4:
	/* 0x4: str x29, [sp, #256] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 256ULL);
arm64_l_8:
	/* 0x8: stp x30, x25, [sp, #272] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 272ULL);
arm64_l_c:
	/* 0xc: stp x24, x23, [sp, #288] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 288ULL);
arm64_l_10:
	/* 0x10: stp x22, x21, [sp, #304] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 304ULL);
arm64_l_14:
	/* 0x14: stp x20, x19, [sp, #320] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 320ULL);
arm64_l_18:
	/* 0x18: ldr x8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c:
	/* 0x1c: str wzr, [sp, #92] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_20:
	/* 0x20: adrp x25, 0 <process_call_heap> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_6));
arm64_l_24:
	/* 0x24: add x9, sp, #0x5c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 92ULL);
arm64_l_28:
	/* 0x28: mov x19, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2c:
	/* 0x2c: add x1, sp, #0x5c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 92ULL);
arm64_l_30:
	/* 0x30: str x8, [sp, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_34:
	/* 0x34: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_38:
	/* 0x38: ldr x25, [x25] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3c:
	/* 0x3c: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_40:
	/* 0x40: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x44ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_44:
	/* 0x44: cbz x0, 600 <generic_retkprobe_event+0x600> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x44, 0x600, arm64_l_600);
arm64_l_48:
	/* 0x48: mov w8, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_4c:
	/* 0x4c: mov x20, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_50:
	/* 0x50: add x23, x0, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_54:
	/* 0x54: adrp x0, 0 <config_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_map_3));
arm64_l_58:
	/* 0x58: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_5c:
	/* 0x5c: mov x1, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_60:
	/* 0x60: str wzr, [x1, #88]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X1, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 88ULL);
arm64_l_64:
	/* 0x64: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_68:
	/* 0x68: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x6cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_6c:
	/* 0x6c: cbz x0, 600 <generic_retkprobe_event+0x600> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x6c, 0x600, arm64_l_600);
arm64_l_70:
	/* 0x70: ldr w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_74:
	/* 0x74: mov x29, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_78:
	/* 0x78: str x8, [x20, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_7c:
	/* 0x7c: mov w8, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_80:
	/* 0x80: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x84ULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_84:
	/* 0x84: cmn x0, #0x16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 22ULL);
arm64_l_88:
	/* 0x88: b.ne 90 <generic_retkprobe_event+0x90> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x88, 0x90, arm64_l_90);
arm64_l_8c:
	/* 0x8c: ldr x0, [x19, #232] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_90:
	/* 0x90: str x0, [x20, #104] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_94:
	/* 0x94: mov w8, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_98:
	/* 0x98: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x9cULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_9c:
	/* 0x9c: ldp x8, x9, [x20, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_a0:
	/* 0xa0: adrp x22, 0 <retprobe_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&retprobe_map_8));
arm64_l_a4:
	/* 0xa4: add x1, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_a8:
	/* 0xa8: str w0, [x20, #124] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 124ULL);
arm64_l_ac:
	/* 0xac: stp x8, x9, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_b0:
	/* 0xb0: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_b4:
	/* 0xb4: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_b8:
	/* 0xb8: ldr x22, [x22] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_bc:
	/* 0xbc: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c0:
	/* 0xc0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xc4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_c4:
	/* 0xc4: cbz x0, 600 <generic_retkprobe_event+0x600> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xc4, 0x600, arm64_l_600);
arm64_l_c8:
	/* 0xc8: ldp x21, x9, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X21, ARM64_X9, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cc:
	/* 0xcc: add x1, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_d0:
	/* 0xd0: ldr x8, [x0, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_d4:
	/* 0xd4: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d8:
	/* 0xd8: stp x8, x9, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_dc:
	/* 0xdc: mov w8, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_e0:
	/* 0xe0: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_e4:
	/* 0xe4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 3ULL: ARM64_SIM_A64_LINK(0xe8ULL); ARM64_SIM_BPF_CALL_bpf_map_delete_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_e8:
	/* 0xe8: mov x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ec:
	/* 0xec: str x21, [x8, #144]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 144ULL);
arm64_l_f0:
	/* 0xf0: ldp w21, w22, [x29, #88] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X21, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 88ULL);
arm64_l_f4:
	/* 0xf4: cbz w22, 1f0 <generic_retkprobe_event+0x1f0> */
	ARM64_SIM_A64_CBZ_W(ARM64_X22, 0xf4, 0x1f0, arm64_l_1f0);
arm64_l_f8:
	/* 0xf8: str x8, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_fc:
	/* 0xfc: str wzr, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_100:
	/* 0x100: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_104:
	/* 0x104: add x9, sp, #0x6c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 108ULL);
arm64_l_108:
	/* 0x108: add x1, sp, #0x6c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 108ULL);
arm64_l_10c:
	/* 0x10c: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_110:
	/* 0x110: str wzr, [sp, #108] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 108ULL);
arm64_l_114:
	/* 0x114: ldr x24, [sp, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_118:
	/* 0x118: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x11cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_11c:
	/* 0x11c: cbz x0, 25c <generic_retkprobe_event+0x25c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x11c, 0x25c, arm64_l_25c);
arm64_l_120:
	/* 0x120: mov w23, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_124:
	/* 0x124: mov w9, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_128:
	/* 0x128: ldr w8, [x0, x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X23, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_12c:
	/* 0x12c: str x9, [x0, #24184] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24184ULL);
arm64_l_130:
	/* 0x130: str w8, [x0, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_134:
	/* 0x134: cbz w8, 2b4 <generic_retkprobe_event+0x2b4> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x134, 0x2b4, arm64_l_2b4);
arm64_l_138:
	/* 0x138: mov w22, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_13c:
	/* 0x13c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_140:
	/* 0x140: add x21, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_144:
	/* 0x144: ldr w8, [x29, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_148:
	/* 0x148: cmp w8, #0xb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 11ULL);
arm64_l_14c:
	/* 0x14c: b.eq 274 <generic_retkprobe_event+0x274> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x14c, 0x274, arm64_l_274);
arm64_l_150:
	/* 0x150: cmp w8, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_154:
	/* 0x154: b.ne 190 <generic_retkprobe_event+0x190> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x154, 0x190, arm64_l_190);
arm64_l_158:
	/* 0x158: ldr w8, [x20, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_15c:
	/* 0x15c: ldr w9, [x20, #124] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 124ULL);
arm64_l_160:
	/* 0x160: adrp x0, 0 <socktrack_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&socktrack_map_9));
arm64_l_164:
	/* 0x164: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_168:
	/* 0x168: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_16c:
	/* 0x16c: add x1, sp, #0x60 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_170:
	/* 0x170: stp w8, w9, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_174:
	/* 0x174: ldr x8, [x20, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_178:
	/* 0x178: add x9, sp, #0x60 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_17c:
	/* 0x17c: add x2, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_180:
	/* 0x180: str x8, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_184:
	/* 0x184: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_188:
	/* 0x188: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18c:
	/* 0x18c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0x190ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_190:
	/* 0x190: ldr x8, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_194:
	/* 0x194: and x24, x21, #0x1fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 8191ULL);
arm64_l_198:
	/* 0x198: mov w21, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_19c:
	/* 0x19c: cmp w22, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1a0:
	/* 0x1a0: b.eq 1fc <generic_retkprobe_event+0x1fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1a0, 0x1fc, arm64_l_1fc);
arm64_l_1a4:
	/* 0x1a4: cmp w21, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1a8:
	/* 0x1a8: b.ne 398 <generic_retkprobe_event+0x398> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1a8, 0x398, arm64_l_398);
arm64_l_1ac:
	/* 0x1ac: str wzr, [x8, x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_XZR, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X24, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b0:
	/* 0x1b0: add x21, x24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1b4:
	/* 0x1b4: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_1b8:
	/* 0x1b8: mov w25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1bc:
	/* 0x1bc: add x23, x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1c0:
	/* 0x1c0: ldr x24, [sp, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1c4:
	/* 0x1c4: mov w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4095ULL);
arm64_l_1c8:
	/* 0x1c8: add x0, x23, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1cc:
	/* 0x1cc: cmp x24, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1d0:
	/* 0x1d0: csel x22, x24, x8, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X22, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_1d4:
	/* 0x1d4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1d8:
	/* 0x1d8: mov w1, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1dc:
	/* 0x1dc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1e0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1e0:
	/* 0x1e0: tbnz w0, #31, 2a4 <generic_retkprobe_event+0x2a4> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x1e0, 0x2a4, arm64_l_2a4);
arm64_l_1e4:
	/* 0x1e4: add x25, x22, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1e8:
	/* 0x1e8: str w22, [x23, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1ec:
	/* 0x1ec: b 2a8 <generic_retkprobe_event+0x2a8> */
	ARM64_SIM_A64_JMP(0x1ec, 0x2a8, arm64_l_2a8);
arm64_l_1f0:
	/* 0x1f0: mov w24, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1f4:
	/* 0x1f4: cmp w21, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1f8:
	/* 0x1f8: b.ne 1a4 <generic_retkprobe_event+0x1a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1f8, 0x1a4, arm64_l_1a4);
arm64_l_1fc:
	/* 0x1fc: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_200:
	/* 0x200: add x25, x24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_204:
	/* 0x204: str wzr, [x8, x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_XZR, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X24, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_208:
	/* 0x208: cbz x9, 2fc <generic_retkprobe_event+0x2fc> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0x208, 0x2fc, arm64_l_2fc);
arm64_l_20c:
	/* 0x20c: str x8, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_210:
	/* 0x210: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_214:
	/* 0x214: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_218:
	/* 0x218: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_21c:
	/* 0x21c: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_220:
	/* 0x220: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_224:
	/* 0x224: ldr x21, [sp, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_228:
	/* 0x228: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_22c:
	/* 0x22c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x230ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_230:
	/* 0x230: tbnz w0, #31, 318 <generic_retkprobe_event+0x318> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x230, 0x318, arm64_l_318);
arm64_l_234:
	/* 0x234: ldr x8, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_238:
	/* 0x238: str x29, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_23c:
	/* 0x23c: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_240:
	/* 0x240: csel x23, x8, x21, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X23, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_244:
	/* 0x244: cmp x21, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_248:
	/* 0x248: csel x29, x8, x23, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X29, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_EQ, 0);
arm64_l_24c:
	/* 0x24c: cmp x29, #0xffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4094ULL);
arm64_l_250:
	/* 0x250: b.ls 344 <generic_retkprobe_event+0x344> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x250, 0x344, arm64_l_344);
arm64_l_254:
	/* 0x254: mov w8, #0xfffffffd */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967293ULL);
arm64_l_258:
	/* 0x258: b 384 <generic_retkprobe_event+0x384> */
	ARM64_SIM_A64_JMP(0x258, 0x384, arm64_l_384);
arm64_l_25c:
	/* 0x25c: mov w22, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_260:
	/* 0x260: mov x8, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_264:
	/* 0x264: add x21, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_268:
	/* 0x268: ldr w8, [x29, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_26c:
	/* 0x26c: cmp w8, #0xb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 11ULL);
arm64_l_270:
	/* 0x270: b.ne 150 <generic_retkprobe_event+0x150> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x270, 0x150, arm64_l_150);
arm64_l_274:
	/* 0x274: adrp x0, 0 <socktrack_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&socktrack_map_9));
arm64_l_278:
	/* 0x278: mov w8, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_27c:
	/* 0x27c: add x9, sp, #0x60 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_280:
	/* 0x280: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_284:
	/* 0x284: add x1, sp, #0x60 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_288:
	/* 0x288: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 3ULL: ARM64_SIM_A64_LINK(0x28cULL); ARM64_SIM_BPF_CALL_bpf_map_delete_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_28c:
	/* 0x28c: ldr x8, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_290:
	/* 0x290: and x24, x21, #0x1fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 8191ULL);
arm64_l_294:
	/* 0x294: mov w21, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_298:
	/* 0x298: cmp w22, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_29c:
	/* 0x29c: b.ne 1a4 <generic_retkprobe_event+0x1a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x29c, 0x1a4, arm64_l_1a4);
arm64_l_2a0:
	/* 0x2a0: b 1fc <generic_retkprobe_event+0x1fc> */
	ARM64_SIM_A64_JMP(0x2a0, 0x1fc, arm64_l_1fc);
arm64_l_2a4:
	/* 0x2a4: mov w24, #0xfffffffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967294ULL);
arm64_l_2a8:
	/* 0x2a8: str w24, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ac:
	/* 0x2ac: add x24, x25, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X25, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2b0:
	/* 0x2b0: b 398 <generic_retkprobe_event+0x398> */
	ARM64_SIM_A64_JMP(0x2b0, 0x398, arm64_l_398);
arm64_l_2b4:
	/* 0x2b4: add x9, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_2b8:
	/* 0x2b8: add x8, x0, #0x9c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 156ULL);
arm64_l_2bc:
	/* 0x2bc: cmp w22, #0x17 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 23ULL);
arm64_l_2c0:
	/* 0x2c0: str x24, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_2c4:
	/* 0x2c4: str x0, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2c8:
	/* 0x2c8: str x8, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2cc:
	/* 0x2cc: str xzr, [x9, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2d0:
	/* 0x2d0: b.le 320 <generic_retkprobe_event+0x320> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2d0, 0x320, arm64_l_320);
arm64_l_2d4:
	/* 0x2d4: cmp w22, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_2d8:
	/* 0x2d8: b.eq 61c <generic_retkprobe_event+0x61c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2d8, 0x61c, arm64_l_61c);
arm64_l_2dc:
	/* 0x2dc: cmp w22, #0x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_2e0:
	/* 0x2e0: b.eq 680 <generic_retkprobe_event+0x680> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2e0, 0x680, arm64_l_680);
arm64_l_2e4:
	/* 0x2e4: cmp w22, #0x2a */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 42ULL);
arm64_l_2e8:
	/* 0x2e8: b.ne a44 <generic_retkprobe_event+0xa44> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2e8, 0xa44, arm64_l_a44);
arm64_l_2ec:
	/* 0x2ec: add x8, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_2f0:
	/* 0x2f0: stp xzr, x24, [sp, #112] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_2f4:
	/* 0x2f4: str x8, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2f8:
	/* 0x2f8: b 6e8 <generic_retkprobe_event+0x6e8> */
	ARM64_SIM_A64_JMP(0x2f8, 0x6e8, arm64_l_6e8);
arm64_l_2fc:
	/* 0x2fc: str x29, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_300:
	/* 0x300: mov x29, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_304:
	/* 0x304: add x8, x8, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_308:
	/* 0x308: stp w29, w29, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X8, ARM64_X29, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_30c:
	/* 0x30c: add x8, x29, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_310:
	/* 0x310: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_314:
	/* 0x314: b 394 <generic_retkprobe_event+0x394> */
	ARM64_SIM_A64_JMP(0x314, 0x394, arm64_l_394);
arm64_l_318:
	/* 0x318: mov w8, #0xfffffffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967294ULL);
arm64_l_31c:
	/* 0x31c: b 388 <generic_retkprobe_event+0x388> */
	ARM64_SIM_A64_JMP(0x31c, 0x388, arm64_l_388);
arm64_l_320:
	/* 0x320: cmp w22, #0xf */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_324:
	/* 0x324: b.eq 6b8 <generic_retkprobe_event+0x6b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x324, 0x6b8, arm64_l_6b8);
arm64_l_328:
	/* 0x328: cmp w22, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_32c:
	/* 0x32c: b.ne a44 <generic_retkprobe_event+0xa44> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x32c, 0xa44, arm64_l_a44);
arm64_l_330:
	/* 0x330: mov x23, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_334:
	/* 0x334: mov w22, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_338:
	/* 0x338: add x21, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_33c:
	/* 0x33c: add x19, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_340:
	/* 0x340: b 64c <generic_retkprobe_event+0x64c> */
	ARM64_SIM_A64_JMP(0x340, 0x64c, arm64_l_64c);
arm64_l_344:
	/* 0x344: ldr x8, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_348:
	/* 0x348: add x22, x24, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_34c:
	/* 0x34c: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_350:
	/* 0x350: mov w1, w29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_354:
	/* 0x354: add x0, x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_358:
	/* 0x358: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_35c:
	/* 0x35c: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_360:
	/* 0x360: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x364ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_364:
	/* 0x364: tbnz w0, #31, 380 <generic_retkprobe_event+0x380> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x364, 0x380, arm64_l_380);
arm64_l_368:
	/* 0x368: cbz x21, b98 <generic_retkprobe_event+0xb98> */
	ARM64_SIM_A64_CBZ(ARM64_X21, 0x368, 0xb98, arm64_l_b98);
arm64_l_36c:
	/* 0x36c: ldr x8, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_370:
	/* 0x370: subs x21, x21, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X21, ARM64_X21, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_374:
	/* 0x374: b.ne b9c <generic_retkprobe_event+0xb9c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x374, 0xb9c, arm64_l_b9c);
arm64_l_378:
	/* 0x378: mov x29, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_37c:
	/* 0x37c: b 304 <generic_retkprobe_event+0x304> */
	ARM64_SIM_A64_JMP(0x37c, 0x304, arm64_l_304);
arm64_l_380:
	/* 0x380: mov w8, #0xfffffffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967294ULL);
arm64_l_384:
	/* 0x384: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_388:
	/* 0x388: ldr x9, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_38c:
	/* 0x38c: str w8, [x9, x25] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X25, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_390:
	/* 0x390: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_394:
	/* 0x394: add x24, x8, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_398:
	/* 0x398: mov w8, #0x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 35ULL);
arm64_l_39c:
	/* 0x39c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 35ULL: ARM64_SIM_A64_LINK(0x3a0ULL); ARM64_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3a0:
	/* 0x3a0: str x0, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_3a4:
	/* 0x3a4: add x8, x0, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_3a8:
	/* 0x3a8: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_3ac:
	/* 0x3ac: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3b0:
	/* 0x3b0: add x11, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_3b4:
	/* 0x3b4: add x0, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_3b8:
	/* 0x3b8: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_3bc:
	/* 0x3bc: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_3c0:
	/* 0x3c0: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_3c4:
	/* 0x3c4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3c8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3c8:
	/* 0x3c8: ldr w8, [sp, #112] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_3cc:
	/* 0x3cc: adrp x22, 0 <execve_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&execve_map_4));
arm64_l_3d0:
	/* 0x3d0: add x9, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_3d4:
	/* 0x3d4: add x1, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_3d8:
	/* 0x3d8: str w8, [sp, #232] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_3dc:
	/* 0x3dc: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_3e0:
	/* 0x3e0: ldr x22, [x22] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3e4:
	/* 0x3e4: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3e8:
	/* 0x3e8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x3ecULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3ec:
	/* 0x3ec: cbz x0, 3fc <generic_retkprobe_event+0x3fc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x3ec, 0x3fc, arm64_l_3fc);
arm64_l_3f0:
	/* 0x3f0: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_3f4:
	/* 0x3f4: mov x23, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3f8:
	/* 0x3f8: cbnz x8, 5a8 <generic_retkprobe_event+0x5a8> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0x3f8, 0x5a8, arm64_l_5a8);
arm64_l_3fc:
	/* 0x3fc: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_400:
	/* 0x400: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_404:
	/* 0x404: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_408:
	/* 0x408: add x11, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_40c:
	/* 0x40c: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_410:
	/* 0x410: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_414:
	/* 0x414: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_418:
	/* 0x418: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_41c:
	/* 0x41c: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_420:
	/* 0x420: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x424ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_424:
	/* 0x424: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_428:
	/* 0x428: cbz x8, 5a4 <generic_retkprobe_event+0x5a4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x428, 0x5a4, arm64_l_5a4);
arm64_l_42c:
	/* 0x42c: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_430:
	/* 0x430: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_434:
	/* 0x434: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_438:
	/* 0x438: add x11, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_43c:
	/* 0x43c: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_440:
	/* 0x440: add x0, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_444:
	/* 0x444: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_448:
	/* 0x448: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_44c:
	/* 0x44c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x450ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_450:
	/* 0x450: ldr w8, [sp, #112] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_454:
	/* 0x454: add x9, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_458:
	/* 0x458: add x1, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_45c:
	/* 0x45c: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_460:
	/* 0x460: str w8, [sp, #232] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_464:
	/* 0x464: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_468:
	/* 0x468: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x46cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_46c:
	/* 0x46c: cbz x0, 47c <generic_retkprobe_event+0x47c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x46c, 0x47c, arm64_l_47c);
arm64_l_470:
	/* 0x470: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_474:
	/* 0x474: mov x23, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_478:
	/* 0x478: cbnz x8, 5a8 <generic_retkprobe_event+0x5a8> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0x478, 0x5a8, arm64_l_5a8);
arm64_l_47c:
	/* 0x47c: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_480:
	/* 0x480: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_484:
	/* 0x484: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_488:
	/* 0x488: add x11, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_48c:
	/* 0x48c: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_490:
	/* 0x490: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_494:
	/* 0x494: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_498:
	/* 0x498: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_49c:
	/* 0x49c: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_4a0:
	/* 0x4a0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x4a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_4a4:
	/* 0x4a4: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_4a8:
	/* 0x4a8: cbz x8, 5a4 <generic_retkprobe_event+0x5a4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x4a8, 0x5a4, arm64_l_5a4);
arm64_l_4ac:
	/* 0x4ac: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_4b0:
	/* 0x4b0: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_4b4:
	/* 0x4b4: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_4b8:
	/* 0x4b8: add x11, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_4bc:
	/* 0x4bc: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_4c0:
	/* 0x4c0: add x0, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_4c4:
	/* 0x4c4: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_4c8:
	/* 0x4c8: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_4cc:
	/* 0x4cc: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x4d0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_4d0:
	/* 0x4d0: ldr w8, [sp, #112] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_4d4:
	/* 0x4d4: add x9, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_4d8:
	/* 0x4d8: add x1, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_4dc:
	/* 0x4dc: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_4e0:
	/* 0x4e0: str w8, [sp, #232] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_4e4:
	/* 0x4e4: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_4e8:
	/* 0x4e8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x4ecULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_4ec:
	/* 0x4ec: cbz x0, 4fc <generic_retkprobe_event+0x4fc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x4ec, 0x4fc, arm64_l_4fc);
arm64_l_4f0:
	/* 0x4f0: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_4f4:
	/* 0x4f4: mov x23, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_4f8:
	/* 0x4f8: cbnz x8, 5a8 <generic_retkprobe_event+0x5a8> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0x4f8, 0x5a8, arm64_l_5a8);
arm64_l_4fc:
	/* 0x4fc: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_500:
	/* 0x500: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_504:
	/* 0x504: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_508:
	/* 0x508: add x11, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_50c:
	/* 0x50c: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_510:
	/* 0x510: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_514:
	/* 0x514: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_518:
	/* 0x518: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_51c:
	/* 0x51c: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_520:
	/* 0x520: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x524ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_524:
	/* 0x524: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_528:
	/* 0x528: cbz x8, 5a4 <generic_retkprobe_event+0x5a4> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x528, 0x5a4, arm64_l_5a4);
arm64_l_52c:
	/* 0x52c: add x8, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_530:
	/* 0x530: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_534:
	/* 0x534: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_538:
	/* 0x538: add x11, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_53c:
	/* 0x53c: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_540:
	/* 0x540: add x0, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_544:
	/* 0x544: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_548:
	/* 0x548: add x2, x8, #0x8d4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2260ULL);
arm64_l_54c:
	/* 0x54c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x550ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_550:
	/* 0x550: ldr w8, [sp, #112] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_554:
	/* 0x554: add x9, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_558:
	/* 0x558: add x1, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_55c:
	/* 0x55c: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_560:
	/* 0x560: str w8, [sp, #232] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_564:
	/* 0x564: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_568:
	/* 0x568: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x56cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_56c:
	/* 0x56c: cbz x0, 57c <generic_retkprobe_event+0x57c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x56c, 0x57c, arm64_l_57c);
arm64_l_570:
	/* 0x570: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_574:
	/* 0x574: mov x23, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_578:
	/* 0x578: cbnz x8, 5a8 <generic_retkprobe_event+0x5a8> */
	ARM64_SIM_A64_CBNZ(ARM64_X8, 0x578, 0x5a8, arm64_l_5a8);
arm64_l_57c:
	/* 0x57c: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_580:
	/* 0x580: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_584:
	/* 0x584: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_588:
	/* 0x588: add x11, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_58c:
	/* 0x58c: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_590:
	/* 0x590: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_594:
	/* 0x594: add x8, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_598:
	/* 0x598: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_59c:
	/* 0x59c: add x2, x8, #0x8e0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2272ULL);
arm64_l_5a0:
	/* 0x5a0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x5a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_5a4:
	/* 0x5a4: mov x23, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5a8:
	/* 0x5a8: mov w8, #0x10d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 269ULL);
arm64_l_5ac:
	/* 0x5ac: stp w8, w24, [x20] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X20, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_5b0:
	/* 0x5b0: mov w8, #0x7d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 125ULL);
arm64_l_5b4:
	/* 0x5b4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 125ULL: ARM64_SIM_A64_LINK(0x5b8ULL); ARM64_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_5b8:
	/* 0x5b8: str x0, [x20, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_5bc:
	/* 0x5bc: cbz x23, 5d0 <generic_retkprobe_event+0x5d0> */
	ARM64_SIM_A64_CBZ(ARM64_X23, 0x5bc, 0x5d0, arm64_l_5d0);
arm64_l_5c0:
	/* 0x5c0: ldr w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_5c4:
	/* 0x5c4: str w8, [x20, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_5c8:
	/* 0x5c8: ldr x8, [x23, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_5cc:
	/* 0x5cc: str x8, [x20, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_5d0:
	/* 0x5d0: str wzr, [x20, #20] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 20ULL);
arm64_l_5d4:
	/* 0x5d4: adrp x1, 0 <retkprobe_calls> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&retkprobe_calls_7));
arm64_l_5d8:
	/* 0x5d8: mov w9, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_5dc:
	/* 0x5dc: mov x0, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5e0:
	/* 0x5e0: ldr w8, [x29] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_5e4:
	/* 0x5e4: str w24, [x20, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_5e8:
	/* 0x5e8: mov w2, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_5ec:
	/* 0x5ec: str x8, [x20, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_5f0:
	/* 0x5f0: mov w8, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_5f4:
	/* 0x5f4: ldr x1, [x1] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_5f8:
	/* 0x5f8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x5fcULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_5fc:
	/* 0x5fc: mov w0, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_600:
	/* 0x600: ldp x20, x19, [sp, #320] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 320ULL);
arm64_l_604:
	/* 0x604: ldr x29, [sp, #256] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 256ULL);
arm64_l_608:
	/* 0x608: ldp x22, x21, [sp, #304] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 304ULL);
arm64_l_60c:
	/* 0x60c: ldp x24, x23, [sp, #288] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 288ULL);
arm64_l_610:
	/* 0x610: ldp x30, x25, [sp, #272] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 272ULL);
arm64_l_614:
	/* 0x614: add sp, sp, #0x150 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 336ULL);
arm64_l_618:
	/* 0x618: b 28c8 <__native_link_arm64_ret_trampoline> */
	ARM64_SIM_A64_JMP(0x618, 0x28c8, arm64_l_28c8);
arm64_l_61c:
	/* 0x61c: mov w22, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_620:
	/* 0x620: add x21, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_624:
	/* 0x624: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_628:
	/* 0x628: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_62c:
	/* 0x62c: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_630:
	/* 0x630: add x0, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_634:
	/* 0x634: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_638:
	/* 0x638: mov x23, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_63c:
	/* 0x63c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x640ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_640:
	/* 0x640: add x19, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_644:
	/* 0x644: ldr x8, [x19, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_648:
	/* 0x648: str x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_64c:
	/* 0x64c: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_650:
	/* 0x650: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_654:
	/* 0x654: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_658:
	/* 0x658: add x0, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_65c:
	/* 0x65c: add x2, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_660:
	/* 0x660: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_664:
	/* 0x664: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x668ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_668:
	/* 0x668: ldr x8, [x19, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_66c:
	/* 0x66c: mov w21, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_670:
	/* 0x670: mov x19, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_674:
	/* 0x674: add x8, x8, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_678:
	/* 0x678: str x8, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_67c:
	/* 0x67c: b 6e8 <generic_retkprobe_event+0x6e8> */
	ARM64_SIM_A64_JMP(0x67c, 0x6e8, arm64_l_6e8);
arm64_l_680:
	/* 0x680: add x8, x24, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_684:
	/* 0x684: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_688:
	/* 0x688: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_68c:
	/* 0x68c: str x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_690:
	/* 0x690: add x11, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_694:
	/* 0x694: add x0, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_698:
	/* 0x698: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_69c:
	/* 0x69c: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_6a0:
	/* 0x6a0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x6a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_6a4:
	/* 0x6a4: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_6a8:
	/* 0x6a8: ldr x8, [x8, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_6ac:
	/* 0x6ac: add x8, x8, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_6b0:
	/* 0x6b0: str x8, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_6b4:
	/* 0x6b4: b 6e8 <generic_retkprobe_event+0x6e8> */
	ARM64_SIM_A64_JMP(0x6b4, 0x6e8, arm64_l_6e8);
arm64_l_6b8:
	/* 0x6b8: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_6bc:
	/* 0x6bc: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_6c0:
	/* 0x6c0: add x10, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_6c4:
	/* 0x6c4: add x11, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_6c8:
	/* 0x6c8: add x0, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_6cc:
	/* 0x6cc: add x2, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_6d0:
	/* 0x6d0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_6d4:
	/* 0x6d4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x6d8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_6d8:
	/* 0x6d8: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_6dc:
	/* 0x6dc: ldr x8, [x8, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_6e0:
	/* 0x6e0: str x8, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_6e4:
	/* 0x6e4: cbz x8, b38 <generic_retkprobe_event+0xb38> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x6e4, 0xb38, arm64_l_b38);
arm64_l_6e8:
	/* 0x6e8: str wzr, [sp, #132] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 132ULL);
arm64_l_6ec:
	/* 0x6ec: adrp x0, 0 <buffer_heap_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&buffer_heap_map_2));
arm64_l_6f0:
	/* 0x6f0: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_6f4:
	/* 0x6f4: add x9, sp, #0x84 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 132ULL);
arm64_l_6f8:
	/* 0x6f8: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_6fc:
	/* 0x6fc: add x1, sp, #0x84 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 132ULL);
arm64_l_700:
	/* 0x700: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x704ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_704:
	/* 0x704: mov x25, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_708:
	/* 0x708: cbz x0, cbc <generic_retkprobe_event+0xcbc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x708, 0xcbc, arm64_l_cbc);
arm64_l_70c:
	/* 0x70c: add x8, x25, #0x1, lsl #12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_710:
	/* 0x710: str w21, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_714:
	/* 0x714: str x29, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_718:
	/* 0x718: str x8, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_71c:
	/* 0x71c: mov w8, #0x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 35ULL);
arm64_l_720:
	/* 0x720: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 35ULL: ARM64_SIM_A64_LINK(0x724ULL); ARM64_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_724:
	/* 0x724: add x2, x0, #0xb30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2864ULL);
arm64_l_728:
	/* 0x728: mov w24, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_72c:
	/* 0x72c: add x8, sp, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_730:
	/* 0x730: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_734:
	/* 0x734: add x0, sp, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_738:
	/* 0x738: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_73c:
	/* 0x73c: mov w29, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_740:
	/* 0x740: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x744ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_744:
	/* 0x744: ldr x22, [sp, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_748:
	/* 0x748: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_74c:
	/* 0x74c: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_750:
	/* 0x750: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_754:
	/* 0x754: add x8, x22, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_758:
	/* 0x758: str x8, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_75c:
	/* 0x75c: ldr x8, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_760:
	/* 0x760: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_764:
	/* 0x764: add x8, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_768:
	/* 0x768: str x2, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_76c:
	/* 0x76c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x770ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_770:
	/* 0x770: ldr x21, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_774:
	/* 0x774: add x23, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_778:
	/* 0x778: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_77c:
	/* 0x77c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_780:
	/* 0x780: add x2, x21, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_784:
	/* 0x784: blr x29 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X29);
		if (ARM64_SIM_L_REG_TAG(ARM64_X29) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x788ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_788:
	/* 0x788: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_78c:
	/* 0x78c: cbz x8, 79c <generic_retkprobe_event+0x79c> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x78c, 0x79c, arm64_l_79c);
arm64_l_790:
	/* 0x790: ldr x9, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_794:
	/* 0x794: mov w8, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_798:
	/* 0x798: b 7e4 <generic_retkprobe_event+0x7e4> */
	ARM64_SIM_A64_JMP(0x798, 0x7e4, arm64_l_7e4);
arm64_l_79c:
	/* 0x79c: add x2, x21, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_7a0:
	/* 0x7a0: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_7a4:
	/* 0x7a4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_7a8:
	/* 0x7a8: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_7ac:
	/* 0x7ac: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_7b0:
	/* 0x7b0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_7b4:
	/* 0x7b4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x7b8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_7b8:
	/* 0x7b8: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_7bc:
	/* 0x7bc: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_7c0:
	/* 0x7c0: b.eq 790 <generic_retkprobe_event+0x790> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x7c0, 0x790, arm64_l_790);
arm64_l_7c4:
	/* 0x7c4: mov w8, #0x2964 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10596ULL);
arm64_l_7c8:
	/* 0x7c8: add x9, x25, #0xff6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4086ULL);
arm64_l_7cc:
	/* 0x7cc: strh w8, [x25, #4094] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4094ULL);
arm64_l_7d0:
	/* 0x7d0: adrp x8, 0 <generic_retkprobe_event> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&arm64_section_Some_SectionIndex_12_addend_0_1));
arm64_l_7d4:
	/* 0x7d4: add x8, x8, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_7d8:
	/* 0x7d8: ldr x8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_7dc:
	/* 0x7dc: str x8, [x9] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_7e0:
	/* 0x7e0: mov w8, #0xff6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4086ULL);
arm64_l_7e4:
	/* 0x7e4: stp xzr, xzr, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_7e8:
	/* 0x7e8: add x2, x22, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_7ec:
	/* 0x7ec: mov w21, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_7f0:
	/* 0x7f0: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_7f4:
	/* 0x7f4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_7f8:
	/* 0x7f8: add x24, x23, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_7fc:
	/* 0x7fc: stp x25, xzr, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X25, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_800:
	/* 0x800: add x29, x23, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_804:
	/* 0x804: add x25, x23, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_808:
	/* 0x808: stp xzr, xzr, [sp, #184] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_80c:
	/* 0x80c: mov w22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_810:
	/* 0x810: str x9, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_814:
	/* 0x814: str x9, [sp, #200] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_818:
	/* 0x818: str w8, [sp, #208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_81c:
	/* 0x81c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_820:
	/* 0x820: strb wzr, [sp, #212] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 212ULL);
arm64_l_824:
	/* 0x824: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x828ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_828:
	/* 0x828: ldr x2, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_82c:
	/* 0x82c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_830:
	/* 0x830: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_834:
	/* 0x834: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_838:
	/* 0x838: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x83cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_83c:
	/* 0x83c: ldr x2, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_840:
	/* 0x840: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_844:
	/* 0x844: mov x0, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_848:
	/* 0x848: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_84c:
	/* 0x84c: str x29, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_850:
	/* 0x850: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x854ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_854:
	/* 0x854: ldr x2, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_858:
	/* 0x858: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_85c:
	/* 0x85c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_860:
	/* 0x860: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x864ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_864:
	/* 0x864: ldr x8, [sp, #184] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_868:
	/* 0x868: sub x8, x8, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_86c:
	/* 0x86c: str x8, [sp, #192] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_870:
	/* 0x870: adrp x8, 0 <CONFIG_ITER_NUM> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM_0));
arm64_l_874:
	/* 0x874: ldr x8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_878:
	/* 0x878: ldrb w8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_87c:
	/* 0x87c: cbz w8, a1c <generic_retkprobe_event+0xa1c> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x87c, 0xa1c, arm64_l_a1c);
arm64_l_880:
	/* 0x880: mov w23, #0x800 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_884:
	/* 0x884: mov w24, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_888:
	/* 0x888: ldp x25, x2, [sp, #176] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X25, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_88c:
	/* 0x88c: ldp x8, x9, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_890:
	/* 0x890: cmp x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_894:
	/* 0x894: ccmp x2, x9, #0x0, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CCMP_REG, ARM64_X2, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_EQ, 0), 0);
arm64_l_898:
	/* 0x898: b.eq ad8 <generic_retkprobe_event+0xad8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x898, 0xad8, arm64_l_ad8);
arm64_l_89c:
	/* 0x89c: ldr x21, [sp, #192] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_8a0:
	/* 0x8a0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_8a4:
	/* 0x8a4: add x9, sp, #0xd8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_8a8:
	/* 0x8a8: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_8ac:
	/* 0x8ac: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_8b0:
	/* 0x8b0: mov x29, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_8b4:
	/* 0x8b4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x8b8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_8b8:
	/* 0x8b8: ldr x8, [sp, #216] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_8bc:
	/* 0x8bc: add x19, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_8c0:
	/* 0x8c0: cmp x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8c4:
	/* 0x8c4: b.eq 9c0 <generic_retkprobe_event+0x9c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x8c4, 0x9c0, arm64_l_9c0);
arm64_l_8c8:
	/* 0x8c8: add x22, x25, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_8cc:
	/* 0x8cc: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_8d0:
	/* 0x8d0: add x9, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_8d4:
	/* 0x8d4: add x0, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_8d8:
	/* 0x8d8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_8dc:
	/* 0x8dc: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_8e0:
	/* 0x8e0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x8e4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_8e4:
	/* 0x8e4: ldr x8, [x19, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_8e8:
	/* 0x8e8: cmp x8, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8ec:
	/* 0x8ec: b.eq 9c0 <generic_retkprobe_event+0x9c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x8ec, 0x9c0, arm64_l_9c0);
arm64_l_8f0:
	/* 0x8f0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_8f4:
	/* 0x8f4: add x9, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_8f8:
	/* 0x8f8: add x0, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_8fc:
	/* 0x8fc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_900:
	/* 0x900: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_904:
	/* 0x904: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x908ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_908:
	/* 0x908: add x2, x25, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_90c:
	/* 0x90c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_910:
	/* 0x910: mov w9, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_914:
	/* 0x914: add x10, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_918:
	/* 0x918: add x0, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_91c:
	/* 0x91c: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_920:
	/* 0x920: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x924ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_924:
	/* 0x924: ldr w21, [sp, #236] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 236ULL);
arm64_l_928:
	/* 0x928: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_92c:
	/* 0x92c: add x25, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_930:
	/* 0x930: ldr x10, [sp, #200] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_934:
	/* 0x934: sub x12, x10, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_938:
	/* 0x938: ldr w22, [sp, #208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_93c:
	/* 0x93c: subs w10, w21, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X10, ARM64_X21, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_940:
	/* 0x940: ldr x9, [x19, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_944:
	/* 0x944: mov x19, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_948:
	/* 0x948: csel w10, wzr, w10, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X10, ARM64_XZR, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_94c:
	/* 0x94c: cmp w22, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_950:
	/* 0x950: csel w11, w22, w21, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_954:
	/* 0x954: cinc w13, w11, hi */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CINC, ARM64_X13, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_958:
	/* 0x958: sub w14, w22, w13 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X22, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_95c:
	/* 0x95c: subs x12, x12, x13 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X12, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_960:
	/* 0x960: str w14, [sp, #208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_964:
	/* 0x964: b.cc ae4 <generic_retkprobe_event+0xae4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x964, 0xae4, arm64_l_ae4);
arm64_l_968:
	/* 0x968: cmp x12, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_96c:
	/* 0x96c: b.hi ae4 <generic_retkprobe_event+0xae4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x96c, 0xae4, arm64_l_ae4);
arm64_l_970:
	/* 0x970: cmp w22, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_974:
	/* 0x974: b.ls 980 <generic_retkprobe_event+0x980> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x974, 0x980, arm64_l_980);
arm64_l_978:
	/* 0x978: mov w13, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_97c:
	/* 0x97c: strb w13, [x8, x12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X12, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_980:
	/* 0x980: add x25, x8, x12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X25, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_984:
	/* 0x984: cmp w22, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_988:
	/* 0x988: add x2, x9, x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_98c:
	/* 0x98c: and w1, w11, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_990:
	/* 0x990: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_994:
	/* 0x994: cinc x0, x25, hi */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CINC, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_HI, 0);
arm64_l_998:
	/* 0x998: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x99cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_99c:
	/* 0x99c: cmp w22, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_9a0:
	/* 0x9a0: str x25, [sp, #200] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_9a4:
	/* 0x9a4: add x25, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_9a8:
	/* 0x9a8: b.ls ae4 <generic_retkprobe_event+0xae4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x9a8, 0xae4, arm64_l_ae4);
arm64_l_9ac:
	/* 0x9ac: ldr x8, [x25] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_9b0:
	/* 0x9b0: str x8, [sp, #176] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_9b4:
	/* 0x9b4: subs w23, w23, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_IMM, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_9b8:
	/* 0x9b8: b.ne 888 <generic_retkprobe_event+0x888> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x9b8, 0x888, arm64_l_888);
arm64_l_9bc:
	/* 0x9bc: b ae4 <generic_retkprobe_event+0xae4> */
	ARM64_SIM_A64_JMP(0x9bc, 0xae4, arm64_l_ae4);
arm64_l_9c0:
	/* 0x9c0: add x2, x21, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_9c4:
	/* 0x9c4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_9c8:
	/* 0x9c8: add x9, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_9cc:
	/* 0x9cc: add x0, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_9d0:
	/* 0x9d0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_9d4:
	/* 0x9d4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x9d8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_9d8:
	/* 0x9d8: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_9dc:
	/* 0x9dc: ldr x9, [x19, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_9e0:
	/* 0x9e0: add x25, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_9e4:
	/* 0x9e4: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_9e8:
	/* 0x9e8: b.eq bf0 <generic_retkprobe_event+0xbf0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x9e8, 0xbf0, arm64_l_bf0);
arm64_l_9ec:
	/* 0x9ec: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_9f0:
	/* 0x9f0: add x2, x21, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_9f4:
	/* 0x9f4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_9f8:
	/* 0x9f8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_9fc:
	/* 0x9fc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xa00ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_a00:
	/* 0xa00: ldr x8, [x25, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_a04:
	/* 0xa04: mov x19, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a08:
	/* 0xa08: add x9, x8, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_a0c:
	/* 0xa0c: stp x9, x8, [sp, #184] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_a10:
	/* 0xa10: subs w23, w23, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_IMM, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a14:
	/* 0xa14: b.ne 888 <generic_retkprobe_event+0x888> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xa14, 0x888, arm64_l_888);
arm64_l_a18:
	/* 0xa18: b ae4 <generic_retkprobe_event+0xae4> */
	ARM64_SIM_A64_JMP(0xa18, 0xae4, arm64_l_ae4);
arm64_l_a1c:
	/* 0xa1c: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a20:
	/* 0xa20: adrp x1, 10 <generic_retkprobe_event+0x10> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_RODATA, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)__arm64_rodata_0));
arm64_l_a24:
	/* 0xa24: add x1, x1, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_a28:
	/* 0xa28: mov w8, #0x800 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_a2c:
	/* 0xa2c: mov w9, #0xb5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 181ULL);
arm64_l_a30:
	/* 0xa30: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_a34:
	/* 0xa34: add x2, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_a38:
	/* 0xa38: mov w0, #0x800 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_a3c:
	/* 0xa3c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 181ULL: ARM64_SIM_A64_LINK(0xa40ULL); ARM64_SIM_BPF_CALL_bpf_loop(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_a40:
	/* 0xa40: b ae0 <generic_retkprobe_event+0xae0> */
	ARM64_SIM_A64_JMP(0xa40, 0xae0, arm64_l_ae0);
arm64_l_a44:
	/* 0xa44: cmp w22, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_a48:
	/* 0xa48: b.hi b38 <generic_retkprobe_event+0xb38> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xa48, 0xb38, arm64_l_b38);
arm64_l_a4c:
	/* 0xa4c: mov x9, #0x7cf2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 31986ULL);
arm64_l_a50:
	/* 0xa50: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a54:
	/* 0xa54: movk x9, #0xf202, lsl #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 61954ULL);
arm64_l_a58:
	/* 0xa58: lsl x8, x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_a5c:
	/* 0xa5c: movk x9, #0x11c1, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 4545ULL);
arm64_l_a60:
	/* 0xa60: tst x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_a64:
	/* 0xa64: b.eq b38 <generic_retkprobe_event+0xb38> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xa64, 0xb38, arm64_l_b38);
arm64_l_a68:
	/* 0xa68: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_a6c:
	/* 0xa6c: str wzr, [sp, #224] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_a70:
	/* 0xa70: add x9, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_a74:
	/* 0xa74: add x1, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_a78:
	/* 0xa78: str x24, [x8, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_a7c:
	/* 0xa7c: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a80:
	/* 0xa80: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a84:
	/* 0xa84: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xa88ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_a88:
	/* 0xa88: mov x25, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a8c:
	/* 0xa8c: cbz x0, cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xa8c, 0xcb8, arm64_l_cb8);
arm64_l_a90:
	/* 0xa90: cmp w22, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_a94:
	/* 0xa94: b.le d08 <generic_retkprobe_event+0xd08> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xa94, 0xd08, arm64_l_d08);
arm64_l_a98:
	/* 0xa98: cmp w22, #0x1e */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 30ULL);
arm64_l_a9c:
	/* 0xa9c: b.le e14 <generic_retkprobe_event+0xe14> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xa9c, 0xe14, arm64_l_e14);
arm64_l_aa0:
	/* 0xaa0: cmp w22, #0x26; 0xaa4: b.gt f38 <generic_retkprobe_event+0xf38> */
arm64_l_aa4:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 38ULL, arm64_l_f38);
arm64_l_aa8:
	/* 0xaa8: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_aac:
	/* 0xaac: sub w8, w22, #0x1f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_ab0:
	/* 0xab0: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_ab4:
	/* 0xab4: b.cs 12e0 <generic_retkprobe_event+0x12e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xab4, 0x12e0, arm64_l_12e0);
arm64_l_ab8:
	/* 0xab8: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_abc:
	/* 0xabc: add x9, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_ac0:
	/* 0xac0: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_ac4:
	/* 0xac4: add x2, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_ac8:
	/* 0xac8: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_acc:
	/* 0xacc: mov w25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_ad0:
	/* 0xad0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xad4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_ad4:
	/* 0xad4: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0xad4, 0xcb8, arm64_l_cb8);
arm64_l_ad8:
	/* 0xad8: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_adc:
	/* 0xadc: strb w8, [sp, #212] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 212ULL);
arm64_l_ae0:
	/* 0xae0: add x25, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_ae4:
	/* 0xae4: ldr x9, [sp, #200] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_ae8:
	/* 0xae8: ldr x2, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_aec:
	/* 0xaec: cmp x9, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_af0:
	/* 0xaf0: b.eq c0c <generic_retkprobe_event+0xc0c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xaf0, 0xc0c, arm64_l_c0c);
arm64_l_af4:
	/* 0xaf4: ldrb w8, [sp, #212] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 212ULL);
arm64_l_af8:
	/* 0xaf8: mov w10, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_afc:
	/* 0xafc: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_b00:
	/* 0xb00: cmp w8, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_b04:
	/* 0xb04: ldr w8, [sp, #208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_b08:
	/* 0xb08: cset w11, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSET, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_b0c:
	/* 0xb0c: sub w10, w10, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_b10:
	/* 0xb10: cmp w8, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_b14:
	/* 0xb14: csel w10, w10, w8, gt */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X10, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_GT, 0);
arm64_l_b18:
	/* 0xb18: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_b1c:
	/* 0xb1c: cbz x9, b2c <generic_retkprobe_event+0xb2c> */
	ARM64_SIM_A64_CBZ(ARM64_X9, 0xb1c, 0xb2c, arm64_l_b2c);
arm64_l_b20:
	/* 0xb20: lsl w23, w11, #1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X23, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 1ULL);
arm64_l_b24:
	/* 0xb24: mov x2, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b28:
	/* 0xb28: b c1c <generic_retkprobe_event+0xc1c> */
	ARM64_SIM_A64_JMP(0xb28, 0xc1c, arm64_l_c1c);
arm64_l_b2c:
	/* 0xb2c: ldr w21, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_b30:
	/* 0xb30: mov x25, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b34:
	/* 0xb34: b cbc <generic_retkprobe_event+0xcbc> */
	ARM64_SIM_A64_JMP(0xb34, 0xcbc, arm64_l_cbc);
arm64_l_b38:
	/* 0xb38: str wzr, [sp, #112] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_b3c:
	/* 0xb3c: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_b40:
	/* 0xb40: add x9, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_b44:
	/* 0xb44: add x1, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_b48:
	/* 0xb48: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b4c:
	/* 0xb4c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xb50ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_b50:
	/* 0xb50: mov x25, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b54:
	/* 0xb54: cbz x0, cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xb54, 0xcb8, arm64_l_cb8);
arm64_l_b58:
	/* 0xb58: cmp w22, #0x19; 0xb5c: b.gt ec4 <generic_retkprobe_event+0xec4> */
arm64_l_b5c:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL, arm64_l_ec4);
arm64_l_b60:
	/* 0xb60: cmp w22, #0x12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_b64:
	/* 0xb64: b.le ff8 <generic_retkprobe_event+0xff8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xb64, 0xff8, arm64_l_ff8);
arm64_l_b68:
	/* 0xb68: cmp w22, #0x14 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_b6c:
	/* 0xb6c: b.le 1234 <generic_retkprobe_event+0x1234> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xb6c, 0x1234, arm64_l_1234);
arm64_l_b70:
	/* 0xb70: cmp w22, #0x15 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_b74:
	/* 0xb74: b.eq 1968 <generic_retkprobe_event+0x1968> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xb74, 0x1968, arm64_l_1968);
arm64_l_b78:
	/* 0xb78: cmp w22, #0x16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 22ULL);
arm64_l_b7c:
	/* 0xb7c: b.eq 1900 <generic_retkprobe_event+0x1900> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xb7c, 0x1900, arm64_l_1900);
arm64_l_b80:
	/* 0xb80: cmp w22, #0x17 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 23ULL);
arm64_l_b84:
	/* 0xb84: b.ne cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xb84, 0xcb8, arm64_l_cb8);
arm64_l_b88:
	/* 0xb88: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_b8c:
	/* 0xb8c: mov w25, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_b90:
	/* 0xb90: stp w24, wzr, [x8, #156] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X8, ARM64_X24, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 156ULL);
arm64_l_b94:
	/* 0xb94: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0xb94, 0xcb8, arm64_l_cb8);
arm64_l_b98:
	/* 0xb98: ldr x8, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_b9c:
	/* 0xb9c: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_ba0:
	/* 0xba0: cmp x9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_ba4:
	/* 0xba4: b.eq 304 <generic_retkprobe_event+0x304> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xba4, 0x304, arm64_l_304);
arm64_l_ba8:
	/* 0xba8: ldr x8, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_bac:
	/* 0xbac: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_bb0:
	/* 0xbb0: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_bb4:
	/* 0xbb4: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_bb8:
	/* 0xbb8: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_bbc:
	/* 0xbbc: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_bc0:
	/* 0xbc0: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_bc4:
	/* 0xbc4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xbc8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_bc8:
	/* 0xbc8: tbnz w0, #31, f28 <generic_retkprobe_event+0xf28> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0xbc8, 0xf28, arm64_l_f28);
arm64_l_bcc:
	/* 0xbcc: ldr x8, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_bd0:
	/* 0xbd0: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_bd4:
	/* 0xbd4: csel x23, x8, x21, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X23, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_bd8:
	/* 0xbd8: cmp x21, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_bdc:
	/* 0xbdc: csel x24, x8, x23, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X24, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_EQ, 0);
arm64_l_be0:
	/* 0xbe0: cmp x24, #0xffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4094ULL);
arm64_l_be4:
	/* 0xbe4: b.ls eec <generic_retkprobe_event+0xeec> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0xbe4, 0xeec, arm64_l_eec);
arm64_l_be8:
	/* 0xbe8: mov w8, #0xfffffffd */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967293ULL);
arm64_l_bec:
	/* 0xbec: b f2c <generic_retkprobe_event+0xf2c> */
	ARM64_SIM_A64_JMP(0xbec, 0xf2c, arm64_l_f2c);
arm64_l_bf0:
	/* 0xbf0: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_bf4:
	/* 0xbf4: mov x19, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_bf8:
	/* 0xbf8: strb w8, [sp, #212] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 212ULL);
arm64_l_bfc:
	/* 0xbfc: ldr x9, [sp, #200] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_c00:
	/* 0xc00: ldr x2, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_c04:
	/* 0xc04: cmp x9, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X9, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_c08:
	/* 0xc08: b.ne af4 <generic_retkprobe_event+0xaf4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xc08, 0xaf4, arm64_l_af4);
arm64_l_c0c:
	/* 0xc0c: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_c10:
	/* 0xc10: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_c14:
	/* 0xc14: mov w23, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_c18:
	/* 0xc18: mov w10, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_c1c:
	/* 0xc1c: add x0, x8, #0xa0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 160ULL);
arm64_l_c20:
	/* 0xc20: and w22, w10, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_c24:
	/* 0xc24: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_c28:
	/* 0xc28: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_c2c:
	/* 0xc2c: mov x21, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c30:
	/* 0xc30: mov w1, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_c34:
	/* 0xc34: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xc38ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_c38:
	/* 0xc38: str w22, [x21, #156] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 156ULL);
arm64_l_c3c:
	/* 0xc3c: ldr x2, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_c40:
	/* 0xc40: mov w21, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_c44:
	/* 0xc44: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_c48:
	/* 0xc48: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_c4c:
	/* 0xc4c: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_c50:
	/* 0xc50: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_c54:
	/* 0xc54: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xc58ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_c58:
	/* 0xc58: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_c5c:
	/* 0xc5c: add x9, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_c60:
	/* 0xc60: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_c64:
	/* 0xc64: add x0, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_c68:
	/* 0xc68: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_c6c:
	/* 0xc6c: add x8, x8, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_c70:
	/* 0xc70: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_c74:
	/* 0xc74: add x2, x8, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_c78:
	/* 0xc78: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xc7cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_c7c:
	/* 0xc7c: ldr x8, [x25, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_c80:
	/* 0xc80: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_c84:
	/* 0xc84: add x10, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_c88:
	/* 0xc88: add x0, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_c8c:
	/* 0xc8c: ldr x2, [x25, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_c90:
	/* 0xc90: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_c94:
	/* 0xc94: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xc98ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_c98:
	/* 0xc98: ldr x8, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_c9c:
	/* 0xc9c: add w25, w22, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_ca0:
	/* 0xca0: add x8, x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_ca4:
	/* 0xca4: str w23, [x8, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_ca8:
	/* 0xca8: ldrh w9, [sp, #248] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 248ULL);
arm64_l_cac:
	/* 0xcac: strh w9, [x8, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_cb0:
	/* 0xcb0: ldr w21, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_cb4:
	/* 0xcb4: mov w23, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_cb8:
	/* 0xcb8: tbnz w25, #31, cdc <generic_retkprobe_event+0xcdc> */
	ARM64_SIM_A64_TBNZ(ARM64_X25, 31, 0xcb8, 0xcdc, arm64_l_cdc);
arm64_l_cbc:
	/* 0xcbc: and x8, x25, #0x7fffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2147483647ULL);
arm64_l_cc0:
	/* 0xcc0: mov w22, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_cc4:
	/* 0xcc4: add x8, x8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_cc8:
	/* 0xcc8: add x21, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_ccc:
	/* 0xccc: ldr w8, [x29, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_cd0:
	/* 0xcd0: cmp w8, #0xb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 11ULL);
arm64_l_cd4:
	/* 0xcd4: b.ne 150 <generic_retkprobe_event+0x150> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xcd4, 0x150, arm64_l_150);
arm64_l_cd8:
	/* 0xcd8: b 274 <generic_retkprobe_event+0x274> */
	ARM64_SIM_A64_JMP(0xcd8, 0x274, arm64_l_274);
arm64_l_cdc:
	/* 0xcdc: ldr x9, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_ce0:
	/* 0xce0: mov w8, #0xffffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967295ULL);
arm64_l_ce4:
	/* 0xce4: mov w22, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_ce8:
	/* 0xce8: str w8, [x9, x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X23, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_cec:
	/* 0xcec: str w8, [x9, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_cf0:
	/* 0xcf0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_cf4:
	/* 0xcf4: add x21, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_cf8:
	/* 0xcf8: ldr w8, [x29, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_cfc:
	/* 0xcfc: cmp w8, #0xb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 11ULL);
arm64_l_d00:
	/* 0xd00: b.ne 150 <generic_retkprobe_event+0x150> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xd00, 0x150, arm64_l_150);
arm64_l_d04:
	/* 0xd04: b 274 <generic_retkprobe_event+0x274> */
	ARM64_SIM_A64_JMP(0xd04, 0x274, arm64_l_274);
arm64_l_d08:
	/* 0xd08: cmp w22, #0x9; 0xd0c: b.gt e3c <generic_retkprobe_event+0xe3c> */
arm64_l_d0c:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL, arm64_l_e3c);
arm64_l_d10:
	/* 0xd10: cmp w22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_d14:
	/* 0xd14: b.le 1040 <generic_retkprobe_event+0x1040> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xd14, 0x1040, arm64_l_1040);
arm64_l_d18:
	/* 0xd18: cmp w22, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_d1c:
	/* 0xd1c: b.eq 1478 <generic_retkprobe_event+0x1478> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd1c, 0x1478, arm64_l_1478);
arm64_l_d20:
	/* 0xd20: cmp w22, #0x6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_d24:
	/* 0xd24: b.eq ea4 <generic_retkprobe_event+0xea4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd24, 0xea4, arm64_l_ea4);
arm64_l_d28:
	/* 0xd28: cmp w22, #0x7 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_d2c:
	/* 0xd2c: b.ne cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xd2c, 0xcb8, arm64_l_cb8);
arm64_l_d30:
	/* 0xd30: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_d34:
	/* 0xd34: ldr x25, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_d38:
	/* 0xd38: str w21, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_d3c:
	/* 0xd3c: mov x24, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d40:
	/* 0xd40: mov w21, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_d44:
	/* 0xd44: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_d48:
	/* 0xd48: ldr x23, [x8, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_d4c:
	/* 0xd4c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_d50:
	/* 0xd50: mov w22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_d54:
	/* 0xd54: stur x23, [x25, #196] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 196ULL);
arm64_l_d58:
	/* 0xd58: add x0, x25, #0xc2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 194ULL);
arm64_l_d5c:
	/* 0xd5c: add x2, x23, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_d60:
	/* 0xd60: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xd64ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d64:
	/* 0xd64: add x0, x25, #0xd6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 214ULL);
arm64_l_d68:
	/* 0xd68: add x2, x23, #0x12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_d6c:
	/* 0xd6c: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d70:
	/* 0xd70: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_d74:
	/* 0xd74: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_d78:
	/* 0xd78: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xd7cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d7c:
	/* 0xd7c: add x0, x25, #0xd4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 212ULL);
arm64_l_d80:
	/* 0xd80: add x2, x23, #0x21e */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 542ULL);
arm64_l_d84:
	/* 0xd84: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_d88:
	/* 0xd88: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_d8c:
	/* 0xd8c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xd90ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d90:
	/* 0xd90: add x0, x25, #0xc0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_d94:
	/* 0xd94: add x2, x23, #0x21c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 540ULL);
arm64_l_d98:
	/* 0xd98: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_d9c:
	/* 0xd9c: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_da0:
	/* 0xda0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xda4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_da4:
	/* 0xda4: add x0, x25, #0xcc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 204ULL);
arm64_l_da8:
	/* 0xda8: add x2, x23, #0x214 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 532ULL);
arm64_l_dac:
	/* 0xdac: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_db0:
	/* 0xdb0: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_db4:
	/* 0xdb4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xdb8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_db8:
	/* 0xdb8: add x0, x25, #0xd0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 208ULL);
arm64_l_dbc:
	/* 0xdbc: add x2, x23, #0x210 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 528ULL);
arm64_l_dc0:
	/* 0xdc0: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_dc4:
	/* 0xdc4: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xdc8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_dc8:
	/* 0xdc8: ldrh w8, [x25, #194] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 194ULL);
arm64_l_dcc:
	/* 0xdcc: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_dd0:
	/* 0xdd0: add x22, x25, #0xac */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_dd4:
	/* 0xdd4: cmp w8, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_dd8:
	/* 0xdd8: stp xzr, xzr, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ddc:
	/* 0xddc: stp xzr, xzr, [x0, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_de0:
	/* 0xde0: b.eq 1cb8 <generic_retkprobe_event+0x1cb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xde0, 0x1cb8, arm64_l_1cb8);
arm64_l_de4:
	/* 0xde4: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_de8:
	/* 0xde8: b.ne 1ce0 <generic_retkprobe_event+0x1ce0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xde8, 0x1ce0, arm64_l_1ce0);
arm64_l_dec:
	/* 0xdec: add x2, x23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_df0:
	/* 0xdf0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_df4:
	/* 0xdf4: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_df8:
	/* 0xdf8: mov w21, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_dfc:
	/* 0xdfc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xe00ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_e00:
	/* 0xe00: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e04:
	/* 0xe04: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_e08:
	/* 0xe08: mov x2, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e0c:
	/* 0xe0c: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xe10ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_e10:
	/* 0xe10: b 1ce0 <generic_retkprobe_event+0x1ce0> */
	ARM64_SIM_A64_JMP(0xe10, 0x1ce0, arm64_l_1ce0);
arm64_l_e14:
	/* 0xe14: cmp w22, #0x1c; 0xe18: b.gt 101c <generic_retkprobe_event+0x101c> */
arm64_l_e18:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 28ULL, arm64_l_101c);
arm64_l_e1c:
	/* 0xe1c: cmp w22, #0x11 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_e20:
	/* 0xe20: b.eq 1310 <generic_retkprobe_event+0x1310> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe20, 0x1310, arm64_l_1310);
arm64_l_e24:
	/* 0xe24: cmp w22, #0x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_e28:
	/* 0xe28: b.eq 13cc <generic_retkprobe_event+0x13cc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe28, 0x13cc, arm64_l_13cc);
arm64_l_e2c:
	/* 0xe2c: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_e30:
	/* 0xe30: cmp w22, #0x1c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_e34:
	/* 0xe34: b.eq 1054 <generic_retkprobe_event+0x1054> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe34, 0x1054, arm64_l_1054);
arm64_l_e38:
	/* 0xe38: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0xe38, 0xcb8, arm64_l_cb8);
arm64_l_e3c:
	/* 0xe3c: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_e40:
	/* 0xe40: sub w8, w22, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_e44:
	/* 0xe44: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_e48:
	/* 0xe48: b.cc 1054 <generic_retkprobe_event+0x1054> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xe48, 0x1054, arm64_l_1054);
arm64_l_e4c:
	/* 0xe4c: sub w8, w22, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_e50:
	/* 0xe50: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_e54:
	/* 0xe54: b.cc 106c <generic_retkprobe_event+0x106c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xe54, 0x106c, arm64_l_106c);
arm64_l_e58:
	/* 0xe58: cmp w22, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 14ULL);
arm64_l_e5c:
	/* 0xe5c: b.ne cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xe5c, 0xcb8, arm64_l_cb8);
arm64_l_e60:
	/* 0xe60: mov w24, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_e64:
	/* 0xe64: mov w21, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_e68:
	/* 0xe68: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_e6c:
	/* 0xe6c: add x23, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_e70:
	/* 0xe70: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_e74:
	/* 0xe74: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_e78:
	/* 0xe78: add x2, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_e7c:
	/* 0xe7c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_e80:
	/* 0xe80: mov w22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_e84:
	/* 0xe84: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xe88ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_e88:
	/* 0xe88: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_e8c:
	/* 0xe8c: add x0, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_e90:
	/* 0xe90: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_e94:
	/* 0xe94: mov w23, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_e98:
	/* 0xe98: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_e9c:
	/* 0xe9c: mov w21, w24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_ea0:
	/* 0xea0: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xea4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_ea4:
	/* 0xea4: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_ea8:
	/* 0xea8: mov w9, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_eac:
	/* 0xeac: mov w1, #0x1001 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4097ULL);
arm64_l_eb0:
	/* 0xeb0: ldr x2, [x8, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_eb4:
	/* 0xeb4: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_eb8:
	/* 0xeb8: add x0, x8, #0xa0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 160ULL);
arm64_l_ebc:
	/* 0xebc: mov w8, #0x1001 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4097ULL);
arm64_l_ec0:
	/* 0xec0: b 15f8 <generic_retkprobe_event+0x15f8> */
	ARM64_SIM_A64_JMP(0xec0, 0x15f8, arm64_l_15f8);
arm64_l_ec4:
	/* 0xec4: cmp w22, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_ec8:
	/* 0xec8: b.le 119c <generic_retkprobe_event+0x119c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xec8, 0x119c, arm64_l_119c);
arm64_l_ecc:
	/* 0xecc: sub w8, w22, #0x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_ed0:
	/* 0xed0: cmp w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_ed4:
	/* 0xed4: b.cs 1088 <generic_retkprobe_event+0x1088> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xed4, 0x1088, arm64_l_1088);
arm64_l_ed8:
	/* 0xed8: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_edc:
	/* 0xedc: mov w25, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_ee0:
	/* 0xee0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_ee4:
	/* 0xee4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_ee8:
	/* 0xee8: b 1228 <generic_retkprobe_event+0x1228> */
	ARM64_SIM_A64_JMP(0xee8, 0x1228, arm64_l_1228);
arm64_l_eec:
	/* 0xeec: ldr x8, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_ef0:
	/* 0xef0: add x22, x29, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X29, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_ef4:
	/* 0xef4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_ef8:
	/* 0xef8: mov w1, w24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_efc:
	/* 0xefc: add x0, x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_f00:
	/* 0xf00: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_f04:
	/* 0xf04: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_f08:
	/* 0xf08: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xf0cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_f0c:
	/* 0xf0c: tbnz w0, #31, f28 <generic_retkprobe_event+0xf28> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0xf0c, 0xf28, arm64_l_f28);
arm64_l_f10:
	/* 0xf10: add x29, x24, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X29, ARM64_X24, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_f14:
	/* 0xf14: cbz x21, 169c <generic_retkprobe_event+0x169c> */
	ARM64_SIM_A64_CBZ(ARM64_X21, 0xf14, 0x169c, arm64_l_169c);
arm64_l_f18:
	/* 0xf18: ldr x8, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_f1c:
	/* 0xf1c: subs x21, x21, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X21, ARM64_X21, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f20:
	/* 0xf20: b.ne 16a0 <generic_retkprobe_event+0x16a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xf20, 0x16a0, arm64_l_16a0);
arm64_l_f24:
	/* 0xf24: b 304 <generic_retkprobe_event+0x304> */
	ARM64_SIM_A64_JMP(0xf24, 0x304, arm64_l_304);
arm64_l_f28:
	/* 0xf28: mov w8, #0xfffffffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967294ULL);
arm64_l_f2c:
	/* 0xf2c: ldr x9, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_f30:
	/* 0xf30: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_f34:
	/* 0xf34: b 38c <generic_retkprobe_event+0x38c> */
	ARM64_SIM_A64_JMP(0xf34, 0x38c, arm64_l_38c);
arm64_l_f38:
	/* 0xf38: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_f3c:
	/* 0xf3c: cmp w22, #0x27 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 39ULL);
arm64_l_f40:
	/* 0xf40: b.eq 15d8 <generic_retkprobe_event+0x15d8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf40, 0x15d8, arm64_l_15d8);
arm64_l_f44:
	/* 0xf44: cmp w22, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_f48:
	/* 0xf48: b.eq 1618 <generic_retkprobe_event+0x1618> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf48, 0x1618, arm64_l_1618);
arm64_l_f4c:
	/* 0xf4c: cmp w22, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_f50:
	/* 0xf50: b.ne cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xf50, 0xcb8, arm64_l_cb8);
arm64_l_f54:
	/* 0xf54: add x10, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_f58:
	/* 0xf58: strb wzr, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_f5c:
	/* 0xf5c: stp xzr, xzr, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f60:
	/* 0xf60: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_f64:
	/* 0xf64: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_f68:
	/* 0xf68: ldr x22, [x10, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_f6c:
	/* 0xf6c: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_f70:
	/* 0xf70: mov w24, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_f74:
	/* 0xf74: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f78:
	/* 0xf78: stp xzr, xzr, [x0, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_f7c:
	/* 0xf7c: stp xzr, xzr, [x0, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_f80:
	/* 0xf80: stp xzr, xzr, [x0, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_f84:
	/* 0xf84: stp xzr, xzr, [x0, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_f88:
	/* 0xf88: stp xzr, xzr, [x0, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_f8c:
	/* 0xf8c: stp xzr, xzr, [x0, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_f90:
	/* 0xf90: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xf94ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_f94:
	/* 0xf94: tbnz x0, #63, 1e60 <generic_retkprobe_event+0x1e60> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0xf94, 0x1e60, arm64_l_1e60);
arm64_l_f98:
	/* 0xf98: add x23, x22, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_f9c:
	/* 0xf9c: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_fa0:
	/* 0xfa0: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_fa4:
	/* 0xfa4: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_fa8:
	/* 0xfa8: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_fac:
	/* 0xfac: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_fb0:
	/* 0xfb0: mov x2, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_fb4:
	/* 0xfb4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xfb8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_fb8:
	/* 0xfb8: tbnz x0, #63, 1e60 <generic_retkprobe_event+0x1e60> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0xfb8, 0x1e60, arm64_l_1e60);
arm64_l_fbc:
	/* 0xfbc: ldrb w8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_fc0:
	/* 0xfc0: ldr x10, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_fc4:
	/* 0xfc4: cmp w8, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_fc8:
	/* 0xfc8: add x0, x10, #0xa0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 160ULL);
arm64_l_fcc:
	/* 0xfcc: cset w9, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_fd0:
	/* 0xfd0: strb w9, [x10, #158] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 158ULL);
arm64_l_fd4:
	/* 0xfd4: cbz w8, 1e40 <generic_retkprobe_event+0x1e40> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0xfd4, 0x1e40, arm64_l_1e40);
arm64_l_fd8:
	/* 0xfd8: mov w8, #0x6c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 108ULL);
arm64_l_fdc:
	/* 0xfdc: mov w9, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_fe0:
	/* 0xfe0: mov w1, #0x6c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 108ULL);
arm64_l_fe4:
	/* 0xfe4: mov x2, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_fe8:
	/* 0xfe8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0xfecULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_fec:
	/* 0xfec: tbnz w0, #31, 1e60 <generic_retkprobe_event+0x1e60> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0xfec, 0x1e60, arm64_l_1e60);
arm64_l_ff0:
	/* 0xff0: sub w21, w0, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_ff4:
	/* 0xff4: b 1e58 <generic_retkprobe_event+0x1e58> */
	ARM64_SIM_A64_JMP(0xff4, 0x1e58, arm64_l_1e58);
arm64_l_ff8:
	/* 0xff8: cmp w22, #0x7; 0xffc: b.gt 1208 <generic_retkprobe_event+0x1208> */
arm64_l_ffc:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL, arm64_l_1208);
arm64_l_1000:
	/* 0x1000: cmp w22, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1004:
	/* 0x1004: b.eq 16fc <generic_retkprobe_event+0x16fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1004, 0x16fc, arm64_l_16fc);
arm64_l_1008:
	/* 0x1008: cmp w22, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_100c:
	/* 0x100c: b.ne cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x100c, 0xcb8, arm64_l_cb8);
arm64_l_1010:
	/* 0x1010: stur xzr, [x0, #156] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 156ULL);
arm64_l_1014:
	/* 0x1014: mov w25, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1018:
	/* 0x1018: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0x1018, 0xcb8, arm64_l_cb8);
arm64_l_101c:
	/* 0x101c: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1020:
	/* 0x1020: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1024:
	/* 0x1024: add x9, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_1028:
	/* 0x1028: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_102c:
	/* 0x102c: add x2, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_1030:
	/* 0x1030: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1034:
	/* 0x1034: mov w25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1038:
	/* 0x1038: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x103cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_103c:
	/* 0x103c: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0x103c, 0xcb8, arm64_l_cb8);
arm64_l_1040:
	/* 0x1040: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1044:
	/* 0x1044: cmp w22, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1048:
	/* 0x1048: b.eq 106c <generic_retkprobe_event+0x106c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1048, 0x106c, arm64_l_106c);
arm64_l_104c:
	/* 0x104c: cmp w22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1050:
	/* 0x1050: b.ne cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1050, 0xcb8, arm64_l_cb8);
arm64_l_1054:
	/* 0x1054: mov w25, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1058:
	/* 0x1058: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_105c:
	/* 0x105c: add x9, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_1060:
	/* 0x1060: add x2, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_1064:
	/* 0x1064: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1068:
	/* 0x1068: b 122c <generic_retkprobe_event+0x122c> */
	ARM64_SIM_A64_JMP(0x1068, 0x122c, arm64_l_122c);
arm64_l_106c:
	/* 0x106c: add x8, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_1070:
	/* 0x1070: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1074:
	/* 0x1074: add x2, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_1078:
	/* 0x1078: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_107c:
	/* 0x107c: mov w25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1080:
	/* 0x1080: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1084ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1084:
	/* 0x1084: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0x1084, 0xcb8, arm64_l_cb8);
arm64_l_1088:
	/* 0x1088: cmp w22, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_108c:
	/* 0x108c: b.eq 1a2c <generic_retkprobe_event+0x1a2c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x108c, 0x1a2c, arm64_l_1a2c);
arm64_l_1090:
	/* 0x1090: cmp w22, #0x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1094:
	/* 0x1094: b.ne cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1094, 0xcb8, arm64_l_cb8);
arm64_l_1098:
	/* 0x1098: str w21, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_109c:
	/* 0x109c: add x2, x24, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_10a0:
	/* 0x10a0: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_10a4:
	/* 0x10a4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_10a8:
	/* 0x10a8: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_10ac:
	/* 0x10ac: mov x25, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10b0:
	/* 0x10b0: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_10b4:
	/* 0x10b4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_10b8:
	/* 0x10b8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x10bcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_10bc:
	/* 0x10bc: ldr x23, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_10c0:
	/* 0x10c0: cbz x23, 1edc <generic_retkprobe_event+0x1edc> */
	ARM64_SIM_A64_CBZ(ARM64_X23, 0x10c0, 0x1edc, arm64_l_1edc);
arm64_l_10c4:
	/* 0x10c4: ldr x24, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_10c8:
	/* 0x10c8: add x2, x23, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_10cc:
	/* 0x10cc: mov w21, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_10d0:
	/* 0x10d0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_10d4:
	/* 0x10d4: stur x23, [x24, #196] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 196ULL);
arm64_l_10d8:
	/* 0x10d8: add x0, x24, #0xc2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 194ULL);
arm64_l_10dc:
	/* 0x10dc: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_10e0:
	/* 0x10e0: mov w22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_10e4:
	/* 0x10e4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x10e8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_10e8:
	/* 0x10e8: add x0, x24, #0xd6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 214ULL);
arm64_l_10ec:
	/* 0x10ec: add x2, x23, #0x12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_10f0:
	/* 0x10f0: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_10f4:
	/* 0x10f4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_10f8:
	/* 0x10f8: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_10fc:
	/* 0x10fc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1100ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1100:
	/* 0x1100: add x0, x24, #0xd4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 212ULL);
arm64_l_1104:
	/* 0x1104: add x2, x23, #0x21e */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 542ULL);
arm64_l_1108:
	/* 0x1108: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_110c:
	/* 0x110c: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1110:
	/* 0x1110: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1114ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1114:
	/* 0x1114: add x0, x24, #0xc0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 192ULL);
arm64_l_1118:
	/* 0x1118: add x2, x23, #0x21c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 540ULL);
arm64_l_111c:
	/* 0x111c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1120:
	/* 0x1120: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1124:
	/* 0x1124: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1128ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1128:
	/* 0x1128: add x0, x24, #0xcc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 204ULL);
arm64_l_112c:
	/* 0x112c: add x2, x23, #0x214 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 532ULL);
arm64_l_1130:
	/* 0x1130: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1134:
	/* 0x1134: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1138:
	/* 0x1138: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x113cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_113c:
	/* 0x113c: add x0, x24, #0xd0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 208ULL);
arm64_l_1140:
	/* 0x1140: add x2, x23, #0x210 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 528ULL);
arm64_l_1144:
	/* 0x1144: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1148:
	/* 0x1148: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x114cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_114c:
	/* 0x114c: ldr x8, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1150:
	/* 0x1150: add x22, x24, #0xac */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1154:
	/* 0x1154: stp xzr, xzr, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X8, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1158:
	/* 0x1158: stp xzr, xzr, [x8, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X8, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_115c:
	/* 0x115c: ldrh w8, [x24, #194] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 194ULL);
arm64_l_1160:
	/* 0x1160: cmp w8, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1164:
	/* 0x1164: b.eq 1e6c <generic_retkprobe_event+0x1e6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1164, 0x1e6c, arm64_l_1e6c);
arm64_l_1168:
	/* 0x1168: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_116c:
	/* 0x116c: b.ne 1e98 <generic_retkprobe_event+0x1e98> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x116c, 0x1e98, arm64_l_1e98);
arm64_l_1170:
	/* 0x1170: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1174:
	/* 0x1174: add x2, x23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1178:
	/* 0x1178: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_117c:
	/* 0x117c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1180:
	/* 0x1180: mov w21, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1184:
	/* 0x1184: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1188ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1188:
	/* 0x1188: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_118c:
	/* 0x118c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1190:
	/* 0x1190: mov x2, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1194:
	/* 0x1194: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1198ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1198:
	/* 0x1198: b 1e98 <generic_retkprobe_event+0x1e98> */
	ARM64_SIM_A64_JMP(0x1198, 0x1e98, arm64_l_1e98);
arm64_l_119c:
	/* 0x119c: cmp w22, #0x1a */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_11a0:
	/* 0x11a0: b.eq 1ac4 <generic_retkprobe_event+0x1ac4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x11a0, 0x1ac4, arm64_l_1ac4);
arm64_l_11a4:
	/* 0x11a4: cmp w22, #0x1b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_11a8:
	/* 0x11a8: b.ne cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x11a8, 0xcb8, arm64_l_cb8);
arm64_l_11ac:
	/* 0x11ac: ldr x9, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_11b0:
	/* 0x11b0: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_11b4:
	/* 0x11b4: add x2, x24, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_11b8:
	/* 0x11b8: mov w1, #0x3f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 63ULL);
arm64_l_11bc:
	/* 0x11bc: add x0, x8, #0xac */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_11c0:
	/* 0x11c0: stp xzr, xzr, [x9, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X9, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_11c4:
	/* 0x11c4: stp xzr, xzr, [x9, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X9, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_11c8:
	/* 0x11c8: stp xzr, xzr, [x9, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X9, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_11cc:
	/* 0x11cc: mov w8, #0x3f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 63ULL);
arm64_l_11d0:
	/* 0x11d0: stp xzr, xzr, [x9, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X9, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_11d4:
	/* 0x11d4: stp xzr, xzr, [x9] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X9, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_11d8:
	/* 0x11d8: mov w9, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_11dc:
	/* 0x11dc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0x11e0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_11e0:
	/* 0x11e0: tbnz x0, #63, 1df0 <generic_retkprobe_event+0x1df0> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x11e0, 0x1df0, arm64_l_1df0);
arm64_l_11e4:
	/* 0x11e4: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_11e8:
	/* 0x11e8: add x2, x24, #0x360 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 864ULL);
arm64_l_11ec:
	/* 0x11ec: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_11f0:
	/* 0x11f0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_11f4:
	/* 0x11f4: add x0, x8, #0xa4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 164ULL);
arm64_l_11f8:
	/* 0x11f8: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_11fc:
	/* 0x11fc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1200ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1200:
	/* 0x1200: mov w25, #0x50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 80ULL);
arm64_l_1204:
	/* 0x1204: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0x1204, 0xcb8, arm64_l_cb8);
arm64_l_1208:
	/* 0x1208: cmp w22, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_120c:
	/* 0x120c: b.eq 1770 <generic_retkprobe_event+0x1770> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x120c, 0x1770, arm64_l_1770);
arm64_l_1210:
	/* 0x1210: cmp w22, #0x12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_1214:
	/* 0x1214: b.ne cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1214, 0xcb8, arm64_l_cb8);
arm64_l_1218:
	/* 0x1218: mov x25, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_121c:
	/* 0x121c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1220:
	/* 0x1220: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1224:
	/* 0x1224: mov w1, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1228:
	/* 0x1228: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_122c:
	/* 0x122c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1230ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1230:
	/* 0x1230: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0x1230, 0xcb8, arm64_l_cb8);
arm64_l_1234:
	/* 0x1234: cmp w22, #0x13 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 19ULL);
arm64_l_1238:
	/* 0x1238: b.eq 19e8 <generic_retkprobe_event+0x19e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1238, 0x19e8, arm64_l_19e8);
arm64_l_123c:
	/* 0x123c: cmp w22, #0x14 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_1240:
	/* 0x1240: b.ne cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1240, 0xcb8, arm64_l_cb8);
arm64_l_1244:
	/* 0x1244: str xzr, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1248:
	/* 0x1248: add x2, x24, #0x110 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 272ULL);
arm64_l_124c:
	/* 0x124c: mov w10, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1250:
	/* 0x1250: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1254:
	/* 0x1254: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1258:
	/* 0x1258: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_125c:
	/* 0x125c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1260:
	/* 0x1260: add x22, x24, #0xd8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_1264:
	/* 0x1264: mov w23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1268:
	/* 0x1268: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x126cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_126c:
	/* 0x126c: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1270:
	/* 0x1270: mov w9, #0x80 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 128ULL);
arm64_l_1274:
	/* 0x1274: mov w10, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_1278:
	/* 0x1278: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_127c:
	/* 0x127c: mov w1, #0x80 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 128ULL);
arm64_l_1280:
	/* 0x1280: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1284:
	/* 0x1284: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0x1288ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1288:
	/* 0x1288: mov w25, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_128c:
	/* 0x128c: ldr x21, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1290:
	/* 0x1290: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1294:
	/* 0x1294: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1298:
	/* 0x1298: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_129c:
	/* 0x129c: add x0, x21, #0x12c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 300ULL);
arm64_l_12a0:
	/* 0x12a0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x12a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_12a4:
	/* 0x12a4: add x0, x21, #0x11c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 284ULL);
arm64_l_12a8:
	/* 0x12a8: add x2, x24, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_12ac:
	/* 0x12ac: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_12b0:
	/* 0x12b0: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_12b4:
	/* 0x12b4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_12b8:
	/* 0x12b8: mov w22, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_12bc:
	/* 0x12bc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x12c0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_12c0:
	/* 0x12c0: add x0, x21, #0x124 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 292ULL);
arm64_l_12c4:
	/* 0x12c4: add x2, x24, #0x118 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 280ULL);
arm64_l_12c8:
	/* 0x12c8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_12cc:
	/* 0x12cc: mov w21, w25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_12d0:
	/* 0x12d0: blr x23 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X23);
		if (ARM64_SIM_L_REG_TAG(ARM64_X23) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x12d4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_12d4:
	/* 0x12d4: mov w23, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_12d8:
	/* 0x12d8: mov w25, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 152ULL);
arm64_l_12dc:
	/* 0x12dc: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0x12dc, 0xcb8, arm64_l_cb8);
arm64_l_12e0:
	/* 0x12e0: cmp w22, #0x26 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 38ULL);
arm64_l_12e4:
	/* 0x12e4: b.ne cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x12e4, 0xcb8, arm64_l_cb8);
arm64_l_12e8:
	/* 0x12e8: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_12ec:
	/* 0x12ec: ldr x8, [x8, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_12f0:
	/* 0x12f0: add x2, x19, w8, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_12f4:
	/* 0x12f4: ubfx w9, w8, #16, #12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_BITFIELD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFX, 16, 12), 0);
arm64_l_12f8:
	/* 0x12f8: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_12fc:
	/* 0x12fc: add w1, w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1300:
	/* 0x1300: add x0, x8, #0xa0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 160ULL);
arm64_l_1304:
	/* 0x1304: mov w8, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_1308:
	/* 0x1308: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0x130cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_130c:
	/* 0x130c: b 15fc <generic_retkprobe_event+0x15fc> */
	ARM64_SIM_A64_JMP(0x130c, 0x15fc, arm64_l_15fc);
arm64_l_1310:
	/* 0x1310: stp xzr, xzr, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1314:
	/* 0x1314: mov w8, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_1318:
	/* 0x1318: mov w24, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_131c:
	/* 0x131c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x1320ULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1320:
	/* 0x1320: lsr x8, x0, #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 32ULL);
arm64_l_1324:
	/* 0x1324: add x9, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1328:
	/* 0x1328: add x10, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_132c:
	/* 0x132c: str x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1330:
	/* 0x1330: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1334:
	/* 0x1334: add x0, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1338:
	/* 0x1338: add x2, sp, #0xf8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 248ULL);
arm64_l_133c:
	/* 0x133c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1340:
	/* 0x1340: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1344ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1344:
	/* 0x1344: ldr w8, [sp, #232] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_1348:
	/* 0x1348: adrp x0, 0 <fdinstall_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&fdinstall_map_5));
arm64_l_134c:
	/* 0x134c: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1350:
	/* 0x1350: add x1, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1354:
	/* 0x1354: str w8, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_1358:
	/* 0x1358: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_135c:
	/* 0x135c: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1360:
	/* 0x1360: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1364ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1364:
	/* 0x1364: cbz x0, 1ba4 <generic_retkprobe_event+0x1ba4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1364, 0x1ba4, arm64_l_1ba4);
arm64_l_1368:
	/* 0x1368: ldr x25, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_136c:
	/* 0x136c: ldr w21, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1370:
	/* 0x1370: add x8, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1374:
	/* 0x1374: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1378:
	/* 0x1378: add x2, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_137c:
	/* 0x137c: mov x22, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1380:
	/* 0x1380: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1384:
	/* 0x1384: mov w23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1388:
	/* 0x1388: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_138c:
	/* 0x138c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1390ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1390:
	/* 0x1390: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1394:
	/* 0x1394: and x21, x21, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1398:
	/* 0x1398: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_139c:
	/* 0x139c: add x1, x21, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_13a0:
	/* 0x13a0: add x0, x8, #0xa0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 160ULL);
arm64_l_13a4:
	/* 0x13a4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_13a8:
	/* 0x13a8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x13acULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_13ac:
	/* 0x13ac: add w21, w21, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_13b0:
	/* 0x13b0: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_13b4:
	/* 0x13b4: add x8, x21, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X21, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_13b8:
	/* 0x13b8: add x0, x25, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_13bc:
	/* 0x13bc: sub x2, x8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_13c0:
	/* 0x13c0: blr x23 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X23);
		if (ARM64_SIM_L_REG_TAG(ARM64_X23) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x13c4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_13c4:
	/* 0x13c4: add x25, x21, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_13c8:
	/* 0x13c8: b 1e64 <generic_retkprobe_event+0x1e64> */
	ARM64_SIM_A64_JMP(0x13c8, 0x1e64, arm64_l_1e64);
arm64_l_13cc:
	/* 0x13cc: add x25, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_13d0:
	/* 0x13d0: str w21, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_13d4:
	/* 0x13d4: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_13d8:
	/* 0x13d8: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_13dc:
	/* 0x13dc: ldr x22, [x25, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_13e0:
	/* 0x13e0: add x10, sp, #0xd8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_13e4:
	/* 0x13e4: mov x23, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_13e8:
	/* 0x13e8: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_13ec:
	/* 0x13ec: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_13f0:
	/* 0x13f0: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_13f4:
	/* 0x13f4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x13f8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_13f8:
	/* 0x13f8: ldrb w8, [sp, #216] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_13fc:
	/* 0x13fc: cbz w8, 1bac <generic_retkprobe_event+0x1bac> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x13fc, 0x1bac, arm64_l_1bac);
arm64_l_1400:
	/* 0x1400: cmp w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1404:
	/* 0x1404: b.ne 1d70 <generic_retkprobe_event+0x1d70> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1404, 0x1d70, arm64_l_1d70);
arm64_l_1408:
	/* 0x1408: add x2, x22, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_140c:
	/* 0x140c: mov w21, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1410:
	/* 0x1410: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1414:
	/* 0x1414: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1418:
	/* 0x1418: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_141c:
	/* 0x141c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1420:
	/* 0x1420: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1424:
	/* 0x1424: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1428ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1428:
	/* 0x1428: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_142c:
	/* 0x142c: add x8, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1430:
	/* 0x1430: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1434:
	/* 0x1434: add x0, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1438:
	/* 0x1438: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_143c:
	/* 0x143c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1440ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1440:
	/* 0x1440: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1444:
	/* 0x1444: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1448:
	/* 0x1448: add x0, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_144c:
	/* 0x144c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1450:
	/* 0x1450: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1454:
	/* 0x1454: add x8, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_1458:
	/* 0x1458: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x145cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_145c:
	/* 0x145c: ldr x21, [sp, #112] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_1460:
	/* 0x1460: mov w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4095ULL);
arm64_l_1464:
	/* 0x1464: ldr x2, [x25, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1468:
	/* 0x1468: add x0, x23, #0xa4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 164ULL);
arm64_l_146c:
	/* 0x146c: cmp x21, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1470:
	/* 0x1470: csel x22, x21, x8, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X22, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_1474:
	/* 0x1474: b 1bfc <generic_retkprobe_event+0x1bfc> */
	ARM64_SIM_A64_JMP(0x1474, 0x1bfc, arm64_l_1bfc);
arm64_l_1478:
	/* 0x1478: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_147c:
	/* 0x147c: str w21, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1480:
	/* 0x1480: str x29, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1484:
	/* 0x1484: ldr x21, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1488:
	/* 0x1488: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_148c:
	/* 0x148c: mov w23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1490:
	/* 0x1490: ldr x29, [x8, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1494:
	/* 0x1494: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1498:
	/* 0x1498: add x0, x21, #0xc4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 196ULL);
arm64_l_149c:
	/* 0x149c: add x2, x29, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_14a0:
	/* 0x14a0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x14a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_14a4:
	/* 0x14a4: add x0, x21, #0xc8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_14a8:
	/* 0x14a8: add x2, x29, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_14ac:
	/* 0x14ac: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14b0:
	/* 0x14b0: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14b4:
	/* 0x14b4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x14b8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_14b8:
	/* 0x14b8: add x0, x21, #0xcc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 204ULL);
arm64_l_14bc:
	/* 0x14bc: add x2, x29, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_14c0:
	/* 0x14c0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14c4:
	/* 0x14c4: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14c8:
	/* 0x14c8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x14ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_14cc:
	/* 0x14cc: add x0, x21, #0xd0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 208ULL);
arm64_l_14d0:
	/* 0x14d0: add x2, x29, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_14d4:
	/* 0x14d4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14d8:
	/* 0x14d8: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14dc:
	/* 0x14dc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x14e0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_14e0:
	/* 0x14e0: str xzr, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_14e4:
	/* 0x14e4: add x2, x29, #0xc8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_14e8:
	/* 0x14e8: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_14ec:
	/* 0x14ec: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_14f0:
	/* 0x14f0: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14f4:
	/* 0x14f4: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_14f8:
	/* 0x14f8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_14fc:
	/* 0x14fc: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1500ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1500:
	/* 0x1500: add x2, x29, #0xb8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 184ULL);
arm64_l_1504:
	/* 0x1504: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1508:
	/* 0x1508: add x9, sp, #0xd8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_150c:
	/* 0x150c: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1510:
	/* 0x1510: add x0, sp, #0xd8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_1514:
	/* 0x1514: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1518:
	/* 0x1518: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x151cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_151c:
	/* 0x151c: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1520:
	/* 0x1520: ldrh w9, [sp, #216] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_1524:
	/* 0x1524: add x0, sp, #0x84 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 132ULL);
arm64_l_1528:
	/* 0x1528: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_152c:
	/* 0x152c: add x22, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1530:
	/* 0x1530: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1534:
	/* 0x1534: add x9, sp, #0x84 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 132ULL);
arm64_l_1538:
	/* 0x1538: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_153c:
	/* 0x153c: blr x23 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X23);
		if (ARM64_SIM_L_REG_TAG(ARM64_X23) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1540ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1540:
	/* 0x1540: ldrb w8, [sp, #132] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 132ULL);
arm64_l_1544:
	/* 0x1544: lsr w8, w8, #4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 4ULL);
arm64_l_1548:
	/* 0x1548: cmp w8, #0x6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_154c:
	/* 0x154c: b.eq 1c2c <generic_retkprobe_event+0x1c2c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x154c, 0x1c2c, arm64_l_1c2c);
arm64_l_1550:
	/* 0x1550: cmp w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1554:
	/* 0x1554: b.ne 2890 <generic_retkprobe_event+0x2890> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1554, 0x2890, arm64_l_2890);
arm64_l_1558:
	/* 0x1558: str x19, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_155c:
	/* 0x155c: add x2, x22, #0x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_1560:
	/* 0x1560: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1564:
	/* 0x1564: add x9, sp, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1568:
	/* 0x1568: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_156c:
	/* 0x156c: add x0, sp, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_1570:
	/* 0x1570: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1574:
	/* 0x1574: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1578:
	/* 0x1578: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x157cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_157c:
	/* 0x157c: ldrb w8, [sp, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_1580:
	/* 0x1580: ldr x9, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1584:
	/* 0x1584: mov w21, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1588:
	/* 0x1588: add x2, x22, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_158c:
	/* 0x158c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1590:
	/* 0x1590: add x23, x9, #0xac */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1594:
	/* 0x1594: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1598:
	/* 0x1598: strh w8, [x9, #192] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_159c:
	/* 0x159c: strh w21, [x9, #194] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 194ULL);
arm64_l_15a0:
	/* 0x15a0: stp xzr, xzr, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_15a4:
	/* 0x15a4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_15a8:
	/* 0x15a8: stp xzr, xzr, [x0, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_15ac:
	/* 0x15ac: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x15b0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_15b0:
	/* 0x15b0: add x2, x22, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_15b4:
	/* 0x15b4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_15b8:
	/* 0x15b8: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_15bc:
	/* 0x15bc: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_15c0:
	/* 0x15c0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x15c4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_15c4:
	/* 0x15c4: add x2, x29, #0xb6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 182ULL);
arm64_l_15c8:
	/* 0x15c8: add x8, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_15cc:
	/* 0x15cc: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_15d0:
	/* 0x15d0: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_15d4:
	/* 0x15d4: b 274c <generic_retkprobe_event+0x274c> */
	ARM64_SIM_A64_JMP(0x15d4, 0x274c, arm64_l_274c);
arm64_l_15d8:
	/* 0x15d8: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_15dc:
	/* 0x15dc: mov w9, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_15e0:
	/* 0x15e0: mov w1, #0x11 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 17ULL);
arm64_l_15e4:
	/* 0x15e4: ldr x8, [x8, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_15e8:
	/* 0x15e8: add x2, x8, #0x118 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 280ULL);
arm64_l_15ec:
	/* 0x15ec: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_15f0:
	/* 0x15f0: add x0, x8, #0xa0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 160ULL);
arm64_l_15f4:
	/* 0x15f4: mov w8, #0x11 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 17ULL);
arm64_l_15f8:
	/* 0x15f8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0x15fcULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_15fc:
	/* 0x15fc: mov x25, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1600:
	/* 0x1600: tbnz x0, #63, cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x1600, 0xcb8, arm64_l_cb8);
arm64_l_1604:
	/* 0x1604: ldr x9, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1608:
	/* 0x1608: sub w8, w25, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_160c:
	/* 0x160c: add x25, x25, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1610:
	/* 0x1610: str w8, [x9] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1614:
	/* 0x1614: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0x1614, 0xcb8, arm64_l_cb8);
arm64_l_1618:
	/* 0x1618: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_161c:
	/* 0x161c: stp xzr, xzr, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1620:
	/* 0x1620: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1624:
	/* 0x1624: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1628:
	/* 0x1628: mov x25, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_162c:
	/* 0x162c: ldr x22, [x8, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1630:
	/* 0x1630: str xzr, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1634:
	/* 0x1634: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1638:
	/* 0x1638: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_163c:
	/* 0x163c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1640ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1640:
	/* 0x1640: tbnz x0, #63, 1de8 <generic_retkprobe_event+0x1de8> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x1640, 0x1de8, arm64_l_1de8);
arm64_l_1644:
	/* 0x1644: ldrh w8, [x25] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1648:
	/* 0x1648: mov w24, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_164c:
	/* 0x164c: cmp w8, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1650:
	/* 0x1650: b.eq 1d98 <generic_retkprobe_event+0x1d98> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1650, 0x1d98, arm64_l_1d98);
arm64_l_1654:
	/* 0x1654: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1658:
	/* 0x1658: b.ne 1dcc <generic_retkprobe_event+0x1dcc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1658, 0x1dcc, arm64_l_1dcc);
arm64_l_165c:
	/* 0x165c: add x2, x22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1660:
	/* 0x1660: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1664:
	/* 0x1664: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1668:
	/* 0x1668: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_166c:
	/* 0x166c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1670:
	/* 0x1670: mov w21, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1674:
	/* 0x1674: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1678ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1678:
	/* 0x1678: ldr w8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_167c:
	/* 0x167c: ldr x9, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1680:
	/* 0x1680: add x2, x22, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1684:
	/* 0x1684: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1688:
	/* 0x1688: add x0, x9, #0x9e */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 158ULL);
arm64_l_168c:
	/* 0x168c: stur x8, [x9, #164] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 164ULL);
arm64_l_1690:
	/* 0x1690: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1694:
	/* 0x1694: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1698ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1698:
	/* 0x1698: b 1dcc <generic_retkprobe_event+0x1dcc> */
	ARM64_SIM_A64_JMP(0x1698, 0x1dcc, arm64_l_1dcc);
arm64_l_169c:
	/* 0x169c: ldr x8, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_16a0:
	/* 0x16a0: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_16a4:
	/* 0x16a4: cmp x9, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_16a8:
	/* 0x16a8: b.cc 304 <generic_retkprobe_event+0x304> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x16a8, 0x304, arm64_l_304);
arm64_l_16ac:
	/* 0x16ac: ldr x8, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_16b0:
	/* 0x16b0: str x19, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_16b4:
	/* 0x16b4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_16b8:
	/* 0x16b8: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_16bc:
	/* 0x16bc: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_16c0:
	/* 0x16c0: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_16c4:
	/* 0x16c4: add x2, x8, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_16c8:
	/* 0x16c8: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_16cc:
	/* 0x16cc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x16d0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_16d0:
	/* 0x16d0: tbnz w0, #31, 2198 <generic_retkprobe_event+0x2198> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x16d0, 0x2198, arm64_l_2198);
arm64_l_16d4:
	/* 0x16d4: ldr x8, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_16d8:
	/* 0x16d8: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_16dc:
	/* 0x16dc: csel x23, x8, x21, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X23, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_16e0:
	/* 0x16e0: cmp x21, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_16e4:
	/* 0x16e4: csel x8, x8, x23, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_EQ, 0);
arm64_l_16e8:
	/* 0x16e8: cmp x8, #0xffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4094ULL);
arm64_l_16ec:
	/* 0x16ec: str x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_16f0:
	/* 0x16f0: b.ls 1df8 <generic_retkprobe_event+0x1df8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x16f0, 0x1df8, arm64_l_1df8);
arm64_l_16f4:
	/* 0x16f4: mov w8, #0xfffffffd */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967293ULL);
arm64_l_16f8:
	/* 0x16f8: b 219c <generic_retkprobe_event+0x219c> */
	ARM64_SIM_A64_JMP(0x16f8, 0x219c, arm64_l_219c);
arm64_l_16fc:
	/* 0x16fc: stp x19, x29, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X19, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1700:
	/* 0x1700: add x19, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_1704:
	/* 0x1704: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1708:
	/* 0x1708: add x9, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_170c:
	/* 0x170c: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1710:
	/* 0x1710: mov w11, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1714:
	/* 0x1714: str w21, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1718:
	/* 0x1718: str xzr, [x19, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_171c:
	/* 0x171c: mov x29, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1720:
	/* 0x1720: add x0, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1724:
	/* 0x1724: str xzr, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1728:
	/* 0x1728: add x2, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_172c:
	/* 0x172c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1730:
	/* 0x1730: mov w25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1734:
	/* 0x1734: blr x11 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X11);
		if (ARM64_SIM_L_REG_TAG(ARM64_X11) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1738ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1738:
	/* 0x1738: ldr x21, [x19, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_173c:
	/* 0x173c: mov w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4095ULL);
arm64_l_1740:
	/* 0x1740: add x0, x29, #0xa4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 164ULL);
arm64_l_1744:
	/* 0x1744: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1748:
	/* 0x1748: mov x23, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_174c:
	/* 0x174c: cmp x21, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1750:
	/* 0x1750: csel x22, x21, x8, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X22, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_1754:
	/* 0x1754: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1758:
	/* 0x1758: mov w1, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_175c:
	/* 0x175c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1760ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1760:
	/* 0x1760: tbnz w0, #31, 1d80 <generic_retkprobe_event+0x1d80> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x1760, 0x1d80, arm64_l_1d80);
arm64_l_1764:
	/* 0x1764: add x25, x22, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1768:
	/* 0x1768: str w22, [x23, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_176c:
	/* 0x176c: b 1d84 <generic_retkprobe_event+0x1d84> */
	ARM64_SIM_A64_JMP(0x176c, 0x1d84, arm64_l_1d84);
arm64_l_1770:
	/* 0x1770: str x29, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1774:
	/* 0x1774: ldr x29, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1778:
	/* 0x1778: add x2, x24, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_177c:
	/* 0x177c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1780:
	/* 0x1780: mov w22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1784:
	/* 0x1784: add x8, x29, #0xdc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 220ULL);
arm64_l_1788:
	/* 0x1788: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_178c:
	/* 0x178c: add x25, x29, #0xc4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 196ULL);
arm64_l_1790:
	/* 0x1790: str x8, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1794:
	/* 0x1794: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1798:
	/* 0x1798: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x179cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_179c:
	/* 0x179c: add x0, x29, #0xa0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 160ULL);
arm64_l_17a0:
	/* 0x17a0: add x2, x24, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_17a4:
	/* 0x17a4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_17a8:
	/* 0x17a8: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_17ac:
	/* 0x17ac: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x17b0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_17b0:
	/* 0x17b0: add x0, x29, #0xac */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_17b4:
	/* 0x17b4: add x2, x24, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_17b8:
	/* 0x17b8: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_17bc:
	/* 0x17bc: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_17c0:
	/* 0x17c0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x17c4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_17c4:
	/* 0x17c4: add x0, x29, #0xb0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 176ULL);
arm64_l_17c8:
	/* 0x17c8: add x2, x24, #0x1c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_17cc:
	/* 0x17cc: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_17d0:
	/* 0x17d0: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_17d4:
	/* 0x17d4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x17d8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_17d8:
	/* 0x17d8: add x0, x29, #0xa4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 164ULL);
arm64_l_17dc:
	/* 0x17dc: add x2, x24, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_17e0:
	/* 0x17e0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_17e4:
	/* 0x17e4: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_17e8:
	/* 0x17e8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x17ecULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_17ec:
	/* 0x17ec: add x0, x29, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_17f0:
	/* 0x17f0: add x2, x24, #0x14 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_17f4:
	/* 0x17f4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_17f8:
	/* 0x17f8: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_17fc:
	/* 0x17fc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1800ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1800:
	/* 0x1800: add x0, x29, #0xb4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 180ULL);
arm64_l_1804:
	/* 0x1804: add x2, x24, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_1808:
	/* 0x1808: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_180c:
	/* 0x180c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1810:
	/* 0x1810: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1814ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1814:
	/* 0x1814: add x0, x29, #0xb8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 184ULL);
arm64_l_1818:
	/* 0x1818: add x2, x24, #0x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 36ULL);
arm64_l_181c:
	/* 0x181c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1820:
	/* 0x1820: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1824:
	/* 0x1824: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1828ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1828:
	/* 0x1828: str wzr, [x29, #192] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_182c:
	/* 0x182c: add x0, x29, #0xbc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 188ULL);
arm64_l_1830:
	/* 0x1830: add x2, x24, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_1834:
	/* 0x1834: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1838:
	/* 0x1838: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_183c:
	/* 0x183c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1840ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1840:
	/* 0x1840: add x0, x29, #0xcc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 204ULL);
arm64_l_1844:
	/* 0x1844: add x2, x24, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_1848:
	/* 0x1848: mov w23, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_184c:
	/* 0x184c: mov w21, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1850:
	/* 0x1850: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1854:
	/* 0x1854: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1858:
	/* 0x1858: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x185cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_185c:
	/* 0x185c: add x0, x29, #0xd4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 212ULL);
arm64_l_1860:
	/* 0x1860: add x2, x24, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_1864:
	/* 0x1864: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1868:
	/* 0x1868: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_186c:
	/* 0x186c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1870ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1870:
	/* 0x1870: add x2, x24, #0x38 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_1874:
	/* 0x1874: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1878:
	/* 0x1878: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_187c:
	/* 0x187c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1880:
	/* 0x1880: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1884ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1884:
	/* 0x1884: add x2, x24, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1888:
	/* 0x1888: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_188c:
	/* 0x188c: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1890:
	/* 0x1890: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1894:
	/* 0x1894: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1898:
	/* 0x1898: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x189cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_189c:
	/* 0x189c: ldr x21, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_18a0:
	/* 0x18a0: ldr x0, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_18a4:
	/* 0x18a4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18a8:
	/* 0x18a8: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18ac:
	/* 0x18ac: add x2, x21, #0xc8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_18b0:
	/* 0x18b0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x18b4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_18b4:
	/* 0x18b4: add x0, x29, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_18b8:
	/* 0x18b8: add x2, x21, #0xcc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 204ULL);
arm64_l_18bc:
	/* 0x18bc: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18c0:
	/* 0x18c0: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18c4:
	/* 0x18c4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x18c8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_18c8:
	/* 0x18c8: add x0, x29, #0xe4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 228ULL);
arm64_l_18cc:
	/* 0x18cc: add x2, x21, #0xd0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 208ULL);
arm64_l_18d0:
	/* 0x18d0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18d4:
	/* 0x18d4: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18d8:
	/* 0x18d8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x18dcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_18dc:
	/* 0x18dc: add x0, x29, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_18e0:
	/* 0x18e0: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_18e4:
	/* 0x18e4: add x2, x21, #0x158 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_18e8:
	/* 0x18e8: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18ec:
	/* 0x18ec: mov w21, w23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_18f0:
	/* 0x18f0: mov w23, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_18f4:
	/* 0x18f4: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x18f8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_18f8:
	/* 0x18f8: mov w25, #0x50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 80ULL);
arm64_l_18fc:
	/* 0x18fc: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0x18fc, 0xcb8, arm64_l_cb8);
arm64_l_1900:
	/* 0x1900: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1904:
	/* 0x1904: add x2, x24, #0xc8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_1908:
	/* 0x1908: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_190c:
	/* 0x190c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1910:
	/* 0x1910: mov w23, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1914:
	/* 0x1914: mov w21, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1918:
	/* 0x1918: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x191cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_191c:
	/* 0x191c: ldr x22, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1920:
	/* 0x1920: add x2, x24, #0xcc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 204ULL);
arm64_l_1924:
	/* 0x1924: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1928:
	/* 0x1928: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_192c:
	/* 0x192c: add x0, x22, #0xa0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 160ULL);
arm64_l_1930:
	/* 0x1930: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1934ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1934:
	/* 0x1934: add x0, x22, #0xa4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 164ULL);
arm64_l_1938:
	/* 0x1938: add x2, x24, #0xd0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 208ULL);
arm64_l_193c:
	/* 0x193c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1940:
	/* 0x1940: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1944:
	/* 0x1944: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1948ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1948:
	/* 0x1948: add x0, x22, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_194c:
	/* 0x194c: add x2, x24, #0x158 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_1950:
	/* 0x1950: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1954:
	/* 0x1954: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1958ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1958:
	/* 0x1958: mov w21, w23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_195c:
	/* 0x195c: mov w23, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1960:
	/* 0x1960: mov w25, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1964:
	/* 0x1964: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0x1964, 0xcb8, arm64_l_cb8);
arm64_l_1968:
	/* 0x1968: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_196c:
	/* 0x196c: add x2, x24, #0x38 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_1970:
	/* 0x1970: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1974:
	/* 0x1974: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1978:
	/* 0x1978: mov w22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_197c:
	/* 0x197c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1980ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1980:
	/* 0x1980: mov w23, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1984:
	/* 0x1984: ldr x21, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1988:
	/* 0x1988: add x2, x24, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_198c:
	/* 0x198c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1990:
	/* 0x1990: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1994:
	/* 0x1994: add x0, x21, #0xa0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 160ULL);
arm64_l_1998:
	/* 0x1998: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x199cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_199c:
	/* 0x199c: add x0, x21, #0xa4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 164ULL);
arm64_l_19a0:
	/* 0x19a0: add x2, x24, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_19a4:
	/* 0x19a4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_19a8:
	/* 0x19a8: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_19ac:
	/* 0x19ac: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x19b0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_19b0:
	/* 0x19b0: add x0, x21, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_19b4:
	/* 0x19b4: add x2, x24, #0x44 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 68ULL);
arm64_l_19b8:
	/* 0x19b8: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_19bc:
	/* 0x19bc: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_19c0:
	/* 0x19c0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x19c4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_19c4:
	/* 0x19c4: add x0, x21, #0xac */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_19c8:
	/* 0x19c8: add x2, x24, #0x80 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_19cc:
	/* 0x19cc: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_19d0:
	/* 0x19d0: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_19d4:
	/* 0x19d4: mov w21, w23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_19d8:
	/* 0x19d8: mov w23, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_19dc:
	/* 0x19dc: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x19e0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_19e0:
	/* 0x19e0: mov w25, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 32ULL);
arm64_l_19e4:
	/* 0x19e4: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0x19e4, 0xcb8, arm64_l_cb8);
arm64_l_19e8:
	/* 0x19e8: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_19ec:
	/* 0x19ec: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_19f0:
	/* 0x19f0: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_19f4:
	/* 0x19f4: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_19f8:
	/* 0x19f8: mov w23, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_19fc:
	/* 0x19fc: mov w21, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1a00:
	/* 0x1a00: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1a04ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1a04:
	/* 0x1a04: ldr x22, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1a08:
	/* 0x1a08: add x2, x24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1a0c:
	/* 0x1a0c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1a10:
	/* 0x1a10: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1a14:
	/* 0x1a14: add x0, x22, #0xa0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 160ULL);
arm64_l_1a18:
	/* 0x1a18: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1a1cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1a1c:
	/* 0x1a1c: add x0, x22, #0xa4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 164ULL);
arm64_l_1a20:
	/* 0x1a20: add x2, x24, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_1a24:
	/* 0x1a24: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1a28:
	/* 0x1a28: b 1aac <generic_retkprobe_event+0x1aac> */
	ARM64_SIM_A64_JMP(0x1a28, 0x1aac, arm64_l_1aac);
arm64_l_1a2c:
	/* 0x1a2c: add x2, x24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1a30:
	/* 0x1a30: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1a34:
	/* 0x1a34: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1a38:
	/* 0x1a38: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1a3c:
	/* 0x1a3c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1a40:
	/* 0x1a40: mov w23, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1a44:
	/* 0x1a44: mov w21, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1a48:
	/* 0x1a48: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1a4cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1a4c:
	/* 0x1a4c: ldr w8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1a50:
	/* 0x1a50: ldr x22, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1a54:
	/* 0x1a54: add x2, x24, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1a58:
	/* 0x1a58: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1a5c:
	/* 0x1a5c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1a60:
	/* 0x1a60: str w8, [x22, #156] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 156ULL);
arm64_l_1a64:
	/* 0x1a64: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1a68:
	/* 0x1a68: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1a6cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1a6c:
	/* 0x1a6c: ldr w8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1a70:
	/* 0x1a70: add x2, x24, #0x50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 80ULL);
arm64_l_1a74:
	/* 0x1a74: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1a78:
	/* 0x1a78: mov w10, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_1a7c:
	/* 0x1a7c: str w8, [x22, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_1a80:
	/* 0x1a80: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1a84:
	/* 0x1a84: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1a88:
	/* 0x1a88: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1a8c:
	/* 0x1a8c: mov w21, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_1a90:
	/* 0x1a90: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0x1a94ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1a94:
	/* 0x1a94: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1a98:
	/* 0x1a98: add x0, x22, #0xa4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 164ULL);
arm64_l_1a9c:
	/* 0x1a9c: mov w9, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1aa0:
	/* 0x1aa0: add x8, x8, #0x3f8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1016ULL);
arm64_l_1aa4:
	/* 0x1aa4: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1aa8:
	/* 0x1aa8: add x2, x8, #0x3f8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1016ULL);
arm64_l_1aac:
	/* 0x1aac: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1ab0:
	/* 0x1ab0: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1ab4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			case 45ULL: ARM64_SIM_A64_LINK(0x1ab4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1ab4:
	/* 0x1ab4: mov w21, w23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1ab8:
	/* 0x1ab8: mov w23, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1abc:
	/* 0x1abc: mov w25, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_1ac0:
	/* 0x1ac0: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0x1ac0, 0xcb8, arm64_l_cb8);
arm64_l_1ac4:
	/* 0x1ac4: ldr x11, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1ac8:
	/* 0x1ac8: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1acc:
	/* 0x1acc: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1ad0:
	/* 0x1ad0: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1ad4:
	/* 0x1ad4: stp xzr, xzr, [x11, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X11, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1ad8:
	/* 0x1ad8: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1adc:
	/* 0x1adc: stp xzr, xzr, [x11, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X11, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1ae0:
	/* 0x1ae0: stp xzr, xzr, [x11, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X11, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1ae4:
	/* 0x1ae4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1ae8:
	/* 0x1ae8: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1aec:
	/* 0x1aec: stp xzr, xzr, [x11, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X11, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1af0:
	/* 0x1af0: stp xzr, xzr, [x11] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X11, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1af4:
	/* 0x1af4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1af8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1af8:
	/* 0x1af8: mov x25, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1afc:
	/* 0x1afc: cbnz x0, cb4 <generic_retkprobe_event+0xcb4> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x1afc, 0xcb4, arm64_l_cb4);
arm64_l_1b00:
	/* 0x1b00: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1b04:
	/* 0x1b04: mov w9, #0x3f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 63ULL);
arm64_l_1b08:
	/* 0x1b08: mov w10, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_1b0c:
	/* 0x1b0c: mov w1, #0x3f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 63ULL);
arm64_l_1b10:
	/* 0x1b10: mov w23, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1b14:
	/* 0x1b14: add x0, x8, #0xac */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_1b18:
	/* 0x1b18: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1b1c:
	/* 0x1b1c: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1b20:
	/* 0x1b20: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0x1b24ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1b24:
	/* 0x1b24: tbnz x0, #63, 1f24 <generic_retkprobe_event+0x1f24> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x1b24, 0x1f24, arm64_l_1f24);
arm64_l_1b28:
	/* 0x1b28: add x2, x24, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1b2c:
	/* 0x1b2c: mov w21, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1b30:
	/* 0x1b30: add x8, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1b34:
	/* 0x1b34: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1b38:
	/* 0x1b38: add x0, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1b3c:
	/* 0x1b3c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1b40:
	/* 0x1b40: mov w22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1b44:
	/* 0x1b44: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1b48ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1b48:
	/* 0x1b48: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1b4c:
	/* 0x1b4c: add x10, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_1b50:
	/* 0x1b50: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1b54:
	/* 0x1b54: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1b58:
	/* 0x1b58: add x0, x8, #0xa4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 164ULL);
arm64_l_1b5c:
	/* 0x1b5c: ldr x8, [x10, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1b60:
	/* 0x1b60: add x8, x8, #0x360 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 864ULL);
arm64_l_1b64:
	/* 0x1b64: ldr x8, [x10, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1b68:
	/* 0x1b68: add x2, x8, #0x360 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 864ULL);
arm64_l_1b6c:
	/* 0x1b6c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1b70ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1b70:
	/* 0x1b70: add x2, x24, #0x58 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1b74:
	/* 0x1b74: add x8, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1b78:
	/* 0x1b78: add x0, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1b7c:
	/* 0x1b7c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1b80:
	/* 0x1b80: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1b84ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1b84:
	/* 0x1b84: cbnz x0, 1b9c <generic_retkprobe_event+0x1b9c> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x1b84, 0x1b9c, arm64_l_1b9c);
arm64_l_1b88:
	/* 0x1b88: ldr w8, [sp, #232] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_1b8c:
	/* 0x1b8c: ldr x9, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1b90:
	/* 0x1b90: cmp w8, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1b94:
	/* 0x1b94: cset w8, ne */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1b98:
	/* 0x1b98: str w8, [x9] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b9c:
	/* 0x1b9c: mov w25, #0x50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 80ULL);
arm64_l_1ba0:
	/* 0x1ba0: b 1f28 <generic_retkprobe_event+0x1f28> */
	ARM64_SIM_A64_JMP(0x1ba0, 0x1f28, arm64_l_1f28);
arm64_l_1ba4:
	/* 0x1ba4: mov x25, #0xffffffffffffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 18446744073709551615ULL);
arm64_l_1ba8:
	/* 0x1ba8: b 1e64 <generic_retkprobe_event+0x1e64> */
	ARM64_SIM_A64_JMP(0x1ba8, 0x1e64, arm64_l_1e64);
arm64_l_1bac:
	/* 0x1bac: add x2, x22, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1bb0:
	/* 0x1bb0: mov w21, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1bb4:
	/* 0x1bb4: add x8, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1bb8:
	/* 0x1bb8: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1bbc:
	/* 0x1bbc: add x0, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1bc0:
	/* 0x1bc0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1bc4:
	/* 0x1bc4: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1bc8:
	/* 0x1bc8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1bccULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1bcc:
	/* 0x1bcc: add x2, x22, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1bd0:
	/* 0x1bd0: add x8, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_1bd4:
	/* 0x1bd4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1bd8:
	/* 0x1bd8: add x0, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_1bdc:
	/* 0x1bdc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1be0:
	/* 0x1be0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1be4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1be4:
	/* 0x1be4: ldr x21, [sp, #112] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_1be8:
	/* 0x1be8: ldr x2, [x25, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1bec:
	/* 0x1bec: mov w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4095ULL);
arm64_l_1bf0:
	/* 0x1bf0: add x0, x23, #0xa4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 164ULL);
arm64_l_1bf4:
	/* 0x1bf4: cmp x21, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1bf8:
	/* 0x1bf8: csel x22, x21, x8, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X22, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_1bfc:
	/* 0x1bfc: mov w1, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1c00:
	/* 0x1c00: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1c04ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1c04:
	/* 0x1c04: tbnz w0, #31, 1c18 <generic_retkprobe_event+0x1c18> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x1c04, 0x1c18, arm64_l_1c18);
arm64_l_1c08:
	/* 0x1c08: stp w21, w22, [x23, #156] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X23, ARM64_X21, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 156ULL);
arm64_l_1c0c:
	/* 0x1c0c: ldr w21, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1c10:
	/* 0x1c10: add x25, x22, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1c14:
	/* 0x1c14: b cb4 <generic_retkprobe_event+0xcb4> */
	ARM64_SIM_A64_JMP(0x1c14, 0xcb4, arm64_l_cb4);
arm64_l_1c18:
	/* 0x1c18: ldr w21, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1c1c:
	/* 0x1c1c: mov w8, #0xfffffffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967294ULL);
arm64_l_1c20:
	/* 0x1c20: mov w25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1c24:
	/* 0x1c24: str w8, [x23, #156] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 156ULL);
arm64_l_1c28:
	/* 0x1c28: b cb4 <generic_retkprobe_event+0xcb4> */
	ARM64_SIM_A64_JMP(0x1c28, 0xcb4, arm64_l_cb4);
arm64_l_1c2c:
	/* 0x1c2c: str x19, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1c30:
	/* 0x1c30: str wzr, [sp, #232] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_1c34:
	/* 0x1c34: adrp x0, 0 <tg_ipv6_ext_heap> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_ipv6_ext_heap_10));
arm64_l_1c38:
	/* 0x1c38: ldr x23, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1c3c:
	/* 0x1c3c: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1c40:
	/* 0x1c40: add x9, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1c44:
	/* 0x1c44: ldrh w21, [sp, #216] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 216ULL);
arm64_l_1c48:
	/* 0x1c48: add x1, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1c4c:
	/* 0x1c4c: add x22, x23, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1c50:
	/* 0x1c50: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c54:
	/* 0x1c54: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1c58ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1c58:
	/* 0x1c58: cbz x0, 270c <generic_retkprobe_event+0x270c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1c58, 0x270c, arm64_l_270c);
arm64_l_1c5c:
	/* 0x1c5c: mov w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 255ULL);
arm64_l_1c60:
	/* 0x1c60: strh w21, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c64:
	/* 0x1c64: strb wzr, [x0, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_1c68:
	/* 0x1c68: add x25, x0, #0x6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1c6c:
	/* 0x1c6c: add x2, x22, #0x6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1c70:
	/* 0x1c70: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1c74:
	/* 0x1c74: strb w8, [x0, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_1c78:
	/* 0x1c78: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1c7c:
	/* 0x1c7c: mov x24, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c80:
	/* 0x1c80: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c84:
	/* 0x1c84: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1c88:
	/* 0x1c88: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1c8cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1c8c:
	/* 0x1c8c: tbnz x0, #63, 270c <generic_retkprobe_event+0x270c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x1c8c, 0x270c, arm64_l_270c);
arm64_l_1c90:
	/* 0x1c90: ldrb w8, [x24, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_1c94:
	/* 0x1c94: cmp w8, #0x32; 0x1c98: b.gt 1f30 <generic_retkprobe_event+0x1f30> */
arm64_l_1c98:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50ULL, arm64_l_1f30);
arm64_l_1c9c:
	/* 0x1c9c: cbz w8, 1f50 <generic_retkprobe_event+0x1f50> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x1c9c, 0x1f50, arm64_l_1f50);
arm64_l_1ca0:
	/* 0x1ca0: cmp w8, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_1ca4:
	/* 0x1ca4: b.eq 1f50 <generic_retkprobe_event+0x1f50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ca4, 0x1f50, arm64_l_1f50);
arm64_l_1ca8:
	/* 0x1ca8: cmp w8, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_1cac:
	/* 0x1cac: b.ne 2268 <generic_retkprobe_event+0x2268> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1cac, 0x2268, arm64_l_2268);
arm64_l_1cb0:
	/* 0x1cb0: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1cb4:
	/* 0x1cb4: b 21b4 <generic_retkprobe_event+0x21b4> */
	ARM64_SIM_A64_JMP(0x1cb4, 0x21b4, arm64_l_21b4);
arm64_l_1cb8:
	/* 0x1cb8: add x2, x23, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1cbc:
	/* 0x1cbc: mov w21, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1cc0:
	/* 0x1cc0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1cc4:
	/* 0x1cc4: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1cc8:
	/* 0x1cc8: mov w25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1ccc:
	/* 0x1ccc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1cd0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1cd0:
	/* 0x1cd0: add x2, x23, #0x38 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_1cd4:
	/* 0x1cd4: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1cd8:
	/* 0x1cd8: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1cdc:
	/* 0x1cdc: blr x25 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X25);
		if (ARM64_SIM_L_REG_TAG(ARM64_X25) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1ce0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1ce0:
	/* 0x1ce0: ldr x21, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1ce4:
	/* 0x1ce4: add x22, x23, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1ce8:
	/* 0x1ce8: add x2, x23, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 14ULL);
arm64_l_1cec:
	/* 0x1cec: mov w23, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1cf0:
	/* 0x1cf0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1cf4:
	/* 0x1cf4: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1cf8:
	/* 0x1cf8: mov w25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1cfc:
	/* 0x1cfc: add x0, x21, #0xbc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 188ULL);
arm64_l_1d00:
	/* 0x1d00: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1d04ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1d04:
	/* 0x1d04: add x0, x21, #0xbe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 190ULL);
arm64_l_1d08:
	/* 0x1d08: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1d0c:
	/* 0x1d0c: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1d10:
	/* 0x1d10: blr x25 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X25);
		if (ARM64_SIM_L_REG_TAG(ARM64_X25) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1d14ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1d14:
	/* 0x1d14: ldrh w8, [x21, #190] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 190ULL);
arm64_l_1d18:
	/* 0x1d18: adrp x0, 0 <socktrack_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&socktrack_map_9));
arm64_l_1d1c:
	/* 0x1d1c: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1d20:
	/* 0x1d20: add x1, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1d24:
	/* 0x1d24: rev w8, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_REV, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1d28:
	/* 0x1d28: lsr w8, w8, #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 16ULL);
arm64_l_1d2c:
	/* 0x1d2c: strh w8, [x21, #190] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 190ULL);
arm64_l_1d30:
	/* 0x1d30: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_1d34:
	/* 0x1d34: ldr x8, [x8, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1d38:
	/* 0x1d38: str x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1d3c:
	/* 0x1d3c: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1d40:
	/* 0x1d40: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1d44:
	/* 0x1d44: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1d48ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1d48:
	/* 0x1d48: cbz x0, 1d64 <generic_retkprobe_event+0x1d64> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1d48, 0x1d64, arm64_l_1d64);
arm64_l_1d4c:
	/* 0x1d4c: ldr w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1d50:
	/* 0x1d50: str w8, [x24, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1d54:
	/* 0x1d54: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1d58:
	/* 0x1d58: str x8, [x24, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1d5c:
	/* 0x1d5c: ldr w8, [x0, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1d60:
	/* 0x1d60: str w8, [x24, #124] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 124ULL);
arm64_l_1d64:
	/* 0x1d64: ldr w21, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1d68:
	/* 0x1d68: mov w25, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 64ULL);
arm64_l_1d6c:
	/* 0x1d6c: b cb4 <generic_retkprobe_event+0xcb4> */
	ARM64_SIM_A64_JMP(0x1d6c, 0xcb4, arm64_l_cb4);
arm64_l_1d70:
	/* 0x1d70: ldr w21, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1d74:
	/* 0x1d74: stur xzr, [x23, #156] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 156ULL);
arm64_l_1d78:
	/* 0x1d78: mov w25, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1d7c:
	/* 0x1d7c: b cb4 <generic_retkprobe_event+0xcb4> */
	ARM64_SIM_A64_JMP(0x1d7c, 0xcb4, arm64_l_cb4);
arm64_l_1d80:
	/* 0x1d80: mov w21, #0xfffffffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967294ULL);
arm64_l_1d84:
	/* 0x1d84: str w21, [x23, #156] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 156ULL);
arm64_l_1d88:
	/* 0x1d88: ldp x19, x29, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X19, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1d8c:
	/* 0x1d8c: mov w23, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1d90:
	/* 0x1d90: ldr w21, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_1d94:
	/* 0x1d94: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0x1d94, 0xcb8, arm64_l_cb8);
arm64_l_1d98:
	/* 0x1d98: ldr x21, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1d9c:
	/* 0x1d9c: add x2, x22, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1da0:
	/* 0x1da0: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1da4:
	/* 0x1da4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1da8:
	/* 0x1da8: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1dac:
	/* 0x1dac: mov w23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1db0:
	/* 0x1db0: add x0, x21, #0xa4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 164ULL);
arm64_l_1db4:
	/* 0x1db4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1db8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1db8:
	/* 0x1db8: add x0, x21, #0x9e */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 158ULL);
arm64_l_1dbc:
	/* 0x1dbc: add x2, x22, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1dc0:
	/* 0x1dc0: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1dc4:
	/* 0x1dc4: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1dc8:
	/* 0x1dc8: blr x23 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X23);
		if (ARM64_SIM_L_REG_TAG(ARM64_X23) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1dccULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1dcc:
	/* 0x1dcc: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1dd0:
	/* 0x1dd0: mov w21, w24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1dd4:
	/* 0x1dd4: mov w23, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1dd8:
	/* 0x1dd8: ldrh w9, [x8, #158] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 158ULL);
arm64_l_1ddc:
	/* 0x1ddc: rev w9, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_REV, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1de0:
	/* 0x1de0: lsr w9, w9, #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 16ULL);
arm64_l_1de4:
	/* 0x1de4: strh w9, [x8, #158] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 158ULL);
arm64_l_1de8:
	/* 0x1de8: mov w25, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_1dec:
	/* 0x1dec: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0x1dec, 0xcb8, arm64_l_cb8);
arm64_l_1df0:
	/* 0x1df0: mov x25, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1df4:
	/* 0x1df4: b cb8 <generic_retkprobe_event+0xcb8> */
	ARM64_SIM_A64_JMP(0x1df4, 0xcb8, arm64_l_cb8);
arm64_l_1df8:
	/* 0x1df8: ldr x9, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_1dfc:
	/* 0x1dfc: add x24, x24, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X24, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1e00:
	/* 0x1e00: ldr x1, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1e04:
	/* 0x1e04: and x8, x24, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_1e08:
	/* 0x1e08: add x0, x9, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1e0c:
	/* 0x1e0c: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1e10:
	/* 0x1e10: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1e14:
	/* 0x1e14: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1e18:
	/* 0x1e18: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1e1cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1e1c:
	/* 0x1e1c: tbnz w0, #31, 2198 <generic_retkprobe_event+0x2198> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x1e1c, 0x2198, arm64_l_2198);
arm64_l_1e20:
	/* 0x1e20: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1e24:
	/* 0x1e24: add x29, x8, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X29, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1e28:
	/* 0x1e28: cbz x21, 1f5c <generic_retkprobe_event+0x1f5c> */
	ARM64_SIM_A64_CBZ(ARM64_X21, 0x1e28, 0x1f5c, arm64_l_1f5c);
arm64_l_1e2c:
	/* 0x1e2c: subs x22, x21, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X22, ARM64_X21, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e30:
	/* 0x1e30: b.ne 1f60 <generic_retkprobe_event+0x1f60> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1e30, 0x1f60, arm64_l_1f60);
arm64_l_1e34:
	/* 0x1e34: ldr x8, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_1e38:
	/* 0x1e38: ldr x19, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1e3c:
	/* 0x1e3c: b 304 <generic_retkprobe_event+0x304> */
	ARM64_SIM_A64_JMP(0x1e3c, 0x304, arm64_l_304);
arm64_l_1e40:
	/* 0x1e40: add x2, x22, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1e44:
	/* 0x1e44: mov w21, #0x6b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 107ULL);
arm64_l_1e48:
	/* 0x1e48: mov w8, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1e4c:
	/* 0x1e4c: mov w1, #0x6b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 107ULL);
arm64_l_1e50:
	/* 0x1e50: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1e54ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1e54:
	/* 0x1e54: tbnz w0, #31, 1e60 <generic_retkprobe_event+0x1e60> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x1e54, 0x1e60, arm64_l_1e60);
arm64_l_1e58:
	/* 0x1e58: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1e5c:
	/* 0x1e5c: strb w21, [x8, #159] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 159ULL);
arm64_l_1e60:
	/* 0x1e60: mov w25, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 112ULL);
arm64_l_1e64:
	/* 0x1e64: mov w21, w24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1e68:
	/* 0x1e68: b cb4 <generic_retkprobe_event+0xcb4> */
	ARM64_SIM_A64_JMP(0x1e68, 0xcb4, arm64_l_cb4);
arm64_l_1e6c:
	/* 0x1e6c: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1e70:
	/* 0x1e70: add x2, x23, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1e74:
	/* 0x1e74: mov w21, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1e78:
	/* 0x1e78: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1e7c:
	/* 0x1e7c: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1e80:
	/* 0x1e80: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1e84:
	/* 0x1e84: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1e88ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1e88:
	/* 0x1e88: add x2, x23, #0x38 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_1e8c:
	/* 0x1e8c: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1e90:
	/* 0x1e90: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1e94:
	/* 0x1e94: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1e98ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1e98:
	/* 0x1e98: ldr x21, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1e9c:
	/* 0x1e9c: add x22, x23, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1ea0:
	/* 0x1ea0: add x2, x23, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 14ULL);
arm64_l_1ea4:
	/* 0x1ea4: mov w23, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1ea8:
	/* 0x1ea8: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1eac:
	/* 0x1eac: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1eb0:
	/* 0x1eb0: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1eb4:
	/* 0x1eb4: add x0, x21, #0xbc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 188ULL);
arm64_l_1eb8:
	/* 0x1eb8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1ebcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1ebc:
	/* 0x1ebc: add x0, x21, #0xbe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 190ULL);
arm64_l_1ec0:
	/* 0x1ec0: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1ec4:
	/* 0x1ec4: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1ec8:
	/* 0x1ec8: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1eccULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1ecc:
	/* 0x1ecc: ldrh w8, [x21, #190] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 190ULL);
arm64_l_1ed0:
	/* 0x1ed0: rev w8, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_REV, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1ed4:
	/* 0x1ed4: lsr w8, w8, #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 16ULL);
arm64_l_1ed8:
	/* 0x1ed8: strh w8, [x21, #190] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 190ULL);
arm64_l_1edc:
	/* 0x1edc: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1ee0:
	/* 0x1ee0: adrp x0, 0 <socktrack_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&socktrack_map_9));
arm64_l_1ee4:
	/* 0x1ee4: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1ee8:
	/* 0x1ee8: add x1, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1eec:
	/* 0x1eec: ldur x8, [x8, #196] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 196ULL);
arm64_l_1ef0:
	/* 0x1ef0: str x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1ef4:
	/* 0x1ef4: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ef8:
	/* 0x1ef8: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1efc:
	/* 0x1efc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1f00ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1f00:
	/* 0x1f00: cbz x0, 1f1c <generic_retkprobe_event+0x1f1c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1f00, 0x1f1c, arm64_l_1f1c);
arm64_l_1f04:
	/* 0x1f04: ldr w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f08:
	/* 0x1f08: str w8, [x25, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1f0c:
	/* 0x1f0c: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1f10:
	/* 0x1f10: str x8, [x25, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1f14:
	/* 0x1f14: ldr w8, [x0, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1f18:
	/* 0x1f18: str w8, [x25, #124] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 124ULL);
arm64_l_1f1c:
	/* 0x1f1c: mov w25, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 64ULL);
arm64_l_1f20:
	/* 0x1f20: b cb0 <generic_retkprobe_event+0xcb0> */
	ARM64_SIM_A64_JMP(0x1f20, 0xcb0, arm64_l_cb0);
arm64_l_1f24:
	/* 0x1f24: mov x25, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1f28:
	/* 0x1f28: mov w21, w23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1f2c:
	/* 0x1f2c: b cb4 <generic_retkprobe_event+0xcb4> */
	ARM64_SIM_A64_JMP(0x1f2c, 0xcb4, arm64_l_cb4);
arm64_l_1f30:
	/* 0x1f30: cmp w8, #0x33 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 51ULL);
arm64_l_1f34:
	/* 0x1f34: b.eq 21a8 <generic_retkprobe_event+0x21a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f34, 0x21a8, arm64_l_21a8);
arm64_l_1f38:
	/* 0x1f38: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_1f3c:
	/* 0x1f3c: b.eq 1f50 <generic_retkprobe_event+0x1f50> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f3c, 0x1f50, arm64_l_1f50);
arm64_l_1f40:
	/* 0x1f40: cmp w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_1f44:
	/* 0x1f44: b.ne 2268 <generic_retkprobe_event+0x2268> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1f44, 0x2268, arm64_l_2268);
arm64_l_1f48:
	/* 0x1f48: mov w8, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 40ULL);
arm64_l_1f4c:
	/* 0x1f4c: b 21b4 <generic_retkprobe_event+0x21b4> */
	ARM64_SIM_A64_JMP(0x1f4c, 0x21b4, arm64_l_21b4);
arm64_l_1f50:
	/* 0x1f50: ldrb w8, [x24, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_1f54:
	/* 0x1f54: lsl w8, w8, #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_1f58:
	/* 0x1f58: b 21b0 <generic_retkprobe_event+0x21b0> */
	ARM64_SIM_A64_JMP(0x1f58, 0x21b0, arm64_l_21b0);
arm64_l_1f5c:
	/* 0x1f5c: mov x22, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1f60:
	/* 0x1f60: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1f64:
	/* 0x1f64: ldr x19, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1f68:
	/* 0x1f68: cmp x8, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1f6c:
	/* 0x1f6c: ldr x8, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_1f70:
	/* 0x1f70: b.eq 304 <generic_retkprobe_event+0x304> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1f70, 0x304, arm64_l_304);
arm64_l_1f74:
	/* 0x1f74: ldr x8, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_1f78:
	/* 0x1f78: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1f7c:
	/* 0x1f7c: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1f80:
	/* 0x1f80: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1f84:
	/* 0x1f84: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1f88:
	/* 0x1f88: add x2, x8, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_1f8c:
	/* 0x1f8c: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1f90:
	/* 0x1f90: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1f94ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1f94:
	/* 0x1f94: tbnz w0, #31, 2198 <generic_retkprobe_event+0x2198> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x1f94, 0x2198, arm64_l_2198);
arm64_l_1f98:
	/* 0x1f98: ldr x8, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_1f9c:
	/* 0x1f9c: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fa0:
	/* 0x1fa0: csel x23, x8, x22, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X23, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_1fa4:
	/* 0x1fa4: cmp x22, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1fa8:
	/* 0x1fa8: csel x21, x8, x23, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X21, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_EQ, 0);
arm64_l_1fac:
	/* 0x1fac: cmp x21, #0xffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4094ULL);
arm64_l_1fb0:
	/* 0x1fb0: b.hi 16f4 <generic_retkprobe_event+0x16f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x1fb0, 0x16f4, arm64_l_16f4);
arm64_l_1fb4:
	/* 0x1fb4: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1fb8:
	/* 0x1fb8: ldr x9, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_1fbc:
	/* 0x1fbc: mov w1, w21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1fc0:
	/* 0x1fc0: add x24, x8, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1fc4:
	/* 0x1fc4: and x8, x24, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_1fc8:
	/* 0x1fc8: add x0, x9, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1fcc:
	/* 0x1fcc: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1fd0:
	/* 0x1fd0: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1fd4:
	/* 0x1fd4: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1fd8:
	/* 0x1fd8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1fdcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1fdc:
	/* 0x1fdc: tbnz w0, #31, 2198 <generic_retkprobe_event+0x2198> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x1fdc, 0x2198, arm64_l_2198);
arm64_l_1fe0:
	/* 0x1fe0: add x29, x21, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X29, ARM64_X21, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1fe4:
	/* 0x1fe4: cbz x22, 1ff0 <generic_retkprobe_event+0x1ff0> */
	ARM64_SIM_A64_CBZ(ARM64_X22, 0x1fe4, 0x1ff0, arm64_l_1ff0);
arm64_l_1fe8:
	/* 0x1fe8: subs x22, x22, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X22, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fec:
	/* 0x1fec: b.eq 1e34 <generic_retkprobe_event+0x1e34> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1fec, 0x1e34, arm64_l_1e34);
arm64_l_1ff0:
	/* 0x1ff0: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1ff4:
	/* 0x1ff4: ldr x19, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1ff8:
	/* 0x1ff8: cmp x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_1ffc:
	/* 0x1ffc: ldr x8, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_2000:
	/* 0x2000: b.cc 304 <generic_retkprobe_event+0x304> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2000, 0x304, arm64_l_304);
arm64_l_2004:
	/* 0x2004: ldr x8, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_2008:
	/* 0x2008: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_200c:
	/* 0x200c: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2010:
	/* 0x2010: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2014:
	/* 0x2014: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2018:
	/* 0x2018: add x2, x8, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_201c:
	/* 0x201c: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2020:
	/* 0x2020: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2024ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2024:
	/* 0x2024: tbnz w0, #31, 2198 <generic_retkprobe_event+0x2198> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2024, 0x2198, arm64_l_2198);
arm64_l_2028:
	/* 0x2028: ldr x8, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_202c:
	/* 0x202c: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2030:
	/* 0x2030: csel x23, x8, x22, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X23, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_2034:
	/* 0x2034: cmp x22, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_2038:
	/* 0x2038: csel x8, x8, x23, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_EQ, 0);
arm64_l_203c:
	/* 0x203c: cmp x8, #0xffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4094ULL);
arm64_l_2040:
	/* 0x2040: str x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2044:
	/* 0x2044: b.hi 16f4 <generic_retkprobe_event+0x16f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2044, 0x16f4, arm64_l_16f4);
arm64_l_2048:
	/* 0x2048: ldr x9, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_204c:
	/* 0x204c: add x21, x21, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X21, ARM64_X21, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2050:
	/* 0x2050: ldr x1, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2054:
	/* 0x2054: and x8, x21, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_2058:
	/* 0x2058: add x0, x9, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_205c:
	/* 0x205c: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_2060:
	/* 0x2060: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2064:
	/* 0x2064: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_2068:
	/* 0x2068: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x206cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_206c:
	/* 0x206c: tbnz w0, #31, 2198 <generic_retkprobe_event+0x2198> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x206c, 0x2198, arm64_l_2198);
arm64_l_2070:
	/* 0x2070: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2074:
	/* 0x2074: add x29, x8, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X29, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2078:
	/* 0x2078: cbz x22, 2084 <generic_retkprobe_event+0x2084> */
	ARM64_SIM_A64_CBZ(ARM64_X22, 0x2078, 0x2084, arm64_l_2084);
arm64_l_207c:
	/* 0x207c: subs x22, x22, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X22, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2080:
	/* 0x2080: b.eq 1e34 <generic_retkprobe_event+0x1e34> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2080, 0x1e34, arm64_l_1e34);
arm64_l_2084:
	/* 0x2084: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2088:
	/* 0x2088: ldr x19, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_208c:
	/* 0x208c: cmp x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2090:
	/* 0x2090: ldr x8, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_2094:
	/* 0x2094: b.eq 304 <generic_retkprobe_event+0x304> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2094, 0x304, arm64_l_304);
arm64_l_2098:
	/* 0x2098: ldr x8, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_209c:
	/* 0x209c: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_20a0:
	/* 0x20a0: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_20a4:
	/* 0x20a4: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_20a8:
	/* 0x20a8: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_20ac:
	/* 0x20ac: add x2, x8, #0x50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 80ULL);
arm64_l_20b0:
	/* 0x20b0: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_20b4:
	/* 0x20b4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x20b8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_20b8:
	/* 0x20b8: tbnz w0, #31, 2198 <generic_retkprobe_event+0x2198> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x20b8, 0x2198, arm64_l_2198);
arm64_l_20bc:
	/* 0x20bc: ldr x8, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_20c0:
	/* 0x20c0: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_20c4:
	/* 0x20c4: csel x23, x8, x22, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X23, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_20c8:
	/* 0x20c8: cmp x22, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_20cc:
	/* 0x20cc: csel x24, x8, x23, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X24, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_EQ, 0);
arm64_l_20d0:
	/* 0x20d0: cmp x24, #0xffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4094ULL);
arm64_l_20d4:
	/* 0x20d4: b.hi 16f4 <generic_retkprobe_event+0x16f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x20d4, 0x16f4, arm64_l_16f4);
arm64_l_20d8:
	/* 0x20d8: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_20dc:
	/* 0x20dc: ldr x9, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_20e0:
	/* 0x20e0: mov w1, w24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_20e4:
	/* 0x20e4: add x21, x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X21, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_20e8:
	/* 0x20e8: and x8, x21, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_20ec:
	/* 0x20ec: add x0, x9, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_20f0:
	/* 0x20f0: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_20f4:
	/* 0x20f4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_20f8:
	/* 0x20f8: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_20fc:
	/* 0x20fc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2100ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2100:
	/* 0x2100: tbnz w0, #31, 2198 <generic_retkprobe_event+0x2198> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2100, 0x2198, arm64_l_2198);
arm64_l_2104:
	/* 0x2104: add x29, x24, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X29, ARM64_X24, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2108:
	/* 0x2108: cbz x22, 2114 <generic_retkprobe_event+0x2114> */
	ARM64_SIM_A64_CBZ(ARM64_X22, 0x2108, 0x2114, arm64_l_2114);
arm64_l_210c:
	/* 0x210c: subs x22, x22, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X22, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2110:
	/* 0x2110: b.eq 1e34 <generic_retkprobe_event+0x1e34> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2110, 0x1e34, arm64_l_1e34);
arm64_l_2114:
	/* 0x2114: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2118:
	/* 0x2118: ldr x19, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_211c:
	/* 0x211c: cmp x8, #0x7 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_2120:
	/* 0x2120: ldr x8, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_2124:
	/* 0x2124: b.cc 304 <generic_retkprobe_event+0x304> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2124, 0x304, arm64_l_304);
arm64_l_2128:
	/* 0x2128: ldr x8, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_212c:
	/* 0x212c: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2130:
	/* 0x2130: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2134:
	/* 0x2134: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2138:
	/* 0x2138: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_213c:
	/* 0x213c: add x2, x8, #0x60 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_2140:
	/* 0x2140: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2144:
	/* 0x2144: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2148ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2148:
	/* 0x2148: tbnz w0, #31, 2198 <generic_retkprobe_event+0x2198> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2148, 0x2198, arm64_l_2198);
arm64_l_214c:
	/* 0x214c: ldr x8, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_2150:
	/* 0x2150: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2154:
	/* 0x2154: csel x9, x8, x22, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X9, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_2158:
	/* 0x2158: cmp x22, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_215c:
	/* 0x215c: csel x22, x8, x9, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X22, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_EQ, 0);
arm64_l_2160:
	/* 0x2160: cmp x22, #0xffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4094ULL);
arm64_l_2164:
	/* 0x2164: b.hi 16f4 <generic_retkprobe_event+0x16f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2164, 0x16f4, arm64_l_16f4);
arm64_l_2168:
	/* 0x2168: ldr x9, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_216c:
	/* 0x216c: add x8, x24, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X24, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2170:
	/* 0x2170: mov w1, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2174:
	/* 0x2174: and x8, x8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_2178:
	/* 0x2178: add x0, x9, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_217c:
	/* 0x217c: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_2180:
	/* 0x2180: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2184:
	/* 0x2184: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_2188:
	/* 0x2188: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x218cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_218c:
	/* 0x218c: tbnz w0, #31, 2198 <generic_retkprobe_event+0x2198> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x218c, 0x2198, arm64_l_2198);
arm64_l_2190:
	/* 0x2190: add x29, x22, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X29, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2194:
	/* 0x2194: b 1e34 <generic_retkprobe_event+0x1e34> */
	ARM64_SIM_A64_JMP(0x2194, 0x1e34, arm64_l_1e34);
arm64_l_2198:
	/* 0x2198: mov w8, #0xfffffffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967294ULL);
arm64_l_219c:
	/* 0x219c: ldr x9, [sp, #264] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 264ULL);
arm64_l_21a0:
	/* 0x21a0: ldp x19, x29, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X19, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_21a4:
	/* 0x21a4: b 38c <generic_retkprobe_event+0x38c> */
	ARM64_SIM_A64_JMP(0x21a4, 0x38c, arm64_l_38c);
arm64_l_21a8:
	/* 0x21a8: ldrb w8, [x24, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_21ac:
	/* 0x21ac: lsl w8, w8, #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_21b0:
	/* 0x21b0: add w8, w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_21b4:
	/* 0x21b4: strh w8, [x24, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_21b8:
	/* 0x21b8: ldrh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_21bc:
	/* 0x21bc: add w9, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_21c0:
	/* 0x21c0: ldrb w8, [x24, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_21c4:
	/* 0x21c4: strh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_21c8:
	/* 0x21c8: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_21cc:
	/* 0x21cc: b.hi 2284 <generic_retkprobe_event+0x2284> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x21cc, 0x2284, arm64_l_2284);
arm64_l_21d0:
	/* 0x21d0: mov x19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 1ULL);
arm64_l_21d4:
	/* 0x21d4: mov w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_21d8:
	/* 0x21d8: movk x19, #0x1800, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 6144ULL);
arm64_l_21dc:
	/* 0x21dc: lsl x10, x10, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_21e0:
	/* 0x21e0: movk x19, #0x1008, lsl #48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 4104ULL);
arm64_l_21e4:
	/* 0x21e4: tst x10, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_21e8:
	/* 0x21e8: b.eq 2284 <generic_retkprobe_event+0x2284> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x21e8, 0x2284, arm64_l_2284);
arm64_l_21ec:
	/* 0x21ec: strb w8, [x24, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_21f0:
	/* 0x21f0: add x8, x23, w9, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X23, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_21f4:
	/* 0x21f4: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_21f8:
	/* 0x21f8: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_21fc:
	/* 0x21fc: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2200:
	/* 0x2200: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2204:
	/* 0x2204: ldrh w8, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2208:
	/* 0x2208: add x2, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_220c:
	/* 0x220c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2210ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2210:
	/* 0x2210: tbnz x0, #63, 270c <generic_retkprobe_event+0x270c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x2210, 0x270c, arm64_l_270c);
arm64_l_2214:
	/* 0x2214: ldrb w8, [x24, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2218:
	/* 0x2218: cmp w8, #0x32; 0x221c: b.gt 223c <generic_retkprobe_event+0x223c> */
arm64_l_221c:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50ULL, arm64_l_223c);
arm64_l_2220:
	/* 0x2220: cbz w8, 225c <generic_retkprobe_event+0x225c> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x2220, 0x225c, arm64_l_225c);
arm64_l_2224:
	/* 0x2224: cmp w8, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_2228:
	/* 0x2228: b.eq 225c <generic_retkprobe_event+0x225c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2228, 0x225c, arm64_l_225c);
arm64_l_222c:
	/* 0x222c: cmp w8, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_2230:
	/* 0x2230: b.ne 2340 <generic_retkprobe_event+0x2340> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2230, 0x2340, arm64_l_2340);
arm64_l_2234:
	/* 0x2234: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2238:
	/* 0x2238: b 2298 <generic_retkprobe_event+0x2298> */
	ARM64_SIM_A64_JMP(0x2238, 0x2298, arm64_l_2298);
arm64_l_223c:
	/* 0x223c: cmp w8, #0x33 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 51ULL);
arm64_l_2240:
	/* 0x2240: b.eq 228c <generic_retkprobe_event+0x228c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2240, 0x228c, arm64_l_228c);
arm64_l_2244:
	/* 0x2244: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2248:
	/* 0x2248: b.eq 225c <generic_retkprobe_event+0x225c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2248, 0x225c, arm64_l_225c);
arm64_l_224c:
	/* 0x224c: cmp w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_2250:
	/* 0x2250: b.ne 2340 <generic_retkprobe_event+0x2340> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2250, 0x2340, arm64_l_2340);
arm64_l_2254:
	/* 0x2254: mov w8, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 40ULL);
arm64_l_2258:
	/* 0x2258: b 2298 <generic_retkprobe_event+0x2298> */
	ARM64_SIM_A64_JMP(0x2258, 0x2298, arm64_l_2298);
arm64_l_225c:
	/* 0x225c: ldrb w8, [x24, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_2260:
	/* 0x2260: lsl w8, w8, #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_2264:
	/* 0x2264: b 2294 <generic_retkprobe_event+0x2294> */
	ARM64_SIM_A64_JMP(0x2264, 0x2294, arm64_l_2294);
arm64_l_2268:
	/* 0x2268: ldrh w8, [x24, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_226c:
	/* 0x226c: ldrh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2270:
	/* 0x2270: add w9, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2274:
	/* 0x2274: ldrb w8, [x24, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_2278:
	/* 0x2278: strh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_227c:
	/* 0x227c: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2280:
	/* 0x2280: b.ls 21d0 <generic_retkprobe_event+0x21d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2280, 0x21d0, arm64_l_21d0);
arm64_l_2284:
	/* 0x2284: strh w9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2288:
	/* 0x2288: b 2710 <generic_retkprobe_event+0x2710> */
	ARM64_SIM_A64_JMP(0x2288, 0x2710, arm64_l_2710);
arm64_l_228c:
	/* 0x228c: ldrb w8, [x24, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_2290:
	/* 0x2290: lsl w8, w8, #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_2294:
	/* 0x2294: add w8, w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2298:
	/* 0x2298: strh w8, [x24, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_229c:
	/* 0x229c: ldrh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_22a0:
	/* 0x22a0: add w9, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_22a4:
	/* 0x22a4: ldrb w8, [x24, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_22a8:
	/* 0x22a8: strh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_22ac:
	/* 0x22ac: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_22b0:
	/* 0x22b0: b.hi 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x22b0, 0x28bc, arm64_l_28bc);
arm64_l_22b4:
	/* 0x22b4: mov w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_22b8:
	/* 0x22b8: lsl x10, x10, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_22bc:
	/* 0x22bc: tst x10, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_22c0:
	/* 0x22c0: b.eq 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x22c0, 0x28bc, arm64_l_28bc);
arm64_l_22c4:
	/* 0x22c4: strb w8, [x24, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_22c8:
	/* 0x22c8: add x8, x23, w9, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X23, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_22cc:
	/* 0x22cc: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_22d0:
	/* 0x22d0: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_22d4:
	/* 0x22d4: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_22d8:
	/* 0x22d8: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_22dc:
	/* 0x22dc: ldrh w8, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_22e0:
	/* 0x22e0: add x2, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_22e4:
	/* 0x22e4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x22e8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_22e8:
	/* 0x22e8: tbnz x0, #63, 270c <generic_retkprobe_event+0x270c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x22e8, 0x270c, arm64_l_270c);
arm64_l_22ec:
	/* 0x22ec: ldrb w8, [x24, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_22f0:
	/* 0x22f0: cmp w8, #0x32; 0x22f4: b.gt 2314 <generic_retkprobe_event+0x2314> */
arm64_l_22f4:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50ULL, arm64_l_2314);
arm64_l_22f8:
	/* 0x22f8: cbz w8, 2334 <generic_retkprobe_event+0x2334> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x22f8, 0x2334, arm64_l_2334);
arm64_l_22fc:
	/* 0x22fc: cmp w8, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_2300:
	/* 0x2300: b.eq 2334 <generic_retkprobe_event+0x2334> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2300, 0x2334, arm64_l_2334);
arm64_l_2304:
	/* 0x2304: cmp w8, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_2308:
	/* 0x2308: b.ne 2414 <generic_retkprobe_event+0x2414> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2308, 0x2414, arm64_l_2414);
arm64_l_230c:
	/* 0x230c: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2310:
	/* 0x2310: b 236c <generic_retkprobe_event+0x236c> */
	ARM64_SIM_A64_JMP(0x2310, 0x236c, arm64_l_236c);
arm64_l_2314:
	/* 0x2314: cmp w8, #0x33 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 51ULL);
arm64_l_2318:
	/* 0x2318: b.eq 2360 <generic_retkprobe_event+0x2360> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2318, 0x2360, arm64_l_2360);
arm64_l_231c:
	/* 0x231c: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2320:
	/* 0x2320: b.eq 2334 <generic_retkprobe_event+0x2334> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2320, 0x2334, arm64_l_2334);
arm64_l_2324:
	/* 0x2324: cmp w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_2328:
	/* 0x2328: b.ne 2414 <generic_retkprobe_event+0x2414> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2328, 0x2414, arm64_l_2414);
arm64_l_232c:
	/* 0x232c: mov w8, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 40ULL);
arm64_l_2330:
	/* 0x2330: b 236c <generic_retkprobe_event+0x236c> */
	ARM64_SIM_A64_JMP(0x2330, 0x236c, arm64_l_236c);
arm64_l_2334:
	/* 0x2334: ldrb w8, [x24, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_2338:
	/* 0x2338: lsl w8, w8, #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_233c:
	/* 0x233c: b 2368 <generic_retkprobe_event+0x2368> */
	ARM64_SIM_A64_JMP(0x233c, 0x2368, arm64_l_2368);
arm64_l_2340:
	/* 0x2340: ldrh w8, [x24, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_2344:
	/* 0x2344: ldrh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2348:
	/* 0x2348: add w9, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_234c:
	/* 0x234c: ldrb w8, [x24, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_2350:
	/* 0x2350: strh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2354:
	/* 0x2354: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2358:
	/* 0x2358: b.ls 22b4 <generic_retkprobe_event+0x22b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2358, 0x22b4, arm64_l_22b4);
arm64_l_235c:
	/* 0x235c: b 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JMP(0x235c, 0x28bc, arm64_l_28bc);
arm64_l_2360:
	/* 0x2360: ldrb w8, [x24, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_2364:
	/* 0x2364: lsl w8, w8, #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_2368:
	/* 0x2368: add w8, w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_236c:
	/* 0x236c: strh w8, [x24, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_2370:
	/* 0x2370: ldrh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2374:
	/* 0x2374: add w9, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2378:
	/* 0x2378: ldrb w8, [x24, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_237c:
	/* 0x237c: strh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2380:
	/* 0x2380: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2384:
	/* 0x2384: b.hi 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2384, 0x28bc, arm64_l_28bc);
arm64_l_2388:
	/* 0x2388: mov w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_238c:
	/* 0x238c: lsl x10, x10, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2390:
	/* 0x2390: tst x10, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2394:
	/* 0x2394: b.eq 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2394, 0x28bc, arm64_l_28bc);
arm64_l_2398:
	/* 0x2398: strb w8, [x24, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_239c:
	/* 0x239c: add x8, x23, w9, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X23, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_23a0:
	/* 0x23a0: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_23a4:
	/* 0x23a4: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_23a8:
	/* 0x23a8: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_23ac:
	/* 0x23ac: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_23b0:
	/* 0x23b0: ldrh w8, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_23b4:
	/* 0x23b4: add x2, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_23b8:
	/* 0x23b8: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x23bcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_23bc:
	/* 0x23bc: tbnz x0, #63, 270c <generic_retkprobe_event+0x270c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x23bc, 0x270c, arm64_l_270c);
arm64_l_23c0:
	/* 0x23c0: ldrb w8, [x24, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_23c4:
	/* 0x23c4: cmp w8, #0x32; 0x23c8: b.gt 23e8 <generic_retkprobe_event+0x23e8> */
arm64_l_23c8:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50ULL, arm64_l_23e8);
arm64_l_23cc:
	/* 0x23cc: cbz w8, 2408 <generic_retkprobe_event+0x2408> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x23cc, 0x2408, arm64_l_2408);
arm64_l_23d0:
	/* 0x23d0: cmp w8, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_23d4:
	/* 0x23d4: b.eq 2408 <generic_retkprobe_event+0x2408> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x23d4, 0x2408, arm64_l_2408);
arm64_l_23d8:
	/* 0x23d8: cmp w8, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_23dc:
	/* 0x23dc: b.ne 24e8 <generic_retkprobe_event+0x24e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x23dc, 0x24e8, arm64_l_24e8);
arm64_l_23e0:
	/* 0x23e0: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_23e4:
	/* 0x23e4: b 2440 <generic_retkprobe_event+0x2440> */
	ARM64_SIM_A64_JMP(0x23e4, 0x2440, arm64_l_2440);
arm64_l_23e8:
	/* 0x23e8: cmp w8, #0x33 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 51ULL);
arm64_l_23ec:
	/* 0x23ec: b.eq 2434 <generic_retkprobe_event+0x2434> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x23ec, 0x2434, arm64_l_2434);
arm64_l_23f0:
	/* 0x23f0: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_23f4:
	/* 0x23f4: b.eq 2408 <generic_retkprobe_event+0x2408> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x23f4, 0x2408, arm64_l_2408);
arm64_l_23f8:
	/* 0x23f8: cmp w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_23fc:
	/* 0x23fc: b.ne 24e8 <generic_retkprobe_event+0x24e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x23fc, 0x24e8, arm64_l_24e8);
arm64_l_2400:
	/* 0x2400: mov w8, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 40ULL);
arm64_l_2404:
	/* 0x2404: b 2440 <generic_retkprobe_event+0x2440> */
	ARM64_SIM_A64_JMP(0x2404, 0x2440, arm64_l_2440);
arm64_l_2408:
	/* 0x2408: ldrb w8, [x24, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_240c:
	/* 0x240c: lsl w8, w8, #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_2410:
	/* 0x2410: b 243c <generic_retkprobe_event+0x243c> */
	ARM64_SIM_A64_JMP(0x2410, 0x243c, arm64_l_243c);
arm64_l_2414:
	/* 0x2414: ldrh w8, [x24, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_2418:
	/* 0x2418: ldrh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_241c:
	/* 0x241c: add w9, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2420:
	/* 0x2420: ldrb w8, [x24, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_2424:
	/* 0x2424: strh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2428:
	/* 0x2428: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_242c:
	/* 0x242c: b.ls 2388 <generic_retkprobe_event+0x2388> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x242c, 0x2388, arm64_l_2388);
arm64_l_2430:
	/* 0x2430: b 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JMP(0x2430, 0x28bc, arm64_l_28bc);
arm64_l_2434:
	/* 0x2434: ldrb w8, [x24, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_2438:
	/* 0x2438: lsl w8, w8, #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_243c:
	/* 0x243c: add w8, w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2440:
	/* 0x2440: strh w8, [x24, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_2444:
	/* 0x2444: ldrh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2448:
	/* 0x2448: add w9, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_244c:
	/* 0x244c: ldrb w8, [x24, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_2450:
	/* 0x2450: strh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2454:
	/* 0x2454: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2458:
	/* 0x2458: b.hi 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2458, 0x28bc, arm64_l_28bc);
arm64_l_245c:
	/* 0x245c: mov w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2460:
	/* 0x2460: lsl x10, x10, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2464:
	/* 0x2464: tst x10, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2468:
	/* 0x2468: b.eq 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2468, 0x28bc, arm64_l_28bc);
arm64_l_246c:
	/* 0x246c: strb w8, [x24, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2470:
	/* 0x2470: add x8, x23, w9, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X23, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_2474:
	/* 0x2474: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2478:
	/* 0x2478: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_247c:
	/* 0x247c: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2480:
	/* 0x2480: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2484:
	/* 0x2484: ldrh w8, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2488:
	/* 0x2488: add x2, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_248c:
	/* 0x248c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2490ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2490:
	/* 0x2490: tbnz x0, #63, 270c <generic_retkprobe_event+0x270c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x2490, 0x270c, arm64_l_270c);
arm64_l_2494:
	/* 0x2494: ldrb w8, [x24, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2498:
	/* 0x2498: cmp w8, #0x32; 0x249c: b.gt 24bc <generic_retkprobe_event+0x24bc> */
arm64_l_249c:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50ULL, arm64_l_24bc);
arm64_l_24a0:
	/* 0x24a0: cbz w8, 24dc <generic_retkprobe_event+0x24dc> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x24a0, 0x24dc, arm64_l_24dc);
arm64_l_24a4:
	/* 0x24a4: cmp w8, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_24a8:
	/* 0x24a8: b.eq 24dc <generic_retkprobe_event+0x24dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x24a8, 0x24dc, arm64_l_24dc);
arm64_l_24ac:
	/* 0x24ac: cmp w8, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_24b0:
	/* 0x24b0: b.ne 25bc <generic_retkprobe_event+0x25bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x24b0, 0x25bc, arm64_l_25bc);
arm64_l_24b4:
	/* 0x24b4: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_24b8:
	/* 0x24b8: b 2514 <generic_retkprobe_event+0x2514> */
	ARM64_SIM_A64_JMP(0x24b8, 0x2514, arm64_l_2514);
arm64_l_24bc:
	/* 0x24bc: cmp w8, #0x33 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 51ULL);
arm64_l_24c0:
	/* 0x24c0: b.eq 2508 <generic_retkprobe_event+0x2508> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x24c0, 0x2508, arm64_l_2508);
arm64_l_24c4:
	/* 0x24c4: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_24c8:
	/* 0x24c8: b.eq 24dc <generic_retkprobe_event+0x24dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x24c8, 0x24dc, arm64_l_24dc);
arm64_l_24cc:
	/* 0x24cc: cmp w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_24d0:
	/* 0x24d0: b.ne 25bc <generic_retkprobe_event+0x25bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x24d0, 0x25bc, arm64_l_25bc);
arm64_l_24d4:
	/* 0x24d4: mov w8, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 40ULL);
arm64_l_24d8:
	/* 0x24d8: b 2514 <generic_retkprobe_event+0x2514> */
	ARM64_SIM_A64_JMP(0x24d8, 0x2514, arm64_l_2514);
arm64_l_24dc:
	/* 0x24dc: ldrb w8, [x24, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_24e0:
	/* 0x24e0: lsl w8, w8, #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_24e4:
	/* 0x24e4: b 2510 <generic_retkprobe_event+0x2510> */
	ARM64_SIM_A64_JMP(0x24e4, 0x2510, arm64_l_2510);
arm64_l_24e8:
	/* 0x24e8: ldrh w8, [x24, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_24ec:
	/* 0x24ec: ldrh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_24f0:
	/* 0x24f0: add w9, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_24f4:
	/* 0x24f4: ldrb w8, [x24, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_24f8:
	/* 0x24f8: strh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_24fc:
	/* 0x24fc: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2500:
	/* 0x2500: b.ls 245c <generic_retkprobe_event+0x245c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2500, 0x245c, arm64_l_245c);
arm64_l_2504:
	/* 0x2504: b 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JMP(0x2504, 0x28bc, arm64_l_28bc);
arm64_l_2508:
	/* 0x2508: ldrb w8, [x24, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_250c:
	/* 0x250c: lsl w8, w8, #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_2510:
	/* 0x2510: add w8, w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2514:
	/* 0x2514: strh w8, [x24, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_2518:
	/* 0x2518: ldrh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_251c:
	/* 0x251c: add w9, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2520:
	/* 0x2520: ldrb w8, [x24, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_2524:
	/* 0x2524: strh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2528:
	/* 0x2528: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_252c:
	/* 0x252c: b.hi 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x252c, 0x28bc, arm64_l_28bc);
arm64_l_2530:
	/* 0x2530: mov w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2534:
	/* 0x2534: lsl x10, x10, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2538:
	/* 0x2538: tst x10, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_253c:
	/* 0x253c: b.eq 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x253c, 0x28bc, arm64_l_28bc);
arm64_l_2540:
	/* 0x2540: strb w8, [x24, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2544:
	/* 0x2544: add x8, x23, w9, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X23, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_2548:
	/* 0x2548: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_254c:
	/* 0x254c: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2550:
	/* 0x2550: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2554:
	/* 0x2554: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2558:
	/* 0x2558: ldrh w8, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_255c:
	/* 0x255c: add x2, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2560:
	/* 0x2560: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2564ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2564:
	/* 0x2564: tbnz x0, #63, 270c <generic_retkprobe_event+0x270c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x2564, 0x270c, arm64_l_270c);
arm64_l_2568:
	/* 0x2568: ldrb w8, [x24, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_256c:
	/* 0x256c: cmp w8, #0x32; 0x2570: b.gt 2590 <generic_retkprobe_event+0x2590> */
arm64_l_2570:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50ULL, arm64_l_2590);
arm64_l_2574:
	/* 0x2574: cbz w8, 25b0 <generic_retkprobe_event+0x25b0> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x2574, 0x25b0, arm64_l_25b0);
arm64_l_2578:
	/* 0x2578: cmp w8, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_257c:
	/* 0x257c: b.eq 25b0 <generic_retkprobe_event+0x25b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x257c, 0x25b0, arm64_l_25b0);
arm64_l_2580:
	/* 0x2580: cmp w8, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_2584:
	/* 0x2584: b.ne 2690 <generic_retkprobe_event+0x2690> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2584, 0x2690, arm64_l_2690);
arm64_l_2588:
	/* 0x2588: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_258c:
	/* 0x258c: b 25e8 <generic_retkprobe_event+0x25e8> */
	ARM64_SIM_A64_JMP(0x258c, 0x25e8, arm64_l_25e8);
arm64_l_2590:
	/* 0x2590: cmp w8, #0x33 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 51ULL);
arm64_l_2594:
	/* 0x2594: b.eq 25dc <generic_retkprobe_event+0x25dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2594, 0x25dc, arm64_l_25dc);
arm64_l_2598:
	/* 0x2598: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_259c:
	/* 0x259c: b.eq 25b0 <generic_retkprobe_event+0x25b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x259c, 0x25b0, arm64_l_25b0);
arm64_l_25a0:
	/* 0x25a0: cmp w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_25a4:
	/* 0x25a4: b.ne 2690 <generic_retkprobe_event+0x2690> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x25a4, 0x2690, arm64_l_2690);
arm64_l_25a8:
	/* 0x25a8: mov w8, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 40ULL);
arm64_l_25ac:
	/* 0x25ac: b 25e8 <generic_retkprobe_event+0x25e8> */
	ARM64_SIM_A64_JMP(0x25ac, 0x25e8, arm64_l_25e8);
arm64_l_25b0:
	/* 0x25b0: ldrb w8, [x24, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_25b4:
	/* 0x25b4: lsl w8, w8, #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_25b8:
	/* 0x25b8: b 25e4 <generic_retkprobe_event+0x25e4> */
	ARM64_SIM_A64_JMP(0x25b8, 0x25e4, arm64_l_25e4);
arm64_l_25bc:
	/* 0x25bc: ldrh w8, [x24, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_25c0:
	/* 0x25c0: ldrh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_25c4:
	/* 0x25c4: add w9, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_25c8:
	/* 0x25c8: ldrb w8, [x24, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_25cc:
	/* 0x25cc: strh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_25d0:
	/* 0x25d0: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_25d4:
	/* 0x25d4: b.ls 2530 <generic_retkprobe_event+0x2530> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x25d4, 0x2530, arm64_l_2530);
arm64_l_25d8:
	/* 0x25d8: b 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JMP(0x25d8, 0x28bc, arm64_l_28bc);
arm64_l_25dc:
	/* 0x25dc: ldrb w8, [x24, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_25e0:
	/* 0x25e0: lsl w8, w8, #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_25e4:
	/* 0x25e4: add w8, w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_25e8:
	/* 0x25e8: strh w8, [x24, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_25ec:
	/* 0x25ec: ldrh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_25f0:
	/* 0x25f0: add w9, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_25f4:
	/* 0x25f4: ldrb w8, [x24, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_25f8:
	/* 0x25f8: strh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_25fc:
	/* 0x25fc: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2600:
	/* 0x2600: b.hi 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2600, 0x28bc, arm64_l_28bc);
arm64_l_2604:
	/* 0x2604: mov w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2608:
	/* 0x2608: lsl x10, x10, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_260c:
	/* 0x260c: tst x10, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2610:
	/* 0x2610: b.eq 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2610, 0x28bc, arm64_l_28bc);
arm64_l_2614:
	/* 0x2614: strb w8, [x24, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2618:
	/* 0x2618: add x8, x23, w9, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X23, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_261c:
	/* 0x261c: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2620:
	/* 0x2620: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2624:
	/* 0x2624: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2628:
	/* 0x2628: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_262c:
	/* 0x262c: ldrh w8, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2630:
	/* 0x2630: add x2, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2634:
	/* 0x2634: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2638ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2638:
	/* 0x2638: tbnz x0, #63, 270c <generic_retkprobe_event+0x270c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x2638, 0x270c, arm64_l_270c);
arm64_l_263c:
	/* 0x263c: ldrb w8, [x24, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2640:
	/* 0x2640: cmp w8, #0x32; 0x2644: b.gt 2664 <generic_retkprobe_event+0x2664> */
arm64_l_2644:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50ULL, arm64_l_2664);
arm64_l_2648:
	/* 0x2648: cbz w8, 2684 <generic_retkprobe_event+0x2684> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x2648, 0x2684, arm64_l_2684);
arm64_l_264c:
	/* 0x264c: cmp w8, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_2650:
	/* 0x2650: b.eq 2684 <generic_retkprobe_event+0x2684> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2650, 0x2684, arm64_l_2684);
arm64_l_2654:
	/* 0x2654: cmp w8, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_2658:
	/* 0x2658: b.ne 28a0 <generic_retkprobe_event+0x28a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2658, 0x28a0, arm64_l_28a0);
arm64_l_265c:
	/* 0x265c: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2660:
	/* 0x2660: b 26bc <generic_retkprobe_event+0x26bc> */
	ARM64_SIM_A64_JMP(0x2660, 0x26bc, arm64_l_26bc);
arm64_l_2664:
	/* 0x2664: cmp w8, #0x33 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 51ULL);
arm64_l_2668:
	/* 0x2668: b.eq 26b0 <generic_retkprobe_event+0x26b0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2668, 0x26b0, arm64_l_26b0);
arm64_l_266c:
	/* 0x266c: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2670:
	/* 0x2670: b.eq 2684 <generic_retkprobe_event+0x2684> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2670, 0x2684, arm64_l_2684);
arm64_l_2674:
	/* 0x2674: cmp w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_2678:
	/* 0x2678: b.ne 28a0 <generic_retkprobe_event+0x28a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2678, 0x28a0, arm64_l_28a0);
arm64_l_267c:
	/* 0x267c: mov w8, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 40ULL);
arm64_l_2680:
	/* 0x2680: b 26bc <generic_retkprobe_event+0x26bc> */
	ARM64_SIM_A64_JMP(0x2680, 0x26bc, arm64_l_26bc);
arm64_l_2684:
	/* 0x2684: ldrb w8, [x24, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_2688:
	/* 0x2688: lsl w8, w8, #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_268c:
	/* 0x268c: b 26b8 <generic_retkprobe_event+0x26b8> */
	ARM64_SIM_A64_JMP(0x268c, 0x26b8, arm64_l_26b8);
arm64_l_2690:
	/* 0x2690: ldrh w8, [x24, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_2694:
	/* 0x2694: ldrh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2698:
	/* 0x2698: add w9, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_269c:
	/* 0x269c: ldrb w8, [x24, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_26a0:
	/* 0x26a0: strh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_26a4:
	/* 0x26a4: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_26a8:
	/* 0x26a8: b.ls 2604 <generic_retkprobe_event+0x2604> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x26a8, 0x2604, arm64_l_2604);
arm64_l_26ac:
	/* 0x26ac: b 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JMP(0x26ac, 0x28bc, arm64_l_28bc);
arm64_l_26b0:
	/* 0x26b0: ldrb w8, [x24, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_26b4:
	/* 0x26b4: lsl w8, w8, #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_26b8:
	/* 0x26b8: add w8, w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_26bc:
	/* 0x26bc: strh w8, [x24, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_26c0:
	/* 0x26c0: ldrh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_26c4:
	/* 0x26c4: add w9, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_26c8:
	/* 0x26c8: ldrb w8, [x24, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_26cc:
	/* 0x26cc: strh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_26d0:
	/* 0x26d0: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_26d4:
	/* 0x26d4: b.hi 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x26d4, 0x28bc, arm64_l_28bc);
arm64_l_26d8:
	/* 0x26d8: mov w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_26dc:
	/* 0x26dc: lsl x10, x10, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X10, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_26e0:
	/* 0x26e0: tst x10, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X10, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26e4:
	/* 0x26e4: b.eq 28bc <generic_retkprobe_event+0x28bc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x26e4, 0x28bc, arm64_l_28bc);
arm64_l_26e8:
	/* 0x26e8: strb w8, [x24, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_26ec:
	/* 0x26ec: add x8, x23, w9, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X23, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_26f0:
	/* 0x26f0: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_26f4:
	/* 0x26f4: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_26f8:
	/* 0x26f8: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_26fc:
	/* 0x26fc: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2700:
	/* 0x2700: ldrh w8, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2704:
	/* 0x2704: add x2, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2708:
	/* 0x2708: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x270cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_270c:
	/* 0x270c: mov w8, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2710:
	/* 0x2710: ldr x21, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2714:
	/* 0x2714: strb w8, [sp, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_2718:
	/* 0x2718: add x2, x22, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_271c:
	/* 0x271c: mov w23, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2720:
	/* 0x2720: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2724:
	/* 0x2724: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2728:
	/* 0x2728: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_272c:
	/* 0x272c: strh w8, [x21, #192] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_2730:
	/* 0x2730: mov w8, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_2734:
	/* 0x2734: strh w8, [x21, #194] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 194ULL);
arm64_l_2738:
	/* 0x2738: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_273c:
	/* 0x273c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2740ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2740:
	/* 0x2740: add x0, x21, #0xac */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 172ULL);
arm64_l_2744:
	/* 0x2744: add x2, x22, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_2748:
	/* 0x2748: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_274c:
	/* 0x274c: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2750ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2750:
	/* 0x2750: ldrb w8, [sp, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_2754:
	/* 0x2754: cmp w8, #0x11 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2758:
	/* 0x2758: b.eq 279c <generic_retkprobe_event+0x279c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2758, 0x279c, arm64_l_279c);
arm64_l_275c:
	/* 0x275c: cmp w8, #0x6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2760:
	/* 0x2760: b.ne 27dc <generic_retkprobe_event+0x27dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2760, 0x27dc, arm64_l_27dc);
arm64_l_2764:
	/* 0x2764: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_2768:
	/* 0x2768: ldrh w9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_276c:
	/* 0x276c: mov w23, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2770:
	/* 0x2770: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2774:
	/* 0x2774: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2778:
	/* 0x2778: add x22, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_277c:
	/* 0x277c: ldr x21, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2780:
	/* 0x2780: add x0, x21, #0xbc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 188ULL);
arm64_l_2784:
	/* 0x2784: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2788:
	/* 0x2788: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_278c:
	/* 0x278c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2790ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2790:
	/* 0x2790: add x0, x21, #0xbe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 190ULL);
arm64_l_2794:
	/* 0x2794: add x2, x22, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2798:
	/* 0x2798: b 27d0 <generic_retkprobe_event+0x27d0> */
	ARM64_SIM_A64_JMP(0x2798, 0x27d0, arm64_l_27d0);
arm64_l_279c:
	/* 0x279c: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_27a0:
	/* 0x27a0: ldrh w9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_27a4:
	/* 0x27a4: mov w23, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_27a8:
	/* 0x27a8: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_27ac:
	/* 0x27ac: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_27b0:
	/* 0x27b0: add x22, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_27b4:
	/* 0x27b4: ldr x21, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_27b8:
	/* 0x27b8: add x0, x21, #0xbc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 188ULL);
arm64_l_27bc:
	/* 0x27bc: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_27c0:
	/* 0x27c0: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_27c4:
	/* 0x27c4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x27c8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_27c8:
	/* 0x27c8: add x0, x21, #0xbe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 190ULL);
arm64_l_27cc:
	/* 0x27cc: add x2, x22, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_27d0:
	/* 0x27d0: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_27d4:
	/* 0x27d4: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x27d8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_27d8:
	/* 0x27d8: b 27e4 <generic_retkprobe_event+0x27e4> */
	ARM64_SIM_A64_JMP(0x27d8, 0x27e4, arm64_l_27e4);
arm64_l_27dc:
	/* 0x27dc: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_27e0:
	/* 0x27e0: str wzr, [x8, #188] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 188ULL);
arm64_l_27e4:
	/* 0x27e4: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_27e8:
	/* 0x27e8: add x2, x29, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_27ec:
	/* 0x27ec: add x10, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_27f0:
	/* 0x27f0: add x0, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_27f4:
	/* 0x27f4: ldrh w9, [x8, #188] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 188ULL);
arm64_l_27f8:
	/* 0x27f8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_27fc:
	/* 0x27fc: rev w9, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_REV, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2800:
	/* 0x2800: lsr w9, w9, #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 16ULL);
arm64_l_2804:
	/* 0x2804: strh w9, [x8, #188] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 188ULL);
arm64_l_2808:
	/* 0x2808: ldrh w9, [x8, #190] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 190ULL);
arm64_l_280c:
	/* 0x280c: rev w9, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_REV, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2810:
	/* 0x2810: lsr w9, w9, #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 16ULL);
arm64_l_2814:
	/* 0x2814: strh w9, [x8, #190] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 190ULL);
arm64_l_2818:
	/* 0x2818: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_281c:
	/* 0x281c: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2820:
	/* 0x2820: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2824ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2824:
	/* 0x2824: add x19, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_2828:
	/* 0x2828: ldr x8, [x19, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_282c:
	/* 0x282c: cbz x8, 288c <generic_retkprobe_event+0x288c> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x282c, 0x288c, arm64_l_288c);
arm64_l_2830:
	/* 0x2830: add x8, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2834:
	/* 0x2834: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2838:
	/* 0x2838: add x10, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_283c:
	/* 0x283c: mov w11, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2840:
	/* 0x2840: ldr x8, [x19, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2844:
	/* 0x2844: add x0, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_2848:
	/* 0x2848: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_284c:
	/* 0x284c: mov w21, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2850:
	/* 0x2850: add x2, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2854:
	/* 0x2854: blr x11 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X11);
		if (ARM64_SIM_L_REG_TAG(ARM64_X11) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2858ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2858:
	/* 0x2858: ldr x8, [x19, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_285c:
	/* 0x285c: ldr x9, [sp, #112] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_2860:
	/* 0x2860: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2864:
	/* 0x2864: add x22, x8, x9, lsl #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 3), 0);
arm64_l_2868:
	/* 0x2868: ldr x23, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_286c:
	/* 0x286c: add x0, x23, #0xd4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 212ULL);
arm64_l_2870:
	/* 0x2870: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2874:
	/* 0x2874: add x2, x22, #0x44 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 68ULL);
arm64_l_2878:
	/* 0x2878: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x287cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_287c:
	/* 0x287c: add x0, x23, #0xd8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_2880:
	/* 0x2880: add x2, x22, #0x45 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 69ULL);
arm64_l_2884:
	/* 0x2884: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2888:
	/* 0x2888: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x288cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_288c:
	/* 0x288c: ldr x19, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_2890:
	/* 0x2890: ldr x29, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_2894:
	/* 0x2894: ldr w21, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_2898:
	/* 0x2898: mov w25, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 64ULL);
arm64_l_289c:
	/* 0x289c: b cb4 <generic_retkprobe_event+0xcb4> */
	ARM64_SIM_A64_JMP(0x289c, 0xcb4, arm64_l_cb4);
arm64_l_28a0:
	/* 0x28a0: ldrh w8, [x24, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_28a4:
	/* 0x28a4: ldrh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_28a8:
	/* 0x28a8: add w9, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_28ac:
	/* 0x28ac: ldrb w8, [x24, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_28b0:
	/* 0x28b0: strh w9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_28b4:
	/* 0x28b4: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_28b8:
	/* 0x28b8: b.ls 26d8 <generic_retkprobe_event+0x26d8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x28b8, 0x26d8, arm64_l_26d8);
arm64_l_28bc:
	/* 0x28bc: strh w9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_28c0:
	/* 0x28c0: b 2710 <generic_retkprobe_event+0x2710> */
	ARM64_SIM_A64_JMP(0x28c0, 0x2710, arm64_l_2710);
arm64_l_28c4:
	/* 0x28c4: nop */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_28c8:
	/* 0x28c8: mov x7, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
