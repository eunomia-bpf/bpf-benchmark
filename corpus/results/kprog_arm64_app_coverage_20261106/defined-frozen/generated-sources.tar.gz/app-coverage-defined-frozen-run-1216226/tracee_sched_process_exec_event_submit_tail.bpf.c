extern char bufs;
extern char config_map;
extern char event_data_map;
extern char events;
extern char proc_info_map;
extern char stack_addresses;
extern char task_info_map;
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_RETURN_CASES \
	case 0x38ULL: goto arm64_l_38; \
	case 0x58ULL: goto arm64_l_58; \
	case 0x74ULL: goto arm64_l_74; \
	case 0x90ULL: goto arm64_l_90; \
	case 0xc4ULL: goto arm64_l_c4; \
	case 0xe0ULL: goto arm64_l_e0; \
	case 0x100ULL: goto arm64_l_100; \
	case 0x120ULL: goto arm64_l_120; \
	case 0x12cULL: goto arm64_l_12c; \
	case 0x158ULL: goto arm64_l_158; \
	case 0x174ULL: goto arm64_l_174; \
	case 0x18cULL: goto arm64_l_18c; \
	case 0x1acULL: goto arm64_l_1ac; \
	case 0x1d8ULL: goto arm64_l_1d8; \
	case 0x1f4ULL: goto arm64_l_1f4; \
	case 0x21cULL: goto arm64_l_21c; \
	case 0x248ULL: goto arm64_l_248; \
	case 0x268ULL: goto arm64_l_268; \
	case 0x290ULL: goto arm64_l_290; \
	case 0x2b4ULL: goto arm64_l_2b4; \
	case 0x2ccULL: goto arm64_l_2cc; \
	case 0x2e8ULL: goto arm64_l_2e8; \
	case 0x31cULL: goto arm64_l_31c; \
	case 0x340ULL: goto arm64_l_340; \
	case 0x388ULL: goto arm64_l_388; \
	case 0x3ccULL: goto arm64_l_3cc; \
	case 0x3e8ULL: goto arm64_l_3e8; \
	case 0x400ULL: goto arm64_l_400; \
	case 0x430ULL: goto arm64_l_430; \
	case 0x44cULL: goto arm64_l_44c; \
	case 0x480ULL: goto arm64_l_480; \
	case 0x4acULL: goto arm64_l_4ac; \
	case 0x508ULL: goto arm64_l_508; \
	case 0x520ULL: goto arm64_l_520; \
	case 0x55cULL: goto arm64_l_55c; \
	case 0x578ULL: goto arm64_l_578; \
	case 0x590ULL: goto arm64_l_590; \
	case 0x5b8ULL: goto arm64_l_5b8; \
	case 0x5d4ULL: goto arm64_l_5d4; \
	case 0x608ULL: goto arm64_l_608; \
	case 0x668ULL: goto arm64_l_668; \
	case 0x684ULL: goto arm64_l_684; \
	case 0x6a0ULL: goto arm64_l_6a0; \
	case 0x738ULL: goto arm64_l_738; \
	case 0x770ULL: goto arm64_l_770; \
	case 0x7b8ULL: goto arm64_l_7b8; \
	case 0x844ULL: goto arm64_l_844; \
	case 0x8d0ULL: goto arm64_l_8d0; \
	case 0x954ULL: goto arm64_l_954; \
	case 0x9dcULL: goto arm64_l_9dc; \
	case 0xa64ULL: goto arm64_l_a64; \
	case 0xad4ULL: goto arm64_l_ad4; \
	case 0xaf0ULL: goto arm64_l_af0; \
	case 0xb0cULL: goto arm64_l_b0c; \
	case 0xb84ULL: goto arm64_l_b84; \
	case 0xbbcULL: goto arm64_l_bbc; \
	case 0xc00ULL: goto arm64_l_c00; \
	case 0xc40ULL: goto arm64_l_c40; \
	case 0xc64ULL: goto arm64_l_c64; \
	case 0xc8cULL: goto arm64_l_c8c; \
	case 0xcacULL: goto arm64_l_cac; \
	case 0xcd4ULL: goto arm64_l_cd4; \
	case 0xcf8ULL: goto arm64_l_cf8; \
	case 0xd10ULL: goto arm64_l_d10; \
	case 0xd2cULL: goto arm64_l_d2c; \
	case 0xd60ULL: goto arm64_l_d60; \
	case 0xd84ULL: goto arm64_l_d84; \
	case 0xe14ULL: goto arm64_l_e14; \
	case 0xe30ULL: goto arm64_l_e30; \
	case 0xe48ULL: goto arm64_l_e48; \
	case 0xe74ULL: goto arm64_l_e74; \
	case 0xe90ULL: goto arm64_l_e90; \
	case 0xec4ULL: goto arm64_l_ec4; \
	case 0xeecULL: goto arm64_l_eec; \
	case 0xf40ULL: goto arm64_l_f40; \
	case 0xf58ULL: goto arm64_l_f58; \
	case 0xfbcULL: goto arm64_l_fbc; \
	case 0x103cULL: goto arm64_l_103c; \
	case 0x1058ULL: goto arm64_l_1058; \
	case 0x1070ULL: goto arm64_l_1070; \
	case 0x10b0ULL: goto arm64_l_10b0; \
	case 0x10ccULL: goto arm64_l_10cc; \
	case 0x10e4ULL: goto arm64_l_10e4; \
	case 0x110cULL: goto arm64_l_110c; \
	case 0x1128ULL: goto arm64_l_1128; \
	case 0x115cULL: goto arm64_l_115c; \
	case 0x11d0ULL: goto arm64_l_11d0; \
	case 0x11f0ULL: goto arm64_l_11f0; \
	case 0x120cULL: goto arm64_l_120c; \
	case 0x122cULL: goto arm64_l_122c; \
	case 0x1254ULL: goto arm64_l_1254; \
	case 0x1270ULL: goto arm64_l_1270; \
	case 0x1290ULL: goto arm64_l_1290; \
	case 0x12b0ULL: goto arm64_l_12b0; \
	case 0x12ccULL: goto arm64_l_12cc; \
	case 0x12e8ULL: goto arm64_l_12e8; \
	case 0x1308ULL: goto arm64_l_1308; \
	case 0x1328ULL: goto arm64_l_1328; \
	case 0x1344ULL: goto arm64_l_1344; \
	case 0x1364ULL: goto arm64_l_1364; \
	case 0x1380ULL: goto arm64_l_1380; \
	case 0x13a4ULL: goto arm64_l_13a4; \
	case 0x13c0ULL: goto arm64_l_13c0; \
	case 0x13e0ULL: goto arm64_l_13e0; \
	case 0x13fcULL: goto arm64_l_13fc; \
	case 0x1428ULL: goto arm64_l_1428; \
	case 0x1448ULL: goto arm64_l_1448; \
	case 0x1464ULL: goto arm64_l_1464; \
	case 0x1494ULL: goto arm64_l_1494; \
	case 0x14b0ULL: goto arm64_l_14b0; \
	case 0x14d0ULL: goto arm64_l_14d0; \
	case 0x14e0ULL: goto arm64_l_14e0; \
	case 0x14fcULL: goto arm64_l_14fc; \
	case 0x1520ULL: goto arm64_l_1520; \
	case 0x1544ULL: goto arm64_l_1544; \
	case 0x1560ULL: goto arm64_l_1560; \
	case 0x1594ULL: goto arm64_l_1594; \
	case 0x15b4ULL: goto arm64_l_15b4; \
	case 0x15ccULL: goto arm64_l_15cc; \
	case 0x15e8ULL: goto arm64_l_15e8; \
	case 0x15fcULL: goto arm64_l_15fc; \
	case 0x1610ULL: goto arm64_l_1610; \
	case 0x163cULL: goto arm64_l_163c; \
	case 0x167cULL: goto arm64_l_167c; \
	case 0x16d8ULL: goto arm64_l_16d8; \
	case 0x16f4ULL: goto arm64_l_16f4; \
	case 0x170cULL: goto arm64_l_170c; \
	case 0x172cULL: goto arm64_l_172c; \
	case 0x1770ULL: goto arm64_l_1770; \
	case 0x178cULL: goto arm64_l_178c; \
	case 0x17c0ULL: goto arm64_l_17c0; \
	case 0x17ecULL: goto arm64_l_17ec; \
	case 0x1828ULL: goto arm64_l_1828; \
	case 0x1868ULL: goto arm64_l_1868; \
	case 0x1884ULL: goto arm64_l_1884; \
	case 0x18b8ULL: goto arm64_l_18b8; \
	case 0x18e0ULL: goto arm64_l_18e0; \
	case 0x1940ULL: goto arm64_l_1940; \
	case 0x195cULL: goto arm64_l_195c; \
	case 0x1974ULL: goto arm64_l_1974; \
	case 0x199cULL: goto arm64_l_199c; \
	case 0x19b8ULL: goto arm64_l_19b8; \
	case 0x19ecULL: goto arm64_l_19ec; \
	case 0x1a18ULL: goto arm64_l_1a18; \
	case 0x1a7cULL: goto arm64_l_1a7c; \
	case 0x1a98ULL: goto arm64_l_1a98; \
	case 0x1ab0ULL: goto arm64_l_1ab0; \
	case 0x1ad8ULL: goto arm64_l_1ad8; \
	case 0x1af4ULL: goto arm64_l_1af4; \
	case 0x1b28ULL: goto arm64_l_1b28; \
	case 0x1b50ULL: goto arm64_l_1b50; \
	case 0x1bb0ULL: goto arm64_l_1bb0; \
	case 0x1bccULL: goto arm64_l_1bcc; \
	case 0x1be4ULL: goto arm64_l_1be4; \
	case 0x1c0cULL: goto arm64_l_1c0c; \
	case 0x1c28ULL: goto arm64_l_1c28; \
	case 0x1c5cULL: goto arm64_l_1c5c; \
	case 0x1c88ULL: goto arm64_l_1c88; \
	case 0x1cecULL: goto arm64_l_1cec; \
	case 0x1d08ULL: goto arm64_l_1d08; \
	case 0x1d20ULL: goto arm64_l_1d20; \
	case 0x1d48ULL: goto arm64_l_1d48; \
	case 0x1d64ULL: goto arm64_l_1d64; \
	case 0x1d98ULL: goto arm64_l_1d98; \
	case 0x1df0ULL: goto arm64_l_1df0; \
	case 0x1e0cULL: goto arm64_l_1e0c; \
	case 0x1e24ULL: goto arm64_l_1e24; \
	case 0x1e4cULL: goto arm64_l_1e4c; \
	case 0x1e68ULL: goto arm64_l_1e68; \
	case 0x1e9cULL: goto arm64_l_1e9c; \
	case 0x1ef8ULL: goto arm64_l_1ef8; \
	case 0x1f14ULL: goto arm64_l_1f14; \
	case 0x1f2cULL: goto arm64_l_1f2c; \
	case 0x1f4cULL: goto arm64_l_1f4c; \
	case 0x1f8cULL: goto arm64_l_1f8c; \
	case 0x1fa8ULL: goto arm64_l_1fa8; \
	case 0x1fdcULL: goto arm64_l_1fdc; \
	case 0x2004ULL: goto arm64_l_2004; \
	case 0x2064ULL: goto arm64_l_2064; \
	case 0x2080ULL: goto arm64_l_2080; \
	case 0x2098ULL: goto arm64_l_2098; \
	case 0x20c8ULL: goto arm64_l_20c8; \
	case 0x2110ULL: goto arm64_l_2110; \
	case 0x212cULL: goto arm64_l_212c; \
	case 0x2160ULL: goto arm64_l_2160; \
	case 0x218cULL: goto arm64_l_218c; \
	case 0x21f4ULL: goto arm64_l_21f4; \
	case 0x2210ULL: goto arm64_l_2210; \
	case 0x2228ULL: goto arm64_l_2228; \
	case 0x2250ULL: goto arm64_l_2250; \
	case 0x226cULL: goto arm64_l_226c; \
	case 0x22a0ULL: goto arm64_l_22a0; \
	case 0x22ccULL: goto arm64_l_22cc; \
	case 0x232cULL: goto arm64_l_232c; \
	case 0x2348ULL: goto arm64_l_2348; \
	case 0x2360ULL: goto arm64_l_2360; \
	case 0x2388ULL: goto arm64_l_2388; \
	case 0x23a4ULL: goto arm64_l_23a4; \
	case 0x23d8ULL: goto arm64_l_23d8; \
	case 0x2400ULL: goto arm64_l_2400; \
	case 0x2460ULL: goto arm64_l_2460; \
	case 0x247cULL: goto arm64_l_247c; \
	case 0x2494ULL: goto arm64_l_2494; \
	case 0x24bcULL: goto arm64_l_24bc; \
	case 0x24d8ULL: goto arm64_l_24d8; \
	case 0x250cULL: goto arm64_l_250c; \
	case 0x2534ULL: goto arm64_l_2534; \
	case 0x2594ULL: goto arm64_l_2594; \
	case 0x25b0ULL: goto arm64_l_25b0; \
	case 0x25c8ULL: goto arm64_l_25c8; \
	case 0x25f0ULL: goto arm64_l_25f0; \
	case 0x260cULL: goto arm64_l_260c; \
	case 0x2640ULL: goto arm64_l_2640; \
	case 0x266cULL: goto arm64_l_266c; \
	case 0x26d4ULL: goto arm64_l_26d4; \
	case 0x26f0ULL: goto arm64_l_26f0; \
	case 0x2708ULL: goto arm64_l_2708; \
	case 0x2730ULL: goto arm64_l_2730; \
	case 0x274cULL: goto arm64_l_274c; \
	case 0x2780ULL: goto arm64_l_2780; \
	case 0x27a8ULL: goto arm64_l_27a8; \
	case 0x2808ULL: goto arm64_l_2808; \
	case 0x2824ULL: goto arm64_l_2824; \
	case 0x283cULL: goto arm64_l_283c; \
	case 0x2864ULL: goto arm64_l_2864; \
	case 0x2880ULL: goto arm64_l_2880; \
	case 0x28b4ULL: goto arm64_l_28b4; \
	case 0x28e0ULL: goto arm64_l_28e0; \
	case 0x2948ULL: goto arm64_l_2948; \
	case 0x2964ULL: goto arm64_l_2964; \
	case 0x297cULL: goto arm64_l_297c; \
	case 0x29a4ULL: goto arm64_l_29a4; \
	case 0x29c0ULL: goto arm64_l_29c0; \
	case 0x29f4ULL: goto arm64_l_29f4; \
	case 0x2a1cULL: goto arm64_l_2a1c; \
	case 0x2a7cULL: goto arm64_l_2a7c; \
	case 0x2a98ULL: goto arm64_l_2a98; \
	case 0x2ab0ULL: goto arm64_l_2ab0; \
	case 0x2ad8ULL: goto arm64_l_2ad8; \
	case 0x2af4ULL: goto arm64_l_2af4; \
	case 0x2b28ULL: goto arm64_l_2b28; \
	case 0x2b54ULL: goto arm64_l_2b54; \
	case 0x2bbcULL: goto arm64_l_2bbc; \
	case 0x2bd8ULL: goto arm64_l_2bd8; \
	case 0x2bf0ULL: goto arm64_l_2bf0; \
	case 0x2c18ULL: goto arm64_l_2c18; \
	case 0x2c34ULL: goto arm64_l_2c34; \
	case 0x2c68ULL: goto arm64_l_2c68; \
	case 0x2c90ULL: goto arm64_l_2c90; \
	case 0x2cf0ULL: goto arm64_l_2cf0; \
	case 0x2d0cULL: goto arm64_l_2d0c; \
	case 0x2d24ULL: goto arm64_l_2d24; \
	case 0x2d4cULL: goto arm64_l_2d4c; \
	case 0x2d68ULL: goto arm64_l_2d68; \
	case 0x2d9cULL: goto arm64_l_2d9c; \
	case 0x2dc8ULL: goto arm64_l_2dc8; \
	case 0x2e30ULL: goto arm64_l_2e30; \
	case 0x2e4cULL: goto arm64_l_2e4c; \
	case 0x2e64ULL: goto arm64_l_2e64; \
	case 0x2e8cULL: goto arm64_l_2e8c; \
	case 0x2ea8ULL: goto arm64_l_2ea8; \
	case 0x2edcULL: goto arm64_l_2edc; \
	case 0x2f04ULL: goto arm64_l_2f04; \
	case 0x2f64ULL: goto arm64_l_2f64; \
	case 0x2f80ULL: goto arm64_l_2f80; \
	case 0x2f98ULL: goto arm64_l_2f98; \
	case 0x2fc0ULL: goto arm64_l_2fc0; \
	case 0x2fdcULL: goto arm64_l_2fdc; \
	case 0x3010ULL: goto arm64_l_3010; \
	case 0x303cULL: goto arm64_l_303c; \
	case 0x30a4ULL: goto arm64_l_30a4; \
	case 0x30c0ULL: goto arm64_l_30c0; \
	case 0x30d8ULL: goto arm64_l_30d8; \
	case 0x3100ULL: goto arm64_l_3100; \
	case 0x311cULL: goto arm64_l_311c; \
	case 0x3150ULL: goto arm64_l_3150; \
	case 0x3178ULL: goto arm64_l_3178; \
	case 0x31d8ULL: goto arm64_l_31d8; \
	case 0x31f4ULL: goto arm64_l_31f4; \
	case 0x320cULL: goto arm64_l_320c; \
	case 0x3234ULL: goto arm64_l_3234; \
	case 0x3250ULL: goto arm64_l_3250; \
	case 0x3284ULL: goto arm64_l_3284; \
	case 0x32b0ULL: goto arm64_l_32b0; \
	case 0x3318ULL: goto arm64_l_3318; \
	case 0x3334ULL: goto arm64_l_3334; \
	case 0x334cULL: goto arm64_l_334c; \
	case 0x3374ULL: goto arm64_l_3374; \
	case 0x3390ULL: goto arm64_l_3390; \
	case 0x33c4ULL: goto arm64_l_33c4; \
	case 0x33ecULL: goto arm64_l_33ec; \
	case 0x344cULL: goto arm64_l_344c; \
	case 0x3468ULL: goto arm64_l_3468; \
	case 0x3480ULL: goto arm64_l_3480; \
	case 0x34a8ULL: goto arm64_l_34a8; \
	case 0x34c4ULL: goto arm64_l_34c4; \
	case 0x34f8ULL: goto arm64_l_34f8; \
	case 0x3524ULL: goto arm64_l_3524; \
	case 0x358cULL: goto arm64_l_358c; \
	case 0x35a8ULL: goto arm64_l_35a8; \
	case 0x35c0ULL: goto arm64_l_35c0; \
	case 0x35e8ULL: goto arm64_l_35e8; \
	case 0x3604ULL: goto arm64_l_3604; \
	case 0x3638ULL: goto arm64_l_3638; \
	case 0x3660ULL: goto arm64_l_3660; \
	case 0x36c0ULL: goto arm64_l_36c0; \
	case 0x36dcULL: goto arm64_l_36dc; \
	case 0x36f4ULL: goto arm64_l_36f4; \
	case 0x371cULL: goto arm64_l_371c; \
	case 0x3738ULL: goto arm64_l_3738; \
	case 0x376cULL: goto arm64_l_376c; \
	case 0x3798ULL: goto arm64_l_3798; \
	case 0x3800ULL: goto arm64_l_3800; \
	case 0x381cULL: goto arm64_l_381c; \
	case 0x3834ULL: goto arm64_l_3834; \
	case 0x385cULL: goto arm64_l_385c; \
	case 0x3878ULL: goto arm64_l_3878; \
	case 0x38acULL: goto arm64_l_38ac; \
	case 0x38d4ULL: goto arm64_l_38d4; \
	case 0x3934ULL: goto arm64_l_3934; \
	case 0x3950ULL: goto arm64_l_3950; \
	case 0x3968ULL: goto arm64_l_3968; \
	case 0x3990ULL: goto arm64_l_3990; \
	case 0x39acULL: goto arm64_l_39ac; \
	case 0x39e0ULL: goto arm64_l_39e0; \
	case 0x3a0cULL: goto arm64_l_3a0c; \
	case 0x3a74ULL: goto arm64_l_3a74; \
	case 0x3a90ULL: goto arm64_l_3a90; \
	case 0x3aa8ULL: goto arm64_l_3aa8; \
	case 0x3ad0ULL: goto arm64_l_3ad0; \
	case 0x3aecULL: goto arm64_l_3aec; \
	case 0x3b20ULL: goto arm64_l_3b20; \
	case 0x3b48ULL: goto arm64_l_3b48; \
	case 0x3ba8ULL: goto arm64_l_3ba8; \
	case 0x3bc4ULL: goto arm64_l_3bc4; \
	case 0x3bdcULL: goto arm64_l_3bdc; \
	case 0x3c04ULL: goto arm64_l_3c04; \
	case 0x3c20ULL: goto arm64_l_3c20; \
	case 0x3c54ULL: goto arm64_l_3c54; \
	case 0x3c80ULL: goto arm64_l_3c80; \
	case 0x3ce8ULL: goto arm64_l_3ce8; \
	case 0x3d04ULL: goto arm64_l_3d04; \
	case 0x3d1cULL: goto arm64_l_3d1c; \
	case 0x3d44ULL: goto arm64_l_3d44; \
	case 0x3d60ULL: goto arm64_l_3d60; \
	case 0x3d94ULL: goto arm64_l_3d94; \
	case 0x3dbcULL: goto arm64_l_3dbc; \
	case 0x3e1cULL: goto arm64_l_3e1c; \
	case 0x3e38ULL: goto arm64_l_3e38; \
	case 0x3e50ULL: goto arm64_l_3e50; \
	case 0x3e78ULL: goto arm64_l_3e78; \
	case 0x3e94ULL: goto arm64_l_3e94; \
	case 0x3ec8ULL: goto arm64_l_3ec8; \
	case 0x3ef4ULL: goto arm64_l_3ef4; \
	case 0x3f58ULL: goto arm64_l_3f58; \
	case 0x3f74ULL: goto arm64_l_3f74; \
	case 0x3f8cULL: goto arm64_l_3f8c; \
	case 0x3fb4ULL: goto arm64_l_3fb4; \
	case 0x3fd0ULL: goto arm64_l_3fd0; \
	case 0x4004ULL: goto arm64_l_4004; \
	case 0x402cULL: goto arm64_l_402c; \
	case 0x408cULL: goto arm64_l_408c; \
	case 0x40a8ULL: goto arm64_l_40a8; \
	case 0x40c0ULL: goto arm64_l_40c0; \
	case 0x4100ULL: goto arm64_l_4100; \
	case 0x411cULL: goto arm64_l_411c; \
	case 0x4134ULL: goto arm64_l_4134;
#include "../arm64_sim_local_bpf.h"

static const __u64 __arm64_rodata_0[2] = {7957420064538977340ULL, 7854346351053923173ULL};

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} bufs_0 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_map_1 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} event_data_map_2 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} events_3 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} proc_info_map_4 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} stack_addresses_5 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} task_info_map_6 SEC(".maps");

SEC("xdp")
int tracee_sched_process_exec_event_submit_tail_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
	/* native subroutine tracee_sched_process_exec_event_submit_tail_xdp */
arm64_l_0:
	/* 0x0: sub sp, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_4:
	/* 0x4: str x29, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_8:
	/* 0x8: stp x30, x25, [sp, #176] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_c:
	/* 0xc: stp x24, x23, [sp, #192] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_10:
	/* 0x10: stp x22, x21, [sp, #208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_14:
	/* 0x14: stp x20, x19, [sp, #224] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_18:
	/* 0x18: mov x24, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c:
	/* 0x1c: str wzr, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_20:
	/* 0x20: adrp x0, 0 <event_data_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&event_data_map_2));
arm64_l_24:
	/* 0x24: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28:
	/* 0x28: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c:
	/* 0x2c: add x9, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_30:
	/* 0x30: add x1, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_34:
	/* 0x34: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x38ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_38:
	/* 0x38: cbz x0, 364 <sched_process_exec_event_submit_tail+0x364> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x38, 0x364, arm64_l_364);
arm64_l_3c:
	/* 0x3c: mov x29, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_40:
	/* 0x40: adrp x0, 0 <config_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_map_1));
arm64_l_44:
	/* 0x44: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_48:
	/* 0x48: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_4c:
	/* 0x4c: add x9, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_50:
	/* 0x50: add x1, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_54:
	/* 0x54: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x58ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_58:
	/* 0x58: str x0, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_5c:
	/* 0x5c: cbz x0, 364 <sched_process_exec_event_submit_tail+0x364> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x5c, 0x364, arm64_l_364);
arm64_l_60:
	/* 0x60: adrp x0, 0 <task_info_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&task_info_map_6));
arm64_l_64:
	/* 0x64: add x1, x29, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_68:
	/* 0x68: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_6c:
	/* 0x6c: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_70:
	/* 0x70: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x74ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_74:
	/* 0x74: cbz x0, 364 <sched_process_exec_event_submit_tail+0x364> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x74, 0x364, arm64_l_364);
arm64_l_78:
	/* 0x78: mov x19, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7c:
	/* 0x7c: adrp x0, 0 <proc_info_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&proc_info_map_4));
arm64_l_80:
	/* 0x80: add x1, x29, #0x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 36ULL);
arm64_l_84:
	/* 0x84: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_88:
	/* 0x88: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_8c:
	/* 0x8c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x90ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_90:
	/* 0x90: cbz x0, 364 <sched_process_exec_event_submit_tail+0x364> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x90, 0x364, arm64_l_364);
arm64_l_94:
	/* 0x94: ldr x23, [x24, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_98:
	/* 0x98: cbz x23, 364 <sched_process_exec_event_submit_tail+0x364> */
	ARM64_SIM_A64_CBZ(ARM64_X23, 0x98, 0x364, arm64_l_364);
arm64_l_9c:
	/* 0x9c: ldr x21, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_a0:
	/* 0xa0: str x19, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_a4:
	/* 0xa4: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_a8:
	/* 0xa8: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_ac:
	/* 0xac: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_b0:
	/* 0xb0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_b4:
	/* 0xb4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_b8:
	/* 0xb8: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_bc:
	/* 0xbc: add x2, x21, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_c0:
	/* 0xc0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xc4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_c4:
	/* 0xc4: ldr x19, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_c8:
	/* 0xc8: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_cc:
	/* 0xcc: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_d0:
	/* 0xd0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_d4:
	/* 0xd4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_d8:
	/* 0xd8: add x2, x19, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_dc:
	/* 0xdc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xe0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_e0:
	/* 0xe0: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_e4:
	/* 0xe4: add x2, x19, #0x50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 80ULL);
arm64_l_e8:
	/* 0xe8: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_ec:
	/* 0xec: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_f0:
	/* 0xf0: str x8, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_f4:
	/* 0xf4: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_f8:
	/* 0xf8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_fc:
	/* 0xfc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x100ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_100:
	/* 0x100: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_104:
	/* 0x104: add x2, x23, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_108:
	/* 0x108: add x9, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_10c:
	/* 0x10c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_110:
	/* 0x110: str x8, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_114:
	/* 0x114: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_118:
	/* 0x118: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_11c:
	/* 0x11c: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x120ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_120:
	/* 0x120: ldr w25, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_124:
	/* 0x124: mov w8, #0x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 35ULL);
arm64_l_128:
	/* 0x128: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 35ULL: ARM64_SIM_A64_LINK(0x12cULL); ARM64_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_12c:
	/* 0x12c: str x24, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_130:
	/* 0x130: str w25, [sp, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_134:
	/* 0x134: cbz x0, 1b4 <sched_process_exec_event_submit_tail+0x1b4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x134, 0x1b4, arm64_l_1b4);
arm64_l_138:
	/* 0x138: add x2, x0, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_13c:
	/* 0x13c: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_140:
	/* 0x140: add x8, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_144:
	/* 0x144: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_148:
	/* 0x148: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_14c:
	/* 0x14c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_150:
	/* 0x150: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_154:
	/* 0x154: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x158ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_158:
	/* 0x158: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_15c:
	/* 0x15c: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_160:
	/* 0x160: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_164:
	/* 0x164: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_168:
	/* 0x168: ldr x2, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_16c:
	/* 0x16c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_170:
	/* 0x170: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x174ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_174:
	/* 0x174: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_178:
	/* 0x178: add x9, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_17c:
	/* 0x17c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_180:
	/* 0x180: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_184:
	/* 0x184: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_188:
	/* 0x188: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x18cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_18c:
	/* 0x18c: ldr x2, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_190:
	/* 0x190: cbz x2, 1b4 <sched_process_exec_event_submit_tail+0x1b4> */
	ARM64_SIM_A64_CBZ(ARM64_X2, 0x190, 0x1b4, arm64_l_1b4);
arm64_l_194:
	/* 0x194: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_198:
	/* 0x198: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_19c:
	/* 0x19c: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1a0:
	/* 0x1a0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1a4:
	/* 0x1a4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1a8:
	/* 0x1a8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1acULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1ac:
	/* 0x1ac: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1b0:
	/* 0x1b0: b 1b8 <sched_process_exec_event_submit_tail+0x1b8> */
	ARM64_SIM_A64_JMP(0x1b0, 0x1b8, arm64_l_1b8);
arm64_l_1b4:
	/* 0x1b4: mov x20, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b8:
	/* 0x1b8: add x2, x20, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1bc:
	/* 0x1bc: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1c0:
	/* 0x1c0: add x9, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1c4:
	/* 0x1c4: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1c8:
	/* 0x1c8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1cc:
	/* 0x1cc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1d0:
	/* 0x1d0: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1d4:
	/* 0x1d4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1d8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1d8:
	/* 0x1d8: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1dc:
	/* 0x1dc: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1e0:
	/* 0x1e0: add x10, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1e4:
	/* 0x1e4: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1e8:
	/* 0x1e8: ldr x2, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1ec:
	/* 0x1ec: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1f0:
	/* 0x1f0: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1f4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1f4:
	/* 0x1f4: ldrh w8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1f8:
	/* 0x1f8: str wzr, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1fc:
	/* 0x1fc: adrp x0, 0 <bufs> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&bufs_0));
arm64_l_200:
	/* 0x200: add x9, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_204:
	/* 0x204: add x1, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_208:
	/* 0x208: and w8, w8, #0xf000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 61440ULL);
arm64_l_20c:
	/* 0x20c: strh w8, [sp, #68] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 68ULL);
arm64_l_210:
	/* 0x210: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_214:
	/* 0x214: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_218:
	/* 0x218: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x21cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_21c:
	/* 0x21c: mov x25, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_220:
	/* 0x220: str x29, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_224:
	/* 0x224: cbz x0, 644 <sched_process_exec_event_submit_tail+0x644> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x224, 0x644, arm64_l_644);
arm64_l_228:
	/* 0x228: add x2, x20, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_22c:
	/* 0x22c: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_230:
	/* 0x230: add x9, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_234:
	/* 0x234: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_238:
	/* 0x238: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_23c:
	/* 0x23c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_240:
	/* 0x240: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_244:
	/* 0x244: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x248ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_248:
	/* 0x248: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_24c:
	/* 0x24c: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_250:
	/* 0x250: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_254:
	/* 0x254: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_258:
	/* 0x258: str x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_25c:
	/* 0x25c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_260:
	/* 0x260: ldr x2, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_264:
	/* 0x264: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x268ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_268:
	/* 0x268: ldr w8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_26c:
	/* 0x26c: tbnz w8, #5, 36c <sched_process_exec_event_submit_tail+0x36c> */
	ARM64_SIM_A64_TBNZ(ARM64_X8, 5, 0x26c, 0x36c, arm64_l_36c);
arm64_l_270:
	/* 0x270: add x2, x20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_274:
	/* 0x274: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_278:
	/* 0x278: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_27c:
	/* 0x27c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_280:
	/* 0x280: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_284:
	/* 0x284: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_288:
	/* 0x288: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_28c:
	/* 0x28c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x290ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_290:
	/* 0x290: ldr x29, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_294:
	/* 0x294: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_298:
	/* 0x298: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_29c:
	/* 0x29c: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2a0:
	/* 0x2a0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2a4:
	/* 0x2a4: sub x8, x29, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2a8:
	/* 0x2a8: str x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2ac:
	/* 0x2ac: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2b0:
	/* 0x2b0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2b4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2b4:
	/* 0x2b4: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2b8:
	/* 0x2b8: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2bc:
	/* 0x2bc: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2c0:
	/* 0x2c0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2c4:
	/* 0x2c4: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2c8:
	/* 0x2c8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2cc:
	/* 0x2cc: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2d0:
	/* 0x2d0: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2d4:
	/* 0x2d4: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2d8:
	/* 0x2d8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2dc:
	/* 0x2dc: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2e0:
	/* 0x2e0: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2e4:
	/* 0x2e4: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2e8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2e8:
	/* 0x2e8: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2ec:
	/* 0x2ec: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2f0:
	/* 0x2f0: b.eq 390 <sched_process_exec_event_submit_tail+0x390> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2f0, 0x390, arm64_l_390);
arm64_l_2f4:
	/* 0x2f4: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2f8:
	/* 0x2f8: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2fc:
	/* 0x2fc: b.eq 390 <sched_process_exec_event_submit_tail+0x390> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2fc, 0x390, arm64_l_390);
arm64_l_300:
	/* 0x300: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_304:
	/* 0x304: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_308:
	/* 0x308: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_30c:
	/* 0x30c: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_310:
	/* 0x310: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_314:
	/* 0x314: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_318:
	/* 0x318: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x31cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_31c:
	/* 0x31c: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_320:
	/* 0x320: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_324:
	/* 0x324: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_328:
	/* 0x328: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_32c:
	/* 0x32c: neg w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_330:
	/* 0x330: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_334:
	/* 0x334: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_338:
	/* 0x338: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_33c:
	/* 0x33c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x340ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_340:
	/* 0x340: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_344:
	/* 0x344: b.lt 4e8 <sched_process_exec_event_submit_tail+0x4e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x344, 0x4e8, arm64_l_4e8);
arm64_l_348:
	/* 0x348: mov w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16383ULL);
arm64_l_34c:
	/* 0x34c: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_350:
	/* 0x350: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_354:
	/* 0x354: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_358:
	/* 0x358: mov w8, #0x4000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16384ULL);
arm64_l_35c:
	/* 0x35c: sub w8, w8, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_360:
	/* 0x360: b 40c <sched_process_exec_event_submit_tail+0x40c> */
	ARM64_SIM_A64_JMP(0x360, 0x40c, arm64_l_40c);
arm64_l_364:
	/* 0x364: mov w0, #0xffffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967295ULL);
arm64_l_368:
	/* 0x368: b 1680 <sched_process_exec_event_submit_tail+0x1680> */
	ARM64_SIM_A64_JMP(0x368, 0x1680, arm64_l_1680);
arm64_l_36c:
	/* 0x36c: adrp x2, 0 <sched_process_exec_event_submit_tail> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_RODATA, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)__arm64_rodata_0));
arm64_l_370:
	/* 0x370: add x2, x2, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_374:
	/* 0x374: mov w8, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_378:
	/* 0x378: mov w9, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_37c:
	/* 0x37c: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_380:
	/* 0x380: mov w1, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_384:
	/* 0x384: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x388ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_388:
	/* 0x388: mov x8, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_38c:
	/* 0x38c: b 63c <sched_process_exec_event_submit_tail+0x63c> */
	ARM64_SIM_A64_JMP(0x38c, 0x63c, arm64_l_63c);
arm64_l_390:
	/* 0x390: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_394:
	/* 0x394: b.ne 4e8 <sched_process_exec_event_submit_tail+0x4e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x394, 0x4e8, arm64_l_4e8);
arm64_l_398:
	/* 0x398: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_39c:
	/* 0x39c: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3a0:
	/* 0x3a0: b.eq 4e8 <sched_process_exec_event_submit_tail+0x4e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3a0, 0x4e8, arm64_l_4e8);
arm64_l_3a4:
	/* 0x3a4: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3a8:
	/* 0x3a8: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3ac:
	/* 0x3ac: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3b0:
	/* 0x3b0: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3b4:
	/* 0x3b4: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3b8:
	/* 0x3b8: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3bc:
	/* 0x3bc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3c0:
	/* 0x3c0: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3c4:
	/* 0x3c4: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3c8:
	/* 0x3c8: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3cc:
	/* 0x3cc: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3d0:
	/* 0x3d0: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3d4:
	/* 0x3d4: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3d8:
	/* 0x3d8: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3dc:
	/* 0x3dc: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3e0:
	/* 0x3e0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3e4:
	/* 0x3e4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3e8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3e8:
	/* 0x3e8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3ec:
	/* 0x3ec: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3f0:
	/* 0x3f0: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3f4:
	/* 0x3f4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3f8:
	/* 0x3f8: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3fc:
	/* 0x3fc: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x400ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_400:
	/* 0x400: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_404:
	/* 0x404: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_408:
	/* 0x408: mov w8, #0x4000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16384ULL);
arm64_l_40c:
	/* 0x40c: str w8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_410:
	/* 0x410: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_414:
	/* 0x414: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_418:
	/* 0x418: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_41c:
	/* 0x41c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_420:
	/* 0x420: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_424:
	/* 0x424: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_428:
	/* 0x428: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_42c:
	/* 0x42c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x430ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_430:
	/* 0x430: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_434:
	/* 0x434: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_438:
	/* 0x438: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_43c:
	/* 0x43c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_440:
	/* 0x440: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_444:
	/* 0x444: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_448:
	/* 0x448: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x44cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_44c:
	/* 0x44c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_450:
	/* 0x450: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_454:
	/* 0x454: b.eq 4d4 <sched_process_exec_event_submit_tail+0x4d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x454, 0x4d4, arm64_l_4d4);
arm64_l_458:
	/* 0x458: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_45c:
	/* 0x45c: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_460:
	/* 0x460: b.eq 4d4 <sched_process_exec_event_submit_tail+0x4d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x460, 0x4d4, arm64_l_4d4);
arm64_l_464:
	/* 0x464: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_468:
	/* 0x468: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_46c:
	/* 0x46c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_470:
	/* 0x470: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_474:
	/* 0x474: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_478:
	/* 0x478: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_47c:
	/* 0x47c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x480ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_480:
	/* 0x480: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_484:
	/* 0x484: ldr w22, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_488:
	/* 0x488: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_48c:
	/* 0x48c: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_490:
	/* 0x490: subs w8, w22, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X22, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_494:
	/* 0x494: b.cc 620 <sched_process_exec_event_submit_tail+0x620> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x494, 0x620, arm64_l_620);
arm64_l_498:
	/* 0x498: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_49c:
	/* 0x49c: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_4a0:
	/* 0x4a0: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_4a4:
	/* 0x4a4: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_4a8:
	/* 0x4a8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x4acULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_4ac:
	/* 0x4ac: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_4b0:
	/* 0x4b0: b.lt 4e0 <sched_process_exec_event_submit_tail+0x4e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x4b0, 0x4e0, arm64_l_4e0);
arm64_l_4b4:
	/* 0x4b4: sub w8, w22, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_4b8:
	/* 0x4b8: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_4bc:
	/* 0x4bc: sub w22, w22, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_4c0:
	/* 0x4c0: str w22, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_4c4:
	/* 0x4c4: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_4c8:
	/* 0x4c8: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_4cc:
	/* 0x4cc: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_4d0:
	/* 0x4d0: b 598 <sched_process_exec_event_submit_tail+0x598> */
	ARM64_SIM_A64_JMP(0x4d0, 0x598, arm64_l_598);
arm64_l_4d4:
	/* 0x4d4: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_4d8:
	/* 0x4d8: b.eq 528 <sched_process_exec_event_submit_tail+0x528> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x4d8, 0x528, arm64_l_528);
arm64_l_4dc:
	/* 0x4dc: ldr w22, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_4e0:
	/* 0x4e0: cmp w22, #0x4, lsl #12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 16384ULL);
arm64_l_4e4:
	/* 0x4e4: b.ne 620 <sched_process_exec_event_submit_tail+0x620> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x4e4, 0x620, arm64_l_620);
arm64_l_4e8:
	/* 0x4e8: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_4ec:
	/* 0x4ec: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_4f0:
	/* 0x4f0: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_4f4:
	/* 0x4f4: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_4f8:
	/* 0x4f8: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_4fc:
	/* 0x4fc: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_500:
	/* 0x500: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_504:
	/* 0x504: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x508ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_508:
	/* 0x508: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_50c:
	/* 0x50c: mov w8, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_510:
	/* 0x510: mov w9, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_514:
	/* 0x514: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_518:
	/* 0x518: mov w1, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_51c:
	/* 0x51c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x520ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_520:
	/* 0x520: mov x8, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_524:
	/* 0x524: b 638 <sched_process_exec_event_submit_tail+0x638> */
	ARM64_SIM_A64_JMP(0x524, 0x638, arm64_l_638);
arm64_l_528:
	/* 0x528: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_52c:
	/* 0x52c: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_530:
	/* 0x530: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x530, 0x4dc, arm64_l_4dc);
arm64_l_534:
	/* 0x534: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_538:
	/* 0x538: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_53c:
	/* 0x53c: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_540:
	/* 0x540: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_544:
	/* 0x544: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_548:
	/* 0x548: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_54c:
	/* 0x54c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_550:
	/* 0x550: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_554:
	/* 0x554: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_558:
	/* 0x558: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x55cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_55c:
	/* 0x55c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_560:
	/* 0x560: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_564:
	/* 0x564: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_568:
	/* 0x568: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_56c:
	/* 0x56c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_570:
	/* 0x570: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_574:
	/* 0x574: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x578ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_578:
	/* 0x578: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_57c:
	/* 0x57c: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_580:
	/* 0x580: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_584:
	/* 0x584: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_588:
	/* 0x588: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_58c:
	/* 0x58c: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x590ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_590:
	/* 0x590: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_594:
	/* 0x594: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_598:
	/* 0x598: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_59c:
	/* 0x59c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_5a0:
	/* 0x5a0: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_5a4:
	/* 0x5a4: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_5a8:
	/* 0x5a8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_5ac:
	/* 0x5ac: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_5b0:
	/* 0x5b0: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_5b4:
	/* 0x5b4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x5b8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_5b8:
	/* 0x5b8: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_5bc:
	/* 0x5bc: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_5c0:
	/* 0x5c0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_5c4:
	/* 0x5c4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_5c8:
	/* 0x5c8: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_5cc:
	/* 0x5cc: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_5d0:
	/* 0x5d0: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x5d4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_5d4:
	/* 0x5d4: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_5d8:
	/* 0x5d8: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_5dc:
	/* 0x5dc: b.eq 1000 <sched_process_exec_event_submit_tail+0x1000> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x5dc, 0x1000, arm64_l_1000);
arm64_l_5e0:
	/* 0x5e0: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_5e4:
	/* 0x5e4: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_5e8:
	/* 0x5e8: b.eq 1000 <sched_process_exec_event_submit_tail+0x1000> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x5e8, 0x1000, arm64_l_1000);
arm64_l_5ec:
	/* 0x5ec: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_5f0:
	/* 0x5f0: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_5f4:
	/* 0x5f4: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_5f8:
	/* 0x5f8: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_5fc:
	/* 0x5fc: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_600:
	/* 0x600: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_604:
	/* 0x604: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x608ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_608:
	/* 0x608: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_60c:
	/* 0x60c: ldr w22, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_610:
	/* 0x610: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_614:
	/* 0x614: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_618:
	/* 0x618: subs w8, w22, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X22, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_61c:
	/* 0x61c: b.cs 1718 <sched_process_exec_event_submit_tail+0x1718> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x61c, 0x1718, arm64_l_1718);
arm64_l_620:
	/* 0x620: sub w8, w22, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_624:
	/* 0x624: mov w10, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_628:
	/* 0x628: and x9, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_62c:
	/* 0x62c: strb w10, [x25, x9] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_630:
	/* 0x630: mov w9, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16383ULL);
arm64_l_634:
	/* 0x634: strb wzr, [x25, x9] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_XZR, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_638:
	/* 0x638: ldr x29, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_63c:
	/* 0x63c: and x8, x8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_640:
	/* 0x640: add x25, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X25, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_644:
	/* 0x644: add x2, x23, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_648:
	/* 0x648: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_64c:
	/* 0x64c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_650:
	/* 0x650: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_654:
	/* 0x654: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_658:
	/* 0x658: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_65c:
	/* 0x65c: add x24, x29, #0x7, lsl #12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 28672ULL);
arm64_l_660:
	/* 0x660: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_664:
	/* 0x664: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x668ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_668:
	/* 0x668: ldr x29, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_66c:
	/* 0x66c: add x2, x21, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_670:
	/* 0x670: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_674:
	/* 0x674: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_678:
	/* 0x678: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_67c:
	/* 0x67c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_680:
	/* 0x680: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x684ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_684:
	/* 0x684: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_688:
	/* 0x688: add x9, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_68c:
	/* 0x68c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_690:
	/* 0x690: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_694:
	/* 0x694: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_698:
	/* 0x698: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_69c:
	/* 0x69c: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x6a0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_6a0:
	/* 0x6a0: ldr w8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_6a4:
	/* 0x6a4: ldr x22, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_6a8:
	/* 0x6a8: ubfx w8, w8, #21, #1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_BITFIELD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFX, 21, 1), 0);
arm64_l_6ac:
	/* 0x6ac: strb w8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_6b0:
	/* 0x6b0: ldr w8, [sp, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_6b4:
	/* 0x6b4: str w8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_6b8:
	/* 0x6b8: ldr x8, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_6bc:
	/* 0x6bc: cmp x22, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_6c0:
	/* 0x6c0: b.cs 7e0 <sched_process_exec_event_submit_tail+0x7e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x6c0, 0x7e0, arm64_l_7e0);
arm64_l_6c4:
	/* 0x6c4: sub w8, w8, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_6c8:
	/* 0x6c8: mov w9, #0x1fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8191ULL);
arm64_l_6cc:
	/* 0x6cc: cmp w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_6d0:
	/* 0x6d0: csel w8, w8, w9, lt */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LT, 0);
arm64_l_6d4:
	/* 0x6d4: str w8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_6d8:
	/* 0x6d8: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_6dc:
	/* 0x6dc: ubfx x9, x8, #8, #24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_BITFIELD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFX, 8, 24), 0);
arm64_l_6e0:
	/* 0x6e0: cmp w9, #0x7c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 124ULL);
arm64_l_6e4:
	/* 0x6e4: b.hi 7e0 <sched_process_exec_event_submit_tail+0x7e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x6e4, 0x7e0, arm64_l_7e0);
arm64_l_6e8:
	/* 0x6e8: ldr x9, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_6ec:
	/* 0x6ec: add x8, x9, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_6f0:
	/* 0x6f0: mov w9, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_6f4:
	/* 0x6f4: strb w9, [x8, #137] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 137ULL);
arm64_l_6f8:
	/* 0x6f8: mov w9, #0x7cfb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 31995ULL);
arm64_l_6fc:
	/* 0x6fc: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_700:
	/* 0x700: cmp w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_704:
	/* 0x704: b.hi 7e0 <sched_process_exec_event_submit_tail+0x7e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x704, 0x7e0, arm64_l_7e0);
arm64_l_708:
	/* 0x708: ldr x9, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_70c:
	/* 0x70c: add x10, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_710:
	/* 0x710: add x2, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_714:
	/* 0x714: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_718:
	/* 0x718: add x20, x9, #0x89 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X20, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 137ULL);
arm64_l_71c:
	/* 0x71c: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_720:
	/* 0x720: add x8, x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_724:
	/* 0x724: add x8, x8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_728:
	/* 0x728: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_72c:
	/* 0x72c: add x8, x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_730:
	/* 0x730: add x0, x8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_734:
	/* 0x734: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x738ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_738:
	/* 0x738: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_73c:
	/* 0x73c: ubfx x9, x8, #3, #29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_BITFIELD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFX, 3, 29), 0);
arm64_l_740:
	/* 0x740: cmp w9, #0xf9e */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3998ULL);
arm64_l_744:
	/* 0x744: b.hi 7e0 <sched_process_exec_event_submit_tail+0x7e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x744, 0x7e0, arm64_l_7e0);
arm64_l_748:
	/* 0x748: add x8, x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_74c:
	/* 0x74c: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_750:
	/* 0x750: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_754:
	/* 0x754: add x2, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_758:
	/* 0x758: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_75c:
	/* 0x75c: add x8, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_760:
	/* 0x760: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_764:
	/* 0x764: add x8, x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_768:
	/* 0x768: add x0, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_76c:
	/* 0x76c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x770ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_770:
	/* 0x770: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_774:
	/* 0x774: ubfx x9, x8, #3, #29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_BITFIELD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFX, 3, 29), 0);
arm64_l_778:
	/* 0x778: cmp w9, #0xb9e */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2974ULL);
arm64_l_77c:
	/* 0x77c: b.hi 7e0 <sched_process_exec_event_submit_tail+0x7e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x77c, 0x7e0, arm64_l_7e0);
arm64_l_780:
	/* 0x780: ldr x9, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_784:
	/* 0x784: ldr w10, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_788:
	/* 0x788: mov w11, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_78c:
	/* 0x78c: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_790:
	/* 0x790: add x9, x9, #0x89 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 137ULL);
arm64_l_794:
	/* 0x794: and x10, x10, #0x1fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 8191ULL);
arm64_l_798:
	/* 0x798: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_79c:
	/* 0x79c: add x8, x8, #0x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_7a0:
	/* 0x7a0: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_7a4:
	/* 0x7a4: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_7a8:
	/* 0x7a8: ldr w9, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_7ac:
	/* 0x7ac: add x0, x8, #0x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_7b0:
	/* 0x7b0: and w1, w9, #0x1fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 8191ULL);
arm64_l_7b4:
	/* 0x7b4: blr x11 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X11);
		if (ARM64_SIM_L_REG_TAG(ARM64_X11) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x7b8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_7b8:
	/* 0x7b8: cbnz x0, 7e0 <sched_process_exec_event_submit_tail+0x7e0> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x7b8, 0x7e0, arm64_l_7e0);
arm64_l_7bc:
	/* 0x7bc: ldrh w8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_7c0:
	/* 0x7c0: ldrh w9, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_7c4:
	/* 0x7c4: add w8, w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_7c8:
	/* 0x7c8: ldr x9, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_7cc:
	/* 0x7cc: add w8, w8, #0x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_7d0:
	/* 0x7d0: strh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_7d4:
	/* 0x7d4: ldrb w8, [x9, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_7d8:
	/* 0x7d8: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_7dc:
	/* 0x7dc: strb w8, [x9, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_7e0:
	/* 0x7e0: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_7e4:
	/* 0x7e4: ubfx x9, x8, #8, #24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_BITFIELD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFX, 8, 24), 0);
arm64_l_7e8:
	/* 0x7e8: cmp w9, #0x7c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 124ULL);
arm64_l_7ec:
	/* 0x7ec: b.hi 884 <sched_process_exec_event_submit_tail+0x884> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x7ec, 0x884, arm64_l_884);
arm64_l_7f0:
	/* 0x7f0: ldr x9, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_7f4:
	/* 0x7f4: add x8, x9, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_7f8:
	/* 0x7f8: mov w9, #0xb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 11ULL);
arm64_l_7fc:
	/* 0x7fc: strb w9, [x8, #137] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 137ULL);
arm64_l_800:
	/* 0x800: mov w9, #0x6cfb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 27899ULL);
arm64_l_804:
	/* 0x804: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_808:
	/* 0x808: cmp w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_80c:
	/* 0x80c: strh w8, [x24, #3490] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3490ULL);
arm64_l_810:
	/* 0x810: b.hi 884 <sched_process_exec_event_submit_tail+0x884> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x810, 0x884, arm64_l_884);
arm64_l_814:
	/* 0x814: ldr x9, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_818:
	/* 0x818: mov w10, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_81c:
	/* 0x81c: mov w11, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_820:
	/* 0x820: mov w1, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_824:
	/* 0x824: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_828:
	/* 0x828: add x9, x9, #0x89 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 137ULL);
arm64_l_82c:
	/* 0x82c: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_830:
	/* 0x830: add x8, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_834:
	/* 0x834: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_838:
	/* 0x838: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_83c:
	/* 0x83c: add x0, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_840:
	/* 0x840: blr x11 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X11);
		if (ARM64_SIM_L_REG_TAG(ARM64_X11) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0x844ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_844:
	/* 0x844: cmp w0, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_848:
	/* 0x848: b.lt 884 <sched_process_exec_event_submit_tail+0x884> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x848, 0x884, arm64_l_884);
arm64_l_84c:
	/* 0x84c: mov w9, #0x6cfb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 27899ULL);
arm64_l_850:
	/* 0x850: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_854:
	/* 0x854: cmp w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_858:
	/* 0x858: b.hi 884 <sched_process_exec_event_submit_tail+0x884> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x858, 0x884, arm64_l_884);
arm64_l_85c:
	/* 0x85c: ldr x9, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_860:
	/* 0x860: ldrb w10, [x9, #136]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 136ULL);
arm64_l_864:
	/* 0x864: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_868:
	/* 0x868: stur w0, [x8, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_86c:
	/* 0x86c: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_870:
	/* 0x870: add w8, w0, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_874:
	/* 0x874: add w8, w8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_878:
	/* 0x878: strh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_87c:
	/* 0x87c: add w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_880:
	/* 0x880: strb w8, [x9] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_884:
	/* 0x884: ldrh w20, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_888:
	/* 0x888: ldr x29, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_88c:
	/* 0x88c: lsr w8, w20, #8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_890:
	/* 0x890: cmp w8, #0x7c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 124ULL);
arm64_l_894:
	/* 0x894: b.hi 994 <sched_process_exec_event_submit_tail+0x994> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x894, 0x994, arm64_l_994);
arm64_l_898:
	/* 0x898: add x8, x29, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_89c:
	/* 0x89c: mov w9, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_8a0:
	/* 0x8a0: strb w9, [x8, #137] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 137ULL);
arm64_l_8a4:
	/* 0x8a4: mov w8, #0x7cfd */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 31997ULL);
arm64_l_8a8:
	/* 0x8a8: cmp w20, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8ac:
	/* 0x8ac: b.hi 8f8 <sched_process_exec_event_submit_tail+0x8f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x8ac, 0x8f8, arm64_l_8f8);
arm64_l_8b0:
	/* 0x8b0: add x8, x20, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X20, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_8b4:
	/* 0x8b4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_8b8:
	/* 0x8b8: add x10, sp, #0x44 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 68ULL);
arm64_l_8bc:
	/* 0x8bc: add x2, sp, #0x44 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 68ULL);
arm64_l_8c0:
	/* 0x8c0: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_8c4:
	/* 0x8c4: add x0, x8, #0x8a */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 138ULL);
arm64_l_8c8:
	/* 0x8c8: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_8cc:
	/* 0x8cc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x8d0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_8d0:
	/* 0x8d0: tbnz x0, #63, 8f8 <sched_process_exec_event_submit_tail+0x8f8> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x8d0, 0x8f8, arm64_l_8f8);
arm64_l_8d4:
	/* 0x8d4: ldrb w9, [x29, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_8d8:
	/* 0x8d8: add w8, w20, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_8dc:
	/* 0x8dc: strh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_8e0:
	/* 0x8e0: add w9, w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_8e4:
	/* 0x8e4: strb w9, [x29, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_8e8:
	/* 0x8e8: lsr w9, w8, #8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_8ec:
	/* 0x8ec: cmp w9, #0x7c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 124ULL);
arm64_l_8f0:
	/* 0x8f0: b.ls 908 <sched_process_exec_event_submit_tail+0x908> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x8f0, 0x908, arm64_l_908);
arm64_l_8f4:
	/* 0x8f4: b 994 <sched_process_exec_event_submit_tail+0x994> */
	ARM64_SIM_A64_JMP(0x8f4, 0x994, arm64_l_994);
arm64_l_8f8:
	/* 0x8f8: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_8fc:
	/* 0x8fc: lsr w9, w8, #8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_900:
	/* 0x900: cmp w9, #0x7c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 124ULL);
arm64_l_904:
	/* 0x904: b.hi 994 <sched_process_exec_event_submit_tail+0x994> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x904, 0x994, arm64_l_994);
arm64_l_908:
	/* 0x908: add x8, x29, w8, uxtw */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTW, 0), 0);
arm64_l_90c:
	/* 0x90c: mov w9, #0xd */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 13ULL);
arm64_l_910:
	/* 0x910: strb w9, [x8, #137] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 137ULL);
arm64_l_914:
	/* 0x914: mov w9, #0x6cfb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 27899ULL);
arm64_l_918:
	/* 0x918: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_91c:
	/* 0x91c: cmp w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_920:
	/* 0x920: strh w8, [x24, #3494] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3494ULL);
arm64_l_924:
	/* 0x924: b.hi 994 <sched_process_exec_event_submit_tail+0x994> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x924, 0x994, arm64_l_994);
arm64_l_928:
	/* 0x928: add x9, x29, #0x89 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 137ULL);
arm64_l_92c:
	/* 0x92c: mov w10, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_930:
	/* 0x930: mov w11, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_934:
	/* 0x934: mov w1, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_938:
	/* 0x938: mov x2, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_93c:
	/* 0x93c: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_940:
	/* 0x940: add x8, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_944:
	/* 0x944: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_948:
	/* 0x948: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_94c:
	/* 0x94c: add x0, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_950:
	/* 0x950: blr x11 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X11);
		if (ARM64_SIM_L_REG_TAG(ARM64_X11) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0x954ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_954:
	/* 0x954: cmp w0, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_958:
	/* 0x958: b.lt 994 <sched_process_exec_event_submit_tail+0x994> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x958, 0x994, arm64_l_994);
arm64_l_95c:
	/* 0x95c: mov w9, #0x6cfb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 27899ULL);
arm64_l_960:
	/* 0x960: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_964:
	/* 0x964: cmp w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_968:
	/* 0x968: b.hi 994 <sched_process_exec_event_submit_tail+0x994> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x968, 0x994, arm64_l_994);
arm64_l_96c:
	/* 0x96c: mov x9, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_970:
	/* 0x970: ldrb w10, [x9, #136]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 136ULL);
arm64_l_974:
	/* 0x974: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_978:
	/* 0x978: stur w0, [x8, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_97c:
	/* 0x97c: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_980:
	/* 0x980: add w8, w0, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_984:
	/* 0x984: add w8, w8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_988:
	/* 0x988: strh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_98c:
	/* 0x98c: add w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_990:
	/* 0x990: strb w8, [x9] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_994:
	/* 0x994: ldrh w20, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_998:
	/* 0x998: lsr w8, w20, #8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_99c:
	/* 0x99c: cmp w8, #0x7c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 124ULL);
arm64_l_9a0:
	/* 0x9a0: b.hi aa4 <sched_process_exec_event_submit_tail+0xaa4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x9a0, 0xaa4, arm64_l_aa4);
arm64_l_9a4:
	/* 0x9a4: add x8, x29, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X20, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_9a8:
	/* 0x9a8: mov w9, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_9ac:
	/* 0x9ac: strb w9, [x8, #137] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 137ULL);
arm64_l_9b0:
	/* 0x9b0: mov w8, #0x7cff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 31999ULL);
arm64_l_9b4:
	/* 0x9b4: cmp w20, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_9b8:
	/* 0x9b8: b.eq a04 <sched_process_exec_event_submit_tail+0xa04> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x9b8, 0xa04, arm64_l_a04);
arm64_l_9bc:
	/* 0x9bc: add x8, x20, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X20, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_9c0:
	/* 0x9c0: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_9c4:
	/* 0x9c4: add x10, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_9c8:
	/* 0x9c8: add x2, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_9cc:
	/* 0x9cc: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_9d0:
	/* 0x9d0: add x0, x8, #0x8a */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 138ULL);
arm64_l_9d4:
	/* 0x9d4: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_9d8:
	/* 0x9d8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x9dcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_9dc:
	/* 0x9dc: tbnz x0, #63, a04 <sched_process_exec_event_submit_tail+0xa04> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x9dc, 0xa04, arm64_l_a04);
arm64_l_9e0:
	/* 0x9e0: ldrb w9, [x29, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_9e4:
	/* 0x9e4: add w8, w20, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_9e8:
	/* 0x9e8: strh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_9ec:
	/* 0x9ec: add w9, w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_9f0:
	/* 0x9f0: strb w9, [x29, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_9f4:
	/* 0x9f4: lsr w9, w8, #8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_9f8:
	/* 0x9f8: cmp w9, #0x7c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 124ULL);
arm64_l_9fc:
	/* 0x9fc: b.ls a14 <sched_process_exec_event_submit_tail+0xa14> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x9fc, 0xa14, arm64_l_a14);
arm64_l_a00:
	/* 0xa00: b aa4 <sched_process_exec_event_submit_tail+0xaa4> */
	ARM64_SIM_A64_JMP(0xa00, 0xaa4, arm64_l_aa4);
arm64_l_a04:
	/* 0xa04: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_a08:
	/* 0xa08: lsr w9, w8, #8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 8ULL);
arm64_l_a0c:
	/* 0xa0c: cmp w9, #0x7c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 124ULL);
arm64_l_a10:
	/* 0xa10: b.hi aa4 <sched_process_exec_event_submit_tail+0xaa4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xa10, 0xaa4, arm64_l_aa4);
arm64_l_a14:
	/* 0xa14: add x8, x29, w8, uxtw */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTW, 0), 0);
arm64_l_a18:
	/* 0xa18: mov w9, #0xf */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 15ULL);
arm64_l_a1c:
	/* 0xa1c: strb w9, [x8, #137] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 137ULL);
arm64_l_a20:
	/* 0xa20: mov w9, #0x6cfb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 27899ULL);
arm64_l_a24:
	/* 0xa24: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_a28:
	/* 0xa28: cmp w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_a2c:
	/* 0xa2c: strh w8, [x24, #3498] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3498ULL);
arm64_l_a30:
	/* 0xa30: b.hi aa4 <sched_process_exec_event_submit_tail+0xaa4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xa30, 0xaa4, arm64_l_aa4);
arm64_l_a34:
	/* 0xa34: ldr x9, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_a38:
	/* 0xa38: mov w10, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_a3c:
	/* 0xa3c: mov w11, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_a40:
	/* 0xa40: mov w1, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_a44:
	/* 0xa44: add x2, x9, #0x34 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 52ULL);
arm64_l_a48:
	/* 0xa48: add x9, x29, #0x89 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 137ULL);
arm64_l_a4c:
	/* 0xa4c: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_a50:
	/* 0xa50: add x8, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_a54:
	/* 0xa54: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_a58:
	/* 0xa58: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_a5c:
	/* 0xa5c: add x0, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_a60:
	/* 0xa60: blr x11 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X11);
		if (ARM64_SIM_L_REG_TAG(ARM64_X11) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0xa64ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_a64:
	/* 0xa64: cmp w0, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_a68:
	/* 0xa68: b.lt aa4 <sched_process_exec_event_submit_tail+0xaa4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0xa68, 0xaa4, arm64_l_aa4);
arm64_l_a6c:
	/* 0xa6c: mov w9, #0x6cfb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 27899ULL);
arm64_l_a70:
	/* 0xa70: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_a74:
	/* 0xa74: cmp w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_a78:
	/* 0xa78: b.hi aa4 <sched_process_exec_event_submit_tail+0xaa4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xa78, 0xaa4, arm64_l_aa4);
arm64_l_a7c:
	/* 0xa7c: mov x9, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a80:
	/* 0xa80: ldrb w10, [x9, #136]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 136ULL);
arm64_l_a84:
	/* 0xa84: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_a88:
	/* 0xa88: stur w0, [x8, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_a8c:
	/* 0xa8c: ldrh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_a90:
	/* 0xa90: add w8, w0, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_a94:
	/* 0xa94: add w8, w8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_a98:
	/* 0xa98: strh w8, [x24, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_a9c:
	/* 0xa9c: add w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_aa0:
	/* 0xaa0: strb w8, [x9] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_aa4:
	/* 0xaa4: ldr x8, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_aa8:
	/* 0xaa8: str x24, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_aac:
	/* 0xaac: ldrb w8, [x8, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_ab0:
	/* 0xab0: tbz w8, #0, c24 <sched_process_exec_event_submit_tail+0xc24> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 0, 0xab0, 0xc24, arm64_l_c24);
arm64_l_ab4:
	/* 0xab4: add x2, x19, #0x58 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_ab8:
	/* 0xab8: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_abc:
	/* 0xabc: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_ac0:
	/* 0xac0: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_ac4:
	/* 0xac4: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_ac8:
	/* 0xac8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_acc:
	/* 0xacc: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_ad0:
	/* 0xad0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xad4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_ad4:
	/* 0xad4: ldr x24, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_ad8:
	/* 0xad8: add x2, x19, #0x60 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_adc:
	/* 0xadc: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_ae0:
	/* 0xae0: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_ae4:
	/* 0xae4: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_ae8:
	/* 0xae8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_aec:
	/* 0xaec: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xaf0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_af0:
	/* 0xaf0: ldr x19, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_af4:
	/* 0xaf4: add x2, x23, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_af8:
	/* 0xaf8: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_afc:
	/* 0xafc: add x9, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_b00:
	/* 0xb00: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_b04:
	/* 0xb04: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_b08:
	/* 0xb08: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xb0cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_b0c:
	/* 0xb0c: cmp x24, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X24, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_b10:
	/* 0xb10: b.cs c24 <sched_process_exec_event_submit_tail+0xc24> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xb10, 0xc24, arm64_l_c24);
arm64_l_b14:
	/* 0xb14: sub w8, w19, w24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X19, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_b18:
	/* 0xb18: mov w9, #0x1fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8191ULL);
arm64_l_b1c:
	/* 0xb1c: ldr x20, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_b20:
	/* 0xb20: cmp w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_b24:
	/* 0xb24: csel w8, w8, w9, lt */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_LT, 0);
arm64_l_b28:
	/* 0xb28: str w8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_b2c:
	/* 0xb2c: ldrh w8, [x20, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_b30:
	/* 0xb30: ubfx x9, x8, #8, #24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_BITFIELD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFX, 8, 24), 0);
arm64_l_b34:
	/* 0xb34: cmp w9, #0x7c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 124ULL);
arm64_l_b38:
	/* 0xb38: b.hi c24 <sched_process_exec_event_submit_tail+0xc24> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xb38, 0xc24, arm64_l_c24);
arm64_l_b3c:
	/* 0xb3c: add x8, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_b40:
	/* 0xb40: mov w9, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_b44:
	/* 0xb44: strb w9, [x8, #137] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 137ULL);
arm64_l_b48:
	/* 0xb48: mov w9, #0x7cfb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 31995ULL);
arm64_l_b4c:
	/* 0xb4c: ldrh w8, [x20, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_b50:
	/* 0xb50: cmp w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_b54:
	/* 0xb54: b.hi c24 <sched_process_exec_event_submit_tail+0xc24> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xb54, 0xc24, arm64_l_c24);
arm64_l_b58:
	/* 0xb58: add x19, x29, #0x89 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 137ULL);
arm64_l_b5c:
	/* 0xb5c: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_b60:
	/* 0xb60: add x10, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_b64:
	/* 0xb64: add x2, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_b68:
	/* 0xb68: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_b6c:
	/* 0xb6c: add x8, x8, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_b70:
	/* 0xb70: add x8, x8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_b74:
	/* 0xb74: ldrh w8, [x20, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_b78:
	/* 0xb78: add x8, x8, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_b7c:
	/* 0xb7c: add x0, x8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_b80:
	/* 0xb80: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xb84ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_b84:
	/* 0xb84: ldrh w8, [x20, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_b88:
	/* 0xb88: ubfx x9, x8, #3, #29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_BITFIELD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFX, 3, 29), 0);
arm64_l_b8c:
	/* 0xb8c: cmp w9, #0xf9e */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3998ULL);
arm64_l_b90:
	/* 0xb90: b.hi c24 <sched_process_exec_event_submit_tail+0xc24> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xb90, 0xc24, arm64_l_c24);
arm64_l_b94:
	/* 0xb94: add x8, x8, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_b98:
	/* 0xb98: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_b9c:
	/* 0xb9c: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_ba0:
	/* 0xba0: add x2, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_ba4:
	/* 0xba4: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_ba8:
	/* 0xba8: add x8, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_bac:
	/* 0xbac: ldrh w8, [x20, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_bb0:
	/* 0xbb0: add x8, x8, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_bb4:
	/* 0xbb4: add x0, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_bb8:
	/* 0xbb8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xbbcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_bbc:
	/* 0xbbc: ldrh w8, [x20, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_bc0:
	/* 0xbc0: ubfx x9, x8, #3, #29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_BITFIELD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFX, 3, 29), 0);
arm64_l_bc4:
	/* 0xbc4: cmp w9, #0xb9e */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2974ULL);
arm64_l_bc8:
	/* 0xbc8: b.hi c24 <sched_process_exec_event_submit_tail+0xc24> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xbc8, 0xc24, arm64_l_c24);
arm64_l_bcc:
	/* 0xbcc: ldr w10, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_bd0:
	/* 0xbd0: add x9, x29, #0x89 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 137ULL);
arm64_l_bd4:
	/* 0xbd4: mov w11, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_bd8:
	/* 0xbd8: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_bdc:
	/* 0xbdc: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_be0:
	/* 0xbe0: add x8, x8, #0x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_be4:
	/* 0xbe4: and x10, x10, #0x1fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 8191ULL);
arm64_l_be8:
	/* 0xbe8: ldrh w8, [x20, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_bec:
	/* 0xbec: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_bf0:
	/* 0xbf0: ldr w9, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_bf4:
	/* 0xbf4: add x0, x8, #0x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_bf8:
	/* 0xbf8: and w1, w9, #0x1fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 8191ULL);
arm64_l_bfc:
	/* 0xbfc: blr x11 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X11);
		if (ARM64_SIM_L_REG_TAG(ARM64_X11) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xc00ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_c00:
	/* 0xc00: cbnz x0, c24 <sched_process_exec_event_submit_tail+0xc24> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0xc00, 0xc24, arm64_l_c24);
arm64_l_c04:
	/* 0xc04: ldrh w8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_c08:
	/* 0xc08: ldrh w9, [x20, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_c0c:
	/* 0xc0c: add w8, w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_c10:
	/* 0xc10: add w8, w8, #0x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_c14:
	/* 0xc14: strh w8, [x20, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_c18:
	/* 0xc18: ldrb w8, [x29, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_c1c:
	/* 0xc1c: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_c20:
	/* 0xc20: strb w8, [x29, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_c24:
	/* 0xc24: add x2, x21, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_c28:
	/* 0xc28: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_c2c:
	/* 0xc2c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_c30:
	/* 0xc30: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_c34:
	/* 0xc34: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_c38:
	/* 0xc38: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_c3c:
	/* 0xc3c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xc40ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_c40:
	/* 0xc40: ldr x24, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_c44:
	/* 0xc44: cbz x24, da8 <sched_process_exec_event_submit_tail+0xda8> */
	ARM64_SIM_A64_CBZ(ARM64_X24, 0xc44, 0xda8, arm64_l_da8);
arm64_l_c48:
	/* 0xc48: str wzr, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_c4c:
	/* 0xc4c: adrp x0, 0 <bufs> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&bufs_0));
arm64_l_c50:
	/* 0xc50: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_c54:
	/* 0xc54: add x9, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_c58:
	/* 0xc58: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c5c:
	/* 0xc5c: add x1, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_c60:
	/* 0xc60: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xc64ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_c64:
	/* 0xc64: cbz x0, da8 <sched_process_exec_event_submit_tail+0xda8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xc64, 0xda8, arm64_l_da8);
arm64_l_c68:
	/* 0xc68: add x2, x24, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_c6c:
	/* 0xc6c: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_c70:
	/* 0xc70: add x9, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_c74:
	/* 0xc74: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_c78:
	/* 0xc78: mov x23, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_c7c:
	/* 0xc7c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_c80:
	/* 0xc80: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_c84:
	/* 0xc84: mov w19, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_c88:
	/* 0xc88: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xc8cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_c8c:
	/* 0xc8c: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_c90:
	/* 0xc90: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_c94:
	/* 0xc94: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_c98:
	/* 0xc98: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_c9c:
	/* 0xc9c: str x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_ca0:
	/* 0xca0: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_ca4:
	/* 0xca4: ldr x2, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_ca8:
	/* 0xca8: blr x19 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X19);
		if (ARM64_SIM_L_REG_TAG(ARM64_X19) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xcacULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_cac:
	/* 0xcac: ldr w8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_cb0:
	/* 0xcb0: tbnz w8, #5, dc4 <sched_process_exec_event_submit_tail+0xdc4> */
	ARM64_SIM_A64_TBNZ(ARM64_X8, 5, 0xcb0, 0xdc4, arm64_l_dc4);
arm64_l_cb4:
	/* 0xcb4: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_cb8:
	/* 0xcb8: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_cbc:
	/* 0xcbc: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_cc0:
	/* 0xcc0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_cc4:
	/* 0xcc4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_cc8:
	/* 0xcc8: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ccc:
	/* 0xccc: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_cd0:
	/* 0xcd0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xcd4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_cd4:
	/* 0xcd4: ldr x24, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_cd8:
	/* 0xcd8: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_cdc:
	/* 0xcdc: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_ce0:
	/* 0xce0: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_ce4:
	/* 0xce4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_ce8:
	/* 0xce8: sub x8, x24, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_cec:
	/* 0xcec: str x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_cf0:
	/* 0xcf0: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_cf4:
	/* 0xcf4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xcf8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_cf8:
	/* 0xcf8: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_cfc:
	/* 0xcfc: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_d00:
	/* 0xd00: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_d04:
	/* 0xd04: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_d08:
	/* 0xd08: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d0c:
	/* 0xd0c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xd10ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d10:
	/* 0xd10: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_d14:
	/* 0xd14: ldr x19, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_d18:
	/* 0xd18: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_d1c:
	/* 0xd1c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_d20:
	/* 0xd20: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_d24:
	/* 0xd24: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_d28:
	/* 0xd28: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xd2cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d2c:
	/* 0xd2c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_d30:
	/* 0xd30: cmp x8, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d34:
	/* 0xd34: b.eq dd8 <sched_process_exec_event_submit_tail+0xdd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd34, 0xdd8, arm64_l_dd8);
arm64_l_d38:
	/* 0xd38: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_d3c:
	/* 0xd3c: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d40:
	/* 0xd40: b.eq dd8 <sched_process_exec_event_submit_tail+0xdd8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd40, 0xdd8, arm64_l_dd8);
arm64_l_d44:
	/* 0xd44: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_d48:
	/* 0xd48: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_d4c:
	/* 0xd4c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_d50:
	/* 0xd50: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_d54:
	/* 0xd54: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_d58:
	/* 0xd58: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_d5c:
	/* 0xd5c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xd60ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d60:
	/* 0xd60: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_d64:
	/* 0xd64: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_d68:
	/* 0xd68: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_d6c:
	/* 0xd6c: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_d70:
	/* 0xd70: neg w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_d74:
	/* 0xd74: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_d78:
	/* 0xd78: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_d7c:
	/* 0xd7c: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_d80:
	/* 0xd80: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0xd84ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d84:
	/* 0xd84: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_d88:
	/* 0xd88: b.lt f20 <sched_process_exec_event_submit_tail+0xf20> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0xd88, 0xf20, arm64_l_f20);
arm64_l_d8c:
	/* 0xd8c: mov w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16383ULL);
arm64_l_d90:
	/* 0xd90: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_d94:
	/* 0xd94: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_d98:
	/* 0xd98: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d9c:
	/* 0xd9c: mov w8, #0x4000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16384ULL);
arm64_l_da0:
	/* 0xda0: sub w19, w8, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_da4:
	/* 0xda4: b e54 <sched_process_exec_event_submit_tail+0xe54> */
	ARM64_SIM_A64_JMP(0xda4, 0xe54, arm64_l_e54);
arm64_l_da8:
	/* 0xda8: ldr x19, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_dac:
	/* 0xdac: mov x2, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_db0:
	/* 0xdb0: ldrh w8, [x19, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_db4:
	/* 0xdb4: ubfx x9, x8, #8, #24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_BITFIELD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFX, 8, 24), 0);
arm64_l_db8:
	/* 0xdb8: cmp w9, #0x7c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 124ULL);
arm64_l_dbc:
	/* 0xdbc: b.ls f74 <sched_process_exec_event_submit_tail+0xf74> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0xdbc, 0xf74, arm64_l_f74);
arm64_l_dc0:
	/* 0xdc0: b 11a4 <sched_process_exec_event_submit_tail+0x11a4> */
	ARM64_SIM_A64_JMP(0xdc0, 0x11a4, arm64_l_11a4);
arm64_l_dc4:
	/* 0xdc4: adrp x2, 0 <sched_process_exec_event_submit_tail> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_RODATA, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)__arm64_rodata_0));
arm64_l_dc8:
	/* 0xdc8: add x2, x2, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_dcc:
	/* 0xdcc: mov w8, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_dd0:
	/* 0xdd0: mov w9, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_dd4:
	/* 0xdd4: b f4c <sched_process_exec_event_submit_tail+0xf4c> */
	ARM64_SIM_A64_JMP(0xdd4, 0xf4c, arm64_l_f4c);
arm64_l_dd8:
	/* 0xdd8: cmp x8, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ddc:
	/* 0xddc: b.ne f20 <sched_process_exec_event_submit_tail+0xf20> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xddc, 0xf20, arm64_l_f20);
arm64_l_de0:
	/* 0xde0: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_de4:
	/* 0xde4: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_de8:
	/* 0xde8: b.eq f20 <sched_process_exec_event_submit_tail+0xf20> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xde8, 0xf20, arm64_l_f20);
arm64_l_dec:
	/* 0xdec: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_df0:
	/* 0xdf0: mov w19, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_df4:
	/* 0xdf4: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_df8:
	/* 0xdf8: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_dfc:
	/* 0xdfc: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_e00:
	/* 0xe00: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_e04:
	/* 0xe04: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_e08:
	/* 0xe08: mov w20, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_e0c:
	/* 0xe0c: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_e10:
	/* 0xe10: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xe14ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_e14:
	/* 0xe14: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_e18:
	/* 0xe18: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_e1c:
	/* 0xe1c: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_e20:
	/* 0xe20: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_e24:
	/* 0xe24: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_e28:
	/* 0xe28: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_e2c:
	/* 0xe2c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xe30ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_e30:
	/* 0xe30: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_e34:
	/* 0xe34: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_e38:
	/* 0xe38: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_e3c:
	/* 0xe3c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_e40:
	/* 0xe40: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_e44:
	/* 0xe44: blr x20 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X20);
		if (ARM64_SIM_L_REG_TAG(ARM64_X20) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xe48ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_e48:
	/* 0xe48: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_e4c:
	/* 0xe4c: mov w19, #0x4000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16384ULL);
arm64_l_e50:
	/* 0xe50: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_e54:
	/* 0xe54: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_e58:
	/* 0xe58: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_e5c:
	/* 0xe5c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_e60:
	/* 0xe60: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_e64:
	/* 0xe64: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_e68:
	/* 0xe68: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e6c:
	/* 0xe6c: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_e70:
	/* 0xe70: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xe74ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_e74:
	/* 0xe74: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_e78:
	/* 0xe78: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_e7c:
	/* 0xe7c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_e80:
	/* 0xe80: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_e84:
	/* 0xe84: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_e88:
	/* 0xe88: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_e8c:
	/* 0xe8c: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xe90ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_e90:
	/* 0xe90: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_e94:
	/* 0xe94: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_e98:
	/* 0xe98: b.eq f10 <sched_process_exec_event_submit_tail+0xf10> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe98, 0xf10, arm64_l_f10);
arm64_l_e9c:
	/* 0xe9c: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_ea0:
	/* 0xea0: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ea4:
	/* 0xea4: b.eq f10 <sched_process_exec_event_submit_tail+0xf10> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xea4, 0xf10, arm64_l_f10);
arm64_l_ea8:
	/* 0xea8: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_eac:
	/* 0xeac: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_eb0:
	/* 0xeb0: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_eb4:
	/* 0xeb4: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_eb8:
	/* 0xeb8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_ebc:
	/* 0xebc: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_ec0:
	/* 0xec0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xec4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_ec4:
	/* 0xec4: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_ec8:
	/* 0xec8: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_ecc:
	/* 0xecc: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_ed0:
	/* 0xed0: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_ed4:
	/* 0xed4: b.cc 1170 <sched_process_exec_event_submit_tail+0x1170> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xed4, 0x1170, arm64_l_1170);
arm64_l_ed8:
	/* 0xed8: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_edc:
	/* 0xedc: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_ee0:
	/* 0xee0: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_ee4:
	/* 0xee4: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_ee8:
	/* 0xee8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0xeecULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_eec:
	/* 0xeec: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_ef0:
	/* 0xef0: b.lt f18 <sched_process_exec_event_submit_tail+0xf18> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0xef0, 0xf18, arm64_l_f18);
arm64_l_ef4:
	/* 0xef4: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_ef8:
	/* 0xef8: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_efc:
	/* 0xefc: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_f00:
	/* 0xf00: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_f04:
	/* 0xf04: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f08:
	/* 0xf08: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_f0c:
	/* 0xf0c: b 10ec <sched_process_exec_event_submit_tail+0x10ec> */
	ARM64_SIM_A64_JMP(0xf0c, 0x10ec, arm64_l_10ec);
arm64_l_f10:
	/* 0xf10: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f14:
	/* 0xf14: b.eq 107c <sched_process_exec_event_submit_tail+0x107c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf14, 0x107c, arm64_l_107c);
arm64_l_f18:
	/* 0xf18: cmp w19, #0x4, lsl #12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 16384ULL);
arm64_l_f1c:
	/* 0xf1c: b.ne 1170 <sched_process_exec_event_submit_tail+0x1170> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xf1c, 0x1170, arm64_l_1170);
arm64_l_f20:
	/* 0xf20: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_f24:
	/* 0xf24: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_f28:
	/* 0xf28: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_f2c:
	/* 0xf2c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_f30:
	/* 0xf30: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_f34:
	/* 0xf34: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_f38:
	/* 0xf38: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_f3c:
	/* 0xf3c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0xf40ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_f40:
	/* 0xf40: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_f44:
	/* 0xf44: mov w8, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_f48:
	/* 0xf48: mov w9, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_f4c:
	/* 0xf4c: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f50:
	/* 0xf50: mov w1, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_f54:
	/* 0xf54: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0xf58ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_f58:
	/* 0xf58: mov x8, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f5c:
	/* 0xf5c: ldr x19, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_f60:
	/* 0xf60: add x2, x23, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_f64:
	/* 0xf64: ldrh w8, [x19, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_f68:
	/* 0xf68: ubfx x9, x8, #8, #24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_BITFIELD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFX, 8, 24), 0);
arm64_l_f6c:
	/* 0xf6c: cmp w9, #0x7c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 124ULL);
arm64_l_f70:
	/* 0xf70: b.hi 11a4 <sched_process_exec_event_submit_tail+0x11a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xf70, 0x11a4, arm64_l_11a4);
arm64_l_f74:
	/* 0xf74: add x8, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_f78:
	/* 0xf78: mov w9, #0x11 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 17ULL);
arm64_l_f7c:
	/* 0xf7c: strb w9, [x8, #137] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 137ULL);
arm64_l_f80:
	/* 0xf80: mov w9, #0x6cfb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 27899ULL);
arm64_l_f84:
	/* 0xf84: ldrh w8, [x19, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_f88:
	/* 0xf88: cmp w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_f8c:
	/* 0xf8c: strh w8, [x19, #3502] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3502ULL);
arm64_l_f90:
	/* 0xf90: b.hi 11a4 <sched_process_exec_event_submit_tail+0x11a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xf90, 0x11a4, arm64_l_11a4);
arm64_l_f94:
	/* 0xf94: add x9, x29, #0x89 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 137ULL);
arm64_l_f98:
	/* 0xf98: mov w10, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_f9c:
	/* 0xf9c: mov w11, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_fa0:
	/* 0xfa0: mov w1, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_fa4:
	/* 0xfa4: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_fa8:
	/* 0xfa8: add x8, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_fac:
	/* 0xfac: ldrh w8, [x19, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_fb0:
	/* 0xfb0: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_fb4:
	/* 0xfb4: add x0, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_fb8:
	/* 0xfb8: blr x11 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X11);
		if (ARM64_SIM_L_REG_TAG(ARM64_X11) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0xfbcULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_fbc:
	/* 0xfbc: cmp w0, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_fc0:
	/* 0xfc0: b.lt 11a4 <sched_process_exec_event_submit_tail+0x11a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0xfc0, 0x11a4, arm64_l_11a4);
arm64_l_fc4:
	/* 0xfc4: mov w9, #0x6cfb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 27899ULL);
arm64_l_fc8:
	/* 0xfc8: ldrh w8, [x19, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_fcc:
	/* 0xfcc: cmp w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_fd0:
	/* 0xfd0: b.hi 11a4 <sched_process_exec_event_submit_tail+0x11a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0xfd0, 0x11a4, arm64_l_11a4);
arm64_l_fd4:
	/* 0xfd4: mov x9, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_fd8:
	/* 0xfd8: ldrb w10, [x9, #136]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 136ULL);
arm64_l_fdc:
	/* 0xfdc: add x8, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_fe0:
	/* 0xfe0: stur w0, [x8, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_fe4:
	/* 0xfe4: ldrh w8, [x19, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_fe8:
	/* 0xfe8: add w8, w0, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_fec:
	/* 0xfec: add w8, w8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_ff0:
	/* 0xff0: strh w8, [x19, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_ff4:
	/* 0xff4: add w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_ff8:
	/* 0xff8: strb w8, [x9] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_ffc:
	/* 0xffc: b 11a4 <sched_process_exec_event_submit_tail+0x11a4> */
	ARM64_SIM_A64_JMP(0xffc, 0x11a4, arm64_l_11a4);
arm64_l_1000:
	/* 0x1000: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1004:
	/* 0x1004: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1004, 0x4dc, arm64_l_4dc);
arm64_l_1008:
	/* 0x1008: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_100c:
	/* 0x100c: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1010:
	/* 0x1010: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1010, 0x4dc, arm64_l_4dc);
arm64_l_1014:
	/* 0x1014: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1018:
	/* 0x1018: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_101c:
	/* 0x101c: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1020:
	/* 0x1020: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1024:
	/* 0x1024: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1028:
	/* 0x1028: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_102c:
	/* 0x102c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1030:
	/* 0x1030: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1034:
	/* 0x1034: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1038:
	/* 0x1038: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x103cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_103c:
	/* 0x103c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1040:
	/* 0x1040: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1044:
	/* 0x1044: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1048:
	/* 0x1048: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_104c:
	/* 0x104c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1050:
	/* 0x1050: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1054:
	/* 0x1054: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1058ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1058:
	/* 0x1058: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_105c:
	/* 0x105c: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1060:
	/* 0x1060: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1064:
	/* 0x1064: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1068:
	/* 0x1068: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_106c:
	/* 0x106c: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1070ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1070:
	/* 0x1070: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1074:
	/* 0x1074: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1078:
	/* 0x1078: b 1750 <sched_process_exec_event_submit_tail+0x1750> */
	ARM64_SIM_A64_JMP(0x1078, 0x1750, arm64_l_1750);
arm64_l_107c:
	/* 0x107c: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1080:
	/* 0x1080: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1084:
	/* 0x1084: b.eq f18 <sched_process_exec_event_submit_tail+0xf18> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1084, 0xf18, arm64_l_f18);
arm64_l_1088:
	/* 0x1088: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_108c:
	/* 0x108c: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1090:
	/* 0x1090: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1094:
	/* 0x1094: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1098:
	/* 0x1098: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_109c:
	/* 0x109c: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_10a0:
	/* 0x10a0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_10a4:
	/* 0x10a4: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_10a8:
	/* 0x10a8: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_10ac:
	/* 0x10ac: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x10b0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_10b0:
	/* 0x10b0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_10b4:
	/* 0x10b4: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_10b8:
	/* 0x10b8: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_10bc:
	/* 0x10bc: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_10c0:
	/* 0x10c0: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_10c4:
	/* 0x10c4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_10c8:
	/* 0x10c8: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x10ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_10cc:
	/* 0x10cc: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_10d0:
	/* 0x10d0: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_10d4:
	/* 0x10d4: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_10d8:
	/* 0x10d8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_10dc:
	/* 0x10dc: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_10e0:
	/* 0x10e0: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x10e4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_10e4:
	/* 0x10e4: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_10e8:
	/* 0x10e8: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_10ec:
	/* 0x10ec: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_10f0:
	/* 0x10f0: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_10f4:
	/* 0x10f4: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_10f8:
	/* 0x10f8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_10fc:
	/* 0x10fc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1100:
	/* 0x1100: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1104:
	/* 0x1104: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1108:
	/* 0x1108: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x110cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_110c:
	/* 0x110c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1110:
	/* 0x1110: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1114:
	/* 0x1114: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1118:
	/* 0x1118: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_111c:
	/* 0x111c: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1120:
	/* 0x1120: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1124:
	/* 0x1124: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1128ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1128:
	/* 0x1128: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_112c:
	/* 0x112c: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1130:
	/* 0x1130: b.eq 169c <sched_process_exec_event_submit_tail+0x169c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1130, 0x169c, arm64_l_169c);
arm64_l_1134:
	/* 0x1134: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1138:
	/* 0x1138: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_113c:
	/* 0x113c: b.eq 169c <sched_process_exec_event_submit_tail+0x169c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x113c, 0x169c, arm64_l_169c);
arm64_l_1140:
	/* 0x1140: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1144:
	/* 0x1144: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1148:
	/* 0x1148: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_114c:
	/* 0x114c: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1150:
	/* 0x1150: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1154:
	/* 0x1154: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1158:
	/* 0x1158: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x115cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_115c:
	/* 0x115c: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_1160:
	/* 0x1160: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1164:
	/* 0x1164: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1168:
	/* 0x1168: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_116c:
	/* 0x116c: b.cs 1814 <sched_process_exec_event_submit_tail+0x1814> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x116c, 0x1814, arm64_l_1814);
arm64_l_1170:
	/* 0x1170: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1174:
	/* 0x1174: mov w10, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_1178:
	/* 0x1178: and x9, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_117c:
	/* 0x117c: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_1180:
	/* 0x1180: strb w10, [x23, x9] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1184:
	/* 0x1184: mov w9, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16383ULL);
arm64_l_1188:
	/* 0x1188: strb wzr, [x23, x9] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_XZR, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_118c:
	/* 0x118c: ldr x19, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1190:
	/* 0x1190: add x2, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1194:
	/* 0x1194: ldrh w8, [x19, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_1198:
	/* 0x1198: ubfx x9, x8, #8, #24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_BITFIELD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFX, 8, 24), 0);
arm64_l_119c:
	/* 0x119c: cmp w9, #0x7c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 124ULL);
arm64_l_11a0:
	/* 0x11a0: b.ls f74 <sched_process_exec_event_submit_tail+0xf74> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x11a0, 0xf74, arm64_l_f74);
arm64_l_11a4:
	/* 0x11a4: ldr x24, [x29, #32208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32208ULL);
arm64_l_11a8:
	/* 0x11a8: add x8, x29, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_11ac:
	/* 0x11ac: mov w23, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_11b0:
	/* 0x11b0: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_11b4:
	/* 0x11b4: str x8, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_11b8:
	/* 0x11b8: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_11bc:
	/* 0x11bc: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_11c0:
	/* 0x11c0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_11c4:
	/* 0x11c4: add x25, x24, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_11c8:
	/* 0x11c8: mov x2, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11cc:
	/* 0x11cc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x11d0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_11d0:
	/* 0x11d0: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_11d4:
	/* 0x11d4: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_11d8:
	/* 0x11d8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_11dc:
	/* 0x11dc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_11e0:
	/* 0x11e0: str x8, [sp, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_11e4:
	/* 0x11e4: add x2, x8, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_11e8:
	/* 0x11e8: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_11ec:
	/* 0x11ec: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x11f0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_11f0:
	/* 0x11f0: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_11f4:
	/* 0x11f4: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_11f8:
	/* 0x11f8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_11fc:
	/* 0x11fc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1200:
	/* 0x1200: add x2, x8, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_1204:
	/* 0x1204: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1208:
	/* 0x1208: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x120cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_120c:
	/* 0x120c: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1210:
	/* 0x1210: mov w19, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1214:
	/* 0x1214: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1218:
	/* 0x1218: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_121c:
	/* 0x121c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1220:
	/* 0x1220: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1224:
	/* 0x1224: add x2, x20, #0x1c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_1228:
	/* 0x1228: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x122cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_122c:
	/* 0x122c: ldr w8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1230:
	/* 0x1230: mov x22, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1234:
	/* 0x1234: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1238:
	/* 0x1238: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_123c:
	/* 0x123c: str w8, [x29, #44] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 44ULL);
arm64_l_1240:
	/* 0x1240: add x29, x24, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1244:
	/* 0x1244: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1248:
	/* 0x1248: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_124c:
	/* 0x124c: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1250:
	/* 0x1250: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1254ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1254:
	/* 0x1254: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1258:
	/* 0x1258: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_125c:
	/* 0x125c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1260:
	/* 0x1260: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1264:
	/* 0x1264: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1268:
	/* 0x1268: mov x2, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_126c:
	/* 0x126c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1270ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1270:
	/* 0x1270: ldr w8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1274:
	/* 0x1274: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1278:
	/* 0x1278: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_127c:
	/* 0x127c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1280:
	/* 0x1280: add x8, x21, x8, lsl #4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 4), 0);
arm64_l_1284:
	/* 0x1284: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1288:
	/* 0x1288: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_128c:
	/* 0x128c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1290ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1290:
	/* 0x1290: ldr w8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1294:
	/* 0x1294: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1298:
	/* 0x1298: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_129c:
	/* 0x129c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_12a0:
	/* 0x12a0: str w8, [x22, #28] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 28ULL);
arm64_l_12a4:
	/* 0x12a4: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_12a8:
	/* 0x12a8: mov x2, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_12ac:
	/* 0x12ac: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x12b0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_12b0:
	/* 0x12b0: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_12b4:
	/* 0x12b4: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_12b8:
	/* 0x12b8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_12bc:
	/* 0x12bc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_12c0:
	/* 0x12c0: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_12c4:
	/* 0x12c4: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_12c8:
	/* 0x12c8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x12ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_12cc:
	/* 0x12cc: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_12d0:
	/* 0x12d0: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_12d4:
	/* 0x12d4: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_12d8:
	/* 0x12d8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_12dc:
	/* 0x12dc: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_12e0:
	/* 0x12e0: mov x2, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_12e4:
	/* 0x12e4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x12e8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_12e8:
	/* 0x12e8: ldr w8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_12ec:
	/* 0x12ec: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_12f0:
	/* 0x12f0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_12f4:
	/* 0x12f4: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_12f8:
	/* 0x12f8: add x8, x21, x8, lsl #4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 4), 0);
arm64_l_12fc:
	/* 0x12fc: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1300:
	/* 0x1300: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1304:
	/* 0x1304: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1308ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1308:
	/* 0x1308: ldr w8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_130c:
	/* 0x130c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1310:
	/* 0x1310: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1314:
	/* 0x1314: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1318:
	/* 0x1318: str w8, [x22, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_131c:
	/* 0x131c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1320:
	/* 0x1320: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1324:
	/* 0x1324: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1328ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1328:
	/* 0x1328: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_132c:
	/* 0x132c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1330:
	/* 0x1330: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1334:
	/* 0x1334: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1338:
	/* 0x1338: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_133c:
	/* 0x133c: mov x2, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1340:
	/* 0x1340: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1344ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1344:
	/* 0x1344: ldr w8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1348:
	/* 0x1348: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_134c:
	/* 0x134c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1350:
	/* 0x1350: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1354:
	/* 0x1354: add x8, x21, x8, lsl #4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 4), 0);
arm64_l_1358:
	/* 0x1358: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_135c:
	/* 0x135c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1360:
	/* 0x1360: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1364ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1364:
	/* 0x1364: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1368:
	/* 0x1368: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_136c:
	/* 0x136c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1370:
	/* 0x1370: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1374:
	/* 0x1374: add x2, x8, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1378:
	/* 0x1378: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_137c:
	/* 0x137c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1380ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1380:
	/* 0x1380: str x20, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1384:
	/* 0x1384: ldr w29, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1388:
	/* 0x1388: add x25, x20, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_138c:
	/* 0x138c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1390:
	/* 0x1390: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1394:
	/* 0x1394: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1398:
	/* 0x1398: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_139c:
	/* 0x139c: mov x2, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_13a0:
	/* 0x13a0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x13a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_13a4:
	/* 0x13a4: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_13a8:
	/* 0x13a8: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_13ac:
	/* 0x13ac: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_13b0:
	/* 0x13b0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_13b4:
	/* 0x13b4: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_13b8:
	/* 0x13b8: mov x2, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_13bc:
	/* 0x13bc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x13c0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_13c0:
	/* 0x13c0: ldr w8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_13c4:
	/* 0x13c4: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_13c8:
	/* 0x13c8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_13cc:
	/* 0x13cc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_13d0:
	/* 0x13d0: add x8, x21, x8, lsl #4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 4), 0);
arm64_l_13d4:
	/* 0x13d4: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_13d8:
	/* 0x13d8: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_13dc:
	/* 0x13dc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x13e0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_13e0:
	/* 0x13e0: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_13e4:
	/* 0x13e4: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_13e8:
	/* 0x13e8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_13ec:
	/* 0x13ec: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_13f0:
	/* 0x13f0: add x2, x8, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_13f4:
	/* 0x13f4: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_13f8:
	/* 0x13f8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x13fcULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_13fc:
	/* 0x13fc: ldr w8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1400:
	/* 0x1400: cmp w29, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1404:
	/* 0x1404: b.ne 146c <sched_process_exec_event_submit_tail+0x146c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1404, 0x146c, arm64_l_146c);
arm64_l_1408:
	/* 0x1408: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_140c:
	/* 0x140c: add x9, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1410:
	/* 0x1410: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1414:
	/* 0x1414: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1418:
	/* 0x1418: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_141c:
	/* 0x141c: mov x2, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1420:
	/* 0x1420: mov w19, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1424:
	/* 0x1424: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1428ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1428:
	/* 0x1428: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_142c:
	/* 0x142c: mov w20, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1430:
	/* 0x1430: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1434:
	/* 0x1434: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1438:
	/* 0x1438: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_143c:
	/* 0x143c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1440:
	/* 0x1440: mov x2, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1444:
	/* 0x1444: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1448ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1448:
	/* 0x1448: ldr w8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_144c:
	/* 0x144c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1450:
	/* 0x1450: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1454:
	/* 0x1454: add x8, x21, x8, lsl #4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 4), 0);
arm64_l_1458:
	/* 0x1458: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_145c:
	/* 0x145c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1460:
	/* 0x1460: blr x19 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X19);
		if (ARM64_SIM_L_REG_TAG(ARM64_X19) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1464ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1464:
	/* 0x1464: ldr w8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1468:
	/* 0x1468: str w8, [x22, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_146c:
	/* 0x146c: str w29, [x22, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1470:
	/* 0x1470: add x25, x24, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1474:
	/* 0x1474: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1478:
	/* 0x1478: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_147c:
	/* 0x147c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1480:
	/* 0x1480: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1484:
	/* 0x1484: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1488:
	/* 0x1488: mov x2, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_148c:
	/* 0x148c: mov w19, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1490:
	/* 0x1490: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1494ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1494:
	/* 0x1494: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1498:
	/* 0x1498: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_149c:
	/* 0x149c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_14a0:
	/* 0x14a0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_14a4:
	/* 0x14a4: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_14a8:
	/* 0x14a8: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_14ac:
	/* 0x14ac: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x14b0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_14b0:
	/* 0x14b0: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_14b4:
	/* 0x14b4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14b8:
	/* 0x14b8: add x10, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_14bc:
	/* 0x14bc: mov w11, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_14c0:
	/* 0x14c0: ldr x2, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_14c4:
	/* 0x14c4: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_14c8:
	/* 0x14c8: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14cc:
	/* 0x14cc: blr x11 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X11);
		if (ARM64_SIM_L_REG_TAG(ARM64_X11) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x14d0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_14d0:
	/* 0x14d0: ldr w8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_14d4:
	/* 0x14d4: str w8, [x22, #52] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 52ULL);
arm64_l_14d8:
	/* 0x14d8: mov w8, #0xf */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 15ULL);
arm64_l_14dc:
	/* 0x14dc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 15ULL: ARM64_SIM_A64_LINK(0x14e0ULL); ARM64_SIM_BPF_CALL_bpf_get_current_uid_gid(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_14e0:
	/* 0x14e0: str w0, [x22, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_14e4:
	/* 0x14e4: add x2, x24, #0x58 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_14e8:
	/* 0x14e8: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_14ec:
	/* 0x14ec: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_14f0:
	/* 0x14f0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_14f4:
	/* 0x14f4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_14f8:
	/* 0x14f8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x14fcULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_14fc:
	/* 0x14fc: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1500:
	/* 0x1500: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1504:
	/* 0x1504: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1508:
	/* 0x1508: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_150c:
	/* 0x150c: str x8, [x22, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1510:
	/* 0x1510: ldr x8, [sp, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1514:
	/* 0x1514: add x2, x8, #0x58 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1518:
	/* 0x1518: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_151c:
	/* 0x151c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1520ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1520:
	/* 0x1520: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1524:
	/* 0x1524: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1528:
	/* 0x1528: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_152c:
	/* 0x152c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1530:
	/* 0x1530: str x8, [x22, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1534:
	/* 0x1534: ldr x8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1538:
	/* 0x1538: add x2, x8, #0x58 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_153c:
	/* 0x153c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1540:
	/* 0x1540: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1544ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1544:
	/* 0x1544: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1548:
	/* 0x1548: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_154c:
	/* 0x154c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1550:
	/* 0x1550: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1554:
	/* 0x1554: str x8, [x22, #104] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_1558:
	/* 0x1558: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_155c:
	/* 0x155c: blr x19 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X19);
		if (ARM64_SIM_L_REG_TAG(ARM64_X19) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1560ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1560:
	/* 0x1560: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1564:
	/* 0x1564: tbz w8, #22, 1574 <sched_process_exec_event_submit_tail+0x1574> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 22, 0x1564, 0x1574, arm64_l_1574);
arm64_l_1568:
	/* 0x1568: ldr w8, [x22, #92] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_156c:
	/* 0x156c: orr w8, w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ORR, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1570:
	/* 0x1570: str w8, [x22, #92] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_1574:
	/* 0x1574: mov x24, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1578:
	/* 0x1578: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_157c:
	/* 0x157c: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1580:
	/* 0x1580: mov w20, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1584:
	/* 0x1584: str xzr, [x24, #60]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 60ULL);
arm64_l_1588:
	/* 0x1588: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_158c:
	/* 0x158c: str xzr, [x24, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1590:
	/* 0x1590: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 16ULL: ARM64_SIM_A64_LINK(0x1594ULL); ARM64_SIM_BPF_CALL_bpf_get_current_comm(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1594:
	/* 0x1594: mov w21, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1598:
	/* 0x1598: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_159c:
	/* 0x159c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_15a0:
	/* 0x15a0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_15a4:
	/* 0x15a4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_15a8:
	/* 0x15a8: mov x2, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_15ac:
	/* 0x15ac: mov w19, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_15b0:
	/* 0x15b0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x15b4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_15b4:
	/* 0x15b4: ldr x2, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_15b8:
	/* 0x15b8: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_15bc:
	/* 0x15bc: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_15c0:
	/* 0x15c0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_15c4:
	/* 0x15c4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_15c8:
	/* 0x15c8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x15ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_15cc:
	/* 0x15cc: ldr x2, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_15d0:
	/* 0x15d0: mov w8, #0x41 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 65ULL);
arm64_l_15d4:
	/* 0x15d4: add x21, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_15d8:
	/* 0x15d8: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_15dc:
	/* 0x15dc: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_15e0:
	/* 0x15e0: mov w1, #0x41 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 65ULL);
arm64_l_15e4:
	/* 0x15e4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x15e8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_15e8:
	/* 0x15e8: add x0, x24, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_15ec:
	/* 0x15ec: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_15f0:
	/* 0x15f0: add x2, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_15f4:
	/* 0x15f4: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_15f8:
	/* 0x15f8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x15fcULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_15fc:
	/* 0x15fc: ldr x0, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1600:
	/* 0x1600: ldr x2, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1604:
	/* 0x1604: mov w8, #0x68 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 104ULL);
arm64_l_1608:
	/* 0x1608: mov w1, #0x68 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 104ULL);
arm64_l_160c:
	/* 0x160c: blr x19 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X19);
		if (ARM64_SIM_L_REG_TAG(ARM64_X19) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1610ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1610:
	/* 0x1610: ldr x8, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1614:
	/* 0x1614: ldr x19, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1618:
	/* 0x1618: ldrb w8, [x8, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_161c:
	/* 0x161c: tbz w8, #3, 1644 <sched_process_exec_event_submit_tail+0x1644> */
	ARM64_SIM_A64_TBZ(ARM64_X8, 3, 0x161c, 0x1644, arm64_l_1644);
arm64_l_1620:
	/* 0x1620: adrp x1, 0 <stack_addresses> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&stack_addresses_5));
arm64_l_1624:
	/* 0x1624: mov w8, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_1628:
	/* 0x1628: mov w9, #0x1b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 27ULL);
arm64_l_162c:
	/* 0x162c: ldr x1, [x1] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1630:
	/* 0x1630: mov x0, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1634:
	/* 0x1634: mov w2, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 256ULL);
arm64_l_1638:
	/* 0x1638: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 27ULL: ARM64_SIM_A64_LINK(0x163cULL); ARM64_SIM_BPF_CALL_bpf_get_stackid(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_163c:
	/* 0x163c: tbnz w0, #31, 1644 <sched_process_exec_event_submit_tail+0x1644> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x163c, 0x1644, arm64_l_1644);
arm64_l_1640:
	/* 0x1640: str w0, [x22, #120] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 120ULL);
arm64_l_1644:
	/* 0x1644: ldr x8, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1648:
	/* 0x1648: mov w9, #0x7d00 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 32000ULL);
arm64_l_164c:
	/* 0x164c: adrp x1, 0 <events> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&events_3));
arm64_l_1650:
	/* 0x1650: mov x0, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1654:
	/* 0x1654: ldrh w8, [x8, #3466] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3466ULL);
arm64_l_1658:
	/* 0x1658: ldr x1, [x1] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_165c:
	/* 0x165c: mov w2, #0xffffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967295ULL);
arm64_l_1660:
	/* 0x1660: mov x3, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1664:
	/* 0x1664: cmp w8, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1668:
	/* 0x1668: csel w8, w8, w9, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_166c:
	/* 0x166c: mov w9, #0x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 25ULL);
arm64_l_1670:
	/* 0x1670: add w4, w8, #0x89 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X4, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 137ULL);
arm64_l_1674:
	/* 0x1674: mov w8, #0xffffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967295ULL);
arm64_l_1678:
	/* 0x1678: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 25ULL: ARM64_SIM_A64_LINK(0x167cULL); ARM64_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_167c:
	/* 0x167c: mov w0, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1680:
	/* 0x1680: ldp x20, x19, [sp, #224] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_1684:
	/* 0x1684: ldr x29, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_1688:
	/* 0x1688: ldp x22, x21, [sp, #208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_168c:
	/* 0x168c: ldp x24, x23, [sp, #192] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_1690:
	/* 0x1690: ldp x30, x25, [sp, #176] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_1694:
	/* 0x1694: add sp, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1698:
	/* 0x1698: b 4138 <__native_link_arm64_ret_trampoline> */
	ARM64_SIM_A64_JMP(0x1698, 0x4138, arm64_l_4138);
arm64_l_169c:
	/* 0x169c: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_16a0:
	/* 0x16a0: b.ne f18 <sched_process_exec_event_submit_tail+0xf18> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x16a0, 0xf18, arm64_l_f18);
arm64_l_16a4:
	/* 0x16a4: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_16a8:
	/* 0x16a8: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_16ac:
	/* 0x16ac: b.eq f18 <sched_process_exec_event_submit_tail+0xf18> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x16ac, 0xf18, arm64_l_f18);
arm64_l_16b0:
	/* 0x16b0: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_16b4:
	/* 0x16b4: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_16b8:
	/* 0x16b8: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_16bc:
	/* 0x16bc: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_16c0:
	/* 0x16c0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_16c4:
	/* 0x16c4: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_16c8:
	/* 0x16c8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_16cc:
	/* 0x16cc: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_16d0:
	/* 0x16d0: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_16d4:
	/* 0x16d4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x16d8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_16d8:
	/* 0x16d8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_16dc:
	/* 0x16dc: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_16e0:
	/* 0x16e0: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_16e4:
	/* 0x16e4: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_16e8:
	/* 0x16e8: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_16ec:
	/* 0x16ec: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_16f0:
	/* 0x16f0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x16f4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_16f4:
	/* 0x16f4: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_16f8:
	/* 0x16f8: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_16fc:
	/* 0x16fc: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1700:
	/* 0x1700: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1704:
	/* 0x1704: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1708:
	/* 0x1708: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x170cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_170c:
	/* 0x170c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1710:
	/* 0x1710: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1714:
	/* 0x1714: b 1848 <sched_process_exec_event_submit_tail+0x1848> */
	ARM64_SIM_A64_JMP(0x1714, 0x1848, arm64_l_1848);
arm64_l_1718:
	/* 0x1718: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_171c:
	/* 0x171c: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_1720:
	/* 0x1720: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1724:
	/* 0x1724: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_1728:
	/* 0x1728: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x172cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_172c:
	/* 0x172c: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1730:
	/* 0x1730: b.lt 4e0 <sched_process_exec_event_submit_tail+0x4e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x1730, 0x4e0, arm64_l_4e0);
arm64_l_1734:
	/* 0x1734: sub w8, w22, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1738:
	/* 0x1738: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_173c:
	/* 0x173c: sub w22, w22, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_1740:
	/* 0x1740: str w22, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1744:
	/* 0x1744: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_1748:
	/* 0x1748: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_174c:
	/* 0x174c: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1750:
	/* 0x1750: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1754:
	/* 0x1754: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1758:
	/* 0x1758: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_175c:
	/* 0x175c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1760:
	/* 0x1760: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1764:
	/* 0x1764: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1768:
	/* 0x1768: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_176c:
	/* 0x176c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1770ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1770:
	/* 0x1770: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1774:
	/* 0x1774: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1778:
	/* 0x1778: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_177c:
	/* 0x177c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1780:
	/* 0x1780: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1784:
	/* 0x1784: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1788:
	/* 0x1788: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x178cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_178c:
	/* 0x178c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1790:
	/* 0x1790: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1794:
	/* 0x1794: b.eq 1904 <sched_process_exec_event_submit_tail+0x1904> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1794, 0x1904, arm64_l_1904);
arm64_l_1798:
	/* 0x1798: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_179c:
	/* 0x179c: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17a0:
	/* 0x17a0: b.eq 1904 <sched_process_exec_event_submit_tail+0x1904> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x17a0, 0x1904, arm64_l_1904);
arm64_l_17a4:
	/* 0x17a4: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_17a8:
	/* 0x17a8: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_17ac:
	/* 0x17ac: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_17b0:
	/* 0x17b0: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_17b4:
	/* 0x17b4: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_17b8:
	/* 0x17b8: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_17bc:
	/* 0x17bc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x17c0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_17c0:
	/* 0x17c0: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_17c4:
	/* 0x17c4: ldr w22, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17c8:
	/* 0x17c8: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_17cc:
	/* 0x17cc: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_17d0:
	/* 0x17d0: subs w8, w22, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X22, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_17d4:
	/* 0x17d4: b.cc 620 <sched_process_exec_event_submit_tail+0x620> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x17d4, 0x620, arm64_l_620);
arm64_l_17d8:
	/* 0x17d8: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_17dc:
	/* 0x17dc: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_17e0:
	/* 0x17e0: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_17e4:
	/* 0x17e4: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_17e8:
	/* 0x17e8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x17ecULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_17ec:
	/* 0x17ec: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_17f0:
	/* 0x17f0: b.lt 4e0 <sched_process_exec_event_submit_tail+0x4e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x17f0, 0x4e0, arm64_l_4e0);
arm64_l_17f4:
	/* 0x17f4: sub w8, w22, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_17f8:
	/* 0x17f8: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_17fc:
	/* 0x17fc: sub w22, w22, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_1800:
	/* 0x1800: str w22, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1804:
	/* 0x1804: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_1808:
	/* 0x1808: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_180c:
	/* 0x180c: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1810:
	/* 0x1810: b 197c <sched_process_exec_event_submit_tail+0x197c> */
	ARM64_SIM_A64_JMP(0x1810, 0x197c, arm64_l_197c);
arm64_l_1814:
	/* 0x1814: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_1818:
	/* 0x1818: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_181c:
	/* 0x181c: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1820:
	/* 0x1820: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_1824:
	/* 0x1824: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x1828ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1828:
	/* 0x1828: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_182c:
	/* 0x182c: b.lt f18 <sched_process_exec_event_submit_tail+0xf18> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x182c, 0xf18, arm64_l_f18);
arm64_l_1830:
	/* 0x1830: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1834:
	/* 0x1834: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_1838:
	/* 0x1838: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_183c:
	/* 0x183c: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_1840:
	/* 0x1840: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1844:
	/* 0x1844: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1848:
	/* 0x1848: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_184c:
	/* 0x184c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1850:
	/* 0x1850: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1854:
	/* 0x1854: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1858:
	/* 0x1858: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_185c:
	/* 0x185c: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1860:
	/* 0x1860: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1864:
	/* 0x1864: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1868ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1868:
	/* 0x1868: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_186c:
	/* 0x186c: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1870:
	/* 0x1870: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1874:
	/* 0x1874: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1878:
	/* 0x1878: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_187c:
	/* 0x187c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1880:
	/* 0x1880: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1884ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1884:
	/* 0x1884: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1888:
	/* 0x1888: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_188c:
	/* 0x188c: b.eq 1a40 <sched_process_exec_event_submit_tail+0x1a40> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x188c, 0x1a40, arm64_l_1a40);
arm64_l_1890:
	/* 0x1890: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1894:
	/* 0x1894: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1898:
	/* 0x1898: b.eq 1a40 <sched_process_exec_event_submit_tail+0x1a40> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1898, 0x1a40, arm64_l_1a40);
arm64_l_189c:
	/* 0x189c: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_18a0:
	/* 0x18a0: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_18a4:
	/* 0x18a4: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_18a8:
	/* 0x18a8: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_18ac:
	/* 0x18ac: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_18b0:
	/* 0x18b0: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_18b4:
	/* 0x18b4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x18b8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_18b8:
	/* 0x18b8: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_18bc:
	/* 0x18bc: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_18c0:
	/* 0x18c0: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_18c4:
	/* 0x18c4: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_18c8:
	/* 0x18c8: b.cc 1170 <sched_process_exec_event_submit_tail+0x1170> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x18c8, 0x1170, arm64_l_1170);
arm64_l_18cc:
	/* 0x18cc: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_18d0:
	/* 0x18d0: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_18d4:
	/* 0x18d4: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_18d8:
	/* 0x18d8: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_18dc:
	/* 0x18dc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x18e0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_18e0:
	/* 0x18e0: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_18e4:
	/* 0x18e4: b.lt f18 <sched_process_exec_event_submit_tail+0xf18> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x18e4, 0xf18, arm64_l_f18);
arm64_l_18e8:
	/* 0x18e8: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_18ec:
	/* 0x18ec: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_18f0:
	/* 0x18f0: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_18f4:
	/* 0x18f4: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_18f8:
	/* 0x18f8: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_18fc:
	/* 0x18fc: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1900:
	/* 0x1900: b 1ab8 <sched_process_exec_event_submit_tail+0x1ab8> */
	ARM64_SIM_A64_JMP(0x1900, 0x1ab8, arm64_l_1ab8);
arm64_l_1904:
	/* 0x1904: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1908:
	/* 0x1908: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1908, 0x4dc, arm64_l_4dc);
arm64_l_190c:
	/* 0x190c: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1910:
	/* 0x1910: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1914:
	/* 0x1914: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1914, 0x4dc, arm64_l_4dc);
arm64_l_1918:
	/* 0x1918: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_191c:
	/* 0x191c: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1920:
	/* 0x1920: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1924:
	/* 0x1924: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1928:
	/* 0x1928: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_192c:
	/* 0x192c: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1930:
	/* 0x1930: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1934:
	/* 0x1934: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1938:
	/* 0x1938: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_193c:
	/* 0x193c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1940ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1940:
	/* 0x1940: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1944:
	/* 0x1944: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1948:
	/* 0x1948: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_194c:
	/* 0x194c: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1950:
	/* 0x1950: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1954:
	/* 0x1954: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1958:
	/* 0x1958: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x195cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_195c:
	/* 0x195c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1960:
	/* 0x1960: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1964:
	/* 0x1964: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1968:
	/* 0x1968: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_196c:
	/* 0x196c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1970:
	/* 0x1970: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1974ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1974:
	/* 0x1974: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1978:
	/* 0x1978: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_197c:
	/* 0x197c: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1980:
	/* 0x1980: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1984:
	/* 0x1984: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1988:
	/* 0x1988: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_198c:
	/* 0x198c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1990:
	/* 0x1990: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1994:
	/* 0x1994: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1998:
	/* 0x1998: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x199cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_199c:
	/* 0x199c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_19a0:
	/* 0x19a0: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_19a4:
	/* 0x19a4: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_19a8:
	/* 0x19a8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_19ac:
	/* 0x19ac: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_19b0:
	/* 0x19b0: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_19b4:
	/* 0x19b4: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x19b8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_19b8:
	/* 0x19b8: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_19bc:
	/* 0x19bc: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19c0:
	/* 0x19c0: b.eq 1b74 <sched_process_exec_event_submit_tail+0x1b74> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x19c0, 0x1b74, arm64_l_1b74);
arm64_l_19c4:
	/* 0x19c4: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_19c8:
	/* 0x19c8: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_19cc:
	/* 0x19cc: b.eq 1b74 <sched_process_exec_event_submit_tail+0x1b74> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x19cc, 0x1b74, arm64_l_1b74);
arm64_l_19d0:
	/* 0x19d0: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_19d4:
	/* 0x19d4: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_19d8:
	/* 0x19d8: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_19dc:
	/* 0x19dc: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_19e0:
	/* 0x19e0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_19e4:
	/* 0x19e4: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_19e8:
	/* 0x19e8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x19ecULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_19ec:
	/* 0x19ec: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_19f0:
	/* 0x19f0: ldr w22, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19f4:
	/* 0x19f4: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_19f8:
	/* 0x19f8: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_19fc:
	/* 0x19fc: subs w8, w22, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X22, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a00:
	/* 0x1a00: b.cc 620 <sched_process_exec_event_submit_tail+0x620> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1a00, 0x620, arm64_l_620);
arm64_l_1a04:
	/* 0x1a04: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_1a08:
	/* 0x1a08: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_1a0c:
	/* 0x1a0c: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1a10:
	/* 0x1a10: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_1a14:
	/* 0x1a14: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x1a18ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1a18:
	/* 0x1a18: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1a1c:
	/* 0x1a1c: b.lt 4e0 <sched_process_exec_event_submit_tail+0x4e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x1a1c, 0x4e0, arm64_l_4e0);
arm64_l_1a20:
	/* 0x1a20: sub w8, w22, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1a24:
	/* 0x1a24: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_1a28:
	/* 0x1a28: sub w22, w22, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_1a2c:
	/* 0x1a2c: str w22, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a30:
	/* 0x1a30: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_1a34:
	/* 0x1a34: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a38:
	/* 0x1a38: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1a3c:
	/* 0x1a3c: b 1bec <sched_process_exec_event_submit_tail+0x1bec> */
	ARM64_SIM_A64_JMP(0x1a3c, 0x1bec, arm64_l_1bec);
arm64_l_1a40:
	/* 0x1a40: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a44:
	/* 0x1a44: b.ne f18 <sched_process_exec_event_submit_tail+0xf18> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1a44, 0xf18, arm64_l_f18);
arm64_l_1a48:
	/* 0x1a48: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1a4c:
	/* 0x1a4c: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1a50:
	/* 0x1a50: b.eq f18 <sched_process_exec_event_submit_tail+0xf18> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1a50, 0xf18, arm64_l_f18);
arm64_l_1a54:
	/* 0x1a54: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1a58:
	/* 0x1a58: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1a5c:
	/* 0x1a5c: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1a60:
	/* 0x1a60: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1a64:
	/* 0x1a64: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1a68:
	/* 0x1a68: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1a6c:
	/* 0x1a6c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1a70:
	/* 0x1a70: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1a74:
	/* 0x1a74: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1a78:
	/* 0x1a78: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1a7cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1a7c:
	/* 0x1a7c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1a80:
	/* 0x1a80: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1a84:
	/* 0x1a84: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1a88:
	/* 0x1a88: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1a8c:
	/* 0x1a8c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1a90:
	/* 0x1a90: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1a94:
	/* 0x1a94: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1a98ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1a98:
	/* 0x1a98: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1a9c:
	/* 0x1a9c: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1aa0:
	/* 0x1aa0: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1aa4:
	/* 0x1aa4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1aa8:
	/* 0x1aa8: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1aac:
	/* 0x1aac: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1ab0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1ab0:
	/* 0x1ab0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1ab4:
	/* 0x1ab4: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1ab8:
	/* 0x1ab8: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1abc:
	/* 0x1abc: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1ac0:
	/* 0x1ac0: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1ac4:
	/* 0x1ac4: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1ac8:
	/* 0x1ac8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1acc:
	/* 0x1acc: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1ad0:
	/* 0x1ad0: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1ad4:
	/* 0x1ad4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1ad8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1ad8:
	/* 0x1ad8: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1adc:
	/* 0x1adc: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1ae0:
	/* 0x1ae0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1ae4:
	/* 0x1ae4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1ae8:
	/* 0x1ae8: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1aec:
	/* 0x1aec: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1af0:
	/* 0x1af0: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1af4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1af4:
	/* 0x1af4: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1af8:
	/* 0x1af8: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1afc:
	/* 0x1afc: b.eq 1cb0 <sched_process_exec_event_submit_tail+0x1cb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1afc, 0x1cb0, arm64_l_1cb0);
arm64_l_1b00:
	/* 0x1b00: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1b04:
	/* 0x1b04: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b08:
	/* 0x1b08: b.eq 1cb0 <sched_process_exec_event_submit_tail+0x1cb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1b08, 0x1cb0, arm64_l_1cb0);
arm64_l_1b0c:
	/* 0x1b0c: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1b10:
	/* 0x1b10: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1b14:
	/* 0x1b14: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1b18:
	/* 0x1b18: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1b1c:
	/* 0x1b1c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1b20:
	/* 0x1b20: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1b24:
	/* 0x1b24: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1b28ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1b28:
	/* 0x1b28: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_1b2c:
	/* 0x1b2c: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b30:
	/* 0x1b30: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1b34:
	/* 0x1b34: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b38:
	/* 0x1b38: b.cc 1170 <sched_process_exec_event_submit_tail+0x1170> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1b38, 0x1170, arm64_l_1170);
arm64_l_1b3c:
	/* 0x1b3c: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_1b40:
	/* 0x1b40: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_1b44:
	/* 0x1b44: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1b48:
	/* 0x1b48: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_1b4c:
	/* 0x1b4c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x1b50ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1b50:
	/* 0x1b50: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1b54:
	/* 0x1b54: b.lt f18 <sched_process_exec_event_submit_tail+0xf18> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x1b54, 0xf18, arm64_l_f18);
arm64_l_1b58:
	/* 0x1b58: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1b5c:
	/* 0x1b5c: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_1b60:
	/* 0x1b60: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_1b64:
	/* 0x1b64: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_1b68:
	/* 0x1b68: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b6c:
	/* 0x1b6c: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1b70:
	/* 0x1b70: b 1d28 <sched_process_exec_event_submit_tail+0x1d28> */
	ARM64_SIM_A64_JMP(0x1b70, 0x1d28, arm64_l_1d28);
arm64_l_1b74:
	/* 0x1b74: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b78:
	/* 0x1b78: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1b78, 0x4dc, arm64_l_4dc);
arm64_l_1b7c:
	/* 0x1b7c: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1b80:
	/* 0x1b80: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1b84:
	/* 0x1b84: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1b84, 0x4dc, arm64_l_4dc);
arm64_l_1b88:
	/* 0x1b88: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1b8c:
	/* 0x1b8c: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1b90:
	/* 0x1b90: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1b94:
	/* 0x1b94: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1b98:
	/* 0x1b98: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1b9c:
	/* 0x1b9c: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1ba0:
	/* 0x1ba0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1ba4:
	/* 0x1ba4: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1ba8:
	/* 0x1ba8: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1bac:
	/* 0x1bac: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1bb0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1bb0:
	/* 0x1bb0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1bb4:
	/* 0x1bb4: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1bb8:
	/* 0x1bb8: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1bbc:
	/* 0x1bbc: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1bc0:
	/* 0x1bc0: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1bc4:
	/* 0x1bc4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1bc8:
	/* 0x1bc8: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1bccULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1bcc:
	/* 0x1bcc: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1bd0:
	/* 0x1bd0: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1bd4:
	/* 0x1bd4: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1bd8:
	/* 0x1bd8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1bdc:
	/* 0x1bdc: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1be0:
	/* 0x1be0: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1be4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1be4:
	/* 0x1be4: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1be8:
	/* 0x1be8: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1bec:
	/* 0x1bec: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1bf0:
	/* 0x1bf0: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1bf4:
	/* 0x1bf4: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1bf8:
	/* 0x1bf8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1bfc:
	/* 0x1bfc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1c00:
	/* 0x1c00: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c04:
	/* 0x1c04: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1c08:
	/* 0x1c08: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1c0cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1c0c:
	/* 0x1c0c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1c10:
	/* 0x1c10: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1c14:
	/* 0x1c14: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1c18:
	/* 0x1c18: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1c1c:
	/* 0x1c1c: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1c20:
	/* 0x1c20: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1c24:
	/* 0x1c24: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1c28ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1c28:
	/* 0x1c28: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1c2c:
	/* 0x1c2c: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c30:
	/* 0x1c30: b.eq 1db4 <sched_process_exec_event_submit_tail+0x1db4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c30, 0x1db4, arm64_l_1db4);
arm64_l_1c34:
	/* 0x1c34: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1c38:
	/* 0x1c38: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c3c:
	/* 0x1c3c: b.eq 1db4 <sched_process_exec_event_submit_tail+0x1db4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1c3c, 0x1db4, arm64_l_1db4);
arm64_l_1c40:
	/* 0x1c40: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1c44:
	/* 0x1c44: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1c48:
	/* 0x1c48: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1c4c:
	/* 0x1c4c: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1c50:
	/* 0x1c50: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1c54:
	/* 0x1c54: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1c58:
	/* 0x1c58: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1c5cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1c5c:
	/* 0x1c5c: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_1c60:
	/* 0x1c60: ldr w22, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c64:
	/* 0x1c64: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1c68:
	/* 0x1c68: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1c6c:
	/* 0x1c6c: subs w8, w22, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X22, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1c70:
	/* 0x1c70: b.cc 620 <sched_process_exec_event_submit_tail+0x620> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1c70, 0x620, arm64_l_620);
arm64_l_1c74:
	/* 0x1c74: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_1c78:
	/* 0x1c78: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_1c7c:
	/* 0x1c7c: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1c80:
	/* 0x1c80: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_1c84:
	/* 0x1c84: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x1c88ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1c88:
	/* 0x1c88: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1c8c:
	/* 0x1c8c: b.lt 4e0 <sched_process_exec_event_submit_tail+0x4e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x1c8c, 0x4e0, arm64_l_4e0);
arm64_l_1c90:
	/* 0x1c90: sub w8, w22, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1c94:
	/* 0x1c94: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_1c98:
	/* 0x1c98: sub w22, w22, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_1c9c:
	/* 0x1c9c: str w22, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ca0:
	/* 0x1ca0: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_1ca4:
	/* 0x1ca4: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ca8:
	/* 0x1ca8: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1cac:
	/* 0x1cac: b 1e2c <sched_process_exec_event_submit_tail+0x1e2c> */
	ARM64_SIM_A64_JMP(0x1cac, 0x1e2c, arm64_l_1e2c);
arm64_l_1cb0:
	/* 0x1cb0: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1cb4:
	/* 0x1cb4: b.ne f18 <sched_process_exec_event_submit_tail+0xf18> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1cb4, 0xf18, arm64_l_f18);
arm64_l_1cb8:
	/* 0x1cb8: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1cbc:
	/* 0x1cbc: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1cc0:
	/* 0x1cc0: b.eq f18 <sched_process_exec_event_submit_tail+0xf18> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1cc0, 0xf18, arm64_l_f18);
arm64_l_1cc4:
	/* 0x1cc4: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1cc8:
	/* 0x1cc8: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1ccc:
	/* 0x1ccc: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1cd0:
	/* 0x1cd0: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1cd4:
	/* 0x1cd4: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1cd8:
	/* 0x1cd8: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1cdc:
	/* 0x1cdc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1ce0:
	/* 0x1ce0: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1ce4:
	/* 0x1ce4: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1ce8:
	/* 0x1ce8: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1cecULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1cec:
	/* 0x1cec: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1cf0:
	/* 0x1cf0: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1cf4:
	/* 0x1cf4: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1cf8:
	/* 0x1cf8: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1cfc:
	/* 0x1cfc: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1d00:
	/* 0x1d00: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1d04:
	/* 0x1d04: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1d08ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1d08:
	/* 0x1d08: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1d0c:
	/* 0x1d0c: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1d10:
	/* 0x1d10: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1d14:
	/* 0x1d14: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1d18:
	/* 0x1d18: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1d1c:
	/* 0x1d1c: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1d20ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1d20:
	/* 0x1d20: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1d24:
	/* 0x1d24: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1d28:
	/* 0x1d28: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1d2c:
	/* 0x1d2c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1d30:
	/* 0x1d30: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1d34:
	/* 0x1d34: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1d38:
	/* 0x1d38: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1d3c:
	/* 0x1d3c: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1d40:
	/* 0x1d40: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1d44:
	/* 0x1d44: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1d48ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1d48:
	/* 0x1d48: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1d4c:
	/* 0x1d4c: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1d50:
	/* 0x1d50: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1d54:
	/* 0x1d54: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1d58:
	/* 0x1d58: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1d5c:
	/* 0x1d5c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1d60:
	/* 0x1d60: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1d64ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1d64:
	/* 0x1d64: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1d68:
	/* 0x1d68: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d6c:
	/* 0x1d6c: b.eq 1ebc <sched_process_exec_event_submit_tail+0x1ebc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d6c, 0x1ebc, arm64_l_1ebc);
arm64_l_1d70:
	/* 0x1d70: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1d74:
	/* 0x1d74: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1d78:
	/* 0x1d78: b.eq 1ebc <sched_process_exec_event_submit_tail+0x1ebc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d78, 0x1ebc, arm64_l_1ebc);
arm64_l_1d7c:
	/* 0x1d7c: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1d80:
	/* 0x1d80: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1d84:
	/* 0x1d84: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1d88:
	/* 0x1d88: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1d8c:
	/* 0x1d8c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1d90:
	/* 0x1d90: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1d94:
	/* 0x1d94: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1d98ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1d98:
	/* 0x1d98: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_1d9c:
	/* 0x1d9c: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1da0:
	/* 0x1da0: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1da4:
	/* 0x1da4: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1da8:
	/* 0x1da8: b.cs 1f38 <sched_process_exec_event_submit_tail+0x1f38> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1da8, 0x1f38, arm64_l_1f38);
arm64_l_1dac:
	/* 0x1dac: ldr x29, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1db0:
	/* 0x1db0: b 1170 <sched_process_exec_event_submit_tail+0x1170> */
	ARM64_SIM_A64_JMP(0x1db0, 0x1170, arm64_l_1170);
arm64_l_1db4:
	/* 0x1db4: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1db8:
	/* 0x1db8: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1db8, 0x4dc, arm64_l_4dc);
arm64_l_1dbc:
	/* 0x1dbc: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1dc0:
	/* 0x1dc0: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1dc4:
	/* 0x1dc4: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1dc4, 0x4dc, arm64_l_4dc);
arm64_l_1dc8:
	/* 0x1dc8: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1dcc:
	/* 0x1dcc: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1dd0:
	/* 0x1dd0: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1dd4:
	/* 0x1dd4: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1dd8:
	/* 0x1dd8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1ddc:
	/* 0x1ddc: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1de0:
	/* 0x1de0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1de4:
	/* 0x1de4: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1de8:
	/* 0x1de8: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1dec:
	/* 0x1dec: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1df0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1df0:
	/* 0x1df0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1df4:
	/* 0x1df4: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1df8:
	/* 0x1df8: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1dfc:
	/* 0x1dfc: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1e00:
	/* 0x1e00: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1e04:
	/* 0x1e04: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1e08:
	/* 0x1e08: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1e0cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1e0c:
	/* 0x1e0c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1e10:
	/* 0x1e10: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1e14:
	/* 0x1e14: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1e18:
	/* 0x1e18: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1e1c:
	/* 0x1e1c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1e20:
	/* 0x1e20: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1e24ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1e24:
	/* 0x1e24: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1e28:
	/* 0x1e28: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1e2c:
	/* 0x1e2c: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1e30:
	/* 0x1e30: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1e34:
	/* 0x1e34: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1e38:
	/* 0x1e38: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1e3c:
	/* 0x1e3c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1e40:
	/* 0x1e40: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1e44:
	/* 0x1e44: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1e48:
	/* 0x1e48: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1e4cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1e4c:
	/* 0x1e4c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1e50:
	/* 0x1e50: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1e54:
	/* 0x1e54: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1e58:
	/* 0x1e58: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1e5c:
	/* 0x1e5c: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1e60:
	/* 0x1e60: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1e64:
	/* 0x1e64: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1e68ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1e68:
	/* 0x1e68: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1e6c:
	/* 0x1e6c: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e70:
	/* 0x1e70: b.eq 2028 <sched_process_exec_event_submit_tail+0x2028> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e70, 0x2028, arm64_l_2028);
arm64_l_1e74:
	/* 0x1e74: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1e78:
	/* 0x1e78: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1e7c:
	/* 0x1e7c: b.eq 2028 <sched_process_exec_event_submit_tail+0x2028> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e7c, 0x2028, arm64_l_2028);
arm64_l_1e80:
	/* 0x1e80: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1e84:
	/* 0x1e84: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1e88:
	/* 0x1e88: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1e8c:
	/* 0x1e8c: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1e90:
	/* 0x1e90: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1e94:
	/* 0x1e94: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1e98:
	/* 0x1e98: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1e9cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1e9c:
	/* 0x1e9c: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_1ea0:
	/* 0x1ea0: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1ea4:
	/* 0x1ea4: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1ea8:
	/* 0x1ea8: ldr w8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1eac:
	/* 0x1eac: subs w8, w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1eb0:
	/* 0x1eb0: b.cs 20b4 <sched_process_exec_event_submit_tail+0x20b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1eb0, 0x20b4, arm64_l_20b4);
arm64_l_1eb4:
	/* 0x1eb4: ldr w22, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1eb8:
	/* 0x1eb8: b 620 <sched_process_exec_event_submit_tail+0x620> */
	ARM64_SIM_A64_JMP(0x1eb8, 0x620, arm64_l_620);
arm64_l_1ebc:
	/* 0x1ebc: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ec0:
	/* 0x1ec0: b.ne f18 <sched_process_exec_event_submit_tail+0xf18> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1ec0, 0xf18, arm64_l_f18);
arm64_l_1ec4:
	/* 0x1ec4: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1ec8:
	/* 0x1ec8: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1ecc:
	/* 0x1ecc: b.eq 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1ecc, 0x20ac, arm64_l_20ac);
arm64_l_1ed0:
	/* 0x1ed0: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1ed4:
	/* 0x1ed4: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1ed8:
	/* 0x1ed8: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1edc:
	/* 0x1edc: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1ee0:
	/* 0x1ee0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1ee4:
	/* 0x1ee4: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_1ee8:
	/* 0x1ee8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1eec:
	/* 0x1eec: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1ef0:
	/* 0x1ef0: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1ef4:
	/* 0x1ef4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1ef8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1ef8:
	/* 0x1ef8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1efc:
	/* 0x1efc: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1f00:
	/* 0x1f00: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1f04:
	/* 0x1f04: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1f08:
	/* 0x1f08: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1f0c:
	/* 0x1f0c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1f10:
	/* 0x1f10: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1f14ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1f14:
	/* 0x1f14: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1f18:
	/* 0x1f18: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1f1c:
	/* 0x1f1c: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1f20:
	/* 0x1f20: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1f24:
	/* 0x1f24: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1f28:
	/* 0x1f28: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1f2cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1f2c:
	/* 0x1f2c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1f30:
	/* 0x1f30: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1f34:
	/* 0x1f34: b 1f6c <sched_process_exec_event_submit_tail+0x1f6c> */
	ARM64_SIM_A64_JMP(0x1f34, 0x1f6c, arm64_l_1f6c);
arm64_l_1f38:
	/* 0x1f38: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_1f3c:
	/* 0x1f3c: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_1f40:
	/* 0x1f40: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1f44:
	/* 0x1f44: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_1f48:
	/* 0x1f48: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x1f4cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1f4c:
	/* 0x1f4c: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1f50:
	/* 0x1f50: b.lt 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x1f50, 0x20ac, arm64_l_20ac);
arm64_l_1f54:
	/* 0x1f54: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1f58:
	/* 0x1f58: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_1f5c:
	/* 0x1f5c: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_1f60:
	/* 0x1f60: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_1f64:
	/* 0x1f64: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f68:
	/* 0x1f68: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1f6c:
	/* 0x1f6c: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1f70:
	/* 0x1f70: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1f74:
	/* 0x1f74: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1f78:
	/* 0x1f78: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1f7c:
	/* 0x1f7c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1f80:
	/* 0x1f80: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1f84:
	/* 0x1f84: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1f88:
	/* 0x1f88: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1f8cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1f8c:
	/* 0x1f8c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1f90:
	/* 0x1f90: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1f94:
	/* 0x1f94: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1f98:
	/* 0x1f98: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1f9c:
	/* 0x1f9c: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1fa0:
	/* 0x1fa0: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1fa4:
	/* 0x1fa4: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1fa8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1fa8:
	/* 0x1fa8: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1fac:
	/* 0x1fac: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fb0:
	/* 0x1fb0: b.eq 20a4 <sched_process_exec_event_submit_tail+0x20a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1fb0, 0x20a4, arm64_l_20a4);
arm64_l_1fb4:
	/* 0x1fb4: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1fb8:
	/* 0x1fb8: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fbc:
	/* 0x1fbc: b.eq 20a4 <sched_process_exec_event_submit_tail+0x20a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1fbc, 0x20a4, arm64_l_20a4);
arm64_l_1fc0:
	/* 0x1fc0: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1fc4:
	/* 0x1fc4: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1fc8:
	/* 0x1fc8: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1fcc:
	/* 0x1fcc: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1fd0:
	/* 0x1fd0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1fd4:
	/* 0x1fd4: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1fd8:
	/* 0x1fd8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1fdcULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1fdc:
	/* 0x1fdc: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_1fe0:
	/* 0x1fe0: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1fe4:
	/* 0x1fe4: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1fe8:
	/* 0x1fe8: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1fec:
	/* 0x1fec: b.cc 1dac <sched_process_exec_event_submit_tail+0x1dac> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1fec, 0x1dac, arm64_l_1dac);
arm64_l_1ff0:
	/* 0x1ff0: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_1ff4:
	/* 0x1ff4: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_1ff8:
	/* 0x1ff8: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1ffc:
	/* 0x1ffc: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_2000:
	/* 0x2000: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x2004ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2004:
	/* 0x2004: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2008:
	/* 0x2008: b.lt 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x2008, 0x20ac, arm64_l_20ac);
arm64_l_200c:
	/* 0x200c: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2010:
	/* 0x2010: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_2014:
	/* 0x2014: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_2018:
	/* 0x2018: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_201c:
	/* 0x201c: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2020:
	/* 0x2020: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2024:
	/* 0x2024: b 2368 <sched_process_exec_event_submit_tail+0x2368> */
	ARM64_SIM_A64_JMP(0x2024, 0x2368, arm64_l_2368);
arm64_l_2028:
	/* 0x2028: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_202c:
	/* 0x202c: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x202c, 0x4dc, arm64_l_4dc);
arm64_l_2030:
	/* 0x2030: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2034:
	/* 0x2034: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2038:
	/* 0x2038: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2038, 0x4dc, arm64_l_4dc);
arm64_l_203c:
	/* 0x203c: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2040:
	/* 0x2040: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2044:
	/* 0x2044: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2048:
	/* 0x2048: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_204c:
	/* 0x204c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2050:
	/* 0x2050: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2054:
	/* 0x2054: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2058:
	/* 0x2058: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_205c:
	/* 0x205c: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2060:
	/* 0x2060: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2064ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2064:
	/* 0x2064: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2068:
	/* 0x2068: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_206c:
	/* 0x206c: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2070:
	/* 0x2070: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2074:
	/* 0x2074: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2078:
	/* 0x2078: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_207c:
	/* 0x207c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2080ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2080:
	/* 0x2080: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2084:
	/* 0x2084: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2088:
	/* 0x2088: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_208c:
	/* 0x208c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2090:
	/* 0x2090: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2094:
	/* 0x2094: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2098ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2098:
	/* 0x2098: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_209c:
	/* 0x209c: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_20a0:
	/* 0x20a0: b 20f0 <sched_process_exec_event_submit_tail+0x20f0> */
	ARM64_SIM_A64_JMP(0x20a0, 0x20f0, arm64_l_20f0);
arm64_l_20a4:
	/* 0x20a4: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_20a8:
	/* 0x20a8: b.eq 22f8 <sched_process_exec_event_submit_tail+0x22f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x20a8, 0x22f8, arm64_l_22f8);
arm64_l_20ac:
	/* 0x20ac: ldr x29, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_20b0:
	/* 0x20b0: b f18 <sched_process_exec_event_submit_tail+0xf18> */
	ARM64_SIM_A64_JMP(0x20b0, 0xf18, arm64_l_f18);
arm64_l_20b4:
	/* 0x20b4: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_20b8:
	/* 0x20b8: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_20bc:
	/* 0x20bc: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_20c0:
	/* 0x20c0: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_20c4:
	/* 0x20c4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x20c8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_20c8:
	/* 0x20c8: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_20cc:
	/* 0x20cc: b.lt 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x20cc, 0x4dc, arm64_l_4dc);
arm64_l_20d0:
	/* 0x20d0: ldr w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_20d4:
	/* 0x20d4: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_20d8:
	/* 0x20d8: sub w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_20dc:
	/* 0x20dc: sub w10, w10, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_20e0:
	/* 0x20e0: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_20e4:
	/* 0x20e4: str w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_20e8:
	/* 0x20e8: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_20ec:
	/* 0x20ec: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_20f0:
	/* 0x20f0: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_20f4:
	/* 0x20f4: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_20f8:
	/* 0x20f8: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_20fc:
	/* 0x20fc: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2100:
	/* 0x2100: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2104:
	/* 0x2104: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2108:
	/* 0x2108: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_210c:
	/* 0x210c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2110ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2110:
	/* 0x2110: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2114:
	/* 0x2114: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2118:
	/* 0x2118: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_211c:
	/* 0x211c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2120:
	/* 0x2120: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2124:
	/* 0x2124: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2128:
	/* 0x2128: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x212cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_212c:
	/* 0x212c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2130:
	/* 0x2130: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2134:
	/* 0x2134: b.eq 21b8 <sched_process_exec_event_submit_tail+0x21b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2134, 0x21b8, arm64_l_21b8);
arm64_l_2138:
	/* 0x2138: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_213c:
	/* 0x213c: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2140:
	/* 0x2140: b.eq 21b8 <sched_process_exec_event_submit_tail+0x21b8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2140, 0x21b8, arm64_l_21b8);
arm64_l_2144:
	/* 0x2144: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2148:
	/* 0x2148: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_214c:
	/* 0x214c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2150:
	/* 0x2150: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2154:
	/* 0x2154: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2158:
	/* 0x2158: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_215c:
	/* 0x215c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2160ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2160:
	/* 0x2160: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_2164:
	/* 0x2164: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2168:
	/* 0x2168: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_216c:
	/* 0x216c: ldr w8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2170:
	/* 0x2170: subs w8, w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2174:
	/* 0x2174: b.cc 1eb4 <sched_process_exec_event_submit_tail+0x1eb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2174, 0x1eb4, arm64_l_1eb4);
arm64_l_2178:
	/* 0x2178: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_217c:
	/* 0x217c: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_2180:
	/* 0x2180: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2184:
	/* 0x2184: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_2188:
	/* 0x2188: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x218cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_218c:
	/* 0x218c: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2190:
	/* 0x2190: b.lt 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x2190, 0x4dc, arm64_l_4dc);
arm64_l_2194:
	/* 0x2194: ldr w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2198:
	/* 0x2198: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_219c:
	/* 0x219c: sub w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_21a0:
	/* 0x21a0: sub w10, w10, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_21a4:
	/* 0x21a4: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_21a8:
	/* 0x21a8: str w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_21ac:
	/* 0x21ac: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_21b0:
	/* 0x21b0: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_21b4:
	/* 0x21b4: b 2230 <sched_process_exec_event_submit_tail+0x2230> */
	ARM64_SIM_A64_JMP(0x21b4, 0x2230, arm64_l_2230);
arm64_l_21b8:
	/* 0x21b8: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_21bc:
	/* 0x21bc: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x21bc, 0x4dc, arm64_l_4dc);
arm64_l_21c0:
	/* 0x21c0: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_21c4:
	/* 0x21c4: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_21c8:
	/* 0x21c8: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x21c8, 0x4dc, arm64_l_4dc);
arm64_l_21cc:
	/* 0x21cc: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_21d0:
	/* 0x21d0: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_21d4:
	/* 0x21d4: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_21d8:
	/* 0x21d8: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_21dc:
	/* 0x21dc: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_21e0:
	/* 0x21e0: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_21e4:
	/* 0x21e4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_21e8:
	/* 0x21e8: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_21ec:
	/* 0x21ec: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_21f0:
	/* 0x21f0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x21f4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_21f4:
	/* 0x21f4: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_21f8:
	/* 0x21f8: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_21fc:
	/* 0x21fc: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2200:
	/* 0x2200: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2204:
	/* 0x2204: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2208:
	/* 0x2208: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_220c:
	/* 0x220c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2210ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2210:
	/* 0x2210: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2214:
	/* 0x2214: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2218:
	/* 0x2218: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_221c:
	/* 0x221c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2220:
	/* 0x2220: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2224:
	/* 0x2224: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2228ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2228:
	/* 0x2228: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_222c:
	/* 0x222c: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2230:
	/* 0x2230: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2234:
	/* 0x2234: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2238:
	/* 0x2238: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_223c:
	/* 0x223c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2240:
	/* 0x2240: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2244:
	/* 0x2244: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2248:
	/* 0x2248: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_224c:
	/* 0x224c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2250ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2250:
	/* 0x2250: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2254:
	/* 0x2254: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2258:
	/* 0x2258: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_225c:
	/* 0x225c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2260:
	/* 0x2260: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2264:
	/* 0x2264: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2268:
	/* 0x2268: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x226cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_226c:
	/* 0x226c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2270:
	/* 0x2270: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2274:
	/* 0x2274: b.eq 2558 <sched_process_exec_event_submit_tail+0x2558> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2274, 0x2558, arm64_l_2558);
arm64_l_2278:
	/* 0x2278: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_227c:
	/* 0x227c: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2280:
	/* 0x2280: b.eq 2558 <sched_process_exec_event_submit_tail+0x2558> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2280, 0x2558, arm64_l_2558);
arm64_l_2284:
	/* 0x2284: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2288:
	/* 0x2288: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_228c:
	/* 0x228c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2290:
	/* 0x2290: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2294:
	/* 0x2294: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2298:
	/* 0x2298: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_229c:
	/* 0x229c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x22a0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_22a0:
	/* 0x22a0: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_22a4:
	/* 0x22a4: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_22a8:
	/* 0x22a8: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_22ac:
	/* 0x22ac: ldr w8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_22b0:
	/* 0x22b0: subs w8, w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_22b4:
	/* 0x22b4: b.cc 1eb4 <sched_process_exec_event_submit_tail+0x1eb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x22b4, 0x1eb4, arm64_l_1eb4);
arm64_l_22b8:
	/* 0x22b8: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_22bc:
	/* 0x22bc: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_22c0:
	/* 0x22c0: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_22c4:
	/* 0x22c4: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_22c8:
	/* 0x22c8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x22ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_22cc:
	/* 0x22cc: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_22d0:
	/* 0x22d0: b.lt 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x22d0, 0x4dc, arm64_l_4dc);
arm64_l_22d4:
	/* 0x22d4: ldr w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_22d8:
	/* 0x22d8: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_22dc:
	/* 0x22dc: sub w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_22e0:
	/* 0x22e0: sub w10, w10, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_22e4:
	/* 0x22e4: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_22e8:
	/* 0x22e8: str w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_22ec:
	/* 0x22ec: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_22f0:
	/* 0x22f0: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_22f4:
	/* 0x22f4: b 25d0 <sched_process_exec_event_submit_tail+0x25d0> */
	ARM64_SIM_A64_JMP(0x22f4, 0x25d0, arm64_l_25d0);
arm64_l_22f8:
	/* 0x22f8: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_22fc:
	/* 0x22fc: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2300:
	/* 0x2300: b.eq 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2300, 0x20ac, arm64_l_20ac);
arm64_l_2304:
	/* 0x2304: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2308:
	/* 0x2308: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_230c:
	/* 0x230c: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2310:
	/* 0x2310: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2314:
	/* 0x2314: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2318:
	/* 0x2318: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_231c:
	/* 0x231c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2320:
	/* 0x2320: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2324:
	/* 0x2324: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2328:
	/* 0x2328: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x232cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_232c:
	/* 0x232c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2330:
	/* 0x2330: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2334:
	/* 0x2334: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2338:
	/* 0x2338: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_233c:
	/* 0x233c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2340:
	/* 0x2340: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2344:
	/* 0x2344: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2348ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2348:
	/* 0x2348: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_234c:
	/* 0x234c: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2350:
	/* 0x2350: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2354:
	/* 0x2354: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2358:
	/* 0x2358: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_235c:
	/* 0x235c: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2360ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2360:
	/* 0x2360: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2364:
	/* 0x2364: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2368:
	/* 0x2368: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_236c:
	/* 0x236c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2370:
	/* 0x2370: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2374:
	/* 0x2374: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2378:
	/* 0x2378: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_237c:
	/* 0x237c: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2380:
	/* 0x2380: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2384:
	/* 0x2384: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2388ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2388:
	/* 0x2388: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_238c:
	/* 0x238c: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2390:
	/* 0x2390: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2394:
	/* 0x2394: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2398:
	/* 0x2398: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_239c:
	/* 0x239c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_23a0:
	/* 0x23a0: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x23a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_23a4:
	/* 0x23a4: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_23a8:
	/* 0x23a8: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_23ac:
	/* 0x23ac: b.eq 2424 <sched_process_exec_event_submit_tail+0x2424> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x23ac, 0x2424, arm64_l_2424);
arm64_l_23b0:
	/* 0x23b0: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_23b4:
	/* 0x23b4: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_23b8:
	/* 0x23b8: b.eq 2424 <sched_process_exec_event_submit_tail+0x2424> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x23b8, 0x2424, arm64_l_2424);
arm64_l_23bc:
	/* 0x23bc: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_23c0:
	/* 0x23c0: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_23c4:
	/* 0x23c4: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_23c8:
	/* 0x23c8: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_23cc:
	/* 0x23cc: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_23d0:
	/* 0x23d0: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_23d4:
	/* 0x23d4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x23d8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_23d8:
	/* 0x23d8: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_23dc:
	/* 0x23dc: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_23e0:
	/* 0x23e0: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_23e4:
	/* 0x23e4: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_23e8:
	/* 0x23e8: b.cc 1dac <sched_process_exec_event_submit_tail+0x1dac> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x23e8, 0x1dac, arm64_l_1dac);
arm64_l_23ec:
	/* 0x23ec: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_23f0:
	/* 0x23f0: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_23f4:
	/* 0x23f4: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_23f8:
	/* 0x23f8: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_23fc:
	/* 0x23fc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x2400ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2400:
	/* 0x2400: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2404:
	/* 0x2404: b.lt 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x2404, 0x20ac, arm64_l_20ac);
arm64_l_2408:
	/* 0x2408: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_240c:
	/* 0x240c: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_2410:
	/* 0x2410: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_2414:
	/* 0x2414: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_2418:
	/* 0x2418: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_241c:
	/* 0x241c: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2420:
	/* 0x2420: b 249c <sched_process_exec_event_submit_tail+0x249c> */
	ARM64_SIM_A64_JMP(0x2420, 0x249c, arm64_l_249c);
arm64_l_2424:
	/* 0x2424: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2428:
	/* 0x2428: b.ne 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2428, 0x20ac, arm64_l_20ac);
arm64_l_242c:
	/* 0x242c: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2430:
	/* 0x2430: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2434:
	/* 0x2434: b.eq 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2434, 0x20ac, arm64_l_20ac);
arm64_l_2438:
	/* 0x2438: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_243c:
	/* 0x243c: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2440:
	/* 0x2440: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2444:
	/* 0x2444: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2448:
	/* 0x2448: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_244c:
	/* 0x244c: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2450:
	/* 0x2450: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2454:
	/* 0x2454: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2458:
	/* 0x2458: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_245c:
	/* 0x245c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2460ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2460:
	/* 0x2460: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2464:
	/* 0x2464: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2468:
	/* 0x2468: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_246c:
	/* 0x246c: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2470:
	/* 0x2470: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2474:
	/* 0x2474: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2478:
	/* 0x2478: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x247cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_247c:
	/* 0x247c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2480:
	/* 0x2480: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2484:
	/* 0x2484: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2488:
	/* 0x2488: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_248c:
	/* 0x248c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2490:
	/* 0x2490: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2494ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2494:
	/* 0x2494: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2498:
	/* 0x2498: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_249c:
	/* 0x249c: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_24a0:
	/* 0x24a0: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_24a4:
	/* 0x24a4: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_24a8:
	/* 0x24a8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_24ac:
	/* 0x24ac: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_24b0:
	/* 0x24b0: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_24b4:
	/* 0x24b4: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_24b8:
	/* 0x24b8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x24bcULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_24bc:
	/* 0x24bc: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_24c0:
	/* 0x24c0: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_24c4:
	/* 0x24c4: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_24c8:
	/* 0x24c8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_24cc:
	/* 0x24cc: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_24d0:
	/* 0x24d0: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_24d4:
	/* 0x24d4: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x24d8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_24d8:
	/* 0x24d8: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_24dc:
	/* 0x24dc: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_24e0:
	/* 0x24e0: b.eq 2698 <sched_process_exec_event_submit_tail+0x2698> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x24e0, 0x2698, arm64_l_2698);
arm64_l_24e4:
	/* 0x24e4: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_24e8:
	/* 0x24e8: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_24ec:
	/* 0x24ec: b.eq 2698 <sched_process_exec_event_submit_tail+0x2698> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x24ec, 0x2698, arm64_l_2698);
arm64_l_24f0:
	/* 0x24f0: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_24f4:
	/* 0x24f4: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_24f8:
	/* 0x24f8: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_24fc:
	/* 0x24fc: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2500:
	/* 0x2500: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2504:
	/* 0x2504: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2508:
	/* 0x2508: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x250cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_250c:
	/* 0x250c: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_2510:
	/* 0x2510: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2514:
	/* 0x2514: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2518:
	/* 0x2518: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_251c:
	/* 0x251c: b.cc 1dac <sched_process_exec_event_submit_tail+0x1dac> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x251c, 0x1dac, arm64_l_1dac);
arm64_l_2520:
	/* 0x2520: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_2524:
	/* 0x2524: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_2528:
	/* 0x2528: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_252c:
	/* 0x252c: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_2530:
	/* 0x2530: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x2534ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2534:
	/* 0x2534: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2538:
	/* 0x2538: b.lt 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x2538, 0x20ac, arm64_l_20ac);
arm64_l_253c:
	/* 0x253c: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2540:
	/* 0x2540: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_2544:
	/* 0x2544: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_2548:
	/* 0x2548: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_254c:
	/* 0x254c: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2550:
	/* 0x2550: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2554:
	/* 0x2554: b 2710 <sched_process_exec_event_submit_tail+0x2710> */
	ARM64_SIM_A64_JMP(0x2554, 0x2710, arm64_l_2710);
arm64_l_2558:
	/* 0x2558: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_255c:
	/* 0x255c: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x255c, 0x4dc, arm64_l_4dc);
arm64_l_2560:
	/* 0x2560: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2564:
	/* 0x2564: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2568:
	/* 0x2568: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2568, 0x4dc, arm64_l_4dc);
arm64_l_256c:
	/* 0x256c: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2570:
	/* 0x2570: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2574:
	/* 0x2574: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2578:
	/* 0x2578: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_257c:
	/* 0x257c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2580:
	/* 0x2580: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2584:
	/* 0x2584: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2588:
	/* 0x2588: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_258c:
	/* 0x258c: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2590:
	/* 0x2590: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2594ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2594:
	/* 0x2594: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2598:
	/* 0x2598: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_259c:
	/* 0x259c: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_25a0:
	/* 0x25a0: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_25a4:
	/* 0x25a4: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_25a8:
	/* 0x25a8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_25ac:
	/* 0x25ac: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x25b0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_25b0:
	/* 0x25b0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_25b4:
	/* 0x25b4: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_25b8:
	/* 0x25b8: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_25bc:
	/* 0x25bc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_25c0:
	/* 0x25c0: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_25c4:
	/* 0x25c4: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x25c8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_25c8:
	/* 0x25c8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_25cc:
	/* 0x25cc: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_25d0:
	/* 0x25d0: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_25d4:
	/* 0x25d4: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_25d8:
	/* 0x25d8: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_25dc:
	/* 0x25dc: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_25e0:
	/* 0x25e0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_25e4:
	/* 0x25e4: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_25e8:
	/* 0x25e8: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_25ec:
	/* 0x25ec: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x25f0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_25f0:
	/* 0x25f0: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_25f4:
	/* 0x25f4: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_25f8:
	/* 0x25f8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_25fc:
	/* 0x25fc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2600:
	/* 0x2600: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2604:
	/* 0x2604: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2608:
	/* 0x2608: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x260cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_260c:
	/* 0x260c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2610:
	/* 0x2610: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2614:
	/* 0x2614: b.eq 27cc <sched_process_exec_event_submit_tail+0x27cc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2614, 0x27cc, arm64_l_27cc);
arm64_l_2618:
	/* 0x2618: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_261c:
	/* 0x261c: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2620:
	/* 0x2620: b.eq 27cc <sched_process_exec_event_submit_tail+0x27cc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2620, 0x27cc, arm64_l_27cc);
arm64_l_2624:
	/* 0x2624: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2628:
	/* 0x2628: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_262c:
	/* 0x262c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2630:
	/* 0x2630: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2634:
	/* 0x2634: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2638:
	/* 0x2638: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_263c:
	/* 0x263c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2640ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2640:
	/* 0x2640: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_2644:
	/* 0x2644: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2648:
	/* 0x2648: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_264c:
	/* 0x264c: ldr w8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2650:
	/* 0x2650: subs w8, w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2654:
	/* 0x2654: b.cc 1eb4 <sched_process_exec_event_submit_tail+0x1eb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2654, 0x1eb4, arm64_l_1eb4);
arm64_l_2658:
	/* 0x2658: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_265c:
	/* 0x265c: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_2660:
	/* 0x2660: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2664:
	/* 0x2664: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_2668:
	/* 0x2668: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x266cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_266c:
	/* 0x266c: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2670:
	/* 0x2670: b.lt 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x2670, 0x4dc, arm64_l_4dc);
arm64_l_2674:
	/* 0x2674: ldr w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2678:
	/* 0x2678: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_267c:
	/* 0x267c: sub w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2680:
	/* 0x2680: sub w10, w10, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_2684:
	/* 0x2684: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_2688:
	/* 0x2688: str w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_268c:
	/* 0x268c: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2690:
	/* 0x2690: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2694:
	/* 0x2694: b 2844 <sched_process_exec_event_submit_tail+0x2844> */
	ARM64_SIM_A64_JMP(0x2694, 0x2844, arm64_l_2844);
arm64_l_2698:
	/* 0x2698: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_269c:
	/* 0x269c: b.ne 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x269c, 0x20ac, arm64_l_20ac);
arm64_l_26a0:
	/* 0x26a0: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_26a4:
	/* 0x26a4: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_26a8:
	/* 0x26a8: b.eq 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x26a8, 0x20ac, arm64_l_20ac);
arm64_l_26ac:
	/* 0x26ac: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_26b0:
	/* 0x26b0: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_26b4:
	/* 0x26b4: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_26b8:
	/* 0x26b8: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_26bc:
	/* 0x26bc: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_26c0:
	/* 0x26c0: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_26c4:
	/* 0x26c4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_26c8:
	/* 0x26c8: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_26cc:
	/* 0x26cc: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_26d0:
	/* 0x26d0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x26d4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_26d4:
	/* 0x26d4: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_26d8:
	/* 0x26d8: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_26dc:
	/* 0x26dc: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_26e0:
	/* 0x26e0: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_26e4:
	/* 0x26e4: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_26e8:
	/* 0x26e8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_26ec:
	/* 0x26ec: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x26f0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_26f0:
	/* 0x26f0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_26f4:
	/* 0x26f4: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_26f8:
	/* 0x26f8: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_26fc:
	/* 0x26fc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2700:
	/* 0x2700: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2704:
	/* 0x2704: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2708ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2708:
	/* 0x2708: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_270c:
	/* 0x270c: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2710:
	/* 0x2710: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2714:
	/* 0x2714: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2718:
	/* 0x2718: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_271c:
	/* 0x271c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2720:
	/* 0x2720: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2724:
	/* 0x2724: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2728:
	/* 0x2728: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_272c:
	/* 0x272c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2730ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2730:
	/* 0x2730: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2734:
	/* 0x2734: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2738:
	/* 0x2738: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_273c:
	/* 0x273c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2740:
	/* 0x2740: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2744:
	/* 0x2744: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2748:
	/* 0x2748: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x274cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_274c:
	/* 0x274c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2750:
	/* 0x2750: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2754:
	/* 0x2754: b.eq 290c <sched_process_exec_event_submit_tail+0x290c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2754, 0x290c, arm64_l_290c);
arm64_l_2758:
	/* 0x2758: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_275c:
	/* 0x275c: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2760:
	/* 0x2760: b.eq 290c <sched_process_exec_event_submit_tail+0x290c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2760, 0x290c, arm64_l_290c);
arm64_l_2764:
	/* 0x2764: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2768:
	/* 0x2768: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_276c:
	/* 0x276c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2770:
	/* 0x2770: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2774:
	/* 0x2774: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2778:
	/* 0x2778: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_277c:
	/* 0x277c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2780ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2780:
	/* 0x2780: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_2784:
	/* 0x2784: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2788:
	/* 0x2788: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_278c:
	/* 0x278c: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2790:
	/* 0x2790: b.cc 1dac <sched_process_exec_event_submit_tail+0x1dac> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2790, 0x1dac, arm64_l_1dac);
arm64_l_2794:
	/* 0x2794: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_2798:
	/* 0x2798: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_279c:
	/* 0x279c: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_27a0:
	/* 0x27a0: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_27a4:
	/* 0x27a4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x27a8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_27a8:
	/* 0x27a8: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_27ac:
	/* 0x27ac: b.lt 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x27ac, 0x20ac, arm64_l_20ac);
arm64_l_27b0:
	/* 0x27b0: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_27b4:
	/* 0x27b4: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_27b8:
	/* 0x27b8: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_27bc:
	/* 0x27bc: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_27c0:
	/* 0x27c0: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_27c4:
	/* 0x27c4: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_27c8:
	/* 0x27c8: b 2984 <sched_process_exec_event_submit_tail+0x2984> */
	ARM64_SIM_A64_JMP(0x27c8, 0x2984, arm64_l_2984);
arm64_l_27cc:
	/* 0x27cc: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_27d0:
	/* 0x27d0: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x27d0, 0x4dc, arm64_l_4dc);
arm64_l_27d4:
	/* 0x27d4: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_27d8:
	/* 0x27d8: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_27dc:
	/* 0x27dc: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x27dc, 0x4dc, arm64_l_4dc);
arm64_l_27e0:
	/* 0x27e0: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_27e4:
	/* 0x27e4: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_27e8:
	/* 0x27e8: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_27ec:
	/* 0x27ec: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_27f0:
	/* 0x27f0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_27f4:
	/* 0x27f4: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_27f8:
	/* 0x27f8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_27fc:
	/* 0x27fc: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2800:
	/* 0x2800: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2804:
	/* 0x2804: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2808ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2808:
	/* 0x2808: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_280c:
	/* 0x280c: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2810:
	/* 0x2810: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2814:
	/* 0x2814: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2818:
	/* 0x2818: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_281c:
	/* 0x281c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2820:
	/* 0x2820: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2824ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2824:
	/* 0x2824: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2828:
	/* 0x2828: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_282c:
	/* 0x282c: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2830:
	/* 0x2830: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2834:
	/* 0x2834: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2838:
	/* 0x2838: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x283cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_283c:
	/* 0x283c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2840:
	/* 0x2840: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2844:
	/* 0x2844: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2848:
	/* 0x2848: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_284c:
	/* 0x284c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2850:
	/* 0x2850: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2854:
	/* 0x2854: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2858:
	/* 0x2858: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_285c:
	/* 0x285c: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2860:
	/* 0x2860: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2864ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2864:
	/* 0x2864: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2868:
	/* 0x2868: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_286c:
	/* 0x286c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2870:
	/* 0x2870: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2874:
	/* 0x2874: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2878:
	/* 0x2878: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_287c:
	/* 0x287c: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2880ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2880:
	/* 0x2880: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2884:
	/* 0x2884: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2888:
	/* 0x2888: b.eq 2a40 <sched_process_exec_event_submit_tail+0x2a40> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2888, 0x2a40, arm64_l_2a40);
arm64_l_288c:
	/* 0x288c: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2890:
	/* 0x2890: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2894:
	/* 0x2894: b.eq 2a40 <sched_process_exec_event_submit_tail+0x2a40> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2894, 0x2a40, arm64_l_2a40);
arm64_l_2898:
	/* 0x2898: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_289c:
	/* 0x289c: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_28a0:
	/* 0x28a0: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_28a4:
	/* 0x28a4: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_28a8:
	/* 0x28a8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_28ac:
	/* 0x28ac: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_28b0:
	/* 0x28b0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x28b4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_28b4:
	/* 0x28b4: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_28b8:
	/* 0x28b8: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_28bc:
	/* 0x28bc: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_28c0:
	/* 0x28c0: ldr w8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_28c4:
	/* 0x28c4: subs w8, w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_28c8:
	/* 0x28c8: b.cc 1eb4 <sched_process_exec_event_submit_tail+0x1eb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x28c8, 0x1eb4, arm64_l_1eb4);
arm64_l_28cc:
	/* 0x28cc: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_28d0:
	/* 0x28d0: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_28d4:
	/* 0x28d4: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_28d8:
	/* 0x28d8: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_28dc:
	/* 0x28dc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x28e0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_28e0:
	/* 0x28e0: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_28e4:
	/* 0x28e4: b.lt 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x28e4, 0x4dc, arm64_l_4dc);
arm64_l_28e8:
	/* 0x28e8: ldr w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_28ec:
	/* 0x28ec: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_28f0:
	/* 0x28f0: sub w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_28f4:
	/* 0x28f4: sub w10, w10, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_28f8:
	/* 0x28f8: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_28fc:
	/* 0x28fc: str w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2900:
	/* 0x2900: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2904:
	/* 0x2904: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2908:
	/* 0x2908: b 2ab8 <sched_process_exec_event_submit_tail+0x2ab8> */
	ARM64_SIM_A64_JMP(0x2908, 0x2ab8, arm64_l_2ab8);
arm64_l_290c:
	/* 0x290c: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2910:
	/* 0x2910: b.ne 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2910, 0x20ac, arm64_l_20ac);
arm64_l_2914:
	/* 0x2914: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2918:
	/* 0x2918: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_291c:
	/* 0x291c: b.eq 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x291c, 0x20ac, arm64_l_20ac);
arm64_l_2920:
	/* 0x2920: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2924:
	/* 0x2924: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2928:
	/* 0x2928: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_292c:
	/* 0x292c: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2930:
	/* 0x2930: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2934:
	/* 0x2934: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2938:
	/* 0x2938: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_293c:
	/* 0x293c: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2940:
	/* 0x2940: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2944:
	/* 0x2944: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2948ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2948:
	/* 0x2948: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_294c:
	/* 0x294c: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2950:
	/* 0x2950: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2954:
	/* 0x2954: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2958:
	/* 0x2958: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_295c:
	/* 0x295c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2960:
	/* 0x2960: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2964ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2964:
	/* 0x2964: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2968:
	/* 0x2968: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_296c:
	/* 0x296c: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2970:
	/* 0x2970: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2974:
	/* 0x2974: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2978:
	/* 0x2978: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x297cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_297c:
	/* 0x297c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2980:
	/* 0x2980: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2984:
	/* 0x2984: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2988:
	/* 0x2988: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_298c:
	/* 0x298c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2990:
	/* 0x2990: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2994:
	/* 0x2994: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2998:
	/* 0x2998: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_299c:
	/* 0x299c: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_29a0:
	/* 0x29a0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x29a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_29a4:
	/* 0x29a4: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_29a8:
	/* 0x29a8: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_29ac:
	/* 0x29ac: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_29b0:
	/* 0x29b0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_29b4:
	/* 0x29b4: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_29b8:
	/* 0x29b8: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_29bc:
	/* 0x29bc: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x29c0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_29c0:
	/* 0x29c0: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_29c4:
	/* 0x29c4: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_29c8:
	/* 0x29c8: b.eq 2b80 <sched_process_exec_event_submit_tail+0x2b80> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x29c8, 0x2b80, arm64_l_2b80);
arm64_l_29cc:
	/* 0x29cc: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_29d0:
	/* 0x29d0: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_29d4:
	/* 0x29d4: b.eq 2b80 <sched_process_exec_event_submit_tail+0x2b80> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x29d4, 0x2b80, arm64_l_2b80);
arm64_l_29d8:
	/* 0x29d8: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_29dc:
	/* 0x29dc: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_29e0:
	/* 0x29e0: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_29e4:
	/* 0x29e4: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_29e8:
	/* 0x29e8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_29ec:
	/* 0x29ec: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_29f0:
	/* 0x29f0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x29f4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_29f4:
	/* 0x29f4: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_29f8:
	/* 0x29f8: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_29fc:
	/* 0x29fc: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2a00:
	/* 0x2a00: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2a04:
	/* 0x2a04: b.cc 1dac <sched_process_exec_event_submit_tail+0x1dac> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2a04, 0x1dac, arm64_l_1dac);
arm64_l_2a08:
	/* 0x2a08: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_2a0c:
	/* 0x2a0c: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_2a10:
	/* 0x2a10: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2a14:
	/* 0x2a14: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_2a18:
	/* 0x2a18: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x2a1cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2a1c:
	/* 0x2a1c: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2a20:
	/* 0x2a20: b.lt 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x2a20, 0x20ac, arm64_l_20ac);
arm64_l_2a24:
	/* 0x2a24: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2a28:
	/* 0x2a28: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_2a2c:
	/* 0x2a2c: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_2a30:
	/* 0x2a30: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_2a34:
	/* 0x2a34: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2a38:
	/* 0x2a38: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2a3c:
	/* 0x2a3c: b 2bf8 <sched_process_exec_event_submit_tail+0x2bf8> */
	ARM64_SIM_A64_JMP(0x2a3c, 0x2bf8, arm64_l_2bf8);
arm64_l_2a40:
	/* 0x2a40: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2a44:
	/* 0x2a44: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2a44, 0x4dc, arm64_l_4dc);
arm64_l_2a48:
	/* 0x2a48: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2a4c:
	/* 0x2a4c: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2a50:
	/* 0x2a50: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2a50, 0x4dc, arm64_l_4dc);
arm64_l_2a54:
	/* 0x2a54: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2a58:
	/* 0x2a58: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2a5c:
	/* 0x2a5c: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2a60:
	/* 0x2a60: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2a64:
	/* 0x2a64: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2a68:
	/* 0x2a68: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2a6c:
	/* 0x2a6c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2a70:
	/* 0x2a70: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2a74:
	/* 0x2a74: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2a78:
	/* 0x2a78: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2a7cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2a7c:
	/* 0x2a7c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2a80:
	/* 0x2a80: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2a84:
	/* 0x2a84: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2a88:
	/* 0x2a88: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2a8c:
	/* 0x2a8c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2a90:
	/* 0x2a90: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2a94:
	/* 0x2a94: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2a98ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2a98:
	/* 0x2a98: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2a9c:
	/* 0x2a9c: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2aa0:
	/* 0x2aa0: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2aa4:
	/* 0x2aa4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2aa8:
	/* 0x2aa8: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2aac:
	/* 0x2aac: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2ab0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2ab0:
	/* 0x2ab0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2ab4:
	/* 0x2ab4: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2ab8:
	/* 0x2ab8: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2abc:
	/* 0x2abc: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2ac0:
	/* 0x2ac0: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2ac4:
	/* 0x2ac4: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2ac8:
	/* 0x2ac8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2acc:
	/* 0x2acc: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2ad0:
	/* 0x2ad0: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2ad4:
	/* 0x2ad4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2ad8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2ad8:
	/* 0x2ad8: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2adc:
	/* 0x2adc: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2ae0:
	/* 0x2ae0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2ae4:
	/* 0x2ae4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2ae8:
	/* 0x2ae8: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2aec:
	/* 0x2aec: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2af0:
	/* 0x2af0: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2af4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2af4:
	/* 0x2af4: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2af8:
	/* 0x2af8: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2afc:
	/* 0x2afc: b.eq 2cb4 <sched_process_exec_event_submit_tail+0x2cb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2afc, 0x2cb4, arm64_l_2cb4);
arm64_l_2b00:
	/* 0x2b00: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2b04:
	/* 0x2b04: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b08:
	/* 0x2b08: b.eq 2cb4 <sched_process_exec_event_submit_tail+0x2cb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2b08, 0x2cb4, arm64_l_2cb4);
arm64_l_2b0c:
	/* 0x2b0c: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2b10:
	/* 0x2b10: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2b14:
	/* 0x2b14: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2b18:
	/* 0x2b18: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2b1c:
	/* 0x2b1c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2b20:
	/* 0x2b20: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2b24:
	/* 0x2b24: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2b28ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2b28:
	/* 0x2b28: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_2b2c:
	/* 0x2b2c: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2b30:
	/* 0x2b30: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2b34:
	/* 0x2b34: ldr w8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b38:
	/* 0x2b38: subs w8, w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b3c:
	/* 0x2b3c: b.cc 1eb4 <sched_process_exec_event_submit_tail+0x1eb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b3c, 0x1eb4, arm64_l_1eb4);
arm64_l_2b40:
	/* 0x2b40: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_2b44:
	/* 0x2b44: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_2b48:
	/* 0x2b48: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2b4c:
	/* 0x2b4c: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_2b50:
	/* 0x2b50: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x2b54ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2b54:
	/* 0x2b54: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2b58:
	/* 0x2b58: b.lt 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x2b58, 0x4dc, arm64_l_4dc);
arm64_l_2b5c:
	/* 0x2b5c: ldr w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b60:
	/* 0x2b60: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_2b64:
	/* 0x2b64: sub w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2b68:
	/* 0x2b68: sub w10, w10, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_2b6c:
	/* 0x2b6c: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_2b70:
	/* 0x2b70: str w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b74:
	/* 0x2b74: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b78:
	/* 0x2b78: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2b7c:
	/* 0x2b7c: b 2d2c <sched_process_exec_event_submit_tail+0x2d2c> */
	ARM64_SIM_A64_JMP(0x2b7c, 0x2d2c, arm64_l_2d2c);
arm64_l_2b80:
	/* 0x2b80: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b84:
	/* 0x2b84: b.ne 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2b84, 0x20ac, arm64_l_20ac);
arm64_l_2b88:
	/* 0x2b88: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2b8c:
	/* 0x2b8c: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2b90:
	/* 0x2b90: b.eq 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2b90, 0x20ac, arm64_l_20ac);
arm64_l_2b94:
	/* 0x2b94: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2b98:
	/* 0x2b98: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2b9c:
	/* 0x2b9c: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2ba0:
	/* 0x2ba0: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2ba4:
	/* 0x2ba4: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2ba8:
	/* 0x2ba8: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2bac:
	/* 0x2bac: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2bb0:
	/* 0x2bb0: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2bb4:
	/* 0x2bb4: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2bb8:
	/* 0x2bb8: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2bbcULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2bbc:
	/* 0x2bbc: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2bc0:
	/* 0x2bc0: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2bc4:
	/* 0x2bc4: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2bc8:
	/* 0x2bc8: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2bcc:
	/* 0x2bcc: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2bd0:
	/* 0x2bd0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2bd4:
	/* 0x2bd4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2bd8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2bd8:
	/* 0x2bd8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2bdc:
	/* 0x2bdc: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2be0:
	/* 0x2be0: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2be4:
	/* 0x2be4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2be8:
	/* 0x2be8: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2bec:
	/* 0x2bec: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2bf0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2bf0:
	/* 0x2bf0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2bf4:
	/* 0x2bf4: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2bf8:
	/* 0x2bf8: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2bfc:
	/* 0x2bfc: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2c00:
	/* 0x2c00: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2c04:
	/* 0x2c04: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2c08:
	/* 0x2c08: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2c0c:
	/* 0x2c0c: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2c10:
	/* 0x2c10: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2c14:
	/* 0x2c14: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2c18ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2c18:
	/* 0x2c18: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2c1c:
	/* 0x2c1c: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2c20:
	/* 0x2c20: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2c24:
	/* 0x2c24: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2c28:
	/* 0x2c28: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2c2c:
	/* 0x2c2c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2c30:
	/* 0x2c30: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2c34ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2c34:
	/* 0x2c34: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2c38:
	/* 0x2c38: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c3c:
	/* 0x2c3c: b.eq 2df4 <sched_process_exec_event_submit_tail+0x2df4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2c3c, 0x2df4, arm64_l_2df4);
arm64_l_2c40:
	/* 0x2c40: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2c44:
	/* 0x2c44: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c48:
	/* 0x2c48: b.eq 2df4 <sched_process_exec_event_submit_tail+0x2df4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2c48, 0x2df4, arm64_l_2df4);
arm64_l_2c4c:
	/* 0x2c4c: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2c50:
	/* 0x2c50: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2c54:
	/* 0x2c54: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2c58:
	/* 0x2c58: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2c5c:
	/* 0x2c5c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2c60:
	/* 0x2c60: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2c64:
	/* 0x2c64: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2c68ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2c68:
	/* 0x2c68: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_2c6c:
	/* 0x2c6c: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2c70:
	/* 0x2c70: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2c74:
	/* 0x2c74: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2c78:
	/* 0x2c78: b.cc 1dac <sched_process_exec_event_submit_tail+0x1dac> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2c78, 0x1dac, arm64_l_1dac);
arm64_l_2c7c:
	/* 0x2c7c: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_2c80:
	/* 0x2c80: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_2c84:
	/* 0x2c84: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2c88:
	/* 0x2c88: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_2c8c:
	/* 0x2c8c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x2c90ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2c90:
	/* 0x2c90: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2c94:
	/* 0x2c94: b.lt 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x2c94, 0x20ac, arm64_l_20ac);
arm64_l_2c98:
	/* 0x2c98: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2c9c:
	/* 0x2c9c: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_2ca0:
	/* 0x2ca0: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_2ca4:
	/* 0x2ca4: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_2ca8:
	/* 0x2ca8: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2cac:
	/* 0x2cac: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2cb0:
	/* 0x2cb0: b 2e6c <sched_process_exec_event_submit_tail+0x2e6c> */
	ARM64_SIM_A64_JMP(0x2cb0, 0x2e6c, arm64_l_2e6c);
arm64_l_2cb4:
	/* 0x2cb4: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2cb8:
	/* 0x2cb8: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2cb8, 0x4dc, arm64_l_4dc);
arm64_l_2cbc:
	/* 0x2cbc: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2cc0:
	/* 0x2cc0: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2cc4:
	/* 0x2cc4: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2cc4, 0x4dc, arm64_l_4dc);
arm64_l_2cc8:
	/* 0x2cc8: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2ccc:
	/* 0x2ccc: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2cd0:
	/* 0x2cd0: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2cd4:
	/* 0x2cd4: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2cd8:
	/* 0x2cd8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2cdc:
	/* 0x2cdc: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2ce0:
	/* 0x2ce0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2ce4:
	/* 0x2ce4: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2ce8:
	/* 0x2ce8: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2cec:
	/* 0x2cec: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2cf0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2cf0:
	/* 0x2cf0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2cf4:
	/* 0x2cf4: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2cf8:
	/* 0x2cf8: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2cfc:
	/* 0x2cfc: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2d00:
	/* 0x2d00: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2d04:
	/* 0x2d04: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2d08:
	/* 0x2d08: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2d0cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2d0c:
	/* 0x2d0c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2d10:
	/* 0x2d10: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2d14:
	/* 0x2d14: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2d18:
	/* 0x2d18: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2d1c:
	/* 0x2d1c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2d20:
	/* 0x2d20: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2d24ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2d24:
	/* 0x2d24: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2d28:
	/* 0x2d28: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2d2c:
	/* 0x2d2c: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2d30:
	/* 0x2d30: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2d34:
	/* 0x2d34: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2d38:
	/* 0x2d38: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2d3c:
	/* 0x2d3c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2d40:
	/* 0x2d40: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d44:
	/* 0x2d44: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2d48:
	/* 0x2d48: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2d4cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2d4c:
	/* 0x2d4c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2d50:
	/* 0x2d50: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2d54:
	/* 0x2d54: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2d58:
	/* 0x2d58: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2d5c:
	/* 0x2d5c: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2d60:
	/* 0x2d60: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2d64:
	/* 0x2d64: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2d68ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2d68:
	/* 0x2d68: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2d6c:
	/* 0x2d6c: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d70:
	/* 0x2d70: b.eq 2f28 <sched_process_exec_event_submit_tail+0x2f28> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2d70, 0x2f28, arm64_l_2f28);
arm64_l_2d74:
	/* 0x2d74: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2d78:
	/* 0x2d78: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d7c:
	/* 0x2d7c: b.eq 2f28 <sched_process_exec_event_submit_tail+0x2f28> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2d7c, 0x2f28, arm64_l_2f28);
arm64_l_2d80:
	/* 0x2d80: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2d84:
	/* 0x2d84: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2d88:
	/* 0x2d88: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2d8c:
	/* 0x2d8c: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2d90:
	/* 0x2d90: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2d94:
	/* 0x2d94: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2d98:
	/* 0x2d98: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2d9cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2d9c:
	/* 0x2d9c: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_2da0:
	/* 0x2da0: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2da4:
	/* 0x2da4: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2da8:
	/* 0x2da8: ldr w8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2dac:
	/* 0x2dac: subs w8, w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2db0:
	/* 0x2db0: b.cc 1eb4 <sched_process_exec_event_submit_tail+0x1eb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2db0, 0x1eb4, arm64_l_1eb4);
arm64_l_2db4:
	/* 0x2db4: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_2db8:
	/* 0x2db8: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_2dbc:
	/* 0x2dbc: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2dc0:
	/* 0x2dc0: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_2dc4:
	/* 0x2dc4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x2dc8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2dc8:
	/* 0x2dc8: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2dcc:
	/* 0x2dcc: b.lt 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x2dcc, 0x4dc, arm64_l_4dc);
arm64_l_2dd0:
	/* 0x2dd0: ldr w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2dd4:
	/* 0x2dd4: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_2dd8:
	/* 0x2dd8: sub w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2ddc:
	/* 0x2ddc: sub w10, w10, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_2de0:
	/* 0x2de0: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_2de4:
	/* 0x2de4: str w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2de8:
	/* 0x2de8: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2dec:
	/* 0x2dec: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2df0:
	/* 0x2df0: b 2fa0 <sched_process_exec_event_submit_tail+0x2fa0> */
	ARM64_SIM_A64_JMP(0x2df0, 0x2fa0, arm64_l_2fa0);
arm64_l_2df4:
	/* 0x2df4: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2df8:
	/* 0x2df8: b.ne 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2df8, 0x20ac, arm64_l_20ac);
arm64_l_2dfc:
	/* 0x2dfc: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2e00:
	/* 0x2e00: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2e04:
	/* 0x2e04: b.eq 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2e04, 0x20ac, arm64_l_20ac);
arm64_l_2e08:
	/* 0x2e08: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2e0c:
	/* 0x2e0c: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2e10:
	/* 0x2e10: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2e14:
	/* 0x2e14: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2e18:
	/* 0x2e18: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2e1c:
	/* 0x2e1c: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2e20:
	/* 0x2e20: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2e24:
	/* 0x2e24: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2e28:
	/* 0x2e28: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2e2c:
	/* 0x2e2c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2e30ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2e30:
	/* 0x2e30: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2e34:
	/* 0x2e34: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2e38:
	/* 0x2e38: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2e3c:
	/* 0x2e3c: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2e40:
	/* 0x2e40: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2e44:
	/* 0x2e44: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2e48:
	/* 0x2e48: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2e4cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2e4c:
	/* 0x2e4c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2e50:
	/* 0x2e50: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2e54:
	/* 0x2e54: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2e58:
	/* 0x2e58: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2e5c:
	/* 0x2e5c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2e60:
	/* 0x2e60: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2e64ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2e64:
	/* 0x2e64: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2e68:
	/* 0x2e68: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2e6c:
	/* 0x2e6c: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2e70:
	/* 0x2e70: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2e74:
	/* 0x2e74: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2e78:
	/* 0x2e78: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2e7c:
	/* 0x2e7c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2e80:
	/* 0x2e80: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2e84:
	/* 0x2e84: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2e88:
	/* 0x2e88: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2e8cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2e8c:
	/* 0x2e8c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2e90:
	/* 0x2e90: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2e94:
	/* 0x2e94: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2e98:
	/* 0x2e98: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2e9c:
	/* 0x2e9c: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2ea0:
	/* 0x2ea0: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2ea4:
	/* 0x2ea4: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2ea8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2ea8:
	/* 0x2ea8: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2eac:
	/* 0x2eac: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2eb0:
	/* 0x2eb0: b.eq 3068 <sched_process_exec_event_submit_tail+0x3068> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2eb0, 0x3068, arm64_l_3068);
arm64_l_2eb4:
	/* 0x2eb4: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2eb8:
	/* 0x2eb8: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2ebc:
	/* 0x2ebc: b.eq 3068 <sched_process_exec_event_submit_tail+0x3068> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2ebc, 0x3068, arm64_l_3068);
arm64_l_2ec0:
	/* 0x2ec0: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2ec4:
	/* 0x2ec4: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2ec8:
	/* 0x2ec8: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2ecc:
	/* 0x2ecc: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2ed0:
	/* 0x2ed0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2ed4:
	/* 0x2ed4: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2ed8:
	/* 0x2ed8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2edcULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2edc:
	/* 0x2edc: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_2ee0:
	/* 0x2ee0: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2ee4:
	/* 0x2ee4: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2ee8:
	/* 0x2ee8: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2eec:
	/* 0x2eec: b.cc 1dac <sched_process_exec_event_submit_tail+0x1dac> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2eec, 0x1dac, arm64_l_1dac);
arm64_l_2ef0:
	/* 0x2ef0: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_2ef4:
	/* 0x2ef4: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_2ef8:
	/* 0x2ef8: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2efc:
	/* 0x2efc: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_2f00:
	/* 0x2f00: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x2f04ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2f04:
	/* 0x2f04: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2f08:
	/* 0x2f08: b.lt 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x2f08, 0x20ac, arm64_l_20ac);
arm64_l_2f0c:
	/* 0x2f0c: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2f10:
	/* 0x2f10: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_2f14:
	/* 0x2f14: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_2f18:
	/* 0x2f18: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_2f1c:
	/* 0x2f1c: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2f20:
	/* 0x2f20: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2f24:
	/* 0x2f24: b 30e0 <sched_process_exec_event_submit_tail+0x30e0> */
	ARM64_SIM_A64_JMP(0x2f24, 0x30e0, arm64_l_30e0);
arm64_l_2f28:
	/* 0x2f28: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2f2c:
	/* 0x2f2c: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2f2c, 0x4dc, arm64_l_4dc);
arm64_l_2f30:
	/* 0x2f30: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2f34:
	/* 0x2f34: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2f38:
	/* 0x2f38: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2f38, 0x4dc, arm64_l_4dc);
arm64_l_2f3c:
	/* 0x2f3c: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2f40:
	/* 0x2f40: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2f44:
	/* 0x2f44: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2f48:
	/* 0x2f48: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2f4c:
	/* 0x2f4c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2f50:
	/* 0x2f50: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_2f54:
	/* 0x2f54: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2f58:
	/* 0x2f58: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2f5c:
	/* 0x2f5c: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2f60:
	/* 0x2f60: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2f64ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2f64:
	/* 0x2f64: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2f68:
	/* 0x2f68: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2f6c:
	/* 0x2f6c: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2f70:
	/* 0x2f70: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2f74:
	/* 0x2f74: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2f78:
	/* 0x2f78: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2f7c:
	/* 0x2f7c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2f80ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2f80:
	/* 0x2f80: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2f84:
	/* 0x2f84: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2f88:
	/* 0x2f88: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2f8c:
	/* 0x2f8c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2f90:
	/* 0x2f90: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2f94:
	/* 0x2f94: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2f98ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2f98:
	/* 0x2f98: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_2f9c:
	/* 0x2f9c: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2fa0:
	/* 0x2fa0: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2fa4:
	/* 0x2fa4: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2fa8:
	/* 0x2fa8: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2fac:
	/* 0x2fac: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2fb0:
	/* 0x2fb0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2fb4:
	/* 0x2fb4: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2fb8:
	/* 0x2fb8: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_2fbc:
	/* 0x2fbc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2fc0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2fc0:
	/* 0x2fc0: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2fc4:
	/* 0x2fc4: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2fc8:
	/* 0x2fc8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2fcc:
	/* 0x2fcc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2fd0:
	/* 0x2fd0: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2fd4:
	/* 0x2fd4: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_2fd8:
	/* 0x2fd8: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x2fdcULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2fdc:
	/* 0x2fdc: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_2fe0:
	/* 0x2fe0: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2fe4:
	/* 0x2fe4: b.eq 319c <sched_process_exec_event_submit_tail+0x319c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2fe4, 0x319c, arm64_l_319c);
arm64_l_2fe8:
	/* 0x2fe8: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2fec:
	/* 0x2fec: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2ff0:
	/* 0x2ff0: b.eq 319c <sched_process_exec_event_submit_tail+0x319c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2ff0, 0x319c, arm64_l_319c);
arm64_l_2ff4:
	/* 0x2ff4: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2ff8:
	/* 0x2ff8: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2ffc:
	/* 0x2ffc: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3000:
	/* 0x3000: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3004:
	/* 0x3004: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3008:
	/* 0x3008: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_300c:
	/* 0x300c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3010ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3010:
	/* 0x3010: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_3014:
	/* 0x3014: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3018:
	/* 0x3018: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_301c:
	/* 0x301c: ldr w8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3020:
	/* 0x3020: subs w8, w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3024:
	/* 0x3024: b.cc 1eb4 <sched_process_exec_event_submit_tail+0x1eb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x3024, 0x1eb4, arm64_l_1eb4);
arm64_l_3028:
	/* 0x3028: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_302c:
	/* 0x302c: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_3030:
	/* 0x3030: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_3034:
	/* 0x3034: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_3038:
	/* 0x3038: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x303cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_303c:
	/* 0x303c: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3040:
	/* 0x3040: b.lt 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x3040, 0x4dc, arm64_l_4dc);
arm64_l_3044:
	/* 0x3044: ldr w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3048:
	/* 0x3048: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_304c:
	/* 0x304c: sub w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3050:
	/* 0x3050: sub w10, w10, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_3054:
	/* 0x3054: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_3058:
	/* 0x3058: str w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_305c:
	/* 0x305c: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3060:
	/* 0x3060: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3064:
	/* 0x3064: b 3214 <sched_process_exec_event_submit_tail+0x3214> */
	ARM64_SIM_A64_JMP(0x3064, 0x3214, arm64_l_3214);
arm64_l_3068:
	/* 0x3068: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_306c:
	/* 0x306c: b.ne 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x306c, 0x20ac, arm64_l_20ac);
arm64_l_3070:
	/* 0x3070: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3074:
	/* 0x3074: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3078:
	/* 0x3078: b.eq 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3078, 0x20ac, arm64_l_20ac);
arm64_l_307c:
	/* 0x307c: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3080:
	/* 0x3080: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3084:
	/* 0x3084: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3088:
	/* 0x3088: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_308c:
	/* 0x308c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3090:
	/* 0x3090: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3094:
	/* 0x3094: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3098:
	/* 0x3098: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_309c:
	/* 0x309c: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_30a0:
	/* 0x30a0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x30a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_30a4:
	/* 0x30a4: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_30a8:
	/* 0x30a8: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_30ac:
	/* 0x30ac: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_30b0:
	/* 0x30b0: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_30b4:
	/* 0x30b4: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_30b8:
	/* 0x30b8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_30bc:
	/* 0x30bc: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x30c0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_30c0:
	/* 0x30c0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_30c4:
	/* 0x30c4: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_30c8:
	/* 0x30c8: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_30cc:
	/* 0x30cc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_30d0:
	/* 0x30d0: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_30d4:
	/* 0x30d4: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x30d8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_30d8:
	/* 0x30d8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_30dc:
	/* 0x30dc: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_30e0:
	/* 0x30e0: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_30e4:
	/* 0x30e4: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_30e8:
	/* 0x30e8: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_30ec:
	/* 0x30ec: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_30f0:
	/* 0x30f0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_30f4:
	/* 0x30f4: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_30f8:
	/* 0x30f8: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_30fc:
	/* 0x30fc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3100ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3100:
	/* 0x3100: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3104:
	/* 0x3104: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3108:
	/* 0x3108: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_310c:
	/* 0x310c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3110:
	/* 0x3110: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3114:
	/* 0x3114: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3118:
	/* 0x3118: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x311cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_311c:
	/* 0x311c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3120:
	/* 0x3120: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3124:
	/* 0x3124: b.eq 32dc <sched_process_exec_event_submit_tail+0x32dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3124, 0x32dc, arm64_l_32dc);
arm64_l_3128:
	/* 0x3128: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_312c:
	/* 0x312c: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3130:
	/* 0x3130: b.eq 32dc <sched_process_exec_event_submit_tail+0x32dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3130, 0x32dc, arm64_l_32dc);
arm64_l_3134:
	/* 0x3134: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3138:
	/* 0x3138: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_313c:
	/* 0x313c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3140:
	/* 0x3140: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3144:
	/* 0x3144: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3148:
	/* 0x3148: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_314c:
	/* 0x314c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3150ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3150:
	/* 0x3150: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_3154:
	/* 0x3154: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3158:
	/* 0x3158: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_315c:
	/* 0x315c: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3160:
	/* 0x3160: b.cc 1dac <sched_process_exec_event_submit_tail+0x1dac> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x3160, 0x1dac, arm64_l_1dac);
arm64_l_3164:
	/* 0x3164: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_3168:
	/* 0x3168: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_316c:
	/* 0x316c: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_3170:
	/* 0x3170: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_3174:
	/* 0x3174: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x3178ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3178:
	/* 0x3178: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_317c:
	/* 0x317c: b.lt 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x317c, 0x20ac, arm64_l_20ac);
arm64_l_3180:
	/* 0x3180: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3184:
	/* 0x3184: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_3188:
	/* 0x3188: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_318c:
	/* 0x318c: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_3190:
	/* 0x3190: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3194:
	/* 0x3194: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3198:
	/* 0x3198: b 3354 <sched_process_exec_event_submit_tail+0x3354> */
	ARM64_SIM_A64_JMP(0x3198, 0x3354, arm64_l_3354);
arm64_l_319c:
	/* 0x319c: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_31a0:
	/* 0x31a0: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x31a0, 0x4dc, arm64_l_4dc);
arm64_l_31a4:
	/* 0x31a4: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_31a8:
	/* 0x31a8: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_31ac:
	/* 0x31ac: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x31ac, 0x4dc, arm64_l_4dc);
arm64_l_31b0:
	/* 0x31b0: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_31b4:
	/* 0x31b4: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_31b8:
	/* 0x31b8: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_31bc:
	/* 0x31bc: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_31c0:
	/* 0x31c0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_31c4:
	/* 0x31c4: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_31c8:
	/* 0x31c8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_31cc:
	/* 0x31cc: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_31d0:
	/* 0x31d0: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_31d4:
	/* 0x31d4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x31d8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_31d8:
	/* 0x31d8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_31dc:
	/* 0x31dc: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_31e0:
	/* 0x31e0: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_31e4:
	/* 0x31e4: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_31e8:
	/* 0x31e8: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_31ec:
	/* 0x31ec: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_31f0:
	/* 0x31f0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x31f4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_31f4:
	/* 0x31f4: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_31f8:
	/* 0x31f8: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_31fc:
	/* 0x31fc: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3200:
	/* 0x3200: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3204:
	/* 0x3204: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3208:
	/* 0x3208: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x320cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_320c:
	/* 0x320c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3210:
	/* 0x3210: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3214:
	/* 0x3214: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3218:
	/* 0x3218: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_321c:
	/* 0x321c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3220:
	/* 0x3220: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3224:
	/* 0x3224: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3228:
	/* 0x3228: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_322c:
	/* 0x322c: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3230:
	/* 0x3230: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3234ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3234:
	/* 0x3234: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3238:
	/* 0x3238: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_323c:
	/* 0x323c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3240:
	/* 0x3240: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3244:
	/* 0x3244: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3248:
	/* 0x3248: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_324c:
	/* 0x324c: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3250ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3250:
	/* 0x3250: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3254:
	/* 0x3254: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3258:
	/* 0x3258: b.eq 3410 <sched_process_exec_event_submit_tail+0x3410> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3258, 0x3410, arm64_l_3410);
arm64_l_325c:
	/* 0x325c: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3260:
	/* 0x3260: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3264:
	/* 0x3264: b.eq 3410 <sched_process_exec_event_submit_tail+0x3410> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3264, 0x3410, arm64_l_3410);
arm64_l_3268:
	/* 0x3268: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_326c:
	/* 0x326c: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3270:
	/* 0x3270: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3274:
	/* 0x3274: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3278:
	/* 0x3278: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_327c:
	/* 0x327c: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3280:
	/* 0x3280: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3284ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3284:
	/* 0x3284: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_3288:
	/* 0x3288: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_328c:
	/* 0x328c: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_3290:
	/* 0x3290: ldr w8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3294:
	/* 0x3294: subs w8, w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3298:
	/* 0x3298: b.cc 1eb4 <sched_process_exec_event_submit_tail+0x1eb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x3298, 0x1eb4, arm64_l_1eb4);
arm64_l_329c:
	/* 0x329c: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_32a0:
	/* 0x32a0: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_32a4:
	/* 0x32a4: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_32a8:
	/* 0x32a8: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_32ac:
	/* 0x32ac: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x32b0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_32b0:
	/* 0x32b0: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_32b4:
	/* 0x32b4: b.lt 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x32b4, 0x4dc, arm64_l_4dc);
arm64_l_32b8:
	/* 0x32b8: ldr w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_32bc:
	/* 0x32bc: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_32c0:
	/* 0x32c0: sub w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_32c4:
	/* 0x32c4: sub w10, w10, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_32c8:
	/* 0x32c8: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_32cc:
	/* 0x32cc: str w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_32d0:
	/* 0x32d0: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_32d4:
	/* 0x32d4: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_32d8:
	/* 0x32d8: b 3488 <sched_process_exec_event_submit_tail+0x3488> */
	ARM64_SIM_A64_JMP(0x32d8, 0x3488, arm64_l_3488);
arm64_l_32dc:
	/* 0x32dc: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_32e0:
	/* 0x32e0: b.ne 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x32e0, 0x20ac, arm64_l_20ac);
arm64_l_32e4:
	/* 0x32e4: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_32e8:
	/* 0x32e8: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_32ec:
	/* 0x32ec: b.eq 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x32ec, 0x20ac, arm64_l_20ac);
arm64_l_32f0:
	/* 0x32f0: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_32f4:
	/* 0x32f4: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_32f8:
	/* 0x32f8: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_32fc:
	/* 0x32fc: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3300:
	/* 0x3300: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3304:
	/* 0x3304: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3308:
	/* 0x3308: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_330c:
	/* 0x330c: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3310:
	/* 0x3310: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3314:
	/* 0x3314: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3318ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3318:
	/* 0x3318: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_331c:
	/* 0x331c: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3320:
	/* 0x3320: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3324:
	/* 0x3324: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3328:
	/* 0x3328: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_332c:
	/* 0x332c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3330:
	/* 0x3330: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3334ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3334:
	/* 0x3334: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3338:
	/* 0x3338: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_333c:
	/* 0x333c: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3340:
	/* 0x3340: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3344:
	/* 0x3344: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3348:
	/* 0x3348: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x334cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_334c:
	/* 0x334c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3350:
	/* 0x3350: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3354:
	/* 0x3354: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3358:
	/* 0x3358: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_335c:
	/* 0x335c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3360:
	/* 0x3360: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3364:
	/* 0x3364: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3368:
	/* 0x3368: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_336c:
	/* 0x336c: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3370:
	/* 0x3370: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3374ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3374:
	/* 0x3374: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3378:
	/* 0x3378: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_337c:
	/* 0x337c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3380:
	/* 0x3380: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3384:
	/* 0x3384: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3388:
	/* 0x3388: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_338c:
	/* 0x338c: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3390ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3390:
	/* 0x3390: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3394:
	/* 0x3394: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3398:
	/* 0x3398: b.eq 3550 <sched_process_exec_event_submit_tail+0x3550> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3398, 0x3550, arm64_l_3550);
arm64_l_339c:
	/* 0x339c: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_33a0:
	/* 0x33a0: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_33a4:
	/* 0x33a4: b.eq 3550 <sched_process_exec_event_submit_tail+0x3550> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x33a4, 0x3550, arm64_l_3550);
arm64_l_33a8:
	/* 0x33a8: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_33ac:
	/* 0x33ac: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_33b0:
	/* 0x33b0: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_33b4:
	/* 0x33b4: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_33b8:
	/* 0x33b8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_33bc:
	/* 0x33bc: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_33c0:
	/* 0x33c0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x33c4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_33c4:
	/* 0x33c4: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_33c8:
	/* 0x33c8: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_33cc:
	/* 0x33cc: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_33d0:
	/* 0x33d0: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_33d4:
	/* 0x33d4: b.cc 1dac <sched_process_exec_event_submit_tail+0x1dac> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x33d4, 0x1dac, arm64_l_1dac);
arm64_l_33d8:
	/* 0x33d8: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_33dc:
	/* 0x33dc: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_33e0:
	/* 0x33e0: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_33e4:
	/* 0x33e4: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_33e8:
	/* 0x33e8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x33ecULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_33ec:
	/* 0x33ec: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_33f0:
	/* 0x33f0: b.lt 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x33f0, 0x20ac, arm64_l_20ac);
arm64_l_33f4:
	/* 0x33f4: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_33f8:
	/* 0x33f8: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_33fc:
	/* 0x33fc: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_3400:
	/* 0x3400: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_3404:
	/* 0x3404: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3408:
	/* 0x3408: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_340c:
	/* 0x340c: b 35c8 <sched_process_exec_event_submit_tail+0x35c8> */
	ARM64_SIM_A64_JMP(0x340c, 0x35c8, arm64_l_35c8);
arm64_l_3410:
	/* 0x3410: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3414:
	/* 0x3414: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3414, 0x4dc, arm64_l_4dc);
arm64_l_3418:
	/* 0x3418: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_341c:
	/* 0x341c: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3420:
	/* 0x3420: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3420, 0x4dc, arm64_l_4dc);
arm64_l_3424:
	/* 0x3424: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3428:
	/* 0x3428: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_342c:
	/* 0x342c: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3430:
	/* 0x3430: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3434:
	/* 0x3434: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3438:
	/* 0x3438: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_343c:
	/* 0x343c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3440:
	/* 0x3440: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3444:
	/* 0x3444: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3448:
	/* 0x3448: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x344cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_344c:
	/* 0x344c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3450:
	/* 0x3450: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3454:
	/* 0x3454: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3458:
	/* 0x3458: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_345c:
	/* 0x345c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3460:
	/* 0x3460: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3464:
	/* 0x3464: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3468ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3468:
	/* 0x3468: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_346c:
	/* 0x346c: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3470:
	/* 0x3470: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3474:
	/* 0x3474: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3478:
	/* 0x3478: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_347c:
	/* 0x347c: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3480ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3480:
	/* 0x3480: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3484:
	/* 0x3484: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3488:
	/* 0x3488: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_348c:
	/* 0x348c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3490:
	/* 0x3490: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3494:
	/* 0x3494: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3498:
	/* 0x3498: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_349c:
	/* 0x349c: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_34a0:
	/* 0x34a0: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_34a4:
	/* 0x34a4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x34a8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_34a8:
	/* 0x34a8: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_34ac:
	/* 0x34ac: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_34b0:
	/* 0x34b0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_34b4:
	/* 0x34b4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_34b8:
	/* 0x34b8: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_34bc:
	/* 0x34bc: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_34c0:
	/* 0x34c0: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x34c4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_34c4:
	/* 0x34c4: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_34c8:
	/* 0x34c8: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_34cc:
	/* 0x34cc: b.eq 3684 <sched_process_exec_event_submit_tail+0x3684> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x34cc, 0x3684, arm64_l_3684);
arm64_l_34d0:
	/* 0x34d0: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_34d4:
	/* 0x34d4: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_34d8:
	/* 0x34d8: b.eq 3684 <sched_process_exec_event_submit_tail+0x3684> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x34d8, 0x3684, arm64_l_3684);
arm64_l_34dc:
	/* 0x34dc: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_34e0:
	/* 0x34e0: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_34e4:
	/* 0x34e4: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_34e8:
	/* 0x34e8: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_34ec:
	/* 0x34ec: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_34f0:
	/* 0x34f0: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_34f4:
	/* 0x34f4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x34f8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_34f8:
	/* 0x34f8: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_34fc:
	/* 0x34fc: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3500:
	/* 0x3500: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_3504:
	/* 0x3504: ldr w8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3508:
	/* 0x3508: subs w8, w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_350c:
	/* 0x350c: b.cc 1eb4 <sched_process_exec_event_submit_tail+0x1eb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x350c, 0x1eb4, arm64_l_1eb4);
arm64_l_3510:
	/* 0x3510: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_3514:
	/* 0x3514: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_3518:
	/* 0x3518: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_351c:
	/* 0x351c: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_3520:
	/* 0x3520: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x3524ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3524:
	/* 0x3524: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3528:
	/* 0x3528: b.lt 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x3528, 0x4dc, arm64_l_4dc);
arm64_l_352c:
	/* 0x352c: ldr w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3530:
	/* 0x3530: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_3534:
	/* 0x3534: sub w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3538:
	/* 0x3538: sub w10, w10, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_353c:
	/* 0x353c: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_3540:
	/* 0x3540: str w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3544:
	/* 0x3544: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3548:
	/* 0x3548: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_354c:
	/* 0x354c: b 36fc <sched_process_exec_event_submit_tail+0x36fc> */
	ARM64_SIM_A64_JMP(0x354c, 0x36fc, arm64_l_36fc);
arm64_l_3550:
	/* 0x3550: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3554:
	/* 0x3554: b.ne 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3554, 0x20ac, arm64_l_20ac);
arm64_l_3558:
	/* 0x3558: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_355c:
	/* 0x355c: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3560:
	/* 0x3560: b.eq 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3560, 0x20ac, arm64_l_20ac);
arm64_l_3564:
	/* 0x3564: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3568:
	/* 0x3568: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_356c:
	/* 0x356c: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3570:
	/* 0x3570: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3574:
	/* 0x3574: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3578:
	/* 0x3578: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_357c:
	/* 0x357c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3580:
	/* 0x3580: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3584:
	/* 0x3584: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3588:
	/* 0x3588: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x358cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_358c:
	/* 0x358c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3590:
	/* 0x3590: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3594:
	/* 0x3594: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3598:
	/* 0x3598: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_359c:
	/* 0x359c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_35a0:
	/* 0x35a0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_35a4:
	/* 0x35a4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x35a8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_35a8:
	/* 0x35a8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_35ac:
	/* 0x35ac: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_35b0:
	/* 0x35b0: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_35b4:
	/* 0x35b4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_35b8:
	/* 0x35b8: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_35bc:
	/* 0x35bc: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x35c0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_35c0:
	/* 0x35c0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_35c4:
	/* 0x35c4: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_35c8:
	/* 0x35c8: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_35cc:
	/* 0x35cc: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_35d0:
	/* 0x35d0: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_35d4:
	/* 0x35d4: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_35d8:
	/* 0x35d8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_35dc:
	/* 0x35dc: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_35e0:
	/* 0x35e0: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_35e4:
	/* 0x35e4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x35e8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_35e8:
	/* 0x35e8: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_35ec:
	/* 0x35ec: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_35f0:
	/* 0x35f0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_35f4:
	/* 0x35f4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_35f8:
	/* 0x35f8: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_35fc:
	/* 0x35fc: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3600:
	/* 0x3600: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3604ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3604:
	/* 0x3604: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3608:
	/* 0x3608: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_360c:
	/* 0x360c: b.eq 37c4 <sched_process_exec_event_submit_tail+0x37c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x360c, 0x37c4, arm64_l_37c4);
arm64_l_3610:
	/* 0x3610: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3614:
	/* 0x3614: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3618:
	/* 0x3618: b.eq 37c4 <sched_process_exec_event_submit_tail+0x37c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3618, 0x37c4, arm64_l_37c4);
arm64_l_361c:
	/* 0x361c: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3620:
	/* 0x3620: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3624:
	/* 0x3624: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3628:
	/* 0x3628: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_362c:
	/* 0x362c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3630:
	/* 0x3630: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3634:
	/* 0x3634: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3638ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3638:
	/* 0x3638: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_363c:
	/* 0x363c: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3640:
	/* 0x3640: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_3644:
	/* 0x3644: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3648:
	/* 0x3648: b.cc 1dac <sched_process_exec_event_submit_tail+0x1dac> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x3648, 0x1dac, arm64_l_1dac);
arm64_l_364c:
	/* 0x364c: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_3650:
	/* 0x3650: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_3654:
	/* 0x3654: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_3658:
	/* 0x3658: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_365c:
	/* 0x365c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x3660ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3660:
	/* 0x3660: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3664:
	/* 0x3664: b.lt 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x3664, 0x20ac, arm64_l_20ac);
arm64_l_3668:
	/* 0x3668: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_366c:
	/* 0x366c: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_3670:
	/* 0x3670: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_3674:
	/* 0x3674: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_3678:
	/* 0x3678: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_367c:
	/* 0x367c: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3680:
	/* 0x3680: b 383c <sched_process_exec_event_submit_tail+0x383c> */
	ARM64_SIM_A64_JMP(0x3680, 0x383c, arm64_l_383c);
arm64_l_3684:
	/* 0x3684: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3688:
	/* 0x3688: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3688, 0x4dc, arm64_l_4dc);
arm64_l_368c:
	/* 0x368c: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3690:
	/* 0x3690: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3694:
	/* 0x3694: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3694, 0x4dc, arm64_l_4dc);
arm64_l_3698:
	/* 0x3698: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_369c:
	/* 0x369c: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_36a0:
	/* 0x36a0: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_36a4:
	/* 0x36a4: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_36a8:
	/* 0x36a8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_36ac:
	/* 0x36ac: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_36b0:
	/* 0x36b0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_36b4:
	/* 0x36b4: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_36b8:
	/* 0x36b8: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_36bc:
	/* 0x36bc: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x36c0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_36c0:
	/* 0x36c0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_36c4:
	/* 0x36c4: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_36c8:
	/* 0x36c8: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_36cc:
	/* 0x36cc: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_36d0:
	/* 0x36d0: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_36d4:
	/* 0x36d4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_36d8:
	/* 0x36d8: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x36dcULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_36dc:
	/* 0x36dc: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_36e0:
	/* 0x36e0: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_36e4:
	/* 0x36e4: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_36e8:
	/* 0x36e8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_36ec:
	/* 0x36ec: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_36f0:
	/* 0x36f0: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x36f4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_36f4:
	/* 0x36f4: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_36f8:
	/* 0x36f8: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_36fc:
	/* 0x36fc: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3700:
	/* 0x3700: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3704:
	/* 0x3704: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3708:
	/* 0x3708: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_370c:
	/* 0x370c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3710:
	/* 0x3710: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3714:
	/* 0x3714: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3718:
	/* 0x3718: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x371cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_371c:
	/* 0x371c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3720:
	/* 0x3720: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3724:
	/* 0x3724: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3728:
	/* 0x3728: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_372c:
	/* 0x372c: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3730:
	/* 0x3730: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3734:
	/* 0x3734: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3738ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3738:
	/* 0x3738: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_373c:
	/* 0x373c: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3740:
	/* 0x3740: b.eq 38f8 <sched_process_exec_event_submit_tail+0x38f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3740, 0x38f8, arm64_l_38f8);
arm64_l_3744:
	/* 0x3744: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3748:
	/* 0x3748: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_374c:
	/* 0x374c: b.eq 38f8 <sched_process_exec_event_submit_tail+0x38f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x374c, 0x38f8, arm64_l_38f8);
arm64_l_3750:
	/* 0x3750: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3754:
	/* 0x3754: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3758:
	/* 0x3758: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_375c:
	/* 0x375c: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3760:
	/* 0x3760: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3764:
	/* 0x3764: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3768:
	/* 0x3768: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x376cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_376c:
	/* 0x376c: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_3770:
	/* 0x3770: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3774:
	/* 0x3774: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_3778:
	/* 0x3778: ldr w8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_377c:
	/* 0x377c: subs w8, w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3780:
	/* 0x3780: b.cc 1eb4 <sched_process_exec_event_submit_tail+0x1eb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x3780, 0x1eb4, arm64_l_1eb4);
arm64_l_3784:
	/* 0x3784: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_3788:
	/* 0x3788: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_378c:
	/* 0x378c: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_3790:
	/* 0x3790: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_3794:
	/* 0x3794: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x3798ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3798:
	/* 0x3798: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_379c:
	/* 0x379c: b.lt 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x379c, 0x4dc, arm64_l_4dc);
arm64_l_37a0:
	/* 0x37a0: ldr w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_37a4:
	/* 0x37a4: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_37a8:
	/* 0x37a8: sub w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_37ac:
	/* 0x37ac: sub w10, w10, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_37b0:
	/* 0x37b0: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_37b4:
	/* 0x37b4: str w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_37b8:
	/* 0x37b8: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_37bc:
	/* 0x37bc: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_37c0:
	/* 0x37c0: b 3970 <sched_process_exec_event_submit_tail+0x3970> */
	ARM64_SIM_A64_JMP(0x37c0, 0x3970, arm64_l_3970);
arm64_l_37c4:
	/* 0x37c4: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_37c8:
	/* 0x37c8: b.ne 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x37c8, 0x20ac, arm64_l_20ac);
arm64_l_37cc:
	/* 0x37cc: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_37d0:
	/* 0x37d0: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_37d4:
	/* 0x37d4: b.eq 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x37d4, 0x20ac, arm64_l_20ac);
arm64_l_37d8:
	/* 0x37d8: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_37dc:
	/* 0x37dc: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_37e0:
	/* 0x37e0: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_37e4:
	/* 0x37e4: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_37e8:
	/* 0x37e8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_37ec:
	/* 0x37ec: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_37f0:
	/* 0x37f0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_37f4:
	/* 0x37f4: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_37f8:
	/* 0x37f8: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_37fc:
	/* 0x37fc: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3800ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3800:
	/* 0x3800: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3804:
	/* 0x3804: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3808:
	/* 0x3808: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_380c:
	/* 0x380c: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3810:
	/* 0x3810: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3814:
	/* 0x3814: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3818:
	/* 0x3818: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x381cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_381c:
	/* 0x381c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3820:
	/* 0x3820: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3824:
	/* 0x3824: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3828:
	/* 0x3828: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_382c:
	/* 0x382c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3830:
	/* 0x3830: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3834ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3834:
	/* 0x3834: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3838:
	/* 0x3838: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_383c:
	/* 0x383c: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3840:
	/* 0x3840: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3844:
	/* 0x3844: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3848:
	/* 0x3848: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_384c:
	/* 0x384c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3850:
	/* 0x3850: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3854:
	/* 0x3854: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3858:
	/* 0x3858: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x385cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_385c:
	/* 0x385c: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3860:
	/* 0x3860: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3864:
	/* 0x3864: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3868:
	/* 0x3868: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_386c:
	/* 0x386c: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3870:
	/* 0x3870: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3874:
	/* 0x3874: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3878ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3878:
	/* 0x3878: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_387c:
	/* 0x387c: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3880:
	/* 0x3880: b.eq 3a38 <sched_process_exec_event_submit_tail+0x3a38> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3880, 0x3a38, arm64_l_3a38);
arm64_l_3884:
	/* 0x3884: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3888:
	/* 0x3888: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_388c:
	/* 0x388c: b.eq 3a38 <sched_process_exec_event_submit_tail+0x3a38> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x388c, 0x3a38, arm64_l_3a38);
arm64_l_3890:
	/* 0x3890: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3894:
	/* 0x3894: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3898:
	/* 0x3898: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_389c:
	/* 0x389c: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_38a0:
	/* 0x38a0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_38a4:
	/* 0x38a4: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_38a8:
	/* 0x38a8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x38acULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_38ac:
	/* 0x38ac: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_38b0:
	/* 0x38b0: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_38b4:
	/* 0x38b4: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_38b8:
	/* 0x38b8: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_38bc:
	/* 0x38bc: b.cc 1dac <sched_process_exec_event_submit_tail+0x1dac> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x38bc, 0x1dac, arm64_l_1dac);
arm64_l_38c0:
	/* 0x38c0: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_38c4:
	/* 0x38c4: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_38c8:
	/* 0x38c8: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_38cc:
	/* 0x38cc: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_38d0:
	/* 0x38d0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x38d4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_38d4:
	/* 0x38d4: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_38d8:
	/* 0x38d8: b.lt 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x38d8, 0x20ac, arm64_l_20ac);
arm64_l_38dc:
	/* 0x38dc: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_38e0:
	/* 0x38e0: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_38e4:
	/* 0x38e4: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_38e8:
	/* 0x38e8: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_38ec:
	/* 0x38ec: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_38f0:
	/* 0x38f0: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_38f4:
	/* 0x38f4: b 3ab0 <sched_process_exec_event_submit_tail+0x3ab0> */
	ARM64_SIM_A64_JMP(0x38f4, 0x3ab0, arm64_l_3ab0);
arm64_l_38f8:
	/* 0x38f8: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_38fc:
	/* 0x38fc: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x38fc, 0x4dc, arm64_l_4dc);
arm64_l_3900:
	/* 0x3900: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3904:
	/* 0x3904: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3908:
	/* 0x3908: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3908, 0x4dc, arm64_l_4dc);
arm64_l_390c:
	/* 0x390c: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3910:
	/* 0x3910: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3914:
	/* 0x3914: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3918:
	/* 0x3918: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_391c:
	/* 0x391c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3920:
	/* 0x3920: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3924:
	/* 0x3924: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3928:
	/* 0x3928: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_392c:
	/* 0x392c: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3930:
	/* 0x3930: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3934ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3934:
	/* 0x3934: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3938:
	/* 0x3938: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_393c:
	/* 0x393c: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3940:
	/* 0x3940: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3944:
	/* 0x3944: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3948:
	/* 0x3948: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_394c:
	/* 0x394c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3950ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3950:
	/* 0x3950: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3954:
	/* 0x3954: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3958:
	/* 0x3958: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_395c:
	/* 0x395c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3960:
	/* 0x3960: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3964:
	/* 0x3964: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3968ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3968:
	/* 0x3968: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_396c:
	/* 0x396c: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3970:
	/* 0x3970: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3974:
	/* 0x3974: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3978:
	/* 0x3978: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_397c:
	/* 0x397c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3980:
	/* 0x3980: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3984:
	/* 0x3984: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3988:
	/* 0x3988: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_398c:
	/* 0x398c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3990ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3990:
	/* 0x3990: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3994:
	/* 0x3994: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3998:
	/* 0x3998: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_399c:
	/* 0x399c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_39a0:
	/* 0x39a0: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_39a4:
	/* 0x39a4: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_39a8:
	/* 0x39a8: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x39acULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_39ac:
	/* 0x39ac: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_39b0:
	/* 0x39b0: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_39b4:
	/* 0x39b4: b.eq 3b6c <sched_process_exec_event_submit_tail+0x3b6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x39b4, 0x3b6c, arm64_l_3b6c);
arm64_l_39b8:
	/* 0x39b8: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_39bc:
	/* 0x39bc: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_39c0:
	/* 0x39c0: b.eq 3b6c <sched_process_exec_event_submit_tail+0x3b6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x39c0, 0x3b6c, arm64_l_3b6c);
arm64_l_39c4:
	/* 0x39c4: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_39c8:
	/* 0x39c8: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_39cc:
	/* 0x39cc: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_39d0:
	/* 0x39d0: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_39d4:
	/* 0x39d4: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_39d8:
	/* 0x39d8: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_39dc:
	/* 0x39dc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x39e0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_39e0:
	/* 0x39e0: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_39e4:
	/* 0x39e4: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_39e8:
	/* 0x39e8: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_39ec:
	/* 0x39ec: ldr w8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_39f0:
	/* 0x39f0: subs w8, w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_39f4:
	/* 0x39f4: b.cc 1eb4 <sched_process_exec_event_submit_tail+0x1eb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x39f4, 0x1eb4, arm64_l_1eb4);
arm64_l_39f8:
	/* 0x39f8: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_39fc:
	/* 0x39fc: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_3a00:
	/* 0x3a00: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_3a04:
	/* 0x3a04: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_3a08:
	/* 0x3a08: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x3a0cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3a0c:
	/* 0x3a0c: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3a10:
	/* 0x3a10: b.lt 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x3a10, 0x4dc, arm64_l_4dc);
arm64_l_3a14:
	/* 0x3a14: ldr w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3a18:
	/* 0x3a18: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_3a1c:
	/* 0x3a1c: sub w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3a20:
	/* 0x3a20: sub w10, w10, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_3a24:
	/* 0x3a24: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_3a28:
	/* 0x3a28: str w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3a2c:
	/* 0x3a2c: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3a30:
	/* 0x3a30: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3a34:
	/* 0x3a34: b 3be4 <sched_process_exec_event_submit_tail+0x3be4> */
	ARM64_SIM_A64_JMP(0x3a34, 0x3be4, arm64_l_3be4);
arm64_l_3a38:
	/* 0x3a38: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3a3c:
	/* 0x3a3c: b.ne 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3a3c, 0x20ac, arm64_l_20ac);
arm64_l_3a40:
	/* 0x3a40: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3a44:
	/* 0x3a44: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3a48:
	/* 0x3a48: b.eq 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3a48, 0x20ac, arm64_l_20ac);
arm64_l_3a4c:
	/* 0x3a4c: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3a50:
	/* 0x3a50: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3a54:
	/* 0x3a54: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3a58:
	/* 0x3a58: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3a5c:
	/* 0x3a5c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3a60:
	/* 0x3a60: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3a64:
	/* 0x3a64: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3a68:
	/* 0x3a68: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3a6c:
	/* 0x3a6c: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3a70:
	/* 0x3a70: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3a74ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3a74:
	/* 0x3a74: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3a78:
	/* 0x3a78: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3a7c:
	/* 0x3a7c: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3a80:
	/* 0x3a80: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3a84:
	/* 0x3a84: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3a88:
	/* 0x3a88: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3a8c:
	/* 0x3a8c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3a90ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3a90:
	/* 0x3a90: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3a94:
	/* 0x3a94: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3a98:
	/* 0x3a98: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3a9c:
	/* 0x3a9c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3aa0:
	/* 0x3aa0: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3aa4:
	/* 0x3aa4: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3aa8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3aa8:
	/* 0x3aa8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3aac:
	/* 0x3aac: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3ab0:
	/* 0x3ab0: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3ab4:
	/* 0x3ab4: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3ab8:
	/* 0x3ab8: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3abc:
	/* 0x3abc: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3ac0:
	/* 0x3ac0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3ac4:
	/* 0x3ac4: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3ac8:
	/* 0x3ac8: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3acc:
	/* 0x3acc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3ad0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3ad0:
	/* 0x3ad0: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3ad4:
	/* 0x3ad4: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3ad8:
	/* 0x3ad8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3adc:
	/* 0x3adc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3ae0:
	/* 0x3ae0: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3ae4:
	/* 0x3ae4: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3ae8:
	/* 0x3ae8: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3aecULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3aec:
	/* 0x3aec: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3af0:
	/* 0x3af0: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3af4:
	/* 0x3af4: b.eq 3cac <sched_process_exec_event_submit_tail+0x3cac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3af4, 0x3cac, arm64_l_3cac);
arm64_l_3af8:
	/* 0x3af8: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3afc:
	/* 0x3afc: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3b00:
	/* 0x3b00: b.eq 3cac <sched_process_exec_event_submit_tail+0x3cac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3b00, 0x3cac, arm64_l_3cac);
arm64_l_3b04:
	/* 0x3b04: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3b08:
	/* 0x3b08: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3b0c:
	/* 0x3b0c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3b10:
	/* 0x3b10: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3b14:
	/* 0x3b14: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3b18:
	/* 0x3b18: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3b1c:
	/* 0x3b1c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3b20ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3b20:
	/* 0x3b20: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_3b24:
	/* 0x3b24: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3b28:
	/* 0x3b28: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_3b2c:
	/* 0x3b2c: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3b30:
	/* 0x3b30: b.cc 1dac <sched_process_exec_event_submit_tail+0x1dac> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x3b30, 0x1dac, arm64_l_1dac);
arm64_l_3b34:
	/* 0x3b34: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_3b38:
	/* 0x3b38: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_3b3c:
	/* 0x3b3c: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_3b40:
	/* 0x3b40: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_3b44:
	/* 0x3b44: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x3b48ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3b48:
	/* 0x3b48: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3b4c:
	/* 0x3b4c: b.lt 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x3b4c, 0x20ac, arm64_l_20ac);
arm64_l_3b50:
	/* 0x3b50: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3b54:
	/* 0x3b54: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_3b58:
	/* 0x3b58: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_3b5c:
	/* 0x3b5c: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_3b60:
	/* 0x3b60: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3b64:
	/* 0x3b64: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3b68:
	/* 0x3b68: b 3d24 <sched_process_exec_event_submit_tail+0x3d24> */
	ARM64_SIM_A64_JMP(0x3b68, 0x3d24, arm64_l_3d24);
arm64_l_3b6c:
	/* 0x3b6c: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3b70:
	/* 0x3b70: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3b70, 0x4dc, arm64_l_4dc);
arm64_l_3b74:
	/* 0x3b74: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3b78:
	/* 0x3b78: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3b7c:
	/* 0x3b7c: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3b7c, 0x4dc, arm64_l_4dc);
arm64_l_3b80:
	/* 0x3b80: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3b84:
	/* 0x3b84: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3b88:
	/* 0x3b88: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3b8c:
	/* 0x3b8c: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3b90:
	/* 0x3b90: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3b94:
	/* 0x3b94: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3b98:
	/* 0x3b98: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3b9c:
	/* 0x3b9c: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3ba0:
	/* 0x3ba0: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3ba4:
	/* 0x3ba4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3ba8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3ba8:
	/* 0x3ba8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3bac:
	/* 0x3bac: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3bb0:
	/* 0x3bb0: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3bb4:
	/* 0x3bb4: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3bb8:
	/* 0x3bb8: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3bbc:
	/* 0x3bbc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3bc0:
	/* 0x3bc0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3bc4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3bc4:
	/* 0x3bc4: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3bc8:
	/* 0x3bc8: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3bcc:
	/* 0x3bcc: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3bd0:
	/* 0x3bd0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3bd4:
	/* 0x3bd4: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3bd8:
	/* 0x3bd8: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3bdcULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3bdc:
	/* 0x3bdc: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3be0:
	/* 0x3be0: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3be4:
	/* 0x3be4: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3be8:
	/* 0x3be8: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3bec:
	/* 0x3bec: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3bf0:
	/* 0x3bf0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3bf4:
	/* 0x3bf4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3bf8:
	/* 0x3bf8: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3bfc:
	/* 0x3bfc: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3c00:
	/* 0x3c00: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3c04ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3c04:
	/* 0x3c04: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3c08:
	/* 0x3c08: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3c0c:
	/* 0x3c0c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3c10:
	/* 0x3c10: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3c14:
	/* 0x3c14: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3c18:
	/* 0x3c18: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3c1c:
	/* 0x3c1c: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3c20ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3c20:
	/* 0x3c20: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3c24:
	/* 0x3c24: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3c28:
	/* 0x3c28: b.eq 3de0 <sched_process_exec_event_submit_tail+0x3de0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3c28, 0x3de0, arm64_l_3de0);
arm64_l_3c2c:
	/* 0x3c2c: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3c30:
	/* 0x3c30: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3c34:
	/* 0x3c34: b.eq 3de0 <sched_process_exec_event_submit_tail+0x3de0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3c34, 0x3de0, arm64_l_3de0);
arm64_l_3c38:
	/* 0x3c38: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3c3c:
	/* 0x3c3c: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3c40:
	/* 0x3c40: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3c44:
	/* 0x3c44: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3c48:
	/* 0x3c48: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3c4c:
	/* 0x3c4c: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3c50:
	/* 0x3c50: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3c54ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3c54:
	/* 0x3c54: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_3c58:
	/* 0x3c58: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3c5c:
	/* 0x3c5c: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_3c60:
	/* 0x3c60: ldr w8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3c64:
	/* 0x3c64: subs w8, w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3c68:
	/* 0x3c68: b.cc 1eb4 <sched_process_exec_event_submit_tail+0x1eb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x3c68, 0x1eb4, arm64_l_1eb4);
arm64_l_3c6c:
	/* 0x3c6c: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_3c70:
	/* 0x3c70: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_3c74:
	/* 0x3c74: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_3c78:
	/* 0x3c78: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_3c7c:
	/* 0x3c7c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x3c80ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3c80:
	/* 0x3c80: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3c84:
	/* 0x3c84: b.lt 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x3c84, 0x4dc, arm64_l_4dc);
arm64_l_3c88:
	/* 0x3c88: ldr w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3c8c:
	/* 0x3c8c: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_3c90:
	/* 0x3c90: sub w8, w10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3c94:
	/* 0x3c94: sub w10, w10, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X10, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_3c98:
	/* 0x3c98: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_3c9c:
	/* 0x3c9c: str w10, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3ca0:
	/* 0x3ca0: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3ca4:
	/* 0x3ca4: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3ca8:
	/* 0x3ca8: b 3e58 <sched_process_exec_event_submit_tail+0x3e58> */
	ARM64_SIM_A64_JMP(0x3ca8, 0x3e58, arm64_l_3e58);
arm64_l_3cac:
	/* 0x3cac: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3cb0:
	/* 0x3cb0: b.ne 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3cb0, 0x20ac, arm64_l_20ac);
arm64_l_3cb4:
	/* 0x3cb4: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3cb8:
	/* 0x3cb8: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3cbc:
	/* 0x3cbc: b.eq 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3cbc, 0x20ac, arm64_l_20ac);
arm64_l_3cc0:
	/* 0x3cc0: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3cc4:
	/* 0x3cc4: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3cc8:
	/* 0x3cc8: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3ccc:
	/* 0x3ccc: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3cd0:
	/* 0x3cd0: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3cd4:
	/* 0x3cd4: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3cd8:
	/* 0x3cd8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3cdc:
	/* 0x3cdc: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3ce0:
	/* 0x3ce0: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3ce4:
	/* 0x3ce4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3ce8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3ce8:
	/* 0x3ce8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3cec:
	/* 0x3cec: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3cf0:
	/* 0x3cf0: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3cf4:
	/* 0x3cf4: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3cf8:
	/* 0x3cf8: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3cfc:
	/* 0x3cfc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3d00:
	/* 0x3d00: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3d04ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3d04:
	/* 0x3d04: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3d08:
	/* 0x3d08: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3d0c:
	/* 0x3d0c: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3d10:
	/* 0x3d10: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3d14:
	/* 0x3d14: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3d18:
	/* 0x3d18: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3d1cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3d1c:
	/* 0x3d1c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3d20:
	/* 0x3d20: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3d24:
	/* 0x3d24: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3d28:
	/* 0x3d28: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3d2c:
	/* 0x3d2c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3d30:
	/* 0x3d30: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3d34:
	/* 0x3d34: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3d38:
	/* 0x3d38: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3d3c:
	/* 0x3d3c: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3d40:
	/* 0x3d40: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3d44ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3d44:
	/* 0x3d44: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3d48:
	/* 0x3d48: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3d4c:
	/* 0x3d4c: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3d50:
	/* 0x3d50: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3d54:
	/* 0x3d54: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3d58:
	/* 0x3d58: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3d5c:
	/* 0x3d5c: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3d60ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3d60:
	/* 0x3d60: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3d64:
	/* 0x3d64: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3d68:
	/* 0x3d68: b.eq 3f1c <sched_process_exec_event_submit_tail+0x3f1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3d68, 0x3f1c, arm64_l_3f1c);
arm64_l_3d6c:
	/* 0x3d6c: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3d70:
	/* 0x3d70: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3d74:
	/* 0x3d74: b.eq 3f1c <sched_process_exec_event_submit_tail+0x3f1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3d74, 0x3f1c, arm64_l_3f1c);
arm64_l_3d78:
	/* 0x3d78: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3d7c:
	/* 0x3d7c: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3d80:
	/* 0x3d80: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3d84:
	/* 0x3d84: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3d88:
	/* 0x3d88: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3d8c:
	/* 0x3d8c: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3d90:
	/* 0x3d90: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3d94ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3d94:
	/* 0x3d94: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_3d98:
	/* 0x3d98: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3d9c:
	/* 0x3d9c: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_3da0:
	/* 0x3da0: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3da4:
	/* 0x3da4: b.cc 1dac <sched_process_exec_event_submit_tail+0x1dac> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x3da4, 0x1dac, arm64_l_1dac);
arm64_l_3da8:
	/* 0x3da8: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_3dac:
	/* 0x3dac: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_3db0:
	/* 0x3db0: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_3db4:
	/* 0x3db4: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_3db8:
	/* 0x3db8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x3dbcULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3dbc:
	/* 0x3dbc: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3dc0:
	/* 0x3dc0: b.lt 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x3dc0, 0x20ac, arm64_l_20ac);
arm64_l_3dc4:
	/* 0x3dc4: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3dc8:
	/* 0x3dc8: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_3dcc:
	/* 0x3dcc: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_3dd0:
	/* 0x3dd0: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_3dd4:
	/* 0x3dd4: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3dd8:
	/* 0x3dd8: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3ddc:
	/* 0x3ddc: b 3f94 <sched_process_exec_event_submit_tail+0x3f94> */
	ARM64_SIM_A64_JMP(0x3ddc, 0x3f94, arm64_l_3f94);
arm64_l_3de0:
	/* 0x3de0: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3de4:
	/* 0x3de4: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3de4, 0x4dc, arm64_l_4dc);
arm64_l_3de8:
	/* 0x3de8: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3dec:
	/* 0x3dec: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3df0:
	/* 0x3df0: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3df0, 0x4dc, arm64_l_4dc);
arm64_l_3df4:
	/* 0x3df4: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3df8:
	/* 0x3df8: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3dfc:
	/* 0x3dfc: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3e00:
	/* 0x3e00: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3e04:
	/* 0x3e04: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3e08:
	/* 0x3e08: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3e0c:
	/* 0x3e0c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3e10:
	/* 0x3e10: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3e14:
	/* 0x3e14: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3e18:
	/* 0x3e18: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3e1cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3e1c:
	/* 0x3e1c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3e20:
	/* 0x3e20: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3e24:
	/* 0x3e24: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3e28:
	/* 0x3e28: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3e2c:
	/* 0x3e2c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3e30:
	/* 0x3e30: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3e34:
	/* 0x3e34: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3e38ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3e38:
	/* 0x3e38: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3e3c:
	/* 0x3e3c: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3e40:
	/* 0x3e40: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3e44:
	/* 0x3e44: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3e48:
	/* 0x3e48: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3e4c:
	/* 0x3e4c: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3e50ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3e50:
	/* 0x3e50: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3e54:
	/* 0x3e54: add x29, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3e58:
	/* 0x3e58: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3e5c:
	/* 0x3e5c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3e60:
	/* 0x3e60: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3e64:
	/* 0x3e64: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3e68:
	/* 0x3e68: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3e6c:
	/* 0x3e6c: mov x2, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3e70:
	/* 0x3e70: mov w24, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3e74:
	/* 0x3e74: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3e78ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3e78:
	/* 0x3e78: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3e7c:
	/* 0x3e7c: ldr x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3e80:
	/* 0x3e80: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3e84:
	/* 0x3e84: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3e88:
	/* 0x3e88: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3e8c:
	/* 0x3e8c: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3e90:
	/* 0x3e90: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3e94ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3e94:
	/* 0x3e94: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3e98:
	/* 0x3e98: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3e9c:
	/* 0x3e9c: b.eq 4050 <sched_process_exec_event_submit_tail+0x4050> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3e9c, 0x4050, arm64_l_4050);
arm64_l_3ea0:
	/* 0x3ea0: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3ea4:
	/* 0x3ea4: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3ea8:
	/* 0x3ea8: b.eq 4050 <sched_process_exec_event_submit_tail+0x4050> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3ea8, 0x4050, arm64_l_4050);
arm64_l_3eac:
	/* 0x3eac: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3eb0:
	/* 0x3eb0: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3eb4:
	/* 0x3eb4: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3eb8:
	/* 0x3eb8: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3ebc:
	/* 0x3ebc: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3ec0:
	/* 0x3ec0: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3ec4:
	/* 0x3ec4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3ec8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3ec8:
	/* 0x3ec8: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_3ecc:
	/* 0x3ecc: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3ed0:
	/* 0x3ed0: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_3ed4:
	/* 0x3ed4: ldr w8, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3ed8:
	/* 0x3ed8: subs w8, w8, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X8, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3edc:
	/* 0x3edc: b.cc 1eb4 <sched_process_exec_event_submit_tail+0x1eb4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x3edc, 0x1eb4, arm64_l_1eb4);
arm64_l_3ee0:
	/* 0x3ee0: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_3ee4:
	/* 0x3ee4: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_3ee8:
	/* 0x3ee8: add x0, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_3eec:
	/* 0x3eec: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_3ef0:
	/* 0x3ef0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x3ef4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3ef4:
	/* 0x3ef4: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_3ef8:
	/* 0x3ef8: b.lt 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x3ef8, 0x4dc, arm64_l_4dc);
arm64_l_3efc:
	/* 0x3efc: ldr w22, [sp] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3f00:
	/* 0x3f00: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_3f04:
	/* 0x3f04: sub w8, w22, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_3f08:
	/* 0x3f08: sub w22, w22, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_3f0c:
	/* 0x3f0c: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_3f10:
	/* 0x3f10: strb w9, [x25, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X25, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_3f14:
	/* 0x3f14: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3f18:
	/* 0x3f18: b 4e0 <sched_process_exec_event_submit_tail+0x4e0> */
	ARM64_SIM_A64_JMP(0x3f18, 0x4e0, arm64_l_4e0);
arm64_l_3f1c:
	/* 0x3f1c: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3f20:
	/* 0x3f20: b.ne 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3f20, 0x20ac, arm64_l_20ac);
arm64_l_3f24:
	/* 0x3f24: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3f28:
	/* 0x3f28: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3f2c:
	/* 0x3f2c: b.eq 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3f2c, 0x20ac, arm64_l_20ac);
arm64_l_3f30:
	/* 0x3f30: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3f34:
	/* 0x3f34: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3f38:
	/* 0x3f38: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3f3c:
	/* 0x3f3c: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3f40:
	/* 0x3f40: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3f44:
	/* 0x3f44: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_3f48:
	/* 0x3f48: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3f4c:
	/* 0x3f4c: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3f50:
	/* 0x3f50: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3f54:
	/* 0x3f54: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3f58ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3f58:
	/* 0x3f58: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3f5c:
	/* 0x3f5c: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3f60:
	/* 0x3f60: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3f64:
	/* 0x3f64: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_3f68:
	/* 0x3f68: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3f6c:
	/* 0x3f6c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3f70:
	/* 0x3f70: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3f74ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3f74:
	/* 0x3f74: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3f78:
	/* 0x3f78: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3f7c:
	/* 0x3f7c: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_3f80:
	/* 0x3f80: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3f84:
	/* 0x3f84: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3f88:
	/* 0x3f88: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3f8cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3f8c:
	/* 0x3f8c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_3f90:
	/* 0x3f90: add x24, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3f94:
	/* 0x3f94: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3f98:
	/* 0x3f98: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3f9c:
	/* 0x3f9c: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3fa0:
	/* 0x3fa0: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3fa4:
	/* 0x3fa4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3fa8:
	/* 0x3fa8: mov x2, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_3fac:
	/* 0x3fac: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3fb0:
	/* 0x3fb0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3fb4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3fb4:
	/* 0x3fb4: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3fb8:
	/* 0x3fb8: ldr x21, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3fbc:
	/* 0x3fbc: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3fc0:
	/* 0x3fc0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3fc4:
	/* 0x3fc4: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_3fc8:
	/* 0x3fc8: add x8, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3fcc:
	/* 0x3fcc: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x3fd0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3fd0:
	/* 0x3fd0: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_3fd4:
	/* 0x3fd4: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3fd8:
	/* 0x3fd8: b.eq 40c4 <sched_process_exec_event_submit_tail+0x40c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3fd8, 0x40c4, arm64_l_40c4);
arm64_l_3fdc:
	/* 0x3fdc: ldr x20, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X20, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_3fe0:
	/* 0x3fe0: cmp x8, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_3fe4:
	/* 0x3fe4: b.eq 40c4 <sched_process_exec_event_submit_tail+0x40c4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3fe4, 0x40c4, arm64_l_40c4);
arm64_l_3fe8:
	/* 0x3fe8: add x2, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_3fec:
	/* 0x3fec: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_3ff0:
	/* 0x3ff0: mov w9, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_3ff4:
	/* 0x3ff4: add x10, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3ff8:
	/* 0x3ff8: add x0, sp, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_3ffc:
	/* 0x3ffc: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_4000:
	/* 0x4000: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x4004ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_4004:
	/* 0x4004: ldr w8, [sp, #76] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 76ULL);
arm64_l_4008:
	/* 0x4008: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_400c:
	/* 0x400c: and w1, w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_4010:
	/* 0x4010: subs w8, w19, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X8, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_4014:
	/* 0x4014: b.cc 1dac <sched_process_exec_event_submit_tail+0x1dac> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x4014, 0x1dac, arm64_l_1dac);
arm64_l_4018:
	/* 0x4018: ldr x2, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_401c:
	/* 0x401c: and w8, w8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_4020:
	/* 0x4020: add x0, x23, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_4024:
	/* 0x4024: mov w8, #0x73 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 115ULL);
arm64_l_4028:
	/* 0x4028: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 115ULL: ARM64_SIM_A64_LINK(0x402cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_402c:
	/* 0x402c: cmp w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_4030:
	/* 0x4030: b.lt 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x4030, 0x20ac, arm64_l_20ac);
arm64_l_4034:
	/* 0x4034: sub w8, w19, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_4038:
	/* 0x4038: mov w9, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_403c:
	/* 0x403c: sub w19, w19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_4040:
	/* 0x4040: and x8, x8, #0x7fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 32767ULL);
arm64_l_4044:
	/* 0x4044: strb w9, [x23, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_4048:
	/* 0x4048: str x20, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_404c:
	/* 0x404c: b 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JMP(0x404c, 0x20ac, arm64_l_20ac);
arm64_l_4050:
	/* 0x4050: cmp x8, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_4054:
	/* 0x4054: b.ne 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x4054, 0x4dc, arm64_l_4dc);
arm64_l_4058:
	/* 0x4058: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_405c:
	/* 0x405c: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_4060:
	/* 0x4060: b.eq 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x4060, 0x4dc, arm64_l_4dc);
arm64_l_4064:
	/* 0x4064: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_4068:
	/* 0x4068: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_406c:
	/* 0x406c: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_4070:
	/* 0x4070: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_4074:
	/* 0x4074: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_4078:
	/* 0x4078: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_407c:
	/* 0x407c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_4080:
	/* 0x4080: mov w22, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_4084:
	/* 0x4084: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_4088:
	/* 0x4088: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x408cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_408c:
	/* 0x408c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_4090:
	/* 0x4090: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_4094:
	/* 0x4094: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_4098:
	/* 0x4098: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_409c:
	/* 0x409c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_40a0:
	/* 0x40a0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_40a4:
	/* 0x40a4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x40a8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_40a8:
	/* 0x40a8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_40ac:
	/* 0x40ac: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_40b0:
	/* 0x40b0: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_40b4:
	/* 0x40b4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_40b8:
	/* 0x40b8: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_40bc:
	/* 0x40bc: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x40c0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_40c0:
	/* 0x40c0: b 4dc <sched_process_exec_event_submit_tail+0x4dc> */
	ARM64_SIM_A64_JMP(0x40c0, 0x4dc, arm64_l_4dc);
arm64_l_40c4:
	/* 0x40c4: cmp x8, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_40c8:
	/* 0x40c8: b.ne 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x40c8, 0x20ac, arm64_l_20ac);
arm64_l_40cc:
	/* 0x40cc: ldp x8, x9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_40d0:
	/* 0x40d0: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_40d4:
	/* 0x40d4: b.eq 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x40d4, 0x20ac, arm64_l_20ac);
arm64_l_40d8:
	/* 0x40d8: add x8, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_40dc:
	/* 0x40dc: mov w20, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_40e0:
	/* 0x40e0: add x9, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_40e4:
	/* 0x40e4: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_40e8:
	/* 0x40e8: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_40ec:
	/* 0x40ec: add x0, sp, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_40f0:
	/* 0x40f0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_40f4:
	/* 0x40f4: mov w21, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_40f8:
	/* 0x40f8: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_40fc:
	/* 0x40fc: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x4100ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_4100:
	/* 0x4100: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_4104:
	/* 0x4104: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_4108:
	/* 0x4108: mov w10, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_410c:
	/* 0x410c: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_4110:
	/* 0x4110: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_4114:
	/* 0x4114: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_4118:
	/* 0x4118: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x411cULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_411c:
	/* 0x411c: ldr x8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_4120:
	/* 0x4120: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_4124:
	/* 0x4124: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_4128:
	/* 0x4128: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_412c:
	/* 0x412c: ldr x2, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_4130:
	/* 0x4130: blr x21 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X21);
		if (ARM64_SIM_L_REG_TAG(ARM64_X21) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x4134ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_4134:
	/* 0x4134: b 20ac <sched_process_exec_event_submit_tail+0x20ac> */
	ARM64_SIM_A64_JMP(0x4134, 0x20ac, arm64_l_20ac);
arm64_l_4138:
	/* 0x4138: mov x7, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
