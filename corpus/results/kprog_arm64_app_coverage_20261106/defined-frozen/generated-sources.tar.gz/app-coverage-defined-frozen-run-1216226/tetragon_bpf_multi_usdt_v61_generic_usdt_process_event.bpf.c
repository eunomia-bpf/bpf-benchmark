extern char CONFIG_ITER_NUM;
extern char buffer_heap_map;
extern char config_map;
extern char data_heap;
extern char fdinstall_map;
extern char process_call_heap;
extern char retprobe_map;
extern char sleepable_preload;
extern char socktrack_map;
extern char tcpmon_map;
extern char tg_conf_map;
extern char tg_errmetrics_map;
extern char tg_ipv6_ext_heap;
extern char tg_rb_events;
extern char tg_stats_map;
extern char usdt_calls;
#define ARM64_SIM_RET_CASES_2c7c case 0x2150ULL: goto arm64_l_2150;
#define ARM64_SIM_RET_CASES_2e04 case 0x2c40ULL: goto arm64_l_2c40;
#define ARM64_SIM_RET_CASES_2ebc case 0x2c40ULL: goto arm64_l_2c40;
#define ARM64_SIM_RET_CASES_2f60 case 0x2ca4ULL: goto arm64_l_2ca4; case 0x2cc4ULL: goto arm64_l_2cc4; case 0x2ce8ULL: goto arm64_l_2ce8; case 0x2d0cULL: goto arm64_l_2d0c; case 0x2d30ULL: goto arm64_l_2d30; case 0x2d54ULL: goto arm64_l_2d54; case 0x2d78ULL: goto arm64_l_2d78; case 0x2d9cULL: goto arm64_l_2d9c; case 0x2dc0ULL: goto arm64_l_2dc0; case 0x2de4ULL: goto arm64_l_2de4;
#define ARM64_SIM_RET_CASES_2f78 case 0x2ca4ULL: goto arm64_l_2ca4; case 0x2cc4ULL: goto arm64_l_2cc4; case 0x2ce8ULL: goto arm64_l_2ce8; case 0x2d0cULL: goto arm64_l_2d0c; case 0x2d30ULL: goto arm64_l_2d30; case 0x2d54ULL: goto arm64_l_2d54; case 0x2d78ULL: goto arm64_l_2d78; case 0x2d9cULL: goto arm64_l_2d9c; case 0x2dc0ULL: goto arm64_l_2dc0; case 0x2de4ULL: goto arm64_l_2de4;
#define ARM64_SIM_RET_CASES_2fb0 case 0x2ca4ULL: goto arm64_l_2ca4; case 0x2cc4ULL: goto arm64_l_2cc4; case 0x2ce8ULL: goto arm64_l_2ce8; case 0x2d0cULL: goto arm64_l_2d0c; case 0x2d30ULL: goto arm64_l_2d30; case 0x2d54ULL: goto arm64_l_2d54; case 0x2d78ULL: goto arm64_l_2d78; case 0x2d9cULL: goto arm64_l_2d9c; case 0x2dc0ULL: goto arm64_l_2dc0; case 0x2de4ULL: goto arm64_l_2de4;
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_RETURN_CASES \
	case 0x3cULL: goto arm64_l_3c; \
	case 0x74ULL: goto arm64_l_74; \
	case 0x94ULL: goto arm64_l_94; \
	case 0x100ULL: goto arm64_l_100; \
	case 0x11cULL: goto arm64_l_11c; \
	case 0x154ULL: goto arm64_l_154; \
	case 0x1c8ULL: goto arm64_l_1c8; \
	case 0x224ULL: goto arm64_l_224; \
	case 0x258ULL: goto arm64_l_258; \
	case 0x424ULL: goto arm64_l_424; \
	case 0x4bcULL: goto arm64_l_4bc; \
	case 0x4d8ULL: goto arm64_l_4d8; \
	case 0x510ULL: goto arm64_l_510; \
	case 0x52cULL: goto arm64_l_52c; \
	case 0x5dcULL: goto arm64_l_5dc; \
	case 0x604ULL: goto arm64_l_604; \
	case 0x640ULL: goto arm64_l_640; \
	case 0x674ULL: goto arm64_l_674; \
	case 0x6a0ULL: goto arm64_l_6a0; \
	case 0x6b8ULL: goto arm64_l_6b8; \
	case 0x6d8ULL: goto arm64_l_6d8; \
	case 0x708ULL: goto arm64_l_708; \
	case 0x720ULL: goto arm64_l_720; \
	case 0x750ULL: goto arm64_l_750; \
	case 0x7c8ULL: goto arm64_l_7c8; \
	case 0x7dcULL: goto arm64_l_7dc; \
	case 0x7f4ULL: goto arm64_l_7f4; \
	case 0x804ULL: goto arm64_l_804; \
	case 0x858ULL: goto arm64_l_858; \
	case 0x888ULL: goto arm64_l_888; \
	case 0x8acULL: goto arm64_l_8ac; \
	case 0x8c8ULL: goto arm64_l_8c8; \
	case 0x93cULL: goto arm64_l_93c; \
	case 0x980ULL: goto arm64_l_980; \
	case 0x9a8ULL: goto arm64_l_9a8; \
	case 0x9f0ULL: goto arm64_l_9f0; \
	case 0xa3cULL: goto arm64_l_a3c; \
	case 0xb08ULL: goto arm64_l_b08; \
	case 0xb98ULL: goto arm64_l_b98; \
	case 0xbb8ULL: goto arm64_l_bb8; \
	case 0xbdcULL: goto arm64_l_bdc; \
	case 0xbfcULL: goto arm64_l_bfc; \
	case 0xcc8ULL: goto arm64_l_cc8; \
	case 0xce0ULL: goto arm64_l_ce0; \
	case 0xcf4ULL: goto arm64_l_cf4; \
	case 0xd08ULL: goto arm64_l_d08; \
	case 0xd1cULL: goto arm64_l_d1c; \
	case 0xd2cULL: goto arm64_l_d2c; \
	case 0xd68ULL: goto arm64_l_d68; \
	case 0xd78ULL: goto arm64_l_d78; \
	case 0xdf4ULL: goto arm64_l_df4; \
	case 0xe08ULL: goto arm64_l_e08; \
	case 0xe28ULL: goto arm64_l_e28; \
	case 0xe5cULL: goto arm64_l_e5c; \
	case 0xec8ULL: goto arm64_l_ec8; \
	case 0xeecULL: goto arm64_l_eec; \
	case 0xf20ULL: goto arm64_l_f20; \
	case 0xfb4ULL: goto arm64_l_fb4; \
	case 0xfecULL: goto arm64_l_fec; \
	case 0x100cULL: goto arm64_l_100c; \
	case 0x104cULL: goto arm64_l_104c; \
	case 0x1078ULL: goto arm64_l_1078; \
	case 0x1090ULL: goto arm64_l_1090; \
	case 0x10a4ULL: goto arm64_l_10a4; \
	case 0x10b8ULL: goto arm64_l_10b8; \
	case 0x10ccULL: goto arm64_l_10cc; \
	case 0x10dcULL: goto arm64_l_10dc; \
	case 0x1118ULL: goto arm64_l_1118; \
	case 0x1128ULL: goto arm64_l_1128; \
	case 0x1180ULL: goto arm64_l_1180; \
	case 0x11a0ULL: goto arm64_l_11a0; \
	case 0x11e4ULL: goto arm64_l_11e4; \
	case 0x1238ULL: goto arm64_l_1238; \
	case 0x1258ULL: goto arm64_l_1258; \
	case 0x126cULL: goto arm64_l_126c; \
	case 0x1288ULL: goto arm64_l_1288; \
	case 0x1298ULL: goto arm64_l_1298; \
	case 0x12d4ULL: goto arm64_l_12d4; \
	case 0x12f8ULL: goto arm64_l_12f8; \
	case 0x131cULL: goto arm64_l_131c; \
	case 0x133cULL: goto arm64_l_133c; \
	case 0x1368ULL: goto arm64_l_1368; \
	case 0x1380ULL: goto arm64_l_1380; \
	case 0x1398ULL: goto arm64_l_1398; \
	case 0x13c4ULL: goto arm64_l_13c4; \
	case 0x13f4ULL: goto arm64_l_13f4; \
	case 0x140cULL: goto arm64_l_140c; \
	case 0x1424ULL: goto arm64_l_1424; \
	case 0x149cULL: goto arm64_l_149c; \
	case 0x14b0ULL: goto arm64_l_14b0; \
	case 0x14c4ULL: goto arm64_l_14c4; \
	case 0x14d8ULL: goto arm64_l_14d8; \
	case 0x14f8ULL: goto arm64_l_14f8; \
	case 0x1514ULL: goto arm64_l_1514; \
	case 0x1538ULL: goto arm64_l_1538; \
	case 0x1570ULL: goto arm64_l_1570; \
	case 0x15a4ULL: goto arm64_l_15a4; \
	case 0x15b8ULL: goto arm64_l_15b8; \
	case 0x15ccULL: goto arm64_l_15cc; \
	case 0x15f0ULL: goto arm64_l_15f0; \
	case 0x162cULL: goto arm64_l_162c; \
	case 0x1660ULL: goto arm64_l_1660; \
	case 0x16f8ULL: goto arm64_l_16f8; \
	case 0x170cULL: goto arm64_l_170c; \
	case 0x1720ULL: goto arm64_l_1720; \
	case 0x1734ULL: goto arm64_l_1734; \
	case 0x1748ULL: goto arm64_l_1748; \
	case 0x175cULL: goto arm64_l_175c; \
	case 0x1770ULL: goto arm64_l_1770; \
	case 0x1784ULL: goto arm64_l_1784; \
	case 0x179cULL: goto arm64_l_179c; \
	case 0x17b4ULL: goto arm64_l_17b4; \
	case 0x17c8ULL: goto arm64_l_17c8; \
	case 0x17dcULL: goto arm64_l_17dc; \
	case 0x17f4ULL: goto arm64_l_17f4; \
	case 0x180cULL: goto arm64_l_180c; \
	case 0x1820ULL: goto arm64_l_1820; \
	case 0x1834ULL: goto arm64_l_1834; \
	case 0x1844ULL: goto arm64_l_1844; \
	case 0x186cULL: goto arm64_l_186c; \
	case 0x1880ULL: goto arm64_l_1880; \
	case 0x1894ULL: goto arm64_l_1894; \
	case 0x18a4ULL: goto arm64_l_18a4; \
	case 0x18c8ULL: goto arm64_l_18c8; \
	case 0x18dcULL: goto arm64_l_18dc; \
	case 0x18f0ULL: goto arm64_l_18f0; \
	case 0x1904ULL: goto arm64_l_1904; \
	case 0x1918ULL: goto arm64_l_1918; \
	case 0x193cULL: goto arm64_l_193c; \
	case 0x1950ULL: goto arm64_l_1950; \
	case 0x1964ULL: goto arm64_l_1964; \
	case 0x1988ULL: goto arm64_l_1988; \
	case 0x19a8ULL: goto arm64_l_19a8; \
	case 0x19d0ULL: goto arm64_l_19d0; \
	case 0x19f0ULL: goto arm64_l_19f0; \
	case 0x1a2cULL: goto arm64_l_1a2c; \
	case 0x1a54ULL: goto arm64_l_1a54; \
	case 0x1a78ULL: goto arm64_l_1a78; \
	case 0x1aa0ULL: goto arm64_l_1aa0; \
	case 0x1ab4ULL: goto arm64_l_1ab4; \
	case 0x1afcULL: goto arm64_l_1afc; \
	case 0x1b10ULL: goto arm64_l_1b10; \
	case 0x1b6cULL: goto arm64_l_1b6c; \
	case 0x1ba0ULL: goto arm64_l_1ba0; \
	case 0x1be8ULL: goto arm64_l_1be8; \
	case 0x1bf8ULL: goto arm64_l_1bf8; \
	case 0x1c1cULL: goto arm64_l_1c1c; \
	case 0x1c2cULL: goto arm64_l_1c2c; \
	case 0x1c60ULL: goto arm64_l_1c60; \
	case 0x1ca0ULL: goto arm64_l_1ca0; \
	case 0x1cf0ULL: goto arm64_l_1cf0; \
	case 0x1d30ULL: goto arm64_l_1d30; \
	case 0x1d7cULL: goto arm64_l_1d7c; \
	case 0x1d90ULL: goto arm64_l_1d90; \
	case 0x1de8ULL: goto arm64_l_1de8; \
	case 0x1e40ULL: goto arm64_l_1e40; \
	case 0x1e50ULL: goto arm64_l_1e50; \
	case 0x1e74ULL: goto arm64_l_1e74; \
	case 0x1e84ULL: goto arm64_l_1e84; \
	case 0x1eb8ULL: goto arm64_l_1eb8; \
	case 0x1f18ULL: goto arm64_l_1f18; \
	case 0x1f44ULL: goto arm64_l_1f44; \
	case 0x1f94ULL: goto arm64_l_1f94; \
	case 0x1fd4ULL: goto arm64_l_1fd4; \
	case 0x2030ULL: goto arm64_l_2030; \
	case 0x209cULL: goto arm64_l_209c; \
	case 0x20c8ULL: goto arm64_l_20c8; \
	case 0x2120ULL: goto arm64_l_2120; \
	case 0x2150ULL: goto arm64_l_2150; \
	case 0x21a4ULL: goto arm64_l_21a4; \
	case 0x21e4ULL: goto arm64_l_21e4; \
	case 0x220cULL: goto arm64_l_220c; \
	case 0x223cULL: goto arm64_l_223c; \
	case 0x2268ULL: goto arm64_l_2268; \
	case 0x229cULL: goto arm64_l_229c; \
	case 0x22ccULL: goto arm64_l_22cc; \
	case 0x2300ULL: goto arm64_l_2300; \
	case 0x232cULL: goto arm64_l_232c; \
	case 0x2360ULL: goto arm64_l_2360; \
	case 0x2390ULL: goto arm64_l_2390; \
	case 0x23c4ULL: goto arm64_l_23c4; \
	case 0x23f0ULL: goto arm64_l_23f0; \
	case 0x2420ULL: goto arm64_l_2420; \
	case 0x24a4ULL: goto arm64_l_24a4; \
	case 0x2588ULL: goto arm64_l_2588; \
	case 0x2668ULL: goto arm64_l_2668; \
	case 0x2748ULL: goto arm64_l_2748; \
	case 0x2828ULL: goto arm64_l_2828; \
	case 0x2908ULL: goto arm64_l_2908; \
	case 0x29e8ULL: goto arm64_l_29e8; \
	case 0x2a1cULL: goto arm64_l_2a1c; \
	case 0x2a2cULL: goto arm64_l_2a2c; \
	case 0x2a68ULL: goto arm64_l_2a68; \
	case 0x2aa0ULL: goto arm64_l_2aa0; \
	case 0x2ab0ULL: goto arm64_l_2ab0; \
	case 0x2afcULL: goto arm64_l_2afc; \
	case 0x2b34ULL: goto arm64_l_2b34; \
	case 0x2b58ULL: goto arm64_l_2b58; \
	case 0x2b68ULL: goto arm64_l_2b68; \
	case 0x2be8ULL: goto arm64_l_2be8; \
	case 0x2c00ULL: goto arm64_l_2c00; \
	case 0x2c20ULL: goto arm64_l_2c20; \
	case 0x2c40ULL: goto arm64_l_2c40; \
	case 0x2ca4ULL: goto arm64_l_2ca4; \
	case 0x2cc4ULL: goto arm64_l_2cc4; \
	case 0x2ce8ULL: goto arm64_l_2ce8; \
	case 0x2d0cULL: goto arm64_l_2d0c; \
	case 0x2d30ULL: goto arm64_l_2d30; \
	case 0x2d54ULL: goto arm64_l_2d54; \
	case 0x2d78ULL: goto arm64_l_2d78; \
	case 0x2d9cULL: goto arm64_l_2d9c; \
	case 0x2dc0ULL: goto arm64_l_2dc0; \
	case 0x2de4ULL: goto arm64_l_2de4; \
	case 0x2e28ULL: goto arm64_l_2e28; \
	case 0x2ef4ULL: goto arm64_l_2ef4; \
	case 0x2f1cULL: goto arm64_l_2f1c; \
	case 0x2f4cULL: goto arm64_l_2f4c; \
	case 0x2f98ULL: goto arm64_l_2f98;
#include "../arm64_sim_local_bpf.h"

static const __u64 __arm64_rodata_0[2] = {6052838352053347359ULL, 15447069371456815136ULL};
static const __u64 __arm64_rodata_1[2] = {12178401890396095487ULL, 12178947204542846966ULL};

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} CONFIG_ITER_NUM_0 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} arm64_section_Some_SectionIndex_14_addend_0_1 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} buffer_heap_map_2 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} config_map_3 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} data_heap_4 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} fdinstall_map_5 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} process_call_heap_6 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} retprobe_map_7 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} sleepable_preload_8 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} socktrack_map_9 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tcpmon_map_10 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_conf_map_11 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_errmetrics_map_12 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_ipv6_ext_heap_13 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_rb_events_14 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} tg_stats_map_15 SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u64);
} usdt_calls_16 SEC(".maps");

SEC("xdp")
int tetragon_bpf_multi_usdt_v61_generic_usdt_process_event_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
	/* native subroutine tetragon_bpf_multi_usdt_v61_generic_usdt_process_event_xdp */
arm64_l_0:
	/* 0x0: sub sp, sp, #0x160 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 352ULL);
arm64_l_4:
	/* 0x4: str x29, [sp, #272] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 272ULL);
arm64_l_8:
	/* 0x8: stp x30, x25, [sp, #288] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 288ULL);
arm64_l_c:
	/* 0xc: stp x24, x23, [sp, #304] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 304ULL);
arm64_l_10:
	/* 0x10: stp x22, x21, [sp, #320] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 320ULL);
arm64_l_14:
	/* 0x14: stp x20, x19, [sp, #336] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 336ULL);
arm64_l_18:
	/* 0x18: str wzr, [sp, #92] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 92ULL);
arm64_l_1c:
	/* 0x1c: adrp x21, 0 <process_call_heap> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_6));
arm64_l_20:
	/* 0x20: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_24:
	/* 0x24: add x9, sp, #0x5c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 92ULL);
arm64_l_28:
	/* 0x28: ldr x21, [x21] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c:
	/* 0x2c: mov x19, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_30:
	/* 0x30: add x1, sp, #0x5c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 92ULL);
arm64_l_34:
	/* 0x34: mov x0, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_38:
	/* 0x38: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x3cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_3c:
	/* 0x3c: cbz x0, 52c <generic_usdt_process_event+0x52c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x3c, 0x52c, arm64_l_52c);
arm64_l_40:
	/* 0x40: ldr w24, [x0, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_44:
	/* 0x44: mov w29, #0x5efc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24316ULL);
arm64_l_48:
	/* 0x48: mov x20, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_4c:
	/* 0x4c: ldr w23, [x0, x29] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X29, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_50:
	/* 0x50: lsr w8, w24, #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 3ULL);
arm64_l_54:
	/* 0x54: cmp w8, #0x464 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1124ULL);
arm64_l_58:
	/* 0x58: b.hi 490 <generic_usdt_process_event+0x490> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x58, 0x490, arm64_l_490);
arm64_l_5c:
	/* 0x5c: str wzr, [sp, #104] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 104ULL);
arm64_l_60:
	/* 0x60: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_64:
	/* 0x64: add x9, sp, #0x68 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 104ULL);
arm64_l_68:
	/* 0x68: add x1, sp, #0x68 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 104ULL);
arm64_l_6c:
	/* 0x6c: mov x0, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_70:
	/* 0x70: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x74ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_74:
	/* 0x74: cbz x0, 490 <generic_usdt_process_event+0x490> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x74, 0x490, arm64_l_490);
arm64_l_78:
	/* 0x78: mov w8, #0x5ef8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24312ULL);
arm64_l_7c:
	/* 0x7c: mov x22, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_80:
	/* 0x80: add x1, x0, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X1, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_84:
	/* 0x84: adrp x0, 0 <config_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_map_3));
arm64_l_88:
	/* 0x88: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_8c:
	/* 0x8c: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_90:
	/* 0x90: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x94ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_94:
	/* 0x94: cmp w23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_98:
	/* 0x98: ccmp x0, #0x0, #0x4, le */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CCMP_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_LE, 4), 0ULL);
arm64_l_9c:
	/* 0x9c: b.eq 490 <generic_usdt_process_event+0x490> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x9c, 0x490, arm64_l_490);
arm64_l_a0:
	/* 0xa0: str x23, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_a4:
	/* 0xa4: and x23, x23, #0x7 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_a8:
	/* 0xa8: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_ac:
	/* 0xac: str x24, [sp, #280] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 280ULL);
arm64_l_b0:
	/* 0xb0: add x21, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_b4:
	/* 0xb4: add x8, x0, x23, lsl #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_b8:
	/* 0xb8: ldr w25, [x8, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_bc:
	/* 0xbc: ldrsw x10, [x8, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDRSW, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_c0:
	/* 0xc0: add x8, x22, x23, lsl #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_c4:
	/* 0xc4: add x24, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_c8:
	/* 0xc8: add x8, x22, x23, lsl #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 3), 0);
arm64_l_cc:
	/* 0xcc: ldr x22, [x8, #24144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24144ULL);
arm64_l_d0:
	/* 0xd0: str wzr, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d4:
	/* 0xd4: str x10, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_d8:
	/* 0xd8: str x22, [sp, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_dc:
	/* 0xdc: tbnz w10, #8, f4 <generic_usdt_process_event+0xf4> */
	ARM64_SIM_A64_TBNZ(ARM64_X10, 8, 0xdc, 0xf4, arm64_l_f4);
arm64_l_e0:
	/* 0xe0: cmp w23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_e4:
	/* 0xe4: b.ls 168 <generic_usdt_process_event+0x168> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0xe4, 0x168, arm64_l_168);
arm64_l_e8:
	/* 0xe8: adrp x21, 0 <process_call_heap> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_6));
arm64_l_ec:
	/* 0xec: ldr x21, [x21] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f0:
	/* 0xf0: b 260 <generic_usdt_process_event+0x260> */
	ARM64_SIM_A64_JMP(0xf0, 0x260, arm64_l_260);
arm64_l_f4:
	/* 0xf4: str xzr, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_f8:
	/* 0xf8: mov w8, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_fc:
	/* 0xfc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x100ULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_100:
	/* 0x100: str x0, [x21, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_104:
	/* 0x104: adrp x0, 0 <sleepable_preload> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&sleepable_preload_8));
arm64_l_108:
	/* 0x108: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_10c:
	/* 0x10c: add x9, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_110:
	/* 0x110: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_114:
	/* 0x114: add x1, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_118:
	/* 0x118: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x11cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_11c:
	/* 0x11c: cbz x0, 154 <generic_usdt_process_event+0x154> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x11c, 0x154, arm64_l_154);
arm64_l_120:
	/* 0x120: ldr w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_124:
	/* 0x124: cmp w25, #0x6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_128:
	/* 0x128: str w8, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_12c:
	/* 0x12c: b.ne 154 <generic_usdt_process_event+0x154> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x12c, 0x154, arm64_l_154);
arm64_l_130:
	/* 0x130: add x8, x0, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_134:
	/* 0x134: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_138:
	/* 0x138: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_13c:
	/* 0x13c: str x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_140:
	/* 0x140: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_144:
	/* 0x144: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_148:
	/* 0x148: add x2, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_14c:
	/* 0x14c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_150:
	/* 0x150: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x154ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_154:
	/* 0x154: ldr x22, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_158:
	/* 0x158: adrp x21, 0 <process_call_heap> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_6));
arm64_l_15c:
	/* 0x15c: str x22, [sp, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_160:
	/* 0x160: ldr x21, [x21] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_164:
	/* 0x164: b 260 <generic_usdt_process_event+0x260> */
	ARM64_SIM_A64_JMP(0x164, 0x260, arm64_l_260);
arm64_l_168:
	/* 0x168: mov w8, #0x50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 80ULL);
arm64_l_16c:
	/* 0x16c: adrp x21, 0 <process_call_heap> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_6));
arm64_l_170:
	/* 0x170: umaddl x8, w23, w8, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_UMADDL, ARM64_X8, ARM64_X23, ARM64_X8, ARM64_X0, ARM64_WIDTH_64, 0, 0);
arm64_l_174:
	/* 0x174: ldrh w9, [x8, #118] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 118ULL);
arm64_l_178:
	/* 0x178: ldr x21, [x21] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_17c:
	/* 0x17c: cbz w9, 260 <generic_usdt_process_event+0x260> */
	ARM64_SIM_A64_CBZ_W(ARM64_X9, 0x17c, 0x260, arm64_l_260);
arm64_l_180:
	/* 0x180: add x8, x8, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_184:
	/* 0x184: add x9, sp, #0x60 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_188:
	/* 0x188: strb wzr, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_18c:
	/* 0x18c: str x24, [sp, #176] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_190:
	/* 0x190: stp x8, x9, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_194:
	/* 0x194: adrp x8, 0 <CONFIG_ITER_NUM> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM_0));
arm64_l_198:
	/* 0x198: ldr x8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19c:
	/* 0x19c: ldrb w8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a0:
	/* 0x1a0: cbz w8, 234 <generic_usdt_process_event+0x234> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x1a0, 0x234, arm64_l_234);
arm64_l_1a4:
	/* 0x1a4: mov x24, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a8:
	/* 0x1a8: mov w22, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1ac:
	/* 0x1ac: mov w29, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1b0:
	/* 0x1b0: b 1dc <generic_usdt_process_event+0x1dc> */
	ARM64_SIM_A64_JMP(0x1b0, 0x1dc, arm64_l_1dc);
arm64_l_1b4:
	/* 0x1b4: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1b8:
	/* 0x1b8: ldr x0, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_1bc:
	/* 0x1bc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1c0:
	/* 0x1c0: ldr x2, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c4:
	/* 0x1c4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1c8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1c8:
	/* 0x1c8: tbnz w0, #31, 228 <generic_usdt_process_event+0x228> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x1c8, 0x228, arm64_l_228);
arm64_l_1cc:
	/* 0x1cc: add x24, x24, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1d0:
	/* 0x1d0: add w22, w22, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1d4:
	/* 0x1d4: cmp x24, #0x50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 80ULL);
arm64_l_1d8:
	/* 0x1d8: b.eq 258 <generic_usdt_process_event+0x258> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d8, 0x258, arm64_l_258);
arm64_l_1dc:
	/* 0x1dc: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1e0:
	/* 0x1e0: add x10, x8, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1e4:
	/* 0x1e4: ldrh w8, [x10, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_1e8:
	/* 0x1e8: cbz w8, 258 <generic_usdt_process_event+0x258> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x1e8, 0x258, arm64_l_258);
arm64_l_1ec:
	/* 0x1ec: ldr x8, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_1f0:
	/* 0x1f0: ldr w11, [x10] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f4:
	/* 0x1f4: ldr x9, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f8:
	/* 0x1f8: add x9, x9, x11 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X9, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1fc:
	/* 0x1fc: str x9, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_200:
	/* 0x200: ldrh w10, [x10, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_204:
	/* 0x204: cbz w10, 1cc <generic_usdt_process_event+0x1cc> */
	ARM64_SIM_A64_CBZ_W(ARM64_X10, 0x204, 0x1cc, arm64_l_1cc);
arm64_l_208:
	/* 0x208: ldrb w10, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_20c:
	/* 0x20c: cbz w10, 1b4 <generic_usdt_process_event+0x1b4> */
	ARM64_SIM_A64_CBZ_W(ARM64_X10, 0x20c, 0x1b4, arm64_l_1b4);
arm64_l_210:
	/* 0x210: mov w10, #0x94 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 148ULL);
arm64_l_214:
	/* 0x214: ldr x0, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_218:
	/* 0x218: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_21c:
	/* 0x21c: ldr x2, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_220:
	/* 0x220: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 148ULL: ARM64_SIM_A64_LINK(0x224ULL); ARM64_SIM_BPF_CALL_bpf_copy_from_user(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_224:
	/* 0x224: tbz w0, #31, 1cc <generic_usdt_process_event+0x1cc> */
	ARM64_SIM_A64_TBZ(ARM64_X0, 31, 0x224, 0x1cc, arm64_l_1cc);
arm64_l_228:
	/* 0x228: ldr x8, [sp, #176] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_22c:
	/* 0x22c: str w22, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_230:
	/* 0x230: b 258 <generic_usdt_process_event+0x258> */
	ARM64_SIM_A64_JMP(0x230, 0x258, arm64_l_258);
arm64_l_234:
	/* 0x234: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_238:
	/* 0x238: adrp x1, 0 <generic_usdt_process_event> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_RODATA, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)__arm64_rodata_0));
arm64_l_23c:
	/* 0x23c: add x1, x1, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_240:
	/* 0x240: mov w8, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_244:
	/* 0x244: mov w9, #0xb5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 181ULL);
arm64_l_248:
	/* 0x248: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_24c:
	/* 0x24c: add x2, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_250:
	/* 0x250: mov w0, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_254:
	/* 0x254: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 181ULL: ARM64_SIM_A64_LINK(0x258ULL); ARM64_SIM_BPF_CALL_bpf_loop(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_258:
	/* 0x258: ldr x22, [sp, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_25c:
	/* 0x25c: mov w29, #0x5efc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24316ULL);
arm64_l_260:
	/* 0x260: mov w24, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_264:
	/* 0x264: cmp w25, #0x15; 0x268: b.gt 29c <generic_usdt_process_event+0x29c> */
arm64_l_268:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL, arm64_l_29c);
arm64_l_26c:
	/* 0x26c: cmp w25, #0xb; 0x270: b.gt 2cc <generic_usdt_process_event+0x2cc> */
arm64_l_270:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 11ULL, arm64_l_2cc);
arm64_l_274:
	/* 0x274: cmp w25, #0x5; 0x278: b.gt 33c <generic_usdt_process_event+0x33c> */
arm64_l_278:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL, arm64_l_33c);
arm64_l_27c:
	/* 0x27c: cmp w25, #0x3; 0x280: b.gt 3d0 <generic_usdt_process_event+0x3d0> */
arm64_l_280:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL, arm64_l_3d0);
arm64_l_284:
	/* 0x284: sub w8, w25, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_288:
	/* 0x288: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_28c:
	/* 0x28c: b.cc 38c <generic_usdt_process_event+0x38c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x28c, 0x38c, arm64_l_38c);
arm64_l_290:
	/* 0x290: cmp w25, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_294:
	/* 0x294: b.eq 38c <generic_usdt_process_event+0x38c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x294, 0x38c, arm64_l_38c);
arm64_l_298:
	/* 0x298: b 408 <generic_usdt_process_event+0x408> */
	ARM64_SIM_A64_JMP(0x298, 0x408, arm64_l_408);
arm64_l_29c:
	/* 0x29c: cmp w25, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2a0:
	/* 0x2a0: b.le 2f0 <generic_usdt_process_event+0x2f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x2a0, 0x2f0, arm64_l_2f0);
arm64_l_2a4:
	/* 0x2a4: cmp w25, #0x27; 0x2a8: b.gt 314 <generic_usdt_process_event+0x314> */
arm64_l_2a8:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 39ULL, arm64_l_314);
arm64_l_2ac:
	/* 0x2ac: sub w8, w25, #0x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_2b0:
	/* 0x2b0: cmp w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_2b4:
	/* 0x2b4: b.cc 3e8 <generic_usdt_process_event+0x3e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2b4, 0x3e8, arm64_l_3e8);
arm64_l_2b8:
	/* 0x2b8: cmp w25, #0x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_2bc:
	/* 0x2bc: b.eq 40c <generic_usdt_process_event+0x40c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2bc, 0x40c, arm64_l_40c);
arm64_l_2c0:
	/* 0x2c0: cmp w25, #0x27 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 39ULL);
arm64_l_2c4:
	/* 0x2c4: b.eq 394 <generic_usdt_process_event+0x394> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2c4, 0x394, arm64_l_394);
arm64_l_2c8:
	/* 0x2c8: b 408 <generic_usdt_process_event+0x408> */
	ARM64_SIM_A64_JMP(0x2c8, 0x408, arm64_l_408);
arm64_l_2cc:
	/* 0x2cc: cmp w25, #0x11; 0x2d0: b.gt 360 <generic_usdt_process_event+0x360> */
arm64_l_2d0:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL, arm64_l_360);
arm64_l_2d4:
	/* 0x2d4: sub w8, w25, #0xf */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_2d8:
	/* 0x2d8: cmp w8, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2dc:
	/* 0x2dc: b.cc 40c <generic_usdt_process_event+0x40c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2dc, 0x40c, arm64_l_40c);
arm64_l_2e0:
	/* 0x2e0: sub w8, w25, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2e4:
	/* 0x2e4: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2e8:
	/* 0x2e8: b.cc 38c <generic_usdt_process_event+0x38c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2e8, 0x38c, arm64_l_38c);
arm64_l_2ec:
	/* 0x2ec: b 408 <generic_usdt_process_event+0x408> */
	ARM64_SIM_A64_JMP(0x2ec, 0x408, arm64_l_408);
arm64_l_2f0:
	/* 0x2f0: cmp w25, #0x1a; 0x2f4: b.gt 380 <generic_usdt_process_event+0x380> */
arm64_l_2f4:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL, arm64_l_380);
arm64_l_2f8:
	/* 0x2f8: cmp w25, #0x16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 22ULL);
arm64_l_2fc:
	/* 0x2fc: b.eq 394 <generic_usdt_process_event+0x394> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2fc, 0x394, arm64_l_394);
arm64_l_300:
	/* 0x300: cmp w25, #0x17 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 23ULL);
arm64_l_304:
	/* 0x304: b.eq 3e8 <generic_usdt_process_event+0x3e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x304, 0x3e8, arm64_l_3e8);
arm64_l_308:
	/* 0x308: cmp w25, #0x1a */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_30c:
	/* 0x30c: b.eq 400 <generic_usdt_process_event+0x400> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x30c, 0x400, arm64_l_400);
arm64_l_310:
	/* 0x310: b 408 <generic_usdt_process_event+0x408> */
	ARM64_SIM_A64_JMP(0x310, 0x408, arm64_l_408);
arm64_l_314:
	/* 0x314: cmp w25, #0x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_318:
	/* 0x318: b.le 3b4 <generic_usdt_process_event+0x3b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x318, 0x3b4, arm64_l_3b4);
arm64_l_31c:
	/* 0x31c: cmp w25, #0x2a */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 42ULL);
arm64_l_320:
	/* 0x320: b.eq 40c <generic_usdt_process_event+0x40c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x320, 0x40c, arm64_l_40c);
arm64_l_324:
	/* 0x324: cmp w25, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_328:
	/* 0x328: b.eq 3c8 <generic_usdt_process_event+0x3c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x328, 0x3c8, arm64_l_3c8);
arm64_l_32c:
	/* 0x32c: cmp w25, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_330:
	/* 0x330: b.ne 408 <generic_usdt_process_event+0x408> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x330, 0x408, arm64_l_408);
arm64_l_334:
	/* 0x334: mov w24, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 112ULL);
arm64_l_338:
	/* 0x338: b 40c <generic_usdt_process_event+0x40c> */
	ARM64_SIM_A64_JMP(0x338, 0x40c, arm64_l_40c);
arm64_l_33c:
	/* 0x33c: cmp w25, #0x9; 0x340: b.gt 3e8 <generic_usdt_process_event+0x3e8> */
arm64_l_340:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL, arm64_l_3e8);
arm64_l_344:
	/* 0x344: cmp w25, #0x6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_348:
	/* 0x348: b.eq 40c <generic_usdt_process_event+0x40c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x348, 0x40c, arm64_l_40c);
arm64_l_34c:
	/* 0x34c: cmp w25, #0x7 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_350:
	/* 0x350: b.eq 3e0 <generic_usdt_process_event+0x3e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x350, 0x3e0, arm64_l_3e0);
arm64_l_354:
	/* 0x354: cmp w25, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_358:
	/* 0x358: b.eq 400 <generic_usdt_process_event+0x400> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x358, 0x400, arm64_l_400);
arm64_l_35c:
	/* 0x35c: b 408 <generic_usdt_process_event+0x408> */
	ARM64_SIM_A64_JMP(0x35c, 0x408, arm64_l_408);
arm64_l_360:
	/* 0x360: cmp w25, #0x13; 0x364: b.gt 39c <generic_usdt_process_event+0x39c> */
arm64_l_364:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 19ULL, arm64_l_39c);
arm64_l_368:
	/* 0x368: ldr x24, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_36c:
	/* 0x36c: cmp w25, #0x12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_370:
	/* 0x370: b.eq 40c <generic_usdt_process_event+0x40c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x370, 0x40c, arm64_l_40c);
arm64_l_374:
	/* 0x374: cmp w25, #0x13 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 19ULL);
arm64_l_378:
	/* 0x378: b.eq 3c8 <generic_usdt_process_event+0x3c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x378, 0x3c8, arm64_l_3c8);
arm64_l_37c:
	/* 0x37c: b 408 <generic_usdt_process_event+0x408> */
	ARM64_SIM_A64_JMP(0x37c, 0x408, arm64_l_408);
arm64_l_380:
	/* 0x380: sub w8, w25, #0x1d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 29ULL);
arm64_l_384:
	/* 0x384: cmp w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_388:
	/* 0x388: b.cs 3f8 <generic_usdt_process_event+0x3f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x388, 0x3f8, arm64_l_3f8);
arm64_l_38c:
	/* 0x38c: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_390:
	/* 0x390: b 40c <generic_usdt_process_event+0x40c> */
	ARM64_SIM_A64_JMP(0x390, 0x40c, arm64_l_40c);
arm64_l_394:
	/* 0x394: mov w24, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_398:
	/* 0x398: b 40c <generic_usdt_process_event+0x40c> */
	ARM64_SIM_A64_JMP(0x398, 0x40c, arm64_l_40c);
arm64_l_39c:
	/* 0x39c: cmp w25, #0x14 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_3a0:
	/* 0x3a0: b.eq 3f0 <generic_usdt_process_event+0x3f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3a0, 0x3f0, arm64_l_3f0);
arm64_l_3a4:
	/* 0x3a4: cmp w25, #0x15 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_3a8:
	/* 0x3a8: b.ne 408 <generic_usdt_process_event+0x408> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3a8, 0x408, arm64_l_408);
arm64_l_3ac:
	/* 0x3ac: mov w24, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 32ULL);
arm64_l_3b0:
	/* 0x3b0: b 40c <generic_usdt_process_event+0x40c> */
	ARM64_SIM_A64_JMP(0x3b0, 0x40c, arm64_l_40c);
arm64_l_3b4:
	/* 0x3b4: cmp w25, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_3b8:
	/* 0x3b8: b.eq 3c8 <generic_usdt_process_event+0x3c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3b8, 0x3c8, arm64_l_3c8);
arm64_l_3bc:
	/* 0x3bc: cmp w25, #0x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_3c0:
	/* 0x3c0: b.eq 3e0 <generic_usdt_process_event+0x3e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3c0, 0x3e0, arm64_l_3e0);
arm64_l_3c4:
	/* 0x3c4: b 408 <generic_usdt_process_event+0x408> */
	ARM64_SIM_A64_JMP(0x3c4, 0x408, arm64_l_408);
arm64_l_3c8:
	/* 0x3c8: mov w24, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_3cc:
	/* 0x3cc: b 40c <generic_usdt_process_event+0x40c> */
	ARM64_SIM_A64_JMP(0x3cc, 0x40c, arm64_l_40c);
arm64_l_3d0:
	/* 0x3d0: cmp w25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_3d4:
	/* 0x3d4: b.eq 3e8 <generic_usdt_process_event+0x3e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x3d4, 0x3e8, arm64_l_3e8);
arm64_l_3d8:
	/* 0x3d8: cmp w25, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_3dc:
	/* 0x3dc: b.ne 408 <generic_usdt_process_event+0x408> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3dc, 0x408, arm64_l_408);
arm64_l_3e0:
	/* 0x3e0: mov w24, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 64ULL);
arm64_l_3e4:
	/* 0x3e4: b 40c <generic_usdt_process_event+0x40c> */
	ARM64_SIM_A64_JMP(0x3e4, 0x40c, arm64_l_40c);
arm64_l_3e8:
	/* 0x3e8: mov w24, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_3ec:
	/* 0x3ec: b 40c <generic_usdt_process_event+0x40c> */
	ARM64_SIM_A64_JMP(0x3ec, 0x40c, arm64_l_40c);
arm64_l_3f0:
	/* 0x3f0: mov w24, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 152ULL);
arm64_l_3f4:
	/* 0x3f4: b 40c <generic_usdt_process_event+0x40c> */
	ARM64_SIM_A64_JMP(0x3f4, 0x40c, arm64_l_40c);
arm64_l_3f8:
	/* 0x3f8: cmp w25, #0x1b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_3fc:
	/* 0x3fc: b.ne 408 <generic_usdt_process_event+0x408> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x3fc, 0x408, arm64_l_408);
arm64_l_400:
	/* 0x400: mov w24, #0x50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 80ULL);
arm64_l_404:
	/* 0x404: b 40c <generic_usdt_process_event+0x40c> */
	ARM64_SIM_A64_JMP(0x404, 0x40c, arm64_l_40c);
arm64_l_408:
	/* 0x408: mov x24, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_40c:
	/* 0x40c: str wzr, [sp, #108] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 108ULL);
arm64_l_410:
	/* 0x410: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_414:
	/* 0x414: add x9, sp, #0x6c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 108ULL);
arm64_l_418:
	/* 0x418: add x1, sp, #0x6c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 108ULL);
arm64_l_41c:
	/* 0x41c: mov x0, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_420:
	/* 0x420: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x424ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_424:
	/* 0x424: cbz x0, 488 <generic_usdt_process_event+0x488> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x424, 0x488, arm64_l_488);
arm64_l_428:
	/* 0x428: ldr x9, [sp, #280] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 280ULL);
arm64_l_42c:
	/* 0x42c: mov w8, #0x3ffb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16379ULL);
arm64_l_430:
	/* 0x430: sub x8, x8, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_434:
	/* 0x434: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_438:
	/* 0x438: b.ls 488 <generic_usdt_process_event+0x488> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x438, 0x488, arm64_l_488);
arm64_l_43c:
	/* 0x43c: add x11, x0, x23, lsl #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 2), 0);
arm64_l_440:
	/* 0x440: mov w8, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_444:
	/* 0x444: ldr x24, [sp, #280] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 280ULL);
arm64_l_448:
	/* 0x448: add x12, x0, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_44c:
	/* 0x44c: ldr w9, [x11, x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X11, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X8, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_450:
	/* 0x450: add x10, x0, x23, lsl #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X10, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 3), 0);
arm64_l_454:
	/* 0x454: add x8, x24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_458:
	/* 0x458: str w9, [x12, x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X12, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X24, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_45c:
	/* 0x45c: str x8, [x10, #24184] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24184ULL);
arm64_l_460:
	/* 0x460: cbz w9, 54c <generic_usdt_process_event+0x54c> */
	ARM64_SIM_A64_CBZ_W(ARM64_X9, 0x460, 0x54c, arm64_l_54c);
arm64_l_464:
	/* 0x464: ldr x23, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_468:
	/* 0x468: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_46c:
	/* 0x46c: add w24, w8, w24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_470:
	/* 0x470: str w24, [x20, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_474:
	/* 0x474: adrp x22, 0 <usdt_calls> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&usdt_calls_16));
arm64_l_478:
	/* 0x478: cmp w23, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_47c:
	/* 0x47c: ldr x22, [x22] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_480:
	/* 0x480: b.le 4a4 <generic_usdt_process_event+0x4a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x480, 0x4a4, arm64_l_4a4);
arm64_l_484:
	/* 0x484: b 510 <generic_usdt_process_event+0x510> */
	ARM64_SIM_A64_JMP(0x484, 0x510, arm64_l_510);
arm64_l_488:
	/* 0x488: ldr x23, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_48c:
	/* 0x48c: ldr x24, [sp, #280] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 280ULL);
arm64_l_490:
	/* 0x490: str w24, [x20, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_494:
	/* 0x494: adrp x22, 0 <usdt_calls> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&usdt_calls_16));
arm64_l_498:
	/* 0x498: cmp w23, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_49c:
	/* 0x49c: ldr x22, [x22] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_4a0:
	/* 0x4a0: b.gt 510 <generic_usdt_process_event+0x510> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x4a0, 0x510, arm64_l_510);
arm64_l_4a4:
	/* 0x4a4: str wzr, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_4a8:
	/* 0x4a8: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_4ac:
	/* 0x4ac: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_4b0:
	/* 0x4b0: add x1, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_4b4:
	/* 0x4b4: mov x0, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_4b8:
	/* 0x4b8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x4bcULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_4bc:
	/* 0x4bc: cbz x0, 510 <generic_usdt_process_event+0x510> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x4bc, 0x510, arm64_l_510);
arm64_l_4c0:
	/* 0x4c0: mov w8, #0x5ef8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24312ULL);
arm64_l_4c4:
	/* 0x4c4: add x1, x0, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X1, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_4c8:
	/* 0x4c8: adrp x0, 0 <config_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&config_map_3));
arm64_l_4cc:
	/* 0x4cc: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_4d0:
	/* 0x4d0: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_4d4:
	/* 0x4d4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x4d8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_4d8:
	/* 0x4d8: cbz x0, 510 <generic_usdt_process_event+0x510> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x4d8, 0x510, arm64_l_510);
arm64_l_4dc:
	/* 0x4dc: add w8, w23, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_4e0:
	/* 0x4e0: and w9, w8, #0x7 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_4e4:
	/* 0x4e4: add x9, x0, w9, uxtw #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X9, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTW, 2), 0);
arm64_l_4e8:
	/* 0x4e8: ldr w9, [x9, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_4ec:
	/* 0x4ec: cmn w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_4f0:
	/* 0x4f0: b.eq 510 <generic_usdt_process_event+0x510> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x4f0, 0x510, arm64_l_510);
arm64_l_4f4:
	/* 0x4f4: str w8, [x20, x29] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X29, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_4f8:
	/* 0x4f8: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_4fc:
	/* 0x4fc: mov w9, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_500:
	/* 0x500: mov x0, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_504:
	/* 0x504: mov x1, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_508:
	/* 0x508: mov w2, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_50c:
	/* 0x50c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x510ULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_510:
	/* 0x510: str wzr, [x20, x29] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_XZR, ARM64_X29, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X29, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_514:
	/* 0x514: mov w8, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_518:
	/* 0x518: mov w9, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_51c:
	/* 0x51c: mov x0, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_520:
	/* 0x520: mov x1, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_524:
	/* 0x524: mov w2, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_528:
	/* 0x528: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 12ULL: ARM64_SIM_A64_LINK(0x52cULL); ARM64_SIM_BPF_CALL_bpf_tail_call(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_52c:
	/* 0x52c: ldp x20, x19, [sp, #336] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 336ULL);
arm64_l_530:
	/* 0x530: mov w0, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_534:
	/* 0x534: ldr x29, [sp, #272] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 272ULL);
arm64_l_538:
	/* 0x538: ldp x22, x21, [sp, #320] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 320ULL);
arm64_l_53c:
	/* 0x53c: ldp x24, x23, [sp, #304] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 304ULL);
arm64_l_540:
	/* 0x540: ldp x30, x25, [sp, #288] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 288ULL);
arm64_l_544:
	/* 0x544: add sp, sp, #0x160 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 352ULL);
arm64_l_548:
	/* 0x548: b 2fb8 <__native_link_arm64_ret_trampoline> */
	ARM64_SIM_A64_JMP(0x548, 0x2fb8, arm64_l_2fb8);
arm64_l_54c:
	/* 0x54c: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_550:
	/* 0x550: and x23, x8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_554:
	/* 0x554: cmp w25, #0x17 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 23ULL);
arm64_l_558:
	/* 0x558: str x22, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_55c:
	/* 0x55c: add x8, x12, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X12, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_560:
	/* 0x560: str x19, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_564:
	/* 0x564: str x12, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_568:
	/* 0x568: and x24, x9, #0xffffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967295ULL);
arm64_l_56c:
	/* 0x56c: stp x8, x11, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_570:
	/* 0x570: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_574:
	/* 0x574: str xzr, [x8, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_578:
	/* 0x578: b.le 5a4 <generic_usdt_process_event+0x5a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x578, 0x5a4, arm64_l_5a4);
arm64_l_57c:
	/* 0x57c: cmp w25, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_580:
	/* 0x580: b.eq 5c0 <generic_usdt_process_event+0x5c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x580, 0x5c0, arm64_l_5c0);
arm64_l_584:
	/* 0x584: cmp w25, #0x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 37ULL);
arm64_l_588:
	/* 0x588: b.eq 61c <generic_usdt_process_event+0x61c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x588, 0x61c, arm64_l_61c);
arm64_l_58c:
	/* 0x58c: cmp w25, #0x2a */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 42ULL);
arm64_l_590:
	/* 0x590: b.ne 9f4 <generic_usdt_process_event+0x9f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x590, 0x9f4, arm64_l_9f4);
arm64_l_594:
	/* 0x594: add x8, sp, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_598:
	/* 0x598: stp xzr, x22, [sp, #112] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 112ULL);
arm64_l_59c:
	/* 0x59c: str x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_5a0:
	/* 0x5a0: b 684 <generic_usdt_process_event+0x684> */
	ARM64_SIM_A64_JMP(0x5a0, 0x684, arm64_l_684);
arm64_l_5a4:
	/* 0x5a4: cmp w25, #0xf */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_5a8:
	/* 0x5a8: b.eq 654 <generic_usdt_process_event+0x654> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x5a8, 0x654, arm64_l_654);
arm64_l_5ac:
	/* 0x5ac: cmp w25, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_5b0:
	/* 0x5b0: b.ne 9f4 <generic_usdt_process_event+0x9f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x5b0, 0x9f4, arm64_l_9f4);
arm64_l_5b4:
	/* 0x5b4: add x23, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_5b8:
	/* 0x5b8: add x21, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_5bc:
	/* 0x5bc: b 5e8 <generic_usdt_process_event+0x5e8> */
	ARM64_SIM_A64_JMP(0x5bc, 0x5e8, arm64_l_5e8);
arm64_l_5c0:
	/* 0x5c0: add x23, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_5c4:
	/* 0x5c4: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_5c8:
	/* 0x5c8: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_5cc:
	/* 0x5cc: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_5d0:
	/* 0x5d0: add x0, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_5d4:
	/* 0x5d4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_5d8:
	/* 0x5d8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x5dcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_5dc:
	/* 0x5dc: add x21, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_5e0:
	/* 0x5e0: ldr x8, [x21, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_5e4:
	/* 0x5e4: str x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_5e8:
	/* 0x5e8: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_5ec:
	/* 0x5ec: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_5f0:
	/* 0x5f0: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_5f4:
	/* 0x5f4: add x0, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_5f8:
	/* 0x5f8: add x2, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_5fc:
	/* 0x5fc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_600:
	/* 0x600: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x604ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_604:
	/* 0x604: ldr x8, [x21, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_608:
	/* 0x608: adrp x21, 0 <process_call_heap> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_6));
arm64_l_60c:
	/* 0x60c: add x8, x8, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_610:
	/* 0x610: str x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_614:
	/* 0x614: ldr x21, [x21] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_618:
	/* 0x618: b 684 <generic_usdt_process_event+0x684> */
	ARM64_SIM_A64_JMP(0x618, 0x684, arm64_l_684);
arm64_l_61c:
	/* 0x61c: add x8, x22, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_620:
	/* 0x620: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_624:
	/* 0x624: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_628:
	/* 0x628: str x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_62c:
	/* 0x62c: add x11, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_630:
	/* 0x630: add x0, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_634:
	/* 0x634: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_638:
	/* 0x638: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_63c:
	/* 0x63c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x640ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_640:
	/* 0x640: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_644:
	/* 0x644: ldr x8, [x8, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_648:
	/* 0x648: add x8, x8, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_64c:
	/* 0x64c: str x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_650:
	/* 0x650: b 684 <generic_usdt_process_event+0x684> */
	ARM64_SIM_A64_JMP(0x650, 0x684, arm64_l_684);
arm64_l_654:
	/* 0x654: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_658:
	/* 0x658: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_65c:
	/* 0x65c: add x10, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_660:
	/* 0x660: add x11, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_664:
	/* 0x664: add x0, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_668:
	/* 0x668: add x2, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_66c:
	/* 0x66c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_670:
	/* 0x670: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x674ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_674:
	/* 0x674: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_678:
	/* 0x678: ldr x8, [x8, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_67c:
	/* 0x67c: str x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_680:
	/* 0x680: cbz x8, af0 <generic_usdt_process_event+0xaf0> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x680, 0xaf0, arm64_l_af0);
arm64_l_684:
	/* 0x684: str wzr, [sp, #132] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 132ULL);
arm64_l_688:
	/* 0x688: adrp x0, 0 <buffer_heap_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&buffer_heap_map_2));
arm64_l_68c:
	/* 0x68c: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_690:
	/* 0x690: add x9, sp, #0x84 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 132ULL);
arm64_l_694:
	/* 0x694: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_698:
	/* 0x698: add x1, sp, #0x84 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 132ULL);
arm64_l_69c:
	/* 0x69c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x6a0ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_6a0:
	/* 0x6a0: cbz x0, ae0 <generic_usdt_process_event+0xae0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x6a0, 0xae0, arm64_l_ae0);
arm64_l_6a4:
	/* 0x6a4: add x8, x0, #0x1, lsl #12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_6a8:
	/* 0x6a8: mov x24, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_6ac:
	/* 0x6ac: str x8, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_6b0:
	/* 0x6b0: mov w8, #0x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 35ULL);
arm64_l_6b4:
	/* 0x6b4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 35ULL: ARM64_SIM_A64_LINK(0x6b8ULL); ARM64_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_6b8:
	/* 0x6b8: add x2, x0, #0xb30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2864ULL);
arm64_l_6bc:
	/* 0x6bc: mov w25, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_6c0:
	/* 0x6c0: add x8, sp, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_6c4:
	/* 0x6c4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_6c8:
	/* 0x6c8: add x0, sp, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_6cc:
	/* 0x6cc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_6d0:
	/* 0x6d0: mov w29, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_6d4:
	/* 0x6d4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x6d8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_6d8:
	/* 0x6d8: ldr x8, [sp, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_6dc:
	/* 0x6dc: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_6e0:
	/* 0x6e0: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_6e4:
	/* 0x6e4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_6e8:
	/* 0x6e8: str x8, [sp, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_6ec:
	/* 0x6ec: add x8, x8, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_6f0:
	/* 0x6f0: str x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_6f4:
	/* 0x6f4: ldr x8, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_6f8:
	/* 0x6f8: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_6fc:
	/* 0x6fc: add x8, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_700:
	/* 0x700: str x2, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_704:
	/* 0x704: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x708ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_708:
	/* 0x708: ldr x23, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_70c:
	/* 0x70c: add x22, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_710:
	/* 0x710: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_714:
	/* 0x714: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_718:
	/* 0x718: add x2, x23, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_71c:
	/* 0x71c: blr x29 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X29);
		if (ARM64_SIM_L_REG_TAG(ARM64_X29) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x720ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_720:
	/* 0x720: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_724:
	/* 0x724: cbz x8, 734 <generic_usdt_process_event+0x734> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x724, 0x734, arm64_l_734);
arm64_l_728:
	/* 0x728: ldr x9, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_72c:
	/* 0x72c: mov w8, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_730:
	/* 0x730: b 77c <generic_usdt_process_event+0x77c> */
	ARM64_SIM_A64_JMP(0x730, 0x77c, arm64_l_77c);
arm64_l_734:
	/* 0x734: add x2, x23, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_738:
	/* 0x738: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_73c:
	/* 0x73c: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_740:
	/* 0x740: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_744:
	/* 0x744: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_748:
	/* 0x748: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_74c:
	/* 0x74c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x750ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_750:
	/* 0x750: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_754:
	/* 0x754: cmp x8, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_758:
	/* 0x758: b.eq 728 <generic_usdt_process_event+0x728> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x758, 0x728, arm64_l_728);
arm64_l_75c:
	/* 0x75c: mov w8, #0x2964 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10596ULL);
arm64_l_760:
	/* 0x760: add x9, x24, #0xff6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4086ULL);
arm64_l_764:
	/* 0x764: strh w8, [x24, #4094] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4094ULL);
arm64_l_768:
	/* 0x768: adrp x8, 10 <generic_usdt_process_event+0x10> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&arm64_section_Some_SectionIndex_14_addend_0_1));
arm64_l_76c:
	/* 0x76c: add x8, x8, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_770:
	/* 0x770: ldr x8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_774:
	/* 0x774: str x8, [x9] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_778:
	/* 0x778: mov w8, #0xff6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4086ULL);
arm64_l_77c:
	/* 0x77c: str x9, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_780:
	/* 0x780: str x9, [sp, #200] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_784:
	/* 0x784: ldr x9, [sp, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_788:
	/* 0x788: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_78c:
	/* 0x78c: mov w25, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_790:
	/* 0x790: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_794:
	/* 0x794: stp xzr, xzr, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_798:
	/* 0x798: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_79c:
	/* 0x79c: add x23, x22, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_7a0:
	/* 0x7a0: add x22, x10, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_7a4:
	/* 0x7a4: mov w29, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_7a8:
	/* 0x7a8: add x2, x9, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_7ac:
	/* 0x7ac: stp x24, xzr, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_7b0:
	/* 0x7b0: stp xzr, xzr, [sp, #184] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_7b4:
	/* 0x7b4: str w8, [sp, #208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_7b8:
	/* 0x7b8: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_7bc:
	/* 0x7bc: add x24, x10, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_7c0:
	/* 0x7c0: strb wzr, [sp, #212] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 212ULL);
arm64_l_7c4:
	/* 0x7c4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x7c8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_7c8:
	/* 0x7c8: ldr x2, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_7cc:
	/* 0x7cc: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_7d0:
	/* 0x7d0: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7d4:
	/* 0x7d4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_7d8:
	/* 0x7d8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x7dcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_7dc:
	/* 0x7dc: ldr x2, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_7e0:
	/* 0x7e0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_7e4:
	/* 0x7e4: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7e8:
	/* 0x7e8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_7ec:
	/* 0x7ec: str x22, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_7f0:
	/* 0x7f0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x7f4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_7f4:
	/* 0x7f4: ldr x2, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_7f8:
	/* 0x7f8: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_7fc:
	/* 0x7fc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_800:
	/* 0x800: blr x29 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X29);
		if (ARM64_SIM_L_REG_TAG(ARM64_X29) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x804ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_804:
	/* 0x804: ldr x8, [sp, #184] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_808:
	/* 0x808: sub x8, x8, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_80c:
	/* 0x80c: str x8, [sp, #192] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_810:
	/* 0x810: adrp x8, 0 <CONFIG_ITER_NUM> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&CONFIG_ITER_NUM_0));
arm64_l_814:
	/* 0x814: ldr x8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_818:
	/* 0x818: ldrb w8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_81c:
	/* 0x81c: cbz w8, 9cc <generic_usdt_process_event+0x9cc> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x81c, 0x9cc, arm64_l_9cc);
arm64_l_820:
	/* 0x820: mov w23, #0x800 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_824:
	/* 0x824: mov w10, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_828:
	/* 0x828: add x22, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_82c:
	/* 0x82c: ldp x29, x2, [sp, #176] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X29, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_830:
	/* 0x830: ldp x8, x9, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_834:
	/* 0x834: cmp x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_838:
	/* 0x838: ccmp x2, x9, #0x0, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CCMP_REG, ARM64_X2, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_CCMP(ARM64_COND_EQ, 0), 0);
arm64_l_83c:
	/* 0x83c: b.eq a90 <generic_usdt_process_event+0xa90> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x83c, 0xa90, arm64_l_a90);
arm64_l_840:
	/* 0x840: ldr x25, [sp, #192] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_844:
	/* 0x844: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_848:
	/* 0x848: add x9, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_84c:
	/* 0x84c: add x0, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_850:
	/* 0x850: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_854:
	/* 0x854: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x858ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_858:
	/* 0x858: ldr x8, [x22] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_85c:
	/* 0x85c: mov w19, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_860:
	/* 0x860: add x24, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_864:
	/* 0x864: cmp x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_868:
	/* 0x868: b.eq 968 <generic_usdt_process_event+0x968> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x868, 0x968, arm64_l_968);
arm64_l_86c:
	/* 0x86c: add x22, x29, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_870:
	/* 0x870: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_874:
	/* 0x874: add x9, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_878:
	/* 0x878: add x0, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_87c:
	/* 0x87c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_880:
	/* 0x880: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_884:
	/* 0x884: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x888ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_888:
	/* 0x888: ldr x8, [x24, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_88c:
	/* 0x88c: cmp x8, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_890:
	/* 0x890: b.eq 968 <generic_usdt_process_event+0x968> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x890, 0x968, arm64_l_968);
arm64_l_894:
	/* 0x894: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_898:
	/* 0x898: add x9, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_89c:
	/* 0x89c: add x0, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_8a0:
	/* 0x8a0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_8a4:
	/* 0x8a4: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_8a8:
	/* 0x8a8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x8acULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_8ac:
	/* 0x8ac: add x2, x29, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_8b0:
	/* 0x8b0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_8b4:
	/* 0x8b4: mov w9, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_8b8:
	/* 0x8b8: add x10, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_8bc:
	/* 0x8bc: add x0, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_8c0:
	/* 0x8c0: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_8c4:
	/* 0x8c4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x8c8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_8c8:
	/* 0x8c8: ldr w22, [sp, #244] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 244ULL);
arm64_l_8cc:
	/* 0x8cc: ldr x8, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_8d0:
	/* 0x8d0: ldr x10, [sp, #200] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_8d4:
	/* 0x8d4: sub x12, x10, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X12, ARM64_X10, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_8d8:
	/* 0x8d8: ldr w25, [sp, #208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_8dc:
	/* 0x8dc: subs w10, w22, w25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X10, ARM64_X22, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8e0:
	/* 0x8e0: ldr x9, [x24, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_8e4:
	/* 0x8e4: ldr x19, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_8e8:
	/* 0x8e8: csel w10, wzr, w10, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X10, ARM64_XZR, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_8ec:
	/* 0x8ec: cmp w25, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X25, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_8f0:
	/* 0x8f0: csel w11, w25, w22, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X11, ARM64_X25, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_CC, 0);
arm64_l_8f4:
	/* 0x8f4: cinc w13, w11, hi */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CINC, ARM64_X13, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_HI, 0);
arm64_l_8f8:
	/* 0x8f8: sub w14, w25, w13 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X14, ARM64_X25, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_8fc:
	/* 0x8fc: subs x12, x12, x13 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X12, ARM64_X12, ARM64_X13, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_900:
	/* 0x900: str w14, [sp, #208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X14, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_904:
	/* 0x904: b.cc a98 <generic_usdt_process_event+0xa98> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x904, 0xa98, arm64_l_a98);
arm64_l_908:
	/* 0x908: cmp x12, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_90c:
	/* 0x90c: b.hi a98 <generic_usdt_process_event+0xa98> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x90c, 0xa98, arm64_l_a98);
arm64_l_910:
	/* 0x910: cmp w25, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X25, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_914:
	/* 0x914: b.ls 920 <generic_usdt_process_event+0x920> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x914, 0x920, arm64_l_920);
arm64_l_918:
	/* 0x918: mov w13, #0x2f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 47ULL);
arm64_l_91c:
	/* 0x91c: strb w13, [x8, x12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X13, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_X12, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_920:
	/* 0x920: add x29, x8, x12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X29, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_924:
	/* 0x924: cmp w25, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X25, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_928:
	/* 0x928: add x2, x9, x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_92c:
	/* 0x92c: and w1, w11, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_930:
	/* 0x930: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_934:
	/* 0x934: cinc x0, x29, hi */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CINC, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_HI, 0);
arm64_l_938:
	/* 0x938: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x93cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_93c:
	/* 0x93c: cmp w25, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X25, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_940:
	/* 0x940: str x29, [sp, #200] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_944:
	/* 0x944: b.ls a98 <generic_usdt_process_event+0xa98> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x944, 0xa98, arm64_l_a98);
arm64_l_948:
	/* 0x948: add x22, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_94c:
	/* 0x94c: mov w29, #0x5efc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24316ULL);
arm64_l_950:
	/* 0x950: mov w10, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_954:
	/* 0x954: ldr x8, [x22, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_958:
	/* 0x958: str x8, [sp, #176] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 176ULL);
arm64_l_95c:
	/* 0x95c: subs w23, w23, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_IMM, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_960:
	/* 0x960: b.ne 82c <generic_usdt_process_event+0x82c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x960, 0x82c, arm64_l_82c);
arm64_l_964:
	/* 0x964: b a9c <generic_usdt_process_event+0xa9c> */
	ARM64_SIM_A64_JMP(0x964, 0xa9c, arm64_l_a9c);
arm64_l_968:
	/* 0x968: add x2, x25, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_96c:
	/* 0x96c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_970:
	/* 0x970: add x9, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_974:
	/* 0x974: add x0, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_978:
	/* 0x978: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_97c:
	/* 0x97c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x980ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_980:
	/* 0x980: ldr x8, [sp, #192] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 192ULL);
arm64_l_984:
	/* 0x984: ldr x9, [x24, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_988:
	/* 0x988: add x22, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_98c:
	/* 0x98c: cmp x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_990:
	/* 0x990: b.eq b58 <generic_usdt_process_event+0xb58> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x990, 0xb58, arm64_l_b58);
arm64_l_994:
	/* 0x994: ldr x0, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_998:
	/* 0x998: add x2, x25, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_99c:
	/* 0x99c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_9a0:
	/* 0x9a0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_9a4:
	/* 0x9a4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x9a8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_9a8:
	/* 0x9a8: ldr x8, [x22, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_9ac:
	/* 0x9ac: ldr x19, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_9b0:
	/* 0x9b0: mov w29, #0x5efc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24316ULL);
arm64_l_9b4:
	/* 0x9b4: mov w10, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_9b8:
	/* 0x9b8: add x9, x8, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_9bc:
	/* 0x9bc: stp x9, x8, [sp, #184] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 184ULL);
arm64_l_9c0:
	/* 0x9c0: subs w23, w23, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_IMM, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_9c4:
	/* 0x9c4: b.ne 82c <generic_usdt_process_event+0x82c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x9c4, 0x82c, arm64_l_82c);
arm64_l_9c8:
	/* 0x9c8: b a9c <generic_usdt_process_event+0xa9c> */
	ARM64_SIM_A64_JMP(0x9c8, 0xa9c, arm64_l_a9c);
arm64_l_9cc:
	/* 0x9cc: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_9d0:
	/* 0x9d0: adrp x1, 20 <generic_usdt_process_event+0x20> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_RODATA, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)__arm64_rodata_1));
arm64_l_9d4:
	/* 0x9d4: add x1, x1, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_9d8:
	/* 0x9d8: mov w8, #0x800 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_9dc:
	/* 0x9dc: mov w9, #0xb5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 181ULL);
arm64_l_9e0:
	/* 0x9e0: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_9e4:
	/* 0x9e4: add x2, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_9e8:
	/* 0x9e8: mov w0, #0x800 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2048ULL);
arm64_l_9ec:
	/* 0x9ec: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 181ULL: ARM64_SIM_A64_LINK(0x9f0ULL); ARM64_SIM_BPF_CALL_bpf_loop(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_9f0:
	/* 0x9f0: b a98 <generic_usdt_process_event+0xa98> */
	ARM64_SIM_A64_JMP(0x9f0, 0xa98, arm64_l_a98);
arm64_l_9f4:
	/* 0x9f4: cmp w25, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_9f8:
	/* 0x9f8: b.hi af0 <generic_usdt_process_event+0xaf0> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x9f8, 0xaf0, arm64_l_af0);
arm64_l_9fc:
	/* 0x9fc: mov x9, #0x7cf2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 31986ULL);
arm64_l_a00:
	/* 0xa00: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a04:
	/* 0xa04: movk x9, #0xf202, lsl #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(16), 61954ULL);
arm64_l_a08:
	/* 0xa08: lsl x8, x8, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X8, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_a0c:
	/* 0xa0c: movk x9, #0x11c1, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 4545ULL);
arm64_l_a10:
	/* 0xa10: tst x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_a14:
	/* 0xa14: b.eq af0 <generic_usdt_process_event+0xaf0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xa14, 0xaf0, arm64_l_af0);
arm64_l_a18:
	/* 0xa18: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_a1c:
	/* 0xa1c: str wzr, [sp, #224] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 224ULL);
arm64_l_a20:
	/* 0xa20: add x9, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_a24:
	/* 0xa24: add x1, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_a28:
	/* 0xa28: str x22, [x8, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_a2c:
	/* 0xa2c: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a30:
	/* 0xa30: mov x0, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a34:
	/* 0xa34: add x22, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_a38:
	/* 0xa38: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xa3cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_a3c:
	/* 0xa3c: mov x13, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a40:
	/* 0xa40: cbz x0, c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xa40, 0xc14, arm64_l_c14);
arm64_l_a44:
	/* 0xa44: ldr x11, [sp, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_a48:
	/* 0xa48: cmp w25, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_a4c:
	/* 0xa4c: b.le c5c <generic_usdt_process_event+0xc5c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xa4c, 0xc5c, arm64_l_c5c);
arm64_l_a50:
	/* 0xa50: cmp w25, #0x1e */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 30ULL);
arm64_l_a54:
	/* 0xa54: b.le d7c <generic_usdt_process_event+0xd7c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xa54, 0xd7c, arm64_l_d7c);
arm64_l_a58:
	/* 0xa58: cmp w25, #0x26; 0xa5c: b.gt e64 <generic_usdt_process_event+0xe64> */
arm64_l_a5c:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 38ULL, arm64_l_e64);
arm64_l_a60:
	/* 0xa60: ldr x22, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_a64:
	/* 0xa64: sub w8, w25, #0x1f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 31ULL);
arm64_l_a68:
	/* 0xa68: add x12, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X12, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_a6c:
	/* 0xa6c: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_a70:
	/* 0xa70: b.cs 12a8 <generic_usdt_process_event+0x12a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xa70, 0x12a8, arm64_l_12a8);
arm64_l_a74:
	/* 0xa74: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a78:
	/* 0xa78: add x9, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_a7c:
	/* 0xa7c: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_a80:
	/* 0xa80: add x2, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_a84:
	/* 0xa84: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_a88:
	/* 0xa88: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a8c:
	/* 0xa8c: b fb0 <generic_usdt_process_event+0xfb0> */
	ARM64_SIM_A64_JMP(0xa8c, 0xfb0, arm64_l_fb0);
arm64_l_a90:
	/* 0xa90: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_a94:
	/* 0xa94: strb w8, [sp, #212] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 212ULL);
arm64_l_a98:
	/* 0xa98: mov w29, #0x5efc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24316ULL);
arm64_l_a9c:
	/* 0xa9c: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_aa0:
	/* 0xaa0: ldr x2, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_aa4:
	/* 0xaa4: cmp x8, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_aa8:
	/* 0xaa8: b.eq b74 <generic_usdt_process_event+0xb74> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xaa8, 0xb74, arm64_l_b74);
arm64_l_aac:
	/* 0xaac: ldrb w9, [sp, #212] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 212ULL);
arm64_l_ab0:
	/* 0xab0: mov w11, #0x1000 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4096ULL);
arm64_l_ab4:
	/* 0xab4: cmp w9, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_ab8:
	/* 0xab8: ldr w9, [sp, #208] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 208ULL);
arm64_l_abc:
	/* 0xabc: cset w10, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSET, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_ac0:
	/* 0xac0: sub w11, w11, w9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X11, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_ac4:
	/* 0xac4: cmp w9, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_ac8:
	/* 0xac8: csel w9, w11, w9, gt */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X9, ARM64_X11, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_GT, 0);
arm64_l_acc:
	/* 0xacc: cbz x8, ae0 <generic_usdt_process_event+0xae0> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0xacc, 0xae0, arm64_l_ae0);
arm64_l_ad0:
	/* 0xad0: lsl w10, w10, #1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X10, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 1ULL);
arm64_l_ad4:
	/* 0xad4: mov x2, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ad8:
	/* 0xad8: str w10, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_adc:
	/* 0xadc: b b7c <generic_usdt_process_event+0xb7c> */
	ARM64_SIM_A64_JMP(0xadc, 0xb7c, arm64_l_b7c);
arm64_l_ae0:
	/* 0xae0: ldr x23, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_ae4:
	/* 0xae4: ldr x24, [sp, #280] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 280ULL);
arm64_l_ae8:
	/* 0xae8: mov x13, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_aec:
	/* 0xaec: b c28 <generic_usdt_process_event+0xc28> */
	ARM64_SIM_A64_JMP(0xaec, 0xc28, arm64_l_c28);
arm64_l_af0:
	/* 0xaf0: str wzr, [sp, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_af4:
	/* 0xaf4: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_af8:
	/* 0xaf8: add x9, sp, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_afc:
	/* 0xafc: add x1, sp, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_b00:
	/* 0xb00: mov x0, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b04:
	/* 0xb04: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0xb08ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_b08:
	/* 0xb08: mov x13, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_b0c:
	/* 0xb0c: cbz x0, c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0xb0c, 0xc14, arm64_l_c14);
arm64_l_b10:
	/* 0xb10: cmp w25, #0x19; 0xb14: b.gt e2c <generic_usdt_process_event+0xe2c> */
arm64_l_b14:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL, arm64_l_e2c);
arm64_l_b18:
	/* 0xb18: cmp w25, #0x12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_b1c:
	/* 0xb1c: b.le f3c <generic_usdt_process_event+0xf3c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xb1c, 0xf3c, arm64_l_f3c);
arm64_l_b20:
	/* 0xb20: cmp w25, #0x14 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_b24:
	/* 0xb24: b.le 11f8 <generic_usdt_process_event+0x11f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xb24, 0x11f8, arm64_l_11f8);
arm64_l_b28:
	/* 0xb28: cmp w25, #0x15 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 21ULL);
arm64_l_b2c:
	/* 0xb2c: b.eq 18ac <generic_usdt_process_event+0x18ac> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xb2c, 0x18ac, arm64_l_18ac);
arm64_l_b30:
	/* 0xb30: cmp w25, #0x16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 22ULL);
arm64_l_b34:
	/* 0xb34: b.eq 1850 <generic_usdt_process_event+0x1850> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xb34, 0x1850, arm64_l_1850);
arm64_l_b38:
	/* 0xb38: ldp x10, x11, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_b3c:
	/* 0xb3c: cmp w25, #0x17 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 23ULL);
arm64_l_b40:
	/* 0xb40: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_b44:
	/* 0xb44: b.ne c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xb44, 0xc1c, arm64_l_c1c);
arm64_l_b48:
	/* 0xb48: ldr x8, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_b4c:
	/* 0xb4c: mov w13, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_b50:
	/* 0xb50: stp w22, wzr, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X8, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b54:
	/* 0xb54: b c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JMP(0xb54, 0xc1c, arm64_l_c1c);
arm64_l_b58:
	/* 0xb58: ldp x2, x19, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X2, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_b5c:
	/* 0xb5c: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_b60:
	/* 0xb60: mov w29, #0x5efc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24316ULL);
arm64_l_b64:
	/* 0xb64: strb w8, [sp, #212] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 212ULL);
arm64_l_b68:
	/* 0xb68: ldr x8, [sp, #200] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 200ULL);
arm64_l_b6c:
	/* 0xb6c: cmp x8, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X8, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_b70:
	/* 0xb70: b.ne aac <generic_usdt_process_event+0xaac> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xb70, 0xaac, arm64_l_aac);
arm64_l_b74:
	/* 0xb74: str wzr, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_b78:
	/* 0xb78: mov w9, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X9, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_b7c:
	/* 0xb7c: ldr x23, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_b80:
	/* 0xb80: and w22, w9, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_b84:
	/* 0xb84: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_b88:
	/* 0xb88: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_b8c:
	/* 0xb8c: mov w1, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_b90:
	/* 0xb90: add x0, x23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_b94:
	/* 0xb94: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xb98ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_b98:
	/* 0xb98: str w22, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_b9c:
	/* 0xb9c: ldr x2, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_ba0:
	/* 0xba0: mov w25, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_ba4:
	/* 0xba4: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_ba8:
	/* 0xba8: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_bac:
	/* 0xbac: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_bb0:
	/* 0xbb0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_bb4:
	/* 0xbb4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xbb8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_bb8:
	/* 0xbb8: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_bbc:
	/* 0xbbc: add x9, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_bc0:
	/* 0xbc0: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_bc4:
	/* 0xbc4: add x0, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_bc8:
	/* 0xbc8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_bcc:
	/* 0xbcc: add x8, x8, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_bd0:
	/* 0xbd0: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_bd4:
	/* 0xbd4: add x2, x8, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_bd8:
	/* 0xbd8: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xbdcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_bdc:
	/* 0xbdc: add x11, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_be0:
	/* 0xbe0: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_be4:
	/* 0xbe4: add x10, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_be8:
	/* 0xbe8: ldr x8, [x11, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_bec:
	/* 0xbec: add x0, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_bf0:
	/* 0xbf0: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_bf4:
	/* 0xbf4: ldr x2, [x11, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_bf8:
	/* 0xbf8: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xbfcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_bfc:
	/* 0xbfc: ldr w9, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_c00:
	/* 0xc00: add x8, x23, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_c04:
	/* 0xc04: add w13, w22, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_c08:
	/* 0xc08: str w9, [x8, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_c0c:
	/* 0xc0c: ldrh w9, [sp, #256] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 256ULL);
arm64_l_c10:
	/* 0xc10: strh w9, [x8, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_c14:
	/* 0xc14: ldp x10, x11, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_c18:
	/* 0xc18: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_c1c:
	/* 0xc1c: ldr x23, [sp, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_c20:
	/* 0xc20: ldr x24, [sp, #280] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 280ULL);
arm64_l_c24:
	/* 0xc24: tbnz w13, #31, c4c <generic_usdt_process_event+0xc4c> */
	ARM64_SIM_A64_TBNZ(ARM64_X13, 31, 0xc24, 0xc4c, arm64_l_c4c);
arm64_l_c28:
	/* 0xc28: and w8, w13, #0x7fffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2147483647ULL);
arm64_l_c2c:
	/* 0xc2c: add w8, w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_c30:
	/* 0xc30: add w24, w8, w24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_c34:
	/* 0xc34: str w24, [x20, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_c38:
	/* 0xc38: adrp x22, 0 <usdt_calls> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&usdt_calls_16));
arm64_l_c3c:
	/* 0xc3c: cmp w23, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_c40:
	/* 0xc40: ldr x22, [x22] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c44:
	/* 0xc44: b.le 4a4 <generic_usdt_process_event+0x4a4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xc44, 0x4a4, arm64_l_4a4);
arm64_l_c48:
	/* 0xc48: b 510 <generic_usdt_process_event+0x510> */
	ARM64_SIM_A64_JMP(0xc48, 0x510, arm64_l_510);
arm64_l_c4c:
	/* 0xc4c: mov w8, #0xffffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967295ULL);
arm64_l_c50:
	/* 0xc50: str w8, [x10, x9] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X10, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X9, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c54:
	/* 0xc54: str w8, [x11, x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X11, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_X24, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c58:
	/* 0xc58: b 468 <generic_usdt_process_event+0x468> */
	ARM64_SIM_A64_JMP(0xc58, 0x468, arm64_l_468);
arm64_l_c5c:
	/* 0xc5c: ldr x10, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_c60:
	/* 0xc60: cmp w25, #0x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_c64:
	/* 0xc64: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_c68:
	/* 0xc68: b.gt dac <generic_usdt_process_event+0xdac> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0xc68, 0xdac, arm64_l_dac);
arm64_l_c6c:
	/* 0xc6c: ldr x22, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_c70:
	/* 0xc70: cmp w25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_c74:
	/* 0xc74: b.le fc0 <generic_usdt_process_event+0xfc0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xc74, 0xfc0, arm64_l_fc0);
arm64_l_c78:
	/* 0xc78: cmp w25, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_c7c:
	/* 0xc7c: b.eq 147c <generic_usdt_process_event+0x147c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xc7c, 0x147c, arm64_l_147c);
arm64_l_c80:
	/* 0xc80: cmp w25, #0x6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_c84:
	/* 0xc84: b.eq e0c <generic_usdt_process_event+0xe0c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xc84, 0xe0c, arm64_l_e0c);
arm64_l_c88:
	/* 0xc88: ldp x10, x11, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_c8c:
	/* 0xc8c: cmp w25, #0x7 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_c90:
	/* 0xc90: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_c94:
	/* 0xc94: b.ne c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xc94, 0xc1c, arm64_l_c1c);
arm64_l_c98:
	/* 0xc98: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_c9c:
	/* 0xc9c: mov x24, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ca0:
	/* 0xca0: add x0, x22, #0x26 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 38ULL);
arm64_l_ca4:
	/* 0xca4: ldr x23, [x8, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_ca8:
	/* 0xca8: mov w25, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_cac:
	/* 0xcac: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_cb0:
	/* 0xcb0: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_cb4:
	/* 0xcb4: mov x29, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X29, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_cb8:
	/* 0xcb8: str x23, [x22, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_cbc:
	/* 0xcbc: add x2, x23, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_cc0:
	/* 0xcc0: mov w22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_cc4:
	/* 0xcc4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xcc8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_cc8:
	/* 0xcc8: add x0, x29, #0x3a */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 58ULL);
arm64_l_ccc:
	/* 0xccc: add x2, x23, #0x12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_cd0:
	/* 0xcd0: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_cd4:
	/* 0xcd4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_cd8:
	/* 0xcd8: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_cdc:
	/* 0xcdc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xce0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_ce0:
	/* 0xce0: add x0, x29, #0x38 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_ce4:
	/* 0xce4: add x2, x23, #0x21e */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 542ULL);
arm64_l_ce8:
	/* 0xce8: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_cec:
	/* 0xcec: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_cf0:
	/* 0xcf0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xcf4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_cf4:
	/* 0xcf4: add x0, x29, #0x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 36ULL);
arm64_l_cf8:
	/* 0xcf8: add x2, x23, #0x21c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 540ULL);
arm64_l_cfc:
	/* 0xcfc: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_d00:
	/* 0xd00: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_d04:
	/* 0xd04: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xd08ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d08:
	/* 0xd08: add x0, x29, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_d0c:
	/* 0xd0c: add x2, x23, #0x214 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 532ULL);
arm64_l_d10:
	/* 0xd10: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_d14:
	/* 0xd14: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_d18:
	/* 0xd18: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xd1cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d1c:
	/* 0xd1c: add x0, x29, #0x34 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 52ULL);
arm64_l_d20:
	/* 0xd20: add x2, x23, #0x210 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 528ULL);
arm64_l_d24:
	/* 0xd24: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_d28:
	/* 0xd28: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xd2cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d2c:
	/* 0xd2c: ldrh w8, [x29, #38] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 38ULL);
arm64_l_d30:
	/* 0xd30: mov x22, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d34:
	/* 0xd34: stp xzr, xzr, [x29] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X29, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_d38:
	/* 0xd38: cmp w8, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_d3c:
	/* 0xd3c: str xzr, [x29, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_d40:
	/* 0xd40: str xzr, [x22, #16]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_d44:
	/* 0xd44: b.eq 1bcc <generic_usdt_process_event+0x1bcc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd44, 0x1bcc, arm64_l_1bcc);
arm64_l_d48:
	/* 0xd48: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_d4c:
	/* 0xd4c: b.ne 1bf8 <generic_usdt_process_event+0x1bf8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xd4c, 0x1bf8, arm64_l_1bf8);
arm64_l_d50:
	/* 0xd50: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_d54:
	/* 0xd54: add x2, x23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_d58:
	/* 0xd58: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_d5c:
	/* 0xd5c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_d60:
	/* 0xd60: mov w25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_d64:
	/* 0xd64: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xd68ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d68:
	/* 0xd68: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d6c:
	/* 0xd6c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_d70:
	/* 0xd70: mov x2, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_d74:
	/* 0xd74: blr x25 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X25);
		if (ARM64_SIM_L_REG_TAG(ARM64_X25) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xd78ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_d78:
	/* 0xd78: b 1bf8 <generic_usdt_process_event+0x1bf8> */
	ARM64_SIM_A64_JMP(0xd78, 0x1bf8, arm64_l_1bf8);
arm64_l_d7c:
	/* 0xd7c: cmp w25, #0x1c; 0xd80: b.gt f98 <generic_usdt_process_event+0xf98> */
arm64_l_d80:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 28ULL, arm64_l_f98);
arm64_l_d84:
	/* 0xd84: cmp w25, #0x11 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_d88:
	/* 0xd88: b.eq 12ec <generic_usdt_process_event+0x12ec> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd88, 0x12ec, arm64_l_12ec);
arm64_l_d8c:
	/* 0xd8c: cmp w25, #0x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 25ULL);
arm64_l_d90:
	/* 0xd90: str x0, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_d94:
	/* 0xd94: b.eq 13a0 <generic_usdt_process_event+0x13a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xd94, 0x13a0, arm64_l_13a0);
arm64_l_d98:
	/* 0xd98: ldp x22, x10, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_d9c:
	/* 0xd9c: cmp w25, #0x1c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_da0:
	/* 0xda0: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_da4:
	/* 0xda4: b.eq fd0 <generic_usdt_process_event+0xfd0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xda4, 0xfd0, arm64_l_fd0);
arm64_l_da8:
	/* 0xda8: b c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JMP(0xda8, 0xc1c, arm64_l_c1c);
arm64_l_dac:
	/* 0xdac: ldr x22, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_db0:
	/* 0xdb0: sub w8, w25, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_db4:
	/* 0xdb4: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_db8:
	/* 0xdb8: b.cc fd0 <generic_usdt_process_event+0xfd0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xdb8, 0xfd0, arm64_l_fd0);
arm64_l_dbc:
	/* 0xdbc: sub w8, w25, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_dc0:
	/* 0xdc0: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_dc4:
	/* 0xdc4: b.cc ff4 <generic_usdt_process_event+0xff4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0xdc4, 0xff4, arm64_l_ff4);
arm64_l_dc8:
	/* 0xdc8: cmp w25, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 14ULL);
arm64_l_dcc:
	/* 0xdcc: b.ne c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xdcc, 0xc1c, arm64_l_c1c);
arm64_l_dd0:
	/* 0xdd0: mov w22, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_dd4:
	/* 0xdd4: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_dd8:
	/* 0xdd8: add x24, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_ddc:
	/* 0xddc: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_de0:
	/* 0xde0: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_de4:
	/* 0xde4: add x2, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_de8:
	/* 0xde8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_dec:
	/* 0xdec: mov w23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_df0:
	/* 0xdf0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xdf4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_df4:
	/* 0xdf4: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_df8:
	/* 0xdf8: add x0, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_dfc:
	/* 0xdfc: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_e00:
	/* 0xe00: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_e04:
	/* 0xe04: blr x23 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X23);
		if (ARM64_SIM_L_REG_TAG(ARM64_X23) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xe08ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_e08:
	/* 0xe08: ldr x22, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_e0c:
	/* 0xe0c: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_e10:
	/* 0xe10: add x0, x22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_e14:
	/* 0xe14: mov w9, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_e18:
	/* 0xe18: ldr x2, [x8, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_e1c:
	/* 0xe1c: mov w8, #0x1001 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4097ULL);
arm64_l_e20:
	/* 0xe20: mov w1, #0x1001 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4097ULL);
arm64_l_e24:
	/* 0xe24: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0xe28ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_e28:
	/* 0xe28: b 12d4 <generic_usdt_process_event+0x12d4> */
	ARM64_SIM_A64_JMP(0xe28, 0x12d4, arm64_l_12d4);
arm64_l_e2c:
	/* 0xe2c: cmp w25, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_e30:
	/* 0xe30: b.le 112c <generic_usdt_process_event+0x112c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xe30, 0x112c, arm64_l_112c);
arm64_l_e34:
	/* 0xe34: ldr x9, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_e38:
	/* 0xe38: sub w8, w25, #0x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 33ULL);
arm64_l_e3c:
	/* 0xe3c: cmp w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_e40:
	/* 0xe40: b.cs 1014 <generic_usdt_process_event+0x1014> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0xe40, 0x1014, arm64_l_1014);
arm64_l_e44:
	/* 0xe44: mov w10, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_e48:
	/* 0xe48: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_e4c:
	/* 0xe4c: mov x0, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e50:
	/* 0xe50: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_e54:
	/* 0xe54: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_e58:
	/* 0xe58: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xe5cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_e5c:
	/* 0xe5c: mov w13, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_e60:
	/* 0xe60: b c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_JMP(0xe60, 0xc14, arm64_l_c14);
arm64_l_e64:
	/* 0xe64: ldr x23, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_e68:
	/* 0xe68: cmp w25, #0x27 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 39ULL);
arm64_l_e6c:
	/* 0xe6c: b.eq 15d4 <generic_usdt_process_event+0x15d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe6c, 0x15d4, arm64_l_15d4);
arm64_l_e70:
	/* 0xe70: cmp w25, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_e74:
	/* 0xe74: b.eq 1608 <generic_usdt_process_event+0x1608> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xe74, 0x1608, arm64_l_1608);
arm64_l_e78:
	/* 0xe78: ldr x10, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_e7c:
	/* 0xe7c: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_e80:
	/* 0xe80: cmp w25, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_e84:
	/* 0xe84: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_e88:
	/* 0xe88: b.ne c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xe88, 0xc1c, arm64_l_c1c);
arm64_l_e8c:
	/* 0xe8c: ldr x22, [x8, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_e90:
	/* 0xe90: strb wzr, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_e94:
	/* 0xe94: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_e98:
	/* 0xe98: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_e9c:
	/* 0xe9c: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ea0:
	/* 0xea0: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_ea4:
	/* 0xea4: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ea8:
	/* 0xea8: stp xzr, xzr, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X23, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_eac:
	/* 0xeac: stp xzr, xzr, [x23, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X23, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_eb0:
	/* 0xeb0: stp xzr, xzr, [x23, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X23, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_eb4:
	/* 0xeb4: stp xzr, xzr, [x23, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X23, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_eb8:
	/* 0xeb8: stp xzr, xzr, [x23, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X23, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_ebc:
	/* 0xebc: stp xzr, xzr, [x23, #80] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X23, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 80ULL);
arm64_l_ec0:
	/* 0xec0: stp xzr, xzr, [x23, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X23, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_ec4:
	/* 0xec4: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xec8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_ec8:
	/* 0xec8: tbnz x0, #63, 1e04 <generic_usdt_process_event+0x1e04> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0xec8, 0x1e04, arm64_l_1e04);
arm64_l_ecc:
	/* 0xecc: add x23, x22, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_ed0:
	/* 0xed0: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ed4:
	/* 0xed4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_ed8:
	/* 0xed8: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_edc:
	/* 0xedc: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_ee0:
	/* 0xee0: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_ee4:
	/* 0xee4: mov x2, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_ee8:
	/* 0xee8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xeecULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_eec:
	/* 0xeec: tbnz x0, #63, 1e04 <generic_usdt_process_event+0x1e04> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0xeec, 0x1e04, arm64_l_1e04);
arm64_l_ef0:
	/* 0xef0: ldrb w8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_ef4:
	/* 0xef4: ldr x10, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_ef8:
	/* 0xef8: cmp w8, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_efc:
	/* 0xefc: add x0, x10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_f00:
	/* 0xf00: cset w9, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSET, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_f04:
	/* 0xf04: strb w9, [x10, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X10, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_f08:
	/* 0xf08: cbz w8, 1dd4 <generic_usdt_process_event+0x1dd4> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0xf08, 0x1dd4, arm64_l_1dd4);
arm64_l_f0c:
	/* 0xf0c: mov w8, #0x6c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 108ULL);
arm64_l_f10:
	/* 0xf10: mov w9, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_f14:
	/* 0xf14: mov w1, #0x6c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 108ULL);
arm64_l_f18:
	/* 0xf18: mov x2, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f1c:
	/* 0xf1c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0xf20ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_f20:
	/* 0xf20: adrp x21, 0 <process_call_heap> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_6));
arm64_l_f24:
	/* 0xf24: mov w29, #0x5efc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24316ULL);
arm64_l_f28:
	/* 0xf28: ldr x21, [x21] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_f2c:
	/* 0xf2c: ldr x19, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_f30:
	/* 0xf30: tbnz w0, #31, 1e04 <generic_usdt_process_event+0x1e04> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0xf30, 0x1e04, arm64_l_1e04);
arm64_l_f34:
	/* 0xf34: sub w22, w0, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_f38:
	/* 0xf38: b 1dfc <generic_usdt_process_event+0x1dfc> */
	ARM64_SIM_A64_JMP(0xf38, 0x1dfc, arm64_l_1dfc);
arm64_l_f3c:
	/* 0xf3c: cmp w25, #0x7; 0xf40: b.gt 11a8 <generic_usdt_process_event+0x11a8> */
arm64_l_f40:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL, arm64_l_11a8);
arm64_l_f44:
	/* 0xf44: cmp w25, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_f48:
	/* 0xf48: b.eq 167c <generic_usdt_process_event+0x167c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf48, 0x167c, arm64_l_167c);
arm64_l_f4c:
	/* 0xf4c: ldp x10, x11, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_f50:
	/* 0xf50: cmp w25, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_f54:
	/* 0xf54: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_f58:
	/* 0xf58: b.ne c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xf58, 0xc1c, arm64_l_c1c);
arm64_l_f5c:
	/* 0xf5c: mov x12, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X12, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f60:
	/* 0xf60: add x29, x0, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X29, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_f64:
	/* 0xf64: mov x24, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_f68:
	/* 0xf68: and w8, w12, #0xf */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_f6c:
	/* 0xf6c: add x21, x29, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X21, ARM64_X29, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_f70:
	/* 0xf70: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_f74:
	/* 0xf74: b.le 1d44 <generic_usdt_process_event+0x1d44> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0xf74, 0x1d44, arm64_l_1d44);
arm64_l_f78:
	/* 0xf78: cmp w8, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_f7c:
	/* 0xf7c: b.eq 1ed8 <generic_usdt_process_event+0x1ed8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf7c, 0x1ed8, arm64_l_1ed8);
arm64_l_f80:
	/* 0xf80: cmp w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_f84:
	/* 0xf84: b.eq 1ee0 <generic_usdt_process_event+0x1ee0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xf84, 0x1ee0, arm64_l_1ee0);
arm64_l_f88:
	/* 0xf88: cmp w8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_f8c:
	/* 0xf8c: b.ne 1f30 <generic_usdt_process_event+0x1f30> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xf8c, 0x1f30, arm64_l_1f30);
arm64_l_f90:
	/* 0xf90: mov w8, #0x5e70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24176ULL);
arm64_l_f94:
	/* 0xf94: b 1eec <generic_usdt_process_event+0x1eec> */
	ARM64_SIM_A64_JMP(0xf94, 0x1eec, arm64_l_1eec);
arm64_l_f98:
	/* 0xf98: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_f9c:
	/* 0xf9c: add x9, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_fa0:
	/* 0xfa0: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_fa4:
	/* 0xfa4: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_fa8:
	/* 0xfa8: add x2, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_fac:
	/* 0xfac: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_fb0:
	/* 0xfb0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xfb4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_fb4:
	/* 0xfb4: ldp x10, x11, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_fb8:
	/* 0xfb8: mov w13, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_fbc:
	/* 0xfbc: b c18 <generic_usdt_process_event+0xc18> */
	ARM64_SIM_A64_JMP(0xfbc, 0xc18, arm64_l_c18);
arm64_l_fc0:
	/* 0xfc0: cmp w25, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_fc4:
	/* 0xfc4: b.eq ff4 <generic_usdt_process_event+0xff4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0xfc4, 0xff4, arm64_l_ff4);
arm64_l_fc8:
	/* 0xfc8: cmp w25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_fcc:
	/* 0xfcc: b.ne c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0xfcc, 0xc1c, arm64_l_c1c);
arm64_l_fd0:
	/* 0xfd0: mov w10, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_fd4:
	/* 0xfd4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_fd8:
	/* 0xfd8: add x9, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_fdc:
	/* 0xfdc: add x2, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_fe0:
	/* 0xfe0: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_fe4:
	/* 0xfe4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_fe8:
	/* 0xfe8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0xfecULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_fec:
	/* 0xfec: mov w13, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_ff0:
	/* 0xff0: b c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_JMP(0xff0, 0xc14, arm64_l_c14);
arm64_l_ff4:
	/* 0xff4: add x8, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_ff8:
	/* 0xff8: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_ffc:
	/* 0xffc: add x2, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1000:
	/* 0x1000: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1004:
	/* 0x1004: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1008:
	/* 0x1008: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x100cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_100c:
	/* 0x100c: mov w13, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1010:
	/* 0x1010: b c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_JMP(0x1010, 0xc14, arm64_l_c14);
arm64_l_1014:
	/* 0x1014: cmp w25, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_1018:
	/* 0x1018: b.eq 196c <generic_usdt_process_event+0x196c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1018, 0x196c, arm64_l_196c);
arm64_l_101c:
	/* 0x101c: ldp x10, x11, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1020:
	/* 0x1020: cmp w25, #0x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 41ULL);
arm64_l_1024:
	/* 0x1024: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1028:
	/* 0x1028: b.ne c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1028, 0xc1c, arm64_l_c1c);
arm64_l_102c:
	/* 0x102c: add x2, x22, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1030:
	/* 0x1030: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1034:
	/* 0x1034: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1038:
	/* 0x1038: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_103c:
	/* 0x103c: mov x24, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1040:
	/* 0x1040: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1044:
	/* 0x1044: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1048:
	/* 0x1048: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x104cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_104c:
	/* 0x104c: ldr x23, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1050:
	/* 0x1050: cbz x23, 1e94 <generic_usdt_process_event+0x1e94> */
	ARM64_SIM_A64_CBZ(ARM64_X23, 0x1050, 0x1e94, arm64_l_1e94);
arm64_l_1054:
	/* 0x1054: ldr x29, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1058:
	/* 0x1058: add x2, x23, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_105c:
	/* 0x105c: mov w25, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1060:
	/* 0x1060: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1064:
	/* 0x1064: str x23, [x29, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1068:
	/* 0x1068: add x0, x29, #0x26 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 38ULL);
arm64_l_106c:
	/* 0x106c: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1070:
	/* 0x1070: mov w22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1074:
	/* 0x1074: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1078ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1078:
	/* 0x1078: add x0, x29, #0x3a */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 58ULL);
arm64_l_107c:
	/* 0x107c: add x2, x23, #0x12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_1080:
	/* 0x1080: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1084:
	/* 0x1084: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1088:
	/* 0x1088: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_108c:
	/* 0x108c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1090ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1090:
	/* 0x1090: add x0, x29, #0x38 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_1094:
	/* 0x1094: add x2, x23, #0x21e */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 542ULL);
arm64_l_1098:
	/* 0x1098: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_109c:
	/* 0x109c: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_10a0:
	/* 0x10a0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x10a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_10a4:
	/* 0x10a4: add x0, x29, #0x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 36ULL);
arm64_l_10a8:
	/* 0x10a8: add x2, x23, #0x21c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 540ULL);
arm64_l_10ac:
	/* 0x10ac: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_10b0:
	/* 0x10b0: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_10b4:
	/* 0x10b4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x10b8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_10b8:
	/* 0x10b8: add x0, x29, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_10bc:
	/* 0x10bc: add x2, x23, #0x214 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 532ULL);
arm64_l_10c0:
	/* 0x10c0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_10c4:
	/* 0x10c4: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_10c8:
	/* 0x10c8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x10ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_10cc:
	/* 0x10cc: add x0, x29, #0x34 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 52ULL);
arm64_l_10d0:
	/* 0x10d0: add x2, x23, #0x210 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 528ULL);
arm64_l_10d4:
	/* 0x10d4: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_10d8:
	/* 0x10d8: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x10dcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_10dc:
	/* 0x10dc: ldrh w8, [x29, #38] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 38ULL);
arm64_l_10e0:
	/* 0x10e0: mov x22, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10e4:
	/* 0x10e4: stp xzr, xzr, [x29] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X29, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_10e8:
	/* 0x10e8: cmp w8, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_10ec:
	/* 0x10ec: str xzr, [x29, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_10f0:
	/* 0x10f0: str xzr, [x22, #16]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_10f4:
	/* 0x10f4: b.eq 1e24 <generic_usdt_process_event+0x1e24> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x10f4, 0x1e24, arm64_l_1e24);
arm64_l_10f8:
	/* 0x10f8: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_10fc:
	/* 0x10fc: b.ne 1e50 <generic_usdt_process_event+0x1e50> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x10fc, 0x1e50, arm64_l_1e50);
arm64_l_1100:
	/* 0x1100: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1104:
	/* 0x1104: add x2, x23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1108:
	/* 0x1108: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_110c:
	/* 0x110c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1110:
	/* 0x1110: mov w25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1114:
	/* 0x1114: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1118ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1118:
	/* 0x1118: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_111c:
	/* 0x111c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1120:
	/* 0x1120: mov x2, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1124:
	/* 0x1124: blr x25 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X25);
		if (ARM64_SIM_L_REG_TAG(ARM64_X25) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1128ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1128:
	/* 0x1128: b 1e50 <generic_usdt_process_event+0x1e50> */
	ARM64_SIM_A64_JMP(0x1128, 0x1e50, arm64_l_1e50);
arm64_l_112c:
	/* 0x112c: cmp w25, #0x1a */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 26ULL);
arm64_l_1130:
	/* 0x1130: b.eq 19f8 <generic_usdt_process_event+0x19f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1130, 0x19f8, arm64_l_19f8);
arm64_l_1134:
	/* 0x1134: ldp x10, x11, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1138:
	/* 0x1138: cmp w25, #0x1b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 27ULL);
arm64_l_113c:
	/* 0x113c: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1140:
	/* 0x1140: b.ne c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1140, 0xc1c, arm64_l_c1c);
arm64_l_1144:
	/* 0x1144: mov x23, x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1148:
	/* 0x1148: ldr x10, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_114c:
	/* 0x114c: add x2, x22, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1150:
	/* 0x1150: mov w8, #0x3f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 63ULL);
arm64_l_1154:
	/* 0x1154: stp xzr, xzr, [x10, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X10, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1158:
	/* 0x1158: mov x0, x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_115c:
	/* 0x115c: stp xzr, xzr, [x10, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X10, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1160:
	/* 0x1160: stp xzr, xzr, [x10, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X10, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1164:
	/* 0x1164: str xzr, [x10, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X10, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1168:
	/* 0x1168: stp xzr, xzr, [x10] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X10, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_116c:
	/* 0x116c: mov w9, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_1170:
	/* 0x1170: mov w1, #0x3f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 63ULL);
arm64_l_1174:
	/* 0x1174: mov x24, x11 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1178:
	/* 0x1178: str xzr, [x0, #16]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_117c:
	/* 0x117c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0x1180ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1180:
	/* 0x1180: tbnz x0, #63, 1dbc <generic_usdt_process_event+0x1dbc> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x1180, 0x1dbc, arm64_l_1dbc);
arm64_l_1184:
	/* 0x1184: ldr x8, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1188:
	/* 0x1188: add x2, x22, #0x360 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 864ULL);
arm64_l_118c:
	/* 0x118c: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1190:
	/* 0x1190: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1194:
	/* 0x1194: add x0, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1198:
	/* 0x1198: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_119c:
	/* 0x119c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x11a0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_11a0:
	/* 0x11a0: mov w13, #0x50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 80ULL);
arm64_l_11a4:
	/* 0x11a4: b 1dc0 <generic_usdt_process_event+0x1dc0> */
	ARM64_SIM_A64_JMP(0x11a4, 0x1dc0, arm64_l_1dc0);
arm64_l_11a8:
	/* 0x11a8: cmp w25, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_11ac:
	/* 0x11ac: b.eq 16d0 <generic_usdt_process_event+0x16d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x11ac, 0x16d0, arm64_l_16d0);
arm64_l_11b0:
	/* 0x11b0: ldp x10, x11, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_11b4:
	/* 0x11b4: cmp w25, #0x12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 18ULL);
arm64_l_11b8:
	/* 0x11b8: mov w29, #0x5efc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24316ULL);
arm64_l_11bc:
	/* 0x11bc: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_11c0:
	/* 0x11c0: b.ne c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x11c0, 0xc1c, arm64_l_c1c);
arm64_l_11c4:
	/* 0x11c4: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_11c8:
	/* 0x11c8: and x24, x24, #0x3ff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 1023ULL);
arm64_l_11cc:
	/* 0x11cc: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_11d0:
	/* 0x11d0: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11d4:
	/* 0x11d4: mov x22, x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11d8:
	/* 0x11d8: mov x23, x11 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11dc:
	/* 0x11dc: mov w1, w24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_11e0:
	/* 0x11e0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x11e4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_11e4:
	/* 0x11e4: mov x13, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11e8:
	/* 0x11e8: mov x11, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11ec:
	/* 0x11ec: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_11f0:
	/* 0x11f0: mov x10, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_11f4:
	/* 0x11f4: b c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JMP(0x11f4, 0xc1c, arm64_l_c1c);
arm64_l_11f8:
	/* 0x11f8: cmp w25, #0x13 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 19ULL);
arm64_l_11fc:
	/* 0x11fc: b.eq 1920 <generic_usdt_process_event+0x1920> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x11fc, 0x1920, arm64_l_1920);
arm64_l_1200:
	/* 0x1200: ldp x10, x11, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1204:
	/* 0x1204: cmp w25, #0x14 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_1208:
	/* 0x1208: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_120c:
	/* 0x120c: b.ne c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x120c, 0xc1c, arm64_l_c1c);
arm64_l_1210:
	/* 0x1210: str xzr, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1214:
	/* 0x1214: add x2, x22, #0x110 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 272ULL);
arm64_l_1218:
	/* 0x1218: mov w12, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_121c:
	/* 0x121c: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1220:
	/* 0x1220: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1224:
	/* 0x1224: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1228:
	/* 0x1228: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_122c:
	/* 0x122c: add x23, x22, #0xd8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 216ULL);
arm64_l_1230:
	/* 0x1230: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1234:
	/* 0x1234: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1238ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1238:
	/* 0x1238: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_123c:
	/* 0x123c: mov w9, #0x80 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 128ULL);
arm64_l_1240:
	/* 0x1240: mov w10, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_1244:
	/* 0x1244: ldr x25, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1248:
	/* 0x1248: mov w1, #0x80 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 128ULL);
arm64_l_124c:
	/* 0x124c: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1250:
	/* 0x1250: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1254:
	/* 0x1254: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0x1258ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1258:
	/* 0x1258: add x0, x25, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_125c:
	/* 0x125c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1260:
	/* 0x1260: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1264:
	/* 0x1264: mov x2, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1268:
	/* 0x1268: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x126cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_126c:
	/* 0x126c: add x0, x25, #0x80 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_1270:
	/* 0x1270: add x2, x22, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_1274:
	/* 0x1274: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1278:
	/* 0x1278: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_127c:
	/* 0x127c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1280:
	/* 0x1280: mov w23, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1284:
	/* 0x1284: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1288ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1288:
	/* 0x1288: add x0, x25, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_128c:
	/* 0x128c: add x2, x22, #0x118 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 280ULL);
arm64_l_1290:
	/* 0x1290: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1294:
	/* 0x1294: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1298ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1298:
	/* 0x1298: ldp x10, x11, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_129c:
	/* 0x129c: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_12a0:
	/* 0x12a0: mov w13, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 152ULL);
arm64_l_12a4:
	/* 0x12a4: b c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JMP(0x12a4, 0xc1c, arm64_l_c1c);
arm64_l_12a8:
	/* 0x12a8: ldr x10, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_12ac:
	/* 0x12ac: cmp w25, #0x26 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 38ULL);
arm64_l_12b0:
	/* 0x12b0: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_12b4:
	/* 0x12b4: b.ne c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x12b4, 0xc1c, arm64_l_c1c);
arm64_l_12b8:
	/* 0x12b8: ldr x8, [x12, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X12, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_12bc:
	/* 0x12bc: add x0, x22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_12c0:
	/* 0x12c0: add x2, x19, w8, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X19, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_12c4:
	/* 0x12c4: ubfx w8, w8, #16, #12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_BITFIELD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_BITFIELD(ARM64_BITFIELD_UBFX, 16, 12), 0);
arm64_l_12c8:
	/* 0x12c8: add w1, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_12cc:
	/* 0x12cc: mov w8, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_12d0:
	/* 0x12d0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0x12d4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_12d4:
	/* 0x12d4: mov x13, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_12d8:
	/* 0x12d8: tbnz x0, #63, c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x12d8, 0xc14, arm64_l_c14);
arm64_l_12dc:
	/* 0x12dc: sub w8, w13, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_12e0:
	/* 0x12e0: add x13, x13, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_12e4:
	/* 0x12e4: str w8, [x22] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_12e8:
	/* 0x12e8: b c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_JMP(0x12e8, 0xc14, arm64_l_c14);
arm64_l_12ec:
	/* 0x12ec: str xzr, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_12f0:
	/* 0x12f0: mov w8, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_12f4:
	/* 0x12f4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x12f8ULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_12f8:
	/* 0x12f8: lsr x8, x0, #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 32ULL);
arm64_l_12fc:
	/* 0x12fc: add x9, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1300:
	/* 0x1300: add x10, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1304:
	/* 0x1304: str x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1308:
	/* 0x1308: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_130c:
	/* 0x130c: add x0, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1310:
	/* 0x1310: add x2, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_1314:
	/* 0x1314: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1318:
	/* 0x1318: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x131cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_131c:
	/* 0x131c: ldr w8, [sp, #240] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 240ULL);
arm64_l_1320:
	/* 0x1320: adrp x0, 0 <fdinstall_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&fdinstall_map_5));
arm64_l_1324:
	/* 0x1324: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1328:
	/* 0x1328: add x1, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_132c:
	/* 0x132c: str w8, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_1330:
	/* 0x1330: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1334:
	/* 0x1334: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1338:
	/* 0x1338: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x133cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_133c:
	/* 0x133c: cbz x0, 1ad4 <generic_usdt_process_event+0x1ad4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x133c, 0x1ad4, arm64_l_1ad4);
arm64_l_1340:
	/* 0x1340: ldr x25, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1344:
	/* 0x1344: ldr w23, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1348:
	/* 0x1348: add x8, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_134c:
	/* 0x134c: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1350:
	/* 0x1350: add x2, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1354:
	/* 0x1354: mov x22, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1358:
	/* 0x1358: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_135c:
	/* 0x135c: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1360:
	/* 0x1360: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1364:
	/* 0x1364: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1368ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1368:
	/* 0x1368: and x23, x23, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_136c:
	/* 0x136c: add x0, x25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1370:
	/* 0x1370: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1374:
	/* 0x1374: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1378:
	/* 0x1378: add x1, x23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_137c:
	/* 0x137c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1380ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1380:
	/* 0x1380: add w23, w23, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1384:
	/* 0x1384: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1388:
	/* 0x1388: add x8, x23, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_138c:
	/* 0x138c: add x0, x25, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X25, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1390:
	/* 0x1390: sub x2, x8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1394:
	/* 0x1394: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1398ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1398:
	/* 0x1398: add x13, x23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_139c:
	/* 0x139c: b 2b6c <generic_usdt_process_event+0x2b6c> */
	ARM64_SIM_A64_JMP(0x139c, 0x2b6c, arm64_l_2b6c);
arm64_l_13a0:
	/* 0x13a0: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_13a4:
	/* 0x13a4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_13a8:
	/* 0x13a8: add x10, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_13ac:
	/* 0x13ac: ldr x22, [x8, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_13b0:
	/* 0x13b0: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_13b4:
	/* 0x13b4: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_13b8:
	/* 0x13b8: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_13bc:
	/* 0x13bc: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_13c0:
	/* 0x13c0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x13c4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_13c4:
	/* 0x13c4: ldrb w8, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_13c8:
	/* 0x13c8: cbz w8, 1adc <generic_usdt_process_event+0x1adc> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x13c8, 0x1adc, arm64_l_1adc);
arm64_l_13cc:
	/* 0x13cc: cmp w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_13d0:
	/* 0x13d0: b.ne 1c84 <generic_usdt_process_event+0x1c84> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x13d0, 0x1c84, arm64_l_1c84);
arm64_l_13d4:
	/* 0x13d4: add x2, x22, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_13d8:
	/* 0x13d8: mov w25, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_13dc:
	/* 0x13dc: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_13e0:
	/* 0x13e0: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_13e4:
	/* 0x13e4: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_13e8:
	/* 0x13e8: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_13ec:
	/* 0x13ec: mov w22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_13f0:
	/* 0x13f0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x13f4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_13f4:
	/* 0x13f4: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_13f8:
	/* 0x13f8: add x8, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_13fc:
	/* 0x13fc: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1400:
	/* 0x1400: add x0, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1404:
	/* 0x1404: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1408:
	/* 0x1408: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x140cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_140c:
	/* 0x140c: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1410:
	/* 0x1410: add x0, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_1414:
	/* 0x1414: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1418:
	/* 0x1418: add x2, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_141c:
	/* 0x141c: add x8, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_1420:
	/* 0x1420: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1424ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1424:
	/* 0x1424: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_1428:
	/* 0x1428: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_142c:
	/* 0x142c: ldr x2, [x8, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1430:
	/* 0x1430: ldr x22, [x8, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1434:
	/* 0x1434: ldr x8, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1438:
	/* 0x1438: add x8, x8, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_143c:
	/* 0x143c: add x23, x8, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1440:
	/* 0x1440: tbz w9, #5, 1464 <generic_usdt_process_event+0x1464> */
	ARM64_SIM_A64_TBZ(ARM64_X9, 5, 0x1440, 0x1464, arm64_l_1464);
arm64_l_1444:
	/* 0x1444: cmp x22, #0x1, lsl #12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_1448:
	/* 0x1448: b.cs 1b34 <generic_usdt_process_event+0x1b34> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x1448, 0x1b34, arm64_l_1b34);
arm64_l_144c:
	/* 0x144c: ldr x9, [sp, #280] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 280ULL);
arm64_l_1450:
	/* 0x1450: str wzr, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1454:
	/* 0x1454: mov w25, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_1458:
	/* 0x1458: add w9, w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_145c:
	/* 0x145c: and x9, x9, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_1460:
	/* 0x1460: add x23, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1464:
	/* 0x1464: cmp x22, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_1468:
	/* 0x1468: mov w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4095ULL);
arm64_l_146c:
	/* 0x146c: add x0, x23, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1470:
	/* 0x1470: csel x24, x22, x8, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X24, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_1474:
	/* 0x1474: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1478:
	/* 0x1478: b 2028 <generic_usdt_process_event+0x2028> */
	ARM64_SIM_A64_JMP(0x1478, 0x2028, arm64_l_2028);
arm64_l_147c:
	/* 0x147c: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_1480:
	/* 0x1480: add x0, x22, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_1484:
	/* 0x1484: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1488:
	/* 0x1488: ldr x25, [x8, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_148c:
	/* 0x148c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1490:
	/* 0x1490: mov w23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1494:
	/* 0x1494: add x2, x25, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1498:
	/* 0x1498: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x149cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_149c:
	/* 0x149c: add x0, x22, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_14a0:
	/* 0x14a0: add x2, x25, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 112ULL);
arm64_l_14a4:
	/* 0x14a4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14a8:
	/* 0x14a8: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14ac:
	/* 0x14ac: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x14b0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_14b0:
	/* 0x14b0: add x0, x22, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_14b4:
	/* 0x14b4: add x2, x25, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_14b8:
	/* 0x14b8: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14bc:
	/* 0x14bc: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14c0:
	/* 0x14c0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x14c4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_14c4:
	/* 0x14c4: add x0, x22, #0x34 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 52ULL);
arm64_l_14c8:
	/* 0x14c8: add x2, x25, #0xa8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 168ULL);
arm64_l_14cc:
	/* 0x14cc: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14d0:
	/* 0x14d0: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14d4:
	/* 0x14d4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x14d8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_14d8:
	/* 0x14d8: str xzr, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_14dc:
	/* 0x14dc: add x2, x25, #0xc8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_14e0:
	/* 0x14e0: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_14e4:
	/* 0x14e4: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_14e8:
	/* 0x14e8: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_14ec:
	/* 0x14ec: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_14f0:
	/* 0x14f0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_14f4:
	/* 0x14f4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x14f8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_14f8:
	/* 0x14f8: add x2, x25, #0xb8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 184ULL);
arm64_l_14fc:
	/* 0x14fc: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1500:
	/* 0x1500: add x9, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1504:
	/* 0x1504: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1508:
	/* 0x1508: add x0, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_150c:
	/* 0x150c: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1510:
	/* 0x1510: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1514ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1514:
	/* 0x1514: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1518:
	/* 0x1518: ldrh w9, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_151c:
	/* 0x151c: add x0, sp, #0xdc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 220ULL);
arm64_l_1520:
	/* 0x1520: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1524:
	/* 0x1524: add x22, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1528:
	/* 0x1528: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_152c:
	/* 0x152c: add x9, sp, #0xdc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 220ULL);
arm64_l_1530:
	/* 0x1530: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1534:
	/* 0x1534: blr x23 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X23);
		if (ARM64_SIM_L_REG_TAG(ARM64_X23) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1538ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1538:
	/* 0x1538: ldrb w8, [sp, #220] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 220ULL);
arm64_l_153c:
	/* 0x153c: lsr w8, w8, #4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 4ULL);
arm64_l_1540:
	/* 0x1540: cmp w8, #0x6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1544:
	/* 0x1544: b.eq 1b44 <generic_usdt_process_event+0x1b44> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1544, 0x1b44, arm64_l_1b44);
arm64_l_1548:
	/* 0x1548: cmp w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_154c:
	/* 0x154c: b.ne 2b68 <generic_usdt_process_event+0x2b68> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x154c, 0x2b68, arm64_l_2b68);
arm64_l_1550:
	/* 0x1550: add x2, x22, #0x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 9ULL);
arm64_l_1554:
	/* 0x1554: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1558:
	/* 0x1558: add x9, sp, #0x84 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 132ULL);
arm64_l_155c:
	/* 0x155c: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1560:
	/* 0x1560: add x0, sp, #0x84 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 132ULL);
arm64_l_1564:
	/* 0x1564: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1568:
	/* 0x1568: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_156c:
	/* 0x156c: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1570ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1570:
	/* 0x1570: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1574:
	/* 0x1574: ldrb w8, [sp, #132] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 132ULL);
arm64_l_1578:
	/* 0x1578: mov w29, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_157c:
	/* 0x157c: add x2, x22, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1580:
	/* 0x1580: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1584:
	/* 0x1584: mov x23, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1588:
	/* 0x1588: strh w8, [x0, #36] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_158c:
	/* 0x158c: strh w29, [x0, #38] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 38ULL);
arm64_l_1590:
	/* 0x1590: stp xzr, xzr, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X0, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1594:
	/* 0x1594: str xzr, [x0, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1598:
	/* 0x1598: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_159c:
	/* 0x159c: str xzr, [x23, #16]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_15a0:
	/* 0x15a0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x15a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_15a4:
	/* 0x15a4: add x2, x22, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_15a8:
	/* 0x15a8: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_15ac:
	/* 0x15ac: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_15b0:
	/* 0x15b0: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_15b4:
	/* 0x15b4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x15b8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_15b8:
	/* 0x15b8: add x2, x25, #0xb6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 182ULL);
arm64_l_15bc:
	/* 0x15bc: add x8, sp, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_15c0:
	/* 0x15c0: add x0, sp, #0x88 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 136ULL);
arm64_l_15c4:
	/* 0x15c4: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_15c8:
	/* 0x15c8: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x15ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_15cc:
	/* 0x15cc: ldrb w22, [sp, #132] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 132ULL);
arm64_l_15d0:
	/* 0x15d0: b 2a2c <generic_usdt_process_event+0x2a2c> */
	ARM64_SIM_A64_JMP(0x15d0, 0x2a2c, arm64_l_2a2c);
arm64_l_15d4:
	/* 0x15d4: ldr x8, [x22, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_15d8:
	/* 0x15d8: add x0, x23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_15dc:
	/* 0x15dc: mov w9, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_15e0:
	/* 0x15e0: mov w1, #0x11 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 17ULL);
arm64_l_15e4:
	/* 0x15e4: add x2, x8, #0x118 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 280ULL);
arm64_l_15e8:
	/* 0x15e8: mov w8, #0x11 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 17ULL);
arm64_l_15ec:
	/* 0x15ec: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0x15f0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_15f0:
	/* 0x15f0: mov x13, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_15f4:
	/* 0x15f4: tbnz x0, #63, c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x15f4, 0xc14, arm64_l_c14);
arm64_l_15f8:
	/* 0x15f8: sub w8, w13, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_15fc:
	/* 0x15fc: add x13, x13, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1600:
	/* 0x1600: str w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1604:
	/* 0x1604: b c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_JMP(0x1604, 0xc14, arm64_l_c14);
arm64_l_1608:
	/* 0x1608: ldr x22, [x22, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_160c:
	/* 0x160c: stp xzr, xzr, [x23, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X23, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1610:
	/* 0x1610: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1614:
	/* 0x1614: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1618:
	/* 0x1618: mov x0, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_161c:
	/* 0x161c: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1620:
	/* 0x1620: str xzr, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1624:
	/* 0x1624: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1628:
	/* 0x1628: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x162cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_162c:
	/* 0x162c: tbnz x0, #63, 1db4 <generic_usdt_process_event+0x1db4> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x162c, 0x1db4, arm64_l_1db4);
arm64_l_1630:
	/* 0x1630: ldrh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1634:
	/* 0x1634: cmp w8, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 10ULL);
arm64_l_1638:
	/* 0x1638: b.eq 1d5c <generic_usdt_process_event+0x1d5c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1638, 0x1d5c, arm64_l_1d5c);
arm64_l_163c:
	/* 0x163c: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1640:
	/* 0x1640: b.ne 1d90 <generic_usdt_process_event+0x1d90> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1640, 0x1d90, arm64_l_1d90);
arm64_l_1644:
	/* 0x1644: add x2, x22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1648:
	/* 0x1648: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_164c:
	/* 0x164c: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1650:
	/* 0x1650: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1654:
	/* 0x1654: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1658:
	/* 0x1658: mov w23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_165c:
	/* 0x165c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1660ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1660:
	/* 0x1660: ldr w8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1664:
	/* 0x1664: ldr x9, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1668:
	/* 0x1668: add x2, x22, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_166c:
	/* 0x166c: add x0, x9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1670:
	/* 0x1670: str x8, [x9, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1674:
	/* 0x1674: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1678:
	/* 0x1678: b 1d88 <generic_usdt_process_event+0x1d88> */
	ARM64_SIM_A64_JMP(0x1678, 0x1d88, arm64_l_1d88);
arm64_l_167c:
	/* 0x167c: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_1680:
	/* 0x1680: add x25, x0, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1684:
	/* 0x1684: mov x24, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1688:
	/* 0x1688: str xzr, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_168c:
	/* 0x168c: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_1690:
	/* 0x1690: add x23, x25, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X25, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1694:
	/* 0x1694: tbnz w8, #4, 1c98 <generic_usdt_process_event+0x1c98> */
	ARM64_SIM_A64_TBNZ(ARM64_X8, 4, 0x1694, 0x1c98, arm64_l_1c98);
arm64_l_1698:
	/* 0x1698: ldr x9, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_169c:
	/* 0x169c: mov x8, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_16a0:
	/* 0x16a0: and x19, x9, #0xffffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X19, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 4294967295ULL);
arm64_l_16a4:
	/* 0x16a4: and w9, w9, #0xf */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 15ULL);
arm64_l_16a8:
	/* 0x16a8: cmp w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_16ac:
	/* 0x16ac: b.le 1e0c <generic_usdt_process_event+0x1e0c> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x16ac, 0x1e0c, arm64_l_1e0c);
arm64_l_16b0:
	/* 0x16b0: cmp w9, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_16b4:
	/* 0x16b4: b.eq 20dc <generic_usdt_process_event+0x20dc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x16b4, 0x20dc, arm64_l_20dc);
arm64_l_16b8:
	/* 0x16b8: cmp w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_16bc:
	/* 0x16bc: b.eq 20e4 <generic_usdt_process_event+0x20e4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x16bc, 0x20e4, arm64_l_20e4);
arm64_l_16c0:
	/* 0x16c0: cmp w9, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_16c4:
	/* 0x16c4: b.ne 20f8 <generic_usdt_process_event+0x20f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x16c4, 0x20f8, arm64_l_20f8);
arm64_l_16c8:
	/* 0x16c8: mov w8, #0x5e70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24176ULL);
arm64_l_16cc:
	/* 0x16cc: b 20f0 <generic_usdt_process_event+0x20f0> */
	ARM64_SIM_A64_JMP(0x16cc, 0x20f0, arm64_l_20f0);
arm64_l_16d0:
	/* 0x16d0: ldr x24, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_16d4:
	/* 0x16d4: add x2, x22, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_16d8:
	/* 0x16d8: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_16dc:
	/* 0x16dc: mov w23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_16e0:
	/* 0x16e0: add x8, x24, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_16e4:
	/* 0x16e4: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_16e8:
	/* 0x16e8: add x25, x24, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X25, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_16ec:
	/* 0x16ec: str x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_16f0:
	/* 0x16f0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_16f4:
	/* 0x16f4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x16f8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_16f8:
	/* 0x16f8: add x0, x24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_16fc:
	/* 0x16fc: add x2, x22, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1700:
	/* 0x1700: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1704:
	/* 0x1704: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1708:
	/* 0x1708: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x170cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_170c:
	/* 0x170c: add x0, x24, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1710:
	/* 0x1710: add x2, x22, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1714:
	/* 0x1714: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1718:
	/* 0x1718: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_171c:
	/* 0x171c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1720ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1720:
	/* 0x1720: add x0, x24, #0x14 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_1724:
	/* 0x1724: add x2, x22, #0x1c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_1728:
	/* 0x1728: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_172c:
	/* 0x172c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1730:
	/* 0x1730: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1734ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1734:
	/* 0x1734: add x0, x24, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1738:
	/* 0x1738: add x2, x22, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_173c:
	/* 0x173c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1740:
	/* 0x1740: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1744:
	/* 0x1744: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1748ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1748:
	/* 0x1748: add x0, x24, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_174c:
	/* 0x174c: add x2, x22, #0x14 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 20ULL);
arm64_l_1750:
	/* 0x1750: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1754:
	/* 0x1754: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1758:
	/* 0x1758: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x175cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_175c:
	/* 0x175c: add x0, x24, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1760:
	/* 0x1760: add x2, x22, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_1764:
	/* 0x1764: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1768:
	/* 0x1768: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_176c:
	/* 0x176c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1770ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1770:
	/* 0x1770: add x0, x24, #0x1c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 28ULL);
arm64_l_1774:
	/* 0x1774: add x2, x22, #0x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 36ULL);
arm64_l_1778:
	/* 0x1778: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_177c:
	/* 0x177c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1780:
	/* 0x1780: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1784ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1784:
	/* 0x1784: str wzr, [x24, #36] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1788:
	/* 0x1788: add x0, x24, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_178c:
	/* 0x178c: add x2, x22, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 40ULL);
arm64_l_1790:
	/* 0x1790: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1794:
	/* 0x1794: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1798:
	/* 0x1798: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x179cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_179c:
	/* 0x179c: add x0, x24, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_17a0:
	/* 0x17a0: add x2, x22, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_17a4:
	/* 0x17a4: mov w29, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_17a8:
	/* 0x17a8: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_17ac:
	/* 0x17ac: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_17b0:
	/* 0x17b0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x17b4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_17b4:
	/* 0x17b4: add x0, x24, #0x38 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_17b8:
	/* 0x17b8: add x2, x22, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_17bc:
	/* 0x17bc: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_17c0:
	/* 0x17c0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_17c4:
	/* 0x17c4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x17c8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_17c8:
	/* 0x17c8: add x2, x22, #0x38 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_17cc:
	/* 0x17cc: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_17d0:
	/* 0x17d0: mov x0, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_17d4:
	/* 0x17d4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_17d8:
	/* 0x17d8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x17dcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_17dc:
	/* 0x17dc: add x2, x22, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_17e0:
	/* 0x17e0: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_17e4:
	/* 0x17e4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_17e8:
	/* 0x17e8: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_17ec:
	/* 0x17ec: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_17f0:
	/* 0x17f0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x17f4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_17f4:
	/* 0x17f4: ldr x22, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_17f8:
	/* 0x17f8: ldr x0, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_17fc:
	/* 0x17fc: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1800:
	/* 0x1800: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1804:
	/* 0x1804: add x2, x22, #0xc8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_1808:
	/* 0x1808: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x180cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_180c:
	/* 0x180c: add x0, x24, #0x44 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 68ULL);
arm64_l_1810:
	/* 0x1810: add x2, x22, #0xcc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 204ULL);
arm64_l_1814:
	/* 0x1814: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1818:
	/* 0x1818: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_181c:
	/* 0x181c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1820ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1820:
	/* 0x1820: add x0, x24, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1824:
	/* 0x1824: add x2, x22, #0xd0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 208ULL);
arm64_l_1828:
	/* 0x1828: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_182c:
	/* 0x182c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1830:
	/* 0x1830: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1834ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1834:
	/* 0x1834: add x0, x24, #0x4c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 76ULL);
arm64_l_1838:
	/* 0x1838: add x2, x22, #0x158 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_183c:
	/* 0x183c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1840:
	/* 0x1840: blr x23 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X23);
		if (ARM64_SIM_L_REG_TAG(ARM64_X23) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1844ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1844:
	/* 0x1844: mov w13, #0x50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 80ULL);
arm64_l_1848:
	/* 0x1848: mov w29, #0x5efc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24316ULL);
arm64_l_184c:
	/* 0x184c: b c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_JMP(0x184c, 0xc14, arm64_l_c14);
arm64_l_1850:
	/* 0x1850: ldr x24, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1854:
	/* 0x1854: add x2, x22, #0xc8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 200ULL);
arm64_l_1858:
	/* 0x1858: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_185c:
	/* 0x185c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1860:
	/* 0x1860: mov w23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1864:
	/* 0x1864: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1868:
	/* 0x1868: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x186cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_186c:
	/* 0x186c: add x0, x24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1870:
	/* 0x1870: add x2, x22, #0xcc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 204ULL);
arm64_l_1874:
	/* 0x1874: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1878:
	/* 0x1878: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_187c:
	/* 0x187c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1880ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1880:
	/* 0x1880: add x0, x24, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1884:
	/* 0x1884: add x2, x22, #0xd0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 208ULL);
arm64_l_1888:
	/* 0x1888: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_188c:
	/* 0x188c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1890:
	/* 0x1890: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1894ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1894:
	/* 0x1894: add x0, x24, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1898:
	/* 0x1898: add x2, x22, #0x158 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 344ULL);
arm64_l_189c:
	/* 0x189c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18a0:
	/* 0x18a0: blr x23 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X23);
		if (ARM64_SIM_L_REG_TAG(ARM64_X23) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x18a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_18a4:
	/* 0x18a4: mov w13, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_18a8:
	/* 0x18a8: b c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_JMP(0x18a8, 0xc14, arm64_l_c14);
arm64_l_18ac:
	/* 0x18ac: ldr x24, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_18b0:
	/* 0x18b0: add x2, x22, #0x38 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_18b4:
	/* 0x18b4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18b8:
	/* 0x18b8: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18bc:
	/* 0x18bc: mov w23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18c0:
	/* 0x18c0: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_18c4:
	/* 0x18c4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x18c8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_18c8:
	/* 0x18c8: add x0, x24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_18cc:
	/* 0x18cc: add x2, x22, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_18d0:
	/* 0x18d0: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18d4:
	/* 0x18d4: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18d8:
	/* 0x18d8: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x18dcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_18dc:
	/* 0x18dc: add x0, x24, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_18e0:
	/* 0x18e0: add x2, x22, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_18e4:
	/* 0x18e4: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18e8:
	/* 0x18e8: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18ec:
	/* 0x18ec: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x18f0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_18f0:
	/* 0x18f0: add x0, x24, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_18f4:
	/* 0x18f4: add x2, x22, #0x44 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 68ULL);
arm64_l_18f8:
	/* 0x18f8: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_18fc:
	/* 0x18fc: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1900:
	/* 0x1900: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1904ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1904:
	/* 0x1904: add x0, x24, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1908:
	/* 0x1908: add x2, x22, #0x80 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 128ULL);
arm64_l_190c:
	/* 0x190c: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1910:
	/* 0x1910: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1914:
	/* 0x1914: blr x23 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X23);
		if (ARM64_SIM_L_REG_TAG(ARM64_X23) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1918ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1918:
	/* 0x1918: mov w13, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 32ULL);
arm64_l_191c:
	/* 0x191c: b c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_JMP(0x191c, 0xc14, arm64_l_c14);
arm64_l_1920:
	/* 0x1920: ldr x24, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1924:
	/* 0x1924: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1928:
	/* 0x1928: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_192c:
	/* 0x192c: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1930:
	/* 0x1930: mov w23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1934:
	/* 0x1934: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1938:
	/* 0x1938: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x193cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_193c:
	/* 0x193c: add x0, x24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1940:
	/* 0x1940: add x2, x22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1944:
	/* 0x1944: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1948:
	/* 0x1948: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_194c:
	/* 0x194c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1950ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1950:
	/* 0x1950: add x0, x24, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1954:
	/* 0x1954: add x2, x22, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_1958:
	/* 0x1958: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_195c:
	/* 0x195c: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1960:
	/* 0x1960: blr x23 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X23);
		if (ARM64_SIM_L_REG_TAG(ARM64_X23) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1964ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1964:
	/* 0x1964: mov w13, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_1968:
	/* 0x1968: b c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_JMP(0x1968, 0xc14, arm64_l_c14);
arm64_l_196c:
	/* 0x196c: add x2, x22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_1970:
	/* 0x1970: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1974:
	/* 0x1974: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1978:
	/* 0x1978: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_197c:
	/* 0x197c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1980:
	/* 0x1980: mov w23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1984:
	/* 0x1984: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1988ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1988:
	/* 0x1988: ldr w8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_198c:
	/* 0x198c: ldr x24, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1990:
	/* 0x1990: add x2, x22, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1994:
	/* 0x1994: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1998:
	/* 0x1998: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_199c:
	/* 0x199c: str w8, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_19a0:
	/* 0x19a0: add x8, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_19a4:
	/* 0x19a4: blr x23 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X23);
		if (ARM64_SIM_L_REG_TAG(ARM64_X23) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x19a8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_19a8:
	/* 0x19a8: ldr w8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_19ac:
	/* 0x19ac: add x2, x22, #0x50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 80ULL);
arm64_l_19b0:
	/* 0x19b0: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_19b4:
	/* 0x19b4: mov w10, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_19b8:
	/* 0x19b8: str w8, [x24, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_19bc:
	/* 0x19bc: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_19c0:
	/* 0x19c0: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_19c4:
	/* 0x19c4: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_19c8:
	/* 0x19c8: mov w22, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_19cc:
	/* 0x19cc: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0x19d0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_19d0:
	/* 0x19d0: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_19d4:
	/* 0x19d4: add x0, x24, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_19d8:
	/* 0x19d8: mov w9, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_19dc:
	/* 0x19dc: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_19e0:
	/* 0x19e0: add x8, x8, #0x3f8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1016ULL);
arm64_l_19e4:
	/* 0x19e4: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_19e8:
	/* 0x19e8: add x2, x8, #0x3f8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1016ULL);
arm64_l_19ec:
	/* 0x19ec: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0x19f0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_19f0:
	/* 0x19f0: mov w13, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_19f4:
	/* 0x19f4: b c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_JMP(0x19f4, 0xc14, arm64_l_c14);
arm64_l_19f8:
	/* 0x19f8: ldr x11, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_19fc:
	/* 0x19fc: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1a00:
	/* 0x1a00: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1a04:
	/* 0x1a04: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1a08:
	/* 0x1a08: stp xzr, xzr, [x11, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X11, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1a0c:
	/* 0x1a0c: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1a10:
	/* 0x1a10: stp xzr, xzr, [x11, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X11, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_1a14:
	/* 0x1a14: stp xzr, xzr, [x11, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X11, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1a18:
	/* 0x1a18: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1a1c:
	/* 0x1a1c: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a20:
	/* 0x1a20: stp xzr, xzr, [x11, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X11, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1a24:
	/* 0x1a24: stp xzr, xzr, [x11] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X11, ARM64_XZR, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1a28:
	/* 0x1a28: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1a2cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1a2c:
	/* 0x1a2c: mov x13, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1a30:
	/* 0x1a30: cbnz x0, 2b6c <generic_usdt_process_event+0x2b6c> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x1a30, 0x2b6c, arm64_l_2b6c);
arm64_l_1a34:
	/* 0x1a34: ldr x8, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1a38:
	/* 0x1a38: mov w9, #0x3f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 63ULL);
arm64_l_1a3c:
	/* 0x1a3c: mov w10, #0x2d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 45ULL);
arm64_l_1a40:
	/* 0x1a40: mov w1, #0x3f */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 63ULL);
arm64_l_1a44:
	/* 0x1a44: add x0, x8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1a48:
	/* 0x1a48: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1a4c:
	/* 0x1a4c: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1a50:
	/* 0x1a50: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 45ULL: ARM64_SIM_A64_LINK(0x1a54ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1a54:
	/* 0x1a54: tbnz x0, #63, 2050 <generic_usdt_process_event+0x2050> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x1a54, 0x2050, arm64_l_2050);
arm64_l_1a58:
	/* 0x1a58: add x2, x22, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1a5c:
	/* 0x1a5c: mov w23, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1a60:
	/* 0x1a60: add x8, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1a64:
	/* 0x1a64: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1a68:
	/* 0x1a68: add x0, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1a6c:
	/* 0x1a6c: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1a70:
	/* 0x1a70: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1a74:
	/* 0x1a74: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1a78ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1a78:
	/* 0x1a78: ldr x8, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1a7c:
	/* 0x1a7c: add x10, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_1a80:
	/* 0x1a80: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1a84:
	/* 0x1a84: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1a88:
	/* 0x1a88: add x0, x8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1a8c:
	/* 0x1a8c: ldr x8, [x10, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1a90:
	/* 0x1a90: add x8, x8, #0x360 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 864ULL);
arm64_l_1a94:
	/* 0x1a94: ldr x8, [x10, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1a98:
	/* 0x1a98: add x2, x8, #0x360 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 864ULL);
arm64_l_1a9c:
	/* 0x1a9c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1aa0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1aa0:
	/* 0x1aa0: add x2, x22, #0x58 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 88ULL);
arm64_l_1aa4:
	/* 0x1aa4: add x8, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1aa8:
	/* 0x1aa8: add x0, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1aac:
	/* 0x1aac: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1ab0:
	/* 0x1ab0: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1ab4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1ab4:
	/* 0x1ab4: cbnz x0, 1acc <generic_usdt_process_event+0x1acc> */
	ARM64_SIM_A64_CBNZ(ARM64_X0, 0x1ab4, 0x1acc, arm64_l_1acc);
arm64_l_1ab8:
	/* 0x1ab8: ldr w8, [sp, #240] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 240ULL);
arm64_l_1abc:
	/* 0x1abc: ldr x9, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1ac0:
	/* 0x1ac0: cmp w8, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_1ac4:
	/* 0x1ac4: cset w8, ne */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSET, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_NE, 0);
arm64_l_1ac8:
	/* 0x1ac8: str w8, [x9] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1acc:
	/* 0x1acc: mov w13, #0x50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 80ULL);
arm64_l_1ad0:
	/* 0x1ad0: b 2b6c <generic_usdt_process_event+0x2b6c> */
	ARM64_SIM_A64_JMP(0x1ad0, 0x2b6c, arm64_l_2b6c);
arm64_l_1ad4:
	/* 0x1ad4: mov x13, #0xffffffffffffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 18446744073709551615ULL);
arm64_l_1ad8:
	/* 0x1ad8: b 2b6c <generic_usdt_process_event+0x2b6c> */
	ARM64_SIM_A64_JMP(0x1ad8, 0x2b6c, arm64_l_2b6c);
arm64_l_1adc:
	/* 0x1adc: add x2, x22, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_1ae0:
	/* 0x1ae0: mov w25, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1ae4:
	/* 0x1ae4: add x8, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1ae8:
	/* 0x1ae8: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1aec:
	/* 0x1aec: add x0, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1af0:
	/* 0x1af0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1af4:
	/* 0x1af4: mov w29, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1af8:
	/* 0x1af8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1afcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1afc:
	/* 0x1afc: add x2, x22, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_1b00:
	/* 0x1b00: add x8, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_1b04:
	/* 0x1b04: add x0, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_1b08:
	/* 0x1b08: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1b0c:
	/* 0x1b0c: blr x29 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X29);
		if (ARM64_SIM_L_REG_TAG(ARM64_X29) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1b10ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1b10:
	/* 0x1b10: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_1b14:
	/* 0x1b14: ldr x2, [x8, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1b18:
	/* 0x1b18: ldr x22, [x8, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_1b1c:
	/* 0x1b1c: ldr x8, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1b20:
	/* 0x1b20: add x8, x8, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_1b24:
	/* 0x1b24: add x23, x8, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1b28:
	/* 0x1b28: tbz w24, #5, 2014 <generic_usdt_process_event+0x2014> */
	ARM64_SIM_A64_TBZ(ARM64_X24, 5, 0x1b28, 0x2014, arm64_l_2014);
arm64_l_1b2c:
	/* 0x1b2c: cmp x22, #0x1, lsl #12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_1b30:
	/* 0x1b30: b.cc 1ffc <generic_usdt_process_event+0x1ffc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x1b30, 0x1ffc, arm64_l_1ffc);
arm64_l_1b34:
	/* 0x1b34: ldr x19, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1b38:
	/* 0x1b38: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1b3c:
	/* 0x1b3c: mov x3, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b40:
	/* 0x1b40: b 2140 <generic_usdt_process_event+0x2140> */
	ARM64_SIM_A64_JMP(0x1b40, 0x2140, arm64_l_2140);
arm64_l_1b44:
	/* 0x1b44: str wzr, [sp, #240] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 240ULL);
arm64_l_1b48:
	/* 0x1b48: adrp x0, 0 <tg_ipv6_ext_heap> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_ipv6_ext_heap_13));
arm64_l_1b4c:
	/* 0x1b4c: ldr x29, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1b50:
	/* 0x1b50: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1b54:
	/* 0x1b54: add x9, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1b58:
	/* 0x1b58: add x1, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1b5c:
	/* 0x1b5c: ldrh w22, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1b60:
	/* 0x1b60: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b64:
	/* 0x1b64: add x21, x29, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X21, ARM64_X29, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1b68:
	/* 0x1b68: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1b6cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1b6c:
	/* 0x1b6c: cbz x0, 29e8 <generic_usdt_process_event+0x29e8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1b6c, 0x29e8, arm64_l_29e8);
arm64_l_1b70:
	/* 0x1b70: mov w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 255ULL);
arm64_l_1b74:
	/* 0x1b74: strh w22, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1b78:
	/* 0x1b78: strb wzr, [x0, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_1b7c:
	/* 0x1b7c: add x24, x0, #0x6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1b80:
	/* 0x1b80: add x2, x21, #0x6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_1b84:
	/* 0x1b84: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1b88:
	/* 0x1b88: strb w8, [x0, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_1b8c:
	/* 0x1b8c: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1b90:
	/* 0x1b90: mov x23, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b94:
	/* 0x1b94: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1b98:
	/* 0x1b98: mov w1, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1b9c:
	/* 0x1b9c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1ba0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1ba0:
	/* 0x1ba0: tbnz x0, #63, 29e8 <generic_usdt_process_event+0x29e8> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x1ba0, 0x29e8, arm64_l_29e8);
arm64_l_1ba4:
	/* 0x1ba4: ldrb w8, [x23, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_1ba8:
	/* 0x1ba8: cmp w8, #0x32; 0x1bac: b.gt 2058 <generic_usdt_process_event+0x2058> */
arm64_l_1bac:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50ULL, arm64_l_2058);
arm64_l_1bb0:
	/* 0x1bb0: cbz w8, 20d0 <generic_usdt_process_event+0x20d0> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x1bb0, 0x20d0, arm64_l_20d0);
arm64_l_1bb4:
	/* 0x1bb4: cmp w8, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_1bb8:
	/* 0x1bb8: b.eq 20d0 <generic_usdt_process_event+0x20d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1bb8, 0x20d0, arm64_l_20d0);
arm64_l_1bbc:
	/* 0x1bbc: cmp w8, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_1bc0:
	/* 0x1bc0: b.ne 24fc <generic_usdt_process_event+0x24fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1bc0, 0x24fc, arm64_l_24fc);
arm64_l_1bc4:
	/* 0x1bc4: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1bc8:
	/* 0x1bc8: b 2448 <generic_usdt_process_event+0x2448> */
	ARM64_SIM_A64_JMP(0x1bc8, 0x2448, arm64_l_2448);
arm64_l_1bcc:
	/* 0x1bcc: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1bd0:
	/* 0x1bd0: add x2, x23, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1bd4:
	/* 0x1bd4: mov w25, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1bd8:
	/* 0x1bd8: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1bdc:
	/* 0x1bdc: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1be0:
	/* 0x1be0: mov w29, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1be4:
	/* 0x1be4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1be8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1be8:
	/* 0x1be8: add x2, x23, #0x38 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_1bec:
	/* 0x1bec: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1bf0:
	/* 0x1bf0: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1bf4:
	/* 0x1bf4: blr x29 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X29);
		if (ARM64_SIM_L_REG_TAG(ARM64_X29) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1bf8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1bf8:
	/* 0x1bf8: ldr x29, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1bfc:
	/* 0x1bfc: add x22, x23, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1c00:
	/* 0x1c00: add x2, x23, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 14ULL);
arm64_l_1c04:
	/* 0x1c04: mov w23, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1c08:
	/* 0x1c08: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1c0c:
	/* 0x1c0c: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1c10:
	/* 0x1c10: mov w25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1c14:
	/* 0x1c14: add x0, x29, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_1c18:
	/* 0x1c18: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1c1cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1c1c:
	/* 0x1c1c: add x0, x29, #0x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 34ULL);
arm64_l_1c20:
	/* 0x1c20: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1c24:
	/* 0x1c24: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1c28:
	/* 0x1c28: blr x25 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X25);
		if (ARM64_SIM_L_REG_TAG(ARM64_X25) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1c2cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1c2c:
	/* 0x1c2c: ldrh w8, [x29, #34] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 34ULL);
arm64_l_1c30:
	/* 0x1c30: adrp x0, 0 <socktrack_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&socktrack_map_9));
arm64_l_1c34:
	/* 0x1c34: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1c38:
	/* 0x1c38: add x1, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1c3c:
	/* 0x1c3c: rev w8, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_REV, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1c40:
	/* 0x1c40: lsr w8, w8, #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 16ULL);
arm64_l_1c44:
	/* 0x1c44: strh w8, [x29, #34] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 34ULL);
arm64_l_1c48:
	/* 0x1c48: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_1c4c:
	/* 0x1c4c: ldr x8, [x8, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1c50:
	/* 0x1c50: str x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1c54:
	/* 0x1c54: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1c58:
	/* 0x1c58: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c5c:
	/* 0x1c5c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1c60ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1c60:
	/* 0x1c60: cbz x0, 2b68 <generic_usdt_process_event+0x2b68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1c60, 0x2b68, arm64_l_2b68);
arm64_l_1c64:
	/* 0x1c64: ldr w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1c68:
	/* 0x1c68: mov w13, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 64ULL);
arm64_l_1c6c:
	/* 0x1c6c: str w8, [x24, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1c70:
	/* 0x1c70: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1c74:
	/* 0x1c74: str x8, [x24, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1c78:
	/* 0x1c78: ldr w8, [x0, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1c7c:
	/* 0x1c7c: str w8, [x24, #124] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 124ULL);
arm64_l_1c80:
	/* 0x1c80: b 2b6c <generic_usdt_process_event+0x2b6c> */
	ARM64_SIM_A64_JMP(0x1c80, 0x2b6c, arm64_l_2b6c);
arm64_l_1c84:
	/* 0x1c84: ldr x8, [sp, #56] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 56ULL);
arm64_l_1c88:
	/* 0x1c88: mov w13, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_1c8c:
	/* 0x1c8c: add x8, x8, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1c90:
	/* 0x1c90: str xzr, [x8, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_1c94:
	/* 0x1c94: b 2b6c <generic_usdt_process_event+0x2b6c> */
	ARM64_SIM_A64_JMP(0x1c94, 0x2b6c, arm64_l_2b6c);
arm64_l_1c98:
	/* 0x1c98: mov w8, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_1c9c:
	/* 0x1c9c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x1ca0ULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1ca0:
	/* 0x1ca0: cmn x0, #0x16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 22ULL);
arm64_l_1ca4:
	/* 0x1ca4: b.ne 1cb0 <generic_usdt_process_event+0x1cb0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1ca4, 0x1cb0, arm64_l_1cb0);
arm64_l_1ca8:
	/* 0x1ca8: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1cac:
	/* 0x1cac: ldr x0, [x8, #232] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_1cb0:
	/* 0x1cb0: ldr x9, [x24, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1cb4:
	/* 0x1cb4: ldr x8, [x24, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1cb8:
	/* 0x1cb8: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1cbc:
	/* 0x1cbc: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1cc0:
	/* 0x1cc0: add x1, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1cc4:
	/* 0x1cc4: add x2, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1cc8:
	/* 0x1cc8: str xzr, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1ccc:
	/* 0x1ccc: stp x9, x22, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1cd0:
	/* 0x1cd0: add x9, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_1cd4:
	/* 0x1cd4: add x22, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_1cd8:
	/* 0x1cd8: stp x8, x0, [x9, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X9, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1cdc:
	/* 0x1cdc: adrp x0, 0 <retprobe_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&retprobe_map_7));
arm64_l_1ce0:
	/* 0x1ce0: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1ce4:
	/* 0x1ce4: add x9, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1ce8:
	/* 0x1ce8: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1cec:
	/* 0x1cec: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0x1cf0ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1cf0:
	/* 0x1cf0: cbz x0, 209c <generic_usdt_process_event+0x209c> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1cf0, 0x209c, arm64_l_209c);
arm64_l_1cf4:
	/* 0x1cf4: neg w8, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1cf8:
	/* 0x1cf8: mov w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1cfc:
	/* 0x1cfc: add x1, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_1d00:
	/* 0x1d00: strh w8, [sp, #256] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 256ULL);
arm64_l_1d04:
	/* 0x1d04: mov w8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_1d08:
	/* 0x1d08: mov w24, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1d0c:
	/* 0x1d0c: strh w8, [sp, #258] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 258ULL);
arm64_l_1d10:
	/* 0x1d10: mov x8, #0x46 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 70ULL);
arm64_l_1d14:
	/* 0x1d14: movk x8, #0x2, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 2ULL);
arm64_l_1d18:
	/* 0x1d18: stur x8, [x22, #36] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1d1c:
	/* 0x1d1c: adrp x22, 0 <tg_errmetrics_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_errmetrics_map_12));
arm64_l_1d20:
	/* 0x1d20: add x8, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_1d24:
	/* 0x1d24: ldr x22, [x22] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1d28:
	/* 0x1d28: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1d2c:
	/* 0x1d2c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1d30ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1d30:
	/* 0x1d30: cbz x0, 2078 <generic_usdt_process_event+0x2078> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1d30, 0x2078, arm64_l_2078);
arm64_l_1d34:
	/* 0x1d34: ldr w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1d38:
	/* 0x1d38: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1d3c:
	/* 0x1d3c: str w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1d40:
	/* 0x1d40: b 209c <generic_usdt_process_event+0x209c> */
	ARM64_SIM_A64_JMP(0x1d40, 0x209c, arm64_l_209c);
arm64_l_1d44:
	/* 0x1d44: cmp w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1d48:
	/* 0x1d48: b.eq 1ee8 <generic_usdt_process_event+0x1ee8> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1d48, 0x1ee8, arm64_l_1ee8);
arm64_l_1d4c:
	/* 0x1d4c: cmp w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1d50:
	/* 0x1d50: b.ne 1f30 <generic_usdt_process_event+0x1f30> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1d50, 0x1f30, arm64_l_1f30);
arm64_l_1d54:
	/* 0x1d54: mov w8, #0x5e58 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24152ULL);
arm64_l_1d58:
	/* 0x1d58: b 1eec <generic_usdt_process_event+0x1eec> */
	ARM64_SIM_A64_JMP(0x1d58, 0x1eec, arm64_l_1eec);
arm64_l_1d5c:
	/* 0x1d5c: ldr x24, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1d60:
	/* 0x1d60: add x2, x22, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1d64:
	/* 0x1d64: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1d68:
	/* 0x1d68: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1d6c:
	/* 0x1d6c: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1d70:
	/* 0x1d70: mov w23, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1d74:
	/* 0x1d74: add x0, x24, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1d78:
	/* 0x1d78: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1d7cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1d7c:
	/* 0x1d7c: add x0, x24, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1d80:
	/* 0x1d80: add x2, x22, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1d84:
	/* 0x1d84: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1d88:
	/* 0x1d88: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1d8c:
	/* 0x1d8c: blr x23 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X23);
		if (ARM64_SIM_L_REG_TAG(ARM64_X23) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1d90ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1d90:
	/* 0x1d90: ldr x9, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1d94:
	/* 0x1d94: adrp x21, 0 <process_call_heap> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_6));
arm64_l_1d98:
	/* 0x1d98: mov w29, #0x5efc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24316ULL);
arm64_l_1d9c:
	/* 0x1d9c: ldrh w8, [x9, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_1da0:
	/* 0x1da0: rev w8, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_REV, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1da4:
	/* 0x1da4: lsr w8, w8, #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 16ULL);
arm64_l_1da8:
	/* 0x1da8: strh w8, [x9, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_1dac:
	/* 0x1dac: ldr x21, [x21] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1db0:
	/* 0x1db0: ldr x19, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1db4:
	/* 0x1db4: mov w13, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_1db8:
	/* 0x1db8: b c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_JMP(0x1db8, 0xc14, arm64_l_c14);
arm64_l_1dbc:
	/* 0x1dbc: mov x13, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1dc0:
	/* 0x1dc0: mov w29, #0x5efc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24316ULL);
arm64_l_1dc4:
	/* 0x1dc4: mov x10, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X10, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1dc8:
	/* 0x1dc8: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_1dcc:
	/* 0x1dcc: mov x11, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X11, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1dd0:
	/* 0x1dd0: b 2b78 <generic_usdt_process_event+0x2b78> */
	ARM64_SIM_A64_JMP(0x1dd0, 0x2b78, arm64_l_2b78);
arm64_l_1dd4:
	/* 0x1dd4: add x2, x22, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_1dd8:
	/* 0x1dd8: mov w22, #0x6b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 107ULL);
arm64_l_1ddc:
	/* 0x1ddc: mov w8, #0x71 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 113ULL);
arm64_l_1de0:
	/* 0x1de0: mov w1, #0x6b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 107ULL);
arm64_l_1de4:
	/* 0x1de4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 113ULL: ARM64_SIM_A64_LINK(0x1de8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1de8:
	/* 0x1de8: adrp x21, 0 <process_call_heap> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_6));
arm64_l_1dec:
	/* 0x1dec: mov w29, #0x5efc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24316ULL);
arm64_l_1df0:
	/* 0x1df0: ldr x21, [x21] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1df4:
	/* 0x1df4: ldr x19, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1df8:
	/* 0x1df8: tbnz w0, #31, 1e04 <generic_usdt_process_event+0x1e04> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x1df8, 0x1e04, arm64_l_1e04);
arm64_l_1dfc:
	/* 0x1dfc: ldr x8, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1e00:
	/* 0x1e00: strb w22, [x8, #3] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 3ULL);
arm64_l_1e04:
	/* 0x1e04: mov w13, #0x70 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 112ULL);
arm64_l_1e08:
	/* 0x1e08: b c14 <generic_usdt_process_event+0xc14> */
	ARM64_SIM_A64_JMP(0x1e08, 0xc14, arm64_l_c14);
arm64_l_1e0c:
	/* 0x1e0c: cmp w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1e10:
	/* 0x1e10: b.eq 20ec <generic_usdt_process_event+0x20ec> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x1e10, 0x20ec, arm64_l_20ec);
arm64_l_1e14:
	/* 0x1e14: cmp w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_1e18:
	/* 0x1e18: b.ne 20f8 <generic_usdt_process_event+0x20f8> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1e18, 0x20f8, arm64_l_20f8);
arm64_l_1e1c:
	/* 0x1e1c: mov w8, #0x5e58 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24152ULL);
arm64_l_1e20:
	/* 0x1e20: b 20f0 <generic_usdt_process_event+0x20f0> */
	ARM64_SIM_A64_JMP(0x1e20, 0x20f0, arm64_l_20f0);
arm64_l_1e24:
	/* 0x1e24: ldr x0, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1e28:
	/* 0x1e28: add x2, x23, #0x48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 72ULL);
arm64_l_1e2c:
	/* 0x1e2c: mov w25, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1e30:
	/* 0x1e30: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1e34:
	/* 0x1e34: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1e38:
	/* 0x1e38: mov w29, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1e3c:
	/* 0x1e3c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1e40ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1e40:
	/* 0x1e40: add x2, x23, #0x38 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_1e44:
	/* 0x1e44: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1e48:
	/* 0x1e48: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1e4c:
	/* 0x1e4c: blr x29 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X29);
		if (ARM64_SIM_L_REG_TAG(ARM64_X29) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1e50ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1e50:
	/* 0x1e50: ldr x29, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1e54:
	/* 0x1e54: add x22, x23, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_1e58:
	/* 0x1e58: add x2, x23, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 14ULL);
arm64_l_1e5c:
	/* 0x1e5c: mov w23, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1e60:
	/* 0x1e60: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1e64:
	/* 0x1e64: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1e68:
	/* 0x1e68: mov w25, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1e6c:
	/* 0x1e6c: add x0, x29, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_1e70:
	/* 0x1e70: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1e74ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1e74:
	/* 0x1e74: add x0, x29, #0x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 34ULL);
arm64_l_1e78:
	/* 0x1e78: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1e7c:
	/* 0x1e7c: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1e80:
	/* 0x1e80: blr x25 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X25);
		if (ARM64_SIM_L_REG_TAG(ARM64_X25) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1e84ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1e84:
	/* 0x1e84: ldrh w8, [x29, #34] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 34ULL);
arm64_l_1e88:
	/* 0x1e88: rev w8, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_REV, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_1e8c:
	/* 0x1e8c: lsr w8, w8, #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 16ULL);
arm64_l_1e90:
	/* 0x1e90: strh w8, [x29, #34] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 34ULL);
arm64_l_1e94:
	/* 0x1e94: ldr x8, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1e98:
	/* 0x1e98: adrp x0, 0 <socktrack_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&socktrack_map_9));
arm64_l_1e9c:
	/* 0x1e9c: add x9, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1ea0:
	/* 0x1ea0: add x1, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1ea4:
	/* 0x1ea4: ldr x8, [x8, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_1ea8:
	/* 0x1ea8: str x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1eac:
	/* 0x1eac: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1eb0:
	/* 0x1eb0: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1eb4:
	/* 0x1eb4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1eb8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1eb8:
	/* 0x1eb8: cbz x0, 2b68 <generic_usdt_process_event+0x2b68> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1eb8, 0x2b68, arm64_l_2b68);
arm64_l_1ebc:
	/* 0x1ebc: ldr w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ec0:
	/* 0x1ec0: str w8, [x24, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1ec4:
	/* 0x1ec4: ldr x8, [x0, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1ec8:
	/* 0x1ec8: str x8, [x24, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_1ecc:
	/* 0x1ecc: ldr w8, [x0, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_1ed0:
	/* 0x1ed0: str w8, [x24, #124] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 124ULL);
arm64_l_1ed4:
	/* 0x1ed4: b 2b68 <generic_usdt_process_event+0x2b68> */
	ARM64_SIM_A64_JMP(0x1ed4, 0x2b68, arm64_l_2b68);
arm64_l_1ed8:
	/* 0x1ed8: mov w8, #0x5e60 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24160ULL);
arm64_l_1edc:
	/* 0x1edc: b 1eec <generic_usdt_process_event+0x1eec> */
	ARM64_SIM_A64_JMP(0x1edc, 0x1eec, arm64_l_1eec);
arm64_l_1ee0:
	/* 0x1ee0: mov w8, #0x5e68 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24168ULL);
arm64_l_1ee4:
	/* 0x1ee4: b 1eec <generic_usdt_process_event+0x1eec> */
	ARM64_SIM_A64_JMP(0x1ee4, 0x1eec, arm64_l_1eec);
arm64_l_1ee8:
	/* 0x1ee8: mov w8, #0x5e50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24144ULL);
arm64_l_1eec:
	/* 0x1eec: add x8, x24, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1ef0:
	/* 0x1ef0: ldr x25, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ef4:
	/* 0x1ef4: tbnz w12, #4, 1f3c <generic_usdt_process_event+0x1f3c> */
	ARM64_SIM_A64_TBNZ(ARM64_X12, 4, 0x1ef4, 0x1f3c, arm64_l_1f3c);
arm64_l_1ef8:
	/* 0x1ef8: cbz x25, 1fec <generic_usdt_process_event+0x1fec> */
	ARM64_SIM_A64_CBZ(ARM64_X25, 0x1ef8, 0x1fec, arm64_l_1fec);
arm64_l_1efc:
	/* 0x1efc: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1f00:
	/* 0x1f00: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_1f04:
	/* 0x1f04: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1f08:
	/* 0x1f08: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1f0c:
	/* 0x1f0c: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_1f10:
	/* 0x1f10: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1f14:
	/* 0x1f14: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x1f18ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1f18:
	/* 0x1f18: tbnz w0, #31, 242c <generic_usdt_process_event+0x242c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x1f18, 0x242c, arm64_l_242c);
arm64_l_1f1c:
	/* 0x1f1c: ldr x23, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_1f20:
	/* 0x1f20: cmp x23, #0xffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4094ULL);
arm64_l_1f24:
	/* 0x1f24: b.ls 21c0 <generic_usdt_process_event+0x21c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x1f24, 0x21c0, arm64_l_21c0);
arm64_l_1f28:
	/* 0x1f28: mov w8, #0xfffffffd */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967293ULL);
arm64_l_1f2c:
	/* 0x1f2c: b 2430 <generic_usdt_process_event+0x2430> */
	ARM64_SIM_A64_JMP(0x1f2c, 0x2430, arm64_l_2430);
arm64_l_1f30:
	/* 0x1f30: mov x25, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X25, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1f34:
	/* 0x1f34: mov x23, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1f38:
	/* 0x1f38: tbz w12, #4, 1ff0 <generic_usdt_process_event+0x1ff0> */
	ARM64_SIM_A64_TBZ(ARM64_X12, 4, 0x1f38, 0x1ff0, arm64_l_1ff0);
arm64_l_1f3c:
	/* 0x1f3c: mov w8, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_1f40:
	/* 0x1f40: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x1f44ULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1f44:
	/* 0x1f44: cmn x0, #0x16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 22ULL);
arm64_l_1f48:
	/* 0x1f48: b.ne 1f54 <generic_usdt_process_event+0x1f54> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x1f48, 0x1f54, arm64_l_1f54);
arm64_l_1f4c:
	/* 0x1f4c: ldr x8, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_1f50:
	/* 0x1f50: ldr x0, [x8, #232] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_1f54:
	/* 0x1f54: ldr x9, [x24, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_1f58:
	/* 0x1f58: ldr x8, [x24, #96] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 96ULL);
arm64_l_1f5c:
	/* 0x1f5c: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1f60:
	/* 0x1f60: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1f64:
	/* 0x1f64: add x1, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1f68:
	/* 0x1f68: add x2, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_1f6c:
	/* 0x1f6c: str x25, [sp, #168] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 168ULL);
arm64_l_1f70:
	/* 0x1f70: stp x9, x22, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_1f74:
	/* 0x1f74: add x9, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_1f78:
	/* 0x1f78: add x22, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_1f7c:
	/* 0x1f7c: stp x8, x0, [x9, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X9, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_1f80:
	/* 0x1f80: adrp x0, 0 <retprobe_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&retprobe_map_7));
arm64_l_1f84:
	/* 0x1f84: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_1f88:
	/* 0x1f88: add x9, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_1f8c:
	/* 0x1f8c: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1f90:
	/* 0x1f90: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0x1f94ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1f94:
	/* 0x1f94: cbz x0, 20c8 <generic_usdt_process_event+0x20c8> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1f94, 0x20c8, arm64_l_20c8);
arm64_l_1f98:
	/* 0x1f98: neg w8, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NEG, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_1f9c:
	/* 0x1f9c: mov w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1fa0:
	/* 0x1fa0: add x1, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_1fa4:
	/* 0x1fa4: strh w8, [sp, #256] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 256ULL);
arm64_l_1fa8:
	/* 0x1fa8: mov w8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 5ULL);
arm64_l_1fac:
	/* 0x1fac: mov w23, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_1fb0:
	/* 0x1fb0: strh w8, [sp, #258] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 258ULL);
arm64_l_1fb4:
	/* 0x1fb4: mov x8, #0x57 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 87ULL);
arm64_l_1fb8:
	/* 0x1fb8: movk x8, #0x2, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 2ULL);
arm64_l_1fbc:
	/* 0x1fbc: stur x8, [x22, #36] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_1fc0:
	/* 0x1fc0: adrp x22, 0 <tg_errmetrics_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_errmetrics_map_12));
arm64_l_1fc4:
	/* 0x1fc4: add x8, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_1fc8:
	/* 0x1fc8: ldr x22, [x22] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1fcc:
	/* 0x1fcc: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1fd0:
	/* 0x1fd0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x1fd4ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_1fd4:
	/* 0x1fd4: cbz x0, 20a4 <generic_usdt_process_event+0x20a4> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x1fd4, 0x20a4, arm64_l_20a4);
arm64_l_1fd8:
	/* 0x1fd8: ldr w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1fdc:
	/* 0x1fdc: add w8, w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_1fe0:
	/* 0x1fe0: str w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1fe4:
	/* 0x1fe4: mov w8, #0xfffffffc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967292ULL);
arm64_l_1fe8:
	/* 0x1fe8: b 2430 <generic_usdt_process_event+0x2430> */
	ARM64_SIM_A64_JMP(0x1fe8, 0x2430, arm64_l_2430);
arm64_l_1fec:
	/* 0x1fec: mov x23, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_1ff0:
	/* 0x1ff0: stp w23, w23, [x21] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X21, ARM64_X23, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_1ff4:
	/* 0x1ff4: add x13, x23, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_1ff8:
	/* 0x1ff8: b 2b6c <generic_usdt_process_event+0x2b6c> */
	ARM64_SIM_A64_JMP(0x1ff8, 0x2b6c, arm64_l_2b6c);
arm64_l_1ffc:
	/* 0x1ffc: ldr x9, [sp, #280] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 280ULL);
arm64_l_2000:
	/* 0x2000: str wzr, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2004:
	/* 0x2004: mov w25, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_2008:
	/* 0x2008: add w9, w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_200c:
	/* 0x200c: and x9, x9, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_2010:
	/* 0x2010: add x23, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2014:
	/* 0x2014: cmp x22, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2018:
	/* 0x2018: mov w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4095ULL);
arm64_l_201c:
	/* 0x201c: add x0, x23, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2020:
	/* 0x2020: csel x24, x22, x8, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X24, ARM64_X22, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_2024:
	/* 0x2024: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2028:
	/* 0x2028: mov w1, w24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_202c:
	/* 0x202c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2030ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2030:
	/* 0x2030: tbnz w0, #31, 2040 <generic_usdt_process_event+0x2040> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2030, 0x2040, arm64_l_2040);
arm64_l_2034:
	/* 0x2034: stp w22, w24, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X23, ARM64_X22, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2038:
	/* 0x2038: add x13, x25, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X13, ARM64_X25, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_203c:
	/* 0x203c: b 2b6c <generic_usdt_process_event+0x2b6c> */
	ARM64_SIM_A64_JMP(0x203c, 0x2b6c, arm64_l_2b6c);
arm64_l_2040:
	/* 0x2040: mov w8, #0xfffffffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967294ULL);
arm64_l_2044:
	/* 0x2044: mov w13, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2048:
	/* 0x2048: str w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_204c:
	/* 0x204c: b 2b6c <generic_usdt_process_event+0x2b6c> */
	ARM64_SIM_A64_JMP(0x204c, 0x2b6c, arm64_l_2b6c);
arm64_l_2050:
	/* 0x2050: mov x13, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X13, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2054:
	/* 0x2054: b 2b6c <generic_usdt_process_event+0x2b6c> */
	ARM64_SIM_A64_JMP(0x2054, 0x2b6c, arm64_l_2b6c);
arm64_l_2058:
	/* 0x2058: cmp w8, #0x33 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 51ULL);
arm64_l_205c:
	/* 0x205c: b.eq 243c <generic_usdt_process_event+0x243c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x205c, 0x243c, arm64_l_243c);
arm64_l_2060:
	/* 0x2060: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2064:
	/* 0x2064: b.eq 20d0 <generic_usdt_process_event+0x20d0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2064, 0x20d0, arm64_l_20d0);
arm64_l_2068:
	/* 0x2068: cmp w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_206c:
	/* 0x206c: b.ne 24fc <generic_usdt_process_event+0x24fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x206c, 0x24fc, arm64_l_24fc);
arm64_l_2070:
	/* 0x2070: mov w8, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 40ULL);
arm64_l_2074:
	/* 0x2074: b 2448 <generic_usdt_process_event+0x2448> */
	ARM64_SIM_A64_JMP(0x2074, 0x2448, arm64_l_2448);
arm64_l_2078:
	/* 0x2078: str w24, [sp, #144] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 144ULL);
arm64_l_207c:
	/* 0x207c: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2080:
	/* 0x2080: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2084:
	/* 0x2084: add x9, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_2088:
	/* 0x2088: add x10, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_208c:
	/* 0x208c: add x1, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_2090:
	/* 0x2090: add x2, sp, #0x90 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 144ULL);
arm64_l_2094:
	/* 0x2094: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2098:
	/* 0x2098: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0x209cULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_209c:
	/* 0x209c: mov w8, #0xfffffffc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967292ULL);
arm64_l_20a0:
	/* 0x20a0: b 21b8 <generic_usdt_process_event+0x21b8> */
	ARM64_SIM_A64_JMP(0x20a0, 0x21b8, arm64_l_21b8);
arm64_l_20a4:
	/* 0x20a4: str w23, [sp, #232] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_20a8:
	/* 0x20a8: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_20ac:
	/* 0x20ac: mov w8, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_20b0:
	/* 0x20b0: add x9, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_20b4:
	/* 0x20b4: add x10, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_20b8:
	/* 0x20b8: add x1, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_20bc:
	/* 0x20bc: add x2, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_20c0:
	/* 0x20c0: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_20c4:
	/* 0x20c4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 2ULL: ARM64_SIM_A64_LINK(0x20c8ULL); ARM64_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_20c8:
	/* 0x20c8: mov w8, #0xfffffffc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967292ULL);
arm64_l_20cc:
	/* 0x20cc: b 2430 <generic_usdt_process_event+0x2430> */
	ARM64_SIM_A64_JMP(0x20cc, 0x2430, arm64_l_2430);
arm64_l_20d0:
	/* 0x20d0: ldrb w8, [x23, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_20d4:
	/* 0x20d4: lsl w8, w8, #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_20d8:
	/* 0x20d8: b 2444 <generic_usdt_process_event+0x2444> */
	ARM64_SIM_A64_JMP(0x20d8, 0x2444, arm64_l_2444);
arm64_l_20dc:
	/* 0x20dc: mov w8, #0x5e60 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24160ULL);
arm64_l_20e0:
	/* 0x20e0: b 20f0 <generic_usdt_process_event+0x20f0> */
	ARM64_SIM_A64_JMP(0x20e0, 0x20f0, arm64_l_20f0);
arm64_l_20e4:
	/* 0x20e4: mov w8, #0x5e68 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24168ULL);
arm64_l_20e8:
	/* 0x20e8: b 20f0 <generic_usdt_process_event+0x20f0> */
	ARM64_SIM_A64_JMP(0x20e8, 0x20f0, arm64_l_20f0);
arm64_l_20ec:
	/* 0x20ec: mov w8, #0x5e50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24144ULL);
arm64_l_20f0:
	/* 0x20f0: add x8, x24, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_20f4:
	/* 0x20f4: ldr x8, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_20f8:
	/* 0x20f8: add x21, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_20fc:
	/* 0x20fc: mov w29, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2100:
	/* 0x2100: add x9, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_2104:
	/* 0x2104: str x8, [x21, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2108:
	/* 0x2108: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_210c:
	/* 0x210c: add x10, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_2110:
	/* 0x2110: add x0, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_2114:
	/* 0x2114: add x2, sp, #0xe8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 232ULL);
arm64_l_2118:
	/* 0x2118: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_211c:
	/* 0x211c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2120ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2120:
	/* 0x2120: ldr x24, [x21] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2124:
	/* 0x2124: tbz w19, #5, 2184 <generic_usdt_process_event+0x2184> */
	ARM64_SIM_A64_TBZ(ARM64_X19, 5, 0x2124, 0x2184, arm64_l_2184);
arm64_l_2128:
	/* 0x2128: cmp x24, #0x1, lsl #12 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4096ULL);
arm64_l_212c:
	/* 0x212c: b.cc 216c <generic_usdt_process_event+0x216c> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x212c, 0x216c, arm64_l_216c);
arm64_l_2130:
	/* 0x2130: ldr x19, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_2134:
	/* 0x2134: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2138:
	/* 0x2138: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_213c:
	/* 0x213c: mov x3, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2140:
	/* 0x2140: str w8, [x23], #4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 4ULL);
arm64_l_2144:
	/* 0x2144: mov x1, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2148:
	/* 0x2148: mov x0, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_214c:
	/* 0x214c: bl 2bac <data_event_bytes> */
	ARM64_SIM_A64_CALL(arm64_l_2bac, 0x2150ULL);
arm64_l_2150:
	/* 0x2150: adrp x21, 0 <process_call_heap> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_6));
arm64_l_2154:
	/* 0x2154: ldp x10, x11, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2158:
	/* 0x2158: add x13, x0, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X13, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 4ULL);
arm64_l_215c:
	/* 0x215c: mov w29, #0x5efc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24316ULL);
arm64_l_2160:
	/* 0x2160: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_2164:
	/* 0x2164: ldr x21, [x21] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2168:
	/* 0x2168: b c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JMP(0x2168, 0xc1c, arm64_l_c1c);
arm64_l_216c:
	/* 0x216c: ldr x8, [sp, #280] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 280ULL);
arm64_l_2170:
	/* 0x2170: str wzr, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2174:
	/* 0x2174: mov w29, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 12ULL);
arm64_l_2178:
	/* 0x2178: add w8, w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_217c:
	/* 0x217c: and x8, x8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_2180:
	/* 0x2180: add x23, x25, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X25, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2184:
	/* 0x2184: cmp x24, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4095ULL);
arm64_l_2188:
	/* 0x2188: mov w8, #0xfff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4095ULL);
arm64_l_218c:
	/* 0x218c: add x0, x23, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2190:
	/* 0x2190: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2194:
	/* 0x2194: csel x25, x24, x8, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X25, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_2198:
	/* 0x2198: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_219c:
	/* 0x219c: mov w1, w25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_21a0:
	/* 0x21a0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x21a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_21a4:
	/* 0x21a4: tbnz w0, #31, 21b4 <generic_usdt_process_event+0x21b4> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x21a4, 0x21b4, arm64_l_21b4);
arm64_l_21a8:
	/* 0x21a8: stp w24, w25, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X23, ARM64_X24, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_21ac:
	/* 0x21ac: add x13, x29, x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X13, ARM64_X29, ARM64_X25, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_21b0:
	/* 0x21b0: b 2b6c <generic_usdt_process_event+0x2b6c> */
	ARM64_SIM_A64_JMP(0x21b0, 0x2b6c, arm64_l_2b6c);
arm64_l_21b4:
	/* 0x21b4: mov w8, #0xfffffffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967294ULL);
arm64_l_21b8:
	/* 0x21b8: str w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_21bc:
	/* 0x21bc: b 2434 <generic_usdt_process_event+0x2434> */
	ARM64_SIM_A64_JMP(0x21bc, 0x2434, arm64_l_2434);
arm64_l_21c0:
	/* 0x21c0: ldr x8, [sp, #280] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 280ULL);
arm64_l_21c4:
	/* 0x21c4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_21c8:
	/* 0x21c8: mov w1, w23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_21cc:
	/* 0x21cc: add x24, x8, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_21d0:
	/* 0x21d0: and x8, x24, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_21d4:
	/* 0x21d4: add x0, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_21d8:
	/* 0x21d8: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_21dc:
	/* 0x21dc: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_21e0:
	/* 0x21e0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x21e4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_21e4:
	/* 0x21e4: tbnz w0, #31, 242c <generic_usdt_process_event+0x242c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x21e4, 0x242c, arm64_l_242c);
arm64_l_21e8:
	/* 0x21e8: cmp x25, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_21ec:
	/* 0x21ec: b.eq 1ff0 <generic_usdt_process_event+0x1ff0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x21ec, 0x1ff0, arm64_l_1ff0);
arm64_l_21f0:
	/* 0x21f0: add x2, x22, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_21f4:
	/* 0x21f4: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_21f8:
	/* 0x21f8: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_21fc:
	/* 0x21fc: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2200:
	/* 0x2200: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2204:
	/* 0x2204: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2208:
	/* 0x2208: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x220cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_220c:
	/* 0x220c: tbnz w0, #31, 242c <generic_usdt_process_event+0x242c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x220c, 0x242c, arm64_l_242c);
arm64_l_2210:
	/* 0x2210: ldr x19, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_2214:
	/* 0x2214: cmp x19, #0xffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4094ULL);
arm64_l_2218:
	/* 0x2218: b.hi 1f28 <generic_usdt_process_event+0x1f28> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2218, 0x1f28, arm64_l_1f28);
arm64_l_221c:
	/* 0x221c: add x24, x23, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X23, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2220:
	/* 0x2220: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2224:
	/* 0x2224: mov w1, w19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2228:
	/* 0x2228: and x8, x24, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_222c:
	/* 0x222c: add x0, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2230:
	/* 0x2230: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_2234:
	/* 0x2234: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_2238:
	/* 0x2238: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x223cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_223c:
	/* 0x223c: tbnz w0, #31, 242c <generic_usdt_process_event+0x242c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x223c, 0x242c, arm64_l_242c);
arm64_l_2240:
	/* 0x2240: add x23, x19, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X19, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2244:
	/* 0x2244: cmp x25, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_2248:
	/* 0x2248: b.cc 1ff0 <generic_usdt_process_event+0x1ff0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x2248, 0x1ff0, arm64_l_1ff0);
arm64_l_224c:
	/* 0x224c: add x2, x22, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2250:
	/* 0x2250: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2254:
	/* 0x2254: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2258:
	/* 0x2258: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_225c:
	/* 0x225c: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2260:
	/* 0x2260: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2264:
	/* 0x2264: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2268ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2268:
	/* 0x2268: tbnz w0, #31, 242c <generic_usdt_process_event+0x242c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2268, 0x242c, arm64_l_242c);
arm64_l_226c:
	/* 0x226c: ldr x8, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_2270:
	/* 0x2270: cmp x8, #0xffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4094ULL);
arm64_l_2274:
	/* 0x2274: str x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2278:
	/* 0x2278: b.hi 1f28 <generic_usdt_process_event+0x1f28> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2278, 0x1f28, arm64_l_1f28);
arm64_l_227c:
	/* 0x227c: add x24, x19, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X19, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2280:
	/* 0x2280: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2284:
	/* 0x2284: ldr x1, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2288:
	/* 0x2288: and x8, x24, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_228c:
	/* 0x228c: add x0, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2290:
	/* 0x2290: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_2294:
	/* 0x2294: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_2298:
	/* 0x2298: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x229cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_229c:
	/* 0x229c: tbnz w0, #31, 242c <generic_usdt_process_event+0x242c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x229c, 0x242c, arm64_l_242c);
arm64_l_22a0:
	/* 0x22a0: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_22a4:
	/* 0x22a4: cmp x25, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 3ULL);
arm64_l_22a8:
	/* 0x22a8: add x23, x8, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_22ac:
	/* 0x22ac: b.eq 1ff0 <generic_usdt_process_event+0x1ff0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x22ac, 0x1ff0, arm64_l_1ff0);
arm64_l_22b0:
	/* 0x22b0: add x2, x22, #0x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 48ULL);
arm64_l_22b4:
	/* 0x22b4: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_22b8:
	/* 0x22b8: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_22bc:
	/* 0x22bc: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_22c0:
	/* 0x22c0: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_22c4:
	/* 0x22c4: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_22c8:
	/* 0x22c8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x22ccULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_22cc:
	/* 0x22cc: tbnz w0, #31, 242c <generic_usdt_process_event+0x242c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x22cc, 0x242c, arm64_l_242c);
arm64_l_22d0:
	/* 0x22d0: ldr x19, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_22d4:
	/* 0x22d4: cmp x19, #0xffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4094ULL);
arm64_l_22d8:
	/* 0x22d8: b.hi 1f28 <generic_usdt_process_event+0x1f28> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x22d8, 0x1f28, arm64_l_1f28);
arm64_l_22dc:
	/* 0x22dc: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_22e0:
	/* 0x22e0: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_22e4:
	/* 0x22e4: mov w1, w19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_22e8:
	/* 0x22e8: add x24, x8, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_22ec:
	/* 0x22ec: and x8, x24, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_22f0:
	/* 0x22f0: add x0, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_22f4:
	/* 0x22f4: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_22f8:
	/* 0x22f8: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_22fc:
	/* 0x22fc: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2300ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2300:
	/* 0x2300: tbnz w0, #31, 242c <generic_usdt_process_event+0x242c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2300, 0x242c, arm64_l_242c);
arm64_l_2304:
	/* 0x2304: add x23, x19, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X19, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2308:
	/* 0x2308: cmp x25, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_230c:
	/* 0x230c: b.cc 1ff0 <generic_usdt_process_event+0x1ff0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x230c, 0x1ff0, arm64_l_1ff0);
arm64_l_2310:
	/* 0x2310: add x2, x22, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_2314:
	/* 0x2314: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2318:
	/* 0x2318: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_231c:
	/* 0x231c: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2320:
	/* 0x2320: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2324:
	/* 0x2324: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2328:
	/* 0x2328: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x232cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_232c:
	/* 0x232c: tbnz w0, #31, 242c <generic_usdt_process_event+0x242c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x232c, 0x242c, arm64_l_242c);
arm64_l_2330:
	/* 0x2330: ldr x8, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_2334:
	/* 0x2334: cmp x8, #0xffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4094ULL);
arm64_l_2338:
	/* 0x2338: str x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_233c:
	/* 0x233c: b.hi 1f28 <generic_usdt_process_event+0x1f28> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x233c, 0x1f28, arm64_l_1f28);
arm64_l_2340:
	/* 0x2340: add x24, x19, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X19, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2344:
	/* 0x2344: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2348:
	/* 0x2348: ldr x1, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_234c:
	/* 0x234c: and x8, x24, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_2350:
	/* 0x2350: add x0, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2354:
	/* 0x2354: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_2358:
	/* 0x2358: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_235c:
	/* 0x235c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2360ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2360:
	/* 0x2360: tbnz w0, #31, 242c <generic_usdt_process_event+0x242c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2360, 0x242c, arm64_l_242c);
arm64_l_2364:
	/* 0x2364: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_2368:
	/* 0x2368: cmp x25, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_236c:
	/* 0x236c: add x23, x8, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2370:
	/* 0x2370: b.eq 1ff0 <generic_usdt_process_event+0x1ff0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2370, 0x1ff0, arm64_l_1ff0);
arm64_l_2374:
	/* 0x2374: add x2, x22, #0x50 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 80ULL);
arm64_l_2378:
	/* 0x2378: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_237c:
	/* 0x237c: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2380:
	/* 0x2380: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2384:
	/* 0x2384: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_2388:
	/* 0x2388: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_238c:
	/* 0x238c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2390ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2390:
	/* 0x2390: tbnz w0, #31, 242c <generic_usdt_process_event+0x242c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2390, 0x242c, arm64_l_242c);
arm64_l_2394:
	/* 0x2394: ldr x19, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_2398:
	/* 0x2398: cmp x19, #0xffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4094ULL);
arm64_l_239c:
	/* 0x239c: b.hi 1f28 <generic_usdt_process_event+0x1f28> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x239c, 0x1f28, arm64_l_1f28);
arm64_l_23a0:
	/* 0x23a0: ldr x8, [sp, #72] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 72ULL);
arm64_l_23a4:
	/* 0x23a4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_23a8:
	/* 0x23a8: mov w1, w19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_23ac:
	/* 0x23ac: add x24, x8, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X24, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_23b0:
	/* 0x23b0: and x8, x24, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_23b4:
	/* 0x23b4: add x0, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_23b8:
	/* 0x23b8: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_23bc:
	/* 0x23bc: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_23c0:
	/* 0x23c0: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x23c4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_23c4:
	/* 0x23c4: tbnz w0, #31, 242c <generic_usdt_process_event+0x242c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x23c4, 0x242c, arm64_l_242c);
arm64_l_23c8:
	/* 0x23c8: add x23, x19, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X19, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_23cc:
	/* 0x23cc: cmp x25, #0x7 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 7ULL);
arm64_l_23d0:
	/* 0x23d0: b.cc 1ff0 <generic_usdt_process_event+0x1ff0> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x23d0, 0x1ff0, arm64_l_1ff0);
arm64_l_23d4:
	/* 0x23d4: add x2, x22, #0x60 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 96ULL);
arm64_l_23d8:
	/* 0x23d8: mov w8, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_23dc:
	/* 0x23dc: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_23e0:
	/* 0x23e0: add x10, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_23e4:
	/* 0x23e4: add x0, sp, #0x98 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 152ULL);
arm64_l_23e8:
	/* 0x23e8: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_23ec:
	/* 0x23ec: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x23f0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_23f0:
	/* 0x23f0: tbnz w0, #31, 242c <generic_usdt_process_event+0x242c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x23f0, 0x242c, arm64_l_242c);
arm64_l_23f4:
	/* 0x23f4: ldr x22, [sp, #160] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 160ULL);
arm64_l_23f8:
	/* 0x23f8: cmp x22, #0xffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 4094ULL);
arm64_l_23fc:
	/* 0x23fc: b.hi 1f28 <generic_usdt_process_event+0x1f28> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x23fc, 0x1f28, arm64_l_1f28);
arm64_l_2400:
	/* 0x2400: add x8, x19, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X19, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2404:
	/* 0x2404: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2408:
	/* 0x2408: mov w1, w22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_240c:
	/* 0x240c: and x8, x8, #0x3fff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 16383ULL);
arm64_l_2410:
	/* 0x2410: add x0, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2414:
	/* 0x2414: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_2418:
	/* 0x2418: ldr x2, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X2, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_241c:
	/* 0x241c: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2420ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2420:
	/* 0x2420: tbnz w0, #31, 242c <generic_usdt_process_event+0x242c> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2420, 0x242c, arm64_l_242c);
arm64_l_2424:
	/* 0x2424: add x23, x22, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2428:
	/* 0x2428: b 1ff0 <generic_usdt_process_event+0x1ff0> */
	ARM64_SIM_A64_JMP(0x2428, 0x1ff0, arm64_l_1ff0);
arm64_l_242c:
	/* 0x242c: mov w8, #0xfffffffe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967294ULL);
arm64_l_2430:
	/* 0x2430: str w8, [x21] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X21, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2434:
	/* 0x2434: mov w13, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2438:
	/* 0x2438: b 2b6c <generic_usdt_process_event+0x2b6c> */
	ARM64_SIM_A64_JMP(0x2438, 0x2b6c, arm64_l_2b6c);
arm64_l_243c:
	/* 0x243c: ldrb w8, [x23, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_2440:
	/* 0x2440: lsl w8, w8, #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_2444:
	/* 0x2444: add w8, w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_2448:
	/* 0x2448: strh w8, [x23, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_244c:
	/* 0x244c: ldrh w9, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2450:
	/* 0x2450: ldrb w22, [x23, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_2454:
	/* 0x2454: add w8, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2458:
	/* 0x2458: cmp w22, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_245c:
	/* 0x245c: strh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2460:
	/* 0x2460: b.hi 2518 <generic_usdt_process_event+0x2518> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2460, 0x2518, arm64_l_2518);
arm64_l_2464:
	/* 0x2464: mov x10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 1ULL);
arm64_l_2468:
	/* 0x2468: mov w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_246c:
	/* 0x246c: movk x10, #0x1800, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 6144ULL);
arm64_l_2470:
	/* 0x2470: lsl x9, x9, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2474:
	/* 0x2474: movk x10, #0x1008, lsl #48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 4104ULL);
arm64_l_2478:
	/* 0x2478: tst x9, x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_247c:
	/* 0x247c: b.eq 2518 <generic_usdt_process_event+0x2518> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x247c, 0x2518, arm64_l_2518);
arm64_l_2480:
	/* 0x2480: strb w22, [x23, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2484:
	/* 0x2484: add x8, x29, w8, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_2488:
	/* 0x2488: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_248c:
	/* 0x248c: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2490:
	/* 0x2490: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2494:
	/* 0x2494: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2498:
	/* 0x2498: ldrh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_249c:
	/* 0x249c: add x2, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_24a0:
	/* 0x24a0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x24a4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_24a4:
	/* 0x24a4: tbnz x0, #63, 29e8 <generic_usdt_process_event+0x29e8> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x24a4, 0x29e8, arm64_l_29e8);
arm64_l_24a8:
	/* 0x24a8: ldrb w8, [x23, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_24ac:
	/* 0x24ac: cmp w8, #0x32; 0x24b0: b.gt 24d0 <generic_usdt_process_event+0x24d0> */
arm64_l_24b0:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50ULL, arm64_l_24d0);
arm64_l_24b4:
	/* 0x24b4: cbz w8, 24f0 <generic_usdt_process_event+0x24f0> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x24b4, 0x24f0, arm64_l_24f0);
arm64_l_24b8:
	/* 0x24b8: cmp w8, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_24bc:
	/* 0x24bc: b.eq 24f0 <generic_usdt_process_event+0x24f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x24bc, 0x24f0, arm64_l_24f0);
arm64_l_24c0:
	/* 0x24c0: cmp w8, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_24c4:
	/* 0x24c4: b.ne 25e0 <generic_usdt_process_event+0x25e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x24c4, 0x25e0, arm64_l_25e0);
arm64_l_24c8:
	/* 0x24c8: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_24cc:
	/* 0x24cc: b 252c <generic_usdt_process_event+0x252c> */
	ARM64_SIM_A64_JMP(0x24cc, 0x252c, arm64_l_252c);
arm64_l_24d0:
	/* 0x24d0: cmp w8, #0x33 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 51ULL);
arm64_l_24d4:
	/* 0x24d4: b.eq 2520 <generic_usdt_process_event+0x2520> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x24d4, 0x2520, arm64_l_2520);
arm64_l_24d8:
	/* 0x24d8: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_24dc:
	/* 0x24dc: b.eq 24f0 <generic_usdt_process_event+0x24f0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x24dc, 0x24f0, arm64_l_24f0);
arm64_l_24e0:
	/* 0x24e0: cmp w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_24e4:
	/* 0x24e4: b.ne 25e0 <generic_usdt_process_event+0x25e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x24e4, 0x25e0, arm64_l_25e0);
arm64_l_24e8:
	/* 0x24e8: mov w8, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 40ULL);
arm64_l_24ec:
	/* 0x24ec: b 252c <generic_usdt_process_event+0x252c> */
	ARM64_SIM_A64_JMP(0x24ec, 0x252c, arm64_l_252c);
arm64_l_24f0:
	/* 0x24f0: ldrb w8, [x23, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_24f4:
	/* 0x24f4: lsl w8, w8, #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_24f8:
	/* 0x24f8: b 2528 <generic_usdt_process_event+0x2528> */
	ARM64_SIM_A64_JMP(0x24f8, 0x2528, arm64_l_2528);
arm64_l_24fc:
	/* 0x24fc: ldrh w8, [x23, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_2500:
	/* 0x2500: ldrh w9, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2504:
	/* 0x2504: ldrb w22, [x23, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_2508:
	/* 0x2508: add w8, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_250c:
	/* 0x250c: cmp w22, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2510:
	/* 0x2510: strh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2514:
	/* 0x2514: b.ls 2464 <generic_usdt_process_event+0x2464> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2514, 0x2464, arm64_l_2464);
arm64_l_2518:
	/* 0x2518: strh w8, [sp, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_251c:
	/* 0x251c: b 29ec <generic_usdt_process_event+0x29ec> */
	ARM64_SIM_A64_JMP(0x251c, 0x29ec, arm64_l_29ec);
arm64_l_2520:
	/* 0x2520: ldrb w8, [x23, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_2524:
	/* 0x2524: lsl w8, w8, #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_2528:
	/* 0x2528: add w8, w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_252c:
	/* 0x252c: strh w8, [x23, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_2530:
	/* 0x2530: ldrh w9, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2534:
	/* 0x2534: ldrb w22, [x23, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_2538:
	/* 0x2538: add w8, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_253c:
	/* 0x253c: cmp w22, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2540:
	/* 0x2540: strh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2544:
	/* 0x2544: b.hi 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2544, 0x2ba4, arm64_l_2ba4);
arm64_l_2548:
	/* 0x2548: mov x10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 1ULL);
arm64_l_254c:
	/* 0x254c: mov w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2550:
	/* 0x2550: movk x10, #0x1800, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 6144ULL);
arm64_l_2554:
	/* 0x2554: lsl x9, x9, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2558:
	/* 0x2558: movk x10, #0x1008, lsl #48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 4104ULL);
arm64_l_255c:
	/* 0x255c: tst x9, x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2560:
	/* 0x2560: b.eq 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2560, 0x2ba4, arm64_l_2ba4);
arm64_l_2564:
	/* 0x2564: strb w22, [x23, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2568:
	/* 0x2568: add x8, x29, w8, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_256c:
	/* 0x256c: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2570:
	/* 0x2570: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2574:
	/* 0x2574: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2578:
	/* 0x2578: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_257c:
	/* 0x257c: ldrh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2580:
	/* 0x2580: add x2, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2584:
	/* 0x2584: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2588ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2588:
	/* 0x2588: tbnz x0, #63, 29e8 <generic_usdt_process_event+0x29e8> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x2588, 0x29e8, arm64_l_29e8);
arm64_l_258c:
	/* 0x258c: ldrb w8, [x23, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2590:
	/* 0x2590: cmp w8, #0x32; 0x2594: b.gt 25b4 <generic_usdt_process_event+0x25b4> */
arm64_l_2594:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50ULL, arm64_l_25b4);
arm64_l_2598:
	/* 0x2598: cbz w8, 25d4 <generic_usdt_process_event+0x25d4> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x2598, 0x25d4, arm64_l_25d4);
arm64_l_259c:
	/* 0x259c: cmp w8, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_25a0:
	/* 0x25a0: b.eq 25d4 <generic_usdt_process_event+0x25d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x25a0, 0x25d4, arm64_l_25d4);
arm64_l_25a4:
	/* 0x25a4: cmp w8, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_25a8:
	/* 0x25a8: b.ne 26c0 <generic_usdt_process_event+0x26c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x25a8, 0x26c0, arm64_l_26c0);
arm64_l_25ac:
	/* 0x25ac: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_25b0:
	/* 0x25b0: b 260c <generic_usdt_process_event+0x260c> */
	ARM64_SIM_A64_JMP(0x25b0, 0x260c, arm64_l_260c);
arm64_l_25b4:
	/* 0x25b4: cmp w8, #0x33 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 51ULL);
arm64_l_25b8:
	/* 0x25b8: b.eq 2600 <generic_usdt_process_event+0x2600> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x25b8, 0x2600, arm64_l_2600);
arm64_l_25bc:
	/* 0x25bc: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_25c0:
	/* 0x25c0: b.eq 25d4 <generic_usdt_process_event+0x25d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x25c0, 0x25d4, arm64_l_25d4);
arm64_l_25c4:
	/* 0x25c4: cmp w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_25c8:
	/* 0x25c8: b.ne 26c0 <generic_usdt_process_event+0x26c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x25c8, 0x26c0, arm64_l_26c0);
arm64_l_25cc:
	/* 0x25cc: mov w8, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 40ULL);
arm64_l_25d0:
	/* 0x25d0: b 260c <generic_usdt_process_event+0x260c> */
	ARM64_SIM_A64_JMP(0x25d0, 0x260c, arm64_l_260c);
arm64_l_25d4:
	/* 0x25d4: ldrb w8, [x23, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_25d8:
	/* 0x25d8: lsl w8, w8, #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_25dc:
	/* 0x25dc: b 2608 <generic_usdt_process_event+0x2608> */
	ARM64_SIM_A64_JMP(0x25dc, 0x2608, arm64_l_2608);
arm64_l_25e0:
	/* 0x25e0: ldrh w8, [x23, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_25e4:
	/* 0x25e4: ldrh w9, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_25e8:
	/* 0x25e8: ldrb w22, [x23, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_25ec:
	/* 0x25ec: add w8, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_25f0:
	/* 0x25f0: cmp w22, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_25f4:
	/* 0x25f4: strh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_25f8:
	/* 0x25f8: b.ls 2548 <generic_usdt_process_event+0x2548> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x25f8, 0x2548, arm64_l_2548);
arm64_l_25fc:
	/* 0x25fc: b 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JMP(0x25fc, 0x2ba4, arm64_l_2ba4);
arm64_l_2600:
	/* 0x2600: ldrb w8, [x23, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_2604:
	/* 0x2604: lsl w8, w8, #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_2608:
	/* 0x2608: add w8, w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_260c:
	/* 0x260c: strh w8, [x23, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_2610:
	/* 0x2610: ldrh w9, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2614:
	/* 0x2614: ldrb w22, [x23, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_2618:
	/* 0x2618: add w8, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_261c:
	/* 0x261c: cmp w22, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2620:
	/* 0x2620: strh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2624:
	/* 0x2624: b.hi 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2624, 0x2ba4, arm64_l_2ba4);
arm64_l_2628:
	/* 0x2628: mov x10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 1ULL);
arm64_l_262c:
	/* 0x262c: mov w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2630:
	/* 0x2630: movk x10, #0x1800, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 6144ULL);
arm64_l_2634:
	/* 0x2634: lsl x9, x9, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2638:
	/* 0x2638: movk x10, #0x1008, lsl #48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 4104ULL);
arm64_l_263c:
	/* 0x263c: tst x9, x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2640:
	/* 0x2640: b.eq 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2640, 0x2ba4, arm64_l_2ba4);
arm64_l_2644:
	/* 0x2644: strb w22, [x23, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2648:
	/* 0x2648: add x8, x29, w8, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_264c:
	/* 0x264c: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2650:
	/* 0x2650: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2654:
	/* 0x2654: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2658:
	/* 0x2658: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_265c:
	/* 0x265c: ldrh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2660:
	/* 0x2660: add x2, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2664:
	/* 0x2664: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2668ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2668:
	/* 0x2668: tbnz x0, #63, 29e8 <generic_usdt_process_event+0x29e8> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x2668, 0x29e8, arm64_l_29e8);
arm64_l_266c:
	/* 0x266c: ldrb w8, [x23, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2670:
	/* 0x2670: cmp w8, #0x32; 0x2674: b.gt 2694 <generic_usdt_process_event+0x2694> */
arm64_l_2674:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50ULL, arm64_l_2694);
arm64_l_2678:
	/* 0x2678: cbz w8, 26b4 <generic_usdt_process_event+0x26b4> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x2678, 0x26b4, arm64_l_26b4);
arm64_l_267c:
	/* 0x267c: cmp w8, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_2680:
	/* 0x2680: b.eq 26b4 <generic_usdt_process_event+0x26b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2680, 0x26b4, arm64_l_26b4);
arm64_l_2684:
	/* 0x2684: cmp w8, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_2688:
	/* 0x2688: b.ne 27a0 <generic_usdt_process_event+0x27a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2688, 0x27a0, arm64_l_27a0);
arm64_l_268c:
	/* 0x268c: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2690:
	/* 0x2690: b 26ec <generic_usdt_process_event+0x26ec> */
	ARM64_SIM_A64_JMP(0x2690, 0x26ec, arm64_l_26ec);
arm64_l_2694:
	/* 0x2694: cmp w8, #0x33 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 51ULL);
arm64_l_2698:
	/* 0x2698: b.eq 26e0 <generic_usdt_process_event+0x26e0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2698, 0x26e0, arm64_l_26e0);
arm64_l_269c:
	/* 0x269c: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_26a0:
	/* 0x26a0: b.eq 26b4 <generic_usdt_process_event+0x26b4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x26a0, 0x26b4, arm64_l_26b4);
arm64_l_26a4:
	/* 0x26a4: cmp w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_26a8:
	/* 0x26a8: b.ne 27a0 <generic_usdt_process_event+0x27a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x26a8, 0x27a0, arm64_l_27a0);
arm64_l_26ac:
	/* 0x26ac: mov w8, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 40ULL);
arm64_l_26b0:
	/* 0x26b0: b 26ec <generic_usdt_process_event+0x26ec> */
	ARM64_SIM_A64_JMP(0x26b0, 0x26ec, arm64_l_26ec);
arm64_l_26b4:
	/* 0x26b4: ldrb w8, [x23, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_26b8:
	/* 0x26b8: lsl w8, w8, #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_26bc:
	/* 0x26bc: b 26e8 <generic_usdt_process_event+0x26e8> */
	ARM64_SIM_A64_JMP(0x26bc, 0x26e8, arm64_l_26e8);
arm64_l_26c0:
	/* 0x26c0: ldrh w8, [x23, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_26c4:
	/* 0x26c4: ldrh w9, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_26c8:
	/* 0x26c8: ldrb w22, [x23, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_26cc:
	/* 0x26cc: add w8, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_26d0:
	/* 0x26d0: cmp w22, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_26d4:
	/* 0x26d4: strh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_26d8:
	/* 0x26d8: b.ls 2628 <generic_usdt_process_event+0x2628> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x26d8, 0x2628, arm64_l_2628);
arm64_l_26dc:
	/* 0x26dc: b 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JMP(0x26dc, 0x2ba4, arm64_l_2ba4);
arm64_l_26e0:
	/* 0x26e0: ldrb w8, [x23, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_26e4:
	/* 0x26e4: lsl w8, w8, #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_26e8:
	/* 0x26e8: add w8, w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_26ec:
	/* 0x26ec: strh w8, [x23, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_26f0:
	/* 0x26f0: ldrh w9, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_26f4:
	/* 0x26f4: ldrb w22, [x23, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_26f8:
	/* 0x26f8: add w8, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_26fc:
	/* 0x26fc: cmp w22, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2700:
	/* 0x2700: strh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2704:
	/* 0x2704: b.hi 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x2704, 0x2ba4, arm64_l_2ba4);
arm64_l_2708:
	/* 0x2708: mov x10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 1ULL);
arm64_l_270c:
	/* 0x270c: mov w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2710:
	/* 0x2710: movk x10, #0x1800, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 6144ULL);
arm64_l_2714:
	/* 0x2714: lsl x9, x9, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_2718:
	/* 0x2718: movk x10, #0x1008, lsl #48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 4104ULL);
arm64_l_271c:
	/* 0x271c: tst x9, x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2720:
	/* 0x2720: b.eq 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2720, 0x2ba4, arm64_l_2ba4);
arm64_l_2724:
	/* 0x2724: strb w22, [x23, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2728:
	/* 0x2728: add x8, x29, w8, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_272c:
	/* 0x272c: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2730:
	/* 0x2730: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2734:
	/* 0x2734: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2738:
	/* 0x2738: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_273c:
	/* 0x273c: ldrh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2740:
	/* 0x2740: add x2, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2744:
	/* 0x2744: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2748ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2748:
	/* 0x2748: tbnz x0, #63, 29e8 <generic_usdt_process_event+0x29e8> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x2748, 0x29e8, arm64_l_29e8);
arm64_l_274c:
	/* 0x274c: ldrb w8, [x23, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2750:
	/* 0x2750: cmp w8, #0x32; 0x2754: b.gt 2774 <generic_usdt_process_event+0x2774> */
arm64_l_2754:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50ULL, arm64_l_2774);
arm64_l_2758:
	/* 0x2758: cbz w8, 2794 <generic_usdt_process_event+0x2794> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x2758, 0x2794, arm64_l_2794);
arm64_l_275c:
	/* 0x275c: cmp w8, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_2760:
	/* 0x2760: b.eq 2794 <generic_usdt_process_event+0x2794> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2760, 0x2794, arm64_l_2794);
arm64_l_2764:
	/* 0x2764: cmp w8, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_2768:
	/* 0x2768: b.ne 2880 <generic_usdt_process_event+0x2880> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2768, 0x2880, arm64_l_2880);
arm64_l_276c:
	/* 0x276c: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2770:
	/* 0x2770: b 27cc <generic_usdt_process_event+0x27cc> */
	ARM64_SIM_A64_JMP(0x2770, 0x27cc, arm64_l_27cc);
arm64_l_2774:
	/* 0x2774: cmp w8, #0x33 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 51ULL);
arm64_l_2778:
	/* 0x2778: b.eq 27c0 <generic_usdt_process_event+0x27c0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2778, 0x27c0, arm64_l_27c0);
arm64_l_277c:
	/* 0x277c: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2780:
	/* 0x2780: b.eq 2794 <generic_usdt_process_event+0x2794> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2780, 0x2794, arm64_l_2794);
arm64_l_2784:
	/* 0x2784: cmp w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_2788:
	/* 0x2788: b.ne 2880 <generic_usdt_process_event+0x2880> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2788, 0x2880, arm64_l_2880);
arm64_l_278c:
	/* 0x278c: mov w8, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 40ULL);
arm64_l_2790:
	/* 0x2790: b 27cc <generic_usdt_process_event+0x27cc> */
	ARM64_SIM_A64_JMP(0x2790, 0x27cc, arm64_l_27cc);
arm64_l_2794:
	/* 0x2794: ldrb w8, [x23, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_2798:
	/* 0x2798: lsl w8, w8, #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_279c:
	/* 0x279c: b 27c8 <generic_usdt_process_event+0x27c8> */
	ARM64_SIM_A64_JMP(0x279c, 0x27c8, arm64_l_27c8);
arm64_l_27a0:
	/* 0x27a0: ldrh w8, [x23, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_27a4:
	/* 0x27a4: ldrh w9, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_27a8:
	/* 0x27a8: ldrb w22, [x23, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_27ac:
	/* 0x27ac: add w8, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_27b0:
	/* 0x27b0: cmp w22, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_27b4:
	/* 0x27b4: strh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_27b8:
	/* 0x27b8: b.ls 2708 <generic_usdt_process_event+0x2708> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x27b8, 0x2708, arm64_l_2708);
arm64_l_27bc:
	/* 0x27bc: b 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JMP(0x27bc, 0x2ba4, arm64_l_2ba4);
arm64_l_27c0:
	/* 0x27c0: ldrb w8, [x23, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_27c4:
	/* 0x27c4: lsl w8, w8, #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_27c8:
	/* 0x27c8: add w8, w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_27cc:
	/* 0x27cc: strh w8, [x23, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_27d0:
	/* 0x27d0: ldrh w9, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_27d4:
	/* 0x27d4: ldrb w22, [x23, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_27d8:
	/* 0x27d8: add w8, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_27dc:
	/* 0x27dc: cmp w22, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_27e0:
	/* 0x27e0: strh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_27e4:
	/* 0x27e4: b.hi 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x27e4, 0x2ba4, arm64_l_2ba4);
arm64_l_27e8:
	/* 0x27e8: mov x10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 1ULL);
arm64_l_27ec:
	/* 0x27ec: mov w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_27f0:
	/* 0x27f0: movk x10, #0x1800, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 6144ULL);
arm64_l_27f4:
	/* 0x27f4: lsl x9, x9, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_27f8:
	/* 0x27f8: movk x10, #0x1008, lsl #48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 4104ULL);
arm64_l_27fc:
	/* 0x27fc: tst x9, x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2800:
	/* 0x2800: b.eq 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2800, 0x2ba4, arm64_l_2ba4);
arm64_l_2804:
	/* 0x2804: strb w22, [x23, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2808:
	/* 0x2808: add x8, x29, w8, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_280c:
	/* 0x280c: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2810:
	/* 0x2810: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2814:
	/* 0x2814: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2818:
	/* 0x2818: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_281c:
	/* 0x281c: ldrh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2820:
	/* 0x2820: add x2, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2824:
	/* 0x2824: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2828ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2828:
	/* 0x2828: tbnz x0, #63, 29e8 <generic_usdt_process_event+0x29e8> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x2828, 0x29e8, arm64_l_29e8);
arm64_l_282c:
	/* 0x282c: ldrb w8, [x23, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2830:
	/* 0x2830: cmp w8, #0x32; 0x2834: b.gt 2854 <generic_usdt_process_event+0x2854> */
arm64_l_2834:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50ULL, arm64_l_2854);
arm64_l_2838:
	/* 0x2838: cbz w8, 2874 <generic_usdt_process_event+0x2874> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x2838, 0x2874, arm64_l_2874);
arm64_l_283c:
	/* 0x283c: cmp w8, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_2840:
	/* 0x2840: b.eq 2874 <generic_usdt_process_event+0x2874> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2840, 0x2874, arm64_l_2874);
arm64_l_2844:
	/* 0x2844: cmp w8, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_2848:
	/* 0x2848: b.ne 2960 <generic_usdt_process_event+0x2960> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2848, 0x2960, arm64_l_2960);
arm64_l_284c:
	/* 0x284c: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2850:
	/* 0x2850: b 28ac <generic_usdt_process_event+0x28ac> */
	ARM64_SIM_A64_JMP(0x2850, 0x28ac, arm64_l_28ac);
arm64_l_2854:
	/* 0x2854: cmp w8, #0x33 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 51ULL);
arm64_l_2858:
	/* 0x2858: b.eq 28a0 <generic_usdt_process_event+0x28a0> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2858, 0x28a0, arm64_l_28a0);
arm64_l_285c:
	/* 0x285c: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2860:
	/* 0x2860: b.eq 2874 <generic_usdt_process_event+0x2874> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2860, 0x2874, arm64_l_2874);
arm64_l_2864:
	/* 0x2864: cmp w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_2868:
	/* 0x2868: b.ne 2960 <generic_usdt_process_event+0x2960> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2868, 0x2960, arm64_l_2960);
arm64_l_286c:
	/* 0x286c: mov w8, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 40ULL);
arm64_l_2870:
	/* 0x2870: b 28ac <generic_usdt_process_event+0x28ac> */
	ARM64_SIM_A64_JMP(0x2870, 0x28ac, arm64_l_28ac);
arm64_l_2874:
	/* 0x2874: ldrb w8, [x23, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_2878:
	/* 0x2878: lsl w8, w8, #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_287c:
	/* 0x287c: b 28a8 <generic_usdt_process_event+0x28a8> */
	ARM64_SIM_A64_JMP(0x287c, 0x28a8, arm64_l_28a8);
arm64_l_2880:
	/* 0x2880: ldrh w8, [x23, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_2884:
	/* 0x2884: ldrh w9, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2888:
	/* 0x2888: ldrb w22, [x23, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_288c:
	/* 0x288c: add w8, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2890:
	/* 0x2890: cmp w22, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2894:
	/* 0x2894: strh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2898:
	/* 0x2898: b.ls 27e8 <generic_usdt_process_event+0x27e8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2898, 0x27e8, arm64_l_27e8);
arm64_l_289c:
	/* 0x289c: b 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JMP(0x289c, 0x2ba4, arm64_l_2ba4);
arm64_l_28a0:
	/* 0x28a0: ldrb w8, [x23, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_28a4:
	/* 0x28a4: lsl w8, w8, #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_28a8:
	/* 0x28a8: add w8, w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_28ac:
	/* 0x28ac: strh w8, [x23, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_28b0:
	/* 0x28b0: ldrh w9, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_28b4:
	/* 0x28b4: ldrb w22, [x23, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_28b8:
	/* 0x28b8: add w8, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_28bc:
	/* 0x28bc: cmp w22, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_28c0:
	/* 0x28c0: strh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_28c4:
	/* 0x28c4: b.hi 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x28c4, 0x2ba4, arm64_l_2ba4);
arm64_l_28c8:
	/* 0x28c8: mov x10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 1ULL);
arm64_l_28cc:
	/* 0x28cc: mov w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_28d0:
	/* 0x28d0: movk x10, #0x1800, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 6144ULL);
arm64_l_28d4:
	/* 0x28d4: lsl x9, x9, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_28d8:
	/* 0x28d8: movk x10, #0x1008, lsl #48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 4104ULL);
arm64_l_28dc:
	/* 0x28dc: tst x9, x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_28e0:
	/* 0x28e0: b.eq 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x28e0, 0x2ba4, arm64_l_2ba4);
arm64_l_28e4:
	/* 0x28e4: strb w22, [x23, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_28e8:
	/* 0x28e8: add x8, x29, w8, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_28ec:
	/* 0x28ec: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_28f0:
	/* 0x28f0: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_28f4:
	/* 0x28f4: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_28f8:
	/* 0x28f8: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_28fc:
	/* 0x28fc: ldrh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2900:
	/* 0x2900: add x2, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2904:
	/* 0x2904: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2908ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2908:
	/* 0x2908: tbnz x0, #63, 29e8 <generic_usdt_process_event+0x29e8> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 63, 0x2908, 0x29e8, arm64_l_29e8);
arm64_l_290c:
	/* 0x290c: ldrb w8, [x23, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_2910:
	/* 0x2910: cmp w8, #0x32; 0x2914: b.gt 2934 <generic_usdt_process_event+0x2934> */
arm64_l_2914:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 50ULL, arm64_l_2934);
arm64_l_2918:
	/* 0x2918: cbz w8, 2954 <generic_usdt_process_event+0x2954> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x2918, 0x2954, arm64_l_2954);
arm64_l_291c:
	/* 0x291c: cmp w8, #0x2b */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 43ULL);
arm64_l_2920:
	/* 0x2920: b.eq 2954 <generic_usdt_process_event+0x2954> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2920, 0x2954, arm64_l_2954);
arm64_l_2924:
	/* 0x2924: cmp w8, #0x2c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 44ULL);
arm64_l_2928:
	/* 0x2928: b.ne 2b88 <generic_usdt_process_event+0x2b88> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2928, 0x2b88, arm64_l_2b88);
arm64_l_292c:
	/* 0x292c: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2930:
	/* 0x2930: b 298c <generic_usdt_process_event+0x298c> */
	ARM64_SIM_A64_JMP(0x2930, 0x298c, arm64_l_298c);
arm64_l_2934:
	/* 0x2934: cmp w8, #0x33 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 51ULL);
arm64_l_2938:
	/* 0x2938: b.eq 2980 <generic_usdt_process_event+0x2980> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2938, 0x2980, arm64_l_2980);
arm64_l_293c:
	/* 0x293c: cmp w8, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2940:
	/* 0x2940: b.eq 2954 <generic_usdt_process_event+0x2954> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2940, 0x2954, arm64_l_2954);
arm64_l_2944:
	/* 0x2944: cmp w8, #0xff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 255ULL);
arm64_l_2948:
	/* 0x2948: b.ne 2b88 <generic_usdt_process_event+0x2b88> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2948, 0x2b88, arm64_l_2b88);
arm64_l_294c:
	/* 0x294c: mov w8, #0x28 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 40ULL);
arm64_l_2950:
	/* 0x2950: b 298c <generic_usdt_process_event+0x298c> */
	ARM64_SIM_A64_JMP(0x2950, 0x298c, arm64_l_298c);
arm64_l_2954:
	/* 0x2954: ldrb w8, [x23, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_2958:
	/* 0x2958: lsl w8, w8, #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 3ULL);
arm64_l_295c:
	/* 0x295c: b 2988 <generic_usdt_process_event+0x2988> */
	ARM64_SIM_A64_JMP(0x295c, 0x2988, arm64_l_2988);
arm64_l_2960:
	/* 0x2960: ldrh w8, [x23, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_2964:
	/* 0x2964: ldrh w9, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2968:
	/* 0x2968: ldrb w22, [x23, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_296c:
	/* 0x296c: add w8, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2970:
	/* 0x2970: cmp w22, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2974:
	/* 0x2974: strh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2978:
	/* 0x2978: b.ls 28c8 <generic_usdt_process_event+0x28c8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2978, 0x28c8, arm64_l_28c8);
arm64_l_297c:
	/* 0x297c: b 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JMP(0x297c, 0x2ba4, arm64_l_2ba4);
arm64_l_2980:
	/* 0x2980: ldrb w8, [x23, #7] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 7ULL);
arm64_l_2984:
	/* 0x2984: lsl w8, w8, #2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 2ULL);
arm64_l_2988:
	/* 0x2988: add w8, w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_298c:
	/* 0x298c: strh w8, [x23, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_2990:
	/* 0x2990: ldrh w9, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2994:
	/* 0x2994: ldrb w22, [x23, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_2998:
	/* 0x2998: add w8, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_299c:
	/* 0x299c: cmp w22, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_29a0:
	/* 0x29a0: strh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_29a4:
	/* 0x29a4: b.hi 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x29a4, 0x2ba4, arm64_l_2ba4);
arm64_l_29a8:
	/* 0x29a8: mov x10, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 1ULL);
arm64_l_29ac:
	/* 0x29ac: mov w9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_29b0:
	/* 0x29b0: movk x10, #0x1800, lsl #32 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(32), 6144ULL);
arm64_l_29b4:
	/* 0x29b4: lsl x9, x9, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_REG, ARM64_X9, ARM64_X9, ARM64_X22, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_SHIFT(ARM64_SHIFT_LSL), 0);
arm64_l_29b8:
	/* 0x29b8: movk x10, #0x1008, lsl #48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(48), 4104ULL);
arm64_l_29bc:
	/* 0x29bc: tst x9, x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_TST_REG, ARM64_X9, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_29c0:
	/* 0x29c0: b.eq 2ba4 <generic_usdt_process_event+0x2ba4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x29c0, 0x2ba4, arm64_l_2ba4);
arm64_l_29c4:
	/* 0x29c4: strb w22, [x23, #5] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 5ULL);
arm64_l_29c8:
	/* 0x29c8: add x8, x29, w8, uxth */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_UXTH, 0), 0);
arm64_l_29cc:
	/* 0x29cc: mov w9, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_29d0:
	/* 0x29d0: mov w10, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X10, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_29d4:
	/* 0x29d4: mov x0, x24 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_29d8:
	/* 0x29d8: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_29dc:
	/* 0x29dc: ldrh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_29e0:
	/* 0x29e0: add x2, x29, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_29e4:
	/* 0x29e4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x29e8ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_29e8:
	/* 0x29e8: mov w22, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_29ec:
	/* 0x29ec: ldr x29, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_29f0:
	/* 0x29f0: mov w8, #0xa */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 10ULL);
arm64_l_29f4:
	/* 0x29f4: strb w22, [sp, #132] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 132ULL);
arm64_l_29f8:
	/* 0x29f8: add x2, x21, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 8ULL);
arm64_l_29fc:
	/* 0x29fc: mov w23, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2a00:
	/* 0x2a00: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2a04:
	/* 0x2a04: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2a08:
	/* 0x2a08: strh w22, [x29, #36] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 36ULL);
arm64_l_2a0c:
	/* 0x2a0c: strh w8, [x29, #38] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X29, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 38ULL);
arm64_l_2a10:
	/* 0x2a10: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2a14:
	/* 0x2a14: mov x0, x29 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2a18:
	/* 0x2a18: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2a1cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2a1c:
	/* 0x2a1c: add x0, x29, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_2a20:
	/* 0x2a20: add x2, x21, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 24ULL);
arm64_l_2a24:
	/* 0x2a24: mov w1, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 16ULL);
arm64_l_2a28:
	/* 0x2a28: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2a2cULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2a2c:
	/* 0x2a2c: cmp w22, #0x11 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 17ULL);
arm64_l_2a30:
	/* 0x2a30: b.eq 2a74 <generic_usdt_process_event+0x2a74> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2a30, 0x2a74, arm64_l_2a74);
arm64_l_2a34:
	/* 0x2a34: cmp w22, #0x6 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 6ULL);
arm64_l_2a38:
	/* 0x2a38: b.ne 2ab4 <generic_usdt_process_event+0x2ab4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2a38, 0x2ab4, arm64_l_2ab4);
arm64_l_2a3c:
	/* 0x2a3c: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_2a40:
	/* 0x2a40: ldrh w9, [sp, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_2a44:
	/* 0x2a44: mov w23, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2a48:
	/* 0x2a48: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2a4c:
	/* 0x2a4c: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2a50:
	/* 0x2a50: add x22, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2a54:
	/* 0x2a54: ldr x29, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2a58:
	/* 0x2a58: add x0, x29, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2a5c:
	/* 0x2a5c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2a60:
	/* 0x2a60: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2a64:
	/* 0x2a64: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2a68ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2a68:
	/* 0x2a68: add x0, x29, #0x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 34ULL);
arm64_l_2a6c:
	/* 0x2a6c: add x2, x22, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2a70:
	/* 0x2a70: b 2aa8 <generic_usdt_process_event+0x2aa8> */
	ARM64_SIM_A64_JMP(0x2a70, 0x2aa8, arm64_l_2aa8);
arm64_l_2a74:
	/* 0x2a74: ldr x8, [sp, #152] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 152ULL);
arm64_l_2a78:
	/* 0x2a78: ldrh w9, [sp, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_2a7c:
	/* 0x2a7c: mov w23, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2a80:
	/* 0x2a80: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2a84:
	/* 0x2a84: mov w24, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2a88:
	/* 0x2a88: add x22, x8, x9 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X22, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2a8c:
	/* 0x2a8c: ldr x29, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X29, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2a90:
	/* 0x2a90: add x0, x29, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2a94:
	/* 0x2a94: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2a98:
	/* 0x2a98: mov x2, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2a9c:
	/* 0x2a9c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2aa0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2aa0:
	/* 0x2aa0: add x0, x29, #0x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 34ULL);
arm64_l_2aa4:
	/* 0x2aa4: add x2, x22, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 2ULL);
arm64_l_2aa8:
	/* 0x2aa8: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_2aac:
	/* 0x2aac: blr x24 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X24);
		if (ARM64_SIM_L_REG_TAG(ARM64_X24) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2ab0ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2ab0:
	/* 0x2ab0: b 2abc <generic_usdt_process_event+0x2abc> */
	ARM64_SIM_A64_JMP(0x2ab0, 0x2abc, arm64_l_2abc);
arm64_l_2ab4:
	/* 0x2ab4: ldr x8, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2ab8:
	/* 0x2ab8: str wzr, [x8, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2abc:
	/* 0x2abc: ldr x9, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2ac0:
	/* 0x2ac0: add x2, x25, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X25, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_2ac4:
	/* 0x2ac4: add x10, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_2ac8:
	/* 0x2ac8: add x0, sp, #0xf0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 240ULL);
arm64_l_2acc:
	/* 0x2acc: ldrh w8, [x9, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2ad0:
	/* 0x2ad0: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2ad4:
	/* 0x2ad4: rev w8, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_REV, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2ad8:
	/* 0x2ad8: lsr w8, w8, #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 16ULL);
arm64_l_2adc:
	/* 0x2adc: strh w8, [x9, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2ae0:
	/* 0x2ae0: ldrh w8, [x9, #34] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 34ULL);
arm64_l_2ae4:
	/* 0x2ae4: rev w8, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_REV, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2ae8:
	/* 0x2ae8: lsr w8, w8, #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SHIFT_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_SHIFT(ARM64_SHIFT_LSR), 16ULL);
arm64_l_2aec:
	/* 0x2aec: strh w8, [x9, #34] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 34ULL);
arm64_l_2af0:
	/* 0x2af0: mov w8, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2af4:
	/* 0x2af4: mov w9, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2af8:
	/* 0x2af8: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2afcULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2afc:
	/* 0x2afc: add x8, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_2b00:
	/* 0x2b00: ldr x8, [x8, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2b04:
	/* 0x2b04: cbz x8, 2b68 <generic_usdt_process_event+0x2b68> */
	ARM64_SIM_A64_CBZ(ARM64_X8, 0x2b04, 0x2b68, arm64_l_2b68);
arm64_l_2b08:
	/* 0x2b08: add x8, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2b0c:
	/* 0x2b0c: mov w9, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2b10:
	/* 0x2b10: add x10, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X10, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_2b14:
	/* 0x2b14: mov w11, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X11, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2b18:
	/* 0x2b18: add x21, sp, #0xe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 224ULL);
arm64_l_2b1c:
	/* 0x2b1c: ldr x8, [x21, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2b20:
	/* 0x2b20: add x0, sp, #0x100 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 256ULL);
arm64_l_2b24:
	/* 0x2b24: mov w1, #0x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 8ULL);
arm64_l_2b28:
	/* 0x2b28: mov w22, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2b2c:
	/* 0x2b2c: add x2, x8, #0x5 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 5ULL);
arm64_l_2b30:
	/* 0x2b30: blr x11 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X11);
		if (ARM64_SIM_L_REG_TAG(ARM64_X11) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2b34ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2b34:
	/* 0x2b34: ldr x8, [x21, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2b38:
	/* 0x2b38: ldr x9, [x21, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2b3c:
	/* 0x2b3c: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2b40:
	/* 0x2b40: add x23, x8, x9, lsl #3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_LSL, 3), 0);
arm64_l_2b44:
	/* 0x2b44: ldr x24, [sp, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X24, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2b48:
	/* 0x2b48: add x0, x24, #0x38 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 56ULL);
arm64_l_2b4c:
	/* 0x2b4c: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2b50:
	/* 0x2b50: add x2, x23, #0x44 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 68ULL);
arm64_l_2b54:
	/* 0x2b54: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2b58ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2b58:
	/* 0x2b58: add x0, x24, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X24, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2b5c:
	/* 0x2b5c: add x2, x23, #0x45 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X2, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 69ULL);
arm64_l_2b60:
	/* 0x2b60: mov w1, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2b64:
	/* 0x2b64: blr x22 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X22);
		if (ARM64_SIM_L_REG_TAG(ARM64_X22) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2b68ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2b68:
	/* 0x2b68: mov w13, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X13, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 64ULL);
arm64_l_2b6c:
	/* 0x2b6c: ldp x10, x11, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X10, ARM64_X11, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2b70:
	/* 0x2b70: mov w29, #0x5efc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X29, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24316ULL);
arm64_l_2b74:
	/* 0x2b74: mov w9, #0x5ea0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24224ULL);
arm64_l_2b78:
	/* 0x2b78: adrp x21, 0 <process_call_heap> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&process_call_heap_6));
arm64_l_2b7c:
	/* 0x2b7c: ldr x21, [x21] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X21, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b80:
	/* 0x2b80: ldr x19, [sp, #64] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 64ULL);
arm64_l_2b84:
	/* 0x2b84: b c1c <generic_usdt_process_event+0xc1c> */
	ARM64_SIM_A64_JMP(0x2b84, 0xc1c, arm64_l_c1c);
arm64_l_2b88:
	/* 0x2b88: ldrh w8, [x23, #2] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 2ULL);
arm64_l_2b8c:
	/* 0x2b8c: ldrh w9, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2b90:
	/* 0x2b90: ldrb w22, [x23, #6] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X22, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 6ULL);
arm64_l_2b94:
	/* 0x2b94: add w8, w9, w8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2b98:
	/* 0x2b98: cmp w22, #0x3c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 60ULL);
arm64_l_2b9c:
	/* 0x2b9c: strh w8, [x23] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2ba0:
	/* 0x2ba0: b.ls 29a8 <generic_usdt_process_event+0x29a8> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x2ba0, 0x29a8, arm64_l_29a8);
arm64_l_2ba4:
	/* 0x2ba4: strh w8, [sp, #136] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_16, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 136ULL);
arm64_l_2ba8:
	/* 0x2ba8: b 29ec <generic_usdt_process_event+0x29ec> */
	ARM64_SIM_A64_JMP(0x2ba8, 0x29ec, arm64_l_29ec);
arm64_l_2bac:
	/* 0x2bac: str x30, [sp, #-64]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551552ULL);
arm64_l_2bb0:
	/* 0x2bb0: stp x24, x23, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2bb4:
	/* 0x2bb4: stp x22, x21, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2bb8:
	/* 0x2bb8: stp x20, x19, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2bbc:
	/* 0x2bbc: mov x22, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2bc0:
	/* 0x2bc0: str wzr, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_2bc4:
	/* 0x2bc4: adrp x0, 0 <data_heap> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&data_heap_4));
arm64_l_2bc8:
	/* 0x2bc8: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2bcc:
	/* 0x2bcc: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2bd0:
	/* 0x2bd0: add x9, sp, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2bd4:
	/* 0x2bd4: mov x19, x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2bd8:
	/* 0x2bd8: add x1, sp, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2bdc:
	/* 0x2bdc: mov x20, x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X3, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2be0:
	/* 0x2be0: mov x21, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2be4:
	/* 0x2be4: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2be8ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2be8:
	/* 0x2be8: cbz x0, 2c6c <data_event_bytes+0xc0> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2be8, 0x2c6c, arm64_l_2c6c);
arm64_l_2bec:
	/* 0x2bec: mov w8, #0x18 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 24ULL);
arm64_l_2bf0:
	/* 0x2bf0: mov x23, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2bf4:
	/* 0x2bf4: str w8, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X0, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2bf8:
	/* 0x2bf8: mov w8, #0xe */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 14ULL);
arm64_l_2bfc:
	/* 0x2bfc: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 14ULL: ARM64_SIM_A64_LINK(0x2c00ULL); ARM64_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2c00:
	/* 0x2c00: mov x24, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X24, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2c04:
	/* 0x2c04: cmn x0, #0x16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 22ULL);
arm64_l_2c08:
	/* 0x2c08: str x0, [x24, #16]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 16ULL);
arm64_l_2c0c:
	/* 0x2c0c: b.ne 2c18 <data_event_bytes+0x6c> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2c0c, 0x2c18, arm64_l_2c18);
arm64_l_2c10:
	/* 0x2c10: ldr x8, [x22, #232] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 232ULL);
arm64_l_2c14:
	/* 0x2c14: str x8, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X24, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c18:
	/* 0x2c18: mov w8, #0x7d */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 125ULL);
arm64_l_2c1c:
	/* 0x2c1c: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 125ULL: ARM64_SIM_A64_LINK(0x2c20ULL); ARM64_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2c20:
	/* 0x2c20: str x0, [x23, #24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 24ULL);
arm64_l_2c24:
	/* 0x2c24: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2c28:
	/* 0x2c28: mov x1, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X23, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2c2c:
	/* 0x2c2c: mov x2, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2c30:
	/* 0x2c30: ldp x8, x9, [x24] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X8, ARM64_X9, ARM64_X24, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c34:
	/* 0x2c34: mov x3, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2c38:
	/* 0x2c38: stp x8, x9, [x19, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X19, ARM64_X8, ARM64_X9, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2c3c:
	/* 0x2c3c: bl 2c80 <do_bytes> */
	ARM64_SIM_A64_CALL(arm64_l_2c80, 0x2c40ULL);
arm64_l_2c40:
	/* 0x2c40: tbnz w0, #31, 2c58 <data_event_bytes+0xac> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2c40, 0x2c58, arm64_l_2c58);
arm64_l_2c44:
	/* 0x2c44: sub w8, w20, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X8, ARM64_X20, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 0);
arm64_l_2c48:
	/* 0x2c48: cmn x20, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 1ULL);
arm64_l_2c4c:
	/* 0x2c4c: str xzr, [x19] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X19, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c50:
	/* 0x2c50: csel w8, wzr, w8, eq */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X8, ARM64_XZR, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_COND_EQ, 0);
arm64_l_2c54:
	/* 0x2c54: b 2c64 <data_event_bytes+0xb8> */
	ARM64_SIM_A64_JMP(0x2c54, 0x2c64, arm64_l_2c64);
arm64_l_2c58:
	/* 0x2c58: mov w8, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X8, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2c5c:
	/* 0x2c5c: stp w0, wzr, [x19] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X19, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2c60:
	/* 0x2c60: mov w0, wzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2c64:
	/* 0x2c64: stp w8, w0, [x19, #8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_X19, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_2c68:
	/* 0x2c68: mov w0, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 32ULL);
arm64_l_2c6c:
	/* 0x2c6c: ldp x20, x19, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2c70:
	/* 0x2c70: ldp x22, x21, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2c74:
	/* 0x2c74: ldp x24, x23, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X24, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2c78:
	/* 0x2c78: ldr x30, [sp], #64 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 64ULL);
arm64_l_2c7c:
	/* 0x2c7c: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_2c7c);
arm64_l_2c80:
	/* 0x2c80: sub sp, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_2c84:
	/* 0x2c84: stp x30, x23, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X30, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2c88:
	/* 0x2c88: stp x22, x21, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2c8c:
	/* 0x2c8c: stp x20, x19, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2c90:
	/* 0x2c90: mov x19, x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X19, ARM64_X3, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2c94:
	/* 0x2c94: mov x21, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X21, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2c98:
	/* 0x2c98: mov x20, x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2c9c:
	/* 0x2c9c: mov x22, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2ca0:
	/* 0x2ca0: bl 2ec0 <__do_bytes> */
	ARM64_SIM_A64_CALL(arm64_l_2ec0, 0x2ca4ULL);
arm64_l_2ca4:
	/* 0x2ca4: tbnz w0, #31, 2e08 <do_bytes+0x188> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2ca4, 0x2e08, arm64_l_2e08);
arm64_l_2ca8:
	/* 0x2ca8: and x23, x0, #0x7fffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X23, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2147483647ULL);
arm64_l_2cac:
	/* 0x2cac: subs x3, x19, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X3, ARM64_X19, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2cb0:
	/* 0x2cb0: b.eq 2ea8 <do_bytes+0x228> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2cb0, 0x2ea8, arm64_l_2ea8);
arm64_l_2cb4:
	/* 0x2cb4: add x2, x23, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2cb8:
	/* 0x2cb8: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2cbc:
	/* 0x2cbc: mov x1, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2cc0:
	/* 0x2cc0: bl 2ec0 <__do_bytes> */
	ARM64_SIM_A64_CALL(arm64_l_2ec0, 0x2cc4ULL);
arm64_l_2cc4:
	/* 0x2cc4: tbnz w0, #31, 2e08 <do_bytes+0x188> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2cc4, 0x2e08, arm64_l_2e08);
arm64_l_2cc8:
	/* 0x2cc8: and x8, x0, #0x7fffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2147483647ULL);
arm64_l_2ccc:
	/* 0x2ccc: add x23, x8, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2cd0:
	/* 0x2cd0: subs x3, x19, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X3, ARM64_X19, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2cd4:
	/* 0x2cd4: b.eq 2ea8 <do_bytes+0x228> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2cd4, 0x2ea8, arm64_l_2ea8);
arm64_l_2cd8:
	/* 0x2cd8: add x2, x23, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2cdc:
	/* 0x2cdc: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2ce0:
	/* 0x2ce0: mov x1, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2ce4:
	/* 0x2ce4: bl 2ec0 <__do_bytes> */
	ARM64_SIM_A64_CALL(arm64_l_2ec0, 0x2ce8ULL);
arm64_l_2ce8:
	/* 0x2ce8: tbnz w0, #31, 2e08 <do_bytes+0x188> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2ce8, 0x2e08, arm64_l_2e08);
arm64_l_2cec:
	/* 0x2cec: and x8, x0, #0x7fffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2147483647ULL);
arm64_l_2cf0:
	/* 0x2cf0: add x23, x8, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2cf4:
	/* 0x2cf4: subs x3, x19, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X3, ARM64_X19, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2cf8:
	/* 0x2cf8: b.eq 2ea8 <do_bytes+0x228> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2cf8, 0x2ea8, arm64_l_2ea8);
arm64_l_2cfc:
	/* 0x2cfc: add x2, x23, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2d00:
	/* 0x2d00: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d04:
	/* 0x2d04: mov x1, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d08:
	/* 0x2d08: bl 2ec0 <__do_bytes> */
	ARM64_SIM_A64_CALL(arm64_l_2ec0, 0x2d0cULL);
arm64_l_2d0c:
	/* 0x2d0c: tbnz w0, #31, 2e08 <do_bytes+0x188> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2d0c, 0x2e08, arm64_l_2e08);
arm64_l_2d10:
	/* 0x2d10: and x8, x0, #0x7fffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2147483647ULL);
arm64_l_2d14:
	/* 0x2d14: add x23, x8, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2d18:
	/* 0x2d18: subs x3, x19, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X3, ARM64_X19, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d1c:
	/* 0x2d1c: b.eq 2ea8 <do_bytes+0x228> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2d1c, 0x2ea8, arm64_l_2ea8);
arm64_l_2d20:
	/* 0x2d20: add x2, x23, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2d24:
	/* 0x2d24: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d28:
	/* 0x2d28: mov x1, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d2c:
	/* 0x2d2c: bl 2ec0 <__do_bytes> */
	ARM64_SIM_A64_CALL(arm64_l_2ec0, 0x2d30ULL);
arm64_l_2d30:
	/* 0x2d30: tbnz w0, #31, 2e08 <do_bytes+0x188> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2d30, 0x2e08, arm64_l_2e08);
arm64_l_2d34:
	/* 0x2d34: and x8, x0, #0x7fffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2147483647ULL);
arm64_l_2d38:
	/* 0x2d38: add x23, x8, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2d3c:
	/* 0x2d3c: subs x3, x19, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X3, ARM64_X19, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d40:
	/* 0x2d40: b.eq 2ea8 <do_bytes+0x228> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2d40, 0x2ea8, arm64_l_2ea8);
arm64_l_2d44:
	/* 0x2d44: add x2, x23, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2d48:
	/* 0x2d48: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d4c:
	/* 0x2d4c: mov x1, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d50:
	/* 0x2d50: bl 2ec0 <__do_bytes> */
	ARM64_SIM_A64_CALL(arm64_l_2ec0, 0x2d54ULL);
arm64_l_2d54:
	/* 0x2d54: tbnz w0, #31, 2e08 <do_bytes+0x188> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2d54, 0x2e08, arm64_l_2e08);
arm64_l_2d58:
	/* 0x2d58: and x8, x0, #0x7fffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2147483647ULL);
arm64_l_2d5c:
	/* 0x2d5c: add x23, x8, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2d60:
	/* 0x2d60: subs x3, x19, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X3, ARM64_X19, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d64:
	/* 0x2d64: b.eq 2ea8 <do_bytes+0x228> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2d64, 0x2ea8, arm64_l_2ea8);
arm64_l_2d68:
	/* 0x2d68: add x2, x23, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2d6c:
	/* 0x2d6c: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d70:
	/* 0x2d70: mov x1, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d74:
	/* 0x2d74: bl 2ec0 <__do_bytes> */
	ARM64_SIM_A64_CALL(arm64_l_2ec0, 0x2d78ULL);
arm64_l_2d78:
	/* 0x2d78: tbnz w0, #31, 2e08 <do_bytes+0x188> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2d78, 0x2e08, arm64_l_2e08);
arm64_l_2d7c:
	/* 0x2d7c: and x8, x0, #0x7fffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2147483647ULL);
arm64_l_2d80:
	/* 0x2d80: add x23, x8, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2d84:
	/* 0x2d84: subs x3, x19, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X3, ARM64_X19, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2d88:
	/* 0x2d88: b.eq 2ea8 <do_bytes+0x228> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2d88, 0x2ea8, arm64_l_2ea8);
arm64_l_2d8c:
	/* 0x2d8c: add x2, x23, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2d90:
	/* 0x2d90: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d94:
	/* 0x2d94: mov x1, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2d98:
	/* 0x2d98: bl 2ec0 <__do_bytes> */
	ARM64_SIM_A64_CALL(arm64_l_2ec0, 0x2d9cULL);
arm64_l_2d9c:
	/* 0x2d9c: tbnz w0, #31, 2e08 <do_bytes+0x188> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2d9c, 0x2e08, arm64_l_2e08);
arm64_l_2da0:
	/* 0x2da0: and x8, x0, #0x7fffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2147483647ULL);
arm64_l_2da4:
	/* 0x2da4: add x23, x8, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2da8:
	/* 0x2da8: subs x3, x19, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X3, ARM64_X19, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2dac:
	/* 0x2dac: b.eq 2ea8 <do_bytes+0x228> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2dac, 0x2ea8, arm64_l_2ea8);
arm64_l_2db0:
	/* 0x2db0: add x2, x23, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2db4:
	/* 0x2db4: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2db8:
	/* 0x2db8: mov x1, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2dbc:
	/* 0x2dbc: bl 2ec0 <__do_bytes> */
	ARM64_SIM_A64_CALL(arm64_l_2ec0, 0x2dc0ULL);
arm64_l_2dc0:
	/* 0x2dc0: tbnz w0, #31, 2e08 <do_bytes+0x188> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2dc0, 0x2e08, arm64_l_2e08);
arm64_l_2dc4:
	/* 0x2dc4: and x8, x0, #0x7fffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2147483647ULL);
arm64_l_2dc8:
	/* 0x2dc8: add x23, x8, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X23, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2dcc:
	/* 0x2dcc: subs x3, x19, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SUBS_REG, ARM64_X3, ARM64_X19, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2dd0:
	/* 0x2dd0: b.eq 2ea8 <do_bytes+0x228> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2dd0, 0x2ea8, arm64_l_2ea8);
arm64_l_2dd4:
	/* 0x2dd4: add x2, x23, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X2, ARM64_X23, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2dd8:
	/* 0x2dd8: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2ddc:
	/* 0x2ddc: mov x1, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2de0:
	/* 0x2de0: bl 2ec0 <__do_bytes> */
	ARM64_SIM_A64_CALL(arm64_l_2ec0, 0x2de4ULL);
arm64_l_2de4:
	/* 0x2de4: tbnz w0, #31, 2e08 <do_bytes+0x188> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2de4, 0x2e08, arm64_l_2e08);
arm64_l_2de8:
	/* 0x2de8: and x8, x0, #0x7fffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_AND, ARM64_MOD_NONE, 0), 2147483647ULL);
arm64_l_2dec:
	/* 0x2dec: add x19, x8, x23 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X19, ARM64_X8, ARM64_X23, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_2df0:
	/* 0x2df0: mov x0, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2df4:
	/* 0x2df4: ldp x20, x19, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2df8:
	/* 0x2df8: ldp x22, x21, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2dfc:
	/* 0x2dfc: ldp x30, x23, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2e00:
	/* 0x2e00: add sp, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_2e04:
	/* 0x2e04: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_2e04);
arm64_l_2e08:
	/* 0x2e08: sxtw x19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SXTW, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2e0c:
	/* 0x2e0c: str wzr, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_2e10:
	/* 0x2e10: adrp x0, 0 <tg_stats_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_stats_map_15));
arm64_l_2e14:
	/* 0x2e14: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2e18:
	/* 0x2e18: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2e1c:
	/* 0x2e1c: add x9, sp, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2e20:
	/* 0x2e20: add x1, sp, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2e24:
	/* 0x2e24: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2e28ULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2e28:
	/* 0x2e28: cbz x0, 2ea8 <do_bytes+0x228> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2e28, 0x2ea8, arm64_l_2ea8);
arm64_l_2e2c:
	/* 0x2e2c: cmn x19, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 12ULL);
arm64_l_2e30:
	/* 0x2e30: b.gt 2e54 <do_bytes+0x1d4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x2e30, 0x2e54, arm64_l_2e54);
arm64_l_2e34:
	/* 0x2e34: cmn x19, #0x1c */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 28ULL);
arm64_l_2e38:
	/* 0x2e38: b.eq 2e74 <do_bytes+0x1f4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2e38, 0x2e74, arm64_l_2e74);
arm64_l_2e3c:
	/* 0x2e3c: cmn x19, #0x16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 22ULL);
arm64_l_2e40:
	/* 0x2e40: b.eq 2e8c <do_bytes+0x20c> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2e40, 0x2e8c, arm64_l_2e8c);
arm64_l_2e44:
	/* 0x2e44: cmn x19, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 16ULL);
arm64_l_2e48:
	/* 0x2e48: b.ne 2e84 <do_bytes+0x204> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2e48, 0x2e84, arm64_l_2e84);
arm64_l_2e4c:
	/* 0x2e4c: add x8, x0, #0x558 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1368ULL);
arm64_l_2e50:
	/* 0x2e50: b 2e98 <do_bytes+0x218> */
	ARM64_SIM_A64_JMP(0x2e50, 0x2e98, arm64_l_2e98);
arm64_l_2e54:
	/* 0x2e54: cmn x19, #0xb */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 11ULL);
arm64_l_2e58:
	/* 0x2e58: b.eq 2e7c <do_bytes+0x1fc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2e58, 0x2e7c, arm64_l_2e7c);
arm64_l_2e5c:
	/* 0x2e5c: cmn x19, #0x7 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 7ULL);
arm64_l_2e60:
	/* 0x2e60: b.eq 2e94 <do_bytes+0x214> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x2e60, 0x2e94, arm64_l_2e94);
arm64_l_2e64:
	/* 0x2e64: cmn x19, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMN_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 2ULL);
arm64_l_2e68:
	/* 0x2e68: b.ne 2e84 <do_bytes+0x204> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x2e68, 0x2e84, arm64_l_2e84);
arm64_l_2e6c:
	/* 0x2e6c: add x8, x0, #0x548 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1352ULL);
arm64_l_2e70:
	/* 0x2e70: b 2e98 <do_bytes+0x218> */
	ARM64_SIM_A64_JMP(0x2e70, 0x2e98, arm64_l_2e98);
arm64_l_2e74:
	/* 0x2e74: add x8, x0, #0x568 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1384ULL);
arm64_l_2e78:
	/* 0x2e78: b 2e98 <do_bytes+0x218> */
	ARM64_SIM_A64_JMP(0x2e78, 0x2e98, arm64_l_2e98);
arm64_l_2e7c:
	/* 0x2e7c: add x8, x0, #0x570 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1392ULL);
arm64_l_2e80:
	/* 0x2e80: b 2e98 <do_bytes+0x218> */
	ARM64_SIM_A64_JMP(0x2e80, 0x2e98, arm64_l_2e98);
arm64_l_2e84:
	/* 0x2e84: add x8, x0, #0x540 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1344ULL);
arm64_l_2e88:
	/* 0x2e88: b 2e98 <do_bytes+0x218> */
	ARM64_SIM_A64_JMP(0x2e88, 0x2e98, arm64_l_2e98);
arm64_l_2e8c:
	/* 0x2e8c: add x8, x0, #0x560 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1376ULL);
arm64_l_2e90:
	/* 0x2e90: b 2e98 <do_bytes+0x218> */
	ARM64_SIM_A64_JMP(0x2e90, 0x2e98, arm64_l_2e98);
arm64_l_2e94:
	/* 0x2e94: add x8, x0, #0x550 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1360ULL);
arm64_l_2e98:
	/* 0x2e98: ldaxr x9, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2e9c:
	/* 0x2e9c: add x9, x9, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 1ULL);
arm64_l_2ea0:
	/* 0x2ea0: stlxr w10, x9, [x8] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STLXR, ARM64_X10, ARM64_X9, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0);
arm64_l_2ea4:
	/* 0x2ea4: cbnz w10, 2e98 <do_bytes+0x218> */
	ARM64_SIM_A64_CBNZ_W(ARM64_X10, 0x2ea4, 0x2e98, arm64_l_2e98);
arm64_l_2ea8:
	/* 0x2ea8: mov x0, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2eac:
	/* 0x2eac: ldp x20, x19, [sp, #48] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 48ULL);
arm64_l_2eb0:
	/* 0x2eb0: ldp x22, x21, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2eb4:
	/* 0x2eb4: ldp x30, x23, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X30, ARM64_X23, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2eb8:
	/* 0x2eb8: add sp, sp, #0x40 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 64ULL);
arm64_l_2ebc:
	/* 0x2ebc: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_2ebc);
arm64_l_2ec0:
	/* 0x2ec0: str x30, [sp, #-48]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551568ULL);
arm64_l_2ec4:
	/* 0x2ec4: stp x22, x21, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X22, ARM64_X21, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2ec8:
	/* 0x2ec8: stp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X20, ARM64_X19, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2ecc:
	/* 0x2ecc: tbnz x3, #63, 2f64 <__do_bytes+0xa4> */
	ARM64_SIM_A64_TBNZ(ARM64_X3, 63, 0x2ecc, 0x2f64, arm64_l_2f64);
arm64_l_2ed0:
	/* 0x2ed0: mov w8, #0x7fe0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 32736ULL);
arm64_l_2ed4:
	/* 0x2ed4: mov x22, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X22, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2ed8:
	/* 0x2ed8: add x0, x1, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2edc:
	/* 0x2edc: mov x20, x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X20, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2ee0:
	/* 0x2ee0: cmp x3, x8 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_REG, ARM64_X3, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0);
arm64_l_2ee4:
	/* 0x2ee4: csel x19, x3, x8, cc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X19, ARM64_X3, ARM64_X8, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_CC, 0);
arm64_l_2ee8:
	/* 0x2ee8: mov w8, #0x4 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4ULL);
arm64_l_2eec:
	/* 0x2eec: mov w1, w19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_2ef0:
	/* 0x2ef0: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 4ULL: ARM64_SIM_A64_LINK(0x2ef4ULL); ARM64_SIM_BPF_CALL_bpf_probe_read(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2ef4:
	/* 0x2ef4: tbnz w0, #31, 2f9c <__do_bytes+0xdc> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2ef4, 0x2f9c, arm64_l_2f9c);
arm64_l_2ef8:
	/* 0x2ef8: add w21, w19, #0x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X21, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 32ULL);
arm64_l_2efc:
	/* 0x2efc: str wzr, [sp, #12] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 12ULL);
arm64_l_2f00:
	/* 0x2f00: adrp x0, 0 <tg_conf_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_conf_map_11));
arm64_l_2f04:
	/* 0x2f04: mov w8, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 1ULL);
arm64_l_2f08:
	/* 0x2f08: str w21, [x20, #4] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_X20, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 4ULL);
arm64_l_2f0c:
	/* 0x2f0c: add x9, sp, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X9, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2f10:
	/* 0x2f10: add x1, sp, #0xc */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X1, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 12ULL);
arm64_l_2f14:
	/* 0x2f14: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2f18:
	/* 0x2f18: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 1ULL: ARM64_SIM_A64_LINK(0x2f1cULL); ARM64_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2f1c:
	/* 0x2f1c: cbz x0, 2f7c <__do_bytes+0xbc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x2f1c, 0x2f7c, arm64_l_2f7c);
arm64_l_2f20:
	/* 0x2f20: ldrb w8, [x0, #40] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X8, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 40ULL);
arm64_l_2f24:
	/* 0x2f24: cbz w8, 2f7c <__do_bytes+0xbc> */
	ARM64_SIM_A64_CBZ_W(ARM64_X8, 0x2f24, 0x2f7c, arm64_l_2f7c);
arm64_l_2f28:
	/* 0x2f28: adrp x1, 0 <tcpmon_map> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tcpmon_map_10));
arm64_l_2f2c:
	/* 0x2f2c: mov w8, #0xffffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967295ULL);
arm64_l_2f30:
	/* 0x2f30: mov w9, #0x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X9, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 25ULL);
arm64_l_2f34:
	/* 0x2f34: ldr x1, [x1] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2f38:
	/* 0x2f38: mov x0, x22 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X22, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2f3c:
	/* 0x2f3c: mov w2, #0xffffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X2, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 4294967295ULL);
arm64_l_2f40:
	/* 0x2f40: mov x3, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2f44:
	/* 0x2f44: mov x4, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X4, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2f48:
	/* 0x2f48: blr x9 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X9);
		if (ARM64_SIM_L_REG_TAG(ARM64_X9) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 25ULL: ARM64_SIM_A64_LINK(0x2f4cULL); ARM64_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2f4c:
	/* 0x2f4c: tbnz w0, #31, 2f9c <__do_bytes+0xdc> */
	ARM64_SIM_A64_TBNZ(ARM64_X0, 31, 0x2f4c, 0x2f9c, arm64_l_2f9c);
arm64_l_2f50:
	/* 0x2f50: mov x0, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2f54:
	/* 0x2f54: ldp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2f58:
	/* 0x2f58: ldp x22, x21, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2f5c:
	/* 0x2f5c: ldr x30, [sp], #48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 48ULL);
arm64_l_2f60:
	/* 0x2f60: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_2f60);
arm64_l_2f64:
	/* 0x2f64: mov x19, #0xffffffffffffffff */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 18446744073709551615ULL);
arm64_l_2f68:
	/* 0x2f68: mov x0, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2f6c:
	/* 0x2f6c: ldp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2f70:
	/* 0x2f70: ldp x22, x21, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2f74:
	/* 0x2f74: ldr x30, [sp], #48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 48ULL);
arm64_l_2f78:
	/* 0x2f78: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_2f78);
arm64_l_2f7c:
	/* 0x2f7c: adrp x0, 0 <tg_rb_events> */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ADRP_GOT, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, ((__u64)(long)&tg_rb_events_14));
arm64_l_2f80:
	/* 0x2f80: mov x3, xzr */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X3, ARM64_XZR, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2f84:
	/* 0x2f84: mov w8, #0x82 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X8, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 130ULL);
arm64_l_2f88:
	/* 0x2f88: ldr x0, [x0] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_2f8c:
	/* 0x2f8c: mov x1, x20 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X20, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2f90:
	/* 0x2f90: mov x2, x21 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X2, ARM64_X21, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2f94:
	/* 0x2f94: blr x8 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X8);
		if (ARM64_SIM_L_REG_TAG(ARM64_X8) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			case 130ULL: ARM64_SIM_A64_LINK(0x2f98ULL); ARM64_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_2f98:
	/* 0x2f98: tbz w0, #31, 2f50 <__do_bytes+0x90> */
	ARM64_SIM_A64_TBZ(ARM64_X0, 31, 0x2f98, 0x2f50, arm64_l_2f50);
arm64_l_2f9c:
	/* 0x2f9c: sxtw x19, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_SXTW, ARM64_X19, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2fa0:
	/* 0x2fa0: mov x0, x19 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X19, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2fa4:
	/* 0x2fa4: ldp x20, x19, [sp, #32] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X20, ARM64_X19, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 32ULL);
arm64_l_2fa8:
	/* 0x2fa8: ldp x22, x21, [sp, #16] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X22, ARM64_X21, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 16ULL);
arm64_l_2fac:
	/* 0x2fac: ldr x30, [sp], #48 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 48ULL);
arm64_l_2fb0:
	/* 0x2fb0: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_2fb0);
arm64_l_2fb4:
	/* 0x2fb4: nop */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_NOP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_2fb8:
	/* 0x2fb8: mov x7, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X7, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
	ARM64_SIM_L_WRITE_REG_WIDTH(ARM64_X0, ARM64_SIM_L_READ_REG(ARM64_X7), ARM64_WIDTH_64);
	ARM64_SIM_RET();
}

ARM64_SIM_LICENSE();
