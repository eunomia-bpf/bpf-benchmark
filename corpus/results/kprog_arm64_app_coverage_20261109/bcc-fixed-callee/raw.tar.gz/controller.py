from pathlib import Path
import subprocess,json,datetime,os
R=Path('/workspaces/repository');D=Path(__file__).resolve().parent
rows=[]
for label in [r['unit'] for r in json.loads((D/'commands.json').read_text())]+['generation']:
 with (D/(label+'.log')).open('w') as log:
  p=subprocess.run(['make','--no-print-directory','-f',str(D/'Makefile'),label],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,exit=p.returncode))
 (D/'status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase='running',rows=rows),indent=2)+'\n')
(D/'status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase='finished',rows=rows),indent=2)+'\n')
