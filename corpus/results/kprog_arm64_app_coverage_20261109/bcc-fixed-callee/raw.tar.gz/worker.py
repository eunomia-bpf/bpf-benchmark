from pathlib import Path
import importlib.util,json,subprocess,re
R=Path('/workspaces/repository');D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('worker',R/'kprog/arm64/trusted_specializer.py');w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
rows=[]
for req,unit in {5:'tcplife',10:'opensnoop',11:'biosnoop',12:'capable'}.items():
 Q=Path('/var/tmp/kprog-tmp/A/bcc-stack')/str(req)/'request';out=D/'generated'/str(req)
 try:
  result=w.specialize((D/'native'/(unit+'.native.o')).read_bytes(),(Q/'kernel.entry').read_text().strip(),json.loads((Q/'generation.metadata.json').read_text()),out,R/'kprog/x86/native_lab/native_link/target/release/native-link')
  raw=subprocess.check_output(['llvm-objdump-18','-d',str(out/'trusted_arm64.bpf.o')],text=True)
  offsets=[int(x,16) for x in re.findall(r'r10 - 0x([0-9a-f]+)',raw)]
  rows.append(dict(request=req,unit=unit,phase='compiled',frame_extent_bytes=max(offsets,default=0),result=result))
 except Exception as e:rows.append(dict(request=req,unit=unit,phase='diagnostic',error=str(e)))
(D/'generation.json').write_text(json.dumps(rows,indent=2)+'\n')
