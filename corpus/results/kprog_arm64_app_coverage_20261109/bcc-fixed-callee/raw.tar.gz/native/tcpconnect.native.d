/var/tmp/kprog-tmp/A/bcc-fixed-callee/native/tcpconnect.native.o: \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/tcpconnect.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/arm64/vmlinux.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/maps.bpf.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/tcpconnect.h
