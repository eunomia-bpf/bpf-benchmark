/var/tmp/kprog-tmp/A/bcc-fixed-callee/native/runqlat.native.o: \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/runqlat.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/arm64/vmlinux.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/runqlat.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/bits.bpf.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/maps.bpf.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/core_fixes.bpf.h
