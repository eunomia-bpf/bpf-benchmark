/var/tmp/kprog-tmp/A/bcc-fixed-callee/native/tcplife.native.o: \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/tcplife.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/arm64/vmlinux.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/tcplife.h
