/var/tmp/kprog-tmp/A/bcc-fixed-callee/native/syscount.native.o: \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/syscount.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/arm64/vmlinux.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/syscount.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/maps.bpf.h
