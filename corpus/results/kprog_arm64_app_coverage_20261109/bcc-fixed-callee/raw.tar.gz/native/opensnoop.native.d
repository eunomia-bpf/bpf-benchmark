/var/tmp/kprog-tmp/A/bcc-fixed-callee/native/opensnoop.native.o: \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/opensnoop.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/arm64/vmlinux.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/opensnoop.h
