/var/tmp/kprog-tmp/A/bcc-fixed-callee/native/vfsstat.native.o: \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/vfsstat.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/arm64/vmlinux.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/vfsstat.h
