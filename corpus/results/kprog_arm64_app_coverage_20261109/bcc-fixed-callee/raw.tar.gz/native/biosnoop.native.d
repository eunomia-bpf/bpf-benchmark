/var/tmp/kprog-tmp/A/bcc-fixed-callee/native/biosnoop.native.o: \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/biosnoop.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/arm64/vmlinux.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/biosnoop.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/core_fixes.bpf.h
