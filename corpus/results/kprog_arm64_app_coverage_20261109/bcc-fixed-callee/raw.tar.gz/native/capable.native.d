/var/tmp/kprog-tmp/A/bcc-fixed-callee/native/capable.native.o: \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/capable.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/arm64/vmlinux.h \
  /var/tmp/kprog-tmp/A/bcc-fixed-callee/src/capable.h
