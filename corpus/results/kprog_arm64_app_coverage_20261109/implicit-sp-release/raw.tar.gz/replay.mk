.PHONY: arm64
arm64:
	python3 /var/tmp/kprog-tmp/A/implicit-sp/arm64-replay.py
