from pathlib import Path
import subprocess,datetime,json
R=Path('/workspaces/repository');D=Path(__file__).resolve().parent
for p in sorted((D/'source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(D/'source'))],check=True)
with (D/'host.log').open('w') as log:
 p=subprocess.run(['make','--keep-going','-f',str(D/'Makefile'),'control'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(D/'host-status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),make_exit=p.returncode,phase='finished'),indent=2)+'\n')
