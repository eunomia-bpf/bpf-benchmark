from pathlib import Path
import subprocess,shutil,os,select,json,hashlib,importlib.util
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/A/implicit-sp')

os.unshare(os.CLONE_NEWNS);subprocess.run(['mount','--make-rprivate','/'],check=True)
for p in sorted((O/'source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(O/'source'))],check=True)

# Pair the established recovery Image/module and current bridge in this private view.
for src,dst in [('kprog/arm64/build/native-load-recovery/recovery/Image','vendor/build/arm64/linux/arch/arm64/boot/Image'),('kprog/arm64/build/native-load-recovery/recovery/bpf_arm64_native_lab.ko','kinsn/module/arm64/build-native-resources/bpf_arm64_native_lab.ko'),('runner/build-arm64-llvmbpf/native_loader/trusted-native-loader','kprog/libnativeloader/build-arm64-typed-tail-v1/trusted-native-loader'),('runner/build-arm64-llvmbpf/native_loader/libnative_loader.a','kprog/libnativeloader/build-arm64-typed-tail-v1/libnative_loader.a'),('runner/build-arm64-llvmbpf/native_loader/trusted-service-client','kprog/libnativeloader/build-arm64-typed-tail-v1/trusted-service-client')]:
 subprocess.run(['mount','--bind',str(R/src),str(R/dst)],check=True)
out=O/'safety-arm64-output';out.mkdir()
for name in ['s7.py','_base_check.py']:shutil.copy2(O/'safety-arm64'/name,out/name)
p=out/'s7.py';s=p.read_text().replace("m.ARCH=ARCH;m.OUT=O;", "m.ARCH=ARCH;m.OUT=O;\nif ARCH=='arm64':m.loader_build=lambda:R/'kprog/libnativeloader/build-arm64-typed-tail-v1'\n")
# The existing readonly-root recipe exports private mounts with distinct file IDs.
s=s.replace('t.HERE=O;t.__file__=__file__;', '''import types,subprocess
 real_popen=subprocess.Popen
 def launch(argv,**kw):
  argv[:]=[x+',multidevs=remap' if x.startswith('local,id=repo,') else x for x in argv]
  return real_popen(argv,**kw)
 t.subprocess=types.SimpleNamespace(Popen=launch,PIPE=subprocess.PIPE,STDOUT=subprocess.STDOUT)
 t.HERE=O;t.__file__=__file__;''')
s=s.replace("try:m.check()","import os\n os.environ['KPROG_TRUSTED_COMPILE_STATE']=str(O/'compile-broker')\n try:m.check()")
p.write_text(s)
for src,dst in [(out,R/'kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp'),(O/'build-arm64-output',R/'kprog/formal/build/fidelity-trusted-arm64'),(O/'transport-output',R/'kprog/arm64/build/trusted-transport')]:
 src.mkdir(exist_ok=True);subprocess.run(['mount','--bind',str(src),str(dst)],check=True)
spec=importlib.util.spec_from_file_location('tcbs',R/'kprog/fidelity/tcb.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
paths=m.includes(R/'kprog/arm64/arm64_sim_local_bpf.h')|m.imports(R/'kprog/arm64/micro-prog/generate_micro_sim_proofs.py')
paths|={R/x for x in ['kprog/trusted_service.py','kprog/trusted_generation.py','kprog/arm64/trusted_specializer.py','vendor/build/arm64/linux/arch/arm64/boot/Image','kinsn/module/arm64/build-native-resources/bpf_arm64_native_lab.ko','kprog/libnativeloader/build-arm64-typed-tail-v1/trusted-native-loader','kprog/libnativeloader/build-arm64-typed-tail-v1/libnative_loader.a','kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link']}
pins={};snapshot=O/'output-arm64-source'
for p in sorted(paths):
 target=snapshot/p.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);pins[str(p.relative_to(R))]=hashlib.sha256(target.read_bytes()).hexdigest();subprocess.run(['mount','--bind',str(target),str(p)],check=True)
(out/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
script=R/'kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp/s7.py'
subprocess.run(['python3',str(script),'build'],check=True)
broker_dir=script.parent/'compile-broker';broker_dir.mkdir()
broker_log=(out/'compile-broker.log').open('w')
broker=subprocess.Popen(['python3',str(R/'kprog/trusted_compile.py'),'serve','--scope',str(R),'--state',str(broker_dir),'--arm64-sysroot',str(R/'kprog/arm64/build/app-runtime-v35/root')],stdout=broker_log,stderr=subprocess.STDOUT)
try:ret=subprocess.run(['python3',str(script),'host']).returncode
finally:
 (broker_dir/'STOP').touch();broker.wait();broker_log.close()
(out/'host.exit').write_text(str(ret)+'\n');raise SystemExit(ret)
