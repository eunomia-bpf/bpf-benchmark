from pathlib import Path
import subprocess,datetime,json,tarfile,hashlib,gzip,collections,importlib.util,shutil,traceback,os
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261109/implicit-sp-release';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(D/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 source=json.loads((D/'source-publication.json').read_text())
 launch=dict(utc=now(),source_publication=source['commit'],fixture_publication='2f0b3d44b5aa406f4ec599a9a06bb05b474e443b',safety_fixture_publication='9bd4222ba',recipe_archive='kprog/results/kprog_recovery_safety_20261109/source-and-recipes.tar.gz',recipe_archive_sha256=sha(R/'kprog/results/kprog_recovery_safety_20261109/source-and-recipes.tar.gz'),scope='Existing48-case scalar AArch64 safety suite; original fixtures and native negative load-only protocol',host_controls=dict(compilers=['GCC','Clang18'],mem_prepost_cases_each=135170,pair_cases_each=122891,stack_lifetime='PASS'),runtime_admission_additions=0)
 (O/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
 (O/'README.md').write_text('ARM implicit-SP stack release\n\nSource55504ff90 routes pre/post-index SP writeback through the existing explicit pointer-tag SP setter and stack release body. Native modular address addition, pre-access/post-access ordering and existing alignment/overlap predicates retain their definitions. Released bytes become fresh and their tags/scalar forwarding are cleared exactly as for an explicit SP write. Original GPR writeback retains its body.\n\nV fixture source2f0b3d44b passes mem_prepost135170 and pair122891 cases under each GCC/Clang18, together with existing stack lifetime controls. The existing48-case scalar AArch64 safety suite reuses the published S16 recipe, original native fixtures and negative load-only protocol. Its existing readonly-root 9p multidevs=remap option is retained for captured source visibility. Full actual generator/compiler/verifier/native-result receipts follow this2GiB CPU8-23 guest. Production admission additions:0.\n')
 with tarfile.open(O/'inputs.tar.gz','w:gz') as tf:
  for name in ['source','safety-arm64']:
   for p in (D/name).rglob('*'):
    if p.is_file():tf.add(p,arcname=str(p.relative_to(D)))
  for name in ['header-parent.h','header-candidate.h','candidate.diff','base-commit','Makefile','host.log','host-status.json','arm64-replay.py','replay.mk','safety-controller.py','source-publication.json']:tf.add(D/name,arcname=name)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['launch.json','README.md','inputs.tar.gz']],'Replay ARM safety after implicit SP release repair','arm-implicit-sp-safety-launch')
 save('actual_arm64_safety',publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR V/COORDINATOR '+now()+': PUSHED '+rec['commit']+' existing48ARM safety replay launch for source55504ff90 implicit-SP release, matching V2f0b3d44b expectations. Host GCC/Clang each prepost135170/pair122891 PASS. Existing S16 scalar fixtures/negative load-only transport reused,2GiB CPU8-23, source/runtime snapshots and multidevs=remap retained. New predicates0. Auto terminal publisher retains every stage and raw receipt.\n')
 with (D/'safety.log').open('w') as log:
  done=subprocess.run(['taskset','-c','8-23','make','-f',str(D/'replay.mk'),'arm64'],cwd=R,env=os.environ|{'TMPDIR':str(D),'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 Q=D/'safety-arm64-output';files=list(Q.rglob('outcomes.json'));rows=json.loads(files[-1].read_text()) if files else []
 report=dict(utc=now(),source_publication=source['commit'],make_exit=done.returncode,cases=len(rows),stages=dict(collections.Counter(r['stage'] for r in rows)),negative_native_test_run=sum(bool(r.get('negative')) and len(r.get('command',[]))>3 for r in rows),positive_results=[dict(name=r['name'],stage=r['stage'],returncode=r.get('returncode')) for r in rows if not r.get('negative')],accepted_load_only=[dict(name=r['name'],stage=r['stage'],request=r.get('request')) for r in rows if r['stage']=='accepted_finding'],host_controls=launch['host_controls'],runtime_admission_additions=0)
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');(O/'outcomes.json').write_text(json.dumps(rows,indent=2)+'\n');(O/'driver.log.gz').write_bytes(gzip.compress((D/'safety.log').read_bytes(),mtime=0))
 with tarfile.open(O/'raw.tar.gz','w:gz') as tf:
  for name in ['safety-arm64-output','build-arm64-output','transport-output','output-arm64-source']:
   for p in (D/name).rglob('*'):
    if p.is_file():tf.add(p,arcname=str(p.relative_to(D)))
  for p in D.iterdir():
   if p.is_file() and p.suffix in ['.log','.json','.py','.mk']:tf.add(p,arcname=p.name)
 paths=[O/'summary.json',O/'outcomes.json',O/'driver.log.gz',O/'raw.tar.gz']
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Record ARM safety outcomes after implicit SP release','arm-implicit-sp-safety-terminal')
 save('finished',publication=rec,summary=report)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR V/COORDINATOR/C '+now()+': PUSHED '+rec['commit']+' implicit-SP source55504ff90 existing ARM safety actual'+str(len(rows))+'cases '+str(report['stages'])+', Makeexit'+str(done.returncode)+', negative nativeTEST_RUN'+str(report['negative_native_test_run'])+'. All raw source/runtime/native/B/compiler/verifier outcomes retained. Original recovery-label accepted stages keep S16 verdict attribution; existing frame/stack/release controls remain explicit. Production predicates added0.\n')
 retired=[]
 for name in ['source','safety-arm64-output','build-arm64-output','transport-output','output-arm64-source']:
  root=D/name
  if root.exists():
   size=sum(p.stat().st_size for p in root.rglob('*') if p.is_file());shutil.rmtree(root);retired.append(dict(path=str(root),bytes=size))
 (D/'cleanup.json').write_text(json.dumps(dict(utc=now(),publication=rec,retired=retired),indent=2)+'\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
