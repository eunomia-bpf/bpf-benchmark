from pathlib import Path
import subprocess,json,datetime,hashlib,tarfile,shutil,os,gzip,importlib.util,traceback,collections
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=Path(__file__).resolve().parent;F=A/'bpf34/current-kfunc-catalog';L=Path('/var/tmp/kprog-tmp/A/single-load-attempt');K=Path('/var/tmp/kprog-tmp/A/probe-read/lowering/applications/runtime');O=R/'corpus/results/kprog_arm64_app_coverage_20261109/uniform-catalog'
epoch='55504ff906ab268a5cab3ab083d6d448d152ed54'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(D/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase)|kw,indent=2)+'\n')
try:
 save('capturing_complete_original_catalog')
 O.mkdir(exist_ok=True)
 base=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/direct-native/current-kfunc-catalog/launch-inputs.tar.gz'
 with tarfile.open(base) as tf:
  for m in tf:
   if m.isfile() and m.name.split('/')[0] in ['catalog','source','paired-modules']:
    p=D/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tf.extractfile(m).read());p.chmod(m.mode)
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',epoch,'kprog/arm64','kprog/formal/generated','kprog/helper_abi.py','kprog/trusted_service.py','kprog/trusted_generation.py','kprog/trusted_compile.py','kprog/selftests'],cwd=R,text=True).splitlines()
 for rel in paths:
  if rel.endswith(('.h','.py','.c','.hpp')):
   q=D/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(subprocess.check_output(['git','show',epoch+':'+rel],cwd=R))
 for p in (L/'source').rglob('*'):
  if p.is_file():
   q=D/'source'/p.relative_to(L/'source');q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 shutil.copytree(K,D/'runtime')
 for name in ['libnative_loader.so','trusted-native-loader','trusted-service-client']:shutil.copy2(L/'runtime'/name,D/'runtime'/name)
 aliases={'native-link':'native-link','native-link-arm64-entry-resources':'native-link','libnative_loader.so':'libnative_loader.so','trusted-native-loader':'trusted-native-loader','trusted-service-client':'trusted-service-client'}
 for p in (D/'source').rglob('*'):
  if p.is_file() and p.name in aliases:shutil.copy2(D/'runtime'/aliases[p.name],p)
 transport=(F/'transport.py').read_text().replace("'8-11'","'16-19'").replace('security_model=none,readonly=on','security_model=none,multidevs=remap,readonly=on').replace("str(ROOT) + ',security_model=none'","str(ROOT) + ',security_model=none,multidevs=remap'")
 (D/'transport.py').write_text(transport)
 mount=(F/'mount.py').read_text()
 marker="stage=R/'kprog/arm64/build/native-load-recovery/recovery'"
 mount=mount.replace(marker,marker+"\nsubprocess.run(['mount','--bind',str(F/'runtime'),str(stage)],check=True)")
 i=mount.index("os.execv(");mount=mount[:i]+"os.execvp('make',['make','-f',str(F/'Makefile'),'catalog'])\n"
 (D/'mount.py').write_text(mount)
 target=R/'kprog/arm64/build/kernel-selftest-runner-current/bpf34-full.py'
 (D/'Makefile').write_text('.PHONY: catalog\ncatalog:\n\tpython3 '+str(target)+' host control '+str(O)+'\n')
 launch=dict(utc=now(),model_source=epoch,loader_publication='d1b4ac1b78a438e0caef9914b981218e3ffd59c0',protected_read_receipt='2823c0b2783ce25ff32c9c1cb68b6d45848319c0',original_input_archive=str(base.relative_to(R)),original_input_archive_sha256=sha(base),compile=json.loads((F/'compile.json').read_text()),source_sha256={str(p.relative_to(D/'source')):sha(p) for p in (D/'source').rglob('*') if p.is_file()},native_and_resources_sha256={str(p.relative_to(D/'catalog')):sha(p) for p in (D/'catalog').rglob('*') if p.is_file()},runtime_sha256={str(p.relative_to(D/'runtime')):sha(p) for p in (D/'runtime').rglob('*') if p.is_file()},module_sha256={str(p.relative_to(D/'paired-modules')):sha(p) for p in (D/'paired-modules').rglob('*') if p.is_file()},guest=dict(memory_MiB=2048,cpu='16-19'),native_annotation_TEST_RUN=0,runtime_admission_additions=0)
 (O/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(D.rglob('*')):
   if p.is_file():tf.add(p,arcname=str(p.relative_to(D)))
 (O/'README.md').write_text('Complete original ARM catalog on one captured model source\n\nAll1917original annotations,380compiled native entries and59whole resource objects retain their original bytes. The complete ARM model/generator/direct dispatcher/generated headers are captured from55504ff906ab268a5cab3ab083d6d448d152ed54. The coordinator08:50 first-attempt loaderd1b4 uses the paired f1/e5/3e3f runtime and original bpf_testmod/NF resource dependencies. The original direct source0 submission opens resource objects autoload=false and retains program context/maps; every native annotation row stays load-only. All stages enter the original annotation agreement table.\n\nThe predecessor20f530b99 measured four header epochs272/11/85/12. This successor uses the existing 9p multidevs=remap source visibility option and a complete immutable source copy; every actual request source identity is collected as evidence. Guest2GiB16-19 shares A allocation with the paired BCC guest. Original selftests and frozen framework retain their published bytes. Runtime admission additions:0. Exact original inputs, model/runtime snapshots and recipes accompany launch.json.\n')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['launch.json','launch-inputs.tar.gz','README.md']],'Run complete ARM catalog on one captured model source','arm-uniform-catalog-launch')
 save('actual_complete_catalog',publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR COORDINATOR/C/V/R '+now()+': PUSHED '+rec['commit']+' full original ARM catalog1917annotations/380native entries/59whole resource objects, original P/resources byte-identical. Full555model/generator/direct/generated header epoch plus first-load loaderd1b4 and captured f1/e5/3e3f runtime. Same protected-read epoch passes2823c0b27. Directsource0/autoloadfalse/map/context protocol retained, all native rowsload-only TEST_RUN0. Existing multidevs=remap and immutable inputcopy preserve source visibility; actual per-request source receipts collected. Guest2GiB16-19 shares own BCC allocation. No additional runtime predicates.\n')
 with (D/'driver.log').open('w') as log:guest=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','python3',str(D/'mount.py')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 Q=O/'trusted-arm64-service-result';paths=[];report=dict(utc=now(),make_exit=guest.returncode,native_annotation_TEST_RUN=0,runtime_admission_additions=0)
 (O/'driver.log.gz').write_bytes(gzip.compress((D/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 if (Q/'summary.json').exists():
  summary=json.loads((Q/'summary.json').read_text());archive=Q/summary['archive'];paths.extend([Q/'summary.json',archive]);report['runtime']={k:summary.get(k) for k in ['ok','guest_exit','qemu_returncode','compiler_exit','archive_sha256','hashes_unchanged']}
  with tarfile.open(archive) as tf:
   members=[m for m in tf if m.isfile() and m.name.endswith('/submissions.json')]
   if members:
    table=json.loads(tf.extractfile(max(members,key=lambda x:x.size)).read());(O/'submissions.json').write_text(json.dumps(table,indent=2)+'\n');paths.append(O/'submissions.json');report['counts']=table['counts']
    c=table['counts'];report['agreement']=[dict(annotation=a,reached_verifier=c[a],installed=c[a+'_installed'],agrees=c[a+'_agrees']) for a in ['failure','success']]
    report['installed_failure']=[{k:r.get(k) for k in ['file','program','expect','stage','request_id','native_sha256']} for r in table['programs'] if r.get('expect')=='failure' and r.get('stage')=='installed']
    report['generation_causes']=dict(collections.Counter(str(r.get('diagnostic','')).split(' at 0x')[0].split('\n')[0][:300] for r in table['programs'] if r['stage']=='generation_failed'))
  identities=collections.Counter();direct=collections.Counter();receipt_count=0
  with tarfile.open(archive) as tf:
   for m in tf:
    if m.isfile() and m.name.endswith('.tar.gz') and '/service-state/' in m.name:
     import io
     with tarfile.open(fileobj=io.BytesIO(tf.extractfile(m).read())) as inner:
      for im in inner:
       if im.isfile() and im.name.endswith('source-identities.json'):
        ids=json.loads(inner.extractfile(im).read());header=ids.get(str(R/'kprog/arm64/arm64_sim_local_bpf.h'));dispatch=ids.get(str(R/'kprog/arm64/arm64_sim_direct.h'))
        if header:identities[header]+=1;receipt_count+=1
        if dispatch:direct[dispatch]+=1
  report['observed_request_model_headers']=dict(identities);report['observed_request_direct_headers']=dict(direct);report['source_identity_receipts']=receipt_count
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 with (O/'README.md').open('a') as f:f.write('\nActual terminal: make'+str(guest.returncode)+', '+json.dumps(report.get('counts',{}))+'. Observed per-request model headers:'+json.dumps(report.get('observed_request_model_headers',{}))+'. Every installed/rejected/generated/resource outcome retains its original raw record; native TEST_RUN0.\n')
 paths.append(O/'README.md')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect complete ARM uniform-source catalog outcomes','arm-uniform-catalog-terminal')
 save('finished',publication=rec,report=report)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR COORDINATOR/C/V/R '+now()+': PUSHED '+rec['commit']+' full uniform-source ARM catalog actual '+json.dumps(report.get('counts',{}))+', source header receipts'+json.dumps(report.get('observed_request_model_headers',{}))+'. Every actual native/P/B/compiler/resource/verifier/install row retained, nativeTEST_RUN0. Agreement and installed __failure rows in summary.json. Private completed inputs retire after publication.\n')
 retired=[]
 for name in ['source','catalog','runtime','paired-modules']:
  root=D/name;size=sum(p.stat().st_size for p in root.rglob('*') if p.is_file());shutil.rmtree(root);retired.append(dict(path=str(root),bytes=size))
 (D/'cleanup.json').write_text(json.dumps(dict(utc=now(),retired=retired),indent=2)+'\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
