from pathlib import Path
import subprocess,json,datetime
R=Path('/workspaces/repository');D=Path(__file__).resolve().parent
for p in sorted((D/'source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(D/'source'))],check=True)
commands=[]
for cohort in ['candidate','parent']:
 if cohort=='parent':subprocess.run(['mount','--bind',str(D/'header-parent.h'),str(R/'kprog/arm64/arm64_sim_local_bpf.h')],check=True)
 for req in [5,10,11,12]:
  with (D/(cohort+'-'+str(req)+'.log')).open('w') as log:
   p=subprocess.run(['make','-f',str(D/'Makefile'),cohort+'-'+str(req)],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  commands.append(dict(cohort=cohort,request=req,exit=p.returncode))
(D/'status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase='finished',commands=commands),indent=2)+'\n')
