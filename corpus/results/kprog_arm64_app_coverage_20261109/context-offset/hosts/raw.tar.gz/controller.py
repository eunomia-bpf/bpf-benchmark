from pathlib import Path
import subprocess,json,datetime,tarfile,importlib.util,hashlib
R=Path('/workspaces/repository');D=Path(__file__).resolve().parent
with (D/'driver.log').open('w') as log:p=subprocess.run(['taskset','-c','16-19','python3',str(D/'host-worker.py')],stdout=log,stderr=subprocess.STDOUT)
O=R/'corpus/results/kprog_arm64_app_coverage_20261109/context-offset/hosts';O.mkdir(exist_ok=True)
data=json.loads((D/'host-results.json').read_text());data['source_publication']='878de10ff1a1b0deaf4cf3d8022ad50a1dc8c6ae';data['worker_exit']=p.returncode
(O/'summary.json').write_text(json.dumps(data,indent=2)+'\n')
with tarfile.open(O/'raw.tar.gz','w:gz') as tf:
 for n in ['host.Makefile','host-commands.json','host-worker.py','controller.py','hosts','driver.log']:tf.add(D/n,arcname=n)
(O/'README.md').write_text('Original ARM host groups on context address normalization\n\nAll13existing groups run on GCC and Clang18 with original assertions/UBSan flags. The private compiler-rt18resource directory supplies the previously recorded missing dependency. Exact commands/binaries/logs are archived. Every actual exit is in summary.json. Runtime admission additions:0.\n')
spec=importlib.util.spec_from_file_location('pub','/var/tmp/kprog-tmp/A/publication/publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
rec=pub.publish([str(q.relative_to(R)) for q in O.iterdir() if q.is_file()],'Collect ARM context-address host regressions','context-offset-hosts')
(D/'publication.json').write_text(json.dumps(rec,indent=2)+'\n')
with Path('/workspaces/.agent-state/kprog-lanes/COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR V/C '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+rec['commit']+' original26GCC/Clang ARM host exits '+str(data['rows'])+' on878de10context normalization. Original assertion and sanitizer flags retained; exact receipts archived.\n')
