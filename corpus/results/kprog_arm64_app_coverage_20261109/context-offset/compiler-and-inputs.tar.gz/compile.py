from pathlib import Path
import subprocess,json,datetime
D=Path('/var/tmp/kprog-tmp/A/context-offset')
cmd=json.loads((D/'compile-command.json').read_text())
with (D/'compile.log').open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
(D/'compile-result.json').write_text(json.dumps(dict(returncode=p.returncode,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
if p.returncode==0:
 with (D/'candidate.objdump').open('w') as f:subprocess.run(['llvm-objdump-18','-d',str(D/'candidate.bpf.o')],stdout=f,check=True)
