from pathlib import Path
import subprocess,tarfile,json,shutil,datetime,os,hashlib,shlex,importlib.util,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261109/ghost-state-layouts/clang-ubsan-replay'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(D/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase)|kw,indent=2)+'\n')
try:
 save('private_runtime_dependency')
 with (D/'download.log').open('w') as log:proc=subprocess.run(['apt-get','download','libclang-rt-18-dev=1:18.1.3-1ubuntu1'],cwd=D,stdout=log,stderr=subprocess.STDOUT)
 proc.check_returncode()
 deb=next(D.glob('*.deb'));subprocess.run(['dpkg-deb','-x',str(deb),str(D/'compiler-rt')],check=True)
 runtime=next((D/'compiler-rt').rglob('libclang_rt.ubsan_standalone-x86_64.a')).parent.parent
 resource=D/'resource';resource.mkdir(exist_ok=True);(resource/'lib').symlink_to(runtime,target_is_directory=True)
 original_resource=Path(subprocess.check_output(['clang-18','-print-resource-dir'],text=True).strip())
 (resource/'include').symlink_to(original_resource/'include',target_is_directory=True)
 bad={'clang-18-test_arm64_return_token_host','clang-18-test_arm64_dq_mem_route_host','clang-18-test_arm64_vreg_route_host'}
 with tarfile.open(R/'corpus/results/kprog_arm64_app_coverage_20261109/ghost-state-layouts/raw.tar.gz') as tf:
  for m in tf:
   if m.isfile() and m.name.startswith('ghost-tag-layout/source/'):
    q=D/'source'/m.name[len('ghost-tag-layout/source/'):];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(tf.extractfile(m).read());q.chmod(m.mode)
   elif m.isfile() and m.name.startswith('ghost-payload-layout/host-source/'):
    q=D/'source'/m.name[len('ghost-payload-layout/host-source/'):];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(tf.extractfile(m).read());q.chmod(m.mode)
  for rel in ['kprog/arm64/arm64_sim_local_bpf.h','kprog/arm64/micro-prog/arm64_abi.py','kprog/arm64/micro-prog/generate_micro_sim_proofs.py']:
   (D/'source'/rel).write_bytes(tf.extractfile('ghost-payload-layout/source/'+rel).read())
  commands=json.loads(tf.extractfile('ghost-payload-layout/host-commands.json').read())
 commands=[c for c in commands if c['label'] in bad]
 (D/'hosts').mkdir(exist_ok=True)
 mk='.PHONY: hosts '+' '.join(c['label'] for c in commands)+'\nhosts: '+' '.join(c['label'] for c in commands)+'\n'
 for row in commands:
  cmd=row['command'];cmd[cmd.index('-o')+1]=str(D/'hosts'/row['label']);cmd.insert(1,'-resource-dir='+str(resource));row['command']=cmd
  mk+=row['label']+':\n\t'+shlex.join(cmd)+'\n\t'+str(D/'hosts'/row['label'])+'\n'
 (D/'Makefile').write_text(mk);(D/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 save('existing_three_clang_UBSan_hosts')
 rows=[]
 for row in commands:
  with (D/'hosts'/(row['label']+'.log')).open('w') as log:proc=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','python3',str(D/'inside.py'),row['label']],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  rows.append(dict(label=row['label'],exit=proc.returncode))
 report=dict(utc=now(),rows=rows,dependency=dict(package='libclang-rt-18-dev',version='1:18.1.3-1ubuntu1',deb=deb.name,deb_sha256=hashlib.sha256(deb.read_bytes()).hexdigest(),private_resource_dir=str(resource)),original_scope='Three original link failures from7c4636d38; original13ARM groups/23successful host outcomes retained.',runtime_admission_additions=0)
 O.mkdir(exist_ok=True);(O/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'inputs-and-logs.tar.gz','w:gz') as tf:
  for p in sorted(D.rglob('*')):
   if p.is_file() and not p.is_symlink() and not str(p.relative_to(D)).startswith('compiler-rt/'):tf.add(p,arcname=str(p.relative_to(D)))
 (O/'README.md').write_text('Existing ARM Clang UBSan runtime replay\n\nThe original three Clang18 host failures7c4636d38 were linker diagnostics for the absent libclang_rt.ubsan_standalone-x86_64.a. The exact same private ghost-payload model, original source cases/assertions and original sanitizer options run again with compiler-rt18.1.3 extracted into private storage. The existing Clang include directory remains selected through a resource symlink; system tools/packages retain their installed state. Exact package version/hash, source, compiler commands, binaries and logs accompany this receipt.\n\nActual outcomes:'+json.dumps(rows)+'. The original23successful host observations and three original dependency errors remain archived; this report supplies the three dependency-complete executions. Published model555 and current guest snapshots retain source. Runtime predicates added:0.\n')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['summary.json','inputs-and-logs.tar.gz','README.md']],'Replay original ARM Clang UBSan hosts with private runtime','arm-ghost-layout-clang-ubsan-replay')
 save('finished',publication=rec,report=report)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR V/C '+now()+': PUSHED '+rec['commit']+' existing3Clang18UBSan host dependency replay '+json.dumps(rows)+'. Original7c4636d38three failures were missing compiler-rt link library, while other23passed. Private libclang-rt18.1.3 package/resource selected; original cases/assertions/sanitizer options and model exact. Complete source/packageSHA/binaries/logs retained. Canonical555/liveguests unchanged; new predicates0.\n')
 for name in ['source','hosts','compiler-rt','resource']:
  p=D/name
  if p.is_symlink():p.unlink()
  elif p.exists():shutil.rmtree(p)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
