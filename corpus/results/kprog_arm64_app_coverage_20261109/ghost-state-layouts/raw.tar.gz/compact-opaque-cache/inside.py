from pathlib import Path
import subprocess,os,sys
R=Path('/workspaces/repository');D=Path(__file__).resolve().parent;cohort=sys.argv[1]
for p in sorted((D/'source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(D/'source'))],check=True)
subprocess.run(['mount','--bind',str(D/('header-'+cohort+'.h')),str(R/'kprog/arm64/arm64_sim_local_bpf.h')],check=True)
os.execvp('make',['make','-f',str(D/'Makefile'),cohort])
