from pathlib import Path
import subprocess,json,os,datetime
D=Path(__file__).resolve().parent
rows=[]
for cohort in ['candidate']:
 with (D/(cohort+'.log')).open('w') as log:
  p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(D/'inside.py'),cohort],env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(cohort=cohort,exit=p.returncode))
(D/'status.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase='finished',rows=rows),indent=2)+'\n')
