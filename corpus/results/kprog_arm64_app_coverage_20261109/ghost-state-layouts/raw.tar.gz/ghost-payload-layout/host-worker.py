from pathlib import Path
import subprocess,json,datetime,os
D=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
rows=[]
for row in json.loads((D/'host-commands.json').read_text()):
 with (D/'hosts'/(row['label']+'.log')).open('w') as log:
  p=subprocess.run(['make','-f',str(D/'host.Makefile'),row['label']],cwd=R/'kprog/formal',env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=row['label'],exit=p.returncode))
(D/'host-results.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=rows),indent=2)+'\n')
