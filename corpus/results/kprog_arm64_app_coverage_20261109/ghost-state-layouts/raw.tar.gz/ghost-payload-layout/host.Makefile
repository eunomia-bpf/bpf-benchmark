.PHONY: hosts
hosts:
	python3 /var/tmp/kprog-tmp/A/ghost-payload-layout/host-worker.py
.PHONY: gcc-test_arm64_alu_operand_select_route_host
gcc-test_arm64_alu_operand_select_route_host:
	gcc -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_alu_operand_select_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_alu_operand_select_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_alu_operand_select_route_host
.PHONY: gcc-test_arm64_dispatch_singleton_route_host
gcc-test_arm64_dispatch_singleton_route_host:
	gcc -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dispatch_singleton_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_dispatch_singleton_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_dispatch_singleton_route_host
.PHONY: gcc-test_arm64_return_token_host
gcc-test_arm64_return_token_host:
	gcc -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=all -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_return_token_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_return_token_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_return_token_host
.PHONY: gcc-test_arm64_ldrsx_op_route_host
gcc-test_arm64_ldrsx_op_route_host:
	gcc -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_ldrsx_op_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_ldrsx_op_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_ldrsx_op_route_host
.PHONY: gcc-test_arm64_helper_arg_ptr_route_host
gcc-test_arm64_helper_arg_ptr_route_host:
	gcc -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_helper_arg_ptr_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_helper_arg_ptr_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_helper_arg_ptr_route_host
.PHONY: gcc-test_arm64_mem_base_src_route_host
gcc-test_arm64_mem_base_src_route_host:
	gcc -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mem_base_src_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_mem_base_src_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_mem_base_src_route_host
.PHONY: gcc-test_arm64_dq_mem_extra_route_host
gcc-test_arm64_dq_mem_extra_route_host:
	gcc -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dq_mem_extra_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_dq_mem_extra_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_dq_mem_extra_route_host
.PHONY: gcc-test_arm64_vreg_field_route_host
gcc-test_arm64_vreg_field_route_host:
	gcc -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_vreg_field_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_vreg_field_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_vreg_field_route_host
.PHONY: gcc-test_arm64_helper_call_host
gcc-test_arm64_helper_call_host:
	gcc -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_helper_call_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_helper_call_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_helper_call_host
.PHONY: gcc-test_arm64_pair_mem_route_host
gcc-test_arm64_pair_mem_route_host:
	gcc -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_pair_mem_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_pair_mem_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_pair_mem_route_host
.PHONY: gcc-test_arm64_mem_prepost_route_host
gcc-test_arm64_mem_prepost_route_host:
	gcc -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mem_prepost_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_mem_prepost_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_mem_prepost_route_host
.PHONY: gcc-test_arm64_dq_mem_route_host
gcc-test_arm64_dq_mem_route_host:
	gcc -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dq_mem_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_dq_mem_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_dq_mem_route_host
.PHONY: gcc-test_arm64_vreg_route_host
gcc-test_arm64_vreg_route_host:
	gcc -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_vreg_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_vreg_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/gcc-test_arm64_vreg_route_host
.PHONY: clang-18-test_arm64_alu_operand_select_route_host
clang-18-test_arm64_alu_operand_select_route_host:
	clang-18 -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_alu_operand_select_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_alu_operand_select_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_alu_operand_select_route_host
.PHONY: clang-18-test_arm64_dispatch_singleton_route_host
clang-18-test_arm64_dispatch_singleton_route_host:
	clang-18 -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dispatch_singleton_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_dispatch_singleton_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_dispatch_singleton_route_host
.PHONY: clang-18-test_arm64_return_token_host
clang-18-test_arm64_return_token_host:
	clang-18 -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=all -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_return_token_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_return_token_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_return_token_host
.PHONY: clang-18-test_arm64_ldrsx_op_route_host
clang-18-test_arm64_ldrsx_op_route_host:
	clang-18 -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_ldrsx_op_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_ldrsx_op_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_ldrsx_op_route_host
.PHONY: clang-18-test_arm64_helper_arg_ptr_route_host
clang-18-test_arm64_helper_arg_ptr_route_host:
	clang-18 -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_helper_arg_ptr_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_helper_arg_ptr_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_helper_arg_ptr_route_host
.PHONY: clang-18-test_arm64_mem_base_src_route_host
clang-18-test_arm64_mem_base_src_route_host:
	clang-18 -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mem_base_src_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_mem_base_src_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_mem_base_src_route_host
.PHONY: clang-18-test_arm64_dq_mem_extra_route_host
clang-18-test_arm64_dq_mem_extra_route_host:
	clang-18 -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dq_mem_extra_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_dq_mem_extra_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_dq_mem_extra_route_host
.PHONY: clang-18-test_arm64_vreg_field_route_host
clang-18-test_arm64_vreg_field_route_host:
	clang-18 -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_vreg_field_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_vreg_field_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_vreg_field_route_host
.PHONY: clang-18-test_arm64_helper_call_host
clang-18-test_arm64_helper_call_host:
	clang-18 -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_helper_call_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_helper_call_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_helper_call_host
.PHONY: clang-18-test_arm64_pair_mem_route_host
clang-18-test_arm64_pair_mem_route_host:
	clang-18 -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_pair_mem_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_pair_mem_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_pair_mem_route_host
.PHONY: clang-18-test_arm64_mem_prepost_route_host
clang-18-test_arm64_mem_prepost_route_host:
	clang-18 -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mem_prepost_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_mem_prepost_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_mem_prepost_route_host
.PHONY: clang-18-test_arm64_dq_mem_route_host
clang-18-test_arm64_dq_mem_route_host:
	clang-18 -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dq_mem_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_dq_mem_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_dq_mem_route_host
.PHONY: clang-18-test_arm64_vreg_route_host
clang-18-test_arm64_vreg_route_host:
	clang-18 -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_vreg_route_host.c -o /var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_vreg_route_host
	/var/tmp/kprog-tmp/A/ghost-payload-layout/hosts/clang-18-test_arm64_vreg_route_host
