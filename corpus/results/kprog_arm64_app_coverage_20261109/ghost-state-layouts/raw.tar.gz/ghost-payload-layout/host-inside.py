from pathlib import Path
import subprocess,os
D=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
for directory in ['source','host-source']:
 for p in sorted((D/directory).rglob('*')):
  if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(D/directory))],check=True)
os.execvp('make',['make','-f',str(D/'host.Makefile'),'hosts'])
