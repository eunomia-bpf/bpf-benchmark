from pathlib import Path
import subprocess,os,json,datetime,hashlib,tarfile,importlib.util,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;S=G/'source/kprog/formal';O=R/'corpus/results/kprog_arm64_app_coverage_20261109/dynptr-access'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'lean-status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
try:
 save('existing_helper_identity_theorems')
 env=os.environ.copy();env['LEAN_PATH']=str(G/'lean-out')+':'+subprocess.check_output(['lake','env','printenv','LEAN_PATH'],cwd=R/'kprog/formal',text=True).strip()
 lean=subprocess.check_output(['lake','env','which','lean'],cwd=R/'kprog/formal',text=True).strip()
 rows=[]
 for rel in ['KProgFormal/Generated/GeneratedArm64HelperIdents.lean','KProgFormal/Arm64HelperIdents.lean']:
  src=S/rel;out=G/'lean-out'/Path(rel).with_suffix('.olean');out.parent.mkdir(parents=True,exist_ok=True)
  cmd=[lean,'--root='+str(S),'-o',str(out),str(src)]
  with (G/('lean-'+src.stem+'.log')).open('w') as log:run=subprocess.run(cmd,cwd=R/'kprog/formal',env=env,stdout=log,stderr=subprocess.STDOUT)
  rows.append(dict(source=rel,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),command=cmd,exit=run.returncode,output_sha256=hashlib.sha256(out.read_bytes()).hexdigest() if out.exists() else None))
  if run.returncode:break
 report=dict(utc=now(),scope='Existing universal helper identity/table theorems,95row source; private output prefix and retained compiler environment',source_publication='6737766140096384da964e3044d16bf662365f16',commands=rows,runtime_admission_additions=0)
 (O/'lean.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'lean-inputs.tar.gz','w:gz') as tf:
  tf.add(G/'lean-controller.py',arcname='lean-controller.py')
  for rel in ['KProgFormal/Generated/GeneratedArm64HelperIdents.lean','KProgFormal/Arm64HelperIdents.lean']:tf.add(S/rel,arcname=rel)
  for p in G.glob('lean-*.log'):tf.add(p,arcname=p.name)
  if (G/'lean-out').exists():tf.add(G/'lean-out',arcname='lean-out')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['lean.json','lean-inputs.tar.gz']],'Check existing ARM helper identity theorems for ninety five helpers','arm-dynptr-access-identity-Lean')
 save('finished',publication=rec,commands=rows)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR V/C/R '+now()+': PUSHED '+rec['commit']+' existing95rowARMhelperidentitytheorems privateLean module exits'+json.dumps([r['exit'] for r in rows])+'. Exactsource673/allgeneraltablelaws preserved; privateoutputprefixandexistingtoolchainreused. VsoleFULLslotretained. Runtimeadmissionadditions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
