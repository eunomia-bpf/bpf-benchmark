from pathlib import Path
import subprocess,json,datetime,hashlib,tarfile,shutil,importlib.util,gzip,os,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');F=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261109/dynptr-access/qemu';O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(F/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
try:
 save('preparing_complete_original_family')
 old=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-helpers/ringbuf-dynptr/qemu/launch-inputs.tar.gz'
 with tarfile.open(old) as tf:
  for m in tf:
   if m.isfile() and (m.name.startswith(('source/','catalog/')) or m.name in ['transport.py','mount.py','compile.json']):
    p=F/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tf.extractfile(m).read());p.chmod(m.mode)
 head='6737766140096384da964e3044d16bf662365f16'
 files=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'kprog/arm64','kprog/formal/generated'],cwd=R,text=True).splitlines()
 files+=[str(p.relative_to(F/'source')) for p in (F/'source/kprog').rglob('*') if p.is_file() and p.suffix in ['.h','.py']]
 for rel in sorted(set(files)):
  if Path(rel).suffix not in ['.h','.py'] or '/build/' in rel or '/results/' in rel:continue
  run=subprocess.run(['git','show',head+':'+rel],cwd=R,capture_output=True)
  if run.returncode==0:
   p=F/'source'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(run.stdout)
 shutil.copytree(R/'kprog/arm64/build/native-load-recovery/recovery',F/'runtime',dirs_exist_ok=True,symlinks=True)
 shutil.copy2(R/'corpus/results/kprog_arm64_app_coverage_20261109/approved-native-size/shared-successor/bpf_arm64_native_lab.ko',F/'runtime/bpf_arm64_native_lab.ko')
 aliases={'native-link':'native-link','native-link-arm64-entry-resources':'native-link','libnative_loader.so':'libnative_loader.so','trusted-native-loader':'trusted-native-loader','trusted-service-client':'trusted-service-client'}
 for p in (F/'source').rglob('*'):
  if p.is_file() and p.name in aliases:shutil.copy2(F/'runtime'/aliases[p.name],p)
 mount=(F/'mount.py').read_text().replace("stage=R/'kprog/arm64/build/native-load-recovery/recovery'","stage=R/'kprog/arm64/build/native-load-recovery/recovery'\nsubprocess.run(['mount','--bind',str(F/'runtime'),str(stage)],check=True)")
 mount=mount.replace('corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-helpers/ringbuf-dynptr/qemu',str(O.relative_to(R)))
 (F/'mount.py').write_text(mount)
 (F/'Makefile').write_text('.PHONY: replay\nreplay:\n\ttaskset -c 12-15 unshare --mount --propagation private python3 '+str(F/'mount.py')+'\n')
 compile=json.loads((F/'compile.json').read_text());compile.update(model_source=head,scope='All81original dynptr_fail native family entries; original86catalog rows and original resource/context object',runtime_module='3e3f44f33',runtime_admission_additions=0)
 (O/'compile.json').write_text(json.dumps(compile,indent=2)+'\n')
 launch=dict(utc=now(),source=head,paired_generation='265f663d7792286ec3a0a06a90aca11134b2c2f4',base_archive=str(old.relative_to(R)),base_archive_sha256=sha(old),model_source_sha256={str(p.relative_to(F/'source')):sha(p) for p in (F/'source').rglob('*') if p.is_file()},runtime_sha256={str(p.relative_to(F/'runtime')):sha(p) for p in (F/'runtime').rglob('*') if p.is_file()},guest=dict(memory_MiB=2048,cpus='12-15'),native_execution_policy='Original annotation rows load-only; TEST_RUN0',runtime_admission_additions=0)
 (O/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(F.rglob('*')):
   if p.is_file() and p.name not in ['controller.pid','controller.log','status.json']:tf.add(p,arcname=str(p.relative_to(F)))
 (O/'README.md').write_text('Original ARM dynptr access verifier replay\n\nThe complete original dynptr_fail family retains81native entries,86catalog rows, original annotations, native bytes and the complete original BPF resource object. Source673776614 supplies95helper identities including actual201read/202write/203data, current published read recovery and stack semantics. Runtime f1/e5 Image and ordinary-copy three-descriptor module3e3f remain private. Existing direct source0 submission opens the whole object with autoloadfalse, creates/pins its maps and keeps original load context. Every native annotation row stays load-only with TEST_RUN0. One2GiB guest12-15 runs alongside original catalog2GiB8-11 and BCC2GiB→Tracee8GiB16-19; maximum12GiB. Full generator/compiler/resource/verifier/installed stage records follow in terminal raw archives. Runtime admission additions:0.\n')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['README.md','compile.json','launch.json','launch-inputs.tar.gz']],'Run complete original ARM dynptr family through stock verification','arm-dynptr-access-qemu-launch')
 save('actual_original_family',publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R/S10 '+now()+': PUSHED '+rec['commit']+' all81originaldynptrnative/86catalogrows source673/95helpers stockQEMUqueue, source0/autoloadfalse/wholeoriginalresource/maps. Memory2GiB12-15 with originalfull2+currentBCC2thenTracee8, peak12GiB. PrivateImage/runtimeordinary3e3f/module3descriptors/source captured; originalnativeannotationsload-onlyTEST_RUN0. Existingguestsretainepochs. Runtimeadmissionadditions0.\n')
 with (F/'driver.log').open('w') as log:run=subprocess.run(['make','-f',str(F/'Makefile'),'replay'],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=run.returncode);paths=[];Q=O/'trusted-arm64-service-result'
 (O/'driver.log.gz').write_bytes(gzip.compress((F/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 if (Q/'summary.json').exists():
  j=json.loads((Q/'summary.json').read_text());paths.extend([Q/'summary.json',Q/j['archive']]);report['runtime']={k:j.get(k) for k in ['ok','guest_exit','compiler_exit','qemu_returncode']}
  with tarfile.open(Q/j['archive']) as tf:
   m=next((m for m in tf if m.isfile() and m.name.endswith('/out/submissions.json')),None)
   if m:
    data=tf.extractfile(m).read();(O/'submissions.json').write_bytes(data);paths.append(O/'submissions.json');report['counts']=json.loads(data)['counts']
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 result=pub.publish([str(p.relative_to(R)) for p in paths],'Collect original ARM dynptr access stock verifier outcomes','arm-dynptr-access-qemu-terminal')
 save('finished',publication=result,**{k:v for k,v in report.items() if k!='utc'})
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R/S10 '+now()+': PUSHED '+result['commit']+' alloriginaldynptr95helperstockverifierterminal '+json.dumps(report.get('counts'))+'. Everyrealstage/raw/P/B/annotationretained; TEST_RUN0. Closedprivatecopiesretireafternowpublishedarchive. Runtimeadmissionadditions0.\n')
 retired=[]
 for name in ['source','catalog','runtime']:
  p=F/name;size=sum(q.stat().st_size for q in p.rglob('*') if q.is_file());shutil.rmtree(p);retired.append(dict(path=str(p),bytes=size))
 (F/'cleanup.json').write_text(json.dumps(dict(utc=now(),publication=result,retired=retired),indent=2)+'\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
