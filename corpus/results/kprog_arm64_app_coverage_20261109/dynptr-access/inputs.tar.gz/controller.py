from pathlib import Path
import collections,datetime,json,hashlib,subprocess,sys,tarfile,io,importlib.util,traceback,os
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
try:
 save('existing_private_and_parent_controls')
 controls=[]
 for cohort in ['source','parent']:
  for target in ['identity','abi']:
   cmd=['make','--no-print-directory','-f',str(G/'Makefile'),target,'BIN='+str(G/(cohort+'-'+target))]
   with (G/(cohort+'-'+target+'.log')).open('w') as log:run=subprocess.run(cmd,cwd=G/cohort,stdout=log,stderr=subprocess.STDOUT)
   controls.append(dict(cohort=cohort,target=target,command=cmd,exit=run.returncode))
   (G/'controls.json').write_text(json.dumps(controls,indent=2)+'\n')
 save('original_complete_dynptr_family_generation',controls=controls)
 P=R/'corpus/results/kprog_arm64_app_coverage_20261108/kernel-selftest-arch/direct-native/full-paired-resources'
 rows=[r for r in json.loads((P/'submissions.json').read_text())['programs'] if r['file']=='dynptr_fail.c']
 Q=P/'trusted-arm64-service-result';summary=json.loads((Q/'summary.json').read_text());inputs={}
 with tarfile.open(Q/summary['archive'],'r|gz') as outer:
  ids={r.get('request_id') for r in rows}
  import re
  for m in outer:
   hit=re.search(r'/(\d+)\.(?:failure|success)\.tar.gz$',m.name)
   if not hit or int(hit[1]) not in ids:continue
   with tarfile.open(fileobj=io.BytesIO(outer.extractfile(m).read())) as inner:
    inputs[int(hit[1])]=(inner.extractfile('request/kernel.native.o').read(),json.loads(inner.extractfile('request/generation.metadata.json').read()))
 sys.path.insert(0,str(R/'kprog'))
 spec=importlib.util.spec_from_file_location('arm_worker',R/'kprog/arm64/trusted_specializer.py');worker=importlib.util.module_from_spec(spec);sys.modules[spec.name]=worker;spec.loader.exec_module(worker)
 linker=R/'kprog/x86/native_lab/native_link/target/release/native-link';observed=[]
 for row in rows:
  record={k:row.get(k) for k in ['file','program','expect','request_id','native_sha256']};record['previous_stage']=row.get('stage')
  pair=inputs.get(row.get('request_id'))
  if pair is None:record.update(stage='archived_resource_outcome',diagnostic=row.get('diagnostic'))
  else:
   native,metadata=pair;out=G/'generated'/row['program'];out.parent.mkdir(parents=True,exist_ok=True)
   try:
    artifact=worker.specialize(native,row['program'],metadata,out,linker)
    (out/'generation.metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    record.update(stage='generated_compiled',native_sha256=artifact['native_sha256'])
   except BaseException as e:record.update(stage='generation_or_compile_failed',diagnostic=str(e),traceback=traceback.format_exc())
  observed.append(record);(G/'generation.json').write_text(json.dumps(dict(programs=observed,counts=dict(collections.Counter(r['stage'] for r in observed))),indent=2)+'\n')
 save('private_replay_finished',controls=controls,counts=dict(collections.Counter(r['stage'] for r in observed)),original_family_entries=len(rows),runtime_admission_additions=0)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
