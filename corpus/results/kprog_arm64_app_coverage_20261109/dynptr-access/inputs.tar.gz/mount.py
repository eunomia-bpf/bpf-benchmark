from pathlib import Path
import subprocess,os,sys
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
for p in sorted((G/'source').rglob('*')):
 if p.is_file() and str(p.relative_to(G/'source')).startswith(('kprog/','kinsn/')) and p.suffix in ['.h','.py']:
  target=R/p.relative_to(G/'source')
  if target.is_file():subprocess.run(['mount','--bind',str(p),str(target)],check=True)
os.execv(sys.executable,[sys.executable,str(G/'controller.py')])
