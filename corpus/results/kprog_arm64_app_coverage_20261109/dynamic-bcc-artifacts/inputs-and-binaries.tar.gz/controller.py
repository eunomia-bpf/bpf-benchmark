from pathlib import Path
import tarfile,subprocess,json,datetime,hashlib,shlex,os,shutil,importlib.util,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261109/dynamic-bcc-artifacts'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(D/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase)|kw,indent=2)+'\n')
try:
 save('extracting_completed_paired_build_objects')
 inputs={'biosnoop':('corpus/results/kprog_arm64_app_coverage_20261109/biosnoop-creation-state/build-inputs.tar.gz','build/'),'opensnoop':('corpus/results/kprog_arm64_app_coverage_20261109/opensnoop-ret-order/raw.tar.gz','')}
 commands=[];mk='.PHONY: all biosnoop opensnoop\nall: biosnoop opensnoop\n'
 for tool,(archive,prefix) in inputs.items():
  root=D/tool;root.mkdir(exist_ok=True)
  with tarfile.open(R/archive) as tf:
   for m in tf:
    if m.isfile() and m.name.startswith(prefix):
     rel=m.name[len(prefix):]
     if rel.startswith(('src/','jit/','native/')) or rel in ['biosnoop.O3.native.o','change.json','source.patch']:
      p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tf.extractfile(m).read());p.chmod(m.mode)
  objs=[root/'jit'/n for n in [tool+'.o','trace_helpers.o','syscall_helpers.o','errno_helpers.o','map_helpers.o','uprobe_helpers.o','btf_helpers.o','compat.o']]
  sysroot=R/'.cache/aarch64-sysroot'
  cmd=['aarch64-linux-gnu-gcc','-g','-O2','-Wall',*[str(p) for p in objs],str(R/'runner/build-arm64-llvmbpf/vendor/libbpf/pic-obj/libbpf.a'),'-L'+str(sysroot/'usr/lib/aarch64-linux-gnu'),'-Wl,-rpath-link,'+str(sysroot/'usr/lib/aarch64-linux-gnu'),'-lelf','-lz','-ldl','-pthread','-o',str(root/tool)]
  commands.append(dict(tool=tool,archive=archive,command=cmd));mk+=tool+':\n\t'+shlex.join(cmd)+'\n'
 (D/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');(D/'Makefile').write_text(mk)
 rows=[]
 for row in commands:
  tool=row['tool'];root=D/tool
  with (D/(tool+'.log')).open('w') as log:proc=subprocess.run(['make','-f',str(D/'Makefile'),tool],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  entry=dict(tool=tool,make_exit=proc.returncode,source_sha256=sha(root/'src'/(tool+'.bpf.c')),bpf_sha256=sha(root/'jit'/(tool+'.bpf.o')))
  if proc.returncode==0:
   entry.update(binary_sha256=sha(root/tool),file=subprocess.check_output(['file',str(root/tool)],text=True).strip(),program_headers=subprocess.check_output(['readelf','-l',str(root/tool)],text=True),dynamic_dependencies=subprocess.check_output(['readelf','-d',str(root/tool)],text=True))
  rows.append(entry)
 report=dict(utc=now(),rows=rows,commands=commands,scope='Relink existing completed paired user objects dynamically so existing LD_PRELOAD shim intercepts unchanged embedded BPF program startup; native P and selected source bytes remain exact.',runtime_admission_additions=0)
 O.mkdir(exist_ok=True);(O/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'inputs-and-binaries.tar.gz','w:gz') as tf:
  for p in sorted(D.rglob('*')):
   if p.is_file():tf.add(p,arcname=str(p.relative_to(D)))
 (O/'README.md').write_text('Paired ARM BCC dynamic executable repair\n\nThe original paired biosnoop5f and opensnoop4474user objects are relinked as dynamic ELF executables with their existing embedded BPF objects. PT_INTERP selects the normal AArch64 interpreter and permits the existing LD_PRELOAD shim to capture application startup. Native P/source/BPF/field/size/helper/workload bytes retain their captured definitions. Biosnoop uses source0185creation-state; opensnoop uses source4474ret-store order. Exact linker commands, object dependencies, ELF interpreter/NEEDED records, source/BPF/binary hashes and both binaries accompany this receipt.\n\nThe initial static biosnoop produces only its application thread while the other7BCC tools expose shim accept threads. A own guest task dump records Python waiting in unix_stream_connect/p9_client_walk and biosnoop in perf-buffer epoll; its partial actual source/runtime/raw observations remain in the original cohort. Dynamic relink repairs the concrete preload boundary. Existing frozen framework and baseline/native source pairing remain intact. Runtime predicates added:0.\n')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['summary.json','inputs-and-binaries.tar.gz','README.md']],'Relink paired ARM BCC tools for preload startup','arm-dynamic-bcc-artifacts')
 save('finished',publication=rec,report=report)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/R/V '+now()+': PUSHED '+rec['commit']+' paired ARM biosnoop/Open dynamic relink from existing completed user.o/BPF/nativeP inputs, actual exits'+json.dumps([{k:r[k] for k in ['tool','make_exit']} for r in rows])+'. PT_INTERP/NEEDED/source/BPF/binary hashes archived. Static biosnoop5f bypassed LD_PRELOAD, matching sole app thread vs other7shim accept threads; Python actualwaitunixconnect/p9walk retained. Only executable link mode changes; same edited C/nativeP/BPF/fields/lengths/helper/workload preserved. Full BCC successor overlays dynamicbio; later candidate pairs dynamicret-orderOpen. Existing frozen framework/currentcatalog555retained; new predicates0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
