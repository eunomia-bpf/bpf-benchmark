from pathlib import Path
import subprocess,json,datetime,hashlib,shutil,tarfile,importlib.util,gzip,os,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;B=G.parent;F=A/'native-load-recovery/arm64/null-btf';O=R/'corpus/results/kprog_arm64_app_coverage_20261109/approved-native-size/null-replay'
O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(kw,utc=now(),phase=phase),indent=2)+'\n')
try:
 save('capturing_existing_NULL_control')
 shutil.copytree(F/'source',G/'source',dirs_exist_ok=True,symlinks=True)
 stage=R/'kprog/arm64/build/native-load-recovery/recovery'
 shutil.copytree(stage,G/'runtime',dirs_exist_ok=True,symlinks=True)
 shutil.copy2(B/'module-output/bpf_arm64_native_lab.ko',G/'runtime/bpf_arm64_native_lab.ko')
 for rel in ['kprog/arm64/arm64_sim_local_bpf.h','kprog/arm64/arm64_sim_direct.h']:
  p=G/'source'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show','5363b5ff6:'+rel],cwd=R))
 fixture=R/'kprog/arm64/build/native-load-recovery/null-fixture'
 for p in fixture.iterdir():
  if p.is_file():
   target=G/'source'/p.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
 shutil.copy2(F/'transport.py',G/'transport.py')
 mount=(F/'mount.py').read_text().replace("stage=R/'kprog/arm64/build/native-load-recovery/recovery'","stage=R/'kprog/arm64/build/native-load-recovery/recovery'\nsubprocess.run(['mount','--bind',str(F/'runtime'),str(stage)],check=True)")
 mount=mount.replace('corpus/results/kprog_arm64_app_coverage_20261108/native-load-recovery/arm64/null-btf',str(O.relative_to(R)))
 (G/'mount.py').write_text(mount)
 make='.PHONY: run\nrun:\n\ttaskset -c 12-15 unshare --mount --propagation private python3 '+str(G/'mount.py')+'\n'
 (G/'Makefile').write_text(make)
 launch=dict(utc=now(),scope='Existing authorized full-word live/NULL BTF control on approved-size ARM module',module_build_publication='c6df92100a4fdaeb6f2cffb0adc191ea7dc8e218',fixture_publication='99b2f95617881440a990173aff8876d6985e798d',model_source='5363b5ff6',guest=dict(memory_MiB=2048,CPUs='12-15'),runtime={str(p.relative_to(G/'runtime')):sha(p) for p in (G/'runtime').rglob('*') if p.is_file()},source={str(p.relative_to(G/'source')):sha(p) for p in (G/'source').rglob('*') if p.is_file()},approved_shared_rules_adopted=1,additional_runtime_admission_rules=0)
 (O/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(G.rglob('*')):
   if p.is_file():tf.add(p,arcname=str(p.relative_to(G)))
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['launch.json','launch-inputs.tar.gz']],'Replay existing ARM live and NULL control on approved size module','arm-approved-size-null-launch')
 save('actual_existing_NULL_guest',publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/S10/V/R '+now()+': PUSHED '+rec['commit']+' existingauthorized99bfullwordlive/NULL control onprivateapprovedmodulec6df, model5363. Addedone2GiBguest12-15; currentfull2+Tracee8+control2=12GiBAallocation. EachguestkeepsprivateImage/module/source; currentfull/Traceeandwaitingprobequeuebytesretaincapture. Approvedsharedruleadopted1, additionalruntimeadmissionrules0.\n')
 with (G/'driver.log').open('w') as log:run=subprocess.run(['make','-f',str(G/'Makefile'),'run'],cwd=R,stdout=log,stderr=subprocess.STDOUT,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'})
 Q=O/'trusted-arm64-service-result';paths=[];report=dict(utc=now(),make_exit=run.returncode,approved_shared_rules_adopted=1,additional_runtime_admission_rules=0)
 if (Q/'summary.json').exists():
  d=json.loads((Q/'summary.json').read_text());paths.extend([Q/'summary.json',Q/d['archive']]);report['runtime']={k:d.get(k) for k in ['ok','guest_exit','qemu_returncode','compiler_exit']};report['guest']=d.get('guest')
 (O/'driver.log.gz').write_bytes(gzip.compress((G/'driver.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 (O/'result.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'result.json')
 result=pub.publish([str(p.relative_to(R)) for p in paths],'Collect existing ARM recovery control on approved copy extent module','arm-approved-size-null-terminal')
 save('finished',publication=result,**report)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/S10/V/R '+now()+': PUSHED '+result['commit']+' existingfullwordlive/NULL approvedARMmodulereplay Makeexit'+str(run.returncode)+' runtime'+json.dumps(report.get('runtime'))+' guest'+json.dumps(report.get('guest'))+'. CompleteactualB/service/verifier/native/return/rawarchivesretained. Approvedsharedruleadopted1, additionalruntimeadmissionrules0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
