from pathlib import Path
import subprocess,json,datetime,hashlib,tarfile,shutil,importlib.util,gzip,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261109/approved-native-size/shared-successor'
O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(G/'successor-status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
try:
 save('applying_shared_submit_successor')
 patch=subprocess.check_output(['git','diff','c2b96d6c3^','c2b96d6c3','--','kinsn/module/include/native_lab_trusted.h'],cwd=R).decode()
 patch=patch.replace('a/kinsn/module/include/','a/include/').replace('b/kinsn/module/include/','b/include/')
 (G/'shared-successor.patch').write_text(patch)
 subprocess.run(['git','apply','--unsafe-paths',str(G/'shared-successor.patch')],cwd=G,check=True)
 save('incremental_ARM_module_successor')
 with (G/'successor-build.log').open('w') as log:
  run=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','sh',str(G/'inside-module.sh')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),scope='ARM shared ELF submit ordinary-copy successor; coordinator directs sole extent bound to actual x86 chunk copy',source_commit='c2b96d6c313fb7bf7e6df48caffa8df694b40b05',predecessor_module_publication='c6df92100a4fdaeb6f2cffb0adc191ea7dc8e218',paired_module_source='b0e107ce6',build_exit=run.returncode,source_sha256={str(p.relative_to(G)):sha(p) for root in [G/'module-source',G/'include'] for p in root.rglob('*') if p.is_file()},successor_patch_sha256=sha(G/'shared-successor.patch'),active_NULL_cohort='d433945e4 retains captured c3 module and model5363',ARM_runtime_admission_rules_added=0)
 mod=G/'module-output/bpf_arm64_native_lab.ko'
 if mod.exists():shutil.copy2(mod,O/mod.name);report['module_sha256']=sha(mod)
 (O/'build.json').write_text(json.dumps(report,indent=2)+'\n')
 (O/'README.md').write_text('ARM ordinary-copy shared successor\n\nCoordinator direct instruction narrows the single1GiB extent bound to actual x86 emitted chunk copying. Shared successor c2b96d6c3 keeps ordinary ELF SUBMIT/SUBMIT_RESOURCES lookup and allocation on ARM. This private incremental module consumes that exact shared-header successor over the captured ARM include tree and paired S10 three-descriptor recovery source. Its existing warm module/kernel outputs are reused. Historical c6df module and d433 NULL cohort retain their captured epochs; current full-catalog, Tracee and probe-read queue keep their runtime bytes. ARM runtime admission rules added:0.\n')
 with tarfile.open(O/'inputs.tar.gz','w:gz') as tf:
  for n in ['shared-successor.py','shared-successor.patch','Makefile','inside-module.sh','successor-build.log']:tf.add(G/n,arcname=n)
  for root in [G/'module-source',G/'include']:
   for p in sorted(root.rglob('*')):
    if p.is_file():tf.add(p,arcname=str(p.relative_to(G)))
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 paths=[O/'build.json',O/'README.md',O/'inputs.tar.gz']
 if mod.exists():paths.append(O/mod.name)
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Build ARM ordinary copy shared submission successor','arm-shared-submit-successor')
 save('finished',publication=rec,build_exit=run.returncode,module_sha256=report.get('module_sha256'))
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/S10/V/R '+now()+': PUSHED '+rec['commit']+' sharedordinaryELFcopy successor ARM module buildexit'+str(run.returncode)+'. Exactc2bsharedheaderremovalappliedoverc3privatebuild; pairedS10b0three-descriptorsource/currentwarmcache retained. Soleapprovedextentboundbelongsactualx86chunkcopy. ActiveNULLcohortd433captureshistoricalc6df; full/Tracee/probequeue runtimebytesretained. ARM runtimeadmissionrulesadded0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
