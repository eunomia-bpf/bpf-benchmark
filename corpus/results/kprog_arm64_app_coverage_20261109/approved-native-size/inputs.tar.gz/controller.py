from pathlib import Path
import subprocess,json,datetime,hashlib,shutil,tarfile,importlib.util,traceback,os
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;B=A/'native-load-recovery/arm64';O=R/'corpus/results/kprog_arm64_app_coverage_20261109/approved-native-size'
O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
try:
 save('preparing_incremental_paired_module')
 for name in ['module-source','include','module-output']:shutil.copytree(B/name,G/name,dirs_exist_ok=True,symlinks=True)
 # Retain current paired ARM recovery source including all3 kfunc descriptors.
 module_rel='kinsn/module/arm64/bpf_arm64_native_lab.c'
 module_source=subprocess.check_output(['git','show','b0e107ce6:'+module_rel],cwd=R)
 (G/'module-source/bpf_arm64_native_lab.c').write_bytes(module_source)
 patch=subprocess.check_output(['git','diff','c3d6523f8^','c3d6523f8','--','kinsn/module/include/native_lab_trusted.h'],cwd=R).decode()
 patch=patch.replace('a/kinsn/module/include/','a/include/').replace('b/kinsn/module/include/','b/include/')
 (G/'approved-shared.patch').write_text(patch)
 subprocess.run(['git','apply','--unsafe-paths',str(G/'approved-shared.patch')],cwd=G,check=True)
 make='R := /workspaces/repository\nG := '+str(G)+'\n.PHONY: modules\nmodules:\n\t$(MAKE) -C $(R)/vendor/build/arm64/linux M=$(G)/module-source MO=$(G)/module-output ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- -j2 modules\n'
 (G/'Makefile').write_text(make)
 inside=(B/'inside-module.sh').read_text().replace('exec make -f '+str(B/'Makefile')+' modules','exec make -f '+str(G/'Makefile')+' modules')
 (G/'inside-module.sh').write_text(inside)
 report=dict(utc=now(),scope='Incremental ARM module build for coordinator-approved1GiB native-copy extent',approval='COORDINATOR DECISIONS2026-11-09 06:55, native_size at least1GiB returns E2BIG at copy time',shared_source='c3d6523f8',paired_recovery_module_source='b0e107ce6',runtime_kernel='f1caa1cd9/e5a3270f0 preserved Image/module symbol epoch',incremental_cache=str(A/'design-only/stack-frame/kernel-link/cache'),module_cache_seed=str(B/'module-output'),shared_patch_sha256=sha(G/'approved-shared.patch'),source_sha256={str(p.relative_to(G)):sha(p) for root in [G/'module-source',G/'include'] for p in root.rglob('*') if p.is_file()},production_source_edits=0,additional_runtime_admission_rules=0)
 save('building_incremental_ARM_module')
 with (G/'build.log').open('w') as log:
  run=subprocess.run(['taskset','-c','12-15','unshare','--mount','--propagation','private','sh',str(G/'inside-module.sh')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 report['build_exit']=run.returncode
 mod=G/'module-output/bpf_arm64_native_lab.ko'
 if mod.exists():report['module_sha256']=sha(mod);shutil.copy2(mod,O/mod.name)
 (O/'build.json').write_text(json.dumps(report,indent=2)+'\n')
 (O/'README.md').write_text('Approved ARM native-copy extent module\n\nCoordinator decision2026-11-09 06:55 supplies the shared native_size >=1GiB E2BIG behavior at kernel copy time. Shared source c3d6523f8 contributes its exact two-line patch to the captured ARM include tree. Paired ARM module source b0e107ce6 carries the existing recovery and three kfunc descriptors. The existing prepared ARM kernel cache and module outputs supply the incremental build. The captured recovery Image, original catalog/Tracee guests and probe-read queue retain their runtime bytes. This receipt records module compilation; actual guest adoption has its own result. Additional runtime admission rules:0.\n')
 with tarfile.open(O/'inputs.tar.gz','w:gz') as tf:
  for name in ['controller.py','Makefile','inside-module.sh','approved-shared.patch','build.log']:tf.add(G/name,arcname=name)
  for root in [G/'module-source',G/'include']:
   for p in sorted(root.rglob('*')):
    if p.is_file():tf.add(p,arcname=str(p.relative_to(G)))
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 paths=[O/'README.md',O/'build.json',O/'inputs.tar.gz']
 if mod.exists():paths.append(O/mod.name)
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Build coordinator approved native copy extent in ARM module cache','arm-approved-native-size-module')
 save('finished',publication=rec,build_exit=run.returncode,module_sha256=report.get('module_sha256'))
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/S10/V/R '+now()+': PUSHED '+rec['commit']+' approvedc3d1GiBcopyextent ARM incrementalmodule buildexit'+str(run.returncode)+'. Seedexistingwarmkernel+modulecache; pairedS10b0 source3descriptors andcapturedARMinclude+exactapproved2linepatch. Originalcurrentguest/queueImage/modulebytesretaincapture. Privatecomponentonly; actualguestadoptionhasseparatereceipt. Additionalruntimeadmissionrules0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
