/var/tmp/kprog-tmp/A/opensnoop-ret-order/native/original-fixed.native.o: \
  /var/tmp/kprog-tmp/A/opensnoop-ret-order/opensnoop.before.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /var/tmp/kprog-tmp/A/opensnoop-ret-order/src/arm64/vmlinux.h \
  /var/tmp/kprog-tmp/A/opensnoop-ret-order/src/opensnoop.h
