/var/tmp/kprog-tmp/A/opensnoop-ret-order/native/reordered.native.o: \
  /var/tmp/kprog-tmp/A/opensnoop-ret-order/src/opensnoop.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /var/tmp/kprog-tmp/A/opensnoop-ret-order/src/arm64/vmlinux.h \
  /var/tmp/kprog-tmp/A/opensnoop-ret-order/src/opensnoop.h
