from pathlib import Path
import os,select,json,datetime,subprocess,tarfile,shutil,hashlib,shlex,difflib,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=Path(__file__).resolve().parent
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(D/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase)|kw,indent=2)+'\n')
try:
 save('queued_after_ghost_trial_archive')
 try:
  fd=os.pidfd_open(3574578);select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 D.joinpath('src').mkdir(exist_ok=True);D.joinpath('native').mkdir(exist_ok=True)
 for p in (R/'vendor/bpf/bcc/libbpf-tools').rglob('*'):
  if p.is_file() and p.suffix in ['.c','.h']:
   q=D/'src'/p.relative_to(R/'vendor/bpf/bcc/libbpf-tools');q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 p=D/'src/opensnoop.bpf.c';before=p.read_text();after=before.replace('\t/* event data */\n','\t/* event data */\n\tevent.ret = ret;\n').replace('\tevent.flags = ap->flags;\n\tevent.ret = ret;','\tevent.flags = ap->flags;')
 p.write_text(after);(D/'opensnoop.before.bpf.c').write_text(before)
 (D/'source.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/libbpf-tools/opensnoop.bpf.c',tofile='b/libbpf-tools/opensnoop.bpf.c',n=0)))
 change=dict(before_sha256=hashlib.sha256(before.encode()).hexdigest(),after_sha256=hashlib.sha256(after.encode()).hexdigest(),change='Move event.ret=ret to the first event-data assignment before helper calls, shortening native scalar liveness.',preserved='Fields, sizes, helper calls, branches, bounds, context reads and final return values retain their original definitions.',scope='Private native producer trial; paired original-source JIT/native application remains the active baseline cohort.')
 (D/'change.json').write_text(json.dumps(change,indent=2)+'\n')
 # The same archived generic model source serves each producer profile.
 with tarfile.open(R/'corpus/results/kprog_arm64_app_coverage_20261109/ghost-state-layouts/raw.tar.gz') as tf:
  for m in tf:
   if m.isfile() and m.name.startswith('ghost-tag-layout/source/'):
    rel=m.name[len('ghost-tag-layout/source/'):];q=D/'model-source'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(tf.extractfile(m).read());q.chmod(m.mode)
  for rel in ['kprog/arm64/arm64_sim_local_bpf.h','kprog/arm64/micro-prog/arm64_abi.py','kprog/arm64/micro-prog/generate_micro_sim_proofs.py']:
   q=D/'model-source'/rel;q.write_bytes(tf.extractfile('scalar-cell-layout/source/'+rel).read())
 base=next(r['original_command'] for r in json.loads(Path('/var/tmp/kprog-tmp/A/bcc-native-os/commands.json').read_text()) if r['unit']=='bcc/opensnoop')
 commands=[];mk='.PHONY: all original reordered original-fixed reordered-fixed generation\nall: original reordered original-fixed reordered-fixed generation\n'
 for label in ['original','reordered','original-fixed','reordered-fixed']:
  cmd=base.copy();cmd[cmd.index('-o')+1]=str(D/'native'/(label+'.native.o'));cmd[cmd.index('-MF')+1]=str(D/'native'/(label+'.native.d'))
  cmd[cmd.index('bcc/libbpf-tools/opensnoop.bpf.c')]=str(D/'opensnoop.before.bpf.c') if label.startswith('original') else str(p)
  cmd=[a.replace('-I'+str(R/'vendor/bpf/bcc/libbpf-tools'),'-I'+str(D/'src')) for a in cmd]
  if label.endswith('-fixed'):cmd.extend('-ffixed-x'+str(n) for n in range(22,26))
  commands.append(dict(label=label,command=cmd));mk+=label+':\n\tcd '+str(R/'vendor/bpf')+' && '+shlex.join(cmd)+'\n'
 mk+='generation:\n\tpython3 '+str(D/'worker.py')+'\n'
 (D/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');(D/'Makefile').write_text(mk)
 rows=[]
 save('native_producer_compilation',change=change)
 for label in [r['label'] for r in commands]:
  with (D/(label+'.log')).open('w') as log:
   proc=subprocess.run(['make','-f',str(D/'Makefile'),label],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  rows.append(dict(label=label,exit=proc.returncode))
 with (D/'generation.log').open('w') as log:
  proc=subprocess.run(['unshare','--mount','--propagation','private','python3',str(D/'inside.py')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 save('finished',native=rows,generation_exit=proc.returncode,change=change)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
