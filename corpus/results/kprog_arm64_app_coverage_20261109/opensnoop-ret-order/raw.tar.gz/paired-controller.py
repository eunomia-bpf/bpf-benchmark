from pathlib import Path
import os,select,json,datetime,subprocess,tarfile,shutil,hashlib,shlex,importlib.util,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261109/opensnoop-ret-order'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(D/'paired-status.json').write_text(json.dumps(dict(utc=now(),phase=phase)|kw,indent=2)+'\n')
try:
 save('queued_after_native_producer_trial')
 try:
  fd=os.pidfd_open(3577969);select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 save('paired_JIT_build')
 src=D/'src';upstream=R/'vendor/repos/bcc/libbpf-tools'
 for p in upstream.iterdir():
  if p.is_file() and p.suffix in ['.c','.h'] and not (src/p.name).exists():shutil.copy2(p,src/p.name)
 shutil.copy2(upstream/'Makefile',D/'upstream.Makefile')
 (D/'jit').mkdir(exist_ok=True)
 sysroot=R/'.cache/aarch64-sysroot'
 includes=' '.join('-I'+str(p) for p in [D/'jit',R/'runner/build-arm64-llvmbpf/vendor/libbpf/prefix/include',R/'vendor/repos/bcc/src/cc/libbpf/include/uapi',sysroot/'usr/include',sysroot/'usr/include/aarch64-linux-gnu'])
 cmd=['make','--no-print-directory','-f',str(D/'upstream.Makefile'),'opensnoop','V=1','APPS=opensnoop','ARCH=arm64','USE_BLAZESYM=0','CC=aarch64-linux-gnu-gcc','CLANG=clang-18','LLVM_STRIP=llvm-strip-18','OUTPUT='+str(D/'jit'),'BPFTOOL='+str(R/'vendor/build/x86/bpftool/bin/bpftool'),'LIBBPF_OBJ='+str(R/'runner/build-arm64-llvmbpf/vendor/libbpf/pic-obj/libbpf.a'),'INCLUDES='+includes,'CFLAGS=-g -O2 -Wall','BPFCFLAGS=-g -O2 -Wall','LDFLAGS=-static -L'+str(sysroot/'usr/lib/aarch64-linux-gnu')+' -Wl,--start-group -lelf -lz -lzstd -Wl,--end-group']
 (D/'paired.Makefile').write_text('.PHONY: jit\njit:\n\tcd '+str(src)+' && '+shlex.join(cmd)+'\n')
 with (D/'paired-build.log').open('w') as log:build=subprocess.run(['make','-f',str(D/'paired.Makefile'),'jit'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 O.mkdir(exist_ok=True)
 report=dict(utc=now(),source_change=json.loads((D/'change.json').read_text()),native=json.loads((D/'status.json').read_text()),generation=json.loads((D/'generation.json').read_text()),paired_JIT_build_exit=build.returncode,paired_JIT_command=cmd,scope='Private same-source JIT/native opensnoop liveness/compiler trial; full application retains its own captured paired source epoch.',runtime_admission_additions=0)
 if (src/'opensnoop').exists():report['paired_JIT_binary_sha256']=sha(src/'opensnoop')
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'raw.tar.gz','w:gz') as tf:
  for p in sorted(D.rglob('*')):
   if p.is_file():tf.add(p,arcname=str(p.relative_to(D)))
 newpatch=R/'corpus/results/kprog_app_source_changes/bcc-opensnoop-event-ret-order.patch';newpatch.write_bytes((D/'source.patch').read_bytes())
 lines=['Paired ARM opensnoop local event liveness trial','','The authorized original C edit moves event.ret=ret to the first event-data assignment before helper calls. The event stays private until the existing perf-output helper; its fields, field sizes, helper calls, branches, bounds and return value retain the same definitions. The store order shortens scalar ret liveness across helpers. The paired JIT BPF/skeleton/upstream application and reordered native profiles share the exact edited C/header tree; original profiles retain the original C. Same-source edited C SHA'+report['source_change']['after_sha256']+'.','',
 'Native O3 and common fixed22-25 allocation variants measure both original and reordered source against the same private generic scalar-cell model. Actual results:']
 for r in report['generation']:lines.append('- '+r['profile']+': '+r['phase']+', B frame'+str(r.get('frame_extent_bytes'))+'.')
 lines+=['','Paired JIT build exit:'+str(build.returncode)+'. Exact sources, source patch, compiler commands, native/BPF objects, skeleton, application binary, model overrides and logs accompany raw.tar.gz. Full QEMU application/verifier evidence belongs to the captured whole-app cohort. Runtime admission additions:0.']
 (O/'README.md').write_text('\n'.join(lines)+'\n')
 paths=[str((O/n).relative_to(R)) for n in ['summary.json','raw.tar.gz','README.md']]+[str(newpatch.relative_to(R))]
 ledger=R/'corpus/results/kprog_app_source_changes/README.md'
 current=subprocess.check_output(['git','show','HEAD:'+str(ledger.relative_to(R))],cwd=R)
 if ledger.read_bytes()==current:
  with ledger.open('a') as f:f.write('\nBCC opensnoop [event return-store order patch](bcc-opensnoop-event-ret-order.patch) moves event.ret=ret to the first local event-data assignment before helper calls. The private event reaches the existing perf-output helper with the same fields, sizes, helper calls, branches, bounds and final return. This shortens ret liveness in native P. The edited JIT BPF/skeleton/application and native P consume the same captured C/header tree; original-source controls retain their own original inputs. Paired compile/layout receipts and every source/profile command are in ../kprog_arm64_app_coverage_20261109/opensnoop-ret-order/. The patch uses zero-context hunks and applies with git apply --unidiff-zero from the BCC root. Current whole-app and kernel safety cohorts retain their captured published source.\n')
  paths.append(str(ledger.relative_to(R)))
 else:
  with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': opensnoop ret-order source ledger append queues behind concurrent ledger work; private source/patch/build receipts published separately.\n')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish(paths,'Record paired opensnoop event-store liveness trial','arm-opensnoop-ret-order-trial')
 save('finished',publication=rec,report=report)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+rec['commit']+' paired opensnoop event.ret store-order source trial/patch ledger. Same original C instructions except ret stored before helpers; fields/sizes/helper calls/branches/limits/return retained. Native4profiles '+json.dumps([{k:r.get(k) for k in ['profile','phase','frame_extent_bytes']} for r in report['generation']])+', same-edited-source JIT build'+str(build.returncode)+'. Private scalar-cell model measured, canonical555/current fullBCC/uniformcatalog source retained. Source/raw/commands/P/B/JIT binary archived. New predicates0.\n')
 for name in ['src','model-source','native','generated','jit']:
  root=D/name
  if root.exists():shutil.rmtree(root)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
