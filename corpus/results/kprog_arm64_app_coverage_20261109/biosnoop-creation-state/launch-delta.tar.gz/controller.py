from pathlib import Path
import subprocess,tarfile,json,datetime,hashlib,shutil,os,gzip,collections,importlib.util,io,traceback,re
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=Path('/var/tmp/kprog-tmp/A/biosnoop-creation-state');G=Path(__file__).resolve().parent;K=Path('/var/tmp/kprog-tmp/A/probe-read/lowering/applications');O=R/'corpus/results/kprog_arm64_app_coverage_20261109/biosnoop-creation-state';O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('capturing_paired_build')
 build=dict(utc=now(),source_publication='0185e288bd959906a4b7058a39e5fa0edfe5f3b7',model_publication='55504ff906ab268a5cab3ab083d6d448d152ed54',change=json.loads((D/'change.json').read_text()),commands=json.loads((D/'commands.json').read_text()),initial_status=json.loads((D/'status.initial.json').read_text()),static_link_status=json.loads((D/'jit-status.json').read_text()),generation=json.loads((D/'generation.json').read_text()),artifacts={str(p.relative_to(D)):sha(p) for p in [D/'src/biosnoop.bpf.c',D/'src/biosnoop',D/'jit/biosnoop.bpf.o',D/'jit/biosnoop.skel.h',D/'biosnoop.O3.native.o',D/'biosnoop.Os.native.o',D/'generated/O3/trusted_arm64.bpf.o',D/'generated/Os/trusted_arm64.bpf.o']},runtime_admission_additions=0)
 (O/'build.json').write_text(json.dumps(build,indent=2)+'\n')
 with tarfile.open(O/'build-inputs.tar.gz','w:gz') as tf:
  for p in sorted(D.rglob('*')):
   if p.is_file() and 'application' not in p.relative_to(D).parts:tf.add(p,arcname='build/'+str(p.relative_to(D)))
  for p in [R/'vendor/bpf/native_compat.h',Path('/var/tmp/kprog-tmp/A/probe-read/lowering/native_division.so'),Path('/var/tmp/kprog-tmp/A/probe-read/lowering/native_division.cpp')]:
   if p.exists():tf.add(p,arcname='compiler/'+p.name)
  for p in [R/'kprog/arm64/arm64_sim_local_bpf.h',R/'kprog/arm64/trusted_specializer.py',R/'kprog/arm64/micro-prog/arm64_abi.py',R/'kprog/arm64/micro-prog/generate_micro_sim_proofs.py']:tf.add(p,arcname='model/'+str(p.relative_to(R)))
 (O/'README.md').write_text('Paired ARM biosnoop creation-state replay\n\nThe operator-authorized creation-state patch0185e288b records the existing lookup result as new_stage. JIT and native use the same edited biosnoop.bpf.c SHA'+build['change']['after_sha256']+' and captured local headers. Native O3 and Os, JIT BPF, embedded upstream biosnoop binary, and both block_rq_insert B builds compile successfully. The initial static link records libelf ZSTD references; the paired incremental link supplies the existing zstd archive and succeeds. Exact commands, sources, objects, skeleton and logs accompany build.json/build-inputs.tar.gz.\n\nThe complete eight-tool BCC QEMU two-start application uses the O3 native variant, current implicit-SP release55504ff90, the same-copy f1/e5/3e3f runtime, all32original manifest rows and the frozen May29 framework. Biosnoop bytecode-length selectors follow the newly embedded object; every original symbol selector remains. Functional work and request outcomes are collected by the existing runner. Timing measures QEMU functionality. Runtime admission additions:0.\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['build.json','build-inputs.tar.gz','README.md']],'Build paired ARM biosnoop creation state inputs','arm-biosnoop-creation-paired-build')
 save('preparing_complete_BCC',build_publication=rec)
 queued=json.loads((R/'corpus/results/kprog_arm64_app_coverage_20261109/probe-read/lowering/applications/queued.json').read_text())['applications']['bcc']
 archives=[queued['base_archive'],queued['delta_archive'],'corpus/results/kprog_arm64_app_coverage_20261109/frame-equality/application/launch-delta.tar.gz']
 for archive in archives:
  with tarfile.open(R/archive) as tf:
   for m in tf:
    if m.isfile() and (m.name.startswith('source/') or m.name=='manifests/bcc.json'):
     p=G/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tf.extractfile(m).read());p.chmod(m.mode)
 source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 frozen_prefixes=['runner/libs/workload.py','runner/libs/app_runners','corpus/driver.py','corpus/config','micro/driver.py','micro/config','micro/programs','Makefile','micro/Makefile','runner/mk']
 frozen=subprocess.check_output(['git','ls-tree','-r','--name-only',source_head,*frozen_prefixes],cwd=R,text=True).splitlines()
 for rel in frozen:
  q=G/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(subprocess.check_output(['git','show',source_head+':'+rel],cwd=R))
 rel='kprog/arm64/arm64_sim_local_bpf.h';(G/'source'/rel).write_bytes(subprocess.check_output(['git','show','55504ff906ab268a5cab3ab083d6d448d152ed54:'+rel],cwd=R))
 aliases={'native-link':'native-link','native-link-arm64-entry-resources':'native-link','libnative_loader.so':'libnative_loader.so','trusted-native-loader':'trusted-native-loader','trusted-service-client':'trusted-service-client'}
 for p in (G/'source').rglob('*'):
  if p.is_file() and p.name in aliases:shutil.copy2(K/'runtime'/aliases[p.name],p)
 shutil.copy2(D/'biosnoop.O3.native.o',G/'source/kprog/arm64/build/app-verified-stage/bcc/biosnoop.native.o')
 manifest=json.loads((G/'manifests/bcc.json').read_text())
 symbols=subprocess.check_output(['llvm-objdump-18','--syms',str(D/'jit/biosnoop.bpf.o')],text=True)
 lengths={m.group(2):int(m.group(1),16) for l in symbols.splitlines() if (m:=re.search(r'\bg\s+F\s+\S+\s+([0-9a-f]+)\s+(\w+)$',l))}
 selector_changes=[]
 for row in manifest['objects']:
  if 'biosnoop' in row['native_object']:
   length=lengths[row['symbol']];selector_changes.append(dict(symbol=row['symbol'],before=row['source_bytecode_len'],after=length));row['source_bytecode_len']=length
 (G/'manifests/bcc.json').write_text(json.dumps(manifest,indent=2)+'\n')
 transport=(K/'bcc/transport.py').read_text().replace('security_model=none,readonly=on','security_model=none,multidevs=remap,readonly=on').replace("str(ROOT) + ',security_model=none'","str(ROOT) + ',security_model=none,multidevs=remap'")
 (G/'transport.py').write_text(transport)
 mount=(K/'bcc/mount.py').read_text().replace('K=G.parent','K=Path('+repr(str(K))+')')
 mount='\n'.join(l for l in mount.splitlines() if "if app=='bcc':subprocess.run" not in l)+'\n'
 marker="os.execvp('make'"
 i=mount.index(marker)
 mount=mount[:i]+"subprocess.run(['mount','--bind',"+repr(str(D/'src/biosnoop'))+",str(R/'kprog/arm64/build/app-runtime-v35/root/usr/local/bin/biosnoop')],check=True)\n"+mount[i:]
 (G/'mount.py').write_text(mount)
 (G/'Makefile').write_text('.PHONY: application\napplication:\n\t$(MAKE) -f corpus/results/kprog_arm64_app_coverage_20261106/Makefile trusted-service-arm64-run TRUSTED_APP=$(APP) TRUSTED_RESULTS='+str(O/'application')+'\n')
 pins={str(p.relative_to(G/'source')):sha(p) for p in (G/'source').rglob('*') if p.is_file()}
 launch=dict(utc=now(),build_publication=rec['commit'],source_publication='0185e288bd959906a4b7058a39e5fa0edfe5f3b7',model_publication='55504ff906ab268a5cab3ab083d6d448d152ed54',framework_capture=source_head,framework_files={rel:pins[rel] for rel in frozen},base_archives=archives,source_sha256=pins,runtime_sha256={str(p.relative_to(K/'runtime')):sha(p) for p in (K/'runtime').rglob('*') if p.is_file()},native_manifest_rows=len(manifest['objects']),biosnoop_selectors=selector_changes,biosnoop_binary_sha256=sha(D/'src/biosnoop'),guest=dict(memory_MiB=2048,cpu='16-19'),runtime_admission_additions=0)
 (O/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
 with tarfile.open(O/'launch-delta.tar.gz','w:gz') as tf:
  old=json.loads((R/'corpus/results/kprog_arm64_app_coverage_20261109/frame-equality/application/launch.json').read_text())['source_sha256']
  for p in sorted((G/'source').rglob('*')):
   if p.is_file() and old.get(str(p.relative_to(G/'source')))!=sha(p):tf.add(p,arcname=str(p.relative_to(G)))
  for name in ['controller.py','mount.py','transport.py','Makefile','manifests/bcc.json']:tf.add(G/name,arcname=name)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['launch.json','launch-delta.tar.gz']],'Run complete ARM BCC with paired biosnoop creation state','arm-biosnoop-creation-application-launch')
 save('actual_complete_application',publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/R/V '+now()+': PUSHED '+rec['commit']+' complete eight-tool ARM BCC paired biosnoop creation-state0185 replay launched2GiB16-19. JIT/native O3 share edited sourceSHA'+build['change']['after_sha256']+'; all32manifestrows retained, four biosnoop bytecode lengths refreshed from embedded BPF. O3/Os native+B builds and JIT upstream binary compile0. Canonical model555implicitSP and captured f1/e5/3e3f runtime; frozen May29 framework bytes captured. Existing 9p multidevs=remap preserves individual file-bind visibility. Runtime admission additions0.\n')
 with (G/'application.log').open('w') as log:
  p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','python3',str(G/'mount.py'),'bcc'],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 Q=O/'application/trusted-arm64-bcc-result';Q.mkdir(parents=True,exist_ok=True);(Q/'driver.log.gz').write_bytes(gzip.compress((G/'application.log').read_bytes(),mtime=0));paths=[Q/'driver.log.gz'];report=dict(utc=now(),make_exit=p.returncode)
 if (Q/'summary.json').exists():
  summary=json.loads((Q/'summary.json').read_text());archive=Q/summary['archive'];scope=dict(Path=Path,Counter=collections.Counter,tarfile=tarfile,io=io,json=json,hashlib=hashlib,now=now);exec(compile((A/'design-only/app-coverage.py').read_text(),'coverage','exec'),scope);report['coverage']=scope['coverage'](summary,archive);paths.extend([Q/'summary.json',archive])
 (Q/'coverage.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(Q/'coverage.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect complete ARM BCC paired biosnoop outcomes','arm-biosnoop-creation-application-terminal')
 save('finished',publication=rec,make_exit=p.returncode)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/R/V '+now()+': PUSHED '+rec['commit']+' complete ARM BCC paired biosnoop application Makeexit'+str(p.returncode)+'. All original full-app outcomes retained; runtime admission additions0.\n')
 retired=[]
 for root in [G/'source',G/'manifests',D/'src',D/'jit',D/'generated']:
  size=sum(p.stat().st_size for p in root.rglob('*') if p.is_file());shutil.rmtree(root);retired.append(dict(path=str(root),bytes=size))
 (G/'cleanup.json').write_text(json.dumps(dict(utc=now(),publication=rec,retired=retired),indent=2)+'\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
