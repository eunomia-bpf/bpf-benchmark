from pathlib import Path
import datetime,json,hashlib,subprocess,re,tarfile,collections,importlib.util,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;F=G.parent;Q=F/'applications';O=R/'corpus/results/kprog_arm64_app_coverage_20261109/probe-read/lowering/entry-static'
O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def functions(p):
 run=subprocess.run(['llvm-nm-18','--print-size','--defined-only','--format=posix',str(p)],capture_output=True,text=True)
 if run.returncode:raise RuntimeError(run.stderr)
 sizes={}
 for line in run.stdout.splitlines():
  a=line.split()
  if len(a)==4 and a[1] in ['T','t']:sizes[a[0]]=int(a[3],16)
 stats={};current=None
 for line in p.with_suffix('.dis').read_text().splitlines():
  label=re.match(r'^\s*[0-9a-f]+ <([^>]+)>:\s*$',line)
  if label:current=label[1];stats[current]=collections.Counter();continue
  ins=re.match(r'^\s*[0-9a-f]+:\s+([a-z][a-z0-9.]+)\b',line)
  if ins and current:
   stats[current]['instructions']+=1
   if ins[1] in ['bl','blr']:stats[current]['calls']+=1
 return sizes,{k:dict(v) for k,v in stats.items()},run.stdout
try:
 save('measuring_actual_entry_functions')
 c=json.loads((R/'corpus/results/kprog_arm64_app_coverage_20261109/probe-read/lowering/paired-control/summary.json').read_text())
 native={};raw=[]
 for row in c['rows']:
  unit=row['unit'];pair={}
  for label,root in [('control',F/'paired-control'),('candidate',F)]:
   p=root/'native'/(unit+'.native.o');sizes,stats,output=functions(p);pair[label]=dict(sizes=sizes,stats=stats,sha256=sha(p));raw.append((unit,label,output))
  native[Path(unit).name+'.native.o']=(unit,pair)
 rows=[]
 for app in ['bcc','tracee']:
  manifest=Q/app/'manifests'/(app+'.json')
  for ordinal,m in enumerate(json.loads(manifest.read_text())['objects']):
   row=dict(app=app,manifest_ordinal=ordinal,program=m.get('program',''),symbol=m.get('symbol'),native_object=m['native_object'])
   match=native.get(Path(m['native_object']).name)
   if match:
    unit,pair=match;row.update(unit=unit,source='Paired actual native compiler objects')
    symbols=[m['symbol']] if m.get('symbol') else sorted(symbol for symbol in pair['control']['sizes'] if symbol[:15]==m['program'][:15])
    row['entry_name_selection']='Explicit manifest symbol' if m.get('symbol') else 'Full ELF symbol set sharing captured 15-byte program name; actual loader context selects the entry'
    row['entries']=[]
    for symbol in symbols:
     e=dict(symbol=symbol)
     for label,body in pair.items():
      e[label]=dict(object_sha256=body['sha256'],entry_symbol_bytes=body['sizes'].get(symbol),disassembly=body['stats'].get(symbol))
     row['entries'].append(e)
   else:
    p=Q/app/'source'/Path(m['native_object']).relative_to(R)
    row.update(source='Retained captured startup P input',retained_sha256=sha(p),retained_bytes=p.stat().st_size)
   rows.append(row)
 report=dict(utc=now(),scope='Complete raw manifest row static entry attribution; ELF entry body sizes and actual disassembly calls',candidate_publication='5bbbf128a2c47bf102376fb28c90df6cd14191a2',control_publication='948835b72a7850f94829b7f21733e504fccd6a87',manifest_rows=dict(collections.Counter(r['app'] for r in rows)),measurement='Each entry body retains its original manifest symbol; linked reachable subprograms and workload-frequency weighting retain separate measurements',rows=rows,runtime_admission_additions=0)
 (O/'entries.json').write_text(json.dumps(report,indent=2)+'\n')
 with (G/'native-symbols.txt').open('w') as f:
  for unit,label,output in raw:f.write('\n'+unit+' '+label+'\n'+output)
 md=['# ARM native producer entry attribution','','All32BCC and123Tracee raw manifest rows remain in entries.json. Actual paired native ELF symbols supply entry-body bytes and disassembly calls. Rows with runtime-selected symbols retain every full ELF name sharing the captured 15-byte program name; the actual application load context supplies the final choice. Captured startup inputs retain their original hashes. These entry-body measurements accompany the complete eleven-object native payloads; actual linked reachable subprograms and workload-frequency weighting have their own measurements. C/R can join the retained full symbol names to application work counters.','','| App | Symbol | Control entry bytes | Candidate entry bytes | Control calls | Candidate calls |','| --- | --- | ---: | ---: | ---: | ---: |']
 for r in rows:
  for e in r.get('entries',[]):
   c=e['control'];n=e['candidate']
   calls=lambda x: str(x['disassembly'].get('calls',0)) if x['disassembly'] is not None else 'pending symbol-label mapping'
   md.append('| '+r['app']+' | '+e['symbol']+' | '+str(c['entry_symbol_bytes'])+' | '+str(n['entry_symbol_bytes'])+' | '+calls(c)+' | '+calls(n)+' |')
 md+=['','Runtime admission additions:0.','']
 (O/'README.md').write_text('\n'.join(md))
 with tarfile.open(O/'inputs.tar.gz','w:gz') as tf:
  tf.add(G/'controller.py',arcname='controller.py');tf.add(G/'native-symbols.txt',arcname='native-symbols.txt')
  for app in ['bcc','tracee']:tf.add(Q/app/'manifests'/(app+'.json'),arcname='manifests/'+app+'.json')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['entries.json','README.md','inputs.tar.gz']],'Attribute ARM scalar read compiler effects to complete app entry lists','arm-probe-read-entry-static')
 save('finished',publication=rec,manifest_rows=report['manifest_rows'])
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/R/V '+now()+': PUSHED '+rec['commit']+' staticentryattribution complete32BCC/123Traceerawmanifestrows. ActualpairedELFentrysizes/disassemblycalls/sourcehashesretainfullsymbols; startupinputsretainoriginalbytes. Entry-body metrics joinactualworkcounters separatelyfromlinkedsubprogramsize andthroughput. Originalcurrentguestsandwholequeuecontinue. Runtimeadmissionadditions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
