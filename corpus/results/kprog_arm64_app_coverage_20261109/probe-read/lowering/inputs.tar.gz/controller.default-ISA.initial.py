from pathlib import Path
from collections import Counter
import datetime,hashlib,importlib.util,json,os,re,struct,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261109/probe-read/lowering';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def run(cmd,path):
 with path.open('w') as f:return subprocess.run(cmd,cwd=R/'vendor/bpf',stdout=f,stderr=subprocess.STDOUT).returncode
def text_bytes(p):
 b=p.read_bytes();off=struct.unpack_from('<Q',b,40)[0];size,n=struct.unpack_from('<HH',b,58)
 return sum(struct.unpack_from('<IIQQQQIIQQ',b,off+i*size)[5] for i in range(n) if struct.unpack_from('<IIQQQQIIQQ',b,off+i*size)[2]&4)
try:
 save('building_existing_native_plugin_target')
 plugin=G/'native_division.so';cmd=['make','--no-print-directory','-f',str(G/'Makefile'),'NATIVE_DIVISION_PLUGIN='+str(plugin),str(plugin)]
 rc=run(cmd,G/'plugin.log');rows=[]
 baseline=json.loads((R/'corpus/results/kprog_arm64_app_coverage_20261109/probe-read/inventory.json').read_text())
 if rc==0:
  for unit in baseline['units']:
   name=unit['unit'];out=G/'native'/(name+'.native.o');out.parent.mkdir(parents=True,exist_ok=True)
   cmd=list(unit['command']);cmd[cmd.index('-o')+1]=str(out)
   cmd=[x for x in cmd if x not in ['-S','-emit-llvm']]
   cmd+=['-c'];cmd=[('-fpass-plugin='+str(plugin)) if x.startswith('-fpass-plugin=') else x for x in cmd];cmd[cmd.index('-MF')+1]=str(out.with_suffix('.d'))
   save('compiling_actual_native_P',unit=name,completed=len(rows))
   cr=run(cmd,out.with_suffix('.compile.log'));row=dict(unit=name,compile_exit=cr,command=cmd)
   if out.exists():
    row.update(bytes=out.stat().st_size,sha256=sha(out),executable_bytes=text_bytes(out))
    ds=subprocess.run(['llvm-objdump-18','-dr','--no-show-raw-insn',str(out)],text=True,capture_output=True);out.with_suffix('.dis').write_text(ds.stdout+ds.stderr);row['disassembly_exit']=ds.returncode
    row['instructions']=len(re.findall(r'^\s*[0-9a-f]+:\s+[a-z][a-z0-9.]+\b',ds.stdout,re.M));row['static_call_sites']=len(re.findall(r'^\s*[0-9a-f]+:\s+bl(?:r)?\s',ds.stdout,re.M))
   ir=G/'IR'/(name+'.ll');ir.parent.mkdir(parents=True,exist_ok=True);ir_cmd=[x for x in cmd if x!='-c'];ir_cmd[ir_cmd.index('-o')+1]=str(ir);ir_cmd[ir_cmd.index('-MF')+1]=str(ir.with_suffix('.d'));ir_cmd+=['-S','-emit-llvm']
   ir_rc=run(ir_cmd,ir.with_suffix('.log'));row['IR_compile_exit']=ir_rc
   if ir.exists():
    s=ir.read_text();row.update(IR_sha256=sha(ir),scalar_read_asm_sites=len(re.findall(r'= (?:tail )?call i64 asm sideeffect "(?:ldrb|ldrh|ldr) ',s)))
   rows.append(row)
 report=dict(utc=now(),scope='Private ARM native P scalar probe-read lowering candidate; existing application C/native ABI/relocations',plugin_make_exit=rc,plugin_command=cmd if not rows else ['make','NATIVE_DIVISION_PLUGIN='+str(plugin),str(plugin)],plugin_sha256=sha(plugin) if plugin.exists() else None,source_sha256=sha(G/'native_division.cpp'),source_patch_sha256=sha(G/'candidate.patch'),compiler_callback='ScalarOptimizerLate, before subsequent standard scalar cleanup',source_scope='same8BCC and paired61c85Tracee3units',baseline_inventory='ef3acc532c38a444da382403473fc0f0b32fe2b2',rows=rows,runtime_admission_additions=0)
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');(O/'candidate.patch').write_bytes((G/'candidate.patch').read_bytes())
 md=['# ARM native scalar probe-read producer candidate','','The existing native compiler plugin lowers helper113 calls with a discarded return and a constant size1/2/4/8 to a single opaque native load and an exact-width destination store. The existing native exception-table destination-zero/resume defines its read-fault result. Named BCC calls and the actual final-input Tracee helper marker share this lowering. Live helper results, wider copies, strings and user-read operations retain their actual helper. Existing native ABI/relocation kinds, kernel/model and benchmark definitions retain their captured bytes.','','The pass runs at ScalarOptimizerLate so subsequent standard scalar cleanup can promote local destination slots. Opaque assembly retains the fault-defined native read through optimization. Actual source and outputs are captured in inputs.tar.gz; candidate.patch applies to the existing plugin source.','','Plugin Make exit:'+str(rc)+'. Native compile successes:'+str(sum(x['compile_exit']==0 for x in rows))+'/'+str(len(rows))+'. IR compile successes:'+str(sum(x['IR_compile_exit']==0 for x in rows))+'/'+str(len(rows))+'.','','| Unit | Compile exit | Executable bytes | Static calls | Lowered scalar sites in IR |','| --- | ---: | ---: | ---: | ---: |']
 for x in rows:md.append('| '+x['unit']+' | '+str(x['compile_exit'])+' | '+str(x.get('executable_bytes'))+' | '+str(x.get('static_call_sites'))+' | '+str(x.get('scalar_read_asm_sites'))+' |')
 md+=['','Generation-bound application replay follows the current complete catalog and paired Tracee terminal. These counts describe compiler-produced P; runtime acceptance, workload counters and hardware throughput retain their separate measurements.','']
 (O/'README.md').write_text('\n'.join(md))
 with tarfile.open(O/'inputs.tar.gz','w:gz') as tf:
  for p in sorted(G.rglob('*')):
   if p.is_file() and p.name not in ['controller.log','controller.pid','status.json']:tf.add(p,arcname=str(p.relative_to(G)))
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str(p.relative_to(R)) for p in sorted(O.iterdir()) if p.is_file()],'Build ARM scalar probe read native P candidate from paired application C','arm-probe-read-lowering-candidate')
 save('finished',publication=rec,plugin_make_exit=rc,compiled=sum(x['compile_exit']==0 for x in rows),IR_compiled=sum(x['IR_compile_exit']==0 for x in rows),attempted=len(rows),lowered_scalar_sites=sum(x.get('scalar_read_asm_sites',0) for x in rows))
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/S2/V/R '+now()+': PUSHED '+rec['commit']+' privateARM scalarprobe-read P compiler candidate, pluginMake'+str(rc)+', actualnative '+str(sum(x['compile_exit']==0 for x in rows))+'/'+str(len(rows))+', IR '+str(sum(x['IR_compile_exit']==0 for x in rows))+'/'+str(len(rows))+', actualscalarreadsites'+str(sum(x.get('scalar_read_asm_sites',0) for x in rows))+'. Existing recipe/plugin extension only; production compiler source retainsphysicalbytes. CallbackScalarOptimizerLate keeps ordinaryscalarcleanup afterlowering. Currentfull/Traceereplays staycaptured; actualapplication/hardware measurements follow. Runtimeadmissionadditions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
