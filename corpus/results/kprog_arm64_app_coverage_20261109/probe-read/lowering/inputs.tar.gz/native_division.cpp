// SPDX-License-Identifier: MIT
// Native input follows the eBPF integer quotient/remainder semantics.
#include <llvm/IR/Constants.h>
#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/InlineAsm.h>
#include <llvm/IR/PassManager.h>
#include <llvm/Passes/PassBuilder.h>
#include <llvm/Passes/PassPlugin.h>
#include <llvm/TargetParser/Triple.h>

namespace {
struct NativeDivision : llvm::PassInfoMixin<NativeDivision> {
    static bool isRequired() { return true; }
    llvm::PreservedAnalyses run(llvm::Function &function,
                               llvm::FunctionAnalysisManager &) {
        llvm::SmallVector<llvm::BinaryOperator *> divisions;
        for (auto &block : function)
            for (auto &instruction : block)
                if (auto *op = llvm::dyn_cast<llvm::BinaryOperator>(&instruction))
                    if (op->getOpcode() == llvm::Instruction::UDiv ||
                        op->getOpcode() == llvm::Instruction::SDiv ||
                        op->getOpcode() == llvm::Instruction::URem ||
                        op->getOpcode() == llvm::Instruction::SRem)
                        divisions.push_back(op);
        for (size_t cursor = 0; cursor < divisions.size(); ++cursor) {
            auto *op = divisions[cursor];
            auto *type = op->getType();
            if (auto *vector = llvm::dyn_cast<llvm::FixedVectorType>(type)) {
                llvm::IRBuilder<> scalarize(op);
                llvm::Value *result = llvm::PoisonValue::get(type);
                for (unsigned lane = 0; lane < vector->getNumElements(); ++lane) {
                    auto *left = scalarize.CreateExtractElement(op->getOperand(0), lane);
                    auto *right = scalarize.CreateExtractElement(op->getOperand(1), lane);
                    auto *element = llvm::BinaryOperator::Create(op->getOpcode(),
                        left, right, "native.div.lane", op);
                    divisions.push_back(element);
                    result = scalarize.CreateInsertElement(result, element, lane);
                }
                op->replaceAllUsesWith(result);
                op->eraseFromParent();
                continue;
            }
            auto *dividend = op->getOperand(0);
            auto *divisor = op->getOperand(1);
            bool sign = op->getOpcode() == llvm::Instruction::SDiv ||
                        op->getOpcode() == llvm::Instruction::SRem;
            bool remainder = op->getOpcode() == llvm::Instruction::URem ||
                             op->getOpcode() == llvm::Instruction::SRem;
            llvm::IRBuilder<> before(op);
            auto *zero = llvm::Constant::getNullValue(type);
            auto *is_zero = before.CreateICmpEQ(divisor, zero);
            llvm::Value *exception = is_zero;
            llvm::Value *exception_result = remainder ? dividend : zero;
            if (sign) {
                auto *minimum = llvm::ConstantInt::get(type,
                    llvm::APInt::getSignedMinValue(type->getScalarSizeInBits()));
                auto *minus_one = llvm::Constant::getAllOnesValue(type);
                auto *overflow = before.CreateAnd(
                    before.CreateICmpEQ(dividend, minimum),
                    before.CreateICmpEQ(divisor, minus_one));
                exception = before.CreateOr(is_zero, overflow);
                exception_result = before.CreateSelect(is_zero,
                    remainder ? dividend : zero, remainder ? zero : dividend);
            }
            auto *entry = op->getParent();
            auto *continuation = entry->splitBasicBlock(op, "native.div.join");
            auto *arithmetic = llvm::BasicBlock::Create(function.getContext(),
                "native.div.nonzero", &function, continuation);
            entry->getTerminator()->eraseFromParent();
            before.SetInsertPoint(entry);
            before.CreateCondBr(exception, continuation, arithmetic);
            llvm::IRBuilder<> calculate(arithmetic);
            llvm::Value *value;
            if (llvm::Triple(function.getParent()->getTargetTriple()).isX86() &&
                type->isIntegerTy() && type->getIntegerBitWidth() <= 64) {
                auto *word = type->getIntegerBitWidth() <= 32 ?
                    calculate.getInt32Ty() : calculate.getInt64Ty();
                auto *left = calculate.CreateIntCast(dividend, word, sign);
                auto *right = calculate.CreateIntCast(divisor, word, sign);
                auto *results = llvm::StructType::get(word, word);
                auto *signature = llvm::FunctionType::get(results, {word, word}, false);
                const char *assembly = sign ?
                    (word->isIntegerTy(64) ? "cqto; idivq $3" : "cltd; idivl $3") :
                    (word->isIntegerTy(64) ? "xorl %edx, %edx; divq $3" :
                                            "xorl %edx, %edx; divl $3");
                auto *divide = llvm::InlineAsm::get(signature, assembly,
                    "=&{ax},=&{dx},0,r,~{flags}", true);
                auto *pair = calculate.CreateCall(divide, {left, right});
                value = calculate.CreateIntCast(calculate.CreateExtractValue(pair,
                    remainder ? 1 : 0), type, sign);
            } else {
                value = calculate.CreateBinOp(op->getOpcode(), dividend, divisor);
            }
            calculate.CreateBr(continuation);
            auto *result = llvm::PHINode::Create(type, 2, "native.div.result", op);
            result->addIncoming(exception_result, entry);
            result->addIncoming(value, arithmetic);
            op->replaceAllUsesWith(result);
            op->eraseFromParent();
        }
        return divisions.empty() ? llvm::PreservedAnalyses::all() :
                                   llvm::PreservedAnalyses::none();
    }
};

// Discarded-return scalar kernel reads have a single-load destination effect.
// Native exception-table recovery clears the complete destination register.
struct NativeProbeRead : llvm::PassInfoMixin<NativeProbeRead> {
    llvm::PreservedAnalyses run(llvm::Function &function,
                               llvm::FunctionAnalysisManager &) {
        if (!llvm::Triple(function.getParent()->getTargetTriple()).isAArch64())
            return llvm::PreservedAnalyses::all();
        llvm::SmallVector<llvm::CallInst *> reads;
        for (auto &block : function)
            for (auto &instruction : block)
                if (auto *call = llvm::dyn_cast<llvm::CallInst>(&instruction))
                    if (call->arg_size() == 3 && call->use_empty())
                        reads.push_back(call);
        bool changed = false;
        for (auto *call : reads) {
            auto *callee = call->getCalledFunction();
            auto *cast = llvm::dyn_cast<llvm::IntToPtrInst>(call->getCalledOperand());
            llvm::CallInst *marker = nullptr;
            bool kernel_read = callee && callee->getName() == "bpf_probe_read_kernel";
            if (cast) {
                marker = llvm::dyn_cast<llvm::CallInst>(cast->getOperand(0));
                auto *identity = marker && marker->arg_size() == 4 ?
                    llvm::dyn_cast<llvm::ConstantInt>(marker->getArgOperand(3)) : nullptr;
                auto *code = marker ?
                    llvm::dyn_cast<llvm::InlineAsm>(marker->getCalledOperand()) : nullptr;
                kernel_read = code && code->getAsmString().empty() &&
                    code->getConstraintString() == "=r,r,r,r,0,~{memory}" &&
                    identity && identity->equalsInt(113);
            }
            if (!kernel_read)
                continue;
            auto *size = llvm::dyn_cast<llvm::ConstantInt>(call->getArgOperand(1));
            if (!size)
                continue;
            const char *assembly;
            switch (size->getZExtValue()) {
            case 1: assembly = "ldrb ${0:w}, [$1]"; break;
            case 2: assembly = "ldrh ${0:w}, [$1]"; break;
            case 4: assembly = "ldr ${0:w}, [$1]"; break;
            case 8: assembly = "ldr $0, [$1]"; break;
            default: continue;
            }
            llvm::IRBuilder<> builder(call);
            builder.SetCurrentDebugLocation(call->getDebugLoc());
            auto *source = call->getArgOperand(2);
            auto *signature = llvm::FunctionType::get(builder.getInt64Ty(),
                                                      {source->getType()}, false);
            auto *load = llvm::InlineAsm::get(signature, assembly,
                                               "=r,r,~{memory}", true);
            auto *value = builder.CreateCall(load, {source}, "native.probe.scalar");
            auto *word = builder.getIntNTy(size->getZExtValue() * 8);
            builder.CreateStore(builder.CreateTruncOrBitCast(value, word),
                                call->getArgOperand(0))->setAlignment(llvm::Align(1));
            call->eraseFromParent();
            if (cast && cast->use_empty()) {
                cast->eraseFromParent();
                if (marker && marker->use_empty())
                    marker->eraseFromParent();
            }
            changed = true;
        }
        return changed ? llvm::PreservedAnalyses::none() :
                         llvm::PreservedAnalyses::all();
    }
};
}

extern "C" LLVM_ATTRIBUTE_WEAK llvm::PassPluginLibraryInfo llvmGetPassPluginInfo() {
    return {LLVM_PLUGIN_API_VERSION, "native-bpf-division", LLVM_VERSION_STRING,
        [](llvm::PassBuilder &builder) {
            builder.registerPipelineStartEPCallback(
                [](llvm::ModulePassManager &passes, llvm::OptimizationLevel) {
                    passes.addPass(llvm::createModuleToFunctionPassAdaptor(NativeDivision()));
                });
            builder.registerScalarOptimizerLateEPCallback(
                [](llvm::FunctionPassManager &passes, llvm::OptimizationLevel) {
                    passes.addPass(NativeProbeRead());
                });
        }};
}
