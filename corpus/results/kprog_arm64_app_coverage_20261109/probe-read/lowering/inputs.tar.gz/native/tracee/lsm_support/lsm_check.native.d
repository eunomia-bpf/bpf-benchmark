/var/tmp/kprog-tmp/A/probe-read/lowering/native/tracee/lsm_support/lsm_check.native.o: \
  tracee/pkg/ebpf/c/lsmsupport/lsm_check.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  tracee/pkg/ebpf/c/lsmsupport/lsm_check_common.h \
  /workspaces/repository/vendor/bpf/tracee/pkg/ebpf/c/vmlinux.h
