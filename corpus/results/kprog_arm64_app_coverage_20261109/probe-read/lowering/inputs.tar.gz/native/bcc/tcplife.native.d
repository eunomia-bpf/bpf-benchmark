/var/tmp/kprog-tmp/A/probe-read/lowering/native/bcc/tcplife.native.o: \
  bcc/libbpf-tools/tcplife.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /workspaces/repository/vendor/bpf/bcc/libbpf-tools/arm64/vmlinux.h \
  bcc/libbpf-tools/tcplife.h
