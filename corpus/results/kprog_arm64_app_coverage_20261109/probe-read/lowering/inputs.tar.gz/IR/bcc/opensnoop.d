/var/tmp/kprog-tmp/A/probe-read/lowering/IR/bcc/opensnoop.ll: \
  bcc/libbpf-tools/opensnoop.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /workspaces/repository/vendor/bpf/bcc/libbpf-tools/arm64/vmlinux.h \
  bcc/libbpf-tools/opensnoop.h
