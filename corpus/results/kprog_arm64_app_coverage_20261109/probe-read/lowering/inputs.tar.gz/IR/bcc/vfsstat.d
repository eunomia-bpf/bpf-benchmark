/var/tmp/kprog-tmp/A/probe-read/lowering/IR/bcc/vfsstat.ll: \
  bcc/libbpf-tools/vfsstat.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /workspaces/repository/vendor/bpf/bcc/libbpf-tools/arm64/vmlinux.h \
  bcc/libbpf-tools/vfsstat.h
