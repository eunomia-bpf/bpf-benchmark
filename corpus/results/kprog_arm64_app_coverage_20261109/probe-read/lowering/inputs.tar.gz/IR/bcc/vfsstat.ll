; ModuleID = 'bcc/libbpf-tools/vfsstat.bpf.c'
source_filename = "bcc/libbpf-tools/vfsstat.bpf.c"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

@stats = global [5 x i64] zeroinitializer, align 8, !dbg !0
@LICENSE = global [4 x i8] c"GPL\00", section "license", align 1, !dbg !16
@llvm.compiler.used = appending global [11 x ptr] [ptr @LICENSE, ptr @fentry_vfs_create, ptr @fentry_vfs_fsync, ptr @fentry_vfs_open, ptr @fentry_vfs_read, ptr @fentry_vfs_write, ptr @kprobe_vfs_create, ptr @kprobe_vfs_fsync, ptr @kprobe_vfs_open, ptr @kprobe_vfs_read, ptr @kprobe_vfs_write], section "llvm.metadata"

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @kprobe_vfs_read(ptr nocapture readnone %0) #0 section "kprobe/vfs_read" !dbg !34 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !81, metadata !DIExpression()), !dbg !82
  call void @llvm.dbg.value(metadata ptr poison, metadata !83, metadata !DIExpression()), !dbg !86
  tail call void @llvm.dbg.value(metadata i32 0, metadata !88, metadata !DIExpression()), !dbg !93
  %2 = atomicrmw add ptr @stats, i64 1 monotonic, align 8, !dbg !95
  ret i32 0, !dbg !96
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @kprobe_vfs_write(ptr nocapture readnone %0) #0 section "kprobe/vfs_write" !dbg !97 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !99, metadata !DIExpression()), !dbg !100
  call void @llvm.dbg.value(metadata ptr poison, metadata !101, metadata !DIExpression()), !dbg !104
  tail call void @llvm.dbg.value(metadata i32 1, metadata !88, metadata !DIExpression()), !dbg !106
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 1), i64 1 monotonic, align 8, !dbg !108
  ret i32 0, !dbg !109
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @kprobe_vfs_fsync(ptr nocapture readnone %0) #0 section "kprobe/vfs_fsync" !dbg !110 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !112, metadata !DIExpression()), !dbg !113
  call void @llvm.dbg.value(metadata ptr poison, metadata !114, metadata !DIExpression()), !dbg !117
  tail call void @llvm.dbg.value(metadata i32 2, metadata !88, metadata !DIExpression()), !dbg !119
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 2), i64 1 monotonic, align 8, !dbg !121
  ret i32 0, !dbg !122
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @kprobe_vfs_open(ptr nocapture readnone %0) #0 section "kprobe/vfs_open" !dbg !123 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !125, metadata !DIExpression()), !dbg !126
  call void @llvm.dbg.value(metadata ptr poison, metadata !127, metadata !DIExpression()), !dbg !130
  tail call void @llvm.dbg.value(metadata i32 3, metadata !88, metadata !DIExpression()), !dbg !132
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 3), i64 1 monotonic, align 8, !dbg !134
  ret i32 0, !dbg !135
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @kprobe_vfs_create(ptr nocapture readnone %0) #0 section "kprobe/vfs_create" !dbg !136 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !138, metadata !DIExpression()), !dbg !139
  call void @llvm.dbg.value(metadata ptr poison, metadata !140, metadata !DIExpression()), !dbg !143
  tail call void @llvm.dbg.value(metadata i32 4, metadata !88, metadata !DIExpression()), !dbg !145
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 4), i64 1 monotonic, align 8, !dbg !147
  ret i32 0, !dbg !148
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @fentry_vfs_read(ptr nocapture readnone %0) #0 section "fentry/vfs_read" !dbg !149 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !154, metadata !DIExpression()), !dbg !155
  call void @llvm.dbg.value(metadata ptr poison, metadata !156, metadata !DIExpression()), !dbg !159
  tail call void @llvm.dbg.value(metadata i32 0, metadata !88, metadata !DIExpression()), !dbg !161
  %2 = atomicrmw add ptr @stats, i64 1 monotonic, align 8, !dbg !163
  ret i32 0, !dbg !164
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @fentry_vfs_write(ptr nocapture readnone %0) #0 section "fentry/vfs_write" !dbg !165 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !167, metadata !DIExpression()), !dbg !168
  call void @llvm.dbg.value(metadata ptr poison, metadata !169, metadata !DIExpression()), !dbg !172
  tail call void @llvm.dbg.value(metadata i32 1, metadata !88, metadata !DIExpression()), !dbg !174
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 1), i64 1 monotonic, align 8, !dbg !176
  ret i32 0, !dbg !177
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @fentry_vfs_fsync(ptr nocapture readnone %0) #0 section "fentry/vfs_fsync" !dbg !178 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !180, metadata !DIExpression()), !dbg !181
  call void @llvm.dbg.value(metadata ptr poison, metadata !182, metadata !DIExpression()), !dbg !185
  tail call void @llvm.dbg.value(metadata i32 2, metadata !88, metadata !DIExpression()), !dbg !187
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 2), i64 1 monotonic, align 8, !dbg !189
  ret i32 0, !dbg !190
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @fentry_vfs_open(ptr nocapture readnone %0) #0 section "fentry/vfs_open" !dbg !191 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !193, metadata !DIExpression()), !dbg !194
  call void @llvm.dbg.value(metadata ptr poison, metadata !195, metadata !DIExpression()), !dbg !198
  tail call void @llvm.dbg.value(metadata i32 3, metadata !88, metadata !DIExpression()), !dbg !200
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 3), i64 1 monotonic, align 8, !dbg !202
  ret i32 0, !dbg !203
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none)
define noundef i32 @fentry_vfs_create(ptr nocapture readnone %0) #0 section "fentry/vfs_create" !dbg !204 {
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !206, metadata !DIExpression()), !dbg !207
  call void @llvm.dbg.value(metadata ptr poison, metadata !208, metadata !DIExpression()), !dbg !211
  tail call void @llvm.dbg.value(metadata i32 4, metadata !88, metadata !DIExpression()), !dbg !213
  %2 = atomicrmw add ptr getelementptr inbounds ([5 x i64], ptr @stats, i64 0, i64 4), i64 1 monotonic, align 8, !dbg !215
  ret i32 0, !dbg !216
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none, inaccessiblemem: none) "disable-tail-calls"="true" "no-jump-tables"="true" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+crc,+lse,+reserve-x18,+reserve-x26,+reserve-x27,+reserve-x28,+v8.1a,+v8a,-fmv,-fp-armv8,-neon,-outline-atomics,-rdm" "tune-cpu"="neoverse-n1" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!28, !29, !30, !31, !32}
!llvm.ident = !{!33}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "stats", scope: !2, file: !3, line: 10, type: !22, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, globals: !15, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "bcc/libbpf-tools/vfsstat.bpf.c", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "ce19acfb17520776f7bc82b0d95b46af")
!4 = !{!5}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "stat_types", file: !6, line: 6, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "bcc/libbpf-tools/vfsstat.h", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "44ced0bd604185dac7c30bfefa38c444")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12, !13, !14}
!9 = !DIEnumerator(name: "S_READ", value: 0)
!10 = !DIEnumerator(name: "S_WRITE", value: 1)
!11 = !DIEnumerator(name: "S_FSYNC", value: 2)
!12 = !DIEnumerator(name: "S_OPEN", value: 3)
!13 = !DIEnumerator(name: "S_CREATE", value: 4)
!14 = !DIEnumerator(name: "S_MAXSTAT", value: 5)
!15 = !{!0, !16}
!16 = !DIGlobalVariableExpression(var: !17, expr: !DIExpression())
!17 = distinct !DIGlobalVariable(name: "LICENSE", scope: !2, file: !3, line: 78, type: !18, isLocal: false, isDefinition: true)
!18 = !DICompositeType(tag: DW_TAG_array_type, baseType: !19, size: 32, elements: !20)
!19 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_unsigned_char)
!20 = !{!21}
!21 = !DISubrange(count: 4)
!22 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 320, elements: !26)
!23 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !24, line: 24520, baseType: !25)
!24 = !DIFile(filename: "bcc/libbpf-tools/arm64/vmlinux.h", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "8ccc174a6567962dd2f209ad34031992")
!25 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!26 = !{!27}
!27 = !DISubrange(count: 5)
!28 = !{i32 7, !"Dwarf Version", i32 5}
!29 = !{i32 2, !"Debug Info Version", i32 3}
!30 = !{i32 1, !"wchar_size", i32 4}
!31 = !{i32 8, !"PIC Level", i32 2}
!32 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!33 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!34 = distinct !DISubprogram(name: "kprobe_vfs_read", scope: !3, file: !3, line: 19, type: !35, scopeLine: 19, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !80)
!35 = !DISubroutineType(types: !36)
!36 = !{!37, !38}
!37 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!38 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !39, size: 64)
!39 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "pt_regs", file: !24, line: 38692, size: 2560, elements: !40)
!40 = !{!41, !63, !64, !67, !70, !71}
!41 = !DIDerivedType(tag: DW_TAG_member, scope: !39, file: !24, line: 38693, baseType: !42, size: 2176)
!42 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !39, file: !24, line: 38693, size: 2176, elements: !43)
!43 = !{!44, !54}
!44 = !DIDerivedType(tag: DW_TAG_member, name: "user_regs", scope: !42, file: !24, line: 38694, baseType: !45, size: 2176)
!45 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "user_pt_regs", file: !24, line: 38673, size: 2176, elements: !46)
!46 = !{!47, !51, !52, !53}
!47 = !DIDerivedType(tag: DW_TAG_member, name: "regs", scope: !45, file: !24, line: 38674, baseType: !48, size: 1984)
!48 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 1984, elements: !49)
!49 = !{!50}
!50 = !DISubrange(count: 31)
!51 = !DIDerivedType(tag: DW_TAG_member, name: "sp", scope: !45, file: !24, line: 38675, baseType: !23, size: 64, offset: 1984)
!52 = !DIDerivedType(tag: DW_TAG_member, name: "pc", scope: !45, file: !24, line: 38676, baseType: !23, size: 64, offset: 2048)
!53 = !DIDerivedType(tag: DW_TAG_member, name: "pstate", scope: !45, file: !24, line: 38677, baseType: !23, size: 64, offset: 2112)
!54 = !DIDerivedType(tag: DW_TAG_member, scope: !42, file: !24, line: 38695, baseType: !55, size: 2176)
!55 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !42, file: !24, line: 38695, size: 2176, elements: !56)
!56 = !{!57, !60, !61, !62}
!57 = !DIDerivedType(tag: DW_TAG_member, name: "regs", scope: !55, file: !24, line: 38696, baseType: !58, size: 1984)
!58 = !DICompositeType(tag: DW_TAG_array_type, baseType: !59, size: 1984, elements: !49)
!59 = !DIDerivedType(tag: DW_TAG_typedef, name: "u64", file: !24, line: 24528, baseType: !23)
!60 = !DIDerivedType(tag: DW_TAG_member, name: "sp", scope: !55, file: !24, line: 38697, baseType: !59, size: 64, offset: 1984)
!61 = !DIDerivedType(tag: DW_TAG_member, name: "pc", scope: !55, file: !24, line: 38698, baseType: !59, size: 64, offset: 2048)
!62 = !DIDerivedType(tag: DW_TAG_member, name: "pstate", scope: !55, file: !24, line: 38699, baseType: !59, size: 64, offset: 2112)
!63 = !DIDerivedType(tag: DW_TAG_member, name: "orig_x0", scope: !39, file: !24, line: 38702, baseType: !59, size: 64, offset: 2176)
!64 = !DIDerivedType(tag: DW_TAG_member, name: "syscallno", scope: !39, file: !24, line: 38703, baseType: !65, size: 32, offset: 2240)
!65 = !DIDerivedType(tag: DW_TAG_typedef, name: "s32", file: !24, line: 24386, baseType: !66)
!66 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s32", file: !24, line: 24380, baseType: !37)
!67 = !DIDerivedType(tag: DW_TAG_member, name: "pmr", scope: !39, file: !24, line: 38704, baseType: !68, size: 32, offset: 2272)
!68 = !DIDerivedType(tag: DW_TAG_typedef, name: "u32", file: !24, line: 24868, baseType: !69)
!69 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u32", file: !24, line: 24856, baseType: !7)
!70 = !DIDerivedType(tag: DW_TAG_member, name: "sdei_ttbr1", scope: !39, file: !24, line: 38705, baseType: !59, size: 64, offset: 2304)
!71 = !DIDerivedType(tag: DW_TAG_member, name: "stackframe", scope: !39, file: !24, line: 38706, baseType: !72, size: 192, offset: 2368)
!72 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "frame_record_meta", file: !24, line: 38687, size: 192, elements: !73)
!73 = !{!74, !79}
!74 = !DIDerivedType(tag: DW_TAG_member, name: "record", scope: !72, file: !24, line: 38688, baseType: !75, size: 128)
!75 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "frame_record", file: !24, line: 38682, size: 128, elements: !76)
!76 = !{!77, !78}
!77 = !DIDerivedType(tag: DW_TAG_member, name: "fp", scope: !75, file: !24, line: 38683, baseType: !59, size: 64)
!78 = !DIDerivedType(tag: DW_TAG_member, name: "lr", scope: !75, file: !24, line: 38684, baseType: !59, size: 64, offset: 64)
!79 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !72, file: !24, line: 38689, baseType: !59, size: 64, offset: 128)
!80 = !{!81}
!81 = !DILocalVariable(name: "ctx", arg: 1, scope: !34, file: !3, line: 19, type: !38)
!82 = !DILocation(line: 0, scope: !34)
!83 = !DILocalVariable(name: "ctx", arg: 1, scope: !84, file: !3, line: 19, type: !38)
!84 = distinct !DISubprogram(name: "____kprobe_vfs_read", scope: !3, file: !3, line: 19, type: !35, scopeLine: 20, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !85)
!85 = !{!83}
!86 = !DILocation(line: 0, scope: !84, inlinedAt: !87)
!87 = distinct !DILocation(line: 19, column: 5, scope: !34)
!88 = !DILocalVariable(name: "key", arg: 1, scope: !89, file: !3, line: 12, type: !37)
!89 = distinct !DISubprogram(name: "inc_stats", scope: !3, file: !3, line: 12, type: !90, scopeLine: 13, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !92)
!90 = !DISubroutineType(types: !91)
!91 = !{!37, !37}
!92 = !{!88}
!93 = !DILocation(line: 0, scope: !89, inlinedAt: !94)
!94 = distinct !DILocation(line: 21, column: 9, scope: !84, inlinedAt: !87)
!95 = !DILocation(line: 14, column: 2, scope: !89, inlinedAt: !94)
!96 = !DILocation(line: 19, column: 5, scope: !34)
!97 = distinct !DISubprogram(name: "kprobe_vfs_write", scope: !3, file: !3, line: 25, type: !35, scopeLine: 25, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !98)
!98 = !{!99}
!99 = !DILocalVariable(name: "ctx", arg: 1, scope: !97, file: !3, line: 25, type: !38)
!100 = !DILocation(line: 0, scope: !97)
!101 = !DILocalVariable(name: "ctx", arg: 1, scope: !102, file: !3, line: 25, type: !38)
!102 = distinct !DISubprogram(name: "____kprobe_vfs_write", scope: !3, file: !3, line: 25, type: !35, scopeLine: 26, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !103)
!103 = !{!101}
!104 = !DILocation(line: 0, scope: !102, inlinedAt: !105)
!105 = distinct !DILocation(line: 25, column: 5, scope: !97)
!106 = !DILocation(line: 0, scope: !89, inlinedAt: !107)
!107 = distinct !DILocation(line: 27, column: 9, scope: !102, inlinedAt: !105)
!108 = !DILocation(line: 14, column: 2, scope: !89, inlinedAt: !107)
!109 = !DILocation(line: 25, column: 5, scope: !97)
!110 = distinct !DISubprogram(name: "kprobe_vfs_fsync", scope: !3, file: !3, line: 31, type: !35, scopeLine: 31, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !111)
!111 = !{!112}
!112 = !DILocalVariable(name: "ctx", arg: 1, scope: !110, file: !3, line: 31, type: !38)
!113 = !DILocation(line: 0, scope: !110)
!114 = !DILocalVariable(name: "ctx", arg: 1, scope: !115, file: !3, line: 31, type: !38)
!115 = distinct !DISubprogram(name: "____kprobe_vfs_fsync", scope: !3, file: !3, line: 31, type: !35, scopeLine: 32, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !116)
!116 = !{!114}
!117 = !DILocation(line: 0, scope: !115, inlinedAt: !118)
!118 = distinct !DILocation(line: 31, column: 5, scope: !110)
!119 = !DILocation(line: 0, scope: !89, inlinedAt: !120)
!120 = distinct !DILocation(line: 33, column: 9, scope: !115, inlinedAt: !118)
!121 = !DILocation(line: 14, column: 2, scope: !89, inlinedAt: !120)
!122 = !DILocation(line: 31, column: 5, scope: !110)
!123 = distinct !DISubprogram(name: "kprobe_vfs_open", scope: !3, file: !3, line: 37, type: !35, scopeLine: 37, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !124)
!124 = !{!125}
!125 = !DILocalVariable(name: "ctx", arg: 1, scope: !123, file: !3, line: 37, type: !38)
!126 = !DILocation(line: 0, scope: !123)
!127 = !DILocalVariable(name: "ctx", arg: 1, scope: !128, file: !3, line: 37, type: !38)
!128 = distinct !DISubprogram(name: "____kprobe_vfs_open", scope: !3, file: !3, line: 37, type: !35, scopeLine: 38, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !129)
!129 = !{!127}
!130 = !DILocation(line: 0, scope: !128, inlinedAt: !131)
!131 = distinct !DILocation(line: 37, column: 5, scope: !123)
!132 = !DILocation(line: 0, scope: !89, inlinedAt: !133)
!133 = distinct !DILocation(line: 39, column: 9, scope: !128, inlinedAt: !131)
!134 = !DILocation(line: 14, column: 2, scope: !89, inlinedAt: !133)
!135 = !DILocation(line: 37, column: 5, scope: !123)
!136 = distinct !DISubprogram(name: "kprobe_vfs_create", scope: !3, file: !3, line: 43, type: !35, scopeLine: 43, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !137)
!137 = !{!138}
!138 = !DILocalVariable(name: "ctx", arg: 1, scope: !136, file: !3, line: 43, type: !38)
!139 = !DILocation(line: 0, scope: !136)
!140 = !DILocalVariable(name: "ctx", arg: 1, scope: !141, file: !3, line: 43, type: !38)
!141 = distinct !DISubprogram(name: "____kprobe_vfs_create", scope: !3, file: !3, line: 43, type: !35, scopeLine: 44, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !142)
!142 = !{!140}
!143 = !DILocation(line: 0, scope: !141, inlinedAt: !144)
!144 = distinct !DILocation(line: 43, column: 5, scope: !136)
!145 = !DILocation(line: 0, scope: !89, inlinedAt: !146)
!146 = distinct !DILocation(line: 45, column: 9, scope: !141, inlinedAt: !144)
!147 = !DILocation(line: 14, column: 2, scope: !89, inlinedAt: !146)
!148 = !DILocation(line: 43, column: 5, scope: !136)
!149 = distinct !DISubprogram(name: "fentry_vfs_read", scope: !3, file: !3, line: 49, type: !150, scopeLine: 49, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !153)
!150 = !DISubroutineType(types: !151)
!151 = !{!37, !152}
!152 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !25, size: 64)
!153 = !{!154}
!154 = !DILocalVariable(name: "ctx", arg: 1, scope: !149, file: !3, line: 49, type: !152)
!155 = !DILocation(line: 0, scope: !149)
!156 = !DILocalVariable(name: "ctx", arg: 1, scope: !157, file: !3, line: 49, type: !152)
!157 = distinct !DISubprogram(name: "____fentry_vfs_read", scope: !3, file: !3, line: 49, type: !150, scopeLine: 50, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !158)
!158 = !{!156}
!159 = !DILocation(line: 0, scope: !157, inlinedAt: !160)
!160 = distinct !DILocation(line: 49, column: 5, scope: !149)
!161 = !DILocation(line: 0, scope: !89, inlinedAt: !162)
!162 = distinct !DILocation(line: 51, column: 9, scope: !157, inlinedAt: !160)
!163 = !DILocation(line: 14, column: 2, scope: !89, inlinedAt: !162)
!164 = !DILocation(line: 49, column: 5, scope: !149)
!165 = distinct !DISubprogram(name: "fentry_vfs_write", scope: !3, file: !3, line: 55, type: !150, scopeLine: 55, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !166)
!166 = !{!167}
!167 = !DILocalVariable(name: "ctx", arg: 1, scope: !165, file: !3, line: 55, type: !152)
!168 = !DILocation(line: 0, scope: !165)
!169 = !DILocalVariable(name: "ctx", arg: 1, scope: !170, file: !3, line: 55, type: !152)
!170 = distinct !DISubprogram(name: "____fentry_vfs_write", scope: !3, file: !3, line: 55, type: !150, scopeLine: 56, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !171)
!171 = !{!169}
!172 = !DILocation(line: 0, scope: !170, inlinedAt: !173)
!173 = distinct !DILocation(line: 55, column: 5, scope: !165)
!174 = !DILocation(line: 0, scope: !89, inlinedAt: !175)
!175 = distinct !DILocation(line: 57, column: 9, scope: !170, inlinedAt: !173)
!176 = !DILocation(line: 14, column: 2, scope: !89, inlinedAt: !175)
!177 = !DILocation(line: 55, column: 5, scope: !165)
!178 = distinct !DISubprogram(name: "fentry_vfs_fsync", scope: !3, file: !3, line: 61, type: !150, scopeLine: 61, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !179)
!179 = !{!180}
!180 = !DILocalVariable(name: "ctx", arg: 1, scope: !178, file: !3, line: 61, type: !152)
!181 = !DILocation(line: 0, scope: !178)
!182 = !DILocalVariable(name: "ctx", arg: 1, scope: !183, file: !3, line: 61, type: !152)
!183 = distinct !DISubprogram(name: "____fentry_vfs_fsync", scope: !3, file: !3, line: 61, type: !150, scopeLine: 62, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !184)
!184 = !{!182}
!185 = !DILocation(line: 0, scope: !183, inlinedAt: !186)
!186 = distinct !DILocation(line: 61, column: 5, scope: !178)
!187 = !DILocation(line: 0, scope: !89, inlinedAt: !188)
!188 = distinct !DILocation(line: 63, column: 9, scope: !183, inlinedAt: !186)
!189 = !DILocation(line: 14, column: 2, scope: !89, inlinedAt: !188)
!190 = !DILocation(line: 61, column: 5, scope: !178)
!191 = distinct !DISubprogram(name: "fentry_vfs_open", scope: !3, file: !3, line: 67, type: !150, scopeLine: 67, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !192)
!192 = !{!193}
!193 = !DILocalVariable(name: "ctx", arg: 1, scope: !191, file: !3, line: 67, type: !152)
!194 = !DILocation(line: 0, scope: !191)
!195 = !DILocalVariable(name: "ctx", arg: 1, scope: !196, file: !3, line: 67, type: !152)
!196 = distinct !DISubprogram(name: "____fentry_vfs_open", scope: !3, file: !3, line: 67, type: !150, scopeLine: 68, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !197)
!197 = !{!195}
!198 = !DILocation(line: 0, scope: !196, inlinedAt: !199)
!199 = distinct !DILocation(line: 67, column: 5, scope: !191)
!200 = !DILocation(line: 0, scope: !89, inlinedAt: !201)
!201 = distinct !DILocation(line: 69, column: 9, scope: !196, inlinedAt: !199)
!202 = !DILocation(line: 14, column: 2, scope: !89, inlinedAt: !201)
!203 = !DILocation(line: 67, column: 5, scope: !191)
!204 = distinct !DISubprogram(name: "fentry_vfs_create", scope: !3, file: !3, line: 73, type: !150, scopeLine: 73, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !205)
!205 = !{!206}
!206 = !DILocalVariable(name: "ctx", arg: 1, scope: !204, file: !3, line: 73, type: !152)
!207 = !DILocation(line: 0, scope: !204)
!208 = !DILocalVariable(name: "ctx", arg: 1, scope: !209, file: !3, line: 73, type: !152)
!209 = distinct !DISubprogram(name: "____fentry_vfs_create", scope: !3, file: !3, line: 73, type: !150, scopeLine: 74, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !210)
!210 = !{!208}
!211 = !DILocation(line: 0, scope: !209, inlinedAt: !212)
!212 = distinct !DILocation(line: 73, column: 5, scope: !204)
!213 = !DILocation(line: 0, scope: !89, inlinedAt: !214)
!214 = distinct !DILocation(line: 75, column: 9, scope: !209, inlinedAt: !212)
!215 = !DILocation(line: 14, column: 2, scope: !89, inlinedAt: !214)
!216 = !DILocation(line: 73, column: 5, scope: !204)
