; ModuleID = 'tracee/pkg/ebpf/c/lsmsupport/kprobe_check.bpf.c'
source_filename = "tracee/pkg/ebpf/c/lsmsupport/kprobe_check.bpf.c"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

%struct.anon = type { ptr, ptr, ptr, ptr }

@TRACE_EVENT_FL_TRACEPOINT_BIT = local_unnamed_addr constant i32 4, align 4, !dbg !0
@TRACE_EVENT_FL_TRACEPOINT = local_unnamed_addr constant i32 16, align 4, !dbg !24
@_license = global [4 x i8] c"GPL\00", section "license", align 1, !dbg !28
@check_result_map = global %struct.anon zeroinitializer, section ".maps", align 8, !dbg !34
@llvm.compiler.used = appending global [3 x ptr] [ptr @_license, ptr @check_result_map, ptr @security_bpf_kprobe], section "llvm.metadata"

; Function Attrs: nounwind
define noundef i32 @security_bpf_kprobe(ptr nocapture readnone %0) #0 section "kprobe/security_bpf" !dbg !62 {
  %2 = alloca i32, align 4, !DIAssignID !105
  %3 = alloca i8, align 4, !DIAssignID !106
  tail call void @llvm.dbg.value(metadata ptr poison, metadata !104, metadata !DIExpression()), !dbg !107
  call void @llvm.dbg.assign(metadata i1 undef, metadata !108, metadata !DIExpression(), metadata !105, metadata ptr %2, metadata !DIExpression()), !dbg !113
  call void @llvm.dbg.assign(metadata i1 undef, metadata !112, metadata !DIExpression(), metadata !106, metadata ptr %3, metadata !DIExpression()), !dbg !113
  call void @llvm.dbg.value(metadata ptr poison, metadata !111, metadata !DIExpression()), !dbg !113
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %2) #4, !dbg !115
  store i32 0, ptr %2, align 4, !dbg !116, !tbaa !117, !DIAssignID !121
  call void @llvm.dbg.assign(metadata i32 0, metadata !108, metadata !DIExpression(), metadata !121, metadata ptr %2, metadata !DIExpression()), !dbg !113
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %3) #4, !dbg !122
  store i8 1, ptr %3, align 4, !dbg !123, !tbaa !124, !DIAssignID !125
  call void @llvm.dbg.assign(metadata i8 1, metadata !112, metadata !DIExpression(), metadata !125, metadata ptr %3, metadata !DIExpression()), !dbg !113
  %4 = ptrtoint ptr %2 to i64, !dbg !126
  %5 = ptrtoint ptr %3 to i64, !dbg !126
  call void @llvm.dbg.value(metadata i64 2, metadata !127, metadata !DIExpression()), !dbg !137
  call void @llvm.dbg.value(metadata i64 ptrtoint (ptr @check_result_map to i64), metadata !133, metadata !DIExpression()), !dbg !137
  call void @llvm.dbg.value(metadata i64 %4, metadata !134, metadata !DIExpression()), !dbg !137
  call void @llvm.dbg.value(metadata i64 %5, metadata !135, metadata !DIExpression()), !dbg !137
  call void @llvm.dbg.value(metadata i64 0, metadata !136, metadata !DIExpression()), !dbg !137
  %6 = call i64 asm sideeffect "", "=r,r,r,r,r,0,~{memory}"(i64 ptrtoint (ptr @check_result_map to i64), i64 %4, i64 %5, i64 0, i64 2) #4, !dbg !139, !srcloc !140
  call void @llvm.dbg.value(metadata i64 %6, metadata !127, metadata !DIExpression()), !dbg !137
  %7 = inttoptr i64 %6 to ptr, !dbg !126
  %8 = call i64 %7(ptr noundef nonnull @check_result_map, ptr noundef nonnull %2, ptr noundef nonnull %3, i64 noundef 0) #4, !dbg !126
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %3) #4, !dbg !141
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %2) #4, !dbg !141
  ret i32 0, !dbg !142
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #3

attributes #0 = { nounwind "disable-tail-calls"="true" "no-jump-tables"="true" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+crc,+lse,+reserve-x18,+reserve-x26,+reserve-x27,+reserve-x28,+v8.1a,+v8a,-fmv,-fp-armv8,-neon,-outline-atomics,-rdm" "tune-cpu"="neoverse-n1" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!56, !57, !58, !59, !60}
!llvm.ident = !{!61}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "TRACE_EVENT_FL_TRACEPOINT_BIT", scope: !2, file: !6, line: 1354, type: !26, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !4, retainedTypes: !13, globals: !23, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "tracee/pkg/ebpf/c/lsmsupport/kprobe_check.bpf.c", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "e0e54995dd00602017281900e342a729")
!4 = !{!5}
!5 = !DICompositeType(tag: DW_TAG_enumeration_type, file: !6, line: 219, baseType: !7, size: 32, elements: !8)
!6 = !DIFile(filename: "tracee/pkg/ebpf/c/vmlinux.h", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "7c0ea1bcacfab38fa83eb3d9705fcc28")
!7 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!8 = !{!9, !10, !11, !12}
!9 = !DIEnumerator(name: "BPF_ANY", value: 0)
!10 = !DIEnumerator(name: "BPF_NOEXIST", value: 1)
!11 = !DIEnumerator(name: "BPF_EXIST", value: 2)
!12 = !DIEnumerator(name: "BPF_F_LOCK", value: 4)
!13 = !{!14, !22}
!14 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64)
!15 = !DISubroutineType(types: !16)
!16 = !{!17, !18, !19, !19, !21}
!17 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!18 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!19 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !20, size: 64)
!20 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!21 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!22 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!23 = !{!0, !24, !28, !34}
!24 = !DIGlobalVariableExpression(var: !25, expr: !DIExpression())
!25 = distinct !DIGlobalVariable(name: "TRACE_EVENT_FL_TRACEPOINT", scope: !2, file: !6, line: 1355, type: !26, isLocal: false, isDefinition: true)
!26 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !27)
!27 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!28 = !DIGlobalVariableExpression(var: !29, expr: !DIExpression())
!29 = distinct !DIGlobalVariable(name: "_license", scope: !2, file: !3, line: 23, type: !30, isLocal: false, isDefinition: true)
!30 = !DICompositeType(tag: DW_TAG_array_type, baseType: !31, size: 32, elements: !32)
!31 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_unsigned_char)
!32 = !{!33}
!33 = !DISubrange(count: 4)
!34 = !DIGlobalVariableExpression(var: !35, expr: !DIExpression())
!35 = distinct !DIGlobalVariable(name: "check_result_map", scope: !2, file: !36, line: 17, type: !37, isLocal: false, isDefinition: true)
!36 = !DIFile(filename: "tracee/pkg/ebpf/c/lsmsupport/lsm_check_common.h", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "13ecb5c44d27cd1ff8036d8587a779b6")
!37 = distinct !DICompositeType(tag: DW_TAG_structure_type, file: !36, line: 12, size: 256, elements: !38)
!38 = !{!39, !44, !49, !52}
!39 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !37, file: !36, line: 13, baseType: !40, size: 64)
!40 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !41, size: 64)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 64, elements: !42)
!42 = !{!43}
!43 = !DISubrange(count: 2)
!44 = !DIDerivedType(tag: DW_TAG_member, name: "max_entries", scope: !37, file: !36, line: 14, baseType: !45, size: 64, offset: 64)
!45 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !46, size: 64)
!46 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 32, elements: !47)
!47 = !{!48}
!48 = !DISubrange(count: 1)
!49 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !37, file: !36, line: 15, baseType: !50, size: 64, offset: 128)
!50 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !51, size: 64)
!51 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u32", file: !6, line: 36, baseType: !7)
!52 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !37, file: !36, line: 16, baseType: !53, size: 64, offset: 192)
!53 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !54, size: 64)
!54 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u8", file: !6, line: 24, baseType: !55)
!55 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!56 = !{i32 7, !"Dwarf Version", i32 5}
!57 = !{i32 2, !"Debug Info Version", i32 3}
!58 = !{i32 1, !"wchar_size", i32 4}
!59 = !{i32 8, !"PIC Level", i32 2}
!60 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!61 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!62 = distinct !DISubprogram(name: "security_bpf_kprobe", scope: !3, file: !3, line: 10, type: !63, scopeLine: 10, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !103)
!63 = !DISubroutineType(types: !64)
!64 = !{!27, !65}
!65 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !66, size: 64)
!66 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "pt_regs", file: !6, line: 195, size: 2688, elements: !67)
!67 = !{!68, !91, !92, !95, !97, !98, !99, !101, !102}
!68 = !DIDerivedType(tag: DW_TAG_member, scope: !66, file: !6, line: 196, baseType: !69, size: 2176)
!69 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !66, file: !6, line: 196, size: 2176, elements: !70)
!70 = !{!71, !82}
!71 = !DIDerivedType(tag: DW_TAG_member, name: "user_regs", scope: !69, file: !6, line: 197, baseType: !72, size: 2176)
!72 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "user_pt_regs", file: !6, line: 188, size: 2176, elements: !73)
!73 = !{!74, !79, !80, !81}
!74 = !DIDerivedType(tag: DW_TAG_member, name: "regs", scope: !72, file: !6, line: 189, baseType: !75, size: 1984)
!75 = !DICompositeType(tag: DW_TAG_array_type, baseType: !76, size: 1984, elements: !77)
!76 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !6, line: 44, baseType: !21)
!77 = !{!78}
!78 = !DISubrange(count: 31)
!79 = !DIDerivedType(tag: DW_TAG_member, name: "sp", scope: !72, file: !6, line: 190, baseType: !76, size: 64, offset: 1984)
!80 = !DIDerivedType(tag: DW_TAG_member, name: "pc", scope: !72, file: !6, line: 191, baseType: !76, size: 64, offset: 2048)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "pstate", scope: !72, file: !6, line: 192, baseType: !76, size: 64, offset: 2112)
!82 = !DIDerivedType(tag: DW_TAG_member, scope: !69, file: !6, line: 198, baseType: !83, size: 2176)
!83 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !69, file: !6, line: 198, size: 2176, elements: !84)
!84 = !{!85, !88, !89, !90}
!85 = !DIDerivedType(tag: DW_TAG_member, name: "regs", scope: !83, file: !6, line: 199, baseType: !86, size: 1984)
!86 = !DICompositeType(tag: DW_TAG_array_type, baseType: !87, size: 1984, elements: !77)
!87 = !DIDerivedType(tag: DW_TAG_typedef, name: "u64", file: !6, line: 45, baseType: !76)
!88 = !DIDerivedType(tag: DW_TAG_member, name: "sp", scope: !83, file: !6, line: 200, baseType: !87, size: 64, offset: 1984)
!89 = !DIDerivedType(tag: DW_TAG_member, name: "pc", scope: !83, file: !6, line: 201, baseType: !87, size: 64, offset: 2048)
!90 = !DIDerivedType(tag: DW_TAG_member, name: "pstate", scope: !83, file: !6, line: 202, baseType: !87, size: 64, offset: 2112)
!91 = !DIDerivedType(tag: DW_TAG_member, name: "orig_x0", scope: !66, file: !6, line: 205, baseType: !87, size: 64, offset: 2176)
!92 = !DIDerivedType(tag: DW_TAG_member, name: "syscallno", scope: !66, file: !6, line: 206, baseType: !93, size: 32, offset: 2240)
!93 = !DIDerivedType(tag: DW_TAG_typedef, name: "s32", file: !6, line: 17, baseType: !94)
!94 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s32", file: !6, line: 16, baseType: !27)
!95 = !DIDerivedType(tag: DW_TAG_member, name: "unused2", scope: !66, file: !6, line: 207, baseType: !96, size: 32, offset: 2272)
!96 = !DIDerivedType(tag: DW_TAG_typedef, name: "u32", file: !6, line: 38, baseType: !51)
!97 = !DIDerivedType(tag: DW_TAG_member, name: "orig_addr_limit", scope: !66, file: !6, line: 208, baseType: !87, size: 64, offset: 2304)
!98 = !DIDerivedType(tag: DW_TAG_member, name: "pmr_save", scope: !66, file: !6, line: 209, baseType: !87, size: 64, offset: 2368)
!99 = !DIDerivedType(tag: DW_TAG_member, name: "stackframe", scope: !66, file: !6, line: 210, baseType: !100, size: 128, offset: 2432)
!100 = !DICompositeType(tag: DW_TAG_array_type, baseType: !87, size: 128, elements: !42)
!101 = !DIDerivedType(tag: DW_TAG_member, name: "lockdep_hardirqs", scope: !66, file: !6, line: 211, baseType: !87, size: 64, offset: 2560)
!102 = !DIDerivedType(tag: DW_TAG_member, name: "exit_rcu", scope: !66, file: !6, line: 212, baseType: !87, size: 64, offset: 2624)
!103 = !{!104}
!104 = !DILocalVariable(name: "ctx", arg: 1, scope: !62, file: !3, line: 10, type: !65)
!105 = distinct !DIAssignID()
!106 = distinct !DIAssignID()
!107 = !DILocation(line: 0, scope: !62)
!108 = !DILocalVariable(name: "key", scope: !109, file: !3, line: 14, type: !51)
!109 = distinct !DISubprogram(name: "____security_bpf_kprobe", scope: !3, file: !3, line: 10, type: !63, scopeLine: 11, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !110)
!110 = !{!111, !108, !112}
!111 = !DILocalVariable(name: "ctx", arg: 1, scope: !109, file: !3, line: 10, type: !65)
!112 = !DILocalVariable(name: "triggered", scope: !109, file: !3, line: 15, type: !54)
!113 = !DILocation(line: 0, scope: !109, inlinedAt: !114)
!114 = distinct !DILocation(line: 10, column: 5, scope: !62)
!115 = !DILocation(line: 14, column: 5, scope: !109, inlinedAt: !114)
!116 = !DILocation(line: 14, column: 11, scope: !109, inlinedAt: !114)
!117 = !{!118, !118, i64 0}
!118 = !{!"int", !119, i64 0}
!119 = !{!"omnipotent char", !120, i64 0}
!120 = !{!"Simple C/C++ TBAA"}
!121 = distinct !DIAssignID()
!122 = !DILocation(line: 15, column: 5, scope: !109, inlinedAt: !114)
!123 = !DILocation(line: 15, column: 10, scope: !109, inlinedAt: !114)
!124 = !{!119, !119, i64 0}
!125 = distinct !DIAssignID()
!126 = !DILocation(line: 18, column: 5, scope: !109, inlinedAt: !114)
!127 = !DILocalVariable(name: "id", arg: 1, scope: !128, file: !129, line: 543, type: !22)
!128 = distinct !DISubprogram(name: "native_helper_id4", scope: !129, file: !129, line: 543, type: !130, scopeLine: 548, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !132)
!129 = !DIFile(filename: "native_compat.h", directory: "/workspaces/repository/vendor/bpf", checksumkind: CSK_MD5, checksum: "d60311c07fe0bcb85ac571d435aebf7a")
!130 = !DISubroutineType(types: !131)
!131 = !{!22, !22, !22, !22, !22, !22}
!132 = !{!127, !133, !134, !135, !136}
!133 = !DILocalVariable(name: "a0", arg: 2, scope: !128, file: !129, line: 544, type: !22)
!134 = !DILocalVariable(name: "a1", arg: 3, scope: !128, file: !129, line: 545, type: !22)
!135 = !DILocalVariable(name: "a2", arg: 4, scope: !128, file: !129, line: 546, type: !22)
!136 = !DILocalVariable(name: "a3", arg: 5, scope: !128, file: !129, line: 547, type: !22)
!137 = !DILocation(line: 0, scope: !128, inlinedAt: !138)
!138 = distinct !DILocation(line: 18, column: 5, scope: !109, inlinedAt: !114)
!139 = !DILocation(line: 549, column: 5, scope: !128, inlinedAt: !138)
!140 = !{i64 38100}
!141 = !DILocation(line: 21, column: 1, scope: !109, inlinedAt: !114)
!142 = !DILocation(line: 10, column: 5, scope: !62)
