from pathlib import Path
import datetime,json,hashlib,subprocess,struct,re,os,tarfile,importlib.util,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;F=G.parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261109/probe-read/lowering/paired-control'
O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def run(cmd,log):
 with log.open('w') as f:return subprocess.run(cmd,cwd=R/'vendor/bpf',stdout=f,stderr=subprocess.STDOUT).returncode
def text_bytes(p):
 b=p.read_bytes();off=struct.unpack_from('<Q',b,40)[0];size,n=struct.unpack_from('<HH',b,58)
 return sum(struct.unpack_from('<IIQQQQIIQQ',b,off+i*size)[5] for i in range(n) if struct.unpack_from('<IIQQQQIIQQ',b,off+i*size)[2]&4)
try:
 save('building_paired_control_plugin')
 plugin=G/'native_division.so';cmd=['make','--no-print-directory','-f',str(F/'Makefile'),'NATIVE_DIVISION_PLUGIN='+str(plugin),str(plugin)]
 rc=run(cmd,G/'plugin.log');rows=[]
 candidate=json.loads((R/'corpus/results/kprog_arm64_app_coverage_20261109/probe-read/lowering/summary.json').read_text())
 if rc==0:
  for row in candidate['rows']:
   name=row['unit'];out=G/'native'/(name+'.native.o');out.parent.mkdir(parents=True,exist_ok=True)
   cmd=list(row['command']);cmd[cmd.index('-o')+1]=str(out);cmd[cmd.index('-MF')+1]=str(out.with_suffix('.d'))
   cmd=[('-fpass-plugin='+str(plugin)) if a.startswith('-fpass-plugin=') else a for a in cmd]
   save('compiling_same_flags_control',unit=name,completed=len(rows))
   cr=run(cmd,out.with_suffix('.compile.log'));r=dict(unit=name,compile_exit=cr,command=cmd,candidate={k:row[k] for k in ['sha256','executable_bytes','instructions','static_call_sites','scalar_read_asm_sites']})
   if out.exists():
    ds=subprocess.run(['llvm-objdump-18','-dr','--no-show-raw-insn',str(out)],text=True,capture_output=True)
    out.with_suffix('.dis').write_text(ds.stdout+ds.stderr)
    r['control']=dict(sha256=sha(out),executable_bytes=text_bytes(out),instructions=len(re.findall(r'^\s*[0-9a-f]+:\s+[a-z][a-z0-9.]+\b',ds.stdout,re.M)),static_call_sites=len(re.findall(r'^\s*[0-9a-f]+:\s+bl(?:r)?\s',ds.stdout,re.M)),disassembly_exit=ds.returncode)
   rows.append(r)
 report=dict(utc=now(),scope='Paired ARMv8.1LSE native P compiler control with scalar probe-read pass absent',candidate_publication='5bbbf128a2c47bf102376fb28c90df6cd14191a2',same_flags='Every candidate compiler argument retained except private output/dependency/plugin paths; both use armv8.1-a+lse',same_source='Original8BCC C and paired61c85Tracee3units',control_plugin_source_sha256=sha(F/'native_division.before.cpp'),plugin_make_exit=rc,plugin_sha256=sha(plugin) if plugin.exists() else None,rows=rows,runtime_admission_additions=0)
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
 md=['# Paired ARM native producer code size','','The actual eleven-object compiler control uses the candidate command lines, Armv8.1LSE target and identical original BCC/paired Tracee C. The captured original plugin source supplies the control; the candidate adds the generic scalar probe-read lowering pass. Both payloads retain complete application translation units. Measurements below describe executable ELF sections and static native instructions/calls. Actual whole application work counters follow the existing queue; R owns restored May29 hardware workload throughput.','','| Unit | Compile exit | Control bytes | Candidate bytes | Control calls | Candidate calls | Scalar read sites |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
 for r in rows:
  c=r.get('control',{});n=r['candidate'];md.append('| '+r['unit']+' | '+str(r['compile_exit'])+' | '+str(c.get('executable_bytes'))+' | '+str(n['executable_bytes'])+' | '+str(c.get('static_call_sites'))+' | '+str(n['static_call_sites'])+' | '+str(n['scalar_read_asm_sites'])+' |')
 md+=['','Plugin Make exit:'+str(rc)+'. Compile successes:'+str(sum(r['compile_exit']==0 for r in rows))+'/'+str(len(rows))+'. Runtime admission additions:0.','']
 (O/'README.md').write_text('\n'.join(md))
 with tarfile.open(O/'inputs.tar.gz','w:gz') as tf:
  for p in sorted(G.rglob('*')):
   if p.is_file():tf.add(p,arcname=str(p.relative_to(G)))
  tf.add(F/'native_division.before.cpp',arcname='control-native_division.cpp')
  tf.add(F/'Makefile',arcname='owning-native-Makefile')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['summary.json','README.md','inputs.tar.gz']],'Measure paired ARM scalar read native producer code size','arm-probe-read-paired-control')
 save('finished',publication=rec,compiled=sum(r['compile_exit']==0 for r in rows),attempted=len(rows))
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+rec['commit']+' actualpaired11object ARMv8.1LSE compilercontrol versus scalarprobe-readcandidate5bb. IdenticalC/nativeflags; privatecontrolpluginretainscapturedoriginalsource. Allactualnativecompiles/staticcode/calls retainedwithraw. Wholeappwork/throughputfollowexistingqueue/Rrecipe. Runtimeadmissionadditions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
