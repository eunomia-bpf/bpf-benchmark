/var/tmp/kprog-tmp/A/probe-read/lowering/paired-control/native/bcc/runqlat.native.o: \
  bcc/libbpf-tools/runqlat.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /workspaces/repository/vendor/bpf/bcc/libbpf-tools/arm64/vmlinux.h \
  bcc/libbpf-tools/runqlat.h bcc/libbpf-tools/bits.bpf.h \
  bcc/libbpf-tools/maps.bpf.h bcc/libbpf-tools/core_fixes.bpf.h
