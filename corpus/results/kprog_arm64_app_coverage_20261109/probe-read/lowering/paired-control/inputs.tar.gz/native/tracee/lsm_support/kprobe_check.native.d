/var/tmp/kprog-tmp/A/probe-read/lowering/paired-control/native/tracee/lsm_support/kprobe_check.native.o: \
  tracee/pkg/ebpf/c/lsmsupport/kprobe_check.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  tracee/pkg/ebpf/c/lsmsupport/lsm_check_common.h \
  /workspaces/repository/vendor/bpf/tracee/pkg/ebpf/c/vmlinux.h
