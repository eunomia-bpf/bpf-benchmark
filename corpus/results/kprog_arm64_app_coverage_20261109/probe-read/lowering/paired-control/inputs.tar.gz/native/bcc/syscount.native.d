/var/tmp/kprog-tmp/A/probe-read/lowering/paired-control/native/bcc/syscount.native.o: \
  bcc/libbpf-tools/syscount.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /workspaces/repository/vendor/bpf/bcc/libbpf-tools/arm64/vmlinux.h \
  bcc/libbpf-tools/syscount.h bcc/libbpf-tools/maps.bpf.h
