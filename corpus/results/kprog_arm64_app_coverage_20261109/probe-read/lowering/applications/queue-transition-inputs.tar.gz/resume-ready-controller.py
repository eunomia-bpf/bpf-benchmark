from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,io,json,os,select,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;F=G.parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261109/probe-read/lowering/applications';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 rec=json.loads((G/'execution-resume.json').read_text())['publication']
 results={}
 for app in ['bcc','tracee']:
  save('actual_application',application=app,launch_publication=rec,results=results)
  child=G/app
  with (child/'application.log').open('w') as log:p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','python3',str(child/'mount.py'),app],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
  Q=O/app/('trusted-arm64-'+app+'-result');Q.mkdir(parents=True,exist_ok=True);(Q/'driver.log.gz').write_bytes(gzip.compress((child/'application.log').read_bytes(),mtime=0));paths=[Q/'driver.log.gz'];terminal=dict(utc=now(),make_exit=p.returncode)
  if (Q/'summary.json').exists():
   d=json.loads((Q/'summary.json').read_text());archive=Q/d['archive'];scope=dict(Path=Path,Counter=collections.Counter,tarfile=tarfile,io=io,json=json,hashlib=hashlib,now=now);exec(compile((A/'design-only/app-coverage.py').read_text(),'coverage','exec'),scope);terminal['coverage']=scope['coverage'](d,archive);paths.extend([Q/'summary.json',archive])
  (Q/'coverage.json').write_text(json.dumps(terminal,indent=2)+'\n');paths.append(Q/'coverage.json')
  result=pub.publish([str(p.relative_to(R)) for p in paths],'Collect complete ARM '+app+' scalar probe read application','arm-probe-read-'+app+'-terminal')
  results[app]=dict(publication=result,make_exit=p.returncode)
  removed=[]
  for name in ['source','manifests']:
   root=child/name;size=sum(p.stat().st_size for p in root.rglob('*') if p.is_file());shutil.rmtree(root);removed.append(dict(path=str(root),bytes=size))
  (child/'cleanup.json').write_text(json.dumps(dict(utc=now(),publication=result,retired=removed),indent=2)+'\n')
  with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/S2/V/R '+now()+': PUSHED '+result['commit']+' completeARM '+app+' scalarprobe-read actualMake'+str(p.returncode)+'. Fullsource/native/B/service/verifier/work outcomes retained; closedprivate source/manifests retired'+str(sum(x['bytes'] for x in removed))+'B. Runtimeadmissionadditions0.\n')
 save('finished',results=results,launch_publication=rec)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
