savedcmd_bpf_arm64_ccmp.mod := printf '%s\n'   bpf_arm64_ccmp.o | awk '!x[$$0]++ { print("./"$$0) }' > bpf_arm64_ccmp.mod
