savedcmd_bpf_arm64_ldr.mod := printf '%s\n'   bpf_arm64_ldr.o | awk '!x[$$0]++ { print("./"$$0) }' > bpf_arm64_ldr.mod
