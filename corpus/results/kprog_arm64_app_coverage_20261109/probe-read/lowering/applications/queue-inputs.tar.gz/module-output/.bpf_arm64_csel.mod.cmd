savedcmd_bpf_arm64_csel.mod := printf '%s\n'   bpf_arm64_csel.o | awk '!x[$$0]++ { print("./"$$0) }' > bpf_arm64_csel.mod
