savedcmd_bpf_arm64_native_lab.mod := printf '%s\n'   bpf_arm64_native_lab.o | awk '!x[$$0]++ { print("./"$$0) }' > bpf_arm64_native_lab.mod
