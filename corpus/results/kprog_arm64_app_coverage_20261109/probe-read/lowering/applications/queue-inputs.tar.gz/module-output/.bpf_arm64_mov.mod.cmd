savedcmd_bpf_arm64_mov.mod := printf '%s\n'   bpf_arm64_mov.o | awk '!x[$$0]++ { print("./"$$0) }' > bpf_arm64_mov.mod
