#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
	.arch = MODULE_ARCH_INIT,
};



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xb3c47d95, "register_btf_kfunc_id_set" },
	{ 0x008a44e9, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "D7176370E8776D089800B46");
