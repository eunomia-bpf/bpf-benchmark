savedcmd_bpf_arm64_str.mod := printf '%s\n'   bpf_arm64_str.o | awk '!x[$$0]++ { print("./"$$0) }' > bpf_arm64_str.mod
