savedcmd_bpf_arm64_prfm.mod := printf '%s\n'   bpf_arm64_prfm.o | awk '!x[$$0]++ { print("./"$$0) }' > bpf_arm64_prfm.mod
