savedcmd_bpf_arm64_ubfm.mod := printf '%s\n'   bpf_arm64_ubfm.o | awk '!x[$$0]++ { print("./"$$0) }' > bpf_arm64_ubfm.mod
