savedcmd_bpf_arm64_rev.mod := printf '%s\n'   bpf_arm64_rev.o | awk '!x[$$0]++ { print("./"$$0) }' > bpf_arm64_rev.mod
