savedcmd_bpf_arm64_extr.mod := printf '%s\n'   bpf_arm64_extr.o | awk '!x[$$0]++ { print("./"$$0) }' > bpf_arm64_extr.mod
