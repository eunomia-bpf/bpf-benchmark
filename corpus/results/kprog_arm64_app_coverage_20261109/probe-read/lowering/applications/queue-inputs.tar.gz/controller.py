from pathlib import Path
import collections,datetime,gzip,hashlib,importlib.util,io,json,os,select,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;F=G.parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261109/probe-read/lowering/applications';O.mkdir(exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 save('capturing_whole_application_inputs')
 head=git('rev-parse','HEAD').decode().strip()
 runtime=R/'kprog/arm64/build/native-load-recovery/recovery'
 shutil.copytree(runtime,G/'runtime',dirs_exist_ok=True)
 K=A/'native-load-recovery/arm64'
 for n in ['paired-modules','module-output']:shutil.copytree(K/n,G/n,dirs_exist_ok=True,symlinks=True)
 base_archives={'bcc':R/'corpus/results/kprog_arm64_app_coverage_20261108/native-load-recovery/arm64/applications/launch-inputs.tar.gz','tracee':R/'corpus/results/kprog_arm64_app_coverage_20261108/tracee-unix-length/application/launch-inputs.tar.gz'}
 native={p.name:p for p in (F/'native').rglob('*.native.o')}
 input_receipts={}
 for app in ['bcc','tracee']:
  child=G/app;child.mkdir(exist_ok=True);old={};archive=base_archives[app]
  with tarfile.open(archive) as tf:
   for m in tf:
    if not m.isfile():continue
    p=child/m.name;p.parent.mkdir(parents=True,exist_ok=True);data=tf.extractfile(m).read();p.write_bytes(data);old[m.name]=hashlib.sha256(data).hexdigest()
  for p in sorted((child/'source').rglob('*')):
   if not p.is_file():continue
   rel=p.relative_to(child/'source')
   if str(rel).startswith(('kprog/','kinsn/')) and p.suffix in ['.h','.py']:
    q=subprocess.run(['git','show',head+':'+str(rel)],cwd=R,capture_output=True)
    if q.returncode==0:p.write_bytes(q.stdout)
  extra=git('ls-tree','-r','--name-only',head,'kprog/arm64').decode().splitlines()
  for rel in extra:
   if Path(rel).suffix in ['.h','.py'] and '/build/' not in rel and '/results/' not in rel:
    p=child/'source'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(git('show',head+':'+rel))
  aliases={'native-link':'native-link','native-link-arm64-entry-resources':'native-link','libnative_loader.so':'libnative_loader.so','trusted-native-loader':'trusted-native-loader','trusted-service-client':'trusted-service-client'}
  for p in (child/'source').rglob('*'):
   if p.is_file() and p.name in aliases:shutil.copy2(G/'runtime'/aliases[p.name],p)
  manifest=json.loads((child/'manifests'/(app+'.json')).read_text())
  replacement=[]
  for row in manifest['objects']+manifest.get('data_objects',[]):
   target=Path(row['native_object']);candidate=native.get(target.name)
   if candidate is not None:
    p=child/'source'/target.relative_to(R);p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(candidate,p);replacement.append(dict(path=str(target),sha256=sha(p),candidate=str(candidate)))
  # Retain each original transport and functional workload while changing P.
  if app=='bcc':shutil.copy2(child/'bcc-transport.py',child/'transport.py')
  make='R := /workspaces/repository\n.PHONY: application\napplication:\n\t$(MAKE) -f corpus/results/kprog_arm64_app_coverage_20261106/Makefile trusted-service-arm64-run TRUSTED_APP=$(APP) TRUSTED_RESULTS='+str(O/app)+'\n'
  (child/'Makefile').write_text(make)
  mount=(child/'mount.py').read_text()
  start=mount.index('K=')
  end=mount.index('for source,target',start)
  mount=mount[:start]+"K=G.parent\nstage=R/'kprog/arm64/build/native-load-recovery/recovery'\nsubprocess.run(['mount','--bind',str(K/'runtime'),str(stage)],check=True)\n"+mount[end:]
  mount=mount.replace("str(G/(app+'-transport.py'))","str(G/'transport.py')")
  (child/'mount.py').write_text(mount)
  initial={str(p.relative_to(child)):sha(p) for p in child.rglob('*') if p.is_file()}
  changed=[p for p in child.rglob('*') if p.is_file() and old.get(str(p.relative_to(child)))!=sha(p)]
  delta=O/(app+'-input-delta.tar.gz')
  with tarfile.open(delta,'w:gz') as tf:
   for p in changed:tf.add(p,arcname=str(p.relative_to(child)))
  input_receipts[app]=dict(base_archive=str(archive.relative_to(R)),base_archive_sha256=sha(archive),delta_archive=str(delta.relative_to(R)),delta_archive_sha256=sha(delta),model_source_head=head,files=initial,native_replacements=replacement,manifest_rows=len(manifest['objects']),functional_recipe='Captured complete prior application recipe, paired workload/JIT/manifest; restored05-29 hardware timing remains R-owned')
 predecessors=[]
 for p in [A/'bpf34/current-kfunc-catalog/controller.pid',A/'app-source/tracee-unix-length/application/controller.pid']:
  pid=int(p.read_text())
  try:fd=os.pidfd_open(pid)
  except ProcessLookupError:fd=None
  predecessors.append((str(p),pid,fd))
 report=dict(utc=now(),scope='Complete ARM BCC then paired Tracee; P compiler scalar probe-read lowering; current replays complete first',compiler_publication=json.loads((F/'status.json').read_text())['publication']['commit'],model_source_head=head,applications=input_receipts,runtime={str(p.relative_to(G/'runtime')):sha(p) for p in (G/'runtime').rglob('*') if p.is_file()},predecessors=[dict(path=p,pid=pid) for p,pid,fd in predecessors],runtime_admission_additions=0)
 (O/'queued.json').write_text(json.dumps(report,indent=2)+'\n')
 (O/'README.md').write_text('Complete ARM scalar probe-read native P applications\n\nExisting complete BCC and paired-source Tracee functional recipes run serially16-19 after the current full catalog and paired Tracee controllers close. Every original manifest entry, startup probe, baseline embedded BPF and workload is captured. Native P replaces the8BCC and3Tracee translation-unit objects with actual compiler8a3dc898b outputs. The committed ARM simulator and current paired same-copy recovery runtime are captured privately. Inputs reconstruct from each existing published base archive plus its input-delta archive; queued.json records every final source, binary and manifest hash. Common runtime/module artifacts accompany the queue archive. Captured functional recipes keep their provenance; restored05-29 performance timing remains R-owned. Every actual generator/compiler/verifier/installed/execution/work stage follows in the terminal archives. Runtime admission additions:0.\n')
 with tarfile.open(O/'queue-inputs.tar.gz','w:gz') as tf:
  tf.add(G/'controller.py',arcname='controller.py')
  for n in ['capture-initial.json','controller.initial-follow-links.py']:
   if (G/n).exists():tf.add(G/n,arcname=n)
  for name in ['runtime','paired-modules','module-output']:tf.add(G/name,arcname=name)
 rec=pub.publish([str(p.relative_to(R)) for p in sorted(O.iterdir()) if p.is_file()],'Queue complete ARM BCC and Tracee scalar probe read applications','arm-probe-read-whole-app-launch')
 save('waiting_existing_full_and_Tracee',publication=rec,predecessors=report['predecessors'])
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/S2/V/R '+now()+': PUSHED '+rec['commit']+' completeARM BCC->Tracee probe-read P application queue, actualcompiler8a3dc898b. Existing full2792901+Tracee2801443 lifetimes pinned bypidfd; bothclosebefore firstnewguest. Nativeobjects/sourcehead/runtime/module/manifests/JIT/workload captured; originalwhole rows retained. Privateinputs onvar/tmp, guests serial16-19 (BCC2GiB/Tracee8GiB). Existingpriorfunctionalrecipesretaincapturedmeaning; R05-29 performance staysseparate. Runtimeadmissionadditions0.\n')
 pending=[fd for p,pid,fd in predecessors if fd is not None]
 while pending:
  ready,_,_=select.select(pending,[],[])
  for fd in ready:os.close(fd);pending.remove(fd)
 results={}
 for app in ['bcc','tracee']:
  save('actual_application',application=app,launch_publication=rec,results=results)
  child=G/app
  with (child/'application.log').open('w') as log:p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','python3',str(child/'mount.py'),app],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
  Q=O/app/('trusted-arm64-'+app+'-result');Q.mkdir(parents=True,exist_ok=True);(Q/'driver.log.gz').write_bytes(gzip.compress((child/'application.log').read_bytes(),mtime=0));paths=[Q/'driver.log.gz'];terminal=dict(utc=now(),make_exit=p.returncode)
  if (Q/'summary.json').exists():
   d=json.loads((Q/'summary.json').read_text());archive=Q/d['archive'];scope=dict(Path=Path,Counter=collections.Counter,tarfile=tarfile,io=io,json=json,hashlib=hashlib,now=now);exec(compile((A/'design-only/app-coverage.py').read_text(),'coverage','exec'),scope);terminal['coverage']=scope['coverage'](d,archive);paths.extend([Q/'summary.json',archive])
  (Q/'coverage.json').write_text(json.dumps(terminal,indent=2)+'\n');paths.append(Q/'coverage.json')
  result=pub.publish([str(p.relative_to(R)) for p in paths],'Collect complete ARM '+app+' scalar probe read application','arm-probe-read-'+app+'-terminal')
  results[app]=dict(publication=result,make_exit=p.returncode)
  removed=[]
  for name in ['source','manifests']:
   root=child/name;size=sum(p.stat().st_size for p in root.rglob('*') if p.is_file());shutil.rmtree(root);removed.append(dict(path=str(root),bytes=size))
  (child/'cleanup.json').write_text(json.dumps(dict(utc=now(),publication=result,retired=removed),indent=2)+'\n')
  with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/S2/V/R '+now()+': PUSHED '+result['commit']+' completeARM '+app+' scalarprobe-read actualMake'+str(p.returncode)+'. Fullsource/native/B/service/verifier/work outcomes retained; closedprivate source/manifests retired'+str(sum(x['bytes'] for x in removed))+'B. Runtimeadmissionadditions0.\n')
 save('finished',results=results,launch_publication=rec)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
