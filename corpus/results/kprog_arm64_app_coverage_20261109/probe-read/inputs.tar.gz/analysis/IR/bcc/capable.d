/var/tmp/kprog-tmp/A/probe-read/IR/bcc/capable.ll: \
  bcc/libbpf-tools/capable.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /workspaces/repository/vendor/bpf/bcc/libbpf-tools/arm64/vmlinux.h \
  bcc/libbpf-tools/capable.h
