/var/tmp/kprog-tmp/A/probe-read/IR/bcc/biosnoop.ll: \
  bcc/libbpf-tools/biosnoop.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /workspaces/repository/vendor/bpf/bcc/libbpf-tools/arm64/vmlinux.h \
  bcc/libbpf-tools/biosnoop.h bcc/libbpf-tools/core_fixes.bpf.h
