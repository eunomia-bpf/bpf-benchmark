/var/tmp/kprog-tmp/A/probe-read/IR/bcc/tcpconnect.ll: \
  bcc/libbpf-tools/tcpconnect.bpf.c \
  /workspaces/repository/vendor/bpf/native_compat.h \
  /workspaces/repository/vendor/bpf/bcc/libbpf-tools/arm64/vmlinux.h \
  bcc/libbpf-tools/maps.bpf.h bcc/libbpf-tools/tcpconnect.h
