from pathlib import Path
import os,subprocess
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;T=A/'app-source/tracee-unix-length'
for src,dst in [(T/'tree',R/'vendor/bpf/tracee/pkg/ebpf/c'),(T/'build-source/vendor/bpf/native_compat.h',R/'vendor/bpf/native_compat.h')]:
 subprocess.run(['mount','--bind',str(src),str(dst)],check=True)
os.execvp('python3',['python3',str(G/'controller.py')])
