from pathlib import Path
from collections import Counter
import datetime,gzip,hashlib,importlib.util,json,os,re,shlex,subprocess,tarfile,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');G=Path(__file__).resolve().parent;T=A/'app-source/tracee-unix-length';O=R/'corpus/results/kprog_arm64_app_coverage_20261109/probe-read'
O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 save('capturing_actual_native_IR')
 old=json.loads((R/'corpus/results/kprog_arm64_app_coverage_20261109/producer-os/summary.json').read_text())
 commands=[(x['object'].replace('.native.o',''),x['command']) for x in old['rows'] if x['optimization']=='O3' and x['object'].startswith('bcc/')]
 out=G/'native'
 targets=[str(out/'tracee/tracee.native.o')]+[str(out/('tracee/lsm_support/'+x+'.native.o')) for x in ['kprobe_check','lsm_check']]
 make=['make','--no-print-directory','-n','-f',str(G/'tracee-Makefile'),'ARCH=arm64','NATIVE_OUT='+str(out),'NATIVE_DIVISION_PLUGIN='+str(G/'native_division.so'),'NATIVE_SYS_INCLUDE_FLAGS=-I/usr/aarch64-linux-gnu/include -I'+str(R/'.cache/aarch64-sysroot/usr/include')+' -I'+str(R/'.cache/aarch64-sysroot/usr/include/aarch64-linux-gnu'),*targets]
 p=subprocess.run(make,cwd=R/'vendor/bpf',text=True,capture_output=True);(G/'tracee-recipe.log').write_text(p.stdout+p.stderr);p.check_returncode()
 for l in re.sub(r'\\\n[ \t]*',' ',p.stdout).splitlines():
  cmd=shlex.split(l)
  if cmd and Path(cmd[0]).name=='clang-18':
   path=Path(cmd[cmd.index('-o')+1]);commands.append((str(path.relative_to(out)).replace('.native.o',''),cmd))
 units=[];deps={}
 for unit,cmd in commands:
  output=G/'IR'/(unit+'.ll');output.parent.mkdir(parents=True,exist_ok=True)
  cmd=list(cmd);cmd[cmd.index('-o')+1]=str(output)
  cmd=[x for x in cmd if x not in ['-c','-MMD']]
  if '-MF' in cmd:i=cmd.index('-MF');del cmd[i:i+2]
  cmd=[('-fpass-plugin='+str(G/'native_division.so')) if x.startswith('-fpass-plugin=') else x for x in cmd]
  cmd+=['-S','-emit-llvm','-MMD','-MF',str(output.with_suffix('.d'))]
  save('compiling_native_IR',unit=unit,completed=len(units))
  with output.with_suffix('.log').open('w') as f:p=subprocess.run(cmd,cwd=R/'vendor/bpf',stdout=f,stderr=subprocess.STDOUT)
  row=dict(unit=unit,command=cmd,compile_exit=p.returncode)
  if output.exists():row.update(sha256=sha(output),bytes=output.stat().st_size)
  units.append(row)
  d=output.with_suffix('.d')
  if d.exists():
   for name in shlex.split(re.sub(r'\\\n',' ',d.read_text()).split(':',1)[1]):
    path=Path(name);path=path if path.is_absolute() else R/'vendor/bpf'/path
    if path.is_file():deps[str(path)]=dict(sha256=sha(path),bytes=path.stat().st_size)
 helper_names={4:'probe_read',45:'probe_read_str',112:'probe_read_user',113:'probe_read_kernel',114:'probe_read_user_str',115:'probe_read_kernel_str'}
 sites=[]
 for unit in units:
  p=G/'IR'/(unit['unit']+'.ll')
  if not p.exists():continue
  text=p.read_text()
  for fn in re.finditer(r'^define [^\n]*@([^ (]+)\([^\n]*\)[^\n]*\{\n(.*?)^\}',text,re.M|re.S):
   name,body=fn.group(1),fn.group(2);counts=Counter(re.findall(r'%[-a-zA-Z$._0-9]+',body));ids={};pointers={}
   for line in body.splitlines():
    m=re.match(r'\s*(%[-a-zA-Z$._0-9]+) = .*call i64 asm .*?\(i64 (\d+),',line)
    if m:ids[m.group(1)]=int(m.group(2))
    m=re.match(r'\s*(%[-a-zA-Z$._0-9]+) = inttoptr i64 (%[-a-zA-Z$._0-9]+) to ptr',line)
    if m and m.group(2) in ids:pointers[m.group(1)]=ids[m.group(2)]
    m=re.search(r'\bcall (?:[^@%(]* )?i64 ([@%][-a-zA-Z$._0-9]+)\((.*)\)',line)
    if not m:continue
    called,args=m.group(1),m.group(2);helper=None
    if called.startswith('@bpf_'):
     helper=next((k for k,v in helper_names.items() if called=='@bpf_'+v),None)
    else:helper=pointers.get(called)
    if helper not in helper_names:continue
    argv=args.split(',');size=None
    if len(argv)>1:
     sm=re.search(r'\b(-?\d+)\s*$',argv[1])
     if sm:size=int(sm.group(1))
    result=re.match(r'\s*(%[-a-zA-Z$._0-9]+) =',line)
    used=bool(result and counts[result.group(1)]>1)
    sites.append(dict(unit=unit['unit'],function=name,helper_id=helper,helper=helper_names[helper],constant_size=size,return_value_used=used,scalar_kernel_read_candidate=helper==113 and size in [1,2,4,8] and not used,line=line.strip()))
 summary=Counter(x['helper'] for x in sites);eligible=[x for x in sites if x['scalar_kernel_read_candidate']]
 report=dict(utc=now(),scope='Read-only inventory of actual optimized native IR for all8BCC and paired Tracee translation units',source_tracee='61c85aa5febf1b6bd8acf8a37104469d90faa32a',plugin_sha256=sha(G/'native_division.so'),units=units,dependencies=deps,helper_counts=dict(summary),scalar_kernel_read_candidates=len(eligible),candidate_sizes=dict(Counter(str(x['constant_size']) for x in eligible)),candidates_by_unit=dict(Counter(x['unit'] for x in eligible)),sites=sites,runtime_admission_additions=0)
 (O/'inventory.json').write_text(json.dumps(report,indent=2)+'\n')
 md=['# Tracee and BCC native probe-read lowering inventory','','Actual optimized ARM native IR from the existing8BCC and3paired Tracee translation units. The application C, native production recipe, division lowering, benchmark framework and current running replay epochs retain their captured definitions.','','Successful IR compiles: '+str(sum(x['compile_exit']==0 for x in units))+'/'+str(len(units))+'. Static probe-read helper calls: '+str(len(sites))+'. Scalar kernel-read candidates with a constant single-load width and an unused helper return: '+str(len(eligible))+'.','','| Helper | Static calls |','| --- | ---: |']
 for k,v in sorted(summary.items()):md.append('| '+k+' | '+str(v)+' |')
 md+=['','## Lowering interface','','The existing kernel helper copies bytes and clears the destination on a read fault. Its return carries0or-EFAULT. Scalar fixed-size calls whose return is discarded can express the same destination observation through one protected native load followed by the destination store. Sizes1/2/4/8 correspond to the existing native scalar read forms and stock exception-table full-register zero/resume behavior. Calls that consume the helper result, wider copies, strings and user reads retain their existing helper operation while the following lowering work develops their complete return/copy/fault behavior.','','The Tracee native helper ABI carries helper identity through its existing empty inline-assembly marker and inttoptr call. BCC uses ordinary named calls. inventory.json retains every site and exact IR line, compiler command, source/dependency identity and status. inputs.tar.gz retains optimized IR, actual source dependencies, plugin, scripts and compiler output. This inventory provides compiler selection evidence; production lowering, generation-bound replay and hardware performance supply subsequent measurements.','']
 (O/'README.md').write_text('\n'.join(md))
 with tarfile.open(O/'inputs.tar.gz','w:gz') as tf:
  for p in sorted(G.rglob('*')):
   if p.is_file() and p.name not in ['controller.log','controller.pid','status.json']:tf.add(p,arcname='analysis/'+str(p.relative_to(G)))
  for name in sorted(deps):tf.add(name,arcname='dependencies/'+name.lstrip('/'))
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str(p.relative_to(R)) for p in sorted(O.iterdir()) if p.is_file()],'Inventory Tracee and BCC native probe read lowering sites','arm-probe-read-inventory')
 save('finished',publication=rec,compiled=sum(x['compile_exit']==0 for x in units),attempted=len(units),helper_counts=dict(summary),scalar_candidates=len(eligible),candidate_sizes=report['candidate_sizes'],candidates_by_unit=report['candidates_by_unit'])
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/S2/V/R '+now()+': PUSHED '+rec['commit']+' Tracee/BCC optimized nativeIR inventory: '+str(len(sites))+' staticprobe-read calls, '+str(len(eligible))+' single-load scalar kernel-read candidates withdiscardedhelperreturn; exact callsites/IR/source/plugin captured. Native helper return0/-EFAULT and fullzero-onfault define loweringinterface; Traceeusesexisting113helpermarker/inttoptr, BCCnamedcalls. Runtime/model/workload source retainsphysicalbytes. Current full/Tracee applicationcontrollerscontinue. Runtimeadmissionadditions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
