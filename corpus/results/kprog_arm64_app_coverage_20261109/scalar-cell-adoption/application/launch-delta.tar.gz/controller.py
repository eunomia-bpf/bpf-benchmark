from pathlib import Path
import subprocess,tarfile,json,datetime,hashlib,shutil,os,gzip,collections,importlib.util,io,traceback,re
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=Path('/var/tmp/kprog-tmp/A/biosnoop-creation-state');G=Path(__file__).resolve().parent;K=Path('/var/tmp/kprog-tmp/A/probe-read/lowering/applications');O=R/'corpus/results/kprog_arm64_app_coverage_20261109/scalar-cell-adoption/application';O.mkdir(parents=True,exist_ok=True)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 import select
 try:
  fd=os.pidfd_open(3600740);select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 build=json.loads((R/'corpus/results/kprog_arm64_app_coverage_20261109/biosnoop-creation-state/build.json').read_text())
 rec=dict(commit='5f259ab00')
 (O/'README.md').write_text('Complete ARM BCC dynamic/scalar-cell application\n\nAll eight tools and32original manifest rows use the current frozen May29 framework. The generic scalar-cell sourcee2e6dc6c034375365d6f359f5faca766e360a271pairs with f1/e5/3e3f runtime and first-attempt loaderd1b4. Biosnoop0185creation-state and opensnoop4474ret-store source edits are each built into matching JIT/BPF/native objects; both user binaries are dynamically relinked2eb414400for the existing LD_PRELOAD shim. Complete sources, native ELF, embedded BPF and executable hashes are retained. Every original symbol selector stays selected; bytecode-length selectors follow the same embedded BPF object. Original48safety runs first on this model. QEMU counters are functional; all actual generation/verifier/install/work outcomes remain raw. Runtime admission additions:0.\n')

 save('preparing_complete_BCC',build_publication=rec)
 queued=json.loads((R/'corpus/results/kprog_arm64_app_coverage_20261109/probe-read/lowering/applications/queued.json').read_text())['applications']['bcc']
 archives=[queued['base_archive'],queued['delta_archive'],'corpus/results/kprog_arm64_app_coverage_20261109/frame-equality/application/launch-delta.tar.gz']
 for archive in archives:
  with tarfile.open(R/archive) as tf:
   for m in tf:
    if m.isfile() and (m.name.startswith('source/') or m.name=='manifests/bcc.json'):
     p=G/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tf.extractfile(m).read());p.chmod(m.mode)
 source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 frozen_prefixes=['runner/libs/workload.py','runner/libs/app_runners','corpus/driver.py','corpus/config','micro/driver.py','micro/config','micro/programs','Makefile','micro/Makefile','runner/mk']
 frozen=subprocess.check_output(['git','ls-tree','-r','--name-only',source_head,*frozen_prefixes],cwd=R,text=True).splitlines()
 for rel in frozen:
  q=G/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(subprocess.check_output(['git','show',source_head+':'+rel],cwd=R))
 rel='kprog/arm64/arm64_sim_local_bpf.h';(G/'source'/rel).write_bytes(subprocess.check_output(['git','show','e2e6dc6c034375365d6f359f5faca766e360a271:'+rel],cwd=R))
 epoch='e2e6dc6c034375365d6f359f5faca766e360a271'
 model_paths=subprocess.check_output(['git','ls-tree','-r','--name-only',epoch,'kprog/arm64','kprog/formal/generated','kprog/helper_abi.py'],cwd=R,text=True).splitlines()
 for rel in model_paths:
  if rel.endswith(('.h','.py','.c','.hpp')):
   q=G/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(subprocess.check_output(['git','show',epoch+':'+rel],cwd=R))
 shutil.copytree(K/'runtime',G/'runtime')
 for name in ['libnative_loader.so','trusted-native-loader','trusted-service-client']:
  shutil.copy2(Path('/var/tmp/kprog-tmp/A/single-load-attempt/runtime')/name,G/'runtime'/name)

 aliases={'native-link':'native-link','native-link-arm64-entry-resources':'native-link','libnative_loader.so':'libnative_loader.so','trusted-native-loader':'trusted-native-loader','trusted-service-client':'trusted-service-client'}
 for p in (G/'source').rglob('*'):
  if p.is_file() and p.name in aliases:shutil.copy2(G/'runtime'/aliases[p.name],p)
 P=Path('/var/tmp/kprog-tmp/A/dynamic-bcc-artifacts')
 shutil.copy2(P/'biosnoop/biosnoop.O3.native.o',G/'source/kprog/arm64/build/app-verified-stage/bcc/biosnoop.native.o')
 shutil.copy2(P/'opensnoop/native/reordered.native.o',G/'source/kprog/arm64/build/app-verified-stage/bcc/opensnoop.native.o')
 # Capture the actual installed five-step shim as part of this immutable source view.
 shimrel='kprog/arm64/build/design-only/libbpfrejit_shim.so'
 q=G/'source'/shimrel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/shimrel,q)

 manifest=json.loads((G/'manifests/bcc.json').read_text())
 selector_changes=[]
 for tool in ['biosnoop','opensnoop']:
  symbols=subprocess.check_output(['llvm-objdump-18','--syms',str(P/tool/'jit'/(tool+'.bpf.o'))],text=True)
  lengths={m.group(2):int(m.group(1),16) for l in symbols.splitlines() if (m:=re.search(r'\bg\s+F\s+\S+\s+([0-9a-f]+)\s+(\w+)$',l))}
  for row in manifest['objects']:
   if tool in row['native_object']:
    length=lengths[row['symbol']];selector_changes.append(dict(tool=tool,symbol=row['symbol'],before=row['source_bytecode_len'],after=length));row['source_bytecode_len']=length
 (G/'manifests/bcc.json').write_text(json.dumps(manifest,indent=2)+'\n')
 transport=(K/'bcc/transport.py').read_text().replace('security_model=none,readonly=on','security_model=none,multidevs=remap,readonly=on').replace("str(ROOT) + ',security_model=none'","str(ROOT) + ',security_model=none,multidevs=remap'")
 (G/'transport.py').write_text(transport)
 mount=(K/'bcc/mount.py').read_text().replace('K=G.parent','K=Path('+repr(str(K))+')').replace("str(K/'runtime')","str(G/'runtime')")
 mount='\n'.join(l for l in mount.splitlines() if "if app=='bcc':subprocess.run" not in l)+'\n'
 marker="os.execvp('make'"
 i=mount.index(marker)
 mount=mount[:i]+"subprocess.run(['mount','--bind',"+repr(str(P/'biosnoop/biosnoop'))+",str(R/'kprog/arm64/build/app-runtime-v35/root/usr/local/bin/biosnoop')],check=True)\n"+"subprocess.run(['mount','--bind',"+repr(str(P/'opensnoop/opensnoop'))+",str(R/'kprog/arm64/build/app-runtime-v35/root/usr/local/bin/opensnoop')],check=True)\n"+mount[i:]
 (G/'mount.py').write_text(mount)
 (G/'Makefile').write_text('.PHONY: application\napplication:\n\t$(MAKE) -f corpus/results/kprog_arm64_app_coverage_20261106/Makefile trusted-service-arm64-run TRUSTED_APP=$(APP) TRUSTED_RESULTS='+str(O/'application')+'\n')
 pins={str(p.relative_to(G/'source')):sha(p) for p in (G/'source').rglob('*') if p.is_file()}
 launch=dict(utc=now(),build_publication=rec['commit'],source_publication='e2e6dc6c034375365d6f359f5faca766e360a271',application_source_edits=['0185e288bd959906a4b7058a39e5fa0edfe5f3b7','4474ab41ee049913fe45b0a2431c47bb4f335b45'],dynamic_artifacts='2eb414400ed57936c3c9db9e9e972976166a7ec5',model_publication='e2e6dc6c034375365d6f359f5faca766e360a271',framework_capture=source_head,framework_files={rel:pins[rel] for rel in frozen},base_archives=archives,source_sha256=pins,runtime_sha256={str(p.relative_to(G/'runtime')):sha(p) for p in (G/'runtime').rglob('*') if p.is_file()},native_manifest_rows=len(manifest['objects']),biosnoop_selectors=selector_changes,biosnoop_binary_sha256=sha(P/'biosnoop/biosnoop'),opensnoop_binary_sha256=sha(P/'opensnoop/opensnoop'),guest=dict(memory_MiB=2048,cpu='16-19'),runtime_admission_additions=0)
 (O/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
 with tarfile.open(O/'launch-delta.tar.gz','w:gz') as tf:
  old=json.loads((R/'corpus/results/kprog_arm64_app_coverage_20261109/frame-equality/application/launch.json').read_text())['source_sha256']
  for p in sorted((G/'source').rglob('*')):
   if p.is_file() and old.get(str(p.relative_to(G/'source')))!=sha(p):tf.add(p,arcname=str(p.relative_to(G)))
  for name in ['controller.py','mount.py','transport.py','Makefile','manifests/bcc.json']:tf.add(G/name,arcname=name)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['launch.json','launch-delta.tar.gz','README.md']],'Run complete ARM BCC with paired biosnoop creation state','arm-dynamic-scalar-application-launch')
 save('actual_complete_application',publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/R/V '+now()+': PUSHED '+rec['commit']+' complete eight-tool ARM BCC dynamic paired Bio0185/Open4474 source and scalar-cell model replay launched2GiB16-19. JIT/native O3 share edited sourceSHA'+build['change']['after_sha256']+'; all32manifestrows retained, Bio/Open bytecode lengths refreshed from embedded BPF. O3/Os native+B builds and JIT upstream binary compile0. Canonical model555implicitSP and captured f1/e5/3e3f runtime; frozen May29 framework bytes captured. Existing 9p multidevs=remap preserves individual file-bind visibility. Runtime admission additions0.\n')
 with (G/'application.log').open('w') as log:
  p=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','python3',str(G/'mount.py'),'bcc'],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 Q=O/'application/trusted-arm64-bcc-result';Q.mkdir(parents=True,exist_ok=True);(Q/'driver.log.gz').write_bytes(gzip.compress((G/'application.log').read_bytes(),mtime=0));paths=[Q/'driver.log.gz'];report=dict(utc=now(),make_exit=p.returncode)
 if (Q/'summary.json').exists():
  summary=json.loads((Q/'summary.json').read_text());archive=Q/summary['archive'];scope=dict(Path=Path,Counter=collections.Counter,tarfile=tarfile,io=io,json=json,hashlib=hashlib,now=now);exec(compile((A/'design-only/app-coverage.py').read_text(),'coverage','exec'),scope);report['coverage']=scope['coverage'](summary,archive);paths.extend([Q/'summary.json',archive])
 (Q/'coverage.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(Q/'coverage.json')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect complete ARM BCC paired biosnoop outcomes','arm-dynamic-scalar-application-terminal')
 save('finished',publication=rec,make_exit=p.returncode)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/R/V '+now()+': PUSHED '+rec['commit']+' complete ARM BCC paired biosnoop application Makeexit'+str(p.returncode)+'. All original full-app outcomes retained; runtime admission additions0.\n')
 retired=[]
 for root in [G/'source',G/'manifests',G/'runtime']:
  if not root.exists():continue
  size=sum(p.stat().st_size for p in root.rglob('*') if p.is_file());shutil.rmtree(root);retired.append(dict(path=str(root),bytes=size))
 (G/'cleanup.json').write_text(json.dumps(dict(utc=now(),publication=rec,retired=retired),indent=2)+'\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
