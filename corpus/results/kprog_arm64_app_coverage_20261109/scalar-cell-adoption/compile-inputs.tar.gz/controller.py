from pathlib import Path
import subprocess,json,datetime,os,tarfile,importlib.util,hashlib,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261109/scalar-cell-adoption'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(D/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase)|kw,indent=2)+'\n')
try:
 save('existing_micro_compilation')
 with (D/'micro.log').open('w') as log:proc=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','python3',str(D/'inside.py')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=proc.returncode,existing_host_receipts=['7c4636d3828af14f52d40c880ee1a21ada22045a','8b26b3b35ce07ed755f9381acf41cbf190b6978e'],source_base='55504ff906ab268a5cab3ab083d6d448d152ed54',source_files=['kprog/arm64/arm64_sim_local_bpf.h','kprog/arm64/micro-prog/arm64_abi.py','kprog/arm64/micro-prog/generate_micro_sim_proofs.py'],runtime_admission_additions=0)
 O.mkdir(exist_ok=True);(O/'compile.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'compile-inputs.tar.gz','w:gz') as tf:
  for p in sorted(D.rglob('*')):
   if p.is_file():tf.add(p,arcname=str(p.relative_to(D)))
 (O/'README.md').write_text('ARM scalar-cell storage adoption\n\nThe generic representation forwards selected full scalar words through named local C value/valid cells. The existing definedness layout chooses possibly-unspecified reads for efficiency; an arbitrary selected subset retains the same raw-memory fallback semantics. All native data reads/writes remain volatile, and pointer/scalar ghost facts remain internal C state. The existing SP release, helper write invalidation, caller clobber, return and architectural fault rules retain their operation bodies. The static slot selector introduces arithmetic/layout decisions and leaves admission to the stock verifier.\n\nOriginal13ARMgroups pass GCC/Clang18 in7c4636d38plus dependency-complete8b26b3b35. Original4BCC P/metadata compile20observations across recorded layouts; final tcplife/biosnoop/capable frames432/64/112. The same-source opensnoop ret-store edit4474plus relative-payload promotion gives512byte B in the matched last-word trial. Existing29micro/negative compile Make exit:'+str(proc.returncode)+'. Exact sources/recipes/compiler artifacts accompany compile-inputs.tar.gz. The original48safety and fullapplication replay follow captured source publication. Runtime predicates added:0.\n')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 paths=[str((O/n).relative_to(R)) for n in ['compile.json','compile-inputs.tar.gz','README.md']]
 rec=pub.publish(paths,'Compile ARM scalar-cell model on original micro corpus','arm-scalar-cell-micro-controls')
 if proc.returncode:
  save('micro_diagnostic',publication=rec,report=report)
 else:
  for rel in report['source_files']:
   base=subprocess.check_output(['git','show','HEAD:'+rel],cwd=R);old=subprocess.check_output(['git','show',report['source_base']+':'+rel],cwd=R)
   if base!=old or (R/rel).read_bytes()!=base:raise RuntimeError('shared ARM source changed '+rel)
  for rel in report['source_files']:(R/rel).write_bytes((D/'source'/rel).read_bytes())
  doc=R/'kprog/arm64/README.md';base=subprocess.check_output(['git','show','HEAD:kprog/arm64/README.md'],cwd=R)
  if doc.read_bytes()!=base:raise RuntimeError('ARM README has concurrent content')
  with doc.open('a') as f:f.write('\nThe [scalar-cell storage receipt](../../corpus/results/kprog_arm64_app_coverage_20261109/scalar-cell-adoption/README.md) records generic named scalar forwarding cells and ordinary local ghost tags/relative payloads. Native data accesses retain volatility. An arbitrary forwarding-cell subset preserves raw fallback; the definedness layout selects a compact set for compilation. Existing SP/helper/caller/return/fault operations retain their definitions. Original13ARMhost groups pass GCC/Clang18 with matching sanitizer runtime, and the original micro compile receipt accompanies the source. Full48safety/application observations retain their separate captured source epochs. The representation adds zero runtime admission predicates.\n')
  source=pub.publish(report['source_files']+['kprog/arm64/README.md'],'Represent ARM scalar forwarding as local value cells','arm-scalar-cell-source')
  save('source_published',source_publication=source,controls_publication=rec,report=report)
  with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/V/R '+now()+': PUSHED '+source['commit']+' generic ARM scalar-cell representation,3own sourcefiles+README. All original host13GCC+13Clang18 pass via7c463/8b26; original micro compile0 in'+rec['commit']+'. Named scalar cells, ordinary provenance/relativepayload ghost storage; all native bytes stayvolatile. Arbitrary selected cell subset falls backraw, so selection is layout optimization for everyP; existing definedness merely chooses efficient set. ExistingSP/helper/return/fault/clobber bodies retained, admission predicates added0. Current uniformcatalog555source snapshot retained. Original48and completeBCC candidate follow; C may reuse this generic metadata representation, V universal cell projection can treat arbitrary indexsubset.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
