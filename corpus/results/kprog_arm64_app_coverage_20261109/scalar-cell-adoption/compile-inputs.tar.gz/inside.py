from pathlib import Path
import subprocess,os
R=Path('/workspaces/repository');D=Path(__file__).resolve().parent
for p in sorted((D/'source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(D/'source'))],check=True)
os.execvp('make',['make','-f',str(D/'Makefile'),'micro'])
