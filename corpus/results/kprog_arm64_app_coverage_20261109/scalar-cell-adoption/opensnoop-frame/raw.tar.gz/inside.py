from pathlib import Path
import subprocess,os,sys
D=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
for p in sorted((D/'model-source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(D/'model-source'))],check=True)
subprocess.run(['mount','--bind',str(D/('header-'+sys.argv[1]+'.h')),str(R/'kprog/arm64/arm64_sim_local_bpf.h')],check=True)
os.execvp('make',['make','-f',str(D/'Makefile'),sys.argv[1]])
