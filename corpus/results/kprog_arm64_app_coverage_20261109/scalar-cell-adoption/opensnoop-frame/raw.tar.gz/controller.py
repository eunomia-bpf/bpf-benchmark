from pathlib import Path
import json,tarfile,subprocess,os,datetime,traceback,shutil
R=Path('/workspaces/repository');D=Path(__file__).resolve().parent
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(D/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase)|kw,indent=2)+'\n')
try:
 save('capturing_exact_reordered_P_and_model')
 with tarfile.open(R/'corpus/results/kprog_arm64_app_coverage_20261109/opensnoop-ret-order/raw.tar.gz') as tf:
  for m in tf:
   if m.isfile() and (m.name.startswith('src/') or m.name.startswith('model-source/') or m.name in ['native/reordered.native.o','commands.json','change.json','generation.json']):
    p=D/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tf.extractfile(m).read());p.chmod(m.mode)
 parent=D/'model-source/kprog/arm64/arm64_sim_local_bpf.h';(D/'header-parent.h').write_bytes(parent.read_bytes())
 (D/'header-payload.h').write_text(parent.read_text().replace('volatile __u64 __a64_stack_payload[ARM64_SIM_STACK_PAYLOAD_WORDS]','__u64 __a64_stack_payload[ARM64_SIM_STACK_PAYLOAD_WORDS]'))
 rows=[]
 for cohort in ['parent','payload']:
  with (D/(cohort+'.log')).open('w') as log:
   proc=subprocess.run(['unshare','--mount','--propagation','private','python3',str(D/'inside.py'),cohort],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
  rows.append(dict(cohort=cohort,exit=proc.returncode))
 save('finished',rows=rows)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
