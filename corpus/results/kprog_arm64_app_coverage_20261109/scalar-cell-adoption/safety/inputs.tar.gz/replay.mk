.PHONY: arm64
arm64:
	python3 /var/tmp/kprog-tmp/A/scalar-cell-safety/arm64-replay.py
