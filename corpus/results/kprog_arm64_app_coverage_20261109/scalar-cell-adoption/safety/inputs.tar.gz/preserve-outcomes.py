from pathlib import Path
import os,select,json,datetime
D=Path(__file__).resolve().parent
pid=int((D/'controller.pid').read_text())
try:fd=os.pidfd_open(pid)
except ProcessLookupError:fd=None
while True:
 files=list((D/'transport-output').rglob('outcomes.json'))
 if files:
  target=D/'safety-arm64-output/outcomes.json'
  if not target.exists():os.link(files[-1],target)
  (D/'outcome-preservation.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source=str(files[-1]),preserved=str(target)))+'\n')
  break
 if fd is None or select.select([fd],[],[],0.1)[0]:break
if fd is not None:os.close(fd)
