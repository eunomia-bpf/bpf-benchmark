from pathlib import Path
import subprocess,datetime,json,tarfile,hashlib,gzip,collections,importlib.util,shutil,traceback,os
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261109/scalar-cell-adoption/safety'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(D/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase)|kw,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
try:
 (D/'controller.pid').write_text(str(os.getpid())+'\n')
 source=json.loads((D/'source-publication.json').read_text());O.mkdir(exist_ok=True)
 launch=dict(utc=now(),source_publication=source['commit'],fixture_publication='9bd4222ba',recipe='Original S16/A implicit-SP48case recipe, same native negative load-only protocol',source_sha256={str(p.relative_to(D/'source')):sha(p) for p in (D/'source').rglob('*') if p.is_file()},runtime_sha256={p.name:sha(p) for p in (D/'runtime').iterdir() if p.is_file()},host_controls='Original13ARMgroups GCC+clang18 pass:7c4636d38+8b26b3b35',micro_receipt='fa403682456c6835ace8cc5fd2525a70393ce8af',guest=dict(memory_MiB=2048,cpu='16-19'),runtime_admission_additions=0)
 (O/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
 (O/'README.md').write_text('Original ARM safety suite on scalar-cell storage\n\nThe existing48scalar AArch64 fixtures and native-negative load-only protocol run with source'+source['commit']+' and the captured f1/e5/3e3f runtime/first-attempt loaderd1b4. Every original fixture remains exact. The new representation keeps volatile native data access and existing SP/helper/return/fault operations. Complete26original host groups/compiler observations pass through7c463/8b26, and existing29micro plus original negative compile passfa403. Native annotations/unsafe fixtures remain load-only. Source/runtime/input identities, every actual stage and original recovery-label findings are collected. Guest2GiB16-19 shares own allocation with uniform catalog. Runtime admission additions:0.\n')
 with tarfile.open(O/'inputs.tar.gz','w:gz') as tf:
  for p in sorted(D.rglob('*')):
   if p.is_file():tf.add(p,arcname=str(p.relative_to(D)))
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['launch.json','README.md','inputs.tar.gz']],'Run original ARM safety suite on scalar-cell storage','arm-scalar-cell-safety-launch')
 save('actual_arm64_safety',publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR V/C/COORDINATOR '+now()+': PUSHED '+rec['commit']+' original48ARM safety source'+source['commit']+' scalar-cell replay; all original S16fixtures/negative load-only protocol retained. Complete26host pass and29micro+negative compile0 already published. First-load d1b4 +f1/e5/3e3f runtime,2GiB16-19 beside uniformcatalog2GiB. Actual raw/model/nativeP/B/verifier/installed/result table auto-publishes. No additional predicates.\n')
 with (D/'preserve-outcomes.log').open('w') as log:subprocess.Popen(['python3',str(D/'preserve-outcomes.py')],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 with (D/'safety.log').open('w') as log:done=subprocess.run(['taskset','-c','16-19','make','-f',str(D/'replay.mk'),'arm64'],cwd=R,env=os.environ|{'TMPDIR':str(D),'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 Q=D/'safety-arm64-output';files=list(Q.rglob('outcomes.json'));rows=json.loads(files[-1].read_text()) if files else []
 report=dict(utc=now(),source_publication=source['commit'],make_exit=done.returncode,cases=len(rows),stages=dict(collections.Counter(r['stage'] for r in rows)),negative_native_test_run=sum(bool(r.get('negative')) and len(r.get('command',[]))>3 for r in rows),positive_results=[dict(name=r['name'],stage=r['stage'],returncode=r.get('returncode')) for r in rows if not r.get('negative')],accepted_load_only=[dict(name=r['name'],stage=r['stage'],request=r.get('request')) for r in rows if r['stage']=='accepted_finding'],runtime_admission_additions=0)
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');(O/'outcomes.json').write_text(json.dumps(rows,indent=2)+'\n');(O/'driver.log.gz').write_bytes(gzip.compress((D/'safety.log').read_bytes(),mtime=0))
 with tarfile.open(O/'raw.tar.gz','w:gz') as tf:
  for name in ['safety-arm64-output','build-arm64-output','transport-output','output-arm64-source']:
   for p in (D/name).rglob('*'):
    if p.is_file():tf.add(p,arcname=str(p.relative_to(D)))
  for p in D.iterdir():
   if p.is_file() and p.suffix in ['.log','.json','.py','.mk']:tf.add(p,arcname=p.name)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['summary.json','outcomes.json','driver.log.gz','raw.tar.gz']],'Collect ARM scalar-cell safety outcomes','arm-scalar-cell-safety-terminal')
 save('finished',publication=rec,summary=report)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR V/C/COORDINATOR '+now()+': PUSHED '+rec['commit']+' scalar-cell original ARM safety actual'+str(len(rows))+'cases '+str(report['stages'])+', Make'+str(done.returncode)+', negative nativeTEST_RUN'+str(report['negative_native_test_run'])+'. Every source/nativeP/B/compiler/verifier/result raw retained. Existing recovery-label accepted stages retain original S16triage; class changes get actual nativeP/B analysis. New predicates0.\n')
 retired=[]
 for name in ['source','runtime','safety-arm64-output','build-arm64-output','transport-output','output-arm64-source']:
  root=D/name
  if root.exists():
   size=sum(p.stat().st_size for p in root.rglob('*') if p.is_file());shutil.rmtree(root);retired.append(dict(path=str(root),bytes=size))
 (D/'cleanup.json').write_text(json.dumps(dict(utc=now(),retired=retired),indent=2)+'\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
