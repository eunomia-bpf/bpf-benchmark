from pathlib import Path
import json,subprocess
p=Path('/var/tmp/kprog-tmp/A/forwarding-revert');rows=[]
for old in json.loads((p/'checks.json').read_text()):
 if old.get('run_returncode')==0:continue
 cmd=[x for x in old['command'] if not x.startswith(('-fsanitize=','-fno-sanitize-')) and x!='-lubsan'];dst=cmd.index('-o')+1;cmd[dst]+='-original-flags'
 c=subprocess.run(cmd,cwd='/workspaces/repository/kprog/formal',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);r=subprocess.run([cmd[dst]],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT) if c.returncode==0 else None
 rows.append({'command':cmd,'source_sha256':old['source_sha256'],'compile_returncode':c.returncode,'compile_output':c.stdout,'run_returncode':r.returncode if r else None,'stdout':r.stdout if r else ''})
(p/'original-flags.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
