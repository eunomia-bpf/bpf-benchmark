from pathlib import Path
import subprocess,json,os,hashlib
root=Path('/workspaces/repository');formal=root/'kprog/formal';out=Path('/var/tmp/kprog-tmp/A/forwarding-revert');rows=[]
names=['stack_arm','stack_write_lanes','stack_write_tag_action','stack_read_tag_source','pair_mem','mem_prepost','stack_arena','helper_arg_ptr']
for cc in ['gcc','/usr/lib/llvm-18/bin/clang']:
 label=Path(cc).name
 for name in names:
  stem='test_arm64_'+name+'_route_host';src=formal/'oracles'/(stem+'.c');binary=out/(label+'-'+stem)
  cmd=[cc,'-include','oracles/arm64_entry_environment_host.h','-DKPROG_TEST_EXCLUSIVE_FAILURE=0','-include','oracles/arm64_exclusive_choice_host.h','-Wall','-Wextra','-O2','-fsanitize=undefined','-fno-sanitize-recover=undefined','-I.','-I../arm64','-I../../kprog','-I../../vendor/libbpf/src',str(src),'-o',str(binary)]
  if label=='clang':cmd[1:1]=['-fno-sanitize-link-runtime'];cmd+=['-lubsan']
  build=subprocess.run(cmd,cwd=formal,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (out/(label+'-'+stem+'.compile.log')).write_text(build.stdout)
  row={'compiler':cc,'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'command':cmd,'compile_returncode':build.returncode}
  if build.returncode==0:
   r=subprocess.run([str(binary)],cwd=formal,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);row.update(run_returncode=r.returncode,stdout=r.stdout)
   (out/(label+'-'+stem+'.run.log')).write_text(r.stdout)
  rows.append(row);(out/'checks.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{k:v for k,v in r.items() if k in ['compiler','source','compile_returncode','run_returncode','stdout']} for r in rows],indent=2))
(out/'checks.exit').write_text(str(int(any(r['compile_returncode'] or r.get('run_returncode',1) for r in rows)))+'\n')
