#!/bin/bash
set -e
D=/var/tmp/kprog-tmp/A/entry-frame
R=/workspaces/repository
cp --reflink=auto /var/tmp/kprog-tmp/S17/arm64-build/arch/arm64/boot/Image "$D/Image.before"
make -C /var/tmp/kprog-tmp/CK/linux O=/var/tmp/kprog-tmp/S17/arm64-build ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- CFLAGS_bpf_jit_comp.o="-wrapper /usr/bin/python3,$D/kernel-compiler.py" -j4 Image > "$D/kernel.log" 2>&1
cp --reflink=auto /var/tmp/kprog-tmp/S17/arm64-build/arch/arm64/boot/Image "$D/Image"
make -C "$R/corpus/results/kprog_app_coverage_20261109/entry-frame" linker > "$D/linker.log" 2>&1
echo 0 > "$D/build.exit"
