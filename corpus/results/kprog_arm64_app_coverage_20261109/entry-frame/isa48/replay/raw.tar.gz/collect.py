from pathlib import Path
import json,gzip,collections,tarfile,select,os,subprocess,datetime,traceback
R=Path('/workspaces/repository');P=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261109/entry-frame/isa48';B=O/'replay'
try:
 try:
  fd=os.pidfd_open(231501);select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 B.mkdir(exist_ok=True);p=P/'results/outcomes.json';rows=json.loads(p.read_text()) if p.exists() else []
 original=R/'kprog/stock-path/results/20261109/arm64-outcomes.json.gz';before=json.loads(gzip.decompress(original.read_bytes()));before=before if isinstance(before,list) else before['outcomes'];old={r['name']:r for r in before}
 comparisons=[dict(name=r['name'],negative=r['negative'],native_sha256=r['native_sha256'],old_stage=old.get(r['name'],{}).get('stage'),stage=r['stage'],input_sha256_equal=r['native_sha256']==old.get(r['name'],{}).get('native_sha256')) for r in rows]
 stages=dict(collections.Counter(r['stage'] for r in rows));report=dict(source=json.loads((P/'provenance.json').read_text())['revision'],cases=48,visited=len(rows),stages=stages,suite_exit=(P/'results/suite.exit').read_text().strip() if (P/'results/suite.exit').exists() else 'pending',negative_native_execution_requests=sum(bool(r['unsafe_native_executed']) for r in rows),arm_application_replays=0,original_baseline=str(original.relative_to(R)),comparisons=comparisons)
 (B/'result.json').write_text(json.dumps(report,indent=2)+'\n');(B/'outcomes.json.gz').write_bytes(gzip.compress((json.dumps(rows,indent=2)+'\n').encode(),mtime=0))
 lines=['# Existing ARM ISA48: fixed entry-frame replay','','Visited'+str(len(rows))+'/48original published cases. Actual stages: '+json.dumps(stages,sort_keys=True)+'. Existing suite exit:'+report['suite_exit']+'. Negative native execution requests:'+str(report['negative_native_execution_requests'])+'. ARM application replays:0.','','| Case | Published stage | Fixed-frame stage | Original native bytes |','| --- | --- | --- | --- |']
 for r in comparisons:lines.append('| '+r['name']+' | '+str(r['old_stage'])+' | '+r['stage']+' | '+str(r['input_sha256_equal'])+' |')
 lines+=['','Original negative annotations remain intact and use the original load-only harness path. Four published positives retain their original execution policy. Accepted load-only findings and any setup failure retain the existing suite classification and original diagnostics. Kernel/module/model and native-link build identities are in the parent queued.json; setup-continuation.json records the original producer binary-path alias. Raw records include both startup attempts, all compiler/request outcomes, console and dmesg.','']
 (B/'README.md').write_text('\n'.join(lines))
 with tarfile.open(B/'raw.tar.gz','w:gz') as archive:
  for name in ['results','setup-first','setup-continuation.json','provenance.json','console.log','run.log','broker.log','broker','guest.exit','qemu.exit','replay.exit','command.json','Makefile','run.py','guest.sh','controller.sh','collect.py','linker.log']:
   p=P/name
   if p.exists():archive.add(p,arcname=name)
 parent=O/'README.md';text=parent.read_text();text+='\nThe [collected replay](replay/README.md) records'+str(len(rows))+'/48visited cases and their actual stages, preserving the original native bytes and annotations.\n';parent.write_text(text)
 todo=R/'kprog/docs/todo.md'
 def update(text):
  lines=text.splitlines()
  for i,line in enumerate(lines):
   if line.startswith('- [ ] **A** Existing ARM ISA48 on the fixed entry frame:'):
    lines[i]='- ['+('x' if len(rows)==48 else ' ')+'] **A** Existing ARM ISA48 fixed-frame replay collected: '+str(len(rows))+'/48 cases, '+json.dumps(stages,sort_keys=True)+'; original case bytes/annotations and suite exit '+report['suite_exit']+' retained. Receipt entry-frame/isa48/replay; ARM applications remain deferred.'
  return '\n'.join(lines)+'\n'
 todo.write_text(update(todo.read_text()));paths=[str(p.relative_to(R)) for p in B.iterdir() if p.is_file()]+[str(parent.relative_to(R))];env=dict(os.environ,GIT_INDEX_FILE=str(P/'result.index'));msg=P/'result-message';msg.write_text('Record the existing ARM ISA48 on the fixed entry frame\n')
 for attempt in range(10):
  base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();subprocess.run(['git','read-tree',base],cwd=R,env=env,check=True);subprocess.run(['git','add','-f','--',*paths],cwd=R,env=env,check=True)
  text=subprocess.check_output(['git','show',base+':kprog/docs/todo.md'],cwd=R,text=True);blob=subprocess.check_output(['git','hash-object','-w','--stdin'],cwd=R,input=update(text),text=True).strip();subprocess.run(['git','update-index','--cacheinfo','100644',blob,'kprog/docs/todo.md'],cwd=R,env=env,check=True)
  if subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()!=base:continue
  names=subprocess.check_output(['git','diff','--cached','--name-only',base],cwd=R,env=env,text=True).splitlines()
  if set(names)-set(paths+['kprog/docs/todo.md']):continue
  subprocess.run(['git','diff','--cached','--check',base],cwd=R,env=env,check=True);done=subprocess.run(['git','commit','-F',str(msg)],cwd=R,env=env,text=True,capture_output=True);print(done.stdout,done.stderr,flush=True)
  if done.returncode==0:break
  if subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==base:done.check_returncode()
 else:raise RuntimeError('result publication waits for the next isolated HEAD update')
 commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();subprocess.run(['git','show','--stat','--oneline',commit],cwd=R,check=True);subprocess.run(['git','push','origin','HEAD:master'],cwd=R,check=True);(P/'result-publication.json').write_text(json.dumps(dict(commit=commit,result=report),indent=2)+'\n')
 A=Path('/workspaces/.agent-state/kprog-lanes/A');p=A/'current.json';state=json.loads(p.read_text());now=datetime.datetime.now(datetime.timezone.utc).isoformat();state['updated']=now;state['arm_isa48'].update(status='collected',visited=len(rows),stages=stages,result_commit=commit,suite_exit=report['suite_exit'],controller=231501);state['next']='Read published ARM ISA48 actual stage transitions and findings; retain the shared-revert and ARM-application deferral boundaries.';p.write_text(json.dumps(state,indent=2)+'\n')
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now+': PUSHED '+commit+' existingARMISA48 fixed-frame replay visited'+str(len(rows))+'/48, actual'+json.dumps(stages,sort_keys=True)+', existing suite exit'+report['suite_exit']+'. Original case bytes/annotations and load-only negative policy retained; negative executionrequests'+str(report['negative_native_execution_requests'])+'/ARMapplicationstarts0. Complete before/after stages/inputSHA, bothstartupattempts and raw compiler/service/dmesg archived. Producer hardcodedcargo path restored by binaryhardlink; model165committedsourcefiles/Image/module/ARMstock-entry-frame linker retained. OwnTODO resultline via privateHEADblob; peers preserved.\n')
 print('RESULT',commit,report,flush=True)
except BaseException:
 (P/'collection-error.txt').write_text(traceback.format_exc());raise
