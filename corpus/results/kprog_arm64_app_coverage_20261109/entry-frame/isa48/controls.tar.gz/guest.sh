#!/bin/bash
R=/workspaces/repository
D=/var/tmp/kprog-tmp/A/entry-frame
export KPROG_STOCK_ARCH=2 KPROG_STOCK_ENDPOINT=bpf_arm64_native_lab
export KPROG_STOCK_LOADER=/mnt/arm64-loader-once/build KPROG_STOCK_MODULE=/mnt/module/kprog_stock.ko
export KPROG_STOCK_NATIVE_LINK=/mnt/arm-native-link KPROG_STOCK_BOUND_PROBE=/mnt/arm64-input/bound-probe-current
export KPROG_TRUSTED_COMPILE_STATE=$D/isa48/broker TMPDIR=$D/isa48 PYTHONDONTWRITEBYTECODE=1
OUT=$D/isa48/results
. "$R/kprog/stock-path/guest/common.sh"
python3 "$R/kprog/stock-path/run_safety.py" check --arch arm64 --out "$OUT" --inputs /mnt/arm64-input --cases /mnt/arm64-input/cases.json > "$OUT/suite.log" 2>&1
echo $? > "$OUT/suite.exit"
dmesg > "$OUT/dmesg"
echo 0
