#!/bin/bash
P=/var/tmp/kprog-tmp/A/entry-frame/isa48
export PATH=/usr/local/cargo/bin:$PATH
cd /workspaces/repository
make -f "$P/Makefile" linker > "$P/linker.log" 2>&1
rc=$?; echo "$rc" > "$P/linker.exit"
if test "$rc" = 0; then make -f "$P/Makefile" replay > "$P/run.log" 2>&1; echo $? > "$P/replay.exit"; fi
