from pathlib import Path
import os,json,subprocess,hashlib
R=Path('/workspaces/repository');D=Path('/var/tmp/kprog-tmp/A/entry-frame');P=D/'isa48'
os.unshare(os.CLONE_NEWNS);subprocess.run(['mount','--make-rprivate','/'],check=True)
j=json.loads((P/'provenance.json').read_text())
for rel in j['source_files']:
 subprocess.run(['mount','--bind',str(P/'source'/rel),str(R/rel)],check=True)
root=R/'kprog/arm64/build/app-runtime-v35/root';state=P/'broker';state.mkdir()
broker_log=(P/'broker.log').open('w');broker=subprocess.Popen(['python3',str(R/'kprog/trusted_compile.py'),'serve','--scope',str(D),'--state',str(state),'--clang',str(R/'kprog/stock-path/bin/clang'),'--arm64-sysroot',str(root)],stdout=broker_log,stderr=subprocess.STDOUT)
args=['qemu-system-aarch64','-M','virt','-cpu','max','-smp','2','-m','2048','-nographic','-no-reboot','-kernel',str(D/'Image')]
for tag,path,ro in [('rootfs',root,True),('repo',R,False),('lane',D,False)]:
 args+=['-fsdev',f'local,id={tag},path={path},security_model=none,multidevs=remap'+(',readonly=on' if ro else ''),'-device',f'virtio-9p-pci,fsdev={tag},mount_tag={tag}']
args+=['-append','console=ttyAMA0 root=rootfs rootfstype=9p rootflags=trans=virtio,version=9p2000.L ro init=/bin/sh loglevel=7 panic=-1 oops=panic'];(P/'command.json').write_text(json.dumps(args,indent=2)+'\n')
qemu=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);tail=b'';booted=False
try:
 with (P/'console.log').open('wb') as output:
  while True:
   chunk=os.read(qemu.stdout.fileno(),4096)
   if not chunk:break
   output.write(chunk);output.flush();tail=(tail+chunk)[-8192:]
   if not booted and tail.endswith(b'# '):
    commands=['mount -t proc proc /proc','mount -t sysfs sysfs /sys','mount -t tmpfs tmpfs /tmp','mount -t tmpfs tmpfs /run','mount -t tmpfs tmpfs /var/tmp','mkdir -p '+str(D),'mount -t 9p -o trans=virtio,version=9p2000.L repo '+str(R),'mount -t 9p -o trans=virtio,version=9p2000.L lane /mnt','mount --bind /mnt '+str(D),'mount -t debugfs debugfs /sys/kernel/debug','bash /mnt/isa48/guest.sh']
    qemu.stdin.write((' && '.join(commands)+'; echo $? > /mnt/isa48/guest.exit; echo o > /proc/sysrq-trigger\n').encode());qemu.stdin.flush();booted=True
 (P/'qemu.exit').write_text(str(qemu.wait())+'\n')
finally:
 if qemu.poll() is None:qemu.terminate();qemu.wait()
 (state/'STOP').touch();broker.wait();broker_log.close()
