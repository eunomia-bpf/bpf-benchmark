from pathlib import Path
import json,datetime,tarfile,hashlib,importlib.util
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=Path(__file__).resolve().parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261109/single-load-attempt'
report=json.loads((O/'build.json').read_text())
(O/'README.md').write_text('AArch64 shared first-attempt loader build\n\nThe coordinator08:50 decision supplies the existing16MiB diagnostic buffer on the first BPF_PROG_LOAD and retains that call FD/error. Shared sourcefb23a234d is captured at'+report['source_head']+'. The existing ARM CMake object cache builds native_loader, native_loader_shared, trusted-native-loader and trusted-service-client incrementally. Make exit:'+str(report['make_exit'])+'. Source hashes, exact build logs, recipes and successful runtime outputs accompany this report. The active paired BCC guest retains its captured runtime; the successor loader serves subsequent replay cohorts. Guest verifier/native execution outcomes follow separately. Runtime admission additions:0.\n\nThe terminal collector records and repairs a local variable-name collision after compilation and archive creation; completed build outputs retain their captured hashes.\n')
with tarfile.open(O/'inputs-and-runtime.tar.gz','w:gz') as tf:
 for q in sorted(D.rglob('*')):
  if q.is_file():tf.add(q,arcname=str(q.relative_to(D)))
spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
rec=pub.publish([str((O/n).relative_to(R)) for n in ['build.json','inputs-and-runtime.tar.gz','README.md']],'Build ARM shared first-attempt loader incrementally','arm-single-load-attempt-build')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
(D/'status.json').write_text(json.dumps(report|dict(utc=now,phase='finished',publication=rec),indent=2)+'\n')
with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/S17/V/R '+now+': PUSHED '+rec['commit']+' approved08:50 shared first-attempt ARM loader incremental build exit'+str(report['make_exit'])+' from'+report['source_head']+'. Four targets compiled0 on existing ARM CMake cache. Exact sources/binaries/logs in single-load-attempt; terminal collector variable-name collision repaired after successful compile. Active paired BCC guest1b0 retains captured runtime; subsequent A replays adopt successor. Runtime admission additions0.\n')
print(json.dumps(dict(publication=rec,make_exit=report['make_exit'],runtime_sha256=report.get('runtime_sha256')),indent=2))
