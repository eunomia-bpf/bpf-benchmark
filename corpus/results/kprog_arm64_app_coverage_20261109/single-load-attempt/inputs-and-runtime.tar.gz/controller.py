from pathlib import Path
import subprocess,json,os,datetime,tarfile,hashlib,shutil,importlib.util,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=Path(__file__).resolve().parent
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(D/'status.json').write_text(json.dumps((dict(utc=now(),phase=phase)|kw),indent=2)+'\n')
try:
 save('incremental_ARM_runtime_build')
 with (D/'build.log').open('w') as log:
  p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(D/'inside.py')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 report=dict(utc=now(),make_exit=p.returncode,source_head=(D/'source-head').read_text().strip(),approved_change='fb23a234d88f80a397a893d3d9188d680bdd6d13',source_sha256={str(p.relative_to(D/'source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (D/'source').rglob('*') if p.is_file()},runtime_admission_additions=0)
 if p.returncode==0:
  (D/'runtime').mkdir(exist_ok=True)
  for name in ['libnative_loader.so','libnative_loader.a','trusted-native-loader','trusted-service-client']:
   shutil.copy2(R/'runner/build-arm64-llvmbpf/native_loader'/name,D/'runtime'/name)
  report['runtime_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (D/'runtime').iterdir() if p.is_file()}
 O=R/'corpus/results/kprog_arm64_app_coverage_20261109/single-load-attempt';O.mkdir(exist_ok=True)
 (O/'build.json').write_text(json.dumps(report,indent=2)+'\n')
 with tarfile.open(O/'inputs-and-runtime.tar.gz','w:gz') as tf:
  for p in sorted(D.rglob('*')):
   if p.is_file():tf.add(p,arcname=str(p.relative_to(D)))
 (O/'README.md').write_text('AArch64 shared first-attempt loader build\n\nThe coordinator08:50 decision supplies the existing16MiB diagnostic buffer on the first BPF_PROG_LOAD and retains that call FD/error. Shared sourcefb23a234d is captured at'+report['source_head']+'. The existing ARM CMake object cache builds native_loader, native_loader_shared, trusted-native-loader and trusted-service-client incrementally. Make exit:'+str(report['make_exit'])+'. Source hashes, exact build logs, recipes and successful runtime outputs accompany this report. The active paired BCC guest retains its captured runtime; the successor loader serves subsequent replay cohorts. Guest verifier/native execution outcomes follow separately. Runtime admission additions:0.\n')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['build.json','inputs-and-runtime.tar.gz','README.md']],'Build ARM shared first-attempt loader incrementally','arm-single-load-attempt-build')
 save('finished',publication=rec,**report)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/S17/V/R '+now()+': PUSHED '+rec['commit']+' approved08:50 shared first-attempt ARM loader incremental build exit'+str(report['make_exit'])+' from'+report['source_head']+'. Four loader targets use existing ARM CMake cache; exact sources/binaries/logs in single-load-attempt. Current BCC guest1b0 retains prior captured runtime. Subsequent A replays adopt this successor; runtime admission additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
