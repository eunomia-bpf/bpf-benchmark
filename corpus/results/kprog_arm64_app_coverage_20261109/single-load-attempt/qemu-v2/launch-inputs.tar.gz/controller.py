from pathlib import Path
import os,json,subprocess,shutil,datetime,tarfile,gzip,hashlib,importlib.util,traceback
R=Path('/workspaces/repository');A=Path('/workspaces/.agent-state/kprog-lanes/A');D=Path(__file__).resolve().parent;L=D.parent;F=A/'native-load-recovery/arm64/null-btf';K=Path('/var/tmp/kprog-tmp/A/probe-read/lowering/applications/runtime');O=R/'corpus/results/kprog_arm64_app_coverage_20261109/single-load-attempt/qemu-v2'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(D/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase)|kw,indent=2)+'\n')
try:
 save('capturing_existing_NULL_control')
 O.mkdir(exist_ok=True)
 with tarfile.open(R/'corpus/results/kprog_arm64_app_coverage_20261109/single-load-attempt/qemu/launch-inputs.tar.gz') as tf:
  for m in tf:
   if m.isfile() and m.name.startswith('source/'):
    q=D/m.name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(tf.extractfile(m).read());q.chmod(m.mode)
 epoch='55504ff906ab268a5cab3ab083d6d448d152ed54'
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',epoch,'kprog/arm64','kprog/formal/generated','kprog/helper_abi.py'],cwd=R,text=True).splitlines()
 for rel in paths:
  if rel.endswith(('.h','.py','.c','.hpp')):
   q=D/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(subprocess.check_output(['git','show',epoch+':'+rel],cwd=R))
 for p in (L/'source').rglob('*'):
  if p.is_file():
   q=D/'source'/p.relative_to(L/'source');q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 (D/'fixture').mkdir(exist_ok=True);(D/'fixture-source').mkdir(exist_ok=True)
 for name in ['native.c','probe.cpp']:shutil.copy2(F/'fixture-source'/name,D/'fixture-source'/name)
 shutil.copy2(F/'fixture/native.o',D/'fixture/native.o')
 shutil.copy2(F/'fixture/module/native_load_fault_module.ko',D/'fixture/native_load_fault_module.ko')
 shutil.copytree(K,D/'runtime')
 for name in ['libnative_loader.so','trusted-native-loader','trusted-service-client']:shutil.copy2(L/'runtime'/name,D/'runtime'/name)
 transport=(F/'transport.py').read_text().replace("'12-15'","'16-19'").replace('security_model=none,readonly=on','security_model=none,multidevs=remap,readonly=on').replace("str(ROOT) + ',security_model=none'","str(ROOT) + ',security_model=none,multidevs=remap'")
 (D/'transport.py').write_text(transport)
 mount=(F/'mount.py').read_text()
 marker="stage=R/'kprog/arm64/build/native-load-recovery/recovery'"
 mount=mount.replace(marker,marker+"\nsubprocess.run(['mount','--bind',str(F/'runtime'),str(stage)],check=True)\nfor p in (F/'fixture').iterdir():\n if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/'kprog/arm64/build/native-load-recovery/null-fixture'/p.name)],check=True)")
 i=mount.index("os.execv(");mount=mount[:i]+"os.execvp('make',['make','-f',str(F/'Makefile'),'guest-host'])\n"
 (D/'mount.py').write_text(mount)
 command=['aarch64-linux-gnu-g++','-std=c++20','-O2','-I'+str(R/'runner/build-arm64-llvmbpf/vendor/libbpf/prefix/include'),str(D/'fixture-source/probe.cpp'),str(L/'runtime/libnative_loader.a'),str(R/'runner/build-arm64-llvmbpf/vendor/libbpf/pic-obj/libbpf.a'),'-L'+str(R/'.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu'),'-Wl,-rpath-link,'+str(R/'.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu'),'-lelf','-lz','-ldl','-pthread','-o',str(D/'fixture/probe')]
 import shlex
 (D/'Makefile').write_text('.PHONY: probe guest-host\nprobe:\n\t'+shlex.join(command)+'\nguest-host:\n\tpython3 '+str(R/'kprog/arm64/build/kernel-selftest-runner-current/bpf34-full.py')+' host control '+str(O)+'\n')
 with (D/'probe-build.log').open('w') as log:build=subprocess.run(['make','-f',str(D/'Makefile'),'probe'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 build.check_returncode()
 launch=dict(utc=now(),loader_publication=json.loads((L/'status.json').read_text())['publication']['commit'],model_publication='55504ff906ab268a5cab3ab083d6d448d152ed54',source_sha256={str(p.relative_to(D/'source')):sha(p) for p in (D/'source').rglob('*') if p.is_file()},runtime_sha256={p.name:sha(p) for p in (D/'runtime').iterdir() if p.is_file()},fixture_sha256={p.name:sha(p) for p in (D/'fixture').iterdir() if p.is_file()},probe_command=command,guest=dict(memory_MiB=2048,cpu='16-19'),runtime_admission_additions=0)
 (O/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for p in sorted(D.rglob('*')):
   if p.is_file():tf.add(p,arcname=str(p.relative_to(D)))
 (O/'README.md').write_text('AArch64 first-attempt loader protected-read replay\n\nThe existing native_load_fault_module NULL BTF control runs on the paired f1/e5/3e3f ARM runtime and source555implicit-SP simulator. Its upstream file__nullable hook, original native read and live/null observations remain exact. The same probe source is relinked against the new first-attempt loader static archive; the service and dynamic loader use the matching successor. Original expected low-word results are live0xffffffff and NULL0. Captured source/binary hashes and full input archive accompany the launch. A2GiB guest16-19 shares A CPU allocation with the active paired BCC cohort. Original application work definitions remain frozen. Runtime admission additions:0.\n')
 spec=importlib.util.spec_from_file_location('pub',A/'six-app-publish.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['launch.json','launch-inputs.tar.gz','README.md']],'Replay ARM protected reads with first-attempt loader','arm-single-attempt-null-v2-launch')
 save('actual_NULL_BTF_guest',publication=rec)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/S17/V/R '+now()+': PUSHED '+rec['commit']+' existing live/NULL BTF protected-read control on first-attempt ARM loaderd1b4ac1b7. Original probe source relinked with new static archive; service/dynamic loader match. Exact fixture/native module and f1/e5/3e3f kernel retained; source555snapshot. Guest2GiB16-19 shares own allocation with current fullBCC2GiB; expected liveffffffff/null0. Runtime admission additions0.\n')
 with (D/'guest.log').open('w') as log:guest=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','python3',str(D/'mount.py')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 Q=O/'trusted-arm64-service-result';paths=[];report=dict(utc=now(),make_exit=guest.returncode,probe_build_exit=build.returncode)
 if (Q/'summary.json').exists():
  summary=json.loads((Q/'summary.json').read_text());archive=Q/summary['archive'];paths.extend([Q/'summary.json',archive]);report['runtime']={k:summary.get(k) for k in ['ok','guest_exit','qemu_returncode','compiler_exit']}
  with tarfile.open(archive) as tf:
   if 'run/guest.json' in tf.getnames():report['guest']=json.loads(tf.extractfile('run/guest.json').read())
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json');(O/'driver.log.gz').write_bytes(gzip.compress((D/'guest.log').read_bytes(),mtime=0));paths.append(O/'driver.log.gz')
 rec=pub.publish([str(p.relative_to(R)) for p in paths],'Collect ARM first-attempt protected-read observations','arm-single-attempt-null-v2-terminal')
 save('finished',publication=rec,report=report)
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A FOR C/S17/V/R '+now()+': PUSHED '+rec['commit']+' first-attempt ARM existing NULL BTF control make'+str(guest.returncode)+' '+json.dumps(report.get('runtime',{}))+'. Complete guest/native/B/verifier logs retained; source/probe/runtime exact launch receipt. Runtime admission additions0.\n')
 for name in ['source','runtime','fixture','fixture-source']:shutil.rmtree(D/name)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
