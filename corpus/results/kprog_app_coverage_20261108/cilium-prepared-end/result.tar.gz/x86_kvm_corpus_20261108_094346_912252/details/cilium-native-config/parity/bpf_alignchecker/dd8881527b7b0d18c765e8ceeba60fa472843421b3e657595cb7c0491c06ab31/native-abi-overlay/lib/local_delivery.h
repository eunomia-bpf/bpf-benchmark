/* SPDX-License-Identifier: (GPL-2.0-only OR BSD-2-Clause) */
/* Copyright Authors of Cilium */

#pragma once

#include "common.h"
#include "identity.h"
#include "dbg.h"
#include "eps.h"
#include "l3.h"
#include "token_bucket.h"

DECLARE_CONFIG(bool, enable_netkit, "Use netkit devices for pods")

/* Global map to jump into policy enforcement of sending endpoint */
struct {
	__uint(type, BPF_MAP_TYPE_PROG_ARRAY);
	__type(key, __u32);
	__type(value, __u32);
	__uint(pinning, LIBBPF_PIN_BY_NAME);
	__uint(max_entries, POLICY_PROG_MAP_SIZE);
} cilium_egresscall_policy __section_maps_btf;

static __always_inline __must_check int
tail_call_egress_policy(struct __ctx_buff *ctx, __u16 endpoint_id)
{
	tail_call_dynamic(ctx, &cilium_egresscall_policy, endpoint_id);
	/* same issue as for the cilium_call_policy calls */
	return DROP_EP_NOT_READY;
}

/* Global map to jump into policy enforcement of receiving endpoint */
struct {
	__uint(type, BPF_MAP_TYPE_PROG_ARRAY);
	__type(key, __u32);
	__type(value, __u32);
	__uint(pinning, LIBBPF_PIN_BY_NAME);
	__uint(max_entries, POLICY_PROG_MAP_SIZE);
} cilium_call_policy __section_maps_btf;

static __always_inline __must_check int
tail_call_policy(struct __ctx_buff *ctx, __u16 endpoint_id)
{
	if (__builtin_constant_p(endpoint_id)) {
		tail_call_static(ctx, cilium_call_policy, endpoint_id);
	} else {
		tail_call_dynamic(ctx, &cilium_call_policy, endpoint_id);
	}

	/* When forwarding from a BPF program to some endpoint,
	 * there are inherent races that can result in the endpoint's
	 * policy program being unavailable (eg. if the endpoint is
	 * terminating).
	 */
	return DROP_EP_NOT_READY;
}

static __always_inline bool
should_redirect_peer(bool from_host)
{
	/* We should only do a redirect_peer() if BPF Host Routing is enabled,
	 * otherwise we do a standard redirect().
	 *
	 * Also, if we're from_host, we cannot do an ingress -> ingress switch
	 * via redirect_peer() and instead need an ingress -> egress netns
	 * traversal (or vice versa.)
	 *
	 * Finally, in case of Pod -> Pod:
	 * - on veth, we're on TC ingress and need a redirect_peer() to get
	 *   to the target namespace.
	 * - on netkit, we're on TC egress and need a regular redirect() to
	 *   the peer device's ifindex. Netkit takes care of the namespace
	 *   switch for us.
	 *
	 * Note: both redirect() and redirect_peer() only traverse the CPU
	 * backlog queue once.
	 */
	return is_defined(ENABLE_HOST_ROUTING) &&
	       !from_host &&
	       !CONFIG(enable_netkit);
}

static __always_inline int redirect_ep(struct __ctx_buff *ctx,
				       int ifindex,
				       bool use_redirect_peer,
				       bool from_tunnel)
{
	if (!use_redirect_peer)
		return (int)ctx_redirect(ctx, ifindex, 0);

	/* When coming from overlay, we need to set packet type
	 * to HOST as otherwise we might get dropped in IP layer.
	 */
	if (from_tunnel)
		ctx_change_type(ctx, PACKET_HOST);

	return ctx_redirect_peer(ctx, ifindex, 0);
}

/* Defines the calling convention for bpf_lxc's ingress policy tail-call.
 * Note that skb->tc_index is also passed through.
 *
 * As the callers (from-overlay, from-netdev, ...) are re-generated independently
 * from the policy tail-call of the inidividual endpoints, any change to this code
 * needs to be introduced with compatibility in mind.
 */
static __always_inline void
local_delivery_fill_meta(struct __ctx_buff *ctx, __u32 seclabel,
			 bool delivery_redirect, bool from_host,
			 bool from_tunnel, __u32 cluster_id)
{
	ctx_store_meta(ctx, CB_SRC_LABEL, seclabel);
	ctx_store_meta(ctx, CB_DELIVERY_REDIRECT, delivery_redirect ? 1 : 0);
	ctx_store_meta(ctx, CB_FROM_HOST, from_host ? 1 : 0);
	ctx_store_meta(ctx, CB_FROM_TUNNEL, from_tunnel ? 1 : 0);
	ctx_store_meta(ctx, CB_CLUSTER_ID_INGRESS, cluster_id);
}

static __always_inline int
local_delivery(struct __ctx_buff *ctx, __u32 seclabel, __u32 magic,
	       const struct endpoint_info *ep, __u8 direction, bool from_host,
	       bool from_tunnel, __u32 cluster_id)
{
	bool use_redirect_peer;

#ifdef LOCAL_DELIVERY_METRICS
	/*
	 * Special LXC case for updating egress forwarding metrics.
	 * Note that the packet could still be dropped but it would show up
	 * as an ingress drop counter in metrics.
	 */
	update_metrics(ctx_full_len(ctx), direction, REASON_FORWARDED);
#endif

	if (direction == METRIC_INGRESS && !from_host) {
		/*
		 * Traffic from nodes, local endpoints, or hairpin connections is ignored
		 */
		int ret;

		ret = accept(ctx, ep->lxc_id);
		if (IS_ERR(ret))
			return ret;
	}

	/* When BPF host routing is enabled we need to check policies at source, as in
	 * this case the skb is delivered directly to pod's namespace and the ingress
	 * policy (the cil_to_container BPF program) is bypassed.
	 */
	use_redirect_peer = should_redirect_peer(from_host);
	if (is_defined(USE_BPF_PROG_FOR_INGRESS_POLICY) && !use_redirect_peer &&
	    /* We need to enforce policies at the source in case of netkit
	     * devices because we can't redirect to proxy from bpf_lxc. That
	     * needs a fix upstream.
	     */
	    !CONFIG(enable_netkit)) {
		set_identity_mark(ctx, seclabel, magic);

# if !defined(ENABLE_NODEPORT)
		/* In tunneling mode, we execute this code to send the packet from
		 * cilium_vxlan to lxc*. If we're using kube-proxy, we don't want to use
		 * redirect() because that would bypass conntrack and the reverse DNAT.
		 * Thus, we send packets to the stack, but since they have the wrong
		 * Ethernet addresses, we need to mark them as PACKET_HOST or the kernel
		 * will drop them.
		 */
		if (from_tunnel) {
			ctx_change_type(ctx, PACKET_HOST);
			return CTX_ACT_OK;
		}
# endif /* !ENABLE_NODEPORT */

		return redirect_ep(ctx, ep->ifindex, use_redirect_peer, from_tunnel);
	}

	/* Jumps to destination pod's BPF program to enforce ingress policies. */
	local_delivery_fill_meta(ctx, seclabel, true, from_host, from_tunnel, cluster_id);
	return tail_call_policy(ctx, ep->lxc_id);
}

/* Performs IPv6 L2/L3 handling and delivers the packet to the destination pod
 * on the same node, either via the stack or via a redirect call.
 * Depending on the configuration, it may also enforce ingress policies for the
 * destination pod via a tail call.
 */
static __always_inline int ipv6_local_delivery(struct __ctx_buff *ctx, int l3_off,
					       __u32 seclabel, __u32 magic,
					       const struct endpoint_info *ep,
					       __u8 direction, bool from_host,
					       bool from_tunnel)
{
	mac_t router_mac = ep->node_mac;
	mac_t lxc_mac = ep->mac;
	int ret;

	cilium_dbg(ctx, DBG_LOCAL_DELIVERY, ep->lxc_id, seclabel);

	ret = ipv6_l3(ctx, l3_off, (__u8 *)&router_mac, (__u8 *)&lxc_mac, direction);
	if (ret != CTX_ACT_OK)
		return ret;

	return local_delivery(ctx, seclabel, magic, ep, direction, from_host,
			      from_tunnel, 0);
}

/* Performs IPv4 L2/L3 handling and delivers the packet to the destination pod
 * on the same node, either via the stack or via a redirect call.
 * Depending on the configuration, it may also enforce ingress policies for the
 * destination pod via a tail call.
 */
static __always_inline int ipv4_local_delivery(struct __ctx_buff *ctx, int l3_off,
					       __u32 seclabel, __u32 magic,
					       struct iphdr *ip4,
					       const struct endpoint_info *ep,
					       __u8 direction, bool from_host,
					       bool from_tunnel, __u32 cluster_id)
{
	mac_t router_mac = ep->node_mac;
	mac_t lxc_mac = ep->mac;
	int ret;

	cilium_dbg(ctx, DBG_LOCAL_DELIVERY, ep->lxc_id, seclabel);

	ret = ipv4_l3(ctx, l3_off, (__u8 *)&router_mac, (__u8 *)&lxc_mac, ip4);
	if (ret != CTX_ACT_OK)
		return ret;

	return local_delivery(ctx, seclabel, magic, ep, direction, from_host,
			      from_tunnel, cluster_id);
}

/* Performs IPv6 L2/L3 handling and delivers the packet to the cilium_host@ingress
 * interface on the same node via a redirect call.
 * If needed by the configuration, host policies will be enforced once delivered,
 * specifically in the cil_to_host program (cilium_host@ingress).
 */
static __always_inline int ipv6_host_delivery(struct __ctx_buff *ctx, int l3_off)
{
	union macaddr router_mac = CONFIG(interface_mac);
	union macaddr host_mac = CONFIG(cilium_host_mac);
	int ret;

	ret = ipv6_l3(ctx, l3_off, (__u8 *)&router_mac.addr, (__u8 *)&host_mac.addr, METRIC_INGRESS);
	if (ret != CTX_ACT_OK)
		return ret;

	cilium_dbg_capture(ctx, DBG_CAPTURE_DELIVERY, CONFIG(cilium_host_ifindex));
	return ctx_redirect(ctx, CONFIG(cilium_host_ifindex), BPF_F_INGRESS);
}

/* Performs IPv4 L2/L3 handling and delivers the packet to the cilium_host@ingress
 * interface on the same node via a redirect call.
 * If needed by the configuration, host policies will be enforced once delivered,
 * specifically in the cil_to_host program (cilium_host@ingress).
 */
static __always_inline int ipv4_host_delivery(struct __ctx_buff *ctx, int l3_off, struct iphdr *ip4)
{
	union macaddr router_mac = CONFIG(interface_mac);
	union macaddr host_mac = CONFIG(cilium_host_mac);
	int ret;

	ret = ipv4_l3(ctx, l3_off, (__u8 *)&router_mac.addr, (__u8 *)&host_mac.addr, ip4);
	if (ret != CTX_ACT_OK)
		return ret;

	cilium_dbg_capture(ctx, DBG_CAPTURE_DELIVERY, CONFIG(cilium_host_ifindex));
	return ctx_redirect(ctx, CONFIG(cilium_host_ifindex), BPF_F_INGRESS);
}
