/* SPDX-License-Identifier: (GPL-2.0-only OR BSD-2-Clause) */
/* Copyright Authors of Cilium */

#pragma once

#include <linux/bpf.h>
#include <bpf/section.h>
#include <bpf/loader.h>

#include "eth.h"

struct device_state {
	union macaddr mac;
	__u8 l3:1;
	__u8 pad0:7;
	__u8 pad1;
	__u16 pad2;
	__u32 pad3;
};

/* Could be read-only from datapath, but bpf_xdp_store_bytes (unlike
 * bpf_skb_store_bytes) does not accept MEM_RDONLY pointers, so map values
 * passed to eth_store_saddr_aligned in XDP programs would be rejected by the
 * verifier.
 */
struct {
	__uint(type, BPF_MAP_TYPE_HASH);
	__type(key, __u32);
	__type(value, struct device_state);
	__uint(pinning, LIBBPF_PIN_BY_NAME);
	__uint(max_entries, 512);
	__uint(map_flags, BPF_F_NO_PREALLOC);
} cilium_devices __section_maps_btf;

static __always_inline const struct device_state *
device_state_lookup(__u32 ifindex)
{
	return map_lookup_elem(&cilium_devices, &ifindex);
}

static __always_inline bool
device_is_l3(__u32 ifindex)
{
	const struct device_state *state = device_state_lookup(ifindex);

	return state ? state->l3 : false;
}

static __always_inline const union macaddr *
device_mac(__u32 ifindex)
{
	const struct device_state *state = device_state_lookup(ifindex);
	static union macaddr __zero_mac = {};

	return state ? &state->mac : &__zero_mac;
}
