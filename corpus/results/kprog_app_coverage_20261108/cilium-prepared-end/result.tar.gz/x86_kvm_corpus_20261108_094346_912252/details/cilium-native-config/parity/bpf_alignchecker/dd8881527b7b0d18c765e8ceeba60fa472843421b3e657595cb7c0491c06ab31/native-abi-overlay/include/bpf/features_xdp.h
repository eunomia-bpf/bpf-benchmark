
/* SPDX-License-Identifier: (GPL-2.0-only OR BSD-2-Clause) */
/* Copyright Authors of Cilium */

/* THIS FILE WAS GENERATED DURING AGENT STARTUP. */

#pragma once
#include "features.h"
#define HAVE_XDP_GET_BUFF_LEN 1

#define HAVE_XDP_LOAD_BYTES 1

#define HAVE_XDP_STORE_BYTES 1

