#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <stdexcept>
#include <llvmbpf.hpp>
extern "C" {
int case0_x86_sim_xdp(void*);int case1_x86_sim_xdp(void*);int case2_x86_sim_xdp(void*);
uint32_t native_cpu0(void*);uint32_t native_cpu1(void*);uint32_t native_cpu2(void*);
unsigned long native_lab_entry_input(unsigned){return 0;}
unsigned long native_lab_exclusive_failure_choice(unsigned){throw std::runtime_error("unexpected exclusive");}
void __x86_sim_unresolved_indirect_target(void){throw std::runtime_error("unexpected unresolved control edge");}
}
static uint64_t unresolved(uint64_t,uint64_t,uint64_t,uint64_t,uint64_t){throw std::runtime_error("BPF reached rejected control edge");}
int main(int argc,char**argv){
 if(argc!=2)return 2;
 int(*host[])(void*)={case0_x86_sim_xdp,case1_x86_sim_xdp,case2_x86_sim_xdp};uint32_t(*cpu[])(void*)={native_cpu0,native_cpu1,native_cpu2};
 uint64_t cases=0;for(unsigned i=0;i<3;i++){
  std::string name=std::string(argv[1])+"/case"+std::to_string(i)+".bin";FILE*f=fopen(name.c_str(),"rb");if(!f)return 3;fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);std::vector<uint8_t>code(n);fread(code.data(),1,code.size(),f);fclose(f);
  bpftime::llvmbpf_vm vm;vm.register_external_function(63u,"rejected_target",(void*)unresolved);if(vm.load_code(code.data(),code.size())!=0)return 4;
  uint64_t seed=0xdeadbeef;for(unsigned j=0;j<65536;j++){
   seed=seed*6364136223846793005ULL+1;uint8_t input[64]={};uint32_t value=j<256?j:(uint32_t)(seed>>32);memcpy(input,&value,4);uint8_t original[64];memcpy(original,input,64);
   uint32_t a=cpu[i](input),b=(uint32_t)host[i](input);uint64_t c=0;if(vm.exec(input,64,c)!=0)return 5;
   if(a!=b||a!=(uint32_t)c||memcmp(original,input,64)){fprintf(stderr,"control mismatch case=%u value=%u CPU=%u host=%u BPF=%u\n",i,value,a,b,(uint32_t)c);return 1;}cases++;
  }
 }
 printf("context CFG actual CPU/UBSan-host/BPF-JIT: OK (%llu observations)\n",(unsigned long long)cases);return 0;
}
