#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 424U
#include "/workspaces/.agent-state/kprog-lanes/C/context-render/read.h"
#include "/workspaces/.agent-state/kprog-lanes/C/context-render/candidate.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 CONFIG_ITER_NUM[] __ksym;
extern __u8 ENV_VARS_ENABLED[] __ksym;
extern __u8 buffer_heap_map[] __ksym;
extern __u8 data_heap[] __ksym;
extern __u8 execve_calls[] __ksym;
extern __u8 execve_heap[] __ksym;
extern __u8 execve_map[] __ksym;
extern __u8 execve_msg_heap_map[] __ksym;
extern __u8 tcpmon_map[] __ksym;
extern __u8 tg_cgtracker_map[] __ksym;
extern __u8 tg_conf_map[] __ksym;
extern __u8 tg_errmetrics_map[] __ksym;
extern __u8 tg_execve_joined_info_map[] __ksym;
extern __u8 tg_execve_joined_info_map_stats[] __ksym;
extern __u8 tg_mbset_gen[] __ksym;
extern __u8 tg_mbset_map[] __ksym;
extern __u8 tg_rb_events[] __ksym;
extern __u8 tg_stats_map[] __ksym;
SEC("tracepoint/trusted/trusted")
int context_event_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_c0_l_0:
	/* 0x0: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
	goto x86_c0_l_1;
x86_c0_l_1:
	/* 0x1: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c0_l_3;
x86_c0_l_3:
	/* 0x3: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c0_l_5;
x86_c0_l_5:
	/* 0x5: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
	goto x86_c0_l_7;
x86_c0_l_7:
	/* 0x7: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c0_l_9;
x86_c0_l_9:
	/* 0x9: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c0_l_a;
x86_c0_l_a:
	/* 0xa: sub    rsp,0xc8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 200ULL);
	goto x86_c0_l_11;
x86_c0_l_11:
	/* 0x11: mov    r15,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RDI, X86_WIDTH_64);
	goto x86_c0_l_14;
x86_c0_l_14:
	/* 0x14: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
	goto x86_c0_l_19;
x86_c0_l_19:
	/* 0x19: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1b;
x86_c0_l_1b:
	/* 0x1b: mov    QWORD PTR [rsp+0x88],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
	goto x86_c0_l_23;
x86_c0_l_23:
	/* 0x23: movzx  r12d,WORD PTR [r15+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
	goto x86_c0_l_28;
x86_c0_l_28:
	/* 0x28: mov    DWORD PTR [rsp+0xa0],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 687194767360ULL);
	goto x86_c0_l_33;
x86_c0_l_33:
	/* 0x33: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)execve_msg_heap_map));
	goto x86_c0_l_3a;
x86_c0_l_3a:
	/* 0x3a: lea    rsi,[rsp+0xa0] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
	goto x86_c0_l_42;
x86_c0_l_42:
	/* 0x42: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_47;
x86_c0_l_47:
	/* 0x47: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_49;
x86_c0_l_49:
	/* 0x49: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_4c;
x86_c0_l_4c:
	/* 0x4c: je     1f88 <event_execve+0x1f88> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4c, 0x1f88, x86_c0_l_1f88);
	goto x86_c0_l_52;
x86_c0_l_52:
	/* 0x52: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_55;
x86_c0_l_55:
	/* 0x55: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
	goto x86_c0_l_5a;
x86_c0_l_5a:
	/* 0x5a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_5c;
x86_c0_l_5c:
	/* 0x5c: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_5f;
x86_c0_l_5f:
	/* 0x5f: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
	goto x86_c0_l_64;
x86_c0_l_64:
	/* 0x64: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_66;
x86_c0_l_66:
	/* 0x66: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_69;
x86_c0_l_69:
	/* 0x69: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_6e;
x86_c0_l_6e:
	/* 0x6e: add    rcx,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_75;
x86_c0_l_75:
	/* 0x75: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_7a;
x86_c0_l_7a:
	/* 0x7a: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_7f;
x86_c0_l_7f:
	/* 0x7f: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_84;
x86_c0_l_84:
	/* 0x84: mov    edx,0xb00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2816ULL);
	goto x86_c0_l_89;
x86_c0_l_89:
	/* 0x89: add    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32ULL);
	goto x86_c0_l_8e;
x86_c0_l_8e:
	/* 0x8e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_93;
x86_c0_l_93:
	/* 0x93: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_95;
x86_c0_l_95:
	/* 0x95: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_9a;
x86_c0_l_9a:
	/* 0x9a: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c0_l_9d;
x86_c0_l_9d:
	/* 0x9d: mov    QWORD PTR [rsp+0x80],r15 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
	goto x86_c0_l_a5;
x86_c0_l_a5:
	/* 0xa5: je     375 <event_execve+0x375> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa5, 0x375, x86_c0_l_375);
	goto x86_c0_l_ab;
x86_c0_l_ab:
	/* 0xab: add    rcx,0xaf4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 2804ULL);
	goto x86_c0_l_b2;
x86_c0_l_b2:
	/* 0xb2: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_b7;
x86_c0_l_b7:
	/* 0xb7: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_bc;
x86_c0_l_bc:
	/* 0xbc: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_c1;
x86_c0_l_c1:
	/* 0xc1: mov    edx,0xaf4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2804ULL);
	goto x86_c0_l_c6;
x86_c0_l_c6:
	/* 0xc6: add    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32ULL);
	goto x86_c0_l_cb;
x86_c0_l_cb:
	/* 0xcb: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_d0;
x86_c0_l_d0:
	/* 0xd0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_d2;
x86_c0_l_d2:
	/* 0xd2: mov    eax,DWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_d6;
x86_c0_l_d6:
	/* 0xd6: mov    DWORD PTR [rsp],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_d9;
x86_c0_l_d9:
	/* 0xd9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)execve_map));
	goto x86_c0_l_e0;
x86_c0_l_e0:
	/* 0xe0: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_e3;
x86_c0_l_e3:
	/* 0xe3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_e8;
x86_c0_l_e8:
	/* 0xe8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_ea;
x86_c0_l_ea:
	/* 0xea: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_ed;
x86_c0_l_ed:
	/* 0xed: je     fd <event_execve+0xfd> */
	X86_SIM_X86_JCC(X86_CC_E, 0xed, 0xfd, x86_c0_l_fd);
	goto x86_c0_l_ef;
x86_c0_l_ef:
	/* 0xef: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_f2;
x86_c0_l_f2:
	/* 0xf2: cmp    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
	goto x86_c0_l_f7;
x86_c0_l_f7:
	/* 0xf7: jne    299 <event_execve+0x299> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf7, 0x299, x86_c0_l_299);
	goto x86_c0_l_fd;
x86_c0_l_fd:
	/* 0xfd: mov    edx,0xb00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2816ULL);
	goto x86_c0_l_102;
x86_c0_l_102:
	/* 0x102: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_107;
x86_c0_l_107:
	/* 0x107: add    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_10a;
x86_c0_l_10a:
	/* 0x10a: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_10f;
x86_c0_l_10f:
	/* 0x10f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_114;
x86_c0_l_114:
	/* 0x114: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_119;
x86_c0_l_119:
	/* 0x119: add    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32ULL);
	goto x86_c0_l_11e;
x86_c0_l_11e:
	/* 0x11e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_123;
x86_c0_l_123:
	/* 0x123: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_125;
x86_c0_l_125:
	/* 0x125: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_12a;
x86_c0_l_12a:
	/* 0x12a: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c0_l_12d;
x86_c0_l_12d:
	/* 0x12d: je     375 <event_execve+0x375> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12d, 0x375, x86_c0_l_375);
	goto x86_c0_l_133;
x86_c0_l_133:
	/* 0x133: add    rcx,0xaf4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 2804ULL);
	goto x86_c0_l_13a;
x86_c0_l_13a:
	/* 0x13a: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_13f;
x86_c0_l_13f:
	/* 0x13f: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_144;
x86_c0_l_144:
	/* 0x144: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_149;
x86_c0_l_149:
	/* 0x149: mov    edx,0xaf4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2804ULL);
	goto x86_c0_l_14e;
x86_c0_l_14e:
	/* 0x14e: add    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32ULL);
	goto x86_c0_l_153;
x86_c0_l_153:
	/* 0x153: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_158;
x86_c0_l_158:
	/* 0x158: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_15a;
x86_c0_l_15a:
	/* 0x15a: mov    eax,DWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_15e;
x86_c0_l_15e:
	/* 0x15e: mov    DWORD PTR [rsp],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_161;
x86_c0_l_161:
	/* 0x161: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)execve_map));
	goto x86_c0_l_168;
x86_c0_l_168:
	/* 0x168: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_16b;
x86_c0_l_16b:
	/* 0x16b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_170;
x86_c0_l_170:
	/* 0x170: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_172;
x86_c0_l_172:
	/* 0x172: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_175;
x86_c0_l_175:
	/* 0x175: je     185 <event_execve+0x185> */
	X86_SIM_X86_JCC(X86_CC_E, 0x175, 0x185, x86_c0_l_185);
	goto x86_c0_l_177;
x86_c0_l_177:
	/* 0x177: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_17a;
x86_c0_l_17a:
	/* 0x17a: cmp    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
	goto x86_c0_l_17f;
x86_c0_l_17f:
	/* 0x17f: jne    299 <event_execve+0x299> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17f, 0x299, x86_c0_l_299);
	goto x86_c0_l_185;
x86_c0_l_185:
	/* 0x185: mov    edx,0xb00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2816ULL);
	goto x86_c0_l_18a;
x86_c0_l_18a:
	/* 0x18a: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_18f;
x86_c0_l_18f:
	/* 0x18f: add    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_192;
x86_c0_l_192:
	/* 0x192: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_197;
x86_c0_l_197:
	/* 0x197: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_19c;
x86_c0_l_19c:
	/* 0x19c: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_1a1;
x86_c0_l_1a1:
	/* 0x1a1: add    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32ULL);
	goto x86_c0_l_1a6;
x86_c0_l_1a6:
	/* 0x1a6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1ab;
x86_c0_l_1ab:
	/* 0x1ab: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1ad;
x86_c0_l_1ad:
	/* 0x1ad: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1b2;
x86_c0_l_1b2:
	/* 0x1b2: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c0_l_1b5;
x86_c0_l_1b5:
	/* 0x1b5: je     375 <event_execve+0x375> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b5, 0x375, x86_c0_l_375);
	goto x86_c0_l_1bb;
x86_c0_l_1bb:
	/* 0x1bb: add    rcx,0xaf4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 2804ULL);
	goto x86_c0_l_1c2;
x86_c0_l_1c2:
	/* 0x1c2: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_1c7;
x86_c0_l_1c7:
	/* 0x1c7: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1cc;
x86_c0_l_1cc:
	/* 0x1cc: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_1d1;
x86_c0_l_1d1:
	/* 0x1d1: mov    edx,0xaf4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2804ULL);
	goto x86_c0_l_1d6;
x86_c0_l_1d6:
	/* 0x1d6: add    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32ULL);
	goto x86_c0_l_1db;
x86_c0_l_1db:
	/* 0x1db: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1e0;
x86_c0_l_1e0:
	/* 0x1e0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1e2;
x86_c0_l_1e2:
	/* 0x1e2: mov    eax,DWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_1e6;
x86_c0_l_1e6:
	/* 0x1e6: mov    DWORD PTR [rsp],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1e9;
x86_c0_l_1e9:
	/* 0x1e9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)execve_map));
	goto x86_c0_l_1f0;
x86_c0_l_1f0:
	/* 0x1f0: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_1f3;
x86_c0_l_1f3:
	/* 0x1f3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_1f8;
x86_c0_l_1f8:
	/* 0x1f8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1fa;
x86_c0_l_1fa:
	/* 0x1fa: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_1fd;
x86_c0_l_1fd:
	/* 0x1fd: je     20d <event_execve+0x20d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fd, 0x20d, x86_c0_l_20d);
	goto x86_c0_l_1ff;
x86_c0_l_1ff:
	/* 0x1ff: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_202;
x86_c0_l_202:
	/* 0x202: cmp    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
	goto x86_c0_l_207;
x86_c0_l_207:
	/* 0x207: jne    299 <event_execve+0x299> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x207, 0x299, x86_c0_l_299);
	goto x86_c0_l_20d;
x86_c0_l_20d:
	/* 0x20d: mov    edx,0xb00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2816ULL);
	goto x86_c0_l_212;
x86_c0_l_212:
	/* 0x212: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_217;
x86_c0_l_217:
	/* 0x217: add    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_21a;
x86_c0_l_21a:
	/* 0x21a: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_21f;
x86_c0_l_21f:
	/* 0x21f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_224;
x86_c0_l_224:
	/* 0x224: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_229;
x86_c0_l_229:
	/* 0x229: add    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32ULL);
	goto x86_c0_l_22e;
x86_c0_l_22e:
	/* 0x22e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_233;
x86_c0_l_233:
	/* 0x233: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_235;
x86_c0_l_235:
	/* 0x235: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_23a;
x86_c0_l_23a:
	/* 0x23a: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c0_l_23d;
x86_c0_l_23d:
	/* 0x23d: je     375 <event_execve+0x375> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23d, 0x375, x86_c0_l_375);
	goto x86_c0_l_243;
x86_c0_l_243:
	/* 0x243: add    rcx,0xaf4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 2804ULL);
	goto x86_c0_l_24a;
x86_c0_l_24a:
	/* 0x24a: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_24f;
x86_c0_l_24f:
	/* 0x24f: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_254;
x86_c0_l_254:
	/* 0x254: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_259;
x86_c0_l_259:
	/* 0x259: mov    edx,0xaf4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 2804ULL);
	goto x86_c0_l_25e;
x86_c0_l_25e:
	/* 0x25e: add    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32ULL);
	goto x86_c0_l_263;
x86_c0_l_263:
	/* 0x263: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_268;
x86_c0_l_268:
	/* 0x268: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_26a;
x86_c0_l_26a:
	/* 0x26a: mov    eax,DWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_26e;
x86_c0_l_26e:
	/* 0x26e: mov    DWORD PTR [rsp],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_271;
x86_c0_l_271:
	/* 0x271: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)execve_map));
	goto x86_c0_l_278;
x86_c0_l_278:
	/* 0x278: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_27b;
x86_c0_l_27b:
	/* 0x27b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_280;
x86_c0_l_280:
	/* 0x280: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_282;
x86_c0_l_282:
	/* 0x282: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_285;
x86_c0_l_285:
	/* 0x285: je     375 <event_execve+0x375> */
	X86_SIM_X86_JCC(X86_CC_E, 0x285, 0x375, x86_c0_l_375);
	goto x86_c0_l_28b;
x86_c0_l_28b:
	/* 0x28b: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_28e;
x86_c0_l_28e:
	/* 0x28e: cmp    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
	goto x86_c0_l_293;
x86_c0_l_293:
	/* 0x293: je     375 <event_execve+0x375> */
	X86_SIM_X86_JCC(X86_CC_E, 0x293, 0x375, x86_c0_l_375);
	goto x86_c0_l_299;
x86_c0_l_299:
	/* 0x299: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_29d;
x86_c0_l_29d:
	/* 0x29d: mov    rcx,QWORD PTR [rbp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
	goto x86_c0_l_2a1;
x86_c0_l_2a1:
	/* 0x2a1: mov    QWORD PTR [r14+0xa8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
	goto x86_c0_l_2a8;
x86_c0_l_2a8:
	/* 0x2a8: mov    QWORD PTR [r14+0xa0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
	goto x86_c0_l_2af;
x86_c0_l_2af:
	/* 0x2af: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_2b6;
x86_c0_l_2b6:
	/* 0x2b6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_mbset_gen));
	goto x86_c0_l_2bd;
x86_c0_l_2bd:
	/* 0x2bd: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_2c0;
x86_c0_l_2c0:
	/* 0x2c0: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_2c5;
x86_c0_l_2c5:
	/* 0x2c5: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_2c7;
x86_c0_l_2c7:
	/* 0x2c7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_2ca;
x86_c0_l_2ca:
	/* 0x2ca: je     46f <event_execve+0x46f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ca, 0x46f, x86_c0_l_46f);
	goto x86_c0_l_2d0;
x86_c0_l_2d0:
	/* 0x2d0: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_2d3;
x86_c0_l_2d3:
	/* 0x2d3: cmp    rcx,QWORD PTR [rbp+0x378] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 888ULL);
	goto x86_c0_l_2da;
x86_c0_l_2da:
	/* 0x2da: je     46f <event_execve+0x46f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2da, 0x46f, x86_c0_l_46f);
	goto x86_c0_l_2e0;
x86_c0_l_2e0:
	/* 0x2e0: mov    QWORD PTR [rsp+0x78],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
	goto x86_c0_l_2e5;
x86_c0_l_2e5:
	/* 0x2e5: mov    QWORD PTR [rsp+0x90],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
	goto x86_c0_l_2ed;
x86_c0_l_2ed:
	/* 0x2ed: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
	goto x86_c0_l_2f2;
x86_c0_l_2f2:
	/* 0x2f2: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)CONFIG_ITER_NUM));
	goto x86_c0_l_2f9;
x86_c0_l_2f9:
	/* 0x2f9: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_2fc;
x86_c0_l_2fc:
	/* 0x2fc: je     3e5 <event_execve+0x3e5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fc, 0x3e5, x86_c0_l_3e5);
	goto x86_c0_l_302;
x86_c0_l_302:
	/* 0x302: mov    ebx,0x1869f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 99999ULL);
	goto x86_c0_l_307;
x86_c0_l_307:
	/* 0x307: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_30a;
x86_c0_l_30a:
	/* 0x30a: mov    r13,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_R13, 0, ((__u64)(long)tg_mbset_map));
	goto x86_c0_l_311;
x86_c0_l_311:
	/* 0x311: mov    eax,DWORD PTR [rbp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_314;
x86_c0_l_314:
	/* 0x314: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_318;
x86_c0_l_318:
	/* 0x318: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_31d;
x86_c0_l_31d:
	/* 0x31d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)execve_map));
	goto x86_c0_l_324;
x86_c0_l_324:
	/* 0x324: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_329;
x86_c0_l_329:
	/* 0x329: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_32b;
x86_c0_l_32b:
	/* 0x32b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_32e;
x86_c0_l_32e:
	/* 0x32e: je     44b <event_execve+0x44b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32e, 0x44b, x86_c0_l_44b);
	goto x86_c0_l_334;
x86_c0_l_334:
	/* 0x334: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_337;
x86_c0_l_337:
	/* 0x337: lea    rsi,[rax+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
	goto x86_c0_l_33b;
x86_c0_l_33b:
	/* 0x33b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_340;
x86_c0_l_340:
	/* 0x340: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_343;
x86_c0_l_343:
	/* 0x343: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_345;
x86_c0_l_345:
	/* 0x345: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_348;
x86_c0_l_348:
	/* 0x348: je     35a <event_execve+0x35a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x348, 0x35a, x86_c0_l_35a);
	goto x86_c0_l_34a;
x86_c0_l_34a:
	/* 0x34a: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_34d;
x86_c0_l_34d:
	/* 0x34d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_350;
x86_c0_l_350:
	/* 0x350: je     35a <event_execve+0x35a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x350, 0x35a, x86_c0_l_35a);
	goto x86_c0_l_352;
x86_c0_l_352:
	/* 0x352: or QWORD PTR [rbp+0x370],rax */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_RBP, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 880ULL);
	goto x86_c0_l_35a;
x86_c0_l_35a:
	/* 0x35a: sub    ebx,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_32, X86_ALU_SUB, 1ULL);
	goto x86_c0_l_35d;
x86_c0_l_35d:
	/* 0x35d: setb   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_B);
	goto x86_c0_l_360;
x86_c0_l_360:
	/* 0x360: cmp    r12,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R12, X86_R15, X86_WIDTH_64);
	goto x86_c0_l_363;
x86_c0_l_363:
	/* 0x363: je     44b <event_execve+0x44b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x363, 0x44b, x86_c0_l_44b);
	goto x86_c0_l_369;
x86_c0_l_369:
	/* 0x369: mov    r15,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R12, X86_WIDTH_64);
	goto x86_c0_l_36c;
x86_c0_l_36c:
	/* 0x36c: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
	goto x86_c0_l_36e;
x86_c0_l_36e:
	/* 0x36e: je     311 <event_execve+0x311> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36e, 0x311, x86_c0_l_311);
	goto x86_c0_l_370;
x86_c0_l_370:
	/* 0x370: jmp    44b <event_execve+0x44b> */
	X86_SIM_X86_JMP(0x370, 0x44b, x86_c0_l_44b);
x86_c0_l_375:
	/* 0x375: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
	goto x86_c0_l_37d;
x86_c0_l_37d:
	/* 0x37d: lea    rdx,[rax+0xb00] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2816ULL);
	goto x86_c0_l_384;
x86_c0_l_384:
	/* 0x384: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_389;
x86_c0_l_389:
	/* 0x389: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_38e;
x86_c0_l_38e:
	/* 0x38e: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_393;
x86_c0_l_393:
	/* 0x393: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_398;
x86_c0_l_398:
	/* 0x398: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_39a;
x86_c0_l_39a:
	/* 0x39a: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_39f;
x86_c0_l_39f:
	/* 0x39f: test   rdx,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64);
	goto x86_c0_l_3a2;
x86_c0_l_3a2:
	/* 0x3a2: je     3c7 <event_execve+0x3c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3a2, 0x3c7, x86_c0_l_3c7);
	goto x86_c0_l_3a4;
x86_c0_l_3a4:
	/* 0x3a4: add    rdx,0xaf4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 2804ULL);
	goto x86_c0_l_3ab;
x86_c0_l_3ab:
	/* 0x3ab: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_3b0;
x86_c0_l_3b0:
	/* 0x3b0: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_3b5;
x86_c0_l_3b5:
	/* 0x3b5: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_3ba;
x86_c0_l_3ba:
	/* 0x3ba: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_3bf;
x86_c0_l_3bf:
	/* 0x3bf: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_3c1;
x86_c0_l_3c1:
	/* 0x3c1: mov    eax,DWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_3c5;
x86_c0_l_3c5:
	/* 0x3c5: jmp    3c9 <event_execve+0x3c9> */
	X86_SIM_X86_JMP(0x3c5, 0x3c9, x86_c0_l_3c9);
x86_c0_l_3c7:
	/* 0x3c7: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_3c9;
x86_c0_l_3c9:
	/* 0x3c9: mov    DWORD PTR [r14+0xa0],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
	goto x86_c0_l_3d0;
x86_c0_l_3d0:
	/* 0x3d0: mov    QWORD PTR [r14+0xa8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 721554505728ULL);
	goto x86_c0_l_3db;
x86_c0_l_3db:
	/* 0x3db: mov    eax,0x40 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 64ULL);
	goto x86_c0_l_3e0;
x86_c0_l_3e0:
	/* 0x3e0: jmp    471 <event_execve+0x471> */
	X86_SIM_X86_JMP(0x3e0, 0x471, x86_c0_l_471);
x86_c0_l_3e5:
	/* 0x3e5: mov    ebx,0x3ff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 1023ULL);
	goto x86_c0_l_3ea;
x86_c0_l_3ea:
	/* 0x3ea: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_3ed;
x86_c0_l_3ed:
	/* 0x3ed: mov    r13,QWORD PTR [rip+0xf] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_R13, 0, ((__u64)(long)tg_mbset_map));
	goto x86_c0_l_3f4;
x86_c0_l_3f4:
	/* 0x3f4: mov    eax,DWORD PTR [rbp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_3f7;
x86_c0_l_3f7:
	/* 0x3f7: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_3fb;
x86_c0_l_3fb:
	/* 0x3fb: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_400;
x86_c0_l_400:
	/* 0x400: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)execve_map));
	goto x86_c0_l_407;
x86_c0_l_407:
	/* 0x407: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_40c;
x86_c0_l_40c:
	/* 0x40c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_40e;
x86_c0_l_40e:
	/* 0x40e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_411;
x86_c0_l_411:
	/* 0x411: je     44b <event_execve+0x44b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x411, 0x44b, x86_c0_l_44b);
	goto x86_c0_l_413;
x86_c0_l_413:
	/* 0x413: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_416;
x86_c0_l_416:
	/* 0x416: lea    rsi,[rax+0x70] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
	goto x86_c0_l_41a;
x86_c0_l_41a:
	/* 0x41a: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_41f;
x86_c0_l_41f:
	/* 0x41f: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_422;
x86_c0_l_422:
	/* 0x422: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_424;
x86_c0_l_424:
	/* 0x424: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_427;
x86_c0_l_427:
	/* 0x427: je     439 <event_execve+0x439> */
	X86_SIM_X86_JCC(X86_CC_E, 0x427, 0x439, x86_c0_l_439);
	goto x86_c0_l_429;
x86_c0_l_429:
	/* 0x429: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_42c;
x86_c0_l_42c:
	/* 0x42c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_42f;
x86_c0_l_42f:
	/* 0x42f: je     439 <event_execve+0x439> */
	X86_SIM_X86_JCC(X86_CC_E, 0x42f, 0x439, x86_c0_l_439);
	goto x86_c0_l_431;
x86_c0_l_431:
	/* 0x431: or QWORD PTR [rbp+0x370],rax */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_RBP, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 880ULL);
	goto x86_c0_l_439;
x86_c0_l_439:
	/* 0x439: sub    ebx,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_32, X86_ALU_SUB, 1ULL);
	goto x86_c0_l_43c;
x86_c0_l_43c:
	/* 0x43c: setb   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_B);
	goto x86_c0_l_43f;
x86_c0_l_43f:
	/* 0x43f: cmp    r12,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R12, X86_R15, X86_WIDTH_64);
	goto x86_c0_l_442;
x86_c0_l_442:
	/* 0x442: je     44b <event_execve+0x44b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x442, 0x44b, x86_c0_l_44b);
	goto x86_c0_l_444;
x86_c0_l_444:
	/* 0x444: mov    r15,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_R12, X86_WIDTH_64);
	goto x86_c0_l_447;
x86_c0_l_447:
	/* 0x447: test   al,al */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8);
	goto x86_c0_l_449;
x86_c0_l_449:
	/* 0x449: je     3f4 <event_execve+0x3f4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x449, 0x3f4, x86_c0_l_3f4);
	goto x86_c0_l_44b;
x86_c0_l_44b:
	/* 0x44b: mov    rax,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
	goto x86_c0_l_450;
x86_c0_l_450:
	/* 0x450: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_453;
x86_c0_l_453:
	/* 0x453: mov    QWORD PTR [rbp+0x378],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 888ULL);
	goto x86_c0_l_45a;
x86_c0_l_45a:
	/* 0x45a: mov    r15,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
	goto x86_c0_l_462;
x86_c0_l_462:
	/* 0x462: mov    r12,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
	goto x86_c0_l_46a;
x86_c0_l_46a:
	/* 0x46a: mov    r13,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
	goto x86_c0_l_46f;
x86_c0_l_46f:
	/* 0x46f: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_471;
x86_c0_l_471:
	/* 0x471: mov    QWORD PTR [r14+0xb0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
	goto x86_c0_l_478;
x86_c0_l_478:
	/* 0x478: mov    DWORD PTR [r14+0x15c],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1494648619009ULL);
	goto x86_c0_l_483;
x86_c0_l_483:
	/* 0x483: mov    rax,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_486;
x86_c0_l_486:
	/* 0x486: shr    rax,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
	goto x86_c0_l_48a;
x86_c0_l_48a:
	/* 0x48a: mov    QWORD PTR [r14+0x178],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1614907703296ULL);
	goto x86_c0_l_495;
x86_c0_l_495:
	/* 0x495: mov    DWORD PTR [r14+0x144],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 324ULL);
	goto x86_c0_l_49c;
x86_c0_l_49c:
	/* 0x49c: mov    DWORD PTR [r14+0x148],r13d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 328ULL);
	goto x86_c0_l_4a3;
x86_c0_l_4a3:
	/* 0x4a3: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
	goto x86_c0_l_4a8;
x86_c0_l_4a8:
	/* 0x4a8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_4aa;
x86_c0_l_4aa:
	/* 0x4aa: lea    rdx,[rax+0x60] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
	goto x86_c0_l_4ae;
x86_c0_l_4ae:
	/* 0x4ae: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_4b1;
x86_c0_l_4b1:
	/* 0x4b1: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_4b6;
x86_c0_l_4b6:
	/* 0x4b6: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_4bb;
x86_c0_l_4bb:
	/* 0x4bb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_4c0;
x86_c0_l_4c0:
	/* 0x4c0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_4c2;
x86_c0_l_4c2:
	/* 0x4c2: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_4c6;
x86_c0_l_4c6:
	/* 0x4c6: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_4c8;
x86_c0_l_4c8:
	/* 0x4c8: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c0_l_4cb;
x86_c0_l_4cb:
	/* 0x4cb: je     537 <event_execve+0x537> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4cb, 0x537, x86_c0_l_537);
	goto x86_c0_l_4cd;
x86_c0_l_4cd:
	/* 0x4cd: add    rcx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
	goto x86_c0_l_4d1;
x86_c0_l_4d1:
	/* 0x4d1: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_4d6;
x86_c0_l_4d6:
	/* 0x4d6: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_4db;
x86_c0_l_4db:
	/* 0x4db: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_4e0;
x86_c0_l_4e0:
	/* 0x4e0: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_4e4;
x86_c0_l_4e4:
	/* 0x4e4: add    rdx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
	goto x86_c0_l_4e8;
x86_c0_l_4e8:
	/* 0x4e8: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_4ed;
x86_c0_l_4ed:
	/* 0x4ed: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_4ef;
x86_c0_l_4ef:
	/* 0x4ef: mov    eax,DWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_4f3;
x86_c0_l_4f3:
	/* 0x4f3: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c0_l_4f5;
x86_c0_l_4f5:
	/* 0x4f5: je     537 <event_execve+0x537> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4f5, 0x537, x86_c0_l_537);
	goto x86_c0_l_4f7;
x86_c0_l_4f7:
	/* 0x4f7: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_4fb;
x86_c0_l_4fb:
	/* 0x4fb: shl    eax,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
	goto x86_c0_l_4fe;
x86_c0_l_4fe:
	/* 0x4fe: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_501;
x86_c0_l_501:
	/* 0x501: add    rcx,0x80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 128ULL);
	goto x86_c0_l_508;
x86_c0_l_508:
	/* 0x508: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_50d;
x86_c0_l_50d:
	/* 0x50d: mov    edx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 16ULL);
	goto x86_c0_l_512;
x86_c0_l_512:
	/* 0x512: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_517;
x86_c0_l_517:
	/* 0x517: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_51b;
x86_c0_l_51b:
	/* 0x51b: mov    edx,DWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_51f;
x86_c0_l_51f:
	/* 0x51f: shl    edx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
	goto x86_c0_l_522;
x86_c0_l_522:
	/* 0x522: add    rdx,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_525;
x86_c0_l_525:
	/* 0x525: add    rdx,0x80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 128ULL);
	goto x86_c0_l_52c;
x86_c0_l_52c:
	/* 0x52c: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
	goto x86_c0_l_531;
x86_c0_l_531:
	/* 0x531: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_533;
x86_c0_l_533:
	/* 0x533: mov    ebx,DWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_537;
x86_c0_l_537:
	/* 0x537: mov    DWORD PTR [r14+0x14c],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 332ULL);
	goto x86_c0_l_53e;
x86_c0_l_53e:
	/* 0x53e: mov    eax,0x7d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 125ULL);
	goto x86_c0_l_543;
x86_c0_l_543:
	/* 0x543: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x7dULL: X86_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x7dULL: X86_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_545;
x86_c0_l_545:
	/* 0x545: mov    QWORD PTR [r14+0x170],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 368ULL);
	goto x86_c0_l_54c;
x86_c0_l_54c:
	/* 0x54c: mov    DWORD PTR [r14+0x140],0x40 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1374389534784ULL);
	goto x86_c0_l_557;
x86_c0_l_557:
	/* 0x557: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
	goto x86_c0_l_55c;
x86_c0_l_55c:
	/* 0x55c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_55e;
x86_c0_l_55e:
	/* 0x55e: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
	goto x86_c0_l_567;
x86_c0_l_567:
	/* 0x567: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_56a;
x86_c0_l_56a:
	/* 0x56a: je     590 <event_execve+0x590> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56a, 0x590, x86_c0_l_590);
	goto x86_c0_l_56c;
x86_c0_l_56c:
	/* 0x56c: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_56f;
x86_c0_l_56f:
	/* 0x56f: add    rdx,0x70 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 112ULL);
	goto x86_c0_l_573;
x86_c0_l_573:
	/* 0x573: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_578;
x86_c0_l_578:
	/* 0x578: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_57d;
x86_c0_l_57d:
	/* 0x57d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_582;
x86_c0_l_582:
	/* 0x582: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_587;
x86_c0_l_587:
	/* 0x587: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_589;
x86_c0_l_589:
	/* 0x589: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_58e;
x86_c0_l_58e:
	/* 0x58e: jmp    592 <event_execve+0x592> */
	X86_SIM_X86_JMP(0x58e, 0x592, x86_c0_l_592);
x86_c0_l_590:
	/* 0x590: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_592;
x86_c0_l_592:
	/* 0x592: mov    DWORD PTR [r14+0x158],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 344ULL);
	goto x86_c0_l_599;
x86_c0_l_599:
	/* 0x599: mov    QWORD PTR [rsp+0x20],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_59e;
x86_c0_l_59e:
	/* 0x59e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_execve_joined_info_map));
	goto x86_c0_l_5a5;
x86_c0_l_5a5:
	/* 0x5a5: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_5aa;
x86_c0_l_5aa:
	/* 0x5aa: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_5af;
x86_c0_l_5af:
	/* 0x5af: add    r12,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_5b2;
x86_c0_l_5b2:
	/* 0x5b2: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_5b4;
x86_c0_l_5b4:
	/* 0x5b4: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_5b7;
x86_c0_l_5b7:
	/* 0x5b7: je     615 <event_execve+0x615> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5b7, 0x615, x86_c0_l_615);
	goto x86_c0_l_5b9;
x86_c0_l_5b9:
	/* 0x5b9: mov    ecx,DWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_5bb;
x86_c0_l_5bb:
	/* 0x5bb: mov    DWORD PTR [r14+0x150],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 336ULL);
	goto x86_c0_l_5c2;
x86_c0_l_5c2:
	/* 0x5c2: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
	goto x86_c0_l_5c6;
x86_c0_l_5c6:
	/* 0x5c6: mov    QWORD PTR [r14+0x168],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 360ULL);
	goto x86_c0_l_5cd;
x86_c0_l_5cd:
	/* 0x5cd: mov    eax,DWORD PTR [rax+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c0_l_5d0;
x86_c0_l_5d0:
	/* 0x5d0: mov    DWORD PTR [r14+0x160],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 352ULL);
	goto x86_c0_l_5d7;
x86_c0_l_5d7:
	/* 0x5d7: mov    QWORD PTR [rsp+0x20],r13 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_5dc;
x86_c0_l_5dc:
	/* 0x5dc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_execve_joined_info_map));
	goto x86_c0_l_5e3;
x86_c0_l_5e3:
	/* 0x5e3: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_5e8;
x86_c0_l_5e8:
	/* 0x5e8: mov    eax,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 3ULL);
	goto x86_c0_l_5ed;
x86_c0_l_5ed:
	/* 0x5ed: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x3ULL: X86_SIM_BPF_CALL_bpf_map_delete_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x3ULL: X86_SIM_BPF_CALL_bpf_map_delete_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_5ef;
x86_c0_l_5ef:
	/* 0x5ef: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c0_l_5f1;
x86_c0_l_5f1:
	/* 0x5f1: je     638 <event_execve+0x638> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5f1, 0x638, x86_c0_l_638);
	goto x86_c0_l_5f3;
x86_c0_l_5f3:
	/* 0x5f3: mov    DWORD PTR [rsp],0x2 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
	goto x86_c0_l_5fa;
x86_c0_l_5fa:
	/* 0x5fa: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_execve_joined_info_map_stats));
	goto x86_c0_l_601;
x86_c0_l_601:
	/* 0x601: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_604;
x86_c0_l_604:
	/* 0x604: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_609;
x86_c0_l_609:
	/* 0x609: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_60b;
x86_c0_l_60b:
	/* 0x60b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_60e;
x86_c0_l_60e:
	/* 0x60e: je     658 <event_execve+0x658> */
	X86_SIM_X86_JCC(X86_CC_E, 0x60e, 0x658, x86_c0_l_658);
	goto x86_c0_l_610;
x86_c0_l_610:
	/* 0x610: inc    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
	goto x86_c0_l_613;
x86_c0_l_613:
	/* 0x613: jmp    658 <event_execve+0x658> */
	X86_SIM_X86_JMP(0x613, 0x658, x86_c0_l_658);
x86_c0_l_615:
	/* 0x615: mov    DWORD PTR [r14+0x150],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1443109011456ULL);
	goto x86_c0_l_620;
x86_c0_l_620:
	/* 0x620: mov    QWORD PTR [r14+0x168],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1546188226560ULL);
	goto x86_c0_l_62b;
x86_c0_l_62b:
	/* 0x62b: mov    DWORD PTR [r14+0x160],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1511828488192ULL);
	goto x86_c0_l_636;
x86_c0_l_636:
	/* 0x636: jmp    658 <event_execve+0x658> */
	X86_SIM_X86_JMP(0x636, 0x658, x86_c0_l_658);
x86_c0_l_638:
	/* 0x638: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_63f;
x86_c0_l_63f:
	/* 0x63f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_execve_joined_info_map_stats));
	goto x86_c0_l_646;
x86_c0_l_646:
	/* 0x646: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_649;
x86_c0_l_649:
	/* 0x649: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_64e;
x86_c0_l_64e:
	/* 0x64e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_650;
x86_c0_l_650:
	/* 0x650: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_653;
x86_c0_l_653:
	/* 0x653: je     658 <event_execve+0x658> */
	X86_SIM_X86_JCC(X86_CC_E, 0x653, 0x658, x86_c0_l_658);
	goto x86_c0_l_655;
x86_c0_l_655:
	/* 0x655: dec    QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_DEC)), 0ULL);
	goto x86_c0_l_658;
x86_c0_l_658:
	/* 0x658: lea    rbx,[r14+0x180] */
	X86_SIM_L_EXEC_LEA(X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 384ULL);
	goto x86_c0_l_65f;
x86_c0_l_65f:
	/* 0x65f: mov    ecx,0xff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 255ULL);
	goto x86_c0_l_664;
x86_c0_l_664:
	/* 0x664: mov    eax,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 45ULL);
	goto x86_c0_l_669;
x86_c0_l_669:
	/* 0x669: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
	goto x86_c0_l_66c;
x86_c0_l_66c:
	/* 0x66c: mov    esi,0xff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 255ULL);
	goto x86_c0_l_671;
x86_c0_l_671:
	/* 0x671: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
	goto x86_c0_l_674;
x86_c0_l_674:
	/* 0x674: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_676;
x86_c0_l_676:
	/* 0x676: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c0_l_678;
x86_c0_l_678:
	/* 0x678: js     6a5 <event_execve+0x6a5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x678, 0x6a5, x86_c0_l_6a5);
	goto x86_c0_l_67a;
x86_c0_l_67a:
	/* 0x67a: je     6ae <event_execve+0x6ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x67a, 0x6ae, x86_c0_l_6ae);
	goto x86_c0_l_67c;
x86_c0_l_67c:
	/* 0x67c: cmp    eax,0xff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 255ULL);
	goto x86_c0_l_681;
x86_c0_l_681:
	/* 0x681: jne    6b2 <event_execve+0x6b2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x681, 0x6b2, x86_c0_l_6b2);
	goto x86_c0_l_683;
x86_c0_l_683:
	/* 0x683: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
	goto x86_c0_l_686;
x86_c0_l_686:
	/* 0x686: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
	goto x86_c0_l_689;
x86_c0_l_689:
	/* 0x689: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
	goto x86_c0_l_68c;
x86_c0_l_68c:
	/* 0x68c: call   0 <event_execve> */
	X86_SIM_X86_CALL(x86_c1_l_1fa0, 0x691ULL);
x86_c0_l_691:
	/* 0x691: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_694;
x86_c0_l_694:
	/* 0x694: test   ecx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32);
	goto x86_c0_l_696;
x86_c0_l_696:
	/* 0x696: mov    edx,0x100 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 256ULL);
	goto x86_c0_l_69b;
x86_c0_l_69b:
	/* 0x69b: mov    eax,0x800000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8388608ULL);
	goto x86_c0_l_6a0;
x86_c0_l_6a0:
	/* 0x6a0: cmove  eax,edx */
	X86_SIM_L_EXEC_CMOV(X86_RAX, X86_RDX, X86_WIDTH_32, X86_CC_E);
	goto x86_c0_l_6a3;
x86_c0_l_6a3:
	/* 0x6a3: jmp    6b8 <event_execve+0x6b8> */
	X86_SIM_X86_JMP(0x6a3, 0x6b8, x86_c0_l_6b8);
x86_c0_l_6a5:
	/* 0x6a5: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_6a7;
x86_c0_l_6a7:
	/* 0x6a7: mov    eax,0x100 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 256ULL);
	goto x86_c0_l_6ac;
x86_c0_l_6ac:
	/* 0x6ac: jmp    6b8 <event_execve+0x6b8> */
	X86_SIM_X86_JMP(0x6ac, 0x6b8, x86_c0_l_6b8);
x86_c0_l_6ae:
	/* 0x6ae: mov    ecx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_32);
	goto x86_c0_l_6b0;
x86_c0_l_6b0:
	/* 0x6b0: jmp    6b8 <event_execve+0x6b8> */
	X86_SIM_X86_JMP(0x6b0, 0x6b8, x86_c0_l_6b8);
x86_c0_l_6b2:
	/* 0x6b2: mov    ecx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_32);
	goto x86_c0_l_6b4;
x86_c0_l_6b4:
	/* 0x6b4: dec    ecx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_DEC, 1);
	goto x86_c0_l_6b6;
x86_c0_l_6b6:
	/* 0x6b6: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_6b8;
x86_c0_l_6b8:
	/* 0x6b8: mov    WORD PTR [r14+0x178],cx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 376ULL);
	goto x86_c0_l_6c0;
x86_c0_l_6c0:
	/* 0x6c0: or     DWORD PTR [r14+0x15c],eax */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_R14, X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 348ULL);
	goto x86_c0_l_6c7;
x86_c0_l_6c7:
	/* 0x6c7: add    DWORD PTR [r14+0x140],ecx */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_R14, X86_RCX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 320ULL);
	goto x86_c0_l_6ce;
x86_c0_l_6ce:
	/* 0x6ce: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
	goto x86_c0_l_6d3;
x86_c0_l_6d3:
	/* 0x6d3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_6d5;
x86_c0_l_6d5:
	/* 0x6d5: mov    DWORD PTR [rsp+0x98],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 652835028992ULL);
	goto x86_c0_l_6e0;
x86_c0_l_6e0:
	/* 0x6e0: lea    rdx,[rax+0xa78] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2680ULL);
	goto x86_c0_l_6e7;
x86_c0_l_6e7:
	/* 0x6e7: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_6ec;
x86_c0_l_6ec:
	/* 0x6ec: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_6f1;
x86_c0_l_6f1:
	/* 0x6f1: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_6f6;
x86_c0_l_6f6:
	/* 0x6f6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_6fb;
x86_c0_l_6fb:
	/* 0x6fb: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_6fd;
x86_c0_l_6fd:
	/* 0x6fd: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_700;
x86_c0_l_700:
	/* 0x700: je     75c <event_execve+0x75c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x700, 0x75c, x86_c0_l_75c);
	goto x86_c0_l_702;
x86_c0_l_702:
	/* 0x702: neg    eax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_NEG, 0);
	goto x86_c0_l_704;
x86_c0_l_704:
	/* 0x704: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_709;
x86_c0_l_709:
	/* 0x709: mov    WORD PTR [rsp+0x22],0x9 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 146028888073ULL);
	goto x86_c0_l_710;
x86_c0_l_710:
	/* 0x710: movabs rax,0x400000042 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 17179869250ULL);
	goto x86_c0_l_71a;
x86_c0_l_71a:
	/* 0x71a: mov    QWORD PTR [rsp+0x24],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
	goto x86_c0_l_71f;
x86_c0_l_71f:
	/* 0x71f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
	goto x86_c0_l_726;
x86_c0_l_726:
	/* 0x726: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_72b;
x86_c0_l_72b:
	/* 0x72b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_730;
x86_c0_l_730:
	/* 0x730: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_732;
x86_c0_l_732:
	/* 0x732: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_735;
x86_c0_l_735:
	/* 0x735: je     73b <event_execve+0x73b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x735, 0x73b, x86_c0_l_73b);
	goto x86_c0_l_737;
x86_c0_l_737:
	/* 0x737: inc    DWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
	goto x86_c0_l_739;
x86_c0_l_739:
	/* 0x739: jmp    75c <event_execve+0x75c> */
	X86_SIM_X86_JMP(0x739, 0x75c, x86_c0_l_75c);
x86_c0_l_73b:
	/* 0x73b: mov    DWORD PTR [rsp],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
	goto x86_c0_l_742;
x86_c0_l_742:
	/* 0x742: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
	goto x86_c0_l_749;
x86_c0_l_749:
	/* 0x749: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_74b;
x86_c0_l_74b:
	/* 0x74b: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_750;
x86_c0_l_750:
	/* 0x750: mov    rdx,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_753;
x86_c0_l_753:
	/* 0x753: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
	goto x86_c0_l_758;
x86_c0_l_758:
	/* 0x758: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_75a;
x86_c0_l_75a:
	/* 0x75a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_75c;
x86_c0_l_75c:
	/* 0x75c: lea    r12,[r14+0x140] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
	goto x86_c0_l_763;
x86_c0_l_763:
	/* 0x763: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_768;
x86_c0_l_768:
	/* 0x768: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_76a;
x86_c0_l_76a:
	/* 0x76a: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
	goto x86_c0_l_76f;
x86_c0_l_76f:
	/* 0x76f: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c0_l_772;
x86_c0_l_772:
	/* 0x772: je     a31 <event_execve+0xa31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x772, 0xa31, x86_c0_l_a31);
	goto x86_c0_l_778;
x86_c0_l_778:
	/* 0x778: add    rcx,0x2b8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 696ULL);
	goto x86_c0_l_77f;
x86_c0_l_77f:
	/* 0x77f: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_782;
x86_c0_l_782:
	/* 0x782: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_787;
x86_c0_l_787:
	/* 0x787: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_78c;
x86_c0_l_78c:
	/* 0x78c: mov    edx,0x2b8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 696ULL);
	goto x86_c0_l_791;
x86_c0_l_791:
	/* 0x791: add    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 24ULL);
	goto x86_c0_l_796;
x86_c0_l_796:
	/* 0x796: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_79b;
x86_c0_l_79b:
	/* 0x79b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_79d;
x86_c0_l_79d:
	/* 0x79d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_7a0;
x86_c0_l_7a0:
	/* 0x7a0: je     7ff <event_execve+0x7ff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7a0, 0x7ff, x86_c0_l_7ff);
	goto x86_c0_l_7a2;
x86_c0_l_7a2:
	/* 0x7a2: neg    eax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_NEG, 0);
	goto x86_c0_l_7a4;
x86_c0_l_7a4:
	/* 0x7a4: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_7a9;
x86_c0_l_7a9:
	/* 0x7a9: mov    WORD PTR [rsp+0x22],0x9 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 146028888073ULL);
	goto x86_c0_l_7b0;
x86_c0_l_7b0:
	/* 0x7b0: movabs rax,0x400000047 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 17179869255ULL);
	goto x86_c0_l_7ba;
x86_c0_l_7ba:
	/* 0x7ba: mov    QWORD PTR [rsp+0x24],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
	goto x86_c0_l_7bf;
x86_c0_l_7bf:
	/* 0x7bf: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
	goto x86_c0_l_7c6;
x86_c0_l_7c6:
	/* 0x7c6: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_7cb;
x86_c0_l_7cb:
	/* 0x7cb: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_7d0;
x86_c0_l_7d0:
	/* 0x7d0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_7d2;
x86_c0_l_7d2:
	/* 0x7d2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_7d5;
x86_c0_l_7d5:
	/* 0x7d5: je     7db <event_execve+0x7db> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7d5, 0x7db, x86_c0_l_7db);
	goto x86_c0_l_7d7;
x86_c0_l_7d7:
	/* 0x7d7: inc    DWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
	goto x86_c0_l_7d9;
x86_c0_l_7d9:
	/* 0x7d9: jmp    7ff <event_execve+0x7ff> */
	X86_SIM_X86_JMP(0x7d9, 0x7ff, x86_c0_l_7ff);
x86_c0_l_7db:
	/* 0x7db: mov    DWORD PTR [rsp+0x10],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476737ULL);
	goto x86_c0_l_7e3;
x86_c0_l_7e3:
	/* 0x7e3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
	goto x86_c0_l_7ea;
x86_c0_l_7ea:
	/* 0x7ea: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_7ec;
x86_c0_l_7ec:
	/* 0x7ec: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_7f1;
x86_c0_l_7f1:
	/* 0x7f1: lea    rdx,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_7f6;
x86_c0_l_7f6:
	/* 0x7f6: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
	goto x86_c0_l_7fb;
x86_c0_l_7fb:
	/* 0x7fb: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_7fd;
x86_c0_l_7fd:
	/* 0x7fd: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_7ff;
x86_c0_l_7ff:
	/* 0x7ff: mov    edx,0x2c0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 704ULL);
	goto x86_c0_l_804;
x86_c0_l_804:
	/* 0x804: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_809;
x86_c0_l_809:
	/* 0x809: add    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_80c;
x86_c0_l_80c:
	/* 0x80c: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_811;
x86_c0_l_811:
	/* 0x811: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_816;
x86_c0_l_816:
	/* 0x816: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_81b;
x86_c0_l_81b:
	/* 0x81b: add    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 24ULL);
	goto x86_c0_l_820;
x86_c0_l_820:
	/* 0x820: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_825;
x86_c0_l_825:
	/* 0x825: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_827;
x86_c0_l_827:
	/* 0x827: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_82a;
x86_c0_l_82a:
	/* 0x82a: je     867 <event_execve+0x867> */
	X86_SIM_X86_JCC(X86_CC_E, 0x82a, 0x867, x86_c0_l_867);
	goto x86_c0_l_82c;
x86_c0_l_82c:
	/* 0x82c: neg    eax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_NEG, 0);
	goto x86_c0_l_82e;
x86_c0_l_82e:
	/* 0x82e: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_833;
x86_c0_l_833:
	/* 0x833: mov    WORD PTR [rsp+0x22],0x9 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 146028888073ULL);
	goto x86_c0_l_83a;
x86_c0_l_83a:
	/* 0x83a: movabs rax,0x400000048 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 17179869256ULL);
	goto x86_c0_l_844;
x86_c0_l_844:
	/* 0x844: mov    QWORD PTR [rsp+0x24],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
	goto x86_c0_l_849;
x86_c0_l_849:
	/* 0x849: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
	goto x86_c0_l_850;
x86_c0_l_850:
	/* 0x850: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_855;
x86_c0_l_855:
	/* 0x855: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_85a;
x86_c0_l_85a:
	/* 0x85a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_85c;
x86_c0_l_85c:
	/* 0x85c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_85f;
x86_c0_l_85f:
	/* 0x85f: je     993 <event_execve+0x993> */
	X86_SIM_X86_JCC(X86_CC_E, 0x85f, 0x993, x86_c0_l_993);
	goto x86_c0_l_865;
x86_c0_l_865:
	/* 0x865: inc    DWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
	goto x86_c0_l_867;
x86_c0_l_867:
	/* 0x867: cmp    QWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_86c;
x86_c0_l_86c:
	/* 0x86c: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
	goto x86_c0_l_871;
x86_c0_l_871:
	/* 0x871: je     a31 <event_execve+0xa31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x871, 0xa31, x86_c0_l_a31);
	goto x86_c0_l_877;
x86_c0_l_877:
	/* 0x877: cmp    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
	goto x86_c0_l_87d;
x86_c0_l_87d:
	/* 0x87d: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
	goto x86_c0_l_882;
x86_c0_l_882:
	/* 0x882: je     a31 <event_execve+0xa31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x882, 0xa31, x86_c0_l_a31);
	goto x86_c0_l_888;
x86_c0_l_888:
	/* 0x888: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)execve_heap));
	goto x86_c0_l_88f;
x86_c0_l_88f:
	/* 0x88f: lea    rsi,[rsp+0x98] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
	goto x86_c0_l_897;
x86_c0_l_897:
	/* 0x897: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_89c;
x86_c0_l_89c:
	/* 0x89c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_89e;
x86_c0_l_89e:
	/* 0x89e: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
	goto x86_c0_l_8a3;
x86_c0_l_8a3:
	/* 0x8a3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_8a6;
x86_c0_l_8a6:
	/* 0x8a6: je     a31 <event_execve+0xa31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8a6, 0xa31, x86_c0_l_a31);
	goto x86_c0_l_8ac;
x86_c0_l_8ac:
	/* 0x8ac: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_8af;
x86_c0_l_8af:
	/* 0x8af: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_8b3;
x86_c0_l_8b3:
	/* 0x8b3: mov    edx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4096ULL);
	goto x86_c0_l_8b8;
x86_c0_l_8b8:
	/* 0x8b8: mov    eax,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 45ULL);
	goto x86_c0_l_8bd;
x86_c0_l_8bd:
	/* 0x8bd: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_8c1;
x86_c0_l_8c1:
	/* 0x8c1: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
	goto x86_c0_l_8c6;
x86_c0_l_8c6:
	/* 0x8c6: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_8c8;
x86_c0_l_8c8:
	/* 0x8c8: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
	goto x86_c0_l_8cd;
x86_c0_l_8cd:
	/* 0x8cd: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_8d0;
x86_c0_l_8d0:
	/* 0x8d0: js     a31 <event_execve+0xa31> */
	X86_SIM_X86_JCC(X86_CC_S, 0x8d0, 0xa31, x86_c0_l_a31);
	goto x86_c0_l_8d6;
x86_c0_l_8d6:
	/* 0x8d6: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_8d9;
x86_c0_l_8d9:
	/* 0x8d9: add    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
	goto x86_c0_l_8dd;
x86_c0_l_8dd:
	/* 0x8dd: mov    QWORD PTR [rsp],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_8e1;
x86_c0_l_8e1:
	/* 0x8e1: mov    eax,DWORD PTR [r14+0x140] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
	goto x86_c0_l_8e8;
x86_c0_l_8e8:
	/* 0x8e8: and    eax,0x1ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 511ULL);
	goto x86_c0_l_8ed;
x86_c0_l_8ed:
	/* 0x8ed: lea    r8,[r14+rax*1] */
	X86_SIM_L_EXEC_LEA(X86_R8, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
	goto x86_c0_l_8f1;
x86_c0_l_8f1:
	/* 0x8f1: add    r8,0x140 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 320ULL);
	goto x86_c0_l_8f8;
x86_c0_l_8f8:
	/* 0x8f8: mov    DWORD PTR [r14+0x184c],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 6220ULL);
	goto x86_c0_l_8ff;
x86_c0_l_8ff:
	/* 0x8ff: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_904;
x86_c0_l_904:
	/* 0x904: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_907;
x86_c0_l_907:
	/* 0x907: sub    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c0_l_90a;
x86_c0_l_90a:
	/* 0x90a: cmp    rcx,0x3ff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 1023ULL);
	goto x86_c0_l_911;
x86_c0_l_911:
	/* 0x911: ja     9c9 <event_execve+0x9c9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x911, 0x9c9, x86_c0_l_9c9);
	goto x86_c0_l_917;
x86_c0_l_917:
	/* 0x917: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c0_l_91a;
x86_c0_l_91a:
	/* 0x91a: sub    rdi,r8 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R8, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c0_l_91d;
x86_c0_l_91d:
	/* 0x91d: add    rdi,0x400 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 1024ULL);
	goto x86_c0_l_924;
x86_c0_l_924:
	/* 0x924: cmp    rcx,rdi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RDI, X86_WIDTH_64);
	goto x86_c0_l_927;
x86_c0_l_927:
	/* 0x927: jae    9c9 <event_execve+0x9c9> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x927, 0x9c9, x86_c0_l_9c9);
	goto x86_c0_l_92d;
x86_c0_l_92d:
	/* 0x92d: dec    ecx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_DEC, 1);
	goto x86_c0_l_92f;
x86_c0_l_92f:
	/* 0x92f: and    ecx,0x3ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
	goto x86_c0_l_935;
x86_c0_l_935:
	/* 0x935: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_937;
x86_c0_l_937:
	/* 0x937: cmp    rax,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64);
	goto x86_c0_l_93a;
x86_c0_l_93a:
	/* 0x93a: cmovne esi,ecx */
	X86_SIM_L_EXEC_CMOV(X86_RSI, X86_RCX, X86_WIDTH_32, X86_CC_NE);
	goto x86_c0_l_93d;
x86_c0_l_93d:
	/* 0x93d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_942;
x86_c0_l_942:
	/* 0x942: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_946;
x86_c0_l_946:
	/* 0x946: mov    rdi,r8 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R8, X86_WIDTH_64);
	goto x86_c0_l_949;
x86_c0_l_949:
	/* 0x949: mov    r15,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RSI, X86_WIDTH_64);
	goto x86_c0_l_94c;
x86_c0_l_94c:
	/* 0x94c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_94e;
x86_c0_l_94e:
	/* 0x94e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_951;
x86_c0_l_951:
	/* 0x951: je     9e4 <event_execve+0x9e4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x951, 0x9e4, x86_c0_l_9e4);
	goto x86_c0_l_957;
x86_c0_l_957:
	/* 0x957: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_95a;
x86_c0_l_95a:
	/* 0x95a: neg    eax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_NEG, 0);
	goto x86_c0_l_95c;
x86_c0_l_95c:
	/* 0x95c: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_961;
x86_c0_l_961:
	/* 0x961: mov    WORD PTR [rsp+0x22],0x9 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 146028888073ULL);
	goto x86_c0_l_968;
x86_c0_l_968:
	/* 0x968: movabs rax,0x40000006c */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 17179869292ULL);
	goto x86_c0_l_972;
x86_c0_l_972:
	/* 0x972: mov    QWORD PTR [rsp+0x24],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
	goto x86_c0_l_977;
x86_c0_l_977:
	/* 0x977: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
	goto x86_c0_l_97e;
x86_c0_l_97e:
	/* 0x97e: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_983;
x86_c0_l_983:
	/* 0x983: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_988;
x86_c0_l_988:
	/* 0x988: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_98a;
x86_c0_l_98a:
	/* 0x98a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_98d;
x86_c0_l_98d:
	/* 0x98d: je     9e9 <event_execve+0x9e9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x98d, 0x9e9, x86_c0_l_9e9);
	goto x86_c0_l_98f;
x86_c0_l_98f:
	/* 0x98f: inc    DWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
	goto x86_c0_l_991;
x86_c0_l_991:
	/* 0x991: jmp    a0d <event_execve+0xa0d> */
	X86_SIM_X86_JMP(0x991, 0xa0d, x86_c0_l_a0d);
x86_c0_l_993:
	/* 0x993: mov    DWORD PTR [rsp+0x68],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598785ULL);
	goto x86_c0_l_99b;
x86_c0_l_99b:
	/* 0x99b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
	goto x86_c0_l_9a2;
x86_c0_l_9a2:
	/* 0x9a2: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_9a4;
x86_c0_l_9a4:
	/* 0x9a4: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_9a9;
x86_c0_l_9a9:
	/* 0x9a9: lea    rdx,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
	goto x86_c0_l_9ae;
x86_c0_l_9ae:
	/* 0x9ae: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
	goto x86_c0_l_9b3;
x86_c0_l_9b3:
	/* 0x9b3: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_9b5;
x86_c0_l_9b5:
	/* 0x9b5: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_9b7;
x86_c0_l_9b7:
	/* 0x9b7: cmp    QWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_9bc;
x86_c0_l_9bc:
	/* 0x9bc: mov    ebx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 0ULL);
	goto x86_c0_l_9c1;
x86_c0_l_9c1:
	/* 0x9c1: jne    877 <event_execve+0x877> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x9c1, 0x877, x86_c0_l_877);
	goto x86_c0_l_9c7;
x86_c0_l_9c7:
	/* 0x9c7: jmp    a31 <event_execve+0xa31> */
	X86_SIM_X86_JMP(0x9c7, 0xa31, x86_c0_l_a31);
x86_c0_l_9c9:
	/* 0x9c9: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
	goto x86_c0_l_9cc;
x86_c0_l_9cc:
	/* 0x9cc: mov    rsi,r8 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R8, X86_WIDTH_64);
	goto x86_c0_l_9cf;
x86_c0_l_9cf:
	/* 0x9cf: call   0 <event_execve> */
	X86_SIM_X86_CALL(x86_c5_l_205c, 0x9d4ULL);
x86_c0_l_9d4:
	/* 0x9d4: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_9d7;
x86_c0_l_9d7:
	/* 0x9d7: mov    eax,0x1000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16777216ULL);
	goto x86_c0_l_9dc;
x86_c0_l_9dc:
	/* 0x9dc: test   ebx,ebx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32);
	goto x86_c0_l_9de;
x86_c0_l_9de:
	/* 0x9de: jne    a1b <event_execve+0xa1b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x9de, 0xa1b, x86_c0_l_a1b);
	goto x86_c0_l_9e0;
x86_c0_l_9e0:
	/* 0x9e0: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_9e2;
x86_c0_l_9e2:
	/* 0x9e2: jmp    a22 <event_execve+0xa22> */
	X86_SIM_X86_JMP(0x9e2, 0xa22, x86_c0_l_a22);
x86_c0_l_9e4:
	/* 0x9e4: mov    rbx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_R15, X86_WIDTH_64);
	goto x86_c0_l_9e7;
x86_c0_l_9e7:
	/* 0x9e7: jmp    a22 <event_execve+0xa22> */
	X86_SIM_X86_JMP(0x9e7, 0xa22, x86_c0_l_a22);
x86_c0_l_9e9:
	/* 0x9e9: mov    DWORD PTR [rsp+0x68],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598785ULL);
	goto x86_c0_l_9f1;
x86_c0_l_9f1:
	/* 0x9f1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
	goto x86_c0_l_9f8;
x86_c0_l_9f8:
	/* 0x9f8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_9fa;
x86_c0_l_9fa:
	/* 0x9fa: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_9ff;
x86_c0_l_9ff:
	/* 0x9ff: lea    rdx,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
	goto x86_c0_l_a04;
x86_c0_l_a04:
	/* 0xa04: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
	goto x86_c0_l_a09;
x86_c0_l_a09:
	/* 0xa09: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_a0b;
x86_c0_l_a0b:
	/* 0xa0b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_a0d;
x86_c0_l_a0d:
	/* 0xa0d: test   ebx,ebx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32);
	goto x86_c0_l_a0f;
x86_c0_l_a0f:
	/* 0xa0f: mov    rbx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_R15, X86_WIDTH_64);
	goto x86_c0_l_a12;
x86_c0_l_a12:
	/* 0xa12: jns    a22 <event_execve+0xa22> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa12, 0xa22, x86_c0_l_a22);
	goto x86_c0_l_a14;
x86_c0_l_a14:
	/* 0xa14: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_a16;
x86_c0_l_a16:
	/* 0xa16: mov    eax,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 512ULL);
	goto x86_c0_l_a1b;
x86_c0_l_a1b:
	/* 0xa1b: or     DWORD PTR [r14+0x15c],eax */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_R14, X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 348ULL);
	goto x86_c0_l_a22;
x86_c0_l_a22:
	/* 0xa22: mov    DWORD PTR [r14+0x1848],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 6216ULL);
	goto x86_c0_l_a29;
x86_c0_l_a29:
	/* 0xa29: mov    WORD PTR [r14+0x17a],bx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 378ULL);
	goto x86_c0_l_a31;
x86_c0_l_a31:
	/* 0xa31: add    ebx,DWORD PTR [r14+0x140] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RBX, X86_R14, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 320ULL);
	goto x86_c0_l_a38;
x86_c0_l_a38:
	/* 0xa38: mov    DWORD PTR [r14+0x140],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
	goto x86_c0_l_a3f;
x86_c0_l_a3f:
	/* 0xa3f: test   BYTE PTR [r14+0x15d],0x20 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 1498943586336ULL);
	goto x86_c0_l_a47;
x86_c0_l_a47:
	/* 0xa47: jne    158b <event_execve+0x158b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa47, 0x158b, x86_c0_l_158b);
	goto x86_c0_l_a4d;
x86_c0_l_a4d:
	/* 0xa4d: mov    QWORD PTR [rsp+0x90],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
	goto x86_c0_l_a55;
x86_c0_l_a55:
	/* 0xa55: mov    ebx,DWORD PTR [r14+0x144] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 324ULL);
	goto x86_c0_l_a5c;
x86_c0_l_a5c:
	/* 0xa5c: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
	goto x86_c0_l_a61;
x86_c0_l_a61:
	/* 0xa61: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_a63;
x86_c0_l_a63:
	/* 0xa63: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_a6a;
x86_c0_l_a6a:
	/* 0xa6a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_a6d;
x86_c0_l_a6d:
	/* 0xa6d: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa6d, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_a73;
x86_c0_l_a73:
	/* 0xa73: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_a76;
x86_c0_l_a76:
	/* 0xa76: lea    rdx,[rax+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_a7d;
x86_c0_l_a7d:
	/* 0xa7d: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_a80;
x86_c0_l_a80:
	/* 0xa80: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_a85;
x86_c0_l_a85:
	/* 0xa85: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_a8a;
x86_c0_l_a8a:
	/* 0xa8a: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_a8f;
x86_c0_l_a8f:
	/* 0xa8f: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_a91;
x86_c0_l_a91:
	/* 0xa91: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_a94;
x86_c0_l_a94:
	/* 0xa94: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa94, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_a9a;
x86_c0_l_a9a:
	/* 0xa9a: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_aa1;
x86_c0_l_aa1:
	/* 0xaa1: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_aa6;
x86_c0_l_aa6:
	/* 0xaa6: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_aab;
x86_c0_l_aab:
	/* 0xaab: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_ab0;
x86_c0_l_ab0:
	/* 0xab0: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_ab5;
x86_c0_l_ab5:
	/* 0xab5: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_ab8;
x86_c0_l_ab8:
	/* 0xab8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_aba;
x86_c0_l_aba:
	/* 0xaba: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_abf;
x86_c0_l_abf:
	/* 0xabf: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_ac2;
x86_c0_l_ac2:
	/* 0xac2: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xac2, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_ac8;
x86_c0_l_ac8:
	/* 0xac8: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_acf;
x86_c0_l_acf:
	/* 0xacf: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_ad2;
x86_c0_l_ad2:
	/* 0xad2: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_ad7;
x86_c0_l_ad7:
	/* 0xad7: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_adc;
x86_c0_l_adc:
	/* 0xadc: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_ae1;
x86_c0_l_ae1:
	/* 0xae1: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_ae3;
x86_c0_l_ae3:
	/* 0xae3: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_ae6;
x86_c0_l_ae6:
	/* 0xae6: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xae6, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_aec;
x86_c0_l_aec:
	/* 0xaec: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_af3;
x86_c0_l_af3:
	/* 0xaf3: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_af8;
x86_c0_l_af8:
	/* 0xaf8: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_afd;
x86_c0_l_afd:
	/* 0xafd: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_b02;
x86_c0_l_b02:
	/* 0xb02: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_b07;
x86_c0_l_b07:
	/* 0xb07: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_b0a;
x86_c0_l_b0a:
	/* 0xb0a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_b0c;
x86_c0_l_b0c:
	/* 0xb0c: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_b11;
x86_c0_l_b11:
	/* 0xb11: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_b14;
x86_c0_l_b14:
	/* 0xb14: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb14, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_b1a;
x86_c0_l_b1a:
	/* 0xb1a: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_b21;
x86_c0_l_b21:
	/* 0xb21: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_b24;
x86_c0_l_b24:
	/* 0xb24: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_b29;
x86_c0_l_b29:
	/* 0xb29: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_b2e;
x86_c0_l_b2e:
	/* 0xb2e: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_b33;
x86_c0_l_b33:
	/* 0xb33: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_b35;
x86_c0_l_b35:
	/* 0xb35: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_b38;
x86_c0_l_b38:
	/* 0xb38: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb38, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_b3e;
x86_c0_l_b3e:
	/* 0xb3e: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_b45;
x86_c0_l_b45:
	/* 0xb45: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_b4a;
x86_c0_l_b4a:
	/* 0xb4a: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_b4f;
x86_c0_l_b4f:
	/* 0xb4f: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_b54;
x86_c0_l_b54:
	/* 0xb54: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_b59;
x86_c0_l_b59:
	/* 0xb59: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_b5c;
x86_c0_l_b5c:
	/* 0xb5c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_b5e;
x86_c0_l_b5e:
	/* 0xb5e: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_b63;
x86_c0_l_b63:
	/* 0xb63: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_b66;
x86_c0_l_b66:
	/* 0xb66: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb66, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_b6c;
x86_c0_l_b6c:
	/* 0xb6c: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_b73;
x86_c0_l_b73:
	/* 0xb73: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_b76;
x86_c0_l_b76:
	/* 0xb76: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_b7b;
x86_c0_l_b7b:
	/* 0xb7b: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_b80;
x86_c0_l_b80:
	/* 0xb80: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_b85;
x86_c0_l_b85:
	/* 0xb85: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_b87;
x86_c0_l_b87:
	/* 0xb87: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_b8a;
x86_c0_l_b8a:
	/* 0xb8a: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb8a, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_b90;
x86_c0_l_b90:
	/* 0xb90: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_b97;
x86_c0_l_b97:
	/* 0xb97: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_b9c;
x86_c0_l_b9c:
	/* 0xb9c: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_ba1;
x86_c0_l_ba1:
	/* 0xba1: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_ba6;
x86_c0_l_ba6:
	/* 0xba6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_bab;
x86_c0_l_bab:
	/* 0xbab: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_bae;
x86_c0_l_bae:
	/* 0xbae: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_bb0;
x86_c0_l_bb0:
	/* 0xbb0: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_bb5;
x86_c0_l_bb5:
	/* 0xbb5: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_bb8;
x86_c0_l_bb8:
	/* 0xbb8: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbb8, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_bbe;
x86_c0_l_bbe:
	/* 0xbbe: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_bc5;
x86_c0_l_bc5:
	/* 0xbc5: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_bc8;
x86_c0_l_bc8:
	/* 0xbc8: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_bcd;
x86_c0_l_bcd:
	/* 0xbcd: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_bd2;
x86_c0_l_bd2:
	/* 0xbd2: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_bd7;
x86_c0_l_bd7:
	/* 0xbd7: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_bd9;
x86_c0_l_bd9:
	/* 0xbd9: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_bdc;
x86_c0_l_bdc:
	/* 0xbdc: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbdc, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_be2;
x86_c0_l_be2:
	/* 0xbe2: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_be9;
x86_c0_l_be9:
	/* 0xbe9: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_bee;
x86_c0_l_bee:
	/* 0xbee: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_bf3;
x86_c0_l_bf3:
	/* 0xbf3: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_bf8;
x86_c0_l_bf8:
	/* 0xbf8: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_bfd;
x86_c0_l_bfd:
	/* 0xbfd: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_c00;
x86_c0_l_c00:
	/* 0xc00: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_c02;
x86_c0_l_c02:
	/* 0xc02: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_c07;
x86_c0_l_c07:
	/* 0xc07: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_c0a;
x86_c0_l_c0a:
	/* 0xc0a: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc0a, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_c10;
x86_c0_l_c10:
	/* 0xc10: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_c17;
x86_c0_l_c17:
	/* 0xc17: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_c1a;
x86_c0_l_c1a:
	/* 0xc1a: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_c1f;
x86_c0_l_c1f:
	/* 0xc1f: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_c24;
x86_c0_l_c24:
	/* 0xc24: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_c29;
x86_c0_l_c29:
	/* 0xc29: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_c2b;
x86_c0_l_c2b:
	/* 0xc2b: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_c2e;
x86_c0_l_c2e:
	/* 0xc2e: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc2e, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_c34;
x86_c0_l_c34:
	/* 0xc34: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_c3b;
x86_c0_l_c3b:
	/* 0xc3b: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_c40;
x86_c0_l_c40:
	/* 0xc40: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_c45;
x86_c0_l_c45:
	/* 0xc45: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_c4a;
x86_c0_l_c4a:
	/* 0xc4a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_c4f;
x86_c0_l_c4f:
	/* 0xc4f: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_c52;
x86_c0_l_c52:
	/* 0xc52: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_c54;
x86_c0_l_c54:
	/* 0xc54: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_c59;
x86_c0_l_c59:
	/* 0xc59: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_c5c;
x86_c0_l_c5c:
	/* 0xc5c: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc5c, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_c62;
x86_c0_l_c62:
	/* 0xc62: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_c69;
x86_c0_l_c69:
	/* 0xc69: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_c6c;
x86_c0_l_c6c:
	/* 0xc6c: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_c71;
x86_c0_l_c71:
	/* 0xc71: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_c76;
x86_c0_l_c76:
	/* 0xc76: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_c7b;
x86_c0_l_c7b:
	/* 0xc7b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_c7d;
x86_c0_l_c7d:
	/* 0xc7d: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_c80;
x86_c0_l_c80:
	/* 0xc80: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc80, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_c86;
x86_c0_l_c86:
	/* 0xc86: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_c8d;
x86_c0_l_c8d:
	/* 0xc8d: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_c92;
x86_c0_l_c92:
	/* 0xc92: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_c97;
x86_c0_l_c97:
	/* 0xc97: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_c9c;
x86_c0_l_c9c:
	/* 0xc9c: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_ca1;
x86_c0_l_ca1:
	/* 0xca1: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_ca4;
x86_c0_l_ca4:
	/* 0xca4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_ca6;
x86_c0_l_ca6:
	/* 0xca6: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_cab;
x86_c0_l_cab:
	/* 0xcab: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_cae;
x86_c0_l_cae:
	/* 0xcae: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcae, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_cb4;
x86_c0_l_cb4:
	/* 0xcb4: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_cbb;
x86_c0_l_cbb:
	/* 0xcbb: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_cbe;
x86_c0_l_cbe:
	/* 0xcbe: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_cc3;
x86_c0_l_cc3:
	/* 0xcc3: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_cc8;
x86_c0_l_cc8:
	/* 0xcc8: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_ccd;
x86_c0_l_ccd:
	/* 0xccd: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_ccf;
x86_c0_l_ccf:
	/* 0xccf: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_cd2;
x86_c0_l_cd2:
	/* 0xcd2: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcd2, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_cd8;
x86_c0_l_cd8:
	/* 0xcd8: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_cdf;
x86_c0_l_cdf:
	/* 0xcdf: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_ce4;
x86_c0_l_ce4:
	/* 0xce4: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_ce9;
x86_c0_l_ce9:
	/* 0xce9: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_cee;
x86_c0_l_cee:
	/* 0xcee: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_cf3;
x86_c0_l_cf3:
	/* 0xcf3: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_cf6;
x86_c0_l_cf6:
	/* 0xcf6: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_cf8;
x86_c0_l_cf8:
	/* 0xcf8: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_cfd;
x86_c0_l_cfd:
	/* 0xcfd: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_d00;
x86_c0_l_d00:
	/* 0xd00: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd00, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_d06;
x86_c0_l_d06:
	/* 0xd06: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_d0d;
x86_c0_l_d0d:
	/* 0xd0d: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_d10;
x86_c0_l_d10:
	/* 0xd10: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_d15;
x86_c0_l_d15:
	/* 0xd15: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_d1a;
x86_c0_l_d1a:
	/* 0xd1a: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_d1f;
x86_c0_l_d1f:
	/* 0xd1f: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_d21;
x86_c0_l_d21:
	/* 0xd21: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_d24;
x86_c0_l_d24:
	/* 0xd24: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd24, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_d2a;
x86_c0_l_d2a:
	/* 0xd2a: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_d31;
x86_c0_l_d31:
	/* 0xd31: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_d36;
x86_c0_l_d36:
	/* 0xd36: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_d3b;
x86_c0_l_d3b:
	/* 0xd3b: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_d40;
x86_c0_l_d40:
	/* 0xd40: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_d45;
x86_c0_l_d45:
	/* 0xd45: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_d48;
x86_c0_l_d48:
	/* 0xd48: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_d4a;
x86_c0_l_d4a:
	/* 0xd4a: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_d4f;
x86_c0_l_d4f:
	/* 0xd4f: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_d52;
x86_c0_l_d52:
	/* 0xd52: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd52, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_d58;
x86_c0_l_d58:
	/* 0xd58: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_d5f;
x86_c0_l_d5f:
	/* 0xd5f: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_d62;
x86_c0_l_d62:
	/* 0xd62: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_d67;
x86_c0_l_d67:
	/* 0xd67: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_d6c;
x86_c0_l_d6c:
	/* 0xd6c: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_d71;
x86_c0_l_d71:
	/* 0xd71: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_d73;
x86_c0_l_d73:
	/* 0xd73: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_d76;
x86_c0_l_d76:
	/* 0xd76: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd76, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_d7c;
x86_c0_l_d7c:
	/* 0xd7c: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_d83;
x86_c0_l_d83:
	/* 0xd83: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_d88;
x86_c0_l_d88:
	/* 0xd88: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_d8d;
x86_c0_l_d8d:
	/* 0xd8d: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_d92;
x86_c0_l_d92:
	/* 0xd92: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_d97;
x86_c0_l_d97:
	/* 0xd97: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_d9a;
x86_c0_l_d9a:
	/* 0xd9a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_d9c;
x86_c0_l_d9c:
	/* 0xd9c: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_da1;
x86_c0_l_da1:
	/* 0xda1: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_da4;
x86_c0_l_da4:
	/* 0xda4: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xda4, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_daa;
x86_c0_l_daa:
	/* 0xdaa: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_db1;
x86_c0_l_db1:
	/* 0xdb1: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_db4;
x86_c0_l_db4:
	/* 0xdb4: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_db9;
x86_c0_l_db9:
	/* 0xdb9: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_dbe;
x86_c0_l_dbe:
	/* 0xdbe: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_dc3;
x86_c0_l_dc3:
	/* 0xdc3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_dc5;
x86_c0_l_dc5:
	/* 0xdc5: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_dc8;
x86_c0_l_dc8:
	/* 0xdc8: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdc8, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_dce;
x86_c0_l_dce:
	/* 0xdce: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_dd5;
x86_c0_l_dd5:
	/* 0xdd5: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_dda;
x86_c0_l_dda:
	/* 0xdda: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_ddf;
x86_c0_l_ddf:
	/* 0xddf: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_de4;
x86_c0_l_de4:
	/* 0xde4: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_de9;
x86_c0_l_de9:
	/* 0xde9: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_dec;
x86_c0_l_dec:
	/* 0xdec: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_dee;
x86_c0_l_dee:
	/* 0xdee: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_df3;
x86_c0_l_df3:
	/* 0xdf3: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_df6;
x86_c0_l_df6:
	/* 0xdf6: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdf6, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_dfc;
x86_c0_l_dfc:
	/* 0xdfc: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_e03;
x86_c0_l_e03:
	/* 0xe03: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_e06;
x86_c0_l_e06:
	/* 0xe06: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_e0b;
x86_c0_l_e0b:
	/* 0xe0b: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_e10;
x86_c0_l_e10:
	/* 0xe10: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_e15;
x86_c0_l_e15:
	/* 0xe15: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_e17;
x86_c0_l_e17:
	/* 0xe17: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_e1a;
x86_c0_l_e1a:
	/* 0xe1a: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe1a, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_e20;
x86_c0_l_e20:
	/* 0xe20: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_e27;
x86_c0_l_e27:
	/* 0xe27: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_e2c;
x86_c0_l_e2c:
	/* 0xe2c: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_e31;
x86_c0_l_e31:
	/* 0xe31: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_e36;
x86_c0_l_e36:
	/* 0xe36: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_e3b;
x86_c0_l_e3b:
	/* 0xe3b: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_e3e;
x86_c0_l_e3e:
	/* 0xe3e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_e40;
x86_c0_l_e40:
	/* 0xe40: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_e45;
x86_c0_l_e45:
	/* 0xe45: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_e48;
x86_c0_l_e48:
	/* 0xe48: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe48, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_e4e;
x86_c0_l_e4e:
	/* 0xe4e: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_e55;
x86_c0_l_e55:
	/* 0xe55: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_e58;
x86_c0_l_e58:
	/* 0xe58: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_e5d;
x86_c0_l_e5d:
	/* 0xe5d: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_e62;
x86_c0_l_e62:
	/* 0xe62: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_e67;
x86_c0_l_e67:
	/* 0xe67: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_e69;
x86_c0_l_e69:
	/* 0xe69: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_e6c;
x86_c0_l_e6c:
	/* 0xe6c: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe6c, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_e72;
x86_c0_l_e72:
	/* 0xe72: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_e79;
x86_c0_l_e79:
	/* 0xe79: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_e7e;
x86_c0_l_e7e:
	/* 0xe7e: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_e83;
x86_c0_l_e83:
	/* 0xe83: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_e88;
x86_c0_l_e88:
	/* 0xe88: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_e8d;
x86_c0_l_e8d:
	/* 0xe8d: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_e90;
x86_c0_l_e90:
	/* 0xe90: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_e92;
x86_c0_l_e92:
	/* 0xe92: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_e97;
x86_c0_l_e97:
	/* 0xe97: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_e9a;
x86_c0_l_e9a:
	/* 0xe9a: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe9a, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_ea0;
x86_c0_l_ea0:
	/* 0xea0: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_ea7;
x86_c0_l_ea7:
	/* 0xea7: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_eaa;
x86_c0_l_eaa:
	/* 0xeaa: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_eaf;
x86_c0_l_eaf:
	/* 0xeaf: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_eb4;
x86_c0_l_eb4:
	/* 0xeb4: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_eb9;
x86_c0_l_eb9:
	/* 0xeb9: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_ebb;
x86_c0_l_ebb:
	/* 0xebb: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_ebe;
x86_c0_l_ebe:
	/* 0xebe: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xebe, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_ec4;
x86_c0_l_ec4:
	/* 0xec4: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_ecb;
x86_c0_l_ecb:
	/* 0xecb: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_ed0;
x86_c0_l_ed0:
	/* 0xed0: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_ed5;
x86_c0_l_ed5:
	/* 0xed5: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_eda;
x86_c0_l_eda:
	/* 0xeda: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_edf;
x86_c0_l_edf:
	/* 0xedf: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_ee2;
x86_c0_l_ee2:
	/* 0xee2: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_ee4;
x86_c0_l_ee4:
	/* 0xee4: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_ee9;
x86_c0_l_ee9:
	/* 0xee9: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_eec;
x86_c0_l_eec:
	/* 0xeec: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xeec, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_ef2;
x86_c0_l_ef2:
	/* 0xef2: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_ef9;
x86_c0_l_ef9:
	/* 0xef9: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_efc;
x86_c0_l_efc:
	/* 0xefc: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_f01;
x86_c0_l_f01:
	/* 0xf01: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_f06;
x86_c0_l_f06:
	/* 0xf06: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_f0b;
x86_c0_l_f0b:
	/* 0xf0b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_f0d;
x86_c0_l_f0d:
	/* 0xf0d: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_f10;
x86_c0_l_f10:
	/* 0xf10: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf10, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_f16;
x86_c0_l_f16:
	/* 0xf16: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_f1d;
x86_c0_l_f1d:
	/* 0xf1d: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_f22;
x86_c0_l_f22:
	/* 0xf22: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_f27;
x86_c0_l_f27:
	/* 0xf27: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_f2c;
x86_c0_l_f2c:
	/* 0xf2c: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_f31;
x86_c0_l_f31:
	/* 0xf31: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_f34;
x86_c0_l_f34:
	/* 0xf34: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_f36;
x86_c0_l_f36:
	/* 0xf36: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_f3b;
x86_c0_l_f3b:
	/* 0xf3b: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_f3e;
x86_c0_l_f3e:
	/* 0xf3e: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf3e, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_f44;
x86_c0_l_f44:
	/* 0xf44: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_f4b;
x86_c0_l_f4b:
	/* 0xf4b: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_f4e;
x86_c0_l_f4e:
	/* 0xf4e: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_f53;
x86_c0_l_f53:
	/* 0xf53: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_f58;
x86_c0_l_f58:
	/* 0xf58: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_f5d;
x86_c0_l_f5d:
	/* 0xf5d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_f5f;
x86_c0_l_f5f:
	/* 0xf5f: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_f62;
x86_c0_l_f62:
	/* 0xf62: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf62, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_f68;
x86_c0_l_f68:
	/* 0xf68: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_f6f;
x86_c0_l_f6f:
	/* 0xf6f: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_f74;
x86_c0_l_f74:
	/* 0xf74: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_f79;
x86_c0_l_f79:
	/* 0xf79: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_f7e;
x86_c0_l_f7e:
	/* 0xf7e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_f83;
x86_c0_l_f83:
	/* 0xf83: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_f86;
x86_c0_l_f86:
	/* 0xf86: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_f88;
x86_c0_l_f88:
	/* 0xf88: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_f8d;
x86_c0_l_f8d:
	/* 0xf8d: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_f90;
x86_c0_l_f90:
	/* 0xf90: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf90, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_f96;
x86_c0_l_f96:
	/* 0xf96: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_f9d;
x86_c0_l_f9d:
	/* 0xf9d: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_fa0;
x86_c0_l_fa0:
	/* 0xfa0: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_fa5;
x86_c0_l_fa5:
	/* 0xfa5: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_faa;
x86_c0_l_faa:
	/* 0xfaa: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_faf;
x86_c0_l_faf:
	/* 0xfaf: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_fb1;
x86_c0_l_fb1:
	/* 0xfb1: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_fb4;
x86_c0_l_fb4:
	/* 0xfb4: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfb4, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_fba;
x86_c0_l_fba:
	/* 0xfba: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_fc1;
x86_c0_l_fc1:
	/* 0xfc1: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_fc6;
x86_c0_l_fc6:
	/* 0xfc6: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_fcb;
x86_c0_l_fcb:
	/* 0xfcb: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_fd0;
x86_c0_l_fd0:
	/* 0xfd0: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_fd5;
x86_c0_l_fd5:
	/* 0xfd5: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_fd8;
x86_c0_l_fd8:
	/* 0xfd8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_fda;
x86_c0_l_fda:
	/* 0xfda: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_fdf;
x86_c0_l_fdf:
	/* 0xfdf: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_fe2;
x86_c0_l_fe2:
	/* 0xfe2: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfe2, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_fe8;
x86_c0_l_fe8:
	/* 0xfe8: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_fef;
x86_c0_l_fef:
	/* 0xfef: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_ff2;
x86_c0_l_ff2:
	/* 0xff2: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_ff7;
x86_c0_l_ff7:
	/* 0xff7: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_ffc;
x86_c0_l_ffc:
	/* 0xffc: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1001;
x86_c0_l_1001:
	/* 0x1001: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1003;
x86_c0_l_1003:
	/* 0x1003: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1006;
x86_c0_l_1006:
	/* 0x1006: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1006, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_100c;
x86_c0_l_100c:
	/* 0x100c: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_1013;
x86_c0_l_1013:
	/* 0x1013: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1018;
x86_c0_l_1018:
	/* 0x1018: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_101d;
x86_c0_l_101d:
	/* 0x101d: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_1022;
x86_c0_l_1022:
	/* 0x1022: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1027;
x86_c0_l_1027:
	/* 0x1027: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_102a;
x86_c0_l_102a:
	/* 0x102a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_102c;
x86_c0_l_102c:
	/* 0x102c: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1031;
x86_c0_l_1031:
	/* 0x1031: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_1034;
x86_c0_l_1034:
	/* 0x1034: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1034, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_103a;
x86_c0_l_103a:
	/* 0x103a: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_1041;
x86_c0_l_1041:
	/* 0x1041: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_1044;
x86_c0_l_1044:
	/* 0x1044: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1049;
x86_c0_l_1049:
	/* 0x1049: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_104e;
x86_c0_l_104e:
	/* 0x104e: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1053;
x86_c0_l_1053:
	/* 0x1053: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1055;
x86_c0_l_1055:
	/* 0x1055: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1058;
x86_c0_l_1058:
	/* 0x1058: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1058, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_105a;
x86_c0_l_105a:
	/* 0x105a: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_1061;
x86_c0_l_1061:
	/* 0x1061: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1066;
x86_c0_l_1066:
	/* 0x1066: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_106b;
x86_c0_l_106b:
	/* 0x106b: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_1070;
x86_c0_l_1070:
	/* 0x1070: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1075;
x86_c0_l_1075:
	/* 0x1075: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_1078;
x86_c0_l_1078:
	/* 0x1078: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_107a;
x86_c0_l_107a:
	/* 0x107a: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_107f;
x86_c0_l_107f:
	/* 0x107f: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_1082;
x86_c0_l_1082:
	/* 0x1082: je     10cb <event_execve+0x10cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1082, 0x10cb, x86_c0_l_10cb);
	goto x86_c0_l_1084;
x86_c0_l_1084:
	/* 0x1084: lea    rdx,[r13+0xaf4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2804ULL);
	goto x86_c0_l_108b;
x86_c0_l_108b:
	/* 0x108b: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_108e;
x86_c0_l_108e:
	/* 0x108e: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1093;
x86_c0_l_1093:
	/* 0x1093: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_1098;
x86_c0_l_1098:
	/* 0x1098: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_109d;
x86_c0_l_109d:
	/* 0x109d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_109f;
x86_c0_l_109f:
	/* 0x109f: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_10a2;
x86_c0_l_10a2:
	/* 0x10a2: je     10ce <event_execve+0x10ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10a2, 0x10ce, x86_c0_l_10ce);
	goto x86_c0_l_10a4;
x86_c0_l_10a4:
	/* 0x10a4: add    r13,0xb00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 2816ULL);
	goto x86_c0_l_10ab;
x86_c0_l_10ab:
	/* 0x10ab: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_10b0;
x86_c0_l_10b0:
	/* 0x10b0: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_10b5;
x86_c0_l_10b5:
	/* 0x10b5: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_10ba;
x86_c0_l_10ba:
	/* 0x10ba: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_10bf;
x86_c0_l_10bf:
	/* 0x10bf: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_10c2;
x86_c0_l_10c2:
	/* 0x10c2: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_10c4;
x86_c0_l_10c4:
	/* 0x10c4: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_10c9;
x86_c0_l_10c9:
	/* 0x10c9: jmp    10ce <event_execve+0x10ce> */
	X86_SIM_X86_JMP(0x10c9, 0x10ce, x86_c0_l_10ce);
x86_c0_l_10cb:
	/* 0x10cb: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_10ce;
x86_c0_l_10ce:
	/* 0x10ce: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_10d0;
x86_c0_l_10d0:
	/* 0x10d0: cmp    DWORD PTR [rsp],ebx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_10d3;
x86_c0_l_10d3:
	/* 0x10d3: cmovne r13,rbp */
	X86_SIM_L_EXEC_CMOV(X86_R13, X86_RBP, X86_WIDTH_64, X86_CC_NE);
	goto x86_c0_l_10d7;
x86_c0_l_10d7:
	/* 0x10d7: add    r13,0xd50 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 3408ULL);
	goto x86_c0_l_10de;
x86_c0_l_10de:
	/* 0x10de: lea    rdi,[rsp+0xb8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
	goto x86_c0_l_10e6;
x86_c0_l_10e6:
	/* 0x10e6: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_10eb;
x86_c0_l_10eb:
	/* 0x10eb: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_10f0;
x86_c0_l_10f0:
	/* 0x10f0: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_10f5;
x86_c0_l_10f5:
	/* 0x10f5: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_10f8;
x86_c0_l_10f8:
	/* 0x10f8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_10fa;
x86_c0_l_10fa:
	/* 0x10fa: mov    rbx,QWORD PTR [rsp+0xb8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
	goto x86_c0_l_1102;
x86_c0_l_1102:
	/* 0x1102: test   rbx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64);
	goto x86_c0_l_1105;
x86_c0_l_1105:
	/* 0x1105: je     11e7 <event_execve+0x11e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1105, 0x11e7, x86_c0_l_11e7);
	goto x86_c0_l_110b;
x86_c0_l_110b:
	/* 0x110b: mov    DWORD PTR [rsp+0xa4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704374636544ULL);
	goto x86_c0_l_1116;
x86_c0_l_1116:
	/* 0x1116: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)buffer_heap_map));
	goto x86_c0_l_111d;
x86_c0_l_111d:
	/* 0x111d: lea    rsi,[rsp+0xa4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
	goto x86_c0_l_1125;
x86_c0_l_1125:
	/* 0x1125: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_112a;
x86_c0_l_112a:
	/* 0x112a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_112c;
x86_c0_l_112c:
	/* 0x112c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_112f;
x86_c0_l_112f:
	/* 0x112f: je     1512 <event_execve+0x1512> */
	X86_SIM_X86_JCC(X86_CC_E, 0x112f, 0x1512, x86_c0_l_1512);
	goto x86_c0_l_1135;
x86_c0_l_1135:
	/* 0x1135: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_1138;
x86_c0_l_1138:
	/* 0x1138: mov    QWORD PTR [rsp+0x78],r12 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
	goto x86_c0_l_113d;
x86_c0_l_113d:
	/* 0x113d: lea    rax,[rbx+0x28] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
	goto x86_c0_l_1141;
x86_c0_l_1141:
	/* 0x1141: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
	goto x86_c0_l_1149;
x86_c0_l_1149:
	/* 0x1149: lea    rax,[rbp+0x1000] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
	goto x86_c0_l_1150;
x86_c0_l_1150:
	/* 0x1150: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
	goto x86_c0_l_1155;
x86_c0_l_1155:
	/* 0x1155: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
	goto x86_c0_l_115a;
x86_c0_l_115a:
	/* 0x115a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_115c;
x86_c0_l_115c:
	/* 0x115c: lea    rdx,[rax+0xd50] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3408ULL);
	goto x86_c0_l_1163;
x86_c0_l_1163:
	/* 0x1163: lea    rdi,[rsp+0xc0] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
	goto x86_c0_l_116b;
x86_c0_l_116b:
	/* 0x116b: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1170;
x86_c0_l_1170:
	/* 0x1170: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1175;
x86_c0_l_1175:
	/* 0x1175: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_117a;
x86_c0_l_117a:
	/* 0x117a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_117c;
x86_c0_l_117c:
	/* 0x117c: mov    r13,QWORD PTR [rsp+0xc0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
	goto x86_c0_l_1184;
x86_c0_l_1184:
	/* 0x1184: add    rbx,0x30 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 48ULL);
	goto x86_c0_l_1188;
x86_c0_l_1188:
	/* 0x1188: lea    rdi,[rsp+0x98] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
	goto x86_c0_l_1190;
x86_c0_l_1190:
	/* 0x1190: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1195;
x86_c0_l_1195:
	/* 0x1195: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_119a;
x86_c0_l_119a:
	/* 0x119a: lea    rcx,[r13+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_119e;
x86_c0_l_119e:
	/* 0x119e: mov    QWORD PTR [rsp+0xa8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
	goto x86_c0_l_11a6;
x86_c0_l_11a6:
	/* 0x11a6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_11ab;
x86_c0_l_11ab:
	/* 0x11ab: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
	goto x86_c0_l_11ae;
x86_c0_l_11ae:
	/* 0x11ae: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_11b0;
x86_c0_l_11b0:
	/* 0x11b0: mov    r15,QWORD PTR [rsp+0x98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
	goto x86_c0_l_11b8;
x86_c0_l_11b8:
	/* 0x11b8: lea    rdx,[r15+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_11bc;
x86_c0_l_11bc:
	/* 0x11bc: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_11c1;
x86_c0_l_11c1:
	/* 0x11c1: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_11c6;
x86_c0_l_11c6:
	/* 0x11c6: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_11cb;
x86_c0_l_11cb:
	/* 0x11cb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_11d0;
x86_c0_l_11d0:
	/* 0x11d0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_11d2;
x86_c0_l_11d2:
	/* 0x11d2: cmp    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
	goto x86_c0_l_11d8;
x86_c0_l_11d8:
	/* 0x11d8: mov    r12d,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 4096ULL);
	goto x86_c0_l_11de;
x86_c0_l_11de:
	/* 0x11de: je     11f4 <event_execve+0x11f4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11de, 0x11f4, x86_c0_l_11f4);
	goto x86_c0_l_11e0;
x86_c0_l_11e0:
	/* 0x11e0: mov    rcx,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
	goto x86_c0_l_11e5;
x86_c0_l_11e5:
	/* 0x11e5: jmp    1244 <event_execve+0x1244> */
	X86_SIM_X86_JMP(0x11e5, 0x1244, x86_c0_l_1244);
x86_c0_l_11e7:
	/* 0x11e7: or     BYTE PTR [r14+0x15d],0x20 */
	X86_SIM_L_EXEC_ALU_MEM_IMM(X86_R14, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 1498943586336ULL);
	goto x86_c0_l_11ef;
x86_c0_l_11ef:
	/* 0x11ef: jmp    1587 <event_execve+0x1587> */
	X86_SIM_X86_JMP(0x11ef, 0x1587, x86_c0_l_1587);
x86_c0_l_11f4:
	/* 0x11f4: lea    rdx,[r15+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_11f8;
x86_c0_l_11f8:
	/* 0x11f8: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_11fd;
x86_c0_l_11fd:
	/* 0x11fd: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1202;
x86_c0_l_1202:
	/* 0x1202: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1207;
x86_c0_l_1207:
	/* 0x1207: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_120c;
x86_c0_l_120c:
	/* 0x120c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_120e;
x86_c0_l_120e:
	/* 0x120e: cmp    QWORD PTR [rsp+0x20],r15 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1213;
x86_c0_l_1213:
	/* 0x1213: mov    rcx,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
	goto x86_c0_l_1218;
x86_c0_l_1218:
	/* 0x1218: je     1244 <event_execve+0x1244> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1218, 0x1244, x86_c0_l_1244);
	goto x86_c0_l_121a;
x86_c0_l_121a:
	/* 0x121a: mov    rcx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_64);
	goto x86_c0_l_121d;
x86_c0_l_121d:
	/* 0x121d: add    rcx,0xff6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 4086ULL);
	goto x86_c0_l_1224;
x86_c0_l_1224:
	/* 0x1224: movabs rax,0x6574656c65642820 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 7310579611361093664ULL);
	goto x86_c0_l_122e;
x86_c0_l_122e:
	/* 0x122e: mov    QWORD PTR [rbp+0xff6],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4086ULL);
	goto x86_c0_l_1235;
x86_c0_l_1235:
	/* 0x1235: mov    WORD PTR [rbp+0xffe],0x2964 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 17583596120420ULL);
	goto x86_c0_l_123e;
x86_c0_l_123e:
	/* 0x123e: mov    r12d,0xff6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 4086ULL);
	goto x86_c0_l_1244;
x86_c0_l_1244:
	/* 0x1244: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c0_l_124d;
x86_c0_l_124d:
	/* 0x124d: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
	goto x86_c0_l_1256;
x86_c0_l_1256:
	/* 0x1256: mov    QWORD PTR [rsp+0x30],rbp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
	goto x86_c0_l_125b;
x86_c0_l_125b:
	/* 0x125b: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
	goto x86_c0_l_1264;
x86_c0_l_1264:
	/* 0x1264: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
	goto x86_c0_l_126d;
x86_c0_l_126d:
	/* 0x126d: mov    QWORD PTR [rsp+0x48],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
	goto x86_c0_l_1276;
x86_c0_l_1276:
	/* 0x1276: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
	goto x86_c0_l_127b;
x86_c0_l_127b:
	/* 0x127b: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
	goto x86_c0_l_1280;
x86_c0_l_1280:
	/* 0x1280: mov    DWORD PTR [rsp+0x58],r12d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
	goto x86_c0_l_1285;
x86_c0_l_1285:
	/* 0x1285: mov    BYTE PTR [rsp+0x5c],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 395136991232ULL);
	goto x86_c0_l_128a;
x86_c0_l_128a:
	/* 0x128a: add    r13,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
	goto x86_c0_l_128e;
x86_c0_l_128e:
	/* 0x128e: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1293;
x86_c0_l_1293:
	/* 0x1293: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1298;
x86_c0_l_1298:
	/* 0x1298: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_129d;
x86_c0_l_129d:
	/* 0x129d: lea    rbp,[rsp+0x28] */
	X86_SIM_L_EXEC_LEA(X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
	goto x86_c0_l_12a2;
x86_c0_l_12a2:
	/* 0x12a2: lea    r15,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
	goto x86_c0_l_12a7;
x86_c0_l_12a7:
	/* 0x12a7: lea    r12,[rsp+0x40] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
	goto x86_c0_l_12ac;
x86_c0_l_12ac:
	/* 0x12ac: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_12b1;
x86_c0_l_12b1:
	/* 0x12b1: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_12b4;
x86_c0_l_12b4:
	/* 0x12b4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_12b6;
x86_c0_l_12b6:
	/* 0x12b6: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_12bb;
x86_c0_l_12bb:
	/* 0x12bb: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_12c0;
x86_c0_l_12c0:
	/* 0x12c0: mov    rdx,QWORD PTR [rsp+0xa8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
	goto x86_c0_l_12c8;
x86_c0_l_12c8:
	/* 0x12c8: mov    rdi,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBP, X86_WIDTH_64);
	goto x86_c0_l_12cb;
x86_c0_l_12cb:
	/* 0x12cb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_12d0;
x86_c0_l_12d0:
	/* 0x12d0: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_12d2;
x86_c0_l_12d2:
	/* 0x12d2: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_12d7;
x86_c0_l_12d7:
	/* 0x12d7: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_12dc;
x86_c0_l_12dc:
	/* 0x12dc: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
	goto x86_c0_l_12df;
x86_c0_l_12df:
	/* 0x12df: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_12e4;
x86_c0_l_12e4:
	/* 0x12e4: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
	goto x86_c0_l_12e7;
x86_c0_l_12e7:
	/* 0x12e7: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_12e9;
x86_c0_l_12e9:
	/* 0x12e9: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_12ee;
x86_c0_l_12ee:
	/* 0x12ee: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_12f3;
x86_c0_l_12f3:
	/* 0x12f3: mov    rdx,QWORD PTR [rsp+0xb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
	goto x86_c0_l_12fb;
x86_c0_l_12fb:
	/* 0x12fb: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c0_l_12fe;
x86_c0_l_12fe:
	/* 0x12fe: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1303;
x86_c0_l_1303:
	/* 0x1303: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1305;
x86_c0_l_1305:
	/* 0x1305: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
	goto x86_c0_l_130a;
x86_c0_l_130a:
	/* 0x130a: add    rax,0xffffffffffffffe0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551584ULL);
	goto x86_c0_l_130e;
x86_c0_l_130e:
	/* 0x130e: mov    QWORD PTR [rsp+0x48],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
	goto x86_c0_l_1313;
x86_c0_l_1313:
	/* 0x1313: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)CONFIG_ITER_NUM));
	goto x86_c0_l_131a;
x86_c0_l_131a:
	/* 0x131a: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_131d;
x86_c0_l_131d:
	/* 0x131d: je     14b5 <event_execve+0x14b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x131d, 0x14b5, x86_c0_l_14b5);
	goto x86_c0_l_1323;
x86_c0_l_1323:
	/* 0x1323: mov    r13d,0x800 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_32, 2048ULL);
	goto x86_c0_l_1329;
x86_c0_l_1329:
	/* 0x1329: mov    r12d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_132f;
x86_c0_l_132f:
	/* 0x132f: mov    rbp,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
	goto x86_c0_l_1334;
x86_c0_l_1334:
	/* 0x1334: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
	goto x86_c0_l_1339;
x86_c0_l_1339:
	/* 0x1339: mov    r15,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
	goto x86_c0_l_133e;
x86_c0_l_133e:
	/* 0x133e: cmp    rbp,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
	goto x86_c0_l_1343;
x86_c0_l_1343:
	/* 0x1343: jne    1350 <event_execve+0x1350> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1343, 0x1350, x86_c0_l_1350);
	goto x86_c0_l_1345;
x86_c0_l_1345:
	/* 0x1345: cmp    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
	goto x86_c0_l_134a;
x86_c0_l_134a:
	/* 0x134a: je     1516 <event_execve+0x1516> */
	X86_SIM_X86_JCC(X86_CC_E, 0x134a, 0x1516, x86_c0_l_1516);
	goto x86_c0_l_1350;
x86_c0_l_1350:
	/* 0x1350: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1355;
x86_c0_l_1355:
	/* 0x1355: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
	goto x86_c0_l_135a;
x86_c0_l_135a:
	/* 0x135a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_135f;
x86_c0_l_135f:
	/* 0x135f: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1361;
x86_c0_l_1361:
	/* 0x1361: cmp    rbp,QWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 104ULL);
	goto x86_c0_l_1366;
x86_c0_l_1366:
	/* 0x1366: je     145a <event_execve+0x145a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1366, 0x145a, x86_c0_l_145a);
	goto x86_c0_l_136c;
x86_c0_l_136c:
	/* 0x136c: lea    rbx,[rbp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RBX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_1370;
x86_c0_l_1370:
	/* 0x1370: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1375;
x86_c0_l_1375:
	/* 0x1375: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_137a;
x86_c0_l_137a:
	/* 0x137a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_137f;
x86_c0_l_137f:
	/* 0x137f: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
	goto x86_c0_l_1382;
x86_c0_l_1382:
	/* 0x1382: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1384;
x86_c0_l_1384:
	/* 0x1384: cmp    QWORD PTR [rsp+0x10],rbp */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_1389;
x86_c0_l_1389:
	/* 0x1389: je     145a <event_execve+0x145a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1389, 0x145a, x86_c0_l_145a);
	goto x86_c0_l_138f;
x86_c0_l_138f:
	/* 0x138f: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1394;
x86_c0_l_1394:
	/* 0x1394: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_1399;
x86_c0_l_1399:
	/* 0x1399: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_139e;
x86_c0_l_139e:
	/* 0x139e: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
	goto x86_c0_l_13a1;
x86_c0_l_13a1:
	/* 0x13a1: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_13a3;
x86_c0_l_13a3:
	/* 0x13a3: add    rbp,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
	goto x86_c0_l_13a7;
x86_c0_l_13a7:
	/* 0x13a7: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_13ac;
x86_c0_l_13ac:
	/* 0x13ac: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_13af;
x86_c0_l_13af:
	/* 0x13af: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
	goto x86_c0_l_13b4;
x86_c0_l_13b4:
	/* 0x13b4: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
	goto x86_c0_l_13b9;
x86_c0_l_13b9:
	/* 0x13b9: mov    rdx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_64);
	goto x86_c0_l_13bc;
x86_c0_l_13bc:
	/* 0x13bc: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_13be;
x86_c0_l_13be:
	/* 0x13be: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
	goto x86_c0_l_13c3;
x86_c0_l_13c3:
	/* 0x13c3: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
	goto x86_c0_l_13c8;
x86_c0_l_13c8:
	/* 0x13c8: mov    ebp,DWORD PTR [rsp+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c0_l_13cc;
x86_c0_l_13cc:
	/* 0x13cc: sub    rax,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c0_l_13cf;
x86_c0_l_13cf:
	/* 0x13cf: mov    r15d,DWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
	goto x86_c0_l_13d4;
x86_c0_l_13d4:
	/* 0x13d4: mov    edx,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_32);
	goto x86_c0_l_13d6;
x86_c0_l_13d6:
	/* 0x13d6: sub    edx,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R15, X86_WIDTH_32, X86_ALU_SUB);
	goto x86_c0_l_13d9;
x86_c0_l_13d9:
	/* 0x13d9: mov    ecx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 0ULL);
	goto x86_c0_l_13de;
x86_c0_l_13de:
	/* 0x13de: cmovb  edx,ecx */
	X86_SIM_L_EXEC_CMOV(X86_RDX, X86_RCX, X86_WIDTH_32, X86_CC_B);
	goto x86_c0_l_13e1;
x86_c0_l_13e1:
	/* 0x13e1: add    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
	goto x86_c0_l_13e6;
x86_c0_l_13e6:
	/* 0x13e6: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_13e8;
x86_c0_l_13e8:
	/* 0x13e8: cmp    r15d,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R15, X86_RBP, X86_WIDTH_32);
	goto x86_c0_l_13eb;
x86_c0_l_13eb:
	/* 0x13eb: seta   sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_A);
	goto x86_c0_l_13ef;
x86_c0_l_13ef:
	/* 0x13ef: mov    ecx,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBP, X86_WIDTH_32);
	goto x86_c0_l_13f1;
x86_c0_l_13f1:
	/* 0x13f1: cmovb  ecx,r15d */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_R15, X86_WIDTH_32, X86_CC_B);
	goto x86_c0_l_13f5;
x86_c0_l_13f5:
	/* 0x13f5: add    esi,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RCX, X86_WIDTH_32, X86_ALU_ADD);
	goto x86_c0_l_13f7;
x86_c0_l_13f7:
	/* 0x13f7: mov    edi,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_32);
	goto x86_c0_l_13fa;
x86_c0_l_13fa:
	/* 0x13fa: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
	goto x86_c0_l_13fc;
x86_c0_l_13fc:
	/* 0x13fc: mov    DWORD PTR [rsp+0x58],edi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
	goto x86_c0_l_1400;
x86_c0_l_1400:
	/* 0x1400: sub    rax,rsi */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RSI, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c0_l_1403;
x86_c0_l_1403:
	/* 0x1403: jb     14d6 <event_execve+0x14d6> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1403, 0x14d6, x86_c0_l_14d6);
	goto x86_c0_l_1409;
x86_c0_l_1409:
	/* 0x1409: cmp    rax,0xfff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 4095ULL);
	goto x86_c0_l_140f;
x86_c0_l_140f:
	/* 0x140f: ja     14d6 <event_execve+0x14d6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x140f, 0x14d6, x86_c0_l_14d6);
	goto x86_c0_l_1415;
x86_c0_l_1415:
	/* 0x1415: cmp    r15d,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R15, X86_RBP, X86_WIDTH_32);
	goto x86_c0_l_1418;
x86_c0_l_1418:
	/* 0x1418: jbe    141e <event_execve+0x141e> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1418, 0x141e, x86_c0_l_141e);
	goto x86_c0_l_141a;
x86_c0_l_141a:
	/* 0x141a: mov    BYTE PTR [rbx+rax*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
	goto x86_c0_l_141e;
x86_c0_l_141e:
	/* 0x141e: xor    edi,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1420;
x86_c0_l_1420:
	/* 0x1420: cmp    r15d,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R15, X86_RBP, X86_WIDTH_32);
	goto x86_c0_l_1423;
x86_c0_l_1423:
	/* 0x1423: seta   dil */
	X86_SIM_L_EXEC_SETCC(X86_RDI, X86_CC_A);
	goto x86_c0_l_1427;
x86_c0_l_1427:
	/* 0x1427: movzx  esi,cl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RSI, X86_RCX, X86_WIDTH_32, X86_WIDTH_8);
	goto x86_c0_l_142a;
x86_c0_l_142a:
	/* 0x142a: add    rbx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_142d;
x86_c0_l_142d:
	/* 0x142d: add    rdi,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_1430;
x86_c0_l_1430:
	/* 0x1430: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1435;
x86_c0_l_1435:
	/* 0x1435: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1437;
x86_c0_l_1437:
	/* 0x1437: mov    QWORD PTR [rsp+0x50],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
	goto x86_c0_l_143c;
x86_c0_l_143c:
	/* 0x143c: cmp    r15d,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R15, X86_RBP, X86_WIDTH_32);
	goto x86_c0_l_143f;
x86_c0_l_143f:
	/* 0x143f: jbe    14d6 <event_execve+0x14d6> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x143f, 0x14d6, x86_c0_l_14d6);
	goto x86_c0_l_1445;
x86_c0_l_1445:
	/* 0x1445: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_144a;
x86_c0_l_144a:
	/* 0x144a: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
	goto x86_c0_l_144f;
x86_c0_l_144f:
	/* 0x144f: dec    r13d */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_DEC, 1);
	goto x86_c0_l_1452;
x86_c0_l_1452:
	/* 0x1452: jne    132f <event_execve+0x132f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1452, 0x132f, x86_c0_l_132f);
	goto x86_c0_l_1458;
x86_c0_l_1458:
	/* 0x1458: jmp    14d6 <event_execve+0x14d6> */
	X86_SIM_X86_JMP(0x1458, 0x14d6, x86_c0_l_14d6);
x86_c0_l_145a:
	/* 0x145a: lea    rdx,[r15+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_145e;
x86_c0_l_145e:
	/* 0x145e: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1463;
x86_c0_l_1463:
	/* 0x1463: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_1468;
x86_c0_l_1468:
	/* 0x1468: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_146d;
x86_c0_l_146d:
	/* 0x146d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_146f;
x86_c0_l_146f:
	/* 0x146f: mov    rax,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
	goto x86_c0_l_1474;
x86_c0_l_1474:
	/* 0x1474: cmp    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
	goto x86_c0_l_1479;
x86_c0_l_1479:
	/* 0x1479: je     1516 <event_execve+0x1516> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1479, 0x1516, x86_c0_l_1516);
	goto x86_c0_l_147f;
x86_c0_l_147f:
	/* 0x147f: add    r15,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
	goto x86_c0_l_1483;
x86_c0_l_1483:
	/* 0x1483: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1488;
x86_c0_l_1488:
	/* 0x1488: lea    rdi,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
	goto x86_c0_l_148d;
x86_c0_l_148d:
	/* 0x148d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1492;
x86_c0_l_1492:
	/* 0x1492: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c0_l_1495;
x86_c0_l_1495:
	/* 0x1495: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1497;
x86_c0_l_1497:
	/* 0x1497: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_149c;
x86_c0_l_149c:
	/* 0x149c: mov    QWORD PTR [rsp+0x48],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
	goto x86_c0_l_14a1;
x86_c0_l_14a1:
	/* 0x14a1: add    rax,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
	goto x86_c0_l_14a5;
x86_c0_l_14a5:
	/* 0x14a5: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
	goto x86_c0_l_14aa;
x86_c0_l_14aa:
	/* 0x14aa: dec    r13d */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_DEC, 1);
	goto x86_c0_l_14ad;
x86_c0_l_14ad:
	/* 0x14ad: jne    132f <event_execve+0x132f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14ad, 0x132f, x86_c0_l_132f);
	goto x86_c0_l_14b3;
x86_c0_l_14b3:
	/* 0x14b3: jmp    14d6 <event_execve+0x14d6> */
	X86_SIM_X86_JMP(0x14b3, 0x14d6, x86_c0_l_14d6);
x86_c0_l_14b5:
	/* 0x14b5: lea    rsi,[rip+0xc73] */
	X86_SIM_X86_CODE_ADDRESS(X86_RSI, 0x212fULL);
	goto x86_c0_l_14bc;
x86_c0_l_14bc:
	/* 0x14bc: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_14be;
x86_c0_l_14be:
	/* 0x14be: lea    rdx,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_14c3;
x86_c0_l_14c3:
	/* 0x14c3: mov    edi,0x800 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 2048ULL);
	goto x86_c0_l_14c8;
x86_c0_l_14c8:
	/* 0x14c8: mov    eax,0xb5 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 181ULL);
	goto x86_c0_l_14cd;
x86_c0_l_14cd:
	/* 0x14cd: mov    edi,0x800 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 2048ULL);
	goto x86_c0_l_14d2;
x86_c0_l_14d2:
	/* 0x14d2: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_14d4;
x86_c0_l_14d4:
	/* 0x14d4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xb5ULL: X86_SIM_BPF_CALL_bpf_loop(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xb5ULL: X86_SIM_BPF_CALL_bpf_loop(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_14d6;
x86_c0_l_14d6:
	/* 0x14d6: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
	goto x86_c0_l_14db;
x86_c0_l_14db:
	/* 0x14db: mov    rdx,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
	goto x86_c0_l_14e0;
x86_c0_l_14e0:
	/* 0x14e0: cmp    rax,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64);
	goto x86_c0_l_14e3;
x86_c0_l_14e3:
	/* 0x14e3: je     152a <event_execve+0x152a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14e3, 0x152a, x86_c0_l_152a);
	goto x86_c0_l_14e5;
x86_c0_l_14e5:
	/* 0x14e5: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_14e7;
x86_c0_l_14e7:
	/* 0x14e7: cmp    BYTE PTR [rsp+0x5c],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 395136991232ULL);
	goto x86_c0_l_14ec;
x86_c0_l_14ec:
	/* 0x14ec: sete   cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_E);
	goto x86_c0_l_14ef;
x86_c0_l_14ef:
	/* 0x14ef: mov    edx,DWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
	goto x86_c0_l_14f3;
x86_c0_l_14f3:
	/* 0x14f3: mov    ebp,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 4096ULL);
	goto x86_c0_l_14f8;
x86_c0_l_14f8:
	/* 0x14f8: sub    ebp,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RDX, X86_WIDTH_32, X86_ALU_SUB);
	goto x86_c0_l_14fa;
x86_c0_l_14fa:
	/* 0x14fa: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
	goto x86_c0_l_14fc;
x86_c0_l_14fc:
	/* 0x14fc: cmovle ebp,edx */
	X86_SIM_L_EXEC_CMOV(X86_RBP, X86_RDX, X86_WIDTH_32, X86_CC_LE);
	goto x86_c0_l_14ff;
x86_c0_l_14ff:
	/* 0x14ff: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_1502;
x86_c0_l_1502:
	/* 0x1502: mov    r12,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
	goto x86_c0_l_1507;
x86_c0_l_1507:
	/* 0x1507: je     1512 <event_execve+0x1512> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1507, 0x1512, x86_c0_l_1512);
	goto x86_c0_l_1509;
x86_c0_l_1509:
	/* 0x1509: mov    bl,cl */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RCX, X86_WIDTH_8);
	goto x86_c0_l_150b;
x86_c0_l_150b:
	/* 0x150b: add    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_ADD);
	goto x86_c0_l_150d;
x86_c0_l_150d:
	/* 0x150d: mov    rdx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_1510;
x86_c0_l_1510:
	/* 0x1510: jmp    1533 <event_execve+0x1533> */
	X86_SIM_X86_JMP(0x1510, 0x1533, x86_c0_l_1533);
x86_c0_l_1512:
	/* 0x1512: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1514;
x86_c0_l_1514:
	/* 0x1514: jmp    1587 <event_execve+0x1587> */
	X86_SIM_X86_JMP(0x1514, 0x1587, x86_c0_l_1587);
x86_c0_l_1516:
	/* 0x1516: mov    BYTE PTR [rsp+0x5c],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 395136991233ULL);
	goto x86_c0_l_151b;
x86_c0_l_151b:
	/* 0x151b: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
	goto x86_c0_l_1520;
x86_c0_l_1520:
	/* 0x1520: mov    rdx,QWORD PTR [rsp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
	goto x86_c0_l_1525;
x86_c0_l_1525:
	/* 0x1525: cmp    rax,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64);
	goto x86_c0_l_1528;
x86_c0_l_1528:
	/* 0x1528: jne    14e5 <event_execve+0x14e5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1528, 0x14e5, x86_c0_l_14e5);
	goto x86_c0_l_152a;
x86_c0_l_152a:
	/* 0x152a: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_152c;
x86_c0_l_152c:
	/* 0x152c: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_152e;
x86_c0_l_152e:
	/* 0x152e: mov    r12,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
	goto x86_c0_l_1533;
x86_c0_l_1533:
	/* 0x1533: mov    rdi,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
	goto x86_c0_l_153b;
x86_c0_l_153b:
	/* 0x153b: and    edi,0x3ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
	goto x86_c0_l_1541;
x86_c0_l_1541:
	/* 0x1541: and    ebp,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
	goto x86_c0_l_1547;
x86_c0_l_1547:
	/* 0x1547: add    rdi,r12 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_154a;
x86_c0_l_154a:
	/* 0x154a: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_154f;
x86_c0_l_154f:
	/* 0x154f: mov    esi,ebp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBP, X86_WIDTH_32);
	goto x86_c0_l_1551;
x86_c0_l_1551:
	/* 0x1551: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1553;
x86_c0_l_1553:
	/* 0x1553: mov    eax,DWORD PTR [r14+0x15c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 348ULL);
	goto x86_c0_l_155a;
x86_c0_l_155a:
	/* 0x155a: mov    ecx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_32);
	goto x86_c0_l_155c;
x86_c0_l_155c:
	/* 0x155c: or     ecx,0x1000 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_OR, 4096ULL);
	goto x86_c0_l_1562;
x86_c0_l_1562:
	/* 0x1562: test   ebp,ebp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32);
	goto x86_c0_l_1564;
x86_c0_l_1564:
	/* 0x1564: cmovne ecx,eax */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RAX, X86_WIDTH_32, X86_CC_NE);
	goto x86_c0_l_1567;
x86_c0_l_1567:
	/* 0x1567: mov    eax,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_32);
	goto x86_c0_l_1569;
x86_c0_l_1569:
	/* 0x1569: or     eax,0x400000 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_OR, 4194304ULL);
	goto x86_c0_l_156e;
x86_c0_l_156e:
	/* 0x156e: test   ebx,ebx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32);
	goto x86_c0_l_1570;
x86_c0_l_1570:
	/* 0x1570: cmove  eax,ecx */
	X86_SIM_L_EXEC_CMOV(X86_RAX, X86_RCX, X86_WIDTH_32, X86_CC_E);
	goto x86_c0_l_1573;
x86_c0_l_1573:
	/* 0x1573: and    eax,0xffffdbff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 4294958079ULL);
	goto x86_c0_l_1578;
x86_c0_l_1578:
	/* 0x1578: mov    DWORD PTR [r14+0x15c],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 348ULL);
	goto x86_c0_l_157f;
x86_c0_l_157f:
	/* 0x157f: mov    WORD PTR [r14+0x17c],bp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 380ULL);
	goto x86_c0_l_1587;
x86_c0_l_1587:
	/* 0x1587: mov    ebx,DWORD PTR [r12] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_158b;
x86_c0_l_158b:
	/* 0x158b: add    ebx,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBP, X86_WIDTH_32, X86_ALU_ADD);
	goto x86_c0_l_158d;
x86_c0_l_158d:
	/* 0x158d: mov    DWORD PTR [r12],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R12, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1591;
x86_c0_l_1591:
	/* 0x1591: mov    QWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1599;
x86_c0_l_1599:
	/* 0x1599: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)ENV_VARS_ENABLED));
	goto x86_c0_l_15a0;
x86_c0_l_15a0:
	/* 0x15a0: xor    r13d,r13d */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_15a3;
x86_c0_l_15a3:
	/* 0x15a3: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_15a6;
x86_c0_l_15a6:
	/* 0x15a6: je     1780 <event_execve+0x1780> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15a6, 0x1780, x86_c0_l_1780);
	goto x86_c0_l_15ac;
x86_c0_l_15ac:
	/* 0x15ac: cmp    ebx,0x3ff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 1023ULL);
	goto x86_c0_l_15b2;
x86_c0_l_15b2:
	/* 0x15b2: ja     1780 <event_execve+0x1780> */
	X86_SIM_X86_JCC(X86_CC_A, 0x15b2, 0x1780, x86_c0_l_1780);
	goto x86_c0_l_15b8;
x86_c0_l_15b8:
	/* 0x15b8: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
	goto x86_c0_l_15bd;
x86_c0_l_15bd:
	/* 0x15bd: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_15bf;
x86_c0_l_15bf:
	/* 0x15bf: lea    rdx,[rax+0xa78] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2680ULL);
	goto x86_c0_l_15c6;
x86_c0_l_15c6:
	/* 0x15c6: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_15c9;
x86_c0_l_15c9:
	/* 0x15c9: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_15ce;
x86_c0_l_15ce:
	/* 0x15ce: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_15d3;
x86_c0_l_15d3:
	/* 0x15d3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_15d8;
x86_c0_l_15d8:
	/* 0x15d8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_15da;
x86_c0_l_15da:
	/* 0x15da: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_15de;
x86_c0_l_15de:
	/* 0x15de: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c0_l_15e1;
x86_c0_l_15e1:
	/* 0x15e1: je     1780 <event_execve+0x1780> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15e1, 0x1780, x86_c0_l_1780);
	goto x86_c0_l_15e7;
x86_c0_l_15e7:
	/* 0x15e7: add    rcx,0x2c8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 712ULL);
	goto x86_c0_l_15ee;
x86_c0_l_15ee:
	/* 0x15ee: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_15f3;
x86_c0_l_15f3:
	/* 0x15f3: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_15f8;
x86_c0_l_15f8:
	/* 0x15f8: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_15fd;
x86_c0_l_15fd:
	/* 0x15fd: mov    edx,0x2c8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 712ULL);
	goto x86_c0_l_1602;
x86_c0_l_1602:
	/* 0x1602: add    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
	goto x86_c0_l_1606;
x86_c0_l_1606:
	/* 0x1606: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_160b;
x86_c0_l_160b:
	/* 0x160b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_160d;
x86_c0_l_160d:
	/* 0x160d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_1610;
x86_c0_l_1610:
	/* 0x1610: je     166f <event_execve+0x166f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1610, 0x166f, x86_c0_l_166f);
	goto x86_c0_l_1612;
x86_c0_l_1612:
	/* 0x1612: neg    eax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_NEG, 0);
	goto x86_c0_l_1614;
x86_c0_l_1614:
	/* 0x1614: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1619;
x86_c0_l_1619:
	/* 0x1619: mov    WORD PTR [rsp+0x22],0x9 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 146028888073ULL);
	goto x86_c0_l_1620;
x86_c0_l_1620:
	/* 0x1620: movabs rax,0x40000009a */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 17179869338ULL);
	goto x86_c0_l_162a;
x86_c0_l_162a:
	/* 0x162a: mov    QWORD PTR [rsp+0x24],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
	goto x86_c0_l_162f;
x86_c0_l_162f:
	/* 0x162f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
	goto x86_c0_l_1636;
x86_c0_l_1636:
	/* 0x1636: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_163b;
x86_c0_l_163b:
	/* 0x163b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_1640;
x86_c0_l_1640:
	/* 0x1640: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1642;
x86_c0_l_1642:
	/* 0x1642: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_1645;
x86_c0_l_1645:
	/* 0x1645: je     164b <event_execve+0x164b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1645, 0x164b, x86_c0_l_164b);
	goto x86_c0_l_1647;
x86_c0_l_1647:
	/* 0x1647: inc    DWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
	goto x86_c0_l_1649;
x86_c0_l_1649:
	/* 0x1649: jmp    166f <event_execve+0x166f> */
	X86_SIM_X86_JMP(0x1649, 0x166f, x86_c0_l_166f);
x86_c0_l_164b:
	/* 0x164b: mov    DWORD PTR [rsp+0x18],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215105ULL);
	goto x86_c0_l_1653;
x86_c0_l_1653:
	/* 0x1653: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
	goto x86_c0_l_165a;
x86_c0_l_165a:
	/* 0x165a: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_165c;
x86_c0_l_165c:
	/* 0x165c: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1661;
x86_c0_l_1661:
	/* 0x1661: lea    rdx,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_1666;
x86_c0_l_1666:
	/* 0x1666: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
	goto x86_c0_l_166b;
x86_c0_l_166b:
	/* 0x166b: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_166d;
x86_c0_l_166d:
	/* 0x166d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_166f;
x86_c0_l_166f:
	/* 0x166f: mov    edx,0x2d0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 720ULL);
	goto x86_c0_l_1674;
x86_c0_l_1674:
	/* 0x1674: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1678;
x86_c0_l_1678:
	/* 0x1678: add    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_167b;
x86_c0_l_167b:
	/* 0x167b: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_1680;
x86_c0_l_1680:
	/* 0x1680: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1685;
x86_c0_l_1685:
	/* 0x1685: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_168a;
x86_c0_l_168a:
	/* 0x168a: add    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
	goto x86_c0_l_168e;
x86_c0_l_168e:
	/* 0x168e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1693;
x86_c0_l_1693:
	/* 0x1693: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1695;
x86_c0_l_1695:
	/* 0x1695: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_1698;
x86_c0_l_1698:
	/* 0x1698: je     16d5 <event_execve+0x16d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1698, 0x16d5, x86_c0_l_16d5);
	goto x86_c0_l_169a;
x86_c0_l_169a:
	/* 0x169a: neg    eax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_NEG, 0);
	goto x86_c0_l_169c;
x86_c0_l_169c:
	/* 0x169c: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_16a1;
x86_c0_l_16a1:
	/* 0x16a1: mov    WORD PTR [rsp+0x22],0x9 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 146028888073ULL);
	goto x86_c0_l_16a8;
x86_c0_l_16a8:
	/* 0x16a8: movabs rax,0x40000009b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 17179869339ULL);
	goto x86_c0_l_16b2;
x86_c0_l_16b2:
	/* 0x16b2: mov    QWORD PTR [rsp+0x24],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
	goto x86_c0_l_16b7;
x86_c0_l_16b7:
	/* 0x16b7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
	goto x86_c0_l_16be;
x86_c0_l_16be:
	/* 0x16be: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_16c3;
x86_c0_l_16c3:
	/* 0x16c3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_16c8;
x86_c0_l_16c8:
	/* 0x16c8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_16ca;
x86_c0_l_16ca:
	/* 0x16ca: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_16cd;
x86_c0_l_16cd:
	/* 0x16cd: je     1f0a <event_execve+0x1f0a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16cd, 0x1f0a, x86_c0_l_1f0a);
	goto x86_c0_l_16d3;
x86_c0_l_16d3:
	/* 0x16d3: inc    DWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
	goto x86_c0_l_16d5;
x86_c0_l_16d5:
	/* 0x16d5: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_16da;
x86_c0_l_16da:
	/* 0x16da: test   rdx,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64);
	goto x86_c0_l_16dd;
x86_c0_l_16dd:
	/* 0x16dd: je     1780 <event_execve+0x1780> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16dd, 0x1780, x86_c0_l_1780);
	goto x86_c0_l_16e3;
x86_c0_l_16e3:
	/* 0x16e3: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_16e8;
x86_c0_l_16e8:
	/* 0x16e8: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_16eb;
x86_c0_l_16eb:
	/* 0x16eb: je     1780 <event_execve+0x1780> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16eb, 0x1780, x86_c0_l_1780);
	goto x86_c0_l_16f1;
x86_c0_l_16f1:
	/* 0x16f1: mov    ecx,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_32);
	goto x86_c0_l_16f3;
x86_c0_l_16f3:
	/* 0x16f3: lea    rsi,[r14+rcx*1] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
	goto x86_c0_l_16f7;
x86_c0_l_16f7:
	/* 0x16f7: add    rsi,0x140 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 320ULL);
	goto x86_c0_l_16fe;
x86_c0_l_16fe:
	/* 0x16fe: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_1701;
x86_c0_l_1701:
	/* 0x1701: sub    r13,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RDX, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c0_l_1704;
x86_c0_l_1704:
	/* 0x1704: cmp    r13,0x3ff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 1023ULL);
	goto x86_c0_l_170b;
x86_c0_l_170b:
	/* 0x170b: ja     1754 <event_execve+0x1754> */
	X86_SIM_X86_JCC(X86_CC_A, 0x170b, 0x1754, x86_c0_l_1754);
	goto x86_c0_l_170d;
x86_c0_l_170d:
	/* 0x170d: lea    rcx,[r14+0x540] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1344ULL);
	goto x86_c0_l_1714;
x86_c0_l_1714:
	/* 0x1714: sub    rcx,rsi */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RSI, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c0_l_1717;
x86_c0_l_1717:
	/* 0x1717: cmp    r13,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R13, X86_RCX, X86_WIDTH_64);
	goto x86_c0_l_171a;
x86_c0_l_171a:
	/* 0x171a: jae    1754 <event_execve+0x1754> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x171a, 0x1754, x86_c0_l_1754);
	goto x86_c0_l_171c;
x86_c0_l_171c:
	/* 0x171c: dec    r13d */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_DEC, 1);
	goto x86_c0_l_171f;
x86_c0_l_171f:
	/* 0x171f: and    r13d,0x3ff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
	goto x86_c0_l_1726;
x86_c0_l_1726:
	/* 0x1726: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1728;
x86_c0_l_1728:
	/* 0x1728: cmp    rax,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64);
	goto x86_c0_l_172b;
x86_c0_l_172b:
	/* 0x172b: cmove  r13d,ebx */
	X86_SIM_L_EXEC_CMOV(X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_E);
	goto x86_c0_l_172f;
x86_c0_l_172f:
	/* 0x172f: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1734;
x86_c0_l_1734:
	/* 0x1734: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_1739;
x86_c0_l_1739:
	/* 0x1739: mov    rdi,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSI, X86_WIDTH_64);
	goto x86_c0_l_173c;
x86_c0_l_173c:
	/* 0x173c: mov    esi,r13d */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_32);
	goto x86_c0_l_173f;
x86_c0_l_173f:
	/* 0x173f: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1741;
x86_c0_l_1741:
	/* 0x1741: and    eax,0x80000000 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483648ULL);
	goto x86_c0_l_1746;
x86_c0_l_1746:
	/* 0x1746: mov    ecx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_32);
	goto x86_c0_l_1748;
x86_c0_l_1748:
	/* 0x1748: shr    ecx,0x1c */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHR, 28ULL);
	goto x86_c0_l_174b;
x86_c0_l_174b:
	/* 0x174b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_174e;
x86_c0_l_174e:
	/* 0x174e: cmovne r13d,ebx */
	X86_SIM_L_EXEC_CMOV(X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_NE);
	goto x86_c0_l_1752;
x86_c0_l_1752:
	/* 0x1752: jmp    1771 <event_execve+0x1771> */
	X86_SIM_X86_JMP(0x1752, 0x1771, x86_c0_l_1771);
x86_c0_l_1754:
	/* 0x1754: mov    rdi,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
	goto x86_c0_l_175c;
x86_c0_l_175c:
	/* 0x175c: mov    rcx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_175f;
x86_c0_l_175f:
	/* 0x175f: call   0 <event_execve> */
	X86_SIM_X86_CALL(x86_c17_l_205c, 0x1764ULL);
x86_c0_l_1764:
	/* 0x1764: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_1767;
x86_c0_l_1767:
	/* 0x1767: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1769;
x86_c0_l_1769:
	/* 0x1769: test   r13d,r13d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_32);
	goto x86_c0_l_176c;
x86_c0_l_176c:
	/* 0x176c: setne  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_NE);
	goto x86_c0_l_176f;
x86_c0_l_176f:
	/* 0x176f: add    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_ADD);
	goto x86_c0_l_1771;
x86_c0_l_1771:
	/* 0x1771: mov    WORD PTR [r14+0x17e],r13w */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 382ULL);
	goto x86_c0_l_1779;
x86_c0_l_1779:
	/* 0x1779: or     DWORD PTR [r14+0x15c],ecx */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_R14, X86_RCX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 348ULL);
	goto x86_c0_l_1780;
x86_c0_l_1780:
	/* 0x1780: mov    eax,DWORD PTR [r14+0x140] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
	goto x86_c0_l_1787;
x86_c0_l_1787:
	/* 0x1787: lea    ecx,[rax+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
	goto x86_c0_l_178b;
x86_c0_l_178b:
	/* 0x178b: mov    DWORD PTR [r14+0x140],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 320ULL);
	goto x86_c0_l_1792;
x86_c0_l_1792:
	/* 0x1792: mov    WORD PTR [r14],0x5 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
	goto x86_c0_l_1798;
x86_c0_l_1798:
	/* 0x1798: mov    rcx,QWORD PTR [r14+0x170] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 368ULL);
	goto x86_c0_l_179f;
x86_c0_l_179f:
	/* 0x179f: mov    QWORD PTR [r14+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
	goto x86_c0_l_17a3;
x86_c0_l_17a3:
	/* 0x17a3: lea    eax,[rax+r13*1+0x140] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 320ULL);
	goto x86_c0_l_17ab;
x86_c0_l_17ab:
	/* 0x17ab: mov    DWORD PTR [r14+0x4],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c0_l_17af;
x86_c0_l_17af:
	/* 0x17af: mov    r13,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
	goto x86_c0_l_17b7;
x86_c0_l_17b7:
	/* 0x17b7: lea    rdx,[r13+0xd00] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3328ULL);
	goto x86_c0_l_17be;
x86_c0_l_17be:
	/* 0x17be: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_17c3;
x86_c0_l_17c3:
	/* 0x17c3: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_17c8;
x86_c0_l_17c8:
	/* 0x17c8: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_17cd;
x86_c0_l_17cd:
	/* 0x17cd: lea    rbx,[r14+0xb8] */
	X86_SIM_L_EXEC_LEA(X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
	goto x86_c0_l_17d4;
x86_c0_l_17d4:
	/* 0x17d4: mov    r12d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_17da;
x86_c0_l_17da:
	/* 0x17da: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_17df;
x86_c0_l_17df:
	/* 0x17df: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_17e1;
x86_c0_l_17e1:
	/* 0x17e1: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_17e6;
x86_c0_l_17e6:
	/* 0x17e6: add    rcx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c0_l_17ea;
x86_c0_l_17ea:
	/* 0x17ea: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_17ef;
x86_c0_l_17ef:
	/* 0x17ef: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_17f4;
x86_c0_l_17f4:
	/* 0x17f4: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_17f9;
x86_c0_l_17f9:
	/* 0x17f9: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c0_l_17fd;
x86_c0_l_17fd:
	/* 0x17fd: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
	goto x86_c0_l_1800;
x86_c0_l_1800:
	/* 0x1800: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1805;
x86_c0_l_1805:
	/* 0x1805: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1807;
x86_c0_l_1807:
	/* 0x1807: lea    rdi,[r14+0xbc] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 188ULL);
	goto x86_c0_l_180e;
x86_c0_l_180e:
	/* 0x180e: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1813;
x86_c0_l_1813:
	/* 0x1813: add    rcx,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
	goto x86_c0_l_1817;
x86_c0_l_1817:
	/* 0x1817: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_181c;
x86_c0_l_181c:
	/* 0x181c: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1821;
x86_c0_l_1821:
	/* 0x1821: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1826;
x86_c0_l_1826:
	/* 0x1826: add    rdx,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
	goto x86_c0_l_182a;
x86_c0_l_182a:
	/* 0x182a: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_182f;
x86_c0_l_182f:
	/* 0x182f: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1831;
x86_c0_l_1831:
	/* 0x1831: lea    rdi,[r14+0xc8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
	goto x86_c0_l_1838;
x86_c0_l_1838:
	/* 0x1838: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_183d;
x86_c0_l_183d:
	/* 0x183d: add    rcx,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
	goto x86_c0_l_1841;
x86_c0_l_1841:
	/* 0x1841: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1846;
x86_c0_l_1846:
	/* 0x1846: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_184b;
x86_c0_l_184b:
	/* 0x184b: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1850;
x86_c0_l_1850:
	/* 0x1850: add    rdx,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
	goto x86_c0_l_1854;
x86_c0_l_1854:
	/* 0x1854: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1859;
x86_c0_l_1859:
	/* 0x1859: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_185b;
x86_c0_l_185b:
	/* 0x185b: lea    rdi,[r14+0xcc] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 204ULL);
	goto x86_c0_l_1862;
x86_c0_l_1862:
	/* 0x1862: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1867;
x86_c0_l_1867:
	/* 0x1867: add    rcx,0x1c */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 28ULL);
	goto x86_c0_l_186b;
x86_c0_l_186b:
	/* 0x186b: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1870;
x86_c0_l_1870:
	/* 0x1870: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1875;
x86_c0_l_1875:
	/* 0x1875: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_187a;
x86_c0_l_187a:
	/* 0x187a: add    rdx,0x1c */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 28ULL);
	goto x86_c0_l_187e;
x86_c0_l_187e:
	/* 0x187e: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1883;
x86_c0_l_1883:
	/* 0x1883: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1885;
x86_c0_l_1885:
	/* 0x1885: lea    rdi,[r14+0xc0] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
	goto x86_c0_l_188c;
x86_c0_l_188c:
	/* 0x188c: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1891;
x86_c0_l_1891:
	/* 0x1891: add    rcx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
	goto x86_c0_l_1895;
x86_c0_l_1895:
	/* 0x1895: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_189a;
x86_c0_l_189a:
	/* 0x189a: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_189f;
x86_c0_l_189f:
	/* 0x189f: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_18a4;
x86_c0_l_18a4:
	/* 0x18a4: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
	goto x86_c0_l_18a8;
x86_c0_l_18a8:
	/* 0x18a8: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_18ad;
x86_c0_l_18ad:
	/* 0x18ad: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_18af;
x86_c0_l_18af:
	/* 0x18af: lea    rdi,[r14+0xc4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 196ULL);
	goto x86_c0_l_18b6;
x86_c0_l_18b6:
	/* 0x18b6: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_18bb;
x86_c0_l_18bb:
	/* 0x18bb: add    rcx,0x14 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 20ULL);
	goto x86_c0_l_18bf;
x86_c0_l_18bf:
	/* 0x18bf: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_18c4;
x86_c0_l_18c4:
	/* 0x18c4: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_18c9;
x86_c0_l_18c9:
	/* 0x18c9: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_18ce;
x86_c0_l_18ce:
	/* 0x18ce: add    rdx,0x14 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 20ULL);
	goto x86_c0_l_18d2;
x86_c0_l_18d2:
	/* 0x18d2: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_18d7;
x86_c0_l_18d7:
	/* 0x18d7: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_18d9;
x86_c0_l_18d9:
	/* 0x18d9: lea    rdi,[r14+0xd0] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
	goto x86_c0_l_18e0;
x86_c0_l_18e0:
	/* 0x18e0: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_18e5;
x86_c0_l_18e5:
	/* 0x18e5: add    rcx,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
	goto x86_c0_l_18e9;
x86_c0_l_18e9:
	/* 0x18e9: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_18ee;
x86_c0_l_18ee:
	/* 0x18ee: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_18f3;
x86_c0_l_18f3:
	/* 0x18f3: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_18f8;
x86_c0_l_18f8:
	/* 0x18f8: add    rdx,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
	goto x86_c0_l_18fc;
x86_c0_l_18fc:
	/* 0x18fc: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1901;
x86_c0_l_1901:
	/* 0x1901: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1903;
x86_c0_l_1903:
	/* 0x1903: lea    rdi,[r14+0xd4] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
	goto x86_c0_l_190a;
x86_c0_l_190a:
	/* 0x190a: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_190f;
x86_c0_l_190f:
	/* 0x190f: add    rcx,0x24 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 36ULL);
	goto x86_c0_l_1913;
x86_c0_l_1913:
	/* 0x1913: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1918;
x86_c0_l_1918:
	/* 0x1918: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_191d;
x86_c0_l_191d:
	/* 0x191d: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1922;
x86_c0_l_1922:
	/* 0x1922: add    rdx,0x24 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 36ULL);
	goto x86_c0_l_1926;
x86_c0_l_1926:
	/* 0x1926: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_192b;
x86_c0_l_192b:
	/* 0x192b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_192d;
x86_c0_l_192d:
	/* 0x192d: lea    rdi,[r14+0xd8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
	goto x86_c0_l_1934;
x86_c0_l_1934:
	/* 0x1934: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1939;
x86_c0_l_1939:
	/* 0x1939: add    rcx,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
	goto x86_c0_l_193d;
x86_c0_l_193d:
	/* 0x193d: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1942;
x86_c0_l_1942:
	/* 0x1942: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1947;
x86_c0_l_1947:
	/* 0x1947: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_194c;
x86_c0_l_194c:
	/* 0x194c: add    rdx,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
	goto x86_c0_l_1950;
x86_c0_l_1950:
	/* 0x1950: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1955;
x86_c0_l_1955:
	/* 0x1955: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1957;
x86_c0_l_1957:
	/* 0x1957: mov    rbx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_195c;
x86_c0_l_195c:
	/* 0x195c: lea    rdi,[r14+0xe8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
	goto x86_c0_l_1963;
x86_c0_l_1963:
	/* 0x1963: lea    rdx,[rbx+0x40] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
	goto x86_c0_l_1967;
x86_c0_l_1967:
	/* 0x1967: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_196c;
x86_c0_l_196c:
	/* 0x196c: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1971;
x86_c0_l_1971:
	/* 0x1971: lea    r15,[r14+0xe0] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
	goto x86_c0_l_1978;
x86_c0_l_1978:
	/* 0x1978: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_197d;
x86_c0_l_197d:
	/* 0x197d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_197f;
x86_c0_l_197f:
	/* 0x197f: lea    rdi,[r14+0xf0] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
	goto x86_c0_l_1986;
x86_c0_l_1986:
	/* 0x1986: lea    rdx,[rbx+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
	goto x86_c0_l_198a;
x86_c0_l_198a:
	/* 0x198a: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_198f;
x86_c0_l_198f:
	/* 0x198f: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1994;
x86_c0_l_1994:
	/* 0x1994: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1999;
x86_c0_l_1999:
	/* 0x1999: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_199b;
x86_c0_l_199b:
	/* 0x199b: add    rbx,0x38 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
	goto x86_c0_l_199f;
x86_c0_l_199f:
	/* 0x199f: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_19a4;
x86_c0_l_19a4:
	/* 0x19a4: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_19a9;
x86_c0_l_19a9:
	/* 0x19a9: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
	goto x86_c0_l_19ac;
x86_c0_l_19ac:
	/* 0x19ac: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_19b1;
x86_c0_l_19b1:
	/* 0x19b1: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
	goto x86_c0_l_19b4;
x86_c0_l_19b4:
	/* 0x19b4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_19b6;
x86_c0_l_19b6:
	/* 0x19b6: mov    eax,DWORD PTR [r14+0xc8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
	goto x86_c0_l_19bd;
x86_c0_l_19bd:
	/* 0x19bd: mov    DWORD PTR [r14+0x154],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 340ULL);
	goto x86_c0_l_19c4;
x86_c0_l_19c4:
	/* 0x19c4: lea    rdx,[r13+0xd70] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3440ULL);
	goto x86_c0_l_19cb;
x86_c0_l_19cb:
	/* 0x19cb: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_19d0;
x86_c0_l_19d0:
	/* 0x19d0: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_19d5;
x86_c0_l_19d5:
	/* 0x19d5: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_19da;
x86_c0_l_19da:
	/* 0x19da: lea    rbx,[r14+0x108] */
	X86_SIM_L_EXEC_LEA(X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 264ULL);
	goto x86_c0_l_19e1;
x86_c0_l_19e1:
	/* 0x19e1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_19e6;
x86_c0_l_19e6:
	/* 0x19e6: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_19e8;
x86_c0_l_19e8:
	/* 0x19e8: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_19ed;
x86_c0_l_19ed:
	/* 0x19ed: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_19f2;
x86_c0_l_19f2:
	/* 0x19f2: mov    edx,0x48 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 72ULL);
	goto x86_c0_l_19f7;
x86_c0_l_19f7:
	/* 0x19f7: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_19fc;
x86_c0_l_19fc:
	/* 0x19fc: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_1a01;
x86_c0_l_1a01:
	/* 0x1a01: mov    esi,0x48 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 72ULL);
	goto x86_c0_l_1a06;
x86_c0_l_1a06:
	/* 0x1a06: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1a08;
x86_c0_l_1a08:
	/* 0x1a08: mov    edx,0x218 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 536ULL);
	goto x86_c0_l_1a0d;
x86_c0_l_1a0d:
	/* 0x1a0d: mov    rcx,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
	goto x86_c0_l_1a12;
x86_c0_l_1a12:
	/* 0x1a12: add    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_1a15;
x86_c0_l_1a15:
	/* 0x1a15: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1a1a;
x86_c0_l_1a1a:
	/* 0x1a1a: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1a1f;
x86_c0_l_1a1f:
	/* 0x1a1f: add    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
	goto x86_c0_l_1a24;
x86_c0_l_1a24:
	/* 0x1a24: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
	goto x86_c0_l_1a27;
x86_c0_l_1a27:
	/* 0x1a27: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1a2c;
x86_c0_l_1a2c:
	/* 0x1a2c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1a2e;
x86_c0_l_1a2e:
	/* 0x1a2e: lea    rdi,[r14+0x10c] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 268ULL);
	goto x86_c0_l_1a35;
x86_c0_l_1a35:
	/* 0x1a35: mov    edx,0x4d8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 1240ULL);
	goto x86_c0_l_1a3a;
x86_c0_l_1a3a:
	/* 0x1a3a: mov    rcx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
	goto x86_c0_l_1a3f;
x86_c0_l_1a3f:
	/* 0x1a3f: add    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_1a42;
x86_c0_l_1a42:
	/* 0x1a42: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1a47;
x86_c0_l_1a47:
	/* 0x1a47: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1a4c;
x86_c0_l_1a4c:
	/* 0x1a4c: add    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 48ULL);
	goto x86_c0_l_1a51;
x86_c0_l_1a51:
	/* 0x1a51: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1a56;
x86_c0_l_1a56:
	/* 0x1a56: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1a58;
x86_c0_l_1a58:
	/* 0x1a58: lea    rdi,[r14+0x110] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 272ULL);
	goto x86_c0_l_1a5f;
x86_c0_l_1a5f:
	/* 0x1a5f: mov    rcx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
	goto x86_c0_l_1a64;
x86_c0_l_1a64:
	/* 0x1a64: add    rcx,0x58 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 88ULL);
	goto x86_c0_l_1a68;
x86_c0_l_1a68:
	/* 0x1a68: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1a6d;
x86_c0_l_1a6d:
	/* 0x1a6d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1a72;
x86_c0_l_1a72:
	/* 0x1a72: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
	goto x86_c0_l_1a77;
x86_c0_l_1a77:
	/* 0x1a77: add    rdx,0x58 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 88ULL);
	goto x86_c0_l_1a7b;
x86_c0_l_1a7b:
	/* 0x1a7b: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1a80;
x86_c0_l_1a80:
	/* 0x1a80: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1a82;
x86_c0_l_1a82:
	/* 0x1a82: mov    QWORD PTR [rsp+0x18],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
	goto x86_c0_l_1a8b;
x86_c0_l_1a8b:
	/* 0x1a8b: lea    rdx,[r13+0xb58] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2904ULL);
	goto x86_c0_l_1a92;
x86_c0_l_1a92:
	/* 0x1a92: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_1a97;
x86_c0_l_1a97:
	/* 0x1a97: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1a9c;
x86_c0_l_1a9c:
	/* 0x1a9c: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1aa1;
x86_c0_l_1aa1:
	/* 0x1aa1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1aa6;
x86_c0_l_1aa6:
	/* 0x1aa6: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1aa8;
x86_c0_l_1aa8:
	/* 0x1aa8: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_1aad;
x86_c0_l_1aad:
	/* 0x1aad: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c0_l_1ab0;
x86_c0_l_1ab0:
	/* 0x1ab0: je     1b47 <event_execve+0x1b47> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ab0, 0x1b47, x86_c0_l_1b47);
	goto x86_c0_l_1ab6;
x86_c0_l_1ab6:
	/* 0x1ab6: mov    DWORD PTR [rsp+0x68],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
	goto x86_c0_l_1abe;
x86_c0_l_1abe:
	/* 0x1abe: add    rcx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
	goto x86_c0_l_1ac2;
x86_c0_l_1ac2:
	/* 0x1ac2: lea    rdi,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
	goto x86_c0_l_1ac7;
x86_c0_l_1ac7:
	/* 0x1ac7: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1acc;
x86_c0_l_1acc:
	/* 0x1acc: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_1ad1;
x86_c0_l_1ad1:
	/* 0x1ad1: add    rdx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
	goto x86_c0_l_1ad5;
x86_c0_l_1ad5:
	/* 0x1ad5: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1ada;
x86_c0_l_1ada:
	/* 0x1ada: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1adc;
x86_c0_l_1adc:
	/* 0x1adc: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_1ae1;
x86_c0_l_1ae1:
	/* 0x1ae1: movsxd rcx,DWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 104ULL);
	goto x86_c0_l_1ae6;
x86_c0_l_1ae6:
	/* 0x1ae6: shl    rcx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
	goto x86_c0_l_1aea;
x86_c0_l_1aea:
	/* 0x1aea: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_1aed;
x86_c0_l_1aed:
	/* 0x1aed: add    rcx,0x80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 128ULL);
	goto x86_c0_l_1af4;
x86_c0_l_1af4:
	/* 0x1af4: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_1af7;
x86_c0_l_1af7:
	/* 0x1af7: mov    edx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 16ULL);
	goto x86_c0_l_1afc;
x86_c0_l_1afc:
	/* 0x1afc: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1b01;
x86_c0_l_1b01:
	/* 0x1b01: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_1b06;
x86_c0_l_1b06:
	/* 0x1b06: movsxd rdx,DWORD PTR [rsp+0x68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 104ULL);
	goto x86_c0_l_1b0b;
x86_c0_l_1b0b:
	/* 0x1b0b: shl    rdx,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
	goto x86_c0_l_1b0f;
x86_c0_l_1b0f:
	/* 0x1b0f: add    rdx,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_1b12;
x86_c0_l_1b12:
	/* 0x1b12: add    rdx,0x80 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 128ULL);
	goto x86_c0_l_1b19;
x86_c0_l_1b19:
	/* 0x1b19: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
	goto x86_c0_l_1b1e;
x86_c0_l_1b1e:
	/* 0x1b1e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1b20;
x86_c0_l_1b20:
	/* 0x1b20: lea    rdi,[r14+0x114] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 276ULL);
	goto x86_c0_l_1b27;
x86_c0_l_1b27:
	/* 0x1b27: mov    edx,0x158 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 344ULL);
	goto x86_c0_l_1b2c;
x86_c0_l_1b2c:
	/* 0x1b2c: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
	goto x86_c0_l_1b31;
x86_c0_l_1b31:
	/* 0x1b31: add    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_1b34;
x86_c0_l_1b34:
	/* 0x1b34: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1b39;
x86_c0_l_1b39:
	/* 0x1b39: add    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
	goto x86_c0_l_1b3e;
x86_c0_l_1b3e:
	/* 0x1b3e: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1b43;
x86_c0_l_1b43:
	/* 0x1b43: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1b45;
x86_c0_l_1b45:
	/* 0x1b45: jmp    1b52 <event_execve+0x1b52> */
	X86_SIM_X86_JMP(0x1b45, 0x1b52, x86_c0_l_1b52);
x86_c0_l_1b47:
	/* 0x1b47: mov    DWORD PTR [r14+0x114],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1185410973696ULL);
	goto x86_c0_l_1b52;
x86_c0_l_1b52:
	/* 0x1b52: mov    r13,QWORD PTR [rsp+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
	goto x86_c0_l_1b5a;
x86_c0_l_1b5a:
	/* 0x1b5a: lea    rdi,[r14+0x118] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 280ULL);
	goto x86_c0_l_1b61;
x86_c0_l_1b61:
	/* 0x1b61: mov    ebx,0x158 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 344ULL);
	goto x86_c0_l_1b66;
x86_c0_l_1b66:
	/* 0x1b66: mov    rcx,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
	goto x86_c0_l_1b6b;
x86_c0_l_1b6b:
	/* 0x1b6b: add    rcx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_1b6e;
x86_c0_l_1b6e:
	/* 0x1b6e: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1b73;
x86_c0_l_1b73:
	/* 0x1b73: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1b78;
x86_c0_l_1b78:
	/* 0x1b78: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
	goto x86_c0_l_1b7d;
x86_c0_l_1b7d:
	/* 0x1b7d: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_1b80;
x86_c0_l_1b80:
	/* 0x1b80: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1b85;
x86_c0_l_1b85:
	/* 0x1b85: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1b87;
x86_c0_l_1b87:
	/* 0x1b87: lea    rdi,[r14+0x11c] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 284ULL);
	goto x86_c0_l_1b8e;
x86_c0_l_1b8e:
	/* 0x1b8e: mov    edx,0x118 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 280ULL);
	goto x86_c0_l_1b93;
x86_c0_l_1b93:
	/* 0x1b93: mov    rcx,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
	goto x86_c0_l_1b98;
x86_c0_l_1b98:
	/* 0x1b98: add    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_1b9b;
x86_c0_l_1b9b:
	/* 0x1b9b: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1ba0;
x86_c0_l_1ba0:
	/* 0x1ba0: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1ba5;
x86_c0_l_1ba5:
	/* 0x1ba5: add    rdx,QWORD PTR [rsp+0x48] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 72ULL);
	goto x86_c0_l_1baa;
x86_c0_l_1baa:
	/* 0x1baa: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1baf;
x86_c0_l_1baf:
	/* 0x1baf: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1bb1;
x86_c0_l_1bb1:
	/* 0x1bb1: lea    rdi,[r14+0x120] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 288ULL);
	goto x86_c0_l_1bb8;
x86_c0_l_1bb8:
	/* 0x1bb8: mov    r15d,0x98 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_32, 152ULL);
	goto x86_c0_l_1bbe;
x86_c0_l_1bbe:
	/* 0x1bbe: mov    rcx,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
	goto x86_c0_l_1bc3;
x86_c0_l_1bc3:
	/* 0x1bc3: add    rcx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_1bc6;
x86_c0_l_1bc6:
	/* 0x1bc6: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1bcb;
x86_c0_l_1bcb:
	/* 0x1bcb: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1bd0;
x86_c0_l_1bd0:
	/* 0x1bd0: mov    rdx,QWORD PTR [rsp+0x50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
	goto x86_c0_l_1bd5;
x86_c0_l_1bd5:
	/* 0x1bd5: add    rdx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_1bd8;
x86_c0_l_1bd8:
	/* 0x1bd8: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1bdd;
x86_c0_l_1bdd:
	/* 0x1bdd: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1bdf;
x86_c0_l_1bdf:
	/* 0x1bdf: lea    rdi,[r14+0x124] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 292ULL);
	goto x86_c0_l_1be6;
x86_c0_l_1be6:
	/* 0x1be6: mov    rcx,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
	goto x86_c0_l_1beb;
x86_c0_l_1beb:
	/* 0x1beb: add    rcx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_1bee;
x86_c0_l_1bee:
	/* 0x1bee: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1bf3;
x86_c0_l_1bf3:
	/* 0x1bf3: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1bf8;
x86_c0_l_1bf8:
	/* 0x1bf8: add    r15,QWORD PTR [rsp+0x58] */
	X86_SIM_L_EXEC_ALU_MEM(X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 88ULL);
	goto x86_c0_l_1bfd;
x86_c0_l_1bfd:
	/* 0x1bfd: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1c02;
x86_c0_l_1c02:
	/* 0x1c02: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c0_l_1c05;
x86_c0_l_1c05:
	/* 0x1c05: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1c07;
x86_c0_l_1c07:
	/* 0x1c07: lea    rdi,[r14+0x128] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 296ULL);
	goto x86_c0_l_1c0e;
x86_c0_l_1c0e:
	/* 0x1c0e: mov    rcx,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
	goto x86_c0_l_1c13;
x86_c0_l_1c13:
	/* 0x1c13: add    rcx,0x58 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 88ULL);
	goto x86_c0_l_1c17;
x86_c0_l_1c17:
	/* 0x1c17: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1c1c;
x86_c0_l_1c1c:
	/* 0x1c1c: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1c21;
x86_c0_l_1c21:
	/* 0x1c21: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
	goto x86_c0_l_1c26;
x86_c0_l_1c26:
	/* 0x1c26: add    rdx,0x58 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 88ULL);
	goto x86_c0_l_1c2a;
x86_c0_l_1c2a:
	/* 0x1c2a: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1c2f;
x86_c0_l_1c2f:
	/* 0x1c2f: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1c31;
x86_c0_l_1c31:
	/* 0x1c31: mov    QWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1c39;
x86_c0_l_1c39:
	/* 0x1c39: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
	goto x86_c0_l_1c41;
x86_c0_l_1c41:
	/* 0x1c41: lea    rdx,[rax+0xa78] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2680ULL);
	goto x86_c0_l_1c48;
x86_c0_l_1c48:
	/* 0x1c48: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_1c4b;
x86_c0_l_1c4b:
	/* 0x1c4b: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1c50;
x86_c0_l_1c50:
	/* 0x1c50: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1c55;
x86_c0_l_1c55:
	/* 0x1c55: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1c5a;
x86_c0_l_1c5a:
	/* 0x1c5a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1c5c;
x86_c0_l_1c5c:
	/* 0x1c5c: mov    edx,0x5a0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 1440ULL);
	goto x86_c0_l_1c61;
x86_c0_l_1c61:
	/* 0x1c61: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1c65;
x86_c0_l_1c65:
	/* 0x1c65: add    rcx,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_1c68;
x86_c0_l_1c68:
	/* 0x1c68: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_1c6d;
x86_c0_l_1c6d:
	/* 0x1c6d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1c72;
x86_c0_l_1c72:
	/* 0x1c72: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1c77;
x86_c0_l_1c77:
	/* 0x1c77: add    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
	goto x86_c0_l_1c7b;
x86_c0_l_1c7b:
	/* 0x1c7b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1c80;
x86_c0_l_1c80:
	/* 0x1c80: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1c82;
x86_c0_l_1c82:
	/* 0x1c82: lea    rdi,[r14+0x12c] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 300ULL);
	goto x86_c0_l_1c89;
x86_c0_l_1c89:
	/* 0x1c89: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_1c8e;
x86_c0_l_1c8e:
	/* 0x1c8e: add    rcx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c0_l_1c91;
x86_c0_l_1c91:
	/* 0x1c91: mov    edx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1c96;
x86_c0_l_1c96:
	/* 0x1c96: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1c9b;
x86_c0_l_1c9b:
	/* 0x1c9b: add    rbx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RBX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 24ULL);
	goto x86_c0_l_1ca0;
x86_c0_l_1ca0:
	/* 0x1ca0: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1ca5;
x86_c0_l_1ca5:
	/* 0x1ca5: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
	goto x86_c0_l_1ca8;
x86_c0_l_1ca8:
	/* 0x1ca8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1caa;
x86_c0_l_1caa:
	/* 0x1caa: lea    r12,[r14+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_1cae;
x86_c0_l_1cae:
	/* 0x1cae: mov    DWORD PTR [rsp+0x18],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
	goto x86_c0_l_1cb6;
x86_c0_l_1cb6:
	/* 0x1cb6: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1cb8;
x86_c0_l_1cb8:
	/* 0x1cb8: mov    edx,0x90 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 144ULL);
	goto x86_c0_l_1cbd;
x86_c0_l_1cbd:
	/* 0x1cbd: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c0_l_1cc0;
x86_c0_l_1cc0:
	/* 0x1cc0: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1cc2;
x86_c0_l_1cc2:
	/* 0x1cc2: call   1cc7 <event_execve+0x1cc7> */
	X86_SIM_L_EXEC_CALL_MEMSET(144ULL);
	goto x86_c0_l_1cc7;
x86_c0_l_1cc7:
	/* 0x1cc7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c0_l_1cce;
x86_c0_l_1cce:
	/* 0x1cce: lea    rsi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_1cd3;
x86_c0_l_1cd3:
	/* 0x1cd3: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_1cd8;
x86_c0_l_1cd8:
	/* 0x1cd8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1cda;
x86_c0_l_1cda:
	/* 0x1cda: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_1cdd;
x86_c0_l_1cdd:
	/* 0x1cdd: je     1cf0 <event_execve+0x1cf0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cdd, 0x1cf0, x86_c0_l_1cf0);
	goto x86_c0_l_1cdf;
x86_c0_l_1cdf:
	/* 0x1cdf: mov    ebx,DWORD PTR [rax+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_1ce2;
x86_c0_l_1ce2:
	/* 0x1ce2: cmp    QWORD PTR [rax+0x20],0x63677270 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 139106677360ULL);
	goto x86_c0_l_1cea;
x86_c0_l_1cea:
	/* 0x1cea: sete   bpl */
	X86_SIM_L_EXEC_SETCC(X86_RBP, X86_CC_E);
	goto x86_c0_l_1cee;
x86_c0_l_1cee:
	/* 0x1cee: jmp    1cf2 <event_execve+0x1cf2> */
	X86_SIM_X86_JMP(0x1cee, 0x1cf2, x86_c0_l_1cf2);
x86_c0_l_1cf0:
	/* 0x1cf0: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1cf2;
x86_c0_l_1cf2:
	/* 0x1cf2: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
	goto x86_c0_l_1cfb;
x86_c0_l_1cfb:
	/* 0x1cfb: mov    rdx,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
	goto x86_c0_l_1d03;
x86_c0_l_1d03:
	/* 0x1d03: add    rdx,0xf88 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 3976ULL);
	goto x86_c0_l_1d0a;
x86_c0_l_1d0a:
	/* 0x1d0a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_1d0d;
x86_c0_l_1d0d:
	/* 0x1d0d: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1d12;
x86_c0_l_1d12:
	/* 0x1d12: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_1d17;
x86_c0_l_1d17:
	/* 0x1d17: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1d1c;
x86_c0_l_1d1c:
	/* 0x1d1c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1d1e;
x86_c0_l_1d1e:
	/* 0x1d1e: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1d22;
x86_c0_l_1d22:
	/* 0x1d22: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c0_l_1d25;
x86_c0_l_1d25:
	/* 0x1d25: je     1f54 <event_execve+0x1f54> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d25, 0x1f54, x86_c0_l_1f54);
	goto x86_c0_l_1d2b;
x86_c0_l_1d2b:
	/* 0x1d2b: test   bpl,bpl */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8);
	goto x86_c0_l_1d2e;
x86_c0_l_1d2e:
	/* 0x1d2e: je     1da3 <event_execve+0x1da3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d2e, 0x1da3, x86_c0_l_1da3);
	goto x86_c0_l_1d30;
x86_c0_l_1d30:
	/* 0x1d30: add    rcx,0x78 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
	goto x86_c0_l_1d34;
x86_c0_l_1d34:
	/* 0x1d34: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_1d39;
x86_c0_l_1d39:
	/* 0x1d39: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1d3e;
x86_c0_l_1d3e:
	/* 0x1d3e: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_1d43;
x86_c0_l_1d43:
	/* 0x1d43: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1d47;
x86_c0_l_1d47:
	/* 0x1d47: add    rdx,0x78 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
	goto x86_c0_l_1d4b;
x86_c0_l_1d4b:
	/* 0x1d4b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1d50;
x86_c0_l_1d50:
	/* 0x1d50: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1d52;
x86_c0_l_1d52:
	/* 0x1d52: mov    rbx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_1d57;
x86_c0_l_1d57:
	/* 0x1d57: test   rbx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64);
	goto x86_c0_l_1d5a;
x86_c0_l_1d5a:
	/* 0x1d5a: je     1f54 <event_execve+0x1f54> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d5a, 0x1f54, x86_c0_l_1f54);
	goto x86_c0_l_1d60;
x86_c0_l_1d60:
	/* 0x1d60: mov    eax,0x50 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 80ULL);
	goto x86_c0_l_1d65;
x86_c0_l_1d65:
	/* 0x1d65: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x50ULL: X86_SIM_BPF_CALL_bpf_get_current_cgroup_id(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x50ULL: X86_SIM_BPF_CALL_bpf_get_current_cgroup_id(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1d67;
x86_c0_l_1d67:
	/* 0x1d67: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1d69;
x86_c0_l_1d69:
	/* 0x1d69: mov    QWORD PTR [r12],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1d6d;
x86_c0_l_1d6d:
	/* 0x1d6d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_1d70;
x86_c0_l_1d70:
	/* 0x1d70: je     1e72 <event_execve+0x1e72> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d70, 0x1e72, x86_c0_l_1e72);
	goto x86_c0_l_1d76;
x86_c0_l_1d76:
	/* 0x1d76: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1d7b;
x86_c0_l_1d7b:
	/* 0x1d7b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_cgtracker_map));
	goto x86_c0_l_1d82;
x86_c0_l_1d82:
	/* 0x1d82: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1d87;
x86_c0_l_1d87:
	/* 0x1d87: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_1d8c;
x86_c0_l_1d8c:
	/* 0x1d8c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1d8e;
x86_c0_l_1d8e:
	/* 0x1d8e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_1d91;
x86_c0_l_1d91:
	/* 0x1d91: je     1e7a <event_execve+0x1e7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d91, 0x1e7a, x86_c0_l_1e7a);
	goto x86_c0_l_1d97;
x86_c0_l_1d97:
	/* 0x1d97: mov    rax,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1d9a;
x86_c0_l_1d9a:
	/* 0x1d9a: mov    QWORD PTR [r14+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_1d9e;
x86_c0_l_1d9e:
	/* 0x1d9e: jmp    1e80 <event_execve+0x1e80> */
	X86_SIM_X86_JMP(0x1d9e, 0x1e80, x86_c0_l_1e80);
x86_c0_l_1da3:
	/* 0x1da3: cmp    ebx,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 11ULL);
	goto x86_c0_l_1da6;
x86_c0_l_1da6:
	/* 0x1da6: ja     1f54 <event_execve+0x1f54> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1da6, 0x1f54, x86_c0_l_1f54);
	goto x86_c0_l_1dac;
x86_c0_l_1dac:
	/* 0x1dac: mov    edx,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_32);
	goto x86_c0_l_1dae;
x86_c0_l_1dae:
	/* 0x1dae: lea    rcx,[rcx+rdx*8] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 3), 0ULL);
	goto x86_c0_l_1db2;
x86_c0_l_1db2:
	/* 0x1db2: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1db7;
x86_c0_l_1db7:
	/* 0x1db7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1dbc;
x86_c0_l_1dbc:
	/* 0x1dbc: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_1dc1;
x86_c0_l_1dc1:
	/* 0x1dc1: shl    rdx,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_SHL, 3ULL);
	goto x86_c0_l_1dc5;
x86_c0_l_1dc5:
	/* 0x1dc5: add    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
	goto x86_c0_l_1dc9;
x86_c0_l_1dc9:
	/* 0x1dc9: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1dce;
x86_c0_l_1dce:
	/* 0x1dce: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1dd0;
x86_c0_l_1dd0:
	/* 0x1dd0: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1dd5;
x86_c0_l_1dd5:
	/* 0x1dd5: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c0_l_1dd8;
x86_c0_l_1dd8:
	/* 0x1dd8: je     1f41 <event_execve+0x1f41> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1dd8, 0x1f41, x86_c0_l_1f41);
	goto x86_c0_l_1dde;
x86_c0_l_1dde:
	/* 0x1dde: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_1de3;
x86_c0_l_1de3:
	/* 0x1de3: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1de8;
x86_c0_l_1de8:
	/* 0x1de8: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_1ded;
x86_c0_l_1ded:
	/* 0x1ded: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1df2;
x86_c0_l_1df2:
	/* 0x1df2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1df7;
x86_c0_l_1df7:
	/* 0x1df7: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1df9;
x86_c0_l_1df9:
	/* 0x1df9: mov    rbx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_1dfe;
x86_c0_l_1dfe:
	/* 0x1dfe: test   rbx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64);
	goto x86_c0_l_1e01;
x86_c0_l_1e01:
	/* 0x1e01: je     1f54 <event_execve+0x1f54> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e01, 0x1f54, x86_c0_l_1f54);
	goto x86_c0_l_1e07;
x86_c0_l_1e07:
	/* 0x1e07: xor    ebp,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1e09;
x86_c0_l_1e09:
	/* 0x1e09: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
	goto x86_c0_l_1e12;
x86_c0_l_1e12:
	/* 0x1e12: lea    rdx,[rbx+0x100] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
	goto x86_c0_l_1e19;
x86_c0_l_1e19:
	/* 0x1e19: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1e1e;
x86_c0_l_1e1e:
	/* 0x1e1e: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1e23;
x86_c0_l_1e23:
	/* 0x1e23: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_1e28;
x86_c0_l_1e28:
	/* 0x1e28: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1e2d;
x86_c0_l_1e2d:
	/* 0x1e2d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1e2f;
x86_c0_l_1e2f:
	/* 0x1e2f: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1e34;
x86_c0_l_1e34:
	/* 0x1e34: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
	goto x86_c0_l_1e3d;
x86_c0_l_1e3d:
	/* 0x1e3d: test   rdx,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64);
	goto x86_c0_l_1e40;
x86_c0_l_1e40:
	/* 0x1e40: je     1ef6 <event_execve+0x1ef6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e40, 0x1ef6, x86_c0_l_1ef6);
	goto x86_c0_l_1e46;
x86_c0_l_1e46:
	/* 0x1e46: add    rdx,0x60 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 96ULL);
	goto x86_c0_l_1e4a;
x86_c0_l_1e4a:
	/* 0x1e4a: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1e4f;
x86_c0_l_1e4f:
	/* 0x1e4f: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1e54;
x86_c0_l_1e54:
	/* 0x1e54: mov    eax,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 113ULL);
	goto x86_c0_l_1e59;
x86_c0_l_1e59:
	/* 0x1e59: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1e5e;
x86_c0_l_1e5e:
	/* 0x1e5e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1e60;
x86_c0_l_1e60:
	/* 0x1e60: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1e65;
x86_c0_l_1e65:
	/* 0x1e65: mov    QWORD PTR [r12],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1e69;
x86_c0_l_1e69:
	/* 0x1e69: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_1e6c;
x86_c0_l_1e6c:
	/* 0x1e6c: jne    1d76 <event_execve+0x1d76> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e6c, 0x1d76, x86_c0_l_1d76);
	goto x86_c0_l_1e72;
x86_c0_l_1e72:
	/* 0x1e72: or     ebp,0x200000 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_32, X86_ALU_OR, 2097152ULL);
	goto x86_c0_l_1e78;
x86_c0_l_1e78:
	/* 0x1e78: jmp    1e80 <event_execve+0x1e80> */
	X86_SIM_X86_JMP(0x1e78, 0x1e80, x86_c0_l_1e80);
x86_c0_l_1e7a:
	/* 0x1e7a: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1e7c;
x86_c0_l_1e7c:
	/* 0x1e7c: mov    QWORD PTR [r14+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c0_l_1e80;
x86_c0_l_1e80:
	/* 0x1e80: add    rbx,0x100 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 256ULL);
	goto x86_c0_l_1e87;
x86_c0_l_1e87:
	/* 0x1e87: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
	goto x86_c0_l_1e8a;
x86_c0_l_1e8a:
	/* 0x1e8a: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1e8f;
x86_c0_l_1e8f:
	/* 0x1e8f: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1e94;
x86_c0_l_1e94:
	/* 0x1e94: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1e99;
x86_c0_l_1e99:
	/* 0x1e99: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
	goto x86_c0_l_1e9c;
x86_c0_l_1e9c:
	/* 0x1e9c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1e9e;
x86_c0_l_1e9e:
	/* 0x1e9e: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1ea2;
x86_c0_l_1ea2:
	/* 0x1ea2: add    rcx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
	goto x86_c0_l_1ea6;
x86_c0_l_1ea6:
	/* 0x1ea6: lea    rdi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1eab;
x86_c0_l_1eab:
	/* 0x1eab: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1eb0;
x86_c0_l_1eb0:
	/* 0x1eb0: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c0_l_1eb5;
x86_c0_l_1eb5:
	/* 0x1eb5: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1eb9;
x86_c0_l_1eb9:
	/* 0x1eb9: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
	goto x86_c0_l_1ebd;
x86_c0_l_1ebd:
	/* 0x1ebd: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
	goto x86_c0_l_1ec2;
x86_c0_l_1ec2:
	/* 0x1ec2: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1ec4;
x86_c0_l_1ec4:
	/* 0x1ec4: mov    ecx,0x10000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 65536ULL);
	goto x86_c0_l_1ec9;
x86_c0_l_1ec9:
	/* 0x1ec9: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_1ecc;
x86_c0_l_1ecc:
	/* 0x1ecc: jne    1ef2 <event_execve+0x1ef2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ecc, 0x1ef2, x86_c0_l_1ef2);
	goto x86_c0_l_1ece;
x86_c0_l_1ece:
	/* 0x1ece: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1ed3;
x86_c0_l_1ed3:
	/* 0x1ed3: test   rdx,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64);
	goto x86_c0_l_1ed6;
x86_c0_l_1ed6:
	/* 0x1ed6: je     1ef2 <event_execve+0x1ef2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ed6, 0x1ef2, x86_c0_l_1ef2);
	goto x86_c0_l_1ed8;
x86_c0_l_1ed8:
	/* 0x1ed8: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
	goto x86_c0_l_1edb;
x86_c0_l_1edb:
	/* 0x1edb: add    rdi,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
	goto x86_c0_l_1edf;
x86_c0_l_1edf:
	/* 0x1edf: mov    ecx,0x80 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 128ULL);
	goto x86_c0_l_1ee4;
x86_c0_l_1ee4:
	/* 0x1ee4: mov    eax,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 45ULL);
	goto x86_c0_l_1ee9;
x86_c0_l_1ee9:
	/* 0x1ee9: mov    esi,0x80 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 128ULL);
	goto x86_c0_l_1eee;
x86_c0_l_1eee:
	/* 0x1eee: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1ef0;
x86_c0_l_1ef0:
	/* 0x1ef0: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1ef2;
x86_c0_l_1ef2:
	/* 0x1ef2: or     ecx,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_32, X86_ALU_OR);
	goto x86_c0_l_1ef4;
x86_c0_l_1ef4:
	/* 0x1ef4: jmp    1f56 <event_execve+0x1f56> */
	X86_SIM_X86_JMP(0x1ef4, 0x1f56, x86_c0_l_1f56);
x86_c0_l_1ef6:
	/* 0x1ef6: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1ef8;
x86_c0_l_1ef8:
	/* 0x1ef8: mov    QWORD PTR [r12],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_1efc;
x86_c0_l_1efc:
	/* 0x1efc: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c0_l_1eff;
x86_c0_l_1eff:
	/* 0x1eff: jne    1d76 <event_execve+0x1d76> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1eff, 0x1d76, x86_c0_l_1d76);
	goto x86_c0_l_1f05;
x86_c0_l_1f05:
	/* 0x1f05: jmp    1e72 <event_execve+0x1e72> */
	X86_SIM_X86_JMP(0x1f05, 0x1e72, x86_c0_l_1e72);
x86_c0_l_1f0a:
	/* 0x1f0a: mov    DWORD PTR [rsp+0x68],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 446676598785ULL);
	goto x86_c0_l_1f12;
x86_c0_l_1f12:
	/* 0x1f12: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_errmetrics_map));
	goto x86_c0_l_1f19;
x86_c0_l_1f19:
	/* 0x1f19: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1f1b;
x86_c0_l_1f1b:
	/* 0x1f1b: lea    rsi,[rsp+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c0_l_1f20;
x86_c0_l_1f20:
	/* 0x1f20: lea    rdx,[rsp+0x68] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
	goto x86_c0_l_1f25;
x86_c0_l_1f25:
	/* 0x1f25: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
	goto x86_c0_l_1f2a;
x86_c0_l_1f2a:
	/* 0x1f2a: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1f2c;
x86_c0_l_1f2c:
	/* 0x1f2c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1f2e;
x86_c0_l_1f2e:
	/* 0x1f2e: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_1f33;
x86_c0_l_1f33:
	/* 0x1f33: test   rdx,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64);
	goto x86_c0_l_1f36;
x86_c0_l_1f36:
	/* 0x1f36: jne    16e3 <event_execve+0x16e3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f36, 0x16e3, x86_c0_l_16e3);
	goto x86_c0_l_1f3c;
x86_c0_l_1f3c:
	/* 0x1f3c: jmp    1780 <event_execve+0x1780> */
	X86_SIM_X86_JMP(0x1f3c, 0x1780, x86_c0_l_1780);
x86_c0_l_1f41:
	/* 0x1f41: mov    rbx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c0_l_1f46;
x86_c0_l_1f46:
	/* 0x1f46: mov    ebp,0x80000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 524288ULL);
	goto x86_c0_l_1f4b;
x86_c0_l_1f4b:
	/* 0x1f4b: test   rbx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64);
	goto x86_c0_l_1f4e;
x86_c0_l_1f4e:
	/* 0x1f4e: jne    1e09 <event_execve+0x1e09> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f4e, 0x1e09, x86_c0_l_1e09);
	goto x86_c0_l_1f54;
x86_c0_l_1f54:
	/* 0x1f54: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1f56;
x86_c0_l_1f56:
	/* 0x1f56: or     DWORD PTR [r14+0x15c],ecx */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_R14, X86_RCX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 348ULL);
	goto x86_c0_l_1f5d;
x86_c0_l_1f5d:
	/* 0x1f5d: mov    QWORD PTR [r14+0x130],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1305670057984ULL);
	goto x86_c0_l_1f68;
x86_c0_l_1f68:
	/* 0x1f68: mov    QWORD PTR [r14+0x138],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1340029796352ULL);
	goto x86_c0_l_1f73;
x86_c0_l_1f73:
	/* 0x1f73: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)execve_calls));
	goto x86_c0_l_1f7a;
x86_c0_l_1f7a:
	/* 0x1f7a: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1f7c;
x86_c0_l_1f7c:
	/* 0x1f7c: mov    eax,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 12ULL);
	goto x86_c0_l_1f81;
x86_c0_l_1f81:
	/* 0x1f81: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
	goto x86_c0_l_1f84;
x86_c0_l_1f84:
	/* 0x1f84: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1f86;
x86_c0_l_1f86:
	/* 0x1f86: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c0_l_1f88;
x86_c0_l_1f88:
	/* 0x1f88: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c0_l_1f8a;
x86_c0_l_1f8a:
	/* 0x1f8a: add    rsp,0xc8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 200ULL);
	goto x86_c0_l_1f91;
x86_c0_l_1f91:
	/* 0x1f91: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c0_l_1f92;
x86_c0_l_1f92:
	/* 0x1f92: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c0_l_1f94;
x86_c0_l_1f94:
	/* 0x1f94: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
	goto x86_c0_l_1f96;
x86_c0_l_1f96:
	/* 0x1f96: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c0_l_1f98;
x86_c0_l_1f98:
	/* 0x1f98: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c0_l_1f9a;
x86_c0_l_1f9a:
	/* 0x1f9a: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
	goto x86_c0_l_1f9b;
x86_c0_l_1f9b:
	/* 0x1f9b: jmp    2820 <__do_str+0x1bf> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_c1_l_1fa0:
	/* 0x1fa0: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c1_l_1fa2;
x86_c1_l_1fa2:
	/* 0x1fa2: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c1_l_1fa4;
x86_c1_l_1fa4:
	/* 0x1fa4: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
	goto x86_c1_l_1fa6;
x86_c1_l_1fa6:
	/* 0x1fa6: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c1_l_1fa8;
x86_c1_l_1fa8:
	/* 0x1fa8: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c1_l_1fa9;
x86_c1_l_1fa9:
	/* 0x1fa9: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
	goto x86_c1_l_1fad;
x86_c1_l_1fad:
	/* 0x1fad: mov    r14,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDX, X86_WIDTH_64);
	goto x86_c1_l_1fb0;
x86_c1_l_1fb0:
	/* 0x1fb0: mov    rbx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RSI, X86_WIDTH_64);
	goto x86_c1_l_1fb3;
x86_c1_l_1fb3:
	/* 0x1fb3: mov    r15,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RDI, X86_WIDTH_64);
	goto x86_c1_l_1fb6;
x86_c1_l_1fb6:
	/* 0x1fb6: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
	goto x86_c1_l_1fbe;
x86_c1_l_1fbe:
	/* 0x1fbe: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)data_heap));
	goto x86_c1_l_1fc5;
x86_c1_l_1fc5:
	/* 0x1fc5: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
	goto x86_c1_l_1fca;
x86_c1_l_1fca:
	/* 0x1fca: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c1_l_1fcf;
x86_c1_l_1fcf:
	/* 0x1fcf: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c1_l_1fd1;
x86_c1_l_1fd1:
	/* 0x1fd1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c1_l_1fd4;
x86_c1_l_1fd4:
	/* 0x1fd4: je     204c <data_event_str+0xac> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fd4, 0x204c, x86_c1_l_204c);
	goto x86_c1_l_1fd6;
x86_c1_l_1fd6:
	/* 0x1fd6: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
	goto x86_c1_l_1fd9;
x86_c1_l_1fd9:
	/* 0x1fd9: mov    DWORD PTR [rax],0x18 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c1_l_1fdf;
x86_c1_l_1fdf:
	/* 0x1fdf: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
	goto x86_c1_l_1fe4;
x86_c1_l_1fe4:
	/* 0x1fe4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c1_l_1fe6;
x86_c1_l_1fe6:
	/* 0x1fe6: mov    r13,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_R12, X86_WIDTH_64);
	goto x86_c1_l_1fe9;
x86_c1_l_1fe9:
	/* 0x1fe9: add    r13,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
	goto x86_c1_l_1fed;
x86_c1_l_1fed:
	/* 0x1fed: mov    QWORD PTR [r12+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c1_l_1ff2;
x86_c1_l_1ff2:
	/* 0x1ff2: cmp    rax,0xffffffffffffffea */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 18446744073709551594ULL);
	goto x86_c1_l_1ff6;
x86_c1_l_1ff6:
	/* 0x1ff6: jne    2000 <data_event_str+0x60> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ff6, 0x2000, x86_c1_l_2000);
	goto x86_c1_l_1ff8;
x86_c1_l_1ff8:
	/* 0x1ff8: mov    rax,QWORD PTR [r15+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c1_l_1ffc;
x86_c1_l_1ffc:
	/* 0x1ffc: mov    QWORD PTR [r13+0x0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c1_l_2000;
x86_c1_l_2000:
	/* 0x2000: mov    eax,0x7d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 125ULL);
	goto x86_c1_l_2005;
x86_c1_l_2005:
	/* 0x2005: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x7dULL: X86_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x7dULL: X86_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c1_l_2007;
x86_c1_l_2007:
	/* 0x2007: mov    QWORD PTR [r12+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c1_l_200c;
x86_c1_l_200c:
	/* 0x200c: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c1_l_2010;
x86_c1_l_2010:
	/* 0x2010: mov    rcx,QWORD PTR [r13+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
	goto x86_c1_l_2014;
x86_c1_l_2014:
	/* 0x2014: mov    QWORD PTR [rbx+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c1_l_2018;
x86_c1_l_2018:
	/* 0x2018: mov    QWORD PTR [rbx+0x18],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c1_l_201c;
x86_c1_l_201c:
	/* 0x201c: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
	goto x86_c1_l_201f;
x86_c1_l_201f:
	/* 0x201f: mov    rsi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R12, X86_WIDTH_64);
	goto x86_c1_l_2022;
x86_c1_l_2022:
	/* 0x2022: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
	goto x86_c1_l_2025;
x86_c1_l_2025:
	/* 0x2025: call   2602 <do_str> */
	X86_SIM_X86_CALL(x86_c2_l_2602, 0x202aULL);
x86_c1_l_202a:
	/* 0x202a: mov    ecx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_32);
	goto x86_c1_l_202c;
x86_c1_l_202c:
	/* 0x202c: sar    ecx,0x1f */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SAR, 31ULL);
	goto x86_c1_l_202f;
x86_c1_l_202f:
	/* 0x202f: and    ecx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_AND);
	goto x86_c1_l_2031;
x86_c1_l_2031:
	/* 0x2031: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c1_l_2033;
x86_c1_l_2033:
	/* 0x2033: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c1_l_2035;
x86_c1_l_2035:
	/* 0x2035: mov    DWORD PTR [rbx],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c1_l_2037;
x86_c1_l_2037:
	/* 0x2037: cmovg  edx,eax */
	X86_SIM_L_EXEC_CMOV(X86_RDX, X86_RAX, X86_WIDTH_32, X86_CC_G);
	goto x86_c1_l_203a;
x86_c1_l_203a:
	/* 0x203a: mov    QWORD PTR [rbx+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c1_l_2042;
x86_c1_l_2042:
	/* 0x2042: mov    DWORD PTR [rbx+0xc],edx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
	goto x86_c1_l_2045;
x86_c1_l_2045:
	/* 0x2045: mov    eax,0x20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 32ULL);
	goto x86_c1_l_204a;
x86_c1_l_204a:
	/* 0x204a: jmp    204e <data_event_str+0xae> */
	X86_SIM_X86_JMP(0x204a, 0x204e, x86_c1_l_204e);
x86_c1_l_204c:
	/* 0x204c: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c1_l_204e;
x86_c1_l_204e:
	/* 0x204e: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
	goto x86_c1_l_2052;
x86_c1_l_2052:
	/* 0x2052: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c1_l_2053;
x86_c1_l_2053:
	/* 0x2053: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c1_l_2055;
x86_c1_l_2055:
	/* 0x2055: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
	goto x86_c1_l_2057;
x86_c1_l_2057:
	/* 0x2057: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c1_l_2059;
x86_c1_l_2059:
	/* 0x2059: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c1_l_205b;
x86_c1_l_205b:
	/* 0x205b: ret */
	X86_SIM_X86_SUB_RET(x86_c1_l_205b_ret);
x86_c1_l_205b_ret:
	switch (__x86_sim_ret_addr) {
	case 0x691ULL: goto x86_c0_l_691;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c2_l_2602:
	/* 0x2602: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c2_l_2604;
x86_c2_l_2604:
	/* 0x2604: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c2_l_2606;
x86_c2_l_2606:
	/* 0x2606: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c2_l_2607;
x86_c2_l_2607:
	/* 0x2607: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
	goto x86_c2_l_260b;
x86_c2_l_260b:
	/* 0x260b: mov    rbx,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDX, X86_WIDTH_64);
	goto x86_c2_l_260e;
x86_c2_l_260e:
	/* 0x260e: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c2_l_2611;
x86_c2_l_2611:
	/* 0x2611: mov    r15,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RDI, X86_WIDTH_64);
	goto x86_c2_l_2614;
x86_c2_l_2614:
	/* 0x2614: mov    BYTE PTR [rsp+0xf],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 64424509440ULL);
	goto x86_c2_l_2619;
x86_c2_l_2619:
	/* 0x2619: lea    rcx,[rsp+0xf] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 15ULL);
	goto x86_c2_l_261e;
x86_c2_l_261e:
	/* 0x261e: call   2661 <__do_str> */
	X86_SIM_X86_CALL(x86_c3_l_2661, 0x2623ULL);
x86_c2_l_2623:
	/* 0x2623: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c2_l_2626;
x86_c2_l_2626:
	/* 0x2626: js     2657 <do_str+0x55> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2626, 0x2657, x86_c2_l_2657);
	goto x86_c2_l_2628;
x86_c2_l_2628:
	/* 0x2628: cmp    BYTE PTR [rsp+0xf],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 64424509440ULL);
	goto x86_c2_l_262d;
x86_c2_l_262d:
	/* 0x262d: jne    2657 <do_str+0x55> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x262d, 0x2657, x86_c2_l_2657);
	goto x86_c2_l_262f;
x86_c2_l_262f:
	/* 0x262f: add    rbx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c2_l_2632;
x86_c2_l_2632:
	/* 0x2632: lea    rcx,[rsp+0xf] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 15ULL);
	goto x86_c2_l_2637;
x86_c2_l_2637:
	/* 0x2637: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
	goto x86_c2_l_263a;
x86_c2_l_263a:
	/* 0x263a: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c2_l_263d;
x86_c2_l_263d:
	/* 0x263d: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
	goto x86_c2_l_2640;
x86_c2_l_2640:
	/* 0x2640: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
	goto x86_c2_l_2643;
x86_c2_l_2643:
	/* 0x2643: call   2661 <__do_str> */
	X86_SIM_X86_CALL(x86_c4_l_2661, 0x2648ULL);
x86_c2_l_2648:
	/* 0x2648: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c2_l_264a;
x86_c2_l_264a:
	/* 0x264a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c2_l_264d;
x86_c2_l_264d:
	/* 0x264d: cmovns rcx,rbx */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RBX, X86_WIDTH_64, X86_CC_NS);
	goto x86_c2_l_2651;
x86_c2_l_2651:
	/* 0x2651: add    rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c2_l_2654;
x86_c2_l_2654:
	/* 0x2654: mov    rax,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_64);
	goto x86_c2_l_2657;
x86_c2_l_2657:
	/* 0x2657: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
	goto x86_c2_l_265b;
x86_c2_l_265b:
	/* 0x265b: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c2_l_265c;
x86_c2_l_265c:
	/* 0x265c: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c2_l_265e;
x86_c2_l_265e:
	/* 0x265e: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c2_l_2660;
x86_c2_l_2660:
	/* 0x2660: ret */
	X86_SIM_X86_SUB_RET(x86_c2_l_2660_ret);
x86_c2_l_2660_ret:
	switch (__x86_sim_ret_addr) {
	case 0x202aULL: goto x86_c1_l_202a;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c3_l_2661:
	/* 0x2661: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c3_l_2663;
x86_c3_l_2663:
	/* 0x2663: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c3_l_2665;
x86_c3_l_2665:
	/* 0x2665: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c3_l_2667;
x86_c3_l_2667:
	/* 0x2667: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c3_l_2668;
x86_c3_l_2668:
	/* 0x2668: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
	goto x86_c3_l_266c;
x86_c3_l_266c:
	/* 0x266c: mov    r15,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RCX, X86_WIDTH_64);
	goto x86_c3_l_266f;
x86_c3_l_266f:
	/* 0x266f: mov    rbx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RSI, X86_WIDTH_64);
	goto x86_c3_l_2672;
x86_c3_l_2672:
	/* 0x2672: mov    r14,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDI, X86_WIDTH_64);
	goto x86_c3_l_2675;
x86_c3_l_2675:
	/* 0x2675: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c3_l_2679;
x86_c3_l_2679:
	/* 0x2679: mov    ecx,0x7fdf */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 32735ULL);
	goto x86_c3_l_267e;
x86_c3_l_267e:
	/* 0x267e: mov    eax,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 45ULL);
	goto x86_c3_l_2683;
x86_c3_l_2683:
	/* 0x2683: mov    esi,0x7fdf */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 32735ULL);
	goto x86_c3_l_2688;
x86_c3_l_2688:
	/* 0x2688: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c3_l_268a;
x86_c3_l_268a:
	/* 0x268a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c3_l_268d;
x86_c3_l_268d:
	/* 0x268d: js     2814 <__do_str+0x1b3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x268d, 0x2814, x86_c3_l_2814);
	goto x86_c3_l_2693;
x86_c3_l_2693:
	/* 0x2693: cmp    rax,0x7fdf */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 32735ULL);
	goto x86_c3_l_2699;
x86_c3_l_2699:
	/* 0x2699: setne  BYTE PTR [r15] */
	X86_SIM_L_EXEC_SETCC_MEM(X86_R15, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_REG_AUX_SRC_SHIFT(X86_CC_NE)), 0ULL);
	goto x86_c3_l_269d;
x86_c3_l_269d:
	/* 0x269d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c3_l_26a0;
x86_c3_l_26a0:
	/* 0x26a0: je     27bc <__do_str+0x15b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26a0, 0x27bc, x86_c3_l_27bc);
	goto x86_c3_l_26a6;
x86_c3_l_26a6:
	/* 0x26a6: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
	goto x86_c3_l_26a9;
x86_c3_l_26a9:
	/* 0x26a9: lea    r15d,[rax+0x1f] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 31ULL);
	goto x86_c3_l_26ad;
x86_c3_l_26ad:
	/* 0x26ad: and    r15d,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
	goto x86_c3_l_26b4;
x86_c3_l_26b4:
	/* 0x26b4: mov    DWORD PTR [rbx+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c3_l_26b8;
x86_c3_l_26b8:
	/* 0x26b8: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
	goto x86_c3_l_26c0;
x86_c3_l_26c0:
	/* 0x26c0: mov    rdi,QWORD PTR [rip+0x120] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c3_l_26c7;
x86_c3_l_26c7:
	/* 0x26c7: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
	goto x86_c3_l_26cc;
x86_c3_l_26cc:
	/* 0x26cc: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c3_l_26d1;
x86_c3_l_26d1:
	/* 0x26d1: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c3_l_26d3;
x86_c3_l_26d3:
	/* 0x26d3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c3_l_26d6;
x86_c3_l_26d6:
	/* 0x26d6: je     2758 <__do_str+0xf7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26d6, 0x2758, x86_c3_l_2758);
	goto x86_c3_l_26dc;
x86_c3_l_26dc:
	/* 0x26dc: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c3_l_26e0;
x86_c3_l_26e0:
	/* 0x26e0: je     2758 <__do_str+0xf7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26e0, 0x2758, x86_c3_l_2758);
	goto x86_c3_l_26e2;
x86_c3_l_26e2:
	/* 0x26e2: mov    rsi,QWORD PTR [rip+0x11c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c3_l_26e9;
x86_c3_l_26e9:
	/* 0x26e9: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c3_l_26ee;
x86_c3_l_26ee:
	/* 0x26ee: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c3_l_26f3;
x86_c3_l_26f3:
	/* 0x26f3: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c3_l_26f8;
x86_c3_l_26f8:
	/* 0x26f8: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
	goto x86_c3_l_26fb;
x86_c3_l_26fb:
	/* 0x26fb: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c3_l_26fe;
x86_c3_l_26fe:
	/* 0x26fe: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c3_l_2701;
x86_c3_l_2701:
	/* 0x2701: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c3_l_2703;
x86_c3_l_2703:
	/* 0x2703: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c3_l_2706;
x86_c3_l_2706:
	/* 0x2706: jns    280e <__do_str+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2706, 0x280e, x86_c3_l_280e);
	goto x86_c3_l_270c;
x86_c3_l_270c:
	/* 0x270c: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
	goto x86_c3_l_270f;
x86_c3_l_270f:
	/* 0x270f: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
	goto x86_c3_l_2717;
x86_c3_l_2717:
	/* 0x2717: mov    rdi,QWORD PTR [rip+0x11c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_stats_map));
	goto x86_c3_l_271e;
x86_c3_l_271e:
	/* 0x271e: lea    rsi,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
	goto x86_c3_l_2723;
x86_c3_l_2723:
	/* 0x2723: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c3_l_2728;
x86_c3_l_2728:
	/* 0x2728: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c3_l_272a;
x86_c3_l_272a:
	/* 0x272a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c3_l_272d;
x86_c3_l_272d:
	/* 0x272d: je     280e <__do_str+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_E, 0x272d, 0x280e, x86_c3_l_280e);
	goto x86_c3_l_2733;
x86_c3_l_2733:
	/* 0x2733: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551604ULL);
	goto x86_c3_l_2737;
x86_c3_l_2737:
	/* 0x2737: jg     27da <__do_str+0x179> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2737, 0x27da, x86_c3_l_27da);
	goto x86_c3_l_273d;
x86_c3_l_273d:
	/* 0x273d: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551588ULL);
	goto x86_c3_l_2741;
x86_c3_l_2741:
	/* 0x2741: je     27f4 <__do_str+0x193> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2741, 0x27f4, x86_c3_l_27f4);
	goto x86_c3_l_2747;
x86_c3_l_2747:
	/* 0x2747: cmp    rbx,0xffffffffffffffea */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551594ULL);
	goto x86_c3_l_274b;
x86_c3_l_274b:
	/* 0x274b: jne    27ae <__do_str+0x14d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x274b, 0x27ae, x86_c3_l_27ae);
	goto x86_c3_l_274d;
x86_c3_l_274d:
	/* 0x274d: add    rax,0x560 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1376ULL);
	goto x86_c3_l_2753;
x86_c3_l_2753:
	/* 0x2753: jmp    280a <__do_str+0x1a9> */
	X86_SIM_X86_JMP(0x2753, 0x280a, x86_c3_l_280a);
x86_c3_l_2758:
	/* 0x2758: mov    rdi,QWORD PTR [rip+0x11c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c3_l_275f;
x86_c3_l_275f:
	/* 0x275f: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c3_l_2761;
x86_c3_l_2761:
	/* 0x2761: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c3_l_2766;
x86_c3_l_2766:
	/* 0x2766: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
	goto x86_c3_l_2769;
x86_c3_l_2769:
	/* 0x2769: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c3_l_276c;
x86_c3_l_276c:
	/* 0x276c: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c3_l_276e;
x86_c3_l_276e:
	/* 0x276e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c3_l_2770;
x86_c3_l_2770:
	/* 0x2770: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c3_l_2773;
x86_c3_l_2773:
	/* 0x2773: jns    280e <__do_str+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2773, 0x280e, x86_c3_l_280e);
	goto x86_c3_l_2779;
x86_c3_l_2779:
	/* 0x2779: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
	goto x86_c3_l_277c;
x86_c3_l_277c:
	/* 0x277c: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
	goto x86_c3_l_2784;
x86_c3_l_2784:
	/* 0x2784: mov    rdi,QWORD PTR [rip+0x11c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_stats_map));
	goto x86_c3_l_278b;
x86_c3_l_278b:
	/* 0x278b: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c3_l_2790;
x86_c3_l_2790:
	/* 0x2790: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c3_l_2795;
x86_c3_l_2795:
	/* 0x2795: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c3_l_2797;
x86_c3_l_2797:
	/* 0x2797: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c3_l_279a;
x86_c3_l_279a:
	/* 0x279a: je     280e <__do_str+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_E, 0x279a, 0x280e, x86_c3_l_280e);
	goto x86_c3_l_279c;
x86_c3_l_279c:
	/* 0x279c: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551604ULL);
	goto x86_c3_l_27a0;
x86_c3_l_27a0:
	/* 0x27a0: jg     27c0 <__do_str+0x15f> */
	X86_SIM_X86_JCC(X86_CC_G, 0x27a0, 0x27c0, x86_c3_l_27c0);
	goto x86_c3_l_27a2;
x86_c3_l_27a2:
	/* 0x27a2: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551588ULL);
	goto x86_c3_l_27a6;
x86_c3_l_27a6:
	/* 0x27a6: je     27f4 <__do_str+0x193> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27a6, 0x27f4, x86_c3_l_27f4);
	goto x86_c3_l_27a8;
x86_c3_l_27a8:
	/* 0x27a8: cmp    rbx,0xffffffffffffffea */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551594ULL);
	goto x86_c3_l_27ac;
x86_c3_l_27ac:
	/* 0x27ac: je     274d <__do_str+0xec> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27ac, 0x274d, x86_c3_l_274d);
	goto x86_c3_l_27ae;
x86_c3_l_27ae:
	/* 0x27ae: cmp    rbx,0xfffffffffffffff0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551600ULL);
	goto x86_c3_l_27b2;
x86_c3_l_27b2:
	/* 0x27b2: jne    27ec <__do_str+0x18b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27b2, 0x27ec, x86_c3_l_27ec);
	goto x86_c3_l_27b4;
x86_c3_l_27b4:
	/* 0x27b4: add    rax,0x558 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1368ULL);
	goto x86_c3_l_27ba;
x86_c3_l_27ba:
	/* 0x27ba: jmp    280a <__do_str+0x1a9> */
	X86_SIM_X86_JMP(0x27ba, 0x280a, x86_c3_l_280a);
x86_c3_l_27bc:
	/* 0x27bc: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c3_l_27be;
x86_c3_l_27be:
	/* 0x27be: jmp    2814 <__do_str+0x1b3> */
	X86_SIM_X86_JMP(0x27be, 0x2814, x86_c3_l_2814);
x86_c3_l_27c0:
	/* 0x27c0: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551605ULL);
	goto x86_c3_l_27c4;
x86_c3_l_27c4:
	/* 0x27c4: je     27fc <__do_str+0x19b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27c4, 0x27fc, x86_c3_l_27fc);
	goto x86_c3_l_27c6;
x86_c3_l_27c6:
	/* 0x27c6: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551609ULL);
	goto x86_c3_l_27ca;
x86_c3_l_27ca:
	/* 0x27ca: je     2804 <__do_str+0x1a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27ca, 0x2804, x86_c3_l_2804);
	goto x86_c3_l_27cc;
x86_c3_l_27cc:
	/* 0x27cc: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551614ULL);
	goto x86_c3_l_27d0;
x86_c3_l_27d0:
	/* 0x27d0: jne    27ec <__do_str+0x18b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27d0, 0x27ec, x86_c3_l_27ec);
	goto x86_c3_l_27d2;
x86_c3_l_27d2:
	/* 0x27d2: add    rax,0x548 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1352ULL);
	goto x86_c3_l_27d8;
x86_c3_l_27d8:
	/* 0x27d8: jmp    280a <__do_str+0x1a9> */
	X86_SIM_X86_JMP(0x27d8, 0x280a, x86_c3_l_280a);
x86_c3_l_27da:
	/* 0x27da: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551605ULL);
	goto x86_c3_l_27de;
x86_c3_l_27de:
	/* 0x27de: je     27fc <__do_str+0x19b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27de, 0x27fc, x86_c3_l_27fc);
	goto x86_c3_l_27e0;
x86_c3_l_27e0:
	/* 0x27e0: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551609ULL);
	goto x86_c3_l_27e4;
x86_c3_l_27e4:
	/* 0x27e4: je     2804 <__do_str+0x1a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27e4, 0x2804, x86_c3_l_2804);
	goto x86_c3_l_27e6;
x86_c3_l_27e6:
	/* 0x27e6: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551614ULL);
	goto x86_c3_l_27ea;
x86_c3_l_27ea:
	/* 0x27ea: je     27d2 <__do_str+0x171> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27ea, 0x27d2, x86_c3_l_27d2);
	goto x86_c3_l_27ec;
x86_c3_l_27ec:
	/* 0x27ec: add    rax,0x540 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1344ULL);
	goto x86_c3_l_27f2;
x86_c3_l_27f2:
	/* 0x27f2: jmp    280a <__do_str+0x1a9> */
	X86_SIM_X86_JMP(0x27f2, 0x280a, x86_c3_l_280a);
x86_c3_l_27f4:
	/* 0x27f4: add    rax,0x568 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1384ULL);
	goto x86_c3_l_27fa;
x86_c3_l_27fa:
	/* 0x27fa: jmp    280a <__do_str+0x1a9> */
	X86_SIM_X86_JMP(0x27fa, 0x280a, x86_c3_l_280a);
x86_c3_l_27fc:
	/* 0x27fc: add    rax,0x570 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1392ULL);
	goto x86_c3_l_2802;
x86_c3_l_2802:
	/* 0x2802: jmp    280a <__do_str+0x1a9> */
	X86_SIM_X86_JMP(0x2802, 0x280a, x86_c3_l_280a);
x86_c3_l_2804:
	/* 0x2804: add    rax,0x550 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1360ULL);
	goto x86_c3_l_280a;
x86_c3_l_280a:
	/* 0x280a: inc QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
	goto x86_c3_l_280e;
x86_c3_l_280e:
	/* 0x280e: mov    rax,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R12, X86_WIDTH_64);
	goto x86_c3_l_2811;
x86_c3_l_2811:
	/* 0x2811: dec    rax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_DEC, 1);
	goto x86_c3_l_2814;
x86_c3_l_2814:
	/* 0x2814: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
	goto x86_c3_l_2818;
x86_c3_l_2818:
	/* 0x2818: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c3_l_2819;
x86_c3_l_2819:
	/* 0x2819: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c3_l_281b;
x86_c3_l_281b:
	/* 0x281b: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c3_l_281d;
x86_c3_l_281d:
	/* 0x281d: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c3_l_281f;
x86_c3_l_281f:
	/* 0x281f: ret */
	X86_SIM_X86_SUB_RET(x86_c3_l_281f_ret);
x86_c3_l_281f_ret:
	switch (__x86_sim_ret_addr) {
	case 0x2623ULL: goto x86_c2_l_2623;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c4_l_2661:
	/* 0x2661: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c4_l_2663;
x86_c4_l_2663:
	/* 0x2663: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c4_l_2665;
x86_c4_l_2665:
	/* 0x2665: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c4_l_2667;
x86_c4_l_2667:
	/* 0x2667: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c4_l_2668;
x86_c4_l_2668:
	/* 0x2668: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
	goto x86_c4_l_266c;
x86_c4_l_266c:
	/* 0x266c: mov    r15,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RCX, X86_WIDTH_64);
	goto x86_c4_l_266f;
x86_c4_l_266f:
	/* 0x266f: mov    rbx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RSI, X86_WIDTH_64);
	goto x86_c4_l_2672;
x86_c4_l_2672:
	/* 0x2672: mov    r14,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDI, X86_WIDTH_64);
	goto x86_c4_l_2675;
x86_c4_l_2675:
	/* 0x2675: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c4_l_2679;
x86_c4_l_2679:
	/* 0x2679: mov    ecx,0x7fdf */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 32735ULL);
	goto x86_c4_l_267e;
x86_c4_l_267e:
	/* 0x267e: mov    eax,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 45ULL);
	goto x86_c4_l_2683;
x86_c4_l_2683:
	/* 0x2683: mov    esi,0x7fdf */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 32735ULL);
	goto x86_c4_l_2688;
x86_c4_l_2688:
	/* 0x2688: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c4_l_268a;
x86_c4_l_268a:
	/* 0x268a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c4_l_268d;
x86_c4_l_268d:
	/* 0x268d: js     2814 <__do_str+0x1b3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x268d, 0x2814, x86_c4_l_2814);
	goto x86_c4_l_2693;
x86_c4_l_2693:
	/* 0x2693: cmp    rax,0x7fdf */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 32735ULL);
	goto x86_c4_l_2699;
x86_c4_l_2699:
	/* 0x2699: setne  BYTE PTR [r15] */
	X86_SIM_L_EXEC_SETCC_MEM(X86_R15, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_REG_AUX_SRC_SHIFT(X86_CC_NE)), 0ULL);
	goto x86_c4_l_269d;
x86_c4_l_269d:
	/* 0x269d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c4_l_26a0;
x86_c4_l_26a0:
	/* 0x26a0: je     27bc <__do_str+0x15b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26a0, 0x27bc, x86_c4_l_27bc);
	goto x86_c4_l_26a6;
x86_c4_l_26a6:
	/* 0x26a6: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
	goto x86_c4_l_26a9;
x86_c4_l_26a9:
	/* 0x26a9: lea    r15d,[rax+0x1f] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 31ULL);
	goto x86_c4_l_26ad;
x86_c4_l_26ad:
	/* 0x26ad: and    r15d,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
	goto x86_c4_l_26b4;
x86_c4_l_26b4:
	/* 0x26b4: mov    DWORD PTR [rbx+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c4_l_26b8;
x86_c4_l_26b8:
	/* 0x26b8: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
	goto x86_c4_l_26c0;
x86_c4_l_26c0:
	/* 0x26c0: mov    rdi,QWORD PTR [rip+0x120] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c4_l_26c7;
x86_c4_l_26c7:
	/* 0x26c7: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
	goto x86_c4_l_26cc;
x86_c4_l_26cc:
	/* 0x26cc: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c4_l_26d1;
x86_c4_l_26d1:
	/* 0x26d1: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c4_l_26d3;
x86_c4_l_26d3:
	/* 0x26d3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c4_l_26d6;
x86_c4_l_26d6:
	/* 0x26d6: je     2758 <__do_str+0xf7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26d6, 0x2758, x86_c4_l_2758);
	goto x86_c4_l_26dc;
x86_c4_l_26dc:
	/* 0x26dc: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c4_l_26e0;
x86_c4_l_26e0:
	/* 0x26e0: je     2758 <__do_str+0xf7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26e0, 0x2758, x86_c4_l_2758);
	goto x86_c4_l_26e2;
x86_c4_l_26e2:
	/* 0x26e2: mov    rsi,QWORD PTR [rip+0x11c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c4_l_26e9;
x86_c4_l_26e9:
	/* 0x26e9: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c4_l_26ee;
x86_c4_l_26ee:
	/* 0x26ee: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c4_l_26f3;
x86_c4_l_26f3:
	/* 0x26f3: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c4_l_26f8;
x86_c4_l_26f8:
	/* 0x26f8: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
	goto x86_c4_l_26fb;
x86_c4_l_26fb:
	/* 0x26fb: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c4_l_26fe;
x86_c4_l_26fe:
	/* 0x26fe: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c4_l_2701;
x86_c4_l_2701:
	/* 0x2701: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c4_l_2703;
x86_c4_l_2703:
	/* 0x2703: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c4_l_2706;
x86_c4_l_2706:
	/* 0x2706: jns    280e <__do_str+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2706, 0x280e, x86_c4_l_280e);
	goto x86_c4_l_270c;
x86_c4_l_270c:
	/* 0x270c: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
	goto x86_c4_l_270f;
x86_c4_l_270f:
	/* 0x270f: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
	goto x86_c4_l_2717;
x86_c4_l_2717:
	/* 0x2717: mov    rdi,QWORD PTR [rip+0x11c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_stats_map));
	goto x86_c4_l_271e;
x86_c4_l_271e:
	/* 0x271e: lea    rsi,[rsp+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
	goto x86_c4_l_2723;
x86_c4_l_2723:
	/* 0x2723: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c4_l_2728;
x86_c4_l_2728:
	/* 0x2728: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c4_l_272a;
x86_c4_l_272a:
	/* 0x272a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c4_l_272d;
x86_c4_l_272d:
	/* 0x272d: je     280e <__do_str+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_E, 0x272d, 0x280e, x86_c4_l_280e);
	goto x86_c4_l_2733;
x86_c4_l_2733:
	/* 0x2733: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551604ULL);
	goto x86_c4_l_2737;
x86_c4_l_2737:
	/* 0x2737: jg     27da <__do_str+0x179> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2737, 0x27da, x86_c4_l_27da);
	goto x86_c4_l_273d;
x86_c4_l_273d:
	/* 0x273d: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551588ULL);
	goto x86_c4_l_2741;
x86_c4_l_2741:
	/* 0x2741: je     27f4 <__do_str+0x193> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2741, 0x27f4, x86_c4_l_27f4);
	goto x86_c4_l_2747;
x86_c4_l_2747:
	/* 0x2747: cmp    rbx,0xffffffffffffffea */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551594ULL);
	goto x86_c4_l_274b;
x86_c4_l_274b:
	/* 0x274b: jne    27ae <__do_str+0x14d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x274b, 0x27ae, x86_c4_l_27ae);
	goto x86_c4_l_274d;
x86_c4_l_274d:
	/* 0x274d: add    rax,0x560 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1376ULL);
	goto x86_c4_l_2753;
x86_c4_l_2753:
	/* 0x2753: jmp    280a <__do_str+0x1a9> */
	X86_SIM_X86_JMP(0x2753, 0x280a, x86_c4_l_280a);
x86_c4_l_2758:
	/* 0x2758: mov    rdi,QWORD PTR [rip+0x11c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c4_l_275f;
x86_c4_l_275f:
	/* 0x275f: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c4_l_2761;
x86_c4_l_2761:
	/* 0x2761: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c4_l_2766;
x86_c4_l_2766:
	/* 0x2766: mov    rsi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_64);
	goto x86_c4_l_2769;
x86_c4_l_2769:
	/* 0x2769: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c4_l_276c;
x86_c4_l_276c:
	/* 0x276c: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c4_l_276e;
x86_c4_l_276e:
	/* 0x276e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c4_l_2770;
x86_c4_l_2770:
	/* 0x2770: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c4_l_2773;
x86_c4_l_2773:
	/* 0x2773: jns    280e <__do_str+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2773, 0x280e, x86_c4_l_280e);
	goto x86_c4_l_2779;
x86_c4_l_2779:
	/* 0x2779: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
	goto x86_c4_l_277c;
x86_c4_l_277c:
	/* 0x277c: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
	goto x86_c4_l_2784;
x86_c4_l_2784:
	/* 0x2784: mov    rdi,QWORD PTR [rip+0x11c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_stats_map));
	goto x86_c4_l_278b;
x86_c4_l_278b:
	/* 0x278b: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c4_l_2790;
x86_c4_l_2790:
	/* 0x2790: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c4_l_2795;
x86_c4_l_2795:
	/* 0x2795: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c4_l_2797;
x86_c4_l_2797:
	/* 0x2797: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c4_l_279a;
x86_c4_l_279a:
	/* 0x279a: je     280e <__do_str+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_E, 0x279a, 0x280e, x86_c4_l_280e);
	goto x86_c4_l_279c;
x86_c4_l_279c:
	/* 0x279c: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551604ULL);
	goto x86_c4_l_27a0;
x86_c4_l_27a0:
	/* 0x27a0: jg     27c0 <__do_str+0x15f> */
	X86_SIM_X86_JCC(X86_CC_G, 0x27a0, 0x27c0, x86_c4_l_27c0);
	goto x86_c4_l_27a2;
x86_c4_l_27a2:
	/* 0x27a2: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551588ULL);
	goto x86_c4_l_27a6;
x86_c4_l_27a6:
	/* 0x27a6: je     27f4 <__do_str+0x193> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27a6, 0x27f4, x86_c4_l_27f4);
	goto x86_c4_l_27a8;
x86_c4_l_27a8:
	/* 0x27a8: cmp    rbx,0xffffffffffffffea */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551594ULL);
	goto x86_c4_l_27ac;
x86_c4_l_27ac:
	/* 0x27ac: je     274d <__do_str+0xec> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27ac, 0x274d, x86_c4_l_274d);
	goto x86_c4_l_27ae;
x86_c4_l_27ae:
	/* 0x27ae: cmp    rbx,0xfffffffffffffff0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551600ULL);
	goto x86_c4_l_27b2;
x86_c4_l_27b2:
	/* 0x27b2: jne    27ec <__do_str+0x18b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27b2, 0x27ec, x86_c4_l_27ec);
	goto x86_c4_l_27b4;
x86_c4_l_27b4:
	/* 0x27b4: add    rax,0x558 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1368ULL);
	goto x86_c4_l_27ba;
x86_c4_l_27ba:
	/* 0x27ba: jmp    280a <__do_str+0x1a9> */
	X86_SIM_X86_JMP(0x27ba, 0x280a, x86_c4_l_280a);
x86_c4_l_27bc:
	/* 0x27bc: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c4_l_27be;
x86_c4_l_27be:
	/* 0x27be: jmp    2814 <__do_str+0x1b3> */
	X86_SIM_X86_JMP(0x27be, 0x2814, x86_c4_l_2814);
x86_c4_l_27c0:
	/* 0x27c0: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551605ULL);
	goto x86_c4_l_27c4;
x86_c4_l_27c4:
	/* 0x27c4: je     27fc <__do_str+0x19b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27c4, 0x27fc, x86_c4_l_27fc);
	goto x86_c4_l_27c6;
x86_c4_l_27c6:
	/* 0x27c6: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551609ULL);
	goto x86_c4_l_27ca;
x86_c4_l_27ca:
	/* 0x27ca: je     2804 <__do_str+0x1a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27ca, 0x2804, x86_c4_l_2804);
	goto x86_c4_l_27cc;
x86_c4_l_27cc:
	/* 0x27cc: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551614ULL);
	goto x86_c4_l_27d0;
x86_c4_l_27d0:
	/* 0x27d0: jne    27ec <__do_str+0x18b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27d0, 0x27ec, x86_c4_l_27ec);
	goto x86_c4_l_27d2;
x86_c4_l_27d2:
	/* 0x27d2: add    rax,0x548 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1352ULL);
	goto x86_c4_l_27d8;
x86_c4_l_27d8:
	/* 0x27d8: jmp    280a <__do_str+0x1a9> */
	X86_SIM_X86_JMP(0x27d8, 0x280a, x86_c4_l_280a);
x86_c4_l_27da:
	/* 0x27da: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551605ULL);
	goto x86_c4_l_27de;
x86_c4_l_27de:
	/* 0x27de: je     27fc <__do_str+0x19b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27de, 0x27fc, x86_c4_l_27fc);
	goto x86_c4_l_27e0;
x86_c4_l_27e0:
	/* 0x27e0: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551609ULL);
	goto x86_c4_l_27e4;
x86_c4_l_27e4:
	/* 0x27e4: je     2804 <__do_str+0x1a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27e4, 0x2804, x86_c4_l_2804);
	goto x86_c4_l_27e6;
x86_c4_l_27e6:
	/* 0x27e6: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551614ULL);
	goto x86_c4_l_27ea;
x86_c4_l_27ea:
	/* 0x27ea: je     27d2 <__do_str+0x171> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27ea, 0x27d2, x86_c4_l_27d2);
	goto x86_c4_l_27ec;
x86_c4_l_27ec:
	/* 0x27ec: add    rax,0x540 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1344ULL);
	goto x86_c4_l_27f2;
x86_c4_l_27f2:
	/* 0x27f2: jmp    280a <__do_str+0x1a9> */
	X86_SIM_X86_JMP(0x27f2, 0x280a, x86_c4_l_280a);
x86_c4_l_27f4:
	/* 0x27f4: add    rax,0x568 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1384ULL);
	goto x86_c4_l_27fa;
x86_c4_l_27fa:
	/* 0x27fa: jmp    280a <__do_str+0x1a9> */
	X86_SIM_X86_JMP(0x27fa, 0x280a, x86_c4_l_280a);
x86_c4_l_27fc:
	/* 0x27fc: add    rax,0x570 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1392ULL);
	goto x86_c4_l_2802;
x86_c4_l_2802:
	/* 0x2802: jmp    280a <__do_str+0x1a9> */
	X86_SIM_X86_JMP(0x2802, 0x280a, x86_c4_l_280a);
x86_c4_l_2804:
	/* 0x2804: add    rax,0x550 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1360ULL);
	goto x86_c4_l_280a;
x86_c4_l_280a:
	/* 0x280a: inc QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
	goto x86_c4_l_280e;
x86_c4_l_280e:
	/* 0x280e: mov    rax,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R12, X86_WIDTH_64);
	goto x86_c4_l_2811;
x86_c4_l_2811:
	/* 0x2811: dec    rax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_DEC, 1);
	goto x86_c4_l_2814;
x86_c4_l_2814:
	/* 0x2814: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
	goto x86_c4_l_2818;
x86_c4_l_2818:
	/* 0x2818: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c4_l_2819;
x86_c4_l_2819:
	/* 0x2819: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c4_l_281b;
x86_c4_l_281b:
	/* 0x281b: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c4_l_281d;
x86_c4_l_281d:
	/* 0x281d: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c4_l_281f;
x86_c4_l_281f:
	/* 0x281f: ret */
	X86_SIM_X86_SUB_RET(x86_c4_l_281f_ret);
x86_c4_l_281f_ret:
	switch (__x86_sim_ret_addr) {
	case 0x2648ULL: goto x86_c2_l_2648;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c5_l_205c:
	/* 0x205c: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
	goto x86_c5_l_205d;
x86_c5_l_205d:
	/* 0x205d: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c5_l_205f;
x86_c5_l_205f:
	/* 0x205f: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c5_l_2061;
x86_c5_l_2061:
	/* 0x2061: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
	goto x86_c5_l_2063;
x86_c5_l_2063:
	/* 0x2063: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c5_l_2065;
x86_c5_l_2065:
	/* 0x2065: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c5_l_2066;
x86_c5_l_2066:
	/* 0x2066: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c5_l_2067;
x86_c5_l_2067:
	/* 0x2067: mov    r14,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RCX, X86_WIDTH_64);
	goto x86_c5_l_206a;
x86_c5_l_206a:
	/* 0x206a: mov    r15,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RDX, X86_WIDTH_64);
	goto x86_c5_l_206d;
x86_c5_l_206d:
	/* 0x206d: mov    rbx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RSI, X86_WIDTH_64);
	goto x86_c5_l_2070;
x86_c5_l_2070:
	/* 0x2070: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c5_l_2073;
x86_c5_l_2073:
	/* 0x2073: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c5_l_207b;
x86_c5_l_207b:
	/* 0x207b: mov    rdi,QWORD PTR [rip+0x2e0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)data_heap));
	goto x86_c5_l_2082;
x86_c5_l_2082:
	/* 0x2082: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c5_l_2087;
x86_c5_l_2087:
	/* 0x2087: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c5_l_208c;
x86_c5_l_208c:
	/* 0x208c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c5_l_208e;
x86_c5_l_208e:
	/* 0x208e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c5_l_2091;
x86_c5_l_2091:
	/* 0x2091: je     2104 <data_event_bytes+0xa8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2091, 0x2104, x86_c5_l_2104);
	goto x86_c5_l_2093;
x86_c5_l_2093:
	/* 0x2093: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
	goto x86_c5_l_2096;
x86_c5_l_2096:
	/* 0x2096: mov    DWORD PTR [rax],0x18 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c5_l_209c;
x86_c5_l_209c:
	/* 0x209c: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
	goto x86_c5_l_20a1;
x86_c5_l_20a1:
	/* 0x20a1: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c5_l_20a3;
x86_c5_l_20a3:
	/* 0x20a3: mov    rbp,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R13, X86_WIDTH_64);
	goto x86_c5_l_20a6;
x86_c5_l_20a6:
	/* 0x20a6: add    rbp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
	goto x86_c5_l_20aa;
x86_c5_l_20aa:
	/* 0x20aa: mov    QWORD PTR [r13+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c5_l_20ae;
x86_c5_l_20ae:
	/* 0x20ae: cmp    rax,0xffffffffffffffea */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 18446744073709551594ULL);
	goto x86_c5_l_20b2;
x86_c5_l_20b2:
	/* 0x20b2: jne    20bd <data_event_bytes+0x61> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20b2, 0x20bd, x86_c5_l_20bd);
	goto x86_c5_l_20b4;
x86_c5_l_20b4:
	/* 0x20b4: mov    rax,QWORD PTR [r12+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c5_l_20b9;
x86_c5_l_20b9:
	/* 0x20b9: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c5_l_20bd;
x86_c5_l_20bd:
	/* 0x20bd: mov    eax,0x7d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 125ULL);
	goto x86_c5_l_20c2;
x86_c5_l_20c2:
	/* 0x20c2: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x7dULL: X86_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x7dULL: X86_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c5_l_20c4;
x86_c5_l_20c4:
	/* 0x20c4: mov    QWORD PTR [r13+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c5_l_20c8;
x86_c5_l_20c8:
	/* 0x20c8: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c5_l_20cc;
x86_c5_l_20cc:
	/* 0x20cc: mov    rcx,QWORD PTR [rbp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
	goto x86_c5_l_20d0;
x86_c5_l_20d0:
	/* 0x20d0: mov    QWORD PTR [rbx+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c5_l_20d4;
x86_c5_l_20d4:
	/* 0x20d4: mov    QWORD PTR [rbx+0x18],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c5_l_20d8;
x86_c5_l_20d8:
	/* 0x20d8: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c5_l_20db;
x86_c5_l_20db:
	/* 0x20db: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
	goto x86_c5_l_20de;
x86_c5_l_20de:
	/* 0x20de: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c5_l_20e1;
x86_c5_l_20e1:
	/* 0x20e1: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c5_l_20e4;
x86_c5_l_20e4:
	/* 0x20e4: call   22de <do_bytes> */
	X86_SIM_X86_CALL(x86_c6_l_22de, 0x20e9ULL);
x86_c5_l_20e9:
	/* 0x20e9: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c5_l_20eb;
x86_c5_l_20eb:
	/* 0x20eb: js     2108 <data_event_bytes+0xac> */
	X86_SIM_X86_JCC(X86_CC_S, 0x20eb, 0x2108, x86_c5_l_2108);
	goto x86_c5_l_20ed;
x86_c5_l_20ed:
	/* 0x20ed: mov    QWORD PTR [rbx],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c5_l_20f4;
x86_c5_l_20f4:
	/* 0x20f4: mov    edx,r14d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_32);
	goto x86_c5_l_20f7;
x86_c5_l_20f7:
	/* 0x20f7: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
	goto x86_c5_l_20f9;
x86_c5_l_20f9:
	/* 0x20f9: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c5_l_20fb;
x86_c5_l_20fb:
	/* 0x20fb: cmp    r14,0xffffffffffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R14, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c5_l_20ff;
x86_c5_l_20ff:
	/* 0x20ff: cmovne ecx,edx */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RDX, X86_WIDTH_32, X86_CC_NE);
	goto x86_c5_l_2102;
x86_c5_l_2102:
	/* 0x2102: jmp    2115 <data_event_bytes+0xb9> */
	X86_SIM_X86_JMP(0x2102, 0x2115, x86_c5_l_2115);
x86_c5_l_2104:
	/* 0x2104: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c5_l_2106;
x86_c5_l_2106:
	/* 0x2106: jmp    2120 <data_event_bytes+0xc4> */
	X86_SIM_X86_JMP(0x2106, 0x2120, x86_c5_l_2120);
x86_c5_l_2108:
	/* 0x2108: mov    DWORD PTR [rbx],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c5_l_210a;
x86_c5_l_210a:
	/* 0x210a: mov    DWORD PTR [rbx+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c5_l_2111;
x86_c5_l_2111:
	/* 0x2111: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c5_l_2113;
x86_c5_l_2113:
	/* 0x2113: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c5_l_2115;
x86_c5_l_2115:
	/* 0x2115: mov    DWORD PTR [rbx+0x8],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
	goto x86_c5_l_2118;
x86_c5_l_2118:
	/* 0x2118: mov    DWORD PTR [rbx+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
	goto x86_c5_l_211b;
x86_c5_l_211b:
	/* 0x211b: mov    eax,0x20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 32ULL);
	goto x86_c5_l_2120;
x86_c5_l_2120:
	/* 0x2120: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c5_l_2124;
x86_c5_l_2124:
	/* 0x2124: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c5_l_2125;
x86_c5_l_2125:
	/* 0x2125: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c5_l_2127;
x86_c5_l_2127:
	/* 0x2127: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
	goto x86_c5_l_2129;
x86_c5_l_2129:
	/* 0x2129: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c5_l_212b;
x86_c5_l_212b:
	/* 0x212b: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c5_l_212d;
x86_c5_l_212d:
	/* 0x212d: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
	goto x86_c5_l_212e;
x86_c5_l_212e:
	/* 0x212e: ret */
	X86_SIM_X86_SUB_RET(x86_c5_l_212e_ret);
x86_c5_l_212e_ret:
	switch (__x86_sim_ret_addr) {
	case 0x9d4ULL: goto x86_c0_l_9d4;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c6_l_22de:
	/* 0x22de: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
	goto x86_c6_l_22df;
x86_c6_l_22df:
	/* 0x22df: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c6_l_22e1;
x86_c6_l_22e1:
	/* 0x22e1: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c6_l_22e3;
x86_c6_l_22e3:
	/* 0x22e3: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
	goto x86_c6_l_22e5;
x86_c6_l_22e5:
	/* 0x22e5: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c6_l_22e7;
x86_c6_l_22e7:
	/* 0x22e7: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c6_l_22e8;
x86_c6_l_22e8:
	/* 0x22e8: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c6_l_22e9;
x86_c6_l_22e9:
	/* 0x22e9: mov    rbx,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RCX, X86_WIDTH_64);
	goto x86_c6_l_22ec;
x86_c6_l_22ec:
	/* 0x22ec: mov    r14,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDX, X86_WIDTH_64);
	goto x86_c6_l_22ef;
x86_c6_l_22ef:
	/* 0x22ef: mov    r15,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RSI, X86_WIDTH_64);
	goto x86_c6_l_22f2;
x86_c6_l_22f2:
	/* 0x22f2: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c6_l_22f5;
x86_c6_l_22f5:
	/* 0x22f5: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c7_l_253e, 0x22faULL);
x86_c6_l_22fa:
	/* 0x22fa: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c6_l_22fc;
x86_c6_l_22fc:
	/* 0x22fc: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x22fc, 0x24a5, x86_c6_l_24a5);
	goto x86_c6_l_2302;
x86_c6_l_2302:
	/* 0x2302: mov    r13d,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_32);
	goto x86_c6_l_2305;
x86_c6_l_2305:
	/* 0x2305: and    r13d,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c6_l_230c;
x86_c6_l_230c:
	/* 0x230c: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c6_l_230f;
x86_c6_l_230f:
	/* 0x230f: sub    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c6_l_2312;
x86_c6_l_2312:
	/* 0x2312: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2312, 0x252c, x86_c6_l_252c);
	goto x86_c6_l_2318;
x86_c6_l_2318:
	/* 0x2318: lea    rdx,[r14+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
	goto x86_c6_l_231c;
x86_c6_l_231c:
	/* 0x231c: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c6_l_231f;
x86_c6_l_231f:
	/* 0x231f: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c6_l_2322;
x86_c6_l_2322:
	/* 0x2322: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c8_l_253e, 0x2327ULL);
x86_c6_l_2327:
	/* 0x2327: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c6_l_2329;
x86_c6_l_2329:
	/* 0x2329: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2329, 0x24a5, x86_c6_l_24a5);
	goto x86_c6_l_232f;
x86_c6_l_232f:
	/* 0x232f: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c6_l_2334;
x86_c6_l_2334:
	/* 0x2334: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
	goto x86_c6_l_2337;
x86_c6_l_2337:
	/* 0x2337: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c6_l_233a;
x86_c6_l_233a:
	/* 0x233a: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c6_l_233d;
x86_c6_l_233d:
	/* 0x233d: sub    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c6_l_2340;
x86_c6_l_2340:
	/* 0x2340: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2340, 0x252c, x86_c6_l_252c);
	goto x86_c6_l_2346;
x86_c6_l_2346:
	/* 0x2346: lea    rdx,[r14+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
	goto x86_c6_l_234a;
x86_c6_l_234a:
	/* 0x234a: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c6_l_234d;
x86_c6_l_234d:
	/* 0x234d: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c6_l_2350;
x86_c6_l_2350:
	/* 0x2350: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c9_l_253e, 0x2355ULL);
x86_c6_l_2355:
	/* 0x2355: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c6_l_2357;
x86_c6_l_2357:
	/* 0x2357: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2357, 0x24a5, x86_c6_l_24a5);
	goto x86_c6_l_235d;
x86_c6_l_235d:
	/* 0x235d: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c6_l_2362;
x86_c6_l_2362:
	/* 0x2362: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
	goto x86_c6_l_2365;
x86_c6_l_2365:
	/* 0x2365: add    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c6_l_2368;
x86_c6_l_2368:
	/* 0x2368: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c6_l_236b;
x86_c6_l_236b:
	/* 0x236b: sub    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c6_l_236e;
x86_c6_l_236e:
	/* 0x236e: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x236e, 0x252c, x86_c6_l_252c);
	goto x86_c6_l_2374;
x86_c6_l_2374:
	/* 0x2374: lea    rdx,[r14+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
	goto x86_c6_l_2378;
x86_c6_l_2378:
	/* 0x2378: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c6_l_237b;
x86_c6_l_237b:
	/* 0x237b: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c6_l_237e;
x86_c6_l_237e:
	/* 0x237e: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c10_l_253e, 0x2383ULL);
x86_c6_l_2383:
	/* 0x2383: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c6_l_2385;
x86_c6_l_2385:
	/* 0x2385: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2385, 0x24a5, x86_c6_l_24a5);
	goto x86_c6_l_238b;
x86_c6_l_238b:
	/* 0x238b: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c6_l_2390;
x86_c6_l_2390:
	/* 0x2390: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
	goto x86_c6_l_2393;
x86_c6_l_2393:
	/* 0x2393: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c6_l_2396;
x86_c6_l_2396:
	/* 0x2396: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c6_l_2399;
x86_c6_l_2399:
	/* 0x2399: sub    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c6_l_239c;
x86_c6_l_239c:
	/* 0x239c: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x239c, 0x252c, x86_c6_l_252c);
	goto x86_c6_l_23a2;
x86_c6_l_23a2:
	/* 0x23a2: lea    rdx,[r14+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
	goto x86_c6_l_23a6;
x86_c6_l_23a6:
	/* 0x23a6: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c6_l_23a9;
x86_c6_l_23a9:
	/* 0x23a9: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c6_l_23ac;
x86_c6_l_23ac:
	/* 0x23ac: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c11_l_253e, 0x23b1ULL);
x86_c6_l_23b1:
	/* 0x23b1: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c6_l_23b3;
x86_c6_l_23b3:
	/* 0x23b3: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x23b3, 0x24a5, x86_c6_l_24a5);
	goto x86_c6_l_23b9;
x86_c6_l_23b9:
	/* 0x23b9: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c6_l_23be;
x86_c6_l_23be:
	/* 0x23be: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
	goto x86_c6_l_23c1;
x86_c6_l_23c1:
	/* 0x23c1: add    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c6_l_23c4;
x86_c6_l_23c4:
	/* 0x23c4: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c6_l_23c7;
x86_c6_l_23c7:
	/* 0x23c7: sub    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c6_l_23ca;
x86_c6_l_23ca:
	/* 0x23ca: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23ca, 0x252c, x86_c6_l_252c);
	goto x86_c6_l_23d0;
x86_c6_l_23d0:
	/* 0x23d0: lea    rdx,[r14+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
	goto x86_c6_l_23d4;
x86_c6_l_23d4:
	/* 0x23d4: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c6_l_23d7;
x86_c6_l_23d7:
	/* 0x23d7: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c6_l_23da;
x86_c6_l_23da:
	/* 0x23da: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c12_l_253e, 0x23dfULL);
x86_c6_l_23df:
	/* 0x23df: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c6_l_23e1;
x86_c6_l_23e1:
	/* 0x23e1: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x23e1, 0x24a5, x86_c6_l_24a5);
	goto x86_c6_l_23e7;
x86_c6_l_23e7:
	/* 0x23e7: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c6_l_23ec;
x86_c6_l_23ec:
	/* 0x23ec: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
	goto x86_c6_l_23ef;
x86_c6_l_23ef:
	/* 0x23ef: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c6_l_23f2;
x86_c6_l_23f2:
	/* 0x23f2: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c6_l_23f5;
x86_c6_l_23f5:
	/* 0x23f5: sub    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c6_l_23f8;
x86_c6_l_23f8:
	/* 0x23f8: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23f8, 0x252c, x86_c6_l_252c);
	goto x86_c6_l_23fe;
x86_c6_l_23fe:
	/* 0x23fe: lea    rdx,[r14+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
	goto x86_c6_l_2402;
x86_c6_l_2402:
	/* 0x2402: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c6_l_2405;
x86_c6_l_2405:
	/* 0x2405: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c6_l_2408;
x86_c6_l_2408:
	/* 0x2408: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c13_l_253e, 0x240dULL);
x86_c6_l_240d:
	/* 0x240d: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c6_l_240f;
x86_c6_l_240f:
	/* 0x240f: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x240f, 0x24a5, x86_c6_l_24a5);
	goto x86_c6_l_2415;
x86_c6_l_2415:
	/* 0x2415: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c6_l_241a;
x86_c6_l_241a:
	/* 0x241a: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
	goto x86_c6_l_241d;
x86_c6_l_241d:
	/* 0x241d: add    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c6_l_2420;
x86_c6_l_2420:
	/* 0x2420: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c6_l_2423;
x86_c6_l_2423:
	/* 0x2423: sub    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c6_l_2426;
x86_c6_l_2426:
	/* 0x2426: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2426, 0x252c, x86_c6_l_252c);
	goto x86_c6_l_242c;
x86_c6_l_242c:
	/* 0x242c: lea    rdx,[r14+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
	goto x86_c6_l_2430;
x86_c6_l_2430:
	/* 0x2430: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c6_l_2433;
x86_c6_l_2433:
	/* 0x2433: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c6_l_2436;
x86_c6_l_2436:
	/* 0x2436: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c14_l_253e, 0x243bULL);
x86_c6_l_243b:
	/* 0x243b: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c6_l_243d;
x86_c6_l_243d:
	/* 0x243d: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x243d, 0x24a5, x86_c6_l_24a5);
	goto x86_c6_l_243f;
x86_c6_l_243f:
	/* 0x243f: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c6_l_2444;
x86_c6_l_2444:
	/* 0x2444: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
	goto x86_c6_l_2447;
x86_c6_l_2447:
	/* 0x2447: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c6_l_244a;
x86_c6_l_244a:
	/* 0x244a: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c6_l_244d;
x86_c6_l_244d:
	/* 0x244d: sub    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c6_l_2450;
x86_c6_l_2450:
	/* 0x2450: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2450, 0x252c, x86_c6_l_252c);
	goto x86_c6_l_2456;
x86_c6_l_2456:
	/* 0x2456: lea    rdx,[r14+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
	goto x86_c6_l_245a;
x86_c6_l_245a:
	/* 0x245a: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c6_l_245d;
x86_c6_l_245d:
	/* 0x245d: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c6_l_2460;
x86_c6_l_2460:
	/* 0x2460: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c15_l_253e, 0x2465ULL);
x86_c6_l_2465:
	/* 0x2465: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c6_l_2467;
x86_c6_l_2467:
	/* 0x2467: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2467, 0x24a5, x86_c6_l_24a5);
	goto x86_c6_l_2469;
x86_c6_l_2469:
	/* 0x2469: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c6_l_246e;
x86_c6_l_246e:
	/* 0x246e: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
	goto x86_c6_l_2471;
x86_c6_l_2471:
	/* 0x2471: add    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c6_l_2474;
x86_c6_l_2474:
	/* 0x2474: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c6_l_2477;
x86_c6_l_2477:
	/* 0x2477: sub    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c6_l_247a;
x86_c6_l_247a:
	/* 0x247a: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x247a, 0x252c, x86_c6_l_252c);
	goto x86_c6_l_2480;
x86_c6_l_2480:
	/* 0x2480: add    r14,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c6_l_2483;
x86_c6_l_2483:
	/* 0x2483: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c6_l_2486;
x86_c6_l_2486:
	/* 0x2486: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c6_l_2489;
x86_c6_l_2489:
	/* 0x2489: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
	goto x86_c6_l_248c;
x86_c6_l_248c:
	/* 0x248c: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c16_l_253e, 0x2491ULL);
x86_c6_l_2491:
	/* 0x2491: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c6_l_2493;
x86_c6_l_2493:
	/* 0x2493: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2493, 0x24a5, x86_c6_l_24a5);
	goto x86_c6_l_2495;
x86_c6_l_2495:
	/* 0x2495: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c6_l_249a;
x86_c6_l_249a:
	/* 0x249a: add    rax,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c6_l_249d;
x86_c6_l_249d:
	/* 0x249d: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
	goto x86_c6_l_24a0;
x86_c6_l_24a0:
	/* 0x24a0: jmp    252c <do_bytes+0x24e> */
	X86_SIM_X86_JMP(0x24a0, 0x252c, x86_c6_l_252c);
x86_c6_l_24a5:
	/* 0x24a5: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c6_l_24a8;
x86_c6_l_24a8:
	/* 0x24a8: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c6_l_24b0;
x86_c6_l_24b0:
	/* 0x24b0: mov    rdi,QWORD PTR [rip+0x3c0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_stats_map));
	goto x86_c6_l_24b7;
x86_c6_l_24b7:
	/* 0x24b7: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c6_l_24bc;
x86_c6_l_24bc:
	/* 0x24bc: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c6_l_24c1;
x86_c6_l_24c1:
	/* 0x24c1: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c6_l_24c3;
x86_c6_l_24c3:
	/* 0x24c3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c6_l_24c6;
x86_c6_l_24c6:
	/* 0x24c6: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24c6, 0x252c, x86_c6_l_252c);
	goto x86_c6_l_24c8;
x86_c6_l_24c8:
	/* 0x24c8: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551604ULL);
	goto x86_c6_l_24cc;
x86_c6_l_24cc:
	/* 0x24cc: jg     24e8 <do_bytes+0x20a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x24cc, 0x24e8, x86_c6_l_24e8);
	goto x86_c6_l_24ce;
x86_c6_l_24ce:
	/* 0x24ce: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551588ULL);
	goto x86_c6_l_24d2;
x86_c6_l_24d2:
	/* 0x24d2: je     2502 <do_bytes+0x224> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24d2, 0x2502, x86_c6_l_2502);
	goto x86_c6_l_24d4;
x86_c6_l_24d4:
	/* 0x24d4: cmp    rbx,0xffffffffffffffea */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551594ULL);
	goto x86_c6_l_24d8;
x86_c6_l_24d8:
	/* 0x24d8: je     251a <do_bytes+0x23c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24d8, 0x251a, x86_c6_l_251a);
	goto x86_c6_l_24da;
x86_c6_l_24da:
	/* 0x24da: cmp    rbx,0xfffffffffffffff0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551600ULL);
	goto x86_c6_l_24de;
x86_c6_l_24de:
	/* 0x24de: jne    2512 <do_bytes+0x234> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24de, 0x2512, x86_c6_l_2512);
	goto x86_c6_l_24e0;
x86_c6_l_24e0:
	/* 0x24e0: add    rax,0x558 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1368ULL);
	goto x86_c6_l_24e6;
x86_c6_l_24e6:
	/* 0x24e6: jmp    2528 <do_bytes+0x24a> */
	X86_SIM_X86_JMP(0x24e6, 0x2528, x86_c6_l_2528);
x86_c6_l_24e8:
	/* 0x24e8: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551605ULL);
	goto x86_c6_l_24ec;
x86_c6_l_24ec:
	/* 0x24ec: je     250a <do_bytes+0x22c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24ec, 0x250a, x86_c6_l_250a);
	goto x86_c6_l_24ee;
x86_c6_l_24ee:
	/* 0x24ee: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551609ULL);
	goto x86_c6_l_24f2;
x86_c6_l_24f2:
	/* 0x24f2: je     2522 <do_bytes+0x244> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24f2, 0x2522, x86_c6_l_2522);
	goto x86_c6_l_24f4;
x86_c6_l_24f4:
	/* 0x24f4: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551614ULL);
	goto x86_c6_l_24f8;
x86_c6_l_24f8:
	/* 0x24f8: jne    2512 <do_bytes+0x234> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24f8, 0x2512, x86_c6_l_2512);
	goto x86_c6_l_24fa;
x86_c6_l_24fa:
	/* 0x24fa: add    rax,0x548 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1352ULL);
	goto x86_c6_l_2500;
x86_c6_l_2500:
	/* 0x2500: jmp    2528 <do_bytes+0x24a> */
	X86_SIM_X86_JMP(0x2500, 0x2528, x86_c6_l_2528);
x86_c6_l_2502:
	/* 0x2502: add    rax,0x568 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1384ULL);
	goto x86_c6_l_2508;
x86_c6_l_2508:
	/* 0x2508: jmp    2528 <do_bytes+0x24a> */
	X86_SIM_X86_JMP(0x2508, 0x2528, x86_c6_l_2528);
x86_c6_l_250a:
	/* 0x250a: add    rax,0x570 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1392ULL);
	goto x86_c6_l_2510;
x86_c6_l_2510:
	/* 0x2510: jmp    2528 <do_bytes+0x24a> */
	X86_SIM_X86_JMP(0x2510, 0x2528, x86_c6_l_2528);
x86_c6_l_2512:
	/* 0x2512: add    rax,0x540 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1344ULL);
	goto x86_c6_l_2518;
x86_c6_l_2518:
	/* 0x2518: jmp    2528 <do_bytes+0x24a> */
	X86_SIM_X86_JMP(0x2518, 0x2528, x86_c6_l_2528);
x86_c6_l_251a:
	/* 0x251a: add    rax,0x560 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1376ULL);
	goto x86_c6_l_2520;
x86_c6_l_2520:
	/* 0x2520: jmp    2528 <do_bytes+0x24a> */
	X86_SIM_X86_JMP(0x2520, 0x2528, x86_c6_l_2528);
x86_c6_l_2522:
	/* 0x2522: add    rax,0x550 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1360ULL);
	goto x86_c6_l_2528;
x86_c6_l_2528:
	/* 0x2528: inc QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
	goto x86_c6_l_252c;
x86_c6_l_252c:
	/* 0x252c: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c6_l_252f;
x86_c6_l_252f:
	/* 0x252f: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c6_l_2533;
x86_c6_l_2533:
	/* 0x2533: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c6_l_2534;
x86_c6_l_2534:
	/* 0x2534: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c6_l_2536;
x86_c6_l_2536:
	/* 0x2536: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
	goto x86_c6_l_2538;
x86_c6_l_2538:
	/* 0x2538: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c6_l_253a;
x86_c6_l_253a:
	/* 0x253a: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c6_l_253c;
x86_c6_l_253c:
	/* 0x253c: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
	goto x86_c6_l_253d;
x86_c6_l_253d:
	/* 0x253d: ret */
	X86_SIM_X86_SUB_RET(x86_c6_l_253d_ret);
x86_c6_l_253d_ret:
	switch (__x86_sim_ret_addr) {
	case 0x20e9ULL: goto x86_c5_l_20e9;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c7_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c7_l_2540;
x86_c7_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c7_l_2542;
x86_c7_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c7_l_2544;
x86_c7_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c7_l_2545;
x86_c7_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c7_l_2546;
x86_c7_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c7_l_2549;
x86_c7_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c7_l_25cb);
	goto x86_c7_l_254f;
x86_c7_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c7_l_2552;
x86_c7_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c7_l_2555;
x86_c7_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c7_l_255c;
x86_c7_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c7_l_2561;
x86_c7_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c7_l_2565;
x86_c7_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c7_l_2569;
x86_c7_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c7_l_256e;
x86_c7_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c7_l_2570;
x86_c7_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c7_l_2572;
x86_c7_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c7_l_2574;
x86_c7_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c7_l_25f0);
	goto x86_c7_l_2576;
x86_c7_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c7_l_257a;
x86_c7_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c7_l_257e;
x86_c7_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c7_l_2586;
x86_c7_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c7_l_258d;
x86_c7_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c7_l_2592;
x86_c7_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c7_l_2597;
x86_c7_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c7_l_2599;
x86_c7_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c7_l_259c;
x86_c7_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c7_l_25d4);
	goto x86_c7_l_259e;
x86_c7_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c7_l_25a2;
x86_c7_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c7_l_25d4);
	goto x86_c7_l_25a4;
x86_c7_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c7_l_25ab;
x86_c7_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c7_l_25b0;
x86_c7_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c7_l_25b5;
x86_c7_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c7_l_25b8;
x86_c7_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c7_l_25bd;
x86_c7_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c7_l_25c0;
x86_c7_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c7_l_25c3;
x86_c7_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c7_l_25c5;
x86_c7_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c7_l_25c7;
x86_c7_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c7_l_25f0);
	goto x86_c7_l_25c9;
x86_c7_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c7_l_25f3);
x86_c7_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c7_l_25d2;
x86_c7_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c7_l_25f3);
x86_c7_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c7_l_25db;
x86_c7_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c7_l_25dd;
x86_c7_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c7_l_25e2;
x86_c7_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c7_l_25e5;
x86_c7_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c7_l_25e8;
x86_c7_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c7_l_25ea;
x86_c7_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c7_l_25ec;
x86_c7_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c7_l_25ee;
x86_c7_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c7_l_25f3);
	goto x86_c7_l_25f0;
x86_c7_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c7_l_25f3;
x86_c7_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c7_l_25f6;
x86_c7_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c7_l_25fa;
x86_c7_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c7_l_25fb;
x86_c7_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c7_l_25fd;
x86_c7_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c7_l_25ff;
x86_c7_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c7_l_2601;
x86_c7_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c7_l_2601_ret);
x86_c7_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x22faULL: goto x86_c6_l_22fa;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c8_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c8_l_2540;
x86_c8_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c8_l_2542;
x86_c8_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c8_l_2544;
x86_c8_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c8_l_2545;
x86_c8_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c8_l_2546;
x86_c8_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c8_l_2549;
x86_c8_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c8_l_25cb);
	goto x86_c8_l_254f;
x86_c8_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c8_l_2552;
x86_c8_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c8_l_2555;
x86_c8_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c8_l_255c;
x86_c8_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c8_l_2561;
x86_c8_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c8_l_2565;
x86_c8_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c8_l_2569;
x86_c8_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c8_l_256e;
x86_c8_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c8_l_2570;
x86_c8_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c8_l_2572;
x86_c8_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c8_l_2574;
x86_c8_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c8_l_25f0);
	goto x86_c8_l_2576;
x86_c8_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c8_l_257a;
x86_c8_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c8_l_257e;
x86_c8_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c8_l_2586;
x86_c8_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c8_l_258d;
x86_c8_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c8_l_2592;
x86_c8_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c8_l_2597;
x86_c8_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c8_l_2599;
x86_c8_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c8_l_259c;
x86_c8_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c8_l_25d4);
	goto x86_c8_l_259e;
x86_c8_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c8_l_25a2;
x86_c8_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c8_l_25d4);
	goto x86_c8_l_25a4;
x86_c8_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c8_l_25ab;
x86_c8_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c8_l_25b0;
x86_c8_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c8_l_25b5;
x86_c8_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c8_l_25b8;
x86_c8_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c8_l_25bd;
x86_c8_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c8_l_25c0;
x86_c8_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c8_l_25c3;
x86_c8_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c8_l_25c5;
x86_c8_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c8_l_25c7;
x86_c8_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c8_l_25f0);
	goto x86_c8_l_25c9;
x86_c8_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c8_l_25f3);
x86_c8_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c8_l_25d2;
x86_c8_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c8_l_25f3);
x86_c8_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c8_l_25db;
x86_c8_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c8_l_25dd;
x86_c8_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c8_l_25e2;
x86_c8_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c8_l_25e5;
x86_c8_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c8_l_25e8;
x86_c8_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c8_l_25ea;
x86_c8_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c8_l_25ec;
x86_c8_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c8_l_25ee;
x86_c8_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c8_l_25f3);
	goto x86_c8_l_25f0;
x86_c8_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c8_l_25f3;
x86_c8_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c8_l_25f6;
x86_c8_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c8_l_25fa;
x86_c8_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c8_l_25fb;
x86_c8_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c8_l_25fd;
x86_c8_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c8_l_25ff;
x86_c8_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c8_l_2601;
x86_c8_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c8_l_2601_ret);
x86_c8_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x2327ULL: goto x86_c6_l_2327;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c9_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c9_l_2540;
x86_c9_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c9_l_2542;
x86_c9_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c9_l_2544;
x86_c9_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c9_l_2545;
x86_c9_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c9_l_2546;
x86_c9_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c9_l_2549;
x86_c9_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c9_l_25cb);
	goto x86_c9_l_254f;
x86_c9_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c9_l_2552;
x86_c9_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c9_l_2555;
x86_c9_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c9_l_255c;
x86_c9_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c9_l_2561;
x86_c9_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c9_l_2565;
x86_c9_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c9_l_2569;
x86_c9_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c9_l_256e;
x86_c9_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c9_l_2570;
x86_c9_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c9_l_2572;
x86_c9_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c9_l_2574;
x86_c9_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c9_l_25f0);
	goto x86_c9_l_2576;
x86_c9_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c9_l_257a;
x86_c9_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c9_l_257e;
x86_c9_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c9_l_2586;
x86_c9_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c9_l_258d;
x86_c9_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c9_l_2592;
x86_c9_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c9_l_2597;
x86_c9_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c9_l_2599;
x86_c9_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c9_l_259c;
x86_c9_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c9_l_25d4);
	goto x86_c9_l_259e;
x86_c9_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c9_l_25a2;
x86_c9_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c9_l_25d4);
	goto x86_c9_l_25a4;
x86_c9_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c9_l_25ab;
x86_c9_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c9_l_25b0;
x86_c9_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c9_l_25b5;
x86_c9_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c9_l_25b8;
x86_c9_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c9_l_25bd;
x86_c9_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c9_l_25c0;
x86_c9_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c9_l_25c3;
x86_c9_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c9_l_25c5;
x86_c9_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c9_l_25c7;
x86_c9_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c9_l_25f0);
	goto x86_c9_l_25c9;
x86_c9_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c9_l_25f3);
x86_c9_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c9_l_25d2;
x86_c9_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c9_l_25f3);
x86_c9_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c9_l_25db;
x86_c9_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c9_l_25dd;
x86_c9_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c9_l_25e2;
x86_c9_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c9_l_25e5;
x86_c9_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c9_l_25e8;
x86_c9_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c9_l_25ea;
x86_c9_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c9_l_25ec;
x86_c9_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c9_l_25ee;
x86_c9_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c9_l_25f3);
	goto x86_c9_l_25f0;
x86_c9_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c9_l_25f3;
x86_c9_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c9_l_25f6;
x86_c9_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c9_l_25fa;
x86_c9_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c9_l_25fb;
x86_c9_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c9_l_25fd;
x86_c9_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c9_l_25ff;
x86_c9_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c9_l_2601;
x86_c9_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c9_l_2601_ret);
x86_c9_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x2355ULL: goto x86_c6_l_2355;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c10_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c10_l_2540;
x86_c10_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c10_l_2542;
x86_c10_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c10_l_2544;
x86_c10_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c10_l_2545;
x86_c10_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c10_l_2546;
x86_c10_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c10_l_2549;
x86_c10_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c10_l_25cb);
	goto x86_c10_l_254f;
x86_c10_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c10_l_2552;
x86_c10_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c10_l_2555;
x86_c10_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c10_l_255c;
x86_c10_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c10_l_2561;
x86_c10_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c10_l_2565;
x86_c10_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c10_l_2569;
x86_c10_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c10_l_256e;
x86_c10_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c10_l_2570;
x86_c10_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c10_l_2572;
x86_c10_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c10_l_2574;
x86_c10_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c10_l_25f0);
	goto x86_c10_l_2576;
x86_c10_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c10_l_257a;
x86_c10_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c10_l_257e;
x86_c10_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c10_l_2586;
x86_c10_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c10_l_258d;
x86_c10_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c10_l_2592;
x86_c10_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c10_l_2597;
x86_c10_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c10_l_2599;
x86_c10_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c10_l_259c;
x86_c10_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c10_l_25d4);
	goto x86_c10_l_259e;
x86_c10_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c10_l_25a2;
x86_c10_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c10_l_25d4);
	goto x86_c10_l_25a4;
x86_c10_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c10_l_25ab;
x86_c10_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c10_l_25b0;
x86_c10_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c10_l_25b5;
x86_c10_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c10_l_25b8;
x86_c10_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c10_l_25bd;
x86_c10_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c10_l_25c0;
x86_c10_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c10_l_25c3;
x86_c10_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c10_l_25c5;
x86_c10_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c10_l_25c7;
x86_c10_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c10_l_25f0);
	goto x86_c10_l_25c9;
x86_c10_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c10_l_25f3);
x86_c10_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c10_l_25d2;
x86_c10_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c10_l_25f3);
x86_c10_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c10_l_25db;
x86_c10_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c10_l_25dd;
x86_c10_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c10_l_25e2;
x86_c10_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c10_l_25e5;
x86_c10_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c10_l_25e8;
x86_c10_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c10_l_25ea;
x86_c10_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c10_l_25ec;
x86_c10_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c10_l_25ee;
x86_c10_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c10_l_25f3);
	goto x86_c10_l_25f0;
x86_c10_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c10_l_25f3;
x86_c10_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c10_l_25f6;
x86_c10_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c10_l_25fa;
x86_c10_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c10_l_25fb;
x86_c10_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c10_l_25fd;
x86_c10_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c10_l_25ff;
x86_c10_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c10_l_2601;
x86_c10_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c10_l_2601_ret);
x86_c10_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x2383ULL: goto x86_c6_l_2383;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c11_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c11_l_2540;
x86_c11_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c11_l_2542;
x86_c11_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c11_l_2544;
x86_c11_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c11_l_2545;
x86_c11_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c11_l_2546;
x86_c11_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c11_l_2549;
x86_c11_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c11_l_25cb);
	goto x86_c11_l_254f;
x86_c11_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c11_l_2552;
x86_c11_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c11_l_2555;
x86_c11_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c11_l_255c;
x86_c11_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c11_l_2561;
x86_c11_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c11_l_2565;
x86_c11_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c11_l_2569;
x86_c11_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c11_l_256e;
x86_c11_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c11_l_2570;
x86_c11_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c11_l_2572;
x86_c11_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c11_l_2574;
x86_c11_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c11_l_25f0);
	goto x86_c11_l_2576;
x86_c11_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c11_l_257a;
x86_c11_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c11_l_257e;
x86_c11_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c11_l_2586;
x86_c11_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c11_l_258d;
x86_c11_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c11_l_2592;
x86_c11_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c11_l_2597;
x86_c11_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c11_l_2599;
x86_c11_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c11_l_259c;
x86_c11_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c11_l_25d4);
	goto x86_c11_l_259e;
x86_c11_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c11_l_25a2;
x86_c11_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c11_l_25d4);
	goto x86_c11_l_25a4;
x86_c11_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c11_l_25ab;
x86_c11_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c11_l_25b0;
x86_c11_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c11_l_25b5;
x86_c11_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c11_l_25b8;
x86_c11_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c11_l_25bd;
x86_c11_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c11_l_25c0;
x86_c11_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c11_l_25c3;
x86_c11_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c11_l_25c5;
x86_c11_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c11_l_25c7;
x86_c11_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c11_l_25f0);
	goto x86_c11_l_25c9;
x86_c11_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c11_l_25f3);
x86_c11_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c11_l_25d2;
x86_c11_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c11_l_25f3);
x86_c11_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c11_l_25db;
x86_c11_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c11_l_25dd;
x86_c11_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c11_l_25e2;
x86_c11_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c11_l_25e5;
x86_c11_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c11_l_25e8;
x86_c11_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c11_l_25ea;
x86_c11_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c11_l_25ec;
x86_c11_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c11_l_25ee;
x86_c11_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c11_l_25f3);
	goto x86_c11_l_25f0;
x86_c11_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c11_l_25f3;
x86_c11_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c11_l_25f6;
x86_c11_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c11_l_25fa;
x86_c11_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c11_l_25fb;
x86_c11_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c11_l_25fd;
x86_c11_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c11_l_25ff;
x86_c11_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c11_l_2601;
x86_c11_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c11_l_2601_ret);
x86_c11_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x23b1ULL: goto x86_c6_l_23b1;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c12_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c12_l_2540;
x86_c12_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c12_l_2542;
x86_c12_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c12_l_2544;
x86_c12_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c12_l_2545;
x86_c12_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c12_l_2546;
x86_c12_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c12_l_2549;
x86_c12_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c12_l_25cb);
	goto x86_c12_l_254f;
x86_c12_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c12_l_2552;
x86_c12_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c12_l_2555;
x86_c12_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c12_l_255c;
x86_c12_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c12_l_2561;
x86_c12_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c12_l_2565;
x86_c12_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c12_l_2569;
x86_c12_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c12_l_256e;
x86_c12_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c12_l_2570;
x86_c12_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c12_l_2572;
x86_c12_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c12_l_2574;
x86_c12_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c12_l_25f0);
	goto x86_c12_l_2576;
x86_c12_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c12_l_257a;
x86_c12_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c12_l_257e;
x86_c12_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c12_l_2586;
x86_c12_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c12_l_258d;
x86_c12_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c12_l_2592;
x86_c12_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c12_l_2597;
x86_c12_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c12_l_2599;
x86_c12_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c12_l_259c;
x86_c12_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c12_l_25d4);
	goto x86_c12_l_259e;
x86_c12_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c12_l_25a2;
x86_c12_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c12_l_25d4);
	goto x86_c12_l_25a4;
x86_c12_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c12_l_25ab;
x86_c12_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c12_l_25b0;
x86_c12_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c12_l_25b5;
x86_c12_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c12_l_25b8;
x86_c12_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c12_l_25bd;
x86_c12_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c12_l_25c0;
x86_c12_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c12_l_25c3;
x86_c12_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c12_l_25c5;
x86_c12_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c12_l_25c7;
x86_c12_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c12_l_25f0);
	goto x86_c12_l_25c9;
x86_c12_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c12_l_25f3);
x86_c12_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c12_l_25d2;
x86_c12_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c12_l_25f3);
x86_c12_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c12_l_25db;
x86_c12_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c12_l_25dd;
x86_c12_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c12_l_25e2;
x86_c12_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c12_l_25e5;
x86_c12_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c12_l_25e8;
x86_c12_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c12_l_25ea;
x86_c12_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c12_l_25ec;
x86_c12_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c12_l_25ee;
x86_c12_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c12_l_25f3);
	goto x86_c12_l_25f0;
x86_c12_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c12_l_25f3;
x86_c12_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c12_l_25f6;
x86_c12_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c12_l_25fa;
x86_c12_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c12_l_25fb;
x86_c12_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c12_l_25fd;
x86_c12_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c12_l_25ff;
x86_c12_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c12_l_2601;
x86_c12_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c12_l_2601_ret);
x86_c12_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x23dfULL: goto x86_c6_l_23df;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c13_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c13_l_2540;
x86_c13_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c13_l_2542;
x86_c13_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c13_l_2544;
x86_c13_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c13_l_2545;
x86_c13_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c13_l_2546;
x86_c13_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c13_l_2549;
x86_c13_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c13_l_25cb);
	goto x86_c13_l_254f;
x86_c13_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c13_l_2552;
x86_c13_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c13_l_2555;
x86_c13_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c13_l_255c;
x86_c13_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c13_l_2561;
x86_c13_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c13_l_2565;
x86_c13_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c13_l_2569;
x86_c13_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c13_l_256e;
x86_c13_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c13_l_2570;
x86_c13_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c13_l_2572;
x86_c13_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c13_l_2574;
x86_c13_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c13_l_25f0);
	goto x86_c13_l_2576;
x86_c13_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c13_l_257a;
x86_c13_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c13_l_257e;
x86_c13_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c13_l_2586;
x86_c13_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c13_l_258d;
x86_c13_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c13_l_2592;
x86_c13_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c13_l_2597;
x86_c13_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c13_l_2599;
x86_c13_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c13_l_259c;
x86_c13_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c13_l_25d4);
	goto x86_c13_l_259e;
x86_c13_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c13_l_25a2;
x86_c13_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c13_l_25d4);
	goto x86_c13_l_25a4;
x86_c13_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c13_l_25ab;
x86_c13_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c13_l_25b0;
x86_c13_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c13_l_25b5;
x86_c13_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c13_l_25b8;
x86_c13_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c13_l_25bd;
x86_c13_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c13_l_25c0;
x86_c13_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c13_l_25c3;
x86_c13_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c13_l_25c5;
x86_c13_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c13_l_25c7;
x86_c13_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c13_l_25f0);
	goto x86_c13_l_25c9;
x86_c13_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c13_l_25f3);
x86_c13_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c13_l_25d2;
x86_c13_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c13_l_25f3);
x86_c13_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c13_l_25db;
x86_c13_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c13_l_25dd;
x86_c13_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c13_l_25e2;
x86_c13_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c13_l_25e5;
x86_c13_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c13_l_25e8;
x86_c13_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c13_l_25ea;
x86_c13_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c13_l_25ec;
x86_c13_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c13_l_25ee;
x86_c13_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c13_l_25f3);
	goto x86_c13_l_25f0;
x86_c13_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c13_l_25f3;
x86_c13_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c13_l_25f6;
x86_c13_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c13_l_25fa;
x86_c13_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c13_l_25fb;
x86_c13_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c13_l_25fd;
x86_c13_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c13_l_25ff;
x86_c13_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c13_l_2601;
x86_c13_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c13_l_2601_ret);
x86_c13_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x240dULL: goto x86_c6_l_240d;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c14_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c14_l_2540;
x86_c14_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c14_l_2542;
x86_c14_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c14_l_2544;
x86_c14_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c14_l_2545;
x86_c14_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c14_l_2546;
x86_c14_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c14_l_2549;
x86_c14_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c14_l_25cb);
	goto x86_c14_l_254f;
x86_c14_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c14_l_2552;
x86_c14_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c14_l_2555;
x86_c14_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c14_l_255c;
x86_c14_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c14_l_2561;
x86_c14_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c14_l_2565;
x86_c14_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c14_l_2569;
x86_c14_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c14_l_256e;
x86_c14_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c14_l_2570;
x86_c14_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c14_l_2572;
x86_c14_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c14_l_2574;
x86_c14_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c14_l_25f0);
	goto x86_c14_l_2576;
x86_c14_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c14_l_257a;
x86_c14_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c14_l_257e;
x86_c14_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c14_l_2586;
x86_c14_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c14_l_258d;
x86_c14_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c14_l_2592;
x86_c14_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c14_l_2597;
x86_c14_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c14_l_2599;
x86_c14_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c14_l_259c;
x86_c14_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c14_l_25d4);
	goto x86_c14_l_259e;
x86_c14_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c14_l_25a2;
x86_c14_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c14_l_25d4);
	goto x86_c14_l_25a4;
x86_c14_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c14_l_25ab;
x86_c14_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c14_l_25b0;
x86_c14_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c14_l_25b5;
x86_c14_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c14_l_25b8;
x86_c14_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c14_l_25bd;
x86_c14_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c14_l_25c0;
x86_c14_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c14_l_25c3;
x86_c14_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c14_l_25c5;
x86_c14_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c14_l_25c7;
x86_c14_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c14_l_25f0);
	goto x86_c14_l_25c9;
x86_c14_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c14_l_25f3);
x86_c14_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c14_l_25d2;
x86_c14_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c14_l_25f3);
x86_c14_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c14_l_25db;
x86_c14_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c14_l_25dd;
x86_c14_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c14_l_25e2;
x86_c14_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c14_l_25e5;
x86_c14_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c14_l_25e8;
x86_c14_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c14_l_25ea;
x86_c14_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c14_l_25ec;
x86_c14_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c14_l_25ee;
x86_c14_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c14_l_25f3);
	goto x86_c14_l_25f0;
x86_c14_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c14_l_25f3;
x86_c14_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c14_l_25f6;
x86_c14_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c14_l_25fa;
x86_c14_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c14_l_25fb;
x86_c14_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c14_l_25fd;
x86_c14_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c14_l_25ff;
x86_c14_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c14_l_2601;
x86_c14_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c14_l_2601_ret);
x86_c14_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x243bULL: goto x86_c6_l_243b;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c15_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c15_l_2540;
x86_c15_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c15_l_2542;
x86_c15_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c15_l_2544;
x86_c15_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c15_l_2545;
x86_c15_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c15_l_2546;
x86_c15_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c15_l_2549;
x86_c15_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c15_l_25cb);
	goto x86_c15_l_254f;
x86_c15_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c15_l_2552;
x86_c15_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c15_l_2555;
x86_c15_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c15_l_255c;
x86_c15_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c15_l_2561;
x86_c15_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c15_l_2565;
x86_c15_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c15_l_2569;
x86_c15_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c15_l_256e;
x86_c15_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c15_l_2570;
x86_c15_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c15_l_2572;
x86_c15_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c15_l_2574;
x86_c15_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c15_l_25f0);
	goto x86_c15_l_2576;
x86_c15_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c15_l_257a;
x86_c15_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c15_l_257e;
x86_c15_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c15_l_2586;
x86_c15_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c15_l_258d;
x86_c15_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c15_l_2592;
x86_c15_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c15_l_2597;
x86_c15_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c15_l_2599;
x86_c15_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c15_l_259c;
x86_c15_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c15_l_25d4);
	goto x86_c15_l_259e;
x86_c15_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c15_l_25a2;
x86_c15_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c15_l_25d4);
	goto x86_c15_l_25a4;
x86_c15_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c15_l_25ab;
x86_c15_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c15_l_25b0;
x86_c15_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c15_l_25b5;
x86_c15_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c15_l_25b8;
x86_c15_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c15_l_25bd;
x86_c15_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c15_l_25c0;
x86_c15_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c15_l_25c3;
x86_c15_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c15_l_25c5;
x86_c15_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c15_l_25c7;
x86_c15_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c15_l_25f0);
	goto x86_c15_l_25c9;
x86_c15_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c15_l_25f3);
x86_c15_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c15_l_25d2;
x86_c15_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c15_l_25f3);
x86_c15_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c15_l_25db;
x86_c15_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c15_l_25dd;
x86_c15_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c15_l_25e2;
x86_c15_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c15_l_25e5;
x86_c15_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c15_l_25e8;
x86_c15_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c15_l_25ea;
x86_c15_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c15_l_25ec;
x86_c15_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c15_l_25ee;
x86_c15_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c15_l_25f3);
	goto x86_c15_l_25f0;
x86_c15_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c15_l_25f3;
x86_c15_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c15_l_25f6;
x86_c15_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c15_l_25fa;
x86_c15_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c15_l_25fb;
x86_c15_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c15_l_25fd;
x86_c15_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c15_l_25ff;
x86_c15_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c15_l_2601;
x86_c15_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c15_l_2601_ret);
x86_c15_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x2465ULL: goto x86_c6_l_2465;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c16_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c16_l_2540;
x86_c16_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c16_l_2542;
x86_c16_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c16_l_2544;
x86_c16_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c16_l_2545;
x86_c16_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c16_l_2546;
x86_c16_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c16_l_2549;
x86_c16_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c16_l_25cb);
	goto x86_c16_l_254f;
x86_c16_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c16_l_2552;
x86_c16_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c16_l_2555;
x86_c16_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c16_l_255c;
x86_c16_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c16_l_2561;
x86_c16_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c16_l_2565;
x86_c16_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c16_l_2569;
x86_c16_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c16_l_256e;
x86_c16_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c16_l_2570;
x86_c16_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c16_l_2572;
x86_c16_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c16_l_2574;
x86_c16_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c16_l_25f0);
	goto x86_c16_l_2576;
x86_c16_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c16_l_257a;
x86_c16_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c16_l_257e;
x86_c16_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c16_l_2586;
x86_c16_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c16_l_258d;
x86_c16_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c16_l_2592;
x86_c16_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c16_l_2597;
x86_c16_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c16_l_2599;
x86_c16_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c16_l_259c;
x86_c16_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c16_l_25d4);
	goto x86_c16_l_259e;
x86_c16_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c16_l_25a2;
x86_c16_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c16_l_25d4);
	goto x86_c16_l_25a4;
x86_c16_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c16_l_25ab;
x86_c16_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c16_l_25b0;
x86_c16_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c16_l_25b5;
x86_c16_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c16_l_25b8;
x86_c16_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c16_l_25bd;
x86_c16_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c16_l_25c0;
x86_c16_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c16_l_25c3;
x86_c16_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c16_l_25c5;
x86_c16_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c16_l_25c7;
x86_c16_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c16_l_25f0);
	goto x86_c16_l_25c9;
x86_c16_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c16_l_25f3);
x86_c16_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c16_l_25d2;
x86_c16_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c16_l_25f3);
x86_c16_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c16_l_25db;
x86_c16_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c16_l_25dd;
x86_c16_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c16_l_25e2;
x86_c16_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c16_l_25e5;
x86_c16_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c16_l_25e8;
x86_c16_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c16_l_25ea;
x86_c16_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c16_l_25ec;
x86_c16_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c16_l_25ee;
x86_c16_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c16_l_25f3);
	goto x86_c16_l_25f0;
x86_c16_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c16_l_25f3;
x86_c16_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c16_l_25f6;
x86_c16_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c16_l_25fa;
x86_c16_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c16_l_25fb;
x86_c16_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c16_l_25fd;
x86_c16_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c16_l_25ff;
x86_c16_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c16_l_2601;
x86_c16_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c16_l_2601_ret);
x86_c16_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x2491ULL: goto x86_c6_l_2491;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c17_l_205c:
	/* 0x205c: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
	goto x86_c17_l_205d;
x86_c17_l_205d:
	/* 0x205d: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c17_l_205f;
x86_c17_l_205f:
	/* 0x205f: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c17_l_2061;
x86_c17_l_2061:
	/* 0x2061: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
	goto x86_c17_l_2063;
x86_c17_l_2063:
	/* 0x2063: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c17_l_2065;
x86_c17_l_2065:
	/* 0x2065: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c17_l_2066;
x86_c17_l_2066:
	/* 0x2066: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c17_l_2067;
x86_c17_l_2067:
	/* 0x2067: mov    r14,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RCX, X86_WIDTH_64);
	goto x86_c17_l_206a;
x86_c17_l_206a:
	/* 0x206a: mov    r15,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RDX, X86_WIDTH_64);
	goto x86_c17_l_206d;
x86_c17_l_206d:
	/* 0x206d: mov    rbx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RSI, X86_WIDTH_64);
	goto x86_c17_l_2070;
x86_c17_l_2070:
	/* 0x2070: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c17_l_2073;
x86_c17_l_2073:
	/* 0x2073: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c17_l_207b;
x86_c17_l_207b:
	/* 0x207b: mov    rdi,QWORD PTR [rip+0x2e0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)data_heap));
	goto x86_c17_l_2082;
x86_c17_l_2082:
	/* 0x2082: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c17_l_2087;
x86_c17_l_2087:
	/* 0x2087: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c17_l_208c;
x86_c17_l_208c:
	/* 0x208c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c17_l_208e;
x86_c17_l_208e:
	/* 0x208e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c17_l_2091;
x86_c17_l_2091:
	/* 0x2091: je     2104 <data_event_bytes+0xa8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2091, 0x2104, x86_c17_l_2104);
	goto x86_c17_l_2093;
x86_c17_l_2093:
	/* 0x2093: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
	goto x86_c17_l_2096;
x86_c17_l_2096:
	/* 0x2096: mov    DWORD PTR [rax],0x18 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c17_l_209c;
x86_c17_l_209c:
	/* 0x209c: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
	goto x86_c17_l_20a1;
x86_c17_l_20a1:
	/* 0x20a1: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c17_l_20a3;
x86_c17_l_20a3:
	/* 0x20a3: mov    rbp,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_R13, X86_WIDTH_64);
	goto x86_c17_l_20a6;
x86_c17_l_20a6:
	/* 0x20a6: add    rbp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
	goto x86_c17_l_20aa;
x86_c17_l_20aa:
	/* 0x20aa: mov    QWORD PTR [r13+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c17_l_20ae;
x86_c17_l_20ae:
	/* 0x20ae: cmp    rax,0xffffffffffffffea */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 18446744073709551594ULL);
	goto x86_c17_l_20b2;
x86_c17_l_20b2:
	/* 0x20b2: jne    20bd <data_event_bytes+0x61> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20b2, 0x20bd, x86_c17_l_20bd);
	goto x86_c17_l_20b4;
x86_c17_l_20b4:
	/* 0x20b4: mov    rax,QWORD PTR [r12+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c17_l_20b9;
x86_c17_l_20b9:
	/* 0x20b9: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c17_l_20bd;
x86_c17_l_20bd:
	/* 0x20bd: mov    eax,0x7d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 125ULL);
	goto x86_c17_l_20c2;
x86_c17_l_20c2:
	/* 0x20c2: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x7dULL: X86_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x7dULL: X86_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c17_l_20c4;
x86_c17_l_20c4:
	/* 0x20c4: mov    QWORD PTR [r13+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c17_l_20c8;
x86_c17_l_20c8:
	/* 0x20c8: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c17_l_20cc;
x86_c17_l_20cc:
	/* 0x20cc: mov    rcx,QWORD PTR [rbp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
	goto x86_c17_l_20d0;
x86_c17_l_20d0:
	/* 0x20d0: mov    QWORD PTR [rbx+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	goto x86_c17_l_20d4;
x86_c17_l_20d4:
	/* 0x20d4: mov    QWORD PTR [rbx+0x18],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
	goto x86_c17_l_20d8;
x86_c17_l_20d8:
	/* 0x20d8: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c17_l_20db;
x86_c17_l_20db:
	/* 0x20db: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
	goto x86_c17_l_20de;
x86_c17_l_20de:
	/* 0x20de: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c17_l_20e1;
x86_c17_l_20e1:
	/* 0x20e1: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c17_l_20e4;
x86_c17_l_20e4:
	/* 0x20e4: call   22de <do_bytes> */
	X86_SIM_X86_CALL(x86_c18_l_22de, 0x20e9ULL);
x86_c17_l_20e9:
	/* 0x20e9: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c17_l_20eb;
x86_c17_l_20eb:
	/* 0x20eb: js     2108 <data_event_bytes+0xac> */
	X86_SIM_X86_JCC(X86_CC_S, 0x20eb, 0x2108, x86_c17_l_2108);
	goto x86_c17_l_20ed;
x86_c17_l_20ed:
	/* 0x20ed: mov    QWORD PTR [rbx],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c17_l_20f4;
x86_c17_l_20f4:
	/* 0x20f4: mov    edx,r14d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_32);
	goto x86_c17_l_20f7;
x86_c17_l_20f7:
	/* 0x20f7: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
	goto x86_c17_l_20f9;
x86_c17_l_20f9:
	/* 0x20f9: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c17_l_20fb;
x86_c17_l_20fb:
	/* 0x20fb: cmp    r14,0xffffffffffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R14, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c17_l_20ff;
x86_c17_l_20ff:
	/* 0x20ff: cmovne ecx,edx */
	X86_SIM_L_EXEC_CMOV(X86_RCX, X86_RDX, X86_WIDTH_32, X86_CC_NE);
	goto x86_c17_l_2102;
x86_c17_l_2102:
	/* 0x2102: jmp    2115 <data_event_bytes+0xb9> */
	X86_SIM_X86_JMP(0x2102, 0x2115, x86_c17_l_2115);
x86_c17_l_2104:
	/* 0x2104: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c17_l_2106;
x86_c17_l_2106:
	/* 0x2106: jmp    2120 <data_event_bytes+0xc4> */
	X86_SIM_X86_JMP(0x2106, 0x2120, x86_c17_l_2120);
x86_c17_l_2108:
	/* 0x2108: mov    DWORD PTR [rbx],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c17_l_210a;
x86_c17_l_210a:
	/* 0x210a: mov    DWORD PTR [rbx+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c17_l_2111;
x86_c17_l_2111:
	/* 0x2111: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c17_l_2113;
x86_c17_l_2113:
	/* 0x2113: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c17_l_2115;
x86_c17_l_2115:
	/* 0x2115: mov    DWORD PTR [rbx+0x8],ecx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
	goto x86_c17_l_2118;
x86_c17_l_2118:
	/* 0x2118: mov    DWORD PTR [rbx+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
	goto x86_c17_l_211b;
x86_c17_l_211b:
	/* 0x211b: mov    eax,0x20 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 32ULL);
	goto x86_c17_l_2120;
x86_c17_l_2120:
	/* 0x2120: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c17_l_2124;
x86_c17_l_2124:
	/* 0x2124: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c17_l_2125;
x86_c17_l_2125:
	/* 0x2125: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c17_l_2127;
x86_c17_l_2127:
	/* 0x2127: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
	goto x86_c17_l_2129;
x86_c17_l_2129:
	/* 0x2129: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c17_l_212b;
x86_c17_l_212b:
	/* 0x212b: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c17_l_212d;
x86_c17_l_212d:
	/* 0x212d: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
	goto x86_c17_l_212e;
x86_c17_l_212e:
	/* 0x212e: ret */
	X86_SIM_X86_SUB_RET(x86_c17_l_212e_ret);
x86_c17_l_212e_ret:
	switch (__x86_sim_ret_addr) {
	case 0x1764ULL: goto x86_c0_l_1764;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c18_l_22de:
	/* 0x22de: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
	goto x86_c18_l_22df;
x86_c18_l_22df:
	/* 0x22df: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c18_l_22e1;
x86_c18_l_22e1:
	/* 0x22e1: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c18_l_22e3;
x86_c18_l_22e3:
	/* 0x22e3: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
	goto x86_c18_l_22e5;
x86_c18_l_22e5:
	/* 0x22e5: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c18_l_22e7;
x86_c18_l_22e7:
	/* 0x22e7: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c18_l_22e8;
x86_c18_l_22e8:
	/* 0x22e8: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c18_l_22e9;
x86_c18_l_22e9:
	/* 0x22e9: mov    rbx,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RCX, X86_WIDTH_64);
	goto x86_c18_l_22ec;
x86_c18_l_22ec:
	/* 0x22ec: mov    r14,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RDX, X86_WIDTH_64);
	goto x86_c18_l_22ef;
x86_c18_l_22ef:
	/* 0x22ef: mov    r15,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RSI, X86_WIDTH_64);
	goto x86_c18_l_22f2;
x86_c18_l_22f2:
	/* 0x22f2: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c18_l_22f5;
x86_c18_l_22f5:
	/* 0x22f5: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c19_l_253e, 0x22faULL);
x86_c18_l_22fa:
	/* 0x22fa: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c18_l_22fc;
x86_c18_l_22fc:
	/* 0x22fc: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x22fc, 0x24a5, x86_c18_l_24a5);
	goto x86_c18_l_2302;
x86_c18_l_2302:
	/* 0x2302: mov    r13d,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_32);
	goto x86_c18_l_2305;
x86_c18_l_2305:
	/* 0x2305: and    r13d,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c18_l_230c;
x86_c18_l_230c:
	/* 0x230c: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c18_l_230f;
x86_c18_l_230f:
	/* 0x230f: sub    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c18_l_2312;
x86_c18_l_2312:
	/* 0x2312: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2312, 0x252c, x86_c18_l_252c);
	goto x86_c18_l_2318;
x86_c18_l_2318:
	/* 0x2318: lea    rdx,[r14+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
	goto x86_c18_l_231c;
x86_c18_l_231c:
	/* 0x231c: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c18_l_231f;
x86_c18_l_231f:
	/* 0x231f: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c18_l_2322;
x86_c18_l_2322:
	/* 0x2322: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c20_l_253e, 0x2327ULL);
x86_c18_l_2327:
	/* 0x2327: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c18_l_2329;
x86_c18_l_2329:
	/* 0x2329: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2329, 0x24a5, x86_c18_l_24a5);
	goto x86_c18_l_232f;
x86_c18_l_232f:
	/* 0x232f: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c18_l_2334;
x86_c18_l_2334:
	/* 0x2334: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
	goto x86_c18_l_2337;
x86_c18_l_2337:
	/* 0x2337: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c18_l_233a;
x86_c18_l_233a:
	/* 0x233a: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c18_l_233d;
x86_c18_l_233d:
	/* 0x233d: sub    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c18_l_2340;
x86_c18_l_2340:
	/* 0x2340: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2340, 0x252c, x86_c18_l_252c);
	goto x86_c18_l_2346;
x86_c18_l_2346:
	/* 0x2346: lea    rdx,[r14+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
	goto x86_c18_l_234a;
x86_c18_l_234a:
	/* 0x234a: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c18_l_234d;
x86_c18_l_234d:
	/* 0x234d: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c18_l_2350;
x86_c18_l_2350:
	/* 0x2350: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c21_l_253e, 0x2355ULL);
x86_c18_l_2355:
	/* 0x2355: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c18_l_2357;
x86_c18_l_2357:
	/* 0x2357: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2357, 0x24a5, x86_c18_l_24a5);
	goto x86_c18_l_235d;
x86_c18_l_235d:
	/* 0x235d: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c18_l_2362;
x86_c18_l_2362:
	/* 0x2362: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
	goto x86_c18_l_2365;
x86_c18_l_2365:
	/* 0x2365: add    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c18_l_2368;
x86_c18_l_2368:
	/* 0x2368: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c18_l_236b;
x86_c18_l_236b:
	/* 0x236b: sub    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c18_l_236e;
x86_c18_l_236e:
	/* 0x236e: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x236e, 0x252c, x86_c18_l_252c);
	goto x86_c18_l_2374;
x86_c18_l_2374:
	/* 0x2374: lea    rdx,[r14+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
	goto x86_c18_l_2378;
x86_c18_l_2378:
	/* 0x2378: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c18_l_237b;
x86_c18_l_237b:
	/* 0x237b: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c18_l_237e;
x86_c18_l_237e:
	/* 0x237e: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c22_l_253e, 0x2383ULL);
x86_c18_l_2383:
	/* 0x2383: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c18_l_2385;
x86_c18_l_2385:
	/* 0x2385: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2385, 0x24a5, x86_c18_l_24a5);
	goto x86_c18_l_238b;
x86_c18_l_238b:
	/* 0x238b: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c18_l_2390;
x86_c18_l_2390:
	/* 0x2390: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
	goto x86_c18_l_2393;
x86_c18_l_2393:
	/* 0x2393: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c18_l_2396;
x86_c18_l_2396:
	/* 0x2396: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c18_l_2399;
x86_c18_l_2399:
	/* 0x2399: sub    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c18_l_239c;
x86_c18_l_239c:
	/* 0x239c: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x239c, 0x252c, x86_c18_l_252c);
	goto x86_c18_l_23a2;
x86_c18_l_23a2:
	/* 0x23a2: lea    rdx,[r14+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
	goto x86_c18_l_23a6;
x86_c18_l_23a6:
	/* 0x23a6: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c18_l_23a9;
x86_c18_l_23a9:
	/* 0x23a9: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c18_l_23ac;
x86_c18_l_23ac:
	/* 0x23ac: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c23_l_253e, 0x23b1ULL);
x86_c18_l_23b1:
	/* 0x23b1: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c18_l_23b3;
x86_c18_l_23b3:
	/* 0x23b3: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x23b3, 0x24a5, x86_c18_l_24a5);
	goto x86_c18_l_23b9;
x86_c18_l_23b9:
	/* 0x23b9: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c18_l_23be;
x86_c18_l_23be:
	/* 0x23be: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
	goto x86_c18_l_23c1;
x86_c18_l_23c1:
	/* 0x23c1: add    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c18_l_23c4;
x86_c18_l_23c4:
	/* 0x23c4: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c18_l_23c7;
x86_c18_l_23c7:
	/* 0x23c7: sub    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c18_l_23ca;
x86_c18_l_23ca:
	/* 0x23ca: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23ca, 0x252c, x86_c18_l_252c);
	goto x86_c18_l_23d0;
x86_c18_l_23d0:
	/* 0x23d0: lea    rdx,[r14+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
	goto x86_c18_l_23d4;
x86_c18_l_23d4:
	/* 0x23d4: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c18_l_23d7;
x86_c18_l_23d7:
	/* 0x23d7: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c18_l_23da;
x86_c18_l_23da:
	/* 0x23da: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c24_l_253e, 0x23dfULL);
x86_c18_l_23df:
	/* 0x23df: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c18_l_23e1;
x86_c18_l_23e1:
	/* 0x23e1: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x23e1, 0x24a5, x86_c18_l_24a5);
	goto x86_c18_l_23e7;
x86_c18_l_23e7:
	/* 0x23e7: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c18_l_23ec;
x86_c18_l_23ec:
	/* 0x23ec: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
	goto x86_c18_l_23ef;
x86_c18_l_23ef:
	/* 0x23ef: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c18_l_23f2;
x86_c18_l_23f2:
	/* 0x23f2: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c18_l_23f5;
x86_c18_l_23f5:
	/* 0x23f5: sub    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c18_l_23f8;
x86_c18_l_23f8:
	/* 0x23f8: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23f8, 0x252c, x86_c18_l_252c);
	goto x86_c18_l_23fe;
x86_c18_l_23fe:
	/* 0x23fe: lea    rdx,[r14+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
	goto x86_c18_l_2402;
x86_c18_l_2402:
	/* 0x2402: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c18_l_2405;
x86_c18_l_2405:
	/* 0x2405: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c18_l_2408;
x86_c18_l_2408:
	/* 0x2408: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c25_l_253e, 0x240dULL);
x86_c18_l_240d:
	/* 0x240d: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c18_l_240f;
x86_c18_l_240f:
	/* 0x240f: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x240f, 0x24a5, x86_c18_l_24a5);
	goto x86_c18_l_2415;
x86_c18_l_2415:
	/* 0x2415: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c18_l_241a;
x86_c18_l_241a:
	/* 0x241a: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
	goto x86_c18_l_241d;
x86_c18_l_241d:
	/* 0x241d: add    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c18_l_2420;
x86_c18_l_2420:
	/* 0x2420: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c18_l_2423;
x86_c18_l_2423:
	/* 0x2423: sub    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c18_l_2426;
x86_c18_l_2426:
	/* 0x2426: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2426, 0x252c, x86_c18_l_252c);
	goto x86_c18_l_242c;
x86_c18_l_242c:
	/* 0x242c: lea    rdx,[r14+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
	goto x86_c18_l_2430;
x86_c18_l_2430:
	/* 0x2430: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c18_l_2433;
x86_c18_l_2433:
	/* 0x2433: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c18_l_2436;
x86_c18_l_2436:
	/* 0x2436: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c26_l_253e, 0x243bULL);
x86_c18_l_243b:
	/* 0x243b: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c18_l_243d;
x86_c18_l_243d:
	/* 0x243d: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x243d, 0x24a5, x86_c18_l_24a5);
	goto x86_c18_l_243f;
x86_c18_l_243f:
	/* 0x243f: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c18_l_2444;
x86_c18_l_2444:
	/* 0x2444: mov    rbp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RAX, X86_WIDTH_64);
	goto x86_c18_l_2447;
x86_c18_l_2447:
	/* 0x2447: add    rbp,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c18_l_244a;
x86_c18_l_244a:
	/* 0x244a: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c18_l_244d;
x86_c18_l_244d:
	/* 0x244d: sub    rcx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c18_l_2450;
x86_c18_l_2450:
	/* 0x2450: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2450, 0x252c, x86_c18_l_252c);
	goto x86_c18_l_2456;
x86_c18_l_2456:
	/* 0x2456: lea    rdx,[r14+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
	goto x86_c18_l_245a;
x86_c18_l_245a:
	/* 0x245a: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c18_l_245d;
x86_c18_l_245d:
	/* 0x245d: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c18_l_2460;
x86_c18_l_2460:
	/* 0x2460: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c27_l_253e, 0x2465ULL);
x86_c18_l_2465:
	/* 0x2465: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c18_l_2467;
x86_c18_l_2467:
	/* 0x2467: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2467, 0x24a5, x86_c18_l_24a5);
	goto x86_c18_l_2469;
x86_c18_l_2469:
	/* 0x2469: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c18_l_246e;
x86_c18_l_246e:
	/* 0x246e: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
	goto x86_c18_l_2471;
x86_c18_l_2471:
	/* 0x2471: add    r13,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c18_l_2474;
x86_c18_l_2474:
	/* 0x2474: mov    rcx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RBX, X86_WIDTH_64);
	goto x86_c18_l_2477;
x86_c18_l_2477:
	/* 0x2477: sub    rcx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R13, X86_WIDTH_64, X86_ALU_SUB);
	goto x86_c18_l_247a;
x86_c18_l_247a:
	/* 0x247a: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x247a, 0x252c, x86_c18_l_252c);
	goto x86_c18_l_2480;
x86_c18_l_2480:
	/* 0x2480: add    r14,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c18_l_2483;
x86_c18_l_2483:
	/* 0x2483: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c18_l_2486;
x86_c18_l_2486:
	/* 0x2486: mov    rsi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R15, X86_WIDTH_64);
	goto x86_c18_l_2489;
x86_c18_l_2489:
	/* 0x2489: mov    rdx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R14, X86_WIDTH_64);
	goto x86_c18_l_248c;
x86_c18_l_248c:
	/* 0x248c: call   253e <__do_bytes> */
	X86_SIM_X86_CALL(x86_c28_l_253e, 0x2491ULL);
x86_c18_l_2491:
	/* 0x2491: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c18_l_2493;
x86_c18_l_2493:
	/* 0x2493: js     24a5 <do_bytes+0x1c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2493, 0x24a5, x86_c18_l_24a5);
	goto x86_c18_l_2495;
x86_c18_l_2495:
	/* 0x2495: and    eax,0x7fffffff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
	goto x86_c18_l_249a;
x86_c18_l_249a:
	/* 0x249a: add    rax,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R13, X86_WIDTH_64, X86_ALU_ADD);
	goto x86_c18_l_249d;
x86_c18_l_249d:
	/* 0x249d: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
	goto x86_c18_l_24a0;
x86_c18_l_24a0:
	/* 0x24a0: jmp    252c <do_bytes+0x24e> */
	X86_SIM_X86_JMP(0x24a0, 0x252c, x86_c18_l_252c);
x86_c18_l_24a5:
	/* 0x24a5: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c18_l_24a8;
x86_c18_l_24a8:
	/* 0x24a8: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c18_l_24b0;
x86_c18_l_24b0:
	/* 0x24b0: mov    rdi,QWORD PTR [rip+0x3c0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_stats_map));
	goto x86_c18_l_24b7;
x86_c18_l_24b7:
	/* 0x24b7: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c18_l_24bc;
x86_c18_l_24bc:
	/* 0x24bc: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c18_l_24c1;
x86_c18_l_24c1:
	/* 0x24c1: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c18_l_24c3;
x86_c18_l_24c3:
	/* 0x24c3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c18_l_24c6;
x86_c18_l_24c6:
	/* 0x24c6: je     252c <do_bytes+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24c6, 0x252c, x86_c18_l_252c);
	goto x86_c18_l_24c8;
x86_c18_l_24c8:
	/* 0x24c8: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551604ULL);
	goto x86_c18_l_24cc;
x86_c18_l_24cc:
	/* 0x24cc: jg     24e8 <do_bytes+0x20a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x24cc, 0x24e8, x86_c18_l_24e8);
	goto x86_c18_l_24ce;
x86_c18_l_24ce:
	/* 0x24ce: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551588ULL);
	goto x86_c18_l_24d2;
x86_c18_l_24d2:
	/* 0x24d2: je     2502 <do_bytes+0x224> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24d2, 0x2502, x86_c18_l_2502);
	goto x86_c18_l_24d4;
x86_c18_l_24d4:
	/* 0x24d4: cmp    rbx,0xffffffffffffffea */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551594ULL);
	goto x86_c18_l_24d8;
x86_c18_l_24d8:
	/* 0x24d8: je     251a <do_bytes+0x23c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24d8, 0x251a, x86_c18_l_251a);
	goto x86_c18_l_24da;
x86_c18_l_24da:
	/* 0x24da: cmp    rbx,0xfffffffffffffff0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551600ULL);
	goto x86_c18_l_24de;
x86_c18_l_24de:
	/* 0x24de: jne    2512 <do_bytes+0x234> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24de, 0x2512, x86_c18_l_2512);
	goto x86_c18_l_24e0;
x86_c18_l_24e0:
	/* 0x24e0: add    rax,0x558 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1368ULL);
	goto x86_c18_l_24e6;
x86_c18_l_24e6:
	/* 0x24e6: jmp    2528 <do_bytes+0x24a> */
	X86_SIM_X86_JMP(0x24e6, 0x2528, x86_c18_l_2528);
x86_c18_l_24e8:
	/* 0x24e8: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551605ULL);
	goto x86_c18_l_24ec;
x86_c18_l_24ec:
	/* 0x24ec: je     250a <do_bytes+0x22c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24ec, 0x250a, x86_c18_l_250a);
	goto x86_c18_l_24ee;
x86_c18_l_24ee:
	/* 0x24ee: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551609ULL);
	goto x86_c18_l_24f2;
x86_c18_l_24f2:
	/* 0x24f2: je     2522 <do_bytes+0x244> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24f2, 0x2522, x86_c18_l_2522);
	goto x86_c18_l_24f4;
x86_c18_l_24f4:
	/* 0x24f4: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 18446744073709551614ULL);
	goto x86_c18_l_24f8;
x86_c18_l_24f8:
	/* 0x24f8: jne    2512 <do_bytes+0x234> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24f8, 0x2512, x86_c18_l_2512);
	goto x86_c18_l_24fa;
x86_c18_l_24fa:
	/* 0x24fa: add    rax,0x548 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1352ULL);
	goto x86_c18_l_2500;
x86_c18_l_2500:
	/* 0x2500: jmp    2528 <do_bytes+0x24a> */
	X86_SIM_X86_JMP(0x2500, 0x2528, x86_c18_l_2528);
x86_c18_l_2502:
	/* 0x2502: add    rax,0x568 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1384ULL);
	goto x86_c18_l_2508;
x86_c18_l_2508:
	/* 0x2508: jmp    2528 <do_bytes+0x24a> */
	X86_SIM_X86_JMP(0x2508, 0x2528, x86_c18_l_2528);
x86_c18_l_250a:
	/* 0x250a: add    rax,0x570 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1392ULL);
	goto x86_c18_l_2510;
x86_c18_l_2510:
	/* 0x2510: jmp    2528 <do_bytes+0x24a> */
	X86_SIM_X86_JMP(0x2510, 0x2528, x86_c18_l_2528);
x86_c18_l_2512:
	/* 0x2512: add    rax,0x540 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1344ULL);
	goto x86_c18_l_2518;
x86_c18_l_2518:
	/* 0x2518: jmp    2528 <do_bytes+0x24a> */
	X86_SIM_X86_JMP(0x2518, 0x2528, x86_c18_l_2528);
x86_c18_l_251a:
	/* 0x251a: add    rax,0x560 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1376ULL);
	goto x86_c18_l_2520;
x86_c18_l_2520:
	/* 0x2520: jmp    2528 <do_bytes+0x24a> */
	X86_SIM_X86_JMP(0x2520, 0x2528, x86_c18_l_2528);
x86_c18_l_2522:
	/* 0x2522: add    rax,0x550 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 1360ULL);
	goto x86_c18_l_2528;
x86_c18_l_2528:
	/* 0x2528: inc QWORD PTR [rax] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
	goto x86_c18_l_252c;
x86_c18_l_252c:
	/* 0x252c: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c18_l_252f;
x86_c18_l_252f:
	/* 0x252f: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c18_l_2533;
x86_c18_l_2533:
	/* 0x2533: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c18_l_2534;
x86_c18_l_2534:
	/* 0x2534: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c18_l_2536;
x86_c18_l_2536:
	/* 0x2536: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
	goto x86_c18_l_2538;
x86_c18_l_2538:
	/* 0x2538: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c18_l_253a;
x86_c18_l_253a:
	/* 0x253a: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c18_l_253c;
x86_c18_l_253c:
	/* 0x253c: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
	goto x86_c18_l_253d;
x86_c18_l_253d:
	/* 0x253d: ret */
	X86_SIM_X86_SUB_RET(x86_c18_l_253d_ret);
x86_c18_l_253d_ret:
	switch (__x86_sim_ret_addr) {
	case 0x20e9ULL: goto x86_c17_l_20e9;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c19_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c19_l_2540;
x86_c19_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c19_l_2542;
x86_c19_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c19_l_2544;
x86_c19_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c19_l_2545;
x86_c19_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c19_l_2546;
x86_c19_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c19_l_2549;
x86_c19_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c19_l_25cb);
	goto x86_c19_l_254f;
x86_c19_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c19_l_2552;
x86_c19_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c19_l_2555;
x86_c19_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c19_l_255c;
x86_c19_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c19_l_2561;
x86_c19_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c19_l_2565;
x86_c19_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c19_l_2569;
x86_c19_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c19_l_256e;
x86_c19_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c19_l_2570;
x86_c19_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c19_l_2572;
x86_c19_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c19_l_2574;
x86_c19_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c19_l_25f0);
	goto x86_c19_l_2576;
x86_c19_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c19_l_257a;
x86_c19_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c19_l_257e;
x86_c19_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c19_l_2586;
x86_c19_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c19_l_258d;
x86_c19_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c19_l_2592;
x86_c19_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c19_l_2597;
x86_c19_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c19_l_2599;
x86_c19_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c19_l_259c;
x86_c19_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c19_l_25d4);
	goto x86_c19_l_259e;
x86_c19_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c19_l_25a2;
x86_c19_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c19_l_25d4);
	goto x86_c19_l_25a4;
x86_c19_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c19_l_25ab;
x86_c19_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c19_l_25b0;
x86_c19_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c19_l_25b5;
x86_c19_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c19_l_25b8;
x86_c19_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c19_l_25bd;
x86_c19_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c19_l_25c0;
x86_c19_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c19_l_25c3;
x86_c19_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c19_l_25c5;
x86_c19_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c19_l_25c7;
x86_c19_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c19_l_25f0);
	goto x86_c19_l_25c9;
x86_c19_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c19_l_25f3);
x86_c19_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c19_l_25d2;
x86_c19_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c19_l_25f3);
x86_c19_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c19_l_25db;
x86_c19_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c19_l_25dd;
x86_c19_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c19_l_25e2;
x86_c19_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c19_l_25e5;
x86_c19_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c19_l_25e8;
x86_c19_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c19_l_25ea;
x86_c19_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c19_l_25ec;
x86_c19_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c19_l_25ee;
x86_c19_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c19_l_25f3);
	goto x86_c19_l_25f0;
x86_c19_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c19_l_25f3;
x86_c19_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c19_l_25f6;
x86_c19_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c19_l_25fa;
x86_c19_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c19_l_25fb;
x86_c19_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c19_l_25fd;
x86_c19_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c19_l_25ff;
x86_c19_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c19_l_2601;
x86_c19_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c19_l_2601_ret);
x86_c19_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x22faULL: goto x86_c18_l_22fa;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c20_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c20_l_2540;
x86_c20_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c20_l_2542;
x86_c20_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c20_l_2544;
x86_c20_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c20_l_2545;
x86_c20_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c20_l_2546;
x86_c20_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c20_l_2549;
x86_c20_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c20_l_25cb);
	goto x86_c20_l_254f;
x86_c20_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c20_l_2552;
x86_c20_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c20_l_2555;
x86_c20_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c20_l_255c;
x86_c20_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c20_l_2561;
x86_c20_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c20_l_2565;
x86_c20_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c20_l_2569;
x86_c20_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c20_l_256e;
x86_c20_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c20_l_2570;
x86_c20_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c20_l_2572;
x86_c20_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c20_l_2574;
x86_c20_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c20_l_25f0);
	goto x86_c20_l_2576;
x86_c20_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c20_l_257a;
x86_c20_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c20_l_257e;
x86_c20_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c20_l_2586;
x86_c20_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c20_l_258d;
x86_c20_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c20_l_2592;
x86_c20_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c20_l_2597;
x86_c20_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c20_l_2599;
x86_c20_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c20_l_259c;
x86_c20_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c20_l_25d4);
	goto x86_c20_l_259e;
x86_c20_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c20_l_25a2;
x86_c20_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c20_l_25d4);
	goto x86_c20_l_25a4;
x86_c20_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c20_l_25ab;
x86_c20_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c20_l_25b0;
x86_c20_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c20_l_25b5;
x86_c20_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c20_l_25b8;
x86_c20_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c20_l_25bd;
x86_c20_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c20_l_25c0;
x86_c20_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c20_l_25c3;
x86_c20_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c20_l_25c5;
x86_c20_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c20_l_25c7;
x86_c20_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c20_l_25f0);
	goto x86_c20_l_25c9;
x86_c20_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c20_l_25f3);
x86_c20_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c20_l_25d2;
x86_c20_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c20_l_25f3);
x86_c20_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c20_l_25db;
x86_c20_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c20_l_25dd;
x86_c20_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c20_l_25e2;
x86_c20_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c20_l_25e5;
x86_c20_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c20_l_25e8;
x86_c20_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c20_l_25ea;
x86_c20_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c20_l_25ec;
x86_c20_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c20_l_25ee;
x86_c20_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c20_l_25f3);
	goto x86_c20_l_25f0;
x86_c20_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c20_l_25f3;
x86_c20_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c20_l_25f6;
x86_c20_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c20_l_25fa;
x86_c20_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c20_l_25fb;
x86_c20_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c20_l_25fd;
x86_c20_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c20_l_25ff;
x86_c20_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c20_l_2601;
x86_c20_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c20_l_2601_ret);
x86_c20_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x2327ULL: goto x86_c18_l_2327;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c21_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c21_l_2540;
x86_c21_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c21_l_2542;
x86_c21_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c21_l_2544;
x86_c21_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c21_l_2545;
x86_c21_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c21_l_2546;
x86_c21_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c21_l_2549;
x86_c21_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c21_l_25cb);
	goto x86_c21_l_254f;
x86_c21_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c21_l_2552;
x86_c21_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c21_l_2555;
x86_c21_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c21_l_255c;
x86_c21_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c21_l_2561;
x86_c21_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c21_l_2565;
x86_c21_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c21_l_2569;
x86_c21_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c21_l_256e;
x86_c21_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c21_l_2570;
x86_c21_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c21_l_2572;
x86_c21_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c21_l_2574;
x86_c21_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c21_l_25f0);
	goto x86_c21_l_2576;
x86_c21_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c21_l_257a;
x86_c21_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c21_l_257e;
x86_c21_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c21_l_2586;
x86_c21_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c21_l_258d;
x86_c21_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c21_l_2592;
x86_c21_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c21_l_2597;
x86_c21_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c21_l_2599;
x86_c21_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c21_l_259c;
x86_c21_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c21_l_25d4);
	goto x86_c21_l_259e;
x86_c21_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c21_l_25a2;
x86_c21_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c21_l_25d4);
	goto x86_c21_l_25a4;
x86_c21_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c21_l_25ab;
x86_c21_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c21_l_25b0;
x86_c21_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c21_l_25b5;
x86_c21_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c21_l_25b8;
x86_c21_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c21_l_25bd;
x86_c21_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c21_l_25c0;
x86_c21_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c21_l_25c3;
x86_c21_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c21_l_25c5;
x86_c21_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c21_l_25c7;
x86_c21_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c21_l_25f0);
	goto x86_c21_l_25c9;
x86_c21_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c21_l_25f3);
x86_c21_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c21_l_25d2;
x86_c21_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c21_l_25f3);
x86_c21_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c21_l_25db;
x86_c21_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c21_l_25dd;
x86_c21_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c21_l_25e2;
x86_c21_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c21_l_25e5;
x86_c21_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c21_l_25e8;
x86_c21_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c21_l_25ea;
x86_c21_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c21_l_25ec;
x86_c21_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c21_l_25ee;
x86_c21_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c21_l_25f3);
	goto x86_c21_l_25f0;
x86_c21_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c21_l_25f3;
x86_c21_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c21_l_25f6;
x86_c21_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c21_l_25fa;
x86_c21_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c21_l_25fb;
x86_c21_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c21_l_25fd;
x86_c21_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c21_l_25ff;
x86_c21_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c21_l_2601;
x86_c21_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c21_l_2601_ret);
x86_c21_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x2355ULL: goto x86_c18_l_2355;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c22_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c22_l_2540;
x86_c22_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c22_l_2542;
x86_c22_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c22_l_2544;
x86_c22_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c22_l_2545;
x86_c22_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c22_l_2546;
x86_c22_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c22_l_2549;
x86_c22_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c22_l_25cb);
	goto x86_c22_l_254f;
x86_c22_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c22_l_2552;
x86_c22_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c22_l_2555;
x86_c22_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c22_l_255c;
x86_c22_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c22_l_2561;
x86_c22_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c22_l_2565;
x86_c22_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c22_l_2569;
x86_c22_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c22_l_256e;
x86_c22_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c22_l_2570;
x86_c22_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c22_l_2572;
x86_c22_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c22_l_2574;
x86_c22_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c22_l_25f0);
	goto x86_c22_l_2576;
x86_c22_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c22_l_257a;
x86_c22_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c22_l_257e;
x86_c22_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c22_l_2586;
x86_c22_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c22_l_258d;
x86_c22_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c22_l_2592;
x86_c22_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c22_l_2597;
x86_c22_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c22_l_2599;
x86_c22_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c22_l_259c;
x86_c22_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c22_l_25d4);
	goto x86_c22_l_259e;
x86_c22_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c22_l_25a2;
x86_c22_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c22_l_25d4);
	goto x86_c22_l_25a4;
x86_c22_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c22_l_25ab;
x86_c22_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c22_l_25b0;
x86_c22_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c22_l_25b5;
x86_c22_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c22_l_25b8;
x86_c22_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c22_l_25bd;
x86_c22_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c22_l_25c0;
x86_c22_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c22_l_25c3;
x86_c22_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c22_l_25c5;
x86_c22_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c22_l_25c7;
x86_c22_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c22_l_25f0);
	goto x86_c22_l_25c9;
x86_c22_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c22_l_25f3);
x86_c22_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c22_l_25d2;
x86_c22_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c22_l_25f3);
x86_c22_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c22_l_25db;
x86_c22_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c22_l_25dd;
x86_c22_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c22_l_25e2;
x86_c22_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c22_l_25e5;
x86_c22_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c22_l_25e8;
x86_c22_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c22_l_25ea;
x86_c22_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c22_l_25ec;
x86_c22_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c22_l_25ee;
x86_c22_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c22_l_25f3);
	goto x86_c22_l_25f0;
x86_c22_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c22_l_25f3;
x86_c22_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c22_l_25f6;
x86_c22_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c22_l_25fa;
x86_c22_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c22_l_25fb;
x86_c22_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c22_l_25fd;
x86_c22_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c22_l_25ff;
x86_c22_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c22_l_2601;
x86_c22_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c22_l_2601_ret);
x86_c22_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x2383ULL: goto x86_c18_l_2383;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c23_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c23_l_2540;
x86_c23_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c23_l_2542;
x86_c23_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c23_l_2544;
x86_c23_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c23_l_2545;
x86_c23_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c23_l_2546;
x86_c23_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c23_l_2549;
x86_c23_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c23_l_25cb);
	goto x86_c23_l_254f;
x86_c23_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c23_l_2552;
x86_c23_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c23_l_2555;
x86_c23_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c23_l_255c;
x86_c23_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c23_l_2561;
x86_c23_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c23_l_2565;
x86_c23_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c23_l_2569;
x86_c23_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c23_l_256e;
x86_c23_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c23_l_2570;
x86_c23_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c23_l_2572;
x86_c23_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c23_l_2574;
x86_c23_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c23_l_25f0);
	goto x86_c23_l_2576;
x86_c23_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c23_l_257a;
x86_c23_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c23_l_257e;
x86_c23_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c23_l_2586;
x86_c23_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c23_l_258d;
x86_c23_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c23_l_2592;
x86_c23_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c23_l_2597;
x86_c23_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c23_l_2599;
x86_c23_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c23_l_259c;
x86_c23_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c23_l_25d4);
	goto x86_c23_l_259e;
x86_c23_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c23_l_25a2;
x86_c23_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c23_l_25d4);
	goto x86_c23_l_25a4;
x86_c23_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c23_l_25ab;
x86_c23_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c23_l_25b0;
x86_c23_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c23_l_25b5;
x86_c23_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c23_l_25b8;
x86_c23_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c23_l_25bd;
x86_c23_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c23_l_25c0;
x86_c23_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c23_l_25c3;
x86_c23_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c23_l_25c5;
x86_c23_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c23_l_25c7;
x86_c23_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c23_l_25f0);
	goto x86_c23_l_25c9;
x86_c23_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c23_l_25f3);
x86_c23_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c23_l_25d2;
x86_c23_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c23_l_25f3);
x86_c23_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c23_l_25db;
x86_c23_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c23_l_25dd;
x86_c23_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c23_l_25e2;
x86_c23_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c23_l_25e5;
x86_c23_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c23_l_25e8;
x86_c23_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c23_l_25ea;
x86_c23_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c23_l_25ec;
x86_c23_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c23_l_25ee;
x86_c23_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c23_l_25f3);
	goto x86_c23_l_25f0;
x86_c23_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c23_l_25f3;
x86_c23_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c23_l_25f6;
x86_c23_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c23_l_25fa;
x86_c23_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c23_l_25fb;
x86_c23_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c23_l_25fd;
x86_c23_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c23_l_25ff;
x86_c23_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c23_l_2601;
x86_c23_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c23_l_2601_ret);
x86_c23_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x23b1ULL: goto x86_c18_l_23b1;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c24_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c24_l_2540;
x86_c24_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c24_l_2542;
x86_c24_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c24_l_2544;
x86_c24_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c24_l_2545;
x86_c24_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c24_l_2546;
x86_c24_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c24_l_2549;
x86_c24_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c24_l_25cb);
	goto x86_c24_l_254f;
x86_c24_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c24_l_2552;
x86_c24_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c24_l_2555;
x86_c24_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c24_l_255c;
x86_c24_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c24_l_2561;
x86_c24_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c24_l_2565;
x86_c24_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c24_l_2569;
x86_c24_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c24_l_256e;
x86_c24_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c24_l_2570;
x86_c24_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c24_l_2572;
x86_c24_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c24_l_2574;
x86_c24_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c24_l_25f0);
	goto x86_c24_l_2576;
x86_c24_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c24_l_257a;
x86_c24_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c24_l_257e;
x86_c24_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c24_l_2586;
x86_c24_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c24_l_258d;
x86_c24_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c24_l_2592;
x86_c24_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c24_l_2597;
x86_c24_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c24_l_2599;
x86_c24_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c24_l_259c;
x86_c24_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c24_l_25d4);
	goto x86_c24_l_259e;
x86_c24_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c24_l_25a2;
x86_c24_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c24_l_25d4);
	goto x86_c24_l_25a4;
x86_c24_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c24_l_25ab;
x86_c24_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c24_l_25b0;
x86_c24_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c24_l_25b5;
x86_c24_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c24_l_25b8;
x86_c24_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c24_l_25bd;
x86_c24_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c24_l_25c0;
x86_c24_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c24_l_25c3;
x86_c24_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c24_l_25c5;
x86_c24_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c24_l_25c7;
x86_c24_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c24_l_25f0);
	goto x86_c24_l_25c9;
x86_c24_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c24_l_25f3);
x86_c24_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c24_l_25d2;
x86_c24_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c24_l_25f3);
x86_c24_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c24_l_25db;
x86_c24_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c24_l_25dd;
x86_c24_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c24_l_25e2;
x86_c24_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c24_l_25e5;
x86_c24_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c24_l_25e8;
x86_c24_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c24_l_25ea;
x86_c24_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c24_l_25ec;
x86_c24_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c24_l_25ee;
x86_c24_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c24_l_25f3);
	goto x86_c24_l_25f0;
x86_c24_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c24_l_25f3;
x86_c24_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c24_l_25f6;
x86_c24_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c24_l_25fa;
x86_c24_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c24_l_25fb;
x86_c24_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c24_l_25fd;
x86_c24_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c24_l_25ff;
x86_c24_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c24_l_2601;
x86_c24_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c24_l_2601_ret);
x86_c24_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x23dfULL: goto x86_c18_l_23df;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c25_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c25_l_2540;
x86_c25_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c25_l_2542;
x86_c25_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c25_l_2544;
x86_c25_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c25_l_2545;
x86_c25_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c25_l_2546;
x86_c25_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c25_l_2549;
x86_c25_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c25_l_25cb);
	goto x86_c25_l_254f;
x86_c25_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c25_l_2552;
x86_c25_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c25_l_2555;
x86_c25_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c25_l_255c;
x86_c25_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c25_l_2561;
x86_c25_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c25_l_2565;
x86_c25_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c25_l_2569;
x86_c25_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c25_l_256e;
x86_c25_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c25_l_2570;
x86_c25_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c25_l_2572;
x86_c25_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c25_l_2574;
x86_c25_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c25_l_25f0);
	goto x86_c25_l_2576;
x86_c25_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c25_l_257a;
x86_c25_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c25_l_257e;
x86_c25_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c25_l_2586;
x86_c25_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c25_l_258d;
x86_c25_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c25_l_2592;
x86_c25_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c25_l_2597;
x86_c25_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c25_l_2599;
x86_c25_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c25_l_259c;
x86_c25_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c25_l_25d4);
	goto x86_c25_l_259e;
x86_c25_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c25_l_25a2;
x86_c25_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c25_l_25d4);
	goto x86_c25_l_25a4;
x86_c25_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c25_l_25ab;
x86_c25_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c25_l_25b0;
x86_c25_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c25_l_25b5;
x86_c25_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c25_l_25b8;
x86_c25_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c25_l_25bd;
x86_c25_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c25_l_25c0;
x86_c25_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c25_l_25c3;
x86_c25_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c25_l_25c5;
x86_c25_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c25_l_25c7;
x86_c25_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c25_l_25f0);
	goto x86_c25_l_25c9;
x86_c25_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c25_l_25f3);
x86_c25_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c25_l_25d2;
x86_c25_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c25_l_25f3);
x86_c25_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c25_l_25db;
x86_c25_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c25_l_25dd;
x86_c25_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c25_l_25e2;
x86_c25_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c25_l_25e5;
x86_c25_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c25_l_25e8;
x86_c25_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c25_l_25ea;
x86_c25_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c25_l_25ec;
x86_c25_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c25_l_25ee;
x86_c25_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c25_l_25f3);
	goto x86_c25_l_25f0;
x86_c25_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c25_l_25f3;
x86_c25_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c25_l_25f6;
x86_c25_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c25_l_25fa;
x86_c25_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c25_l_25fb;
x86_c25_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c25_l_25fd;
x86_c25_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c25_l_25ff;
x86_c25_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c25_l_2601;
x86_c25_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c25_l_2601_ret);
x86_c25_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x240dULL: goto x86_c18_l_240d;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c26_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c26_l_2540;
x86_c26_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c26_l_2542;
x86_c26_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c26_l_2544;
x86_c26_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c26_l_2545;
x86_c26_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c26_l_2546;
x86_c26_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c26_l_2549;
x86_c26_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c26_l_25cb);
	goto x86_c26_l_254f;
x86_c26_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c26_l_2552;
x86_c26_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c26_l_2555;
x86_c26_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c26_l_255c;
x86_c26_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c26_l_2561;
x86_c26_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c26_l_2565;
x86_c26_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c26_l_2569;
x86_c26_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c26_l_256e;
x86_c26_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c26_l_2570;
x86_c26_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c26_l_2572;
x86_c26_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c26_l_2574;
x86_c26_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c26_l_25f0);
	goto x86_c26_l_2576;
x86_c26_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c26_l_257a;
x86_c26_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c26_l_257e;
x86_c26_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c26_l_2586;
x86_c26_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c26_l_258d;
x86_c26_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c26_l_2592;
x86_c26_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c26_l_2597;
x86_c26_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c26_l_2599;
x86_c26_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c26_l_259c;
x86_c26_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c26_l_25d4);
	goto x86_c26_l_259e;
x86_c26_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c26_l_25a2;
x86_c26_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c26_l_25d4);
	goto x86_c26_l_25a4;
x86_c26_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c26_l_25ab;
x86_c26_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c26_l_25b0;
x86_c26_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c26_l_25b5;
x86_c26_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c26_l_25b8;
x86_c26_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c26_l_25bd;
x86_c26_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c26_l_25c0;
x86_c26_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c26_l_25c3;
x86_c26_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c26_l_25c5;
x86_c26_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c26_l_25c7;
x86_c26_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c26_l_25f0);
	goto x86_c26_l_25c9;
x86_c26_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c26_l_25f3);
x86_c26_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c26_l_25d2;
x86_c26_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c26_l_25f3);
x86_c26_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c26_l_25db;
x86_c26_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c26_l_25dd;
x86_c26_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c26_l_25e2;
x86_c26_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c26_l_25e5;
x86_c26_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c26_l_25e8;
x86_c26_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c26_l_25ea;
x86_c26_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c26_l_25ec;
x86_c26_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c26_l_25ee;
x86_c26_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c26_l_25f3);
	goto x86_c26_l_25f0;
x86_c26_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c26_l_25f3;
x86_c26_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c26_l_25f6;
x86_c26_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c26_l_25fa;
x86_c26_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c26_l_25fb;
x86_c26_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c26_l_25fd;
x86_c26_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c26_l_25ff;
x86_c26_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c26_l_2601;
x86_c26_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c26_l_2601_ret);
x86_c26_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x243bULL: goto x86_c18_l_243b;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c27_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c27_l_2540;
x86_c27_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c27_l_2542;
x86_c27_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c27_l_2544;
x86_c27_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c27_l_2545;
x86_c27_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c27_l_2546;
x86_c27_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c27_l_2549;
x86_c27_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c27_l_25cb);
	goto x86_c27_l_254f;
x86_c27_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c27_l_2552;
x86_c27_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c27_l_2555;
x86_c27_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c27_l_255c;
x86_c27_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c27_l_2561;
x86_c27_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c27_l_2565;
x86_c27_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c27_l_2569;
x86_c27_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c27_l_256e;
x86_c27_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c27_l_2570;
x86_c27_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c27_l_2572;
x86_c27_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c27_l_2574;
x86_c27_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c27_l_25f0);
	goto x86_c27_l_2576;
x86_c27_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c27_l_257a;
x86_c27_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c27_l_257e;
x86_c27_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c27_l_2586;
x86_c27_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c27_l_258d;
x86_c27_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c27_l_2592;
x86_c27_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c27_l_2597;
x86_c27_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c27_l_2599;
x86_c27_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c27_l_259c;
x86_c27_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c27_l_25d4);
	goto x86_c27_l_259e;
x86_c27_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c27_l_25a2;
x86_c27_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c27_l_25d4);
	goto x86_c27_l_25a4;
x86_c27_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c27_l_25ab;
x86_c27_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c27_l_25b0;
x86_c27_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c27_l_25b5;
x86_c27_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c27_l_25b8;
x86_c27_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c27_l_25bd;
x86_c27_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c27_l_25c0;
x86_c27_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c27_l_25c3;
x86_c27_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c27_l_25c5;
x86_c27_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c27_l_25c7;
x86_c27_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c27_l_25f0);
	goto x86_c27_l_25c9;
x86_c27_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c27_l_25f3);
x86_c27_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c27_l_25d2;
x86_c27_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c27_l_25f3);
x86_c27_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c27_l_25db;
x86_c27_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c27_l_25dd;
x86_c27_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c27_l_25e2;
x86_c27_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c27_l_25e5;
x86_c27_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c27_l_25e8;
x86_c27_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c27_l_25ea;
x86_c27_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c27_l_25ec;
x86_c27_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c27_l_25ee;
x86_c27_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c27_l_25f3);
	goto x86_c27_l_25f0;
x86_c27_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c27_l_25f3;
x86_c27_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c27_l_25f6;
x86_c27_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c27_l_25fa;
x86_c27_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c27_l_25fb;
x86_c27_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c27_l_25fd;
x86_c27_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c27_l_25ff;
x86_c27_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c27_l_2601;
x86_c27_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c27_l_2601_ret);
x86_c27_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x2465ULL: goto x86_c18_l_2465;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c28_l_253e:
	/* 0x253e: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c28_l_2540;
x86_c28_l_2540:
	/* 0x2540: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c28_l_2542;
x86_c28_l_2542:
	/* 0x2542: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c28_l_2544;
x86_c28_l_2544:
	/* 0x2544: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c28_l_2545;
x86_c28_l_2545:
	/* 0x2545: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
	goto x86_c28_l_2546;
x86_c28_l_2546:
	/* 0x2546: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
	goto x86_c28_l_2549;
x86_c28_l_2549:
	/* 0x2549: js     25cb <__do_bytes+0x8d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2549, 0x25cb, x86_c28_l_25cb);
	goto x86_c28_l_254f;
x86_c28_l_254f:
	/* 0x254f: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
	goto x86_c28_l_2552;
x86_c28_l_2552:
	/* 0x2552: mov    r12,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDI, X86_WIDTH_64);
	goto x86_c28_l_2555;
x86_c28_l_2555:
	/* 0x2555: cmp    rcx,0x7fe0 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 32736ULL);
	goto x86_c28_l_255c;
x86_c28_l_255c:
	/* 0x255c: mov    ebx,0x7fe0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 32736ULL);
	goto x86_c28_l_2561;
x86_c28_l_2561:
	/* 0x2561: cmovb  rbx,rcx */
	X86_SIM_L_EXEC_CMOV(X86_RBX, X86_RCX, X86_WIDTH_64, X86_CC_B);
	goto x86_c28_l_2565;
x86_c28_l_2565:
	/* 0x2565: lea    rdi,[rsi+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c28_l_2569;
x86_c28_l_2569:
	/* 0x2569: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
	goto x86_c28_l_256e;
x86_c28_l_256e:
	/* 0x256e: mov    esi,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RBX, X86_WIDTH_32);
	goto x86_c28_l_2570;
x86_c28_l_2570:
	/* 0x2570: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c28_l_2572;
x86_c28_l_2572:
	/* 0x2572: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c28_l_2574;
x86_c28_l_2574:
	/* 0x2574: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2574, 0x25f0, x86_c28_l_25f0);
	goto x86_c28_l_2576;
x86_c28_l_2576:
	/* 0x2576: lea    r15d,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
	goto x86_c28_l_257a;
x86_c28_l_257a:
	/* 0x257a: mov    DWORD PTR [r14+0x4],r15d */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c28_l_257e;
x86_c28_l_257e:
	/* 0x257e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
	goto x86_c28_l_2586;
x86_c28_l_2586:
	/* 0x2586: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_conf_map));
	goto x86_c28_l_258d;
x86_c28_l_258d:
	/* 0x258d: lea    rsi,[rsp+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
	goto x86_c28_l_2592;
x86_c28_l_2592:
	/* 0x2592: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c28_l_2597;
x86_c28_l_2597:
	/* 0x2597: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c28_l_2599;
x86_c28_l_2599:
	/* 0x2599: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
	goto x86_c28_l_259c;
x86_c28_l_259c:
	/* 0x259c: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259c, 0x25d4, x86_c28_l_25d4);
	goto x86_c28_l_259e;
x86_c28_l_259e:
	/* 0x259e: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
	goto x86_c28_l_25a2;
x86_c28_l_25a2:
	/* 0x25a2: je     25d4 <__do_bytes+0x96> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a2, 0x25d4, x86_c28_l_25d4);
	goto x86_c28_l_25a4;
x86_c28_l_25a4:
	/* 0x25a4: mov    rsi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tcpmon_map));
	goto x86_c28_l_25ab;
x86_c28_l_25ab:
	/* 0x25ab: mov    ecx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c28_l_25b0;
x86_c28_l_25b0:
	/* 0x25b0: mov    eax,0x19 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 25ULL);
	goto x86_c28_l_25b5;
x86_c28_l_25b5:
	/* 0x25b5: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
	goto x86_c28_l_25b8;
x86_c28_l_25b8:
	/* 0x25b8: mov    edx,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 4294967295ULL);
	goto x86_c28_l_25bd;
x86_c28_l_25bd:
	/* 0x25bd: mov    rcx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_R14, X86_WIDTH_64);
	goto x86_c28_l_25c0;
x86_c28_l_25c0:
	/* 0x25c0: mov    r8,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R15, X86_WIDTH_64);
	goto x86_c28_l_25c3;
x86_c28_l_25c3:
	/* 0x25c3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x19ULL: X86_SIM_BPF_CALL_bpf_perf_event_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c28_l_25c5;
x86_c28_l_25c5:
	/* 0x25c5: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c28_l_25c7;
x86_c28_l_25c7:
	/* 0x25c7: js     25f0 <__do_bytes+0xb2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25c7, 0x25f0, x86_c28_l_25f0);
	goto x86_c28_l_25c9;
x86_c28_l_25c9:
	/* 0x25c9: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25c9, 0x25f3, x86_c28_l_25f3);
x86_c28_l_25cb:
	/* 0x25cb: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
	goto x86_c28_l_25d2;
x86_c28_l_25d2:
	/* 0x25d2: jmp    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JMP(0x25d2, 0x25f3, x86_c28_l_25f3);
x86_c28_l_25d4:
	/* 0x25d4: mov    rdi,QWORD PTR [rip+0x61c] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)tg_rb_events));
	goto x86_c28_l_25db;
x86_c28_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c28_l_25dd;
x86_c28_l_25dd:
	/* 0x25dd: mov    eax,0x82 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 130ULL);
	goto x86_c28_l_25e2;
x86_c28_l_25e2:
	/* 0x25e2: mov    rsi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R14, X86_WIDTH_64);
	goto x86_c28_l_25e5;
x86_c28_l_25e5:
	/* 0x25e5: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
	goto x86_c28_l_25e8;
x86_c28_l_25e8:
	/* 0x25e8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
	goto x86_c28_l_25ea;
x86_c28_l_25ea:
	/* 0x25ea: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x82ULL: X86_SIM_BPF_CALL_bpf_ringbuf_output(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
	goto x86_c28_l_25ec;
x86_c28_l_25ec:
	/* 0x25ec: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
	goto x86_c28_l_25ee;
x86_c28_l_25ee:
	/* 0x25ee: jns    25f3 <__do_bytes+0xb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ee, 0x25f3, x86_c28_l_25f3);
	goto x86_c28_l_25f0;
x86_c28_l_25f0:
	/* 0x25f0: movsxd rbx,eax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_WIDTH_32);
	goto x86_c28_l_25f3;
x86_c28_l_25f3:
	/* 0x25f3: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
	goto x86_c28_l_25f6;
x86_c28_l_25f6:
	/* 0x25f6: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
	goto x86_c28_l_25fa;
x86_c28_l_25fa:
	/* 0x25fa: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
	goto x86_c28_l_25fb;
x86_c28_l_25fb:
	/* 0x25fb: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
	goto x86_c28_l_25fd;
x86_c28_l_25fd:
	/* 0x25fd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
	goto x86_c28_l_25ff;
x86_c28_l_25ff:
	/* 0x25ff: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
	goto x86_c28_l_2601;
x86_c28_l_2601:
	/* 0x2601: ret */
	X86_SIM_X86_SUB_RET(x86_c28_l_2601_ret);
x86_c28_l_2601_ret:
	switch (__x86_sim_ret_addr) {
	case 0x2491ULL: goto x86_c18_l_2491;
	default: __x86_sim_unresolved_indirect_target();
	}
}

X86_SIM_LICENSE();
