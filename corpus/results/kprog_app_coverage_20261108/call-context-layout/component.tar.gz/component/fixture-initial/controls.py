from pathlib import Path
import sys,importlib.util,subprocess,json
R=Path('/workspaces/repository');D=Path(__file__).parent
sys.path.insert(0,str(R/'kprog/x86/micro-prog'));sys.path.insert(0,str(D));spec=importlib.util.spec_from_file_location('controlled_generator',D/'generate_micro_sim_proofs.py');g=importlib.util.module_from_spec(spec);sys.modules[spec.name]=g;spec.loader.exec_module(g)
bodies=[
'''mov eax,DWORD PTR [rdi]
call .Lf
add eax,13
call .Lf
ret
.Lf:
sub rsp,16
mov QWORD PTR [rsp],rax
test eax,1
jz .Leven
imul eax,eax,3
add rsp,16
ret
.Leven:
add eax,7
add rsp,16
ret''',
'''mov eax,DWORD PTR [rdi]
call .Lf
xor eax,0x1234
call .Lf
ret
.Lf:
sub rsp,16
mov QWORD PTR [rsp],rax
call .Lg
mov ecx,DWORD PTR [rsp]
add eax,ecx
add rsp,16
ret
.Lg:
rol eax,5
add eax,29
ret''',
'''mov eax,DWORD PTR [rdi]
lea rdx,[rip+.Lf]
test eax,1
jz .Lchosen
lea rdx,[rip+.Lg]
.Lchosen:
call rdx
add eax,13
call rdx
ret
.Lf:
add eax,7
ret
.Lg:
imul eax,eax,3
ret'''
]
rows=[]
for k,body in enumerate(bodies):
 name='case'+str(k);asm=D/(name+'.S');asm.write_text('.intel_syntax noprefix\n.text\n.global native_cpu'+str(k)+'\n.type native_cpu'+str(k)+',@function\nnative_cpu'+str(k)+':\n'+body+'\n.size native_cpu'+str(k)+',.-native_cpu'+str(k)+'\n.section .note.GNU-stack,"",@progbits\n')
 subprocess.run(['cc','-c',str(asm),'-o',str(D/(name+'.native.o'))],check=True)
 subprocess.run([str(D.parent/'cilium-matched-modules-runtime/native-link-readonly-c'),'--input',str(D/(name+'.native.o')),'--symbol','native_cpu'+str(k),'--mode','proof','--preserve-entry-abi','--output',str(D/(name+'.proof.o'))],check=True,capture_output=True)
 insns,functions,exitaddr,rodata=g.parse_native_linked_program(name,D)
 source=g.render_program(name,insns,functions,kind='raw',program_section='xdp',exit_addr=exitaddr,rodata16=rodata)
 source=source.replace('#include "../x86_sim_local_bpf.h"','#include '+json.dumps(str(D/'read.h'))+'\n#include '+json.dumps(str(D/'candidate.h')))
 (D/(name+'.bpf.c')).write_text(source)
 # The host-only adapter records any rejected-dispatch edge as a test failure.
 # The verifier artifact retains the ordinary invalid-call guard unchanged.
 host=source.replace('__attribute__((error("indirect target was not eliminated by specialization")))','')
 (D/(name+'.host.c')).write_text(host)
 rows.append(dict(name=name,native_instructions=len(insns)+sum(map(len,functions.values())),native_functions=len(functions)))
(D/'control-shapes.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows),flush=True)
