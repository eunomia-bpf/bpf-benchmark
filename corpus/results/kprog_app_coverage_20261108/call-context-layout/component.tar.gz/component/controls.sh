set -eu
D=/workspaces/.agent-state/kprog-lanes/C/context-render
cd /workspaces/repository
trap 'echo $? > "$D/controls.exit"' EXIT
python3 "$D/controls.py"
for number in 0 1 2; do
 /usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -D__TARGET_ARCH_x86 -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/case$number.bpf.c" -o "$D/case$number.bpf.o"
 cc -DLICENSE=case${number}_LICENSE -O2 -fsanitize=undefined -fno-sanitize-recover=all -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/case$number.host.c" -o "$D/case$number.host.o"
done
python3 - <<'PY'
from pathlib import Path
from elftools.elf.elffile import ELFFile
import struct,json
D=Path('/workspaces/.agent-state/kprog-lanes/C/context-render')
for i in range(3):
 with (D/f'case{i}.bpf.o').open('rb') as f:
  code=ELFFile(f).get_section_by_name('xdp').data();(D/f'case{i}.original.bin').write_bytes(code)
  instructions=list(struct.iter_unpack('<BBhi',code));adapters=[]
  for j,(op,reg,offset,imm) in enumerate(instructions):
   if op==0xb7 and reg>>4==9:
    assert offset==1 and imm==2
    adapters.append(dict(pc=j,kind='native SP numeric environment',value=0))
    instructions[j]=(0xb7,reg&15,0,0)
   if op==0x85 and reg==0 and offset==0 and imm==-1:
    adapters.append(dict(pc=j,kind='rejected-edge test reporter',helper_id=63));instructions[j]=(op,reg,offset,63)
  (D/f'case{i}.bin').write_bytes(b''.join(struct.pack('<BBhi',*row)for row in instructions));(D/f'case{i}.environment.json').write_text(json.dumps(adapters,indent=2)+'\n')
PY
c++ -O2 -std=c++20 -fsanitize=undefined -fno-sanitize-recover=all -Ivendor/llvmbpf/include -Ivendor/llvmbpf/src "$D/test.cpp" "$D"/case?.host.o "$D"/case?.native.o runner/build-llvmbpf/CMakeFiles/micro_exec.dir/workspaces/repository/vendor/llvmbpf/src/*.o -L/usr/lib/llvm-18/lib -lLLVM-18 -lspdlog -lfmt -ldl -pthread -o "$D/check"
"$D/check" "$D"
