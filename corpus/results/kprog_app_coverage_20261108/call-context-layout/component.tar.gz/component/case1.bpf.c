#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 32U
#include "/workspaces/.agent-state/kprog-lanes/C/context-render/read.h"
#include "/workspaces/.agent-state/kprog-lanes/C/context-render/candidate.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

SEC("xdp")
int case1_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_c0_l_0:
	/* 0x0: mov    eax,DWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_2;
x86_c0_l_2:
	/* 0x2: call   16 <subf1> */
	X86_SIM_X86_CALL(x86_c1_l_16, 0x7ULL);
x86_c0_l_7:
	/* 0x7: xor    eax,0x1234 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 4660ULL);
	goto x86_c0_l_c;
x86_c0_l_c:
	/* 0xc: call   16 <subf1> */
	X86_SIM_X86_CALL(x86_c3_l_16, 0x11ULL);
x86_c0_l_11:
	/* 0x11: jmp    34 <subg1+0x7> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_c1_l_16:
	/* 0x16: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
	goto x86_c1_l_1a;
x86_c1_l_1a:
	/* 0x1a: mov    QWORD PTR [rsp],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c1_l_1e;
x86_c1_l_1e:
	/* 0x1e: call   2d <subg1> */
	X86_SIM_X86_CALL(x86_c2_l_2d, 0x23ULL);
x86_c1_l_23:
	/* 0x23: mov    ecx,DWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c1_l_26;
x86_c1_l_26:
	/* 0x26: add    eax,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_32, X86_ALU_ADD);
	goto x86_c1_l_28;
x86_c1_l_28:
	/* 0x28: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
	goto x86_c1_l_2c;
x86_c1_l_2c:
	/* 0x2c: ret */
	X86_SIM_X86_SUB_RET(x86_c1_l_2c_ret);
x86_c1_l_2c_ret:
	switch (__x86_sim_ret_addr) {
	case 0x7ULL: goto x86_c0_l_7;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c2_l_2d:
	/* 0x2d: rol    eax,0x5 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ROL, 5ULL);
	goto x86_c2_l_30;
x86_c2_l_30:
	/* 0x30: add    eax,0x1d */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 29ULL);
	goto x86_c2_l_33;
x86_c2_l_33:
	/* 0x33: ret */
	X86_SIM_X86_SUB_RET(x86_c2_l_33_ret);
x86_c2_l_33_ret:
	switch (__x86_sim_ret_addr) {
	case 0x23ULL: goto x86_c1_l_23;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c3_l_16:
	/* 0x16: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
	goto x86_c3_l_1a;
x86_c3_l_1a:
	/* 0x1a: mov    QWORD PTR [rsp],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c3_l_1e;
x86_c3_l_1e:
	/* 0x1e: call   2d <subg1> */
	X86_SIM_X86_CALL(x86_c4_l_2d, 0x23ULL);
x86_c3_l_23:
	/* 0x23: mov    ecx,DWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c3_l_26;
x86_c3_l_26:
	/* 0x26: add    eax,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_32, X86_ALU_ADD);
	goto x86_c3_l_28;
x86_c3_l_28:
	/* 0x28: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
	goto x86_c3_l_2c;
x86_c3_l_2c:
	/* 0x2c: ret */
	X86_SIM_X86_SUB_RET(x86_c3_l_2c_ret);
x86_c3_l_2c_ret:
	switch (__x86_sim_ret_addr) {
	case 0x11ULL: goto x86_c0_l_11;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c4_l_2d:
	/* 0x2d: rol    eax,0x5 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ROL, 5ULL);
	goto x86_c4_l_30;
x86_c4_l_30:
	/* 0x30: add    eax,0x1d */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 29ULL);
	goto x86_c4_l_33;
x86_c4_l_33:
	/* 0x33: ret */
	X86_SIM_X86_SUB_RET(x86_c4_l_33_ret);
x86_c4_l_33_ret:
	switch (__x86_sim_ret_addr) {
	case 0x23ULL: goto x86_c3_l_23;
	default: __x86_sim_unresolved_indirect_target();
	}
}

X86_SIM_LICENSE();
