from pathlib import Path
import sys,importlib.util,json,shutil,hashlib
R=Path('/workspaces/repository');D=Path(__file__).parent
sys.path.insert(0,str(R/'kprog/x86/micro-prog'));sys.path.insert(0,str(D))
spec=importlib.util.spec_from_file_location('context_generator',D/'generate_micro_sim_proofs.py');g=importlib.util.module_from_spec(spec);sys.modules[spec.name]=g;spec.loader.exec_module(g)
for name in ['candidate.h','read.h']:shutil.copy2(D.parent/'stack-typed-volatile-current'/name,D/name)
base=D/'event/request';folder=base/'generated';meta=json.loads((base/'generation.metadata.json').read_text());insns,functions,exitaddr,rodata=g.parse_native_linked_program('trusted_x86',folder)
flow={};original=g.check_definedness
def captured(*args,**kwargs):
 out=original(*args,**kwargs);flow.update(kwargs['control_flow']);return out
g.check_definedness=captured
source=g.render_program('context_event',insns,functions,kind={6:'xdp',3:'tc',8:'cgroup_skb'}.get(meta['prog_type'],'raw'),exit_addr=exitaddr,rodata16=rodata,program_section=meta['section'],trusted_map_bindings=[dict(native_symbol=m['name'],value_offset=m.get('value_offset'))for m in meta['maps']])
source=source.replace('#include "../x86_sim_local_bpf.h"','#include '+json.dumps(str(D/'read.h'))+'\n#include '+json.dumps(str(D/'candidate.h')))
(D/'event.bpf.c').write_text(source)
obs=dict(native_insns=len(insns)+sum(len(f)for f in functions.values()),native_subroutines=len(functions),nodes=len(flow['edges']),contexts=len({key[0] for key in flow['edges']}),edges=sum(len(v)for v in flow['edges'].values()),native_returns=sum(i.mnemonic=='ret' for i in [*insns,*(i for f in functions.values()for i in f)]),context_returns=sum(1 for key in flow['edges'] if any(i.addr==key[1]and i.mnemonic=='ret'for i in [*insns,*(i for f in functions.values()for i in f)])),original_proof_sha256=hashlib.sha256((folder/'trusted_x86.proof.o').read_bytes()).hexdigest())
(D/'shape-before-compile.json').write_text(json.dumps(obs,indent=2)+'\n');print(json.dumps(obs,indent=2),flush=True)
