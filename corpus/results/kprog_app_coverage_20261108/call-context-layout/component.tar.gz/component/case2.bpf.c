#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 8U
#include "/workspaces/.agent-state/kprog-lanes/C/context-render/read.h"
#include "/workspaces/.agent-state/kprog-lanes/C/context-render/candidate.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

SEC("xdp")
int case2_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_c0_l_0:
	/* 0x0: mov    eax,DWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_2;
x86_c0_l_2:
	/* 0x2: lea    rdx,[rip+0x2f] */
	X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x38ULL);
	goto x86_c0_l_9;
x86_c0_l_9:
	/* 0x9: test   eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_e;
x86_c0_l_e:
	/* 0xe: je     17 <native_cpu2+0x17> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe, 0x17, x86_c0_l_17);
	goto x86_c0_l_10;
x86_c0_l_10:
	/* 0x10: lea    rdx,[rip+0x25] */
	X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x3cULL);
	goto x86_c0_l_17;
x86_c0_l_17:
	/* 0x17: call   rdx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDX);
		switch (X86_SIM_L_REG_TAG(X86_RDX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x38ULL: X86_SIM_X86_CALL(x86_c1_l_38, 0x19ULL);
			case 0x3cULL: X86_SIM_X86_CALL(x86_c1_l_3c, 0x19ULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_c0_l_19:
	/* 0x19: add    eax,0xd */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 13ULL);
	goto x86_c0_l_1c;
x86_c0_l_1c:
	/* 0x1c: lea    rdx,[rip+0x15] */
	X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x38ULL);
	goto x86_c0_l_23;
x86_c0_l_23:
	/* 0x23: test   eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c0_l_28;
x86_c0_l_28:
	/* 0x28: je     31 <native_cpu2+0x31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28, 0x31, x86_c0_l_31);
	goto x86_c0_l_2a;
x86_c0_l_2a:
	/* 0x2a: lea    rdx,[rip+0xb] */
	X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x3cULL);
	goto x86_c0_l_31;
x86_c0_l_31:
	/* 0x31: call   rdx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDX);
		switch (X86_SIM_L_REG_TAG(X86_RDX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x38ULL: X86_SIM_X86_CALL(x86_c2_l_38, 0x33ULL);
			case 0x3cULL: X86_SIM_X86_CALL(x86_c2_l_3c, 0x33ULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_c0_l_33:
	/* 0x33: jmp    40 <subg2+0x4> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_c1_l_38:
	/* 0x38: add    eax,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 7ULL);
	goto x86_c1_l_3b;
x86_c1_l_3b:
	/* 0x3b: ret */
	X86_SIM_X86_SUB_RET(x86_c1_l_3b_ret);
x86_c1_l_3b_ret:
	switch (__x86_sim_ret_addr) {
	case 0x19ULL: goto x86_c0_l_19;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c1_l_3c:
	/* 0x3c: imul   eax,eax,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_RAX, X86_RAX, X86_WIDTH_32, 3ULL);
	goto x86_c1_l_3f;
x86_c1_l_3f:
	/* 0x3f: ret */
	X86_SIM_X86_SUB_RET(x86_c1_l_3f_ret);
x86_c1_l_3f_ret:
	switch (__x86_sim_ret_addr) {
	case 0x19ULL: goto x86_c0_l_19;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c2_l_38:
	/* 0x38: add    eax,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 7ULL);
	goto x86_c2_l_3b;
x86_c2_l_3b:
	/* 0x3b: ret */
	X86_SIM_X86_SUB_RET(x86_c2_l_3b_ret);
x86_c2_l_3b_ret:
	switch (__x86_sim_ret_addr) {
	case 0x33ULL: goto x86_c0_l_33;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c2_l_3c:
	/* 0x3c: imul   eax,eax,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_RAX, X86_RAX, X86_WIDTH_32, 3ULL);
	goto x86_c2_l_3f;
x86_c2_l_3f:
	/* 0x3f: ret */
	X86_SIM_X86_SUB_RET(x86_c2_l_3f_ret);
x86_c2_l_3f_ret:
	switch (__x86_sim_ret_addr) {
	case 0x33ULL: goto x86_c0_l_33;
	default: __x86_sim_unresolved_indirect_target();
	}
}

X86_SIM_LICENSE();
