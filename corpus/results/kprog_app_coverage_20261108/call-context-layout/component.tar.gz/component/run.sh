set -eu
D=/workspaces/.agent-state/kprog-lanes/C/context-render
cd /workspaces/repository
trap 'echo $? > "$D/compile.exit"' EXIT
python3 "$D/generate.py"
/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/event.bpf.c" -o "$D/event.bpf.o"
