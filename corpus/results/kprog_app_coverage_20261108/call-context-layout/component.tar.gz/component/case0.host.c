#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 24U
#include "/workspaces/.agent-state/kprog-lanes/C/context-render/read.h"
#include "/workspaces/.agent-state/kprog-lanes/C/context-render/candidate.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	;
#endif

SEC("xdp")
int case0_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_c0_l_0:
	/* 0x0: mov    eax,DWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c0_l_2;
x86_c0_l_2:
	/* 0x2: call   14 <subf0> */
	X86_SIM_X86_CALL(x86_c1_l_14, 0x7ULL);
x86_c0_l_7:
	/* 0x7: add    eax,0xd */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 13ULL);
	goto x86_c0_l_a;
x86_c0_l_a:
	/* 0xa: call   14 <subf0> */
	X86_SIM_X86_CALL(x86_c2_l_14, 0xfULL);
x86_c0_l_f:
	/* 0xf: jmp    33 <subf0+0x1f> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_c1_l_14:
	/* 0x14: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
	goto x86_c1_l_18;
x86_c1_l_18:
	/* 0x18: mov    QWORD PTR [rsp],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c1_l_1c;
x86_c1_l_1c:
	/* 0x1c: test   eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c1_l_21;
x86_c1_l_21:
	/* 0x21: je     2b <subf0+0x17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21, 0x2b, x86_c1_l_2b);
	goto x86_c1_l_23;
x86_c1_l_23:
	/* 0x23: imul   eax,eax,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_RAX, X86_RAX, X86_WIDTH_32, 3ULL);
	goto x86_c1_l_26;
x86_c1_l_26:
	/* 0x26: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
	goto x86_c1_l_2a;
x86_c1_l_2a:
	/* 0x2a: ret */
	X86_SIM_X86_SUB_RET(x86_c1_l_2a_ret);
x86_c1_l_2a_ret:
	switch (__x86_sim_ret_addr) {
	case 0x7ULL: goto x86_c0_l_7;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c1_l_2b:
	/* 0x2b: add    eax,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 7ULL);
	goto x86_c1_l_2e;
x86_c1_l_2e:
	/* 0x2e: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
	goto x86_c1_l_32;
x86_c1_l_32:
	/* 0x32: ret */
	X86_SIM_X86_SUB_RET(x86_c1_l_32_ret);
x86_c1_l_32_ret:
	switch (__x86_sim_ret_addr) {
	case 0x7ULL: goto x86_c0_l_7;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c2_l_14:
	/* 0x14: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
	goto x86_c2_l_18;
x86_c2_l_18:
	/* 0x18: mov    QWORD PTR [rsp],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	goto x86_c2_l_1c;
x86_c2_l_1c:
	/* 0x1c: test   eax,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RAX, X86_WIDTH_32, 1ULL);
	goto x86_c2_l_21;
x86_c2_l_21:
	/* 0x21: je     2b <subf0+0x17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21, 0x2b, x86_c2_l_2b);
	goto x86_c2_l_23;
x86_c2_l_23:
	/* 0x23: imul   eax,eax,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_RAX, X86_RAX, X86_WIDTH_32, 3ULL);
	goto x86_c2_l_26;
x86_c2_l_26:
	/* 0x26: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
	goto x86_c2_l_2a;
x86_c2_l_2a:
	/* 0x2a: ret */
	X86_SIM_X86_SUB_RET(x86_c2_l_2a_ret);
x86_c2_l_2a_ret:
	switch (__x86_sim_ret_addr) {
	case 0xfULL: goto x86_c0_l_f;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_c2_l_2b:
	/* 0x2b: add    eax,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 7ULL);
	goto x86_c2_l_2e;
x86_c2_l_2e:
	/* 0x2e: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
	goto x86_c2_l_32;
x86_c2_l_32:
	/* 0x32: ret */
	X86_SIM_X86_SUB_RET(x86_c2_l_32_ret);
x86_c2_l_32_ret:
	switch (__x86_sim_ret_addr) {
	case 0xfULL: goto x86_c0_l_f;
	default: __x86_sim_unresolved_indirect_target();
	}
}

X86_SIM_LICENSE();
