from pathlib import Path
import json,re,subprocess,time
from elftools.elf.elffile import ELFFile
N=Path(__file__).parent;R=Path('/workspaces/repository');s=(N/'trusted_x86.bpf.c').read_text();s=re.sub(r'#include "[^"\n]*x86_sim_local_bpf.h"','#include '+json.dumps(str(N/'source/kprog/x86/x86_sim_local_bpf.h')),s);p=N/'tracee.c';p.write_text(s)
command=['/usr/lib/llvm-18/bin/clang','-g','-O3','-mcpu=v4','-target','bpf','-mllvm','-bpf-stack-size=4096','-D__TARGET_ARCH_x86','-I'+str(R/'vendor/libbpf/include/uapi'),'-I'+str(R/'vendor/libbpf/src'),'-I/usr/include/x86_64-linux-gnu','-c',str(p),'-o',str(N/'tracee.bpf.o')]
t=time.monotonic()
with(N/'tracee.compile.log').open('w')as log:q=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
row=dict(command=command,exit=q.returncode,wall_seconds=time.monotonic()-t)
if q.returncode==0:
 with(N/'tracee.bpf.o').open('rb')as f:row['sections']=[dict(name=s.name,instructions=s.data_size//8)for s in ELFFile(f).iter_sections()if s['sh_flags']&4 and s.data_size]
(N/'component.json').write_text(json.dumps(row,indent=2)+'\n');print(row,flush=True)
raise SystemExit(q.returncode)
