from pathlib import Path
import os,sys,json,subprocess,select,threading,time
N=Path(__file__).parent;D=N.parent/'remaining-apps';A=D/'tracee-ghost-init';R=Path('/workspaces/repository')
try:
 fd=os.pidfd_open(int((N/'checks.pid').read_text()));select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
if int((N/'checks.exit').read_text()):raise RuntimeError('compile check outcome '+(N/'checks.exit').read_text())
rows=json.loads((N/'mov-hosts.json').read_text())
if any(r.get('compile_exit') or r.get('run_exit') for r in rows):raise RuntimeError('existing host outcomes '+repr(rows))
state=N/'broker'
with(N/'broker.log').open('wb')as log:server=subprocess.Popen(['taskset','-c','8-11',sys.executable,str(N/'service/trusted_compile.py'),'serve','--scope',str(N.parent),'--state',str(state),'--clang','/usr/lib/llvm-18/bin/clang'],stdout=log,stderr=subprocess.STDOUT)
(N/'broker.pid').write_text(str(server.pid)+'\n')
def monitor():
 rc=server.wait()
 if not(state/'STOP').exists():(state/'failed.json').write_text(json.dumps(dict(error='compiler exited',returncode=rc))+'\n')
threading.Thread(target=monitor,daemon=True).start()
try:
 while not(state/'ready.json').exists():
  if server.poll()is not None:raise RuntimeError('compiler startup '+str(server.returncode))
  time.sleep(.1)
 with(N/'whole.log').open('wb')as log:q=subprocess.run(['make','-f',str(A/'Makefile'),'corpus','STATE='+str(A),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS=tracee/monitor','SAMPLES=1','WORKLOAD_DURATION=2'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 (N/'whole.exit').write_text(str(q.returncode)+'\n')
 with(N/'collect.log').open('wb')as log:q=subprocess.run([sys.executable,str(N/'collect.py'),'tracee-ghost-init'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 (N/'collect.exit').write_text(str(q.returncode)+'\n');q.check_returncode()
finally:
 (state/'STOP').write_text('application cohort closed\n');server.wait()
with(N/'publish.log').open('wb')as log:q=subprocess.run([sys.executable,str(N/'publish.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(N/'publish.exit').write_text(str(q.returncode)+'\n');q.check_returncode()
(N/'queue.exit').write_text('0\n')
