from pathlib import Path
from datetime import datetime,timezone
import json,tarfile,shutil,subprocess,sys,re
N=Path(__file__).parent;C=N.parent.parent;R=Path('/workspaces/repository');A=N.parent/'remaining-apps/tracee-ghost-init';I=N.parent/'remaining-apps/collected/tracee-ghost-init';O=R/'corpus/results/kprog_app_coverage_20261108/stack-ghost-init';O.mkdir(exist_ok=True)
v=json.loads((I/'coverage.json').read_text());rows=v['programs'];work=[dict(application=p['application'],status=p['app']['status'],error=p['app'].get('error'),baseline=p['app'].get('baseline'),post_rejit=p['app'].get('post_rejit'))for p in v['results']];baseline=len(work[0]['baseline'].get('bpf',[]))if work and work[0]['baseline']else 0
for p in I.iterdir():
 if p.is_file():shutil.copy2(p,O/p.name)
(O/'work.json').write_text(json.dumps(work,indent=2)+'\n')
summary=f"Whole Tracee: baseline{baseline}, generated{v['generated']}, compiled{v['compiled']}, installed{v['installed']}, failed{v['failed']}, native joins{sum(r['native_sha256_matches']for r in rows)}/{len(rows)}."
lines=['# Tracee on initialized inactive ghost pointer storage','',summary,'','Private generic representation initializes named and array ghost pointer cells to0 while their existing initial tags remain scalar. Raw native stack bytes, architectural GPRs, memory operations, flags and control flow retain their existing expressions. Existing pointer-overlap/lifetime native-host comparisons,30micro compiler controls and the captured full Tracee compilation retain their actual logs. Canonical source adoption0; runtime admission additions0.','','| Native entry | Generated | Compiled | Status | Verifier observation |','| --- | ---: | ---: | ---: | --- |']
for r in rows:lines.append('| '+r['entry']+' | '+str(int(r['generated']))+' | '+str(int(r['compiled']))+' | '+str(r['status'])+' | '+('; '.join(r['verifier_excerpt'][-2:]).replace('|','/'))+' |')
lines+=['','The whole original Tracee application retains the existing image/native inputs and two-second workload. Baseline resident census and submitted terminal requests have distinct domains. Runtime compilation uses the fresh registered service and host compiler broker. [runtime.tar.gz](runtime.tar.gz), [service.tar.gz](service.tar.gz) and [result.tar.gz](result.tar.gz) retain complete captured inputs, generated C/BPF, compiler, verifier and raw work evidence. Universal inactive-ghost/compiler erasure remains with V.','']
(O/'README.md').write_text('\n'.join(lines))
with tarfile.open(O/'runtime.tar.gz','w:gz')as t:
 for p in sorted(N.iterdir()):
  if p.name not in ['broker','publication.json','publish.log','__pycache__']:t.add(p,arcname=p.name)
 for name in ['Makefile','guest.py','summary.json']:t.add(A/name,arcname='application/'+name)
paths=[str(p.relative_to(R))for p in O.iterdir()if p.is_file()]
table=R/'corpus/results/kprog_app_coverage_20261108/README.md';rel=str(table.relative_to(R))
if work and table.read_bytes()==subprocess.check_output(['git','show','HEAD:'+rel]):
 failed=[r for r in rows if r['status']];reject=[r for r in failed if r['compiled'] and r['verifier_excerpt']];other=[r for r in failed if r not in reject];causes='; '.join(r['entry']+' '+next((x for x in r['verifier_excerpt'] if 'processed 'not in x),r.get('error','load error'))[:150].replace('|','/')for r in reject)
 line=f"| Tracee | {baseline} resident | {v['generated']} | {v['compiled']} | {v['installed']} | {len(other)} | {len(reject)}: {causes or '0'} | [private initialized ghost whole cohort](stack-ghost-init/README.md) |";table.write_text(re.sub(r'^\| Tracee \|.*$',lambda _:line,table.read_text(),flags=re.M));paths.append(rel)
sys.path.insert(0,str(C));from publish_owned import publish
commit=publish(paths,'Record original Tracee on initialized ghost pointer storage',N/'publication.json');now=datetime.now(timezone.utc).isoformat()
text='\n- LOCAL C FOR V/A/R '+now+': PUSHED '+commit+' '+summary+' Private inactive-pointer initialization candidate, canonical adoption0. Actual source/hosts/full/micro/runtime receipts in stack-ghost-init. Existing native algorithm,memops,flags,branches retained. Runtime admission additions0.\n'
(C.parent/'COORDINATION.md').open('a').write(text);(C/'last.md').open('a').write('\n## '+now+' ghost storage continuation\n'+text)
p=C/'current.json';j=json.loads(p.read_text());j['updated']=now;j['active']['stack-ghost-init'].update(status='closed and published '+commit,summary=summary);p.write_text(json.dumps(j,indent=2)+'\n');print(summary,commit,flush=True)
