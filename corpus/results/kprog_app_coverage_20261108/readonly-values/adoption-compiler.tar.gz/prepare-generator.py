from pathlib import Path
import difflib,ast,json
N=Path(__file__).parent;R=Path('/workspaces/repository')
p=R/'kprog/x86/micro-prog/generate_micro_sim_proofs.py';old=p.read_text()
function=r'''def readonly_load_declarations(objects: list[tuple[str, bytes]]) -> list[str]:
    """Represent immutable native bytes as finite C values at their exact offsets.

    The compile-time base choice preserves object identity. Each unrepresented
    address or access width retains the ordinary memory operation.
    """
    lines = []
    for name, data in objects:
        lines.extend([
            f"static __always_inline __u64 {name}_value(__u64 offset, __u8 width)",
            "{", "\tswitch (width) {",
        ])
        for width in (1, 2, 4, 8):
            lines.append(f"\tcase {width}: switch (offset) {{")
            for offset in range(len(data) - width + 1):
                value = int.from_bytes(data[offset:offset + width], "little")
                lines.extend([
                    f"\tcase {offset}: {{",
                    f"\t\t__u64 value = {value}ULL;",
                    '\t\t__asm__("" : "+r"(value));',
                    "\t\treturn value;", "\t}",
                ])
            lines.append("\t} break;")
        lines.extend([
            "\t}",
            f"\treturn KPROG_X86_MEM_LOAD((const __u8 *){name} + offset, width);",
            "}", "",
        ])
    if objects:
        lines.extend([
            "#undef X86_SIM_L_NATIVE_DATA_LOAD",
            "#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \\",
            "({ const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \\",
            "   __u8 __x86_ro_width = (WIDTH); __u64 __x86_ro_value; \\",
        ])
        for name, _ in objects:
            lines.extend([
                "   if (__builtin_constant_p((__u64)(long)__x86_ro_base - "
                f"(__u64)(long){name})) \\",
                f"       __x86_ro_value = {name}_value("
                f"(__u64)(long)__x86_ro_base - (__u64)(long){name} + "
                "__x86_ro_off, __x86_ro_width); else \\",
            ])
        lines.extend([
            "       __x86_ro_value = KPROG_X86_MEM_LOAD("
            "KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width); \\",
            "   __x86_ro_value; })", "",
        ])
    return lines


'''
s=old.replace('def render_program(name: str, insns: list[NativeInsn],',function+'def render_program(name: str, insns: list[NativeInsn],')
s=s.replace('    rodata_objects = []\n','    rodata_objects = []\n    readonly_values = []\n',1)
s=s.replace('        rodata_objects.append(dict(proof_section=section_name, proof_symbol=ident,','        readonly_values.append((ident, value))\n        rodata_objects.append(dict(proof_section=section_name, proof_symbol=ident,',1)
s=s.replace('    lines.extend([\n        section,','    lines.extend(readonly_load_declarations(readonly_values))\n    lines.extend([\n        section,',1)
ast.parse(s)
(N/'candidate-generator.py').write_text(s)
(N/'generator.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+str(p.relative_to(R)),tofile='b/'+str(p.relative_to(R)))))
# Keep the application compiler input frozen while formatting the adoption patch.
p=R/'kprog/x86/x86_sim_local_bpf.h';old=p.read_text();s=(N/'source/kprog/x86/x86_sim_local_bpf.h').read_text()
s=s.replace(' X86_SIM_L_LOAD_ADDR(KPROG_PTR_ADD64_BITS((BASE), (OFF)), (WIDTH))','\tX86_SIM_L_LOAD_ADDR(KPROG_PTR_ADD64_BITS((BASE), (OFF)), (WIDTH))')
s=s.replace(' __x86_l_base_ptr, __x86_l_disp, __x86_l_read_mem_width);','\t\t\t\t\t__x86_l_base_ptr, __x86_l_disp,       \\\n\t\t\t\t\t__x86_l_read_mem_width);')
s=s.replace(' __x86_l_base_ptr, __x86_l_disp, __x86_l_mem_width);','\t\t\t\t\t__x86_l_base_ptr, __x86_l_disp, __x86_l_mem_width);')
(N/'candidate-header.h').write_text(s)
(N/'header.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+str(p.relative_to(R)),tofile='b/'+str(p.relative_to(R)))))
# Extract the generic renderer from the actual candidate generator for comparison.
module=ast.parse((N/'candidate-generator.py').read_text())
node=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='readonly_load_declarations')
scope={};exec(compile(ast.Module(body=[node],type_ignores=[]),'<readonly-renderer>','exec'),scope)
fn=scope['readonly_load_declarations']
from renderer import readonly_code
import re
captured=(N/'captured.c').read_text();match=re.search(r'static const __u8 (__x86_rodata_\d+)\[\d+\] SEC\([^\n]+?= \{([^}]+)\};',captured)
objects=[(match[1],bytes(int(v.strip(),16)for v in match[2].split(',')))]
original=readonly_code(objects)
new='\n'.join(fn(objects))+'\n'
# Use the same captured program, replacing only the renderer declarations.
s=captured.replace(original,new).replace(str(N/'source/kprog/x86/x86_sim_local_bpf.h'),str(N/'candidate-header.h'))
# A flat header path requires its include graph to retain the source snapshot.
header=(N/'candidate-header.h').read_text().replace('#include "x86_sim.h"','#include "'+str(N/'source/kprog/x86/x86_sim.h')+'"')
header=header.replace('#include "../../kinsn/','#include "'+str(N/'source/kinsn')+'/').replace('#include "../formal/','#include "'+str(N/'source/kprog/formal')+'/')
(N/'candidate-header.h').write_text(header)
(N/'candidate-generated.c').write_text(s)
with (N/'Makefile').open('a')as f:f.write('''\n.PHONY: adoption-component
adoption-component:
\t/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -I$(ROOT)/kprog/x86 -I$(ROOT)/vendor/libbpf/include/uapi -I$(ROOT)/vendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c $(HERE)/candidate-generated.c -o $(HERE)/candidate-generated.bpf.o
''')
print('generic candidate generator parsed; captured source bytes',len(s))
