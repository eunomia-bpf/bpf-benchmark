set -eu
N=/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/readonly-values
trap 'echo $? > "$N/candidate-micro.exit"' EXIT
taskset -c 8-11 make -f "$N/Makefile" candidate-micro > "$N/candidate-micro.log" 2>&1
