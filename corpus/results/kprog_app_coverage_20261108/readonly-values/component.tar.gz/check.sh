set -eu
N=/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/readonly-values
trap 'echo $? > "$N/check.exit"' EXIT
taskset -c 8-11 make -f "$N/Makefile" component > "$N/component.log" 2>&1
