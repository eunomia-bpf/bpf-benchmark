from pathlib import Path
import random,json
from renderer import readonly_code
N=Path(__file__).parent
rng=random.Random(74039)
objects=[('one',bytes(rng.randrange(256)for _ in range(96))),('two',bytes(rng.randrange(256)for _ in range(96)))]
lines=['#include <stdint.h>','#include <stdio.h>','#include <string.h>', '#include <stdlib.h>', '#include "'+str(N/'source/kprog/x86/x86_sim_local_bpf.h')+'"']
for name,data in objects:
 lines.append('static const __u8 '+name+'[96] = {'+','.join(map(str,data))+'};')
# Model the first 80 bytes as the immutable native extent. Reads of the
# accessible remaining backing bytes exercise the original memory route.
lines += [readonly_code([(name,data[:80])for name,data in objects]),'int main(void) { unsigned long count=0;']
lines += ['for (unsigned which=0;which<2;which++) for (unsigned w=1;w<=8;w*=2) for (unsigned base=0;base<24;base++) for (unsigned at=0;at+w<=96;at++) {', 'const __u8 *p=which?two:one; __u64 expected=0; memcpy(&expected,p+at,w);', '__s64 delta=(__s64)at-base; __asm__("" : "+r"(delta));', '__u64 actual=which?two_value(base+delta,w):one_value(base+delta,w);', 'if (actual!=expected) { fprintf(stderr,"extent read which%u width%u base%u at%u\\n",which,w,base,at);return 1;} count++;','}']
# Exercise compile-time identity and the raw route with unrelated memory.
lines += ['for(unsigned w=1;w<=8;w*=2) for(unsigned at=0;at+w<=96;at++){','__u64 expected=0;memcpy(&expected,one+at,w); __u64 off=at; __asm__("" : "+r"(off));', '__u64 actual=X86_SIM_L_NATIVE_DATA_LOAD(one+16,off-16,w); if(actual!=expected)return 2;count++;','__u8 mutable[96];memcpy(mutable,two,96);memcpy(&expected,mutable+at,w);actual=X86_SIM_L_NATIVE_DATA_LOAD(mutable,off,w);if(actual!=expected)return 3;count++;','}', 'printf("readonly native-byte reads: %lu, differences: 0\\n",count); return 0; }']
(N/'host.c').write_text('\n'.join(lines)+'\n')
