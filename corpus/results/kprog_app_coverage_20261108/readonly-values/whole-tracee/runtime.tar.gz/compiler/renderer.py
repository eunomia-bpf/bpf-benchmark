import re

def readonly_code(objects):
 lines=[]
 for name,data in objects:
  lines += [f'static __always_inline __u64 {name}_value(__u64 offset, __u8 width)', '{', 'switch (width) {']
  for width in (1,2,4,8):
   lines += [f'case {width}: switch (offset) {{']
   for offset in range(len(data)-width+1):
    value=int.from_bytes(data[offset:offset+width],'little')
    lines += [f'case {offset}: {{ __u64 value = {value}ULL; __asm__("" : "+r"(value)); return value; }}']
   lines += ['} break;']
  lines += ['}',f'return KPROG_X86_MEM_LOAD((const __u8 *){name} + offset, width);','}']
 if objects:
  lines += ['#undef X86_SIM_L_NATIVE_DATA_LOAD', '#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \\', '({ void *__ro_base = (BASE); __u64 __ro_off = (OFF); __u8 __ro_width = (WIDTH); __u64 __ro_value; \\']
  for name,_ in objects:
   lines += [f'if (__builtin_constant_p((__u64)(long)__ro_base - (__u64)(long){name})) \\',f' __ro_value = {name}_value((__u64)(long)__ro_base - (__u64)(long){name} + __ro_off, __ro_width); else \\']
  lines += [' __ro_value = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__ro_base, __ro_off), __ro_width); \\', ' __ro_value; })']
 return '\n'.join(lines)+'\n'

def transform(text,header):
 text=text.replace('/workspaces/repository/kprog/x86/x86_sim_local_bpf.h',str(header))
 objects=[]
 pattern=r'static const __u8 (__x86_rodata_\d+)\[\d+\] SEC\([^\n]+?= \{([^}]+)\};'
 for match in re.finditer(pattern,text):
  objects.append((match[1],bytes(int(v.strip(),16)for v in match[2].split(','))))
 if objects:
  marker=re.search(r'static const char __x86_rodata_metadata[^\n]+\n',text)
  pos=marker.end()
  text=text[:pos]+readonly_code(objects)+'\n'+text[pos:]
 return text
