from pathlib import Path
import shutil,re,json,hashlib
from datetime import datetime,timezone
N=Path(__file__).resolve().parent;R=Path('/workspaces/repository');D=N.parent
for rel in ['kprog/x86/x86_sim.h','kprog/x86/x86_sim_local_bpf.h','kinsn/module/include/native_lab_input.h','kprog/formal/generated']:
 src=R/rel;dst=N/'source'/rel;dst.parent.mkdir(parents=True,exist_ok=True)
 if src.is_dir():shutil.copytree(src,dst,dirs_exist_ok=True)
 else:shutil.copy2(src,dst)
h=N/'source/kprog/x86/x86_sim_local_bpf.h';s=h.read_text()
old='#define X86_SIM_L_LOAD_ADDR(ADDR, WIDTH) KPROG_X86_MEM_LOAD((ADDR), (WIDTH))'
s=s.replace(old,old+'\n\n#ifndef X86_SIM_L_NATIVE_DATA_LOAD\n#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \\\n X86_SIM_L_LOAD_ADDR(KPROG_PTR_ADD64_BITS((BASE), (OFF)), (WIDTH))\n#endif')
for width in ['__x86_l_read_mem_width','__x86_l_mem_width']:
 pattern=r'X86_SIM_L_LOAD_ADDR\(\s*\\\n\s*\(void \*\)\(long\)__x86_l_addr,\s*\\?\n?\s*'+width+r'\)'
 s,n=re.subn(pattern,lambda m:'X86_SIM_L_NATIVE_DATA_LOAD( \\\n __x86_l_base_ptr, __x86_l_disp, '+width+')',s)
 print(width,n)
h.write_text(s)
(N/'before.h').write_text((R/'kprog/x86/x86_sim_local_bpf.h').read_text())
from renderer import transform
s=(D/'tracee-length/failure.c').read_text();(N/'captured.c').write_text(transform(s,h))
(N/'Makefile').write_text(f'''ROOT := {R}
HERE := {N}
.PHONY: component micro
component:
\t/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -I$(ROOT)/kprog/x86 -I$(ROOT)/vendor/libbpf/include/uapi -I$(ROOT)/vendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c $(HERE)/captured.c -o $(HERE)/captured.bpf.o
micro:
\t$(MAKE) -C $(ROOT)/kprog/x86 micro-proofs-build CLANG=$(HERE)/clang-micro PROOF_BUILD_DIR=$(HERE)/micro NEGATIVE_NATIVE_BUILD_DIR=$(HERE)/negative-native
''')
(N/'check.sh').write_text(f'''set -eu
N={N}
trap 'echo $? > "$N/check.exit"' EXIT
taskset -c 8-11 make -f "$N/Makefile" component > "$N/component.log" 2>&1
''')
files={str(p.relative_to(N)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (N/'source').rglob('*')if p.is_file()}
(N/'inputs.json').write_text(json.dumps(files,indent=2)+'\n')
with Path('/workspaces/.agent-state/kprog-lanes/COORDINATION.md').open('a')as f:f.write('\n- LOCAL C '+datetime.now(timezone.utc).isoformat()+': x86 continuation takes the closed Cilium helper9 stack-spill and Tracee immutable-read frontiers. Private readonly-value representation expands exact native object bytes through finite C loads; original raw memory operation covers every remaining address. Component then whole Tracee receipts follow. Canonical model/generator stay at published sources during measurement; A/V shared changes retain ownership.\n')
