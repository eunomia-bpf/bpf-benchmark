from pathlib import Path
import sys,subprocess,json,os,select,hashlib
H=Path(__file__).parent;R=Path('/workspaces/repository');C=H.parent.parent
with(H/'build.log').open('w')as log:q=subprocess.run(['taskset','-c','20-23','make','-f',str(H/'Makefile'),'build'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(H/'build.exit').write_text(str(q.returncode)+'\n');q.check_returncode()
pins={}
for path in ['kprog/libnativeloader/build/trusted-native-loader','kprog/libnativeloader/build/libnative_loader.a','kprog/libnativeloader/src/native_loader.cpp','kprog/libnativeloader/src/native_loader_link_schema.hpp','kprog/tv/build-kernel-x86/arch/x86/boot/bzImage','kprog/tv/build-x86/corpus-modules/bpf_x86_native_lab.ko','kprog/x86/native_lab/native_link/target/release/native-link']:
 pins[path]=hashlib.sha256((R/path).read_bytes()).hexdigest()
(H/'inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
try:
 fd=os.pidfd_open(int((C/'design-only/remaining-apps/katran-shared-extent/controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
with(H/'replay.log').open('w')as log:q=subprocess.run(['make','-f',str(H/'Makefile'),'replay'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(H/'replay.exit').write_text(str(q.returncode)+'\n')
with(H/'publish.log').open('w')as log:q=subprocess.run([sys.executable,str(H/'publish.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(H/'publish.exit').write_text(str(q.returncode)+'\n');q.check_returncode()
