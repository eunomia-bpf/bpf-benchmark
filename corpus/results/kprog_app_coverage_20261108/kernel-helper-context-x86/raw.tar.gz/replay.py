from pathlib import Path
import subprocess,sys,json,fcntl,os
H=Path(__file__).parent;R=Path('/workspaces/repository');S=H/'requests';S.mkdir(mode=0o700)
command=[sys.executable,str(R/'kprog/trusted_service.py'),'--arch','1','--endpoint','/sys/kernel/debug/bpf_x86_native_lab/specializer','--state',str(S),'--native-link',str(R/'kprog/x86/native_lab/native_link/target/release/native-link'),'--loader',str(R/'kprog/libnativeloader/build/trusted-native-loader')]
service=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=(H/'service.stderr').open('w'),text=True);log=[];rows=[]
try:
 line=service.stdout.readline();log.append(line);print(line,flush=True)
 for row in json.loads((H/'cases.json').read_text()):
  cmd=[str(H/'probe'),row['bpf.o'],row['native.o'],row['symbol']]
  done=subprocess.run(cmd,cwd=R,env=dict(os.environ,BPFREJIT_NATIVE_LOADER_REQUIRE_BOUND_PROOF='1'),capture_output=True,text=True)
  (H/(row['name']+'.stdout')).write_text(done.stdout);(H/(row['name']+'.stderr')).write_text(done.stderr)
  if done.returncode and 'trusted specializer refused native program:' not in done.stderr:raise RuntimeError('producer setup: '+row['name']+' '+done.stderr)
  line=service.stdout.readline();log.append(line);row.update(command=cmd,producer_exit=done.returncode,request=json.loads(line),native_executions=0);rows.append(row);(H/'outcomes.json').write_text(json.dumps(rows,indent=2)+'\n');print(row['name'],row['request']['status'],flush=True)
finally:
 with(S/'request.lock').open('rb')as lock:fcntl.flock(lock,fcntl.LOCK_EX)
 service.terminate();tail=service.communicate()[0];log.append(tail);(H/'service.log').write_text(''.join(log))
