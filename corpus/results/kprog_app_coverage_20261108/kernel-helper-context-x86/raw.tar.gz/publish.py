from pathlib import Path
from datetime import datetime,timezone
import json,sys,tarfile,hashlib
H=Path(__file__).parent;C=H.parent.parent;R=Path('/workspaces/repository');O=R/'corpus/results/kprog_app_coverage_20261108/kernel-helper-context-x86';O.mkdir(parents=True,exist_ok=True)
rows=json.loads((H/'outcomes.json').read_text())
for row in rows:
 request=row['request'];archive=request.get('artifact_archive',request.get('failure_archive'))
 with tarfile.open(archive)as t:
  names=set(t.getnames());row['generated']='request/generated/trusted_x86.bpf.c'in names;row['compiled']='request/generated/trusted_x86.bpf.o'in names;row['native_hash_matches']=hashlib.sha256(t.extractfile('request/kernel.native.o').read()).hexdigest()==row['native.o_sha256']
result=dict(utc=datetime.now(timezone.utc).isoformat(),build_exit=int((H/'build.exit').read_text()),replay_exit=int((H/'replay.exit').read_text()),inputs=json.loads((H/'inputs.json').read_text()),records=rows,native_executions=0)
(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['# Original kernel C MTU helpers on x86','','The three original annotated C native objects retain their complete bytes. A fresh source_prog_id0 resource producer submits them through the existing five-step constructor using object-derived context and actual resource map FDs. The common loader uses the existing bpf_check_mtu contextual alias selection shared with lane A; the single contextual-ID source change retains A ownership. This x86 warm build supplies the public helper identity to native-link. Original annotations retain R ownership for the complete safety sweep.','','All three probes request loading only; native executions0. This cohort records generation, compilation and kernel installation separately.','','| Original entry | Generated | Compiled | Kernel status |','| --- | ---: | ---: | ---: |']
for row in rows:lines.append('| '+row['symbol']+' | '+str(int(row['generated']))+' | '+str(int(row['compiled']))+' | '+str(row['request']['status'])+' |')
lines+=['','Warm worker/static/shared library build and existing9service cases run through make trusted-service-check. Exact actual exits/hashes and all native joins are in [summary.json](summary.json). Source, original kernel C/native/BPF inputs, actual generated B, compiler/verifier/service/producer output and commands remain in [raw.tar.gz](raw.tar.gz).','','```sh','make -f /workspaces/.agent-state/kprog-lanes/C/design-only/kernel-helper-context-x86/Makefile build replay','```','','Worker path: kprog/libnativeloader/build/trusted-native-loader. Existing runtime admission predicates retain their definitions; additions0.',''];(O/'README.md').write_text('\n'.join(lines))
with tarfile.open(O/'raw.tar.gz','w:gz')as t:
 for p in H.iterdir():
  if p.name not in ['publication.json','publish.log','controller.log']:t.add(p,arcname=p.name)
 for row in rows:
  for ext in ['native.o','bpf.o']:t.add(row[ext],arcname='inputs/'+row['name']+'.'+ext)
 for source in sorted((R/'kprog/libnativeloader/src').iterdir()):
  if source.suffix in ['.cpp','.hpp']:t.add(source,arcname='source/'+source.name)
 t.add(R/'kprog/libnativeloader/build/trusted-native-loader',arcname='worker/trusted-native-loader')
sys.path.insert(0,str(C));from publish_owned import publish
commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Record original kernel C MTU helper requests on x86',H/'publication.json');now=datetime.now(timezone.utc).isoformat();msg='\n- LOCAL C FOR R/A/V '+now+': PUSHED '+commit+' original MTU C3 x86 source0 requests '+repr([(r['symbol'],r['generated'],r['compiled'],r['request']['status'])for r in rows])+', nativeexecutions0. Fresh canonical x86 worker/static/shared warm build+existing9service cases recorded. A contextual163 identity source ownership retained; complete originalP/B/verifier/source/worker hashes archived. R can consume kprog/libnativeloader/build/trusted-native-loader with shared006e Image/module. Runtime admission additions0.\n';(C.parent/'COORDINATION.md').open('a').write(msg);(C/'last.md').open('a').write(msg)
p=C/'current.json';j=json.loads(p.read_text());j['updated']=now;j['active']['kernel-helper-context-x86'].update(status='closed and published '+commit,result=result);p.write_text(json.dumps(j,indent=2)+'\n');print(commit,flush=True)
