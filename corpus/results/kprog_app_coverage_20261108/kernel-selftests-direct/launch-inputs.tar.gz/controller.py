from pathlib import Path
import os,json,subprocess,tarfile,sys,datetime,traceback,gzip
G=Path(__file__).resolve().parent;C=G.parent.parent;R=Path('/workspaces/repository');O=R/'corpus/results/kprog_app_coverage_20261108/kernel-selftests-direct'
sys.path.insert(0,str(C));from publish_owned import publish
def notice(s):
 msg='\n- LOCAL C FOR R/A/V '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': '+s+'\n'
 for p in [C.parent/'COORDINATION.md',C/'last.md']:
  with p.open('a') as f:f.write(msg)
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(phase=phase,**kw),indent=2)+'\n')
try:
 O.mkdir(exist_ok=True);(O/'launch.json').write_bytes((G/'launch.json').read_bytes())
 (O/'README.md').write_text('# x86 original kernel C direct native catalog replay\n\nThis cohort submits every239currently compiled original C entry from the existing1917-row x86 catalog. The complete catalog retains its C/inline-assembly, compilation and entry stages. Each object opens with allprogramautoloadfalse; actual maps/BTF and temporary bpffs pins carry its capabilities. Direct native P, source_prog_id0 and original program context use A published submit source2e9a11f3d. The registered service generates B from the immutable kernel copy and the stock verifier supplies the load outcome. Every negative annotation uses load-only submission, and installed __failure entries count as findings. Native executions:0.\n\nThe launch snapshot captures the current canonical x86 simulatorc1f6b78f4, common Python/generated headers, paired loader/linker/module, original native/resource objects and complete catalog. A private mount namespace retains these bytes throughout the run. The shared incremental Image is c0a47723ee51; one12GiB/four-vCPU guest runs on20-23 after the completed BCC/Katran cohort. Runtime admission additions:0.\n\nCommand: `make -f /workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-direct/Makefile run`. Original source catalogs, additional C compilation coverage, program-context triage and universal compiler/model closure retain their owners R/A/C/V.\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as tf:
  for name in ['launch.json','source','table','Makefile','mount.py','controller.py']:tf.add(G/name,arcname=name)
 commit=publish([str((O/n).relative_to(R)) for n in ['README.md','launch.json','launch-inputs.tar.gz']],'Run original x86 kernel C entries through direct native submission',G/'launch-publication.json');save('running',launch_publication=commit);notice('PUSHED '+commit+' priority2a x86 direct-source0 original239compiled-C catalog replay starts20-23/12GiB. Existing A2e9a submit/maps/BTF/autoloadfalse installed-stage attribution; canonicalc1f6 captured source/sharedextent Image/pairedmodule. Every annotation load-only, nativeexecutions0. R sourcecatalog and A submit implementation ownership retained; C classifies x86 simulator/compiler/ABI outcomes. Runtime admission additions0.')
 with (G/'run.log').open('w') as f:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1','PYTHONPYCACHEPREFIX':str(G/'pycache')})
 (G/'run.exit').write_text(str(p.returncode)+'\n');report=dict(make_exit=p.returncode,native_execution_count=0);paths=[]
 q=G/'out/submissions.json'
 if q.exists():
  (O/'submissions.json').write_bytes(q.read_bytes());paths.append(O/'submissions.json');report['counts']=json.loads(q.read_text())['counts']
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 with tarfile.open(O/'raw.tar.gz','w:gz') as tf:
  for name in ['out','tmp','run.log','run.exit']:tf.add(G/name,arcname=name)
 paths.append(O/'raw.tar.gz');commit=publish([str(p.relative_to(R)) for p in paths],'Record original x86 kernel C direct native outcomes',G/'result-publication.json');save('finished',result_publication=commit,**report);notice('PUSHED '+commit+' original239x86 direct-native terminal '+json.dumps(report)+'. Every actual resource/generation/compiler/verifier/install row and native/B/maps/context retained; installed __failure rows supply simulator/compiler triage findings. Runtime admission additions0.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
