from pathlib import Path
import subprocess,json,tarfile,sys,datetime,traceback
G=Path(__file__).resolve().parent;C=G.parent.parent;R=Path('/workspaces/repository');O=R/'corpus/results/kprog_app_coverage_20261108/kernel-selftests-direct'
try:
 with (G/'resource.log').open('w')as log:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'resource-mount.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 (G/'resource.exit').write_text(str(p.returncode)+'\n')
 names=['resource.mk','resource-observation.py','resource-mount.py','resource-controller.py','resource.log','resource.exit'];paths=[]
 q=G/'resource-observation.json'
 if q.exists():(O/q.name).write_bytes(q.read_bytes());paths.append(O/q.name);names.append(q.name)
 with tarfile.open(O/'resource-observation.tar.gz','w:gz')as tf:
  for n in names:tf.add(G/n,arcname=n)
 paths.append(O/'resource-observation.tar.gz');sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in paths],'Observe actual x86 typed map BTF after resource creation',G/'resource-publication.json')
 data=json.loads(q.read_text())if q.exists()else{};msg='\n- LOCAL C FOR R/A/V '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+commit+' typedmap fresh resource-only metadata observation Makeexit'+str(p.returncode)+' mapinfo'+json.dumps(data.get('map_info'))+'. Existing autoloadfalse map/BTF prelude and bpf_obj_get_info_by_fd only; native submissions/executions0. Actual map/type correspondence guides existingfivekptr findings; runtime admission additions0.\n'
 for n in [C.parent/'COORDINATION.md',C/'last.md']:
  with n.open('a')as f:f.write(msg)
except BaseException as e:(G/'resource-error.json').write_text(json.dumps(dict(error=str(e),traceback=traceback.format_exc()),indent=2));raise
