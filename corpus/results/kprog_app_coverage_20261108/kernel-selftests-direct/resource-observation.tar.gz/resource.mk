R := /workspaces/repository
G := /workspaces/.agent-state/kprog-lanes/C/design-only/kernel-selftests-direct
.PHONY: resources resources-guest
resources:
	taskset -c 20-23 vng --run $(R)/kprog/tv/build-kernel-x86/arch/x86/boot/bzImage --cwd $(R) --rwdir $(R) --rwdir /workspaces/.agent-state/kprog-lanes/C --overlay-rwdir /tmp --overlay-rwdir /run --disable-monitor --cpus 2 --memory 2G --append 'loglevel=4 panic=30 oops=panic' --exec 'make -f $(G)/resource.mk resources-guest'
resources-guest:
	@mountpoint -q /sys/fs/bpf || mount -t bpf bpf /sys/fs/bpf
	PYTHONDONTWRITEBYTECODE=1 PYTHONPYCACHEPREFIX=$(G)/pycache python3 -B $(G)/resource-observation.py
