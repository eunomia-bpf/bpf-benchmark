from pathlib import Path
import sys,json,ctypes as c,struct,traceback
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');sys.path.insert(0,str(R/'kprog/selftests'));import submit
class MapInfo(c.Structure):
 _fields_=[(n,c.c_uint32)for n in ['type','id','key_size','value_size','max_entries','map_flags']]+[('name',c.c_char*16)]+[(n,c.c_uint32)for n in ['ifindex','btf_vmlinux_value_type_id']]+[(n,c.c_uint64)for n in ['netns_dev','netns_ino']]+[(n,c.c_uint32)for n in ['btf_id','btf_key_type_id','btf_value_type_id','btf_vmlinux_id']]+[('map_extra',c.c_uint64),('hash',c.c_uint64),('hash_size',c.c_uint32)]
rows=json.loads((G/'table/programs.json').read_text())['programs'];row=next(r for r in rows if r['program']=='size_not_bpf_dw');obj=submit.ObjectResources('x86',row['bpf_object'],row['program'])
try:
 metadata,fds,details=obj.load(row['bpf_object']);maps=[]
 for fd in fds:
  info=obj.info(fd,MapInfo());maps.append({n:(getattr(info,n).decode(errors='replace')if n=='name'else getattr(info,n)) for n,_ in MapInfo._fields_})
 result=dict(metadata=metadata,resources=details,map_info=maps,loaded_modules=sorted(p.name for p in Path('/sys/module').iterdir()),kernel_release=Path('/proc/sys/kernel/osrelease').read_text().strip(),native_submissions=0,native_executions=0,source='Existing all-autoload-false object resource creation; bpf_obj_get_info_by_fd observation')
 (G/'resource-observation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
finally:obj.close()
