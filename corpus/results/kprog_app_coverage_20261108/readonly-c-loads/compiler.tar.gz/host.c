#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
static const __u8 one[96] = {201,151,142,122,201,179,220,231,126,49,177,186,68,34,106,61,223,80,192,177,1,191,6,30,189,228,206,9,209,170,147,67,25,223,9,195,103,144,209,63,20,10,219,90,103,99,79,22,230,227,189,184,156,59,245,7,234,32,231,46,0,168,236,8,138,122,22,200,67,191,98,97,223,37,253,3,89,55,248,109,231,175,70,112,209,250,159,151,170,69,223,18,59,215,194,165};
static const __u8 two[96] = {94,182,41,162,142,70,11,106,82,255,70,239,245,228,131,86,167,7,3,122,30,41,111,242,213,165,219,200,19,165,106,81,206,164,9,246,78,99,55,220,217,212,70,184,66,154,69,92,40,190,149,164,166,197,178,196,25,9,150,206,190,185,158,140,168,166,206,174,118,15,197,107,171,219,193,70,80,147,197,23,95,17,60,32,7,216,183,142,103,2,161,242,100,26,242,174};
static __always_inline __u64 one_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 0, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 1, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 2, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 3, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 4, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 5, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 6, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 7, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 8, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 9, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 10, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 11, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 12, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 13, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 14, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 15, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 16, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 17, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 18, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 19, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 20, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 21, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 22, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 23, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 24, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 25, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 26, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 27, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 28, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 29, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 30, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 31, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 32, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 33, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 34, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 35, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 36, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 37, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 38, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 39, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 40, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 41, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 42, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 43, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 44, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 45, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 46, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 47, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 48, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 49, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 50, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 51, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 52, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 53, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 54, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 55, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 56, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 57, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 58, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 59, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 60, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 61, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 62, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 63, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 64, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 65, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 66, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 67, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 68, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 69, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 70, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 71, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 72, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 73, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 74, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 75, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 76, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 77, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 78, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 79: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 79, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 0, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 1, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 2, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 3, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 4, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 5, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 6, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 7, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 8, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 9, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 10, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 11, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 12, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 13, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 14, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 15, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 16, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 17, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 18, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 19, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 20, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 21, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 22, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 23, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 24, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 25, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 26, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 27, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 28, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 29, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 30, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 31, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 32, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 33, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 34, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 35, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 36, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 37, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 38, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 39, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 40, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 41, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 42, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 43, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 44, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 45, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 46, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 47, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 48, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 49, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 50, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 51, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 52, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 53, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 54, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 55, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 56, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 57, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 58, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 59, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 60, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 61, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 62, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 63, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 64, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 65, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 66, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 67, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 68, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 69, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 70, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 71, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 72, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 73, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 74, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 75, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 76, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 77, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 78, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 0, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 1, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 2, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 3, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 4, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 5, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 6, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 7, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 8, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 9, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 10, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 11, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 12, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 13, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 14, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 15, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 16, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 17, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 18, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 19, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 20, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 21, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 22, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 23, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 24, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 25, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 26, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 27, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 28, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 29, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 30, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 31, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 32, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 33, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 34, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 35, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 36, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 37, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 38, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 39, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 40, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 41, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 42, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 43, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 44, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 45, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 46, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 47, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 48, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 49, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 50, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 51, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 52, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 53, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 54, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 55, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 56, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 57, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 58, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 59, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 60, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 61, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 62, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 63, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 64, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 65, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 66, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 67, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 68, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 69, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 70, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 71, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 72, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 73, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 74, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 75, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 76, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 0, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 1, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 2, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 3, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 4, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 5, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 6, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 7, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 8, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 9, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 10, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 11, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 12, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 13, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 14, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 15, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 16, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 17, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 18, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 19, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 20, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 21, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 22, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 23, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 24, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 25, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 26, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 27, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 28, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 29, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 30, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 31, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 32, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 33, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 34, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 35, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 36, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 37, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 38, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 39, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 40, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 41, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 42, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 43, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 44, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 45, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 46, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 47, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 48, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 49, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 50, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 51, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 52, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 53, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 54, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 55, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 56, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 57, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 58, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 59, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 60, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 61, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 62, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 63, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 64, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 65, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 66, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 67, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 68, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 69, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 70, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 71, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, one + 72, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)one + offset, width);
}

static __always_inline __u64 two_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 0, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 1, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 2, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 3, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 4, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 5, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 6, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 7, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 8, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 9, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 10, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 11, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 12, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 13, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 14, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 15, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 16, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 17, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 18, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 19, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 20, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 21, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 22, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 23, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 24, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 25, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 26, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 27, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 28, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 29, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 30, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 31, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 32, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 33, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 34, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 35, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 36, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 37, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 38, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 39, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 40, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 41, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 42, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 43, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 44, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 45, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 46, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 47, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 48, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 49, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 50, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 51, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 52, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 53, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 54, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 55, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 56, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 57, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 58, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 59, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 60, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 61, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 62, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 63, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 64, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 65, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 66, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 67, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 68, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 69, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 70, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 71, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 72, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 73, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 74, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 75, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 76, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 77, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 78, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 79: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 79, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 0, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 1, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 2, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 3, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 4, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 5, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 6, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 7, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 8, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 9, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 10, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 11, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 12, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 13, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 14, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 15, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 16, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 17, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 18, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 19, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 20, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 21, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 22, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 23, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 24, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 25, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 26, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 27, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 28, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 29, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 30, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 31, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 32, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 33, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 34, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 35, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 36, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 37, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 38, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 39, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 40, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 41, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 42, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 43, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 44, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 45, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 46, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 47, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 48, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 49, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 50, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 51, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 52, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 53, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 54, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 55, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 56, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 57, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 58, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 59, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 60, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 61, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 62, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 63, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 64, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 65, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 66, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 67, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 68, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 69, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 70, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 71, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 72, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 73, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 74, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 75, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 76, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 77: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 77, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 78: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 78, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 0, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 1, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 2, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 3, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 4, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 5, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 6, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 7, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 8, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 9, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 10, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 11, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 12, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 13, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 14, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 15, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 16, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 17, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 18, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 19, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 20, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 21, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 22, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 23, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 24, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 25, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 26, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 27, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 28, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 29, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 30, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 31, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 32, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 33, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 34, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 35, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 36, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 37, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 38, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 39, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 40, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 41, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 42, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 43, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 44, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 45, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 46, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 47, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 48, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 49, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 50, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 51, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 52, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 53, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 54, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 55, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 56, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 57, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 58, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 59, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 60, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 61, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 62, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 63, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 64, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 65, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 66, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 67, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 68, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 69, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 70, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 71, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 72, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 73: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 73, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 74: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 74, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 75: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 75, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 76: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 76, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 0, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 1, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 2, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 3, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 4, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 5, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 6, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 7, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 8, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 9, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 10, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 11, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 12, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 13, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 14, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 15: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 15, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 16: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 16, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 17: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 17, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 18: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 18, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 19: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 19, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 20: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 20, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 21: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 21, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 22: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 22, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 23: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 23, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 24: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 24, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 25: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 25, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 26: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 26, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 27: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 27, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 28: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 28, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 29: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 29, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 30: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 30, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 31: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 31, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 32: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 32, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 33: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 33, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 34: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 34, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 35: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 35, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 36: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 36, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 37: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 37, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 38: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 38, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 39: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 39, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 40: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 40, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 41: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 41, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 42: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 42, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 43: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 43, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 44: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 44, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 45: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 45, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 46: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 46, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 47: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 47, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 48: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 48, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 49: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 49, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 50: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 50, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 51: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 51, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 52: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 52, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 53: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 53, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 54: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 54, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 55: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 55, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 56: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 56, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 57: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 57, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 58: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 58, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 59: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 59, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 60: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 60, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 61: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 61, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 62: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 62, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 63: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 63, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 64: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 64, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 65: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 65, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 66: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 66, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 67: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 67, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 68: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 68, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 69: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 69, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 70: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 70, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 71: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 71, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 72: {
		__u64 value = 0;
		__builtin_memcpy(&value, two + 72, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)two + offset, width);
}

#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
({ const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 __x86_ro_value; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)one)) \
       __x86_ro_value = one_value((__u64)(long)__x86_ro_base - (__u64)(long)one + __x86_ro_off, __x86_ro_width); else \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)two)) \
       __x86_ro_value = two_value((__u64)(long)__x86_ro_base - (__u64)(long)two + __x86_ro_off, __x86_ro_width); else \
       __x86_ro_value = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width); \
   __x86_ro_value; })

int main(void) { unsigned long count=0;
for (unsigned which=0;which<2;which++) for (unsigned w=1;w<=8;w*=2) for (unsigned base=0;base<24;base++) for (unsigned at=0;at+w<=96;at++) {
const __u8 *p=which?two:one; __u64 expected=0; memcpy(&expected,p+at,w);
__s64 delta=(__s64)at-base; __asm__("" : "+r"(delta));
__u64 actual=which?two_value(base+delta,w):one_value(base+delta,w);
if (actual!=expected) { fprintf(stderr,"extent read which%u width%u base%u at%u\n",which,w,base,at);return 1;} count++;
}
for(unsigned w=1;w<=8;w*=2) for(unsigned at=0;at+w<=96;at++){
__u64 expected=0;memcpy(&expected,one+at,w); __u64 off=at; __asm__("" : "+r"(off));
__u64 actual=X86_SIM_L_NATIVE_DATA_LOAD(one+16,off-16,w); if(actual!=expected)return 2;count++;
__u8 mutable[96];memcpy(mutable,two,96);memcpy(&expected,mutable+at,w);actual=X86_SIM_L_NATIVE_DATA_LOAD(mutable,off,w);if(actual!=expected)return 3;count++;
}
printf("readonly native-byte reads: %lu, differences: 0\n",count); return 0; }
