set -eu
A=/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/readonly-values/adoption
trap 'echo $? > "$A/check.exit"' EXIT
taskset -c 8-11 make -f "$A/Makefile" host source > "$A/host.log" 2>&1
taskset -c 8-11 make -f "$A/Makefile" component > "$A/component.log" 2>&1
taskset -c 8-11 make -f "$A/Makefile" micro > "$A/micro.log" 2>&1
