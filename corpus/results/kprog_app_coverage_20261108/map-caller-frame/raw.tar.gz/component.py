from pathlib import Path
import json,sys,traceback
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');sys.path.insert(0,str(R/'kprog/x86'))
from trusted_specializer import specialize
try:
 result=specialize((G/'input.native.o').read_bytes(),'tail_ipv4_policy',json.loads((G/'metadata.json').read_text()),G/'generated',R/'kprog/x86/native_lab/native_link/target/release/native-link');j=dict(stage='compiled',artifacts=result)
except Exception as e:j=dict(stage='generation_or_compile_failure',error=str(e),traceback=traceback.format_exc())
(G/'component.json').write_text(json.dumps(j,indent=2)+'\n');print(j['stage'],flush=True)
