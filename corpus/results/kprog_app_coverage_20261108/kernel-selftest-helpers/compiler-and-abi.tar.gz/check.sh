set -eu
N=/workspaces/.agent-state/kprog-lanes/C/design-only/helper-selftests
trap 'echo $? > "$N/check.exit"' EXIT
PATH=/root/.elan/bin:$PATH taskset -c 8-11 make -f "$N/Makefile" check lean > "$N/check.log" 2>&1
