from pathlib import Path
import json,subprocess,hashlib,shutil
N=Path(__file__).parent;R=Path('/workspaces/repository');linker=R/'kprog/x86/native_lab/native_link/target/release/native-link';O=N/'upstream';O.mkdir(exist_ok=True)
rows=[]
for group,names in [('verifier_const',[f'tcx{i}'for i in range(1,8)]),('verifier_mtu',['tc_uninit_mtu'])]:
 source=R/'kprog/selftests/build'/(group+'.native.o');captured=O/(group+'.native.o');shutil.copy2(source,captured)
 for entry in names:
  obj=O/(group+'__'+entry+'.proof.o');command=[str(linker),'--input',str(captured),'--symbol',entry,'--mode','proof','--preserve-entry-abi','--output',str(obj)]
  done=subprocess.run(command,text=True,capture_output=True,cwd=R)
  (O/(entry+'.stdout')).write_text(done.stdout);(O/(entry+'.stderr')).write_text(done.stderr)
  row=dict(entry=entry,command=command,returncode=done.returncode,native_sha256=hashlib.sha256(captured.read_bytes()).hexdigest())
  if obj.exists():
   row['proof_sha256']=hashlib.sha256(obj.read_bytes()).hexdigest()
   q=subprocess.run(['readelf','--wide','--relocs',str(obj)],text=True,capture_output=True);(O/(entry+'.relocations')).write_text(q.stdout+q.stderr)
  rows.append(row);print(entry,done.returncode,done.stderr[-160:].strip(),flush=True)
result=dict(linker=str(linker),linker_sha256=hashlib.sha256(linker.read_bytes()).hexdigest(),generated=sum(r['returncode']==0 for r in rows),total=len(rows),programs=rows)
(N/'upstream.json').write_text(json.dumps(result,indent=2)+'\n')
raise SystemExit(int(any(r['returncode']for r in rows)))
