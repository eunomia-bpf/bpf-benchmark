#include <linux/bpf.h>
#include <initializer_list>
#include <cstdint>
#include <cstdio>
#include <cstring>
struct SupportedHelper {
    int id;
    const char *symbol;
};
constexpr SupportedHelper kSupportedHelpers[] = {
    {BPF_FUNC_probe_read, "bpf_probe_read_compat"},
    {BPF_FUNC_probe_read_str, "bpf_probe_read_compat_str"},
    {BPF_FUNC_trace_printk, "bpf_trace_printk"},
    {BPF_FUNC_ktime_get_ns, "bpf_ktime_get_ns"},
    {BPF_FUNC_ktime_get_boot_ns, "bpf_ktime_get_boot_ns"},
    {BPF_FUNC_get_current_pid_tgid, "bpf_get_current_pid_tgid"},
    {BPF_FUNC_get_current_uid_gid, "bpf_get_current_uid_gid"},
    {BPF_FUNC_get_smp_processor_id, "bpf_get_smp_processor_id"},
    {BPF_FUNC_get_prandom_u32, "bpf_get_prandom_u32"},
    {BPF_FUNC_probe_read_kernel, "bpf_probe_read_kernel"},
    {BPF_FUNC_probe_read_user, "bpf_probe_read_user"},
    {BPF_FUNC_probe_write_user, "bpf_probe_write_user"},
    {BPF_FUNC_probe_read_kernel_str, "bpf_probe_read_kernel_str"},
    {BPF_FUNC_probe_read_user_str, "bpf_probe_read_user_str"},
    {BPF_FUNC_map_lookup_elem, "bpf_map_lookup_elem"},
    {BPF_FUNC_map_update_elem, "bpf_map_update_elem"},
    {BPF_FUNC_map_delete_elem, "bpf_map_delete_elem"},
    {BPF_FUNC_get_current_comm, "bpf_get_current_comm"},
    {BPF_FUNC_get_current_cgroup_id, "bpf_get_current_cgroup_id"},
    {BPF_FUNC_current_task_under_cgroup, "bpf_current_task_under_cgroup"},
    {BPF_FUNC_get_stackid, "bpf_get_stackid"},
    {BPF_FUNC_get_stack, "bpf_get_stack"},
    {BPF_FUNC_get_current_task, "bpf_get_current_task"},
    {BPF_FUNC_perf_event_output, "bpf_perf_event_output"},
    {BPF_FUNC_ringbuf_output, "bpf_ringbuf_output"},
    {BPF_FUNC_ringbuf_reserve, "bpf_ringbuf_reserve"},
    {BPF_FUNC_ringbuf_submit, "bpf_ringbuf_submit"},
    {BPF_FUNC_ringbuf_discard, "bpf_ringbuf_discard"},
    {BPF_FUNC_ringbuf_query, "bpf_ringbuf_query"},
    {BPF_FUNC_xdp_adjust_meta, "bpf_xdp_adjust_meta"},
    {BPF_FUNC_xdp_adjust_head, "bpf_xdp_adjust_head"},
    {BPF_FUNC_xdp_adjust_tail, "bpf_xdp_adjust_tail"},
    {BPF_FUNC_xdp_get_buff_len, "bpf_xdp_get_buff_len"},
    {BPF_FUNC_xdp_load_bytes, "bpf_xdp_load_bytes"},
    {BPF_FUNC_xdp_store_bytes, "bpf_xdp_store_bytes"},
    {BPF_FUNC_skb_store_bytes, "bpf_skb_store_bytes"},
    {BPF_FUNC_l3_csum_replace, "bpf_l3_csum_replace"},
    {BPF_FUNC_l4_csum_replace, "bpf_l4_csum_replace"},
    {BPF_FUNC_clone_redirect, "bpf_clone_redirect"},
    {BPF_FUNC_get_cgroup_classid, "bpf_get_cgroup_classid"},
    {BPF_FUNC_skb_vlan_push, "bpf_skb_vlan_push"},
    {BPF_FUNC_skb_vlan_pop, "bpf_skb_vlan_pop"},
    {BPF_FUNC_skb_get_tunnel_key, "bpf_skb_get_tunnel_key"},
    {BPF_FUNC_skb_set_tunnel_key, "bpf_skb_set_tunnel_key"},
    {BPF_FUNC_redirect, "bpf_redirect"},
    {BPF_FUNC_get_route_realm, "bpf_get_route_realm"},
    {BPF_FUNC_skb_load_bytes, "bpf_skb_load_bytes"},
    {BPF_FUNC_skb_load_bytes_relative, "bpf_skb_load_bytes_relative"},
    {BPF_FUNC_csum_diff, "bpf_csum_diff"},
    {BPF_FUNC_skb_get_tunnel_opt, "bpf_skb_get_tunnel_opt"},
    {BPF_FUNC_skb_set_tunnel_opt, "bpf_skb_set_tunnel_opt"},
    {BPF_FUNC_skb_change_proto, "bpf_skb_change_proto"},
    {BPF_FUNC_skb_change_type, "bpf_skb_change_type"},
    {BPF_FUNC_skb_under_cgroup, "bpf_skb_under_cgroup"},
    {BPF_FUNC_get_hash_recalc, "bpf_get_hash_recalc"},
    {BPF_FUNC_skb_change_tail, "bpf_skb_change_tail"},
    {BPF_FUNC_skb_pull_data, "bpf_skb_pull_data"},
    {BPF_FUNC_csum_update, "bpf_csum_update"},
    {BPF_FUNC_set_hash_invalid, "bpf_set_hash_invalid"},
    {BPF_FUNC_skb_adjust_room, "bpf_skb_adjust_room"},
    {BPF_FUNC_get_numa_node_id, "bpf_get_numa_node_id"},
    {BPF_FUNC_skb_change_head, "bpf_skb_change_head"},
    {BPF_FUNC_get_socket_cookie, "bpf_get_socket_cookie"},
    {BPF_FUNC_get_socket_uid, "bpf_get_socket_uid"},
    {BPF_FUNC_sk_lookup_udp, "bpf_sk_lookup_udp"},
    {BPF_FUNC_sk_release, "bpf_sk_release"},
    {BPF_FUNC_map_push_elem, "bpf_map_push_elem"},
    {BPF_FUNC_map_pop_elem, "bpf_map_pop_elem"},
    {BPF_FUNC_sk_fullsock, "bpf_sk_fullsock"},
    {BPF_FUNC_override_return, "bpf_override_return"},
    {BPF_FUNC_strtol, "bpf_strtol"},
    {BPF_FUNC_check_mtu, "bpf_check_mtu"},
    {BPF_FUNC_send_signal, "bpf_send_signal"},
    {BPF_FUNC_seq_write, "bpf_seq_write"},
    {BPF_FUNC_copy_from_user, "bpf_copy_from_user"},
    {BPF_FUNC_jiffies64, "bpf_jiffies64"},
    {BPF_FUNC_ktime_get_coarse_ns, "bpf_ktime_get_coarse_ns"},
    {BPF_FUNC_sk_assign, "bpf_sk_assign"},
    {BPF_FUNC_get_current_task_btf, "bpf_get_current_task_btf"},
    {BPF_FUNC_ima_inode_hash, "bpf_ima_inode_hash"},
    {BPF_FUNC_get_func_ip, "bpf_get_func_ip"},
    {BPF_FUNC_get_attach_cookie, "bpf_get_attach_cookie"},
    {BPF_FUNC_task_pt_regs, "bpf_task_pt_regs"},
    {BPF_FUNC_loop, "bpf_loop"},
    {BPF_FUNC_get_func_arg, "bpf_get_func_arg"},
    {BPF_FUNC_get_func_ret, "bpf_get_func_ret"},
    {BPF_FUNC_get_func_arg_cnt, "bpf_get_func_arg_cnt"},
    {BPF_FUNC_ima_file_hash, "bpf_ima_file_hash"},
    {BPF_FUNC_set_hash, "bpf_set_hash"},
    {BPF_FUNC_redirect_neigh, "bpf_redirect_neigh"},
    {BPF_FUNC_redirect_peer, "bpf_redirect_peer"},
};
constexpr const char *kTypedHelperSymbols[] = {
    "bpf_user_rnd_u32",
    "bpf_perf_event_output_tp",
    "bpf_perf_event_output_raw_tp",
    "bpf_get_stackid_tp",
    "bpf_get_stackid_pe",
    "bpf_get_stackid_raw_tp",
    "bpf_get_stack_tp",
    "bpf_get_stack_pe",
    "bpf_get_stack_raw_tp",
    "bpf_xdp_fib_lookup",
    "bpf_skb_fib_lookup",
    "bpf_skb_check_mtu",
    "bpf_xdp_check_mtu",
    "bpf_xdp_redirect_map",
    "bpf_tc_skc_lookup_tcp",
    "bpf_xdp_skc_lookup_tcp",
    "bpf_skc_lookup_tcp",
    "bpf_tc_sk_lookup_udp",
    "bpf_xdp_sk_lookup_udp",
    "bpf_sock_addr_sk_lookup_udp",
    "bpf_sk_lookup_udp",
    "bpf_get_func_ip_tracing",
    "bpf_get_func_ip_kprobe",
    "bpf_get_func_ip_kprobe_multi",
    "bpf_get_func_ip_uprobe_multi",
};
struct HelperAlias {
    int id;
    const char *link_name;
    const char *kernel_symbol;
};
const char *helper_symbol_for_id(int helper_id)
{
    for (const auto &helper : kSupportedHelpers) {
        if (helper.id == helper_id) {
            return helper.symbol;
        }
    }
    return nullptr;
}
HelperAlias helper_alias_for_call(int helper_id, uint32_t prog_type, uint32_t expected_attach_type)
{
    if (helper_id == BPF_FUNC_get_func_ip) {
        const char *symbol = "bpf_get_func_ip_tracing";
        if (prog_type == BPF_PROG_TYPE_KPROBE) {
            if (expected_attach_type == BPF_TRACE_KPROBE_MULTI ||
                expected_attach_type == BPF_TRACE_KPROBE_SESSION)
                symbol = "bpf_get_func_ip_kprobe_multi";
            else if (expected_attach_type == BPF_TRACE_UPROBE_MULTI ||
                expected_attach_type == BPF_TRACE_UPROBE_SESSION)
                symbol = "bpf_get_func_ip_uprobe_multi";
            else symbol = "bpf_get_func_ip_kprobe";
        }
        return HelperAlias{helper_id, "bpf_get_func_ip", symbol};
    }
    if (helper_id == BPF_FUNC_perf_event_output) {
        if (prog_type == BPF_PROG_TYPE_TRACEPOINT ||
            prog_type == BPF_PROG_TYPE_PERF_EVENT) {
            return HelperAlias{helper_id, "bpf_perf_event_output",
                               "bpf_perf_event_output_tp"};
        }
        if (prog_type == BPF_PROG_TYPE_RAW_TRACEPOINT ||
            prog_type == BPF_PROG_TYPE_RAW_TRACEPOINT_WRITABLE ||
            prog_type == BPF_PROG_TYPE_TRACING) {
            return HelperAlias{helper_id, "bpf_perf_event_output",
                               "bpf_perf_event_output_raw_tp"};
        }
        return HelperAlias{helper_id, "bpf_perf_event_output",
                           "bpf_perf_event_output"};
    }
    if (helper_id == BPF_FUNC_get_stackid) {
        if (prog_type == BPF_PROG_TYPE_TRACEPOINT) {
            return HelperAlias{helper_id, "bpf_get_stackid",
                               "bpf_get_stackid_tp"};
        }
        if (prog_type == BPF_PROG_TYPE_PERF_EVENT) {
            return HelperAlias{helper_id, "bpf_get_stackid",
                               "bpf_get_stackid_pe"};
        }
        if (prog_type == BPF_PROG_TYPE_RAW_TRACEPOINT ||
            prog_type == BPF_PROG_TYPE_RAW_TRACEPOINT_WRITABLE ||
            prog_type == BPF_PROG_TYPE_TRACING) {
            return HelperAlias{helper_id, "bpf_get_stackid",
                               "bpf_get_stackid_raw_tp"};
        }
        return HelperAlias{helper_id, "bpf_get_stackid", "bpf_get_stackid"};
    }
    if (helper_id == BPF_FUNC_get_stack) {
        if (prog_type == BPF_PROG_TYPE_TRACEPOINT) {
            return HelperAlias{helper_id, "bpf_get_stack", "bpf_get_stack_tp"};
        }
        if (prog_type == BPF_PROG_TYPE_PERF_EVENT) {
            return HelperAlias{helper_id, "bpf_get_stack", "bpf_get_stack_pe"};
        }
        if (prog_type == BPF_PROG_TYPE_RAW_TRACEPOINT ||
            prog_type == BPF_PROG_TYPE_RAW_TRACEPOINT_WRITABLE ||
            prog_type == BPF_PROG_TYPE_TRACING) {
            return HelperAlias{helper_id, "bpf_get_stack",
                               "bpf_get_stack_raw_tp"};
        }
        return HelperAlias{helper_id, "bpf_get_stack", "bpf_get_stack"};
    }
    if (helper_id == BPF_FUNC_get_prandom_u32) {
        return HelperAlias{helper_id, "bpf_get_prandom_u32", "bpf_user_rnd_u32"};
    }
    if (helper_id == BPF_FUNC_fib_lookup) {
        if (prog_type == BPF_PROG_TYPE_XDP) {
            return HelperAlias{helper_id, "bpf_fib_lookup", "bpf_xdp_fib_lookup"};
        }
        if (prog_type == BPF_PROG_TYPE_SCHED_CLS ||
            prog_type == BPF_PROG_TYPE_SCHED_ACT) {
            return HelperAlias{helper_id, "bpf_fib_lookup", "bpf_skb_fib_lookup"};
        }
        return HelperAlias{helper_id, "bpf_fib_lookup", nullptr};
    }
    if (helper_id == BPF_FUNC_check_mtu) {
        return HelperAlias{helper_id, "bpf_check_mtu",
                           prog_type == BPF_PROG_TYPE_XDP
                               ? "bpf_xdp_check_mtu" : "bpf_skb_check_mtu"};
    }
    if (helper_id == BPF_FUNC_redirect_map) {
        if (prog_type == BPF_PROG_TYPE_XDP) {
            return HelperAlias{helper_id, "bpf_redirect_map", "bpf_xdp_redirect_map"};
        }
        return HelperAlias{helper_id, "bpf_redirect_map", nullptr};
    }
    if (helper_id == BPF_FUNC_skc_lookup_tcp) {
        if (prog_type == BPF_PROG_TYPE_XDP) {
            return HelperAlias{helper_id, "bpf_skc_lookup_tcp", "bpf_xdp_skc_lookup_tcp"};
        }
        if (prog_type == BPF_PROG_TYPE_SCHED_CLS ||
            prog_type == BPF_PROG_TYPE_SCHED_ACT) {
            return HelperAlias{helper_id, "bpf_skc_lookup_tcp", "bpf_tc_skc_lookup_tcp"};
        }
        return HelperAlias{helper_id, "bpf_skc_lookup_tcp", "bpf_skc_lookup_tcp"};
    }
    if (helper_id == BPF_FUNC_sk_lookup_udp) {
        if (prog_type == BPF_PROG_TYPE_XDP) {
            return HelperAlias{helper_id, "bpf_sk_lookup_udp", "bpf_xdp_sk_lookup_udp"};
        }
        if (prog_type == BPF_PROG_TYPE_SCHED_CLS ||
            prog_type == BPF_PROG_TYPE_SCHED_ACT) {
            return HelperAlias{helper_id, "bpf_sk_lookup_udp", "bpf_tc_sk_lookup_udp"};
        }
        if (prog_type == BPF_PROG_TYPE_CGROUP_SOCK_ADDR) {
            return HelperAlias{helper_id, "bpf_sk_lookup_udp", "bpf_sock_addr_sk_lookup_udp"};
        }
        return HelperAlias{helper_id, "bpf_sk_lookup_udp", "bpf_sk_lookup_udp"};
    }
    const char *symbol = helper_symbol_for_id(helper_id);
    return HelperAlias{helper_id, symbol, symbol};
}
int main() {
 unsigned cases=0;
 for (unsigned type : {3U,4U,6U}) {
  auto a=helper_alias_for_call(105,type,0);
  if(a.id!=105 || std::strcmp(a.link_name,"bpf_strtol") || std::strcmp(a.kernel_symbol,"bpf_strtol")) return 1;
  ++cases;
  a=helper_alias_for_call(163,type,0);
  const char *expected=type==6?"bpf_xdp_check_mtu":"bpf_skb_check_mtu";
  if(a.id!=163 || std::strcmp(a.link_name,"bpf_check_mtu") || std::strcmp(a.kernel_symbol,expected)) return 2;
  ++cases;
 }
 for(const char *wanted : {"bpf_xdp_check_mtu","bpf_skb_check_mtu"}) {
  bool found=false;for(const char *name:kTypedHelperSymbols) found|=!std::strcmp(name,wanted);
  if(!found)return 3;++cases;
 }
 std::printf("helper kernel target aliases: %u cases, 0 differences\n",cases);return 0;
}
