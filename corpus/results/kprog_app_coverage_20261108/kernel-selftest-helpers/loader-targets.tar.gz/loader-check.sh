set -eu
N=/workspaces/.agent-state/kprog-lanes/C/design-only/helper-selftests
trap 'echo $? > "$N/loader-check.exit"' EXIT
taskset -c 8-11 make -f "$N/Makefile" loader-alias > "$N/loader-alias.log" 2>&1
taskset -c 8-11 make -f "$N/Makefile" loader-build > "$N/loader-build.log" 2>&1
