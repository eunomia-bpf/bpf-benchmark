from pathlib import Path
import json,select,os,subprocess,sys,tarfile,datetime,traceback
G=Path(__file__).resolve().parent;C=G.parent.parent.parent;R=Path('/workspaces/repository');Q=C/'design-only/tetragon-paired-source';O=R/'corpus/results/kprog_app_coverage_20261108/otel-counted-native-loop/compiler-o2'
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(phase=phase,**kw),indent=2)+'\n')
try:
 save('queued_after_tetragon_host_build')
 try:
  fd=os.pidfd_open(int((Q/'controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 save('compiling')
 with(G/'run.log').open('w')as f:p=subprocess.run(['taskset','-c','8-11','unshare','--mount','--propagation','private','python3',str(G/'mount.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'run.exit').write_text(str(p.returncode)+'\n');O.mkdir(parents=True,exist_ok=True);j=dict(make_exit=p.returncode,original_whole_application='f162c3111c5653df5776aeba1b268dfb56200259',original_B_compiled=True,original_stock_frontier='invalid write to stack R10 off=-528 size=8',command=json.loads((G/'command.json').read_text()),native_executions=0,service_compiler_policy='captured original O3 retained');(O/'summary.json').write_text(json.dumps(j,indent=2)+'\n');(O/'README.md').write_text('# OTel captured B compilation at O2\n\nThe identical generated C from whole paired-source OTel f162c3111 compiles with O2 as a generic simulator compiler-policy candidate. Source/entry/native P/metadata stay captured; the original O3 object reaches stock-verifier stackoff528/8. Actual compile Makeexit'+str(p.returncode)+'. Complete old/new compiler commands, source dependencies, warnings, B and disassembly accompany raw.tar.gz. This host compilation records its artifact outcome; stock-verifier acceptance follows a source-captured guest. Current service compiler policy retains O3. Native executions0; runtime admission additions0.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as tf:
  for p in G.iterdir():
   if p.name not in {'controller.log','status.json'}:tf.add(p,arcname=p.name)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Record captured OTel simulator compilation with O2',G/'publication.json');save('finished',commit=commit,**j)
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR A/V/R '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+commit+' OTel identical captured B/O2 compiler artifact, Makeexit'+str(p.returncode)+'. Original O3 whole-app f162c3111 frontier stackoff528/8; generic compiler-policy evaluation retains every native/source/metadata byte and current productionO3. Stock acceptance follows actual guest; runtime admission additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
