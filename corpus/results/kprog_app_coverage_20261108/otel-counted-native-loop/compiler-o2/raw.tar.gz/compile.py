from pathlib import Path
import json,subprocess
G=Path(__file__).resolve().parent
with(G/'clang.stdout').open('w')as out,(G/'clang.stderr').open('w')as err:p=subprocess.run(json.loads((G/'command.json').read_text()),stdout=out,stderr=err)
(G/'clang.exit').write_text(str(p.returncode)+'\n')
if p.returncode==0:
 with(G/'o2.disasm').open('w')as f:subprocess.run(['/usr/bin/llvm-objdump-18','-d',str(G/'o2.bpf.o')],stdout=f,stderr=subprocess.STDOUT,check=True)
raise SystemExit(p.returncode)
