set -eu
cd /workspaces/repository
mount --bind /workspaces/.agent-state/kprog-lanes/C/design-only/otel-counted-native-loop/native_stack_trace.edited.c /workspaces/repository/vendor/repos/opentelemetry-ebpf-profiler/support/ebpf/native_stack_trace.ebpf.c
make -f /workspaces/.agent-state/kprog-lanes/C/design-only/otel-counted-native-loop/Makefile native baseline collector
