from pathlib import Path
from datetime import datetime,timezone
import sys,subprocess,json,os,select,hashlib,tarfile
H=Path(__file__).parent;C=H.parent.parent;R=Path('/workspaces/repository')
try:
 fd=os.pidfd_open(int((H/'adopt.pid').read_text()));select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
adoption=json.loads((H/'publication.json').read_text())
pins={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [R/'kprog/x86/x86_sim_local_bpf.h',R/'kprog/tv/build-kernel-x86/arch/x86/boot/bzImage',R/'kprog/tv/build-x86/corpus-modules/bpf_x86_native_lab.ko',R/'kprog/libnativeloader/build/trusted-native-loader']}
(H/'safety-inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
with(H/'safety.log').open('w')as log:q=subprocess.run(['make','-f',str(H/'Makefile'),'safety'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(H/'safety.exit').write_text(str(q.returncode)+'\n')
rows=json.loads((H/'safety/outcomes.json').read_text());stages={k:sum(row['stage']==k for row in rows)for k in sorted(set(row['stage']for row in rows))};result=dict(utc=datetime.now(timezone.utc).isoformat(),source_adoption=adoption['commit'],exit=q.returncode,stages=stages,cases=len(rows),inputs=pins,records=rows)
O=R/'corpus/results/kprog_app_coverage_20261108/undefined-flags/safety';O.mkdir(parents=True,exist_ok=True);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
(O/'README.md').write_text('# Existing native38 after ANDN/BZHI undefined flag source adoption\n\nThe existing38native objects, original resource maps and load-only negative producers retain their definitions. Canonical source'+adoption['commit']+' uses existing kind6 PF/AF outputs; this fresh shared kernel/module request cohort supplies its actual runtime evidence separately from the host and compiler components.\n\nActual stages: '+json.dumps(stages)+'. Native risk executions0; positive controls retain the existing TEST_RUN expected-result comparison. Actual exits/source/runtime/worker hashes and every row are in [summary.json](summary.json); original cases, complete P/B/compiler/verifier/request outputs and commands remain in [raw.tar.gz](raw.tar.gz). Earlier unsupported/unbounded generation outcomes retain their coverage classification. Runtime admission additions0.\n\n```sh\nmake -f /workspaces/.agent-state/kprog-lanes/C/design-only/undefined-flags/Makefile safety\n```\n')
with tarfile.open(O/'raw.tar.gz','w:gz')as t:
 for name in ['safety','safety.py','safety-queue.py','safety.log','safety.exit','safety-inputs.json','Makefile']:t.add(H/name,arcname=name)
 t.add(R/'kprog/x86/x86_sim_local_bpf.h',arcname='source/x86_sim_local_bpf.h')
 for p in (C/'design-only/safety/build').iterdir():
  if p.name.endswith(('.native.o','.bpf.o')):t.add(p,arcname='original-inputs/'+p.name)
parent=O.parent/'README.md';s=parent.read_text();s=s.replace('Makefile before host oracles micro','Makefile before\nmake -f /workspaces/.agent-state/kprog-lanes/C/design-only/undefined-flags/Makefile host oracles micro');parent.write_text(s)
sys.path.insert(0,str(C));from publish_owned import publish
commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()]+[str(parent.relative_to(R))],'Record existing native safety after undefined flag source adoption',H/'safety-publication.json');now=datetime.now(timezone.utc).isoformat();msg='\n- LOCAL C FOR V/A/R '+now+': PUSHED '+commit+' canonical PF/AF source'+adoption['commit']+' actualnative38 '+repr(stages)+'; shared Image/module/currentworker, original38P/resource maps retained. Actual risknativeexecutions0 and every P/B/verifier/entry hash archived. Host51200 and4oracles/30compiler receipts remain their distinct domains; generic DefinednessTransport/all other undefined-output interfaces stayV/C active. Admission additions0.\n';(C.parent/'COORDINATION.md').open('a').write(msg);(C/'last.md').open('a').write(msg)
p=C/'current.json';j=json.loads(p.read_text());j['updated']=now;j['active']['undefined-flags'].update(safety_publication=commit,safety_stages=stages,safety_exit=q.returncode);j['next']='Read undefined-flags actual source adoption and native38 receipts; continue priority2a originalkernel C/native ABI findings with A owning transferredBPF34. Next whole-app runs use current pairedruntime and explicit model epoch. Other undefined-output classes and 32780-byte compiler expansion retain their existing scope.';p.write_text(json.dumps(j,indent=2)+'\n');print(commit,stages,flush=True)
