from pathlib import Path
from datetime import datetime,timezone
import subprocess,sys,json,os,select,hashlib,tarfile,shutil,traceback
G=Path(__file__).resolve().parent;C=G.parent.parent.parent;R=Path('/workspaces/repository');Q=C/'design-only/kernel-selftests-direct';O=R/'corpus/results/kprog_app_coverage_20261108/undefined-flags/four-apps'
def notice(s):
 msg='\n- LOCAL C FOR R/A/V '+datetime.now(timezone.utc).isoformat()+': '+s+'\n'
 for p in [C.parent/'COORDINATION.md',C/'last.md']:
  with p.open('a')as f:f.write(msg)
try:
 try:
  fd=os.pidfd_open(int((Q/'resource-controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 image=subprocess.check_output(['docker','image','inspect','--format','{{.Id}}','bpf-benchmark/kprog-five-step-tracee:c-runner'],text=True).strip();files=[p for p in (G/'source').rglob('*')if p.is_file()]+[G/'clang',G/'guest.py',G/'Makefile',R/'kprog/tv/build-kernel-x86/arch/x86/boot/bzImage',R/'kprog/tv/build-x86/corpus-modules/bpf_x86_native_lab.ko'];inputs=dict(utc=datetime.now(timezone.utc).isoformat(),adopted_source='c1f6b78f4a26c3075d85c50dd3e3d62a16e713bf',image=image,files={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in files});(G/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
 command=['make','-f',str(G/'Makefile'),'corpus','STATE='+str(G),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS=otelcol-ebpf-profiler,cilium,tetragon/observer,tracee','SAMPLES=1','WORKLOAD_DURATION=2'];(G/'command.json').write_text(json.dumps(command,indent=2)+'\n');(G/'status.json').write_text(json.dumps(dict(state='running',command=command),indent=2)+'\n');notice('Canonicalc1f6 remainingfouroriginal-app replay START20-23/12GiB after original239kernel table and typedmap metadata observation. OTel/Cilium/Tetragon/Tracee use captured common producer/dependencies/sharedextent Image/paireda507moduleimage and existing app/native/workload definitions. Every terminal request/work/stage is collected and privatelypublished; runtime admission additions0.')
 with(G/'run.log').open('w')as log:p=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT)
 (G/'run.exit').write_text(str(p.returncode)+'\n')
 with(G/'collect.log').open('w')as log:q=subprocess.run([sys.executable,str(G.parent/'collect.py'),G.name],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 (G/'collect.exit').write_text(str(q.returncode)+'\n');q.check_returncode();I=G.parent/'collected'/G.name;O.mkdir(parents=True,exist_ok=True)
 for path in I.iterdir():
  if path.is_file():shutil.copy2(path,O/path.name)
 j=json.loads((I/'coverage.json').read_text());work=[dict(application=x['application'],status=x['app']['status'],error=x['app'].get('error'),baseline=x['app'].get('baseline'),post_rejit=x['app'].get('post_rejit'))for x in j['results']];(O/'work.json').write_text(json.dumps(work,indent=2)+'\n');result=dict(utc=datetime.now(timezone.utc).isoformat(),make_exit=p.returncode,native_requests=j['native_requests'],generated=j['generated'],compiled=j['compiled'],installed=j['installed'],failed=j['failed'],work=[dict(application=x['application'],status=x['status'],error=x['error'])for x in work],inputs=inputs);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
 (O/'README.md').write_text('# Original OTel, Cilium, Tetragon and Tracee with canonical undefined flag outputs\n\nThe complete original four-app cohort runs after the current native239kernel annotation catalog and the existing resource-metadata observation. Captured canonical ANDN/BZHI PF/AF sourcec1f6 uses the existing kind6 output. The paired sharedextent Image/ordinary/native modules, upstream applications/native P, producer/dependencies and original two-second workload retain their recorded definitions. Actual Makeexit'+str(p.returncode)+'; G/C/I/failed'+repr((j['generated'],j['compiled'],j['installed'],j['failed']))+'; work'+repr(result['work'])+'.\n\nCoverage rows and verifier/compiler/generation stages are in [coverage.json](coverage.json); [work.json](work.json) retains both phases and their raw counters. Complete source/compiler/runtime/native/B/service records accompany this cohort. BCC25/25 and Katran1/1 current-source receipts remain in the adjacent bcc-katran report. Runtime admission additions0.\n')
 with tarfile.open(O/'runtime.tar.gz','w:gz')as tf:
  for name in ['Makefile','guest.py','clang','source','inputs.json','command.json','controller.py','run.log','run.exit','collect.log','collect.exit','summary.json']:tf.add(G/name,arcname=name)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Record four original applications with canonical undefined flag outputs',G/'publication.json');(G/'status.json').write_text(json.dumps(dict(state='finished',publication=commit,result=result),indent=2)+'\n');notice('PUSHED '+commit+' canonicalc1f6 wholefourapp terminal G/C/I/failed'+repr((j['generated'],j['compiled'],j['installed'],j['failed']))+'; actualwork'+repr(result['work'])+'. Originalnative P/source/header/producer/module/worker identities and full raw outcomes retained. Runtime admission additions0.')
except BaseException as e:(G/'status.json').write_text(json.dumps(dict(state='requires_continuation',error=str(e),traceback=traceback.format_exc()),indent=2)+'\n');raise
