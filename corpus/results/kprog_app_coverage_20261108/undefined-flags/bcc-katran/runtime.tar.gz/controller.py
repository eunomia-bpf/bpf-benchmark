from pathlib import Path
from datetime import datetime,timezone
import subprocess,sys,json,os,select,hashlib
G=Path(__file__).parent;C=G.parent.parent.parent;H=C/'design-only/undefined-flags';R=Path('/workspaces/repository')
try:
 fd=os.pidfd_open(int((H/'safety-controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
adoption=json.loads((H/'publication.json').read_text());image=subprocess.check_output(['docker','image','inspect','--format','{{.Id}}','bpf-benchmark/kprog-five-step-tracee:c-runner'],text=True).strip()
files=[p for p in (G/'source').rglob('*')if p.is_file()]+[G/'clang',G/'guest.py',G/'Makefile',R/'kprog/tv/build-kernel-x86/arch/x86/boot/bzImage',R/'kprog/tv/build-x86/corpus-modules/bpf_x86_native_lab.ko']
inputs=dict(utc=datetime.now(timezone.utc).isoformat(),adopted_source=adoption['commit'],image=image,files={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in files});(G/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
command=['make','-f',str(G/'Makefile'),'corpus','STATE='+str(G),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS=bcc/set,katran','SAMPLES=1','WORKLOAD_DURATION=2']
with(G/'run.log').open('w')as log:q=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT)
(G/'run.exit').write_text(str(q.returncode)+'\n')
with(G/'collect.log').open('w')as log:q=subprocess.run([sys.executable,str(G.parent/'collect.py'),G.name],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(G/'collect.exit').write_text(str(q.returncode)+'\n');q.check_returncode()
with(G/'publish.log').open('w')as log:q=subprocess.run([sys.executable,str(G/'publish.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(G/'publish.exit').write_text(str(q.returncode)+'\n');q.check_returncode()
