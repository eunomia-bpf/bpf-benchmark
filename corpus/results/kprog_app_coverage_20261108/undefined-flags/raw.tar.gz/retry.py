from pathlib import Path
import subprocess,json
H=Path(__file__).parent;results={s:int((H/(s+'.exit')).read_text())for s in ['before','host']}
for target in ['oracles','micro']:
 with(H/(target+'.log')).open('w')as log:q=subprocess.run(['taskset','-c','20-23','make','-f',str(H/'Makefile'),target],cwd='/workspaces/repository',stdout=log,stderr=subprocess.STDOUT)
 results[target]=q.returncode;(H/(target+'.exit')).write_text(str(q.returncode)+'\n');(H/'exits.json').write_text(json.dumps(results,indent=2)+'\n')
