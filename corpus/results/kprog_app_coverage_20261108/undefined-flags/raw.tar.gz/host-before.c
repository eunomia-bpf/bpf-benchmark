#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 64U
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>
static unsigned choice_bits,choice_index;
static unsigned long choice(void){return (choice_bits>>(choice_index++&1))&1;}
#undef X86_SIM_L_UNSPECIFIED
#define X86_SIM_L_UNSPECIFIED() choice()
static unsigned long cases;
static int check(unsigned form,unsigned width,unsigned bits,unsigned incoming,__u64 a,__u64 b){
 X86_SIM_L_DECLARE_STATE();X86_SIM_L_DECLARE_STACK();__u8 __x86_sim_abi_kind=0;
 __u64 memory=form==1?b:a,original=memory;
 X86_SIM_L_WRITE_REG_WIDTH(X86_RAX,a,8);X86_SIM_L_WRITE_REG_WIDTH(X86_RCX,b,8);
 X86_SIM_L_WRITE_REG_PTR_TAG(X86_RBX,&memory,X86_SIM_TAG_SCALAR);
 __u64 regs[16];__u8 tags[16];for(unsigned r=0;r<16;r++){regs[r]=X86_SIM_L_READ_REG(r);tags[r]=X86_SIM_L_REG_TAG(r);}
 __x86_cf=incoming&1;__x86_zf=(incoming>>1)&1;__x86_sf=(incoming>>2)&1;__x86_of=(incoming>>3)&1;
 __x86_pf=(bits&1)^1;__x86_af=((bits>>1)&1)^1;choice_bits=bits;choice_index=0;
 if(form==0)X86_SIM_L_EXEC_ANDN(X86_R9,X86_RAX,X86_RCX,width);
 else if(form==1)X86_SIM_L_EXEC_ANDN_MEM(X86_R9,X86_RAX,width,X86_MEM_AUX_FULL(X86_REG_NONE,0,width)|X86_MEM_AUX_ALU_OP(X86_RBX),0);
 else if(form==2)X86_SIM_L_EXEC_BZHI(X86_R9,X86_RAX,X86_RCX,width);
 else X86_SIM_L_EXEC_BZHI_MEM(X86_R9,X86_RBX,width,X86_MEM_AUX_FULL(X86_REG_NONE,0,width)|X86_REG_AUX_SRC_SHIFT(X86_RCX),0);
 unsigned n=width*8,count=b&255;__u64 mask=width==4?0xffffffffULL:~0ULL;
 __u64 expected=form<2?((~a)&b):count>=n?a:count?(a&((1ULL<<count)-1)):0;expected&=mask;
 unsigned cf=form<2?0:count>=n;
 if(choice_index!=2||__x86_pf!=(bits&1)||__x86_af!=((bits>>1)&1)||__x86_cf!=cf||__x86_zf!=(expected==0)||__x86_sf!=((expected>>(n-1))&1)||__x86_of||X86_SIM_L_EVAL_CC(10)!=(bits&1)||X86_SIM_L_EVAL_CC(11)!=((bits&1)^1)){
  fprintf(stderr,"flags form=%u width=%u choices=%u calls=%u PF=%u AF=%u\n",form,width,bits,choice_index,__x86_pf,__x86_af);return 1;}
 for(unsigned r=0;r<16;r++)if(X86_SIM_L_READ_REG(r)!=(r==X86_R9?expected:regs[r])||X86_SIM_L_REG_TAG(r)!=(r==X86_R9?X86_SIM_TAG_SCALAR:tags[r]))return 2;
 if(memory!=original)return 3;cases++;return 0;
}
int main(void){const __u64 values[]={0,1,31,32,63,64,255,0x80000000ULL,0x8000000000000000ULL,~0ULL};
 for(unsigned f=0;f<4;f++)for(unsigned w=4;w<=8;w+=4)for(unsigned b=0;b<4;b++)for(unsigned old=0;old<16;old++)for(unsigned i=0;i<10;i++)for(unsigned j=0;j<10;j++){int rc=check(f,w,b,old,values[i],values[j]);if(rc)return rc;}
 printf("ANDN/BZHI four forms independent PF/AF choices and defined flags/GPR/memory frames: %lu cases PASS\n",cases);return 0;}
