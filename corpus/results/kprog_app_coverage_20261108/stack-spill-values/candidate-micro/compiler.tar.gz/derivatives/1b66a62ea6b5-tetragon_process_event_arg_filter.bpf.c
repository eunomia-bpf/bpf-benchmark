#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13)
#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 112U
#include "/workspaces/.agent-state/kprog-lanes/C/design-only/stack-spill-values/source/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int tetragon_process_event_arg_filter_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    r8,QWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3:
	/* 0x3: mov    rcx,QWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7:
	/* 0x7: mov    rdx,r8 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R8, X86_WIDTH_64);
x86_l_a:
	/* 0xa: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_c:
	/* 0xc: cmp    rdx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_f:
	/* 0xf: jbe    16 <tetragon_process_event_arg_filter_xdp+0x16> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xf, 0x16, x86_l_16);
x86_l_11:
	/* 0x11: jmp    2e2 <tetragon_process_event_arg_filter_xdp+0x2e2> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_16:
	/* 0x16: lea    rsi,[rdx+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a:
	/* 0x1a: cmp    rsi,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_64);
x86_l_1d:
	/* 0x1d: ja     11 <tetragon_process_event_arg_filter_xdp+0x11> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1d, 0x11, x86_l_11);
x86_l_1f:
	/* 0x1f: lea    rsi,[rdx+0x410] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1040ULL);
x86_l_26:
	/* 0x26: cmp    rsi,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_64);
x86_l_29:
	/* 0x29: ja     11 <tetragon_process_event_arg_filter_xdp+0x11> */
	X86_SIM_X86_JCC(X86_CC_A, 0x29, 0x11, x86_l_11);
x86_l_2b:
	/* 0x2b: cmp    DWORD PTR [rdx+0x8],0x20 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738400ULL);
x86_l_2f:
	/* 0x2f: jne    11 <tetragon_process_event_arg_filter_xdp+0x11> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f, 0x11, x86_l_11);
x86_l_31:
	/* 0x31: cmp    DWORD PTR [rdx+0xc],0x20 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607584ULL);
x86_l_35:
	/* 0x35: jne    11 <tetragon_process_event_arg_filter_xdp+0x11> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x35, 0x11, x86_l_11);
x86_l_37:
	/* 0x37: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_38:
	/* 0x38: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3a:
	/* 0x3a: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3c:
	/* 0x3c: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3e:
	/* 0x3e: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_40:
	/* 0x40: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_41:
	/* 0x41: sub    rsp,0x40 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 64ULL);
x86_l_45:
	/* 0x45: mov    QWORD PTR [rsp+0x18],r8 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4a:
	/* 0x4a: add    rdx,0x2f */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 47ULL);
x86_l_4e:
	/* 0x4e: movabs r9,0xe7037ed1a0b428db */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_64, 16646288086500911323ULL);
x86_l_58:
	/* 0x58: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5a:
	/* 0x5a: jmp    7a <tetragon_process_event_arg_filter_xdp+0x7a> */
	X86_SIM_X86_JMP(0x5a, 0x7a, x86_l_7a);
x86_l_5c:
	/* 0x5c: shl    r10,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_64, X86_ALU_SHL, 32ULL);
x86_l_60:
	/* 0x60: mov    eax,r8d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R8, X86_WIDTH_32);
x86_l_63:
	/* 0x63: or     rax,r10 */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R10, X86_WIDTH_64, X86_ALU_OR);
x86_l_66:
	/* 0x66: xor    r9,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_RAX, X86_WIDTH_64, X86_ALU_XOR);
x86_l_69:
	/* 0x69: inc    rsi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_6c:
	/* 0x6c: add    rdx,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_70:
	/* 0x70: cmp    rsi,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_64, 32ULL);
x86_l_74:
	/* 0x74: je     2c2 <tetragon_process_event_arg_filter_xdp+0x2c2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x74, 0x2c2, x86_l_2c2);
x86_l_7a:
	/* 0x7a: movzx  r11d,BYTE PTR [rdx-0x13] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551597ULL);
x86_l_7f:
	/* 0x7f: movzx  r10d,BYTE PTR [rdx-0x12] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551598ULL);
x86_l_84:
	/* 0x84: shl    r10d,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_88:
	/* 0x88: or     r10,r11 */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R11, X86_WIDTH_64, X86_ALU_OR);
x86_l_8b:
	/* 0x8b: cmp    r10d,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 4ULL);
x86_l_8f:
	/* 0x8f: jg     a5 <tetragon_process_event_arg_filter_xdp+0xa5> */
	X86_SIM_X86_JCC(X86_CC_G, 0x8f, 0xa5, x86_l_a5);
x86_l_91:
	/* 0x91: cmp    r10d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 1ULL);
x86_l_95:
	/* 0x95: je     cf <tetragon_process_event_arg_filter_xdp+0xcf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x95, 0xcf, x86_l_cf);
x86_l_97:
	/* 0x97: cmp    r10d,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 2ULL);
x86_l_9b:
	/* 0x9b: jne    b9 <tetragon_process_event_arg_filter_xdp+0xb9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x9b, 0xb9, x86_l_b9);
x86_l_9d:
	/* 0x9d: mov    r14d,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 35ULL);
x86_l_a3:
	/* 0xa3: jmp    dd <tetragon_process_event_arg_filter_xdp+0xdd> */
	X86_SIM_X86_JMP(0xa3, 0xdd, x86_l_dd);
x86_l_a5:
	/* 0xa5: cmp    r10d,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 5ULL);
x86_l_a9:
	/* 0xa9: je     d7 <tetragon_process_event_arg_filter_xdp+0xd7> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa9, 0xd7, x86_l_d7);
x86_l_ab:
	/* 0xab: cmp    r10d,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 9ULL);
x86_l_af:
	/* 0xaf: jne    b9 <tetragon_process_event_arg_filter_xdp+0xb9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xaf, 0xb9, x86_l_b9);
x86_l_b1:
	/* 0xb1: mov    r14d,0x41 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 65ULL);
x86_l_b7:
	/* 0xb7: jmp    dd <tetragon_process_event_arg_filter_xdp+0xdd> */
	X86_SIM_X86_JMP(0xb7, 0xdd, x86_l_dd);
x86_l_b9:
	/* 0xb9: cmp    r10w,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_16, 13ULL);
x86_l_be:
	/* 0xbe: mov    r14d,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 0ULL);
x86_l_c4:
	/* 0xc4: mov    eax,0x59 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 89ULL);
x86_l_c9:
	/* 0xc9: cmove  r14d,eax */
	X86_SIM_L_EXEC_CMOV(X86_R14, X86_RAX, X86_WIDTH_32, X86_CC_E);
x86_l_cd:
	/* 0xcd: jmp    dd <tetragon_process_event_arg_filter_xdp+0xdd> */
	X86_SIM_X86_JMP(0xcd, 0xdd, x86_l_dd);
x86_l_cf:
	/* 0xcf: mov    r14d,0x11 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 17ULL);
x86_l_d5:
	/* 0xd5: jmp    dd <tetragon_process_event_arg_filter_xdp+0xdd> */
	X86_SIM_X86_JMP(0xd5, 0xdd, x86_l_dd);
x86_l_d7:
	/* 0xd7: mov    r14d,0x37 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 55ULL);
x86_l_dd:
	/* 0xdd: movzx  eax,WORD PTR [rdx-0x7] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 18446744073709551609ULL);
x86_l_e1:
	/* 0xe1: movzx  ecx,BYTE PTR [rdx-0x5] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551611ULL);
x86_l_e5:
	/* 0xe5: shl    ecx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_SHL, 16ULL);
x86_l_e8:
	/* 0xe8: or     rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR);
x86_l_eb:
	/* 0xeb: movzx  eax,BYTE PTR [rdx-0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551612ULL);
x86_l_ef:
	/* 0xef: shl    eax,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 24ULL);
x86_l_f2:
	/* 0xf2: or     rax,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_OR);
x86_l_f5:
	/* 0xf5: movzx  edi,BYTE PTR [rdx-0x3] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551613ULL);
x86_l_f9:
	/* 0xf9: shl    rdi,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_SHL, 32ULL);
x86_l_fd:
	/* 0xfd: movzx  ebp,BYTE PTR [rdx-0x2] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551614ULL);
x86_l_101:
	/* 0x101: shl    rbp,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_SHL, 40ULL);
x86_l_105:
	/* 0x105: or     rbp,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RDI, X86_WIDTH_64, X86_ALU_OR);
x86_l_108:
	/* 0x108: or     rbp,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RAX, X86_WIDTH_64, X86_ALU_OR);
x86_l_10b:
	/* 0x10b: cmp    rax,0x68736162 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 1752392034ULL);
x86_l_111:
	/* 0x111: je     121 <tetragon_process_event_arg_filter_xdp+0x121> */
	X86_SIM_X86_JCC(X86_CC_E, 0x111, 0x121, x86_l_121);
x86_l_113:
	/* 0x113: cmp    eax,0x6c727563 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 1819440483ULL);
x86_l_118:
	/* 0x118: jne    128 <tetragon_process_event_arg_filter_xdp+0x128> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x118, 0x128, x86_l_128);
x86_l_11a:
	/* 0x11a: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_11f:
	/* 0x11f: jmp    14a <tetragon_process_event_arg_filter_xdp+0x14a> */
	X86_SIM_X86_JMP(0x11f, 0x14a, x86_l_14a);
x86_l_121:
	/* 0x121: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_126:
	/* 0x126: jmp    14a <tetragon_process_event_arg_filter_xdp+0x14a> */
	X86_SIM_X86_JMP(0x126, 0x14a, x86_l_14a);
x86_l_128:
	/* 0x128: mov    eax,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_12d:
	/* 0x12d: movabs rdi,0x6e6f68747970 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_64, 121424772888944ULL);
x86_l_137:
	/* 0x137: cmp    rbp,rdi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64);
x86_l_13a:
	/* 0x13a: je     14a <tetragon_process_event_arg_filter_xdp+0x14a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13a, 0x14a, x86_l_14a);
x86_l_13c:
	/* 0x13c: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_13e:
	/* 0x13e: cmp    ecx,0x6873 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 26739ULL);
x86_l_144:
	/* 0x144: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_147:
	/* 0x147: shl    eax,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 2ULL);
x86_l_14a:
	/* 0x14a: mov    r8d,DWORD PTR [rdx-0x1f] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551585ULL);
x86_l_14e:
	/* 0x14e: test   r14d,r14d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_32);
x86_l_151:
	/* 0x151: je     5c <tetragon_process_event_arg_filter_xdp+0x5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x151, 0x5c, x86_l_5c);
x86_l_157:
	/* 0x157: mov    QWORD PTR [rsp+0x20],r11 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_15c:
	/* 0x15c: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_161:
	/* 0x161: movzx  ecx,BYTE PTR [rdx-0x17] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551593ULL);
x86_l_165:
	/* 0x165: movzx  edi,WORD PTR [rdx-0x11] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 18446744073709551599ULL);
x86_l_169:
	/* 0x169: mov    DWORD PTR [rsp+0x4],edi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_16d:
	/* 0x16d: movzx  edi,BYTE PTR [rdx-0xf] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551601ULL);
x86_l_171:
	/* 0x171: mov    QWORD PTR [rsp+0x28],rdi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_176:
	/* 0x176: movzx  r15d,BYTE PTR [rdx-0xe] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551602ULL);
x86_l_17b:
	/* 0x17b: movzx  edi,BYTE PTR [rdx-0xd] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551603ULL);
x86_l_17f:
	/* 0x17f: mov    DWORD PTR [rsp+0x14],edi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_183:
	/* 0x183: movzx  ebx,BYTE PTR [rdx-0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551604ULL);
x86_l_187:
	/* 0x187: movzx  edi,BYTE PTR [rdx-0xb] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551605ULL);
x86_l_18b:
	/* 0x18b: mov    QWORD PTR [rsp+0x30],rdi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_190:
	/* 0x190: movzx  r12d,BYTE PTR [rdx-0xa] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551606ULL);
x86_l_195:
	/* 0x195: movzx  edi,BYTE PTR [rdx-0x9] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551607ULL);
x86_l_199:
	/* 0x199: mov    QWORD PTR [rsp+0x38],rdi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_19e:
	/* 0x19e: movzx  r13d,BYTE PTR [rdx-0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551608ULL);
x86_l_1a3:
	/* 0x1a3: movzx  edi,BYTE PTR [rdx-0x1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551615ULL);
x86_l_1a7:
	/* 0x1a7: movzx  r11d,BYTE PTR [rdx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1ab:
	/* 0x1ab: mov    r10d,DWORD PTR [rdx-0x1b] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551589ULL);
x86_l_1af:
	/* 0x1af: cmp    cl,0x42 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_8, 66ULL);
x86_l_1b2:
	/* 0x1b2: je     1f6 <tetragon_process_event_arg_filter_xdp+0x1f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b2, 0x1f6, x86_l_1f6);
x86_l_1b4:
	/* 0x1b4: mov    r9d,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_R9, X86_R15, X86_WIDTH_32);
x86_l_1b7:
	/* 0x1b7: and    r9d,0x24 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_32, X86_ALU_AND, 36ULL);
x86_l_1bb:
	/* 0x1bb: jne    1f6 <tetragon_process_event_arg_filter_xdp+0x1f6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1bb, 0x1f6, x86_l_1f6);
x86_l_1bd:
	/* 0x1bd: movzx  eax,BYTE PTR [rdx-0x16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 18446744073709551594ULL);
x86_l_1c1:
	/* 0x1c1: shl    eax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_1c4:
	/* 0x1c4: movzx  edi,WORD PTR [rdx-0x15] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 18446744073709551595ULL);
x86_l_1c8:
	/* 0x1c8: shl    edi,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_SHL, 16ULL);
x86_l_1cb:
	/* 0x1cb: or     rax,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_OR);
x86_l_1ce:
	/* 0x1ce: or     rax,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDI, X86_WIDTH_64, X86_ALU_OR);
x86_l_1d1:
	/* 0x1d1: shl    r10,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_64, X86_ALU_SHL, 16ULL);
x86_l_1d5:
	/* 0x1d5: xor    r10,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RAX, X86_WIDTH_64, X86_ALU_XOR);
x86_l_1d8:
	/* 0x1d8: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1dd:
	/* 0x1dd: add    r9,r10 */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R10, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1e0:
	/* 0x1e0: inc    rsi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1e3:
	/* 0x1e3: add    rdx,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_1e7:
	/* 0x1e7: cmp    rsi,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_64, 32ULL);
x86_l_1eb:
	/* 0x1eb: jne    7a <tetragon_process_event_arg_filter_xdp+0x7a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1eb, 0x7a, x86_l_7a);
x86_l_1f1:
	/* 0x1f1: jmp    2c2 <tetragon_process_event_arg_filter_xdp+0x2c2> */
	X86_SIM_X86_JMP(0x1f1, 0x2c2, x86_l_2c2);
x86_l_1f6:
	/* 0x1f6: shl    r14,0x30 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_64, X86_ALU_SHL, 48ULL);
x86_l_1fa:
	/* 0x1fa: mov    rcx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RAX, X86_WIDTH_64);
x86_l_1fd:
	/* 0x1fd: shl    rcx,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_SHL, 40ULL);
x86_l_201:
	/* 0x201: or     rcx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R14, X86_WIDTH_64, X86_ALU_OR);
x86_l_204:
	/* 0x204: mov    r14d,DWORD PTR [rsp+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_209:
	/* 0x209: movzx  r9d,r14w */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R9, X86_R14, X86_WIDTH_32, X86_WIDTH_16);
x86_l_20d:
	/* 0x20d: shl    r9,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_64, X86_ALU_SHL, 24ULL);
x86_l_211:
	/* 0x211: or     r9,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_RCX, X86_WIDTH_64, X86_ALU_OR);
x86_l_214:
	/* 0x214: mov    r8d,r8d */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_R8, X86_WIDTH_32);
x86_l_217:
	/* 0x217: or     r8,r9 */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R9, X86_WIDTH_64, X86_ALU_OR);
x86_l_21a:
	/* 0x21a: test   r14b,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_R14, X86_WIDTH_8, 2ULL);
x86_l_21e:
	/* 0x21e: je     24f <tetragon_process_event_arg_filter_xdp+0x24f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21e, 0x24f, x86_l_24f);
x86_l_220:
	/* 0x220: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_222:
	/* 0x222: je     24f <tetragon_process_event_arg_filter_xdp+0x24f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x222, 0x24f, x86_l_24f);
x86_l_224:
	/* 0x224: shl    rdi,0x30 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_SHL, 48ULL);
x86_l_228:
	/* 0x228: shl    r11,0x38 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_64, X86_ALU_SHL, 56ULL);
x86_l_22c:
	/* 0x22c: or     r11,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RDI, X86_WIDTH_64, X86_ALU_OR);
x86_l_22f:
	/* 0x22f: or     r11,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RBP, X86_WIDTH_64, X86_ALU_OR);
x86_l_232:
	/* 0x232: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_237:
	/* 0x237: and    cl,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_8, X86_ALU_AND, 7ULL);
x86_l_23a:
	/* 0x23a: lea    eax,[rcx+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_23d:
	/* 0x23d: shlx   rax,r11,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RAX, X86_R11, X86_WIDTH_64, X86_RAX, X86_ALU_SHL);
x86_l_242:
	/* 0x242: not    cl */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_8, X86_ALU_NOT, 0);
x86_l_244:
	/* 0x244: shrx   rcx,r11,rcx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RCX, X86_R11, X86_WIDTH_64, X86_RCX, X86_ALU_SHR);
x86_l_249:
	/* 0x249: or     rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR);
x86_l_24c:
	/* 0x24c: xor    r8,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_RCX, X86_WIDTH_64, X86_ALU_XOR);
x86_l_24f:
	/* 0x24f: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_254:
	/* 0x254: shl    r15d,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_258:
	/* 0x258: add    r15,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_25d:
	/* 0x25d: mov    eax,DWORD PTR [rsp+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_261:
	/* 0x261: shl    eax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_SHL, 16ULL);
x86_l_264:
	/* 0x264: shl    ebx,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_32, X86_ALU_SHL, 24ULL);
x86_l_267:
	/* 0x267: or     ebx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RAX, X86_WIDTH_32, X86_ALU_OR);
x86_l_269:
	/* 0x269: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_26e:
	/* 0x26e: shl    rax,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHL, 32ULL);
x86_l_272:
	/* 0x272: shl    r12,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_SHL, 40ULL);
x86_l_276:
	/* 0x276: or     r12,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_RAX, X86_WIDTH_64, X86_ALU_OR);
x86_l_279:
	/* 0x279: mov    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_27e:
	/* 0x27e: shl    rax,0x30 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHL, 48ULL);
x86_l_282:
	/* 0x282: shl    r13,0x38 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_SHL, 56ULL);
x86_l_286:
	/* 0x286: or     r13,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_OR);
x86_l_289:
	/* 0x289: or     rbx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R15, X86_WIDTH_64, X86_ALU_OR);
x86_l_28c:
	/* 0x28c: or     rbx,r12 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R12, X86_WIDTH_64, X86_ALU_OR);
x86_l_28f:
	/* 0x28f: or     rbx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R13, X86_WIDTH_64, X86_ALU_OR);
x86_l_292:
	/* 0x292: xor    r10,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RBX, X86_WIDTH_64, X86_ALU_XOR);
x86_l_295:
	/* 0x295: test   BYTE PTR [rsp+0x4],0x4 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869188ULL);
x86_l_29a:
	/* 0x29a: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_29f:
	/* 0x29f: cmovne rax,r10 */
	X86_SIM_L_EXEC_CMOV(X86_RAX, X86_R10, X86_WIDTH_64, X86_CC_NE);
x86_l_2a3:
	/* 0x2a3: add    rax,r8 */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R8, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2a6:
	/* 0x2a6: mov    ecx,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RSI, X86_WIDTH_32);
x86_l_2a8:
	/* 0x2a8: and    cl,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_8, X86_ALU_AND, 7ULL);
x86_l_2ab:
	/* 0x2ab: lea    edi,[rcx+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2ae:
	/* 0x2ae: shlx   rdi,rax,rdi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RDI, X86_RAX, X86_WIDTH_64, X86_RDI, X86_ALU_SHL);
x86_l_2b3:
	/* 0x2b3: not    cl */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_8, X86_ALU_NOT, 0);
x86_l_2b5:
	/* 0x2b5: shrx   rax,rax,rcx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RAX, X86_RAX, X86_WIDTH_64, X86_RCX, X86_ALU_SHR);
x86_l_2ba:
	/* 0x2ba: or     rax,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDI, X86_WIDTH_64, X86_ALU_OR);
x86_l_2bd:
	/* 0x2bd: jmp    66 <tetragon_process_event_arg_filter_xdp+0x66> */
	X86_SIM_X86_JMP(0x2bd, 0x66, x86_l_66);
x86_l_2c2:
	/* 0x2c2: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2c7:
	/* 0x2c7: mov    QWORD PTR [rax],r9 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RAX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ca:
	/* 0x2ca: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2cf:
	/* 0x2cf: add    rsp,0x40 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 64ULL);
x86_l_2d3:
	/* 0x2d3: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2d4:
	/* 0x2d4: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2d6:
	/* 0x2d6: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2d8:
	/* 0x2d8: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2da:
	/* 0x2da: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2dc:
	/* 0x2dc: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2dd:
	/* 0x2dd: jmp    2e2 <tetragon_process_event_arg_filter_xdp+0x2e2> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_2e2:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
