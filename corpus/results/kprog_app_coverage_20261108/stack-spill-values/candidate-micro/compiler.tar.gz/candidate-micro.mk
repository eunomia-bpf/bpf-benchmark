ROOT := /workspaces/repository
HERE := /workspaces/.agent-state/kprog-lanes/C/design-only/stack-spill-values
.PHONY: micro
micro:
	PATH=$(HERE)/bin:$$PATH $(MAKE) -C $(ROOT)/kprog/x86 micro-proofs-build PROOF_BUILD_DIR=$(HERE)/candidate-micro NEGATIVE_NATIVE_BUILD_DIR=$(HERE)/negative-native
