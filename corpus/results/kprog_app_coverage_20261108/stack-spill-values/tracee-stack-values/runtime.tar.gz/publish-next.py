from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys,tarfile,shutil,re
G=Path(__file__).parent;C=G.parent.parent.parent;R=Path('/workspaces/repository');D=G.parent.parent/'remaining-apps';key,label=sys.argv[1:];A=D/key;O=R/'corpus/results/kprog_app_coverage_20261108/stack-spill-values'/key
epoch='75d2c8813' if key=='tetragon-stack-values' else 'd963788c0'
O.mkdir(exist_ok=True);input=D/'collected'/key/'coverage.json';v=None;work=[];rows=[];baseline=0
if input.exists():
 v=json.loads(input.read_text())
 for p in input.parent.iterdir():
  if p.is_file():shutil.copy2(p,O/p.name)
 rows=v['programs'];work=[dict(application=p['application'],status=p['app']['status'],error=p['app'].get('error'),baseline=p['app'].get('baseline'),post_rejit=p['app'].get('post_rejit'))for p in v['results']];(O/'work.json').write_text(json.dumps(work,indent=2)+'\n');baseline=len(work[0]['baseline'].get('bpf',[]))if work and work[0]['baseline']else 0
 summary=f"Whole {label}: baseline{baseline}, generated{v['generated']}, compiled{v['compiled']}, installed{v['installed']}, failed{v['failed']}, native hash joins{sum(p['native_sha256_matches']for p in rows)}/{len(rows)}."
else:summary='Whole '+label+' setup ended before collected coverage.'
lines=['# Whole '+label+' on canonical stack spill representation','',summary,'','| Native entry | Generated | Compiled | Status | Verifier observation |','| --- | ---: | ---: | ---: | --- |']
for p in rows:lines.append('| '+p['entry']+' | '+str(int(p['generated']))+' | '+str(int(p['compiled']))+' | '+str(p['status'])+' | '+('; '.join(p['verifier_excerpt'][-2:]).replace('|','/'))+' |')
lines+=['','Complete original application, existing two-second workload, captured runtime image and captured model '+epoch+'. Baseline resident census and terminal native requests retain distinct measured domains. Complete input bytes, generated C/BPF, per-request stock-verifier logs, workload counters and app errors remain in the archives. Runtime admission checks, limits and per-program proofs added0. If the workload was not reached, this receipt records its setup error and zero observed requests; it does not establish whole-application coverage.','']
(O/'README.md').write_text('\n'.join(lines))
with tarfile.open(O/'runtime.tar.gz','w:gz')as t:
 for name in ['service','source','vendor','native-link','clang-next','queue-next.py','next-inputs.json','tetragon-next.json','publish-next.py','tetragon-source','tetragon-clang','broker-next.log']:
  t.add(G/name,arcname=name)
 for p in G.glob(key+'.*'):t.add(p,arcname='controller/'+p.name)
 for name in ['Makefile','guest.py','summary.json']:
  if(A/name).exists():t.add(A/name,arcname='application/'+name)
paths=[str(p.relative_to(R))for p in O.iterdir()if p.is_file()]
if v and work:
 table=R/'corpus/results/kprog_app_coverage_20261108/README.md';rel=str(table.relative_to(R))
 if table.read_bytes()==subprocess.check_output(['git','show','HEAD:'+rel]):
  failed=[p for p in rows if p['status']];reject=[p for p in failed if p['compiled']and p['verifier_excerpt']];other=[p for p in failed if p not in reject];causes='; '.join(p['entry']+' '+next((x for x in p['verifier_excerpt']if 'processed 'not in x),p.get('error','load error'))[:150].replace('|','/')for p in reject)
  line=f"| {label} | {baseline} resident | {v['generated']} | {v['compiled']} | {v['installed']} | {len(other)} | {len(reject)}: {causes or '0'} | [canonical stack spill whole cohort](stack-spill-values/{key}/README.md) |";table.write_text(re.sub(r'^\| '+label+r' \|.*$',lambda _:line,table.read_text(),flags=re.M));paths.append(rel)
sys.path.insert(0,str(C));from publish_owned import publish
commit=publish(paths,'Record whole '+label+' on canonical stack spill model',G/(key+'.publication.json'));now=datetime.now(timezone.utc).isoformat()
with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C '+now+': PUSHED '+commit+' '+summary+' Original whole app/image/native inputs/workload with captured model '+epoch+'. All source/BPF/verifier/work records in stack-spill-values/'+key+'. Runtime admission additions0. Continue actual frontier.\n')
p=C/'current.json';d=json.loads(p.read_text());d['updated']=now;d['published'][key]=commit;d['active']['canonical-next-apps'][key]=dict(status='closed and published '+commit,summary=summary)
if v and work:d['closed'][label.lower()].update(generated=v['generated'],compiled=v['compiled'],installed=v['installed'],baseline_resident=baseline,latest_published=commit,frontier=rows[-1]['verifier_excerpt']if rows else[])
p.write_text(json.dumps(d,indent=2)+'\n');print(commit,summary,flush=True)

# Keep the same serial controller alive through the coordinator's successor.
if key=='tracee-stack-values':
 successor=json.loads((G/'tetragon-next.json').read_text());next_key=successor['key'];A=D/next_key
 with(G/(next_key+'.log')).open('wb')as log:q=subprocess.run(['make','-f',str(A/'Makefile'),'corpus','STATE='+str(A),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS='+successor['app'],'SAMPLES=1','WORKLOAD_DURATION=2'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 (G/(next_key+'.exit')).write_text(str(q.returncode)+'\n')
 with(G/(next_key+'.collect.log')).open('wb')as log:q=subprocess.run([sys.executable,str(D/'collect.py'),next_key],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 (G/(next_key+'.collect.exit')).write_text(str(q.returncode)+'\n')
 with(G/(next_key+'.publish.log')).open('wb')as log:q=subprocess.run([sys.executable,str(G/'publish-next.py'),next_key,successor['label']],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 q.check_returncode()
