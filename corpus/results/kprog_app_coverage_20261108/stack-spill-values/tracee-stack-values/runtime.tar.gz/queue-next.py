from pathlib import Path
import os,select,sys,subprocess,threading,time,json
G=Path(__file__).parent;D=G.parent.parent/'remaining-apps';R=Path('/workspaces/repository')
try:
 fd=os.pidfd_open(int((G/'queue.pid').read_text()));select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
state=G/'broker-next'
with(G/'broker-next.log').open('wb')as log:server=subprocess.Popen(['taskset','-c','8-11',sys.executable,str(G/'service/trusted_compile.py'),'serve','--scope',str(G.parent.parent),'--state',str(state),'--clang','/usr/lib/llvm-18/bin/clang'],stdout=log,stderr=subprocess.STDOUT)
(G/'broker-next.pid').write_text(str(server.pid)+'\n')
def monitor():
 rc=server.wait()
 if not(state/'STOP').exists():(state/'failed.json').write_text(json.dumps(dict(error='compiler exited',returncode=rc))+'\n')
threading.Thread(target=monitor,daemon=True).start()
try:
 while not(state/'ready.json').exists():
  if server.poll()is not None:raise RuntimeError('compiler startup exit '+str(server.returncode))
  time.sleep(.1)
 for row in json.loads((G/'next-inputs.json').read_text())['rows']:
  key=row['key'];A=D/key
  with(G/(key+'.log')).open('wb')as log:q=subprocess.run(['make','-f',str(A/'Makefile'),'corpus','STATE='+str(A),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS='+row['app'],'SAMPLES=1','WORKLOAD_DURATION=2'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  (G/(key+'.exit')).write_text(str(q.returncode)+'\n')
  with(G/(key+'.collect.log')).open('wb')as log:q=subprocess.run([sys.executable,str(D/'collect.py'),key],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  (G/(key+'.collect.exit')).write_text(str(q.returncode)+'\n')
  with(G/(key+'.publish.log')).open('wb')as log:q=subprocess.run([sys.executable,str(G/'publish-next.py'),key,row['label']],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  q.check_returncode()
finally:
 (state/'STOP').write_text('application cohorts closed\n');server.wait()
(G/'queue-next.exit').write_text('0\n')
