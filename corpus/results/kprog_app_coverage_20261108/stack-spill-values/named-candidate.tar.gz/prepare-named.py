from pathlib import Path
import re,shutil,json
N=Path(__file__).parent;p=N/'source/kprog/x86/x86_sim_local_bpf.h';s=p.read_text();(N/'array-header.h').write_text(s)
for name in ['captured.bpf.o','component.log','component.exit','host.c','host.log','host.exit']:
 q=N/name
 if q.exists():shutil.copy2(q,N/('array-'+name))
start=s.index('/* Native stack bytes and pointer-shaped representatives')
end=s.index('#define X86_SIM_L_DECLARE_REG(REG, NAME)',start)
meta=r'''/* Native bytes and pointer representatives keep distinct storage. A named
 * layout lets the compiler scalarize each ghost cell before lowering loops. */
struct x86_sim_stack_value { void *pointer; __u8 tag; };
#ifdef X86_SIM_STACK_VALUE_WORDS
#define X86_SIM_L_SV_TAG_NAME_(I) __x86_stack_value_tag_##I
#define X86_SIM_L_SV_PTR_NAME_(I) __x86_stack_value_ptr_##I
#define X86_SIM_L_SV_TAG(I) X86_SIM_L_SV_TAG_NAME_(I)
#define X86_SIM_L_SV_PTR(I) X86_SIM_L_SV_PTR_NAME_(I)
#define X86_SIM_L_SV_DECLARE(I) __u8 X86_SIM_L_SV_TAG(I)=0; void *X86_SIM_L_SV_PTR(I);
#define X86_SIM_L_DECLARE_STACK_VALUES() X86_SIM_STACK_VALUE_WORDS(X86_SIM_L_SV_DECLARE)
#define X86_SIM_L_SV_EACH(OP) X86_SIM_STACK_VALUE_WORDS(OP)
#else
#define X86_SIM_L_SV_TAG(I) __x86_stack_value_tags[(I)]
#define X86_SIM_L_SV_PTR(I) __x86_stack_value_ptrs[(I)]
#define X86_SIM_L_DECLARE_STACK_VALUES() \
    __u8 __x86_stack_value_tags[KPROG_X86_STACK_WORDS(X86_SIM_STACK_BYTES)]={}; \
    void *__x86_stack_value_ptrs[KPROG_X86_STACK_WORDS(X86_SIM_STACK_BYTES)]
#define X86_SIM_L_SV_EACH(OP) \
    _Pragma("unroll") \
    for (__u32 __x86_sv_i=0; __x86_sv_i<KPROG_X86_STACK_WORDS(X86_SIM_STACK_BYTES); ++__x86_sv_i) { OP(__x86_sv_i) }
#endif
#define X86_SIM_L_SV_CLEAR_ONE(I) X86_SIM_L_SV_TAG(I)=X86_SIM_TAG_SCALAR;
#define X86_SIM_L_STACK_VALUES_CLEAR() do { X86_SIM_L_SV_EACH(X86_SIM_L_SV_CLEAR_ONE) } while(0)
#define X86_SIM_L_SV_ERASE_ONE(I) \
    do { __u64 __x86_sv_start=(__u64)(I)*8U; \
         if (__x86_sv_index-__x86_sv_start<8U || __x86_sv_start-__x86_sv_index<__x86_sv_width) \
             X86_SIM_L_SV_TAG(I)=X86_SIM_TAG_SCALAR; } while(0);
#define X86_SIM_L_STACK_VALUES_ERASE(INDEX, WIDTH) \
    do { __u64 __x86_sv_index=(INDEX),__x86_sv_width=X86_SIM_L_EFFECTIVE_WIDTH(WIDTH); \
         X86_SIM_L_SV_EACH(X86_SIM_L_SV_ERASE_ONE) } while(0)
#define X86_SIM_L_SV_SAVE_ONE(I) \
    do { if (__x86_sv_at==(__u64)(I)*8U) { \
        if (__x86_sv_tag==X86_SIM_TAG_STACK) X86_SIM_L_SV_PTR(I)=__x86_sv_pointer; \
        X86_SIM_L_SV_TAG(I)=__x86_sv_tag; } } while(0);
#define X86_SIM_L_STACK_VALUES_SAVE(INDEX, WIDTH, POINTER, TAG) \
    do { __u64 __x86_sv_at=(INDEX); __u8 __x86_sv_tag=(TAG); \
         if (X86_SIM_L_EFFECTIVE_WIDTH(WIDTH)==X86_WIDTH_64 && __x86_sv_tag!=X86_SIM_TAG_SCALAR) { \
             void *__x86_sv_pointer=(POINTER); X86_SIM_L_SV_EACH(X86_SIM_L_SV_SAVE_ONE) } } while(0)
#define X86_SIM_L_SV_READ_ONE(I) \
    do { if (__x86_sv_at==(__u64)(I)*8U && X86_SIM_L_SV_TAG(I)!=X86_SIM_TAG_SCALAR) { \
         __x86_sv_result.tag=X86_SIM_L_SV_TAG(I); \
         if (__x86_sv_result.tag==X86_SIM_TAG_STACK) __x86_sv_result.pointer=X86_SIM_L_SV_PTR(I); } } while(0);
#define X86_SIM_L_STACK_VALUES_READ(INDEX, WIDTH) \
    ({ struct x86_sim_stack_value __x86_sv_result={}; __u64 __x86_sv_at=(INDEX); \
       if (X86_SIM_L_EFFECTIVE_WIDTH(WIDTH)==X86_WIDTH_64) { X86_SIM_L_SV_EACH(X86_SIM_L_SV_READ_ONE) } \
       __x86_sv_result; })
/* Ordinary callees keep the caller's allocated frame. Ghost facts for older
 * deallocated slots disappear while their architectural bytes stay raw. */
#define X86_SIM_L_SV_BELOW_SP_ONE(I) \
    do { if ((__s64)((__u64)(I)*8U)-(__s64)(X86_SIM_STACK_BYTES-8U)<__x86_sv_sp) \
             X86_SIM_L_SV_TAG(I)=X86_SIM_TAG_SCALAR; } while(0);
#define X86_SIM_L_STACK_VALUES_CALL_FRAME() \
    do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; \
         X86_SIM_L_SV_EACH(X86_SIM_L_SV_BELOW_SP_ONE) } while(0)

'''
s=s[:start]+meta+s[end:]
s=s.replace('X86_SIM_L_HELPER_REGISTER_CLOBBERS(); } while(0)\n#define X86_SIM_L_HELPER_READONLY_POINTER_RESULT', 'X86_SIM_L_STACK_VALUES_CALL_FRAME(); X86_SIM_L_HELPER_REGISTER_CLOBBERS(); } while(0)\n#define X86_SIM_L_HELPER_READONLY_POINTER_RESULT',1)
s=s.replace('X86_SIM_L_HELPER_REGISTER_CLOBBERS(); } while(0)\n\n#define X86_SIM_L_HELPER_SCALAR_RESULT', 'X86_SIM_L_STACK_VALUES_CALL_FRAME(); X86_SIM_L_HELPER_REGISTER_CLOBBERS(); } while(0)\n\n#define X86_SIM_L_HELPER_SCALAR_RESULT',1)
p.write_text(s)
for name,size in [('captured.c',280),('host.c',128)]:
 p=N/name;s=p.read_text();marker='#include '
 pos=s.index(marker);prefix='#define X86_SIM_STACK_VALUE_WORDS(M) '+' '.join(f'M({i})'for i in range((size+7)//8))+'\n';s=s[:pos]+prefix+s[pos:];p.write_text(s)
print('named ghost cells, same raw arena/ops; declarations cover the actual arena extent')
