from pathlib import Path
import shutil,json,hashlib
R=Path('/workspaces/repository');N=Path(__file__).parent
for rel in ['kprog/x86/x86_sim_local_bpf.h','kprog/x86/x86_sim.h','kprog/formal/generated','kinsn/module/include/native_lab_input.h']:
 src=R/rel;dst=N/'source'/rel;dst.parent.mkdir(parents=True,exist_ok=True)
 if src.is_dir():shutil.copytree(src,dst,dirs_exist_ok=True)
 else:shutil.copy2(src,dst)
p=N/'source/kprog/x86/x86_sim_local_bpf.h';s=p.read_text();(N/'before.h').write_text(s)
meta=r'''/* Native stack bytes and pointer-shaped representatives have separate storage.
 * Every raw load/store still executes. Ghost writes carry only the representation
 * of an exact full-width store and disappear on overlapping/opaque writes. */
struct x86_sim_stack_value {
    void *pointer;
    __u8 tag;
};
#define X86_SIM_L_DECLARE_STACK_VALUES() \
    __u8 __x86_stack_value_tags[KPROG_X86_STACK_WORDS(X86_SIM_STACK_BYTES)] = {}; \
    void *__x86_stack_value_ptrs[KPROG_X86_STACK_WORDS(X86_SIM_STACK_BYTES)] = {}
#define X86_SIM_L_STACK_VALUES_CLEAR() \
    do { \
        _Pragma("unroll") \
        for (__u32 __x86_sv_i=0; __x86_sv_i<KPROG_X86_STACK_WORDS(X86_SIM_STACK_BYTES); ++__x86_sv_i) \
            __x86_stack_value_tags[__x86_sv_i]=X86_SIM_TAG_SCALAR; \
    } while (0)
#define X86_SIM_L_STACK_VALUES_ERASE(INDEX, WIDTH) \
    do { \
        __u64 __x86_sv_index=(INDEX), __x86_sv_width=X86_SIM_L_EFFECTIVE_WIDTH(WIDTH); \
        _Pragma("unroll") \
        for (__u32 __x86_sv_i=0; __x86_sv_i<KPROG_X86_STACK_WORDS(X86_SIM_STACK_BYTES); ++__x86_sv_i) { \
            __u64 __x86_sv_start=(__u64)__x86_sv_i*8U; \
            if (__x86_sv_index-__x86_sv_start<8U || __x86_sv_start-__x86_sv_index<__x86_sv_width) \
                __x86_stack_value_tags[__x86_sv_i]=X86_SIM_TAG_SCALAR; \
        } \
    } while (0)
#define X86_SIM_L_STACK_VALUES_SAVE(INDEX, WIDTH, POINTER, TAG) \
    do { \
        __u64 __x86_sv_at=(INDEX); __u8 __x86_sv_tag=(TAG); \
        if (X86_SIM_L_EFFECTIVE_WIDTH(WIDTH)==X86_WIDTH_64 && __x86_sv_tag!=X86_SIM_TAG_SCALAR) { \
            _Pragma("unroll") \
            for (__u32 __x86_sv_k=0; __x86_sv_k<KPROG_X86_STACK_WORDS(X86_SIM_STACK_BYTES); ++__x86_sv_k) \
                if (__x86_sv_at==(__u64)__x86_sv_k*8U) { \
                    __x86_stack_value_ptrs[__x86_sv_k]=(POINTER); \
                    __x86_stack_value_tags[__x86_sv_k]=__x86_sv_tag; \
                } \
        } \
    } while (0)
#define X86_SIM_L_STACK_VALUES_READ(INDEX, WIDTH) \
    ({ \
        struct x86_sim_stack_value __x86_sv_result={}; __u64 __x86_sv_at=(INDEX); \
        if (X86_SIM_L_EFFECTIVE_WIDTH(WIDTH)==X86_WIDTH_64) { \
            _Pragma("unroll") \
            for (__u32 __x86_sv_k=0; __x86_sv_k<KPROG_X86_STACK_WORDS(X86_SIM_STACK_BYTES); ++__x86_sv_k) \
                if (__x86_sv_at==(__u64)__x86_sv_k*8U && __x86_stack_value_tags[__x86_sv_k]!=X86_SIM_TAG_SCALAR) { \
                    __x86_sv_result.tag=__x86_stack_value_tags[__x86_sv_k]; \
                    __x86_sv_result.pointer=__x86_stack_value_ptrs[__x86_sv_k]; \
                } \
        } \
        __x86_sv_result; \
    })

'''
s=s.replace('#define X86_SIM_L_DECLARE_REG(REG, NAME)',meta+'#define X86_SIM_L_DECLARE_REG(REG, NAME)',1)
s=s.replace('struct x86_sim_state *__x86_state = (STATE_PTR);                    \\\n\t(void)__x86_state','struct x86_sim_state *__x86_state = (STATE_PTR);                    \\\n\tX86_SIM_L_DECLARE_STACK_VALUES();                                  \\\n\t(void)__x86_state',1)
s=s.replace('#define X86_SIM_L_DECLARE_STATE()                                           \\\n', '#define X86_SIM_L_DECLARE_STATE()                                           \\\n\tX86_SIM_L_DECLARE_STACK_VALUES();                                  \\\n',1)
s=s.replace('__u64 __x86_stw_index = X86_SIM_L_STACK_INDEX(OFF);       \\\n', '__u64 __x86_stw_index = X86_SIM_L_STACK_INDEX(OFF);       \\\n\t\tX86_SIM_L_STACK_VALUES_ERASE(__x86_stw_index, (WIDTH)); \\\n',1)
old='#define X86_SIM_L_STORE_ADDR(ADDR, WIDTH, VALUE)                           \\\n\tKPROG_X86_MEM_STORE((ADDR), (WIDTH), (VALUE))'
new=r'''#define X86_SIM_L_STORE_ADDR(ADDR, WIDTH, VALUE) \
    do { X86_SIM_L_STACK_VALUES_CLEAR(); \
         KPROG_X86_MEM_STORE((ADDR), (WIDTH), (VALUE)); } while (0)
#define X86_SIM_L_STORE_ADDR_TAGGED(ADDR, WIDTH, VALUE, TAG) \
    do { \
        void *__x86_st_addr=(ADDR); __u8 __x86_st_width=(WIDTH),__x86_st_tag=(TAG); \
        __u64 __x86_st_value=(VALUE); \
        if (__x86_st_tag==X86_SIM_TAG_STACK) \
            X86_SIM_L_STACK_VALUES_ERASE((__u64)(long)__x86_st_addr-(__u64)(long)&__x86_stack_mem.b[0],__x86_st_width); \
        else if (__x86_st_tag==X86_SIM_TAG_SCALAR) X86_SIM_L_STACK_VALUES_CLEAR(); \
        KPROG_X86_MEM_STORE(__x86_st_addr,__x86_st_width,__x86_st_value); \
    } while (0)'''
assert old in s;s=s.replace(old,new,1)
# Recover pointer shape after the raw native-value load. Narrow/sign-extending
# forms retain the original bit-lane write; the architectural bytes stay raw.
old='''\t\t\tX86_SIM_L_WRITE_REG_WIDTH((DST), __x86_l_value,   \\
\t\t\t\t\t\t  __x86_l_write_width);     \\
\t\t\tbreak;'''
new=r'''            struct x86_sim_stack_value __x86_mv_saved=X86_SIM_L_STACK_VALUES_READ( \
                X86_SIM_L_STACK_INDEX((__s64)(long)__x86_l_base_ptr+__x86_l_disp),__x86_l_mem_width); \
            if ((OP)==X86_OP_MOV_LOAD && __x86_l_write_width==X86_WIDTH_64 && \
                __x86_mv_saved.tag!=X86_SIM_TAG_SCALAR && (DST)!=X86_RSP) \
                X86_SIM_L_WRITE_REG_PTR_TAG((DST),__x86_mv_saved.pointer,__x86_mv_saved.tag); \
            else X86_SIM_L_WRITE_REG_WIDTH((DST),__x86_l_value,__x86_l_write_width); \
            break;'''
assert old in s;s=s.replace(old,new,1)
# Non-RSP aliases use the actual arena address for the same ghost-word lookup.
old='''\t\t\tX86_SIM_L_WRITE_REG_WIDTH((DST), __x86_l_value,   \\
\t\t\t\t\t\t  __x86_l_write_width);     \\
\t\t\tbreak;'''
# The remaining occurrence belongs to the default MOV-load arm.
assert old in s
new=r'''            struct x86_sim_stack_value __x86_mv_alias={}; \
            if (X86_SIM_L_REG_TAG(SRC)==X86_SIM_TAG_STACK) \
                __x86_mv_alias=X86_SIM_L_STACK_VALUES_READ( \
                    (__u64)(long)__x86_l_addr-(__u64)(long)&__x86_stack_mem.b[0],__x86_l_mem_width); \
            if ((OP)==X86_OP_MOV_LOAD && __x86_l_write_width==X86_WIDTH_64 && \
                __x86_mv_alias.tag!=X86_SIM_TAG_SCALAR && (DST)!=X86_RSP) \
                X86_SIM_L_WRITE_REG_PTR_TAG((DST),__x86_mv_alias.pointer,__x86_mv_alias.tag); \
            else X86_SIM_L_WRITE_REG_WIDTH((DST),__x86_l_value,__x86_l_write_width); \
            break;'''
s=s.replace(old,new,1)
# Keep the original pre-barrier effective offset for ghost scalarization.
start=s.index('#define X86_SIM_L_EXEC_STORE(OP,');end=s.index('#define X86_SIM_L_EXEC_MOVBE_LOAD',start);part=s[start:end]
needle='\t\t__x86_l_disp = X86_SIM_L_MEM_OFFSET((AUX), __x86_l_disp); \\\n'
part=part.replace(needle,needle+'        __s64 __x86_l_meta_disp=__x86_l_disp; \\\n',1)
old='''\t\t\t\t__x86_l_value);                            \\
\t\t\tbreak;'''
new=r'''                __x86_l_value); \
            if ((OP)==X86_OP_MOV_STORE_REG && __x86_l_width==X86_WIDTH_64 && \
                KPROG_X86_STORE_SRC_SHIFT(0U,(AUX))==0U) \
                X86_SIM_L_STACK_VALUES_SAVE( \
                    X86_SIM_L_STACK_INDEX((__s64)(long)__x86_l_base_ptr+__x86_l_meta_disp), \
                    __x86_l_width,(SRC)==X86_RSP ? X86_SIM_L_STACK_PTR((__s64)(long)X86_SIM_L_READ_REG_PTR(SRC)) : X86_SIM_L_READ_REG_PTR(SRC), \
                    (SRC)==X86_RSP ? X86_SIM_TAG_STACK : X86_SIM_L_REG_TAG(SRC)); \
            break;'''
assert old in part;part=part.replace(old,new,1)
part=part.replace('''\t\t\tif (X86_SIM_L_REG_TAG(DST) == X86_SIM_TAG_STACK && \\''',r'''            if (X86_SIM_L_REG_TAG(DST)==X86_SIM_TAG_STACK) \
                X86_SIM_L_STACK_VALUES_ERASE((__u64)(long)__x86_l_addr-(__u64)(long)&__x86_stack_mem.b[0],__x86_l_width); \
            if (X86_SIM_L_REG_TAG(DST) == X86_SIM_TAG_STACK && \
'''.rstrip('\n'),1)
part=part.replace('X86_SIM_L_STORE_ADDR(__x86_l_addr,         \\\n\t\t\t\t\t__x86_l_width, __x86_l_value);', 'X86_SIM_L_STORE_ADDR_TAGGED(__x86_l_addr, \\\n                    __x86_l_width,__x86_l_value,X86_SIM_L_REG_TAG(DST));',1)
# Scalar aliases retain the byte ladder. Pointer aliases retain a wide store
# and then the representation of the exact stored register.
needle='''\t\t\tbreak;                                           \\
\t\t}                                                         \\
\t\t} while (0)'''
replacement=r'''            if (X86_SIM_L_REG_TAG(DST)==X86_SIM_TAG_STACK && (OP)==X86_OP_MOV_STORE_REG && \
                __x86_l_width==X86_WIDTH_64 && KPROG_X86_STORE_SRC_SHIFT(0U,(AUX))==0U) \
                X86_SIM_L_STACK_VALUES_SAVE( \
                    (__u64)(long)__x86_l_addr-(__u64)(long)&__x86_stack_mem.b[0],__x86_l_width, \
                    (SRC)==X86_RSP ? X86_SIM_L_STACK_PTR((__s64)(long)X86_SIM_L_READ_REG_PTR(SRC)) : X86_SIM_L_READ_REG_PTR(SRC), \
                    (SRC)==X86_RSP ? X86_SIM_TAG_STACK : X86_SIM_L_REG_TAG(SRC)); \
            break; \
        } \
        } while (0)'''
assert needle in part;part=part.replace(needle,replacement,1);s=s[:start]+part+s[end:]
# Known non-stack object writers retain private-slot representatives.
s=s.replace('else X86_SIM_L_STORE_ADDR((ADDR),(WIDTH),(VALUE)); } while(0)', 'else X86_SIM_L_STORE_ADDR_TAGGED((ADDR),(WIDTH),(VALUE),X86_SIM_L_REG_TAG(BASE)); } while(0)',1)
s=s.replace('#define X86_SIM_L_HELPER_CLOBBERS() \\', '#define X86_SIM_L_HELPER_REGISTER_CLOBBERS() \\',1)
marker='#define X86_SIM_L_HELPER_SCALAR_RESULT(EXPR)'
pos=s.index(marker)
wrappers=r'''#define X86_SIM_L_HELPER_CLOBBERS() \
    do { X86_SIM_L_STACK_VALUES_CLEAR(); X86_SIM_L_HELPER_REGISTER_CLOBBERS(); } while(0)
#define X86_SIM_L_HELPER_READONLY_SCALAR_RESULT(EXPR) \
    do { __u64 __x86_hr=(__u64)(EXPR); X86_SIM_L_WRITE_REG_WIDTH(X86_RAX,__x86_hr,X86_WIDTH_64); \
         X86_SIM_L_HELPER_REGISTER_CLOBBERS(); } while(0)
#define X86_SIM_L_HELPER_READONLY_POINTER_RESULT(EXPR) \
    do { void *__x86_hr=(void *)(EXPR); X86_SIM_L_WRITE_REG_PTR_TAG(X86_RAX,__x86_hr,X86_SIM_TAG_MAP_VALUE); \
         X86_SIM_L_HELPER_REGISTER_CLOBBERS(); } while(0)

'''
s=s[:pos]+wrappers+s[pos:]
s=s.replace('X86_SIM_L_HELPER_POINTER_RESULT(bpf_map_lookup_elem(', 'X86_SIM_L_HELPER_READONLY_POINTER_RESULT(bpf_map_lookup_elem(',1)
s=s.replace('X86_SIM_L_HELPER_SCALAR_RESULT(bpf_skb_store_bytes(', 'X86_SIM_L_HELPER_READONLY_SCALAR_RESULT(bpf_skb_store_bytes(',1)
p.write_text(s)
source=Path('/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/cilium-live-data-end/failure.c').read_text().replace(str(R/'kprog/x86/x86_sim_local_bpf.h'),str(p));(N/'captured.c').write_text(source)
(N/'Makefile').write_text(f'''ROOT := {R}
HERE := {N}
.PHONY: component
component:
\t/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -I$(ROOT)/kprog/x86 -I$(ROOT)/vendor/libbpf/include/uapi -I$(ROOT)/vendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c $(HERE)/captured.c -o $(HERE)/captured.bpf.o
''')
(N/'inputs.json').write_text(json.dumps({str(p.relative_to(N)):hashlib.sha256(p.read_bytes()).hexdigest()for p in (N/'source').rglob('*')if p.is_file()},indent=2)+'\n')
print('private header bytes',len(s))
