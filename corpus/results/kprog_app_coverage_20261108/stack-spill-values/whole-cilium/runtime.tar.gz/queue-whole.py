from pathlib import Path
import os,subprocess,sys,threading,time,json
N=Path(__file__).parent;D=N.parent/'remaining-apps';R=Path('/workspaces/repository');A=D/'cilium-stack-spill-values';state=N/'whole-broker'
with(N/'whole-broker.log').open('wb')as log:server=subprocess.Popen(['taskset','-c','8-11',sys.executable,str(N/'service/trusted_compile.py'),'serve','--scope',str(N.parent),'--state',str(state),'--clang','/usr/lib/llvm-18/bin/clang'],stdout=log,stderr=subprocess.STDOUT)
(N/'whole-broker.pid').write_text(str(server.pid)+'\n')
def monitor():
 rc=server.wait()
 if not(state/'STOP').exists():(state/'failed.json').write_text(json.dumps(dict(error='compiler exited',returncode=rc))+'\n')
threading.Thread(target=monitor,daemon=True).start()
try:
 while not(state/'ready.json').exists():
  if server.poll()is not None:raise RuntimeError('compiler startup exit '+str(server.returncode))
  time.sleep(.1)
 with(N/'whole.log').open('wb')as log:q=subprocess.run(['make','-f',str(A/'Makefile'),'corpus','STATE='+str(A),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS=cilium/agent','SAMPLES=1','WORKLOAD_DURATION=2'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 (N/'whole.exit').write_text(str(q.returncode)+'\n')
 with(N/'whole.collect.log').open('wb')as log:q=subprocess.run([sys.executable,str(D/'collect.py'),'cilium-stack-spill-values'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 (N/'whole.collect.exit').write_text(str(q.returncode)+'\n')
finally:
 (state/'STOP').write_text('application cohort closed\n');server.wait()
(N/'queue-whole.exit').write_text('0\n')
