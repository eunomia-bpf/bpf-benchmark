from pathlib import Path
import shutil
N=Path(__file__).parent;p=N/'source/kprog/x86/x86_sim_local_bpf.h';s=p.read_text()
for name in ['captured.bpf.o','named-component.log','named-component.exit','host.c','host-liveness.c']:
 shutil.copy2(N/name,N/('named-'+name))
(N/'named-header.h').write_text(s)
# Ghost offsets use the expression before its verifier-opacity barrier; the
# architectural byte access retains the original barrier and address expression.
s=s.replace('#define X86_SIM_L_STACK_WRITE(OFF, WIDTH, VALUE)', '#define X86_SIM_L_STACK_WRITE_RAW(OFF, WIDTH, VALUE)',1)
s=s.replace('\t\tX86_SIM_L_STACK_VALUES_ERASE(__x86_stw_index, (WIDTH)); \\\n','',1)
pos=s.index('#define X86_SIM_L_STACK_READ(OFF, WIDTH)')
s=s[:pos]+'''#define X86_SIM_L_STACK_WRITE(OFF, WIDTH, VALUE) \\
    do { X86_SIM_L_STACK_VALUES_ERASE(X86_SIM_L_STACK_INDEX(OFF),(WIDTH)); \\
         X86_SIM_L_STACK_WRITE_RAW((OFF),(WIDTH),(VALUE)); } while(0)

'''+s[pos:]
a=s.index('#define X86_SIM_L_EXEC_MOV_LOAD(');b=s.index('#define X86_SIM_L_EXEC_STORE(',a)
x=s[a:b]
needle='\t\t__s64 __x86_l_disp = X86_SIM_L_MEM_OFFSET((AUX), x86_simm(IMM));\\\n'
assert x.count(needle)==1
x=x.replace(needle,needle+'        __s64 __x86_l_meta_disp=__x86_l_disp; \\\n')
x=x.replace('X86_SIM_L_STACK_INDEX((__s64)(long)__x86_l_base_ptr+__x86_l_disp),__x86_l_mem_width);','X86_SIM_L_STACK_INDEX((__s64)(long)__x86_l_base_ptr+__x86_l_meta_disp),__x86_l_mem_width);')
s=s[:a]+x+s[b:]
a=s.index('#define X86_SIM_L_EXEC_STORE(');b=s.index('#define X86_SIM_L_EXEC_MOVBE_LOAD(',a);x=s[a:b]
needle='\t\t\tX86_SIM_L_STACK_WRITE( '
assert x.count(needle)==1
x=x.replace(needle,'            X86_SIM_L_STACK_VALUES_ERASE(X86_SIM_L_STACK_INDEX((__s64)(long)__x86_l_base_ptr+__x86_l_meta_disp),__x86_l_width); \\\n\t\t\tX86_SIM_L_STACK_WRITE_RAW( ',1)
s=s[:a]+x+s[b:];p.write_text(s)
