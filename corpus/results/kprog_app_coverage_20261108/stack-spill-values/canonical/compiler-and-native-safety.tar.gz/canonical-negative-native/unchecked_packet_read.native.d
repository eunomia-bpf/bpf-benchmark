/workspaces/.agent-state/kprog-lanes/C/design-only/stack-spill-values/canonical-negative-native/unchecked_packet_read.native.o: \
  unchecked_packet_read.bpf.c include/native_helpers.h \
  include/../../../micro/programs/common.h \
  /workspaces/repository/micro/programs/build-x86/kernel_offsets.h
include/native_helpers.h:
include/../../../micro/programs/common.h:
/workspaces/repository/micro/programs/build-x86/kernel_offsets.h:
