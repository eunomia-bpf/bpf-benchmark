ROOT := /workspaces/repository
HERE := /workspaces/.agent-state/kprog-lanes/C/design-only/stack-spill-values
NAMES := test_x86_stack_write_lanes_route_host test_x86_stack_arm_route_host
.PHONY: run
run:
	@set -eu; for name in $(NAMES); do cc -O2 -g -fsanitize=undefined -fno-sanitize-recover=all -I$(ROOT)/kprog/formal -I$(ROOT)/kprog/formal/oracles -I$(ROOT)/kprog/x86 -I$(ROOT)/kprog -I$(ROOT)/vendor/libbpf/src $(HERE)/existing-hosts/state-$$name.c -o $(HERE)/existing-hosts/state-$$name; $(HERE)/existing-hosts/state-$$name; done
