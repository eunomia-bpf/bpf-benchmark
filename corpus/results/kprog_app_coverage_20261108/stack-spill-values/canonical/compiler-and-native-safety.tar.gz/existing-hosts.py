from pathlib import Path
import subprocess,json,hashlib
N=Path(__file__).parent;R=Path('/workspaces/repository');O=N/'existing-hosts';O.mkdir(exist_ok=True)
names=['test_x86_stack_write_lanes_route_host.c','test_x86_helper_call_host.c','test_x86_helper_dispatch_route_host.c','test_x86_call_ret_route_host.c','test_x86_mov_memory_frame_host.c','test_x86_alu_memory_frame_host.c','test_x86_helper_abi_host.c']
rows=[]
for name in names:
 p=R/'kprog/formal/oracles'/name
 if not p.exists():
  rows.append(dict(name=name,stage='fixture-name-not-present'));continue
 text=p.read_text().replace('#include "../x86/x86_sim_local_bpf.h"','#include '+json.dumps(str(N/'source/kprog/x86/x86_sim_local_bpf.h')))
 source=O/name;source.write_text(text);exe=O/p.stem
 command=['cc','-O2','-g','-fsanitize=undefined','-fno-sanitize-recover=all','-I'+str(R/'kprog/formal'),'-I'+str(R/'kprog/formal/oracles'),'-I'+str(R/'kprog/x86'),'-I'+str(R/'kprog'),'-I'+str(R/'vendor/libbpf/src'),str(source),'-o',str(exe)]
 with(O/(p.stem+'.compile.log')).open('w')as log:q=subprocess.run(command,cwd=R/'kprog/formal',stdout=log,stderr=subprocess.STDOUT)
 row=dict(name=name,original_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),command=command,compile_exit=q.returncode)
 if q.returncode==0:
  with(O/(p.stem+'.run.log')).open('w')as log:q=subprocess.run([str(exe)],cwd=R/'kprog/formal',stdout=log,stderr=subprocess.STDOUT)
  row['run_exit']=q.returncode
 rows.append(row);(O/'outcomes.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,row.get('compile_exit'),row.get('run_exit'),flush=True)
(O/'outcomes.json').write_text(json.dumps(rows,indent=2)+'\n')
(N/'existing-hosts.exit').write_text('0\n')
