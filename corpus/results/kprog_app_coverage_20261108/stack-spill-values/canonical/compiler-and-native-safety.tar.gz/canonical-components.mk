ROOT := /workspaces/repository
HERE := /workspaces/.agent-state/kprog-lanes/C/design-only/stack-spill-values
.PHONY: micro source
micro:
	PATH=/usr/lib/llvm-18/bin:$$PATH $(MAKE) -C $(ROOT)/kprog/x86 micro-proofs-build PROOF_BUILD_DIR=$(HERE)/canonical-micro NEGATIVE_NATIVE_BUILD_DIR=$(HERE)/canonical-negative-native
source:
	cd $(ROOT)/kprog/formal && python3 tools/generate_x86_specialization_spec.py --check
	cd $(ROOT)/kprog/formal && python3 tools/generate_x86_mem_access_spec.py --check
