set -eu
D=/workspaces/.agent-state/kprog-lanes/C/kernel-kfunc-binding
R=/workspaces/repository
trap 'echo $? > "$D/build.exit"' EXIT
cp -a --reflink=auto "$R/vendor/linux-framework" "$D/source"
cp -a --reflink=auto "$R/kprog/tv/build-kernel-x86" "$D/build"
python3 "$D/prepare.py"
make -C "$D/source" O="$D/build" ARCH=x86 -j4 bzImage modules
make -C "$D/build" M="$R/kinsn/module/x86" MO="$D/module" ARCH=x86 -j4 modules
sha256sum "$D/build/arch/x86/boot/bzImage" "$D/build/vmlinux" "$D/module/bpf_x86_native_lab.ko" > "$D/outputs.sha256"
