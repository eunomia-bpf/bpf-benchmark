set -eu
D=/workspaces/.agent-state/kprog-lanes/C/kernel-kfunc-binding
cd /workspaces/repository
trap 'echo $? > "$D/check.exit"' EXIT
c++ -O2 -fsanitize=address,undefined -fno-sanitize-recover=all -Ivendor/libbpf/include/uapi "$D/check.cpp" -o "$D/check"
"$D/check"
