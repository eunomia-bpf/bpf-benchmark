#include <linux/bpf.h>
#include <cstdint>
#include <initializer_list>
#include <cstdio>
struct Kind{bool native_proof;};
static bool actual(const bpf_insn *insn,bool native){Kind x{native};auto kinsn=&x;auto op=BPF_OP(insn->code);
#include "predicate.inc"
}
int main(){uint64_t cases=0,bad=0;int offs[]={-32768,-1,0,1,32767};int imms[]={INT32_MIN,-1,0,1,INT32_MAX};
for(bool native:{false,true})for(unsigned cls:{BPF_JMP,BPF_JMP32})for(unsigned src=0;src<16;src++)for(unsigned dst=0;dst<16;dst++)for(int off:offs)for(int imm:imms){bpf_insn insn{};insn.code=cls|BPF_CALL;insn.src_reg=src;insn.dst_reg=dst;insn.off=off;insn.imm=imm;
bool canonical=cls==BPF_JMP&&src==BPF_PSEUDO_KFUNC_CALL&&dst==0&&off==0&&imm>0;bool want=native&&(src==0||canonical);if(actual(&insn,native)!=want)bad++;cases++;}
bpf_insn c{};c.code=BPF_JMP|BPF_CALL;c.src_reg=BPF_PSEUDO_KFUNC_CALL;c.imm=1;if(!actual(&c,true)||actual(&c,false))bad++;
printf("kernel proof-call identity source predicate: %llu cases, differences=%llu\n",(unsigned long long)cases,(unsigned long long)bad);return bad?1:0;}
