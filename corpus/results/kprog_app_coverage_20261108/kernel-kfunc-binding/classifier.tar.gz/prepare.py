from pathlib import Path
import os,json,hashlib
D=Path(__file__).parent
p=D/'source/kernel/bpf/verifier.c';assert p.read_bytes()==(D/'verifier.before.c').read_bytes();p.write_bytes((D/'verifier.candidate.c').read_bytes())
p=D/'build/source';assert p.is_symlink();p.unlink();p.symlink_to(D/'source',target_is_directory=True)
(D/'build/Makefile').write_text('export KBUILD_OUTPUT = '+str(D/'build')+'\ninclude '+str(D/'source/Makefile')+'\n')
p=D/'source/.git'
if p.is_file():p.unlink()
(D/'prepared.json').write_text(json.dumps({'source':str(D/'source'),'build':str(D/'build'),'verifier_sha256':hashlib.sha256((D/'verifier.candidate.c').read_bytes()).hexdigest()},indent=2)+'\n')
