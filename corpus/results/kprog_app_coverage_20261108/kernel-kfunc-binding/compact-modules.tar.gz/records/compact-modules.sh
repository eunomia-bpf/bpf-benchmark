set -eu
D=/workspaces/.agent-state/kprog-lanes/C/kernel-kfunc-binding
trap 'echo $? > "$D/compact-modules.exit"' EXIT
unshare --mount --propagation private sh "$D/inside.compact-modules.sh"
release=$(cat "$D/build/include/config/kernel.release")
depmod -b "$D/runtime-modules-compact" "$release"
python3 "$D/verify-compact-modules.py"
