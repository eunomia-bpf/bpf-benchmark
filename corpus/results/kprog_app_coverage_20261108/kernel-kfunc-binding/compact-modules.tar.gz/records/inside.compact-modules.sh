set -eu
D=/workspaces/.agent-state/kprog-lanes/C/kernel-kfunc-binding
R=/workspaces/repository
mount --bind "$D/build" "$R/kprog/tv/build-kernel-x86"
mount --bind "$D/verifier.registered.c" "$R/vendor/linux-framework/kernel/bpf/verifier.c"
make -C "$R/vendor/linux-framework" O="$R/kprog/tv/build-kernel-x86" ARCH=x86 INSTALL_MOD_PATH="$D/runtime-modules-compact" INSTALL_MOD_STRIP=1 DEPMOD=true modules_install
