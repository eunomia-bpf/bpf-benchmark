from pathlib import Path
from elftools.elf.elffile import ELFFile
from elftools.elf.relocation import RelocationSection
import hashlib,json
K=Path(__file__).parent;base=K/'runtime-modules';compact=K/'runtime-modules-compact';rows=[]
def runtime(p):
 with p.open('rb')as f:
  e=ELFFile(f);out={};rels=[]
  for sec in e.iter_sections():
   if sec['sh_flags']&2 or sec.name in ['.BTF','.BTF.ext','.modinfo','__versions']:out[sec.name]=hashlib.sha256(sec.data()).hexdigest()
   if isinstance(sec,RelocationSection):
    target=e.get_section(sec['sh_info']);symbols=e.get_section(sec['sh_link'])
    if not(target['sh_flags']&2 or target.name in ['.BTF','.BTF.ext','.modinfo','__versions']):continue
    for r in sec.iter_relocations():
     symbol=symbols.get_symbol(r['r_info_sym']);index=symbol['st_shndx'];name=e.get_section(index).name if isinstance(index,int)else index
     rels.append((target.name,r['r_offset'],r['r_info_type'],symbol.name,name,symbol['st_value'],r.entry.get('r_addend',0)))
  return dict(sections=out,relocations=sorted(rels))
for old in sorted(base.rglob('*.ko')):
 rel=old.relative_to(base);new=compact/rel;assert runtime(old)==runtime(new),str(rel)
 rows.append({'path':str(rel),'before_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'compact_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'runtime_sections_btf_relocations_equal':True,'before_bytes':old.stat().st_size,'compact_bytes':new.stat().st_size})
assert rows
(K/'compact-module-identities.json').write_text(json.dumps({'modules':len(rows),'before_bytes':sum(r['before_bytes']for r in rows),'compact_bytes':sum(r['compact_bytes']for r in rows),'scope':'standard INSTALL_MOD_STRIP=1 then normal module signing; allocated sections, BTF, modinfo, versions and normalized runtime relocations equal for every module','rows':rows},indent=2)+'\n')
print('verified compact modules',len(rows),flush=True)
