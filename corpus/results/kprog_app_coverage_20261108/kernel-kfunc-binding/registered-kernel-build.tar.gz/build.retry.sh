set -eu
D=/workspaces/.agent-state/kprog-lanes/C/kernel-kfunc-binding
R=/workspaces/repository
trap 'echo $? > "$D/build.exit"' EXIT
python3 - <<'CHECK'
import shutil
assert shutil.disk_usage('/workspaces').free > 30*1024**3
CHECK
mkdir "$D/build"
rsync -aHS --exclude='/.modules-install.*/' --exclude='/modules-install/' --exclude='/.virtme_mods/' --exclude='/vmlinux' --exclude='/vmlinux.o' --exclude='/vmlinux.unstripped' --exclude='/.tmp_vmlinux*' "$R/kprog/tv/build-kernel-x86/" "$D/build/"
unshare --mount --propagation private sh "$D/inside.retry.sh"
sha256sum "$D/build/arch/x86/boot/bzImage" "$D/build/vmlinux" "$D/module/bpf_x86_native_lab.ko" > "$D/outputs.sha256"
