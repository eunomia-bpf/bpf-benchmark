set -eu
D=/workspaces/.agent-state/kprog-lanes/C/kernel-kfunc-binding
R=/workspaces/repository
mount --bind "$D/build" "$R/kprog/tv/build-kernel-x86"
mount --bind "$D/verifier.registered.c" "$R/vendor/linux-framework/kernel/bpf/verifier.c"
make -C "$R/vendor/linux-framework" O="$R/kprog/tv/build-kernel-x86" ARCH=x86 -j4 bzImage modules_prepare
make -C "$R/kprog/tv/build-kernel-x86" M="$R/kinsn/module/x86" MO="$D/module" ARCH=x86 -j4 modules
