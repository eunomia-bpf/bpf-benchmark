set -eu
D=/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/tetragon-assets
trap 'echo $? > "$D/build.exit"' EXIT
docker build -f "$D/Dockerfile" -t bpf-benchmark/kprog-five-step-tetragon:c-current "$D"
docker image inspect bpf-benchmark/kprog-five-step-tetragon:c-current > "$D/image.json"
