set -eu
D=/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/final-modules
trap 'echo $? > "$D/build.exit"' EXIT
taskset -c 8-11 unshare --mount --propagation private sh "$D/inside.sh"
