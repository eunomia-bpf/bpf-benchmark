from pathlib import Path
import os,select,subprocess,json,hashlib,sys
D=Path(__file__).parent.parent;F=Path(__file__).parent;A=D/'cilium-final-modules';R=Path('/workspaces/repository')
def wait(path):
 try:
  fd=os.pidfd_open(int(path.read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
wait(F/'build.pid')
rc=int((F/'build.exit').read_text())
if rc:raise SystemExit('incremental modules build exit '+str(rc))
old=json.loads((F/'before.json').read_text());old['after_kernel_sha256']=hashlib.sha256((D.parent/'build/arch/x86/boot/bzImage').read_bytes()).hexdigest();old['after_vmlinux_sha256']=hashlib.sha256((D.parent/'build/vmlinux').read_bytes()).hexdigest();old['installed_modules']=len(list((F/'install').rglob('*.ko')));(F/'module-epoch.json').write_text(json.dumps(old,indent=2)+'\n')
image='bpf-benchmark/kprog-design-final-modules:c-20261108'
with(F/'image.log').open('wb')as log:q=subprocess.run(['docker','build','-f',str(F/'Dockerfile'),'-t',image,str(F)],stdout=log,stderr=subprocess.STDOUT)
(F/'image.exit').write_text(str(q.returncode)+'\n');q.check_returncode();(F/'image.json').write_bytes(subprocess.check_output(['docker','image','inspect',image]))
wait(D/'queue.pid');wait(D/'safety-retry.pid')
with(F/'cilium.log').open('wb')as log:q=subprocess.run(['make','-f',str(A/'Makefile'),'corpus','STATE='+str(A),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS=cilium/agent','SAMPLES=1','WORKLOAD_DURATION=2'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(F/'cilium.exit').write_text(str(q.returncode)+'\n')
with(F/'collect.log').open('wb')as log:p=subprocess.run([sys.executable,str(D/'collect.py'),'cilium-final-modules'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
(F/'collect.exit').write_text(str(p.returncode)+'\n')
