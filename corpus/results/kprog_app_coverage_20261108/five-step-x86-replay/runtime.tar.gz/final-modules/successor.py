from pathlib import Path
import os,select,subprocess,json,hashlib,sys
D=Path(__file__).parent.parent;F=Path(__file__).parent;A=D/'cilium-final-modules';R=Path('/workspaces/repository')
def wait(path):
 try:
  fd=os.pidfd_open(int(path.read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
wait(F/'build.pid')
rc=int((F/'build.exit').read_text())
if rc:raise SystemExit('incremental modules build exit '+str(rc))
old=json.loads((F/'before.json').read_text());old['after_kernel_sha256']=hashlib.sha256((D.parent/'build/arch/x86/boot/bzImage').read_bytes()).hexdigest();old['after_vmlinux_sha256']=hashlib.sha256((D.parent/'build/vmlinux').read_bytes()).hexdigest();old['installed_modules']=len(list((F/'install').rglob('*.ko')));(F/'module-epoch.json').write_text(json.dumps(old,indent=2)+'\n')
image='bpf-benchmark/kprog-design-final-modules:c-20261108'
with(F/'image.log').open('wb')as log:q=subprocess.run(['docker','build','-f',str(F/'Dockerfile'),'-t',image,str(F)],stdout=log,stderr=subprocess.STDOUT)
(F/'image.exit').write_text(str(q.returncode)+'\n');q.check_returncode();(F/'image.json').write_bytes(subprocess.check_output(['docker','image','inspect',image]))
wait(D/'queue.pid');wait(D/'safety-retry.pid')
import threading,time
state=F/'broker'
with(F/'broker.log').open('wb')as log:server=subprocess.Popen(['taskset','-c','20-23',sys.executable,str(D/'frozen-python/trusted_compile.py'),'serve','--scope',str(D),'--state',str(state),'--clang','/usr/lib/llvm-18/bin/clang'],stdout=log,stderr=subprocess.STDOUT)
(F/'broker.pid').write_text(str(server.pid)+'\n')
def monitor():
 rc=server.wait()
 if not(state/'STOP').exists():(state/'failed.json').write_text(json.dumps(dict(error='compiler exited',returncode=rc))+'\n')
threading.Thread(target=monitor,daemon=True).start()
try:
 while not(state/'ready.json').exists():
  if server.poll()is not None:raise RuntimeError('compiler startup exit '+str(server.returncode))
  time.sleep(.1)
 for key,app in [('cilium-final-modules','cilium/agent'),('tracee-final-modules','tracee/monitor')]:
  a=D/key
  with(F/(key+'.log')).open('wb')as log:q=subprocess.run(['make','-f',str(a/'Makefile'),'corpus','STATE='+str(a),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS='+app,'SAMPLES=1','WORKLOAD_DURATION=2'],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  (F/(key+'.exit')).write_text(str(q.returncode)+'\n')
  with(F/(key+'.collect.log')).open('wb')as log:p=subprocess.run([sys.executable,str(D/'collect.py'),key],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  (F/(key+'.collect.exit')).write_text(str(p.returncode)+'\n')
finally:
 (state/'STOP').write_text('matched module cohort closed\n');server.wait()
(F/'successor.exit').write_text('0\n')
