ROOT := /workspaces/repository
HERE := /workspaces/.agent-state/kprog-lanes/C/design-only
.PHONY: safety-build safety-guest safety
safety-build:
	PATH=/usr/lib/llvm-18/bin:$(PATH) python3 $(HERE)/safety/check.py build
safety-guest:
	@mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug
	insmod $(HERE)/module/bpf_x86_native_lab.ko
	PATH=/usr/lib/llvm-18/bin:$(PATH) python3 $(HERE)/safety/check.py check
safety:
	taskset -c 20-23 vng --run $(HERE)/build/arch/x86/boot/bzImage --cwd $(ROOT) --rwdir $(ROOT) --rwdir $(HERE) --overlay-rwdir /tmp --overlay-rwdir /run --disable-monitor --cpus 4 --memory 4G --append 'loglevel=4 panic=30 oops=panic' --exec 'make -f $(HERE)/Makefile safety-guest'

.PHONY: safety-final-guest safety-final
safety-final-guest:
	@mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug
	insmod $(HERE)/module/bpf_x86_native_lab.ko
	PATH=/usr/lib/llvm-18/bin:$(PATH) python3 $(HERE)/safety/check.py check --out $(HERE)/safety/final
safety-final:
	taskset -c 20-23 vng --run $(HERE)/build/arch/x86/boot/bzImage --cwd $(ROOT) --rwdir $(ROOT) --rwdir $(HERE) --overlay-rwdir /tmp --overlay-rwdir /run --disable-monitor --cpus 4 --memory 4G --append 'loglevel=4 panic=30 oops=panic' --exec 'make -f $(HERE)/Makefile safety-final-guest'

.PHONY: safety-complete-guest safety-complete
safety-complete-guest:
	@mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug
	insmod $(HERE)/module/bpf_x86_native_lab.ko
	PATH=/usr/lib/llvm-18/bin:$(PATH) python3 $(HERE)/safety/check.py check --out /workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/safety
safety-complete:
	taskset -c 20-23 vng --run $(HERE)/build/arch/x86/boot/bzImage --cwd $(ROOT) --rwdir $(ROOT) --rwdir $(HERE) --overlay-rwdir /tmp --overlay-rwdir /run --disable-monitor --cpus 4 --memory 4G --append 'loglevel=4 panic=30 oops=panic' --exec 'make -f /workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/checks.Makefile safety-complete-guest'
