from pathlib import Path
import subprocess,shutil,json,os,traceback
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository')
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(phase=phase,**kw),indent=2)+'\n')
try:
 save('building')
 with(G/'build.log').open('w')as f:p=subprocess.run(['taskset','-c','8-11','make','-f',str(G/'Makefile'),'build'],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'build.exit').write_text(str(p.returncode)+'\n');p.check_returncode()
 for rel in ['kprog/x86/native_lab/native_link/target/release/native-link','kprog/libnativeloader/build/trusted-native-loader','kprog/libnativeloader/build/libnative_loader.so']:shutil.copy2(R/rel,G/'source'/rel)
 save('component')
 with(G/'component.log').open('w')as f:p=subprocess.run(['taskset','-c','8-11','unshare','--mount','--propagation','private','python3',str(G/'mount.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'component.exit').write_text(str(p.returncode)+'\n');save('finished',component_exit=p.returncode)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
