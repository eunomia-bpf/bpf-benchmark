from pathlib import Path
import sys,json,traceback
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');sys.path.insert(0,str(R/'kprog/x86'))
from trusted_specializer import specialize
out=[]
for row in json.loads((G/'component-inputs.json').read_text()):
 p=Path(row['input']);result=dict(row)
 try:
  artifacts=specialize((p/'input.native.o').read_bytes(),row['program'],json.loads((p/'metadata.json').read_text()),p/'generated-final',R/'kprog/x86/native_lab/native_link/target/release/native-link');result.update(stage='compiled',artifacts=artifacts)
 except Exception as e:
  result.update(stage='generation_or_compile_failure',error=str(e),traceback=traceback.format_exc())
 out.append(result);(G/'component-outcomes.json').write_text(json.dumps(out,indent=2)+'\n');print(row['file'],row['program'],result['stage'],flush=True)
