from pathlib import Path
import subprocess,json,hashlib,tarfile,sys,datetime,traceback,shutil
G=Path(__file__).resolve().parent;C=G.parent.parent;R=Path('/workspaces/repository');O=R/'corpus/results/kprog_app_coverage_20261108/tracee-clamp-register'
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(phase=phase,**kw),indent=2)+'\n')
try:
 save('paired_compile')
 with(G/'build.log').open('w')as f:p=subprocess.run(['taskset','-c','8-11','unshare','--mount','--propagation','private','sh',str(G/'build.sh')],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 rc=p.returncode;(G/'build.exit').write_text(str(rc)+'\n');j=dict(make_exit=rc,source_commit=json.loads((G/'source-publication.json').read_text())['commit'],source_files={str(p.relative_to(G/'tree')):hashlib.sha256(p.read_bytes()).hexdigest()for p in(G/'tree').rglob('*')if p.is_file()},native_objects={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in(G/'stage').glob('*.native.o')},bpf_object_sha256=hashlib.sha256((R/'vendor/build/.tracee-build/none/x86/dist/tracee.bpf.o').read_bytes()).hexdigest(),binary_sha256=hashlib.sha256((R/'vendor/build/x86/tracee/bin/tracee').read_bytes()).hexdigest());O.mkdir(exist_ok=True);(O/'compile.json').write_text(json.dumps(j,indent=2)+'\n');(O/'README.md').write_text('# Paired Tracee existing-clamp register lifetime\n\nSource '+j['source_commit']+' keeps the runtime size value through empty read/write register asm before four original update_min operations. Each original limit/guard and earlier checked string-offset operation retains its meaning. This closes the ordinary-C elimination mechanism exposed by the paired-source baseline4d0306168, whose first verifier frontier is bpf_probe_read R2 unbounded. Both native/JIT frontends read the identical selected C tree, and the embedded Tracee binary consumes its JIT BPF. Actual paired Makeexit'+str(rc)+'. Complete source/compiler output identities accompany compile-inputs.tar.gz. Whole original application/workload follows the current serial chain. Runtime admission additions0.\n')
 with tarfile.open(O/'compile-inputs.tar.gz','w:gz')as tf:
  for n in ['Makefile','build.sh','controller.py','buffer.before.h','buffer.after.h','tree','build.log','build.exit']:tf.add(G/n,arcname=n)
 if rc==0:
  image=G/'image';image.mkdir();(image/'native').mkdir()
  for p in(G/'stage').iterdir():
   if p.name.endswith('.native.o')or p.name=='manifest.json':shutil.copy2(p,image/'native'/p.name)
  shutil.copy2(R/'vendor/build/x86/tracee/bin/tracee',image/'tracee');shutil.copy2(R/'vendor/build/.tracee-build/none/x86/dist/tracee.bpf.o',image/'tracee.bpf.o');shutil.copytree(R/'vendor/build/.tracee-build/none/x86/dist/lsm_support',image/'lsm_support')
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Record Tracee paired source compilation with preserved size registers',G/'publication.json');save('finished',commit=commit,make_exit=rc)
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR A/R/V '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': PUSHED '+commit+' Tracee existing-clamp register source '+j['source_commit']+' paired Makeexit'+str(rc)+'. Original size limits/guards/stringoffset reload retained, full source/native/BPF/embedded identities recorded. Original workload follows serial queue. Runtime admission additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
