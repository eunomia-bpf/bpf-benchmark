set -eu
cd /workspaces/repository
mount --bind /workspaces/.agent-state/kprog-lanes/C/design-only/tracee-clamp-register/tree /workspaces/repository/vendor/bpf/tracee/pkg/ebpf/c
mount --bind /workspaces/.agent-state/kprog-lanes/C/design-only/tracee-clamp-register/tree /workspaces/repository/vendor/repos/tracee/pkg/ebpf/c
make -f /workspaces/.agent-state/kprog-lanes/C/design-only/tracee-clamp-register/Makefile native baseline binary
