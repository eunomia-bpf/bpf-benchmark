from pathlib import Path
import os,sys,json,datetime,traceback,subprocess,tarfile,select,signal
G=Path(__file__).resolve().parent;C=G.parent.parent;R=Path('/workspaces/repository');Q=C/'design-only/kernel-selftests-dynptr-family';O=R/'corpus/results/kprog_app_coverage_20261108/kernel-selftests-expanded';TETRA=2297049;held=False
sys.path.insert(0,str(C));from publish_owned import publish
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(phase=phase,**kw),indent=2)+'\n')
def notice(s):
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR A/V/R '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': '+s+'\n')
try:
 O.mkdir(exist_ok=True);(O/'launch.json').write_bytes((G/'launch.json').read_bytes());(O/'README.md').write_text('# Expanded original x86 kernel C entry cohort\n\nThe current common catalog contains317 compiled native objects and315 present C entries, compared with the previous239-entry runtime cohort. This epoch captures all315 existing original native objects and all1917 catalog rows. Every native/source/annotation byte retains its origin. All50 whole original resource BPF files compile with the existing60e37 wrapper. Captured generic named-helper/RAW context source is0818f5677. Original BPF object programs use autoload=false for native resource preparation, native source_prog_id0 and load-only submission; native executions0.\n\nBefore the entire native cohort, the original published verifier_lsm no_null_check and null_check BPF programs are each loaded by libbpf with every sibling autoload=false. Their stock load result, hook target, original object identity and verifier log are retained. This original BPF baseline has attachments0 and executions0. The full315 native table includes both LSM cases and all existing native-compiled C entries. Actual native/P/B/context and original kernel annotations supply their own domains; the paired-kernel LSM nullability question remains explicit.\n\nThe20-23/12GiB guest follows the existing239 dynptr replay and precedes queued whole Tetragon, following priority2a. The existing Tetragon waiter keeps its captured source and resumes after this actual guest closes. Every outcome remains recorded, including generation/compiler/resource and installed failure findings. Runtime admission additions0.\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz')as tf:
  for n in ['launch.json','original-programs.json','table','source','resources.py','resource.log','resource.exit','resource-compile.json','Makefile','mount.py','baseline.py','controller.py','testmod-source','testmod-build']:tf.add(G/n,arcname=n)
 commit=publish([str((O/n).relative_to(R))for n in ['README.md','launch.json','launch-inputs.tar.gz']],'Run every compiled x86 kernel C entry with original LSM baseline',G/'launch-publication.json')
 os.kill(TETRA,signal.SIGSTOP);held=True;save('queued_after_original239_before_tetragon',launch_publication=commit);notice('PUSHED '+commit+' expanded315 native entries/all50resources compiled0, complete original annotations. Original stock LSM BPF/loadonly baseline joins matched native cases. Priority2a guest follows existing239; paused only idle Tetragon waiter2297049 and resumes it after this actual guest. Runtime admission additions0.')
 try:
  fd=os.pidfd_open(int((Q/'controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 save('running',launch_publication=commit)
 with(G/'run.log').open('w')as f:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1','PYTHONPYCACHEPREFIX':str(G/'pycache')})
 (G/'run.exit').write_text(str(p.returncode)+'\n')
 # Follow an actual retained guest before releasing the serial lane resources.
 for proc in Path('/proc').iterdir():
  if proc.name.isdigit():
   try:cmd=(proc/'cmdline').read_bytes().split(b'\0')
   except (FileNotFoundError,ProcessLookupError):continue
   if cmd and cmd[0].endswith(b'qemu-system-x86_64')and any(('path='+str(G)+',').encode()in arg for arg in cmd):
    try:
     fd=os.pidfd_open(int(proc.name));select.select([fd],[],[]);os.close(fd)
    except ProcessLookupError:pass
 report=dict(make_exit=p.returncode,native_execution_count=0,original_stock_lsm=json.loads((G/'out/original-stock-lsm.json').read_text())if(G/'out/original-stock-lsm.json').exists()else[],counts=json.loads((G/'out/submissions.json').read_text())['counts']if(G/'out/submissions.json').exists()else{})
 paths=[]
 for n in ['submissions.json','original-stock-lsm.json']:
  if(G/'out'/n).exists():(O/n).write_bytes((G/'out'/n).read_bytes());paths.append(O/n)
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 with tarfile.open(O/'raw.tar.gz','w:gz')as tf:
  for n in ['out','tmp','run.log','run.exit']:tf.add(G/n,arcname=n)
 paths.append(O/'raw.tar.gz');commit=publish([str(p.relative_to(R))for p in paths],'Record expanded x86 kernel C and original stock LSM outcomes',G/'result-publication.json');save('finished',commit=commit,**report);notice('PUSHED '+commit+' original315 x86 actual '+repr(report['counts'])+' and original stock LSM baseline '+repr([(r['program'],r['stage'])for r in report['original_stock_lsm']])+'. Native executions0; runtime admission additions0.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
finally:
 if held:os.kill(TETRA,signal.SIGCONT)
