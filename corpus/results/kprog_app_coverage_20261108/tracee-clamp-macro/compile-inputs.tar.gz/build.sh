set -eu
cd /workspaces/repository
mount --bind /workspaces/.agent-state/kprog-lanes/C/design-only/tracee-clamp-macro/tree /workspaces/repository/vendor/bpf/tracee/pkg/ebpf/c
mount --bind /workspaces/.agent-state/kprog-lanes/C/design-only/tracee-clamp-macro/tree /workspaces/repository/vendor/repos/tracee/pkg/ebpf/c
make -f /workspaces/.agent-state/kprog-lanes/C/design-only/tracee-clamp-macro/Makefile native baseline binary
