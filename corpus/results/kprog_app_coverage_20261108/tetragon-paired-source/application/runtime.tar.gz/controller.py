from pathlib import Path
from datetime import datetime,timezone
import subprocess,sys,json,os,select,hashlib,tarfile,shutil,traceback
G=Path(__file__).resolve().parent;C=G.parent.parent.parent;R=Path('/workspaces/repository');Q=C/'design-only/kernel-selftests-dynptr-family';O=R/'corpus/results/kprog_app_coverage_20261108/tetragon-paired-source/application'
def notice(s):
 msg='\n- LOCAL C FOR R/A/V '+datetime.now(timezone.utc).isoformat()+': '+s+'\n'
 for p in [C.parent/'COORDINATION.md',C/'last.md']:
  with p.open('a')as f:f.write(msg)
def save(state,**kw):(G/'status.json').write_text(json.dumps(dict(state=state,**kw),indent=2)+'\n')
try:
 save('queued_after_original239_dynptr')
 try:
  fd=os.pidfd_open(int((Q/'controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 B=C/'design-only/tetragon-paired-source'
 try:
  fd=os.pidfd_open(int((B/'controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 result=json.loads((B/'status.json').read_text())
 if result.get('make_exit')!=0:raise RuntimeError('Paired Tetragon compiler outcome requires continuation: '+repr(result))
 (G/'image/native').mkdir(exist_ok=True);(G/'image/bpf').mkdir(exist_ok=True)
 for path in (B/'stage').iterdir():
  if path.name.endswith('.native.o') or path.name=='manifest.json':shutil.copy2(path,G/'image/native'/path.name)
 for path in (B/'bpf/objs').glob('*.o'):shutil.copy2(path,G/'image/bpf'/path.name)
 notice('Packaging paired x86 Tetragon source cccd71558 plus A counted path/local length edits, actual current-kernel BTF and complete shared C tree. Current RAW/dynptr simulator0818 source captured; kernel/module retained. Runtime admission additions0.')
 with(G/'image.log').open('w')as f:p=subprocess.run(['make','-f',str(G/'Makefile'),'image'],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'image.exit').write_text(str(p.returncode)+'\n');p.check_returncode();image=subprocess.check_output(['docker','image','inspect','--format','{{.Id}}','bpf-benchmark/kprog-five-step-tracee:c-runner'],text=True).strip();files=[p for p in(G/'source').rglob('*')if p.is_file()]+[G/'clang',G/'guest.py',G/'Makefile']+[p for p in(G/'image').rglob('*')if p.is_file()];inputs=dict(utc=datetime.now(timezone.utc).isoformat(),app_source_commit='cccd71558b756369b52b2aacb1e961eaa513096d',canonical_ghost_commit='87ab19c5c9b9bed3562b7da3bd46d42c211f3a8b',image=image,files={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in files});(G/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');command=['make','-f',str(G/'Makefile'),'corpus','STATE='+str(G),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS=tetragon/observer','SAMPLES=1','WORKLOAD_DURATION=2'];(G/'command.json').write_text(json.dumps(command,indent=2)+'\n');save('running',image=image);notice('Whole paired-source x86 Tetragon START20-23/12GiB source cccd71558 with actual credential namespace, counted traversal and checked local length; image'+image+'. Original application program selection and workload retained; actual counters/errors accompany every terminal stage.')
 with(G/'run.log').open('w')as f:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py'),*command],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'run.exit').write_text(str(p.returncode)+'\n')
 with(G/'collect.log').open('w')as f:q=subprocess.run([sys.executable,str(G.parent/'collect.py'),G.name],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'collect.exit').write_text(str(q.returncode)+'\n');q.check_returncode();I=G.parent/'collected'/G.name;O.mkdir(parents=True,exist_ok=True)
 for path in I.iterdir():
  if path.is_file():shutil.copy2(path,O/path.name)
 j=json.loads((I/'coverage.json').read_text());work=[dict(application=x['application'],status=x['app']['status'],error=x['app'].get('error'),baseline=x['app'].get('baseline'),post_rejit=x['app'].get('post_rejit'))for x in j['results']];(O/'work.json').write_text(json.dumps(work,indent=2)+'\n');result=dict(make_exit=p.returncode,native_requests=j['native_requests'],generated=j['generated'],compiled=j['compiled'],installed=j['installed'],failed=j['failed'],work=[dict(application=x['application'],status=x['status'],error=(x['error']or'').splitlines()[0]if x['error']else'')for x in work],inputs=inputs);(O/'summary.json').write_text(json.dumps(result,indent=2)+'\n');(O/'README.md').write_text('# Whole paired-source x86 Tetragon\n\nThe complete original tetragon/observer startup/workload consumes paired native/JIT C sources and current-kernel BTF layouts. Source edits5d15225c7/a9abb84e5/cccd71558 retain existing path bounds and local capped/masked length and record task credential user namespace in user_inum. The source-change ledger records that payload difference and every prior selected/upstream C-tree difference. Current generic RAW context and dynptr named helpers are captured in0818f5677 model source. Actual G/C/I/failed'+repr((j['generated'],j['compiled'],j['installed'],j['failed']))+'; Makeexit'+str(p.returncode)+'. Original workload, program census, complete native/B/compiler/verifier/service and work records accompany this report. Runtime admission additions0.\n')
 with tarfile.open(O/'runtime.tar.gz','w:gz')as tf:
  for name in ['Makefile','guest.py','clang','mount.py','source','image','image.log','image.exit','inputs.json','command.json','controller.py','run.log','run.exit','collect.log','collect.exit','summary.json']:tf.add(G/name,arcname=name)
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Record whole paired-source x86 Tetragon outcomes',G/'publication.json');save('finished',commit=commit,result={k:result[k]for k in ['make_exit','native_requests','generated','compiled','installed','failed','work']});notice('PUSHED '+commit+' whole paired-source x86 Tetragon G/C/I/failed'+repr((j['generated'],j['compiled'],j['installed'],j['failed']))+' actualwork'+repr(result['work'])+'.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
