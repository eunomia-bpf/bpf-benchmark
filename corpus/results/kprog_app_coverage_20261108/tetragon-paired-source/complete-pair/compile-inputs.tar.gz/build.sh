set -eu
cd /workspaces/repository
mount --bind /workspaces/.agent-state/kprog-lanes/C/design-only/tetragon-paired-source/tree /workspaces/repository/vendor/bpf/tetragon/bpf
make -f /workspaces/.agent-state/kprog-lanes/C/design-only/tetragon-paired-source/Makefile paired
