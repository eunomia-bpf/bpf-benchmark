#ifndef KPROG_FORMAL_GENERATED_X86_REG_READ_H
#define KPROG_FORMAL_GENERATED_X86_REG_READ_H
#if defined(__BPF__) || defined(__bpf__)
#define KPROG_X86_READ_REG_AT(VALUE, WIDTH, BYTE_SHIFT) \
 ({ __u64 __narrow=(VALUE) >> ((WIDTH)==X86_WIDTH_8 ? (BYTE_SHIFT) : 0U); \
    if ((WIDTH)==X86_WIDTH_8) __narrow=(__u8)__narrow; \
    else if ((WIDTH)==X86_WIDTH_16) __narrow=(__u16)__narrow; \
    else if ((WIDTH)==X86_WIDTH_32) __narrow=(__u32)__narrow; \
    __narrow; })
#else
#define KPROG_X86_READ_REG_AT(VALUE, WIDTH, BYTE_SHIFT) \
 KPROG_X86_APPLY_WIDTH((VALUE) >> ((WIDTH)==X86_WIDTH_8 ? (BYTE_SHIFT) : 0U), (WIDTH))
#endif
#endif
