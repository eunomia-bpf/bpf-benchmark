#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 256U
typedef unsigned char __u8; typedef unsigned short __u16;
typedef unsigned int __u32; typedef unsigned long long __u64;
typedef signed char __s8; typedef signed short __s16;
typedef signed int __s32; typedef signed long long __s64;
#define __always_inline inline
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
#include <stdio.h>
#define STATE() X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); \
 struct x86_sim_xdp_abi __x86_sim_abi={0}; \
 struct __sk_buff *__x86_sim_skb_ctx=0
static __u32 stack_return(__u64 base, __s64 offset) {
 STATE(); __x86_native_stack_base=base;
 __x86_rax.ptr=X86_SIM_L_STACK_PTR(offset); __x86_rax_tag=X86_SIM_TAG_STACK;
 X86_SIM_X86_RET();
}
static int pointer_load(__u8 op, __u8 dst, __u64 base, __u64 immediate) {
 STATE(); __x86_native_stack_base=base;
 X86_SIM_L_EXEC_PTR_LOAD(op,dst,0,immediate);
 return X86_SIM_L_READ_REG(dst)==immediate &&
 X86_SIM_L_REG_TAG(dst)==(op==X86_OP_MOV_LOAD_MAP_PTR?5:7);
}
int main(void) {
 const __u64 bases[]={0,0x1234567887654321ULL,0xfffffffffffffff0ULL};
 const __u64 values[]={0,1,0x80000000ULL,0xfedcba9876543210ULL};
 unsigned failures=0,cases=0;
 for(unsigned b=0;b<3;b++) {
  for(__s64 off=-256;off<=0;off+=8) {
   cases++;failures+=stack_return(bases[b],off)!=(__u32)(bases[b]+(__u64)off);
  }
  for(unsigned op=0;op<2;op++)for(unsigned dst=0;dst<16;dst++)
   for(unsigned v=0;v<4;v++) {
    cases++;failures+=!pointer_load(op?X86_OP_MOV_LOAD_HELPER_ID:X86_OP_MOV_LOAD_MAP_PTR,dst,bases[b],values[v]);
   }
 }
 printf("native numeric coordinate: %u cases, %u differences\n",cases,failures);
 return failures?1:0;
}
