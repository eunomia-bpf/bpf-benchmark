from pathlib import Path
import os,select,subprocess
D=Path(__file__).parent
try:
 fd=os.pidfd_open(int((D/'queue.pid').read_text()));select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
with (D/'safety-retry.log').open('wb')as log:q=subprocess.run(['make','-f',str(D/'checks.Makefile'),'safety-complete'],cwd='/workspaces/repository',stdout=log,stderr=subprocess.STDOUT)
(D/'safety-retry.exit').write_text(str(q.returncode)+'\n')
