from pathlib import Path
from datetime import datetime,timezone
import subprocess,sys,json,os,select,threading,time
D=Path(__file__).parent;R=Path('/workspaces/repository');os.chdir(R)
def run(name,command):
 with (D/(name+'.log')).open('wb')as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 (D/(name+'.exit')).write_text(str(p.returncode)+'\n');print(name,p.returncode,flush=True)
 return p.returncode
run('micro-build',['taskset','-c','20-23','make','-C','kprog/x86','micro-proofs-build','CLANG=clang-18','PROOF_BUILD_DIR='+str(D/'micro-build'),'NEGATIVE_NATIVE_BUILD_DIR='+str(D/'negative-native')])
run('safety',['make','-f',str(D/'checks.Makefile'),'safety-complete'])
with (D/'broker.log').open('wb')as log:server=subprocess.Popen(['taskset','-c','20-23',sys.executable,str(D/'frozen-python/trusted_compile.py'),'serve','--scope',str(D),'--state',str(D/'broker'),'--clang','/usr/lib/llvm-18/bin/clang'],stdout=log,stderr=subprocess.STDOUT)
(D/'broker.pid').write_text(str(server.pid)+'\n')
def watch():
 rc=server.wait()
 if not (D/'broker/STOP').exists():(D/'broker/failed.json').write_text(json.dumps(dict(error='trusted compiler exited',returncode=rc))+'\n')
threading.Thread(target=watch,daemon=True).start()
try:
 while not (D/'broker/ready.json').exists():
  if server.poll() is not None:raise RuntimeError('compiler startup exit '+str(server.returncode))
  time.sleep(.1)
 for key,app in json.loads((D/'plan.json').read_text())['apps']:
  a=D/key
  run(key,['make','-f',str(a/'Makefile'),'corpus','STATE='+str(a),'CPUS=20-23','VM_CPUS=8','VM_MEM=12G','APPS='+app,'SAMPLES=1','WORKLOAD_DURATION=2'])
finally:
 (D/'broker/STOP').write_text('application cohort closed\n');server.wait()
(D/'queue.exit').write_text('0\n')
