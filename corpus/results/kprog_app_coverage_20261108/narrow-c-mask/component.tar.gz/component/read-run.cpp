#include <llvmbpf.hpp>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>
#include <array>
#define DECL(W,S) extern "C" uint64_t read_##W##_##S(const uint64_t *);
DECL(0,0) DECL(0,8) DECL(1,0) DECL(1,8) DECL(2,0) DECL(2,8) DECL(4,0) DECL(4,8) DECL(8,0) DECL(8,8)
struct Case{const char *name;unsigned width,shift;uint64_t(*host)(const uint64_t*);};
#define CASE(W,S) {"read_" #W "_" #S,W,S,read_##W##_##S}
Case cases[]={CASE(0,0),CASE(0,8),CASE(1,0),CASE(1,8),CASE(2,0),CASE(2,8),CASE(4,0),CASE(4,8),CASE(8,0),CASE(8,8)};
int main(int argc,char**argv){if(argc!=2)return 2;std::string root=argv[1];std::ofstream bad(root+"/mismatches.jsonl");uint64_t total=0,fail=0;
 for(auto &c:cases){std::ifstream in(root+"/"+c.name+".bin",std::ios::binary);std::vector<uint8_t>code((std::istreambuf_iterator<char>(in)),{});if(code.empty())return 3;
  bpftime::llvmbpf_vm vm;if(vm.load_code(code.data(),code.size())<0||!vm.compile()){std::cerr<<vm.get_error_message()<<'\n';return 4;}
  uint64_t state=0xfedcba9876543210ULL;
  for(unsigned i=0;i<65536;++i){state=state*6364136223846793005ULL+1442695040888963407ULL;
   uint64_t raw=i==0?0:i==1?~0ULL:i==2?0xffffffff00000000ULL:i==3?0x8000000080000000ULL:i==4?0x800080ffULL:state, before=raw,want=0;
   unsigned n=c.width?c.width:8,shift=c.width==1?c.shift:0;
   for(unsigned j=0;j<n;++j)want|=uint64_t(uint8_t(raw>>(shift+8*j)))<<(8*j);
   uint64_t got=0,host=c.host(&raw);if(vm.exec(&raw,sizeof(raw),got)<0)return 5;
   if(got!=want||host!=want||raw!=before){++fail;bad<<"{\"form\":\""<<c.name<<"\",\"input\":"<<before<<",\"expected\":"<<want<<",\"jit\":"<<got<<",\"host\":"<<host<<"}\n";}
   ++total;
  }
 }
 std::cout<<"generic register read BPF JIT/host/byte oracle: "<<total<<" observations, differences="<<fail<<'\n';return fail?1:0;
}
