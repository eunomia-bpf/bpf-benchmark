typedef unsigned long long __u64;typedef unsigned int __u32;typedef unsigned short __u16;typedef unsigned char __u8;
#define X86_WIDTH_8 1U
#define X86_WIDTH_16 2U
#define X86_WIDTH_32 4U
#define X86_WIDTH_64 8U
#define KPROG_X86_APPLY_WIDTH(V,W) ((W)==1?(__u8)(V):(W)==2?(__u16)(V):(W)==4?(__u32)(V):(V))
#include "read.h"
#define F(W,S) __u64 read_##W##_##S(const __u64 *p) {return KPROG_X86_READ_REG_AT(*p,W,S);}
F(0,0) F(0,8) F(1,0) F(1,8) F(2,0) F(2,8) F(4,0) F(4,8) F(8,0) F(8,8)
