set -eu
D=/workspaces/.agent-state/kprog-lanes/C/narrow-c-mask
cd /workspaces/repository
trap 'echo $? > "$D/checks.exit"' EXIT
/usr/lib/llvm-18/bin/clang -O3 -mcpu=v4 -target bpf -c "$D/reads.c" -o "$D/reads.o"
cc -O2 -fsanitize=undefined -fno-sanitize-recover=all -c "$D/reads.c" -o "$D/read-host.o"
c++ -O2 -std=c++20 -fsanitize=undefined -fno-sanitize-recover=all "$D/read-run.cpp" "$D/read-host.o" runner/build-llvmbpf/CMakeFiles/micro_exec.dir/workspaces/repository/vendor/llvmbpf/src/*.o -Ivendor/llvmbpf/include -Ivendor/llvmbpf/src -L/usr/lib/llvm-18/lib -lLLVM-18 -lspdlog -lfmt -ldl -pthread -o "$D/read-check"
python3 "$D/read-extract.py"
"$D/read-check" "$D"
/usr/lib/llvm-18/bin/clang -g -O3 -mcpu=v4 -target bpf -mllvm -bpf-stack-size=4096 -D__TARGET_ARCH_x86 -Ikprog/x86 -Ikprog/formal/generated -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c "$D/tracee.bpf.c" -o "$D/tracee.bpf.o"
