from pathlib import Path
from elftools.elf.elffile import ELFFile
import struct,json,hashlib
D=Path(__file__).parent;rows=[]
with (D/'reads.o').open('rb')as f:
 e=ELFFile(f)
 for s in e.get_section_by_name('.symtab').iter_symbols():
  if s['st_info']['type']!='STT_FUNC':continue
  assert s.name.startswith('read_');code=e.get_section(s['st_shndx']).data()[s['st_value']:s['st_value']+s['st_size']]
  (D/(s.name+'.bin')).write_bytes(code);ins=[struct.unpack('<BBhi',code[i:i+8])for i in range(0,len(code),8)]
  assert all(op[0]in[0x79,0x61,0xbf,0xbc,0x57,0x67,0x77,0x95,0x18,0]for op in ins),(s.name,ins)
  rows.append(dict(name=s.name,instructions=ins,sha256=hashlib.sha256(code).hexdigest()))
assert len(rows)==10;(D/'bytecode.json').write_text(json.dumps(rows,indent=2)+'\n')
