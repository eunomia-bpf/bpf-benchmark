set -eu
D=/workspaces/.agent-state/kprog-lanes/C/proof-kfunc-original-btf
trap 'echo $? > "$D/check.exit"' EXIT
cd /workspaces/repository
c++ -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -Ivendor/libbpf/include/uapi -Irunner/build-llvmbpf/vendor/libbpf/prefix/include "$D/check.cpp" runner/build-llvmbpf/vendor/libbpf/pic-obj/libbpf.a -lelf -lz -o "$D/check"
"$D/check" /workspaces/.agent-state/kprog-lanes/C/cilium-packet-frontier/kfunc/request/generated/trusted_x86.bpf.o /workspaces/repository/kprog/tv/build-kernel-x86/vmlinux
"$D/check" /workspaces/.agent-state/kprog-lanes/C/cilium-packet-frontier/bmi2/request/generated/trusted_x86.bpf.o /workspaces/repository/kprog/tv/build-kernel-x86/vmlinux
