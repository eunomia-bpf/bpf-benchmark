#include <bpf/btf.h>
#include <bpf/libbpf.h>
#include <linux/bpf.h>
#include <gelf.h>
#include <cstdint>
#include <cstring>
#include <stdexcept>
#include <string>
#include <memory>
#include <iostream>
#include <fstream>
#include <vector>
#include <iterator>
extern "C" {
#include "/workspaces/repository/vendor/libbpf/src/relo_core.h"
}
void fail(const std::string &s) {throw std::runtime_error(s);}
#include "helper.inc"
std::unique_ptr<btf,decltype(&btf__free)> types(btf_func_linkage linkage, bool pointer, bool present=true) {
 auto b=std::unique_ptr<btf,decltype(&btf__free)>(btf__new_empty(),btf__free);
 if(!b || libbpf_get_error(b.get()))fail("new BTF");
 int value=pointer?btf__add_ptr(b.get(),0):btf__add_int(b.get(),"int",4,BTF_INT_SIGNED);
 int proto=btf__add_func_proto(b.get(),value);
 if(value<0||proto<0||btf__add_func_param(b.get(),"ctx",value)<0)fail("prototype BTF");
 if(present&&btf__add_func(b.get(),"cast",linkage,proto)<0)fail("function BTF");
 return b;
}
int main(int argc,char **argv) {
 auto local=types(BTF_FUNC_EXTERN,true), kernel=types(BTF_FUNC_GLOBAL,true), bad=types(BTF_FUNC_GLOBAL,false), missing=types(BTF_FUNC_EXTERN,true,false);
 GElf_Sym symbol={};symbol.st_info=GELF_ST_INFO(STB_GLOBAL,STT_NOTYPE);symbol.st_shndx=SHN_UNDEF;
 bpf_insn call={};call.code=BPF_JMP|BPF_CALL;call.src_reg=BPF_PSEUDO_CALL;call.imm=-1;
 unsigned count=0;
 auto check=[&](const btf *l,const btf *k,const char *name,GElf_Sym s,int64_t addend,bpf_insn insn,bool accept) {
  bool ok=true;try{relocate_vmlinux_proof_call(l,k,name,s,addend,insn);}catch(const std::runtime_error&){ok=false;}
  if(ok!=accept)fail("call relocation outcome");
  if(ok&&(insn.src_reg!=BPF_PSEUDO_KFUNC_CALL||insn.imm!=btf__find_by_name_kind(k,name,BTF_KIND_FUNC)||insn.off||insn.dst_reg||insn.code!=(BPF_JMP|BPF_CALL)))fail("resolved instruction bits");
  ++count;
 };
 check(local.get(),kernel.get(),"cast",symbol,0,call,true);
 check(local.get(),bad.get(),"cast",symbol,0,call,false);
 check(bad.get(),kernel.get(),"cast",symbol,0,call,false);
 check(missing.get(),kernel.get(),"cast",symbol,0,call,false);
 check(local.get(),missing.get(),"cast",symbol,0,call,false);
 check(local.get(),kernel.get(),nullptr,symbol,0,call,false);
 check(nullptr,kernel.get(),"cast",symbol,0,call,false);
 check(local.get(),nullptr,"cast",symbol,0,call,false);
 for(int addend:{-1,1})check(local.get(),kernel.get(),"cast",symbol,addend,call,false);
 for(int mode=0;mode<7;++mode){auto c=call;switch(mode){case 0:c.code=BPF_LD|BPF_DW|BPF_IMM;break;case 1:c.src_reg=0;break;case 2:c.src_reg=BPF_PSEUDO_KFUNC_CALL;break;case 3:c.dst_reg=1;break;case 4:c.off=1;break;case 5:c.imm=0;break;case 6:c.imm=123;break;}check(local.get(),kernel.get(),"cast",symbol,0,c,false);}
 auto s=symbol;s.st_info=GELF_ST_INFO(STB_WEAK,STT_NOTYPE);check(local.get(),kernel.get(),"cast",s,0,call,false);s=symbol;s.st_shndx=1;check(local.get(),kernel.get(),"cast",s,0,call,false);
 if(argc==3){
  auto l=std::unique_ptr<btf,decltype(&btf__free)>(btf__parse(argv[1],nullptr),btf__free);
  auto k=std::unique_ptr<btf,decltype(&btf__free)>(btf__parse(argv[2],nullptr),btf__free);
  if(!l||!k||libbpf_get_error(l.get())||libbpf_get_error(k.get()))fail("actual BTF parse");
  std::ifstream input(argv[1],std::ios::binary);std::vector<char> bytes((std::istreambuf_iterator<char>(input)),std::istreambuf_iterator<char>());
  elf_version(EV_CURRENT);auto e=std::unique_ptr<Elf,decltype(&elf_end)>(elf_memory(bytes.data(),bytes.size()),elf_end);if(!e)fail("actual ELF");
  auto original=source_proof_btf(e.get());
  auto opened=std::unique_ptr<bpf_object,decltype(&bpf_object__close)>(bpf_object__open_file(argv[1],nullptr),bpf_object__close);
  if(!opened||libbpf_get_error(opened.get()))fail("open actual proof object");
  auto normalized=btf__find_by_name_kind(bpf_object__btf(opened.get()),"bpf_cast_to_kern_ctx",BTF_KIND_FUNC);
  auto original_id=btf__find_by_name_kind(original.get(),"bpf_cast_to_kern_ctx",BTF_KIND_FUNC);
  if(normalized<=0||original_id<=0||btf_vlen(btf__type_by_id(bpf_object__btf(opened.get()),normalized))!=BTF_FUNC_GLOBAL||btf_vlen(btf__type_by_id(original.get(),original_id))!=BTF_FUNC_EXTERN)fail("actual extern normalization census");
  GElf_Sym actual_symbol={};actual_symbol.st_info=GELF_ST_INFO(STB_GLOBAL,STT_NOTYPE);actual_symbol.st_shndx=SHN_UNDEF;
  check(bpf_object__btf(opened.get()),k.get(),"bpf_cast_to_kern_ctx",actual_symbol,0,call,false);
  std::cout<<"actual libbpf open normalizes extern; original ELF BTF preserves declaration\n";
  Elf_Scn *section=nullptr;unsigned calls=0;
  while((section=elf_nextscn(e.get(),section))){GElf_Shdr h={};if(!gelf_getshdr(section,&h))fail("ELF header");if(h.sh_type!=SHT_REL)continue;
   auto data=elf_getdata(section,nullptr);auto symsec=elf_getscn(e.get(),h.sh_link);GElf_Shdr sh={};if(!data||!symsec||!gelf_getshdr(symsec,&sh))fail("relocation symbols");auto symbols=elf_getdata(symsec,nullptr);auto code=elf_getdata(elf_getscn(e.get(),h.sh_info),nullptr);
   for(size_t i=0;i<h.sh_size/h.sh_entsize;++i){GElf_Rel rel={};if(!gelf_getrel(data,i,&rel))fail("actual relocation");if(GELF_R_TYPE(rel.r_info)!=R_BPF_64_32)continue;
    GElf_Sym sym={};if(!gelf_getsym(symbols,GELF_R_SYM(rel.r_info),&sym))fail("actual symbol");const char *name=elf_strptr(e.get(),sh.sh_link,sym.st_name);if(!code||rel.r_offset+sizeof(bpf_insn)>code->d_size)fail("actual instruction extent");
    bpf_insn raw={};__builtin_memcpy(&raw,(char*)code->d_buf+rel.r_offset,sizeof(raw));check(original.get(),k.get(),name,sym,0,raw,true);++calls;
   }
  }
  if(calls!=1)fail("actual kfunc census");std::cout<<"original whole Cilium ELF + matching kernel BTF: "<<calls<<" exact relocation passes\n";
 }
 std::cout<<"actual vmlinux proof-call relocation: "<<count<<" BTF/site/prototype cases pass\n";
}
