from pathlib import Path
import os,json,subprocess,tarfile,sys,datetime,traceback,select
G=Path(__file__).resolve().parent;C=G.parent.parent;R=Path('/workspaces/repository');Q=C/'design-only/raw-helper-context';O=R/'corpus/results/kprog_app_coverage_20261108/kernel-selftests-dynptr-family'
sys.path.insert(0,str(C));from publish_owned import publish
def notice(s):
 msg='\n- LOCAL C FOR A/R/V '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': '+s+'\n'
 for p in [C.parent/'COORDINATION.md',C/'last.md']:
  with p.open('a')as f:f.write(msg)
def save(phase,**kw):(G/'status.json').write_text(json.dumps(dict(phase=phase,**kw),indent=2)+'\n')
try:
 O.mkdir(exist_ok=True);(O/'launch.json').write_bytes((G/'launch.json').read_bytes())
 (O/'README.md').write_text('# Entire original239 x86 kernel C replay after dynptr helper extension\n\nAll239 original native entries and annotations from ed803f22c retain bytes. All39 whole original resource BPF objects retain the successful60e37d894 compilation and full pointee BTF. Captured source includes generic RAW helper context identity a808041cc, generic named dynptr/per-CPU/strncmp bodies and common helper resolution. The callback and kfunc generation frontiers retain their actual stages. This epoch uses the same paired kernel/module and bpf_testmod, current warm worker/linker and current producer with every BPF program autoload=false; native P submits through source_prog_id0. Every request is load-only; native executions0.\n\nCommand: `make -f '+str(G/'Makefile')+' run` in a private captured-source mount namespace. Serial20-23/12GiB guest follows original38 RAW-context replay and the current paired application chain. Each resource/generation/compiler/verifier/install outcome joins the original annotation. Coordinator-classified native-compile differences retain raw installed stages. Runtime admission additions0.\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz')as tf:
  for name in ['launch.json','source','table','Makefile','mount.py','controller.py','testmod-source','testmod-build']:tf.add(G/name,arcname=name)
 commit=publish([str((O/n).relative_to(R))for n in ['README.md','launch.json','launch-inputs.tar.gz']],'Run original x86 kernel C entries with complete dynptr helper bodies',G/'launch-publication.json');save('queued_after_raw_context38',launch_publication=commit);notice('PUSHED '+commit+' priority2a entire original239 x86 successor with generic dynptr/strncmp/perCPU helpers, RAW actualCTX and all39resources; captured source/worker/linker retain immutable bytes. Guest follows raw-context original38,20-23/12GiB. Nativeexecutions0; runtime admission additions0.')
 try:
  fd=os.pidfd_open(int((Q/'controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 save('running',launch_publication=commit)
 with(G/'run.log').open('w')as f:p=subprocess.run(['unshare','--mount','--propagation','private','python3',str(G/'mount.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1','PYTHONPYCACHEPREFIX':str(G/'pycache')})
 (G/'run.exit').write_text(str(p.returncode)+'\n');report=dict(make_exit=p.returncode,native_execution_count=0);paths=[]
 q=G/'out/submissions.json'
 if q.exists():
  (O/'submissions.json').write_bytes(q.read_bytes());paths.append(O/'submissions.json');report['counts']=json.loads(q.read_text())['counts']
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'summary.json')
 with tarfile.open(O/'raw.tar.gz','w:gz')as tf:
  for name in ['out','tmp','run.log','run.exit']:tf.add(G/name,arcname=name)
 paths.append(O/'raw.tar.gz');commit=publish([str(p.relative_to(R))for p in paths],'Record original x86 kernel C outcomes after dynptr helper coverage',G/'result-publication.json');save('finished',result_publication=commit,**report);notice('PUSHED '+commit+' original239 x86 dynptr helper terminal '+json.dumps(report)+'. Full native/source/resource/compiler/verifier rows retained; runtime admission additions0.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
