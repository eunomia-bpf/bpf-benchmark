from pathlib import Path
from datetime import datetime,timezone
import os,select,sys,json,importlib.util,struct,hashlib
from elftools.elf.elffile import ELFFile
T=Path(__file__).parent;R=Path('/workspaces/repository');N=T.parent.parent/'stack-spill-values'
try:
 fd=os.pidfd_open(int((N/'canonical-components.pid').read_text()));select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
spec=importlib.util.spec_from_file_location('tetragon_precise_generation',R/'kprog/x86/trusted_specializer.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
os.environ['CLANG']='/usr/lib/llvm-18/bin/clang'
a=json.loads((T/'artifacts.json').read_text());meta=json.loads((T/'generation.metadata.json').read_text());d=dict(started=datetime.now(timezone.utc).isoformat(),native_sha256=hashlib.sha256((T/'request.native.o').read_bytes()).hexdigest(),original_artifact=a,sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [R/'kprog/x86/x86_sim_local_bpf.h',R/'kprog/x86/micro-prog/generate_micro_sim_proofs.py',R/'kprog/x86/micro-prog/x86_abi.py']})
(T/'input.json').write_text(json.dumps(d,indent=2)+'\n')
try:
 result=m.specialize((T/'request.native.o').read_bytes(),a['symbol'],meta,T/'generated',R/'kprog/x86/native_lab/native_link/target/release/native-link');d['result']=result
 with Path(result['simulator_object']).open('rb')as f:
  d['sections']=[]
  for s in ELFFile(f).iter_sections():
   if s['sh_flags']&4 and s.data_size:
    ins=list(struct.iter_unpack('<BBhi',s.data()));d['sections'].append(dict(name=s.name,instructions=len(ins),maximum_fp_minus_offset=-min([0]+[o for c,r,o,i in ins if ((r&15)==10 or(r>>4)==10)and o<0])))
 d['exit']=0
except Exception as error:
 d.update(exit=1,error=str(error));raise
finally:
 d['finished']=datetime.now(timezone.utc).isoformat();(T/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
