from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,time,struct,hashlib
from elftools.elf.elffile import ELFFile
T=Path(__file__).parent;R=Path('/workspaces/repository');A=T/'alias';O=T/'compiler-flags';O.mkdir(exist_ok=True)
base=A/'source/kprog/x86/x86_sim_local_bpf_baseline.h';base.write_bytes((A/'before.h').read_bytes());source=O/'baseline.c';source.write_text((T/'generated/trusted_x86.bpf.c').read_text().replace(str(R/'kprog/x86/x86_sim_local_bpf.h'),str(base)))
rows=[]
for name,source in [('baseline',source),('alias',A/'captured.c')]:
 obj=O/(name+'.bpf.o');command=['/usr/lib/llvm-18/bin/clang','-g','-O2','-mcpu=v4','-target','bpf','-mllvm','-bpf-stack-size=4096','-D__TARGET_ARCH_x86','-I'+str(R/'kprog/x86'),'-I'+str(R/'vendor/libbpf/include/uapi'),'-I'+str(R/'vendor/libbpf/src'),'-I/usr/include/x86_64-linux-gnu','-c',str(source),'-o',str(obj)]
 start=time.monotonic()
 with(O/(name+'.log')).open('w')as log:q=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 row=dict(name=name,command=command,exit=q.returncode,wall_seconds=time.monotonic()-start,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),sections=[])
 if q.returncode==0:
  with obj.open('rb')as f:
   for s in ELFFile(f).iter_sections():
    if s['sh_flags']&4 and s.data_size:
     ins=list(struct.iter_unpack('<BBhi',s.data()));row['sections'].append(dict(name=s.name,instructions=len(ins),maximum_fp_minus_offset=-min([0]+[o for c,r,o,i in ins if ((r&15)==10 or(r>>4)==10)and o<0])))
 rows.append(row);(O/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
(T/'compiler-flags.exit').write_text('0\n')
